-- (v1.2.79) Menu staff (F10) › Organisations et entreprises : le coffre et les véhicules de n'importe quelle organisation ou entreprise.
--   · Coffre : s'ouvre à distance dans l'inventaire (prendre, déposer depuis son sac) ; « Ajouter un objet » le remplit directement.
--   · Véhicules : liste (état, qui l'a donné), ajouter un véhicule neuf, supprimer, rendre un véhicule donné à son ancien propriétaire.
-- Tout passe par le journal du staff et le journal d'audit.
local G, P, DB = PB.G, PB.Perm, PB.DB
local S = G.Staff
if not S or not S.Def then return end
P.Register('staff.orgs', "Menu staff : coffres et véhicules des organisations et des entreprises", 'staff', true)

-- catégorie du menu, juste avant le Builder
do
    local at = #S.CATS + 1
    for i, c in ipairs(S.CATS) do if c.id == 'builder' then at = i break end end
    table.insert(S.CATS, at, { id = 'orgs', label = 'Organisations et entreprises', icon = 'briefcase', perm = 'staff.orgs' })
end

local function clean(s, n) return (tostring(s or ''):gsub('[%c<>|"\\]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, n)) end
local function gangDef(id) return G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[tostring(id or '')] end
local function target(p)
    p = type(p) == 'table' and p or {}
    local kind, id = tostring(p.kind or ''), tostring(p.org or '')
    if kind == 'gang' then local d = gangDef(id) return d and { kind = 'gang', id = id, label = d.label or id } or nil end
    if kind == 'biz' then local b = G.Biz and G.Biz.Get(id) return b and { kind = 'biz', id = b.id, label = b.label or b.id } or nil end
    return nil
end
local function playerName(license)
    if not license or license == '' then return nil end
    local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { license })
    local n = r and ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') or ''
    return n ~= '' and n or 'un joueur'
end
local function vehiclesOf(o)
    if not G.Garage then return {} end
    return o.kind == 'gang' and G.Garage.OfGang(o.id) or G.Garage.OfBiz(o.id)
end
local function stashesOf(o)
    if o.kind == 'gang' then return { { owner = 'o:' .. o.id, label = "Coffre de l'organisation" } } end
    local out = {}
    for _, r in ipairs(DB.q('SELECT id, label FROM pb_inv_stashes WHERE biz = ? ORDER BY label', { o.id }) or {}) do out[#out + 1] = { owner = 's:' .. r.id, label = r.label } end
    return out
end
local function stashOk(o, owner)
    for _, s in ipairs(stashesOf(o)) do if s.owner == owner then return s end end
    return nil
end
local function vehOf(o, plate)
    local v = G.Garage and G.Garage.Vehicle(tostring(plate or ''))
    if not v then return nil end
    if (o.kind == 'gang' and v.gang == o.id) or (o.kind == 'biz' and v.biz == o.id) then return v end
    return nil
end
local STATE = { out = 'Sorti', impound = 'En fourrière', garage = 'Au garage' }

-- Liste des organisations et entreprises (ouverture du menu)
table.insert(S.SpecExtra, function(src, spec)
    if not P.Has(src, 'staff.orgs') then return end
    local gangs, bizs = {}, {}
    for id, d in pairs(G.Tags and G.Tags.GangDefs and G.Tags.GangDefs() or {}) do gangs[#gangs + 1] = { id = id, label = d.label or id } end
    table.sort(gangs, function(a, b) return a.label < b.label end)
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do bizs[#bizs + 1] = { id = b.id, label = b.label or b.id } end
    spec.orgadmin = { gangs = gangs, bizs = bizs }
end)

-- Fiche d'une organisation / entreprise : coffres, caisse, véhicules (envoyée à la demande)
local function sendSheet(src, o)
    local vehs = {}
    for _, v in ipairs(vehiclesOf(o)) do
        local donor = playerName(v.license)
        vehs[#vehs + 1] = { plate = v.plate, label = (v.label and v.label ~= '') and v.label or v.model, model = v.model,
            state = STATE[v.state or 'garage'] or 'Au garage', donor = donor, given = donor ~= nil or nil }
    end
    local stashes = {}
    for _, s in ipairs(stashesOf(o)) do
        local n = 0
        for _, it in pairs(G.Inv and G.Inv.Contents(s.owner) or {}) do n = n + (tonumber(it.qty) or 0) end
        stashes[#stashes + 1] = { owner = s.owner, label = s.label, count = n }
    end
    local money
    if o.kind == 'gang' and G.Orgs and G.Orgs.Vault then money = G.Orgs.Vault(o.id) end
    TriggerClientEvent('pb:g:staff:org', src, PB.Json({ kind = o.kind, id = o.id, label = o.label, money = money, stashes = stashes, vehicles = vehs }))
    return true
end
S.Def('org_view', 'staff.orgs', { quiet = true, run = function(src, _, p)
    local o = target(p)
    if not o then return false, 'Organisation ou entreprise introuvable.' end
    return sendSheet(src, o)
end })

S.Def('org_stash', 'staff.orgs', { log = true, run = function(src, _, p)
    local o = target(p)
    if not o then return false, 'Organisation ou entreprise introuvable.' end
    local s = stashOk(o, tostring(p.stash or ''))
    if not s then return false, 'Coffre introuvable.' end
    if not G.Inv or not G.Inv.OpenStaffView(src, s.owner, s.label .. ' · ' .. o.label, not (S.ReadOnly and S.ReadOnly(src))) then return false, "Impossible d'ouvrir le coffre pour le moment." end
    return true, nil
end })

S.Def('org_item', 'staff.orgs', { log = true, run = function(src, _, p)
    local o = target(p)
    if not o then return false, 'Organisation ou entreprise introuvable.' end
    local s = stashOk(o, tostring(p.stash or ''))
    if not s then return false, 'Coffre introuvable.' end
    local item = clean(p.item, 48):lower()
    local qty = math.floor(tonumber(p.qty) or 0)
    if item == '' or not G.Inv.Def(item) then return false, 'Objet inconnu (nom exact, ex. water).' end
    if qty < 1 or qty > 1000 then return false, 'Quantité entre 1 et 1000.' end
    local ok, why = G.Inv.Add(s.owner, item, qty)
    if not ok then return false, why or 'Le coffre est plein.' end
    if G.Inv.PushOwners then G.Inv.PushOwners(s.owner) end
    PB.Audit.Log('staff', 'org.item.add', src, s.owner, nil, { item = item, qty = qty, org = o.id })
    sendSheet(src, o)
    return true, ('%d × %s ajouté(s) dans %s.'):format(qty, G.Inv.Def(item).label or item, s.label)
end })

S.Def('org_veh_add', 'staff.orgs', { log = true, run = function(src, _, p)
    local o = target(p)
    if not o then return false, 'Organisation ou entreprise introuvable.' end
    local model = clean(p.model, 32):lower()
    if not model:match('^[%w_]+$') or #model < 2 then return false, 'Modèle invalide (ex. sultan).' end
    local label = clean(p.label, 64)
    if label == '' then label = model:sub(1, 1):upper() .. model:sub(2) end
    local plate
    if o.kind == 'gang' then
        local e
        plate, e = G.Orgs.AddVehicle(o.id, model, label)   -- respecte le maximum de véhicules par organisation
        if not plate then return false, e end
    else
        plate = G.Orgs and G.Orgs.NewPlate and G.Orgs.NewPlate()
        if not plate then return false, 'Aucune plaque disponible.' end
        DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price, biz) VALUES (?, ?, ?, ?, ?, ?, ?)', { '', plate, model, label, os.time(), 0, o.id })
    end
    PB.Audit.Log('staff', 'org.vehicle.add', src, plate, nil, { org = o.id, kind = o.kind, model = model })
    sendSheet(src, o)
    return true, ('%s (%s) ajouté au garage de %s.'):format(label, plate, o.label)
end })

S.Def('org_veh_del', 'staff.orgs', { log = true, run = function(src, _, p)
    local o = target(p)
    if not o then return false, 'Organisation ou entreprise introuvable.' end
    local v = vehOf(o, p.plate)
    if not v then return false, "Ce véhicule n'appartient pas (ou plus) à " .. o.label .. '.' end
    G.Garage.Wipe(v)
    PB.Audit.Log('staff', 'org.vehicle.delete', src, v.plate, { org = o.id, model = v.model, license = v.license }, nil)
    sendSheet(src, o)
    return true, ('%s (%s) supprimé définitivement.'):format(v.label or v.model, v.plate)
end })

S.Def('org_veh_back', 'staff.orgs', { log = true, run = function(src, _, p)
    local o = target(p)
    if not o then return false, 'Organisation ou entreprise introuvable.' end
    local v = vehOf(o, p.plate)
    if not v then return false, "Ce véhicule n'appartient pas (ou plus) à " .. o.label .. '.' end
    if (v.license or '') == '' then return false, "Ce véhicule n'a pas été donné par un joueur." end
    DB.exec(o.kind == 'gang' and "UPDATE pb_vehicles SET gang = '' WHERE plate = ?" or "UPDATE pb_vehicles SET biz = '' WHERE plate = ?", { v.plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { v.plate })
    PB.Audit.Log('staff', 'org.vehicle.back', src, v.plate, { org = o.id }, { license = v.license })
    sendSheet(src, o)
    return true, ('%s rendu à %s.'):format(v.label or v.model, playerName(v.license))
end })
