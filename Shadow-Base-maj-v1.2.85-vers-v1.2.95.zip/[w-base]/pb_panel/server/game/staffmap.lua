-- (v1.2.91) Outils de surveillance du staff :
--   · Carte des joueurs : tous les joueurs sur la carte (et la mini-carte) du membre du staff, avec un filtre (tous, staff en service,
--     une entreprise, un gang). Les positions viennent du serveur toutes les 2 s : même les joueurs loin de lui apparaissent.
--   · Caméra libre : le staff se détache de son personnage (invisible, immobile) pour filmer ou surveiller sans être vu.
local G, P = PB.G, PB.Perm
local S = G.Staff
if not S or not S.Def then return end

local watch = {}   -- src -> { kind = 'all' | 'staff' | 'job' | 'gang', id = '' }
AddEventHandler('playerDropped', function() watch[source] = nil end)
local jobCache = {}   -- src -> { at, biz, label }
AddEventHandler('playerDropped', function() jobCache[source] = nil end)
local function jobOf(src)
    local c = jobCache[src]
    if c and os.time() - c.at < 30 then return c end
    local j = G.Biz and G.Biz.Job and G.Biz.Job(src)
    c = { at = os.time(), biz = j and j.biz or nil, label = j and j.label or nil }
    jobCache[src] = c
    return c
end
local function nameOf(src)
    local i = G.Identity and G.Identity(src)
    local n = i and (((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) or ''
    return n ~= '' and n or (GetPlayerName(src) or ('Joueur ' .. src))
end
local function keep(f, src)
    if f.kind == 'all' then return true end
    if f.kind == 'staff' then return S.OnDuty(src) end
    if f.kind == 'job' then return jobOf(src).biz == f.id end
    if f.kind == 'gang' then local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src) return g ~= nil and g.id == f.id end
    return false
end

S.Def('pmap', 'staff.players', { quiet = true, run = function(src, _, p)
    p = type(p) == 'table' and p or {}
    if p.on == false then watch[src] = nil TriggerClientEvent('pb:g:staff:pmap', src, PB.Json({ off = true })) return true, 'Carte des joueurs masquée.' end
    local kind = ({ all = 'all', staff = 'staff', job = 'job', gang = 'gang' })[tostring(p.kind or 'all')] or 'all'
    watch[src] = { kind = kind, id = tostring(p.id or ''):sub(1, 32) }
    return true, 'Carte des joueurs affichée (carte et mini-carte).'
end })
S.Def('freecam', 'staff.spectate', { quiet = true, run = function(src)
    TriggerClientEvent('pb:g:staff:fx', src, 'freecam', '{}')
    return true
end, log = true })

table.insert(S.SpecExtra, function(src, spec)
    if not P.Has(src, 'staff.players') then return end
    local jobs, gangs = {}, {}
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do jobs[#jobs + 1] = { b.id, b.label or b.id } end
    for id, d in pairs(G.Tags and G.Tags.GangDefs and G.Tags.GangDefs() or {}) do gangs[#gangs + 1] = { id, d.label or id } end
    table.sort(gangs, function(a, b) return a[2] < b[2] end)
    local w = watch[src]
    spec.pmap = { on = w ~= nil, kind = w and w.kind or 'all', id = w and w.id or '', jobs = jobs, gangs = gangs }
end)

CreateThread(function()
    while true do
        Wait(2000)
        if next(watch) then
            local pos = {}
            for src in pairs(G.Players()) do
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 then local c = GetEntityCoords(ped) if c then pos[src] = c end end
            end
            for w, f in pairs(watch) do
                if not (S.OnDuty(w) and P.Has(w, 'staff.players')) then
                    watch[w] = nil
                    TriggerClientEvent('pb:g:staff:pmap', w, PB.Json({ off = true }))
                else
                    local list = {}
                    for src, c in pairs(pos) do
                        if src ~= w and keep(f, src) then
                            local j = jobOf(src)
                            local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
                            list[#list + 1] = { i = src, u = G.UidOf and G.UidOf(src) or src, n = nameOf(src), x = math.floor(c.x), y = math.floor(c.y), z = math.floor(c.z),
                                j = j.label, g = g and g.label or nil, s = S.OnDuty(src) or nil }
                        end
                    end
                    TriggerClientEvent('pb:g:staff:pmap', w, PB.Json({ list = list }))
                end
            end
        end
    end
end)
