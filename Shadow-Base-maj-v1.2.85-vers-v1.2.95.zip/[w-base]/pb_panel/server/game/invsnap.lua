-- Sauvegardes d'inventaire : une photo du sac de chaque joueur toutes les 30 minutes (si le contenu a changé) et à la déconnexion.
-- Le staff retrouve le sac d'un joueur à une date donnée et le restaure (une sauvegarde « avant restauration » est faite d'abord).
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('invsnap.restore', "Restaurer l'inventaire d'un joueur depuis une sauvegarde", 'staff', true)
PB.Migrate('347_inv_snap', "Sauvegardes d'inventaire", function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_inv_snap (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, at INT NOT NULL, reason VARCHAR(40) NOT NULL DEFAULT '', items INT NOT NULL DEFAULT 0, sig VARCHAR(40) NOT NULL DEFAULT '', data MEDIUMTEXT NOT NULL, PRIMARY KEY (id), KEY k_lic (license, at))]]))
end)
-- (v1.2.90) l'argent (espèces, banque) est photographié avec le sac : « retour en arrière » complet depuis le menu staff
PB.Migrate('563_inv_snap_money', "Sauvegardes : argent du joueur", { 'ALTER TABLE pb_inv_snap ADD COLUMN cash BIGINT NULL DEFAULT NULL', 'ALTER TABLE pb_inv_snap ADD COLUMN bank BIGINT NULL DEFAULT NULL' })
PB.Cfg.Define('invsnap', { enabled = true, every_min = 30, keep = 48, keep_days = 14 })
local S = {}
G.InvSnap = S
local function cfg(k, d) return PB.Cfg.Get('invsnap', k, d) end
local function now() return os.time() end
local function contents(license)
    local rows = DB.q('SELECT slot, item, qty FROM pb_inv WHERE owner = ? ORDER BY slot', { 'p:' .. license }) or {}
    local parts, n = {}, 0
    for _, r in ipairs(rows) do parts[#parts + 1] = r.slot .. ':' .. r.item .. ':' .. r.qty n = n + r.qty end
    return rows, table.concat(parts, ','), n
end
-- empreinte courte du contenu (on ne refait pas de sauvegarde si rien n'a bougé)
local function sigOf(s) local h = 5381 for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end return ('%08x%d'):format(h, #s) end
local function moneyOf(license)
    for _, p in pairs(G.Players()) do if p.license == license then return tonumber(p.row.cash) or 0, tonumber(p.row.bank) or 0 end end
    local r = DB.one('SELECT cash, bank FROM pb_players WHERE license = ?', { license })
    return r and tonumber(r.cash) or 0, r and tonumber(r.bank) or 0
end
function S.Take(license, reason, force)
    if cfg('enabled', true) == false and not force then return false end
    local rows, flat, n = contents(license)
    local cash, bank = moneyOf(license)
    local sig = sigOf(flat .. '|' .. cash .. '|' .. bank)
    local last = DB.one('SELECT sig FROM pb_inv_snap WHERE license = ? ORDER BY id DESC LIMIT 1', { license })
    if not force and last and last.sig == sig then return false end
    DB.insert('INSERT INTO pb_inv_snap (license, at, reason, items, sig, data, cash, bank) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', { license, now(), tostring(reason or ''):sub(1, 40), n, sig, PB.Json(rows), cash, bank })
    -- on ne garde que les N dernières par joueur
    local keep = math.floor(tonumber(cfg('keep', 48)) or 48)
    local cut = DB.one('SELECT id FROM pb_inv_snap WHERE license = ? ORDER BY id DESC LIMIT 1 OFFSET ?', { license, keep })
    if cut then DB.exec('DELETE FROM pb_inv_snap WHERE license = ? AND id <= ?', { license, cut.id }) end
    return true
end
function S.Restore(license, id, by, withMoney)
    local snap = DB.one('SELECT * FROM pb_inv_snap WHERE id = ? AND license = ?', { tonumber(id) or -1, license })
    if not snap then return false, 'Sauvegarde introuvable.' end
    local rows = PB.FromJson(snap.data, nil)
    if type(rows) ~= 'table' then return false, 'Sauvegarde illisible.' end
    S.Take(license, 'avant restauration', true)
    local owner = 'p:' .. license
    DB.exec('DELETE FROM pb_inv WHERE owner = ?', { owner })
    for _, r in ipairs(rows) do
        if tonumber(r.slot) and tostring(r.item or '') ~= '' and (tonumber(r.qty) or 0) > 0 then
            DB.exec('INSERT INTO pb_inv (owner, slot, item, qty) VALUES (?, ?, ?, ?)', { owner, math.floor(r.slot), tostring(r.item), math.floor(r.qty) })
        end
    end
    local money = withMoney and tonumber(snap.cash) ~= nil
    if money then
        local c, b = math.max(0, math.floor(tonumber(snap.cash) or 0)), math.max(0, math.floor(tonumber(snap.bank) or 0))
        DB.exec('UPDATE pb_players SET cash = ?, bank = ? WHERE license = ?', { c, b, license })
        for src, p in pairs(G.Players()) do if p.license == license then p.row.cash, p.row.bank = c, b if G.PushState then pcall(G.PushState, src) end end end
    end
    for src, p in pairs(G.Players()) do if p.license == license and G.Inv and G.Inv.Push then pcall(G.Inv.Push, src) G.Notify(src, { type = 'info', title = 'Retour en arrière', text = money and 'Ton inventaire et ton argent ont été restaurés par le staff.' or 'Ton inventaire a été restauré par le staff.' }) end end
    if G.Timeline then G.Timeline.Add(license, 'inv', ('Inventaire restauré à la sauvegarde du %s (par %s)'):format(os.date('%d/%m %H:%M', snap.at), tostring(by or 'staff')), 'warn') end
    return true, ('%s restauré (%s).'):format(money and 'Inventaire et argent' or 'Inventaire', os.date('%d/%m/%Y %H:%M', snap.at))
end
-- toutes les X minutes pour les joueurs connectés, et à la déconnexion
CreateThread(function()
    while true do
        Wait(math.max(5, tonumber(cfg('every_min', 30)) or 30) * 60000)
        for _, p in pairs(G.Players()) do pcall(S.Take, p.license, 'automatique') end
        pcall(DB.exec, 'DELETE FROM pb_inv_snap WHERE at < ?', { now() - (tonumber(cfg('keep_days', 14)) or 14) * 86400 })
    end
end)
AddEventHandler('playerDropped', function() local p = G.Get(source) if p then local lic = p.license SetTimeout(3000, function() pcall(S.Take, lic, 'déconnexion') end) end end)

-- Menu staff › un joueur › Retour en arrière : les sauvegardes de ses dernières 48 h, puis restauration (sac + argent)
local St = G.Staff
if St and St.Def then
    St.Def('rollback', 'invsnap.restore', { target = true, quiet = true, run = function(src, t)
        local p = G.Get(t)
        S.Take(p.license, 'consultation staff')
        local list = {}
        for _, r in ipairs(DB.q('SELECT id, at, reason, items, cash, bank FROM pb_inv_snap WHERE license = ? AND at >= ? ORDER BY id DESC LIMIT 40', { p.license, now() - 48 * 3600 }) or {}) do
            list[#list + 1] = { id = r.id, at = os.date('%d/%m %H:%M', r.at), ago = math.floor((now() - r.at) / 60), reason = r.reason, items = r.items, cash = tonumber(r.cash), bank = tonumber(r.bank) }
        end
        TriggerClientEvent('pb:g:staff:rollback', src, PB.Json({ id = t, name = (p.row.firstname or '') .. ' ' .. (p.row.lastname or ''), list = list }))
        return true
    end })
    St.Def('rollback_do', 'invsnap.restore', { target = true, rank = true, run = function(src, t, p)
        local pl = G.Get(t)
        local ok, msg = S.Restore(pl.license, tonumber(p.snap), PB.Actor(src).name, p.money ~= false)
        if not ok then return false, msg end
        PB.Audit.Log('staff', 'rollback', src, pl.license, nil, nil, { snap = p.snap, money = p.money ~= false })
        return true, msg
    end, log = true })
end

PB.Action('invsnap.restore', 'invsnap.restore', function(ctx, p)
    local ok, msg = S.Restore(tostring(p.lic or ''), p.id, ctx.actor and ctx.actor.name)
    if not ok then return false, msg end
    ctx.audit('staff', 'invsnap.restore', tostring(p.lic), nil, nil, { id = p.id })
    ctx.toast = msg
    return true
end, { critical = true, confirm = { title = "Restaurer cet inventaire ?", text = "Le sac actuel du joueur est remplacé (une sauvegarde de l'état actuel est faite avant).", danger = true } })
PB.Action('invsnap.take', 'invsnap.restore', function(ctx, p)
    S.Take(tostring(p.lic or ''), 'manuelle (staff)', true)
    ctx.toast = 'Sauvegarde faite.'
    return true
end)

local form = PB.Form.Cfg({ ns = 'invsnap', id = 'settings', title = "Sauvegardes d'inventaire", perm = 'invsnap.restore', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Sauvegardes automatiques', default = true },
    { k = 'every_min', type = 'number', label = 'Toutes les (minutes)', default = 30, min = 5, max = 720 },
    { k = 'keep', type = 'number', label = 'Sauvegardes gardées par joueur', default = 48, min = 5, max = 500 },
    { k = 'keep_days', type = 'number', label = 'Conservation (jours)', default = 14, min = 1, max = 180 },
} })
local function nameOf(lic) local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { lic }) return r and ((r.firstname or '') .. ' ' .. (r.lastname or '')) or lic end
PB.Module({
    id = 'invsnap', label = "Sauvegardes d'inventaire", icon = 'bag', group = 'Serveur', order = 99, perm = 'invsnap.restore', hint = 'Retrouver et restaurer le sac d\'un joueur',
    caps = function() return PB.Capsify({
        { 'Photo du sac toutes les 30 min et à la déconnexion', 'ok', 'Seulement si le contenu a changé.' },
        { 'Restauration à une date', 'ok', "Remplace le sac (sauvegarde de l'état actuel faite avant) ; le joueur connecté voit son sac se mettre à jour." },
        { 'Coffres et véhicules', 'off', 'Seul le sac du personnage est sauvegardé.' },
    }) end,
    doc = "## Sauvegardes d'inventaire\nCherche le joueur, choisis la date, regarde le contenu, puis **Restaurer**. Pratique après un bug, une duplication ou une perte injuste.",
    view = function(ctx)
        return { tabs = {
            { id = 'find', label = 'Joueur', icon = 'user', build = function(_, params)
                params = params or {}
                local blocks = { { type = 'form', id = 'invsnap.find', title = 'Chercher un joueur', cols = 2, fields = { { k = 'q', type = 'text', label = 'Nom, prénom ou licence', maxlen = 64 } }, values = { q = params.q or '' }, submit = { nav = { tab = 'find' }, as = 'params', label = 'Chercher' } } }
                local q = tostring(params.q or ''):sub(1, 64)
                if q ~= '' and not params.lic then
                    local like = '%' .. q:gsub('[%%_]', '') .. '%'
                    local rows = {}
                    for _, r in ipairs(DB.q('SELECT license, firstname, lastname, last_seen FROM pb_players WHERE firstname LIKE ? OR lastname LIKE ? OR license LIKE ? ORDER BY last_seen DESC LIMIT 30', { like, like, like }) or {}) do
                        rows[#rows + 1] = { name = ((r.firstname or '') .. ' ' .. (r.lastname or '')), license = r.license, seen = tonumber(r.last_seen) or 0, actions = { { nav = { tab = 'find', params = { lic = r.license } }, label = 'Sauvegardes', icon = 'bag' } } }
                    end
                    blocks[#blocks + 1] = B.table({ id = 'isf', title = 'Résultats', columns = { { k = 'name', label = 'Personnage' }, { k = 'license', label = 'Licence', type = 'mono' }, { k = 'seen', label = 'Vu', type = 'date' } }, rows = rows, empty = 'Personne ne correspond.' })
                end
                if params.lic then
                    local lic = tostring(params.lic):sub(1, 80)
                    local rows = {}
                    for _, r in ipairs(DB.q('SELECT id, at, reason, items, data FROM pb_inv_snap WHERE license = ? ORDER BY id DESC LIMIT 60', { lic }) or {}) do
                        local list = PB.FromJson(r.data, {}) or {}
                        local parts = {}
                        for i = 1, math.min(6, #list) do parts[#parts + 1] = list[i].qty .. '× ' .. list[i].item end
                        rows[#rows + 1] = { at = r.at, reason = r.reason, items = r.items, detail = table.concat(parts, ', ') .. (#list > 6 and (' … (+' .. (#list - 6) .. ')') or ''),
                            actions = { { action = 'invsnap.restore', label = 'Restaurer', icon = 'refresh', danger = true, payload = { lic = lic, id = r.id } } } }
                    end
                    blocks[#blocks + 1] = B.actions({ { action = 'invsnap.take', label = 'Sauvegarder maintenant', icon = 'bag', payload = { lic = lic } } }, nameOf(lic))
                    blocks[#blocks + 1] = B.table({ id = 'isl', title = 'Sauvegardes de ' .. nameOf(lic), columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'reason', label = 'Origine' }, { k = 'items', label = 'Objets', type = 'num' }, { k = 'detail', label = 'Contenu' } }, rows = rows, empty = 'Aucune sauvegarde pour ce joueur.' })
                end
                return blocks
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
