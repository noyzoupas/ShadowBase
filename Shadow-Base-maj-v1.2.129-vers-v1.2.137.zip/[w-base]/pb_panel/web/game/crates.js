/* (patch 335) Ouverture d'une caisse : bande de récompenses qui défile puis s'arrête sur le gain.
   Jeu → NUI : G.send('crates.open', { crate, color, strip: [{label, kind}], at, win: {label, kind} }). Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let box = null, timer = 0;
const KIND = { money: 'Argent', bank: 'Banque', item: 'Objet', weapon: 'Arme', vehicle: 'Véhicule' };
function drop() { clearTimeout(timer); if (box) { box.remove(); box = null; } }
G.on('crates.open', function (d) {
  drop();
  const strip = (Array.isArray(d.strip) ? d.strip : []).slice(0, 60);
  const at = Math.max(0, Math.min(strip.length - 1, Number(d.at) || 0));
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color) ? d.color : '#9aa4b2';
  const CARD = 132, GAP = 8;
  const cells = strip.map((r) => h('div', { class: 'cr-c' }, h('small', null, KIND[r.kind] || ''), h('b', null, String(r.label || ''))));
  const track = h('div', { class: 'cr-tr' }, cells);
  const win = h('div', { class: 'cr-win' }, h('small', null, String(d.crate || 'Caisse')), h('b', null, String((d.win && d.win.label) || '')), h('em', null, KIND[(d.win && d.win.kind)] || ''));
  box = h('div', { id: 'g-crates', style: { '--cc': col } },
    h('div', { class: 'cr-t' }, String(d.crate || 'Caisse')),
    h('div', { class: 'cr-v' }, h('div', { class: 'cr-m' }), track), win);
  G.root.appendChild(box);
  const vw = box.querySelector('.cr-v').offsetWidth || 700;
  const target = at * (CARD + GAP) + CARD / 2 - vw / 2 + (Math.random() * 40 - 20);
  requestAnimationFrame(() => requestAnimationFrame(() => { track.style.transform = 'translateX(' + (-target) + 'px)'; }));
  timer = setTimeout(() => { if (!box) return; box.classList.add('done'); cells[at] && cells[at].classList.add('on'); timer = setTimeout(drop, 7000); }, 5600);
});
G.on('crates.close', drop);
})();
