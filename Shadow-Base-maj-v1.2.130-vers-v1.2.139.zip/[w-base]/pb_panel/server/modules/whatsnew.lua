-- Nouveautés : journal des mises à jour affiché dans le panel (carte sur l'accueil + module « Nouveautés »).
-- Chaque lot ajoute une entrée à PB.Changelog (voir la liste plus bas). Le « lu / non lu » est mémorisé par administrateur (licence).
-- Pour ajouter une nouveauté : PB.News.Add({ id = 'lot37', date = 'AAAA-MM-JJ', title = '…', items = { { tag = 'Nouveau', text = '…', module = 'id-du-module' } } }).

local B, P, DB = PB.B, PB.Perm, PB.DB
local N = {}
PB.News = N

PB.Migrate('192_news_seen', 'Nouveautés : dernier lot lu par administrateur', {
    [[CREATE TABLE IF NOT EXISTS pb_news_seen (license VARCHAR(64) NOT NULL PRIMARY KEY, seq INT NOT NULL DEFAULT 0)]],
})

N.list = {}   -- du plus ancien au plus récent ; seq = position
function N.Add(e)
    if type(e) ~= 'table' or not e.id then return end
    for _, x in ipairs(N.list) do if x.id == e.id then return end end
    local items = {}
    for _, it in ipairs(e.items or {}) do
        items[#items + 1] = { tag = tostring(it.tag or 'Nouveau'):sub(1, 16), text = tostring(it.text or ''):sub(1, 600), module = it.module and tostring(it.module) or nil }
    end
    N.list[#N.list + 1] = { id = tostring(e.id), seq = #N.list + 1, date = tostring(e.date or ''), title = tostring(e.title or e.id):sub(1, 160), items = items }
end

local function seenOf(license)
    local r = license and DB.one('SELECT seq FROM pb_news_seen WHERE license = ?', { license })
    return r and tonumber(r.seq) or 0
end
-- Entrées pour un administrateur : { unseen, entries (les plus récentes d'abord) }
function N.For(license, limit)
    local seen, out, unseen = seenOf(license), {}, 0
    for i = #N.list, 1, -1 do
        local e = N.list[i]
        local isNew = e.seq > seen
        if isNew then unseen = unseen + 1 end
        if #out < (limit or 50) then out[#out + 1] = { id = e.id, date = e.date, title = e.title, items = e.items, new = isNew } end
    end
    return unseen, out
end
function N.MarkRead(license)
    if not license or #N.list == 0 then return end
    DB.exec('REPLACE INTO pb_news_seen (license, seq) VALUES (?, ?)', { license, N.list[#N.list].seq })
end

-- Journal des lots ----------------------------------------------------------------------------------------------------------------------
N.Add({ id = 'lot34', date = '2026-10-17', title = 'Patch notes 34 : téléphone, inventaire, boutiques', items = {
    { tag = 'Amélioré', text = "Boutiques, inventaire, notifications et HUD repensés.", module = 'shops' },
} })
N.Add({ id = 'lot35', date = '2026-10-17', title = 'Patch notes 35 : entreprises, gangs, carte', items = {
    { tag = 'Nouveau', text = "130 entreprises et gangs prêts à installer, rangés en 10 catégories.", module = 'biz' },
    { tag = 'Nouveau', text = "Module « Carte du jeu » : clique sur la carte, tu es téléporté, E pour poser un point.", module = 'carte' },
    { tag = 'Nouveau', text = "Menu staff : emploi, second emploi, gang, grade, armes dans l'inventaire, redémarrage planifié.", module = 'staff' },
    { tag = 'Corrigé', text = "Boutiques bloquées, noclip en véhicule, boutons grisés, éditeur d'automatisations." },
} })
N.Add({ id = 'lot36', date = '2026-10-17', title = 'Patch notes 36 : coffres, concession, tablettes', items = {
    { tag = 'Nouveau', text = "Coffre de véhicule (touche K) et touches capot, moteur, ceinture, vitres.", module = 'vehtrunk' },
    { tag = 'Nouveau', text = "Concession : 45 véhicules par défaut et nouvelle fiche (vitesse, places, coffre).", module = 'shops' },
    { tag = 'Nouveau', text = "Tablettes entreprise et gang complétées : équipe, annonces, journal, stats, paie, caisse commune, territoires…", module = 'orga' },
    { tag = 'Changé', text = "Noms au-dessus des têtes réservés au staff, couleur par grade.", module = 'tags' },
    { tag = 'Changé', text = "Créateur de personnage redessiné ; tablette transparente.", module = 'character' },
} })
N.Add({ id = 'fix37', date = '2026-10-17', title = 'Gros correctif de présentation', items = {
    { tag = 'Corrigé', text = "Commandes « restreintes » : la restriction ne s'appliquait jamais (faille corrigée).", module = 'commands' },
    { tag = 'Corrigé', text = "Second emploi : il est maintenant payé à chaque paie (pourcentage réglable).", module = 'biz' },
    { tag = 'Corrigé', text = "Points « bureau du patron / siège » : la tablette s'ouvre enfin." },
    { tag = 'Corrigé', text = "Garage : une page avec une note faisait planter l'écran." },
    { tag = 'Amélioré', text = "290 actions du panel et 119 événements du jeu testés avec des données absurdes : plus aucun plantage." },
} })

-- Actions -------------------------------------------------------------------------------------------------------------------------------
PB.Action('news.read', nil, function(ctx) N.MarkRead(ctx.license) return true, { unseen = 0 } end, { read = true })

-- Module --------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'whatsnew', label = 'Nouveautés', icon = 'sparkle', group = 'Pilotage', order = 5, perm = 'whatsnew.view', hint = 'Ce qui change à chaque mise à jour',
    doc = "## Nouveautés\nChaque mise à jour de Shadow Base ajoute une entrée ici, avec un lien direct vers le module concerné. Une pastille signale ce que tu n'as pas encore lu ; « Tout marquer comme lu » l'efface pour ton compte.",
    view = function(ctx)
        return { tabs = { { id = 'all', label = 'Mises à jour', icon = 'sparkle', build = function()
            local unseen, entries = N.For(ctx.license, 50)
            local blocks = {}
            if unseen > 0 then blocks[#blocks + 1] = B.actions({ { action = 'news.read', label = 'Tout marquer comme lu (' .. unseen .. ')', icon = 'check', primary = true } }) end
            for _, e in ipairs(entries) do
                local rows = {}
                for _, it in ipairs(e.items) do
                    local row = { tag = it.tag, text = it.text }
                    if it.module then row.actions = { { nav = it.module, label = 'Ouvrir', icon = 'arrow' } } end
                    rows[#rows + 1] = row
                end
                blocks[#blocks + 1] = B.table({ id = 'news_' .. e.id, title = (e.new and 'NOUVEAU · ' or '') .. e.title .. (e.date ~= '' and ('  (' .. e.date .. ')') or ''), columns = { { k = 'tag', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' } }, rows = rows })
            end
            if #blocks == 0 then blocks[1] = B.notice('info', 'Aucune nouveauté pour le moment.') end
            return blocks
        end } } }
    end,
})

N.Add({ id = 'lot39', date = '2026-10-17', title = 'Patch notes 39 : images, tablettes, placement, nettoyage', items = {
    { tag = 'Corrigé', text = "Images d'objets de l'inventaire et tablette des organisations (mise en page)." },
    { tag = 'Changé', text = "Tablette entreprise : uniquement les outils du métier (police : appels, détenus, amendes, dossiers).", module = 'biz' },
    { tag = 'Nouveau', text = "Placement à l'écran : déplace le vrai HUD, le chat, les menus et l'invite.", module = 'placement' },
    { tag = 'Changé', text = "Onglets en double supprimés (Services, Argent, Documentation, Garages).", module = 'general' },
} })

PB.SelfTest.Add('nouveautés', function(R)
    R.check(#N.list >= 3, 'journal', 'aucune entrée')
    local seen = {}
    for _, e in ipairs(N.list) do
        R.check(not seen[e.id], 'journal', 'identifiant en double : ' .. e.id)
        seen[e.id] = true
        R.check(#e.items > 0, 'journal', 'entrée vide : ' .. e.id)
    end
end)

N.Add({ id = 'patch40', date = '2026-10-18', title = 'Patch notes 40 : inventaire, territoires, points, identité', items = {
    { tag = 'Corrigé', text = "Inventaire : glisser-déposer, vrais filtres, armes jamais consommées (touches 1 à 5)." },
    { tag = 'Nouveau', text = "Tablette illégale : carte des territoires ; Mirror Park donne un gilet toutes les 10 h dans le coffre de l'organisation." },
    { tag = 'Nouveau', text = "Carte : « Configurer tout » pose tous les points d'une entreprise ou d'un gang d'une traite.", module = 'carte' },
    { tag = 'Changé', text = "Supérette : interface d'origine avec panier. Notifications : déplacement corrigé." },
    { tag = 'Nouveau', text = "Logo W et bannières Shadow Base (offres, Halloween, patch notes)." },
    { tag = 'Nouveau', text = "Menus : bannière animée Shadow Base (réglable dans Menus > Apparence).", module = 'menus' },
} })

N.Add({ id = 'patch41', date = '2026-10-18', title = 'Patch notes 41 : aides, infos, ALT, bannière, chuchoter', items = {
    { tag = 'Nouveau', text = "Barre d'aide en bas de l'écran : noclip (molette = vitesse, Ctrl, Maj) et cabine de vêtements." },
    { tag = 'Changé', text = "Les infos d'un joueur, l'argent, les papiers et la plaque s'affichent dans une fiche à côté du menu, plus en notification." },
    { tag = 'Nouveau', text = "Menu ALT en cascade, épuré (nouvelle version par défaut).", module = 'interface' },
    { tag = 'Nouveau', text = "Bannière des menus : le W se dessine, le texte suit le menu ouvert (Menu admin, Menu police…).", module = 'menus' },
    { tag = 'Nouveau', text = "Menu staff : Chuchoter, message que seul le joueur reçoit (voix privée en option).", module = 'staff' },
    { tag = 'Changé', text = "Le W de Shadow Base est le logo par défaut du panel.", module = 'general' },
} })
N.Add({ id = 'patch42', date = '2026-10-18', title = 'Patch notes 42 : organisations, starter pack, véhicules de gang', items = {
    { tag = 'Nouveau', text = "Carte du jeu › Entreprise / organisation : tu remplis les infos, puis tu es guidé en jeu pour poser le point coffre, le point boss, le rangement des véhicules et la sortie du garage.", module = 'carte' },
    { tag = 'Nouveau', text = "Module Organisations : création d'un gang avec ses grades, liste (membres, véhicules, caisse), réglages.", module = 'orgs' },
    { tag = 'Nouveau', text = "Starter pack à la création : objets dans le coffre, argent dans la caisse et trois véhicules de départ (tout est réglable).", module = 'orgs' },
    { tag = 'Nouveau', text = "Garage de gang : tu y retrouves tes véhicules et ceux de l'organisation ; les membres ont la clé des véhicules du gang.", module = 'garage' },
    { tag = 'Nouveau', text = "Donner un de tes véhicules à l'organisation, le reprendre, et le chef peut attribuer un véhicule du gang à un membre.", module = 'garage' },
    { tag = 'Nouveau', text = "Panel : ajouter un véhicule neuf à une organisation ou en attribuer un existant (par plaque).", module = 'orgs' },
    { tag = 'Changé', text = "Un garage de gang n'apparaît (carte, marqueur, touche E) que pour les membres de ce gang.", module = 'garage' },
    { tag = 'Correctif', text = "Garage et fourrière : l'aperçu transparent d'un véhicule ne peut plus rester à la sortie après avoir sorti la voiture.", module = 'garage' },
} })


N.Add({ id = 'patch43', date = '2026-10-20', title = 'Patch notes 43 : extensions, staff, PNJ, correctif images', items = {
    { tag = 'Nouveau', text = 'Extensions : une autre ressource se branche sur Shadow Base (pages, réglages, actions, permissions). Module Extensions.', module = 'extensions' },
    { tag = 'Nouveau', text = 'Menu staff : « Libérer de prison » et liste des détenus dans Gestion des sanctions.' },
    { tag = 'Nouveau', text = 'Monde : supprimer les PNJ et les PNJ police (activés par défaut).', module = 'world' },
    { tag = 'Correctif', text = "Envoyer une image depuis le PC (bannière, logo) ne déconnecte plus." },
} })
N.Add({ id = 'patch44', date = '2026-10-20', title = 'Patch notes 44 : activités, blips, inventaire, territoires, HUD', items = {
    { tag = 'Nouveau', text = 'Activités ouvertes à tous (pêche, mine, bois, agriculture, cueillette, décharge, craft), posées au Builder.', module = 'wb_activites' },
    { tag = 'Nouveau', text = 'Blips : coffres en dégradé aux couleurs du serveur, QG de gang, vraie icône Burger Shot.' },
    { tag = 'Nouveau', text = "Message en entrant dans un territoire ; HUD faim / soif / micro et barres vie / armure." },
    { tag = 'Correctif', text = "Fond de l'inventaire : le jeu se voit derrière (plus noir opaque)." },
} })
N.Add({ id = 'patch45', date = '2026-10-20', title = 'Patch notes 45 : portes, menu boss, builder, GPS, animations', items = {
    { tag = 'Nouveau', text = 'Portes verrouillables par groupes (F10 › Builder › Portes ou /portes).', module = 'wb_portes' },
    { tag = 'Nouveau', text = 'Gestion des entreprises et organisations seulement au point boss.' },
    { tag = 'Nouveau', text = 'Builder : supprimer un point ou tous les points ; GPS dans le F5 ; animations manger et boire.' },
    { tag = 'Correctif', text = 'Burger Shot : menus qui clignotaient, client PNJ mal placé ; menu F2 retiré (tout est dans ALT).' },
} })
N.Add({ id = 'patch46', date = '2026-10-20', title = 'Patch notes 46 : points de métier pour toutes les entreprises', items = {
    { tag = 'Nouveau', text = 'Builder : accueil, atelier (garages), cuisine / bar et comptoir de vente selon le métier.', module = 'carte' },
} })
N.Add({ id = 'patch47', date = '2026-10-20', title = 'Patch notes 47 : agence immobilière, mises à jour', items = {
    { tag = 'Nouveau', text = 'Agence immobilière : annonces, intérieurs, visites et commission (menu ALT des agents).' },
    { tag = 'Nouveau', text = 'Module Mises à jour : nouvelles versions signées, patch notes et téléchargement gratuit.', module = 'updates' },
} })

N.Add({ id = 'patch48', date = '2026-10-21', title = 'Patch notes 48 : écran de chargement', items = {
    { tag = 'Nouveau', text = 'Écran de chargement : logo, barre de progression et bandeau de messages qui défile (ressource wb_loading).' },
} })
N.Add({ id = 'patch49', date = '2026-10-21', title = 'Patch notes 49 : la base devient Shadow Base', items = {
    { tag = 'Nouveau', text = 'Nouveau nom et nouveau logo : Shadow Base.', module = 'general' },
} })
N.Add({ id = 'patch50', date = '2026-10-21', title = 'Patch notes 50 : corrections, journal des expulsions, vestiaires, braquages', items = {
    { tag = 'Nouveau', text = "Journal des expulsions et bans : raison précise, origine et référence pour chaque kick.", module = 'kicks' },
    { tag = 'Correctif', text = "Anticheat : plus d'éjections pendant un restart ou un lag.", module = 'general' },
    { tag = 'Correctif', text = "Staff affiché hors ligne, touches des menus, onglets vides, suppression des anciens points.", module = 'general' },
    { tag = 'Nouveau', text = "Vrais vestiaires d'entreprise et de gang, vendeurs derrière le comptoir et braquages animés.", module = 'general' },
} })
N.Add({ id = 'patch51', date = '2026-10-21', title = 'Patch notes 51 : petits jobs, vraie pêche, vendeurs derrière le comptoir', items = {
    { tag = 'Nouveau', text = "Petits jobs pour chaque entreprise (touche O) : livraisons, taxi, dépannage, patrouille, secours, chantiers…", module = 'general' },
    { tag = 'Nouveau', text = "Pêche : raretés de poissons et de leurres, cannes, ferrage, marché aux prix variables, records.", module = 'general' },
    { tag = 'Correctif', text = "Vendeurs placés derrière le comptoir dans toutes les supérettes, magasins comme braquages.", module = 'shops' },
    { tag = 'Correctif', text = "Menotté : plus d'animations ; saisies au casier ; annonces visibles dans le chat ; couleur des gangs.", module = 'general' },
} })
N.Add({ id = 'patch52', date = '2026-10-21', title = 'Patch notes 52 : coiffeur / barbier, bandeau de démarrage', items = {
    { tag = 'Nouveau', text = "Coiffeur / barbier : coupe, couleurs, barbe, sourcils, maquillage, aperçu en direct. Builder › Commerces.", module = 'shops' },
    { tag = 'Nouveau', text = "Au démarrage, la console affiche la version, le numéro du dernier patch notes et l'état de la licence.", module = 'general' },
} })
N.Add({ id = 'patch53', date = '2026-10-21', title = 'Patch notes 53 : moins de métiers, Builder plus rapide, Auto Exotic, packs', items = {
    { tag = 'Amélioré', text = "Catalogue court : 14 entreprises utiles (dont Auto Exotic) ; les inutilisées sont retirées.", module = 'biz' },
    { tag = 'Amélioré', text = "Builder : Entrée pose le point tout de suite ; icône du siège au choix ; patron choisi parmi les joueurs connectés.", module = 'carte' },
    { tag = 'Nouveau', text = "3 packs de départ pour les organisations, donnés à la création.", module = 'orgs' },
    { tag = 'Correctif', text = "Points accueil / atelier / cuisine et points du Burger Shot : posés, affichés et supprimables.", module = 'carte' },
    { tag = 'Amélioré', text = "Inventaire : cases moins vertes, fond plus transparent.", module = 'inv' },
} })
N.Add({ id = 'patch54', date = '2026-10-21', title = 'Patch notes 54 : grosse optimisation, noms et ID réservés au staff', items = {
    { tag = 'Amélioré', text = "Noms, grades et ID visibles par le staff seulement (étiquettes, menu ALT, inventaire).", module = 'tags' },
    { tag = 'Amélioré', text = "Optimisation client et serveur : boucles allégées, moins d'envois réseau.", module = 'monitor' },
    { tag = 'Correctif', text = "Blips des entreprises : couleur, taille et portée rétablies.", module = 'carte' },
} })
N.Add({ id = 'patch55', date = '2026-10-22', title = 'Patch notes 55 : VIP, tatoueur, chasse, braquages, logements, animaux', items = {
    { tag = 'Nouveau', text = "VIP (menu staff, /vip, panel) : multi-personnages, animaux de compagnie, meubles, canne et leurres VIP, bonus de revente.", module = 'vip' },
    { tag = 'Nouveau', text = "Salon de tatouage, chasse, braquages (cambriolages, receleur, distributeurs, GoFast, fourgons blindés).", module = 'shops' },
    { tag = 'Nouveau', text = "Logements : impôt foncier, colocation, sonnette, intérieurs instanciés, meubles et aquarium.", module = 'housing' },
    { tag = 'Amélioré', text = "Builder (fantôme, Ctrl+Z), inventaire (tri, recherche, coffre), vestiaires, spectateur, événements programmés.", module = 'events' },
    { tag = 'Amélioré', text = "Optimisation : panel chargé à la demande, images allégées, purge des journaux, index.", module = 'monitor' },
} })
N.Add({ id = 'patch56', date = '2026-10-22', title = "Patch notes 56 : atelier d'armes, portes en ALT, menu ALT admin, VIP dans F5", items = {
    { tag = 'Nouveau', text = "Atelier d'armes clandestin (wb_armes) : ateliers cachés, pièces, plans, niveau d'armurier, finition, mini-jeu, marché noir.", module = 'extensions' },
    { tag = 'Nouveau', text = "Portes en ALT pour le staff : porte surlignée, choix des entreprises et gangs qui gardent l'accès, avec recherche.", module = 'ctx' },
    { tag = 'Nouveau', text = "Menu ALT staff : DV, pneus crevés, faire descendre, occupants avec ID, donner un véhicule, mute chat et micro, TP.", module = 'ctx' },
    { tag = 'Amélioré', text = "Carte « Mon VIP » dans le menu F5 : statut, date de fin, avantages.", module = 'personal' },
    { tag = 'Corrigé', text = "Invites E des extensions (pêche, chasse…) bloquées, envoi d'images depuis le PC bloqué, invite E hors de l'écran.", module = 'general' },
} })
N.Add({ id = 'patch57', date = '2026-10-22', title = 'Patch notes 57 : entreprises sur mesure et toutes les icônes de la carte', items = {
    { tag = 'Nouveau', text = "Entreprises sur mesure : nom libre, fonctionnement de n'importe quel type (mécano, café, bar, taxi…), créées au Builder ou dans le panel.", module = 'biz' },
    { tag = 'Nouveau', text = "Sélecteur des 965 icônes de GTA avec aperçu, recherche et couleur, pour le siège des entreprises.", module = 'biz' },
    { tag = 'Amélioré', text = "Type de fonctionnement et icône modifiables après coup ; les petits jobs suivent le type choisi.", module = 'biz' },
} })
N.Add({ id = 'patch58', date = '2026-10-22', title = 'Patch notes 58 : appels vocaux au téléphone', items = {
    { tag = 'Nouveau', text = "Appels vocaux (pma-voice) : application Appels avec clavier, appels récents et manqués ; bouton Appeler sur les contacts et les conversations.", module = 'phone' },
    { tag = 'Nouveau', text = "Appeler un service de l'annuaire : tous les employés en service sonnent, le premier qui décroche prend l'appel.", module = 'phone' },
    { tag = 'Nouveau', text = "Bandeau d'appel en haut de l'écran, sonnerie, téléphone à l'oreille ; /decrocher et /raccrocher.", module = 'phone' },
    { tag = 'Sécurité', text = "Canaux d'appel tirés au hasard et surveillés : un joueur qui tente d'écouter l'appel d'un autre est retiré et journalisé.", module = 'phone' },
} })
N.Add({ id = 'patch59', date = '2026-10-22', title = 'Patch notes 59 : radio F4, tickets Discord, anti-duplication, chronologie', items = {
    { tag = 'Nouveau', text = "Poste radio sur F4 : fréquence au pavé ou aux flèches, volume retenu, raccourcis vers les canaux de ton métier ; parler avec Verr. Maj.", module = 'radio' },
    { tag = 'Nouveau', text = "Tickets : /ticket (catégorie, conversation, suivi), /report devient un ticket ; le staff répond dans le panel ou directement sur Discord.", module = 'tickets' },
    { tag = 'Nouveau', text = "Anti-duplication : alerte quand un joueur gagne trop d'argent ou reçoit trop d'objets en 1 h (staff en service + Discord).", module = 'vigil' },
    { tag = 'Nouveau', text = "Chronologie d'un joueur : connexions, argent, objets, sanctions, tickets, expulsions et journal sur une seule ligne du temps.", module = 'vigil' },
    { tag = 'Nouveau', text = "Téléphone : partager sa position par message (bouton « Y aller ») et haut-parleur pendant un appel.", module = 'phone' },
    { tag = 'Corrigé', text = "Champs du panel refusés à tort (« format invalide ») : une touche comme F4 pour le noclip, les identifiants, les listes « nom|valeur ».", module = 'general' },
    { tag = 'Changé', text = "F4 n'est plus le raccourci staff « téléportation au point GPS » (à reprendre dans Staff › Raccourcis si besoin).", module = 'staff' },
} })
N.Add({ id = 'patch60', date = '2026-10-22', title = 'Patch notes 60 : bar et discothèque, télévisions, 911, conférences, coma', items = {
    { tag = 'Nouveau', text = "Bar, discothèque, café : le barman prépare au bar (ingrédients payés par la caisse) puis sert un client avec ALT ; le client accepte et paie.", module = 'biz' },
    { tag = 'Nouveau', text = "Télévisions : ALT sur un écran, puis un lien YouTube ou Vimeo ; tout le monde autour voit et entend la même vidéo.", module = 'tv' },
    { tag = 'Nouveau', text = "Téléphone : SOS 911 (police et secours sonnent et reçoivent ta position), conférence à plusieurs, numéros bloqués, groupes de discussion.", module = 'phone' },
    { tag = 'Nouveau', text = "Faim ou soif à 0 : coma (réanimation par les secours possible), avec un avertissement sous 10 %.", module = 'hud' },
    { tag = 'Nouveau', text = "Builder : dupliquer un point, déplacer tous les points d'un coup, « y aller » avec vérification du sol ; panel › Points posés (carte et problèmes).", module = 'pointsmap' },
    { tag = 'Amélioré', text = "Garage et téléphone : carburant, moteur et carrosserie de chaque véhicule, et bouton Localiser.", module = 'garage' },
    { tag = 'Amélioré', text = "Menu F10 : recherche unique (joueur, ID, plaque, numéro). Économie : gains par heure et par activité.", module = 'staff' },
} })
N.Add({ id = 'patch61', date = '2026-10-22', title = 'Patch notes 61 : points et étiquettes, garage avec aperçu, noclip fantôme', items = {
    { tag = 'Changé', text = "Plus de flèches : un petit point lumineux marque chaque endroit où interagir, et l'étiquette « [E] GARAGE » s'affiche dessus, dans le monde.", module = 'hud' },
    { tag = 'Nouveau', text = "Garage en menu : en descendant sur un véhicule, il apparaît en transparence à la sortie, avec une caméra.", module = 'garage' },
    { tag = 'Corrigé', text = "Fourrière : la récupération marche même sans point de sortie ou si le véhicule est resté en ville ; tu es mis au volant.", module = 'garage' },
    { tag = 'Amélioré', text = "Noclip : invisible pour tous les joueurs, tu te vois en transparence (ton véhicule aussi).", module = 'staff' },
} })
N.Add({ id = 'patch62', date = '2026-10-22', title = 'Patch notes 62 : atelier mécano facturé, customisation en direct, menu Shadow retravaillé', items = {
    { tag = 'Nouveau', text = "Customisation dans le véhicule : peintures (classique, mat, métal, chrome, nacré, teinte libre), jantes, carrosserie, Benny's, performances, xénons, néons, fumée, vitres, plaque, klaxon, livrée — chaque option s'affiche sur la voiture.", module = 'mech' },
    { tag = 'Nouveau', text = "Devis puis facture au client : il paie (la caisse de l'entreprise encaisse) ou refuse (la custom est retirée). Réparer et nettoyer depuis F5 › Mon entreprise, facturés pareil.", module = 'mech' },
    { tag = 'Nouveau', text = "Mécano en service : ouvre et conduit les véhicules des clients. Tenue de service (ex. Benny's) enfilée à la prise de service, vêtements rendus à la fin.", module = 'mech' },
    { tag = 'Changé', text = "Menu Shadow retravaillé (fond, bannière, lignes et icônes de la maquette).", module = 'menus' },
    { tag = 'Corrigé', text = "Inventaire : titres en français qui ne débordent plus, plus de cadenas « Premium » dans les coffres. Portes : beaucoup plus de portes détectées en ALT (portails, grilles, portes de garage, doubles portes).", module = 'inv' },
} })
N.Add({ id = 'patch63', date = '2026-10-23', title = 'Patch notes 63 : casino et repères de la carte', items = {
    { tag = 'Nouveau', text = "Casino au Builder (Casino › Caisse / Jeu) : machine à sous, roulette, blackjack, roue de la fortune, dés, plus haut / plus bas, tickets à gratter, avec de vraies animations. Tous les tirages sont faits par le serveur.", module = 'casino' },
    { tag = 'Nouveau', text = "Jetons de casino dans l'inventaire (achetés et revendus à la caisse), loterie hebdomadaire avec cagnotte, casino de l'État ou d'une entreprise, statistiques et redistribution affichées.", module = 'casino' },
    { tag = 'Nouveau', text = "Repères : les doublons sont masqués automatiquement, les repères fantômes supprimés ; « /blips reset » ou Points posés › Repères des joueurs pour tout redessiner.", module = 'pointsmap' },
    { tag = 'Corrigé', text = "Repères qui restaient sur la carte : joueur observé par le staff, animal de compagnie, alertes 911 et secours empilées.", module = 'pointsmap' },
} })
N.Add({ id = 'patch64', date = '2026-10-23', title = 'Patch notes 64 : la ville réagit (impayés, mandats, fourrière, secours)', items = {
    { tag = 'Nouveau', text = "Factures et amendes impayées : majoration, puis saisie sur le compte (même hors ligne), puis mandat visible dans la tablette de la police.", module = 'coherence' },
    { tag = 'Nouveau', text = "Véhicule abandonné ou disparu : envoyé en fourrière, SMS au propriétaire. Messages automatiques au téléphone (Trésor public, Fourrière, Hôpital…).", module = 'coherence' },
    { tag = 'Nouveau', text = "Joueur à terre : les secouristes en service sont alertés tout seuls ; les frais d'hôpital vont à la caisse des secours, facture si le joueur n'a pas l'argent.", module = 'coherence' },
    { tag = 'Amélioré', text = "Chronologie du joueur : factures, amendes, majorations, saisies, mandats, fourrières, comas, prison, réanimations.", module = 'vigil' },
    { tag = 'Corrigé', text = "Employés restés « en service » après une déconnexion ; page Paie qui affichait toujours « payée par l'État ». Patron prévenu quand la caisse ne couvre plus la paie.", module = 'coherence' },
} })
N.Add({ id = 'patch65', date = '2026-10-23', title = 'Patch notes 65 : taxi, dépanneuse, annonces, véhicules de service, logements', items = {
    { tag = 'Nouveau', text = "Taxi : app Taxi du téléphone (commander, accepter), taximètre mesuré par le serveur, paiement automatique ou facture.", module = 'taxi' },
    { tag = 'Nouveau', text = "Dépanneuse : un mécano en service avec un plateau charge un véhicule (ALT), le décharge ou le dépose à la fourrière contre une prime pour sa caisse.", module = 'garage' },
    { tag = 'Nouveau', text = "Véhicules de service d'entreprise (clé seulement en service) et clés prêtées pour 1 à 24 h.", module = 'garage' },
    { tag = 'Nouveau', text = "Téléphone : app Annonces (vente, achat, emploi, logement…) avec Écrire / Appeler l'auteur.", module = 'phone' },
    { tag = 'Nouveau', text = "Logements : loyer prélevé même hors ligne, expulsion après les impayés tolérés, affaires mises à la consigne, dette transmise à l'agence.", module = 'housing' },
    { tag = 'Amélioré', text = "Économie › Tableau de bord ; historique récent à côté du spectateur staff ; plus d'annonces de redémarrage en double.", module = 'economy' },
} })
N.Add({ id = 'patch66', date = '2026-10-23', title = 'Patch notes 66 : Builder rangé, garages terrestres, aériens et navals', items = {
    { tag = 'Amélioré', text = "Builder (F10 › Builder) : tout est rangé en 7 sections (Entreprises, Illégal, Commerces et services, Garages et véhicules, Immobilier et coffres, Activités, Autres) avec une recherche, au lieu d'une longue liste.", module = 'carte' },
    { tag = 'Nouveau', text = "Garages créés en jeu : on pose l'entrée, la sortie du véhicule et le PNJ, étape par étape ; garage, hangar d'avions, port, et une fourrière pour chacun.", module = 'garage' },
    { tag = 'Nouveau', text = "Garages séparés par type : un avion ne se range que dans un hangar, un bateau que dans un port ; icône de carte selon le type, PNJ au comptoir.", module = 'garage' },
    { tag = 'Corrigé', text = "Le groupe Casino n'apparaissait pas dans le Builder ; nom du jeu repris du préréglage choisi.", module = 'casino' },
} })
N.Add({ id = 'patch67', date = '2026-10-23', title = 'Patch notes 67 : ville vivante (ouvert / fermé, contrats, plaques, Discord, journaux)', items = {
    { tag = 'Nouveau', text = "Entreprises ouvertes ou fermées : repère vert ou rouge sur la carte selon les employés en service, et annuaire du téléphone en direct (ouverts d'abord).", module = 'biz' },
    { tag = 'Nouveau', text = "Contrats de vente entre joueurs (app Contrats) : véhicule ou logement, signature à côté, paiement sécurisé et taxe de mutation.", module = 'economy' },
    { tag = 'Nouveau', text = "Plaques personnalisées (payantes, au garage) et fausses plaques pour les illégaux : la police ne retrouve plus le véhicule, retrait en ALT.", module = 'garage' },
    { tag = 'Nouveau', text = "Journal des morts (qui, par qui, arme, distance, position) et sauvegardes d'inventaire avec restauration à une date donnée.", module = 'kills' },
    { tag = 'Nouveau', text = "Discord ↔ personnage : rôles VIP, métier et groupe donnés et retirés tout seuls, pseudo du personnage, Discord obligatoire en option.", module = 'discordlink' },
} })
N.Add({ id = 'patch68', date = '2026-10-23', title = 'Patch notes 68 : largages, chasses au trésor, guerres de territoire', items = {
    { tag = 'Nouveau', text = "Largage : une zone est annoncée, une caisse tombe, le premier qui l'ouvre gagne argent et objets. Chasse au trésor : la zone se resserre toutes les 3 minutes, il faut creuser au bon endroit.", module = 'worldev' },
    { tag = 'Nouveau', text = "Lancement automatique (toutes les X minutes s'il y a assez de joueurs), planifié dans Événements, ou à la main depuis le panel.", module = 'worldev' },
    { tag = 'Nouveau', text = "Guerres de territoire planifiées (jour et heure) : points de présence dans la zone et d'éliminations de rivaux, tableau des scores à l'écran, la zone et la récompense au vainqueur, historique.", module = 'wars' },
} })
N.Add({ id = 'patch69', date = '2026-10-23', title = 'Patch notes 69 : grande chasse aux bugs', items = {
    { tag = 'Corrigé', text = "Duplication d'objets quand deux joueurs vident le même coffre en même temps ; aquarium et consigne qui pouvaient donner deux fois.", module = 'inv' },
    { tag = 'Corrigé', text = "Caisses (organisation, entreprise, casino, bar, atelier, missions) qui pouvaient payer deux fois ou passer dans le rouge sur un double clic.", module = 'economy' },
    { tag = 'Corrigé', text = "Garage : on ne range plus une voiture laissée ailleurs (doublon). Fourrière et atelier : la plaque est lue par le serveur, plus de saisie ou de tuning à distance.", module = 'garage' },
    { tag = 'Corrigé', text = "Location remboursée même véhicule détruit ; magasin qui encaissait sans donner l'objet ; remboursement accepté alors que le client n'avait plus les articles ; achat de logement payé sans être attribué en cas d'erreur.", module = 'shops' },
    { tag = 'Corrigé', text = "Se déconnecter menotté ne libère plus (toujours menotté à la reconnexion, police prévenue) ; virements à soi-même refusés.", module = 'biz' },
    { tag = 'Corrigé', text = "Braquages : un distributeur payé deux fois, GoFast livré avec n'importe quel véhicule. Fabrication (armes, activités) qui donnait l'objet même si les pièces manquaient.", module = 'extensions' },
    { tag = 'Corrigé', text = "Discord : synchronisations étalées (plus de limite de débit), pseudo envoyé seulement s'il change.", module = 'discordlink' },
} })
N.Add({ id = 'patch70', date = '2026-10-23', title = 'Patch notes 70 : poker entre joueurs, historique du casino', items = {
    { tag = 'Nouveau', text = "Poker Texas Hold'em entre joueurs (Builder › Casino › Jeu › Poker) : 2 à 6 places, cave en jetons, blindes, relances, tapis et pots secondaires, temps de parole, commission du casino dès le flop.", module = 'casino' },
    { tag = 'Nouveau', text = "Casino › Mes parties : bilans du jour, de la semaine et depuis toujours, jeu préféré, plus gros gain, dernières parties. Panel › Casino › Joueurs : classement des gagnants et perdants.", module = 'casino' },
} })
N.Add({ id = 'patch71', date = '2026-10-23', title = "Patch notes 71 : hélipad, où est ma voiture, meubles à vendre, tenue de service", items = {
    { tag = 'Nouveau', text = "Hélipad d'entreprise (Builder › entreprise › Hélipad) et catalogue de véhicules de service achetés avec la caisse : hélicoptères à l'hélipad, voitures au garage, bateaux au port ; revente à 50 %.", module = 'garage' },
    { tag = 'Nouveau', text = "Téléphone › Garage : où est chaque véhicule (en direct, dernière position connue, garage, fourrière la plus proche), itinéraire et repère sur la carte ; véhicules de service et clés prêtées listés aussi.", module = 'garage' },
    { tag = 'Nouveau', text = "Meubles en objets : Magasin de meubles au Builder, on pose ses meubles chez soi et ils reviennent dans le sac quand on les retire. App Contrats : vente d'objets entre joueurs (meubles et autres), paiement sécurisé.", module = 'housing' },
    { tag = 'Amélioré', text = "Tenue de service : la dernière tenue enfilée au vestiaire devient sa tenue de service ; chacun peut désactiver la tenue automatique.", module = 'biz' },
    { tag = 'Corrigé', text = "Licence : la limite de joueurs et le blocage sans licence ne s'appliquaient pas (erreur dans la connexion).", module = 'general' },
} })
N.Add({ id = 'patch72', date = '2026-10-23', title = 'Patch notes 72 : nouveau menu ALT, drapeaux de vente, tournois de poker, badge', items = {
    { tag = 'Amélioré', text = "Menu ALT refait : petite boîte bleu nuit, texte seul, barre bleue sur la ligne survolée, les catégories s'ouvrent dedans et « Retour » remonte. Les anciens styles restent au choix dans le panel.", module = 'ctx' },
    { tag = 'Amélioré', text = "Drapeaux de vente redessinés (vrai drapeau rectangulaire qui flotte dans le vent, emblème, blanc quand la zone est neutre). Plus de texte au-dessus du drapeau : l'état de la zone s'affiche sur le côté de l'écran.", module = 'flags' },
    { tag = 'Nouveau', text = "Poker : tournois (droit d'entrée, jetons de tournoi, blindes qui doublent, cagnotte partagée entre les premiers, classement dans le panel) et tables privées avec mot de passe.", module = 'casino' },
    { tag = 'Nouveau', text = "Croupiers du casino aux tables (blackjack, roulette, dés, plus haut / plus bas, poker) avec un geste à chaque donne.", module = 'casino' },
    { tag = 'Nouveau', text = "Badge d'employé : ALT › Métier › Montrer mon badge (entreprise, grade, matricule, en service ou non).", module = 'biz' },
} })
N.Add({ id = 'patch73', date = '2026-10-23', title = 'Patch notes 73 : menu ALT comme la référence, corrections', items = {
    { tag = 'Amélioré', text = "Menu ALT : large boîte bleu ardoise translucide, texte blanc bien espacé, pastille bleu cyan sur la ligne choisie, sans surlignage.", module = 'ctx' },
    { tag = 'Corrigé', text = "À la déconnexion, le joueur disparaissait avant que les autres scripts ne le lisent : le service n'était pas toujours remis à zéro et la déconnexion n'apparaissait pas dans la chronologie.", module = 'coherence' },
    { tag = 'Corrigé', text = "Points d'entreprise et sacs au sol : demandes limitées (un client modifié pouvait surcharger la base de données).", module = 'inv' },
} })
N.Add({ id = 'patch74', date = '2026-10-23', title = "Patch notes 74 : fusion 1.2.2, inventaire d'origine conservé, corrections", items = {
    { tag = 'Amélioré', text = "Tout le travail des patchs 63 à 73 est intégré (casino, poker, taxi, contrats, guerres de territoire, largages, Builder rangé…), sauf le nouvel inventaire : l'inventaire d'origine est gardé (couleur du serveur, décor assombri, flou). Les protections anti-duplication de l'inventaire sont bien reprises.", module = 'inv' },
    { tag = 'Corrigé', text = "Un serveur passé par la 1.2.2 retrouve automatiquement l'apparence d'origine de l'inventaire (une seule fois, réglable ensuite dans le panel).", module = 'inv' },
    { tag = 'Corrigé', text = "Loterie du casino : le prochain tirage pouvait être décalé d'une heure au changement d'heure été / hiver.", module = 'casino' },
    { tag = 'Corrigé', text = "Téléphone : les apps (Contrats, Annonces…) plantaient au démarrage du serveur ; Économie › Contrats ne s'ouvrait pas dans le panel.", module = 'phone' },
} })
N.Add({ id = 'patch75', date = '2026-10-23', title = "Patch notes 75 : menus F6 / F7 en lib, garage sans fenêtre, taxi facturé, HUD et police d'écriture", items = {
    { tag = 'Nouveau', text = "F6 : menu de mon entreprise (lib) avec « Prendre / Quitter mon service », facture, menottes, réparation, nettoyage, customisation, taxi, service au bar… F5 ne fait plus que dire si on est dans une entreprise.", module = 'quick' },
    { tag = 'Nouveau', text = "F7 : menu de mon organisation (lib) : ligoter, détacher, escorter, mettre dans un véhicule, fouiller, GPS du QG, coffre, caisse, membres. La tablette de l'organisation s'ouvre seulement au QG.", module = 'orga' },
    { tag = 'Amélioré', text = "Choisir quelqu'un (facture, menottes, fouille, service…) : la personne survolée est entourée et marquée d'une flèche. Une facture reçue s'affiche tout de suite : Payer ou Plus tard.", module = 'quick' },
    { tag = 'Amélioré', text = "Taxi : tout se fait au F6 (courses, compteur), et à la fin le chauffeur envoie la facture au client choisi. Le téléphone ne sert plus qu'à commander.", module = 'taxi' },
    { tag = 'Corrigé', text = "Garage : plus aucune fenêtre (Clés, Organisation, Entreprise sont dans le menu), le joueur est figé dans le menu, et une sortie ratée remet le véhicule au garage au lieu de bloquer.", module = 'garage' },
    { tag = 'Nouveau', text = "Builder : véhicules de l'entreprise choisis dans tout le catalogue, par catégorie. Aperçu en transparence avant de poser un jeu du casino, et le menu revient d'une étape après la pose.", module = 'carte' },
    { tag = 'Amélioré', text = "Portes : on coche qui a accès puis Valider. Grandes portes et portails s'ouvrent de plus loin, et en voiture jusqu'à 15 m.", module = 'extensions' },
    { tag = 'Amélioré', text = "Prise de service en menu, tablette en main à l'ouverture, klaxons audibles avant de choisir chez le mécano, micro qui marche en appel même téléphone ouvert.", module = 'biz' },
    { tag = 'Amélioré', text = "Nouveau HUD « Shadow » collé à la mini-carte, heure et serveur en haut à droite, tableau staff en petites cases, menu ALT carré et compact, une seule police partout (Poppins), inventaire compris.", module = 'hud' },
    { tag = 'Nouveau', text = "Tableau staff : case « Joueurs en BDA », les joueurs connectés présents dans le salon vocal d'attente du support sur Discord (salon à régler dans le panel).", module = 'staff' },
    { tag = 'Nouveau', text = "Point de vente : en bas à droite, chaque organisation présente sur le point avec son nombre de membres.", module = 'flags' },
    { tag = 'Amélioré', text = "Gamertags refaits : [VIP*] [entreprise] [gang] au-dessus, [ID][Joueur] Nom (Nouveau) au milieu, le ping en dessous.", module = 'tags' },
} })
N.Add({ id = 'patch76', date = '2026-10-23', title = 'Patch notes 76 : HUD comme les photos, props permanents, clic partout, musique coupée', items = {
    { tag = 'Nouveau', text = "F10 › Props permanents : le staff pose des objets (barrières, tables, décor…) avec un aperçu, et ils restent après un redémarrage. Props proches : celui survolé est entouré, Entrée pour le retirer.", module = 'props' },
    { tag = 'Amélioré', text = "Plus de musique dans les magasins (vêtements, supérettes, Ammu-Nation, coiffeurs, tatoueurs, concession, customisation).", module = 'general' },
    { tag = 'Nouveau', text = "/bdatest (staff) : vérifie tout de suite la case « Joueurs en BDA » et dit ce qui manque.", module = 'staff' },
    { tag = 'Amélioré', text = "Un seul clic partout : menus, inventaire, menu ALT, téléphone, tablettes. Volume réglable dans le panel (Menus).", module = 'menus' },
    { tag = 'Corrigé', text = "F6 ouvrait encore la tablette et F7 ne répondait pas chez les joueurs déjà venus (anciennes touches gardées par FiveM) : F6 ouvre le menu de l'entreprise, F7 celui de l'organisation. Aussi /entreprise et /organisation.", module = 'quick' },
    { tag = 'Amélioré', text = "Invite d'interaction, notifications (avec le logo du serveur) et compteur refaits comme les photos de référence ; petite touche « E » rouge à la place du rond sous les points.", module = 'hud' },
    { tag = 'Nouveau', text = "En haut à droite : ton métier et ton organisation.", module = 'hud' },
    { tag = 'Corrigé', text = "Points de missions civiles d'exemple (dont « coursier ») qui restaient sur la carte : désactivés, et supprimables au Builder.", module = 'civil' },
} })
N.Add({ id = 'patch77', date = '2026-10-23', title = "Patch notes 77 : logement, fiche d'infos, braquage, gamertags, invite", items = {
    { tag = 'Corrigé', text = "Logement : l'invite « E : sortir » restait affichée partout dans l'appartement (et même après en être sorti autrement). Elle n'apparaît plus qu'à la porte, et disparaît dès qu'on n'est plus dedans.", module = 'housing' },
    { tag = 'Corrigé', text = "Fiche d'infos (menu staff, papiers, menu ALT…) : elle se ferme en même temps que le menu au lieu de rester à l'écran.", module = 'staff' },
    { tag = 'Amélioré', text = "Fiche d'infos plus carrée et transparente, dans le style du serveur.", module = 'staff' },
    { tag = 'Corrigé', text = "Invite d'interaction : texte et touche plus petits, une touche longue (RMB…) tient dans son carré.", module = 'hud' },
    { tag = 'Corrigé', text = "Braquage de supérette : le vendeur ne reste plus à te regarder, il va vider la caisse dans un sac.", module = 'crime' },
    { tag = 'Corrigé', text = "Gamertags qui bougeaient quand on tourne la caméra ou qu'on marche : ils restent bien fixes au-dessus des joueurs.", module = 'tags' },
    { tag = 'Amélioré', text = "Inventaire : les demi-cercles en pointillés et les petites croix du fond sont retirés.", module = 'inv' },
    { tag = 'Nouveau', text = "Une vraie image pour chaque objet du serveur (265 objets) : poissons, gibier, meubles, butin, drogues, pièces d'armes, plats, matériaux, masques, sacs… dans l'inventaire et les boutiques.", module = 'inv' },
} })
N.Add({ id = 'patch78', date = '2026-10-23', title = "Patch notes 78 : commandes de chat, 220 emotes, gestes à deux", items = {
    { tag = 'Nouveau', text = "Plus de 80 commandes de chat : /bring, /goto, /tp, /tpm, /heal, /revive, /car, /dv, /fix, /kick, /ban, /jail, /givecash… pour le staff (mêmes droits et même service que le menu F10), et /id, /donner, /de, /essayer, /siege, /position, /moteur, /coffre, /e… pour tout le monde. /aide les liste.", module = 'staff' },
    { tag = 'Nouveau', text = "Menu des emotes : 220 emotes (danses, humeurs, repos, sport, accessoires, boissons, nourriture, métiers, gestes) et un aperçu dans chaque carte.", module = 'animmenu' },
    { tag = 'Nouveau', text = "8 nouveaux gestes à deux : taper dans la main, accolade, tape dans le dos, poignée virile, bise, remettre un objet, gifle et coup de tête (RP). « Checker » fait un vrai check du poing.", module = 'ctx' },
    { tag = 'Corrigé', text = "Danse 1 et Danse 2 ne se lançaient pas (animations inexistantes) : remplacées.", module = 'animmenu' },
    { tag = 'Amélioré', text = "Audit complet : animations, événements, interface et manifestes vérifiés sur toute la base.", module = 'general' },
} })
N.Add({ id = 'patch79', date = '2026-10-23', title = "Patch notes 79 : cases à cocher, notifications, taille du HUD", items = {
    { tag = 'Corrigé', text = "Menus : une case à cocher qui se cochait puis se décochait toute seule (double-clic, clics rapprochés, réglages du service staff).", module = 'menus' },
    { tag = 'Amélioré', text = "Notifications : les notifications identiques ne s'empilent plus, la carte affiche « x2, x3… ».", module = 'hud' },
    { tag = 'Corrigé', text = "HUD en haut à droite : cadre noir autour de l'ID retiré.", module = 'hud' },
    { tag = 'Nouveau', text = "F5 › Mes paramètres : taille du HUD réglable par chaque joueur (80 % à 160 %).", module = 'personal' },
} })
N.Add({ id = 'patch80', date = '2026-10-23', title = "Patch notes 80 : ID permanent, boutique en coins, HUD agrandi", items = {
    { tag = 'Nouveau', text = "ID permanent : chaque compte garde le même numéro pour toujours (têtes des joueurs, HUD, /id, menus staff, panel, journaux). Les commandes (/goto 12…) et les champs « ID du joueur » demandent cet ID ; la recherche staff trouve aussi un joueur hors ligne.", module = 'players' },
    { tag = 'Nouveau', text = "Boutique du serveur (/boutique, F11, menu Échap) : armes permanentes, véhicules, VIP, villas, argent en jeu, objets, plaques personnalisées, payés en coins.", module = 'premium' },
    { tag = 'Nouveau', text = "Les coins s'achètent uniquement avec de l'argent réel (Tebex : commande « shadowcoins add sid:{sid} <coins> {transaction} », jamais créditée deux fois). Le staff peut créditer ou retirer depuis le panel, avec un motif tracé.", module = 'premium' },
    { tag = 'Nouveau', text = "Arme permanente : liée au joueur (ni donnée, ni jetée, ni prise lors d'une fouille) ; perdue, elle se récupère dans « Mes achats ». Villa de la boutique : sans impôt ni loyer, intérieur et meubles au choix même sans VIP.", module = 'premium' },
    { tag = 'Corrigé', text = "HUD agrandi (F5 › taille du HUD) : l'argent sortait au-dessus de la carte. Il grossit maintenant depuis le haut de la carte, voix / faim / soif depuis le bas.", module = 'hud' },
    { tag = 'Corrigé', text = "Taxi : la part du chauffeur suit son compte (payée même s'il s'est déconnecté, jamais à un autre joueur qui reprend son numéro).", module = 'biz' },
    { tag = 'Corrigé', text = "Menu F7 : un membre d'organisation pouvait libérer, escorter, mettre en véhicule ou fouiller un prisonnier menotté par la police.", module = 'orga' },
    { tag = 'Corrigé', text = "Choix d'une personne (F6, F7, mécano) : le numéro de connexion des inconnus n'apparaît plus.", module = 'quick' },
    { tag = 'Amélioré', text = "Menu Échap : bouton « Boutique du serveur » et solde de coins sur l'accueil.", module = 'pause' },
} })
N.Add({ id = 'patch81', date = '2026-10-23', title = "Patch notes 81 : cadeaux et promotions dans la boutique", items = {
    { tag = 'Nouveau', text = "Boutique : « Offrir » un article à un joueur connecté (avec son ID permanent). C'est l'acheteur qui paie ; le joueur est prévenu et le retrouve dans « Mes achats » (« Offert par … »). Les plaques ne s'offrent pas.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : promotions par article (réduction en % et durée en jours) depuis le panel. Les joueurs voient le prix barré, le badge « −25 % » et la date de fin.", module = 'premium' },
    { tag = 'Corrigé', text = "ID permanent : à la déconnexion, l'ID restait associé au numéro de connexion ; un joueur qui reprenait ce numéro pouvait l'hériter. Il est maintenant libéré proprement.", module = 'players' },
} })
N.Add({ id = 'patch82', date = '2026-10-23', title = "Patch notes 82 : nouvelle boutique", items = {
    { tag = 'Amélioré', text = "Boutique entièrement redessinée : colonne avec le solde et « Acheter des coins », catégories en couleur, article à la une (promotion ou plus bel article), grandes cartes avec image, prix doré et badges (−25 %, déjà à toi, plus que 3…).", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : un clic sur un article ouvre sa fiche (grande image, ce que l'on reçoit, prix), avec confirmation de l'achat, « Offrir » et le choix de la plaque dans la même fiche. Échap ferme d'abord la fiche.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : « Mes achats » et « Historique » en listes claires, recherche dans toutes les pages, message de résultat en bas de la fenêtre.", module = 'premium' },
} })
N.Add({ id = 'patch131', date = '2026-10-27', title = "Patch notes 131 : props du staff et menu staff trié", items = {
    { tag = 'Nouveau', text = "Menu staff › Props permanents › Poser un prop : un catalogue intégré trié par thème (Barrières et signalisation, Mobilier, Événements, Éclairage et énergie, Chantier et stockage, Divers). Les modèles ajoutés dans le panel arrivent dans « Ajoutés par le serveur ».", module = 'staff' },
    { tag = 'Nouveau', text = "Aperçu au survol : en passant sur un prop (clavier ou souris), il apparaît en transparence devant toi et tourne sur lui-même. Entrée pour le placer, puis E pour le poser.", module = 'staff' },
    { tag = 'Amélioré', text = "Le réglage des noms au-dessus des têtes quitte l'accueil du menu staff : il est dans Gestion personnelle › Affichage, à côté des noms staff, du squelette et des repères.", module = 'staff' },
    { tag = 'Amélioré', text = "Gestion personnelle rangée en sections : Déplacement, Protection, Affichage, Téléportation.", module = 'staff' },
    { tag = 'Corrigé', text = "Dans tous les menus, survoler une ligne à la souris déclenche le même effet qu'au clavier (ex. le prop proche est entouré).", module = 'staff' },
} })
N.Add({ id = 'patch132', date = '2026-10-27', title = "Patch notes 132 : grades des patrons, double emploi VIP, ascenseurs, viseur staff", items = {
    { tag = 'Nouveau', text = "Entreprises : au bureau du patron, F6 › Grades et salaires permet maintenant de créer un grade (nom, salaire, position), de lui donner ou retirer des droits (engager, facturer, caisse…), de le renommer et de le supprimer (ses employés passent au grade du dessous). Les employés gardent leur grade quand on en ajoute un.", module = 'biz' },
    { tag = 'Nouveau', text = "Organisations illégales : le chef crée, renomme et supprime les grades de SON organisation (Gestion › Grades, au point boss), jusqu'à 8. Chaque organisation a ses propres grades ; sans grades perso, ce sont ceux du panel.", module = 'orga' },
    { tag = 'Modifié', text = "Double emploi réservé aux VIP : sans VIP, impossible d'avoir un second emploi. Un patron peut engager un VIP qui travaille déjà ailleurs : il devient son second emploi. VIP expiré : le second emploi n'est plus payé et /jobswap est bloqué. Réglable : Entreprises › Réglages.", module = 'biz' },
    { tag = 'Nouveau', text = "Builder › Ascenseurs : crée un ascenseur, pose chaque étage là où tu te tiens (Ajouter un étage ici), renomme, réordonne, réserve l'accès à une entreprise ou une organisation. En jeu : E à un étage, choix de la destination, fondu au noir et arrivée. Liste et réglages dans le panel (Ascenseurs).", module = 'elevators' },
    { tag = 'Nouveau', text = "Menu staff › Gestion personnelle › Balles infinies : munitions illimitées, sans rechargement, pour l'arme en main.", module = 'staff' },
    { tag = 'Nouveau', text = "Menu staff › Gestion personnelle › Viseur staff : un viseur au centre de l'écran ; le joueur visé est entouré avec son nom, son ID et sa distance. Clic gauche : ses actions rapides (infos, aller vers, ramener, observer, geler, soigner, message, avertir, expulser, prison) et « Toutes les actions ». Raccourcis clavier assignables dans FiveM.", module = 'staff' },
    { tag = 'Corrigé', text = "Inventaire transparent pour de vrai : le voile noir (88 %) et le flou étaient dessinés par le jeu derrière l'interface. Ils passent à 12 % et sans flou ; réglable dans le panel (Inventaire › Assombrissement du décor / Flouter le jeu).", module = 'inv' },
} })
N.Add({ id = 'patch133', date = '2026-10-27', title = "Patch notes 133 : Builder Créer / Existant, ponts mécano, garages par type, grosse passe de cohérence", items = {
    { tag = 'Nouveau', text = "Builder en deux onglets : « Créer » (entreprise, groupe, garage, magasin, ascenseur… puis ses points) et « Existant » (tout ce qui est déjà posé : modifier, déplacer, y aller, supprimer, du plus proche au plus loin).", module = 'builder' },
    { tag = 'Nouveau', text = "Garages mécano : plusieurs ponts (un par mécano). Dans la liste des points de l'entreprise, « Pont (atelier) » en ajoute un à chaque Entrée ; la customisation s'ouvre près de n'importe lequel.", module = 'builder' },
    { tag = 'Modifié', text = "Chaque véhicule ne se sort et ne se range que dans son type de garage, y compris pour les entreprises et les organisations : voitures au garage, hélicoptères à l'hélipad / au hangar, bateaux au port. Le vrai type est appris sur le véhicule (même un modèle ajouté). Un hélicoptère ou un bateau acheté en concession est livré au hangar / au port le plus proche (GPS posé).", module = 'garage' },
    { tag = 'Amélioré', text = "Points d'interaction tous identiques : la même touche « E » arrondie partout, y compris pêche, chasse, activités, Burger Shot et ascenseurs.", module = 'hud' },
    { tag = 'Modifié', text = "Menu staff : une seule option « Noms au-dessus des têtes » (ID et nom). Le réglage des étiquettes passe dans F5 › Mes paramètres.", module = 'staff' },
    { tag = 'Nouveau', text = "Menu staff › Gestion personnelle › « Infos staff en haut de l'écran » : la barre staff reste en haut, même avec un menu ouvert. Elle ne disparaît plus (renvoyée toutes les 5 s si l'interface l'a perdue).", module = 'staff' },
    { tag = 'Corrigé', text = "Points d'entreprise : bureau du patron, siège et accueil ouvraient le même menu. Le bureau du patron ouvre maintenant la gestion (employés, grades, caisse), l'accueil les factures, le siège le tableau de bord ; le point boss d'une organisation ouvre sa gestion.", module = 'biz' },
    { tag = 'Nouveau', text = "Garages mécano : le coffre « Pièces détachées » n'est jamais vide. Il remonte tout seul à 25 kits de réparation toutes les 5 minutes ; par défaut seul le patron y accède (kits offerts aux clients). Réglable : Atelier › Kits de réparation.", module = 'mech' },
    { tag = 'Nouveau', text = "Double emploi : F5 › Mon entreprise affiche les deux emplois et « Passer à … » pour changer (VIP).", module = 'biz' },
    { tag = 'Nouveau', text = "Nouvel écran de chargement (wb_loading) : fond noir, logo, nom du serveur, vraie progression du chargement avec l'étape en cours, astuces qui défilent.", module = 'general' },
    { tag = 'Corrigé', text = "Économie : l'allocation sans emploi (150 $) valait autant qu'un premier salaire, qui est imposé : un employé de café gagnait moins qu'un chômeur. Elle passe à environ 40 % du premier salaire (60 $ en économie équilibrée), dans tous les préréglages.", module = 'eco' },
    { tag = 'Corrigé', text = "Paie VIP : 2 500 $ par quart d'heure, soit plus que le chef de la police. Elle passe à 300 $ (si elle n'avait pas été modifiée).", module = 'vip' },
    { tag = 'Corrigé', text = "Paie : il faut avoir été connecté au moins la moitié de la période (se connecter juste avant la paie ne rapporte plus un salaire entier). Le second emploi n'est versé qu'en travaillant (en service).", module = 'biz' },
    { tag = 'Corrigé', text = "Prix : un même article coûtait un prix différent selon le magasin (sandwich 6, 7 ou 8 $ ; Sultan 32 000 ou 38 000 $…). Prix de référence partout. Le kit de réparation (450 $) coûtait moins cher qu'une réparation au garage (500 $) : il passe à 1 200 $.", module = 'shops' },
    { tag = 'Corrigé', text = "Armes : tout pesait 1,5 kg (du couteau au lance-roquettes). Poids réalistes par type (pistolet 1,1 kg, fusil 3,6 kg, sniper 6,5 kg, minigun 20 kg…) ; grenades, molotovs et bombes s'empilent par 5. Gusenberg rangée avec les mitraillettes, mitrailleuse de combat avec les armes lourdes.", module = 'armory' },
    { tag = 'Corrigé', text = "Munitions : le sac affichait « ammo_rifle », « ammo_smg »… au lieu de leur nom. Corrigé.", module = 'inv' },
    { tag = 'Corrigé', text = "La corde était vendue partout mais ne servait à rien : ligoter quelqu'un (menu de l'organisation) en utilise une.", module = 'orga' },
    { tag = 'Corrigé', text = "Bijouterie : elle se braquait sans aucun policier en ligne alors que la Fleeca en demande 2 ; il en faut 1. Le Builder et le réglage par défaut demandent tous les deux un crochet.", module = 'crime' },
    { tag = 'Corrigé', text = "Grades créés par le patron : même limite que le panel (12). Réglage « coût de réparation payé par la caisse » retiré du panel (il n'était plus utilisé).", module = 'biz' },
} })
N.Add({ id = 'patch135', date = '2026-10-28', title = "Patch notes 135 : grand audit (bugs, exploits, cohérence)", items = {
    { tag = 'Corrigé', text = "Props (menu staff) : choisir un prop dans le catalogue plantait le script et empêchait toute pose. Corrigé.", module = 'staff' },
    { tag = 'Corrigé', text = "Exploit d'argent : un patron d'une entreprise payée par l'État pouvait fixer 20 000 $ de salaire par paie (argent créé à chaque paie). Plafond réglable, 1 500 $ par défaut (Entreprises › Réglages). Une entreprise payée par sa caisse garde jusqu'à 20 000 $.", module = 'biz' },
    { tag = 'Corrigé', text = "Munitions de fusil, sniper, mitrailleuse et roquettes : « utiliser » la boîte la faisait disparaître sans rien recharger. Elles rechargent l'arme équipée du bon calibre.", module = 'armory' },
    { tag = 'Corrigé', text = "Ascenseurs : un joueur menotté ou inconscient pouvait s'enfuir par l'ascenseur. Refusé.", module = 'elevators' },
    { tag = 'Corrigé', text = "Garages par type : certaines voitures passaient pour des bateaux ou des avions à cause du début de leur nom (ex. Pegassi Toros, « toro »). Le type se lit maintenant sur le nom exact du modèle.", module = 'garage' },
    { tag = 'Corrigé', text = "Tomber inconscient avec une interface ouverte (téléphone, sac, banque, magasin, menu…) la laissait par-dessus l'écran de mort, souris comprise. Tout se ferme.", module = 'death' },
    { tag = 'Corrigé', text = "Une quarantaine d'icônes manquaient (drapeau, nuage, historique, porte, cloche, cube, lune…) et s'affichaient comme un « i » dans les menus du jeu et du panel.", module = 'general' },
    { tag = 'Corrigé', text = "Montants : une trentaine de messages affichaient « 15000 $ », « $15000 » ou « - 500 $ ». Partout au même format : « 15 000 $ », « -500 $ » (coiffeur, tatoueur, location, soins, territoires, guerres, essence, packs, infos staff…).", module = 'general' },
    { tag = 'Nouveau', text = "Radio : si la touche pour parler de pma-voice est la même que celle du menu ALT (ALT gauche par défaut), le menu radio le signale. Conseil : setr voice_defaultRadio \"CAPITAL\" dans server.cfg (Verr. Maj).", module = 'radio' },
    { tag = 'Nouveau', text = "Démissionner : un employé ne pouvait pas quitter son entreprise (seul le patron pouvait le renvoyer). F5 › Mon entreprise › « Démissionner » (ou /demission), deux fois pour confirmer ; « Quitter le second emploi » (/demission2). Un patron ne démissionne pas : le staff nomme un autre patron.", module = 'biz' },
    { tag = 'Nouveau', text = "Organisations : un membre peut « Quitter l'organisation » (menu de l'organisation › Gestion). Avant, seul le chef pouvait l'exclure. Le chef ne quitte pas : le staff nomme un autre chef.", module = 'orga' },
    { tag = 'Corrigé', text = "Second emploi : le message disait « /jobswap » ; il indique maintenant F5 › Mon entreprise.", module = 'biz' },
    { tag = 'Corrigé', text = "Builder › Existant : une suppression refusée affichait quand même « supprimé ».", module = 'builder' },
} })
N.Add({ id = 'patch134', date = '2026-10-27', title = "Patch notes 134 : Ammu-Nation, téléphone obligatoire, nouvelle radio, chasse aux bugs d'interface", items = {
    { tag = 'Modifié', text = "Ammu-Nation : plus d'armes à feu en vente libre. On y trouve les armes blanches (couteau, batte, pied-de-biche, club de golf, marteau, lampe torche, machette, hachette, cran d'arrêt, poing américain, clé) et les munitions de tous les calibres pour tout le monde (9 mm, calibre 12, SMG, fusil, sniper, mitrailleuse, roquettes). Le pistolet (150 000 $) est réservé aux VIP ; un non-VIP ne peut ni l'acheter, ni le recevoir d'un vendeur.", module = 'shops' },
    { tag = 'Modifié', text = "Téléphone obligatoire : sans l'objet « téléphone » dans le sac, impossible d'ouvrir le téléphone, d'appeler ou d'être joint (le 911 aussi). Chaque personnage reçoit un téléphone gratuit, une seule fois (à la fin de la création, ou à la connexion pour les personnages existants).", module = 'phone' },
    { tag = 'Nouveau', text = "Radio (F4) refaite en menu : fréquence actuelle, « Choisir une fréquence », « Couper la radio », volume (← →, mémorisé), 5 dernières fréquences, fréquences réservées de ton métier, touche pour parler rappelée.", module = 'radio' },
    { tag = 'Corrigé', text = "Menu ALT : quand il fallait écrire (montant, quantité…), la fenêtre se déformait : titre en double, « Retour » surligné, flèches de nombre, fenêtre qui sortait de l'écran. Chaque champ a maintenant son libellé, accepte seulement des chiffres et la fenêtre se recentre.", module = 'ctx' },
    { tag = 'Corrigé', text = "Menus (staff, F5, builder…) : une valeur longue à droite écrasait le libellé (« A » au lieu de « Accès ») et passait sur deux lignes. Le libellé garde sa place, la valeur est coupée proprement (…).", module = 'menu' },
    { tag = 'Corrigé', text = "Atelier mécano (customisation) : le texte d'aide passait sous la barre des touches, la carte choisie était coupée, les prix revenaient à la ligne, l'en-tête chevauchait la liste en 1366×768 et le bouton « Valider » était tronqué. Tout tient dans son cadre, à toutes les résolutions.", module = 'mech' },
    { tag = 'Corrigé', text = "Garage : « Nouvelle plaque » était une liste vide (impossible d'écrire la plaque). C'est un vrai champ de texte. Seul le premier formulaire de la page s'affichait (ex. « Reprendre un véhicule » d'une organisation) : ils s'affichent tous.", module = 'garage' },
    { tag = 'Corrigé', text = "Garage, concession, fourrière : avec un formulaire ouvert, la fiche du véhicule disparaissait et ses boutons revenaient dans les cartes, qui n'affichaient plus que « F… » et « PB 0… ». La fiche reste à droite, le formulaire passe dessous, le tout défile si besoin ; les lignes de la fiche disent ce qu'elles montrent (Carburant, État mécanique…) au lieu de « 0 % ».", module = 'garage' },
    { tag = 'Corrigé', text = "Magasins et garages en 1366×768 : le nom du lieu passait sous l'argent ; le message « ajouté au panier » recouvrait l'argent et le bouton Fermer.", module = 'shops' },
    { tag = 'Corrigé', text = "Notifications : le logo affiché à gauche était une image cassée (fichier manquant). Elles prennent le logo du serveur.", module = 'notify' },
    { tag = 'Corrigé', text = "Menu F5 en cartes : en 1366×768 la dernière rangée sortait de l'écran ; un nom long (« Los Santos Customs ») passait sur deux lignes.", module = 'personal' },
    { tag = 'Corrigé', text = "Écran d'entrée : « E Commencer » passait sous le logo sur les petits écrans.", module = 'entrance' },
    { tag = 'Corrigé', text = "Sac : poids écrits de trois façons (« 4.85/30.00 KG », « 25,1 kg »). Partout au même format : « 4,85 / 30 kg ».", module = 'inv' },
    { tag = 'Corrigé', text = "Infos staff d'un joueur : argent affiché « $4120 » au lieu de « 4 120 $ » ; grade vide remplacé par « — ».", module = 'staff' },
    { tag = 'Corrigé', text = "Noms au-dessus des têtes : le réglage avait été mis dans F5 › Mes paramètres, visible par tous les joueurs. Il est retiré du F5 : les noms sont réservés au staff et s'affichent seulement avec Menu staff › Gestion personnelle › « Noms au-dessus des têtes » (ID, nom et grade ; masqués par défaut). L'ancien affichage en double du menu staff est supprimé.", module = 'staff' },
    { tag = 'Modifié', text = "Écran de chargement retiré : wb_loading ne s'affiche plus (son dossier peut être supprimé). Le chargement FiveM par défaut revient.", module = 'general' },
} })
N.Add({ id = 'patch83', date = '2026-10-23', title = "Patch notes 83 : boutique dans la DA du serveur", items = {
    { tag = 'Amélioré', text = "Boutique dans la DA du serveur : angles carrés, gris des notifications, actions au rouge de la touche d'interaction, titres et étiquettes en capitales comme le HUD, logo du serveur, filets de couleur par catégorie. L'or reste réservé aux coins.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : le clic du serveur se joue aussi sur les cartes et l'article à la une ; rappel « ÉCHAP Fermer » avec la touche du serveur.", module = 'premium' },
} })
N.Add({ id = 'patch84', date = '2026-10-23', title = "Patch notes 84 : boutique encore plus complète", items = {
    { tag = 'Amélioré', text = "Boutique : accueil avec un carrousel « À la une » (promotions d'abord, puis le plus bel article de chaque catégorie, défilement automatique) et une rangée par catégorie avec « Voir tout ».", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : tri par prix (croissant, décroissant) et filtre « Dans mon budget » dans chaque catégorie.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : navigation au clavier (flèches, Entrée, Échap) avec la barre des touches en bas, dans le style des invites d'interaction ; solde rappelé en bas à droite.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : photo de fond discrète selon la catégorie, cartes qui apparaissent l'une après l'autre, reflet au survol, carte choisie au clavier entourée de rouge.", module = 'premium' },
} })
N.Add({ id = 'patch85', date = '2026-10-23', title = "Patch notes 85 : fiches techniques, favoris, écran d'achat", items = {
    { tag = 'Nouveau', text = "Boutique : fiche technique lue dans le jeu (vitesse en km/h, accélération, freinage, adhérence pour les véhicules ; dégâts et chargeur pour les armes), en barres sur la fiche et la vitesse sur la carte.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : favoris (étoile sur chaque carte et dans la fiche, page « Favoris »), gardés sur le poste du joueur.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : écran « Achat réussi » / « Cadeau envoyé » avec l'article, et le solde qui défile jusqu'à sa nouvelle valeur.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : badge « Nouveau » sur les 3 derniers articles ajoutés au catalogue.", module = 'premium' },
} })
N.Add({ id = 'patch86', date = '2026-10-23', title = "Patch notes 86 : chasse aux bugs", items = {
    { tag = 'Corrigé', text = "ID permanent et boutique : la base de données n'était pas reliée dans ces deux modules ; en jeu, l'ID n'aurait jamais été attribué et la boutique n'aurait pas pu s'ouvrir. Corrigé, et les tests le détectent désormais.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : changer la plaque d'un véhicule de la boutique permettait ensuite de s'en faire livrer un deuxième avec « Récupérer ». L'achat suit maintenant la plaque, et « Récupérer » n'apparaît que si le véhicule a vraiment disparu.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : couleurs des catégories invisibles dans le navigateur du jeu (fonction CSS trop récente) ; remplacées.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : elle ne s'ouvre plus par-dessus une autre interface (inventaire, téléphone, menus) ni quand on est à terre.", module = 'premium' },
    { tag = 'Corrigé', text = "Menu ALT : « Remettre sur ses roues » ne détectait jamais un véhicule retourné (fonction du jeu absente côté serveur).", module = 'ctx' },
} })
N.Add({ id = 'patch87', date = '2026-10-23', title = "Patch notes 87 : nouvelle entrée en ville", items = {
    { tag = 'Nouveau', text = "Écran d'entrée dans la boîte de nuit : vue d'ensemble avec la piste qui danse et la musique, « Appuyez sur E pour commencer » ; la caméra zoome sur ton personnage accoudé à la rambarde de la mezzanine.", module = 'entrance' },
    { tag = 'Nouveau', text = "Choix du personnage : ← → déplace la caméra d'un personnage à l'autre ; fiche (naissance, métier, argent, dernière connexion) ; emplacement libre = création du personnage ; emplacements « Réservé VIP » pour les autres.", module = 'entrance' },
    { tag = 'Nouveau', text = "Entrer en ville : transition du jeu (dézoom vers le ciel puis trois zooms jusqu'au point d'apparition), comme dans GTA. Le règlement attend la fin de la transition.", module = 'entrance' },
    { tag = 'Nouveau', text = "Réglage en jeu par le staff : /entree camera, /entree place 1 à 5, /entree piste, /entree test. Tout est aussi réglable dans le panel (Écran d'entrée).", module = 'entrance' },
} })
N.Add({ id = 'patch88', date = '2026-10-23', title = "Patch notes 88 : écran d'entrée épuré", items = {
    { tag = 'Amélioré', text = "Écran d'entrée : au début, seulement le logo du serveur (sans fond) et son nom ; plus de cadre transparent ni de texte. Seule la touche E reste, discrète, en bas.", module = 'entrance' },
    { tag = 'Amélioré', text = "Choix du personnage : plus de bandeau au-dessus de la fiche, la fiche monte en haut à gauche.", module = 'entrance' },
} })
N.Add({ id = 'patch89', date = '2026-10-23', title = "Patch notes 89 : écran d'entrée", items = {
    { tag = 'Corrigé', text = "Écran d'entrée : l'indication « E Commencer » restait visible en bas pendant le choix du personnage (son animation empêchait de la cacher).", module = 'entrance' },
} })
N.Add({ id = 'patch90', date = '2026-10-23', title = "Patch notes 90 : écran d'entrée", items = {
    { tag = 'Amélioré', text = "Écran d'entrée : l'indication « E Commencer » est en haut à gauche, sous le logo et le nom du serveur.", module = 'entrance' },
} })
N.Add({ id = 'patch91', date = '2026-10-23', title = "Patch notes 91 : écran d'entrée", items = {
    { tag = 'Corrigé', text = "Écran d'entrée : après E, le logo et le nom du serveur restaient affichés derrière la fiche du personnage (l'animation d'apparition empêchait de les cacher). Ils disparaissent maintenant ; un test le vérifie.", module = 'entrance' },
} })
N.Add({ id = 'patch92', date = '2026-10-24', title = "Patch notes 92 : menus F6 / F7 sans tablette, nouvelle souris", items = {
    { tag = 'Nouveau', text = "Menu F6 de l'entreprise : plus de tablette. En bas du menu, « Gestion de l'entreprise » ouvre toutes ses pages en sous-menus (tableau de bord, citoyens et dossiers, factures, équipe, annonces, statistiques, caisse…). Formulaires (liste ← →, saisie), confirmation avant de renvoyer ou d'exclure. Employés, grades, salaires et caisse restent au bureau du patron.", module = 'quick' },
    { tag = 'Nouveau', text = "Menu F7 des organisations : plus de tablette. Après les actions (ligoter, fouiller, QG, coffre, caisse), « Gestion de l'organisation » : crypto, classement, crews, grades, laboratoires, contrats, territoires (GPS), effectif, messages, caisse, activité. Gestion du chef au point boss ; le coffre s'ouvre au QG.", module = 'orga' },
    { tag = 'Nouveau', text = "Sans entreprise, F6 ouvre l'espace citoyen (finances, virement, factures, entreprises, profil). Le point du siège / QG et /tablette ouvrent le même menu ; plus de tablette en main.", module = 'quick' },
    { tag = 'Nouveau', text = "Souris du serveur dans toutes les interfaces (boutique, menu ALT, inventaire, téléphone…) : flèche aux couleurs du serveur, main seulement sur ce qui se clique, main appuyée pendant le clic.", module = 'hud' },
} })
N.Add({ id = 'patch93', date = '2026-10-24', title = "Patch notes 93 : menu F6 pour toutes les entreprises", items = {
    { tag = 'Nouveau', text = "Menu F6 de toutes les entreprises (restaurants, cafés, bars, magasins, concession, immobilier, médias, transport…), pas seulement police, secours, garage et taxi : partie « Mon établissement » avec Ouvrir / Fermer l'établissement (annoncé à toute la ville, « Ouvert » dans l'annuaire), Annonce publique, Demander du renfort (ta position aux collègues en service) et la liste des collègues en service.", module = 'quick' },
    { tag = 'Nouveau', text = "Métiers de santé (secours, pompiers, clinique, vétérinaire) : « Soigner » une personne blessée depuis le menu F6, inscrit dans les dossiers.", module = 'quick' },
    { tag = 'Corrigé', text = "Espace citoyen (F6 sans entreprise) : les pages réservées aux employés (équipe, annonces, règlement, lieux…) n'apparaissent plus.", module = 'biz' },
    { tag = 'Nouveau', text = "Panel › Menu entreprise (F6) › Réglages : chaque action commune s'active ou se coupe, avec les délais (annonce, renfort).", module = 'quick' },
} })
N.Add({ id = 'patch94', date = '2026-10-24', title = "Patch notes 94 : gestes de chaque métier (F6)", items = {
    { tag = 'Nouveau', text = "Mécano et dépanneur (F6 › Gestes du métier) : diagnostic du véhicule (moteur, carrosserie, réservoir, pneus, carburant), réparer le moteur, la carrosserie, changer les pneus, remettre sur ses roues, ouvrir un véhicule verrouillé (le propriétaire est prévenu), faire le plein, charger / décharger le plateau de la dépanneuse, envoyer à la fourrière. Animation et barre de progression ; chaque geste est ajouté à la facture du client.", module = 'quick' },
    { tag = 'Nouveau', text = "Police : contrôle d'identité (naissance, nationalité, permis d'arme, antécédents) et contrôle de plaque (propriétaire, fourrière, véhicule non enregistré). Secours : bilan du patient. Pompiers : éteindre les feux autour.", module = 'quick' },
    { tag = 'Nouveau', text = "Armurerie : vérifier le permis d'arme avant une vente. Médias (Weazel News, radio, journal) : flash info en grand chez tous les joueurs. Station-service : faire le plein. Station de lavage : laver le véhicule. Transport et travaux : missions de l'entreprise avec GPS.", module = 'quick' },
    { tag = 'Nouveau', text = "Factures pré-remplies selon le secteur : garage (réparation, remorquage, pneus), santé (consultation, soins, ambulance), restauration (menu, boisson), commerce, services, médias, loisirs, travaux…", module = 'quick' },
    { tag = 'Sécurité', text = "Tout est revérifié par le serveur : métier et service, véhicule réellement à côté (plaque lue par le serveur), durée du travail, distance à la fin ; ouverture de véhicule et fourrière inscrites dans les dossiers et le journal.", module = 'quick' },
} })
N.Add({ id = 'patch95', date = '2026-10-24', title = "Patch notes 95 : customisation seulement au garage", items = {
    { tag = 'Modifié', text = "Mécano : plus de « Customisation » dans le menu F6. Peinture, jantes, performances… se font seulement au garage, à l'atelier (point posé au Builder). Les réparations et les gestes du métier restent dans le F6.", module = 'mech' },
    { tag = 'Corrigé', text = "La customisation pouvait s'ouvrir n'importe où (la vérification de l'atelier était ignorée). Il faut maintenant être à moins de 15 m de l'atelier de son garage ; sans atelier posé, elle est indisponible.", module = 'mech' },
} })
N.Add({ id = 'patch96', date = '2026-10-24', title = "Patch notes 96 : cohérence de toute la base", items = {
    { tag = 'Corrigé', text = "Employés : dans le menu F6, partie « Mon espace » avec leurs pages perso (finances et virement, factures à payer, entreprises, profil). Depuis la fin de la tablette, ils n'y avaient plus accès.", module = 'quick' },
    { tag = 'Corrigé', text = "Plus aucun message ne parle de la tablette ou d'anciennes touches : facture du garage (F6 › Envoyer la facture), amende et facture à régler (F6 › Factures ou téléphone), virements (F6 › Finances), points du bureau du patron, de l'accueil et du QG, permis d'arme (F6 de la police).", module = 'general' },
    { tag = 'Modifié', text = "Panel : textes, documentation et aperçus mis à jour (menu F6 au lieu de la tablette, touches F5 / F6 / F7) ; réglages d'images des anciennes tuiles retirés.", module = 'general' },
} })
N.Add({ id = 'patch97', date = '2026-10-24', title = "Patch notes 97 : nouveau créateur et interfaces redessinées", items = {
    { tag = 'Nouveau', text = "Créateur de personnage redessiné dans la DA du serveur : panneau carré avec la barre rouge, étapes en segments, titres en capitales, boutons rouges, barre des touches (Entrée = étape suivante). Carte d'identité qui se remplit en direct à droite (nom, naissance, âge, taille, nationalité, arrivée).", module = 'character' },
    { tag = 'Nouveau', text = "Créateur : les vrais portraits des parents de GTA Online ; mères parmi les femmes, pères parmi les hommes. Date de naissance en jour / mois / année (31 février corrigé tout seul). Barre de caméra Visage / Corps / Pieds et rotation.", module = 'character' },
    { tag = 'Corrigé', text = "Créateur : une barre d'erreur rouge vide s'affichait par-dessus les champs, et la date de naissance était coupée (format américain).", module = 'character' },
    { tag = 'Nouveau', text = "Banque, logement et tickets : nouvelle fenêtre dans la DA (pages à gauche, espèces et banque en bas, cartes, tableaux, formulaires, confirmation avant une action sensible). Plus de style tablette.", module = 'general' },
    { tag = 'Amélioré', text = "Garage, fourrière, supérettes, armurerie et autres magasins : angles carrés, actions rouges, titres en capitales. Écran de mort (« État critique », chrono, barre, touches rouges) et écran de bienvenue (règlement numéroté) redessinés.", module = 'general' },
    { tag = 'Modifié', text = "Argent affiché partout au format « 18 250 $ » ; le HUD garde son style GTA « $640 ».", module = 'general' },
} })
N.Add({ id = 'patch98', date = '2026-10-24', title = "Patch notes 98 : nouvelle boutique", items = {
    { tag = 'Nouveau', text = "Boutique entièrement refaite : en-tête avec le logo, le code boutique (ton ID permanent), ton VIP, tes coins et « Acheter des coins » ; catégories à gauche ; grandes cartes avec la rareté (commun, rare, épique, légendaire) ; fenêtre de confirmation avec l'image, le prix et Annuler.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique journalière : une sélection qui change chaque jour à minuit, à prix réduit, un achat par joueur ; compte à rebours avant le renouvellement ; « Déjà acheté » une fois prise.", module = 'premium' },
    { tag = 'Nouveau', text = "Coffres : contenu et chances affichés, ouverture avec une bande qui défile puis s'arrête sur le gain. Le tirage se fait sur le serveur, seulement parmi ce que tu peux encore recevoir ; le gain est livré et récupérable dans « Mes achats ».", module = 'premium' },
    { tag = 'Nouveau', text = "Boosts : paie +25 % / +50 %, missions +50 %, pendant 24 h à 3 jours ; le bonus est versé en plus à chaque paie ou mission, et les boosts actifs s'affichent dans la boutique.", module = 'premium' },
    { tag = 'Nouveau', text = "Panel › Boutique : rareté, offres du jour (nombre, réduction, nouveau tirage), contenu des coffres, boosts, couleur de la boutique.", module = 'premium' },
} })
N.Add({ id = 'patch99', date = '2026-10-24', title = "Patch notes 99 : avantages VIP", items = {
    { tag = 'Nouveau', text = "VIP : pêche automatique. Lance ta canne comme d'habitude : chaque touche est ferrée toute seule et la ligne est relancée avec le même appât, prise après prise. X pour arrêter (ou bouger, plus d'appât, sac plein).", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : paie VIP de 2 500 $ toutes les 15 minutes de présence, en plus de la paie normale. Le temps compte par compte (une reconnexion ne remet pas le compteur à zéro) et ne s'écoule pas pour un joueur immobile (AFK).", module = 'vip' },
    { tag = 'Nouveau', text = "Panel › VIP › Avantages : montant et fréquence de la paie VIP, banque ou espèces, AFK payé ou non, pêche automatique, bonus de revente.", module = 'vip' },
} })
N.Add({ id = 'patch100', date = '2026-10-24', title = "Patch notes 100 : carte rapide (touche M)", items = {
    { tag = 'Nouveau', text = "Touche M : la mini-carte s'agrandit en bas à gauche, sans couper le jeu (tu continues de marcher ou de conduire). À côté, un panneau « Destinations » : tes véhicules (position en direct), ton logement, ton entreprise, le QG de ton organisation, tes lieux enregistrés, puis les services les plus proches (distributeur, banque, supérette, station-service, garage, fourrière, armurerie, vêtements, coiffeur, police, hôpital…), avec la distance.", module = 'hud' },
    { tag = 'Nouveau', text = "Carte rapide : ↑ ↓ pour choisir, Entrée pour mettre le GPS, Suppr pour l'effacer, ← → pour zoomer, M pour fermer. Échap ouvre la carte plein écran du jeu.", module = 'hud' },
    { tag = 'Amélioré', text = "Le HUD se place au-dessus de la mini-carte agrandie pendant que la carte rapide est ouverte.", module = 'hud' },
    { tag = 'Nouveau', text = "Panel › HUD › Carte rapide (M) : activer, touche par défaut, services proposés.", module = 'hud' },
} })
N.Add({ id = 'patch101', date = '2026-10-24', title = "Patch notes 101 : avantages VIP, F5 véhicules, Galaxy Club", items = {
    { tag = 'Nouveau', text = "VIP : mode drift. /drift l'active ou le coupe ; au volant, Maj gauche maintenue fait décrocher l'arrière.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : ventes entre joueurs sans taxe (contrats du téléphone : les 5 % de taxe de mutation ne sont plus retenus).", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : comptoir de location à Cayo Perico, en plus de la location normale. Véhicules importés (Squaddie, Slamtruck, Winky) avec un grand coffre (150 à 300 kg).", module = 'rental' },
    { tag = 'Nouveau', text = "VIP : récoltes ×3 (activités, fermes des entreprises) et drogues ×3 au champ.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : +20 kg dans le sac.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : Tec-9 et fusil à pompe dans le sac pendant toute la durée de l'abonnement (liés : ni donnés, ni jetés), repris à la fin.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : factures et amendes de la LSPD et des EMS réduites de 40 % (frais d'hôpital compris).", module = 'vip' },
    { tag = 'Nouveau', text = "Réapparition à l'hôpital : les armes et les objets sont perdus (réglable : aucun, armes seulement, tout ; téléphone, papiers, clés et vêtements gardés). Les VIP gardent tout.", module = 'death' },
    { tag = 'Nouveau', text = "VIP : reports prioritaires. Le ticket passe en tête de liste du staff avec la mention ★ VIP.", module = 'staff' },
    { tag = 'Nouveau', text = "Discord : second rôle des VIP (Gold), donné et retiré avec le rôle VIP. Les salons vocaux VIP et le salon textuel VIP (enchères) suivent ces rôles.", module = 'discordlink' },
    { tag = 'Nouveau', text = "F5 › Mes véhicules : pour chaque véhicule, son emplacement, le poids du coffre et son contenu, en lecture seule (rien ne peut être pris à distance).", module = 'personal' },
    { tag = 'Nouveau', text = "Galaxy Club : nouvelle boîte de nuit (Serveur, Barman, Agent de sécurité, DJ, Chef de la sécurité, Responsable, Patron), avec les factures du club (entrée, carré VIP, bouteille…).", module = 'biz' },
    { tag = 'Nouveau', text = "Agent de sécurité (F6) : palpation (arme repérée, rien n'est pris), contrôle à l'entrée (âge, bracelet, interdit), bracelets de la soirée, interdire ou réautoriser l'entrée, expulser (GPS vers la sortie), demander du renfort.", module = 'biz' },
    { tag = 'Nouveau', text = "Panel › VIP › Avantages : chaque avantage se règle ou se coupe (multiplicateurs, kilos, armes, réduction, entreprises concernées…).", module = 'vip' },
} })
N.Add({ id = 'patch102', date = '2026-10-24', title = "Patch notes 102 : icône Burger Shot sur la carte", items = {
    { tag = 'Corrigé', text = "Burger Shot : l'icône burger apparaît de nouveau sur la carte, en orange, pour tout le monde. L'ancienne icône (98) n'a pas d'image en jeu.", module = 'biz' },
    { tag = 'Corrigé', text = "Si le siège du Burger Shot n'avait pas de point sur la carte, il est posé au restaurant de Vespucci. Un siège masqué volontairement n'est pas touché.", module = 'biz' },
} })
N.Add({ id = 'patch103', date = '2026-10-24', title = "Patch notes 103 : coffre des véhicules en lecture seule (F5)", items = {
    { tag = 'Amélioré', text = "F5 › Mes véhicules : un clic sur un véhicule ouvre l'inventaire, ton sac à gauche et le coffre du véhicule à droite, où qu'il soit. L'épingle met le GPS.", module = 'personal' },
    { tag = 'Nouveau', text = "Inventaire en lecture seule : bandeau « Lecture seule », impossible de prendre, déposer, déplacer, utiliser, donner, jeter ou trier tant que cette vue est ouverte (vérifié aussi par le serveur).", module = 'inv' },
} })
N.Add({ id = 'patch104', date = '2026-10-25', title = "Patch notes 104 : menus « Shadow Studio V2 » (lib et menu ALT)", items = {
    { tag = 'Nouveau', text = "Nouveau style de menu « Shadow Studio V2 » (panel › Menus › Style du menu) : bloc noir en haut à gauche, logo rond, titre et onglets, barre de section avec compteur (3 / 11), lignes à icônes (la ligne choisie est blanche), interrupteurs, curseurs, valeurs avec points, description à part avec les valeurs en gras, touches en bas (Parcourir, Valider, Retour).", module = 'menus' },
    { tag = 'Nouveau', text = "Nouvelle version « Shadow Studio V2 » du menu ALT (panel › Menu ALT › Version du menu) : en-tête « Nom · ID », toutes les actions à la suite avec un espace entre les catégories, icônes fines, action dangereuse en rouge, un peu transparent. Flèches, Entrée et Retour arrière au clavier.", module = 'ctx' },
    { tag = 'Nouveau', text = "Développeurs : un menu peut afficher des onglets dans le style Shadow Studio V2 avec tabs = { { icon = 'users', label = 'Personnel' }, … } et tab = n° actif.", module = 'menus' },
} })
N.Add({ id = 'patch105', date = '2026-10-25', title = "Patch notes 105 : tous les menus lib en style Shadow Studio V2", items = {
    { tag = 'Amélioré', text = "Tous les menus lib (menu admin, F5, F6, F7, garage, atelier, stations…) passent au style Shadow Studio V2. On peut revenir à l'ancien dans Menus › Apparence › Style du menu.", module = 'menus' },
    { tag = 'Amélioré', text = "Le style Shadow Studio V2 a exactement la taille et la place de l'ancienne lib (336 × 584 px sur un écran 1080p, à gauche), avec le même pas entre les lignes : pas plus large, pas plus grand.", module = 'menus' },
    { tag = 'Amélioré', text = "Menu principal : la barre sous le titre affiche le sous-titre (grade, service…) ; dans un sous-menu, son titre.", module = 'menus' },
} })
N.Add({ id = 'patch106', date = '2026-10-25', title = "Patch notes 106 : logo du serveur dans les menus", items = {
    { tag = 'Corrigé', text = "Menus Shadow Studio V2 : le logo en haut est celui du serveur (panel › Identité). Il s'affiche dès que l'image arrive, même si le menu est déjà ouvert, et suit tout changement de logo sans redémarrer.", module = 'menus' },
    { tag = 'Amélioré', text = "Sans logo en jeu envoyé depuis le PC, les interfaces prennent le logo du panel (adresse https).", module = 'general' },
} })
N.Add({ id = 'patch107', date = '2026-10-25', title = "Patch notes 107 : en-tête des menus refait", items = {
    { tag = 'Amélioré', text = "Menus Shadow Studio V2 : en-tête plus rempli, avec le logo du serveur en plus grand et un halo de la couleur du serveur, le nom du serveur au-dessus du titre, les pastilles (Discord, site) en dessous, un fond texturé et un filet de couleur en bas. La taille du menu ne change pas.", module = 'menus' },
} })
N.Add({ id = 'patch108', date = '2026-10-25', title = "Patch notes 108 : nouveau logo de base, Discord dans les menus", items = {
    { tag = 'Nouveau', text = "Nouveau logo de Shadow Base (détouré, sans fond) : il s'affiche partout tant que le serveur n'a pas mis le sien (menus, bienvenue, création de personnage, boutique, panel…).", module = 'general' },
    { tag = 'Amélioré', text = "En-tête des menus : le lien du site est retiré, il ne reste que le Discord, réglable dans Menus › Apparence › « Discord affiché en haut des menus » (vide = pas de pastille).", module = 'menus' },
} })
N.Add({ id = 'patch109', date = '2026-10-25', title = "Patch notes 109 : style Shadow Studio V2 pour les interfaces en jeu", items = {
    { tag = 'Nouveau', text = "Panel › Interface › « Style des interfaces en jeu » : Shadow (DA du serveur, comme avant) ou Shadow Studio V2 (noir et blanc, verre, angles arrondis). Le changement s'applique en direct, sans redémarrer.", module = 'general' },
    { tag = 'Nouveau', text = "En Shadow Studio V2, supérette, armurerie, garage, fourrière, concession, magasin de vêtements, masques et sacs, créateur de personnage et écran d'entrée passent en noir et blanc : l'élément choisi est blanc.", module = 'shops' },
} })
N.Add({ id = 'patch110', date = '2026-10-25', title = "Patch notes 110 : inventaire Shadow Studio V2", items = {
    { tag = 'Nouveau', text = "Inventaire en style Shadow Studio V2 : logo du serveur en haut, catégories en pastilles au-dessus du sac (Tout, Armes, Nourriture…) qui filtrent les objets, panneaux en verre autour du personnage au centre.", module = 'inv' },
    { tag = 'Nouveau', text = "Jauge de poids par catégorie : la barre se découpe selon ce que tu portes, avec la légende (kg par catégorie) et les kilos libres. Elle passe en orange à 75 % (« Lourd ») et en rouge à 90 % (« Presque plein »).", module = 'inv' },
    { tag = 'Amélioré', text = "Shadow Studio V2 : la case sélectionnée est blanche, les slots d'équipement et la barre rapide sont arrondis, le texte Premium passe sous la barre rapide pour ne plus cacher la mini-carte.", module = 'inv' },
} })
N.Add({ id = 'patch111', date = '2026-10-25', title = "Patch notes 111 : intro animée à l'entrée", items = {
    { tag = 'Nouveau', text = "Écran d'entrée › « Style de l'accueil » : boîte de nuit (comme avant) ou intro animée : logo qui apparaît, nom du serveur, slogan, barre de chargement et « Appuie sur Entrée pour continuer ».", module = 'entrance' },
    { tag = 'Nouveau', text = "L'intro affiche les joueurs en ligne (sur le maximum du serveur) et le Discord des menus. Nouveau champ « Slogan » sous le titre (vide = pas de slogan).", module = 'entrance' },
} })
N.Add({ id = 'patch112', date = '2026-10-25', title = "Patch notes 112 : interfaces Shadow Studio V2 recadrées", items = {
    { tag = 'Amélioré', text = "Style Shadow Studio V2 : toutes les interfaces suivent les mêmes marges (60 px sur les côtés, 56 px en haut et en bas), avec en haut à gauche le logo du serveur, un filet, le titre et le sous-titre, et un fond assombri sur les bords.", module = 'general' },
    { tag = 'Amélioré', text = "Supérette, armurerie, épicerie (Shadow Studio V2) : catégories en liste à gauche, articles en grandes cartes au centre, panier sur toute la hauteur à droite avec le total et le bouton de paiement en bas.", module = 'shops' },
    { tag = 'Amélioré', text = "Garage et fourrière (Shadow Studio V2) : véhicules en bande en bas de l'écran, fiche du véhicule choisi à droite (plaque, état, détails) avec Sortir, Localiser… en grands boutons.", module = 'garage' },
    { tag = 'Amélioré', text = "Magasin de vêtements, masques et sacs (Shadow Studio V2) : rail d'icônes à gauche, une ligne par modèle à droite (la ligne choisie montre ses variantes), barre de paiement en bas, caméra juste au-dessus.", module = 'shops' },
    { tag = 'Amélioré', text = "Choix du personnage : liste numérotée à gauche (Vos personnages), fiche d'identité à droite avec métier, argent et dernière connexion, et un grand bouton Jouer avec sa touche Entrée.", module = 'entrée' },
    { tag = 'Amélioré', text = "Habillage commun à toutes les interfaces (banque, garage, logement, magasins, menus, tablettes, mécanicien…) : angles droits, panneaux sombres plats, sélection en couleur d'accent. L'accent est magenta par défaut ; pour le changer, va dans le panel › Inventaire › Réglages › « Couleur d'accent des interfaces ».", module = 'interface' },
    { tag = 'Amélioré', text = "Créateur de personnage et sélection de personnage (Shadow Studio V2) : panneaux, carte d'identité, emplacements et touches alignés sur les marges. Intro animée plus sombre, titre plus grand.", module = 'entrance' },
    { tag = 'Corrigé', text = "Créateur : la carte d'identité n'affiche plus « null » sous la nationalité tant qu'aucun point d'arrivée n'est choisi.", module = 'character' },
} })
N.Add({ id = 'patch113', date = '2026-10-25', title = "Patch notes 113 : lib Shadow Studio V2 à la bonne taille", items = {
    { tag = 'Corrigé', text = "Menus lib en style Shadow Studio V2 trop petits : le texte tombait à 11 px. Ils reprennent la taille de la maquette : 380 px de large, lignes de 34 px, texte de 14 px, titre de 18 px (sur un écran 1080p).", module = 'menus' },
    { tag = 'Corrigé', text = "Menus lib Shadow Studio V2 mal placés (au milieu à gauche, sur la mini-carte) : ils s'ouvrent en haut à gauche, à 24 px des bords, et la boîte s'arrête après la dernière ligne au lieu de garder un grand vide.", module = 'menus' },
    { tag = 'Amélioré', text = "Les menus suivent la taille de l'écran : 1,33 fois plus grands en 1440p, 2 fois en 4K, pour rester lisibles partout.", module = 'menus' },
} })
N.Add({ id = 'patch114', date = '2026-10-25', title = "Patch notes 114 : HUD et menu ALT corrigés", items = {
    { tag = 'Corrigé', text = "HUD : en style Shadow Studio V2, une grande barre noire recouvrait le bas de l'écran et cachait l'argent, la voix, la faim et la soif. Le HUD reprend sa place collée à la mini-carte.", module = 'hud' },
    { tag = 'Corrigé', text = "Menu ALT en version Shadow Studio V2 beaucoup trop grand (texte de 28 px, 500 px de large). Il fait maintenant 300 px de large avec un texte de 17 px en 1080p, et grandit avec l'écran.", module = 'ctx' },
    { tag = 'Amélioré', text = "Menu ALT Shadow Studio V2 : fond plus couvrant, lisible sur un décor clair.", module = 'ctx' },
    { tag = 'Corrigé', text = "Magasin de vêtements (Shadow Studio V2) : les touches d'aide ne cachent plus l'argent en haut, elles passent au-dessus des boutons de caméra.", module = 'shops' },
} })
N.Add({ id = 'patch115', date = '2026-10-25', title = "Patch notes 115 : plus de rectangles noirs", items = {
    { tag = 'Corrigé', text = "Rectangles noirs autour des interfaces en jeu (boutiques, garage, entrée, créateur, menus…) : le flou d'arrière-plan et les mélanges de couleurs, mal gérés par FiveM, sont coupés. Les fonds restent semi-transparents.", module = 'general' },
} })
N.Add({ id = 'patch116', date = '2026-10-25', title = "Patch notes 116 : le style Nova devient Shadow Studio V2", items = {
    { tag = 'Modifié', text = "Le style « Nova » s'appelle maintenant « Shadow Studio V2 » partout dans le panel (Interface, Menus, Menu ALT). L'ancien style s'appelle « Shadow Studio V1 ». Tes réglages ne changent pas.", module = 'general' },
    { tag = 'Corrigé', text = "Patch notes : les textes longs ne sont plus coupés au milieu d'une lettre accentuée.", module = 'general' },
} })
N.Add({ id = 'patch117', date = '2026-10-26', title = "Patch notes 117 : son des menus coupable, un seul style de lib", items = {
    { tag = 'Nouveau', text = "F5 › Mes paramètres › « Sons des menus » : chaque joueur peut couper le petit clic des menus de la lib et des interfaces. Le choix est mémorisé sur son poste. Le réglage du serveur (Menus › Comportement) reste prioritaire.", module = 'menus' },
    { tag = 'Modifié', text = "Les menus de la lib (F5, F6, F7, menu admin, garage, atelier, stations…) n'ont plus qu'un style : Shadow Studio V2. Les anciens styles (V1, épuré, classique) sont retirés et les serveurs qui les utilisaient passent en V2.", module = 'menus' },
} })
N.Add({ id = 'patch118', date = '2026-10-26', title = "Patch notes 118 : Shadow Studio V2 partout, nouveau bouton d'interaction", items = {
    { tag = 'Modifié', text = "Shadow Studio V2 devient le seul style : interfaces en jeu (boutiques, garage, vêtements, créateur, entrée…), inventaire, menus de la lib et menu ALT. Les anciens styles sont retirés du panel et les serveurs qui les utilisaient passent en V2.", module = 'general' },
    { tag = 'Amélioré', text = "Bouton d'interaction refait en V2 : pastille noire à coins doux, touche blanche à lettre noire, petite pointe vers le point ; la petite touche « E » au-dessus des points passe aussi en blanc et noir.", module = 'hud' },
    { tag = 'Retiré', text = "Menu d'interaction de la touche F2 supprimé (et son onglet dans le panel). Les actions passent par le menu ALT et le F5.", module = 'general' },
} })
N.Add({ id = 'patch119', date = '2026-10-26', title = "Patch notes 119 : logo et bannière du serveur partout", items = {
    { tag = 'Corrigé', text = "Logo du serveur envoyé depuis le PC : il ne s'affichait pas à l'écran d'entrée, dans le créateur, les boutiques, le garage et les vêtements quand l'image arrivait après l'ouverture (logo Shadow Base à la place). Il est demandé dès la connexion et se met à jour tout seul.", module = 'general' },
    { tag = 'Corrigé', text = "HUD : le logo du serveur en haut à droite apparaissait cassé quand il était envoyé depuis le PC. Le nom du serveur s'affiche le temps que l'image arrive.", module = 'hud' },
    { tag = 'Nouveau', text = "Menus de la lib : la bannière s'affiche en haut, au-dessus du logo et du titre. Ordre : Menus › Image de bannière, sinon Identité › Bannière du serveur, sinon la bannière du server.cfg (banner_detail).", module = 'menus' },
    { tag = 'Amélioré', text = "Sans nom réglé dans le panel, le nom du serveur est repris du server.cfg (sv_projectName, sinon sv_hostname).", module = 'general' },
} })
N.Add({ id = 'patch120', date = '2026-10-26', title = "Patch notes 120 : créateur V2, inventaire léger, menu ALT plus petit", items = {
    { tag = 'Modifié', text = "Menus de la lib : pas de bannière au-dessus du menu (retour en arrière), seulement le logo et le titre.", module = 'menus' },
    { tag = 'Amélioré', text = "Créateur de personnage en Shadow Studio V2 : en-tête en haut à gauche, étapes en pastilles en haut au centre, formulaire à gauche, carte d'identité à droite, caméra en bas au centre, Précédent / Suivant en bas à droite. L'étape Départ affiche la grande carte à droite.", module = 'character' },
    { tag = 'Nouveau', text = "Créateur : réglages au clavier. Flèches haut / bas pour choisir un réglage (taille, curseurs, listes, ‹ ›), gauche / droite pour le changer. La souris choisit aussi le réglage survolé.", module = 'character' },
    { tag = 'Amélioré', text = "Inventaire beaucoup plus léger, presque transparent : on voit le jeu derrière, sans voile sombre.", module = 'inv' },
    { tag = 'Amélioré', text = "Menu ALT encore réduit : texte de 13 px en 1080p, un peu plus large pour les libellés.", module = 'ctx' },
} })
N.Add({ id = 'patch121', date = '2026-10-26', title = "Patch notes 121 : menus d'entreprise par métier, menu ALT rangé", items = {
    { tag = 'Corrigé', text = "Menu de l'entreprise (F6) : le patron de n'importe quelle entreprise voyait les gestes de sécurité de club (palpation, contrôle à l'entrée, bracelet, interdiction, expulsion, liste de la soirée). Ils sont maintenant réservés aux boîtes de nuit, à la sécurité privée et aux grades qui ont le droit « Sécurité ».", module = 'quick' },
    { tag = 'Corrigé', text = "Menu F6 d'une boîte de nuit : un seul « Demander du renfort » au lieu de deux.", module = 'quick' },
    { tag = 'Amélioré', text = "Menu ALT rangé par catégories : Métier, Mon personnage, Interactions, Gestes à deux, Animations, Gestes, Poses, Danses, Sport, Staff, avec le nombre d'actions. On ouvre une catégorie pour voir ses actions ; Retour (ou flèche gauche / Retour arrière) revient aux catégories. Peu d'actions : tout s'affiche directement, avec un titre par catégorie.", module = 'ctx' },
    { tag = 'Amélioré', text = "Menu ALT › Métier : la prise de service est en premier.", module = 'ctx' },
} })
N.Add({ id = 'patch122', date = '2026-10-26', title = "Patch notes 122 : photos des vêtements, serveur plus fluide", items = {
    { tag = 'Nouveau', text = "Photos de près de 5 000 vêtements du jeu (homme et femme) : masques, sacs, hauts, sous-hauts, pantalons, chaussures, gilets, accessoires, écussons, chapeaux, lunettes, oreilles, montres et bracelets. Elles s'affichent dans les magasins de vêtements, le magasin de masques et sacs, et dans l'inventaire pour les objets vêtements.", module = 'shops' },
    { tag = 'Amélioré', text = "Photos regroupées en 30 paquets (18 Mo au total) au lieu de 5 000 fichiers : téléchargement plus rapide à la connexion. Vignettes de 64 px dans la liste des vêtements.", module = 'shops' },
    { tag = 'Amélioré', text = "Les tâches automatiques du serveur (paies, loyers, véhicules sortis, événements, anti-triche, sauvegardes…) ne partent plus toutes à la même seconde : fini les pics de lag toutes les minutes.", module = 'monitor' },
    { tag = 'Amélioré', text = "Sauvegarde régulière des joueurs étalée (un joueur toutes les 60 ms) au lieu de tout le serveur d'un coup.", module = 'monitor' },
    { tag = 'Amélioré', text = "Base de données : nouveaux index pour les véhicules sortis, les doubles de clé, les loyers, les événements et les bannissements.", module = 'monitor' },
} })
N.Add({ id = 'patch123', date = '2026-10-26', title = "Patch notes 123 : garage d'entreprise, essence, tir à la tête, magasins de vêtements, plus de thème rouge", items = {
    { tag = 'Corrigé', text = "Garage d'entreprise : seuls les véhicules de l'entreprise s'y affichent, s'y sortent et s'y rangent. Les véhicules personnels restent dans les garages publics.", module = 'garage' },
    { tag = 'Corrigé', text = "Essence : on peut faire le plein à toutes les pompes du jeu (27 stations au lieu de 6), au volant ou à pied à côté de la pompe avec le véhicule garé à côté. Le moteur se coupe tout seul pendant le plein.", module = 'fuel' },
    { tag = 'Corrigé', text = "Combat : les joueurs peuvent se blesser et se tuer (tir entre joueurs autorisé explicitement). Le staff en service n'est plus invincible d'office (réglage « Invincible dès la prise de service » dans le menu staff, désactivé par défaut).", module = 'death' },
    { tag = 'Nouveau', text = "Une balle dans la tête met à terre immédiatement (armes à feu seulement). Réglable dans Écran de mort › « Balle dans la tête mortelle ».", module = 'death' },
    { tag = 'Corrigé', text = "Magasin de vêtements qui s'ouvrait en « Masques et sacs » : après un passage au magasin de masques, les autres magasins de vêtements gardaient seulement ces deux rayons. Chaque magasin affiche maintenant ses propres rayons.", module = 'shops' },
    { tag = 'Corrigé', text = "Créateur de personnage, choix du personnage et du point d'apparition : ils s'ouvrent parfois avant que la configuration arrive et prenaient l'ancien thème rouge. Shadow Studio V2 est maintenant actif dès le chargement.", module = 'character' },
    { tag = 'Corrigé', text = "Écran de mort, écran d'accueil (règlement) et carte rapide : plus aucun rouge de l'ancien thème, tout est en noir et blanc Shadow Studio V2.", module = 'death' },
} })
N.Add({ id = 'patch124', date = '2026-10-26', title = "Patch notes 124 : tenues dans l'inventaire, inventaire transparent, noms masquables", items = {
    { tag = 'Nouveau', text = "Magasin de vêtements : chaque pièce achetée (haut, pantalon, chaussures, chapeau, lunettes, masque, montre…) arrive dans l'inventaire, déjà portée, avec sa photo du magasin (homme ou femme). Utiliser l'objet l'enlève ou le remet ; il se donne et se range comme les autres objets.", module = 'shops' },
    { tag = 'Amélioré', text = "Inventaire quasi transparent : panneaux réduits à un contour, plus de voile ni de flou sur l'écran ; seules les cases et les objets ressortent (texte ombré pour rester lisible).", module = 'inv' },
    { tag = 'Nouveau', text = "Menu staff › « Noms au-dessus des têtes » : chaque membre du staff peut masquer les noms et ID affichés au-dessus des joueurs (réglage mémorisé sur son poste).", module = 'tags' },
} })
N.Add({ id = 'patch125', date = '2026-10-27', title = "Patch notes 125 : ceinture, plein à pied, réglages au clavier", items = {
    { tag = 'Corrigé', text = "Ceinture : un appui ne la bascule plus deux fois de suite (« bouclée » aussitôt suivi de « détachée »).", module = 'trunk' },
    { tag = 'Modifié', text = "Essence : on descend du véhicule pour faire le plein. À la pompe, E ouvre le choix des litres, puis le personnage remplit le réservoir (animation, durée selon les litres). Au volant près d'une pompe : « Descends du véhicule pour faire le plein ».", module = 'fuel' },
    { tag = 'Corrigé', text = "Menu F5 en grandes cartes › Mes paramètres : la taille du HUD se règle aux flèches ← → et avec des boutons ‹ › (le curseur ne répondait qu'à la souris). La valeur affichée est la bonne à la réouverture.", module = 'personal' },
    { tag = 'Amélioré', text = "Menus de la lib : les flèches gauche / droite de la manette et du clavier (deux codes de touche du jeu) changent les listes et les curseurs.", module = 'menus' },
    { tag = 'Corrigé', text = "Menu F5 en grandes cartes : plus de rouge, accents blancs Shadow Studio V2.", module = 'personal' },
} })
N.Add({ id = 'patch126', date = '2026-10-27', title = "Patch notes 126 : garde-robe, gilets pare-balles, clés prêtées, flotte, ceinture", items = {
    { tag = 'Nouveau', text = "Garde-robe : « Enregistrer ma tenue » (bouton Tenue de l'inventaire ou menu ALT sur soi) range la tenue portée dans un sac de vêtements, avec la photo du haut. Utiliser le sac remet toute la tenue, n'importe où (visage et cheveux ne changent pas). Dans un logement, menu ALT › « Mes tenues » : enfiler ou supprimer. 10 tenues par joueur.", module = 'inv' },
    { tag = 'Nouveau', text = "Gilets pare-balles en vêtement : « Gilet pare-balles léger » (blindage 50) et « lourd » (100), avec leur photo. Ils s'équipent dans la case Gilet ; le blindage restant est gardé quand on l'enlève ; à 0 le gilet est détruit. Tant qu'il tient, une balle dans la tête ne tue pas d'un coup. À ajouter au catalogue d'un magasin (objets gilet_leger et gilet_lourd).", module = 'inv' },
    { tag = 'Nouveau', text = "Menu ALT sur un joueur › « Prêter la clé de mon véhicule » : ton véhicule personnel le plus proche (30 m), pour 1 heure, sans passer par le garage.", module = 'garage' },
    { tag = 'Nouveau', text = "Flotte : le patron (menu F6) et le chef d'organisation (menu F7) voient leurs véhicules de service : sortis ou non, qui les a sortis, GPS pour les retrouver, et « Rappeler au garage » pour ceux qui sont abandonnés (personne à bord).", module = 'garage' },
    { tag = 'Nouveau', text = "HUD : pastille « Ceinture » qui clignote au-dessus du compteur quand on roule à plus de 10 km/h sans ceinture (voitures seulement).", module = 'hud' },
    { tag = 'Corrigé', text = "Stations-service : plus de station en double au même endroit (pack de base + liste des 27 stations) ; les doublons existants sont retirés au démarrage.", module = 'fuel' },
    { tag = 'Corrigé', text = "Photos des vêtements : 352 images vides (texture manquante, damier rose) retirées ; ces pièces gardent leur numéro.", module = 'shops' },
} })
N.Add({ id = 'patch127', date = '2026-10-27', title = "Patch notes 127 : braquages par niveau, invites stables, graffitis visibles", items = {
    { tag = 'Nouveau', text = "Braquages par niveau : supérette, bijouterie, banque Fleeca, grande banque (Maze Bank, Pacific…). Chaque niveau impose un temps d'attente pour laisser la police arriver : 2 min, 3 min, 5 min et 8 min par défaut (Activités illégales › Réglages). Un minuteur s'affiche en haut de l'écran ; la police reçoit l'alerte avec la durée.", module = 'crime' },
    { tag = 'Nouveau', text = "Pendant le braquage, le braqueur est libre de ses mouvements (il peut se défendre) mais doit tenir la zone (12 à 30 m selon le niveau). Sortir de la zone lance un compte à rebours de 15 s pour revenir ; mort, menotté ou trop longtemps dehors = braquage raté.", module = 'crime' },
    { tag = 'Nouveau', text = "Builder : quatre points de braquage (supérette, bijouterie, Fleeca, Maze Bank) avec des gains, des délais et un nombre de policiers adaptés. Les braquages déjà posés prennent leur niveau d'après leur nom (« Fleeca », « Maze »…) ou la nouvelle colonne Niveau.", module = 'crime' },
    { tag = 'Amélioré', text = "Bijouterie et banques : touche E au point du braquage (plus besoin de viser un vendeur qui n'existe pas). Supérette : viser le vendeur affiche maintenant la progression.", module = 'crime' },
    { tag = 'Corrigé', text = "L'invite du braquage ne s'affichait qu'un instant : celle du magasin au même comptoir l'effaçait. Elle a maintenant sa propre ligne, et le vendeur reste reconnu tant qu'il est au comptoir.", module = 'crime' },
    { tag = 'Corrigé', text = "Le braqueur restait bloqué en train de viser pendant tout le braquage ; et une prise de territoire lançait en plus l'animation d'attente des activités illégales.", module = 'crime' },
    { tag = 'Corrigé', text = "Graffitis posés mais invisibles : la page qui dessine le tag recevait parfois le tag avant d'être chargée. Le texte est maintenant inscrit dans la page elle-même et l'envoi est répété. Les tags ne sont plus affichés retournés.", module = 'graffiti' },
} })
N.Add({ id = 'patch128', date = '2026-10-27', title = "Patch notes 128 : chasse avec le guide, couleur du serveur partout, points de pêche", items = {
    { tag = 'Nouveau', text = "Chasse : le guide de chasse (PNJ) prête un fusil, des cartouches et un couteau (« Demander à chasser »). Le fusil ne blesse que le gibier, jamais un joueur ni un véhicule, et ses cartouches ne s'épuisent pas. Au marché du chasseur, le marchand reprend tout seul le matériel prêté avant d'acheter le gibier (sans le fusil, pas de vente).", module = 'chasse' },
    { tag = 'Amélioré', text = "Chasse : beaucoup plus de gibier (un animal toutes les 20 s, jusqu'à 6 autour de chaque chasseur), mais des prix bas (35 % des prix de base) pour que les entreprises restent la vraie source de revenus. Réglable dans Extensions › Chasse.", module = 'chasse' },
    { tag = 'Corrigé', text = "La couleur principale du serveur (panel › Général) s'applique de nouveau à toutes les interfaces : inventaire, magasins, garde-robe, créateur, menus, entrée… Le texte posé dessus passe en noir ou en blanc selon la couleur ; une couleur trop sombre est éclaircie pour rester lisible.", module = 'general' },
    { tag = 'Corrigé', text = "Points de pêche : « Supprimer le point de pêche le plus proche » (Builder › Pêche) retire aussi les anciennes zones de pêche et poissonneries posées avec les Activités, dont l'icône restait sur la carte. Rayon de suppression porté à 25 m.", module = 'peche' },
} })
N.Add({ id = 'patch129', date = '2026-10-27', title = "Patch notes 129 : toute l'économie suit le panel, toutes les interfaces en V2", items = {
    { tag = 'Nouveau', text = "Onglet Économie : le multiplicateur des prix et la TVA s'appliquent maintenant à tout ce que les joueurs paient : magasins, véhicules, vêtements, coiffeur, carburant, location, logements du serveur, mécanicien, plaques, petites annonces, matériel de pêche et de chasse, animalerie, marché noir, receleur. Les menus du jeu affichent le prix réellement payé.", module = 'eco' },
    { tag = 'Nouveau', text = "Onglet Économie : le multiplicateur des salaires s'applique à tous les gains (missions, petits jobs, braquages, drogue, cambriolages, distributeurs, GoFast, fourgons, territoires, guerres, pêche, chasse, récolte, événements). Deux nouveaux réglages : « Revenus illégaux (×) » et « Activités et loisirs (×) », inclus dans les presets.", module = 'eco' },
    { tag = 'Amélioré', text = "Toutes les interfaces passent dans la DA Shadow Studio V2 (verre noir, Montserrat, angles arrondis, couleur du serveur) : banque, logement, tickets du support, accueil et règlement, écran de mort, menu pause, graffitis, tablette, carte rapide, badge professionnel, boutique du serveur, casino, guerre de territoire, compteur du taxi, barre du staff, écran partagé, astuces, chat et barres de progression.", module = 'general' },
    { tag = 'Info', text = "Avec la TVA par défaut (8 %), la location, le carburant, les logements du serveur et le mécanicien coûtent 8 % de plus qu'avant : c'est la même règle que les magasins. Les logements mis en vente par un agent immobilier gardent le prix choisi par l'agent.", module = 'eco' },
} })
N.Add({ id = 'patch130', date = '2026-10-27', title = "Patch notes 130 : nouveau téléphone, AirDrop, nouvel atelier, boutique", items = {
    { tag = 'Nouveau', text = "Téléphone entièrement refait façon iPhone : coque titane, Dynamic Island, barre d'état, widgets Météo (quartier, météo et température du jeu) et Calendrier (date du jeu), nouvelles icônes, dock, bouton Rechercher (applications et contacts), applications en mode sombre avec grands titres, bulles de messages, calculatrice ronde.", module = 'phone' },
    { tag = 'Nouveau', text = "Fonds d'écran : Réglages › Fond d'écran ouvre une galerie (cuivre, argent, nuit, graphite et cinq néons) ; le « + » reprend la bannière du serveur. Les anciens fonds sont convertis automatiquement.", module = 'phone' },
    { tag = 'Nouveau', text = "AirDrop : Contacts › ta fiche (ou un contact) › choisis une personne à côté de toi (6 m) ; elle accepte ou refuse et le contact s'ajoute chez elle. Réception activable dans Réglages › AirDrop.", module = 'phone' },
    { tag = 'Nouveau', text = "Atelier du mécano refait : la voiture au centre avec une caméra qui suit l'onglet, les pièces à gauche (Performances, Extérieur, Intérieur, Peinture, Roues, Extras), les performances avant / après et le panier à droite. ↑ ↓ pièce, ← → réglage (appliqué tout de suite : le client voit le changement), Q / E onglet, Entrée valide le devis, Échap annule. « Ouvrir les portes » pour montrer l'intérieur. Clic maintenu et glisser autour de la voiture pour tourner la caméra, molette pour zoomer. Même logique qu'avant : le serveur recalcule les prix, puis F6 › Envoyer la facture.", module = 'mech' },
    { tag = 'Amélioré', text = "Boutique du serveur (coins) dans la même DA que l'atelier : panneaux noirs, onglets à liseré blanc, bouton principal blanc, réductions en vert.", module = 'premium' },
} })
N.Add({ id = 'patch136', date = '2026-10-28', title = "Patch notes 136 : grosse liste (viseur, territoires, blanchiment, labos, EMS, F7, téléphone…)", items = {
    { tag = "Corrigé", text = "Viseur staff : il plantait le jeu en visant quelqu'un (contour lumineux posé sur un personnage) et n'était pas au centre de l'écran. Repère sans danger (cercle au sol + flèche) et réticule au vrai centre ; même correction dans tous les menus de sélection (F6, F7…).", module = 'staff' },
    { tag = "Corrigé", text = "Points qui ne s'enlevaient pas (pêche, chasse, activités, braquages, animalerie, atelier d'armes) : ils apparaissent maintenant dans Builder › Existant et se suppriment un par un.", module = 'carte' },
    { tag = "Nouveau", text = "Territoires de gang au Builder : marche jusqu'à chaque coin et appuie sur Entrée, la zone se dessine au fur et à mesure ; E pour terminer, puis le nom et l'objet offert toutes les 5 h au groupe qui la tient. Les zones dessinées s'affichent au sol et la capture suit leur contour.", module = 'territories' },
    { tag = "Modifié", text = "Drapeaux : tous les anciens points de vente et leurs drapeaux sont retirés une fois ; on les repose depuis Builder › Drogues (le drapeau vient avec le point de vente, drogue déjà choisie).", module = 'flags' },
    { tag = "Nouveau", text = "Blanchiment avec un contact (PNJ) : plus la mise est petite, plus il prend un gros pourcentage (45 % à 14 %) ; ça dure longtemps (1 h + 3 min par 1 000 $), l'argent propre revient au fur et à mesure, même si tu pars, notification à la fin, un seul à la fois. Les VIP suivent l'avancement de partout (/blanchiment).", module = 'crime' },
    { tag = "Nouveau", text = "Laboratoires de drogue : la transformation devient un mini-jeu en trois étapes (dosage, cuisson, mise en sachets). Ratée = ingrédients perdus, réussie = production normale, excellente = +50 %.", module = 'crime' },
    { tag = "Nouveau", text = "Toutes les supérettes posées sont braquables, avec leur propre vendeur (plus d'apu en double ni de braquage à configurer pour chacune). Il faut tenir le vendeur en joue 5 s.", module = 'crime' },
    { tag = "Modifié", text = "Menu F7 : seulement les actions illégales (ligoter, détacher, escorter, mettre / sortir du véhicule, fouiller, cagoule, braquer mains en l'air, QG, coffre, caisse). La gestion (crypto, territoires, grades, caisse…) est au point boss.", module = 'orga' },
    { tag = "Nouveau", text = "Menu ALT › « Actions illégales » : les mêmes actions, visibles seulement par les membres d'un gang ou d'une organisation.", module = 'ctx' },
    { tag = "Nouveau", text = "EMS : animation de massage cardiaque avant de réanimer (et soins à genoux), puis choix de la personne à facturer (gens autour mis en surbrillance). Médecin (PNJ) à poser au Builder : soins complets, chers exprès.", module = 'biz' },
    { tag = "Nouveau", text = "Agence immobilière : l'agent choisit une gamme (studio, appartement, luxe, villa) à prix fixés par le serveur, l'intérieur est posé tout seul. Plus de prix libre.", module = 'housing' },
    { tag = "Corrigé", text = "Logement acheté : le point au sol restait « à vendre ». Carte : vert libre, rouge occupé, rose chez toi. Sortie de l'intérieur plus fiable (plus de blocage sur le menu).", module = 'housing' },
    { tag = "Modifié", text = "Carte : les points d'entreprise portent le nom de l'entreprise (« Bennys », « Bennys · Garage ») au lieu de « Siège · Ouvert / Fermé » ; la couleur reste verte ouverte, rouge fermée.", module = 'biz' },
    { tag = "Nouveau", text = "F5 › « Entreprises de la ville » : chaque entreprise ouverte ou fermée en ce moment, avec le GPS.", module = 'personal' },
    { tag = "Modifié", text = "Staff : hors service, F10 n'affiche que « Prendre mon service ». Ped de service : le magasin de vêtements, le coiffeur et le tatoueur ne l'enlèvent plus. Nouveau : « Démenotter / délier » dans la fiche d'un joueur (et /demenotter).", module = 'staff' },
    { tag = "Nouveau", text = "Téléphone : configuration au premier démarrage (« Bonjour » animé, code à 4 ou 6 chiffres, Face ID, fond d'écran), écran verrouillé à chaque ouverture (Face ID ou code), Réglages › Face ID et code. Téléphone plus petit à l'écran.", module = 'phone' },
    { tag = "Corrigé", text = "Téléphone › Localiser : un véhicule rangé indique maintenant « Rangé au garage … (à sortir au guichet) » (le GPS menait au garage sans rien dessus) ; un véhicule disparu du monde depuis plus de 30 min part à la fourrière au lieu d'un GPS vers une rue vide.", module = 'garage' },
    { tag = "Modifié", text = "Véhicules : le moteur démarre d'un coup ; le passager ne passe plus au volant quand le conducteur descend ; touche G (réglable) pour changer de place.", module = 'vehtrunk' },
    { tag = "Nouveau", text = "HUD : la vie (cœur et pourcentage) au-dessus de la faim et de la soif.", module = 'hud' },
    { tag = "Amélioré", text = "Notifications plus fines, barre à la couleur du serveur, logo détouré tout seul (plus de carré noir) ; menus de la lib à la couleur du serveur (Menus › Apparence) ; plus de cadre noir autour de la barre staff.", module = 'hud' },
    { tag = "Corrigé", text = "Boutons « Fermer » des interfaces (banque, logement, tickets, magasins…) : ils étaient écrasés en ovale, ils ont un style propre. Photos des articles de l'armurerie et des magasins recadrées (cartes plus petites, image entière). Plus de barre d'aide dans le magasin de vêtements.", module = 'shops' },
    { tag = "Corrigé", text = "Invites « E » : toujours posées sur le point d'interaction (ou sur le personnage), comme aux supérettes, au lieu de s'afficher à part.", module = 'hud' },
    { tag = "Modifié", text = "Chasse : puma et panthère s'approchent au pas, attaquent seulement de près et font 4 fois moins de dégâts.", module = 'events' },
    { tag = "Retiré", text = "Base militaire : plus de soldats, de véhicules de l'armée ni d'avions de chasse dans le monde ; chars, blindés et avions militaires retirés du catalogue. Les PNJ morts ne lâchent plus d'arme ni d'argent.", module = 'world' },
} })
N.Add({ id = 'patch137', date = '2026-10-28', title = "Patch notes 137 : batailles de zone, annonces plein écran, customs, recherche d'objets", items = {
    { tag = "Nouveau", text = "Territoires = batailles de zone : points de contrôle à tenir seul, score par point tenu et par élimination, premier à 100 ou meilleur score au temps. Tableau des scores à l'écran, avance par les graffitis. Prise possible seulement aux heures réelles programmées (ven/sam/dim 20h-23h, Paris), pas de secours en zone de guerre, texte propre en bas de l'écran et scores en bas à droite, annonces de début et de fin, tirs interdits dans la zone sauf pour son gang hors guerre.", module = 'territories' },
    { tag = "Corrigé", text = "Atelier : customs des véhicules add-on (teintes, annulation, roues de moto, options du modèle, refus signalés, ré-application à la sortie).", module = 'mech' },
    { tag = "Nouveau", text = "Annonces plein écran façon txAdmin : grand bandeau au centre de l'écran (4 styles, durée, son, auteur), panel › Annonces, commande /annonce, historique. Aperçu dans le panel, utilisable depuis le menu admin F10. Réservé aux fondateurs.", module = 'announce' },
    { tag = "Nouveau", text = "HUD : munitions en haut à droite (chargeur / réserve + barre) à la place de celles du jeu, réglable.", module = 'hud' },
    { tag = "Nouveau", text = "Menu staff › Donner un objet : recherche par nom simplifié ou technique, les deux noms affichés.", module = 'staff' },
    { tag = "Nouveau", text = "Panneau à droite de la carte du jeu (icônes natives de GTA) : lieux par catégorie, recherche, repères qui clignotent, GPS, masquer les repères, zones de territoires (Échap › Carte ou /carte).", module = 'pause' },
    { tag = "Nouveau", text = "Territoires : les batailles reprennent après un redémarrage, historique des guerres, police et staff peuvent tirer dans les zones.", module = 'territories' },
    { tag = "Nouveau", text = "Annonces : destinataires au choix (groupe, entreprise, joueur, staff, police), modèles enregistrés, historique nettoyé automatiquement.", module = 'announce' },
    { tag = "Nouveau", text = "Menu staff : journal des actions et bouton Annuler (argent, objets, gel, silence, téléportation, bannissement, prison).", module = 'staff' },
} })
N.Add({ id = 'patch138', date = '2026-10-29', title = "Patch notes 138 : téléphone, nouvelles cartes", items = {
    { tag = 'Nouveau', text = "Cartes du panel et du créateur (choix du point d'arrivée) : la nouvelle carte satellite avec le nom des lieux, et un bouton Satellite / Plan pour passer au plan des routes. Même cadrage que la carte du jeu : les points restent à leur place.", module = 'pointsmap' },
    { tag = 'Corrigé', text = "Téléphone : on pouvait rester bloqué dans la configuration du premier démarrage. Le code se tape aussi au clavier (chiffres, Retour arrière), « Passer (sans code) » est proposé dès le Bonjour, l'accueil s'ouvre tout de suite après « Commencer », et la configuration n'est plus redemandée à chaque ouverture (colonnes de la base réparées au démarrage si besoin).", module = 'phone' },
} })
N.Add({ id = 'patch139', date = '2026-10-29', title = "Patch notes 139 : villa Playboy", items = {
    { tag = 'Nouveau', text = "Nouvelle carte : la villa Playboy à Richman (ressource playboy_mansion dans [addon]). Intérieur complet : garage, deux bureaux, cave à vin avec entrée secrète, pièce secrète, trois chambres, cuisine, bibliothèque, sur deux étages. Les points (entrée, garage, coffre…) se posent au Builder." },
} })
N.Add({ id = 'patch140', date = '2026-10-29', title = "Patch notes 140 : territoires réparés", items = {
    { tag = 'Corrigé', text = "Carte : les territoires s'affichent avec leur vraie forme (la zone dessinée au Builder est remplie, plus un grand cercle approximatif). Le staff qui gère les territoires les voit aussi, même sans gang : une zone créée apparaît tout de suite.", module = 'territories' },
    { tag = 'Corrigé', text = "Contour au sol : il suit le terrain tous les 2,5 m (avant : un trait tiré à la hauteur du joueur, qui flottait ou s'enfonçait), avec un voile lumineux de 2 m de haut de la couleur du gang. Rouge pendant une guerre.", module = 'territories' },
    { tag = 'Corrigé', text = "Dans une zone : « Territoire · nom » s'affiche à chaque entrée et reste tant qu'on y est (il disparaissait après la première fois). La présence suit le contour dessiné, partout : prise des points, éliminations, guerres planifiées.", module = 'territories' },
    { tag = 'Corrigé', text = "Guerres : le compte à rebours et les scores ne s'affichent plus que dans la zone en guerre (avant : sur l'écran de tout le serveur). La zone clignote en rouge sur la carte, et la fin de la guerre est envoyée à tous : plus de zone restée « en guerre » chez ceux qui étaient partis. Deux batailles en même temps ne se mélangent plus.", module = 'territories' },
} })
N.Add({ id = 'patch141', date = '2026-10-29', title = "Patch notes 141 : affichage des guerres", items = {
    { tag = 'Amélioré', text = "Guerre de territoire : texte propre en haut de l'écran, sans cadre (« ZONE EN GUERRE · zone · temps restant », puis les règles), et les points de chaque gang en bas à droite avec leur barre de couleur. Même affichage pour les batailles de zone et les guerres planifiées, seulement dans la zone en guerre.", module = 'territories' },
} })
N.Add({ id = 'patch142', date = '2026-10-29', title = "Patch notes 142 : tirs libres pendant toute prise de zone", items = {
    { tag = 'Corrigé', text = "Prise d'un territoire déjà tenu par une organisation : pendant la prise, tout le monde peut tirer dans la zone. Avant, pendant une guerre planifiée, seul le gang propriétaire pouvait tirer (les attaquants étaient désarmés), et pendant une bataille quelqu'un qui arrivait pouvait rester bloqué quelques secondes.", module = 'territories' },
    { tag = 'Corrigé', text = "Guerres planifiées : secours coupés dans la zone comme pour les batailles, zone rouge avec sa vraie forme sur la carte, plus d'invite « Attaquer » pendant la guerre. Une bataille et une guerre planifiée ne peuvent plus se lancer sur la même zone en même temps.", module = 'territories' },
} })
N.Add({ id = 'patch143', date = '2026-10-29', title = "Patch notes 143 : téléphone, carte, zones visibles", items = {
    { tag = 'Corrigé', text = "Téléphone : à l'étape « Fond d'écran » du premier démarrage, le bouton Continuer sortait de l'écran (on restait bloqué). La grille des fonds défile, le bouton reste toujours visible en bas.", module = 'phone' },
    { tag = 'Nouveau', text = "Carte (Échap › Carte ou /carte) : ton nom FiveM en première ligne de la liste, un clic fait clignoter ta position sur la carte.", module = 'pause' },
    { tag = 'Amélioré', text = "Territoires : les zones et leur repère sont visibles sur la carte par tous les joueurs (réglage dans Zones de gangs › Réglages ; avant, seulement les membres d'un gang).", module = 'territories' },
} })
N.Add({ id = 'patch144', date = '2026-10-29', title = "Patch notes 144 : tablette au QG, carte des territoires, barres de défilement", items = {
    { tag = 'Nouveau', text = "Tablette de l'entreprise et de l'organisation, dans la même fenêtre que la banque : elle s'ouvre seulement au siège / QG (E sur le point), et se ferme si on s'éloigne. Bureau du patron : la gestion s'ouvre directement. /tablette, /orga et les pages de gestion du F6 renvoient au siège (réglage dans Organisations › réglages). L'espace citoyen reste ouvert à tous.", module = 'orga' },
    { tag = 'Nouveau', text = "Tablette de l'organisation › Accueil : tableau de bord (ton grade et ton XP, membres en ligne, caisse commune, territoires tenus, classement, derniers messages du chef, nos territoires avec la prochaine livraison, membres connectés).", module = 'orga' },
    { tag = 'Nouveau', text = "Tablette de l'organisation › Territoires : carte des zones avec leur vraie forme, en bleu si libre, à la couleur du gang qui la tient sinon (ta zone entourée de blanc), légende, Satellite / Plan, cadrage sur les zones ou toute la carte.", module = 'territories' },
    { tag = 'Amélioré', text = "Carte du jeu : les territoires libres sont en bleu, ceux d'un gang prennent sa couleur, plus visibles.", module = 'territories' },
    { tag = 'Corrigé', text = "Grosse barre blanche à droite des listes (téléphone, magasins, menus, inventaire…) : le navigateur du jeu ignorait le réglage des barres de défilement. Barre fine et discrète partout, cachée dans le téléphone.", module = 'hud' },
} })
N.Add({ id = 'patch145', date = '2026-10-29', title = "Patch notes 145 : carte du serveur, moteur, armes, chasse, F2", items = {
    { tag = 'Nouveau', text = "Carte (Échap › Carte ou /carte) : la carte du serveur en plein écran à la place de celle de GTA, avec le même panneau à droite. Trois types de carte (Satellite, Plan, Sombre), territoires (bleus si libres, couleur du gang sinon), repères des lieux, ta position, GPS d'un clic sur la carte ou sur un lieu. Glisser pour déplacer, molette pour zoomer.", module = 'pause' },
    { tag = 'Corrigé', text = "Véhicules : le moteur calait à chaque première montée (comme un moteur froid). Il était coupé le temps que le serveur vérifie la clé ; il n'est plus coupé que si tu n'as vraiment pas la clé.", module = 'garage' },
    { tag = 'Corrigé', text = "Armes : les touches 1 à 5 répondaient « une arme s'équipe avec les touches 1 à 5 » sans rien faire pour une arme hors du catalogue (pack d'armes, objet weapon_*). Elle s'équipe maintenant, et une arme ajoutée au catalogue dans le panel est utilisable tout de suite.", module = 'weapons' },
    { tag = 'Corrigé', text = "Plus de menu sur F2 : il faisait doublon avec le F6 (menu entreprise) chez les joueurs venus quand il était sur F2.", module = 'quick' },
    { tag = 'Amélioré', text = "Chasse : aucun animal ne voit, n'entend ni n'attaque le chasseur, même les pumas et panthères ; la faune du monde non plus. On ne meurt plus en chassant.", module = 'activities' },
    { tag = 'Amélioré', text = "Guerre de territoire : les points de chaque gang sont tout en bas à droite, les munitions juste au-dessus (elles montent quand il y a plus de gangs dans la zone). Hors guerre, les munitions restent en bas à droite.", module = 'territories' },
    { tag = 'Amélioré', text = "Tablette de l'organisation › Territoires : la carte se déplace en glissant et zoome à la molette ou avec + / −.", module = 'territories' },
    { tag = 'Amélioré', text = "Plus aucun bandeau de couleur à gauche : onglets de la boutique F11, petites notifications d'action (tablette, banque, boutique, marché), encadrés d'information, notifications au style « minimal ».", module = 'hud' },
} })
N.Add({ id = 'patch146', date = '2026-10-29', title = "Patch notes 146 : carte, sac, Dynasty8, blanchiment, DJ, Fish & Chips", items = {
    { tag = 'Corrigé', text = "Carte : P, /carte et la carte rapide (Échap ou P depuis celle-ci) ouvrent la carte du serveur, plus celle de GTA. Échap ouvre le menu du serveur (sa « Carte » est la nôtre) ; réglables dans Menu Échap.", module = 'pause' },
    { tag = 'Corrigé', text = "Sac à dos impossible à retirer : un vêtement porté se retire maintenant toujours d'un clic sur sa case, et il est retiré tout seul si son objet quitte ton inventaire (coffre, don, jeté).", module = 'inv' },
    { tag = 'Amélioré', text = "Coffres de véhicule agrandis : poids doublé et 50 % d'emplacements en plus (les réglages existants aussi).", module = 'trunk' },
    { tag = 'Nouveau', text = "Points de ton entreprise / organisation (siège, tablette, coffre, garage, vestiaire, atelier…) : un repère rose sur la carte, visible de ses membres seulement. Les territoires prennent la couleur exacte du gang.", module = 'tags' },
    { tag = 'Corrigé', text = "Les points de vente de drogue ne s'affichent plus sur la carte (ni drapeaux, ni repère qui parle de drogue).", module = 'crime' },
    { tag = 'Amélioré', text = "Laboratoire de drogue : plus de mini-jeu, seulement l'animation de préparation et la barre de progression ; la quantité produite est toujours celle prévue.", module = 'crime' },
    { tag = 'Nouveau', text = "Dynasty8 : menu ALT › une personne › Remettre les clés. Logement à vendre : clé définitive au prix de l'annonce. Logement à louer : l'agent choisit la durée (1 à 30 jours). Le client accepte et paie depuis son compte ; l'agence touche sa commission.", module = 'housing' },
    { tag = 'Amélioré', text = "Blanchiment : vraie fenêtre (même style que la banque) à la place du menu, avec l'argent sale sur toi, les offres du contact à cliquer et l'avancement en cours.", module = 'launder' },
    { tag = 'Nouveau', text = "DJ : tables de mixage, platines et enceintes dans les props permanents (F10 › Props, catégorie DJ et musique). ALT sur la table › Mettre de la musique (lien YouTube) : tout le monde autour l'entend, plus fort en s'approchant. Les écrans (ALT › Diffuser une vidéo) passent la vidéo avec le son.", module = 'tv' },
    { tag = 'Nouveau', text = "Fish & Chips : nouveau type d'entreprise (Builder) avec sa carte (fish & chips, filet pané, frites, petits pois, burger de poisson, boissons). Préparation en cuisine et vente au comptoir ou au client, sans livraison.", module = 'biz' },
} })
N.Add({ id = 'patch147', date = '2026-10-29', title = "Patch notes 147 : menu Échap, carte de GTA, Mort RP, repos, concession, Fish & Chips, cigares", items = {
    { tag = 'Nouveau', text = "Menu Échap : des cases au centre de l'écran, le jeu reste visible derrière. Carte (celle de GTA), Paramètres (ceux de GTA), Personnage, Parcours, Réglages, Boutique, Mes lieux, Reprendre.", module = 'pause' },
    { tag = 'Amélioré', text = "Carte : retour à la carte de base de GTA (P, /carte, Échap › Carte), sans panneau.", module = 'pause' },
    { tag = 'Corrigé', text = "Écran de mort : « Maintiens G pour réapparaître » ne marchait pas (la touche était bloquée par un autre script), et les rectangles noirs autour des touches ont disparu.", module = 'death' },
    { tag = 'Nouveau', text = "Repos après une réapparition : 3 minutes sans sortir d'arme, sans tirer ni courir (temps affiché). Le staff peut en mettre ou en retirer (menu staff › un joueur). Nouvelles options globales du menu staff : réanimer tout le monde, lever tous les repos, démenotter tout le monde.", module = 'staff' },
    { tag = 'Nouveau', text = "Mort RP (menu staff › un joueur) : à sa prochaine balle reçue, le personnage meurt pour de bon. Écran MORT RP, objets qu'il a donnés à d'autres joueurs ces 24 h retirés, expulsion au bout de 10 s, toutes les données du personnage effacées (le compte, les bans et les sanctions restent).", module = 'staff' },
    { tag = 'Nouveau', text = "Prisons au Builder (catégorie Prison) : lieu, sortie et limite de la zone, pour la police et pour le staff. Les peines du menu staff vont dans la prison du staff.", module = 'justice' },
    { tag = 'Nouveau', text = "Concession tenue par des joueurs (magasin Concession rattaché à une entreprise) : le client regarde les véhicules et demande un essai (alerte aux vendeurs en service). Le vendeur, menu ALT sur le client : Faire essayer un véhicule, Vendre un véhicule (le client accepte et paie, l'entreprise encaisse).", module = 'shops' },
    { tag = 'Nouveau', text = "Fish & Chips : même système que le Burger Shot (bornes, cuisine, postes, mini-jeux) sans livraison, à son nom. Le Burger Shot devient un modèle : copie la ressource et change sa config pour créer un autre restaurant identique.", module = 'biz' },
    { tag = 'Nouveau', text = "Fabrique de cigares (Builder › Activités › Cigares) : champ de tabac, séchoir, assemblage des cigares, mise en boîte, revente au grossiste.", module = 'activities' },
    { tag = 'Amélioré', text = "Supérettes : seulement du pain, de l'eau et le téléphone. Quincaillerie sans kit de réparation. Magasins de meubles : un vendeur PNJ. Laboratoire de drogue : 8 s au lieu de 20.", module = 'shops' },
} })
N.Add({ id = 'patch148', date = '2026-10-29', title = "Patch notes 148 : blanchiment, actions annulées, chat, notifications", items = {
    { tag = 'Amélioré', text = "Blanchiment : l'argent propre reste chez le contact. Quand c'est fini, une notification te prévient et tu vas le récupérer (bouton Récupérer). Nouvelle progression : anneau qui se remplit peu à peu, avec une lumière qui file le long de la partie remplie jusqu'au bout, et temps restant en direct.", module = 'launder' },
    { tag = 'Corrigé', text = "Action annulée (labo, récolte…) : la barre de progression restait à l'écran. X annule maintenant l'action pour de bon et la barre disparaît toujours.", module = 'crime' },
    { tag = 'Amélioré', text = "Chat en haut à gauche, à la place du chat de base, plus épuré : messages sans bulle, panneau en verre discret quand on écrit.", module = 'chat' },
    { tag = 'Amélioré', text = "Notifications au-dessus de la mini-carte, sans la petite croix.", module = 'notify' },
    { tag = 'Corrigé', text = "Drapeau (point de vente) : le nombre de membres de chaque gang est tout en bas à droite ; les munitions montent au-dessus.", module = 'flags' },
} })
N.Add({ id = 'patch149', date = '2026-10-29', title = "Patch notes 149 : journal du staff sur MariaDB", items = {
    { tag = 'Corrigé', text = "Journal du staff : la table ne se créait pas sur MariaDB (« undo » est un mot réservé). Elle se crée au prochain démarrage, et les actions du staff s'y enregistrent de nouveau.", module = 'staff' },
} })
N.Add({ id = 'patch150', date = '2026-10-29', title = "Patch notes 150 : page du métier dans la tablette, concession d'entreprise, Builder de la prison", items = {
    { tag = 'Nouveau', text = "Tablette d'entreprise : une page propre au métier, comme le panneau d'une vraie entreprise. Ouvrir / fermer l'établissement, annonce à la ville, ventes du jour et de la semaine, dernières ventes, GPS vers ses points de vente.", module = 'biz' },
    { tag = 'Nouveau', text = "Concession : catalogue et prix des véhicules, promotion sur toute la vitrine, vitrine avec essais par les vendeurs ou achat direct, catalogue complet de GTA en option. Les vendeurs gèrent toujours les essais et les ventes en ville.", module = 'biz' },
    { tag = 'Nouveau', text = "Boîte de nuit, bar, DJ : lancer une soirée (la ville est prévenue), happy hour sur la carte du bar, ce qui passe sur les platines près du club (la direction peut couper), carte et stock du bar.", module = 'biz' },
    { tag = 'Nouveau', text = "Café et restauration : menu du jour annoncé à la ville, happy hour, prix de la carte, stock du comptoir et réapprovisionnement payé par la caisse.", module = 'biz' },
    { tag = 'Nouveau', text = "Builder : la concession existe en deux versions. Commerces › Concessionnaire (vente directe, sans vendeur) et Entreprises › Concession de l'entreprise (vitrine, essais, ventes par les vendeurs, argent dans la caisse).", module = 'carte' },
    { tag = 'Amélioré', text = "Builder : nouvelle section Prison, avec la prison de la police et celle du staff bien séparées (1 · lieu du détenu, 2 · sortie, 3 · limite de la zone). Avant, tout était mélangé dans « Autres ».", module = 'carte' },
} })
N.Add({ id = 'patch151', date = '2026-10-29', title = "Patch notes 151 : objets reçus et perdus à l'écran", items = {
    { tag = 'Nouveau', text = "Quand ton sac change, une petite carte apparaît en bas de l'écran avec l'image de l'objet, son nom et « +2 » ou « −1 » : objet ramassé, acheté, reçu, pris dans un coffre, munitions ou nourriture utilisées, objet donné ou retiré. Le même objet s'additionne sur une seule carte.", module = 'inventory' },
} })
N.Add({ id = 'patch152', date = '2026-10-29', title = "Patch notes 152 : supprimer un véhicule depuis la fiche joueur", items = {
    { tag = 'Nouveau', text = "Panel › Joueurs : la fiche d'un joueur (bouton « Fiche » dans la liste en ligne ou hors ligne) liste ses véhicules, avec « Supprimer définitivement » (droit « Gérer les véhicules », confirmation demandée).", module = 'players' },
    { tag = 'Amélioré', text = "Supprimer un véhicule l'enlève aussi de la ville s'il est sorti et vide son coffre (avant, le contenu du coffre restait en base).", module = 'garage' },
} })
N.Add({ id = 'patch153', date = '2026-10-29', title = "Patch notes 153 : coffres de véhicules agrandis", items = {
    { tag = 'Amélioré', text = "Coffres des véhicules : au moins 130 kg (40 emplacements) pour toutes les voitures, bateaux et appareils, au moins 200 kg (60 emplacements) pour les camions, utilitaires, fourgons, services, urgences, militaires et commerciaux. Les coffres déjà plus grands ne changent pas ; motos et vélos gardent leur petit coffre.", module = 'trunk' },
} })
N.Add({ id = 'patch154', date = '2026-10-29', title = "Patch notes 154 : objet offert par les zones au choix", items = {
    { tag = 'Amélioré', text = "Zones de gangs : l'objet offert se choisit parmi tous les objets de l'inventaire, objets personnalisés compris, avec la même recherche que « Donner un objet » du staff (nom simple ou technique, ou par catégorie). On règle aussi la quantité et toutes les combien d'heures.", module = 'territories' },
    { tag = 'Nouveau', text = "Builder › Existant › Territoires : chaque zone a « Objet offert » pour changer l'objet, la quantité et la fréquence sans la recréer. Dans le panel (Zones de gangs › Zones), l'objet se choisit dans une liste au lieu d'être tapé.", module = 'territories' },
} })
N.Add({ id = 'patch155', date = '2026-10-29', title = "Patch notes 155 : plus aucun militaire dans le monde", items = {
    { tag = 'Corrigé', text = "Armée : il restait des hélicoptères et des avions militaires (Cayo Perico notamment). Tout le matériel militaire du jeu est maintenant retiré : hélicoptères (Valkyrie, Hunter, Akula, Cargobob, Savage…), avions (Lazer, Titan, Besra, Hydra, Volatol…), blindés, remorques et bateaux de l'armée, soldats et mercenaires.", module = 'world' },
    { tag = 'Amélioré', text = "Ceux déjà garés dans le monde disparaissent aussi (contrôle toutes les 15 s). Un véhicule militaire sorti par le staff ou par un script n'est jamais touché.", module = 'world' },
} })
N.Add({ id = 'patch156', date = '2026-10-30', title = "Patch notes 156 : téléphone Garage refait, notifications et textes d'information", items = {
    { tag = 'Amélioré', text = "Téléphone › Garage : une carte par véhicule (nom, plaque, état Sorti / Rangé / Fourrière, où il se trouve), trois jauges lisibles (carburant, moteur, carrosserie) et un seul bouton Localiser / Y aller. Les jauges ne se superposent plus au texte.", module = 'interface' },
    { tag = 'Amélioré', text = "Notifications : nouvelle carte noire translucide avec le logo du serveur, son nom, la catégorie (Général, Attention, Erreur…) et le message ; les montants, quantités et x/y sont en orange.", module = 'interface' },
    { tag = 'Amélioré', text = "Texte d'information en haut à gauche (territoire, repos après réapparition) : même style que les textes d'action des serveurs pro, blanc avec les valeurs en orange, à la place du texte centré en bas de l'écran.", module = 'territories' },
} })
N.Add({ id = 'patch157', date = '2026-10-30', title = "Patch notes 157 : nouveau design du panel", items = {
    { tag = 'Nouveau', text = "Panel refait : plus de barre latérale. L'accueil est une grille de catégories (Serveur, Joueurs, Économie, Véhicules, Illégal & gangs…) avec le nombre d'outils ; une catégorie ouvre la liste de ses outils en cartes, un outil ouvre sa page. Le tableau de bord et les favoris ont chacun leur tuile.", module = 'interface' },
    { tag = 'Nouveau', text = "Recherche en haut à droite (touche /), qui filtre tout de suite les catégories ou les outils de la catégorie ouverte ; Échap revient en arrière avant de fermer ; barre d'aide en bas.", module = 'interface' },
    { tag = 'Amélioré', text = "Plus fluide : entrées animées en cascade, survol qui s'allume à la couleur de la marque, aucun flou coûteux. Les pages d'outils gardent le même contenu avec des champs et des boutons plus nets.", module = 'interface' },
} })
N.Add({ id = 'patch158', date = '2026-10-30', title = "Patch notes 158 : déplacer les interfaces directement en jeu", items = {
    { tag = 'Nouveau', text = "Placement en jeu : Panel › Placement à l'écran › « Modifier directement en jeu » (ou la commande /placement). Le panel se ferme et chaque interface (HUD, compteur, chat, notifications, menus, munitions, invite, barre de progression, mini-carte) apparaît dans un cadre pointillé sur ta vraie vue : glisse-la où tu veux, puis Valider. Échap annule.", module = 'placement' },
    { tag = 'Nouveau', text = "Les notifications peuvent rester où on les lâche (emplacement libre), en plus des 7 coins ; la mini-carte du jeu se déplace aussi (à vérifier sur ta résolution).", module = 'placement' },
    { tag = 'Amélioré', text = "Le glisser respecte maintenant les limites acceptées par le serveur (plus d'erreur « Valeur hors limites » en posant le chat tout à droite).", module = 'placement' },
} })
N.Add({ id = 'patch159', date = '2026-10-30', title = "Patch notes 159 : écran de chargement à la connexion, barre du noclip, sons des menus", items = {
    { tag = 'Corrigé', text = "Connexion : après le loading screen, on ne voit plus son personnage tomber dans le vide. Un écran de chargement (logo du serveur, sur fond noir) reste affiché jusqu'à l'écran « Appuyez sur E », le créateur ou l'arrivée à la dernière position, et le personnage reste figé derrière.", module = 'character' },
    { tag = 'Corrigé', text = "Noclip : la barre des touches ne déborde plus et ne passe plus à la ligne (une pastille par touche, la vitesse ne fait plus bouger la barre). Les touches affichées sont les bonnes : ZQSD se déplacer, E monter, A (Q en QWERTY) descendre, Shift boost, Ctrl ralenti, molette vitesse.", module = 'staff' },
    { tag = 'Nouveau', text = "F5 › Mes paramètres › Sons des menus : trois choix, clic du serveur, sons de base des menus de GTA ou aucun son. Réglage mémorisé sur ton poste.", module = 'personal' },
} })
N.Add({ id = 'patch160', date = '2026-10-30', title = "Patch notes 160 : blanchiment corrigé, petites notifications", items = {
    { tag = 'Corrigé', text = "Blanchiment : le bouton « Récupérer » ne faisait rien, l'argent restait bloqué chez le contact. Il est maintenant versé. Si le contact d'origine a été supprimé ou reposé, n'importe quel autre contact rend l'argent.", module = 'launder' },
    { tag = 'Amélioré', text = "Notifications beaucoup plus petites : logo et nom du serveur sur une seule ligne, catégorie discrète à droite, message en dessous.", module = 'notify' },
} })
N.Add({ id = 'patch161', date = '2026-10-30', title = "Patch notes 161 : bouton E, avantages VIP, drogues", items = {
    { tag = 'Amélioré', text = "Bouton E pour interagir refait : pastille translucide, touche ronde à la couleur du serveur.", module = 'hud' },
    { tag = 'Nouveau', text = "VIP : blanchiment avec 5 points de commission en moins et 25 % plus rapide, repos après réapparition réduit de moitié, fourrière gratuite, carburant 20 % moins cher, 5 places de véhicules en plus. Tout se règle dans le panel (VIP › Réglages) et se voit dans F5.", module = 'vip' },
    { tag = 'Amélioré', text = "Drogues plus légères : 1 kg le produit brut (au lieu de 1,5), 0,7 kg le pochon (au lieu de 1). Le produit brut non transformé se vend deux fois moins cher (x0,2 au lieu de x0,4) ; le prix des pochons ne change pas.", module = 'crime' },
    { tag = 'Amélioré', text = "Notifications un peu plus grandes, toujours compactes.", module = 'notify' },
} })
N.Add({ id = 'patch162', date = '2026-10-30', title = "Patch notes 162 : organisations, tout au QG", items = {
    { tag = 'Amélioré', text = "Organisations illégales : plus de point bureau. Tout se gère au QG (membres, grades, caisse, crypto, territoires, labos, contrats). Les bureaux déjà posés sont retirés ; une organisation sans QG voit son bureau devenir son QG. Les entreprises gardent leur bureau du patron.", module = 'orga' },
} })
N.Add({ id = 'patch163', date = '2026-10-30', title = "Patch notes 163 : encore plus d'avantages VIP", items = {
    { tag = 'Nouveau', text = "VIP : boombox portable (/boombox) : posée par terre, un lien YouTube, tout le monde autour entend la musique ; on change de musique ou on la ramasse quand on veut. Elle remplace l'avantage sur le blanchiment, qui redevient le même pour tout le monde.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : peinture caméléon (/cameleon, au volant de ton véhicule) : 8 teintes dont un arc-en-ciel, la couleur change selon l'angle de vue. Gratuite et enregistrée sur le véhicule.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : +50 kg et +15 emplacements dans les coffres de ses véhicules, -10 % en magasin (supérettes, vêtements, coiffeurs, tatoueurs), 10 tenues enregistrées en plus, plaque personnalisée gratuite, priorité dans la file d'attente.", module = 'vip' },
} })
N.Add({ id = 'patch164', date = '2026-10-30', title = "Patch notes 164 : onglet Téléportation dans le menu staff", items = {
    { tag = 'Nouveau', text = "Menu staff › Téléportation : TP rapides (ajoute ta position, visible par tout le staff), Lieux du Builder (magasins, garages, banques, entreprises…) et Mappings.", module = 'staff' },
    { tag = 'Nouveau', text = "Mappings : le serveur lit tout seul les fichiers de carte des ressources démarrées et trouve où ils se trouvent, à chaque démarrage ou avec « Rechercher à nouveau ». Un mapping ajouté apparaît sans rien régler ; on peut le renommer ou le masquer.", module = 'staff' },
} })
N.Add({ id = 'patch165', date = '2026-10-30', title = "Patch notes 165 : vraies peintures caméléon", items = {
    { tag = 'Nouveau', text = "VIP : /cameleon propose maintenant les vraies peintures du jeu : 20 peintures spéciales et 62 peintures Rockstar, en plus de l'effet qui suit le regard. Peintures par WildBrick142 et Disquse (Chameleon Paint), shaders de Rockstar Games.", module = 'vip' },
} })
N.Add({ id = 'patch166', date = '2026-10-30', title = "Patch notes 166 : grosse correction", items = {
    { tag = 'Corrigé', text = "Mort RP : il restait du personnage effacé : 2e métier, clés de véhicules, factures, casier, comptes en banque, appels, tickets de loterie, gang, photo. Tout est retiré ; le compte, lui, reste (bans, VIP, notes du staff).", module = 'mortrp' },
    { tag = 'Corrigé', text = "Comptoirs d'entreprise : une bijouterie, un tatoueur, une armurerie ou un magasin de meubles proposaient du pain et de l'eau par défaut. Leur catalogue démarre vide, à remplir. La fabrique de cigares vend des cigares (plus des pizzas), le Galaxy a la carte du bar.", module = 'carte' },
    { tag = 'Corrigé', text = "Plus aucun véhicule militaire à louer (Squaddie et Winky remplacés à Cayo Perico par le Verus et le Manchez Scout) ni en concession, même avec le catalogue élargi.", module = 'rental' },
    { tag = 'Corrigé', text = "Duplication d'objets : en cas de double clic ou d'action simultanée, un objet pouvait être donné, jeté, vendu, servi au bar ou consommé sans être retiré du sac. Le retrait est maintenant vérifié d'abord partout ; un client de bar est remboursé si l'article n'est plus là.", module = 'inventory' },
    { tag = 'Amélioré', text = "Textes du panel et des organisations remis à jour : plus de « point boss » ni de « bureau du chef » pour les organisations illégales.", module = 'orga' },
} })
N.Add({ id = 'patch167', date = '2026-10-30', title = "Patch notes 167 : caméléon dans le F5", items = {
    { tag = 'Amélioré', text = "VIP : la peinture caméléon se gère maintenant depuis le menu F5, avec sa propre entrée juste après la carte VIP. La commande /cameleon disparaît.", module = 'vip' },
} })
N.Add({ id = 'patch168', date = '2026-10-30', title = "Patch notes 168 : boutique plus simple, coins au menu staff", items = {
    { tag = 'Amélioré', text = "Panel › Boutique : ajouter un article se fait en trois étapes. La catégorie, puis le choix dans la liste complète avec les photos (tous les véhicules, toutes les armes, tous les objets de l'inventaire, logements, durées de VIP, montants, boosts), puis le prix. Le nom et la photo se remplissent tout seuls ; le formulaire ne montre que les champs utiles.", module = 'premium' },
    { tag = 'Nouveau', text = "Menu staff › un joueur › Coins de la boutique : donner ou retirer des coins, avec un motif. Droit « Boutique : créditer ou retirer des coins », tracé dans les mouvements.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : l'historique des mouvements de coins pouvait rester vide pour les opérations sans référence (crédits du staff, achats). Tout est maintenant tracé.", module = 'premium' },
} })
N.Add({ id = 'patch169', date = '2026-10-30', title = "Patch notes 169 : réapparition à l'hôpital", items = {
    { tag = 'Corrigé', text = "Écran de mort : la touche G est maintenant lue directement au clavier, même si « Détoner » a été réassignée dans les réglages de GTA ou désactivée par un autre script. Il faut toujours la maintenir 1,5 seconde, une fois le délai écoulé. En secours, la commande /reapparaitre fait la même chose.", module = 'death' },
    { tag = 'Corrigé', text = "Réapparition : une panne de facture, de journal ou de sac ne bloque plus le joueur à terre, et un point d'hôpital mal réglé renvoie à l'hôpital par défaut. Si le serveur ne savait pas le joueur à terre, l'écran se recale au lieu d'ignorer la touche.", module = 'death' },
    { tag = 'Corrigé', text = "Réapparition : le personnage attend que le sol de l'hôpital soit chargé avant de retomber, il ne passe plus à travers la carte.", module = 'death' },
    { tag = 'Corrigé', text = "Anticheat : un joueur à terre n'est plus signalé pour invincibilité. Réglé sur « Expulser », cette détection pouvait le sortir du serveur pendant l'écran de mort.", module = 'anticheat' },
} })
N.Add({ id = 'patch170', date = '2026-10-30', title = "Patch notes 170 : boombox en main et CarPlay", items = {
    { tag = 'Nouveau', text = "CarPlay : dans un véhicule, touche O. Un petit écran propose des radios en un clic, un vrai champ pour coller un lien YouTube ou Vimeo et tes derniers liens. Tous les occupants peuvent changer ou couper la musique, et les autres sont prévenus.", module = 'music' },
    { tag = 'Amélioré', text = "Boombox VIP : c'est maintenant un objet du sac. Utilisée, elle passe en main et ouvre le même écran ; utilisée à nouveau, elle se range. Le son la suit quand tu te déplaces. La commande /boombox et la pose au sol disparaissent.", module = 'vip' },
    { tag = 'Nouveau', text = "Panel › Musique : liste des musiques en cours, radios et distances réglables.", module = 'music' },
} })
N.Add({ id = 'patch171', date = '2026-10-30', title = "Patch notes 171 : notifications et véhicules du staff", items = {
    { tag = 'Amélioré', text = "Notifications : le petit type (Informations, Succès, Attention, Erreur) revient sous le nom du serveur, avec son icône et sa couleur.", module = 'notify' },
    { tag = 'Nouveau', text = "Menu staff (F10) › Gestion des véhicules › Supprimer définitivement : le véhicule où tu es ou le plus proche, par plaque, ou par joueur connecté. Aussi sur la fiche d'un joueur : Véhicules du joueur. Une confirmation est demandée.", module = 'garage' },
} })
N.Add({ id = 'patch172', date = '2026-10-30', title = "Patch notes 172 : écran de la boombox", items = {
    { tag = 'Corrigé', text = "Boombox et CarPlay : l'écran ne réagissait pas à la souris, les clics passaient à travers. Équiper la boombox ferme aussi l'inventaire, qui restait derrière.", module = 'music' },
} })
N.Add({ id = 'patch173', date = '2026-10-30', title = "Patch notes 173 : notifications refaites", items = {
    { tag = 'Amélioré', text = "Notifications refaites d'après le modèle : carte sombre, logo sur une tuile, type en gras avec le nom du serveur dessous, croix pour fermer, barre de temps à la couleur du serveur et message en dessous.", module = 'notify' },
} })
N.Add({ id = 'patch174', date = '2026-10-30', title = "Patch notes 174 : Discord obligatoire", items = {
    { tag = 'Nouveau', text = "Connexion : Discord est maintenant obligatoire pour rejoindre le serveur, même en maintenance. Un joueur sans l'application Discord ouverte est refusé avec les étapes à suivre. L'équipe et le propriétaire passent toujours. Réglage et message : Panel › Discord ↔ personnage.", module = 'discordlink' },
} })
N.Add({ id = 'patch175', date = '2026-10-30', title = "Patch notes 175 : membre du Discord obligatoire", items = {
    { tag = 'Nouveau', text = "Connexion : il faut aussi être membre du serveur Discord pour rejoindre. Le joueur refusé voit le lien pour le rejoindre et peut se reconnecter aussitôt. Il faut le jeton du bot et l'identifiant du serveur (module Discord). Si Discord ne répond pas, le joueur entre, pour qu'une panne ne ferme pas le serveur. L'équipe et le propriétaire passent toujours.", module = 'discordlink' },
} })
N.Add({ id = 'patch176', date = '2026-10-30', title = "Patch notes 176 : notifications et boombox", items = {
    { tag = 'Amélioré', text = "Notifications : plus de croix, fond un peu plus transparent.", module = 'notify' },
    { tag = 'Corrigé', text = "Boombox : elle se tient maintenant par la poignée, droite, côté haut-parleurs vers l'extérieur.", module = 'vip' },
    { tag = 'Nouveau', text = "Staff : /boombox_regler ajuste en direct la position de la boombox dans la main, avec les flèches, pour tout le monde.", module = 'music' },
} })
N.Add({ id = 'patch177', date = '2026-10-30', title = "Patch notes 177 : job casino", items = {
    { tag = 'Nouveau', text = "Job casino : l'entreprise Casino a sa page Salle de jeux dans la tablette, avec bénéfices, jeux, plus gros gains et interdits. La direction relie le casino à sa caisse, ouvre ou ferme la salle et règle les mises.", module = 'casino' },
    { tag = 'Nouveau', text = "Menu F6 du casino : vendre des jetons à un client, voir les joueurs en salle ; pour la direction, offrir des jetons et interdire de casino. Un joueur interdit, ou une salle fermée, peut toujours revendre ses jetons à la caisse.", module = 'casino' },
    { tag = 'Nouveau', text = "Mapping molo_casino ajouté au serveur (nécessite la licence du pack sur le compte Cfx du serveur).", module = 'casino' },
} })
N.Add({ id = 'patch178', date = '2026-10-30', title = "Patch notes 178 : tables de casino Molo", items = {
    { tag = 'Nouveau', text = "Casino : les scripts Molo sont installés (poker à trois cartes, blackjack, roulette, machines à sous, roue, paris, hôtel). Leurs jetons passent par la caisse du serveur, qui débite le vrai argent du joueur et la caisse de l'entreprise.", module = 'casino' },
    { tag = 'Amélioré', text = "Job casino : avec Molo, la tablette suit les jetons vendus et rachetés. Fermer la salle ou interdire un joueur arrête la vente de jetons, pas les tables.", module = 'casino' },
} })
N.Add({ id = 'patch179', date = '2026-10-30', title = "Patch notes 179 : réglage de la boombox", items = {
    { tag = 'Corrigé', text = "/boombox_regler : les trois rotations fonctionnent vraiment. En mode rotation, les flèches tournent et penchent la boombox, A et E l'inclinent (Page haut et bas aussi).", module = 'music' },
} })
N.Add({ id = 'patch180', date = '2026-10-30', title = "Patch notes 180 : plaques, boutique et repères du casino", items = {
    { tag = 'Corrigé', text = "Boutique : la plaque personnalisée fonctionne. L'écran n'envoyait pas le véhicule et le texte sous les noms attendus, l'achat était toujours refusé.", module = 'premium' },
    { tag = 'Nouveau', text = "VIP : Changer de plaque dans le menu F5, gratuitement, pour un véhicule rangé au garage.", module = 'vip' },
    { tag = 'Amélioré', text = "Boutique : les caisses mystère sont supprimées, tirage compris. Celles déjà en vente disparaissent à la mise à jour.", module = 'premium' },
    { tag = 'Nouveau', text = "Staff : F10 › Téléportation › Casino regroupe la caisse, la salle, la roue, le podium, le bar, l'hôtel et les ascenseurs.", module = 'casino' },
} })
N.Add({ id = 'patch181', date = '2026-10-30', title = "Patch notes 181 : téléportation et mappings", items = {
    { tag = 'Corrigé', text = "Noclip : la téléportation fonctionne aussi en plein vol. C'est maintenant le noclip qui applique le saut, sans attendre le sol.", module = 'staff' },
    { tag = 'Corrigé', text = "Téléportation sans hauteur connue (mappings, point GPS) : le sol est cherché par paliers au-dessus du lieu, le personnage n'arrive plus sous la carte ou en l'air.", module = 'staff' },
    { tag = 'Corrigé', text = "Menu staff › Téléportation › Mappings : les fichiers sont lus correctement, et une liste de secours prend le relais si le serveur ne peut pas lire ses dossiers. Le résultat signale les fichiers de packs protégés, illisibles.", module = 'staff' },
} })
N.Add({ id = 'patch182', date = '2026-10-30', title = "Patch notes 182 : Builder, poser un autre", items = {
    { tag = 'Nouveau', text = "Builder : recliquer sur un type de point déjà posé propose « Poser un autre » ou de choisir celui à supprimer, avec le nombre déjà posé.", module = 'builder' },
    { tag = 'Nouveau', text = "Builder, points d'une entreprise, d'un groupe ou d'une drogue : « Poser un autre ici » s'ajoute à Déplacer et Supprimer (coffre, prise de service, bureau, vestiaire, récolte…). Un nouveau coffre est vide. Les garages d'entreprise restent uniques.", module = 'builder' },
} })
N.Add({ id = 'patch183', date = '2026-10-30', title = "Patch notes 183 : mises à jour légères", items = {
    { tag = 'Amélioré', text = "Mises à jour : plus besoin de tout retélécharger. Chaque version publie un petit zip avec seulement les fichiers qui ont changé, et Panel › Mises à jour donne celui de ta version. Ta licence et pb_panel/config.lua ne bougent pas.", module = 'updates' },
} })
N.Add({ id = 'patch184', date = '2026-10-30', title = "Patch notes 184 : coffres à 650 kg", items = {
    { tag = 'Amélioré', text = "Les coffres de toutes les entreprises et de toutes les organisations passent à 650 kg, y compris ceux déjà posés.", module = 'inventory' },
} })
N.Add({ id = 'patch185', date = '2026-10-30', title = "Patch notes 185 : armes VVS", items = {
    { tag = 'Nouveau', text = "Armes : les 50 armes du VVS Female Gun Pack sont au catalogue, avec leurs munitions et le permis obligatoire. Le staff peut les donner avec /giveweapon. La ressource du pack doit être installée sur le serveur.", module = 'weapons' },
} })
N.Add({ id = 'patch186', date = '2026-10-30', title = "Patch notes 186 : images des armes VVS", items = {
    { tag = 'Amélioré', text = "Inventaire : les 50 armes du pack VVS ont maintenant leur vraie image. Elles ne sont ajoutées que sur un serveur qui possède ce pack.", module = 'weapons' },
} })
N.Add({ id = 'patch187', date = '2026-10-30', title = "Patch notes 187 : armes de pack", items = {
    { tag = 'Amélioré', text = "Armes : équiper une arme dont le pack n'est pas démarré sur le serveur affiche maintenant un message clair, au lieu de ne rien faire.", module = 'weapons' },
} })
N.Add({ id = 'patch188', date = '2026-10-30', title = "Patch notes 188 : armes et véhicules addon en boutique", items = {
    { tag = 'Nouveau', text = "Panel › Boutique : l'étape de choix propose maintenant les armes addon (groupe Armes addon, avec leur image) et les véhicules addon installés sur le serveur (groupe Véhicules addon).", module = 'premium' },
} })
N.Add({ id = 'patch189', date = '2026-10-30', title = "Patch notes 189 : grandes portes et carte", items = {
    { tag = 'Corrigé', text = "Portes : les portails, portes coulissantes et grosses portes de garage sont maintenant détectés au menu ALT et à la visée. La touche E et les vérifications du serveur tiennent compte de leur largeur.", module = 'doors' },
    { tag = 'Corrigé', text = "Carte : les numéros d'icône sont toujours transmis au jeu en entier, ce qui évite un rond à la place de l'icône.", module = 'blips' },
    { tag = 'Nouveau', text = "/blips indique combien de repères s'affichent en rond et quel script les a créés (détail en F8).", module = 'blips' },
} })
N.Add({ id = 'patch190', date = '2026-10-30', title = "Patch notes 190 : props aux flèches, zones hors de la mini-carte", items = {
    { tag = 'Amélioré', text = "Props du staff : les flèches déplacent le prop (← → gauche / droite, ↑ ↓ monter / descendre, Maj + ↑ ↓ avancer / reculer). Molette ou Q / X pour tourner, G pour qu'il suive de nouveau la visée, E pour poser.", module = 'props' },
    { tag = 'Modifié', text = "Territoires : les zones et leurs repères ne s'affichent plus sur la mini-carte, seulement sur la grande carte.", module = 'territories' },
} })
N.Add({ id = 'patch191', date = '2026-10-30', title = "Patch notes 191 : portes à la montée en véhicule", items = {
    { tag = 'Corrigé', text = "Montée en véhicule : si la porte reste fermée alors que le joueur arrive à sa hauteur, elle s'ouvre, puis se referme une fois assis.", module = 'general' },
} })
N.Add({ id = 'patch192', date = '2026-10-30', title = "Patch notes 192 : pack d'armes VVS", items = {
    { tag = 'Corrigé', text = "Pack VVS : les armes n'étaient ajoutées au catalogue que si leurs images étaient présentes, et ces images ne sont jamais publiées. Le pack est maintenant aussi reconnu à sa ressource démarrée, même si elle démarre après Shadow Base.", module = 'weapons' },
    { tag = 'Amélioré', text = "Menu staff › Donner une arme : les armes du pack sont rangées dans leur catégorie « Pack VVS ».", module = 'weapons' },
} })
N.Add({ id = 'patch193', date = '2026-10-31', title = "Patch notes 193 : minage et bûcheron libres, Builder rangé, logo du serveur", items = {
    { tag = 'Nouveau', text = "Minage et bûcheron passent en farm libre, sans métier ni entreprise, sur le modèle de la chasse : le guide prête l'outil gratuitement, des filons ou des arbres de rareté différente apparaissent dans les zones posées au Builder, et le marché rachète à prix variables (bonus VIP). Deux nouvelles extensions : wb_minage et wb_bucheron (à démarrer après pb_panel).", module = 'extensions' },
    { tag = 'Amélioré', text = "Builder : « Activités et extensions » est rangé par thème (Récolte et farm libre, Métiers et chaînes de production, Animaux, Portes et accès, Restaurants), et la liste des points des Activités est séparée par catégorie (Mine, Agriculture, Cigares…) au lieu d'une longue liste à plat.", module = 'carte' },
    { tag = 'Amélioré', text = "Activités : on ne pose plus de nouveau filon ni de nouvelle coupe de bois (remplacés par les extensions libres) ; les points déjà posés, les fonderies et la scierie continuent de fonctionner.", module = 'wb_activites' },
    { tag = 'Corrigé', text = "Le logo principal du panel (Général › Logo (fichier)) devient aussi le logo en jeu (écran d'entrée, menus, notifications, bienvenue) quand aucun « Logo du serveur en jeu » n'est réglé ; avant, il fallait le renvoyer à part.", module = 'general' },
    { tag = 'Amélioré', text = "Menu animations : les arcs en pointillés (haut et droite) sont supprimés.", module = 'animmenu' },
} })
N.Add({ id = 'patch194', date = '2026-10-31', title = "Patch notes 194 : auto-école, pioche et hache en main", items = {
    { tag = 'Nouveau', text = "Nouvelle extension wb_autoecole avec sa propre interface : accueil (carte de permis et examens), code une question à la fois avec corrections à la fin, examen de conduite avec affichage en jeu (vitesse et limite, fautes, point en cours, consigne du moniteur) et rapport de fautes final. Un moniteur est assis à côté pendant la conduite.", module = 'wb_autoecole' },
    { tag = 'Nouveau', text = "Parcours posé au Builder (Activités et extensions › Services et permis) : départ du véhicule, points avec consigne du moniteur et arrêts obligatoires. Vitesse, arrêts, chocs, sortie du véhicule et progression sont contrôlés côté serveur ; téléportation et triche sont refusées.", module = 'wb_autoecole' },
    { tag = 'Nouveau', text = "Permis voiture, moto et poids lourd enregistrés par joueur, prix, note de passage, limite, fautes maximum et attente après un échec réglables. Option « Permis obligatoire pour conduire » (désactivée par défaut). Commandes : /permis (carte de permis), /permis_donner, /permis_retirer. Les autres ressources lisent un permis avec exports.wb_autoecole:HasLicence.", module = 'wb_autoecole' },
    { tag = 'Amélioré', text = "Minage et bûcheron : l'outil prêté par le guide (Pioche / Hache) est maintenant tenu en main et balancé sur le filon ou l'arbre pendant la récolte, avec une vraie animation de frappe à la place du scénario générique.", module = 'wb_minage' },
} })
N.Add({ id = 'patch195', date = '2026-10-31', title = "Patch notes 195 : faim et soif, retour à l'auto-école", items = {
    { tag = 'Modifié', text = "La faim et la soif descendent deux fois moins vite : 0,5 et 0,7 point par minute. Un réglage déjà changé dans le panel reste tel quel.", module = 'hud' },
    { tag = 'Amélioré', text = "Auto-école : après un échec à l'examen de conduite, le candidat revient directement devant le moniteur, sauf s'il est à terre.", module = 'general' },
} })
N.Add({ id = 'patch196', date = '2026-10-31', title = "Patch notes 196 : tous les props du jeu, télés", items = {
    { tag = 'Nouveau', text = "F10 › Props permanents › Poser un prop › Tous les props du jeu : toute la liste du jeu, rangée par thème, avec une recherche et l'aperçu au survol.", module = 'props' },
    { tag = 'Nouveau', text = "Nouvelle catégorie « Télés et écrans » : pose l'écran, puis ALT dessus pour diffuser une vidéo YouTube ou Vimeo.", module = 'props' },
    { tag = 'Amélioré', text = "Diffusion possible sur 7 modèles de plus (vieilles télés, moniteurs, ordinateur portable), aussi dans le décor et les logements.", module = 'tv' },
} })
N.Add({ id = 'patch197', date = '2026-10-31', title = "Patch notes 197 : menus plus transparents, fiche du joueur", items = {
    { tag = 'Amélioré', text = "Menus : fond plus transparent, et plus de liseré blanc au-dessus de la description.", module = 'menus' },
    { tag = 'Amélioré', text = "Menu staff › fiche d'un joueur refaite : logo du serveur, chemin, nom et badge d'identifiant en haut, actions rangées par section, métier et argent affichés, Freeze en interrupteur, actions sensibles en rouge.", module = 'staff' },
    { tag = 'Nouveau', text = "Bannir ouvre une fenêtre à côté du menu : raison, durée, Confirmer en rouge ou Annuler.", module = 'staff' },
} })
N.Add({ id = 'patch198', date = '2026-10-31', title = "Patch notes 198 : véhicules prêtés, vendre tout, arrivée en ville, logo", items = {
    { tag = 'Nouveau', text = "Minage : le chef de mine prête un camion, et la chasse un 4x4 chez le guide. Ce que tu récoltes à moins de 40 m de lui va dans son chargement, racheté au marché s'il est garé à côté. Point « Sortie du véhicule » au Builder.", module = 'activities' },
    { tag = 'Nouveau', text = "Marchés (minage, bûcheron, chasse, pêche, grossiste des activités) : « Tout vendre » en haut de la liste, avec le prix total.", module = 'activities' },
    { tag = 'Nouveau', text = "Entrer en ville : nouvel écran d'arrivée (la ville la nuit à la couleur du serveur, barre d'avancement réelle, levée de rideau). Il couvre tout dès le clic et ne s'ouvre qu'une fois les mappings, intérieurs et collisions chargés.", module = 'general' },
    { tag = 'Amélioré', text = "Tous les menus : ligne choisie à la couleur du serveur, en-tête comme la fiche joueur, saisies dans la même fenêtre à côté du menu (le copier-coller y fonctionne), actions sensibles en rouge.", module = 'menus' },
    { tag = 'Corrigé', text = "Builder : les PNJ du minage, du bûcheron et de la chasse gardent le sens du staff (ils regardaient toujours vers le nord). Le personnage devient semi-transparent pendant la pose.", module = 'builder' },
    { tag = 'Corrigé', text = "Logo du serveur : image réduite avant l'envoi, plus de copie complète dans l'historique des réglages (ancien + nouveau logo dépassaient la taille d'une requête MySQL), rechargement des panels groupé.", module = 'general' },
} })
N.Add({ id = 'patch199', date = '2026-10-31', title = "Patch notes 199 : crochet, tablette d'armes, boombox, mini-écrans", items = {
    { tag = 'Nouveau', text = "Vol de voiture : le crochet (menu ALT ou depuis le sac) lance un mini-jeu : relier les fils de la même couleur avant la fin du temps. Réussi, le véhicule s'ouvre et démarre sans clé.", module = 'crime' },
    { tag = 'Nouveau', text = "Atelier d'armes : une tablette remplace le menu. Recettes, matériaux manquants, et onglet « Où trouver » avec les lieux de ferraille et de poudre et le GPS (lieux à poser au Builder).", module = 'activities' },
    { tag = 'Nouveau', text = "Boombox : « Poser au sol » avec la même pose que les props, le son part alors de là ; E près d'elle pour la régler ou la reprendre. Réglage dans la main par boutons (/boombox_regler).", module = 'music' },
    { tag = 'Nouveau', text = "Observer un joueur : un mini-écran par joueur, plusieurs en même temps, à déplacer et redimensionner avec /ecrans (nécessite screenshot-basic, une image toutes les 2 s environ). L'observation en plein écran reste disponible.", module = 'staff' },
    { tag = 'Corrigé', text = "Builder : les points posés par les activités (minage, chasse, auto-école, atelier…) restaient marqués « Aucune position » : ils affichent maintenant combien sont posés.", module = 'builder' },
    { tag = 'Modifié', text = "Écran d'arrivée en ville refait : sobre, logo, étape, pourcentage et une ligne qui avance.", module = 'general' },
} })
N.Add({ id = 'patch200', date = '2026-10-31', title = "Patch notes 200 : garages, clés, statut Discord, créateur", items = {
    { tag = 'Corrigé', text = "Garages et clés : le jeu centre les plaques courtes en ajoutant des espaces devant, que le serveur ne retirait pas : véhicule impossible à ranger, « pas la clé » sur son propre véhicule. Une clé obtenue après coup est aussi reconnue sans remonter dans le véhicule.", module = 'garage' },
    { tag = 'Corrigé', text = "Ammu-Nation : le bouton Tester tient dans la carte. Le pistolet VIP est grisé et « Réservé VIP » pour les autres.", module = 'shops' },
    { tag = 'Nouveau', text = "Statut Discord configurable dans le panel : application, texte avec variables, images et boutons.", module = 'richp' },
    { tag = 'Corrigé', text = "Gamertags : plusieurs joueurs dans un véhicule ne se superposent plus, les étiquettes s'empilent.", module = 'tags' },
    { tag = 'Corrigé', text = "Mort RP : l'écran d'inconscience ne s'ouvre plus en dessous.", module = 'staff' },
    { tag = 'Amélioré', text = "Créateur : toutes les nationalités avec recherche, listes déroulantes au style du serveur, pastilles aux vraies couleurs du jeu.", module = 'character' },
} })
N.Add({ id = 'patch201', date = '2026-10-31', title = "Patch notes 201 : atelier d'armes, portes, service staff", items = {
    { tag = 'Modifié', text = "Atelier d'armes : les munitions ne se fabriquent plus (plus de douilles ni de poudre, plus de lieu de poudre au Builder). Elles s'achètent à l'Ammu-Nation. Une arme de finition excellente rapporte plus d'expérience au lieu d'une boîte de munitions.", module = 'wb_armes' },
    { tag = 'Amélioré', text = "Atelier d'armes : nouvelle tablette translucide sans cadre, avec des icônes blanches unies, plus lisible : menu à gauche (Armes, Pièces, Démontage, Où trouver, Plans), cartes avec l'image de chaque objet, détail à droite avec ce qui manque (✓ / ✕), quantité réglable et un bouton Fabriquer qui explique pourquoi il est grisé. Un encart « Comment ça marche » guide les débutants.", module = 'wb_armes' },
    { tag = 'Nouveau', text = "Zones safe (nouvelle extension wb_zonesafe) : F10 › Builder › Zones safe, pose une zone petite (25 m), moyenne (50 m), grande (100 m) ou au rayon libre. Dedans : pas de tirs, pas de coups, invincible. Chaque règle se coupe dans le panel, et les zones apparaissent sur la carte.", module = 'wb_zonesafe' },
    { tag = 'Modifié', text = "Les roulades de combat sont supprimées (Espace pendant qu'on vise ou qu'on est armé ne fait plus rien). Réglage : setr pb_noroll 0 pour les rétablir.", module = 'combat' },
    { tag = 'Amélioré', text = "Inventaire entièrement refait : sac en grille de 7 colonnes avec recherche et filtres (tout, consommables, vêtements, armes, outils), raccourcis en dessous, personnage au centre avec ses 12 emplacements et son état (faim, soif, vie, armure, endurance, stress), et à droite directement les joueurs à proximité (plus d'onglet Aperçu), le sol ou le coffre ouvert. Détail et actions de l'objet en bas à droite, transfert rapide avec Maj + clic, Ctrl + F pour chercher. Plus de barres de durabilité sous les armes.", module = 'inventaire' },
    { tag = 'Nouveau', text = "Station-service : une vraie interface au lieu du petit menu. Jauge en arc du réservoir (ce qu'il y a déjà, ce qui va être ajouté), montant qui défile, curseur de litres avec 10 L, 25 L et Plein, argent disponible, et paiement. Le plein s'affiche ensuite avec la jauge qui se remplit.", module = 'carburant' },
    { tag = 'Amélioré', text = "Créateur de personnage : même style que l'inventaire (panneaux plats, titres plus grands, touches blanches, bouton principal plein avec sa touche).", module = 'créateur' },
    { tag = 'Nouveau', text = "Nouvelle jauge en arc pour toutes les actions qui prennent du temps (soins, réparations, récoltes, graffiti…) : l'arc se remplit, le chiffre défile, le temps restant s'affiche, et la fin se confirme par un « Terminé » animé. Elle remplace l'ancienne barre de progression. Les ressources peuvent l'utiliser avec exports.pb_panel:Gauge (valeur qui défile, par exemple un montant) ou la piloter à la main avec GaugeSet / GaugeEnd.", module = 'interface' },
    { tag = 'Corrigé', text = "Portes : une porte déverrouillée par un joueur autorisé se referme maintenant toute seule (30 secondes par défaut, réglable dans le panel) et tout est reverrouillé au démarrage du serveur. Nouvelle commande staff /portes_diag [id joueur] : elle dit, pour la porte la plus proche, si ce joueur a l'accès et pourquoi (staff en service, métier, gang). Nouveau réglage « Le staff en service ouvre toutes les portes » (désactivable pour tester). Le client revérifie aussi l'état des portes proches pour qu'elles ne restent pas ouvertes à tout le monde.", module = 'wb_portes' },
    { tag = 'Corrigé', text = "Service staff : quand les permissions d'un membre du staff sont retirées pendant qu'il est en service, il n'est plus considéré en service (avant, il gardait ses passe-droits jusqu'à sa déconnexion : portes, radio, anti-triche).", module = 'staff' },
} })
N.Add({ id = 'patch202', date = '2026-11-01', title = "Patch notes 202 : nouvelle DA des interfaces", items = {
    { tag = 'Nouveau', text = "Écran de chargement refait, tout se règle dans le panel (Interfaces) : images de fond, titre, texte, couleur, liens Discord et Boutique, musiques avec lecteur.", module = 'uida' },
    { tag = 'Amélioré', text = "Écran « Bonjour … » avant l'arrivée en ville : fond, étape, grand pourcentage, barre. Aussi après le créateur : le décor se charge derrière.", module = 'uida' },
    { tag = 'Amélioré', text = "Choix du personnage : emplacements numérotés, carte des points de départ, touches Décor (J), Masquer (H), Quitter (deux fois Échap).", module = 'character' },
    { tag = 'Amélioré', text = "Créateur refait en 10 étapes : choix homme ou femme dans la salle d'identité, hérédité avec un troisième parent, visage, peau, cheveux, pilosité, maquillage, tenue, identité, arrivée. Glisser pour tourner, molette pour zoomer, Ctrl+Z pour défaire.", module = 'character' },
    { tag = 'Modifié', text = "Inventaire : ton ped s'affiche au centre (une copie), le personnage du monde ne bouge plus.", module = 'inv' },
    { tag = 'Amélioré', text = "Chat : panneau en haut à gauche et commandes rangées par catégories avec leur description.", module = 'chat' },
    { tag = 'Amélioré', text = "Banque refaite sur un seul écran : carte du compte, courbe sur 12 h à 30 jours, historique détaillé, dépôt, retrait et virement avec récapitulatif.", module = 'bank' },
    { tag = 'Nouveau', text = "Magasin de vêtements refait : accueil, catalogue par rayon, variantes, panier, choix espèces ou carte, tenues enregistrées et tenues de la communauté. Prix à la pièce réglable.", module = 'shops' },
    { tag = 'Amélioré', text = "Ammu-Nation refait : rayons, recherche, tri, fiche de l'arme avec dégâts, poids et chargeur, aperçu 3D de l'article devant le vendeur.", module = 'shops' },
    { tag = 'Nouveau', text = "Carte : les repères de même icône sont regroupés sous un seul nom dans la légende (« ‹ 1/20 › »). Noms réglables dans le panel.", module = 'uida' },
} })
N.Add({ id = 'patch203', date = '2026-11-01', title = "Patch notes 203 : sons et détails de l'inventaire", items = {
    { tag = 'Nouveau', text = "Inventaire : sons à l'ouverture, au clic droit, sur chaque action, en prenant et en déposant un objet.", module = 'inv' },
    { tag = 'Nouveau', text = "Fenêtre de quantité : curseur, MAX, Échap pour annuler, Entrée pour valider, pour donner, jeter, ranger, prendre et détruire.", module = 'inv' },
    { tag = 'Nouveau', text = "Clic droit : Donner (« Aucun joueur à proximité » s'il n'y a personne), Renommer, Détruire. Détruire se coupe dans le panel.", module = 'inv' },
    { tag = 'Amélioré', text = "Info-bulle détaillée sur chaque objet, message « Il reste : 1 » quand le sac change, poids en vert ou en rouge un instant.", module = 'inv' },
} })
N.Add({ id = 'patch204', date = '2026-11-01', title = "Patch notes 204 : HUD", items = {
    { tag = 'Corrigé', text = "Le HUD pouvait rester caché après l'inventaire ou le créateur. Nouvelle commande /hudinfo : donne la cause et le rétablit.", module = 'hud' },
} })
N.Add({ id = 'patch205', date = '2026-11-01', title = "Patch notes 205 : nouveau menu pause, boutique", items = {
    { tag = 'Nouveau', text = "Nouveau menu pause : la carte du serveur en grand, recherche de lieux, lieux enregistrés, statistiques, repères du jeu, GPS, survol, position, zoom, déconnexion.", module = 'pause' },
    { tag = 'Amélioré', text = "Boutique retravaillée : angles droits, aplats sombres, couleur du serveur.", module = 'premium' },
    { tag = 'Corrigé', text = "Écran d'entrée : la touche E s'affichait dans un carré blanc sans la lettre.", module = 'character' },
    { tag = 'Amélioré', text = "Inventaire : le bloc État est plus compact, le personnage rentre en entier.", module = 'inv' },
} })
N.Add({ id = 'patch206', date = '2026-11-01', title = "Patch notes 206 : packs d'armes, menu pause", items = {
    { tag = 'Nouveau', text = "Packs d'armes Japan et Bloodline : leurs 10 armes arrivent au catalogue dès que la ressource est démarrée, rangées à part dans le give du staff.", module = 'weapons' },
    { tag = 'Amélioré', text = "Menu pause en plein écran : ton ped au centre avec ta fiche (identité, argent, emploi, permis, VIP, état, compétences, véhicules, logements). La carte a son propre onglet.", module = 'pause' },
    { tag = 'Corrigé', text = "Inventaire : plus de petits ronds à côté du nom des cases, titre État centré, bloc plus petit pour laisser passer les pieds.", module = 'inv' },
} })
N.Add({ id = 'patch207', date = '2026-11-01', title = "Patch notes 207 : ancien inventaire, menu Échap retiré, prisons réglables", items = {
    { tag = 'Amélioré', text = "Retour à l'ancien inventaire.", module = 'inv' },
    { tag = 'Amélioré', text = "Le menu Échap du serveur est retiré : Échap ouvre le menu de GTA. /carte, la carte rapide (M), les styles de carte et les lieux communs restent.", module = 'pause' },
    { tag = 'Amélioré', text = "Nouvelle barre de progression en bas de l'écran (récolte, traitement, préparation…) : cases qui se remplissent, pourcentage, rappel de la touche X.", module = 'hud' },
    { tag = 'Amélioré', text = "HUD staff refait : trois carrés simples. Retour à l'ancien écran de chargement. Écran du E plus bas et plus aéré.", module = 'staff' },
    { tag = 'Amélioré', text = "Retour à l'ancien choix du personnage, avec le logo FA ; bannière Fraternity en plein écran pendant la connexion.", module = 'character' },
    { tag = 'Nouveau', text = "Justice › Prisons : lieu, sortie et zone de la prison de la police et de la prison du staff. Au Builder : chantiers TIG en plus des prisons.", module = 'justice' },
} })
N.Add({ id = 'patch208', date = '2026-11-01', title = "Patch notes 208 : point ou zone, masques et sacs, barre de progression", items = {
    { tag = 'Nouveau', text = "Builder › Drogues : à la pose, chaque récolte, labo ou vente est un point avec E ou une zone avec E (5 à 30 m, contour au sol).", module = 'crime' },
    { tag = 'Corrigé', text = "La touche E qui montre où se trouve un point d'activité s'affiche de nouveau de loin.", module = 'crime' },
    { tag = 'Amélioré', text = "Magasin de masques et sacs : même écran que les vêtements, seulement l'achat. Masques et sacs retirés du magasin de vêtements.", module = 'shops' },
    { tag = 'Amélioré', text = "Barre de progression : aussi à la récolte et à la vente, un peu plus haut, à la couleur du serveur.", module = 'hud' },
} })
N.Add({ id = 'patch209', date = '2026-11-01', title = "Patch notes 209 : HUD rétabli, variantes, gros sac", items = {
    { tag = 'Corrigé', text = "Le HUD ne s'affichait plus : une erreur arrêtait sa boucle dès l'arrivée en ville.", module = 'hud' },
    { tag = 'Corrigé', text = "Vêtements, masques, sacs : toutes les variantes sont visibles, avec défilement. Les sacs se vendent dans toutes leurs couleurs.", module = 'shops' },
    { tag = 'Corrigé', text = "Télévisions : les vidéos YouTube sont de nouveau lues (YouTube refusait le lecteur, erreur 153).", module = 'tv' },
    { tag = 'Corrigé', text = "Menu ALT : le véhicule dans lequel on est assis est maintenant cliquable.", module = 'ctx' },
    { tag = 'Amélioré', text = "Le sac le plus lourd (+50 kg) est un gros sac porté sur le dos.", module = 'inv' },
    { tag = 'Amélioré', text = "Barre de progression et jauge du plein plus hautes ; écran du E : message tout en haut, bouton plus bas.", module = 'hud' },
} })
N.Add({ id = 'patch338', date = '2026-11-06', title = "Caisses : vraie animation d'ouverture", items = {
    { tag = 'Nouveau', text = "Ouverture de caisse refaite : la caisse tombe, tremble, s'ouvre (couvercle + lumière), puis les lots tournent en anneau 3D et s'arrêtent sur ton gain. Aux couleurs du serveur (noir/blanc/vert).", module = 'caisses' },
} })
N.Add({ id = 'patch337', date = '2026-11-06', title = "Patch notes 337 : nouvelles drogues", items = {
    { tag = 'Nouveau', text = "Activités illégales : tu peux créer tes propres drogues dans le panel (nom, prix du pochon, style du labo). Elles apparaissent dans le Builder du menu staff avec leurs objets (brut, pochon, pur) créés automatiquement.", module = 'crime' },
} })
N.Add({ id = 'patch336', date = '2026-11-06', title = "Patch notes 336 : images d'objets", items = {
    { tag = 'Nouveau', text = "Nouvelles images pour la boombox et le kit de réparation.", module = 'inventaire' },
} })
N.Add({ id = 'patch335', date = '2026-11-06', title = "Patch notes 335 : les caisses", items = {
    { tag = 'Nouveau', text = "Caisses : on en gagne avec le temps de jeu (une toutes les 60 min par défaut) et on les ouvre avec /caisses, avec une animation. Récompenses : argent, objets, armes, véhicules. Types de caisses, chances et contenu réglables dans le panel › Caisses. /givecaisse pour en donner.", module = 'crates' },
} })
N.Add({ id = 'patch334', date = '2026-11-06', title = "Patch notes 334 : véhicules d'origine des métiers", items = {
    { tag = 'Nouveau', text = "Police, secours, dépanneurs et taxis : leurs véhicules d'origine (voiture de police, interceptor, ambulance, dépanneuse, plateau, taxi) sont ajoutés automatiquement au garage de chaque entreprise, à la création et pour celles qui existent déjà. Une seule fois par entreprise. Réglage dans Entreprises.", module = 'biz' },
} })
N.Add({ id = 'patch333', date = '2026-11-06', title = "Patch notes 333 : cases à cocher et fiche des reports", items = {
    { tag = 'Nouveau', text = "Menus : les interrupteurs deviennent des cases à cocher carrées arrondies (vide = contour, cochée = coche).", module = 'menus' },
    { tag = 'Nouveau', text = "Staff : ouvrir un report affiche une fiche « Information du report » (ID temporaire, ID unique, raison, ouvert depuis).", module = 'staff' },
} })
N.Add({ id = 'patch332', date = '2026-11-06', title = "Patch notes 332 : livrée par défaut", items = {
    { tag = 'Correctif', text = "Un véhicule sans livrée enregistrée sort avec la livrée 0 (la normale) au lieu d'un camouflage tiré au hasard.", module = 'garage' },
} })
N.Add({ id = 'patch331', date = '2026-11-06', title = "Patch notes 331 : catégorie Addon", items = {
    { tag = 'Nouveau', text = "Magasin de vêtements : une catégorie « Addon » regroupe les vêtements, masques, sacs et accessoires ajoutés au serveur. Les coiffures addon ont leur réglage « Coupe addon » chez le coiffeur. Le premier numéro addon de chaque pièce se règle dans Interfaces › Vêtements addon ; /addoninfo aide à les trouver.", module = 'uida' },
} })
N.Add({ id = 'patch330', date = '2026-11-06', title = "Patch notes 330 : camouflage des véhicules addon", items = {
    { tag = 'Correctif', text = "Un véhicule sans livrée enregistrée ne tire plus un camouflage au hasard à la sortie du garage. Commandes /livrees et /livree N pour trouver la bonne livrée.", module = 'garage' },
} })
N.Add({ id = 'patch329', date = '2026-11-06', title = "Patch notes 329 : écrans de chargement avec vos images", items = {
    { tag = 'Nouveau', text = "Chargement, « Connexion à la ville » et arrivée du personnage utilisent les images réglées dans Interfaces : fondu entre images, lent zoom, flou qui se précise.", module = 'uida' },
    { tag = 'Nouveau', text = "Interfaces : bloc « Rendu » avec les trois écrans (première image https).", module = 'uida' },
} })
N.Add({ id = 'patch328', date = '2026-11-06', title = "Patch notes 328 : logo, écrans de chargement, inventaire", items = {
    { tag = 'Correctif', text = "Le logo de l'écran « Appuyer sur E pour commencer » suit enfin le logo du serveur (celui réglé au panel) au lieu d'un ancien logo fixe. Le logo par défaut du serveur est aussi remplacé par le nouveau.", module = 'Écrans' },
    { tag = 'Amélioration', text = "Écran de chargement entre le choix du personnage et l'arrivée en ville : l'illustration du serveur en fond, avec « Bonjour … » et la progression en bas. Une image réglée au panel (Écran « Bonjour… ») garde la priorité.", module = 'Écrans' },
    { tag = 'Amélioration', text = "Écran « Connexion à la ville » : plus de fond flou, un fond net aux couleurs du serveur.", module = 'Écrans' },
    { tag = 'Amélioration', text = "Inventaire : cases et équipements un peu plus sombres (moins transparents) pour mieux voir les icônes.", module = 'Inventaire' },
} })
N.Add({ id = 'patch327', date = '2026-11-06', title = "Patch notes 327 : création de garage", items = {
    { tag = 'Correctif', text = "Créer un garage redemande bien où sortent les véhicules, comme avant ; mais une fois le point posé, le Builder revient sur la liste du garage au lieu de se fermer, pour finir la configuration (rangement, gardien).", module = 'Builder' },
} })
N.Add({ id = 'patch326', date = '2026-11-06', title = "Patch notes 326 : labos en première personne, Builder des garages, confirmations", items = {
    { tag = 'Nouveau', text = "Les labos immersifs se jouent à la première personne, face à l'établi, avec de vrais gestes : clic gauche maintenu et souris pour remuer, clic gauche maintenu pour verser la casserole, clic gauche pour taper avec le marteau ou hacher au couteau. Plus rien d'automatique : la recette avance selon ce que tu fais (X pour annuler).", module = 'Activités illégales' },
    { tag = 'Correctif', text = "Créer un garage au Builder ne demande plus d'office la sortie des véhicules et ne ferme plus le Builder : la liste reste ouverte, on pose la sortie, le rangement et le gardien dans l'ordre voulu.", module = 'Builder' },
    { tag = 'Correctif', text = "Les confirmations disent la bonne action : « Donner ? » pour un don de véhicule, « Rendre ? », « Retirer ? », « Revenir en arrière ? »… et non plus toujours « Supprimer ? ».", module = 'Menus' },
} })
N.Add({ id = 'patch325', date = '2026-11-06', title = "Patch notes 325 : garages, véhicules d'organisation, blips", items = {
    { tag = 'Nouveau', text = "Ajouter un véhicule à une entreprise ou à un gang (Builder et menu staff › Organisations) : la liste de tous les véhicules du serveur par catégorie, avec aperçu transparent, plus les modèles installés qui ne sont dans aucune catégorie. On peut aussi taper un nom à la main et choisir son type : voiture, naval ou aérien.", module = 'Garages' },
    { tag = 'Correctif', text = "Un hélicoptère ou un bateau ajouté à une entreprise ou un gang ne se retrouve plus dans le garage des voitures : le type choisi à l'ajout est enregistré avec le véhicule.", module = 'Garages' },
    { tag = 'Nouveau', text = "Chaque garage (public, fourrière, entreprise, gang, hélipad) a un point de rangement à poser au Builder, avec son marker : voiture, bateau ou avion selon le type. Sans point posé, le rangement se fait à l'entrée comme avant.", module = 'Garages' },
    { tag = 'Nouveau', text = "Donner un véhicule à un joueur et en faire apparaître un : la liste de tous les véhicules par catégorie avec aperçu transparent, et un champ pour taper le nom d'un véhicule qui n'apparaît pas dans la liste (véhicule perm, par exemple).", module = 'Staff' },
    { tag = 'Nouveau', text = "Builder : chaque garage (public, fourrière, entreprise, gang) a sa fiche avec « Y aller », et les garages créés sans nom reçoivent un nom distinct (Garage 1, Hangar 2, Port 1…).", module = 'Builder' },
    { tag = 'Amélioration', text = "Le point « QG / Siège » devient un simple blip sur la carte : il n'ouvre plus de tablette, ce qui évite les doublons avec le bureau du patron. Les organisations ont un point « Tablette de gestion » pour la gestion ; un ancien QG continue de servir tant que ce point n'est pas posé.", module = 'Builder' },
} })
N.Add({ id = 'patch324', date = '2026-11-06', title = "Patch notes 324 : établi et commandes de test du labo", items = {
    { tag = 'Nouveau', text = "Un point de labo immersif pose maintenant un établi (prop) à son emplacement : table de coke, de méthamphétamine ou de cannabis selon la drogue. Il apparaît quand on s'approche et disparaît si le point est supprimé ou repassé en classique.", module = 'Activités illégales' },
    { tag = 'Nouveau', text = "Commande /labotest [coke|meth|weed|heroin|ecstasy] (staff) : joue la recette immersive ici, sans point, sans ingrédient et sans rien recevoir. Commande /laboprop [drogue] : montre l'établi devant toi 15 secondes et indique le modèle utilisé.", module = 'Activités illégales' },
} })
N.Add({ id = 'patch323', date = '2026-11-06', title = "Patch notes 323 : relecture complète et correctifs", items = {
    { tag = 'Corrigé', text = "Menus et pages du panel : une entrée vide au milieu d'une liste (option réservée à un droit, à un mode…) ne coupe plus la suite de la liste. Cette erreur masquait des choix dans le Builder et pouvait cacher des tableaux dans certaines pages.", module = 'Système' },
    { tag = 'Corrigé', text = "Labo immersif : l'objet « produit pur » est créé avant la vérification de la place dans le sac (le labo refusait sinon de démarrer la première fois).", module = 'Activités illégales' },
} })
N.Add({ id = 'patch322', date = '2026-11-06', title = "Patch notes 322 : choix de pose du Builder rétablis", items = {
    { tag = 'Corrigé', text = "Builder › Drogues : à la création d'un point, tous les choix reviennent (point classique, point immersif, zone ronde, zone tracée, vente aux PNJ). Une erreur de liste les masquait et ne laissait que « Point avec E ».", module = 'Builder' },
    { tag = 'Amélioré', text = "/pbcheck cherche aussi quelle ressource du serveur affiche un ancien texte de tracé de zone.", module = 'Système' },
} })
N.Add({ id = 'patch321', date = '2026-11-06', title = "Patch notes 321 : commande de diagnostic", items = {
    { tag = 'Nouveau', text = "Commande /pbcheck (console ou staff) : indique si les fichiers sur le disque du serveur sont à jour et si les scripts que chaque joueur fait tourner le sont aussi (utile après wupdate).", module = 'Système' },
} })
N.Add({ id = 'patch320', date = '2026-11-06', title = "Patch notes 320 : tracé de zone point par point", items = {
    { tag = 'Corrigé', text = "Tracé d'une zone coin par coin : un appui sur Entrée pose un seul coin (plus de pose en continu), et on termine avec E, G ou Y (3 coins minimum).", module = 'Builder' },
} })
N.Add({ id = 'patch319', date = '2026-11-06', title = "Patch notes 319 : mécano seul", items = {
    { tag = 'Nouveau', text = "Un mécano seul peut se facturer la customisation d'un véhicule sans propriétaire : F6 › Envoyer la facture › « Me facturer ». Il paie, la caisse du garage encaisse, la customisation reste.", module = 'Mécanicien' },
} })
N.Add({ id = 'patch318', date = '2026-11-06', title = "Patch notes 318 : passants dans les zones de vente", items = {
    { tag = 'Nouveau', text = "Dans une zone de vente aux PNJ, des passants apparaissent et se promènent : 2 par défaut, plus 2 par joueur présent dans la zone (maximum 14). Ils disparaissent quand plus personne n'est à proximité.", module = 'Activités illégales' },
    { tag = 'Amélioré', text = "Un passant servi disparaît 5 secondes après la vente et un nouveau apparaît ailleurs dans la zone.", module = 'Activités illégales' },
    { tag = 'Nouveau', text = "Panel › Activités illégales › Réglages : nombre de passants de base, par joueur et maximum.", module = 'Activités illégales' },
} })
N.Add({ id = 'patch317', date = '2026-11-06', title = "Patch notes 317 : le visage s'adapte au masque", items = {
    { tag = 'Amélioré', text = "Le visage s'adapte au masque porté, comme sur GTA Online : les joues et le menton ne traversent plus les cagoules.", module = 'Personnage' },
    { tag = 'Amélioré', text = "Le visage d'origine revient dès que le masque est retiré, rien n'est modifié sur le personnage.", module = 'Personnage' },
} })
N.Add({ id = 'patch316', date = '2026-11-06', title = "Patch notes 316 : territoires gagnés par les ventes de drogue", items = {
    { tag = 'Nouveau', text = "Territoires : nouveau mode de prise « Ventes ». La zone revient au gang qui y vend le plus de drogue (classement sur plusieurs jours, ventes aux points comme aux passants). Aucune bataille sur ces zones.", module = 'Territoires' },
    { tag = 'Nouveau', text = "Builder › Territoire de gang : choix « Combat » ou « Ventes » à la création, modifiable ensuite dans Territoires. La commande /ventes affiche le classement de la zone où l'on se trouve.", module = 'Builder' },
    { tag = 'Nouveau', text = "Zones « ventes » : les ventes ne comptent que pendant les horaires réglés (par défaut tous les jours de 18 h à 23 h, heure de Paris). Une vente à 3 h du matin ne sert à rien. Réglable dans Panel › Territoires.", module = 'Territoires' },
    { tag = 'Nouveau', text = "Panel › Territoires : jours comptés dans le classement (7), ventes minimum pour tenir une zone (500 $) et durée minimale avant un changement de main (1 h).", module = 'Territoires' },
} })
N.Add({ id = 'patch315', date = '2026-11-06', title = "Patch notes 315 : vente de drogue aux passants", items = {
    { tag = 'Nouveau', text = "Builder › Drogues › Vente : choisis « Vente au point » (E sur le point, comme avant) ou « Vente aux PNJ » (zone ronde ou tracée). Dans la zone, on s'approche d'un passant et E lui propose la marchandise.", module = 'Activités illégales' },
    { tag = 'Nouveau', text = "Le passant accepte (échange, paiement à l'unité, produit pur payé plus cher) ou refuse, s'enfuit et disparaît. Les chances d'acceptation se règlent dans Activités illégales › Réglages (65 % par défaut) ; la police peut être prévenue selon l'alerte du point.", module = 'Activités illégales' },
} })
N.Add({ id = 'patch314', date = '2026-11-06', title = "Patch notes 314 : labos immersifs pour chaque drogue", items = {
    { tag = 'Nouveau', text = "Une recette immersive par drogue : cannabis (broyer, remplir, rouler), cocaïne, héroïne, ecstasy et méthamphétamine (casserole, plaque, refroidissement, coups).", module = 'Activités illégales' },
    { tag = 'Amélioré', text = "Labo immersif : aucun ingrédient ni objet à apporter (casserole et plaque sont juste de la mise en scène). À la fin de la recette, on reçoit le produit pur (cocaïne pure, méthamphétamine pure, etc.), qui se vend 1,6 × le prix d'un pochon chez les dealers.", module = 'Activités illégales' },
    { tag = 'Nouveau', text = "Builder › Drogues › Laboratoire : à la pose, choisis « Point classique (E + barre) » ou « Point immersif ». Le choix se refait quand tu déplaces le point.", module = 'Builder' },
} })
N.Add({ id = 'patch313', date = '2026-11-06', title = "Patch notes 313 : labo de drogue interactif", items = {
    { tag = 'Nouveau', text = "Labo interactif : on met les ingrédients dans la casserole, on la renverse sur la plaque, on laisse durcir puis on casse la plaque (3 coups) pour récupérer le produit. Chaque étape est validée par le serveur (ordre, durée, distance).", module = 'Activités illégales' },
    { tag = 'Nouveau', text = "Panel › Activités illégales › Filières : nouvelle colonne « mode » sur les points de transformation. Vide = transformation classique (E + barre, inchangée) ; cook = labo interactif.", module = 'Activités illégales' },
} })
N.Add({ id = 'patch312', date = '2026-11-06', title = "Patch notes 312 : fourrière et bateaux", items = {
    { tag = 'Corrigé', text = "Fourrière : on ne voit plus que les véhicules réellement en fourrière (ou sortis et récupérables), du type de cette fourrière, au lieu de toute la liste.", module = 'Garages' },
    { tag = 'Corrigé', text = "Les yachts et bateaux ajoutés au serveur ne s'affichent plus dans le garage des voitures (ils sont reconnus par leur nom).", module = 'Garages' },
} })
N.Add({ id = 'patch311', date = '2026-11-05', title = "Patch notes 311 : Builder plus fiable, menu staff plus rapide", items = {
    { tag = 'Corrigé', text = "Builder : un point supprimé (zone safe, garage…) disparaît tout de suite de la liste, sans devoir rouvrir le menu.", module = 'Builder' },
    { tag = 'Corrigé', text = "Zones safe : le tracé coin par coin ne referme plus le menu au bout de 3 secondes et ne bloque plus le clavier ; Entrée valide la zone.", module = 'Zones safe' },
    { tag = 'Corrigé', text = "Zones safe : la zone se termine aussi avec G ou en appuyant sur E sur le premier coin (en plus d'Entrée).", module = 'Zones safe' },
    { tag = 'Amélioré', text = "Menu staff : les requêtes (détenus, garages) partent en même temps au lieu d'une par une, et la liste des joueurs suivis se lit en une seule requête.", module = 'Performance' },
} })
N.Add({ id = 'patch310', date = '2026-11-05', title = "Patch notes 310 : ambulance gayaems", items = {
    { tag = 'Nouveau', text = "Véhicule addon « gayaems » (ambulance EMS) ajouté à la liste des véhicules addon du serveur : il apparaît dans les listes de véhicules (Builder, panel) dès que sa ressource est démarrée.", module = 'garage' },
} })
N.Add({ id = 'patch309', date = '2026-11-05', title = "Patch notes 309 : message clair quand wupdate ne peut pas sauvegarder", items = {
    { tag = 'Amélioré', text = "Mises à jour : si le serveur ne peut vraiment écrire nulle part pour garder le point de retour, « wupdate » indique le dossier concerné et la marche à suivre (créer le dossier « rollback » dans pb_panel/data avec les droits d'écriture, ou installer le zip à la main) au lieu d'un message vague.", module = 'updates' },
} })
N.Add({ id = 'patch308', date = '2026-11-05', title = "Patch notes 308 : wupdate ne bloque plus", items = {
    { tag = 'Corrigé', text = "Mises à jour : chez certains hébergeurs, le serveur n'a pas le droit de créer le dossier des points de retour, et « wupdate » refusait d'installer (« dossier … impossible à écrire »). Le point de retour va maintenant dans un dossier qui existe déjà, et s'il ne peut vraiment pas être écrit, la mise à jour s'installe quand même (avec un avertissement).", module = 'updates' },
} })
N.Add({ id = 'patch307', date = '2026-11-05', title = "Patch notes 307 : adresse du panel mobile", items = {
    { tag = 'Corrigé', text = "Panel mobile : l'adresse « …users.cfx.re » donnée par FiveM est retirée par Cfx.re (elle commence par « deprecated ») et ne marchait pas. L'adresse affichée utilise maintenant l'IP publique du serveur et le port 30120.", module = 'webpanel' },
} })
N.Add({ id = 'patch306', date = '2026-11-05', title = "Patch notes 306 : panel mobile, adresse corrigée", items = {
    { tag = 'Corrigé', text = "Panel mobile : la page s'ouvre aussi sans la barre « / » à la fin de l'adresse, et une adresse fausse affiche une explication au lieu d'une page vide. L'IP publique est cherchée auprès de plusieurs services ; la console affiche l'adresse seule sur sa ligne, facile à copier.", module = 'webpanel' },
} })
N.Add({ id = 'patch305', date = '2026-11-05', title = "Patch notes 305 : panel mobile sans être en jeu", items = {
    { tag = 'Nouveau', text = "Panel mobile depuis la console : dans txAdmin › Console (marche aussi sur téléphone), tape « panelmobile » : l'adresse et un code à 6 chiffres pour le propriétaire s'affichent. « panelmobile license:xxxx » ou « panelmobile #12 » pour un autre membre du staff.", module = 'webpanel' },
    { tag = 'Amélioré', text = "L'adresse du panel mobile contient maintenant la vraie IP publique du serveur (plus « <IP de ton serveur> »).", module = 'webpanel' },
} })
N.Add({ id = 'patch304', date = '2026-11-05', title = "Patch notes 304 : pharmacie, recrutement, colocation, carte d'identité, concerts", items = {
    { tag = 'Nouveau', text = "Pharmacie : Builder › Commerces › Pharmacie (soins légers), avec un PNJ. Pansement, désinfectant, antidouleur, petite trousse. Exprès moins efficaces que les secours : soin progressif, plafond à 70 % de la vie, 45 s entre deux produits, rien à terre. Réglages : panel › Entreprises › Réglages › Pharmacie.", module = 'shops' },
    { tag = 'Nouveau', text = "Téléphone › Emplois : les entreprises qui recrutent, et « Postuler » avec un message. Le patron (ou un grade qui peut engager) ouvre le recrutement et répond dans la tablette F6 › Candidatures : Accepter envoie la proposition d'embauche au candidat où qu'il soit, Refuser le prévient par SMS.", module = 'phone' },
    { tag = 'Nouveau', text = "Colocation : cagnotte du loyer (le titulaire et les colocataires y versent, le loyer est pris dedans d'abord) et partage du loyer à parts égales, prélevé à chaque loyer. Menu du logement › Cagnotte du loyer.", module = 'housing' },
    { tag = 'Nouveau', text = "Carte d'identité : une vraie carte à l'écran avec la photo du personnage, nom, naissance, sexe, taille, nationalité, numéro. ALT › Montrer mes papiers, ou l'objet « Carte d'identité » du sac (la personne en face la voit aussi). Retour arrière pour la ranger.", module = 'ctx' },
    { tag = 'Nouveau', text = "Concerts : Builder › Loisirs › Scène de concert. La sono s'entend fort dans tout le rayon (60 m, réglable), synchronisée pour tout le monde, avec des lumières de scène. E sur la console du DJ : radio, lien YouTube, couper. Le staff et les employés en service de l'établissement choisi (panel › Musique › Scènes) peuvent jouer.", module = 'music' },
    { tag = 'Amélioré', text = "EMS : la facture de réanimation ou de soins part tout de suite au patient (réglable : sinon on choisit la personne comme avant).", module = 'ems' },
    { tag = 'Amélioré', text = "Tablette du patron › Statistiques : chiffre d'affaires sur 30 jours, heures de service de l'équipe, et pour chaque employé ses heures et ce qu'il a encaissé sur 7 jours.", module = 'biz' },
    { tag = 'Amélioré', text = "Graffitis : le gang dont un tag est effacé est prévenu (et par qui, si c'est un autre gang).", module = 'graffiti' },
} })
N.Add({ id = 'patch303', date = '2026-11-05', title = "Patch notes 303 : panel mobile, Discord, nettoyage, banc d'essai", items = {
    { tag = 'Nouveau', text = "Panel mobile : le panel depuis ton téléphone ou un navigateur, sans être en jeu. En jeu, /panelmobile (ou panel › Panel mobile) donne l'adresse et un code à 6 chiffres (5 min, une seule fois). Session de 12 h au plus, droits suivis en direct, PIN toujours demandé pour les actions sensibles. Il faut le droit « Se connecter au panel mobile ».", module = 'webpanel' },
    { tag = 'Nouveau', text = "Statut du serveur sur Discord : un seul message tenu à jour chaque minute (joueurs, file d'attente, staff, police, secours, temps en ligne, prochain redémarrage), rouge à l'arrêt. Panel › Discord : webhook « Statut du serveur ».", module = 'discord' },
    { tag = 'Nouveau', text = "Rôles Discord → avantages : priorité dans la file d'attente par rôle, liste blanche par rôle, VIP tant qu'on a le rôle, et bonus d'ancienneté dans la file. Panel › Discord ↔ personnage › Rôles → avantages.", module = 'discordlink' },
    { tag = 'Nouveau', text = "Nettoyage automatique : les véhicules vides sans propriétaire (sortis par le staff, missions, épaves) inutilisés depuis 30 min et loin des joueurs sont retirés, avec une annonce 60 s avant. Jamais les véhicules des joueurs, entreprises, gangs ni les locations. Chaque nuit, les vieux messages de reports et journaux sont supprimés (90 jours).", module = 'autoclean' },
    { tag = 'Nouveau', text = "Banc d'essai : mesure la cadence du serveur, la vitesse de la base, les opérations du jeu répétées comme pour 50 joueurs, la mémoire et les plus grosses tables. Avis à côté de chaque mesure.", module = 'bench' },
} })
N.Add({ id = 'patch302', date = '2026-11-05', title = "Patch notes 302 : outils de modération", items = {
    { tag = 'Nouveau', text = "Menu staff › un joueur › Sanction rapide : motifs prêts (Freekill, HRP, Metagaming, Powergaming, Carkill, NoFear, Troll, Cheat…) avec la sanction et la durée déjà choisies, plus une précision facultative. La liste se règle dans le panel › Statistiques du staff › Réglages (libellé|sanction|minutes).", module = 'staff' },
    { tag = 'Nouveau', text = "Comptes liés : chaque connexion note les identifiants du joueur (Rockstar, Steam, Discord, Xbox, FiveM, empreinte du PC, IP chiffrée). Fiche d'un joueur › Comptes liés : les autres comptes qui les partagent, bannis en rouge. Un compte lié à un banni (même PC, Steam ou Discord) prévient le staff ; il peut aussi être refusé (réglage, coupé par défaut).", module = 'staff' },
    { tag = 'Nouveau', text = "Liste de surveillance : fiche d'un joueur › Surveiller ce joueur (avec un motif). Le staff en service est prévenu à chacune de ses connexions (et Discord, canal Alertes).", module = 'staff' },
    { tag = 'Nouveau', text = "F10 › Modération : les 30 dernières morts (tueur, arme, distance, dossiers, Y aller), la liste de surveillance et les statistiques du staff sur 7 jours.", module = 'staff' },
    { tag = 'Nouveau', text = "Rediffusion des morts : les 30 secondes avant et 3 secondes après chaque meurtre sont enregistrées (positions, arme en main, véhicule) pour tous les joueurs à moins de 150 m. F10 › Modération › Morts récentes › Rediffusion : caméra libre, tueur en rouge, victime en bleu, Espace pause, flèches pour avancer, Tab pour suivre un joueur.", module = 'staff' },
    { tag = 'Nouveau', text = "Alerte freekill : un joueur qui tue 3 personnes en 10 minutes (réglable) est signalé au staff en service et sur Discord. Les policiers en service ne comptent pas.", module = 'staff' },
    { tag = 'Nouveau', text = "Reports : à la clôture, le joueur peut noter l'aide reçue avec /noter 1 à 5 (et un commentaire).", module = 'staff' },
    { tag = 'Nouveau', text = "Panel › Statistiques du staff : heures de service, reports pris, temps avant de prendre un report, sanctions données, note moyenne des joueurs, sur 7 et 30 jours.", module = 'staffstats' },
} })
N.Add({ id = 'patch301', date = '2026-11-05', title = "Patch notes 301 : retour en arrière des mises à jour, historique des joueurs", items = {
    { tag = 'Nouveau', text = "Mises à jour : avant chaque « wupdate », un point de retour est créé tout seul : les fichiers qui vont changer, une sauvegarde de la base et une de la configuration. Rien n'est installé si cette sauvegarde échoue. Les 3 derniers points sont gardés.", module = 'updates' },
    { tag = 'Nouveau', text = "Console : « wrollback » liste les points de retour ; « wrollback 4 » remet les fichiers de la version d'avant ; « wrollback 4 base » remet aussi la base (ce que les joueurs ont fait depuis la mise à jour est perdu). Puis le serveur redémarre. Aussi dans le panel › Mises à jour. La version annulée n'est jamais réinstallée toute seule.", module = 'updates' },
    { tag = 'Nouveau', text = "Menu staff › un joueur › Historique complet (et dans le dossier d'un joueur hors ligne) : sanctions (même levées), reports, notes du staff, amendes et peines de la police, expulsions automatiques et tout ce que le staff lui a fait (argent, objets, soins, téléportations, retours en arrière, register, wipe…), du plus récent au plus ancien, avec un filtre par type.", module = 'staff' },
} })
N.Add({ id = 'patch300', date = '2026-11-05', title = "Patch notes 300 : serveur plus solide", items = {
    { tag = 'Corrigé', text = "Stabilité : 47 tâches de fond (salaires, loyers, licence, sauvegardes, carte des joueurs, protection des nouveaux, territoires, locations…) s'arrêtaient pour de bon à la moindre erreur, jusqu'au prochain redémarrage. Elles continuent maintenant et l'erreur est notée dans la console.", module = 'monitor' },
    { tag = 'Corrigé', text = "Protection des nouveaux joueurs : un policier ou un ambulancier en service garde ses actions de métier (menotter, fouiller, escorter, mettre dans le véhicule, sortir du véhicule) même pendant ses premières minutes. Les actions illégales et de gang restent bloquées.", module = 'ctx' },
    { tag = 'Corrigé', text = "Reports : en prenant un report, la notification « Report pris en charge » n'est plus remplacée par celle du chat.", module = 'staff' },
    { tag = 'Amélioré', text = "Tests de robustesse : plus de 13 000 appels réseau piégés et les 212 actions du menu staff avec des données invalides, sans aucune erreur serveur.", module = 'monitor' },
} })
N.Add({ id = 'patch299', date = '2026-11-05', title = "Patch notes 299 : mises à jour visibles tout de suite", items = {
    { tag = 'Corrigé', text = "Mises à jour : le site GitHub Pages pouvait mettre des heures à afficher une nouvelle version, et « wupdate » répondait « Déjà à jour ». Le serveur lit maintenant la copie du dépôt, à jour dès la publication (site en secours). Signature et empreinte toujours vérifiées.", module = 'updates' },
} })
N.Add({ id = 'patch298', date = '2026-11-05', title = "Patch notes 298 : tracé des zones safe refait", items = {
    { tag = 'Corrigé', text = "Zones safe tracées coin par coin : on pouvait rester bloqué dans le tracé (une fenêtre gardait le clavier). Le clavier est rendu au jeu au départ et l'aide s'affiche à l'écran par le jeu lui-même.", module = 'wb_zonesafe' },
    { tag = 'Amélioré', text = "Nouvelles touches : E pose un coin, Retour arrière retire le dernier, Entrée termine (3 coins minimum), X annule. Secours dans le chat : /zonefin et /zoneannuler.", module = 'wb_zonesafe' },
} })
N.Add({ id = 'patch297', date = '2026-11-05', title = "Patch notes 297 : carte des joueurs et caméra libre", items = {
    { tag = 'Nouveau', text = "Menu staff › Gestion des joueurs › Carte des joueurs : tous les joueurs sur ta carte et ta mini-carte, même loin de toi (ID, nom, métier, gang), mis à jour toutes les 2 s. Filtre : tous, staff en service, une entreprise ou un gang. Rouge : staff, violet : gang, bleu : métier.", module = 'staff' },
    { tag = 'Nouveau', text = "Menu staff › Gestion personnelle › Caméra libre : la caméra se détache, ton personnage devient invisible et la suit (le monde reste chargé). ZQSD et souris, Maj / Ctrl pour la vitesse, E / A pour monter et descendre, molette, H pour cacher l'interface et filmer, Retour arrière pour revenir.", module = 'staff' },
} })
N.Add({ id = 'patch296', date = '2026-11-05', title = "Patch notes 296 : parler au joueur d'un report dans le chat", items = {
    { tag = 'Nouveau', text = "Reports : le staff parle au joueur directement dans le chat, sans casser la scène en vocal. Seuls le joueur et le staff en service voient la conversation (ligne « REPORT #12 » en violet). Staff : menu F10 › report › Répondre dans le chat, ou /rr 12 message. Joueur : /r message.", module = 'staff' },
    { tag = 'Amélioré', text = "En prenant un report, le joueur reçoit un premier message dans le chat. Tous les messages restent dans le ticket (/ticket, panel, Discord).", module = 'staff' },
} })
N.Add({ id = 'patch295', date = '2026-11-05', title = "Patch notes 295 : retour en arrière et lecture seule", items = {
    { tag = 'Nouveau', text = "Menu staff › un joueur › Retour en arrière : ses sauvegardes des dernières 48 h (heure, objets, espèces et banque). Restaurer le sac et l'argent, ou le sac seul ; l'état actuel est sauvegardé avant. Après un bug, une duplication ou une triche.", module = 'staff' },
    { tag = 'Amélioré', text = "Les sauvegardes d'inventaire gardent maintenant aussi l'argent du joueur, et se font dès que le sac ou l'argent change (toutes les 30 min au plus).", module = 'invsnap' },
    { tag = 'Nouveau', text = "Mode lecture seule pour les modérateurs : un grade avec le droit « Menu staff en lecture seule » voit tout (fiches, inventaires, coffres, véhicules) mais ne peut rien donner, retirer, faire apparaître ni restaurer. Le fondateur n'est jamais concerné.", module = 'staff' },
} })
N.Add({ id = 'patch294', date = '2026-11-05', title = "Patch notes 294 : permis à points", items = {
    { tag = 'Nouveau', text = "Permis de conduire à points : 12 points au départ (réglable dans Auto-école). La police (menu ALT ou F6) contrôle le permis et retire des points avec un motif ; le conducteur est prévenu. À 0, tous les permis sont annulés, code compris : il faut repasser l'auto-école, qui redonne tous les points.", module = 'wb_autoecole' },
    { tag = 'Amélioré', text = "/permis affiche aussi les points restants. Chaque retrait est noté au journal de l'auto-école.", module = 'wb_autoecole' },
} })
N.Add({ id = 'patch293', date = '2026-11-04', title = "Patch notes 293 : register et wipe", items = {
    { tag = 'Nouveau', text = "Menu staff › un joueur › Register : il est expulsé et refait son identité et son apparence à la reconnexion. Argent, objets, véhicules et logements gardés, sans argent de départ en double.", module = 'staff' },
    { tag = 'Nouveau', text = "Menu staff › un joueur › Wipe : il est expulsé et tout son personnage est effacé (identité, argent, objets, véhicules, logements, emploi, organisation). Le compte reste : bans, sanctions, VIP, coins. Double confirmation, noté au journal du staff.", module = 'staff' },
    { tag = 'Amélioré', text = "Deux nouveaux droits : « register » et « wipe » (Grades et permissions).", module = 'staff' },
} })
N.Add({ id = 'patch292', date = '2026-11-04', title = "Patch notes 292 : plus de redémarrage automatique", items = {
    { tag = 'Amélioré', text = "Mises à jour : par défaut, plus rien ne s'installe ni ne redémarre tout seul. Quand une version sort, la console et le staff en ligne sont prévenus ; « wupdate » l'installe et redémarre quand tu le décides. L'installation automatique reste activable dans Mises à jour › Installation automatique.", module = 'updates' },
} })
N.Add({ id = 'patch291', date = '2026-11-04', title = "Patch notes 291 : garages publics, fourrières et /car", items = {
    { tag = 'Amélioré', text = "Builder › Créer › Véhicules › Garage, hangar, port, fourrière (pour tous les citoyens) : le gardien se tient où tu es et un véhicule transparent te suit tout de suite pour choisir la sortie (E). Plus besoin de poser la sortie à part.", module = 'carte' },
    { tag = 'Nouveau', text = "Staff : /car modèle fait apparaître un véhicule (ex. /car sultan) et /dv supprime celui où tu es. En service, avec le droit des véhicules.", module = 'staff' },
} })
N.Add({ id = 'patch290', date = '2026-11-04', title = "Patch notes 290 : voitures perms", items = {
    { tag = 'Nouveau', text = "Voitures perms : véhicules réservés, jamais en vente, que le staff donne à un joueur. Menu staff › un joueur › Donner un véhicule : la liste des voitures perms avec aperçu du véhicule, ou « Autre modèle… ». Le véhicule arrive dans son garage avec son vrai nom.", module = 'staff' },
    { tag = 'Amélioré', text = "Liste réglable dans le panel : Menu staff › Réglages › Voitures perms (modèle|nom affiché). Les modèles absents du serveur sont masqués.", module = 'staff' },
    { tag = 'Amélioré', text = "Audi RS7 et Ferrari F8 ajoutées aux voitures perms (avec la BMW M3 drag et la BMW M6).", module = 'staff' },
} })
N.Add({ id = 'patch289', date = '2026-11-04', title = "Patch notes 289 : aperçu des véhicules au Builder", items = {
    { tag = 'Nouveau', text = "Builder : en choisissant les véhicules d'une entreprise ou d'un pack de départ (entreprise ou gang), le véhicule survolé apparaît devant toi et tourne lentement, avec une caméra qui le cadre. Visible par toi seul ; il disparaît en quittant la liste.", module = 'carte' },
} })
N.Add({ id = 'patch288', date = '2026-11-04', title = "Patch notes 288 : garages d'entreprise et zones tracées", items = {
    { tag = 'Corrigé', text = "Garages d'entreprise : ils n'apparaissaient chez personne (le jeu ne recevait jamais l'entreprise du joueur). Les employés retrouvent le garage, son marqueur et la touche E ; les coffres et points d'entreprise sont concernés aussi.", module = 'garage' },
    { tag = 'Corrigé', text = "Garages d'entreprise et de gang : un gardien (PNJ) se tient maintenant à chaque garage, sur le point posé au Builder ou à l'entrée. Celui d'une entreprise se voit de tous, celui d'un gang des membres seulement.", module = 'garage' },
    { tag = 'Corrigé', text = "Zones safe tracées coin par coin : Entrée posait des coins dans le menu du Builder rouvert, ou un coin tout seul juste après le nom. Le menu reste de côté pendant le tracé ; Entrée, Y et X n'ouvrent plus rien d'autre. Entrée et sortie d'une zone tracée détectées plus vite.", module = 'wb_zonesafe' },
} })
N.Add({ id = 'patch287', date = '2026-11-04', title = "Patch notes 287 : redémarrage sans droit", items = {
    { tag = 'Corrigé', text = "Redémarrage : sans le droit « quit », les joueurs étaient expulsés mais le serveur ne s'arrêtait pas. Maintenant personne n'est expulsé, le redémarrage est annulé et la console affiche la ligne à taper : add_ace resource.pb_panel command.quit allow (effet immédiat dans la console, à garder aussi dans server.cfg).", module = 'updates' },
    { tag = 'Corrigé', text = "Le droit « quit » est lu sur la ressource elle-même (plus de faux « droit absent »).", module = 'updates' },
} })
N.Add({ id = 'patch286', date = '2026-11-04', title = "Patch notes 286 : licence renforcée", items = {
    { tag = 'Amélioré', text = "Licence : révocation en ligne activée par défaut (liste signée publiée avec les mises à jour, relue toutes les heures). Une licence révoquée le reste même si le serveur ne joint plus le site, et une ancienne liste ne peut pas la réactiver.", module = 'license' },
    { tag = 'Amélioré', text = "Licence : la clé publique est épinglée. Remplacer license_pub.lua pour fabriquer de fausses licences verrouille le serveur.", module = 'license' },
    { tag = 'Amélioré', text = "Sans licence valide, les ressources liées (chasse, pêche, mine, braquages, armes…) refusent aussi toute action.", module = 'license' },
} })
N.Add({ id = 'patch285', date = '2026-11-04', title = "Patch notes 285 : prêt pour l'escrow", items = {
    { tag = 'Amélioré', text = "Ressources prêtes pour l'escrow Cfx.re (code chiffré) : les fichiers config.lua restent lisibles et modifiables par le propriétaire du serveur. Aucun changement en jeu." },
} })
N.Add({ id = 'patch284', date = '2026-11-04', title = "Patch notes 284 : mises à jour toutes seules", items = {
    { tag = 'Nouveau', text = "Mises à jour automatiques : le serveur vérifie toutes les 10 minutes. Dès qu'une nouvelle version est publiée, il l'installe, annonce « Redémarrage du serveur dans 5 minutes » aux joueurs, puis redémarre (15 s s'il n'y a personne). Plus besoin de taper « wupdate ».", module = 'updates' },
    { tag = 'Amélioré', text = "Panel › Mises à jour › Installation automatique : activer ou couper, délai avant le redémarrage, fréquence de vérification. « wupdate » reste disponible pour installer tout de suite.", module = 'updates' },
} })
N.Add({ id = 'patch283', date = '2026-11-04', title = "Patch notes 283 : redémarrage après wupdate", items = {
    { tag = 'Corrigé', text = "Redémarrage (après « wupdate », planifié ou depuis le menu staff) : le serveur ne s'arrêtait pas (« Access denied for command quit ») quand server.cfg ne donne pas ce droit à la ressource. Il s'arrête maintenant quand même et txAdmin le relance.", module = 'updates' },
    { tag = 'Amélioré', text = "Console et panel (Mises à jour) : rappel de la ligne à ajouter dans server.cfg pour un arrêt classique : add_ace resource.pb_panel command.quit allow.", module = 'updates' },
} })
N.Add({ id = 'patch282', date = '2026-11-04', title = "Patch notes 282 : coffres et véhicules des organisations (staff)", items = {
    { tag = 'Nouveau', text = "Menu staff (F10) › Organisations et entreprises : pour chaque gang ou entreprise, ouvrir son coffre à distance (prendre, déposer depuis son sac) ou y ajouter un objet directement. La caisse de l'organisation est affichée.", module = 'staff' },
    { tag = 'Nouveau', text = "Même menu : la liste de ses véhicules (état, et « donné par » pour ceux offerts par un joueur), ajouter un véhicule neuf, supprimer un véhicule, rendre un véhicule donné à son ancien propriétaire. Tout est noté dans le journal du staff. Droit : « coffres et véhicules des organisations et des entreprises ».", module = 'staff' },
} })
N.Add({ id = 'patch281', date = '2026-11-04', title = "Patch notes 281 : protection des nouveaux joueurs", items = {
    { tag = 'Nouveau', text = "Pendant ses 30 premières minutes de jeu, un nouveau joueur ne peut ni sortir d'arme, ni tirer, ni frapper, ni menotter, fouiller, escorter, ligoter, braquer ou prendre en otage. Le temps restant s'affiche en bas de l'écran ; il garde « (Nouveau) » dans son gamertag.", module = 'staff' },
    { tag = 'Nouveau', text = "Son véhicule (quand il conduit) traverse les autres joueurs et leurs véhicules : plus de « freekill » à la voiture.", module = 'staff' },
    { tag = 'Nouveau', text = "Le temps ne compte qu'en ville, personnage créé. Seuls les comptes arrivés après cette mise à jour sont protégés. Menu staff › un joueur › « Lever la protection nouveau ». Durée réglable (ou désactivée) dans Menu staff › Réglages.", module = 'staff' },
} })
N.Add({ id = 'patch280', date = '2026-11-04', title = "Patch notes 280 : garage posé en une fois", items = {
    { tag = 'Amélioré', text = "Builder : en posant un garage (public, d'entreprise, de gang ou un hélipad), le gardien se tient où tu es, puis un véhicule transparent te suit pour choisir tout de suite où sortent les véhicules (E pour poser). Plus besoin de poser la sortie à part.", module = 'carte' },
    { tag = 'Nouveau', text = "Builder › Existant › un garage public : « Où sortent les véhicules » pour la déplacer.", module = 'carte' },
} })
N.Add({ id = 'patch279', date = '2026-11-04', title = "Patch notes 279 : boutique refaite", items = {
    { tag = 'Amélioré', text = "Boutique refaite : onglets en haut (Accueil, catégories, Boutique du jour avec son minuteur, Panier), solde et « Quitter » à droite, offre phare, cartes avec rareté, réduction, stock restant et « 1 par joueur ».", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : panier (+ sur chaque carte), récapitulatif, confirmation, suggestions « Vous aimerez aussi ». Les achats du panier passent un par un, chacun revérifié par le serveur.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : fiche d'un article (caractéristiques, contenu, Acheter, Ajouter au panier, Offrir à un joueur), VIP présenté en paliers avec « Recommandé », fenêtre « Offrir à un joueur » qui dit combien il manque.", module = 'premium' },
} })
N.Add({ id = 'patch278', date = '2026-11-04', title = "Patch notes 278 : mises à jour automatiques", items = {
    { tag = 'Nouveau', text = "Mises à jour : « wupdate » dans la console (txAdmin) télécharge la nouvelle version, vérifie sa signature et son empreinte, installe les fichiers puis redémarre le serveur (compte à rebours de 60 s ; « wupdate 300 » = 5 minutes). Aussi dans le panel : Mises à jour › Installer et redémarrer.", module = 'updates' },
    { tag = 'Amélioré', text = "Rien n'est écrit si le téléchargement est abîmé ; pb_panel/config.lua, license.key et server.cfg ne sont jamais touchés.", module = 'updates' },
} })
N.Add({ id = 'patch277', date = '2026-11-04', title = "Patch notes 277 : diffusion vidéo", items = {
    { tag = 'Nouveau', text = "Menu staff › Gestion du serveur › Diffusion vidéo (fondateur uniquement) : une vidéo YouTube sur l'écran de tous les joueurs, en même temps. L'écran est bloqué, chacun règle son volume ; ceux qui arrivent pendant la diffusion la rejoignent au bon moment. Le fondateur l'arrête depuis son écran.", module = 'staff' },
} })
N.Add({ id = 'patch276', date = '2026-11-04', title = "Patch notes 276 : ventes par PNJ", items = {
    { tag = 'Nouveau', text = "Menu staff › Gestion du serveur › Ventes par PNJ uniquement : trois bascules (Concessions, Immobilier, Supérettes). Activées, plus de vendeur joueur : on achète seul. Décochées, les vendeurs reviennent.", module = 'shops' },
    { tag = 'Nouveau', text = "Builder › Immobilier › Agence immobilière (PNJ) : la liste des logements libres, le GPS et une visite de 15 minutes ; achat ou location à la porte.", module = 'housing' },
} })
N.Add({ id = 'patch275', date = '2026-11-04', title = "Patch notes 275 : pôle emploi", items = {
    { tag = 'Nouveau', text = "Builder › Services publics › Pôle emploi : un PNJ qui liste les emplois sans métier (bûcheron, mineur, chasseur, pêcheur, activités libres) et les entreprises qui recrutent. Choisir un emploi pose le GPS sur le guide le plus proche.", module = 'jobs' },
} })
N.Add({ id = 'patch274', date = '2026-11-04', title = "Patch notes 274 : Builder rangé", items = {
    { tag = 'Amélioré', text = "Builder rangé par thème, toujours dans le même ordre : Entreprises, Illégal, Commerces et banques, Véhicules, Immobilier et coffres, Emplois libres, Services publics, Loisirs, Bâtiments, Autres.", module = 'builder' },
    { tag = 'Corrigé', text = "Builder : les catégories changeaient d'ordre à chaque ouverture.", module = 'builder' },
} })
N.Add({ id = 'patch273', date = '2026-11-04', title = "Patch notes 273 : temps de service", items = {
    { tag = 'Nouveau', text = "Entreprises : chaque minute en service est comptée (l'employé ne voit rien). Le patron voit le temps de service de chacun (7 derniers jours et total) dans la tablette › Employés, et peut remettre les compteurs à zéro.", module = 'biz' },
} })
N.Add({ id = 'patch272', date = '2026-11-04', title = "Patch notes 272 : menu ALT et organisations", items = {
    { tag = 'Nouveau', text = "Menu ALT › Mon organisation : menu F7 complet, GPS du QG, coffre et caisse commune, en plus des actions sur une personne (ligoter, braquer, escorter…).", module = 'ctx' },
} })
N.Add({ id = 'patch271', date = '2026-11-04', title = "Patch notes 271 : braquage et otage", items = {
    { tag = 'Nouveau', text = "Braquage (mains en l'air) et otage escorté depuis le menu F7 ou ALT : E arrête l'action en cours. L'invite reste à l'écran tant que l'action dure.", module = 'orga' },
} })
N.Add({ id = 'patch270', date = '2026-11-04', title = "Patch notes 270 : territoires sur la carte", items = {
    { tag = 'Modifié', text = "Carte : une zone tenue porte le nom de l'organisation qui la tient ; une zone libre n'a plus de nom.", module = 'terr' },
} })
N.Add({ id = 'patch269', date = '2026-11-04', title = "Patch notes 269 : facture de l'atelier", items = {
    { tag = 'Amélioré', text = "Atelier : quand la customisation est validée, le menu « Envoyer la facture » s'ouvre tout seul avec les clients proches.", module = 'mech' },
} })
N.Add({ id = 'patch268', date = '2026-11-04', title = "Patch notes 268 : klaxons", items = {
    { tag = 'Corrigé', text = "Atelier : tous les klaxons sonnaient pareil (le klaxon d'origine était remis juste après) et le klaxon acheté n'était pas gardé. Chaque klaxon joue maintenant son son.", module = 'mech' },
} })
N.Add({ id = 'patch267', date = '2026-11-03', title = "Patch notes 267 : recrutement", items = {
    { tag = 'Amélioré', text = "Recrutement refait : une carte montre l'entreprise ou l'organisation, qui propose et le poste. Y pour accepter, N pour refuser.", module = 'general' },
    { tag = 'Corrigé', text = "Entreprises : on ne peut plus être engagé sans avoir accepté.", module = 'general' },
} })
N.Add({ id = 'patch266', date = '2026-11-03', title = "Patch notes 266 : retirer un PNJ", items = {
    { tag = 'Nouveau', text = "Staff : ALT sur un PNJ posé au Builder ou un vendeur de magasin permet de le retirer pour tout le monde, avec double confirmation.", module = 'general' },
} })
N.Add({ id = 'patch265', date = '2026-11-03', title = "Patch notes 265 : location et tenue de départ", items = {
    { tag = 'Amélioré', text = "Builder : en posant une location de véhicules, on choisit où les véhicules sortent. Modifiable ensuite dans la liste des points.", module = 'general' },
    { tag = 'Amélioré', text = "La tenue choisie à la création du personnage arrive dans l'inventaire, déjà portée : on peut l'enlever et la remettre.", module = 'general' },
} })
N.Add({ id = 'patch264', date = '2026-11-03', title = "Patch notes 264 : variantes des accessoires", items = {
    { tag = 'Corrigé', text = "Créateur de personnage : chapeaux, lunettes, oreilles, montres et bracelets ont maintenant leurs variantes de couleur.", module = 'general' },
} })
N.Add({ id = 'patch263', date = '2026-11-03', title = "Patch notes 263 : écran de la concession", items = {
    { tag = 'Amélioré', text = "Concession : même écran que les magasins, catégories à gauche, petites cartes, recherche sur tous les véhicules. Un clic ouvre la fiche du véhicule.", module = 'general' },
} })
N.Add({ id = 'patch262', date = '2026-11-03', title = "Patch notes 262 : PNJ et suppressions", items = {
    { tag = 'Corrigé', text = "Builder : le jeu ne devrait plus planter quand on place un PNJ.", module = 'general' },
    { tag = 'Amélioré', text = "Staff : double confirmation avant de supprimer un prop, un objet du décor, un point, une zone, un ascenseur ou un véhicule. « Annuler » est toujours en premier.", module = 'general' },
} })
N.Add({ id = 'patch261', date = '2026-11-03', title = "Patch notes 261 : concession", items = {
    { tag = 'Nouveau', text = "Concession : points « Catalogue véhicules » (autant qu'on veut), chacun avec l'endroit où les véhicules s'affichent. Les clients y regardent tous les véhicules.", module = 'general' },
    { tag = 'Nouveau', text = "Concession : « Poste du vendeur » à poser devant le comptoir. En service, E : vendre un véhicule au client, le faire essayer ou lui envoyer une facture.", module = 'general' },
} })
N.Add({ id = 'patch260', date = '2026-11-03', title = "Patch notes 260 : distributeurs du décor", items = {
    { tag = 'Nouveau', text = "Staff : ALT sur un distributeur de la carte permet de le retirer pour tout le monde, de le déplacer ou de le dupliquer, même s'il n'est pas dans la liste du Builder.", module = 'general' },
} })
N.Add({ id = 'patch259', date = '2026-11-03', title = "Patch notes 259 : carte, noclip, gamertags", items = {
    { tag = 'Corrigé', text = "Carte : le bureau de tabac et le magasin de meubles ont leur icône à eux, ils ne sont plus rangés sous le nom d'un autre magasin.", module = 'general' },
    { tag = 'Amélioré', text = "Barre des touches du noclip : plus de rectangle noir derrière.", module = 'general' },
    { tag = 'Corrigé', text = "Les gamertags et les textes du jeu ne se sélectionnent plus à la souris.", module = 'general' },
} })
N.Add({ id = 'patch258', date = '2026-11-03', title = "Patch notes 258 : magasins", items = {
    { tag = 'Corrigé', text = "Magasins : l'ancien écran avec les grosses catégories ne revient plus quand tu y retournes après un achat.", module = 'general' },
} })
N.Add({ id = 'patch257', date = '2026-11-03', title = "Patch notes 257 : touche pour fumer", items = {
    { tag = 'Corrigé', text = "Fumer : G et X répondent même si l'inventaire était ouvert ou si la touche a été changée dans GTA.", module = 'general' },
} })
N.Add({ id = 'patch256', date = '2026-11-03', title = "Patch notes 256 : bureau de tabac", items = {
    { tag = 'Nouveau', text = "Builder : un bureau de tabac à poser, avec cigarettes, paquets et vapoteuses.", module = 'general' },
} })
N.Add({ id = 'patch255', date = '2026-11-03', title = "Patch notes 255 : barre de vie", items = {
    { tag = 'Amélioré', text = "La barre de vie est collée sous la carte, de sa largeur, et plus épaisse.", module = 'general' },
} })
N.Add({ id = 'patch254', date = '2026-11-03', title = "Patch notes 254 : fumer et effets de drogue", items = {
    { tag = 'Nouveau', text = "Cigarette et vapoteuse : à fumer nature, ou avec ta weed ou un pochon de drogue. G pour tirer, X pour ranger.", module = 'general' },
    { tag = 'Nouveau', text = "Fumée visible par les joueurs proches, et un effet différent pour chaque drogue.", module = 'general' },
    { tag = 'Amélioré', text = "Inventaire : beaucoup de nouvelles images d'objets.", module = 'general' },
} })
N.Add({ id = 'patch253', date = '2026-11-03', title = "Patch notes 253 : établi d'armes", items = {
    { tag = 'Amélioré', text = "Nouvel écran de fabrication d'armes : fond plein, vraies images, couleur du serveur, et le bouton Fabriquer toujours visible.", module = 'general' },
} })
N.Add({ id = 'patch252', date = '2026-11-03', title = "Patch notes 252 : images manquantes", items = {
    { tag = 'Amélioré', text = "Inventaire : les objets sans image en ont une (outils, bûches, tabac, charbon, minerai d'argent…).", module = 'general' },
} })
N.Add({ id = 'patch251', date = '2026-11-03', title = "Patch notes 251 : images des drogues", items = {
    { tag = 'Amélioré', text = "Inventaire : nouvelles images pour le cannabis, la meth, l'ecstasy et l'héroïne, à la récolte et en pochon.", module = 'general' },
    { tag = 'Amélioré', text = "On récolte maintenant de la meth brute, de l'héroïne brute et de l'ecstasy brute.", module = 'general' },
} })
N.Add({ id = 'patch250', date = '2026-11-03', title = "Patch notes 250 : porte ou prop", items = {
    { tag = 'Corrigé', text = "ALT : un prop posé n'est plus pris pour une porte.", module = 'general' },
    { tag = 'Nouveau', text = "ALT sur un objet du décor pris pour une porte : tu choisis Porte, Déplacer, Dupliquer ou Retirer.", module = 'general' },
} })
N.Add({ id = 'patch249', date = '2026-11-03', title = "Patch notes 249 : images de la cocaïne", items = {
    { tag = 'Amélioré', text = "Cocaïne : on récolte maintenant de la coke brute (plus de feuilles), transformée en pochons. Nouvelles images dans l'inventaire.", module = 'general' },
} })
N.Add({ id = 'patch248', date = '2026-11-03', title = "Patch notes 248 : PNJ des points", items = {
    { tag = 'Nouveau', text = "Builder : après chaque point posé, choisis sans PNJ ou un style, avec aperçu, puis place-le toi-même. Aussi depuis les points déjà posés.", module = 'general' },
    { tag = 'Corrigé', text = "Location de véhicules : rangée dans Commerces, avec une icône différente de celle du concessionnaire.", module = 'general' },
} })
N.Add({ id = 'patch247', date = '2026-11-03', title = "Patch notes 247 : infos de capture", items = {
    { tag = 'Corrigé', text = "Capture de drapeau : les infos sont tout en bas à droite, et les munitions montent au-dessus à chaque ligne ajoutée.", module = 'general' },
} })
N.Add({ id = 'patch246', date = '2026-11-02', title = "Patch notes 246 : capture de drapeau", items = {
    { tag = 'Nouveau', text = "Points de vente : ALT sur le drapeau montre le bonus de vente, la durée de possession et le temps de capture, puis lance la capture.", module = 'general' },
    { tag = 'Amélioré', text = "Le drapeau est maintenant un vrai objet du jeu, sans mât ni tissu dessinés.", module = 'general' },
} })
N.Add({ id = 'patch245', date = '2026-11-02', title = "Patch notes 245 : zones du Builder", items = {
    { tag = 'Nouveau', text = "Builder, récolte, labo et vente de drogue : la zone ronde se voit avant de la poser (← → pour la taille).", module = 'general' },
    { tag = 'Nouveau', text = "Builder : zone tracée à la main, tu vas à chaque coin et tu appuies sur Entrée. Le E marche partout dedans.", module = 'general' },
} })
N.Add({ id = 'patch244', date = '2026-11-02', title = "Patch notes 244 : couleur du sélecteur", items = {
    { tag = 'Corrigé', text = "Sélecteur de personnage et écran d'entrée : ils restaient blancs, ils prennent la couleur du serveur.", module = 'general' },
} })
N.Add({ id = 'patch243', date = '2026-11-02', title = "Patch notes 243 : écran de connexion", items = {
    { tag = 'Amélioré', text = "Nouvel écran de connexion : fond flouté, logo et nom du serveur au centre, barre de chargement.", module = 'general' },
} })
N.Add({ id = 'patch242', date = '2026-11-02', title = "Patch notes 242 : coffres privés, inventaire", items = {
    { tag = 'Amélioré', text = "Coffres et garages d'entreprise et d'organisation : visibles par leurs membres seulement, staff compris.", module = 'general' },
    { tag = 'Corrigé', text = "Inventaire : la dernière rangée du coffre ne dépasse plus, et les raccourcis sont plus bas que les pieds du personnage.", module = 'general' },
} })
N.Add({ id = 'patch241', date = '2026-11-02', title = "Patch notes 241 : ALT sur les props", items = {
    { tag = 'Nouveau', text = "Staff : ALT sur un prop posé pour le déplacer, le dupliquer ou le retirer.", module = 'staff' },
} })
N.Add({ id = 'patch240', date = '2026-11-02', title = "Patch notes 240 : retirer des objets du décor", items = {
    { tag = 'Nouveau', text = "Builder › Existant › Objets du décor : vise un distributeur, une poubelle, une barrière… et retire-le pour tout le monde, puis remets-le quand tu veux.", module = 'general' },
} })
N.Add({ id = 'patch239', date = '2026-11-02', title = "Patch notes 239 : redémarrer pb_panel", items = {
    { tag = 'Corrigé', text = "Redémarrer pb_panel relance les ressources qui en dépendent (portes, activités…) : elles restaient arrêtées.", module = 'general' },
} })
N.Add({ id = 'patch238', date = '2026-11-02', title = "Patch notes 238 : menu ALT sur les objets au sol", items = {
    { tag = 'Corrigé', text = "Menu ALT : les objets posés au sol (enceintes, tables de mixage, distributeurs…) n'étaient pas cliquables.", module = 'general' },
} })
N.Add({ id = 'patch237', date = '2026-11-02', title = "Patch notes 237 : déplacer les props", items = {
    { tag = 'Nouveau', text = "Props : un prop déjà posé se déplace et se tourne (F10 › Props permanents › Props proches).", module = 'staff' },
    { tag = 'Amélioré', text = "Pose de props : Ctrl + ← → tourne à plat, et la visée porte jusqu'à 38 m.", module = 'staff' },
} })
N.Add({ id = 'patch236', date = '2026-11-02', title = "Patch notes 236 : droits des grades", items = {
    { tag = 'Nouveau', text = "Tablettes d'entreprise et d'organisation : les droits d'un grade se règlent avec des cases à cocher décrites.", module = 'general' },
    { tag = 'Nouveau', text = "Organisations : le chef peut donner à un grade le droit de recruter, exclure, gérer les grades, écrire à la famille ou retirer de la caisse.", module = 'general' },
} })
N.Add({ id = 'patch235', date = '2026-11-02', title = "Patch notes 235 : listes déroulantes", items = {
    { tag = 'Corrigé', text = "Toutes les listes déroulantes (tablettes, boutique, panel…) : plus de liste blanche illisible, elles suivent la couleur du serveur.", module = 'general' },
} })
N.Add({ id = 'patch234', date = '2026-11-02', title = "Patch notes 234 : menu entreprise", items = {
    { tag = 'Amélioré', text = "Menu entreprise : plus d'onglets Entreprises, Profil et Annonces. Les annonces sont sur l'accueil.", module = 'general' },
} })
N.Add({ id = 'patch233', date = '2026-11-02', title = "Patch notes 233 : musique sur les enceintes", items = {
    { tag = 'Nouveau', text = "Enceintes et pupitre DJ : ALT pour diffuser le son d'un lien YouTube ou Vimeo, sans l'image.", module = 'general' },
} })
N.Add({ id = 'patch232', date = '2026-11-02', title = "Patch notes 232 : case de tenue", items = {
    { tag = 'Nouveau', text = "Inventaire : une vraie case Tenue en haut. Glisse-y un sac de tenue, ou clique pour choisir parmi tes tenues.", module = 'general' },
} })
N.Add({ id = 'patch231', date = '2026-11-02', title = "Patch notes 231 : packs de vêtements", items = {
    { tag = 'Corrigé', text = "Magasin de vêtements : les vêtements ajoutés par un pack s'affichent, même sans photo.", module = 'general' },
} })
N.Add({ id = 'patch230', date = '2026-11-02', title = "Patch notes 230 : écran d'accueil", items = {
    { tag = 'Amélioré', text = "Écran d'accueil : « E Commencer » remonté sous le logo, logo rapproché du titre.", module = 'general' },
} })
N.Add({ id = 'patch229', date = '2026-11-02', title = "Patch notes 229 : couleurs, sélecteur de personnage", items = {
    { tag = 'Corrigé', text = "Carte, musique, menu F5 et autres écrans : le bleu et le violet en dur suivent la couleur du serveur. La banque reste verte et les vêtements rouges.", module = 'general' },
    { tag = 'Amélioré', text = "Sélecteur de personnage : suppression à part de « Entrer en ville », confirmation lisible et bouton rouge.", module = 'general' },
    { tag = 'Corrigé', text = "Anti-triche : plus d'alerte d'invincibilité pendant la création du personnage.", module = 'general' },
} })
N.Add({ id = 'patch228', date = '2026-11-02', title = "Patch notes 228 : touches liées deux fois", items = {
    { tag = 'Corrigé', text = "Menu staff et F5 : ils s'ouvraient et se refermaient aussitôt quand la touche était liée deux fois.", module = 'staff' },
} })
N.Add({ id = 'patch227', date = '2026-11-02', title = "Patch notes 227 : teinture d'armes VIP, mât des drapeaux", items = {
    { tag = 'Nouveau', text = "VIP : teinture de l'arme en main (or, platine, rose…), depuis F5 ou /teinture.", module = 'general' },
    { tag = 'Amélioré', text = "Drapeaux : le drapeau pend davantage et se cale au sommet du mât.", module = 'general' },
} })
N.Add({ id = 'patch226', date = '2026-11-02', title = "Patch notes 226 : drapeau comme sur la vidéo", items = {
    { tag = 'Amélioré', text = "Drapeaux : drapeau noir en haut du mât, halo blanc au pied, et en bas à droite l'état de la zone puis chaque groupe avec son effectif et sa progression.", module = 'general' },
} })
N.Add({ id = 'patch225', date = '2026-11-02', title = "Patch notes 225 : fiche d'article, drapeaux", items = {
    { tag = 'Nouveau', text = "Boutique : fiche d'article en pleine page (image, contenu, quantité, prix).", module = 'general' },
    { tag = 'Amélioré', text = "Drapeaux : halo au pied du mât, état de la zone et nombre de personnes en bas à droite.", module = 'general' },
} })
N.Add({ id = 'patch224', date = '2026-11-02', title = "Patch notes 224 : F5 instantané, corps entier dans l'inventaire", items = {
    { tag = 'Amélioré', text = "Menu F5 : il s'ouvre tout de suite, avec beaucoup moins de lectures en base.", module = 'personal' },
    { tag = 'Amélioré', text = "Carte et téléphone : moins de lectures en base.", module = 'general' },
    { tag = 'Nouveau', text = "Inventaire : au survol d'un joueur proche, son personnage entier s'affiche au centre.", module = 'general' },
} })
N.Add({ id = 'patch223', date = '2026-11-02', title = "Patch notes 223 : portraits de l'inventaire, menus plus rapides", items = {
    { tag = 'Corrigé', text = "Inventaire : les portraits des joueurs proches s'affichent à la place de l'icône.", module = 'general' },
    { tag = 'Amélioré', text = "Menu staff : il s'ouvre tout de suite, et beaucoup moins de lectures en base.", module = 'staff' },
    { tag = 'Amélioré', text = "Squelettes du staff plus fins.", module = 'staff' },
} })
N.Add({ id = 'patch222', date = '2026-11-02', title = "Patch notes 222 : une seule couleur, tenue, fenêtre de saisie", items = {
    { tag = 'Corrigé', text = "Plus de boutons roses : toutes les interfaces suivent la couleur principale du serveur.", module = 'general' },
    { tag = 'Nouveau', text = "Inventaire : icône en haut pour enlever ou remettre sa tenue.", module = 'general' },
    { tag = 'Amélioré', text = "Fenêtre de saisie (durée d'un ban, etc.) à droite du menu, à la même hauteur.", module = 'general' },
} })
N.Add({ id = 'patch221', date = '2026-11-02', title = "Patch notes 221 : choix du personnage", items = {
    { tag = 'Corrigé', text = "Les deux personnages du choix homme / femme ont les pieds au sol et la tête dans l'image.", module = 'general' },
    { tag = 'Corrigé', text = "Créateur : texte lisible sur la couleur du serveur, même quand elle est claire.", module = 'general' },
} })
N.Add({ id = 'patch220', date = '2026-11-02', title = "Patch notes 220 : viseur staff, invites, performances", items = {
    { tag = 'Corrigé', text = "Le viseur staff marche menu ouvert.", module = 'staff' },
    { tag = 'Corrigé', text = "Les invites E et de braquage ne montent plus en haut de l'écran.", module = 'general' },
    { tag = 'Amélioré', text = "Moins de travail à chaque image côté joueur, et le menu staff renvoie moins de données après chaque action.", module = 'general' },
} })
N.Add({ id = 'patch219', date = '2026-11-02', title = "Patch notes 219 : Discord obligatoire, gamertags, squelettes", items = {
    { tag = 'Amélioré', text = "Discord obligatoire : un onglet Vérification dit ce qui est vraiment appliqué, et un bouton teste un compte.", module = 'discordlink' },
    { tag = 'Amélioré', text = "Gamertags : portée de 120 m (jusqu'à 400 m), visibles à travers les murs, allumés dès la prise de service.", module = 'tags' },
    { tag = 'Corrigé', text = "Squelettes : affichés plus loin et plus nets, ils ne clignotent plus, à la couleur du serveur.", module = 'staff' },
} })
N.Add({ id = 'patch218', date = '2026-11-02', title = "Patch notes 218 : mini-écrans du staff", items = {
    { tag = 'Corrigé', text = "Observer (mini-écran) ne passe plus en plein écran sans prévenir : le menu dit ce qui manque.", module = 'staff' },
} })
N.Add({ id = 'patch217', date = '2026-11-02', title = "Patch notes 217 : barre de vie, inventaire d'un joueur, suppression de personnage", items = {
    { tag = 'Modifié', text = "Sous la carte : la barre verte et bleue laisse place à une ligne fine à la couleur du serveur. L'armure s'affiche à droite de la carte quand on en porte.", module = 'hud' },
    { tag = 'Modifié', text = "Voir l'inventaire d'un joueur ouvre son vrai inventaire. Seul le fondateur peut y prendre des objets.", module = 'staff' },
    { tag = 'Nouveau', text = "Le fondateur peut supprimer un de ses personnages depuis le sélecteur.", module = 'character' },
} })
N.Add({ id = 'patch216', date = '2026-11-02', title = "Patch notes 216 : portraits dans l'inventaire, fiche des points", items = {
    { tag = 'Nouveau', text = "Inventaire : le portrait des joueurs proches en bas à droite. Glisse un objet dessus pour le donner.", module = 'inv' },
    { tag = 'Modifié', text = "La fiche à côté d'un point du Builder est la même que la fiche Informations d'un joueur.", module = 'carte' },
} })
N.Add({ id = 'patch215', date = '2026-11-02', title = "Patch notes 215 : dossier des joueurs, fenêtre de saisie", items = {
    { tag = 'Nouveau', text = "Menu staff › Joueurs : recherche en ligne et hors ligne, avec un dossier complet et des actions sur les absents (note, argent, avertissement, prison, bannissement).", module = 'staff' },
    { tag = 'Amélioré', text = "La liste et la fiche d'un joueur montrent s'il est en prison et s'il a un ATA.", module = 'staff' },
    { tag = 'Modifié', text = "La fenêtre de saisie s'ouvre en haut, centrée sur le menu.", module = 'interface' },
} })
N.Add({ id = 'patch214', date = '2026-11-02', title = "Patch notes 214 : zones safe tracées, chat staff, Builder", items = {
    { tag = 'Nouveau', text = "Zones safe tracées coin par coin au Builder. Visibles seulement sur la grande carte, avec une notification à l'entrée et à la sortie.", module = 'wb_zonesafe' },
    { tag = 'Nouveau', text = "Chat staff avec le grade de chacun : bouton dans le chat ou /s message.", module = 'uikit' },
    { tag = 'Modifié', text = "Chat privé : seul celui qui écrit voit son message (réglable). Les annonces et le chat staff ne changent pas.", module = 'uikit' },
    { tag = 'Amélioré', text = "Builder : recherche dans Créer et dans Existant, sur tout l'onglet. Fiche sur le côté avec le nom complet et les infos du point. Noclip possible menu ouvert.", module = 'carte' },
    { tag = 'Corrigé', text = "La couleur choisie pour l'icône d'une entreprise n'est plus remplacée par le vert ou le rouge « ouvert / fermé ».", module = 'biz' },
    { tag = 'Modifié', text = "HUD staff et chat aux couleurs du serveur.", module = 'staff' },
} })
N.Add({ id = 'patch213', date = '2026-11-02', title = "Patch notes 213 : vêtements sans photo, touches, joueur à terre", items = {
    { tag = 'Corrigé', text = "Magasin de vêtements : les numéros sans photo, souvent vides ou invisibles, ne sont plus proposés. Réglable dans Magasins › Réglages.", module = 'shops' },
    { tag = 'Corrigé', text = "La touche E des interactions et le choix du personnage prennent la couleur du serveur.", module = 'general' },
    { tag = 'Corrigé', text = "Un joueur à terre reste au sol quand on le frappe.", module = 'general' },
} })
N.Add({ id = 'patch212', date = '2026-11-02', title = "Patch notes 212 : deux curseurs dans l'inventaire", items = {
    { tag = 'Corrigé', text = "Inventaire : un seul curseur à l'écran. Celui du jeu pouvait s'afficher en plus de celui de l'interface.", module = 'inventory' },
} })
N.Add({ id = 'patch211', date = '2026-11-02', title = "Patch notes 211 : pack de départ sur mesure", items = {
    { tag = 'Nouveau', text = "Pack sur mesure pour les organisations et les entreprises : armes, objets et véhicules choisis dans les listes, argent, et écriture à la main pour un nom précis. Au Builder et dans le panel.", module = 'biz' },
} })
N.Add({ id = 'patch210', date = '2026-11-02', title = "Patch notes 210 : graffitis, gibier, packs d'entreprise, radio", items = {
    { tag = 'Corrigé', text = "Graffitis : la pose était refusée (« Attends un peu ») si le menu venait d'être ouvert. Le délai ne compte plus qu'entre deux tags vraiment posés.", module = 'graffiti' },
    { tag = 'Amélioré', text = "Chasse : beaucoup plus d'animaux. Le gibier arrive vite dans une zone vide, jusqu'à 16 vivants par chasseur, et les carcasses ne bloquent plus les apparitions.", module = 'wb_chasse' },
    { tag = 'Nouveau', text = "Pack de départ pour les entreprises légales : 3 packs réglables (argent, objets, véhicules), au choix à la création ou après.", module = 'biz' },
    { tag = 'Modifié', text = "La radio s'achète dans les supérettes LTD (250 $) : il faut l'avoir sur soi pour s'en servir. Réglable dans le panel.", module = 'radio' },
} })
N.Add({ id = 'patch208', date = '2026-11-01', title = "Patch notes 208 : tablette de police (MDT)", items = {
    { tag = 'Nouveau', text = "Tablette de police (F6 ou /mdt, en service) : fenêtre très transparente tout en carrés et rectangles. Citoyens, plaques, appels, avis de recherche, rapports, unités et statuts 10-8, détenus, code pénal.", module = 'biz' },
    { tag = 'Nouveau', text = "Avis de recherche sur une personne ou une plaque, annoncés aux unités en service ; rapports liés à la fiche d'un citoyen.", module = 'biz' },
    { tag = 'Nouveau', text = "Entreprises › Réglages : activer la tablette et régler l'opacité de son fond (12 % par défaut).", module = 'biz' },
} })
