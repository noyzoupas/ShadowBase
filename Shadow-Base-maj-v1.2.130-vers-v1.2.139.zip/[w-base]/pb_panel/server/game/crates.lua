-- (patch 335) Caisses : on en gagne avec le temps de jeu, on les ouvre pour recevoir argent, objets, armes ou véhicules.
-- Tout est décidé par le serveur (tirage, retrait de la caisse, remise de la récompense). Réglages : panel › Caisses.
local G, DB, Form = PB.G, PB.DB, PB.Form
local C = {}
G.Crates = C

local DEF_CRATES = {
    { id = 'commune', label = 'Caisse commune', color = '#9aa4b2', drop = 80 },
    { id = 'rare', label = 'Caisse rare', color = '#4ea3ff', drop = 17 },
    { id = 'legendaire', label = 'Caisse légendaire', color = '#ffb43a', drop = 3 },
}
-- kind : money (qty = montant), bank (qty = montant), item (what = objet, qty = nombre), weapon (what = arme, qty = boîtes de munitions), vehicle (what = modèle)
local DEF_REWARDS = {
    { crate = 'commune', kind = 'money', what = '', qty = 500, label = '500 $', weight = 40 },
    { crate = 'commune', kind = 'money', what = '', qty = 1500, label = '1 500 $', weight = 20 },
    { crate = 'rare', kind = 'money', what = '', qty = 7500, label = '7 500 $', weight = 40 },
    { crate = 'rare', kind = 'vehicle', what = 'sultan', qty = 1, label = 'Sultan', weight = 10 },
    { crate = 'legendaire', kind = 'money', what = '', qty = 50000, label = '50 000 $', weight = 40 },
    { crate = 'legendaire', kind = 'vehicle', what = 'zentorno', qty = 1, label = 'Zentorno', weight = 5 },
}
PB.Cfg.Define('crates', { enabled = true, minutes = 60, max_per_player = 50, crates = DEF_CRATES, rewards = DEF_REWARDS })
local function cfg(k, d) return PB.Cfg.Get('crates', k, d) end

PB.Migrate('565_crates', 'Caisses : stock des joueurs et temps de jeu', {
    [[CREATE TABLE IF NOT EXISTS pb_crates (license VARCHAR(64) NOT NULL, crate VARCHAR(32) NOT NULL, qty INT NOT NULL DEFAULT 0, PRIMARY KEY (license, crate))]],
    [[CREATE TABLE IF NOT EXISTS pb_crate_time (license VARCHAR(64) NOT NULL PRIMARY KEY, secs INT NOT NULL DEFAULT 0)]],
})

local function crateList()
    local out = {}
    for _, c in ipairs(cfg('crates', DEF_CRATES) or {}) do
        local id = tostring(c.id or ''):lower():gsub('[^%w_]', '')
        if id ~= '' then out[#out + 1] = { id = id, label = tostring(c.label or id):sub(1, 40), color = tostring(c.color or ''):match('^#%x%x%x%x%x%x$') or '#9aa4b2', drop = math.max(0, tonumber(c.drop) or 0) } end
    end
    return out
end
local function crateOf(id) for _, c in ipairs(crateList()) do if c.id == id then return c end end end
local function rewardsOf(id)
    local out, tot = {}, 0
    for _, r in ipairs(cfg('rewards', DEF_REWARDS) or {}) do
        if tostring(r.crate or ''):lower() == id then
            local w = math.max(0, math.floor(tonumber(r.weight) or 0))
            if w > 0 then out[#out + 1] = { kind = tostring(r.kind or 'money'), what = tostring(r.what or ''), qty = math.max(1, math.floor(tonumber(r.qty) or 1)), label = tostring(r.label or r.what or ''):sub(1, 40), weight = w } tot = tot + w end
        end
    end
    return out, tot
end
local function pickReward(list, tot)
    local n = math.random(1, tot)
    for _, r in ipairs(list) do n = n - r.weight if n <= 0 then return r end end
    return list[#list]
end

function C.Count(license, id)
    local r = DB.one('SELECT qty FROM pb_crates WHERE license = ? AND crate = ?', { license, id })
    return r and tonumber(r.qty) or 0
end
function C.Total(license)
    local r = DB.one('SELECT COALESCE(SUM(qty), 0) AS n FROM pb_crates WHERE license = ?', { license })
    return r and tonumber(r.n) or 0
end
function C.Give(license, id, qty)
    qty = math.floor(tonumber(qty) or 0)
    if qty <= 0 or not crateOf(id) then return false end
    DB.exec('INSERT INTO pb_crates (license, crate, qty) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE qty = qty + ?', { license, id, qty, qty })
    return true
end
local function srcOfLicense(lic) for id, p in pairs(G.Players()) do if p.license == lic then return id end end end

-- remise de la récompense : renvoie true, ou false + raison (la caisse n'est alors pas consommée)
local function deliver(src, r)
    local p = G.Get(src)
    if not p then return false, 'Joueur introuvable.' end
    if r.kind == 'money' or r.kind == 'bank' then
        return G.AddMoney(src, r.kind == 'bank' and 'bank' or 'cash', r.qty, 'Caisse')
    elseif r.kind == 'item' then
        if not PB.Inv.Give(src, r.what, r.qty) then return false, "Ton inventaire est plein ou trop lourd : fais de la place puis réessaie." end
        return true
    elseif r.kind == 'weapon' then
        if G.SyncArmory then pcall(G.SyncArmory, { { type = 'weapon', name = r.what, label = r.label } }) end
        if not PB.Inv.Give(src, r.what, 1) then return false, "Ton inventaire est plein ou trop lourd : fais de la place puis réessaie." end
        return true
    elseif r.kind == 'vehicle' then
        local m = r.what:lower()
        if not m:match('^[%w_]+$') then return false, 'Récompense mal réglée.' end
        local plate
        for _ = 1, 30 do
            local x = ('CA%06d'):format(math.random(0, 999999))
            if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { x }) then plate = x break end
        end
        if not plate then return false, 'Réessaie.' end
        DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price, vtype) VALUES (?, ?, ?, ?, ?, ?, ?)', { p.license, plate, m, r.label ~= '' and r.label or m, os.time(), 0, G.Garage and G.Garage.CleanVT and G.Garage.CleanVT(nil, m) or '' })
        return true
    end
    return false, 'Récompense inconnue.'
end

local function listFor(license)
    local out = {}
    for _, c in ipairs(crateList()) do
        local n = C.Count(license, c.id)
        local rw = {}
        for _, r in ipairs(rewardsOf(c.id)) do rw[#rw + 1] = r.label end
        out[#out + 1] = { id = c.id, label = c.label, color = c.color, qty = n, rewards = rw }
    end
    return out
end
RegisterNetEvent('pb:g:crates:list', function()
    local src = source
    local p = G.Get(src)
    if not p or not p.license then return end
    TriggerClientEvent('pb:g:crates:list', src, PB.Json({ crates = listFor(p.license), minutes = tonumber(cfg('minutes', 60)) or 60 }))
end)

local opening = {}
RegisterNetEvent('pb:g:crates:open', function(id)
    local src = source
    local p = G.Get(src)
    id = tostring(id or ''):lower()
    if not p or not p.license or cfg('enabled', true) == false or opening[src] then return end
    local c = crateOf(id)
    if not c then return end
    opening[src] = true
    local ok, err = pcall(function()
        if C.Count(p.license, id) < 1 then G.Notify(src, { type = 'warn', title = 'Caisses', text = "Tu n'as pas cette caisse." }) return end
        local list, tot = rewardsOf(id)
        if tot <= 0 then G.Notify(src, { type = 'warn', title = 'Caisses', text = "Cette caisse est vide (aucune récompense réglée)." }) return end
        local win = pickReward(list, tot)
        local done, why = deliver(src, win)
        if not done then G.Notify(src, { type = 'warn', title = 'Caisses', text = why or 'Impossible de donner la récompense.' }) return end
        DB.exec('UPDATE pb_crates SET qty = GREATEST(qty - 1, 0) WHERE license = ? AND crate = ?', { p.license, id })
        -- bande de défilement : 40 tirages, la récompense gagnée à la position 35
        local strip = {}
        for i = 1, 40 do local r = i == 35 and win or pickReward(list, tot) strip[i] = { label = r.label, kind = r.kind } end
        TriggerClientEvent('pb:g:crates:result', src, PB.Json({ crate = c.label, color = c.color, strip = strip, at = 35, win = { label = win.label, kind = win.kind } }))
        if PB.Audit and PB.Audit.Log then pcall(PB.Audit.Log, 'economy', 'crates.open', { src = src, license = p.license }, id .. ' → ' .. win.kind .. ':' .. win.what .. 'x' .. win.qty, nil, { crate = id, kind = win.kind, what = win.what, qty = win.qty }) end
    end)
    opening[src] = nil
    if not ok then print('[Shadow Base] caisses : ' .. tostring(err)) end
end)

-- temps de jeu : une caisse toutes les N minutes passées en ville
local acc = {}
local function pickDropped()
    local all, tot = {}, 0
    for _, c in ipairs(crateList()) do if c.drop > 0 then all[#all + 1] = c tot = tot + c.drop end end
    if tot <= 0 then return nil end
    local n = math.random(1, math.floor(tot))
    for _, c in ipairs(all) do n = n - c.drop if n <= 0 then return c end end
    return all[#all]
end
CreateThread(function()
    Wait(20000)
    while true do
        Wait(60000)
        local every = math.max(5, math.floor(tonumber(cfg('minutes', 60)) or 60)) * 60
        if cfg('enabled', true) ~= false then
            for src, p in pairs(G.Players()) do
                local lic = p.license
                if lic then
                    if acc[lic] == nil then local r = DB.one('SELECT secs FROM pb_crate_time WHERE license = ?', { lic }) acc[lic] = r and tonumber(r.secs) or 0 end
                    acc[lic] = acc[lic] + 60
                    if acc[lic] >= every then
                        acc[lic] = acc[lic] - every
                        if C.Total(lic) < (tonumber(cfg('max_per_player', 50)) or 50) then
                            local c = pickDropped()
                            if c and C.Give(lic, c.id, 1) then
                                G.Notify(src, { type = 'success', title = 'Nouvelle caisse !', text = ('Tu as gagné : %s. Ouvre-la avec /caisses.'):format(c.label), duration = 9000 })
                            end
                        end
                    end
                    DB.exec('INSERT INTO pb_crate_time (license, secs) VALUES (?, ?) ON DUPLICATE KEY UPDATE secs = ?', { lic, acc[lic], acc[lic] })
                end
            end
        end
    end
end)
AddEventHandler('playerDropped', function() local p = G.Get(source) if p and p.license then acc[p.license] = nil end opening[source] = nil end)

-- /givecaisse <id joueur> <caisse> [nombre] : console ou staff avec le droit « objets »
RegisterCommand('givecaisse', function(src, a)
    if src ~= 0 and not PB.Perm.Has(src, 'staff.items') then return end
    local t, id, n = tonumber(a[1]), tostring(a[2] or ''):lower(), math.max(1, math.floor(tonumber(a[3]) or 1))
    local p = t and G.Get(t)
    local function say(m) if src == 0 then print(m) else G.Notify(src, { type = 'info', title = 'Caisses', text = m }) end end
    if not p or not p.license then return say('Joueur introuvable : /givecaisse <id> <caisse> [nombre]') end
    if not crateOf(id) then return say('Caisse inconnue : ' .. id) end
    C.Give(p.license, id, n)
    G.Notify(t, { type = 'success', title = 'Caisse reçue', text = ('%d × %s. Ouvre-les avec /caisses.'):format(n, crateOf(id).label) })
    say(('%d × %s donné(es).'):format(n, id))
end, false)
exports('GiveCrate', function(license, id, qty) return C.Give(tostring(license), tostring(id):lower(), qty) end)

-- Panel
local settings = Form.Cfg({ ns = 'crates', id = 'settings', title = 'Caisses', perm = 'garage.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Caisses activées', default = true },
    { k = 'minutes', type = 'number', label = 'Une caisse toutes les … minutes de jeu', default = 60, min = 5, max = 1440 },
    { k = 'max_per_player', type = 'number', label = 'Caisses non ouvertes maximum par joueur', default = 50, min = 1, max = 1000 },
    { k = 'crates', type = 'rows', label = 'Types de caisses (chance = poids du tirage quand une caisse est gagnée au temps de jeu ; 0 = jamais gagnée, donnée seulement par /givecaisse)', default = DEF_CRATES, wide = true, maxitems = 12,
      cols = { { k = 'id', label = 'Identifiant', maxlen = 24, pattern = '^[%w_]+$', lower = true, required = true }, { k = 'label', label = 'Nom', maxlen = 40, required = true }, { k = 'color', label = 'Couleur (#rrggbb)', maxlen = 7, pattern = '^#%x%x%x%x%x%x$' }, { k = 'drop', label = 'Chance', type = 'number', min = 0, max = 1000 } } },
    { k = 'rewards', type = 'rows', label = "Récompenses : type = money (argent liquide), bank (banque), item (objet), weapon (arme), vehicle (véhicule). « Contenu » = objet, arme ou modèle ; « Quantité » = montant ou nombre. Poids : plus il est grand, plus c'est fréquent.", default = DEF_REWARDS, wide = true, maxitems = 120,
      cols = { { k = 'crate', label = 'Caisse', maxlen = 24, pattern = '^[%w_]+$', lower = true, required = true }, { k = 'kind', label = 'Type', maxlen = 8, pattern = '^[a-z]+$', required = true }, { k = 'what', label = 'Contenu', maxlen = 40 },
        { k = 'qty', label = 'Quantité', type = 'number', min = 1, max = 100000000 }, { k = 'label', label = 'Nom affiché', maxlen = 40, required = true }, { k = 'weight', label = 'Poids', type = 'number', min = 0, max = 10000 } } },
} })
PB.Module({
    id = 'crates', label = 'Caisses', icon = 'gift', group = 'Serveur', order = 97, perm = 'garage.view', hint = 'Caisses gagnées au temps de jeu',
    caps = function()
        return PB.Capsify({
            { 'Caisses gagnées au temps de jeu', 'ok', 'Une toutes les N minutes en ville ; le type est tiré selon la chance de chaque caisse.' },
            { 'Ouverture avec animation (/caisses)', 'ok', 'Tirage, retrait de la caisse et remise de la récompense faits par le serveur.' },
            { 'Argent, objets, armes, véhicules', 'ok', "Un véhicule gagné arrive au garage du joueur. Si l'inventaire est plein, la caisse n'est pas consommée." },
            { 'Boutique avec argent réel', 'off', 'Non prévu.' },
        })
    end,
    doc = "## Caisses\nLes joueurs gagnent des caisses avec leur temps de jeu et les ouvrent avec **/caisses**. Règle ici la fréquence, les types de caisses et leur contenu.\n\n`/givecaisse <id> <caisse> [nombre]` (console ou staff) en donne ; `exports.pb_panel:GiveCrate(licence, caisse, nombre)` pour tes scripts.",
    view = function(ctx) return { tabs = { { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end } } } end,
})
