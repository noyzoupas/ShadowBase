/* (patch 338) Ouverture d'une caisse : la caisse tombe, s'ouvre (couvercle + lumière), puis les lots tournent en anneau 3D et s'arrêtent sur le gain.
   Jeu → NUI : G.send('crates.open', { crate, color, strip: [{label, kind}], at, win: {label, kind} }). Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let box = null, timers = [];
const KIND = { money: 'Argent', bank: 'Banque', item: 'Objet', weapon: 'Arme', vehicle: 'Véhicule' };
const T_SPIN = 4800;
function later(fn, ms) { timers.push(setTimeout(fn, ms)); }
function drop() { timers.forEach(clearTimeout); timers = []; if (box) { box.remove(); box = null; } }
function face(cls, kids) { return h('div', { class: 'cr-f ' + cls }, kids || null); }
G.on('crates.open', function (d) {
  drop();
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color) ? d.color : '#00f895';
  const strip = Array.isArray(d.strip) ? d.strip : [];
  const win = (d.win && typeof d.win === 'object') ? d.win : { label: '?', kind: 'item' };
  /* anneau : le gain + des lots différents pris dans la bande */
  const seen = { [win.label]: 1 }, pool = [];
  strip.forEach((r) => { if (r && !seen[r.label]) { seen[r.label] = 1; pool.push(r); } });
  for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
  const N = 10, ring = pool.slice(0, N - 1);
  while (ring.length < N - 1) ring.push({ label: '???', kind: 'item' });
  const k = Math.floor(Math.random() * N);
  ring.splice(k, 0, win);
  const step = 360 / N, R = 250;
  const cards = ring.map((r, i) => h('div', { class: 'cr-k', style: { transform: 'rotateY(' + (i * step) + 'deg) translateZ(' + R + 'px)' } },
    h('div', { class: 'cr-ki' }, h('small', null, KIND[r.kind] || ''), h('b', null, String(r.label || '')))));
  const ringEl = h('div', { class: 'cr-ring' }, cards);
  const lid = h('div', { class: 'cr-lid' }, h('div', { class: 'cr-lp' }, h('i', null)));
  const crate = h('div', { class: 'cr-crate' }, [
    face('fr', h('b', null, String(d.crate || 'Caisse'))), face('bk'), face('lf'), face('rt'), face('bt'),
    h('div', { class: 'cr-in' }), lid]);
  const res = h('div', { class: 'cr-res' }, h('small', null, String(d.crate || 'Caisse')), h('b', null, String(win.label || '')), h('em', null, KIND[win.kind] || ''));
  box = h('div', { id: 'g-crates', style: { '--cc': col } }, [
    h('div', { class: 'cr-beam' }),
    h('div', { class: 'cr-scene' }, [h('div', { class: 'cr-cw' }, crate), h('div', { class: 'cr-rw' }, ringEl)]),
    res]);
  G.root.appendChild(box);
  const set = (c) => { if (box) box.classList.add(c); };
  later(() => set('s-drop'), 30);
  later(() => set('s-shake'), 900);
  later(() => set('s-open'), 1900);
  later(() => {
    set('s-ring');
    ringEl.style.transition = 'transform ' + T_SPIN + 'ms cubic-bezier(.1,.62,.1,1)';
    ringEl.style.transform = 'rotateY(' + (-(k * step) - 360 * 4) + 'deg)';
  }, 3200);
  later(() => { set('s-win'); cards[k].classList.add('on'); }, 3200 + T_SPIN + 150);
  later(drop, 3200 + T_SPIN + 150 + 6500);
});
G.on('crates.close', drop);
})();
