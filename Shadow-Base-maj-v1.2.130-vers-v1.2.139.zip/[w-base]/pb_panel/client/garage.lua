-- Garages et fourrière : blips, marqueurs, menu (E à pied), rangement (E en véhicule), apparition des véhicules, verrouillage (touche réglable).
local G = PBG
local isOpen = false
local points, blips = {}, {}
local locked = {}

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if G.garageMenuEnd then G.garageMenuEnd() end
    if not isOpen then return end
    isOpen = false
    TriggerServerEvent('pb:g:garage:close')
    G.focus(false)
    G.send('garage.close', {})
end

-- Garage en menu lib : la liste des véhicules ; en descendant sur un véhicule, il apparaît en transparence à la sortie du garage
-- (aperçu local, invisible pour les autres) avec une caméra dessus. « Clés », « Organisation » et « Entreprise » sont aussi des
-- sous-menus (plus aucune fenêtre). Le joueur est figé tant que le menu du garage est ouvert.
local menuOn, nuiOn, frameD, rowsD, wantNui, leaving = false, false, nil, {}, false, false
local libPage, libLabel = nil, nil
local frozen = false
local function freeze(on)
    if frozen == on then return end
    frozen = on
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then FreezeEntityPosition(ped, on) elseif not on then FreezeEntityPosition(ped, false) end
end
local preview, previewKey, cam
local pgen = 0   -- (patch 330) génération : un aperçu créé après la fermeture du menu se supprime tout seul
local function killVeh(v)
    if v and DoesEntityExist(v) then
        SetEntityAsMissionEntity(v, true, true)
        DeleteVehicle(v)
        if DoesEntityExist(v) then DeleteEntity(v) end
    end
end
local function stopPreview()
    pgen = pgen + 1
    killVeh(preview)
    preview, previewKey = nil, nil
end
local function stopCam()
    if cam then RenderScriptCams(false, true, 400, true, true) DestroyCam(cam, false) cam = nil end
end
local function showPreview(r)
    local sp = frameD and frameD.spawn
    if not r or not sp or not r.model then stopPreview() return end
    if not menuOn then return end
    if previewKey == r.plate then return end
    stopPreview()
    previewKey = r.plate
    local gen = pgen
    CreateThread(function()
        local hash = GetHashKey(r.model)
        if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then return end
        RequestModel(hash)
        local t = GetGameTimer() + 3000
        while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
        if previewKey ~= r.plate or gen ~= pgen or not menuOn or not HasModelLoaded(hash) then return end
        local v = CreateVehicle(hash, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, (sp.h or 0) + 0.0, false, false)   -- local : personne d'autre ne le voit
        SetModelAsNoLongerNeeded(hash)
        if previewKey ~= r.plate or gen ~= pgen or not menuOn then killVeh(v) return end
        preview = v
        SetVehicleOnGroundProperly(v)
        SetEntityCollision(v, false, false)
        FreezeEntityPosition(v, true)
        SetEntityAlpha(v, 165, false)
        SetVehicleNumberPlateText(v, r.plate)
        SetVehicleDoorsLocked(v, 2)
        if r.c1 and r.c2 then SetVehicleColours(v, math.floor(r.c1), math.floor(r.c2)) end
        if not cam then
            local h = math.rad((sp.h or 0) + 35.0)
            cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
            SetCamCoord(cam, sp.x - math.sin(h) * 6.0, sp.y + math.cos(h) * 6.0, sp.z + 1.6)
            PointCamAtCoord(cam, sp.x + 0.0, sp.y + 0.0, sp.z + 0.4)
            SetCamFov(cam, 50.0)
            RenderScriptCams(true, true, 500, true, true)
        end
    end)
end
local function endMenu(keepSession)
    menuOn = false
    libPage = nil
    stopPreview() stopCam()
    freeze(false)
    if not keepSession and not nuiOn then TriggerServerEvent('pb:g:garage:close') end
end
local function rowsOf(page)
    for _, b in ipairs((page and page.blocks) or {}) do if b.type == 'table' then return b.rows or {} end end
    return {}
end
local function openMenu(sel)
    local items = {}
    if #rowsD == 0 then items[1] = { label = 'Aucun véhicule ici', icon = 'car', disabled = true, description = 'Achète un véhicule à la concession.' } end
    for i, r in ipairs(rowsD) do
        local acts = {}
        for _, a in ipairs(r.actions or {}) do
            acts[#acts + 1] = { label = a.label, icon = a.act == 'take' and 'car' or a.act == 'recover' and 'key' or a.act == 'locate' and 'gps' or 'check',
                onSelect = function() leaving = (a.act == 'take' or a.act == 'recover') TriggerServerEvent('pb:g:garage:act', a.act, a.payload or {}, 'cars') end }
        end
        if #acts == 0 then acts[1] = { label = r.where ~= '' and r.where or 'Rien à faire ici', icon = 'info', disabled = true } end
        items[#items + 1] = { type = 'submenu', label = r.label or r.plate, icon = 'car', right = r.state, row = r, idx = i,
            description = (r.plate or '') .. (r.fuel and (' · ' .. r.fuel) or '') .. (r.health and (' · ' .. r.health) or ''),
            submenu = { id = 'garage.car', title = r.label or r.plate, subtitle = r.plate, items = acts } }
    end
    for _, n in ipairs((frameD and frameD.nav) or {}) do
        if n.id ~= 'cars' then
            items[#items + 1] = { label = n.label, icon = n.icon == 'lock' and 'key' or 'users', description = n.id == 'keys' and 'Donner, prêter ou rendre une clé.' or 'Véhicules partagés.', onSelect = function()
                stopPreview()
                libPage, libLabel = n.id, n.label
                TriggerServerEvent('pb:g:garage:page', n.id)
            end }
        end
    end
    menuOn = true
    freeze(true)
    G.Menu.Open({ id = 'garage', title = (frameD and frameD.brand) or 'Garage', subtitle = frameD and frameD.impound and 'Fourrière' or 'Mes véhicules', banner = { text = frameD and frameD.impound and 'Fourrière' or 'Garage' }, items = items, sel = sel,
        onHover = function(it) if it and it.row then showPreview(it.row) else stopPreview() end end,
        onOpen = function(m) local it = m.items and m.items[m.sel or 1] if it and it.row then showPreview(it.row) end end,
        onClose = function() if menuOn then endMenu(false) end end })
end

G.garageMenuEnd = function() if menuOn then menuOn = false G.Menu.Close() end libPage = nil stopPreview() stopCam() freeze(false) nuiOn = false end

-- page « Clés » / « Organisation » / « Entreprise » : les blocs du serveur deviennent un sous-menu
local function libDef(pg)
    local name = libPage
    return { id = 'garage.' .. tostring(name), title = libLabel or 'Garage', subtitle = frameD and frameD.brand or nil,
        items = G.Menu.FromBlocks(pg and pg.blocks or {}, function(act, payload) TriggerServerEvent('pb:g:garage:act', act, payload, name) end, 'garage.' .. tostring(name)),
        onClose = function() if libPage == name then libPage = nil end end }
end

RegisterNetEvent('pb:g:garage:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.frame then frameD = d.frame end
    -- sous-menu (clés, organisation, entreprise) demandé depuis le menu
    if menuOn and libPage and d.page and d.page.page == libPage and (d.ev == 'page' or d.ev == 'result') then
        if d.ev == 'result' and d.msg then G.send('notify', { type = d.ok and 'success' or 'error', title = (frameD and frameD.brand) or 'Garage', text = d.msg }) end
        local top = G.Menu.Stack:Current()
        if d.ev == 'page' and not (top and top.def and top.def.id == 'garage.' .. libPage) then G.Menu.Push(libDef(d.page))
        else
            -- après une action : on revient à la page mise à jour (au bon niveau)
            while G.Menu.Stack:Depth() > 1 and not (G.Menu.Stack:Current().def.id == 'garage.' .. libPage) do table.remove(G.Menu.Stack.menus) end
            G.Menu.Replace(libDef(d.page))
        end
        return
    end
    if d.ev == 'page' and d.err then G.send('notify', { type = 'error', title = 'Garage', text = d.err }) return end
    if d.ev == 'open' then
        if isOpen or menuOn or busy() then TriggerServerEvent('pb:g:garage:close') return end
        rowsD = rowsOf(d.page)
        openMenu()
        return
    end
    if menuOn and d.page and d.page.page == 'cars' then
        if d.ev == 'result' and d.msg then G.send('notify', { type = d.ok and 'success' or 'error', title = (frameD and frameD.brand) or 'Garage', text = d.msg }) end
        -- véhicule sorti : le menu se ferme (le joueur est mis au volant) ; sinon la liste se met à jour
        if leaving and d.ok then leaving = false endMenu(false) G.Menu.Close() return end
        leaving = false
        rowsD = rowsOf(d.page)
        menuOn = false            -- fermeture sans quitter la session du garage
        G.Menu.Close()
        stopPreview()
        openMenu()
        return
    end
    if not isOpen then return end
    G.send('garage.' .. tostring(d.ev), d)
end)
G.nui['garage.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:garage:page', tostring(d.page or 'cars')) end return {} end
G.nui['garage.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:garage:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'cars')) end return {} end
G.nui['garage.close'] = function() close() return {} end

local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', '') end

local function props(veh)
    local c1, c2 = GetVehicleColours(veh)
    if G.VehProps then return G.VehProps(veh) end
    local fuel = GetVehicleFuelLevel and GetVehicleFuelLevel(veh) or 100.0
    return { eh = GetVehicleEngineHealth(veh), bh = GetVehicleBodyHealth(veh), th = GetVehiclePetrolTankHealth(veh), fuel = fuel, c1 = c1, c2 = c2, dirt = GetVehicleDirtLevel(veh) }
end

local function spawnFail(d, why)
    close()
    freeze(false)
    G.send('notify', { type = 'error', title = 'Garage', text = why .. ' Le véhicule reste au garage.' })
    TriggerServerEvent('pb:g:veh:spawnfail', d.plate)
end
RegisterNetEvent('pb:g:veh:spawn', function(j)
    local d = G.decode(j)
    if not d then return end
    if G.garageMenuEnd then G.garageMenuEnd() end   -- le menu se ferme tout de suite : plus de menu bloqué pendant le chargement
    local hash = GetHashKey(d.model)
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then spawnFail(d, ('Modèle « %s » introuvable sur ce serveur.'):format(tostring(d.model))) return end
    RequestModel(hash)
    local t = GetGameTimer()
    while not HasModelLoaded(hash) and GetGameTimer() - t < 8000 do Wait(10) end
    if not HasModelLoaded(hash) then spawnFail(d, 'Le modèle du véhicule ne se charge pas.') return end
    local sp = d.spawn or {}
    if not sp.x then spawnFail(d, 'Sortie du garage introuvable.') return end
    -- la sortie peut être loin (fourrière) : on y amène d'abord le joueur, puis on dégage la place
    local ped = PlayerPedId()
    if #(GetEntityCoords(ped) - vector3(sp.x + 0.0, sp.y + 0.0, sp.z + 0.0)) > 60.0 then
        SetEntityCoords(ped, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, false, false, false, false)
        local tc = GetGameTimer() + 3000
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < tc do Wait(0) end
    end
    ClearAreaOfVehicles(sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, 3.0, false, false, false, false, false)
    local veh = CreateVehicle(hash, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, (sp.h or 0) + 0.0, true, false)
    local te = GetGameTimer() + 3000
    while not DoesEntityExist(veh) and GetGameTimer() < te do Wait(0) end
    if not DoesEntityExist(veh) then SetModelAsNoLongerNeeded(hash) spawnFail(d, "Le véhicule n'a pas pu apparaître (place occupée ou serveur qui refuse).") return end
    SetEntityAsMissionEntity(veh, true, true)
    ResetEntityAlpha(veh) SetEntityCollision(veh, true, true) FreezeEntityPosition(veh, false)   -- jamais un véhicule fantôme
    SetVehicleHasBeenOwnedByPlayer(veh, true)
    SetVehicleNumberPlateText(veh, d.plate)
    SetVehicleOnGroundProperly(veh)
    local p = d.props
    if p then
        if p.c1 and p.c2 then SetVehicleColours(veh, math.floor(p.c1), math.floor(p.c2)) end
        if p.eh then SetVehicleEngineHealth(veh, p.eh + 0.0) end
        if p.bh then SetVehicleBodyHealth(veh, p.bh + 0.0) end
        if p.th then SetVehiclePetrolTankHealth(veh, p.th + 0.0) end
        if p.fuel and SetVehicleFuelLevel then SetVehicleFuelLevel(veh, p.fuel + 0.0) end
        if p.dirt then SetVehicleDirtLevel(veh, p.dirt + 0.0) end
        if G.ApplyMods and type(p.mods) == 'table' then G.ApplyMods(veh, p.mods) end
        if G.ApplyCustom and type(p.mods) == 'table' and type(p.mods.custom) == 'table' then
            local custom = p.mods.custom
            G.ApplyCustom(veh, custom)
            -- un véhicule tout juste créé (surtout un addon) n'a pas toujours fini de charger ses pièces : on repasse une fois, puis les dégâts
            CreateThread(function() Wait(1500) if DoesEntityExist(veh) then G.ApplyCustom(veh, custom) end end)
        end
        -- peinture caméléon (VIP) : remise à la sortie du garage tant que le propriétaire est VIP
        if G.vip == true and type(p.mods) == 'table' and (tonumber(p.mods.cham) or 0) > 0 then Entity(veh).state:set('pb_cham', tonumber(p.mods.cham), true) end
        -- vraie peinture caméléon (VIP) : remise à la sortie ; sans VIP (ou sans le mod), retour à une couleur normale plutôt qu'une carrosserie noire
        local vp = type(p.mods) == 'table' and tonumber(p.mods.champ) or 0
        if vp > 0 then
            SetVehicleModKit(veh, 0)
            if G.vip == true and (vp <= 222 or GetResourceState('spchameleon') == 'started') then SetVehicleColours(veh, vp, vp) else SetVehicleColours(veh, 0, 0) end
        end
        if G.ApplyDamage then G.ApplyDamage(veh, p) end
    end
    SetModelAsNoLongerNeeded(hash)
    -- directement au volant (on réessaie : le véhicule réseau peut mettre un instant à être prêt)
    for _ = 1, 20 do
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        Wait(50)
        if GetVehiclePedIsIn(PlayerPedId(), false) == veh then break end
    end
    TriggerServerEvent('pb:g:veh:spawned', d.plate, NetworkGetNetworkIdFromEntity(veh))
    close()
end)
RegisterNetEvent('pb:g:veh:stored', function(plate)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and plateOf(veh) == plate then TaskLeaveVehicle(ped, veh, 0) Wait(900) SetEntityAsMissionEntity(veh, true, true) DeleteVehicle(veh) end
end)

-- Verrouillage
RegisterNetEvent('pb:g:veh:lockState', function(j)
    local d = G.decode(j)
    if not d then return end
    locked[d.plate] = d.locked
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local veh = GetClosestVehicle(c.x, c.y, c.z, 60.0, 0, 71)
    if veh ~= 0 and plateOf(veh) == d.plate then
        SetVehicleDoorsLocked(veh, d.locked and 2 or 1)
        SetVehicleDoorsLockedForAllPlayers(veh, d.locked)
        StartVehicleHorn(veh, 80, GetHashKey('HELDDOWN'), false)
        SetVehicleLights(veh, 2) Wait(180) SetVehicleLights(veh, 0)
    end
end)
RegisterCommand('pb_lock', function()
    if busy() or not G.begun then return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    local c = GetEntityCoords(ped)
    if veh == 0 then veh = GetClosestVehicle(c.x, c.y, c.z, (G.cfg.garage and G.cfg.garage.lock_dist or 6) + 0.0, 0, 71) end
    if veh ~= 0 then TriggerServerEvent('pb:g:veh:lock', plateOf(veh), NetworkGetNetworkIdFromEntity(veh)) end
end, false)

local prev = G.onCfg
local allPoints, myGang, lastCfg = {}, '', nil
-- Les garages de gang ne sont visibles (blip, marqueur, touche E) que par les membres du gang concerné
local function rebuild(c)
    points = {}
    local myBiz = G.job and G.job.biz or nil
    for _, p in ipairs(allPoints) do
        if (p.kind ~= 'gang' or (p.gang and p.gang == myGang)) and (p.kind ~= 'biz' or (p.biz and p.biz == myBiz)) then points[#points + 1] = p end
    end
    -- gardien à chaque garage public et à chaque fourrière (modèles réglables dans la configuration des garages)
    local gc, npcs = (c and c.garage) or {}, {}
    if gc.npc ~= false then
        -- le gardien d'un garage d'entreprise se voit de tous (le garage, lui, ne s'ouvre qu'aux employés) ; celui d'un gang, des membres seulement
        local seen = {}
        for _, p in ipairs(points) do seen[p.id] = true end
        local withNpc = {}
        for _, p in ipairs(allPoints) do if seen[p.id] or p.kind == 'biz' then withNpc[#withNpc + 1] = p end end
        for _, p in ipairs(withNpc) do
            -- (v1.2.84) garages d'entreprise et de gang : un gardien aussi (sur le point posé au Builder, sinon sur l'entrée)
            local m = p.kind == 'impound' and (gc.npc_impound or 'a_m_m_hasjew_01') or (gc.npc_public or 'a_m_y_business_02')
            if m and p.npc then npcs[#npcs + 1] = { id = p.id, model = m, x = p.npc.x, y = p.npc.y, z = p.npc.z, h = p.npc.h }
            elseif m then npcs[#npcs + 1] = { id = p.id, model = m, x = p.x, y = p.y, z = p.z, h = p.h, ghost = true } end
        end
    end
    G.Npcs('garages', npcs)
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (c and c.garage and c.garage.blips) then return end
    for _, p in ipairs(points) do
        if p.kind == 'biz' then goto skip end   -- garage d'entreprise : pas de repère public (les employés connaissent l'adresse)
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        -- icône selon le type : garage, hangar aérien (hélicoptère), port (bateau) ; fourrière en orange
        local sp = p.kind == 'impound' and 68 or (p.vtype == 'air' and 43 or (p.vtype == 'boat' and 427 or 357))
        SetBlipSprite(b, sp) SetBlipColour(b, p.kind == 'impound' and 17 or 3) SetBlipScale(b, 0.8) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
        ::skip::
    end
end
-- le métier arrive souvent après la configuration, et il peut changer : le garage de l'entreprise suit
local lastBiz = false
RegisterNetEvent('pb:g:biz:job', function()
    Wait(0)
    local b = G.job and G.job.biz or nil
    if b ~= lastBiz then lastBiz = b if lastCfg then rebuild(lastCfg) end end
end)
G.onCfg = function(c)
    if prev then prev(c) end
    allPoints, lastCfg = c.garage_points or {}, c
    rebuild(c)
end
RegisterNetEvent('pb:g:mygang', function(id) myGang = tostring(id or '') rebuild(lastCfg) end)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.garage and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_lock', 'Verrouiller / déverrouiller le véhicule', 'keyboard', (G.cfg.garage and G.cfg.garage.lock_key) or 'L')
    while not G.begun do Wait(1000) end
    TriggerServerEvent('pb:g:veh:needLocks')
end)

-- (patch 325) Marker du point de rangement : voiture, bateau ou avion selon le type du garage (MarkerTypeCarSymbol 36, BoatSymbol 35, PlaneSymbol 33)
local SYMBOL = { car = 36, boat = 35, air = 33 }
local SYMBOL_COL = { car = { 111, 180, 255 }, boat = { 70, 200, 220 }, air = { 255, 190, 80 } }
CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    local function storeAt(pt)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then TriggerServerEvent('pb:g:garage:store', pt.id, plateOf(veh), props(veh), NetworkGetNetworkIdFromEntity(veh)) end
    end
    while true do
        if not G.begun or busy() or isOpen or #points == 0 then hide() Wait(700)
        else
            local gc = G.cfg.garage or {}
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local inVeh = IsPedInAnyVehicle(ped, false)
            local best, bd = nil, 1e9
            local sbest, sd = nil, 1e9
            for _, p in ipairs(points) do
                local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0))
                if d < bd then best, bd = p, d end
                if p.store and p.kind ~= 'impound' then
                    local ds = #(c - vector3(p.store.x + 0.0, p.store.y + 0.0, p.store.z + 0.0))
                    if ds < sd then sbest, sd = p, ds end
                end
            end
            local active, txt, tkey, onE = false, nil, nil, nil
            -- entrée : à pied, ouvre le menu ; en véhicule, range (seulement si aucun point de rangement n'a été posé)
            if best and bd <= 15.0 then
                active = true
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, best.kind == 'impound' and 255 or 111, 180, best.kind == 'impound' and 87 or 255, 1.8)
                local reach = inVeh and (gc.store_dist or 25.0) * 0.4 or (gc.use_distance or 2.5)
                if bd <= reach then
                    if not inVeh then
                        txt, tkey = (best.kind == 'impound' and 'Fourrière : ' or 'Garage : ') .. best.label, best.id .. 'p'
                        onE = function() TriggerServerEvent('pb:g:garage:open', best.id) end
                    elseif best.kind ~= 'impound' and not best.store then
                        txt, tkey = 'Ranger le véhicule : ' .. best.label, best.id .. 'v'
                        onE = function() storeAt(best) end
                    end
                end
            end
            -- point de rangement posé au Builder : le marker du bon type, et E dessus avec son véhicule
            if sbest and sd <= 45.0 then
                active = true
                local vt = sbest.vtype or 'car'
                local col = SYMBOL_COL[vt] or SYMBOL_COL.car
                local sp = sbest.store
                DrawMarker(SYMBOL[vt] or 36, sp.x + 0.0, sp.y + 0.0, sp.z - 0.35, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.4, 1.4, 1.4, col[1], col[2], col[3], 190, false, true, 2, true, nil, nil, false)
                if inVeh and sd <= (vt == 'car' and 4.0 or 9.0) then
                    txt, tkey = 'Ranger le véhicule : ' .. sbest.label, sbest.id .. 's'
                    onE = function() storeAt(sbest) end
                end
            end
            if txt then
                if not shown or key ~= tkey then shown, key = true, tkey G.send('prompt', { show = true, key = 'E', text = txt }) end
                if IsControlJustPressed(0, 38) and onE then onE() end
            else hide() end
            Wait(active and 0 or 500)
        end
    end
end)

CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
