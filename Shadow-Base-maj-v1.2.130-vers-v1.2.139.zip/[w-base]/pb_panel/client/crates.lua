-- (patch 335) Caisses : /caisses ouvre la liste, l'ouverture lance l'animation (web/game/crates.js)
local G = PB.G
local function decode(j) local ok, d = pcall(json.decode, j or '') return ok and type(d) == 'table' and d or nil end
local MINUTES = 60

local function openList(d)
    local items = {}
    local total = 0
    for _, c in ipairs(d.crates or {}) do
        total = total + (c.qty or 0)
        items[#items + 1] = { label = c.label, right = ('x%d'):format(c.qty or 0), icon = 'gift', disabled = (c.qty or 0) < 1 or nil,
            description = (c.qty or 0) > 0 and ('Contenu possible : ' .. table.concat(c.rewards or {}, ', ')) or 'Tu n\'en as pas. Elles se gagnent avec le temps de jeu.',
            onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:crates:open', c.id) end }
    end
    if #items == 0 then items[1] = { label = 'Aucune caisse sur ce serveur', disabled = true } end
    G.Menu.Open({ id = 'crates.list', title = 'Mes caisses', subtitle = ('%d caisse(s) · une toutes les %d min de jeu'):format(total, tonumber(d.minutes) or MINUTES), items = items })
end
RegisterNetEvent('pb:g:crates:list', function(j) local d = decode(j) if d then openList(d) end end)
RegisterNetEvent('pb:g:crates:result', function(j) local d = decode(j) if d then G.send('crates.open', d) end end)
RegisterCommand('caisses', function() TriggerServerEvent('pb:g:crates:list') end, false)
