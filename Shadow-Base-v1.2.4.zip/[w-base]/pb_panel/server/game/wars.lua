-- Guerres de territoire planifiées : à heure fixe, une zone de gang devient « en guerre » pendant N minutes.
-- Score : présence dans la zone (points par membre toutes les 15 s) + éliminations d'un gang rival dans la zone.
-- À la fin, le gang en tête prend la zone et touche la récompense (partagée entre ses membres connectés). Historique gardé.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G
local Wr = { cur = nil }
G.Wars = Wr

P.Register('wars.manage', 'Planifier et lancer les guerres de territoire', 'territories', true)
PB.Migrate('346_gang_wars', 'Guerres de territoire', {
    [[CREATE TABLE IF NOT EXISTS pb_wars (id INT AUTO_INCREMENT PRIMARY KEY, zone VARCHAR(32) NOT NULL, zone_label VARCHAR(64) NOT NULL DEFAULT '', started INT NOT NULL DEFAULT 0, ended INT NOT NULL DEFAULT 0, winner VARCHAR(32) NOT NULL DEFAULT '', scores TEXT NULL, reward INT NOT NULL DEFAULT 0)]],
})
PB.Cfg.Define('wars', { enabled = false, schedule = { 'sam|21:00|random', 'mer|21:00|random' }, duration = 30, min_gangs = 2, hold_pts = 1, kill_pts = 5, reward = 50000, protect_min = 1440, warn_min = 15 })
local function cfg(k, d) return PB.Cfg.Get('wars', k, d) end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function now() return os.time() end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end
local function zones() return PB.Cfg.Get('territories', 'zones', {}) or {} end
local function zoneById(id) for _, z in ipairs(zones()) do if z.id == id then return z end end end
local function inZone(src, z) return G.DistTo(src, z.x, z.y, z.z) <= (tonumber(z.radius) or 30) + 15 end
local function gangLabel(id) local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id] return d and d.label or id end
local function gangColor(id) local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id] return d and d.color or '#e5384f' end
local DAYS = { dim = 1, lun = 2, mar = 3, mer = 4, jeu = 5, ven = 6, sam = 7 }

local function board(e)
    if not e then return { on = false } end
    local rows = {}
    for g, s in pairs(e.score) do rows[#rows + 1] = { id = g, label = gangLabel(g), color = gangColor(g), pts = s, kills = e.kills[g] or 0 } end
    table.sort(rows, function(a, b) return a.pts > b.pts end)
    return { on = true, zone = e.label, x = e.x, y = e.y, r = e.r, ends = e.ends, left = math.max(0, e.ends - now()), rows = rows }
end
function Wr.Push(target) TriggerClientEvent('pb:g:war', target or -1, PB.Json(board(Wr.cur))) end
table.insert(G.beginHooks, function(src) if Wr.cur then Wr.Push(src) end end)

function Wr.Start(zoneId, by)
    if Wr.cur then return false, 'Une guerre est déjà en cours.' end
    local list = zones()
    if #list == 0 then return false, 'Aucune zone de gang configurée (Zones de gangs).' end
    local z = (zoneId and zoneId ~= 'random') and zoneById(zoneId) or list[math.random(1, #list)]
    if not z then return false, 'Zone inconnue.' end
    local gangs = {}
    for s in pairs(G.Players()) do local g = gangOf(s) if g then gangs[g.id] = true end end
    local n = 0 for _ in pairs(gangs) do n = n + 1 end
    if by == 'planifié' and n < num('min_gangs', 2) then
        PB.Announce(('Guerre de territoire annulée (%s) : pas assez de gangs connectés.'):format(z.label), 'chat')
        return false, 'Pas assez de gangs connectés.'
    end
    Wr.cur = { zone = z.id, label = z.label, x = z.x, y = z.y, z = z.z, r = tonumber(z.radius) or 30, started = now(), ends = now() + math.max(5, num('duration', 30)) * 60, score = {}, kills = {}, owner = G.Territories and G.Territories.Owner(z.id) or nil }
    PB.Announce(('GUERRE DE TERRITOIRE : %s est en jeu pendant %d minutes ! Tenez la zone et éliminez les rivaux.'):format(z.label, math.max(5, num('duration', 30))), 'both')
    PB.Audit.Log('serveur', 'war.start', by or 'système', z.id, nil, nil)
    Wr.Push()
    return true, 'Guerre lancée sur ' .. z.label .. '.'
end
function Wr.Finish(cancel)
    local e = Wr.cur
    if not e then return false end
    Wr.cur = nil
    local b = board(e)
    local top = b.rows[1]
    local tie = b.rows[2] and top and b.rows[2].pts == top.pts
    local winner = (not cancel and top and top.pts > 0 and not tie) and top.id or ''
    local paid = 0
    if winner ~= '' then
        DB.exec('REPLACE INTO pb_territories (zone, gang, since, lastcap) VALUES (?, ?, ?, ?)', { e.zone, winner, now(), now() + math.max(0, num('protect_min', 1440)) * 60 - ((tonumber((zoneById(e.zone) or {}).cooldown) or 60) * 60) })
        local members = {}
        for s in pairs(G.Players()) do local g = gangOf(s) if g and g.id == winner then members[#members + 1] = s end end
        local total = math.floor(num('reward', 50000))
        if #members > 0 and total > 0 then
            local share = math.floor(total / #members)
            for _, s in ipairs(members) do G.AddMoney(s, 'cash', share, 'Victoire de guerre : ' .. e.label) G.Notify(s, { type = 'success', title = 'Victoire', text = ('+%d $ (part de la récompense).'):format(share) }) end
            paid = share * #members
        end
        if G.Territories then G.Territories.Push() end
        TriggerClientEvent('pb:g:zone:banner', -1, PB.Json({ title = 'Guerre gagnée', sub = gangLabel(winner), zone = e.label, color = gangColor(winner) }))
        PB.Announce(('%s remporte la guerre de %s (%d points) !'):format(gangLabel(winner), e.label, top.pts), 'both')
    elseif not cancel then
        PB.Announce(('Guerre de %s terminée sans vainqueur%s.'):format(e.label, tie and ' (égalité)' or ''), 'both')
    else
        PB.Announce(('La guerre de %s est annulée.'):format(e.label), 'chat')
    end
    local sc = {}
    for _, r in ipairs(b.rows) do sc[#sc + 1] = { gang = r.id, pts = r.pts, kills = r.kills } end
    DB.insert('INSERT INTO pb_wars (zone, zone_label, started, ended, winner, scores, reward) VALUES (?, ?, ?, ?, ?, ?, ?)', { e.zone, e.label, e.started, now(), winner, PB.Json(sc), paid })
    PB.Audit.Log('serveur', 'war.end', 'système', e.zone, winner, nil)
    Wr.Push()
    return true
end

-- éliminations : un tueur d'un gang qui abat un membre d'un AUTRE gang, dans la zone, marque des points
AddEventHandler('pb_panel:kill', function(row)
    local e = Wr.cur
    if not e or not row or not row.ksrc or not row.vsrc then return end
    local kg, vg = gangOf(row.ksrc), gangOf(row.vsrc)
    if not kg or not vg or kg.id == vg.id then return end
    local z = zoneById(e.zone)
    if not z or not inZone(row.vsrc, z) then return end
    e.score[kg.id] = (e.score[kg.id] or 0) + math.floor(num('kill_pts', 5))
    e.kills[kg.id] = (e.kills[kg.id] or 0) + 1
    Wr.Push()
end)

-- horloge : points de présence, fin, planning
local lastKey, warned = nil, {}
function Wr.Tick()
        local e = Wr.cur
        if e then
            local z = zoneById(e.zone)
            if z then
                for s in pairs(G.Players()) do
                    local g = gangOf(s)
                    if g and usable(s) and inZone(s, z) then e.score[g.id] = (e.score[g.id] or 0) + math.floor(num('hold_pts', 1)) end
                end
            end
            if now() >= e.ends then Wr.Finish(false) else Wr.Push() end
        end
        if cfg('enabled', false) == true then
            local d = os.date('*t', now())
            for _, line in ipairs(cfg('schedule', {}) or {}) do
                local day, hh, mm, zid = tostring(line):match('^(%a+)|(%d%d?):(%d%d)|?([%w_]*)$')
                if day and (DAYS[day:lower():sub(1, 3)] == d.wday or day:lower() == 'tous') then
                    local at = tonumber(hh) * 60 + tonumber(mm)
                    local cur = d.hour * 60 + d.min
                    local key = ('%s-%d-%s'):format(os.date('%Y%m%d', now()), at, line)
                    local warn = math.floor(num('warn_min', 15))
                    if warn > 0 and cur == at - warn and not warned[key] then
                        warned[key] = true
                        local z = zid ~= '' and zid ~= 'random' and zoneById(zid)
                        PB.Announce(('Guerre de territoire dans %d minutes%s. Préparez-vous.'):format(warn, z and (' sur ' .. z.label) or ''), 'both')
                    end
                    if cur == at and lastKey ~= key then lastKey = key Wr.Start(zid ~= '' and zid or 'random', 'planifié') end
                end
            end
        end
end
CreateThread(function() while true do Wait(15000) Wr.Tick() end end)

PB.Action('wars.start', 'wars.manage', function(ctx, p)
    local ok, msg = Wr.Start(p.zone, ctx.actor and ctx.actor.name)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
PB.Action('wars.stop', 'wars.manage', function(ctx, p)
    if not Wr.Finish(p.cancel == true) then return false, 'Aucune guerre en cours.' end
    ctx.toast = 'Guerre terminée.'
    return true
end)
local form = PB.Form.Cfg({ ns = 'wars', id = 'settings', title = 'Guerres de territoire', perm = 'wars.manage', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Guerres planifiées actives', default = false },
    { k = 'duration', type = 'number', label = 'Durée d\'une guerre (minutes)', default = 30, min = 5, max = 180 },
    { k = 'min_gangs', type = 'number', label = 'Gangs connectés minimum', default = 2, min = 1, max = 20 },
    { k = 'warn_min', type = 'number', label = 'Annonce avant le début (minutes, 0 = aucune)', default = 15, min = 0, max = 120 },
    { k = 'hold_pts', type = 'number', label = 'Points par membre présent (toutes les 15 s)', default = 1, min = 0, max = 100 },
    { k = 'kill_pts', type = 'number', label = 'Points par élimination d\'un rival dans la zone', default = 5, min = 0, max = 1000 },
    { k = 'reward', type = 'number', label = 'Récompense du vainqueur ($, partagée)', default = 50000, min = 0, max = 100000000 },
    { k = 'protect_min', type = 'number', label = 'Zone protégée après la victoire (minutes)', default = 1440, min = 0, max = 20160 },
    { k = 'schedule', type = 'list', label = 'Planning (jour|HH:MM|zone ou random)', default = { 'sam|21:00|random', 'mer|21:00|random' }, maxitems = 20, maxlen = 48, wide = true,
      hint = 'Jours : lun, mar, mer, jeu, ven, sam, dim ou tous. Zone : identifiant de la zone (Zones de gangs) ou random.' },
} })
PB.Module({
    id = 'wars', label = 'Guerres de territoire', icon = 'flag', group = 'Serveur', order = 147, perm = 'wars.manage', hint = 'Guerres planifiées, score, récompense',
    caps = function() return PB.Capsify({
        { 'Planning', 'ok', 'Jours et heures fixes, zone imposée ou au hasard, annonce avant le début.' },
        { 'Score', 'ok', 'Présence dans la zone + éliminations de rivaux dans la zone ; tableau en direct à l\'écran.' },
        { 'Récompense', 'ok', 'La zone passe au vainqueur (protégée), et la récompense est partagée entre ses membres connectés.' },
    }) end,
    doc = "## Guerres de territoire\nLes zones sont celles de **Zones de gangs**. Pendant une guerre, chaque membre d'un gang présent dans la zone rapporte des points toutes les 15 s, et chaque rival abattu dans la zone en rapporte davantage. En cas d'égalité, personne ne gagne.",
    view = function(ctx)
        local e = Wr.cur
        local zopts = { { 'random', 'Au hasard' } }
        for _, z in ipairs(zones()) do zopts[#zopts + 1] = { z.id, z.label } end
        return { tabs = {
            { id = 'now', label = 'En direct', icon = 'flag', build = function()
                local blocks = {}
                if e then
                    local b = board(e)
                    blocks[#blocks + 1] = B.notice('info', ('Guerre en cours sur %s · fin à %s.'):format(e.label, os.date('%H:%M', e.ends)))
                    local rows = {}
                    for _, r in ipairs(b.rows) do rows[#rows + 1] = { gang = r.label, pts = r.pts, kills = r.kills } end
                    blocks[#blocks + 1] = B.table({ id = 'score', title = 'Score', columns = { { k = 'gang', label = 'Gang' }, { k = 'pts', label = 'Points' }, { k = 'kills', label = 'Éliminations' } }, rows = rows, empty = 'Personne n\'a encore marqué.' })
                    blocks[#blocks + 1] = B.actions({ { action = 'wars.stop', label = 'Terminer maintenant', icon = 'flag', payload = {} }, { action = 'wars.stop', label = 'Annuler', icon = 'x', danger = true, payload = { cancel = true }, confirm = 'Annuler sans vainqueur ?' } }, 'Guerre')
                else
                    blocks[#blocks + 1] = { type = 'form', id = 'warstart', title = 'Lancer une guerre maintenant', cols = 1, fields = { { k = 'zone', type = 'select', label = 'Zone', options = zopts, required = true } }, values = { zone = 'random' }, submit = { action = 'wars.start', label = 'Lancer' } }
                end
                return blocks
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
            { id = 'history', label = 'Historique', icon = 'clock', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_wars ORDER BY id DESC LIMIT 50') or {}) do
                    local sc = PB.FromJson(r.scores or '[]') or {}
                    local parts = {}
                    for _, s in ipairs(sc) do parts[#parts + 1] = gangLabel(s.gang) .. ' ' .. tostring(s.pts) end
                    rows[#rows + 1] = { at = r.started, zone = r.zone_label, winner = r.winner ~= '' and gangLabel(r.winner) or '—', scores = table.concat(parts, ' · '), reward = r.reward }
                end
                return { B.table({ id = 'wh', title = 'Dernières guerres', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'zone', label = 'Zone' }, { k = 'winner', label = 'Vainqueur', type = 'badge' }, { k = 'scores', label = 'Scores' }, { k = 'reward', label = 'Versé ($)', type = 'num' } }, rows = rows, empty = 'Aucune guerre pour l\'instant.' }) }
            end },
        } }
    end,
})
