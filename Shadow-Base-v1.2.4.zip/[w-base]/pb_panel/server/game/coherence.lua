-- Cohérence entre les systèmes : ce qui relie les scripts entre eux pour que la ville réagisse logiquement.
--  · Recouvrement : facture ou amende impayée -> majoration -> saisie sur le compte en banque -> mandat (la police le voit).
--  · Véhicules : abandonnés (propriétaire parti) ou disparus du monde -> fourrière ; le propriétaire reçoit un SMS (fourrière, épave).
--  · Secours : un joueur à terre alerte les secouristes en service tout seul ; la réapparition à l'hôpital est payée à l'hôpital
--    (caisse des secours), et facturée si le joueur n'a pas l'argent.
--  · Entreprises : service remis à zéro à la déconnexion, patron prévenu quand la caisse ne couvre plus la paie.
--  · Chronologie du joueur : factures, majorations, saisies, mandats, fourrières, comas, réapparitions.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('coherence.manage', 'Gérer la cohérence de la ville (recouvrement, mandats, fourrière automatique, secours)', 'world')
PB.Migrate('342_coherence', 'Cohérence : chronologie, recouvrement, mandats', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_timeline (id BIGINT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, kind VARCHAR(12) NOT NULL, text VARCHAR(200) NOT NULL DEFAULT '', tone VARCHAR(6) NOT NULL DEFAULT 'info', at INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license, at))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_warrants (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', reason VARCHAR(160) NOT NULL DEFAULT '', amount BIGINT NOT NULL DEFAULT 0, invoice_id INT NOT NULL DEFAULT 0, status VARCHAR(8) NOT NULL DEFAULT 'open', by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, closed_by VARCHAR(64) NOT NULL DEFAULT '', closed_at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_lic (license, status), KEY k_st (status))]]))
    pcall(DB.exec, "ALTER TABLE pb_biz_invoices ADD COLUMN stage TINYINT NOT NULL DEFAULT 0")
    pcall(DB.exec, "ALTER TABLE pb_biz_invoices ADD COLUMN stage_at INT NOT NULL DEFAULT 0")
end)
PB.Cfg.Define('coherence', {
    recovery = true, late_days = 3, surcharge = 10, seize_days = 7, warrant = true, warrant_min = 500, police_notify = true,
    abandon = true, abandon_offline_min = 20, abandon_gone_min = 15, impound_sms = true,
    auto_ems = true, auto_ems_secs = 20, hospital_pay = true, hospital_bill = true,
    duty_reset = true, payroll_warn = true,
})
local Co = {}
G.Coherence = Co
local function cfg(k, d) return PB.Cfg.Get('coherence', k, d) end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function acct(id) return 'biz:' .. tostring(id) end
local function srcOf(license) for id, p in pairs(G.Players()) do if p.license == license then return id end end end
Co.SourceOf = srcOf
local function sms(license, key, body) if G.Phone and G.Phone.Notice then pcall(G.Phone.Notice, license, key, body) end end
local function nameOf(license)
    local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { license })
    local n = r and ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') or ''
    return n ~= '' and n or license
end

local bizLabel
-- Chronologie ------------------------------------------------------------------------------------------------------------------------------
G.Timeline = {}
function G.Timeline.Add(license, kind, text, tone)
    if not license or license == '' then return end
    DB.insert('INSERT INTO pb_timeline (license, kind, text, tone, at) VALUES (?, ?, ?, ?, ?)', { tostring(license), tostring(kind):sub(1, 12), tostring(text):sub(1, 200), tone or 'info', now() })
end
-- ce que les autres systèmes signalent déjà : factures, amendes, prison, réanimations
local function licOf(src) local p = G.Get(tonumber(src) or -1) return p and p.license end
AddEventHandler('pb_panel:invoice', function(_, tid, bizId, amount, reason) local l = licOf(tid) if l then G.Timeline.Add(l, 'bill', ('Facture de %s reçue : %s (%s)'):format(bizLabel(bizId), money(amount), tostring(reason or '')), 'info') end end)
AddEventHandler('pb_panel:invoicePaid', function(id, payer, bizId, amount, kind) local l = licOf(payer) if l then G.Timeline.Add(l, 'bill', ('%s #%s réglée : %s'):format(kind == 'fine' and 'Amende' or 'Facture', tostring(id), money(amount)), 'ok') end end)
AddEventHandler('pb_panel:fine', function(_, tid, amount, reason) local l = licOf(tid) if l then G.Timeline.Add(l, 'fine', ('Amende : %s (%s)'):format(money(amount), tostring(reason or '')), 'warn') end end)
AddEventHandler('pb_panel:jailed', function(tid, kind, amount, reason) local l = licOf(tid) if l then G.Timeline.Add(l, 'jail', ('%s : %s (%s)'):format(kind == 'tig' and 'Travaux d\'intérêt général' or 'Prison', tostring(amount or ''), tostring(reason or '')), 'bad') end end)
AddEventHandler('pb_panel:revivedBy', function(_, tid) local l = licOf(tid) if l then G.Timeline.Add(l, 'care', 'Réanimé par les secours', 'ok') end end)
PB.OnReady(function()
    local V = G.Vigil
    if not V or not V.Timeline or V._coherence then return end
    local orig = V.Timeline
    V._coherence = true
    V.Timeline = function(license, limit)
        local out = orig(license, limit)
        for _, r in ipairs(DB.q('SELECT kind, text, tone, at FROM pb_timeline WHERE license = ? ORDER BY id DESC LIMIT ?', { license, limit or 150 }) or {}) do
            out[#out + 1] = { at = tonumber(r.at) or 0, kind = r.kind, text = r.text, tone = r.tone }
        end
        table.sort(out, function(a, b) return a.at > b.at end)
        while #out > (limit or 150) do table.remove(out) end
        return out
    end
end)

-- Argent d'un joueur, connecté ou non (saisie) --------------------------------------------------------------------------------------------
-- prend au plus « amount » sur le compte en banque ; renvoie ce qui a été pris
local function seizeBank(license, amount, reason)
    local src = srcOf(license)
    if src then
        local have = math.max(0, math.floor(G.GetMoney(src, 'bank') or 0))
        local take = math.min(have, amount)
        if take > 0 then G.RemoveMoney(src, 'bank', take, reason) end
        return take
    end
    local r = DB.one('SELECT bank FROM pb_players WHERE license = ?', { license })
    local take = math.min(math.max(0, math.floor(tonumber(r and r.bank) or 0)), amount)
    if take > 0 and DB.exec('UPDATE pb_players SET bank = bank - ? WHERE license = ? AND bank >= ?', { take, license, take }) == 0 then return 0 end
    return take
end
Co.SeizeBank = seizeBank

-- Recouvrement des factures et amendes ------------------------------------------------------------------------------------------------------
local function book(inv, amount)
    if inv.kind == 'fine' and PB.Cfg.Get('biz', 'fine_to', 'state') == 'state' then G.Eco.Book('state', amount, 'Saisie : amende #' .. inv.id, inv.license)
    else G.Eco.Book(acct(inv.biz_id), amount, 'Saisie : facture #' .. inv.id, inv.license) end
end
bizLabel = function(id) local b = G.Biz and G.Biz.Get(id) return b and b.label or 'Entreprise' end
local function policeOnDuty()
    local out = {}
    for id in pairs(G.Players()) do
        local c = G.Biz and G.Biz.Ctx(id)
        if c and c.duty and c.biz.kind == 'police' then out[#out + 1] = id end
    end
    return out
end
function Co.Warrant(license, reason, amount, invId, by)
    local open = DB.one("SELECT id FROM pb_warrants WHERE license = ? AND invoice_id = ? AND status = 'open'", { license, invId or 0 })
    if open and (invId or 0) > 0 then return open.id end
    local name = nameOf(license)
    local id = DB.insert('INSERT INTO pb_warrants (license, name, reason, amount, invoice_id, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { license, name, tostring(reason):sub(1, 160), amount or 0, invId or 0, by or 'Trésor public', now() })
    G.Timeline.Add(license, 'warrant', ('Mandat #%s : %s'):format(tostring(id), reason), 'bad')
    sms(license, 'tresor', ('Un mandat a été émis contre vous (%s). Réglez votre dette ou présentez-vous à la police.'):format(reason))
    if cfg('police_notify', true) then
        for _, s in ipairs(policeOnDuty()) do G.Notify(s, { type = 'warn', title = 'Nouveau mandat #' .. tostring(id), text = ('%s : %s'):format(name, reason), duration = 10000 }) end
    end
    PB.Audit.Log('justice', 'warrant.open', by or 'système', name, nil, nil, { raison = reason, montant = amount, facture = invId })
    return id
end
function Co.CloseWarrant(id, by)
    local w = DB.one('SELECT * FROM pb_warrants WHERE id = ?', { tonumber(id) or -1 })
    if not w or w.status ~= 'open' then return false end
    DB.exec("UPDATE pb_warrants SET status = 'closed', closed_by = ?, closed_at = ? WHERE id = ?", { tostring(by or 'système'):sub(1, 64), now(), w.id })
    G.Timeline.Add(w.license, 'warrant', ('Mandat #%d levé (%s)'):format(w.id, tostring(by or 'système')), 'ok')
    return true
end
function Co.OpenWarrants(license)
    return DB.q("SELECT * FROM pb_warrants WHERE status = 'open'" .. (license and ' AND license = ?' or '') .. ' ORDER BY id DESC LIMIT 100', license and { license } or {}) or {}
end
local function isFine(inv) return inv.kind == 'fine' end
function Co.RecoveryTick()
    if cfg('recovery', true) == false then return 0 end
    local t, n = now(), 0
    local late, seize, pct = num('late_days', 3) * 86400, num('seize_days', 7) * 86400, num('surcharge', 10)
    -- 1. majoration
    for _, inv in ipairs(DB.q("SELECT * FROM pb_biz_invoices WHERE status = 'pending' AND stage = 0 AND at < ?", { t - late }) or {}) do
        local add = math.ceil(inv.amount * pct / 100)
        if DB.exec("UPDATE pb_biz_invoices SET amount = amount + ?, stage = 1, stage_at = ? WHERE id = ? AND stage = 0 AND status = 'pending'", { add, t, inv.id }) > 0 then
            n = n + 1
            local what = isFine(inv) and 'Amende' or ('Facture ' .. bizLabel(inv.biz_id))
            G.Timeline.Add(inv.license, 'bill', ('%s #%d majorée de %d %% : %s'):format(what, inv.id, pct, money(inv.amount + add)), 'warn')
            sms(inv.license, 'tresor', ('%s #%d (%s) impayée depuis %d jours : majorée de %d %%, à régler : %s. Sans paiement sous %d jours, la somme sera saisie sur votre compte.')
                :format(what, inv.id, inv.reason, num('late_days', 3), pct, money(inv.amount + add), math.max(0, num('seize_days', 7) - num('late_days', 3))))
        end
    end
    -- 2. saisie sur le compte, puis mandat pour le reste. Le débiteur a toujours le délai annoncé dans le SMS de majoration,
    --    même pour une vieille facture (installation du module sur un serveur qui a déjà des impayés)
    local grace = math.max(1, num('seize_days', 7) - num('late_days', 3)) * 86400
    for _, inv in ipairs(DB.q("SELECT * FROM pb_biz_invoices WHERE status = 'pending' AND stage = 1 AND at < ? AND stage_at < ?", { t - seize, t - grace }) or {}) do
        if DB.exec("UPDATE pb_biz_invoices SET stage = 2 WHERE id = ? AND stage = 1 AND status = 'pending'", { inv.id }) > 0 then
            n = n + 1
            local what = isFine(inv) and 'Amende' or ('Facture ' .. bizLabel(inv.biz_id))
            local took = seizeBank(inv.license, inv.amount, 'Saisie : ' .. what:lower() .. ' #' .. inv.id)
            if took > 0 then book(inv, took) end
            local rest = inv.amount - took
            if rest <= 0 then
                DB.exec("UPDATE pb_biz_invoices SET status = 'paid', paid_at = ? WHERE id = ?", { t, inv.id })
                G.Timeline.Add(inv.license, 'bill', ('%s #%d saisie sur le compte : %s'):format(what, inv.id, money(took)), 'warn')
                sms(inv.license, 'tresor', ('%s #%d : %s saisis sur votre compte en banque. Dette réglée.'):format(what, inv.id, money(took)))
                TriggerEvent('pb_panel:invoicePaid', inv.id, srcOf(inv.license), inv.biz_id, took, inv.kind)
            else
                DB.exec('UPDATE pb_biz_invoices SET amount = ? WHERE id = ?', { rest, inv.id })
                G.Timeline.Add(inv.license, 'bill', ('%s #%d : %s saisis, reste %s'):format(what, inv.id, money(took), money(rest)), 'bad')
                sms(inv.license, 'tresor', ('%s #%d : %s saisis sur votre compte, il reste %s à payer.'):format(what, inv.id, money(took), money(rest)))
                if cfg('warrant', true) ~= false and rest >= num('warrant_min', 500) then Co.Warrant(inv.license, ('%s #%d impayée (%s) : reste %s'):format(what, inv.id, inv.reason, money(rest)), rest, inv.id) end
            end
        end
    end
    return n
end
CreateThread(function() while true do Wait(300000) pcall(Co.RecoveryTick) end end)
-- une facture payée (tablette, téléphone, saisie) lève son mandat
AddEventHandler('pb_panel:invoicePaid', function(invId)
    for _, w in ipairs(DB.q("SELECT id FROM pb_warrants WHERE invoice_id = ? AND status = 'open'", { tonumber(invId) or -1 }) or {}) do Co.CloseWarrant(w.id, 'dette réglée') end
end)
-- un recherché qui se connecte : la police en service est prévenue
table.insert(G.beginHooks, function(src, p)
    if cfg('police_notify', true) == false then return end
    local open = DB.one("SELECT COUNT(*) AS n FROM pb_warrants WHERE license = ? AND status = 'open'", { p.license })
    if open and (tonumber(open.n) or 0) > 0 then
        local name = nameOf(p.license)
        for _, s in ipairs(policeOnDuty()) do G.Notify(s, { type = 'warn', title = 'Personne recherchée', text = ('%s (%d mandat%s) est en ville.'):format(name, open.n, open.n > 1 and 's' or ''), duration = 9000 }) end
    end
end)

-- Tablette de la police : mandats en cours dans « Citoyens et amendes » --------------------------------------------------------------------
PB.OnReady(function()
    local Biz = G.Biz
    if not Biz or not Biz.PAGES or not Biz.ACT then return end
    local orig = Biz.PAGES.citizens
    Biz.PAGES.citizens = function(src)
        local blocks, title = orig(src)
        local c = Biz.Ctx(src)
        if blocks and c and c.biz.kind == 'police' then
            local rows = {}
            for _, w in ipairs(Co.OpenWarrants()) do
                rows[#rows + 1] = { who = w.name, reason = w.reason, amount = w.amount > 0 and money(w.amount) or '', at = os.date('%d/%m %H:%M', w.at), online = srcOf(w.license) and 'En ville' or 'Absent',
                    actions = Biz.Allowed(c, 'jail') and { { act = 'warrant_close', label = 'Lever (arrêté)', payload = { id = w.id }, confirm = 'Lever ce mandat ? La personne a été arrêtée ou a réglé sa situation.' } } or nil }
            end
            table.insert(blocks, 1, { type = 'table', title = 'Mandats en cours', columns = { { k = 'who', label = 'Personne' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Dette' }, { k = 'online', label = 'Présence' }, { k = 'at', label = 'Depuis' } }, rows = rows, empty = 'Aucun mandat en cours.' })
        end
        return blocks, title
    end
    Biz.ACT.warrant_close = function(c, src, p)
        if c.biz.kind ~= 'police' or not Biz.Allowed(c, 'jail') then return false, "Tu n'as pas le droit de lever un mandat." end
        if not c.duty then return false, 'Prends ton service.' end
        if not Co.CloseWarrant(p.id, Biz.Display(src)) then return false, 'Mandat introuvable ou déjà levé.' end
        return true, 'Mandat levé.'
    end
    -- facture annulée par l'entreprise : son mandat tombe aussi
    local cancel = Biz.ACT.cancel_invoice
    Biz.ACT.cancel_invoice = function(c, src, p)
        local ok, msg = cancel(c, src, p)
        if ok then for _, w in ipairs(DB.q("SELECT id FROM pb_warrants WHERE invoice_id = ? AND status = 'open'", { tonumber(p.id) or -1 }) or {}) do Co.CloseWarrant(w.id, 'facture annulée') end end
        return ok, msg
    end
end)

-- Véhicules : fourrière automatique et SMS ------------------------------------------------------------------------------------------------------
local gone = {}    -- plaque -> premier constat « plus dans le monde »
local offAt = {}   -- licence -> heure de déconnexion
AddEventHandler('playerDropped', function() local p = G.Get(source) if p then offAt[p.license] = now() end end)
table.insert(G.beginHooks, function(src, p) offAt[p.license] = nil end)
local function impoundPoint()
    local r = DB.one("SELECT label FROM pb_garages WHERE kind = 'impound' AND enabled = 1 ORDER BY label LIMIT 1")
    return r and r.label or 'la fourrière'
end
local function feeTxt() local f = PB.Cfg.Get('garage', 'impound_fee', 250) return money(G.Eco and G.Eco.Fine(f) or f) end
local function vehicleSms(plate, why)
    if cfg('impound_sms', true) == false then return end
    local v = DB.one('SELECT license, label, gang, biz FROM pb_vehicles WHERE plate = ?', { tostring(plate) })
    if not v or (v.license or '') == '' then return end
    sms(v.license, 'fourriere', ('%s (%s) : %s Il vous attend à %s (frais : %s).'):format(v.label ~= '' and v.label or 'Votre véhicule', plate, why, impoundPoint(), feeTxt()))
    G.Timeline.Add(v.license, 'impound', ('%s (%s) en fourrière : %s'):format(v.label, plate, why), 'warn')
end
AddEventHandler('pb_panel:impounded', function(plate, reason) vehicleSms(plate, ('mis en fourrière (%s).'):format(tostring(reason or 'sans motif'))) end)
AddEventHandler('pb_panel:vehicleWrecked', function(_, plate) vehicleSms(plate, 'détruit, son épave a été remorquée.') end)
function Co.AbandonTick()
    if cfg('abandon', true) == false or not (G.Garage and G.Garage.Impound) then return 0 end
    local t, n = now(), 0
    local offMin, goneMin = num('abandon_offline_min', 20) * 60, num('abandon_gone_min', 15) * 60
    for _, v in ipairs(DB.q("SELECT s.plate, s.net, s.out_at, v.license, v.gang, v.biz FROM pb_vehicle_state s JOIN pb_vehicles v ON v.plate = s.plate WHERE s.state = 'out'") or {}) do
        local inWorld = G.Garage.InWorld and G.Garage.InWorld(v)
        local why
        if inWorld == false then
            gone[v.plate] = gone[v.plate] or t
            if t - gone[v.plate] >= goneMin then why = 'retrouvé par la fourrière' end
        else
            gone[v.plate] = nil
            local lic = v.license or ''
            if lic ~= '' and (v.gang or '') == '' and (v.biz or '') == '' and not srcOf(lic) and offAt[lic] and t - offAt[lic] >= offMin then
                local occupied = false
                if inWorld then pcall(function() local e = NetworkGetEntityFromNetworkId(v.net) occupied = e and GetPedInVehicleSeat(e, -1) ~= 0 end) end
                if not occupied then why = 'abandonné après le départ de son propriétaire' end
            end
        end
        if why then
            gone[v.plate] = nil
            if G.Garage.Impound(v.plate, why) then n = n + 1 end
        end
    end
    return n
end
CreateThread(function() while true do Wait(120000) pcall(Co.AbandonTick) end end)

-- Secours --------------------------------------------------------------------------------------------------------------------------------------
-- entreprise des secours : la première de type « ems » active
function Co.Hospital()
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do if b.kind == 'ems' and PB.ToBool(b.enabled) then return b end end
end
-- réapparition payée : l'argent va à la caisse de l'hôpital ; sans argent : facture de l'hôpital (qui suit le recouvrement)
function Co.HospitalCharge(src, cost, paid)
    local p = G.Get(src)
    local h = Co.Hospital()
    if not p or not h or cost <= 0 then return false end
    if paid then
        if cfg('hospital_pay', true) ~= false then G.Eco.Book(acct(h.id), cost, 'Soins : réapparition', p.license) end
        G.Timeline.Add(p.license, 'care', ('Réapparition à l\'hôpital (%s payés)'):format(money(cost)), 'info')
        return true
    end
    if cfg('hospital_bill', true) == false then return false end
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { h.id, p.license, nameOf(p.license), cost, "Soins à l'hôpital", 'invoice', 'pending', h.label, '', now() })
    sms(p.license, 'hopital', ("Facture de soins de %s : %s. À régler dans votre téléphone (Factures) sous %d jours."):format(h.label, money(cost), num('late_days', 3)))
    G.Timeline.Add(p.license, 'care', ('Réapparition à l\'hôpital : facture #%s de %s'):format(tostring(id), money(cost)), 'warn')
    return true
end
-- joueur à terre : alerte automatique des secours s'il n'a pas appelé lui-même
local downAt = {}
AddEventHandler('pb_panel:playerDied', function(src)
    local p = G.Get(src)
    if p then G.Timeline.Add(p.license, 'down', 'À terre / dans le coma', 'warn') end
    if cfg('auto_ems', true) == false then return end
    local stamp = now()
    downAt[src] = stamp
    SetTimeout(math.max(5, num('auto_ems_secs', 20)) * 1000, function()
        local pl = G.Get(src)
        if downAt[src] ~= stamp or not pl or not PB.ToBool(pl.row.dead) then return end
        if G.EmsAlert then G.EmsAlert(src, true) end
    end)
end)
AddEventHandler('pb_panel:emsCalled', function(src) downAt[src] = nil end)
AddEventHandler('pb_panel:playerRespawned', function(src) downAt[src] = nil end)
AddEventHandler('playerDropped', function() downAt[source] = nil end)

-- Entreprises ----------------------------------------------------------------------------------------------------------------------------------
-- service : remis à zéro à la déconnexion (sinon l'employé revient « en service » en civil) et au démarrage du serveur
AddEventHandler('playerDropped', function()
    if cfg('duty_reset', true) == false then return end
    local p = G.Get(source)
    if p then DB.exec('UPDATE pb_biz_members SET on_duty = 0 WHERE license = ? AND on_duty = 1', { p.license }) end
end)
PB.OnReady(function() if cfg('duty_reset', true) ~= false then pcall(DB.exec, 'UPDATE pb_biz_members SET on_duty = 0 WHERE on_duty = 1', {}) end end)
-- paie : le patron connecté est prévenu (une fois par heure) quand la caisse ne couvre plus la paie des employés en service
local warned = {}
function Co.PayrollTick()
    if cfg('payroll_warn', true) == false or not G.Biz then return 0 end
    local need, bosses, n = {}, {}, 0
    for id in pairs(G.Players()) do
        local c = G.Biz.Ctx(id)
        if c and c.biz.pay_from == 'society' then
            if c.duty then need[c.biz.id] = (need[c.biz.id] or 0) + (tonumber(c.grade.salary) or 0) end
            if c.boss then bosses[c.biz.id] = bosses[c.biz.id] or {} table.insert(bosses[c.biz.id], id) end
        end
    end
    for bid, amount in pairs(need) do
        local bal = G.Eco.Balance(acct(bid))
        if amount > 0 and bal < amount and (not warned[bid] or now() - warned[bid] > 3600) then
            warned[bid] = now()
            for _, s in ipairs(bosses[bid] or {}) do
                G.Notify(s, { type = 'warn', title = 'Caisse insuffisante', text = ('La prochaine paie coûte %s, la caisse n\'a que %s : les employés ne seront pas payés. Dépose de l\'argent dans la caisse.'):format(money(amount), money(bal)), duration = 12000 })
                n = n + 1
            end
        end
    end
    return n
end
CreateThread(function() while true do Wait(600000) pcall(Co.PayrollTick) end end)

-- Panel ---------------------------------------------------------------------------------------------------------------------------------------
PB.Action('coherence.warrant.close', 'coherence.manage', function(ctx, p)
    if not Co.CloseWarrant(p.id, ctx.actor and ctx.actor.name or 'staff') then return false, 'Mandat introuvable ou déjà levé.' end
    ctx.audit('justice', 'warrant.close', tostring(p.id))
    ctx.toast = 'Mandat levé.'
    return true
end)
PB.Action('coherence.run', 'coherence.manage', function(ctx)
    local a, b, c = Co.RecoveryTick(), Co.AbandonTick(), Co.PayrollTick()
    ctx.audit('config', 'coherence.run', 'maintenant')
    ctx.toast = ('Recouvrement : %d facture(s) traitée(s) · fourrière : %d véhicule(s) · paie : %d alerte(s).'):format(a, b, c)
    return true
end)
PB.Action('coherence.payfrom', 'coherence.manage', function(ctx, p)
    local v = p.to == 'society' and 'society' or 'free'
    local n = DB.exec('UPDATE pb_biz SET pay_from = ?', { v })
    ctx.audit('config', 'coherence.payfrom', v, nil, nil, { entreprises = n })
    ctx.toast = v == 'society' and 'Toutes les entreprises paient maintenant leurs salaires avec leur caisse.' or "Les salaires sont de nouveau versés par l'État."
    return true
end, { confirm = { title = 'Changer la source des salaires de toutes les entreprises ?', text = 'Avec la caisse : un employé n\'est payé que si la caisse de son entreprise peut le payer.' } })
local form = PB.Form.Cfg({ ns = 'coherence', id = 'settings', title = 'Réglages', perm = 'coherence.manage', cols = 2, fields = {
    { k = 'recovery', type = 'toggle', label = 'Recouvrement des factures et amendes impayées', default = true },
    { k = 'late_days', type = 'number', label = 'Majoration après (jours)', default = 3, min = 1, max = 60 },
    { k = 'surcharge', type = 'number', label = 'Majoration (%)', default = 10, min = 0, max = 200 },
    { k = 'seize_days', type = 'number', label = 'Saisie sur le compte après (jours)', default = 7, min = 2, max = 120 },
    { k = 'warrant', type = 'toggle', label = 'Mandat si la saisie ne suffit pas', default = true },
    { k = 'warrant_min', type = 'number', label = 'Mandat à partir d\'un reste dû de ($)', default = 500, min = 0, max = 10000000 },
    { k = 'police_notify', type = 'toggle', label = 'Prévenir la police (nouveau mandat, recherché qui se connecte)', default = true },
    { k = 'abandon', type = 'toggle', label = 'Fourrière automatique des véhicules abandonnés ou disparus', default = true },
    { k = 'abandon_offline_min', type = 'number', label = 'Propriétaire déconnecté depuis (minutes)', default = 20, min = 5, max = 1440 },
    { k = 'abandon_gone_min', type = 'number', label = 'Véhicule disparu du monde depuis (minutes)', default = 15, min = 2, max = 1440 },
    { k = 'impound_sms', type = 'toggle', label = 'SMS au propriétaire (fourrière, épave)', default = true },
    { k = 'auto_ems', type = 'toggle', label = 'Alerte automatique des secours quand un joueur est à terre', default = true },
    { k = 'auto_ems_secs', type = 'number', label = 'Délai avant l\'alerte automatique (secondes)', default = 20, min = 5, max = 300 },
    { k = 'hospital_pay', type = 'toggle', label = "Frais de réapparition versés à la caisse de l'hôpital (entreprise de secours)", default = true },
    { k = 'hospital_bill', type = 'toggle', label = "Sans argent : facture de l'hôpital au lieu de soins gratuits", default = true },
    { k = 'duty_reset', type = 'toggle', label = 'Fin de service à la déconnexion', default = true },
    { k = 'payroll_warn', type = 'toggle', label = 'Prévenir le patron quand la caisse ne couvre plus la paie', default = true },
} })
PB.Module({
    id = 'coherence', label = 'Cohérence de la ville', icon = 'link', group = 'Serveur', order = 83, perm = 'coherence.manage', hint = 'Recouvrement, mandats, fourrière automatique, secours',
    caps = function()
        return PB.Capsify({
            { 'Factures et amendes impayées', 'ok', 'Majoration, puis saisie sur le compte (même hors ligne), puis mandat pour le reste. SMS du Trésor public à chaque étape.' },
            { 'Mandats', 'ok', 'Visibles dans la tablette de la police (Citoyens et amendes) ; levés à l\'arrestation ou au paiement.' },
            { 'Fourrière automatique', 'ok', 'Véhicule laissé en ville par un joueur parti, ou disparu du monde : envoyé en fourrière, SMS au propriétaire.' },
            { 'Secours', 'ok', 'Alerte automatique des secouristes ; frais d\'hôpital versés à la caisse des secours ; facture si le joueur n\'a pas l\'argent.' },
            { 'Disparition d\'un véhicule du monde', 'warn', 'Lue avec OneSync ; sans OneSync, seule la règle « propriétaire parti » s\'applique.' },
        })
    end,
    doc = "## Cohérence de la ville\nRelie les systèmes entre eux : une facture impayée finit en saisie puis en mandat, un véhicule abandonné finit à la fourrière avec un SMS, un joueur à terre alerte les secours, l'hôpital encaisse les soins.\n\nTout se règle dans **Réglages**. **Lancer maintenant** applique tout de suite les règles (sinon : toutes les 2 à 10 minutes).",
    view = function(ctx)
        return { tabs = {
            { id = 'overview', label = 'Vue d\'ensemble', icon = 'link', build = function()
                local late = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE status = 'pending' AND stage >= 1") or {}
                local pend = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE status = 'pending'") or {}
                local w = DB.one("SELECT COUNT(*) AS n FROM pb_warrants WHERE status = 'open'") or {}
                local imp = DB.one("SELECT COUNT(*) AS n FROM pb_vehicle_state WHERE state = 'impound'") or {}
                local h = Co.Hospital()
                local soc = DB.one("SELECT COUNT(*) AS n FROM pb_biz WHERE pay_from = 'society'") or {}
                local all = DB.one('SELECT COUNT(*) AS n FROM pb_biz') or {}
                return { B.stats({ { label = 'Factures en attente', value = tostring(pend.n or 0), icon = 'file', sub = money(pend.s) }, { label = 'En retard (majorées)', value = tostring(late.n or 0), icon = 'alert', sub = money(late.s) },
                        { label = 'Mandats en cours', value = tostring(w.n or 0), icon = 'shield' }, { label = 'Véhicules en fourrière', value = tostring(imp.n or 0), icon = 'car' } }),
                    B.notice(h and 'info' or 'warn', h and ("Hôpital : « " .. h.label .. " » encaisse les frais de réapparition et facture les joueurs sans argent.") or "Aucune entreprise de secours (type EMS) : les frais de réapparition ne vont à personne et aucune facture n'est émise."),
                    B.actions({ { action = 'coherence.run', label = 'Lancer maintenant', icon = 'refresh', primary = true },
                        { action = 'coherence.payfrom', label = ('Salaires payés par la caisse (%d / %d entreprises)'):format(tonumber(soc.n) or 0, tonumber(all.n) or 0), icon = 'coins', payload = { to = 'society' } },
                        { action = 'coherence.payfrom', label = "Salaires versés par l'État", icon = 'building', payload = { to = 'free' } } }, 'Actions') }
            end },
            { id = 'warrants', label = 'Mandats', icon = 'shield', build = function()
                local rows = {}
                for _, r in ipairs(Co.OpenWarrants()) do
                    rows[#rows + 1] = { who = r.name, reason = r.reason, amount = r.amount > 0 and money(r.amount) or '', at = r.at, here = srcOf(r.license) and { text = 'En ville', tone = 'warn' } or { text = 'Absent', tone = 'off' },
                        actions = { { action = 'coherence.warrant.close', label = 'Lever', icon = 'check', payload = { id = r.id }, confirm = 'Lever ce mandat ?' } } }
                end
                return { B.table({ id = 'cwr', title = 'Mandats en cours', columns = { { k = 'who', label = 'Personne' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Reste dû' }, { k = 'here', label = 'Présence', type = 'badge' }, { k = 'at', label = 'Émis', type = 'date' } }, rows = rows, empty = 'Aucun mandat.' }) }
            end },
            { id = 'late', label = 'Impayés', icon = 'alert', build = function()
                local rows = {}
                for _, i in ipairs(DB.q("SELECT i.*, b.label AS blabel FROM pb_biz_invoices i LEFT JOIN pb_biz b ON b.id = i.biz_id WHERE i.status = 'pending' ORDER BY i.at LIMIT 100") or {}) do
                    rows[#rows + 1] = { who = i.name, from = i.kind == 'fine' and 'Amende' or (i.blabel or i.biz_id), reason = i.reason, amount = money(i.amount), at = i.at,
                        stage = ({ [0] = { text = 'Normale', tone = 'off' }, [1] = { text = 'Majorée', tone = 'warn' }, [2] = { text = 'Saisie, mandat', tone = 'bad' } })[tonumber(i.stage) or 0] }
                end
                return { B.table({ id = 'clt', title = 'Factures et amendes en attente', columns = { { k = 'who', label = 'Débiteur' }, { k = 'from', label = 'De' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant' }, { k = 'stage', label = 'Étape', type = 'badge' }, { k = 'at', label = 'Émise', type = 'date' } }, rows = rows, empty = 'Aucun impayé.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
