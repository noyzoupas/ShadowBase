-- Gamertags (noms au-dessus des joueurs) : le serveur compose ce qui peut être montré (nom RP, ID, métier, rang staff en service, état),
-- le client ne fait que placer les étiquettes à l'écran. Rien n'est envoyé aux joueurs qui n'ont pas le droit de les voir.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local T = {}
G.Tags = T

P.Register('tags.edit', 'Modifier les gamertags', 'tags', true)
PB.Cfg.Define('tags', {
    enabled = true, show_to = 'staff', staff_view_v1 = false, distance = 25, style = 'badge', name_mode = 'rp', show_id = true, show_job = true, show_staff = true, staff_duty_only = true,
    show_self = true, self_v2 = false, staff_only = true, show_dead = true, show_talking = true, max_shown = 24, accent = 'rank', staff_label_hide = {},
    show_gang = true, walls = 'los', name_color_default = '#d9cb8f', talk_color = '#5fd4f4', show_pseudo = true, prefix_fmt = '[{id}]', show_bar = 'health', show_star = true, allow_player_color = false, style_v3 = false, gang_source = 'native', gang_resource = '', gang_export = '', gang_default_color = '#dfe2e7', gangs = { 'ballas|Ballas|#b58cff', 'families|Families|#7be0a4', 'vagos|Vagos|#ffb457' },
})

-- Première venue de chaque compte (mention « (Nouveau) » sur le gamertag pendant les premières heures)
PB.Migrate('375_first_seen', 'Gamertags : première venue des joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_first_seen (license VARCHAR(64) NOT NULL PRIMARY KEY, at INT NOT NULL DEFAULT 0)]],
})
local firstSeen = {}
table.insert(G.beginHooks, function(src)
    local p = G.Players()[src]
    if not p then return end
    local r = DB.one('SELECT at FROM pb_first_seen WHERE license = ?', { p.license })
    if not r then DB.exec('INSERT INTO pb_first_seen (license, at) VALUES (?, ?)', { p.license, os.time() }) r = { at = os.time() } end
    firstSeen[src] = tonumber(r.at) or os.time()
end)
AddEventHandler('playerDropped', function() firstSeen[source] = nil end)

PB.Migrate('071_tag_gang', 'Gamertags : gang des joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_tag_gang (license VARCHAR(64) NOT NULL, gang VARCHAR(32) NOT NULL, since INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
})
local function cfg(k, d) return PB.Cfg.Get('tags', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

-- Gang du joueur : défini dans le panel (onglet Gangs) ou par un autre script (exports.pb_panel:SetPlayerGang).
local gangOf = {}       -- src -> id du gang
local nativeGangs, nativeLoaded = {}, false
function T.RefreshNative()
    nativeGangs, nativeLoaded = {}, true
    local ok, rows = pcall(DB.q, "SELECT name, label, color, otype FROM pb_org_groups WHERE kind = 'gang' AND name <> 'none'", {})
    for _, r in ipairs(ok and rows or {}) do
        nativeGangs[r.name] = { id = r.name, label = clean(r.label, 24), color = (r.color or ''):match('^#%x%x%x%x%x%x$'), type = (r.otype or '') ~= '' and r.otype or 'gang' }
    end
end
local function gangDefs()
    if not nativeLoaded then T.RefreshNative() end
    local out = {}
    for id, d in pairs(nativeGangs) do out[id] = d end
    for _, line in ipairs(cfg('gangs', {}) or {}) do
        local id, label, col = tostring(line):match('^([%w_%-]+)|([^|]+)|?(#?%x*)$')
        if id then out[id] = { id = id, label = clean(label, 24), color = (col and col:match('^#%x%x%x%x%x%x$')) or nil } end
    end
    return out
end
T.GangDefs = gangDefs
-- Source externe : gang lu depuis l'export d'une ressource de ton serveur.
local extCache = {}
local function external(src)
    local mode = cfg('gang_source', 'native')
    if mode == 'native' then return false end
    local t = os.time()
    local c = extCache[src]
    if c and t - c.t < 5 then return c.id end
    local ok, id = pcall(function()
        if mode == 'custom' then
            local res, fn = cfg('gang_resource', ''), cfg('gang_export', '')
            if res == '' or fn == '' then return nil end
            return exports[res][fn](exports[res], src)
        end
    end)
    id = ok and type(id) == 'string' and id:match('^[%w_%-]+$') and id ~= 'none' and id or nil
    extCache[src] = { t = t, id = id }
    return id
end
AddEventHandler('playerDropped', function() extCache[source] = nil end)
function T.Gang(src)
    local ext = external(src)
    if ext ~= false then
        if not ext then return nil end
        local d = gangDefs()[ext]
        if d then return d end
        return { id = ext, label = clean((ext:gsub('_', ' '):gsub('^%l', string.upper)), 24), color = cfg('gang_default_color', '#dfe2e7') }
    end
    local id = gangOf[src]
    local d = id and gangDefs()[id]
    if not d then return nil end
    return d
end
function T.SetGang(src, id)
    local p = G.Players()[tonumber(src) or -1]
    if not p then return false, 'Joueur hors ligne.' end
    if id == nil or id == '' then
        DB.exec('DELETE FROM pb_tag_gang WHERE license = ?', { p.license }) gangOf[src] = nil
        TriggerEvent('pb_panel:gangChanged', tonumber(src), nil)
        return true
    end
    id = tostring(id)
    if not gangDefs()[id] then return false, 'Gang inconnu.' end
    DB.exec('REPLACE INTO pb_tag_gang (license, gang, since) VALUES (?, ?, ?)', { p.license, id, os.time() })
    gangOf[src] = id
    TriggerEvent('pb_panel:gangChanged', tonumber(src), id)
    return true
end
local function loadGang(src)
    local p = G.Players()[src]
    if not p then return end
    local r = DB.one('SELECT gang FROM pb_tag_gang WHERE license = ?', { p.license })
    gangOf[src] = r and r.gang or nil
end
table.insert(G.beginHooks, function(src) loadGang(src) end)
AddEventHandler('playerDropped', function() gangOf[source] = nil end)
exports('SetPlayerGang', function(src, id) return T.SetGang(src, id) end)
exports('GetPlayerGang', function(src) local g = T.Gang(tonumber(src) or -1) return g and g.id or nil end)

local function isStaffViewer(src)
    return P.Has(src, 'staff.menu')
end

-- Étiquette d'un joueur, telle que les autres la voient
function T.Entry(src, p)
    local mode = cfg('name_mode', 'rp')
    local name
    if mode == 'steam' then name = GetPlayerName and GetPlayerName(src) or nil
    elseif mode == 'id' then name = nil
    else
        local id = G.Identity(src)
        if id and id.created and id.firstname ~= '' then name = (id.firstname .. ' ' .. (id.lastname or '')) end
    end
    local e = { i = src }
    if cfg('show_staff', true) ~= false then
        local gname, g = P.GetGrade(src)
        local hidden = false
        for _, h in ipairs(cfg('staff_label_hide', {}) or {}) do if h == gname then hidden = true end end
        if g and not hidden and (not cfg('staff_duty_only', true) or (G.Staff and G.Staff.OnDuty(src))) then e.s = clean(g.label, 24) e.sc = g.color e.gcol = g.color end
    end
    if cfg('staff_only', true) ~= false and not e.s then return nil end   -- pas d'étiquette : rien d'autre à calculer
    e.n = clean(name or ('Joueur ' .. src), 40)
    if cfg('show_id', true) ~= false then e.id = src end
    e.c = cfg('name_color_default', '#d9cb8f')
    if cfg('show_pseudo', true) ~= false and GetPlayerName then e.p = clean(GetPlayerName(src), 24) end
    if cfg('show_job', true) ~= false and G.Biz and G.Biz.Job then
        local j = G.Biz.Job(src)
        if j then e.j = clean(j.label, 30) e.jg = clean(j.gradeLabel, 24) e.jc = j.color end
        if j then local b = G.Biz.Get(j.biz) if b and b.color then e.jc = b.color end end
    end
    if cfg('show_gang', true) ~= false then
        local g = T.Gang(src)
        if g then e.g = g.label e.gc = g.color end
    end
    if e.s and cfg('staff_only', true) ~= false and type(e.gcol) == 'string' and e.gcol:match('^#%x%x%x%x%x%x$') then e.c = e.gcol end
    e.gcol = nil
    if cfg('show_dead', true) ~= false and PB.ToBool(p.row.dead) then e.d = 1 end
    -- style « Sensity » : [VIP*] [entreprise] [gang] / [ID][rôle] Nom (Nouveau) / Ping
    if G.Vip and G.Vip.Is and G.Vip.Is(src) then e.v = clean(PB.Cfg.Get('vip', 'label', 'VIP'), 20) end
    e.r = e.s or 'Joueur'
    local fs = firstSeen[src]
    if fs and os.time() - fs < (tonumber(cfg('new_hours', 72)) or 72) * 3600 then e.nw = 1 end
    if cfg('show_ping', true) ~= false and GetPlayerPing then local ok, pg = pcall(GetPlayerPing, src) if ok and tonumber(pg) then e.pg = math.floor(tonumber(pg) / 5 + 0.5) * 5 end end
    if e.s and cfg('show_star', true) ~= false then e.st = 1 end
    local fmt = tostring(cfg('prefix_fmt', '[{id}]') or '')
    if fmt ~= '' then
        e.pf = clean((fmt:gsub('{id}', tostring(src)):gsub('{job}', e.j or ''):gsub('{gang}', e.g or '')), 32)
    end
    return e
end

function T.Build()
    local list = {}
    for src, p in pairs(G.Players()) do
        if PB.ToBool(p.row.created) then local e = T.Entry(src, p) if e then list[#list + 1] = e end end
    end
    table.sort(list, function(a, b) return a.i < b.i end)
    return list
end

local lastSent = {}
function T.Push(force)
    local on = cfg('enabled', true)
    local showTo = cfg('show_to', 'staff')
    if on and showTo == 'staff' then
        local any = false
        for src in pairs(G.Players()) do if isStaffViewer(src) then any = true break end end
        if not any then on = false end
    end
    local list = on and T.Build() or {}
    local full = PB.Json(list)
    for src in pairs(G.Players()) do
        local j = full
        if not on then j = '[]'
        elseif showTo == 'staff' and not isStaffViewer(src) then j = '[]' end
        if force or lastSent[src] ~= j then
            lastSent[src] = j
            TriggerClientEvent('pb:g:tags', src, j)
            local w = cfg('walls', 'los')
            TriggerClientEvent('pb:g:tags:walls', src, (w == 'all' or (w == 'staff' and isStaffViewer(src))) and 1 or 0)
        end
    end
end
AddEventHandler('playerDropped', function() lastSent[source] = nil end)
table.insert(G.beginHooks, function(src) lastSent[src] = nil end)
PB.Cfg.OnChange('tags', function() T.Push(true) end)

-- Une fois : les noms, grades et ID ne sont plus envoyés aux joueurs (seulement au staff), même sur un serveur réglé avant ce changement
PB.OnReady(function()
    if cfg('staff_view_v1', false) ~= true then
        PB.Cfg.Set('tags', 'show_to', 'staff', nil, 'Étiquettes : visibles par le staff seulement')
        PB.Cfg.Set('tags', 'staff_view_v1', true, nil, 'Étiquettes : réglage appliqué')
    end
end)

CreateThread(function()
    while true do
        Wait(2500)
        pcall(T.Push)
    end
end)

local look = Form.Cfg({ ns = 'tags', id = 'look', title = 'Gamertags', perm = 'tags.edit', cols = 2, fields = {
    { k = 'name_color_default', type = 'color', label = 'Couleur du nom par défaut', default = '#d9cb8f', hint = "Couleur utilisée si le grade n'a pas de couleur (ou si les noms ne sont pas réservés au staff)." },
    { k = 'talk_color', type = 'color', label = 'Couleur du nom quand le joueur parle', default = '#5fd4f4' },
    { k = 'staff_only', type = 'toggle', label = 'Noms au-dessus des têtes : staff seulement', default = true, hint = "Seuls les membres du staff (en service si l'option ci-dessous est active) ont un nom au-dessus de la tête. Leur couleur est celle de leur grade (Permissions › Grades)." },
    { k = 'show_pseudo', type = 'toggle', label = 'Afficher le pseudo FiveM après le nom (Nom | Pseudo)', default = true },
    { k = 'prefix_fmt', type = 'text', label = 'Préfixe devant le nom', default = '[{id}]', maxlen = 24, hint = 'Variables : {id}, {job}, {gang}. Ex. [ID {id}]. Vide = aucun préfixe.' },
    { k = 'show_bar', type = 'select', label = 'Barre sous le nom', opts = { { 'health', 'Santé' }, { 'none', 'Aucune' } }, default = 'health' },
    { k = 'show_star', type = 'toggle', label = 'Étoile après le nom pour le staff en service', default = true },
    { k = 'show_ping', type = 'toggle', label = 'Ping sous le nom (style Sensity)', default = true },
    { k = 'new_hours', type = 'number', label = '« (Nouveau) » pendant (heures après la première venue)', default = 72, min = 0, max = 720 },
    { k = 'enabled', type = 'toggle', label = 'Gamertags actifs', default = true },
    { k = 'show_to', type = 'select', label = 'Qui voit les étiquettes', opts = { { 'staff', 'Le staff seulement (recommandé)' }, { 'all', 'Tout le monde' } }, default = 'staff', hint = "« Staff seulement » : les autres joueurs ne reçoivent aucune information." },
    { k = 'style', type = 'select', label = 'Style', opts = { { 'sensity', 'Sensity ([VIP*] [entreprise] [gang], [ID][rôle] Nom, ping) — style de base' }, { 'badge', 'Badge (gang, [ID] Nom | pseudo ★, barre)' }, { 'clean', 'Épuré (texte : gang, nom, entreprise)' }, { 'pill', 'Pastille (nom + rang)' }, { 'card', 'Carte (nom, métier, rang)' }, { 'minimal', 'Minimal (nom seul)' } }, default = 'badge' },
    { k = 'name_mode', type = 'select', label = 'Nom affiché', opts = { { 'rp', 'Prénom Nom du personnage' }, { 'steam', 'Pseudo FiveM' }, { 'id', 'Numéro seulement' } }, default = 'rp' },
    { k = 'distance', type = 'number', label = 'Distance (mètres)', default = 25, min = 5, max = 80 },
    { k = 'max_shown', type = 'number', label = "Nombre d'étiquettes maximum à l'écran", default = 24, min = 4, max = 60 },
    { k = 'show_id', type = 'toggle', label = "Afficher l'ID", default = true },
    { k = 'show_job', type = 'toggle', label = "Afficher l'entreprise et le grade", default = true },
    { k = 'show_gang', type = 'toggle', label = 'Afficher le gang au-dessus du nom', default = true },
    { k = 'walls', type = 'select', label = 'Étiquettes à travers les murs', opts = { { 'los', 'Non : seulement les personnes en vue' }, { 'staff', 'Oui pour le staff' }, { 'all', 'Oui pour tout le monde' } }, default = 'los',
      hint = "Le jeu ne cache pas une étiquette 2D derrière un mur ; ce réglage choisit si on la garde ou non. Limité par la distance d'affichage." },
    { k = 'gang_source', type = 'select', label = 'Source des gangs', opts = { { 'native', 'Gangs de cette base (onglet Gangs)' }, { 'custom', "Export d'une autre ressource" } }, default = 'native',
      hint = "Export : la ressource doit fournir une fonction qui reçoit l'ID du joueur et renvoie le nom du gang (texte). Un gang absent de la liste ci-dessous est affiché avec son nom brut." },
    { k = 'gang_resource', type = 'text', label = "Ressource de l'export (source « export »)", default = '', maxlen = 40, pattern = '^[%w_%-]*$' },
    { k = 'gang_export', type = 'text', label = "Nom de la fonction exportée", default = '', maxlen = 40, pattern = '^[%w_]*$' },
    { k = 'gang_default_color', type = 'color', label = 'Couleur des gangs inconnus de la liste', default = '#dfe2e7' },
    { k = 'gangs', type = 'list', label = 'Gangs disponibles (id|nom|#couleur)', default = { 'ballas|Ballas|#b58cff', 'families|Families|#7be0a4', 'vagos|Vagos|#ffb457' }, maxitems = 30, maxlen = 48, pattern = '^[%w_%-]+|[^|]+|?#?%x*$', wide = true, hint = 'Chaque joueur peut appartenir à un gang : onglet Gangs.' },
    { k = 'show_staff', type = 'toggle', label = 'Afficher le rang staff', default = true },
    { k = 'staff_duty_only', type = 'toggle', label = 'Rang staff visible seulement en service', default = true, hint = 'Évite de montrer un modérateur hors service.' },
    { k = 'staff_label_hide', type = 'list', label = 'Rangs staff à ne jamais afficher (noms techniques)', default = {}, maxitems = 10, maxlen = 32, pattern = '^[%w_%-]+$', wide = true },
    { k = 'show_dead', type = 'toggle', label = "Marquer les joueurs inconscients", default = true },
    { k = 'show_self', type = 'toggle', label = "Afficher aussi ma propre étiquette", default = true },
    { k = 'show_talking', type = 'toggle', label = 'Indiquer qui parle', default = true },
    { k = 'accent', type = 'select', label = "Couleur d'accent", opts = { { 'rank', 'Rang staff, sinon entreprise, sinon serveur' }, { 'job', "Entreprise, sinon serveur" }, { 'server', 'Couleur du serveur' } }, default = 'rank' },
} })

PB.Action('tags.gang.set', 'tags.edit', function(ctx, p)
    local v = p.values or {}
    local src = tonumber(v.player)
    if not src or not G.Players()[src] then return false, "Saisis l'ID d'un joueur en ligne." end
    local ok, e = T.SetGang(src, v.gang)
    if not ok then return false, e end
    ctx.audit('config', 'tags.gang', tostring(src), nil, { gang = v.gang })
    T.Push(true)
    ctx.toast = 'Gang enregistré.'
    return true
end)
PB.Action('tags.gang.clear', 'tags.edit', function(ctx, p)
    local lic = tostring(p.license or '')
    DB.exec('DELETE FROM pb_tag_gang WHERE license = ?', { lic })
    for src, pl in pairs(G.Players()) do if pl.license == lic then gangOf[src] = nil end end
    ctx.audit('config', 'tags.gang.retirer', lic)
    T.Push(true)
    ctx.toast = 'Retiré du gang.'
    return true
end)

PB.Module({
    id = 'tags', label = 'Gamertags', icon = 'tag', group = 'Serveur', order = 142, perm = 'tags.edit', hint = 'Noms au-dessus des joueurs',
    caps = function()
        return PB.Capsify({
            { 'Nom, ID, entreprise, grade et rang staff', 'ok', 'Composés par le serveur, placés à l\'écran par le client.' },
            { 'Quatre styles', 'ok', 'Épuré (texte), pastille, carte ou minimal.' },
            { 'Gang au-dessus du nom', 'ok', "Gangs natifs (onglet Gangs, exports.pb_panel:SetPlayerGang) ou lus depuis l'export d'une ressource. Non testé en jeu : seul un faux framework est simulé." },
            { 'Visibilité réservée au staff', 'ok', "Les autres joueurs ne reçoivent rien." },
            { 'Voir à travers les murs', 'ok', "Réglage : non (en vue seulement), staff ou tout le monde. Jamais testé dans un vrai FiveM ici." },
        })
    end,
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'tags', title = 'Gamertags (exemple)', form = 'tags.look', cfg = { tags = PB.Cfg.All('tags'), menus = PB.Cfg.All('menus') } } } end },
            { id = 'look', label = 'Réglages', icon = 'sliders', build = function() return { look(ctx) } end },
            { id = 'gangs', label = 'Gangs', icon = 'users', build = function()
                local opts, rows = {}, {}
                for id, d in pairs(gangDefs()) do opts[#opts + 1] = { id, d.label } end
                table.sort(opts, function(a, b) return a[1] < b[1] end)
                local names = {}
                for src, pl in pairs(G.Players()) do names[pl.license] = (GetPlayerName and GetPlayerName(src)) or ('#' .. src) end
                local defs = gangDefs()
                for _, r in ipairs(DB.q('SELECT license, gang, since FROM pb_tag_gang ORDER BY since DESC LIMIT 300') or {}) do
                    local d = defs[r.gang]
                    rows[#rows + 1] = { who = names[r.license] or r.license, gang = d and d.label or (r.gang .. ' (supprimé)'), since = r.since,
                        actions = ctx.has('tags.edit') and { { action = 'tags.gang.clear', label = 'Retirer', icon = 'trash', payload = { license = r.license } } } or nil }
                end
                local out = {}
                if ctx.has('tags.edit') then
                    out[#out + 1] = { type = 'form', id = 'tags.gang', title = 'Attribuer un gang', desc = "Le gang apparaît au-dessus du nom du joueur. Les gangs se définissent dans Réglages.", cols = 2, fields = {
                        { k = 'player', type = 'number', label = 'ID du joueur en ligne', min = 1, max = 65535, required = true },
                        { k = 'gang', type = 'select', label = 'Gang', options = opts, opts = opts, required = true },
                    }, values = {}, submit = { action = 'tags.gang.set', label = 'Attribuer' } }
                end
                out[#out + 1] = B.table({ id = 'tagsg', title = 'Membres', search = true, columns = { { k = 'who', label = 'Joueur' }, { k = 'gang', label = 'Gang', type = 'badge' }, { k = 'since', label = 'Depuis', type = 'date' } }, rows = rows, empty = 'Aucun membre.' })
                return out
            end },
        } }
    end,
})

PB.SelfTest.Add('gamertags', function(R)
    local s = cfg('style', 'badge')
    R.check(s == 'sensity' or s == 'badge' or s == 'clean' or s == 'pill' or s == 'card' or s == 'minimal', 'style des gamertags', 'valeur inconnue : ' .. tostring(s))
    local d = tonumber(cfg('distance', 25)) or 0
    R.check(d >= 5 and d <= 80, 'distance des gamertags', 'hors limites : ' .. d)
end)

-- Ma propre étiquette est visible par défaut (une seule fois : un choix fait ensuite dans le panel est conservé).
PB.OnReady(function()
    if PB.Cfg.Get('tags', 'style_v3', false) ~= true then
        PB.Cfg.Set('tags', 'style', 'badge', nil, 'Style de base : badge')
        PB.Cfg.Set('tags', 'style_v3', true, nil, 'Migration')
    end
    if PB.Cfg.Get('tags', 'self_v2', false) ~= true then
        PB.Cfg.Set('tags', 'show_self', true, nil, 'Étiquette personnelle visible par défaut')
        PB.Cfg.Set('tags', 'self_v2', true, nil, 'Migration')
    end
end)

-- Une fois : les gamertags passent au style « Sensity » (comme la capture) et tout le monde a une étiquette
-- (toujours visible par le staff seulement, réglage « Qui voit les étiquettes »)
PB.OnReady(function()
    if cfg('sensity_v1', false) ~= true then
        PB.Cfg.Set('tags', 'style', 'sensity', nil, 'Gamertags : style Sensity')
        PB.Cfg.Set('tags', 'staff_only', false, nil, 'Gamertags : style Sensity')
        PB.Cfg.Set('tags', 'sensity_v1', true, nil, 'Migration')
    end
end)
