-- Applications du téléphone : Appels (phonecall.lua), Messages, Contacts, Annuaire, Banque, Factures, Garage, GPS, Notes, Réglages (+ Calculatrice côté interface).
-- Tout passe par le serveur : le client n'envoie que des demandes (page, action) et le serveur répond avec les données déjà filtrées.
-- Les pages « blocs » de phone.lua restent en place (compatibilité) ; l'interface téléphone lit le champ `data`.
local G, DB = PB.G, PB.DB
local Ph = G.Phone

local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function cfg(k, d) return PB.Cfg.Get('phone', k, d) end

PB.Cfg.Define('phone', {
    anim = true, hide_apps = {}, ads_price = 50, ads_hours = 48, ads_max = 3,
    places = { 'Hôpital Pillbox|298.0|-584.0', 'Commissariat de Mission Row|441.0|-981.0', 'Legion Square|195.0|-934.0', 'Concessionnaire Simeon|-56.0|-1097.0', 'Aéroport de Los Santos|-1037.0|-2737.0', 'Plage de Vespucci|-1600.0|-1000.0' },
})

PB.Migrate('051_phone_apps', 'Téléphone : notes et préférences', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_notes (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, title VARCHAR(60) NOT NULL DEFAULT '', body VARCHAR(1500) NOT NULL DEFAULT '', updated INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_lic (license))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_prefs (license VARCHAR(64) NOT NULL, wall VARCHAR(12) NOT NULL DEFAULT 'dusk', dnd TINYINT(1) NOT NULL DEFAULT 0, sound TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (license))]]))
end)

local WALLS = { 'dusk', 'ocean', 'ember', 'forest', 'rose', 'mono', 'banner' }
local APPS = {   -- id, libellé, icône, page serveur (nil = côté interface seulement)
    { 'calls', 'Appels', 'phone', 'calls' }, { 'messages', 'Messages', 'chat', 'messages' }, { 'contacts', 'Contacts', 'users', 'contacts' }, { 'services', 'Annuaire', 'building', 'services' },
    { 'bank', 'Banque', 'card', 'bank' }, { 'bills', 'Factures', 'file', 'bills' }, { 'garage', 'Garage', 'car', 'garage' },
    { 'gps', 'GPS', 'pin', 'gps' }, { 'ads', 'Annonces', 'tag', 'ads' }, { 'taxi', 'Taxi', 'route', 'taxi' }, { 'deals', 'Contrats', 'file', 'deals' }, { 'notes', 'Notes', 'list', 'notes' }, { 'calc', 'Calculatrice', 'calc', nil }, { 'settings', 'Réglages', 'sliders', 'settings' },
}

local function prefs(license)
    local r = DB.one('SELECT wall, dnd, sound FROM pb_phone_prefs WHERE license = ?', { license })
    return { wall = r and r.wall or 'dusk', dnd = r and PB.ToBool(r.dnd) or false, sound = r == nil or PB.ToBool(r.sound) }
end
function Ph.Prefs(license) return prefs(license) end
local function savePrefs(license, p)
    DB.exec('INSERT INTO pb_phone_prefs (license, wall, dnd, sound) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE wall = VALUES(wall), dnd = VALUES(dnd), sound = VALUES(sound)', { license, p.wall, p.dnd and 1 or 0, p.sound and 1 or 0 })
end
local function pendingBills(license)
    local r = DB.one("SELECT COUNT(*) AS n FROM pb_biz_invoices WHERE license = ? AND status = 'pending'", { license })
    return r and r.n or 0
end
local function places()
    local out = {}
    for i, line in ipairs(cfg('places', {}) or {}) do
        local l, x, y = tostring(line):match('^([^|]+)|(%-?%d+%.?%d*)|(%-?%d+%.?%d*)$')
        if l then out[#out + 1] = { id = i, label = l, x = tonumber(x), y = tonumber(y) } end
    end
    return out
end
local function hiddenApps() local t = {} for _, a in ipairs(cfg('hide_apps', {}) or {}) do t[tostring(a)] = true end return t end

function Ph.Info(src)
    local p = G.Get(src)
    if not p then return nil end
    local pf = prefs(p.license)
    local hide, apps = hiddenApps(), {}
    local un, bills = Ph.Unread(p.license), pendingBills(p.license)
    for _, a in ipairs(APPS) do
        if not hide[a[1]] then apps[#apps + 1] = { id = a[1], label = a[2], icon = a[3], page = a[4], badge = a[1] == 'messages' and un or (a[1] == 'bills' and bills) or (a[1] == 'calls' and Ph.Missed and Ph.Missed(p.license)) or 0 } end
    end
    return { number = Ph.Number(p.license), name = Ph.Display(src), unread = un, bills = bills, wall = pf.wall, dnd = pf.dnd, sound = pf.sound, apps = apps, cash = p.row.cash, bank = p.row.bank, anim = cfg('anim', true) ~= false }
end

-- Pages (données structurées) ---------------------------------------------------------------------------------------------------------------
local DATA = {}
Ph.DATA = DATA
local function reg(name, title) Ph.PAGES[name] = Ph.PAGES[name] or function() return {}, title end end
for _, n in ipairs({ { 'calls', 'Appels' }, { 'bank', 'Banque' }, { 'bills', 'Factures' }, { 'garage', 'Garage' }, { 'gps', 'GPS' }, { 'ads', 'Annonces' }, { 'taxi', 'Taxi' }, { 'deals', 'Contrats' }, { 'notes', 'Notes' }, { 'settings', 'Réglages' } }) do reg(n[1], n[2]) end

DATA.home = function(src) return { info = Ph.Info(src) } end
DATA.messages = function(src)
    local p = G.Get(src)
    local out = {}
    for _, t in ipairs(Ph.Threads(p.license)) do
        out[#out + 1] = { num = t.num, label = Ph.LabelOf(p.license, t.num), last = t.last:sub(1, 80), mine = t.mine, at = Ph.Stamp(t.at), unread = t.unread, svc = t.num:match('^svc:') ~= nil or t.num:match('^sys:') ~= nil }
    end
    return { threads = out }
end
DATA.thread = function(src, s)
    local p = G.Get(src)
    local me, num = Ph.Number(p.license), s.thread
    if not num then return { empty = true } end
    local gid = Ph.GrpOf(num)
    if gid then
        local list = DB.q('SELECT id, from_num, body, at, pos FROM pb_phone_msgs WHERE to_num = ? ORDER BY id DESC LIMIT ?', { num, cfg('thread_view', 40) }) or {}
        local msgs = {}
        for i = #list, 1, -1 do local m = list[i] msgs[#msgs + 1] = { id = m.id, mine = m.from_num == me, who = m.from_num ~= me and (Ph.ContactName(p.license, m.from_num) or m.from_num) or nil, body = m.body, at = Ph.Stamp(m.at), reported = true, pos = (m.pos or '') ~= '' or nil } end
        if list[1] then DB.exec('UPDATE pb_phone_group_members SET last_read = ? WHERE group_id = ? AND license = ?', { list[1].id, gid, p.license }) end
        local members = {}
        for _, r in ipairs(DB.q('SELECT gm.license, n.number FROM pb_phone_group_members gm LEFT JOIN pb_phone_numbers n ON n.license = gm.license WHERE gm.group_id = ?', { gid }) or {}) do members[#members + 1] = r.license == p.license and 'Toi' or (Ph.ContactName(p.license, r.number or '') or r.number or '?') end
        return { num = num, label = Ph.LabelOf(p.license, num), group = true, members = members, msgs = msgs, canAdd = false, maxlen = cfg('msg_maxlen', 240) }
    end
    local list = DB.q('SELECT id, from_num, body, at, reported, pos FROM pb_phone_msgs WHERE ((from_num = ? AND to_num = ? AND del_from = 0) OR (from_num = ? AND to_num = ? AND del_to = 0)) ORDER BY id DESC LIMIT ?', { me, num, num, me, cfg('thread_view', 40) }) or {}
    local msgs = {}
    for i = #list, 1, -1 do local m = list[i] msgs[#msgs + 1] = { id = m.id, mine = m.from_num == me, body = m.body, at = Ph.Stamp(m.at), reported = PB.ToBool(m.reported), pos = (m.pos or '') ~= '' or nil } end
    local sys = num:match('^sys:') ~= nil
    local svc = num:match('^svc:') ~= nil or sys
    return { num = num, label = Ph.LabelOf(p.license, num), svc = svc, ro = sys or nil, msgs = msgs, canAdd = not svc and Ph.ContactName(p.license, num) == nil, maxlen = cfg('msg_maxlen', 240) }
end
DATA.contacts = function(src)
    local p = G.Get(src)
    local out = {}
    for _, c in ipairs(DB.q('SELECT id, name, number FROM pb_phone_contacts WHERE license = ? ORDER BY name', { p.license }) or {}) do out[#out + 1] = { id = c.id, name = c.name, number = c.number } end
    local blocked = {}
    for _, b in ipairs(DB.q('SELECT number FROM pb_phone_blocks WHERE license = ? ORDER BY at DESC', { p.license }) or {}) do blocked[#blocked + 1] = { number = b.number, name = Ph.ContactName(p.license, b.number) } end
    for _, c in ipairs(out) do c.blocked = Ph.Blocked(p.license, c.number) or nil end
    return { list = out, max = cfg('max_contacts', 60), me = Ph.Number(p.license), blocked = blocked }
end
DATA.services = function()
    local out = {}
    for _, b in ipairs(Ph.Services()) do out[#out + 1] = { id = b.id, name = b.label, duty = #Ph.OnDutyOf(b.id) } end
    -- ouvertes d'abord, puis par nom
    table.sort(out, function(a, b) if (a.duty > 0) ~= (b.duty > 0) then return a.duty > 0 end return a.name < b.name end)
    return { list = out }
end
DATA.bank = function(src)
    local p = G.Get(src)
    local kinds = { deposit = 'Dépôt', withdraw = 'Retrait', transfer_out = 'Virement émis', transfer_in = 'Virement reçu', fee = 'Frais', admin = 'Ajustement', salary = 'Salaire' }
    local tx = {}
    for _, r in ipairs(DB.q('SELECT kind, amount, other, note, at FROM pb_bank_tx WHERE license = ? ORDER BY id DESC LIMIT 14', { p.license }) or {}) do
        local plus = r.kind == 'deposit' or r.kind == 'transfer_in' or r.kind == 'salary' or (r.kind == 'admin' and r.amount > 0)
        tx[#tx + 1] = { label = kinds[r.kind] or r.kind, amount = r.amount, plus = plus, note = r.note, at = Ph.Stamp(r.at) }
    end
    local contacts = {}
    for _, c in ipairs(DB.q('SELECT name, number FROM pb_phone_contacts WHERE license = ? ORDER BY name LIMIT 30', { p.license }) or {}) do contacts[#contacts + 1] = { name = c.name, number = c.number } end
    local B = PB.Cfg.All('bank')
    return { bank = p.row.bank, cash = p.row.cash, iban = G.Bank and G.Bank.Iban(p.license) or '', tx = tx, contacts = contacts, min = tonumber(B.transfer_min) or 1, max = tonumber(B.transfer_max) or 250000, fee = tonumber(B.transfer_fee) or 0 }
end
DATA.bills = function(src)
    local p = G.Get(src)
    local out = {}
    for _, i in ipairs(DB.q('SELECT i.id, i.amount, i.reason, i.kind, i.status, i.at, b.label AS blabel FROM pb_biz_invoices i LEFT JOIN pb_biz b ON b.id = i.biz_id WHERE i.license = ? ORDER BY (i.status = ?) DESC, i.id DESC LIMIT 30', { p.license, 'pending' }) or {}) do
        out[#out + 1] = { id = i.id, from = i.blabel or '', reason = i.reason, amount = i.amount, fine = i.kind == 'fine', status = i.status, at = Ph.Stamp(i.at or 0) }
    end
    return { list = out, bank = p.row.bank }
end
DATA.garage = function(src)
    local p = G.Get(src)
    local out, pts = {}, {}
    for _, g in ipairs(G.Garage and G.Garage.Points() or {}) do pts[g.id] = g.label end
    local function add(v, group)
        local c = G.Garage.Condition and G.Garage.Condition(v.plate) or {}
        local w = G.Garage.Where and G.Garage.Where(v.plate, src) or {}
        out[#out + 1] = { plate = v.plate, label = v.label or v.model or v.plate, state = v.state, garage = pts[v.garage] or '', fuel = c.fuel, engine = c.engine, body = c.body, live = c.live or nil,
            where = w.text, canGo = w.x ~= nil or nil, group = group }
    end
    for _, v in ipairs(G.Garage and G.Garage.Owned(p.license) or {}) do add(v, 'mine') end
    -- véhicules de service de l'entreprise (en service) et clés prêtées
    local bc = G.Biz and G.Biz.Ctx(src)
    if bc and bc.duty and G.Garage.OfBiz then for _, v in ipairs(G.Garage.OfBiz(bc.biz.id)) do add(v, 'biz') end end
    for _, k in ipairs(DB.q('SELECT plate FROM pb_vehicle_keys WHERE license = ? AND (until_at = 0 OR until_at > ?)', { p.license, os.time() }) or {}) do
        local v = G.Garage.Vehicle(k.plate)
        if v then add(v, 'keys') end
    end
    return { list = out }
end
DATA.gps = function() return { places = places() } end
DATA.notes = function(src)
    local p = G.Get(src)
    local out = {}
    for _, n in ipairs(DB.q('SELECT id, title, body, updated FROM pb_phone_notes WHERE license = ? ORDER BY updated DESC, id DESC LIMIT 60', { p.license }) or {}) do out[#out + 1] = { id = n.id, title = n.title, body = n.body, at = Ph.Stamp(n.updated) } end
    return { list = out }
end
-- Petites annonces : visibles par tous pendant ads_hours ; on contacte l'auteur par message ou appel
PB.Migrate('344_phone_ads', 'Téléphone : petites annonces', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_ads (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, number VARCHAR(12) NOT NULL DEFAULT '', name VARCHAR(64) NOT NULL DEFAULT '', cat VARCHAR(12) NOT NULL DEFAULT 'divers', title VARCHAR(60) NOT NULL, body VARCHAR(400) NOT NULL DEFAULT '', price BIGINT NOT NULL DEFAULT 0, at INT NOT NULL, expires INT NOT NULL, PRIMARY KEY (id), KEY k_exp (expires), KEY k_lic (license))]]))
end)
local AD_CATS = { { 'vente', 'Vente' }, { 'achat', 'Achat' }, { 'service', 'Service' }, { 'emploi', 'Emploi' }, { 'logement', 'Logement' }, { 'vehicule', 'Véhicule' }, { 'divers', 'Divers' } }
local AD_CAT = {}
for _, c in ipairs(AD_CATS) do AD_CAT[c[1]] = c[2] end
DATA.ads = function(src)
    local p = G.Get(src)
    local out = {}
    for _, a in ipairs(DB.q('SELECT * FROM pb_phone_ads WHERE expires > ? ORDER BY id DESC LIMIT 80', { now() }) or {}) do
        out[#out + 1] = { id = a.id, cat = a.cat, catLabel = AD_CAT[a.cat] or 'Divers', title = a.title, body = a.body, price = tonumber(a.price) or 0, name = a.name, number = a.number, at = Ph.Stamp(a.at), mine = a.license == p.license or nil }
    end
    return { list = out, cats = AD_CATS, price = tonumber(cfg('ads_price', 50)) or 0, hours = tonumber(cfg('ads_hours', 48)) or 48 }
end
DATA.deals = function(src) if not G.Deals then return {} end return { goods = G.Deals.Goods(src), near = G.Deals.Nearby(src), tax = tonumber(PB.Cfg.Get('deals', 'tax', 5)) or 0 } end
Ph.ACT.deal_offer = function(_, src, p) if not G.Deals then return false, 'Indisponible.' end local ok, msg = G.Deals.Offer(src, p.buyer, p.kind, p.ref, p.price, p.qty) return ok, msg, 'deals' end
DATA.taxi = function(src) return G.Taxi and G.Taxi.PhoneData(src) or {} end
DATA.settings = function(src)
    local p = G.Get(src)
    local pf = prefs(p.license)
    return { wall = pf.wall, walls = WALLS, dnd = pf.dnd, sound = pf.sound, number = Ph.Number(p.license), name = Ph.Display(src), iban = G.Bank and G.Bank.Iban(p.license) or '' }
end
function Ph.Data(src, name, s)
    local fn = DATA[name]
    if not fn then return nil end
    local ok, d = pcall(fn, src, s or {})
    return ok and d or nil
end

-- Actions -------------------------------------------------------------------------------------------------------------------------------------
local ACT = Ph.ACT
local function cleanText(s, n) return PB.Trim(PB.Sanitize(tostring(s or ''), n)) end

ACT.set_wall = function(_, src, p)
    local w = tostring(p.wall or '')
    local ok = false
    for _, k in ipairs(WALLS) do if k == w then ok = true end end
    if not ok then return false, 'Fond inconnu.' end
    local pl = G.Get(src)
    local pf = prefs(pl.license) pf.wall = w
    savePrefs(pl.license, pf)
    return true, 'Fond d\'écran changé.', 'settings'
end
ACT.set_dnd = function(_, src, p)
    local pl = G.Get(src)
    local pf = prefs(pl.license) pf.dnd = p.on == true
    savePrefs(pl.license, pf)
    return true, pf.dnd and 'Ne pas déranger activé.' or 'Notifications rétablies.', 'settings'
end
ACT.set_sound = function(_, src, p)
    local pl = G.Get(src)
    local pf = prefs(pl.license) pf.sound = p.on == true
    savePrefs(pl.license, pf)
    return true, pf.sound and 'Sons activés.' or 'Sons coupés.', 'settings'
end

ACT.ad_post = function(_, src, p)
    local pl = G.Get(src)
    local title, body = cleanText(p.title, 60), cleanText(p.body, 400)
    local cat = AD_CAT[tostring(p.cat or '')] and tostring(p.cat) or 'divers'
    local price = math.max(0, math.min(100000000, math.floor(tonumber(p.price) or 0)))
    if #title < 3 then return false, 'Donne un titre à ton annonce.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_ads WHERE license = ? AND expires > ?', { pl.license, now() })
    if n and (tonumber(n.n) or 0) >= (tonumber(cfg('ads_max', 3)) or 3) then return false, ('Tu as déjà %d annonces en ligne : supprimes-en une.'):format(n.n) end
    local cost = tonumber(cfg('ads_price', 50)) or 0
    if cost > 0 then
        if not G.Pay(src, cost, 'bank') then return false, ('Publier une annonce coûte %s.'):format(money(cost)) end
        G.Eco.Book('state', cost, 'Petite annonce', pl.license)
    end
    DB.insert('INSERT INTO pb_phone_ads (license, number, name, cat, title, body, price, at, expires) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { pl.license, Ph.Number(pl.license) or '', Ph.Display(src), cat, title, body, price, now(), now() + (tonumber(cfg('ads_hours', 48)) or 48) * 3600 })
    PB.Audit.Log('phone', 'ad.post', src, title, nil, nil, { cat = cat, price = price })
    return true, 'Annonce publiée.', 'ads'
end
ACT.ad_del = function(_, src, p)
    local pl = G.Get(src)
    local own = DB.one('SELECT id FROM pb_phone_ads WHERE id = ? AND license = ?', { math.floor(tonumber(p.id) or 0), pl.license })
    if not own and not PB.Perm.Has(src, 'phone.moderate') then return false, 'Ce n\'est pas ton annonce.' end
    DB.exec('DELETE FROM pb_phone_ads WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    return true, 'Annonce supprimée.', 'ads'
end
-- Taxi (taxi.lua) : commander, annuler ; chauffeur : accepter, compteur
local function taxi(fn, ...) if not G.Taxi then return false, 'Service indisponible.' end local ok, msg = G.Taxi[fn](...) return ok, msg, 'taxi' end
ACT.taxi_call = function(_, src) return taxi('Call', src) end
ACT.taxi_cancel = function(_, src) return taxi('Cancel', src) end
ACT.taxi_accept = function(_, src, p) return taxi('Accept', src, p.id) end
ACT.taxi_start = function(_, src) return taxi('Start', src) end
ACT.taxi_stop = function(_, src) return taxi('Stop', src) end
ACT.note_save = function(_, src, p)
    local pl = G.Get(src)
    local title, body = cleanText(p.title, 60), PB.Sanitize(tostring(p.body or ''):gsub('\r', ''), 1500)
    if title == '' and body == '' then return false, 'Écris quelque chose.' end
    if title == '' then title = (body:gsub('\n.*', '')):sub(1, 40) end
    local id = math.floor(tonumber(p.id) or 0)
    if id > 0 then
        local own = DB.one('SELECT id FROM pb_phone_notes WHERE id = ? AND license = ?', { id, pl.license })
        if not own then return false, 'Note introuvable.' end
        DB.exec('UPDATE pb_phone_notes SET title = ?, body = ?, updated = ? WHERE id = ?', { title, body, now(), id })
    else
        local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_notes WHERE license = ?', { pl.license })
        if n and n.n >= 40 then return false, 'Maximum 40 notes : supprime-en une.' end
        DB.insert('INSERT INTO pb_phone_notes (license, title, body, updated) VALUES (?, ?, ?, ?)', { pl.license, title, body, now() })
    end
    return true, 'Note enregistrée.', 'notes'
end
ACT.note_del = function(_, src, p)
    local pl = G.Get(src)
    DB.exec('DELETE FROM pb_phone_notes WHERE id = ? AND license = ?', { math.floor(tonumber(p.id) or 0), pl.license })
    return true, 'Note supprimée.', 'notes'
end

ACT.gps_set = function(_, src, p)
    local id = math.floor(tonumber(p.id) or 0)
    for _, pl in ipairs(places()) do
        if pl.id == id then TriggerClientEvent('pb:g:phone:gps', src, pl.x, pl.y, pl.label) return true, 'Itinéraire placé : ' .. pl.label .. '.', 'gps' end
    end
    return false, 'Lieu inconnu.'
end
ACT.gps_clear = function(_, src)
    TriggerClientEvent('pb:g:phone:gps', src, nil, nil, nil)
    return true, 'Itinéraire effacé.', 'gps'
end
ACT.gps_car = function(_, src, p)
    local pl = G.Get(src)
    local plate = tostring(p.plate or '')
    local v = G.Garage and G.Garage.Vehicle(plate)
    if not v or not (v.license == pl.license or G.Garage.HasKey(pl.license, plate)) then return false, 'Tu n\'as pas la clé de ce véhicule.' end
    local w = G.Garage.Where(plate, src)
    if not w or not w.x then return false, (w and w.text or 'Véhicule introuvable') .. '.' end
    TriggerClientEvent('pb:g:phone:gps', src, w.x, w.y, v.label or plate)
    TriggerClientEvent('pb:g:phone:carblip', src, PB.Json({ { x = w.x, y = w.y, z = w.z, label = (v.label or plate) .. ' · ' .. plate, live = w.kind == 'live' } }))
    return true, w.text .. ' : itinéraire tracé.', 'garage'
end
-- tous mes véhicules sortis sur la carte pendant deux minutes
ACT.gps_all = function(_, src)
    local pl = G.Get(src)
    local list = {}
    for _, v in ipairs(G.Garage and G.Garage.Owned(pl.license) or {}) do
        if v.state == 'out' then
            local w = G.Garage.Where(v.plate, src)
            if w and w.x then list[#list + 1] = { x = w.x, y = w.y, z = w.z, label = (v.label or v.plate) .. ' · ' .. v.plate, live = w.kind == 'live' } end
        end
    end
    if #list == 0 then return false, 'Aucun véhicule sorti à afficher.' end
    TriggerClientEvent('pb:g:phone:carblip', src, PB.Json(list))
    return true, #list .. ' véhicule(s) affiché(s) sur la carte pendant 2 minutes.', 'garage'
end

-- Partage de position : la position est lue par le serveur au moment de l'envoi ; « Y aller » place l'itinéraire vers ce point
ACT.send_pos = function(s, src)
    if not s.thread then return false, 'Ouvre une conversation.' end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c then return false, 'Position introuvable.' end
    local ok, why = Ph.Send(src, s.thread, 'Position partagée', ('%.1f,%.1f'):format(c.x, c.y))
    return ok, ok and 'Position envoyée.' or why, 'thread'
end
ACT.gps_msg = function(_, src, p)
    local pl = G.Get(src)
    local me = Ph.Number(pl.license)
    local m = DB.one('SELECT pos FROM pb_phone_msgs WHERE id = ? AND (to_num = ? OR from_num = ?)', { math.floor(tonumber(p.id) or 0), me, me })
    local x, y = tostring(m and m.pos or ''):match('^(%-?[%d%.]+),(%-?[%d%.]+)$')
    if not x then return false, 'Aucune position dans ce message.' end
    TriggerClientEvent('pb:g:phone:gps', src, tonumber(x), tonumber(y), 'Position partagée')
    return true, 'Itinéraire placé vers la position.', 'thread'
end

-- Bloquer / débloquer un numéro
ACT.block = function(_, src, p)
    local pl = G.Get(src)
    local num = tostring(p.num or '')
    if not Ph.ValidNumber(num) then return false, 'Numéro invalide.' end
    if num == Ph.Number(pl.license) then return false, 'C\'est ton numéro.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_blocks WHERE license = ?', { pl.license })
    if n and n.n >= 100 then return false, 'Maximum 100 numéros bloqués.' end
    DB.exec('INSERT IGNORE INTO pb_phone_blocks (license, number, at) VALUES (?, ?, ?)', { pl.license, num, now() })
    return true, 'Numéro bloqué : plus de messages ni d\'appels de sa part.', 'contacts'
end
ACT.unblock = function(_, src, p)
    DB.exec('DELETE FROM pb_phone_blocks WHERE license = ? AND number = ?', { G.Get(src).license, tostring(p.num or '') })
    return true, 'Numéro débloqué.', 'contacts'
end
-- Groupes : créer (avec des numéros), quitter
ACT.group_create = function(s, src, p)
    local pl = G.Get(src)
    local name = PB.Trim(PB.Sanitize(tostring(p.name or ''), 32))
    if #name < 2 then return false, 'Donne un nom au groupe.' end
    local nums, seen = {}, {}
    for n in tostring(p.numbers or ''):gmatch('%d%d%d%-%d%d%d%d') do
        local lic = Ph.LicenseOf(n)
        if lic and lic ~= pl.license and not seen[lic] and #nums < 9 then seen[lic] = true nums[#nums + 1] = lic end
    end
    if #nums == 0 then return false, 'Ajoute au moins un numéro valide (ex. 555-0123, séparés par des virgules).' end
    local mine = DB.one('SELECT COUNT(*) AS n FROM pb_phone_groups WHERE owner = ?', { pl.license })
    if mine and mine.n >= 10 then return false, 'Maximum 10 groupes créés.' end
    local gid = DB.insert('INSERT INTO pb_phone_groups (name, owner, created) VALUES (?, ?, ?)', { name, pl.license, now() })
    DB.exec('INSERT INTO pb_phone_group_members (group_id, license) VALUES (?, ?)', { gid, pl.license })
    for _, lic in ipairs(nums) do DB.exec('INSERT IGNORE INTO pb_phone_group_members (group_id, license) VALUES (?, ?)', { gid, lic }) end
    s.thread = 'grp:' .. gid
    return true, ('Groupe « %s » créé (%d membres).'):format(name, #nums + 1), 'thread'
end
ACT.group_leave = function(s, src)
    local gid = s.thread and Ph.GrpOf(s.thread)
    if not gid then return false, 'Ouvre le groupe.' end
    DB.exec('DELETE FROM pb_phone_group_members WHERE group_id = ? AND license = ?', { gid, G.Get(src).license })
    local left = DB.one('SELECT COUNT(*) AS n FROM pb_phone_group_members WHERE group_id = ?', { gid })
    if left and left.n == 0 then DB.exec('DELETE FROM pb_phone_groups WHERE id = ?', { gid }) DB.exec('DELETE FROM pb_phone_msgs WHERE to_num = ?', { 'grp:' .. gid }) end
    s.thread = nil
    return true, 'Tu as quitté le groupe.', 'messages'
end

ACT.pay_bill = function(_, src, p)
    if not (G.Biz and G.Biz.PayInvoice) then return false, 'Paiement indisponible.' end
    local ok, inv = G.Biz.PayInvoice(src, p.id)
    if not ok then return false, inv end
    return true, ('Facture réglée : %s.'):format(money(inv.amount)), 'bills'
end

ACT.bank_send = function(_, src, p)
    local me = G.Get(src)
    local num = tostring(p.num or '')
    if not Ph.ValidNumber(num) then return false, 'Numéro invalide (ex. 555-0123).' end
    local lic = Ph.LicenseOf(num)
    if not lic then return false, "Ce numéro n'existe pas." end
    if lic == me.license then return false, "Tu ne peux pas t'envoyer de l'argent." end
    local iban = G.Bank and G.Bank.Iban(lic)
    if not iban then return false, 'Compte du destinataire introuvable.' end
    local ok, msg = G.Bank.Transfer(src, { amount = p.amount, iban = iban, note = p.note }, 'phone')
    return ok, msg, 'bank'
end

-- Appui sur le bouton « ouvrir » : rien de plus ici ; les évènements d'ouverture/fermeture restent dans phone.lua.
-- Notification de message : le son ne part que si le destinataire n'a pas activé « ne pas déranger ».
function Ph.QuietFor(license) local pf = prefs(license) return pf.dnd end
