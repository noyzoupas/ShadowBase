-- Contrats de vente entre joueurs (app Contrats du téléphone) : un véhicule ou un logement acheté, vendu à un joueur à côté.
-- L'acheteur reçoit le contrat (prix, bien), accepte ou refuse ; le serveur revérifie tout au moment de signer, prend l'argent
-- (banque puis espèces), verse le vendeur (moins la taxe de mutation) et change le propriétaire. Rien ne peut être vendu deux fois.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

PB.Cfg.Define('deals', { enabled = true, tax = 5, item_tax = 0, items = true, offer_secs = 60, max_dist = 6 })
local D = { offers = {} }   -- offers[acheteur] = { seller, kind, ref, label, price, at }
G.Deals = D
local function cfg(k, d) return PB.Cfg.Get('deals', k, d) end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function near(a, b) return G.DistBetween(a, b) <= (tonumber(cfg('max_dist', 6)) or 6) end

-- Biens vendables d'un joueur
function D.Goods(src)
    local p = G.Get(src)
    local out = {}
    for _, v in ipairs(DB.q("SELECT plate, label, model FROM pb_vehicles WHERE license = ? AND gang = '' AND biz = '' ORDER BY label", { p.license }) or {}) do
        out[#out + 1] = { kind = 'veh', ref = v.plate, label = (v.label ~= '' and v.label or v.model) .. ' (' .. v.plate .. ')' }
    end
    for _, h in ipairs(DB.q("SELECT id, label FROM pb_properties WHERE owner = ? AND kind = 'buy' ORDER BY label", { p.license }) or {}) do
        out[#out + 1] = { kind = 'house', ref = h.id, label = h.label }
    end
    -- objets du sac (meubles, matériel…) : vendus à l'unité ou par lot
    if cfg('items', true) ~= false and G.Inv and G.Inv.Contents then
        local tot = {}
        for _, it in pairs(G.Inv.Contents('p:' .. p.license)) do tot[it.item] = (tot[it.item] or 0) + it.qty end
        local items = {}
        for name, n in pairs(tot) do local d = G.Inv.Def(name) items[#items + 1] = { kind = 'item', ref = name, label = (d and d.label or name), max = n } end
        table.sort(items, function(a, b) return a.label < b.label end)
        for _, it in ipairs(items) do out[#out + 1] = it end
    end
    return out
end
local function owns(license, kind, ref, qty)
    if kind == 'item' then
        local n = G.Inv and G.Inv.Count('p:' .. license, ref) or 0
        if n < (qty or 1) then return nil end
        local d = G.Inv.Def(ref)
        return { label = d and d.label or ref, n = n }
    end
    if kind == 'veh' then return DB.one("SELECT plate, label FROM pb_vehicles WHERE plate = ? AND license = ? AND gang = '' AND biz = ''", { ref, license }) end
    return DB.one("SELECT id, label, arrears FROM pb_properties WHERE id = ? AND owner = ? AND kind = 'buy'", { ref, license })
end
function D.Nearby(src)
    local out = {}
    for id, pl in pairs(G.Players()) do if id ~= src and PB.ToBool(pl.row.created) and near(src, id) then out[#out + 1] = { id = id, name = display(id) } end end
    return out
end

function D.Offer(src, buyer, kind, ref, price, qty)
    if cfg('enabled', true) == false then return false, 'Les contrats de vente sont désactivés.' end
    buyer, price = tonumber(buyer), math.floor(tonumber(price) or 0)
    kind = (kind == 'house' or kind == 'item') and kind or 'veh'
    if kind == 'item' and cfg('items', true) == false then return false, 'La vente d\'objets est désactivée.' end
    qty = kind == 'item' and math.max(1, math.min(1000, math.floor(tonumber(qty) or 1))) or nil
    local p, bp = G.Get(src), buyer and G.Get(buyer)
    if not bp or buyer == src then return false, 'Choisis un acheteur à côté de toi.' end
    if not near(src, buyer) then return false, "L'acheteur doit être à côté de toi." end
    if price < 1 or price > 100000000 then return false, 'Prix invalide.' end
    local item = owns(p.license, kind, tostring(ref or ''), qty)
    if not item then return false, kind == 'item' and "Tu n'en as pas autant." or "Ce bien ne t'appartient pas." end
    if kind == 'house' and G.Housing and not G.Housing.StashEmpty(item.id) then return false, 'Vide d\'abord le coffre du logement.' end
    if kind == 'house' and (item.arrears or 0) > 0 then return false, "Règle d'abord l'impôt foncier en retard." end
    if D.offers[buyer] and now() - D.offers[buyer].at < (tonumber(cfg('offer_secs', 60)) or 60) then return false, 'Cette personne a déjà un contrat en attente.' end
    local label = kind == 'veh' and ('Véhicule ' .. item.label .. ' (' .. item.plate .. ')') or (kind == 'item' and (qty .. ' × ' .. item.label) or ('Logement « ' .. item.label .. ' »'))
    D.offers[buyer] = { seller = src, sellerLic = p.license, kind = kind, ref = tostring(ref), label = label, price = price, qty = qty, at = now() }
    TriggerClientEvent('pb:g:deal:offer', buyer, PB.Json({ from = display(src), what = label, price = price, tax = tonumber(cfg(kind == 'item' and 'item_tax' or 'tax', 5)) or 0, secs = tonumber(cfg('offer_secs', 60)) or 60 }))
    return true, ('Contrat envoyé à %s : %s pour %s.'):format(display(buyer), label, money(price))
end

function D.Answer(buyer, yes)
    local o = D.offers[buyer]
    D.offers[buyer] = nil
    if not o then return false, 'Aucun contrat en attente.' end
    local seller = o.seller
    local sp, bp = G.Get(seller), G.Get(buyer)
    if not yes then if sp then G.Notify(seller, { type = 'warn', title = 'Contrat', text = display(buyer) .. ' a refusé le contrat.' }) end return true, 'Contrat refusé.' end
    if now() - o.at > (tonumber(cfg('offer_secs', 60)) or 60) then return false, 'Le contrat a expiré.' end
    if not sp or sp.license ~= o.sellerLic then return false, "Le vendeur n'est plus là." end
    if not near(seller, buyer) then return false, 'Le vendeur doit être à côté de toi pour signer.' end
    local item = owns(o.sellerLic, o.kind, o.ref, o.qty)
    if not item then return false, "Le vendeur ne possède plus ce bien." end
    -- limites de l'acheteur
    if o.kind == 'item' then
        local okc, why = true, nil
        if G.Inv.CanCarry then okc, why = G.Inv.CanCarry('p:' .. bp.license, o.ref, o.qty) end
        if not okc then return false, tostring(why or 'Ton sac est plein.') end
    elseif o.kind == 'veh' then
        local n = DB.one("SELECT COUNT(*) AS n FROM pb_vehicles WHERE license = ? AND gang = '' AND biz = ''", { bp.license })
        local mx = tonumber(PB.Cfg.Get('garage', 'max_vehicles', 12)) or 12
        if n and (tonumber(n.n) or 0) >= mx then return false, ('Tu possèdes déjà %d véhicules (maximum).'):format(mx) end
    else
        local n = DB.one('SELECT COUNT(*) AS n FROM pb_properties WHERE owner = ?', { bp.license })
        local mx = tonumber(PB.Cfg.Get('housing', 'max_owned', 2)) or 2
        if n and (tonumber(n.n) or 0) >= mx then return false, ('Tu possèdes déjà %d logements (maximum).'):format(mx) end
    end
    local acc = G.Pay(buyer, o.price, 'bank')
    if not acc then if sp then G.Notify(seller, { type = 'warn', title = 'Contrat', text = display(buyer) .. " n'a pas assez d'argent." }) end return false, ('Il te faut %s.'):format(money(o.price)) end
    -- transfert (la condition sur l'ancien propriétaire empêche toute double vente)
    local moved
    if o.kind == 'item' then
        -- retrait chez le vendeur d'abord (un seul retrait possible), puis ajout chez l'acheteur ; sinon tout est rendu
        moved = G.Inv.Remove('p:' .. o.sellerLic, o.ref, o.qty)
        if moved and not G.Inv.Add('p:' .. bp.license, o.ref, o.qty) then G.Inv.Add('p:' .. o.sellerLic, o.ref, o.qty) moved = false end
        if G.Inv.Push then pcall(G.Inv.Push, seller) pcall(G.Inv.Push, buyer) end
    elseif o.kind == 'veh' then
        moved = (tonumber(DB.exec("UPDATE pb_vehicles SET license = ? WHERE plate = ? AND license = ? AND gang = '' AND biz = ''", { bp.license, o.ref, o.sellerLic })) or 0) > 0
        if moved then DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { o.ref }) end
    else
        moved = (tonumber(DB.exec("UPDATE pb_properties SET owner = ?, since = ?, arrears = 0, locked = 1 WHERE id = ? AND owner = ? AND kind = 'buy'", { bp.license, now(), o.ref, o.sellerLic })) or 0) > 0
        if moved then DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { o.ref }) G.PushConfig() end
    end
    if not moved then G.AddMoney(buyer, acc, o.price, 'Contrat annulé (remboursement)') return false, 'Le transfert a échoué : tu es remboursé.' end
    local tax = math.floor(o.price * (tonumber(cfg(o.kind == 'item' and 'item_tax' or 'tax', 5)) or 0) / 100)
    G.AddMoney(seller, 'bank', o.price - tax, 'Vente : ' .. o.label)
    if tax > 0 then G.Eco.Book('state', tax, 'Taxe de mutation', bp.license) end
    PB.Audit.Log('economy', 'deal.' .. o.kind, display(seller), display(buyer), nil, nil, { bien = o.label, prix = o.price, taxe = tax })
    if G.Timeline then
        G.Timeline.Add(o.sellerLic, 'deal', ('Vendu %s à %s pour %s'):format(o.label, display(buyer), money(o.price)), 'info')
        G.Timeline.Add(bp.license, 'deal', ('Acheté %s à %s pour %s'):format(o.label, display(seller), money(o.price)), 'info')
    end
    G.Notify(seller, { type = 'success', title = 'Contrat signé', text = ('%s vendu : %s reçus en banque%s.'):format(o.label, money(o.price - tax), tax > 0 and (' (taxe ' .. money(tax) .. ')') or '') })
    TriggerEvent('pb_panel:dealSigned', seller, buyer, o.kind, o.ref, o.price)
    return true, ('Contrat signé : %s est à toi.'):format(o.label)
end
RegisterNetEvent('pb:g:deal:answer', function(yes)
    local src = source
    local ok, msg = D.Answer(src, yes == true)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Contrat', text = msg })
end)
AddEventHandler('playerDropped', function() local s = source D.offers[s] = nil for b, o in pairs(D.offers) do if o.seller == s then D.offers[b] = nil end end end)

local form = PB.Form.Cfg({ ns = 'deals', id = 'settings', title = 'Contrats de vente entre joueurs', perm = 'economy.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Contrats de vente (app Contrats du téléphone)', default = true },
    { k = 'tax', type = 'number', label = 'Taxe de mutation (%, payée par le vendeur)', default = 5, min = 0, max = 50 },
    { k = 'items', type = 'toggle', label = 'Vente d\'objets du sac (meubles, matériel…)', default = true },
    { k = 'item_tax', type = 'number', label = 'Taxe sur la vente d\'objets (%)', default = 0, min = 0, max = 50 },
    { k = 'offer_secs', type = 'number', label = 'Temps pour accepter (secondes)', default = 60, min = 15, max = 300 },
    { k = 'max_dist', type = 'number', label = 'Distance maximale entre vendeur et acheteur (m)', default = 6, min = 2, max = 30 },
} })
G.DealsForm = form
