-- Actions de terrain de la police : menottes, fouille (inventaire du suspect menotté), mise en fourrière d'un véhicule.
-- S'appuie sur les entreprises (grade + service + droits cuff / search / seize) ; le client n'exécute que l'animation et la saisie de la plaque.

local B, Form = PB.B, PB.Form
local G, DB = PB.G, PB.DB
local Biz = G.Biz

PB.Cfg.Define('police', { cuff_dist = 3, search_needs_cuffs = true, uncuff_on_death = true, impound_dist = 12, impound_wait = 10, relog_cuff_min = 30 })

local Po = {}
G.Police = Po
local function cfg(k, d) return PB.Cfg.Get('police', k, d) end
local function now() return os.time() end

-- État : menottes (en mémoire). Se déconnecter menotté ne libère pas : à la reconnexion (dans le délai réglé), on est toujours menotté.
local cuffed, cuffLic, fled = {}, {}, {}
function G.IsCuffed(src) return cuffed[tonumber(src) or -1] == true end
exports('IsCuffed', function(src) return G.IsCuffed(src) end)
local function setCuffed(tid, on)
    cuffed[tid] = on and true or nil
    local p = on and G.Get(tid)
    cuffLic[tid] = p and p.license or nil
    TriggerClientEvent('pb:g:police:cuff', tid, PB.Json({ on = on and true or false }))
end
Po.SetCuffed = setCuffed
AddEventHandler('playerDropped', function()
    local src = source
    if cuffed[src] and cuffLic[src] then fled[cuffLic[src]] = now() end
    cuffed[src], cuffLic[src] = nil, nil
end)
table.insert(G.beginHooks, function(src)
    local p = G.Get(src)
    local at = p and fled[p.license]
    if not at then return end
    fled[p.license] = nil
    if now() - at > (tonumber(cfg('relog_cuff_min', 30)) or 30) * 60 then return end
    setCuffed(src, true)
    G.Notify(src, { type = 'warn', title = 'Police', text = 'Tu t\'es déconnecté(e) menotté(e) : tu l\'es toujours.', duration = 9000 })
    local who = G.Identity and G.Identity(src)
    local name = who and who.firstname and (who.firstname .. ' ' .. (who.lastname or '')) or ('#' .. src)
    for s in pairs(G.Players()) do
        local c = Biz.Ctx(s)
        if c and c.duty and Biz.Allowed(c, 'cuff') then G.Notify(s, { type = 'info', title = 'Police', text = name .. ' s\'est reconnecté(e) : toujours menotté(e).' }) end
    end
    PB.Audit.Log('police', 'cuff.relog', src, name, nil, nil, nil)
end)
-- le joueur menotté qui meurt est libéré
local prevDead = G.SetDead
function G.SetDead(src, dead) if dead and cfg('uncuff_on_death', true) and cuffed[tonumber(src)] then setCuffed(tonumber(src), false) end return prevDead(src, dead) end

local function near(src, tid, extra) return G.DistBetween(src, tid) <= cfg('cuff_dist', 3) + (extra or 0) end
local function targetNear(c, src, p, extra)
    local tp, err, tid = Biz.Target(src, p.id)
    if not tp then return nil, err end
    if not near(src, tid, extra or 1) then return nil, 'Cette personne est trop loin.' end
    return tp, nil, tid
end
local function police(c, perm)
    if not Biz.Allowed(c, perm) then return false, "Tu n'as pas ce droit." end
    if not c.duty then return false, 'Prends ton service.' end
    return true
end

-- Actions de la tablette ---------------------------------------------------------------------------------------------------------------------
Biz.ACT.cuff = function(c, src, p)
    local ok, why = police(c, 'cuff') if not ok then return false, why end
    local tp, err, tid = targetNear(c, src, p) if not tp then return false, err end
    if cuffed[tid] then return false, 'Cette personne est déjà menottée.' end
    if PB.ToBool(tp.row.dead) then return false, 'Cette personne est inconsciente.' end
    setCuffed(tid, true)
    Biz.Record(c, tp.license, Biz.Display(tid), 'cuff', 'Menottée par ' .. Biz.Display(src), 0)
    G.Notify(tid, { type = 'warn', title = c.biz.label, text = 'Tu es menotté(e).' })
    TriggerEvent('pb_panel:cuffed', src, tid, true)
    return true, Biz.Display(tid) .. ' est menotté(e).'
end
Biz.ACT.uncuff = function(c, src, p)
    local ok, why = police(c, 'cuff') if not ok then return false, why end
    local tp, err, tid = targetNear(c, src, p) if not tp then return false, err end
    if not cuffed[tid] then return false, "Cette personne n'est pas menottée." end
    setCuffed(tid, false)
    G.Notify(tid, { type = 'info', title = c.biz.label, text = 'Tu es libéré(e).' })
    TriggerEvent('pb_panel:cuffed', src, tid, false)
    return true, Biz.Display(tid) .. ' est libéré(e).'
end
-- Escorte et mise en véhicule (même code que le menu ALT : server/game/ctxmenu.lua)
Biz.ACT.escort = function(c, src, p)
    local ok, why = police(c, 'cuff') if not ok then return false, why end
    local tp, err, tid = targetNear(c, src, p) if not tp then return false, err end
    if not (G.Ctx and G.Ctx.Escort) then return false, 'Escorte indisponible.' end
    return G.Ctx.Escort(src, tid)
end
Biz.ACT.put_veh = function(c, src, p)
    local ok, why = police(c, 'cuff') if not ok then return false, why end
    local tp, err, tid = targetNear(c, src, p, 4) if not tp then return false, err end
    if not (G.Ctx and G.Ctx.PutVeh) then return false, 'Mise en véhicule indisponible.' end
    return G.Ctx.PutVeh(src, tid)
end
Biz.ACT.search = function(c, src, p)
    local ok, why = police(c, 'search') if not ok then return false, why end
    local tp, err, tid = targetNear(c, src, p) if not tp then return false, err end
    if cfg('search_needs_cuffs', true) and not cuffed[tid] then return false, 'Menotte la personne avant de la fouiller.' end
    Biz.Record(c, tp.license, Biz.Display(tid), 'search', 'Fouillée par ' .. Biz.Display(src), 0)
    G.Notify(tid, { type = 'warn', title = c.biz.label, text = 'Tu es fouillé(e).' })
    TriggerEvent('pb_panel:searched', src, tid)
    TriggerClientEvent('pb:g:police:search', src, 'p:' .. tp.license)
    return true, 'Fouille en cours : déplace les objets saisis dans ton sac.'
end

-- Mise en fourrière : le serveur demande la plaque du véhicule le plus proche au client, puis revérifie
local pending = {}
AddEventHandler('playerDropped', function() pending[source] = nil end)
Biz.ACT.seize = function(c, src, p)
    local ok, why = police(c, 'seize') if not ok then return false, why end
    local reason = Biz.Clean(p.reason, 70)
    if reason == '' then return false, 'Indique le motif de la saisie.' end
    pending[src] = { reason = reason, at = now(), biz = c.biz.id }
    TriggerClientEvent('pb:g:police:askVehicle', src)
    return true, 'Approche-toi du véhicule : recherche de la plaque…'
end
RegisterNetEvent('pb:g:police:vehicle', function(plate, netId)
    local src = source
    local pd = pending[src]
    pending[src] = nil
    if not pd or now() - pd.at > cfg('impound_wait', 10) then return end
    local c = Biz.Ctx(src)
    if not c or c.biz.id ~= pd.biz or not Biz.Allowed(c, 'seize') or not c.duty then return end
    -- le véhicule doit exister près de l'agent ; sa plaque est lue par le serveur (jamais celle envoyée par le client)
    if G.ServerSees() then
        local ent, real = G.VehNear(src, netId, cfg('impound_dist', 12))
        if not ent then G.Notify(src, { type = 'error', text = real }) return end
        plate = real
    else plate = tostring(plate or ''):gsub('%s+$', ''):sub(1, 12) end
    if plate == '' then G.Notify(src, { type = 'error', text = 'Aucun véhicule à proximité.' }) return end
    if G.Garage and G.Garage.Real then plate = G.Garage.Real(plate) or plate end
    local v = G.Garage and G.Garage.Vehicle(plate)
    if not v then G.Notify(src, { type = 'error', text = 'Véhicule inconnu : seuls les véhicules achetés en ville peuvent être saisis.' }) return end
    if v.state == 'impound' then G.Notify(src, { type = 'error', text = 'Ce véhicule est déjà en fourrière.' }) return end
    local ok, err = G.Garage.Impound(plate, pd.reason)
    if not ok then G.Notify(src, { type = 'error', text = err or 'Impossible.' }) return end
    local owner = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { v.license })
    local name = owner and (((owner.firstname or '') .. ' ' .. (owner.lastname or '')):gsub('^%s+', '')) or ''
    Biz.Record(c, v.license, name, 'seize', ('Véhicule %s saisi : %s'):format(plate, pd.reason), 0)
    for id, pl in pairs(G.Players()) do if pl.license == v.license then G.Notify(id, { type = 'warn', title = c.biz.label, text = ('Ton véhicule %s a été mis en fourrière : %s.'):format(plate, pd.reason) }) end end
    G.Notify(src, { type = 'success', title = 'Fourrière', text = ('Véhicule %s mis en fourrière.'):format(plate) })
    TriggerEvent('pb_panel:seized', src, plate, pd.reason)
end)

-- Accès à l'inventaire d'un suspect : seulement un agent en service avec le droit « search », à côté d'une personne menottée
local Inv = G.Inv
local prevExtra = Inv and Inv.ExtraAccess
if Inv then
    Inv.ExtraAccess = function(src, kind, id)
        if kind == 'p' then
            local c = Biz.Ctx(src)
            if not c or not c.duty or not Biz.Allowed(c, 'search') then return false end
            local tid
            for sid, pl in pairs(G.Players()) do if pl.license == id then tid = sid end end
            if not tid or tid == src then return false end
            if cfg('search_needs_cuffs', true) and not cuffed[tid] then return false end
            return near(src, tid, 4)
        end
        if prevExtra then return prevExtra(src, kind, id) end
        return false
    end
end

-- Page « Terrain » de la tablette --------------------------------------------------------------------------------------------------------------
Biz.PAGE_META.field = { label = 'Terrain', icon = 'siren', group = 'Entreprise' }
table.insert(Biz.ORDER, 'field')
Biz.NavAllow.field = function(c) return c.biz.kind == 'police' and (Biz.Allowed(c, 'cuff') or Biz.Allowed(c, 'search') or Biz.Allowed(c, 'seize')) end
Biz.PAGES.field = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.NavAllow.field(c) then return nil end
    local rows = {}
    for _, n in ipairs(Biz.Nearby(src, cfg('cuff_dist', 3) + 1)) do
        local acts = {}
        if cuffed[n.id] then
            if Biz.Allowed(c, 'cuff') then acts[#acts + 1] = { act = 'uncuff', label = 'Libérer', payload = { id = n.id } } end
            if Biz.Allowed(c, 'search') then acts[#acts + 1] = { act = 'search', label = 'Fouiller', payload = { id = n.id }, primary = true } end
        elseif Biz.Allowed(c, 'cuff') then
            acts[#acts + 1] = { act = 'cuff', label = 'Menotter', payload = { id = n.id }, primary = true }
        end
        rows[#rows + 1] = { name = n.name, state = cuffed[n.id] and 'Menotté(e)' or 'Libre', dist = math.floor(G.DistBetween(src, n.id)) .. ' m', actions = acts }
    end
    local blocks = {
        { type = 'notice', text = c.duty and 'Les actions de terrain s\'appliquent aux personnes à portée. Une fouille exige une personne menottée.' or 'Prends ton service pour utiliser les actions de terrain.' },
        { type = 'table', title = 'Personnes à portée', columns = { { k = 'name', label = 'Nom' }, { k = 'state', label = 'État' }, { k = 'dist', label = 'Distance' } }, rows = rows, empty = 'Personne à portée.' } }
    if Biz.Allowed(c, 'seize') then
        blocks[#blocks + 1] = { type = 'form', id = 'seize', title = 'Mettre un véhicule en fourrière', desc = 'Le véhicule le plus proche de toi est saisi (il doit avoir été acheté en ville).', fields = { { k = 'reason', type = 'text', label = 'Motif', maxlen = 70 } }, submit = { act = 'seize', label = 'Saisir le véhicule' } }
    end
    return blocks, 'Terrain'
end

-- Panel : réglages ------------------------------------------------------------------------------------------------------------------------------
local policeForm = Form.Cfg({ ns = 'police', id = 'settings', title = 'Actions de terrain de la police', perm = 'biz.edit', cols = 2, fields = {
    { k = 'cuff_dist', type = 'number', label = 'Portée des menottes (m)', default = 3, min = 1, max = 10, int = false, step = 0.5 },
    { k = 'relog_cuff_min', type = 'number', label = 'Reconnexion menotté(e) : toujours menotté(e) pendant (min, 0 = non)', default = 30, min = 0, max = 1440 },
    { k = 'search_needs_cuffs', type = 'toggle', label = 'Fouille : exiger que la personne soit menottée', default = true },
    { k = 'uncuff_on_death', type = 'toggle', label = 'Libérer une personne menottée qui tombe à terre', default = true },
    { k = 'impound_dist', type = 'number', label = 'Distance maximale pour saisir un véhicule (m)', default = 12, min = 3, max = 50 },
    { k = 'impound_wait', type = 'number', label = 'Délai de recherche de la plaque (secondes)', default = 10, min = 3, max = 30 },
} })

table.insert(Biz.ExtraSettings, policeForm)

PB.SelfTest.Add('police', function(R)
    R.check(Inv ~= nil and Inv.ExtraAccess ~= nil, 'fouille', "l'inventaire n'est pas chargé : la fouille est impossible")
    R.check(G.Garage ~= nil, 'saisie de véhicule', "le module Garages n'est pas chargé : la mise en fourrière est impossible")
end)
