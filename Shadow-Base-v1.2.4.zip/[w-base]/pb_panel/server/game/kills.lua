-- Journal des morts : qui a tué qui, avec quelle arme, à quelle distance, où. Le tueur annoncé par le jeu de la victime est vérifié
-- côté serveur (connecté, à moins de 400 m). Sert au staff (panel, chronologie des joueurs) et aux guerres de territoire.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('kills.view', 'Voir le journal des morts', 'staff')
PB.Migrate('346_kills', 'Journal des morts', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_kills (id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, victim VARCHAR(80) NOT NULL, victim_name VARCHAR(64) NOT NULL DEFAULT '', killer VARCHAR(80) NOT NULL DEFAULT '', killer_name VARCHAR(64) NOT NULL DEFAULT '', weapon VARCHAR(40) NOT NULL DEFAULT '', dist INT NOT NULL DEFAULT 0, x DOUBLE NOT NULL DEFAULT 0, y DOUBLE NOT NULL DEFAULT 0, z DOUBLE NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_at (at), KEY k_v (victim), KEY k_k (killer))]]))
end)
PB.Cfg.Define('kills', { keep_days = 30, staff_feed = false })
local K = { recent = {} }   -- recent : 200 dernières morts en mémoire (guerres de territoire)
G.Kills = K
local function now() return os.time() end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return GetPlayerName(src) or ('Joueur ' .. src) end
local function coords(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end

-- Arme : nom lisible d'après le hachage du jeu
local WEAPON_NAMES = {}
local function u32(h) h = math.floor(tonumber(h) or 0) if h < 0 then h = h + 4294967296 end return h end
local function addName(code, label) local ok, h = pcall(GetHashKey, code) if ok and h then WEAPON_NAMES[u32(h)] = label end end
PB.OnReady(function()
    for _, w in ipairs(PB.Cfg.Get('weapons', 'catalog', {}) or {}) do if w.hash then addName(w.hash, w.label or w.hash) end end
    local base = { WEAPON_UNARMED = 'Poings', WEAPON_PISTOL = 'Pistolet', WEAPON_COMBATPISTOL = 'Pistolet de combat', WEAPON_PISTOL50 = 'Pistolet .50', WEAPON_HEAVYPISTOL = 'Pistolet lourd', WEAPON_SNSPISTOL = 'Pistolet SNS',
        WEAPON_REVOLVER = 'Revolver', WEAPON_MICROSMG = 'Micro-SMG', WEAPON_SMG = 'SMG', WEAPON_ASSAULTSMG = 'SMG d\'assaut', WEAPON_ASSAULTRIFLE = 'Fusil d\'assaut', WEAPON_CARBINERIFLE = 'Carabine',
        WEAPON_SPECIALCARBINE = 'Carabine spéciale', WEAPON_PUMPSHOTGUN = 'Fusil à pompe', WEAPON_SAWNOFFSHOTGUN = 'Fusil à canon scié', WEAPON_SNIPERRIFLE = 'Fusil de précision', WEAPON_HEAVYSNIPER = 'Fusil de précision lourd',
        WEAPON_KNIFE = 'Couteau', WEAPON_BAT = 'Batte', WEAPON_CROWBAR = 'Pied-de-biche', WEAPON_MACHETE = 'Machette', WEAPON_HATCHET = 'Hachette', WEAPON_NIGHTSTICK = 'Matraque', WEAPON_STUNGUN = 'Taser',
        WEAPON_GRENADE = 'Grenade', WEAPON_MOLOTOV = 'Cocktail Molotov', WEAPON_RPG = 'Lance-roquettes', WEAPON_RUN_OVER_BY_CAR = 'Écrasé par un véhicule', WEAPON_RAMMED_BY_CAR = 'Percuté par un véhicule',
        WEAPON_FALL = 'Chute', WEAPON_DROWNING = 'Noyade', WEAPON_EXPLOSION = 'Explosion', WEAPON_FIRE = 'Feu', WEAPON_BLEEDING = 'Hémorragie', WEAPON_ANIMAL = 'Animal', WEAPON_GUSENBERG = 'Gusenberg', WEAPON_COMBATPDW = 'PDW de combat' }
    for code, label in pairs(base) do addName(code, label) end
end)
function K.WeaponName(h) return WEAPON_NAMES[u32(h)] or (u32(h) == 0 and 'Inconnue' or 'Arme') end

AddEventHandler('pb_panel:killReport', function(victim, killer, weapon)
    local vp = G.Get(victim)
    if not vp then return end
    local vc = coords(victim)
    local kp = killer > 0 and killer ~= victim and G.Get(killer) or nil
    local dist = 0
    if kp then
        local kc = coords(killer)
        dist = (vc and kc) and math.floor(#(vc - kc) + 0.5) or 0
        if dist > 400 then kp = nil dist = 0 end   -- annonce impossible : ignorée
    end
    local wname = K.WeaponName(weapon)
    local row = { at = now(), victim = vp.license, victimName = display(victim), killer = kp and kp.license or '', killerName = kp and display(killer) or '', weapon = wname, dist = dist,
        x = vc and vc.x or 0, y = vc and vc.y or 0, z = vc and vc.z or 0, vsrc = victim, ksrc = kp and killer or nil }
    DB.insert('INSERT INTO pb_kills (at, victim, victim_name, killer, killer_name, weapon, dist, x, y, z) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { row.at, row.victim, row.victimName, row.killer, row.killerName, wname:sub(1, 40), dist, row.x, row.y, row.z })
    table.insert(K.recent, 1, row)
    if #K.recent > 200 then table.remove(K.recent) end
    if G.Timeline then
        G.Timeline.Add(row.victim, 'death', kp and ('Tué(e) par %s (%s, %d m)'):format(row.killerName, wname, dist) or ('Mort : %s'):format(wname), 'bad')
        if kp then G.Timeline.Add(row.killer, 'kill', ('A tué %s (%s, %d m)'):format(row.victimName, wname, dist), 'warn') end
    end
    if PB.Cfg.Get('kills', 'staff_feed', false) and kp then
        for s in pairs(G.Players()) do if P.Has(s, 'kills.view') and (not G.Staff or G.Staff.OnDuty(s)) then G.Notify(s, { type = 'info', title = 'Mort', text = ('%s → %s (%s, %d m)'):format(row.killerName, row.victimName, wname, dist), duration = 6000 }) end end
    end
    TriggerEvent('pb_panel:kill', row)
end)
CreateThread(function()
    while true do
        Wait(3600000)
        local d = tonumber(PB.Cfg.Get('kills', 'keep_days', 30)) or 30
        pcall(DB.exec, 'DELETE FROM pb_kills WHERE at < ?', { now() - d * 86400 })
    end
end)

local form = PB.Form.Cfg({ ns = 'kills', id = 'settings', title = 'Journal des morts', perm = 'kills.view', cols = 2, fields = {
    { k = 'staff_feed', type = 'toggle', label = 'Afficher chaque mort entre joueurs au staff en service', default = false },
    { k = 'keep_days', type = 'number', label = 'Conservation (jours)', default = 30, min = 1, max = 365 },
} })
PB.Module({
    id = 'kills', label = 'Journal des morts', icon = 'skull', group = 'Serveur', order = 98, perm = 'kills.view', hint = 'Qui a tué qui, arme, distance',
    caps = function() return PB.Capsify({
        { 'Tueur, arme, distance, lieu', 'ok', "Lus par le jeu de la victime, vérifiés par le serveur (tueur connecté, à moins de 400 m)." },
        { 'Accidents et morts naturelles', 'ok', 'Chute, noyade, véhicule, faim : notés sans tueur.' },
    }) end,
    doc = "## Journal des morts\nChaque mort est notée avec le tueur (s'il y en a un), l'arme, la distance et le lieu. La chronologie de chaque joueur l'affiche aussi. **Y aller** te téléporte sur le lieu.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Dernières morts', icon = 'skull', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_kills ORDER BY id DESC LIMIT 250') or {}) do
                    rows[#rows + 1] = { at = r.at, victim = r.victim_name, killer = r.killer_name ~= '' and r.killer_name or '—', weapon = r.weapon, dist = r.dist > 0 and (r.dist .. ' m') or '',
                        actions = { { action = 'points.goto.xyz', label = 'Y aller', icon = 'pin', payload = { x = r.x, y = r.y, z = r.z } } } }
                end
                local top = {}
                for _, r in ipairs(DB.q("SELECT killer_name, COUNT(*) AS n FROM pb_kills WHERE killer <> '' AND at > ? GROUP BY killer, killer_name ORDER BY n DESC LIMIT 10", { now() - 7 * 86400 }) or {}) do top[#top + 1] = { who = r.killer_name, n = tonumber(r.n) or 0 } end
                return { B.table({ id = 'kl', title = 'Dernières morts', search = true, columns = { { k = 'at', label = 'Quand', type = 'date' }, { k = 'victim', label = 'Victime' }, { k = 'killer', label = 'Tueur' }, { k = 'weapon', label = 'Arme' }, { k = 'dist', label = 'Distance' } }, rows = rows, empty = 'Aucune mort enregistrée.' }),
                    B.table({ id = 'ktop', title = 'Plus de victimes (7 jours)', columns = { { k = 'who', label = 'Joueur' }, { k = 'n', label = 'Victimes', type = 'num' } }, rows = top, empty = 'Personne.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
PB.Action('points.goto.xyz', 'kills.view', function(ctx, p)
    local src = tonumber(ctx.src) or 0
    if src <= 0 or not G.Get(src) then return false, 'Ouvre le panel en jeu pour te téléporter.' end
    local x, y, z = tonumber(p.x), tonumber(p.y), tonumber(p.z)
    if not x then return false, 'Position inconnue.' end
    TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = x, y = y, z = z }))
    ctx.close = true
    return true
end)
