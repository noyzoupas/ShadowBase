-- Menu Échap : accueil et annonces, fiche du personnage (filmée en studio côté jeu), parcours (emplois et organisations successifs),
-- carte avec lieux enregistrés et GPS, réglages du jeu. Le serveur compose les données et valide les lieux ; les réglages restent sur le PC du joueur.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local U = {}
G.Pause = U

P.Register('pause.edit', 'Modifier le menu Échap (annonces, lieux, onglets)', 'pause', true)
PB.Migrate('096_pause', 'Menu Échap : parcours et lieux enregistrés', {
    [[CREATE TABLE IF NOT EXISTS pb_pause_path (id INT AUTO_INCREMENT PRIMARY KEY, license VARCHAR(64) NOT NULL, kind VARCHAR(8) NOT NULL, ref VARCHAR(48) NOT NULL DEFAULT '', label VARCHAR(80) NOT NULL, grade VARCHAR(40) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, KEY k_lic (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_pause_places (id INT AUTO_INCREMENT PRIMARY KEY, license VARCHAR(64) NOT NULL, label VARCHAR(40) NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, at INT NOT NULL DEFAULT 0, KEY k_lic (license))]],
})
PB.Cfg.Define('pause', { enabled = true, replace_esc = false, welcome = 'Bienvenue, {name}.', announcements = {}, places = {}, max_places = 20,
    tab_character = true, tab_path = true, tab_map = true, tab_settings = true })
local function cfg(k, d) return PB.Cfg.Get('pause', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) end
local function nameOf(src) local i = G.Identity(src) or {} local n = ((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') return n ~= '' and n or ('Joueur ' .. src) end

-- Parcours --------------------------------------------------------------------------------------------------------------------------------
-- Une ligne par changement ; la fin d'une ligne est le début de la suivante du même type.
function U.Record(src, kind, ref, label, grade)
    local p = G.Get(tonumber(src) or -1)
    if not p then return false end
    ref, label, grade = clean(ref, 48), clean(label, 80), clean(grade, 40)
    local last = DB.one('SELECT ref, grade FROM pb_pause_path WHERE license = ? AND kind = ? ORDER BY id DESC LIMIT 1', { p.license, kind })
    if last and last.ref == ref and last.grade == grade then return false end
    if not last and ref == '' then return false end
    DB.exec('INSERT INTO pb_pause_path (license, kind, ref, label, grade, at) VALUES (?, ?, ?, ?, ?, ?)', { p.license, kind, ref, label, grade, os.time() })
    return true
end
AddEventHandler('pb_panel:jobChanged', function(src, bizId, gradeNo)
    if not bizId then U.Record(src, 'job', '', 'Sans emploi', '') return end
    local b = G.Biz and G.Biz.Get and G.Biz.Get(bizId)
    local g = G.Biz and G.Biz.Grade and G.Biz.Grade(bizId, gradeNo or 0)
    U.Record(src, 'job', bizId, b and b.label or bizId, g and g.label or '')
end)
AddEventHandler('pb_panel:gangChanged', function(src, id)
    if not id then U.Record(src, 'gang', '', 'Sans organisation', '') return end
    local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id]
    U.Record(src, 'gang', id, d and d.label or id, '')
end)
function U.Path(src)
    local p = G.Get(src)
    if not p then return {} end
    local rows = DB.q('SELECT kind, ref, label, grade, at FROM pb_pause_path WHERE license = ? ORDER BY at, id', { p.license }) or {}
    local out, byKind = {}, {}
    for i, r in ipairs(rows) do
        local e = { kind = r.kind, label = r.label, grade = r.grade ~= '' and r.grade or nil, from = tonumber(r.at) or 0, ref = r.ref }
        out[#out + 1] = e
        if byKind[r.kind] then byKind[r.kind].to = e.from end
        byKind[r.kind] = e
    end
    for _, e in ipairs(out) do e.current = (e.to == nil and e.ref ~= '') or nil end
    for i = 1, math.floor(#out / 2) do out[i], out[#out - i + 1] = out[#out - i + 1], out[i] end   -- plus récent d'abord
    while #out > 40 do out[#out] = nil end
    return out
end

-- Lieux -----------------------------------------------------------------------------------------------------------------------------------
local function sharedPlaces()
    local out = {}
    for i, l in ipairs(cfg('places', {}) or {}) do
        if type(l) == 'table' and tonumber(l.x) and tonumber(l.y) then out[#out + 1] = { id = 's' .. i, label = clean(l.label, 40), x = tonumber(l.x), y = tonumber(l.y), z = tonumber(l.z) or 0, shared = true } end
    end
    return out
end
function U.Places(src)
    local p = G.Get(src)
    local out = sharedPlaces()
    if p then
        for _, r in ipairs(DB.q('SELECT id, label, x, y, z FROM pb_pause_places WHERE license = ? ORDER BY id', { p.license }) or {}) do
            out[#out + 1] = { id = 'p' .. r.id, label = r.label, x = r.x, y = r.y, z = r.z }
        end
    end
    return out
end
local function findPlace(src, pid)
    for _, pl in ipairs(U.Places(src)) do if pl.id == tostring(pid) then return pl end end
end

local function keyList()
    local function c(ns, k, d) return PB.Cfg.Get(ns, k, d) end
    return {
        { label = 'Inventaire', key = c('inv', 'key', 'I') }, { label = 'Téléphone', key = c('phone', 'key', 'F1') }, { label = 'Menu de mon entreprise', key = c('quick', 'key', 'F6') },
        { label = 'Menu de mon organisation', key = c('tablets', 'orga_key', 'F7') }, { label = 'Menu personnel', key = c('personal', 'key', 'F5') },
        { label = 'Menu contextuel (maintenir)', key = c('ctx', 'key', 'LMENU') }, { label = 'Verrouiller le véhicule', key = c('garage', 'lock_key', 'L') },
        { label = 'Raccourcis objets', key = '1 à 5' }, { label = 'Menu Échap', key = 'Échap' },
    }
end

function U.Data(src)
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) then return nil end
    local id = G.Identity(src) or {}
    local name = nameOf(src)
    local job = G.Biz and G.Biz.Job and G.Biz.Job(src)
    local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
    local ann = {}
    for _, a in ipairs(cfg('announcements', {}) or {}) do
        if type(a) == 'table' and tostring(a.title or '') ~= '' then ann[#ann + 1] = { title = clean(a.title, 60), text = clean(a.text, 400), date = clean(a.date, 20) } end
    end
    local cars = {}
    if G.Garage and G.Garage.Owned then
        for _, v in ipairs(G.Garage.Owned(p.license)) do cars[#cars + 1] = { label = (v.label ~= '' and v.label or v.model), model = tostring(v.model or ''), plate = v.plate, state = v.state } end
    end
    local d = {
        name = name, id = src,
        welcome = clean(tostring(cfg('welcome', 'Bienvenue, {name}.')):gsub('{name}', name), 120),
        announcements = ann,
        stats = { cash = money(p.row.cash), bank = money(p.row.bank), job = job and (job.label .. ' · ' .. job.gradeLabel) or 'Sans emploi', gang = g and g.label or nil, online = (function() local n = 0 for _ in pairs(G.Players()) do n = n + 1 end return n end)() },
        tabs = { character = cfg('tab_character', true) ~= false, path = cfg('tab_path', true) ~= false, map = cfg('tab_map', true) ~= false, settings = cfg('tab_settings', true) ~= false },
        char = { identity = { firstname = id.firstname, lastname = id.lastname, dob = id.dob, nationality = id.nationality, height = id.height, sex = id.sex },
            job = job and { label = job.label, grade = job.gradeLabel, salary = job.salary } or nil, gang = g and { label = g.label, color = g.color } or nil, cars = cars, cash = money(p.row.cash), bank = money(p.row.bank) },
        path = U.Path(src), places = U.Places(src), keys = keyList(), maxPlaces = tonumber(cfg('max_places', 20)) or 20,
    }
    return d
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

RegisterNetEvent('pb:g:pause:open', function()
    local src = source
    if cfg('enabled', true) == false or not usable(src) or not throttle(src, 400) then return end
    local d = U.Data(src)
    if d then TriggerClientEvent('pb:g:pause:ui', src, PB.Json({ ev = 'open', data = d })) end
end)
RegisterNetEvent('pb:g:pause:refresh', function()
    local src = source
    if cfg('enabled', true) == false or not usable(src) or not throttle(src, 300) then return end
    local d = U.Data(src)
    if d then TriggerClientEvent('pb:g:pause:ui', src, PB.Json({ ev = 'data', data = d })) end
end)
-- Ajout d'un lieu à la position du joueur (lue par le serveur) ; suppression de ses propres lieux seulement
RegisterNetEvent('pb:g:pause:place:add', function(label)
    local src = source
    if not usable(src) or not throttle(src, 600) then return end
    local p = G.Get(src)
    label = clean(label, 40)
    if #label < 2 then G.Notify(src, { type = 'warn', title = 'Lieux', text = 'Donne un nom au lieu (2 caractères minimum).' }) return end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_pause_places WHERE license = ?', { p.license })
    if n and n.n >= (tonumber(cfg('max_places', 20)) or 20) then G.Notify(src, { type = 'warn', title = 'Lieux', text = 'Tu as atteint le nombre maximal de lieux.' }) return end
    local c = GetEntityCoords and GetPlayerPed and GetEntityCoords(GetPlayerPed(src))
    if not c then return end
    DB.insert('INSERT INTO pb_pause_places (license, label, x, y, z, at) VALUES (?, ?, ?, ?, ?, ?)', { p.license, label, c.x, c.y, c.z, os.time() })
    G.Notify(src, { type = 'success', title = 'Lieux', text = 'Lieu enregistré : ' .. label .. '.' })
    TriggerClientEvent('pb:g:pause:ui', src, PB.Json({ ev = 'places', places = U.Places(src) }))
end)
RegisterNetEvent('pb:g:pause:place:del', function(pid)
    local src = source
    if not usable(src) or not throttle(src, 300) then return end
    local n = tostring(pid or ''):match('^p(%d+)$')
    if not n then return end
    DB.exec('DELETE FROM pb_pause_places WHERE id = ? AND license = ?', { tonumber(n), G.Get(src).license })
    TriggerClientEvent('pb:g:pause:ui', src, PB.Json({ ev = 'places', places = U.Places(src) }))
end)
RegisterNetEvent('pb:g:pause:gps', function(pid)
    local src = source
    if not usable(src) or not throttle(src, 300) then return end
    local pl = findPlace(src, pid)
    if pl then TriggerClientEvent('pb:g:pause:gps', src, PB.Json({ x = pl.x, y = pl.y, label = pl.label })) end
end)

-- Réglages dans le panel -------------------------------------------------------------------------------------------------------------------
local general = Form.Cfg({ ns = 'pause', id = 'general', title = 'Menu Échap', perm = 'pause.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Menu Shadow Base disponible (commande /menu)', default = true },
    { k = 'replace_esc', type = 'toggle', label = 'Échap ouvre ce menu à la place de celui du jeu', default = false, hint = "Désactivé : la touche P (menu de pause du jeu) reste le seul accès, et ce menu s'ouvre avec /menu." },
    { k = 'welcome', type = 'text', label = "Message d'accueil ({name} = nom du personnage)", default = 'Bienvenue, {name}.', maxlen = 120, wide = true },
    { k = 'max_places', type = 'number', label = 'Lieux enregistrés par joueur', default = 20, min = 1, max = 100 },
    { k = 'tab_character', type = 'toggle', label = 'Onglet Personnage', default = true }, { k = 'tab_path', type = 'toggle', label = 'Onglet Parcours', default = true },
    { k = 'tab_map', type = 'toggle', label = 'Onglet Carte', default = true }, { k = 'tab_settings', type = 'toggle', label = 'Onglet Réglages du jeu', default = true },
} })
local annForm = Form.Cfg({ ns = 'pause', id = 'announcements', title = "Annonces de l'accueil", perm = 'pause.edit', fields = {
    { k = 'announcements', type = 'rows', label = 'Annonces (la plus récente en premier)', default = {}, wide = true, maxitems = 12,
      cols = { { k = 'title', label = 'Titre', required = true, maxlen = 60 }, { k = 'text', label = 'Texte', maxlen = 400 }, { k = 'date', label = 'Date (libre)', maxlen = 20 } } } } })
local placeForm = Form.Cfg({ ns = 'pause', id = 'places', title = 'Lieux proposés à tous', perm = 'pause.edit', fields = {
    { k = 'places', type = 'rows', label = 'Lieux (coordonnées du jeu)', default = {}, wide = true, maxitems = 40,
      hint = 'Visibles dans l’onglet Carte de tous les joueurs ; le GPS les rejoint. Les joueurs ajoutent aussi leurs propres lieux.',
      cols = { { k = 'label', label = 'Nom', required = true, maxlen = 40 }, { k = 'x', label = 'X', number = true, required = true }, { k = 'y', label = 'Y', number = true, required = true }, { k = 'z', label = 'Z', number = true } } } } })

PB.Module({
    id = 'pause', label = 'Menu Échap', icon = 'menu', group = 'Serveur', order = 147, perm = 'pause.edit', hint = 'Accueil, personnage, parcours, carte, réglages du jeu',
    caps = function() return PB.Capsify({
        { 'Accueil, annonces, parcours, lieux et GPS', 'ok', 'Données composées par le serveur ; lieux ajoutés à la position lue par le serveur.' },
        { 'Fiche du personnage filmée (vous ou un véhicule)', 'partial', "Caméra de jeu devant le personnage ou devant une copie locale du véhicule, sur place : ce n'est pas un vrai studio fermé." },
        { 'Carte 2D', 'partial', "Ouvre la carte du jeu avec tes lieux et ton GPS ; les cases de territoire sont dessinées par le jeu (cercles)." },
        { 'Survol 3D du monde', 'partial', "Caméra aérienne qui rejoint un lieu enregistré. Pas de tracé de trajet dans la vue 3D : le trajet GPS apparaît sur la carte." },
        { 'Réglages du jeu', 'partial', "Filtres, ombres, distance d'affichage, radio et caméra : appels natifs du jeu ; volumes de voix seulement avec pma-voice. Jamais vérifié ici dans un vrai FiveM." },
        { 'Changer les touches', 'off', "FiveM ne permet pas à une ressource de changer les touches d'un joueur : le menu les affiche et renvoie vers Réglages > Touches du jeu." } }) end,
    doc = "## Menu Échap\n**Échap** ouvre ce menu (la touche **P** garde le menu de pause du jeu). Accueil avec annonces, **Personnage** (fiche filmée, toi ou l'un de tes véhicules), **Parcours** (emplois et organisations, du plus récent au plus ancien), **Carte** (carte du jeu ou survol 3D, lieux enregistrés, GPS) et **Réglages du jeu** (caméras, radio, volumes, filtres, ombres, touches).\n\n- Les annonces et les lieux communs se règlent dans le panel.\n- Chaque joueur enregistre ses lieux à l'endroit où il se trouve ; le serveur lit la position.\n- Les réglages du jeu sont gardés sur le PC du joueur.",
    view = function(ctx)
        return { tabs = {
            { id = 'general', label = 'Réglages', icon = 'sliders', build = function() return { general(ctx), { type = 'gpreview', kind = 'pause', title = 'Vue du joueur', cfg = {} } } end },
            { id = 'ann', label = 'Annonces', icon = 'bell', build = function() return { annForm(ctx) } end },
            { id = 'places', label = 'Lieux', icon = 'gps', build = function() return { placeForm(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('menu Échap', function(R)
    R.check(#keyList() >= 8, 'touches', 'liste des touches trop courte')
    R.check(type(U.Data) == 'function' and type(U.Path) == 'function', 'données', 'fonctions manquantes')
end)
