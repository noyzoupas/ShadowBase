/* Gamertags : étiquettes au-dessus des joueurs. Le client Lua envoie les textes (rarement) et les positions écran (souvent) ; ici on dessine.
   Tout le texte est inséré avec textContent (via le constructeur DOM). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;

function accentOf(e, c) {
  const server = (G.rmenu && G.rmenu.themeOf) ? G.rmenu.themeOf(G.cfg && G.cfg.menus).accent : '#dfe2e7';
  const hex = (x) => (typeof x === 'string' && /^#[0-9a-fA-F]{6}$/.test(x)) ? x : null;
  if (c.accent === 'server') return server;
  if (c.accent === 'job') return hex(e.jc) || server;
  return hex(e.sc) || hex(e.jc) || server;
}

function tagEl(e, c) {
  const ac = accentOf(e, c || {});
  const style = (c && c.style) || 'clean';
  const nm = h('b', { class: 'tg-n' }, String(e.n || ''));
  const idc = e.id != null ? h('i', { class: 'tg-id' }, String(e.id)) : null;
  const rank = e.s ? h('span', { class: 'tg-rank' }, h('u'), String(e.s)) : null;
  const job = e.j ? h('span', { class: 'tg-job' }, String(e.j) + (e.jg ? ' · ' + String(e.jg) : '')) : null;
  const dead = e.d ? h('span', { class: 'tg-dead' }, G.ico('skull'), 'Inconscient') : null;
  const mic = h('span', { class: 'tg-mic' }, G.ico('mic'));
  const main = h('div', { class: 'tg-main' }, mic, nm, idc);
  if (style === 'sensity') {
    // [VIP*] [Entreprise] [Gang] / [ID][Joueur] Nom (Nouveau) / Ping 48 ms
    const ok = (x) => /^#[0-9a-fA-F]{6}$/.test(x || '');
    const top = [];
    if (e.v) top.push(h('span', { class: 'ts-vip' }, '[' + String(e.v) + '*]'));
    if (e.j) top.push(h('span', { class: 'ts-co', style: ok(e.jc) ? { color: e.jc } : null }, '[' + String(e.j) + ']'));
    if (e.g) top.push(h('span', { class: 'ts-gg', style: ok(e.gc) ? { color: e.gc } : null }, '[' + String(e.g) + ']'));
    const role = h('span', { class: 'ts-role', style: e.s && ok(e.sc) ? { color: e.sc } : null }, '[' + String(e.r || 'Joueur') + ']');
    const line = h('div', { class: 'ts-ln' }, e.id != null ? h('span', { class: 'ts-id' }, '[' + String(e.id) + ']') : null, role, h('span', { class: 'ts-nm' }, String(e.n || '')), e.nw ? h('span', { class: 'ts-new' }, '(Nouveau)') : null);
    const ping = e.pg != null ? h('div', { class: 'ts-pg' + (e.pg >= 150 ? ' bad' : e.pg >= 90 ? ' mid' : '') }, 'Ping ' + String(e.pg) + ' ms') : null;
    return h('div', { class: 'tg tg-sensity' + (e.d ? ' dead' : '') }, top.length ? h('div', { class: 'ts-top' }, top) : null, line, ping, e.d ? h('div', { class: 'ts-dead' }, 'Inconscient') : null);
  }
  if (style === 'badge') {
    // comme sur Los Santos RP : badge du gang / de l'entreprise, ligne « [ID] Nom | pseudo ★ », barre de santé
    const bt = e.g || e.j || e.s || '';
    const badge = bt ? h('span', { class: 'tg-bd' }, String(bt)) : null;
    const line = h('div', { class: 'tg-ln' }, e.pf ? h('span', { class: 'tg-pf' }, String(e.pf)) : null, h('span', { class: 'tg-nm' }, String(e.n || '')),
      e.p ? h('span', { class: 'tg-ps' }, '| ' + String(e.p)) : null, e.st ? h('span', { class: 'tg-st' }, '★') : null);
    const nc = /^#[0-9a-fA-F]{6}$/.test(e.c || '') ? e.c : '#d9cb8f', tkc = /^#[0-9a-fA-F]{6}$/.test(c.talk_color || '') ? c.talk_color : '#5fd4f4';
    const bar = c.show_bar === 'none' ? null : h('i', { class: 'tg-bar' }, h('u', { style: { width: '100%' } }));
    return h('div', { class: 'tg tg-badge' + (e.d ? ' dead' : ''), style: { '--nc': nc, '--tk': tkc, '--tgc': ac, '--tgr': G.hexToRgb(ac) } }, badge, line, bar, e.d ? h('span', { class: 'tg-dead' }, G.ico('skull'), 'Inconscient') : null);
  }
  if (style === 'clean') {
    const gang = e.g ? h('span', { class: 'tg-gang', style: e.gc && /^#[0-9a-fA-F]{6}$/.test(e.gc) ? { '--gc': e.gc } : null }, String(e.g)) : null;
    const rk = e.s ? h('span', { class: 'tg-rk' }, String(e.s)) : null;
    const jb = e.j ? h('span', { class: 'tg-co' }, String(e.j) + (e.jg ? ' · ' + String(e.jg) : '')) : null;
    return h('div', { class: 'tg tg-clean' + (e.d ? ' dead' : '') + (e.s ? ' staff' : ''), style: { '--tgc': ac, '--tgr': G.hexToRgb(ac) } }, rk, gang, h('div', { class: 'tg-main' }, mic, nm, idc), jb, dead);
  }
  const body = style === 'minimal' ? [rank, main] : style === 'card' ? [rank, main, job, dead] : [rank, main, dead];
  return h('div', { class: 'tg tg-' + style + (e.d ? ' dead' : '') + (e.s ? ' staff' : ''), style: { '--tgc': ac, '--tgr': G.hexToRgb(ac) } }, body);
}
G.tagEl = tagEl;

let layer = null, data = {}, els = {};
const box = () => layer || (layer = (function () { const e = h('div', { id: 'g-tags' }); G.root.appendChild(e); return e; })());
const conf = () => (G.cfg && G.cfg.tags) || {};

let lastP = [];
function render() {
  const b = box(), seen = {};
  lastP.forEach((p) => {
    const e = data[p.i]; if (!e) return;
    seen[p.i] = 1;
    let el = els[p.i];
    if (!el) { el = tagEl(e, conf()); el.classList.add('abs'); b.appendChild(el); els[p.i] = el; }
    el.style.transform = 'translate(' + (p.x * 100).toFixed(2) + 'vw,' + (p.y * 100).toFixed(2) + 'vh) translate(-50%,-100%) scale(' + p.s + ')';
    el.classList.toggle('talk', p.t === 1);
    const bu = el.querySelector('.tg-bar u');
    if (bu && p.b != null) { bu.style.width = p.b + '%'; bu.classList.toggle('low', p.b < 30); }
  });
  Object.keys(els).forEach((k) => { if (!seen[k]) { els[k].remove(); delete els[k]; } });
}
function reset() { Object.keys(els).forEach((k) => { els[k].remove(); delete els[k]; }); render(); }
G.on('tags.data', (d) => { data = {}; (d.list || []).forEach((e) => { data[e.i] = e; }); reset(); });
G.on('tags.pos', (d) => { lastP = d.p || []; render(); });
G.on('cfg', () => { reset(); });

G.preview.tags = function (b, cfg) {
  const c = (cfg && cfg.tags) || cfg || {};
  G.clear(b);
  const people = [
    { n: 'Léa Marchand', id: 12, p: 'LEA_FR', pf: '[12]', c: '#d9cb8f', s: 'Administrateur', r: 'Administrateur', sc: '#ff6b7d', st: 1, j: 'Police', jg: 'Capitaine', jc: '#6fb4ff', v: 'Elite Club', pg: 45 },
    { n: 'Clara Willis', id: 65685, r: 'Joueur', nw: 1, pg: 48 },
    { n: 'Matt Willis', id: 80757, r: 'Joueur', v: 'Elite Club', pg: 50 },
    { n: 'Tony Vega', id: 19, p: 'TonyV', pf: '[19]', c: '#ffb457', g: 'Vagos', gc: '#ffb457', j: 'Mécano Sud', jg: 'Employé' },
    { n: 'Karim Benali', id: 7, p: 'KB_07', pf: '[7]', c: '#d9cb8f', g: 'BMF', gc: '#b58cff', t: 1 },
    { n: 'Noah Girard', id: 31, p: 'Noah', pf: '[31]', c: '#9ad7ff', d: 1 },
    { n: 'Sofia Rossi', id: 4, p: 'SofiR', pf: '[4]', c: '#c7f08a', s: 'Modérateur', sc: '#7be0a4', st: 1 },
  ];
  const scene = h('div', { class: 'tg-scene' });
  people.forEach((p, i) => {
    const e = Object.assign({}, p);
    if (c.show_id === false) delete e.id;
    if (c.show_job === false) { delete e.j; delete e.jg; }
    if (c.show_staff === false) delete e.s;
    if (c.show_gang === false) { delete e.g; delete e.gc; }
    if (c.show_dead === false) delete e.d;
    if (c.show_pseudo === false) delete e.p;
    if (c.show_star === false) delete e.st;
    if (c.prefix_fmt === '') delete e.pf;
    if (c.name_mode === 'id') e.n = 'Joueur ' + p.id;
    const el = tagEl(e, c);
    if (p.t && c.show_talking !== false) el.classList.add('talk');
    el.style.left = (14 + i * 18) + '%'; el.style.top = (30 + (i % 2) * 28) + '%';
    el.classList.add('tgp');
    scene.appendChild(el);
  });
  b.appendChild(G.fitStage(scene, 900, 360));
};
})();
