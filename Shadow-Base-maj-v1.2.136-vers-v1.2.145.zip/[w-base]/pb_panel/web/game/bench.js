/* (patch 340) Établi vu du dessus : les pièces sont posées sur un tapis, on les glisse à la souris sur leur emplacement pour assembler.
   Mode « weapon » (armes : tapis bleu quadrillé) et « drug » (drogues : tapis sombre, balance, sachets…).
   Jeu → NUI : bench.open { mode, title, hint, secs, parts: [{ id, label, kind }] } · NUI → jeu : bench.done { ok, errors, ms }. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const NS = 'http://www.w3.org/2000/svg';
// formes (viewBox 100 × 40), remplies en noir avec un liseré clair, comme les pièces posées sur l'établi
const SHAPE = {
  barrel: 'M2 14h74l4-4h18v20H80l-4-4H2z',
  slide: 'M2 8h88l8 8v8H2z',
  receiver: 'M4 6h72l12 10v8H64l-6 12H44l4-12H4z',
  stock: 'M2 12l60-4 36 4v18l-36 4L2 28z',
  grip: 'M20 2h30l12 36H34z',
  spring: 'M2 20h12l6-14 10 28 10-28 10 28 10-28 6 14h30',
  plate: 'M4 6h92v28H4zM14 14h72v12H14z',
  jar: 'M30 6h40v6l6 6v18H24V18l6-6z',
  powder: 'M14 34c4-18 20-24 36-24s32 6 36 24z',
  pills: 'M8 20a10 10 0 0110-10h22a10 10 0 010 20H18A10 10 0 018 20zM60 20a10 10 0 0110-10h12a10 10 0 010 20H70a10 10 0 01-10-10z',
  scale: 'M10 34h80v4H10zM46 10h8v24h-8zM14 12h72l-8 12H22z',
  bag: 'M30 4h40l-4 8 14 8v18H20V20l14-8z',
};
const LAY = {"pistol":{"vw":560,"vh":300,"parts":[{"id":"slide","file":"pistol_slide.png","x":20,"y":6,"w":360,"h":64},{"id":"barrel","file":"pistol_barrel.png","x":385,"y":20,"w":110,"h":44},{"id":"receiver","file":"pistol_receiver.png","x":20,"y":78,"w":300,"h":140},{"id":"spring","file":"pistol_spring.png","x":60,"y":230,"w":150,"h":30},{"id":"mag","file":"pistol_mag.png","x":330,"y":100,"w":70,"h":120},{"id":"trigger","file":"pistol_trigger.png","x":420,"y":120,"w":40,"h":56}]},"snspistol":{"vw":460,"vh":280,"parts":[{"id":"slide","file":"snspistol_slide.png","x":20,"y":6,"w":290,"h":56},{"id":"barrel","file":"snspistol_barrel.png","x":315,"y":18,"w":100,"h":38},{"id":"receiver","file":"snspistol_receiver.png","x":20,"y":68,"w":240,"h":120},{"id":"spring","file":"snspistol_spring.png","x":40,"y":200,"w":120,"h":26},{"id":"mag","file":"snspistol_mag.png","x":270,"y":90,"w":56,"h":100},{"id":"trigger","file":"snspistol_trigger.png","x":340,"y":110,"w":34,"h":48}]},"microsmg":{"vw":700,"vh":380,"parts":[{"id":"stock","file":"microsmg_stock.png","x":10,"y":40,"w":180,"h":60},{"id":"slide","file":"microsmg_slide.png","x":190,"y":6,"w":300,"h":60},{"id":"receiver","file":"microsmg_receiver.png","x":190,"y":70,"w":300,"h":130},{"id":"barrel","file":"microsmg_barrel.png","x":490,"y":24,"w":160,"h":44},{"id":"mag","file":"microsmg_mag.png","x":330,"y":200,"w":80,"h":150},{"id":"spring","file":"microsmg_spring.png","x":210,"y":330,"w":130,"h":28},{"id":"trigger","file":"microsmg_trigger.png","x":440,"y":200,"w":40,"h":54}]},"sawnoff":{"vw":1000,"vh":340,"parts":[{"id":"stock","file":"sawnoff_stock.png","x":10,"y":60,"w":300,"h":130},{"id":"receiver","file":"sawnoff_receiver.png","x":300,"y":70,"w":250,"h":120},{"id":"barrel","file":"sawnoff_barrel.png","x":550,"y":60,"w":420,"h":76},{"id":"slide","file":"sawnoff_slide.png","x":350,"y":24,"w":140,"h":48},{"id":"spring","file":"sawnoff_spring.png","x":570,"y":170,"w":220,"h":30},{"id":"trigger","file":"sawnoff_trigger.png","x":470,"y":200,"w":44,"h":58}]},"compactrifle":{"vw":1060,"vh":380,"parts":[{"id":"stock","file":"compactrifle_stock.png","x":10,"y":60,"w":260,"h":130},{"id":"receiver","file":"compactrifle_receiver.png","x":260,"y":60,"w":330,"h":130},{"id":"barrel","file":"compactrifle_barrel.png","x":590,"y":86,"w":390,"h":42},{"id":"slide","file":"compactrifle_slide.png","x":350,"y":20,"w":150,"h":50},{"id":"mag","file":"compactrifle_mag.png","x":360,"y":190,"w":86,"h":150},{"id":"handguard","file":"compactrifle_handguard.png","x":590,"y":70,"w":200,"h":70},{"id":"spring","file":"compactrifle_spring.png","x":420,"y":330,"w":190,"h":28},{"id":"trigger","file":"compactrifle_trigger.png","x":510,"y":190,"w":44,"h":58}]},"assaultrifle":{"vw":1140,"vh":400,"parts":[{"id":"stock","file":"assaultrifle_stock.png","x":10,"y":60,"w":290,"h":140},{"id":"receiver","file":"assaultrifle_receiver.png","x":290,"y":56,"w":370,"h":134},{"id":"barrel","file":"assaultrifle_barrel.png","x":660,"y":88,"w":440,"h":42},{"id":"slide","file":"assaultrifle_slide.png","x":390,"y":16,"w":160,"h":52},{"id":"mag","file":"assaultrifle_mag.png","x":420,"y":190,"w":92,"h":170},{"id":"handguard","file":"assaultrifle_handguard.png","x":660,"y":72,"w":260,"h":74},{"id":"spring","file":"assaultrifle_spring.png","x":450,"y":350,"w":200,"h":28},{"id":"trigger","file":"assaultrifle_trigger.png","x":560,"y":190,"w":46,"h":60}]}};
let box = null, tick = 0;
function svg(kind, cls) {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 100 40'); s.setAttribute('class', cls || '');
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', SHAPE[kind] || SHAPE.plate);
  if (kind === 'spring') p.setAttribute('fill', 'none');
  s.appendChild(p); return s;
}
function drop(res) {
  clearInterval(tick); tick = 0;
  if (box) { box.remove(); box = null; }
  if (res) G.post('bench.done', res);
}
G.on('bench.close', () => drop(null));
G.on('bench.open', function (d) {
  drop(null);
  const mode = d.mode === 'drug' ? 'drug' : 'weapon';
  const parts = (Array.isArray(d.parts) ? d.parts : []).slice(0, 8);
  if (!parts.length) { G.post('bench.done', { ok: true, errors: 0, ms: 0 }); return; }
  const secs = Math.max(3, Math.min(240, Number(d.secs) || 10)), t0 = Date.now();
  const W = 1100, H = 600;
  let placed = 0, errors = 0, finishing = false;
  const stage = h('div', { class: 'bn-st', style: { width: W + 'px', height: H + 'px' } });
  const lay = mode === 'weapon' && LAY[d.weapon] ? LAY[d.weapon] : null;
  let pieces;
  if (lay) {
    // (patch 342) pièces rendues en 3D (web/img/bench) : l'arme assemblée est dessinée en ombre en haut, les pièces sont éparpillées dessous
    const want = {}; parts.forEach((p) => { want[p.id] = 1; });
    const lp = lay.parts;   // toutes les pièces de l'arme (pas seulement celles de la recette)
    const f = Math.min(1, 980 / lay.vw), ox = (W - lay.vw * f) / 2, oy = 24;
    pieces = lp.map((q) => {
      const w = q.w * f, hh = q.h * f, sx = ox + q.x * f, sy = oy + q.y * f;
      const slot = h('div', { class: 'bn-sl img', style: { left: sx + 'px', top: sy + 'px', width: w + 'px', height: hh + 'px' } }, h('img', { src: 'img/bench/' + q.file, draggable: false, alt: '' }));
      const px = 20 + Math.random() * Math.max(10, W - w - 40), py = 300 + Math.random() * Math.max(10, H - 340 - hh * 0.5);
      const el = h('div', { class: 'bn-p img', style: { left: px + 'px', top: py + 'px', width: w + 'px', height: hh + 'px', transform: 'rotate(' + Math.round(Math.random() * 60 - 30) + 'deg)' } }, h('img', { src: 'img/bench/' + q.file, draggable: false, alt: '' }));
      stage.appendChild(slot); return { slot, el, sx, sy, w, h: hh, done: false };
    });
  } else {
    const n0 = parts.length, gap = (W - 60) / n0;
    pieces = parts.map((p, i) => {
      const sx = 30 + gap * i + gap / 2 - 60;
      const slot = h('div', { class: 'bn-sl', style: { left: sx + 'px', top: '70px' } }, svg(p.kind, 'g'), h('small', null, String(p.label || '')));
      const px = 40 + Math.random() * (W - 220), py = 260 + Math.random() * 270;
      const el = h('div', { class: 'bn-p', style: { left: px + 'px', top: py + 'px', transform: 'rotate(' + Math.round(Math.random() * 50 - 25) + 'deg)' } }, svg(p.kind, 'f'));
      stage.appendChild(slot); return { slot, el, sx, sy: 70, w: 120, h: 70, done: false };
    });
  }
  pieces.forEach((q) => stage.appendChild(q.el));
  const n = pieces.length;
  const msg = h('div', { class: 'bn-msg' }, String(d.hint || (mode === 'drug' ? 'Glisse chaque ingrédient sur son emplacement.' : "Assemble les pièces de l'arme : clic gauche pour glisser.")));
  const bar = h('i'), barw = h('div', { class: 'bn-bar' }, bar);
  box = h('div', { id: 'g-bench', class: 'bn-' + mode }, [
    h('div', { class: 'bn-top' }, h('b', null, String(d.title || 'Établi')), h('span', null, 'Échap : annuler')),
    h('div', { class: 'bn-mat' }, stage), msg, barw]);
  G.root.appendChild(box);
  const sc = Math.min(1.4, (window.innerWidth * 0.84) / W, (window.innerHeight * 0.7) / H);
  stage.style.transform = 'scale(' + sc + ')'; stage.style.transformOrigin = '50% 0';
  let drag = null;
  pieces.forEach((q) => {
    q.el.addEventListener('pointerdown', (e) => {
      if (q.done || finishing) return;
      const r = q.el.getBoundingClientRect();
      drag = { q, dx: e.clientX - r.left, dy: e.clientY - r.top };
      q.el.classList.add('up'); q.el.style.transform = 'rotate(0deg)';
      try { q.el.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
    });
    q.el.addEventListener('pointermove', (e) => {
      if (!drag || drag.q !== q) return;
      const s = stage.getBoundingClientRect();
      q.el.style.left = ((e.clientX - s.left - drag.dx) / sc) + 'px';
      q.el.style.top = ((e.clientY - s.top - drag.dy) / sc) + 'px';
    });
    q.el.addEventListener('pointerup', () => {
      if (!drag || drag.q !== q) return;
      drag = null; q.el.classList.remove('up');
      const x = parseFloat(q.el.style.left), y = parseFloat(q.el.style.top);
      let hit = null;
      pieces.forEach((o) => { if (!o.done && Math.abs(x - o.sx) < 48 && Math.abs(y - o.sy) < 40) hit = o; });
      if (hit === q) {
        q.done = true; placed++;
        q.el.style.left = q.sx + 'px'; q.el.style.top = q.sy + 'px'; q.el.classList.add('ok'); q.slot.classList.add('ok');
        if (placed >= n) finish();
      } else if (hit) { errors++; q.el.classList.add('bad'); setTimeout(() => q.el.classList.remove('bad'), 300); }
    });
  });
  function finish() {
    finishing = true;
    msg.textContent = mode === 'drug' ? 'Mélange en cours…' : 'Assemblage…';
    pieces.forEach((q) => { q.slot.style.opacity = '0'; });
    box.classList.add('fin');
  }
  tick = setInterval(() => {
    const el = (Date.now() - t0) / 1000;
    bar.style.width = Math.min(100, el / secs * 100) + '%';
    if (finishing && el >= secs) drop({ ok: true, errors, ms: Date.now() - t0 });
    else if (!finishing && el >= secs * 4 + 20) drop({ ok: false, errors, ms: Date.now() - t0 });   // trop long : abandon
  }, 100);
});
G.nui = G.nui || {};
window.addEventListener('keydown', (e) => { if (box && e.key === 'Escape') { e.preventDefault(); drop({ ok: false, errors: 0, ms: 0, cancel: true }); } }, true);
})();
