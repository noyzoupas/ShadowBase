-- Module 21 : Interface du panel (thème par défaut du serveur, préférences par personne, langue, documentation, raccourcis).

local B, P, Form = PB.B, PB.Perm, PB.Form

P.Register('interface.edit', "Modifier l'apparence par défaut du panel", 'interface')

local appearance = Form.Cfg({
    ns = 'interface', id = 'appearance', title = 'Apparence par défaut', perm = 'interface.edit', cols = 2,
    desc = "Valeurs utilisées par tous ceux qui n'ont pas choisi leurs propres réglages. Chacun peut ensuite personnaliser son panel dans « Mes préférences ».",
    fields = {
        { k = 'theme', type = 'select', label = 'Thème', default = 'elyx', opts = { { 'elyx', 'W (gris blanc)' }, { 'mauve', 'Mauve' }, { 'aurora', 'Aurore (bleu-vert)' }, { 'ember', 'Braise (orange)' }, { 'forest', 'Forêt (vert)' }, { 'mono', 'Monochrome' }, { 'halloween', 'Halloween' }, { 'noel', 'Noël' } } },
        { k = 'glass_level', type = 'select', label = 'Opacité (panel, inventaire et toutes les interfaces en jeu)', default = 'solid', opts = { { 'clear', 'Transparent' }, { 'soft', 'Léger' }, { 'solid', 'Opaque' }, { 'full', 'Presque plein' } }, hint = 'Un seul niveau pour toute la base : le panel, le menu de configuration, l\'inventaire, la banque, la boutique…' },
        { k = 'blur', type = 'range', label = 'Flou de fond (px)', default = 18, min = 0, max = 40, step = 1 },
        { k = 'radius', type = 'range', label = 'Arrondi des angles (px)', default = 22, min = 0, max = 32, step = 1 },
        { k = 'density', type = 'select', label = 'Densité', default = 'comfort', opts = { { 'compact', 'Compacte' }, { 'comfort', 'Confortable' }, { 'large', 'Large' } } },
        { k = 'font_scale', type = 'range', label = 'Taille du texte', default = 1, min = 0.85, max = 1.3, step = 0.05 },
        { k = 'lang', type = 'select', label = 'Langue par défaut', default = 'fr', opts = { { 'fr', 'Français' }, { 'en', 'English' } } },
        { k = 'big_logo', type = 'toggle', label = "Logo en grand en haut des onglets", default = true },
        { k = 'animations', type = 'toggle', label = 'Animations', default = true },
        { k = 'panel_x', type = 'range', label = 'Position horizontale du panneau (%)', default = 50, min = 20, max = 80, step = 1 },
        { k = 'panel_w', type = 'range', label = 'Largeur du panneau (% de l\'écran)', default = 100, min = 50, max = 100, step = 1 },
    },
})

-- Position du menu de la librairie admin (le menu lui-même n'est PAS recréé : le panel ne fait que mémoriser et transmettre sa position)
PB.Action('interface.staffmenu.save', 'interface.edit', function(ctx, p)
    local v = p.values or {}
    local clean, err = PB.Validate({
        { k = 'x', type = 'number', label = 'Position horizontale', min = 0, max = 100, int = false },
        { k = 'y', type = 'number', label = 'Position verticale', min = 0, max = 100, int = false },
        { k = 'scale', type = 'number', label = 'Taille', min = 0.6, max = 1.6, int = false },
        { k = 'opacity', type = 'number', label = 'Opacité', min = 0.3, max = 1, int = false },
    }, { x = v.x, y = v.y, scale = v.scale or 1, opacity = v.opacity or 1 })
    if not clean then return false, err end
    local before = PB.Cfg.Get('interface', 'staffmenu', {})
    PB.Cfg.Set('interface', 'staffmenu', clean, ctx.actor, 'Position du menu de la librairie admin')
    local pushed = PB.AdminLib.Call('setLayout', clean)
    ctx.audit('config', 'interface.staffmenu', 'position', before, clean)
    ctx.toast = pushed ~= nil and 'Position enregistrée et transmise à la librairie.' or 'Position enregistrée. Ta librairie la lit avec exports.pb_panel:GetStaffMenuLayout().'
    return true
end)
exports('GetStaffMenuLayout', function() return PB.Cfg.Get('interface', 'staffmenu', { x = 50, y = 12, scale = 1, opacity = 1 }) end)

-- Position du chat, de l'invite « E » et de la barre de progression (en % de l'écran ; centre de l'élément, sauf le chat : coin bas-gauche)
PB.Cfg.Define('place', { chat_x = 1.2, chat_y = 3, prompt_x = 50, prompt_y = 82, prog_x = 50, prog_y = 80, ammo_x = 98.8, ammo_y = 98, mm_x = 0, mm_y = 79.2 })
local PLACE_DEFAULT = { chat_x = 1.2, chat_y = 3, prompt_x = 50, prompt_y = 82, prog_x = 50, prog_y = 80, ammo_x = 98.8, ammo_y = 98 }
-- (v1.2.45) chat en haut à gauche (ancré par le haut) : l'ancienne place par défaut (22,5 % du bas) est déplacée une fois
PB.OnReady(function()
    if PB.Cfg.Get('place', 'chat_top_v1', false) ~= true then
        PB.Cfg.Set('place', 'chat_x', 1.2, nil, 'Chat en haut à gauche')
        PB.Cfg.Set('place', 'chat_y', 3, nil, 'Chat en haut à gauche')
        PB.Cfg.Set('place', 'chat_top_v1', true, nil, 'Migration')
    end
end)
-- (v1.2.45) munitions en bas à droite (au-dessus des points d'une guerre de territoire) : l'ancienne place par défaut (en haut) est déplacée
PB.OnReady(function()
    if PB.Cfg.Get('place', 'ammo_bottom_v1', false) ~= true then
        if (tonumber(PB.Cfg.Get('place', 'ammo_y', 98)) or 98) == 9 then PB.Cfg.Set('place', 'ammo_y', 98, nil, 'Munitions en bas à droite') end
        PB.Cfg.Set('place', 'ammo_bottom_v1', true, nil, 'Migration')
    end
end)

-- Éditeur de placement : positions de tous les éléments en jeu, validées et journalisées par groupe de réglages.
local PLACE = {
    hud    = { perm = 'hud.edit',    why = 'Position du HUD',            keys = { pos_x = { 0, 100 }, pos_y = { 0, 100 }, ring_x = { 0, 100 }, ring_y = { 0, 100 }, bar_x = { 0, 100 }, bar_y = { 0, 100 }, veh_x = { 0, 100 }, veh_y = { 0, 100 }, photo_x = { 0, 95 }, photo_y = { 0, 60 }, scale = { 0.5, 1.8 }, veh_scale = { 0.5, 1.8 }, opacity = { 0.3, 1 } } },
    staff  = { perm = 'staff.edit',  why = 'Position du tableau staff',  keys = { hud_x = { 0, 95 }, hud_y = { 0, 95 }, hud_top = { 0, 30 } } },
    notify = { perm = 'uikit.edit',  why = 'Position des notifications', keys = { lift = { 5, 60 }, x = { 0, 80 }, y = { 0, 92 } }, enums = { position = { custom = 1, map = 1, ['top-right'] = 1, ['top-left'] = 1, ['top-center'] = 1, ['bottom-right'] = 1, ['bottom-left'] = 1, ['bottom-center'] = 1 } } },
    staffmenu = { perm = 'interface.edit', why = 'Position du menu staff', keys = { x = { 0, 100 }, y = { 0, 100 }, scale = { 0.6, 1.6 }, opacity = { 0.3, 1 } }, special = true },
    place  = { perm = 'interface.edit', why = "Position du chat, de l'invite, de la barre de progression et des munitions", keys = { chat_x = { 0, 80 }, chat_y = { 0, 80 }, prompt_x = { 0, 100 }, prompt_y = { 0, 100 }, prog_x = { 0, 100 }, prog_y = { 0, 100 }, ammo_x = { 0, 100 }, mm_x = { 0, 85 }, mm_y = { 0, 81 }, ammo_y = { 0, 100 } } },
    menus  = { perm = 'menus.edit',  why = 'Position du menu personnel', keys = { offset_x = { -2000, 2000 }, offset_y = { -2000, 2000 } }, enums = { position = { left = 1, center = 1, right = 1 } } },
}
PB.Interface = PB.Interface or {}
PB.Interface.Place = PLACE
PB.Interface.Versions = PB.Interface.Versions or {}   -- les fichiers en jeu y ajoutent leur choix de version : function(ctx) -> blocs
PB.Action('interface.place.save', 'panel.open', function(ctx, p)
    local groups = type(p.groups) == 'table' and p.groups or {}
    local done = {}
    for ns, vals in pairs(groups) do
        local g = PLACE[ns]
        if not g or type(vals) ~= 'table' then return false, 'Groupe inconnu.' end
        if not ctx.has(g.perm) then return false, "Tu n'as pas le droit de modifier : " .. g.why:lower() .. '.' end
        local patch = {}
        for k, rng in pairs(g.keys) do
            local v = vals[k]
            if v ~= nil then
                v = tonumber(v)
                if not v or v ~= v or v < rng[1] or v > rng[2] then return false, ('Valeur hors limites : %s.'):format(k) end
                patch[k] = v
            end
        end
        for k, allowed in pairs(g.enums or {}) do
            local v = vals[k]
            if v ~= nil then
                if type(v) ~= 'string' or not allowed[v] then return false, ('Valeur inconnue : %s.'):format(k) end
                patch[k] = v
            end
        end
        if next(patch) then done[#done + 1] = { ns = ns, patch = patch, g = g } end
    end
    if #done == 0 then return false, 'Rien à enregistrer.' end
    for _, d in ipairs(done) do
        local before = {}
        if d.g.special then
            -- menu staff : une seule valeur « interface.staffmenu » ; transmise aussi à la librairie admin si elle expose setLayout
            local cur = PB.Cfg.Get('interface', 'staffmenu', { x = 50, y = 22, scale = 1, opacity = 1 })
            local nv = {}
            for k, v in pairs(cur) do nv[k] = v end
            for k, v in pairs(d.patch) do nv[k] = v end
            PB.Cfg.Set('interface', 'staffmenu', nv, ctx.actor, d.g.why)
            pcall(function() PB.AdminLib.Call('setLayout', nv) end)
            ctx.audit('config', 'interface.place', d.ns, cur, nv)
            goto continue
        end
        for k in pairs(d.patch) do before[k] = PB.Cfg.Get(d.ns, k) end
        local ok, e = PB.Cfg.SetMany(d.ns, d.patch, ctx.actor, d.g.why)
        if ok == false or ok == nil and e then return false, e end
        ctx.audit('config', 'interface.place', d.ns, before, d.patch)
        ::continue::
    end
    ctx.toast = 'Positions enregistrées et envoyées aux joueurs.'
    return true
end)

PB.Module({
    id = 'interface', label = 'Interface', icon = 'palette', group = 'Système', order = 200, perm = 'panel.open', hint = 'Thème, langue, préférences, aide',
    caps = function()
        return PB.Capsify({
            { 'Thèmes, transparence, flou, arrondi, densité', 'ok', 'Appliqués immédiatement dans le panel.' },
            { 'Préférences par personne', 'ok', 'Enregistrées côté serveur, pour chaque licence.' },
            { 'Favoris et recherche globale', 'ok', 'Recherche sur les modules, onglets et réglages auxquels tu as accès.' },
            { 'Langues', 'partial', "Interface en français et en anglais. Les libellés des réglages des scripts tiers restent en français." },
            { 'Interfaces en jeu : HUD, créateur de personnage, écran de mort, magasins, notifications, chat, menu', 'ok', "Fournies par le panel (lot 1) et configurées depuis ses modules. Les autres écrans (inventaire, téléphone, métiers...) arrivent par lots." },
        })
    end,
    doc = "## Interface\nLes réglages par défaut s'appliquent à tout le monde ; chaque personne peut en choisir d'autres pour elle seule.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('mine', 'Mes préférences', 'user', function()
                return { { type = 'prefs', id = 'myprefs', title = 'Mes préférences', desc = "Enregistrées pour ta licence. Elles remplacent les valeurs par défaut du serveur." } }
            end),
            tab('default', 'Apparence du serveur', 'palette', function() return { appearance(ctx) } end, 'interface.edit'),
            tab('versions', 'Versions des interfaces', 'layers', function()
                local out = { B.notice('info', "Pour chaque interface qui existe en plusieurs présentations, choisis ici celle de ton serveur. L'aperçu montre chaque version telle qu'elle apparaît en jeu.") }
                for _, fn in ipairs(PB.Interface.Versions) do for _, b in ipairs(fn(ctx)) do out[#out + 1] = b end end
                return out
            end),
            tab('keys', 'Raccourcis', 'keyboard', function()
                return { B.kv('Ouverture', { { 'Touche', tostring(Config.OpenKey) }, { 'Commande', '/' .. tostring(Config.OpenCommand) } }),
                    B.notice('info', "Par défaut le panel n'a pas de touche : F10 ouvre le menu staff, qui contient « Ouvrir le panel de configuration ». Tu peux aussi définir une touche (Config.OpenKey) ou utiliser la commande. Chaque joueur peut aussi réassigner la touche dans les paramètres de touches de FiveM.", 'Raccourcis'),
                    B.kv('Dans le panel', { { 'Recherche globale', 'Ctrl + K' }, { 'Fermer', 'Échap' } }) }
            end),
        } }
    end,
})

-- Une seule fois : panneau plein écran et réellement transparent (les réglages faits ensuite dans le panel sont conservés).
PB.OnReady(function()
    if PB.Cfg.Get('interface', 'full_v2', false) ~= true then
        PB.Cfg.Set('interface', 'glass_level', 'solid', nil, 'Opacité par défaut')
        PB.Cfg.Set('interface', 'panel_w', 100, nil, 'Panel plein écran par défaut')
        PB.Cfg.Set('interface', 'panel_x', 50, nil, 'Panel plein écran par défaut')
        PB.Cfg.Set('interface', 'full_v2', true, nil, 'Migration')
    end
end)

PB.OnReady(function() PB.SelfTest.Add('placement: groupes et bornes de position', function(R)
    for ns, g in pairs(PB.Interface.Place) do
        R.check(type(g.perm) == 'string' and g.perm ~= '', 'Placement', 'groupe sans permission : ' .. ns)
        for k, rng in pairs(g.keys) do R.check(rng[1] < rng[2], 'Placement', 'bornes invalides : ' .. ns .. '.' .. k) end
    end
    R.check(PB.Cfg.Get('hud', 'photo_x') ~= nil, 'Placement', 'hud.photo_x doit avoir une valeur par défaut')
end) end)
