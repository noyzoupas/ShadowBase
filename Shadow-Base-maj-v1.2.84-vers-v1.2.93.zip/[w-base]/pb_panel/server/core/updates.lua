-- Mises à jour de Shadow Base : le serveur lit régulièrement un fichier latest.json publié gratuitement (GitHub Pages / Releases),
-- vérifie sa signature Ed25519 (même clé publique que les licences : une fausse mise à jour est refusée), et prévient les administrateurs
-- (console, notification du panel, module « Mises à jour » avec les patch notes et le lien de téléchargement).
-- (v1.2.78) « wupdate » (console txAdmin) ou « Installer et redémarrer » (panel) installe la mise à jour puis redémarre.
--
-- latest.json : { "v":1, "version":"1.2.0", "date":"2026-10-20", "title":"…", "notes":["…"], "download":"https://…zip", "sha256":"…", "site":"https://…", "sig":"<hex>" }
-- Signature sur :  WBUPD1|version|date|download|sha256   (outil : W-Base/outils/publier.py)

PB.Update = PB.Update or {}
local U = PB.Update
local E = PB.Ed25519
local RES = GetCurrentResourceName()

local P = PB.Perm
P.Register('updates.view', 'Voir les mises à jour de Shadow Base', 'panel')

local function cfg() return (Config and Config.Update) or {} end
-- adresse : convar wbase_update_url > Config.Update.url > fichier update_url.txt (écrit par l'outil de publication, livré dans le zip)
local function url()
    local c = GetConvar('wbase_update_url', '') if c ~= '' then return c end
    local u = tostring(cfg().url or '') if u ~= '' then return u end
    return (tostring(LoadResourceFile(RES, 'update_url.txt') or ''):gsub('%s+', ''))
end
U.Current = GetResourceMetadata(RES, 'version', 0) or '0.0.0'
U.Latest, U.Checked, U.Error = nil, 0, nil

local function parts(v) local a, b, c = tostring(v or ''):match('^(%d+)%.(%d+)%.(%d+)') return tonumber(a) or 0, tonumber(b) or 0, tonumber(c) or 0 end
function U.Newer(a, b)   -- a plus récente que b ?
    local a1, a2, a3 = parts(a)
    local b1, b2, b3 = parts(b)
    if a1 ~= b1 then return a1 > b1 end
    if a2 ~= b2 then return a2 > b2 end
    return a3 > b3
end

function U.Verify(doc)
    if type(doc) ~= 'table' or doc.v ~= 1 then return false, 'Fichier de mise à jour illisible.' end
    for _, k in ipairs({ 'version', 'date', 'download', 'sha256', 'sig' }) do if type(doc[k]) ~= 'string' or doc[k] == '' then return false, 'Champ manquant : ' .. k end end
    if not tostring(doc.download):match('^https://') then return false, 'Lien de téléchargement non sécurisé.' end
    local pub = E.unhex(PB.LicensePub or '')
    local sig = E.unhex(doc.sig)
    if not pub or #pub ~= 32 or not sig or #sig ~= 64 then return false, 'Signature absente.' end
    local msg = ('WBUPD1|%s|%s|%s|%s'):format(doc.version, doc.date, doc.download, doc.sha256)
    if not E.verify(sig, msg, pub) then return false, 'Signature incorrecte : mise à jour ignorée (fichier modifié ou faux).' end
    return true
end

-- Mise à jour rapide : le petit zip prévu pour la version installée (seulement les fichiers changés). Signé lui aussi, sinon on l'ignore.
function U.Delta(doc)
    if type(doc) ~= 'table' or type(doc.deltas) ~= 'table' then return nil end
    for _, d in ipairs(doc.deltas) do
        if type(d) == 'table' and d.from == U.Current and type(d.url) == 'string' and d.url:match('^https://') and type(d.sha256) == 'string' and type(d.sig) == 'string' then
            local pub, sig = E.unhex(PB.LicensePub or ''), E.unhex(d.sig)
            if pub and #pub == 32 and sig and #sig == 64 and E.verify(sig, ('WBDELTA1|%s|%s|%s|%s'):format(doc.version, d.from, d.url, d.sha256), pub) then return d end
            return nil
        end
    end
    return nil
end

function U.Check(cb)
    local u = url()
    if not u:match('^https://') then U.Error = 'Adresse de mise à jour non renseignée (Config.Update.url).' if cb then cb(false) end return end
    PerformHttpRequest(u .. (u:find('?', 1, true) and '&' or '?') .. 't=' .. os.time(), function(status, body)
        U.Checked = os.time()
        if status ~= 200 or not body then U.Error = 'Serveur de mises à jour injoignable (' .. tostring(status) .. ').' if cb then cb(false) end return end
        local doc = PB.FromJson(body, nil)
        local ok, why = U.Verify(doc)
        if not ok then U.Error = why PB.Warn('[mises à jour] ' .. why) if cb then cb(false) end return end
        U.Error = nil
        local was = U.Latest and U.Latest.version
        U.Latest = doc
        if U.Newer(doc.version, U.Current) and was ~= doc.version then
            print('^3============================================================^7')
            print(('^3[Shadow Base]^7 Mise à jour disponible : ^2%s^7 (installée : %s) — %s'):format(doc.version, U.Current, tostring(doc.title or '')))
            local d = U.Delta(doc)
            print('^3[Shadow Base]^7 Téléchargement : ' .. (d and (d.url .. (' (%d fichiers changés)'):format(tonumber(d.files) or 0)) or doc.download))
            print('^3============================================================^7')
            if PB.Notify then PB.Notify('info', 'Mise à jour Shadow Base ' .. doc.version, tostring(doc.title or 'Nouvelle version disponible.')) end
        end
        if cb then cb(true) end
    end, 'GET', '', { ['Accept'] = 'application/json' })
end

-- (v1.2.81) Installation automatique : dès qu'une nouvelle version est publiée, le serveur l'installe tout seul et redémarre
-- (annonce aux joueurs « Redémarrage dans X minutes » ; 15 s s'il n'y a personne). Plus besoin de savoir quand taper « wupdate ».
-- Réglable dans le panel › Mises à jour (désactivable). Vérification toutes les 10 minutes.
local function acfg(k, d) local v = PB.Cfg and PB.Cfg.Get('updates', k, nil) if v == nil then return d end return v end
local tried = {}   -- version -> true : une seule tentative automatique par version (pas de boucle si l'installation échoue)
local told = {}
function U.AutoTick()
    if U.Busy or not U.Latest or not U.Newer(U.Latest.version, U.Current) then return end
    local v = U.Latest.version
    -- (v1.2.88) par défaut : rien ne s'installe ni ne redémarre tout seul ; la console et le staff en ligne sont prévenus, « wupdate » installe
    if acfg('auto', false) ~= true then
        if told[v] then return end
        told[v] = true
        print(('^3[Shadow Base]^7 Version %s disponible : tape ^2wupdate^7 dans la console pour l\'installer et redémarrer.'):format(v))
        for _, id in ipairs(GetPlayers()) do
            local s = tonumber(id)
            if P.Has(s, 'updates.install') and PB.G and PB.G.Notify then
                PB.G.Notify(s, { type = 'info', title = 'Mise à jour ' .. v, text = 'Nouvelle version de Shadow Base disponible : « wupdate » dans la console txAdmin pour l\'installer.', duration = 12000 })
            end
        end
        return
    end
    if tried[v] then return end
    tried[v] = true
    local n = #GetPlayers()
    local secs = n > 0 and math.max(1, math.min(60, math.floor(tonumber(acfg('auto_minutes', 5)) or 5))) * 60 or 15
    print(('^3[Shadow Base]^7 Installation automatique de la version %s (redémarrage dans %d s, %d joueur(s) en ligne).'):format(v, secs, n))
    U.Install('automatique', secs, function(ok, msg)
        print(('%s[Shadow Base]^7 %s'):format(ok and '^2' or '^1', tostring(msg)))
        if PB.Notify then PB.Notify(ok and 'success' or 'error', 'Mise à jour automatique', tostring(msg)) end
    end)
end
CreateThread(function()
    Wait(20000)
    while true do
        pcall(U.Check, function(ok) if ok then pcall(U.AutoTick) end end)
        Wait(math.max(2, math.min(360, math.floor(tonumber(acfg('check_minutes', 10)) or 10))) * 60 * 1000)
    end
end)

RegisterCommand('wbase_update', function(src)
    if src ~= 0 then return end
    U.Check(function(ok)
        if not ok then print('^1[Shadow Base]^7 ' .. tostring(U.Error)) return end
        if U.Newer(U.Latest.version, U.Current) then print(('^3[Shadow Base]^7 Version %s disponible (installée : %s) : %s'):format(U.Latest.version, U.Current, U.Latest.download))
        else print(('^2[Shadow Base]^7 À jour (%s).'):format(U.Current)) end
    end)
end, true)

-- (v1.2.78) Installation automatique : « wupdate » dans la console (txAdmin › Console) ou le bouton du panel.
-- 1. lit latest.json et vérifie sa signature ; 2. télécharge le petit zip prévu pour la version installée (sinon le zip complet) ;
-- 3. vérifie son empreinte SHA-256 (publiée et signée) et chaque fichier (CRC) ; 4. écrit les fichiers dans resources/[w-base]
--    (jamais pb_panel/config.lua, license.key ni server.cfg) ; 5. redémarre le serveur avec le compte à rebours habituel (txAdmin le relance).
-- Tout est vérifié AVANT d'écrire le premier fichier : un téléchargement abîmé n'installe rien.
U.Busy = false
local PROTECT = { ['pb_panel/config.lua'] = true, ['pb_panel/license.key'] = true }
local WIN = (type(package) == 'table' and package.config and package.config:sub(1, 1) == '\\') or tostring(GetResourcePath and GetResourcePath(RES) or ''):match('^%a:[/\\]') ~= nil
local function say(msg, kind) print(('%s[Shadow Base]^7 %s'):format(kind == 'err' and '^1' or (kind == 'ok' and '^2' or '^3'), msg)) end
local function baseDir()
    local p = (GetResourcePath and GetResourcePath(RES) or ''):gsub('\\', '/')
    return p:match('^(.*)/[^/]+$')   -- dossier qui contient pb_panel ([w-base])
end
local function mkdirs(dir)
    if WIN then os.execute(('mkdir "%s" >nul 2>nul'):format(dir:gsub('/', '\\'))) else os.execute(("mkdir -p '%s'"):format(dir:gsub("'", ""))) end
end
local function writeFile(path, data)
    local f = io.open(path, 'wb')
    if not f then mkdirs(path:match('^(.*)/[^/]+$') or '.') f = io.open(path, 'wb') end
    if not f then return false end
    f:write(data) f:close()
    return true
end
local function yield() Wait(0) end
function U.Install(by, restartSecs, done)
    if U.Busy then return done(false, 'Une installation est déjà en cours.') end
    if not (PB.Zip and io and io.open) then return done(false, "Ce serveur ne permet pas d'écrire les fichiers (bibliothèque io absente) : installe le zip à la main.") end
    local base = baseDir()
    if not base then return done(false, 'Dossier des ressources introuvable.') end
    U.Busy = true
    local function fin(ok, msg) U.Busy = false done(ok, msg) end
    U.Check(function(ok)
        if not ok then return fin(false, tostring(U.Error)) end
        local L = U.Latest
        if not U.Newer(L.version, U.Current) then return fin(false, ('Déjà à jour (%s).'):format(U.Current)) end
        local d = U.Delta(L)
        local link, sha = d and d.url or L.download, d and d.sha256 or L.sha256
        say(('Téléchargement de la version %s (%s)…'):format(L.version, d and ('mise à jour rapide, %d fichiers'):format(tonumber(d.files) or 0) or 'zip complet'))
        PerformHttpRequest(link, function(status, body)
            CreateThread(function()
                if status ~= 200 or type(body) ~= 'string' or #body < 100 then return fin(false, 'Téléchargement impossible (' .. tostring(status) .. ').') end
                say(('Zip reçu (%.1f Mo) : vérification…'):format(#body / 1e6))
                if PB.Zip.Sha256(body, yield) ~= tostring(sha):lower() then return fin(false, "Empreinte SHA-256 différente de celle publiée : rien n'est installé.") end
                local list, err = PB.Zip.Entries(body)
                if not list then return fin(false, err) end
                local files = {}
                for _, e in ipairs(list) do
                    local rel = e.name:match('^%[w%-base%]/(.+)$')
                    if rel and not rel:match('/$') and not rel:find('..', 1, true) and not rel:match('^/') and not PROTECT[rel] and not rel:match('server%.cfg$') then
                        local data, why = PB.Zip.Read(body, e, yield)
                        if not data then return fin(false, why) end
                        files[#files + 1] = { rel = rel, data = data }
                        yield()
                    end
                end
                if #files == 0 then return fin(false, 'Le zip ne contient aucun fichier de [w-base].') end
                local n, failed = 0, {}
                for _, f in ipairs(files) do
                    if writeFile(base .. '/' .. f.rel, f.data) then n = n + 1 else failed[#failed + 1] = f.rel end
                    if n % 25 == 0 then yield() end
                end
                PB.Audit.Log('serveur', 'update.install', by or 'console', L.version, U.Current, nil, { files = n, failed = #failed })
                if #failed > 0 then return fin(false, ('%d fichier(s) installé(s), %d impossible(s) à écrire (droits du dossier ?) : %s. Pas de redémarrage.'):format(n, #failed, table.concat(failed, ', '):sub(1, 300))) end
                say(('Version %s installée : %d fichier(s) remplacé(s). Ta config et ta licence n\'ont pas bougé.'):format(L.version, n), 'ok')
                local secs = math.max(10, math.min(3600, math.floor(tonumber(restartSecs) or 60)))
                if PB.Restart and PB.Restart.Start then
                    local okR, msgR = PB.Restart.Start(secs, 'Mise à jour ' .. L.version)
                    if not okR then say(tostring(msgR), 'err') end
                    if PB.Restart.Supervised and not PB.Restart.Supervised() then say("Aucun superviseur (txAdmin) détecté : relance le serveur toi-même après l'arrêt.", 'err') end
                else ExecuteCommand('quit') end   -- (PB.Restart.Quit gère le droit manquant)
                fin(true, ('Version %s installée (%d fichiers). Redémarrage dans %d s.'):format(L.version, n, secs))
            end)
        end, 'GET', '', { ['Accept'] = 'application/zip' })
    end)
end
-- console (txAdmin) : wupdate [secondes avant le redémarrage, 60 par défaut]
RegisterCommand('wupdate', function(src, args)
    if src ~= 0 and not (PB.Perm.IsOwner and PB.Perm.IsOwner(src)) then return end
    local who = src == 0 and 'console' or (GetPlayerName(src) or ('#' .. src))
    say('Recherche de la mise à jour…')
    U.Install(who, tonumber(args[1]) or 60, function(ok, msg)
        say(tostring(msg), ok and 'ok' or 'err')
        if src ~= 0 and PB.Notify then PB.Notify(ok and 'success' or 'error', 'Mise à jour', tostring(msg)) end
    end)
end, false)

exports('UpdateInfo', function()
    return { current = U.Current, latest = U.Latest and U.Latest.version or nil, available = U.Latest ~= nil and U.Newer(U.Latest.version, U.Current) or false }
end)

PB.Action('updates.check', 'updates.view', function(ctx)
    U.Check()
    ctx.toast = 'Vérification lancée : rouvre l\'onglet dans quelques secondes.'
    ctx.refresh = false
    return true
end, { rate = 6 })

P.Register('updates.install', 'Installer une mise à jour de Shadow Base et redémarrer le serveur', 'panel', true)
PB.Action('updates.install', 'updates.install', function(ctx)
    U.Install(ctx.actor and ctx.actor.name or 'panel', 60, function(ok, msg) if PB.Notify then PB.Notify(ok and 'success' or 'error', 'Mise à jour', tostring(msg)) end end)
    ctx.toast = 'Installation lancée : suis-la dans la console. Le serveur redémarrera tout seul.'
    ctx.refresh = false
    return true
end, { rate = 2 })

local autoForm = PB.Form and PB.Form.Cfg({ ns = 'updates', id = 'auto', title = 'Installation automatique', perm = 'updates.install', cols = 2, fields = {
    { k = 'auto', type = 'toggle', label = 'Installer et redémarrer tout seul à chaque nouvelle version', default = false, hint = 'Coupé : le serveur prévient seulement (console et staff en ligne) ; tu installes avec « wupdate » quand tu veux. Activé : installation, annonce aux joueurs, puis redémarrage.' },
    { k = 'auto_minutes', type = 'number', label = 'Délai avant le redémarrage quand des joueurs sont en ligne (minutes)', default = 5, min = 1, max = 60, hint = 'Sans personne en ligne : 15 secondes.' },
    { k = 'check_minutes', type = 'number', label = 'Vérifier toutes les (minutes)', default = 10, min = 2, max = 360 },
} }) or nil

PB.Module({
    id = 'updates', label = 'Mises à jour', icon = 'download', group = 'Système', order = 960, perm = 'updates.view', hint = 'Nouvelle version de Shadow Base',
    doc = "## Mises à jour\nShadow Base vérifie toutes les 6 heures si une nouvelle version est publiée. Le fichier est **signé** : une fausse mise à jour est refusée.\n\nPour installer : télécharge le zip, arrête le serveur, remplace les dossiers des ressources **sans écraser** `pb_panel/config.lua` ni `pb_panel/license.key`, puis redémarre. Les tables de la base se mettent à jour seules.",
    view = function(ctx)
        return { tabs = { { id = 'main', label = 'Version', icon = 'download', build = function()
            local L = U.Latest
            local avail = L ~= nil and U.Newer(L.version, U.Current)
            local blocks = {
                PB.B.stats({ { label = 'Installée', value = U.Current, icon = 'cpu' }, { label = 'Dernière publiée', value = L and L.version or '—', icon = 'download' },
                    { label = 'Vérifiée', value = U.Checked > 0 and os.date('%d/%m %H:%M', U.Checked) or 'jamais', icon = 'clock' } }),
            }
            if U.Error then blocks[#blocks + 1] = PB.B.notice('warn', U.Error) end
            if PB.Restart and PB.Restart.CanQuit and not PB.Restart.CanQuit() then
                blocks[#blocks + 1] = PB.B.notice('info', ("Conseil : ajoute la ligne « %s » dans server.cfg. Sans elle, le redémarrage après « wupdate » arrête le serveur directement (txAdmin le relance quand même)."):format(PB.Restart.ACE_LINE), 'Redémarrage')
            end
            if avail then
                local d = U.Delta(L)
                if d then
                    blocks[#blocks + 1] = PB.B.notice('info', ('Version %s disponible (%s). Mise à jour rapide : %d fichier(s) à remplacer. Arrête le serveur, extrais le zip dans resources/ en acceptant de remplacer, puis redémarre. Ta licence et ta config ne bougent pas.'):format(L.version, L.date, tonumber(d.files) or 0), L.title)
                    blocks[#blocks + 1] = PB.B.kv('Mise à jour rapide', { { 'Zip', d.url }, { 'Taille', ('%.1f Mo'):format((tonumber(d.size) or 0) / 1e6) }, { 'Fichiers modifiés', tostring(tonumber(d.files) or 0) }, { 'Empreinte SHA-256', d.sha256 }, { 'Patch notes', L.site or '—' } })
                    if (tonumber(d.removed) or 0) > 0 then blocks[#blocks + 1] = PB.B.notice('warn', ('%d ancien(s) fichier(s) à retirer : lance supprimer-anciens-fichiers.bat, extrait avec le zip.'):format(tonumber(d.removed) or 0)) end
                else
                    blocks[#blocks + 1] = PB.B.notice('info', ('Version %s disponible (%s). Télécharge le zip, arrête le serveur, remplace les ressources sans écraser pb_panel/config.lua ni license.key, puis redémarre.'):format(L.version, L.date), L.title)
                    blocks[#blocks + 1] = PB.B.kv('Téléchargement (gratuit)', { { 'Zip', L.download }, { 'Empreinte SHA-256', L.sha256 }, { 'Patch notes', L.site or '—' } })
                end
                local rows = {}
                for i, n in ipairs(type(L.notes) == 'table' and L.notes or {}) do if i <= 60 then rows[#rows + 1] = { n = tostring(n):sub(1, 300) } end end
                if #rows > 0 then blocks[#blocks + 1] = PB.B.table({ id = 'notes', title = 'Nouveautés', columns = { { k = 'n', label = '' } }, rows = rows }) end
            elseif L then
                blocks[#blocks + 1] = PB.B.notice('info', 'Shadow Base est à jour.')
            end
            local acts = { { action = 'updates.check', label = 'Vérifier maintenant', icon = 'refresh' } }
            if avail then acts[#acts + 1] = { action = 'updates.install', label = 'Installer et redémarrer', icon = 'download', confirm = "Installer la version " .. L.version .. " puis redémarrer le serveur (compte à rebours de 60 s) ?" } end
            blocks[#blocks + 1] = PB.B.actions(acts)
            blocks[#blocks + 1] = PB.B.notice('info', 'Ou dans la console txAdmin : wupdate (installe puis redémarre ; wupdate 300 = redémarrage dans 5 minutes).')
            if autoForm then blocks[#blocks + 1] = autoForm(ctx) end
            return blocks
        end } } }
    end,
})
