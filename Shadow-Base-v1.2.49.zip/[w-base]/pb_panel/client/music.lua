-- Musique : boombox en main, CarPlay des véhicules et volume selon la distance. Le serveur tient la liste des musiques (server/game/music.lua) ;
-- ici on place l'objet dans la main, on ouvre l'écran (web/game/music.js) et on dit à la page quoi jouer et à quel volume.
local G = PBG
local sources, stations, boxRange, carRange, volume = {}, {}, 30, 16, 70
local kv = GetResourceKvpInt('pb_music_vol')
local myVol = kv > 0 and (kv - 1) or 100   -- réglage personnel (0..100), mémorisé +1 (0 = jamais réglé)
local ui = nil      -- { mode = 'car' | 'box', veh }
local held = false
local prop = nil
local PROP, ANIM_DICT, ANIM = 'prop_boombox_01', 'move_weapon@jerrycan@generic', 'idle'
local boxPos = { 0.15, 0.0, 0.0, 90.0, 252.5, 0.0 }   -- position dans la main (x, y, z, rotations), réglable en jeu : /boombox_regler
local function placeBox()
    if not prop or not DoesEntityExist(prop) then return end
    local ped = PlayerPedId()
    AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 57005), boxPos[1] + 0.0, boxPos[2] + 0.0, boxPos[3] + 0.0, boxPos[4] + 0.0, boxPos[5] + 0.0, boxPos[6] + 0.0, true, true, false, true, 1, true)
end

local function me() return GetPlayerServerId(PlayerId()) end
local function myKey()
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh ~= 0 then return 'car:' .. NetworkGetNetworkIdFromEntity(veh) end
    if held then return 'box:' .. me() end
end
local function current()
    local k = myKey()
    local s = k and sources[k]
    return s and { kind = s.kind, id = s.id, title = s.title, by = s.by } or nil
end

local function closeUi()
    if not ui then return end
    ui = nil
    SetNuiFocusKeepInput(false)
    G.focus(false)
    G.send('music.close', {})
end
G.onForceClose(closeUi)

local function openUi()
    if ui or not G.begun or G.dead or G.creating or G.wardrobe then return end
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 and not held then
        G.send('notify', { type = 'info', title = 'Musique', text = 'Monte dans un véhicule ou équipe ta boombox.' })
        return
    end
    ui = { mode = veh ~= 0 and 'car' or 'box', veh = veh }
    local label = 'Boombox'
    if veh ~= 0 then
        local n = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(veh)))
        label = (n and n ~= 'NULL') and n or 'CarPlay'
    end
    G.focus(true)
    SetNuiFocusKeepInput(true)   -- on continue à conduire ou marcher, écran ouvert
    G.send('music.open', { mode = ui.mode, label = label, stations = stations, vol = myVol, cur = current() })
    CreateThread(function()
        while ui do
            for _, c in ipairs({ 1, 2, 24, 25, 68, 69, 70, 91, 92, 106, 140, 141, 142, 257, 263, 264, 199, 200, 245 }) do DisableControlAction(0, c, true) end
            local veh2 = GetVehiclePedIsIn(PlayerPedId(), false)
            if (ui.mode == 'car' and veh2 ~= ui.veh) or (ui.mode == 'box' and not held) then closeUi() end
            Wait(0)
        end
    end)
end
RegisterCommand('pb_music', function() if ui then closeUi() else openUi() end end, false)
RegisterKeyMapping('pb_music', 'Musique : CarPlay et boombox', 'keyboard', 'O')

G.nui['music.close'] = function() closeUi() return {} end
G.nui['music.typing'] = function(d) if ui then SetNuiFocusKeepInput(not (d and d.on)) end return {} end
G.nui['music.play'] = function(d)
    d = d or {}
    TriggerServerEvent('pb:g:music:play', tonumber(d.station), d.url and tostring(d.url):sub(1, 300) or nil)
    return {}
end
G.nui['music.stop'] = function() TriggerServerEvent('pb:g:music:stop') return {} end
G.nui['music.holster'] = function() TriggerServerEvent('pb:g:music:holster') return {} end
G.nui['music.vol'] = function(d)
    myVol = math.max(0, math.min(100, math.floor(tonumber(d and d.v) or myVol)))
    SetResourceKvpInt('pb_music_vol', myVol + 1)
    return {}
end

RegisterNetEvent('pb:g:music:list', function(j)
    local d = G.decode(j)
    if not d then return end
    boxRange, carRange, volume = tonumber(d.box_range) or 30, tonumber(d.car_range) or 16, tonumber(d.volume) or 70
    stations = d.stations or {}
    if type(d.box_pos) == 'table' and #d.box_pos == 6 and json.encode(d.box_pos) ~= json.encode(boxPos) then boxPos = d.box_pos placeBox() end
    local by = {}
    for _, s in ipairs(d.sources or {}) do by[s.k] = s end
    sources = by
    if ui then G.send('music.state', { cur = current() }) end
end)

-- Boombox en main ----------------------------------------------------------------------------------------------------------------------
local function dropProp()
    if prop and DoesEntityExist(prop) then DetachEntity(prop, true, false) DeleteEntity(prop) end
    prop = nil
end
local function loadOr(check, req, ms)
    req()
    local t = GetGameTimer() + ms
    while not check() and GetGameTimer() < t do Wait(10) end
    return check()
end
RegisterNetEvent('pb:g:music:box', function(on)
    held = on == true
    local ped = PlayerPedId()
    if not held then
        dropProp()
        StopAnimTask(ped, ANIM_DICT, ANIM, 2.0)
        return
    end
    SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
    local model = joaat(PROP)
    if loadOr(function() return HasModelLoaded(model) end, function() RequestModel(model) end, 3000) then
        local c = GetEntityCoords(ped)
        dropProp()
        prop = CreateObject(model, c.x, c.y, c.z + 0.2, true, true, false)
        placeBox()
        SetModelAsNoLongerNeeded(model)
    end
    loadOr(function() return HasAnimDictLoaded(ANIM_DICT) end, function() RequestAnimDict(ANIM_DICT) end, 3000)
    if G.invClose then G.invClose() end   -- équipée depuis le sac : l'inventaire ne reste pas derrière l'écran
    openUi()
    CreateThread(function()
        while held do
            local p = PlayerPedId()
            if HasAnimDictLoaded(ANIM_DICT) and not IsEntityPlayingAnim(p, ANIM_DICT, ANIM, 3) then TaskPlayAnim(p, ANIM_DICT, ANIM, 4.0, -4.0, -1, 49, 0.0, false, false, false) end
            for _ = 1, 25 do   -- une boombox à la main : pas d'arme ni de coup
                if not held then break end
                DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 37, true) DisableControlAction(0, 140, true)
                Wait(0)
            end
        end
    end)
end)

-- Réglage en direct de la position dans la main (droit « Gérer la musique », boombox en main). Validé par le serveur, appliqué à tout le monde.
local adjusting = false
RegisterCommand('boombox_regler', function() TriggerServerEvent('pb:g:music:adjust') end, false)
RegisterNetEvent('pb:g:music:adjust', function()
    if adjusting or not held or not prop then return end
    adjusting = true
    closeUi()
    local saved = { table.unpack(boxPos) }
    local rotate, nextAt = false, 0
    local function help()
        G.send('hints', { items = { { k = 'R', t = rotate and 'Mode : rotation' or 'Mode : position' }, { k = '← →', t = 'Axe 1' }, { k = '↑ ↓', t = 'Axe 2' }, { k = 'PAGE ↑↓', t = 'Axe 3' }, { k = 'ENTRÉE', t = 'Enregistrer' }, { k = 'RETOUR', t = 'Annuler' } } })
    end
    help()
    CreateThread(function()
        while adjusting and held do
            for _, c in ipairs({ 10, 11, 24, 25, 45, 172, 173, 174, 175, 177, 191, 199, 200 }) do DisableControlAction(0, c, true) end
            if IsDisabledControlJustPressed(0, 45) then rotate = not rotate help() end
            local now = GetGameTimer()
            if now >= nextAt then
                local i, d = nil, 0
                if IsDisabledControlPressed(0, 174) then i, d = 1, -1 elseif IsDisabledControlPressed(0, 175) then i, d = 1, 1
                elseif IsDisabledControlPressed(0, 173) then i, d = 2, -1 elseif IsDisabledControlPressed(0, 172) then i, d = 2, 1
                elseif IsDisabledControlPressed(0, 11) then i, d = 3, -1 elseif IsDisabledControlPressed(0, 10) then i, d = 3, 1 end
                if i then
                    if rotate then boxPos[i + 3] = (boxPos[i + 3] + d * 2.5) % 360 else boxPos[i] = math.floor((boxPos[i] + d * 0.01) * 100 + 0.5) / 100 end
                    placeBox()
                    nextAt = now + 90
                end
            end
            if IsDisabledControlJustPressed(0, 191) then
                TriggerServerEvent('pb:g:music:savepos', boxPos)
                break
            elseif IsDisabledControlJustPressed(0, 177) then
                boxPos = saved
                placeBox()
                break
            end
            Wait(0)
        end
        adjusting = false
        G.send('hints', { items = {} })
    end)
end)

-- Son : qui joue autour de moi, à quel volume ---------------------------------------------------------------------------------------------
local lastSent = ''
CreateThread(function()
    while true do
        Wait(300)
        local list = {}
        if G.begun then
            local ped = PlayerPedId()
            local here = GetEntityCoords(ped)
            local myVeh = GetVehiclePedIsIn(ped, false)
            local near = {}
            for k, s in pairs(sources) do
                local ent, factor = 0, 0.0
                if s.t == 'car' then
                    if NetworkDoesEntityExistWithNetworkId(s.net) then ent = NetToVeh(s.net) end
                    if ent ~= 0 and ent == myVeh then
                        factor = 1.0
                        if GetPlayerRadioStationName() then SetVehRadioStation(ent, 'OFF') end   -- la radio du jeu ne joue pas par-dessus
                    elseif ent ~= 0 and carRange > 0 then
                        factor = math.max(0.0, 1.0 - #(here - GetEntityCoords(ent)) / carRange) * 0.55
                    end
                elseif s.o == me() then
                    factor = 0.9
                else
                    local pl = GetPlayerFromServerId(s.o)
                    if pl and pl ~= -1 then
                        ent = GetPlayerPed(pl)
                        if ent and ent ~= 0 then factor = math.max(0.0, 1.0 - #(here - GetEntityCoords(ent)) / boxRange) end
                    end
                end
                if factor > 0.0 then
                    if myVeh ~= 0 and ent ~= myVeh then factor = factor * 0.5 end   -- vitres fermées : on entend moins le dehors
                    near[#near + 1] = { s = s, k = k, f = factor }
                end
            end
            table.sort(near, function(a, b) return a.f > b.f end)
            for i = 1, math.min(3, #near) do   -- trois musiques à la fois au plus
                local n, s = near[i], near[i].s
                local v = math.floor(volume * (myVol / 100) * n.f / 2 + 0.5) * 2
                list[#list + 1] = { k = n.k, kind = s.kind, id = s.id, url = s.url, at = s.at, start = math.max(0, GetCloudTimeAsInt() - (tonumber(s.at) or 0)) * (s.kind == 'stream' and 0 or 1), vol = v }
            end
        end
        local sig = {}
        for _, e in ipairs(list) do sig[#sig + 1] = e.k .. ':' .. tostring(e.at) .. ':' .. e.vol end
        table.sort(sig)
        local joined = table.concat(sig, '|')
        if joined ~= lastSent then
            lastSent = joined
            G.send('music.sync', { list = list })
        end
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r == GetCurrentResourceName() then dropProp() end
end)
