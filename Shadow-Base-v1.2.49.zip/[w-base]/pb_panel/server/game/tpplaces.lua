-- Menu staff › Téléportation : TP rapides (favoris du staff), lieux posés au Builder, et tous les mappings du serveur.
-- Mappings : les .ymap des ressources démarrées sont lus sur le disque ; chaque fichier indique la zone de ses objets (« entitiesExtents »).
-- Les fichiers proches sont regroupés en un seul lieu. Aucune coordonnée n'est écrite à la main : tout vient des fichiers ou du staff.
local G, DB = PB.G, PB.DB
local T = { lastScan = nil }
G.TpPlaces = T

PB.Migrate('526_tp_places', 'Menu staff : lieux de téléportation', {
    [[CREATE TABLE IF NOT EXISTS pb_tp_places (id INT NOT NULL AUTO_INCREMENT, kind VARCHAR(8) NOT NULL DEFAULT 'fav', skey VARCHAR(120) NOT NULL DEFAULT '', res VARCHAR(64) NOT NULL DEFAULT '',
        label VARCHAR(64) NOT NULL DEFAULT '', x DOUBLE NOT NULL DEFAULT 0, y DOUBLE NOT NULL DEFAULT 0, z DOUBLE NULL, renamed INT NOT NULL DEFAULT 0, hidden INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_kind (kind))]],
})
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, n)) end

-- Décompression (deflate brut), en Lua pur : le serveur n'a pas de zlib ----------------------------------------------------------------------
local LBASE = { 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258 }
local LEXT = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 }
local DBASE = { 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577 }
local DEXT = { 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 }
local ORDER = { 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 }
local MAX_OUT = 32 * 1024 * 1024

local function huff(lens, n)
    local count, offs, symbol = {}, {}, {}
    for i = 0, 15 do count[i] = 0 end
    for i = 0, n - 1 do count[lens[i] or 0] = count[lens[i] or 0] + 1 end
    offs[1] = 0
    for i = 1, 14 do offs[i + 1] = offs[i] + count[i] end
    for i = 0, n - 1 do
        local l = lens[i] or 0
        if l ~= 0 then symbol[offs[l]] = i offs[l] = offs[l] + 1 end
    end
    return { count = count, symbol = symbol }
end
function T.Inflate(s, start)
    local pos, buf, cnt = start or 1, 0, 0
    local out, n = {}, 0
    local byte = string.byte
    local function bits(k)
        while cnt < k do
            local b = byte(s, pos)
            if not b then error('fin de fichier') end
            buf = buf | (b << cnt)
            pos, cnt = pos + 1, cnt + 8
        end
        local v = buf & ((1 << k) - 1)
        buf, cnt = buf >> k, cnt - k
        return v
    end
    local function decode(h)
        local code, first, index = 0, 0, 0
        for len = 1, 15 do
            code = code | bits(1)
            local c = h.count[len]
            if code - c < first then return h.symbol[index + (code - first)] end
            index, first, code = index + c, (first + c) << 1, code << 1
        end
        error('code invalide')
    end
    local fixedL, fixedD
    local last = 0
    while last == 0 do
        last = bits(1)
        local kind = bits(2)
        if kind == 0 then
            buf, cnt = 0, 0
            local a, b = byte(s, pos, pos + 1)
            local len = (a or 0) | ((b or 0) << 8)
            pos = pos + 4
            for i = 0, len - 1 do n = n + 1 out[n] = byte(s, pos + i) end
            pos = pos + len
        elseif kind == 1 or kind == 2 then
            local lc, dc
            if kind == 1 then
                if not fixedL then
                    local l = {}
                    for i = 0, 143 do l[i] = 8 end for i = 144, 255 do l[i] = 9 end for i = 256, 279 do l[i] = 7 end for i = 280, 287 do l[i] = 8 end
                    local d = {}
                    for i = 0, 29 do d[i] = 5 end
                    fixedL, fixedD = huff(l, 288), huff(d, 30)
                end
                lc, dc = fixedL, fixedD
            else
                local nl, nd, nc = bits(5) + 257, bits(5) + 1, bits(4) + 4
                local cl = {}
                for i = 1, nc do cl[ORDER[i]] = bits(3) end
                local ch = huff(cl, 19)
                local l, i = {}, 0
                while i < nl + nd do
                    local sym = decode(ch)
                    if sym < 16 then l[i] = sym i = i + 1
                    else
                        local prev, rep = 0, 0
                        if sym == 16 then prev, rep = l[i - 1] or 0, 3 + bits(2)
                        elseif sym == 17 then rep = 3 + bits(3)
                        else rep = 11 + bits(7) end
                        for _ = 1, rep do l[i] = prev i = i + 1 end
                    end
                end
                local d = {}
                for k = 0, nd - 1 do d[k] = l[nl + k] end
                lc, dc = huff(l, nl), huff(d, nd)
            end
            while true do
                local sym = decode(lc)
                if sym < 256 then n = n + 1 out[n] = sym
                elseif sym == 256 then break
                else
                    sym = sym - 256
                    local len = LBASE[sym] + bits(LEXT[sym])
                    local ds = decode(dc) + 1
                    local dist = DBASE[ds] + bits(DEXT[ds])
                    for _ = 1, len do n = n + 1 out[n] = out[n - dist] end
                end
                if n > MAX_OUT then error('fichier trop gros') end
            end
            if coroutine.isyieldable() then Wait(0) end
        else
            error('bloc invalide')
        end
    end
    return out, n
end

-- Zone des objets d'un .ymap (format RSC7) : { minx, miny, minz, maxx, maxy, maxz } ; nil si illisible ou vide
function T.YmapExtents(raw)
    if type(raw) ~= 'string' or #raw < 32 or raw:sub(1, 4) ~= 'RSC7' then return nil end
    local ok, d, n = pcall(T.Inflate, raw, 17)
    if not ok then return nil end
    local function bytes(o, c) if o + c > n then return nil end return string.char(table.unpack(d, o + 1, o + c)) end
    local function u32(o) local b = bytes(o, 4) return b and string.unpack('<I4', b) or nil end
    local function i16(o) local b = bytes(o, 2) return b and string.unpack('<i2', b) or nil end
    local function ptr(p) if not p or (p >> 28) ~= 5 then return nil end return p & 0x0FFFFFFF end
    local rootIdx, count, blocks = i16(0x1C), i16(0x4C), ptr(u32(0x30))
    if not (rootIdx and count and blocks) or rootIdx < 1 or rootIdx > count then return nil end
    local root = ptr(u32(blocks + (rootIdx - 1) * 16 + 8))
    if not root then return nil end
    local a, b = bytes(root + 64, 12), bytes(root + 80, 12)
    if not (a and b) then return nil end
    local x1, y1, z1 = string.unpack('<fff', a)
    local x2, y2, z2 = string.unpack('<fff', b)
    if not (x1 < x2 + 0.001 and y1 < y2 + 0.001 and math.abs(x1) < 12000 and math.abs(y1) < 12000 and math.abs(x2) < 12000 and math.abs(y2) < 12000) then return nil end
    return { x1, y1, z1, x2, y2, z2 }
end

-- Regroupement ---------------------------------------------------------------------------------------------------------------------------
-- pas des lieux : lumières lointaines, occlusion, versions lointaines, doublons pour la version Enhanced
local function noise(name)
    name = name:lower()
    return name:find('lodlight', 1, true) or name:find('occl', 1, true) or name:find('_long', 1, true) or name:find('_lod', 1, true) or name:find('_strm', 1, true) or name:find('critical', 1, true)
end
local WIDE, NEAR, PER_RES = 600.0, 300.0, 6
local function pretty(res)
    local s = tostring(res):gsub('[_%-]+', ' ')
    return (s:gsub('(%a)([%w\']*)', function(a, b) return a:upper() .. b end))
end
-- files = { { name, ext = extents }, … } -> lieux { key, label, x, y }
function T.Cluster(res, files)
    local groups = {}
    for _, f in ipairs(files) do
        local e = f.ext
        if e and not noise(f.name) and e[4] - e[1] <= WIDE and e[5] - e[2] <= WIDE then
            local cx, cy = (e[1] + e[4]) / 2, (e[2] + e[5]) / 2
            local g
            for _, h in ipairs(groups) do if math.sqrt((h.x / h.n - cx) ^ 2 + (h.y / h.n - cy) ^ 2) <= NEAR then g = h break end end
            if not g then g = { x = 0, y = 0, n = 0, name = f.name } groups[#groups + 1] = g end
            g.x, g.y, g.n = g.x + cx, g.y + cy, g.n + 1
        end
    end
    table.sort(groups, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.name < b.name end)
    local out = {}
    for i, g in ipairs(groups) do
        if i > PER_RES then break end
        out[#out + 1] = { key = (res .. ':' .. g.name):sub(1, 120), label = (#groups > 1 and (pretty(res) .. ' · ' .. g.name:gsub('%.ymap$', '')) or pretty(res)):sub(1, 64), x = g.x / g.n, y = g.y / g.n }
    end
    return out
end

-- Fichiers .ymap sur le disque : FiveM n'a pas de fonction pour lister un dossier, on demande au système
local function listYmaps()
    if not (io and io.popen and GetResourcePath and GetNumResources) then return nil, "ce serveur n'autorise pas la lecture des dossiers" end
    local here = GetResourcePath(GetCurrentResourceName())
    if not here then return nil, 'dossier du serveur introuvable' end
    local norm = function(p) return (tostring(p):gsub('\\', '/')) end
    local root = norm(here):match('^(.*/resources)/')
    if not root or root:find('["%%&|<>;$`]') then return nil, 'dossier du serveur introuvable' end
    local win = package and package.config and package.config:sub(1, 1) == '\\'
    local cmd = win and ('dir /b /s "' .. root:gsub('/', '\\') .. '\\*.ymap" 2>nul') or ('find "' .. root .. '" -type f -iname "*.ymap" 2>/dev/null')
    local ok, h = pcall(io.popen, cmd, 'r')
    if not ok or not h then return nil, "ce serveur n'autorise pas la lecture des dossiers" end
    local paths = {}
    for line in h:lines() do paths[#paths + 1] = norm(line):gsub('%s+$', '') end
    h:close()
    -- chaque fichier est rattaché à sa ressource démarrée
    local byRes = {}
    local roots = {}
    for i = 0, GetNumResources() - 1 do
        local r = GetResourceByFindIndex(i)
        if r and GetResourceState(r) == 'started' then local p = GetResourcePath(r) if p then roots[#roots + 1] = { r, norm(p) .. '/' } end end
    end
    for _, p in ipairs(paths) do
        for _, rr in ipairs(roots) do
            if p:sub(1, #rr[2]):lower() == rr[2]:lower() then
                local rel = p:sub(#rr[2] + 1)
                if not rel:lower():find('enhanced', 1, true) then byRes[rr[1]] = byRes[rr[1]] or {} table.insert(byRes[rr[1]], rel) end
                break
            end
        end
    end
    return byRes
end

-- Recherche complète ; garde les noms donnés et les lieux masqués par le staff
function T.Scan()
    local byRes, why = listYmaps()
    if not byRes then T.lastScan = { ok = false, why = why } return false, why end
    local seen, n = {}, 0
    for res, rels in pairs(byRes) do
        local files = {}
        for _, rel in ipairs(rels) do
            local name = rel:match('[^/]+$') or rel
            if not noise(name) then
                local raw = LoadResourceFile(res, rel)
                if raw and #raw <= 6 * 1024 * 1024 then
                    local ok, ext = pcall(T.YmapExtents, raw)
                    if ok and ext then files[#files + 1] = { name = name, ext = ext } end
                end
                if coroutine.isyieldable() then Wait(0) end
            end
        end
        for _, m in ipairs(T.Cluster(res, files)) do
            seen[m.key] = true
            n = n + 1
            local r = DB.one("SELECT id, renamed FROM pb_tp_places WHERE kind = 'map' AND skey = ?", { m.key })
            if r then
                DB.exec('UPDATE pb_tp_places SET x = ?, y = ?, label = CASE WHEN renamed = 1 THEN label ELSE ? END WHERE id = ?', { m.x, m.y, m.label, r.id })
            else
                DB.insert("INSERT INTO pb_tp_places (kind, skey, res, label, x, y) VALUES ('map', ?, ?, ?, ?, ?)", { m.key, res, m.label, m.x, m.y })
            end
        end
    end
    for _, r in ipairs(DB.q("SELECT id, skey FROM pb_tp_places WHERE kind = 'map'") or {}) do
        if not seen[r.skey] then DB.exec('DELETE FROM pb_tp_places WHERE id = ?', { r.id }) end
    end
    T.lastScan = { ok = true, n = n }
    T.placesAt = nil
    return true, n
end
PB.OnReady(function()
    CreateThread(function()
        Wait(20000)
        local ok, e = pcall(T.Scan)
        if not ok then PB.Err('mappings : ' .. tostring(e)) end
    end)
end)

-- Lieux posés au Builder : les listes de la Carte, rangées par groupe
function T.Places()
    local now = os.time()
    if T.placesAt and now - T.placesAt < 60 then return T.placesCache end
    local groups, order = {}, {}
    local Place = PB.Place
    for _, id in ipairs(Place and Place.order or {}) do
        local t = Place.types[id]
        if t and not t.hidden and t.list then
            local ok, rows = pcall(t.list)
            if ok and type(rows) == 'table' then
                for i, r in ipairs(rows) do
                    if i > 60 then break end
                    if tonumber(r.x) and tonumber(r.y) then
                        local g = t.group or 'Autres'
                        if not groups[g] then groups[g] = {} order[#order + 1] = g end
                        table.insert(groups[g], { id, tostring(r.id), clean(r.label, 48), clean(t.label, 48) })
                    end
                end
            end
        end
    end
    table.sort(order)
    local out = {}
    for _, g in ipairs(order) do out[#out + 1] = { g, groups[g] } end
    T.placesCache, T.placesAt = out, now
    return out
end
function T.Spec()
    local maps, favs = {}, {}
    for _, r in ipairs(DB.q("SELECT id, kind, label, hidden FROM pb_tp_places ORDER BY label") or {}) do
        if r.kind == 'map' then maps[#maps + 1] = { tonumber(r.id), r.label, (tonumber(r.hidden) or 0) ~= 0 }
        else favs[#favs + 1] = { tonumber(r.id), r.label } end
    end
    return { maps = maps, favs = favs, places = T.Places(), scan = T.lastScan }
end

-- Actions du menu staff --------------------------------------------------------------------------------------------------------------------
local S = G.Staff
local function go(src, x, y, z) TriggerClientEvent('pb:g:staff:fx', src, 'tpxy', PB.Json({ x = x + 0.0, y = y + 0.0, z = z and (z + 0.0) or nil })) end
local function rowOf(id) return DB.one('SELECT * FROM pb_tp_places WHERE id = ?', { math.floor(tonumber(id) or 0) }) end

S.Def('tp_saved', 'staff.teleport', { quiet = true, run = function(src, _, p)
    local r = rowOf(p.place)
    if not r then return false, 'Lieu introuvable.' end
    go(src, tonumber(r.x), tonumber(r.y), tonumber(r.z))
    return true
end })
S.Def('tp_place', 'staff.teleport', { quiet = true, run = function(src, _, p)
    local t = PB.Place and PB.Place.types[tostring(p.type or '')]
    if not (t and t.list) then return false, 'Lieu introuvable.' end
    local ok, rows = pcall(t.list)
    for _, r in ipairs(ok and rows or {}) do
        if tostring(r.id) == tostring(p.place) and tonumber(r.x) and tonumber(r.y) then go(src, tonumber(r.x), tonumber(r.y), tonumber(r.z)) return true end
    end
    return false, 'Lieu introuvable.'
end })
S.Def('tp_fav_add', 'staff.teleport', { run = function(src, _, p)
    local name = clean(p.name, 48)
    if #name < 2 then return false, 'Donne un nom à ce lieu.' end
    local c = GetEntityCoords(GetPlayerPed(src))
    if not c then return false, 'Position illisible.' end
    DB.insert("INSERT INTO pb_tp_places (kind, label, x, y, z) VALUES ('fav', ?, ?, ?, ?)", { name, c.x, c.y, c.z })
    return true, name .. ' ajouté aux TP rapides.'
end, log = true })
S.Def('tp_del', 'staff.teleport', { run = function(src, _, p)
    local r = rowOf(p.place)
    if not r or r.kind ~= 'fav' then return false, 'Lieu introuvable.' end
    DB.exec('DELETE FROM pb_tp_places WHERE id = ?', { r.id })
    return true, r.label .. ' retiré des TP rapides.'
end, log = true })
S.Def('tp_rename', 'staff.teleport', { run = function(src, _, p)
    local r = rowOf(p.place)
    local name = clean(p.name, 64)
    if not r then return false, 'Lieu introuvable.' end
    if #name < 2 then return false, 'Nom trop court.' end
    DB.exec('UPDATE pb_tp_places SET label = ?, renamed = 1 WHERE id = ?', { name, r.id })
    return true, 'Renommé : ' .. name .. '.'
end, log = true })
S.Def('tp_hide', 'staff.teleport', { run = function(src, _, p)
    local r = rowOf(p.place)
    if not r or r.kind ~= 'map' then return false, 'Lieu introuvable.' end
    local on = (tonumber(r.hidden) or 0) == 0
    DB.exec('UPDATE pb_tp_places SET hidden = ? WHERE id = ?', { on and 1 or 0, r.id })
    return true, on and (r.label .. ' masqué.') or (r.label .. ' de nouveau affiché.')
end, log = true })
S.Def('tp_scan', 'staff.teleport', { run = function(src)
    CreateThread(function()
        local ok, a = T.Scan()
        G.Notify(src, ok and { type = 'success', title = 'Mappings', text = ('%d mapping(s) trouvé(s).'):format(a) } or { type = 'error', title = 'Mappings', text = 'Recherche impossible : ' .. tostring(a) .. '.' })
    end)
    return true, 'Recherche des mappings lancée…'
end, log = true })
