-- (v1.2.98) Panel mobile : le panel ouvert depuis un téléphone ou un navigateur, sans être en jeu.
-- Adresse : http(s)://<serveur>/pb_panel/ (FiveM sert la ressource). Connexion par un code à 6 chiffres donné en jeu (/panelmobile ou
-- panel › Panel mobile), valable 5 minutes et une seule fois. La session dure 12 h au plus (réglable) et suit tes droits en direct :
-- un staff retiré perd l'accès tout de suite. Les actions sensibles demandent toujours le PIN. Les actions « en jeu » (téléportation…)
-- ne marchent pas depuis le téléphone : elles le disent. Aucune page n'est servie si le panel mobile est coupé.
local P = PB.Perm
local RES = GetCurrentResourceName()
PB.Cfg.Define('webpanel', { enabled = true, hours = 12 })
local function cfg(k, d) return PB.Cfg.Get('webpanel', k, d) end
P.Register('webpanel.use', 'Se connecter au panel mobile (téléphone, navigateur)', 'panel', true)

local codes, sessions = {}, {}   -- code -> { license, name, exp } · token -> { license, name, exp, last, ip }
local fails = {}                  -- ip -> { n, untilT }
local function rnd(n) local t = {} for i = 1, n do t[i] = string.format('%x', math.random(0, 15)) end return table.concat(t) end
local function token() return PB.Sha256 and PB.Sha256(rnd(32) .. tostring(GetGameTimer()) .. tostring(os.clock())):sub(1, 48) or rnd(48) end

local publicIp = nil   -- (v1.3.00) IP publique du serveur, demandée une fois au démarrage
CreateThread(function()
    Wait(5000)
    local ov = GetConvar('sv_listingIPOverride', '')
    if ov:match('^%d+%.%d+%.%d+%.%d+$') then publicIp = ov return end
    -- plusieurs services, au cas où l'un ne répond pas
    for _, u in ipairs({ 'https://api.ipify.org', 'https://ipv4.icanhazip.com', 'https://ifconfig.me/ip', 'https://checkip.amazonaws.com' }) do
        if publicIp then return end
        PerformHttpRequest(u, function(code, body)
            local ip = tostring(body or ''):match('(%d+%.%d+%.%d+%.%d+)')
            if code == 200 and ip and not publicIp then publicIp = ip end
        end, 'GET')
        Wait(3000)
    end
end)
function PB.WebIpKnown() return publicIp ~= nil or GetConvar('web_baseUrl', '') ~= '' end
function PB.WebUrl()
    local base = GetConvar('web_baseUrl', '')
    if base ~= '' then return 'https://' .. base:gsub('^https?://', ''):gsub('/$', '') .. '/' .. RES .. '/' end
    local ep = GetConvar('endpoint_add_tcp', '')
    local port = ep:match(':(%d+)$') or '30120'
    return 'http://' .. (publicIp or '<IP de ton serveur>') .. ':' .. port .. '/' .. RES .. '/'
end

-- code de connexion (en jeu)
local function newCode(src)
    if cfg('enabled', true) == false then return nil, 'Le panel mobile est coupé (panel › Panel mobile).' end
    if not (P.Has(src, 'panel.open') and P.Has(src, 'webpanel.use')) then return nil, "Tu n'as pas le droit d'utiliser le panel mobile." end
    local lic = P.GetLicense(src)
    for c, x in pairs(codes) do if x.license == lic then codes[c] = nil end end
    local c
    repeat c = string.format('%06d', math.random(0, 999999)) until not codes[c]
    codes[c] = { license = lic, name = GetPlayerName(src) or 'Staff', exp = os.time() + 300 }
    PB.Audit.Log('securite', 'webpanel.code', src, lic)
    return c
end
local function sayCode(src)
    local c, e = newCode(src)
    if not c then PB.G.Notify(src, { type = 'error', title = 'Panel mobile', text = e }) return end
    PB.G.Notify(src, { type = 'info', title = 'Panel mobile · code ' .. c, text = ('Ouvre %s sur ton téléphone et tape le code %s (valable 5 min, une seule fois). Ne le donne à personne.'):format(PB.WebUrl(), c), duration = 60000 })
    TriggerClientEvent('chat:addMessage', src, { args = { 'Panel mobile', ('Adresse : %s · code : %s (5 min)'):format(PB.WebUrl(), c) } })
end
-- (v1.3.00) depuis la console (txAdmin › Console, aussi sur téléphone) : panelmobile [licence ou #ID] — sans rien : le propriétaire
local function consoleCode(arg)
    if cfg('enabled', true) == false then return nil, 'Le panel mobile est coupé (panel › Panel mobile).' end
    local lic
    arg = tostring(arg or '')
    if arg:match('^license:%x+$') then lic = arg
    elseif arg:match('^#?%d+$') and PB.G and PB.G.Uid and PB.G.Uid.LicenseOf then lic = PB.G.Uid.LicenseOf(tonumber((arg:gsub('#', ''))))
    else lic = (P.OwnerList and P.OwnerList() or {})[1] end
    if not lic then return nil, "Aucun propriétaire défini dans pb_panel/config.lua : tape panelmobile license:xxxx (ta licence)." end
    if not (P.HasLicense(lic, 'panel.open') and (P.IsOwnerLicense(lic) or P.HasLicense(lic, 'webpanel.use'))) then return nil, "Ce compte n'a pas le droit d'utiliser le panel mobile." end
    for c, x in pairs(codes) do if x.license == lic then codes[c] = nil end end
    local c
    repeat c = string.format('%06d', math.random(0, 999999)) until not codes[c]
    local r = PB.DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ? OR license LIKE ? LIMIT 1', { lic, lic .. '#%' })
    codes[c] = { license = lic, name = r and ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') or 'Propriétaire', exp = os.time() + 300 }
    if codes[c].name == '' then codes[c].name = 'Propriétaire' end
    PB.Audit.Log('securite', 'webpanel.code', 'console', lic)
    return c
end
RegisterCommand('panelmobile', function(src, args)
    if src > 0 then sayCode(src) return end
    local c, e = consoleCode(args[1])
    if not c then print('^1[Panel mobile]^7 ' .. tostring(e)) return end
    print('^2[Panel mobile]^7 Code : ' .. c .. ' (valable 5 min, une seule fois). Adresse à ouvrir sur ton téléphone :')
    print(PB.WebUrl())
    if not PB.WebIpKnown() then print("^3[Panel mobile]^7 IP publique pas encore trouvée : remplace <IP de ton serveur> par l'IP que tu tapes dans FiveM pour te connecter (F8 › connect).") end
end, false)
PB.Action('webpanel.code', 'panel.open', function(ctx)
    if not ctx.src or ctx.src <= 0 then return false, 'Demande le code en jeu (/panelmobile) ou dans la console txAdmin (panelmobile).' end
    local c, e = newCode(ctx.src)
    if not c then return false, e end
    ctx.toast = 'Code : ' .. c .. ' (5 min) · ' .. PB.WebUrl()
    return true, { code = c, url = PB.WebUrl() }
end, { rate = 6 })
PB.Action('webpanel.revoke', 'panel.open', function(ctx)
    local n = 0
    for t, s in pairs(sessions) do if s.license == ctx.license then sessions[t] = nil n = n + 1 end end
    ctx.toast = n .. ' session(s) mobile fermée(s).'
    return true
end)

-- contexte d'une requête du téléphone : droits lus par la licence, jamais ceux de la console
local function webCtx(s)
    local gname = P.GradeOf(s.license)
    local gr = gname and P.Grade(gname)
    local owner = P.IsOwnerLicense(s.license)
    local ctx = { src = -1, web = true, rkey = 'w:' .. s.license, license = s.license, actor = { src = 0, name = s.name .. ' (mobile)', license = s.license },
        grade = gname, gradeLabel = gr and gr.label or gname, level = owner and 1000 or (gr and gr.level or 0) }
    ctx.has = function(perm)
        if PB.License and PB.License.Locked then return owner and (perm == 'panel.open' or tostring(perm):sub(1, 8) == 'license.') end
        return P.HasLicense(s.license, perm)
    end
    return PB.CtxAudit(ctx)
end
local function sessionOf(tok)
    local s = type(tok) == 'string' and sessions[tok]
    if not s then return nil end
    if os.time() > s.exp or os.time() - s.last > 3600 or not (P.HasLicense(s.license, 'panel.open') and P.HasLicense(s.license, 'webpanel.use')) then sessions[tok] = nil return nil end
    s.last = os.time()
    return s
end

-- fichiers servis : la page mobile et ce dont le panel a besoin (rien d'autre)
local TYPES = { html = 'text/html; charset=utf-8', css = 'text/css; charset=utf-8', js = 'application/javascript; charset=utf-8', png = 'image/png', jpg = 'image/jpeg', webp = 'image/webp', svg = 'image/svg+xml', woff2 = 'font/woff2', woff = 'font/woff', ttf = 'font/ttf' }
local function page(res, code, title, text)
    res.writeHead(code, { ['Content-Type'] = 'text/html; charset=utf-8', ['Cache-Control'] = 'no-store' })
    res.send(('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>%s</title><body style="font-family:system-ui;background:#0e1016;color:#e8eaf0;padding:32px"><h2>%s</h2><p>%s</p><p><a style="color:#9cc3ff" href="/%s/">Retour au panel mobile</a></p>'):format(title, title, text, RES))
end
local function serveFile(res, rel)
    rel = tostring(rel or ''):gsub('^/+', '')
    rel = rel:gsub('^' .. RES:gsub('%p', '%%%0') .. '/', '')   -- au cas où le chemin contient encore le nom de la ressource
    if rel == '' or rel == 'index.html' or rel == 'mobile.html' then
        local html = LoadResourceFile(RES, 'web/mobile.html')
        if not html then return page(res, 500, 'Fichier manquant', "web/mobile.html est introuvable dans pb_panel : relance « wupdate » dans la console.") end
        html = html:gsub('{{BASE}}', '/' .. RES .. '/')
        res.writeHead(200, { ['Content-Type'] = TYPES.html, ['Cache-Control'] = 'no-store', ['X-Content-Type-Options'] = 'nosniff', ['Referrer-Policy'] = 'no-referrer' })
        res.send(html)
        return
    end
    local ext = rel:match('%.(%w+)$')
    local okPath = not rel:find('..', 1, true) and rel:match('^[%w_%-%./]+$') and TYPES[ext] and (rel == 'app.css' or rel == 'app.js' or rel:match('^fonts/') or rel:match('^img/'))
    if not okPath then return page(res, 404, 'Page introuvable', 'Cette adresse ne mène nulle part. Ouvre simplement /' .. RES .. '/ (avec la barre à la fin).') end
    local data = LoadResourceFile(RES, 'web/' .. rel)
    if not data then return page(res, 404, 'Fichier introuvable', 'web/' .. rel) end
    res.writeHead(200, { ['Content-Type'] = TYPES[ext], ['Cache-Control'] = 'max-age=3600', ['X-Content-Type-Options'] = 'nosniff', ['Referrer-Policy'] = 'no-referrer' })
    res.send(data)
end
local function json(res, code, t)
    res.writeHead(code, { ['Content-Type'] = 'application/json; charset=utf-8', ['Cache-Control'] = 'no-store', ['X-Content-Type-Options'] = 'nosniff' })
    res.send(PB.Json(t))
end

local function api(req, res, path, body)
    local ip = tostring(req.address or '?'):match('^[^:]+') or '?'
    local d = PB.FromJson(body or '', {}) or {}
    if type(d) ~= 'table' then d = {} end
    if path == 'login' then
        local f = fails[ip]
        if f and f.untilT > os.time() then return json(res, 429, { ok = false, err = ('Trop d\'essais : réessaie dans %d s.'):format(f.untilT - os.time()) }) end
        local c = codes[tostring(d.code or ''):gsub('%D', '')]
        if not c or c.exp < os.time() then
            f = f or { n = 0, untilT = 0 } f.n = f.n + 1
            if f.n >= 5 then f.n, f.untilT = 0, os.time() + 300 end
            fails[ip] = f
            return json(res, 403, { ok = false, err = 'Code invalide ou expiré : demande-en un en jeu avec /panelmobile.' })
        end
        codes[tostring(d.code):gsub('%D', '')] = nil
        fails[ip] = nil
        local t = token()
        sessions[t] = { license = c.license, name = c.name, exp = os.time() + math.max(1, math.min(72, tonumber(cfg('hours', 12)) or 12)) * 3600, last = os.time(), ip = ip }
        PB.Audit.Log('securite', 'webpanel.connexion', { src = 0, name = c.name .. ' (mobile)', license = c.license }, ip)
        return json(res, 200, { ok = true, token = t })
    end
    local s = sessionOf(d.token)
    if not s then return json(res, 401, { ok = false, expired = true, err = 'Session expirée : reconnecte-toi avec un nouveau code.' }) end
    if path == 'open' then
        local ctx = webCtx(s)
        return json(res, 200, { kind = 'opened', id = 0, json = PB.Json({ token = d.token, boot = PB.BuildBoot(ctx) }) })
    elseif path == 'call' then
        local name = tostring(d.name or '')
        if #name > 64 then return json(res, 400, {}) end
        local payload = type(d.json) == 'string' and PB.FromJson(d.json, {}) or {}
        if type(payload) ~= 'table' then payload = {} end
        local r = PB.Dispatch(-1, name, payload, webCtx(s))
        return json(res, 200, { kind = 'res', id = d.id, json = PB.Json(r) })
    elseif path == 'logout' then
        sessions[d.token] = nil
        return json(res, 200, { ok = true })
    end
    return json(res, 404, {})
end

if SetHttpHandler then
    SetHttpHandler(function(req, res)
        if cfg('enabled', true) == false then return page(res, 403, 'Panel mobile coupé', 'Active-le dans le panel › Panel mobile.') end
        local path = tostring(req.path or '/'):gsub('%?.*$', '')
        path = path:gsub('^/' .. RES:gsub('%p', '%%%0') .. '/', '/')
        local apiPath = path:match('/api/(%w+)$')
        if apiPath then
            if req.method ~= 'POST' then return json(res, 405, {}) end
            req.setDataHandler(function(body)
                local ok, e = pcall(api, req, res, apiPath, body)
                if not ok then PB.Warn('panel mobile : ' .. tostring(e)) pcall(json, res, 500, { ok = false, err = 'Erreur interne.' }) end
            end)
            return
        end
        serveFile(res, path)
    end)
end
-- sessions expirées oubliées
CreateThread(function()
    while true do
        Wait(600000)
        local t = os.time()
        for k, s in pairs(sessions) do if t > s.exp or t - s.last > 3600 then sessions[k] = nil end end
        for k, c in pairs(codes) do if c.exp < t then codes[k] = nil end end
    end
end)
PB.WebSessions = function() local n = 0 for _ in pairs(sessions) do n = n + 1 end return n end

local form = PB.Form and PB.Form.Cfg({ ns = 'webpanel', id = 'settings', title = 'Panel mobile', perm = 'security.limits', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Autoriser le panel mobile', default = true, hint = 'Coupé : la page ne répond plus et les sessions en cours ne marchent plus.' },
    { k = 'hours', type = 'number', label = 'Durée maximale d\'une session (heures)', default = 12, min = 1, max = 72 },
} }) or nil
PB.Module({
    id = 'webpanel', label = 'Panel mobile', icon = 'phone', group = 'Système', order = 955, perm = 'panel.open', hint = 'Le panel depuis ton téléphone',
    doc = "## Panel mobile\nOuvre l'adresse affichée sur ton téléphone, puis tape le code à 6 chiffres donné ici ou par **/panelmobile** en jeu. Le code marche 5 minutes et une seule fois. Il faut le droit « Se connecter au panel mobile ».",
    view = function(ctx)
        return { tabs = { { id = 'main', label = 'Panel mobile', icon = 'phone', build = function()
            local blocks = {
                PB.B.kv('Adresse', { { 'Sur ton téléphone', PB.WebUrl() }, { 'Sessions ouvertes', tostring(PB.WebSessions()) } }),
                PB.B.notice('info', "Code à 6 chiffres : bouton ci-dessous ou /panelmobile en jeu. Valable 5 minutes, une seule fois. Si l'adresse commence par http://<IP…>, remplace par l'IP publique de ton serveur (et ouvre le port 30120 en TCP)."),
                PB.B.actions({ { action = 'webpanel.code', label = 'Obtenir un code de connexion', icon = 'key' }, { action = 'webpanel.revoke', label = 'Fermer mes sessions mobiles', icon = 'x' } }),
            }
            if not ctx.has('webpanel.use') then table.insert(blocks, 1, PB.B.notice('warn', "Ton grade n'a pas le droit « Se connecter au panel mobile » (webpanel.use) : demande-le au propriétaire.")) end
            if form and ctx.has('security.limits') then blocks[#blocks + 1] = form(ctx) end
            return blocks
        end } } }
    end,
})
