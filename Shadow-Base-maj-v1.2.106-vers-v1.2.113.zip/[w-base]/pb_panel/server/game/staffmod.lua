-- (v1.2.98) Outils de modération du menu staff (F10) :
--   · Motifs prêts : « Freekill », « HRP », « Metagaming »… chacun avec sa sanction et sa durée, réglables dans le panel.
--   · Comptes liés : chaque connexion note les identifiants du joueur (Rockstar, Steam, Discord, Xbox, FiveM, empreinte du PC, IP chiffrée).
--     Deux comptes qui partagent un identifiant sont « liés ». Un compte lié à un banni par l'empreinte du PC est signalé au staff,
--     et peut être refusé (réglage, coupé par défaut : une famille peut partager un PC).
--   · Liste de surveillance : le staff en service est prévenu quand un joueur surveillé se connecte.
--   · Note des reports : à la clôture, le joueur peut noter l'aide reçue (/noter 1 à 5).
--   · Statistiques du staff : heures de service, reports pris, temps de réponse, sanctions, note moyenne.
--   · Morts récentes en direct, alerte « freekill » (plusieurs victimes en peu de temps), rediffusion des 30 secondes autour d'une mort.
local G, P, DB = PB.G, PB.Perm, PB.DB
local S = G.Staff
if not (S and S.Def and S.ACT) then return end
local function now() return os.time() end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, n or 120)) end
local function baseOf(l) return tostring(l or ''):match('^[^#]+') or '' end
local function lic(src) return P.GetLicense(src) end
local function name(src)
    local i = G.Identity and G.Identity(src)
    local n = i and (((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) or ''
    return n ~= '' and n or (GetPlayerName(src) or ('Joueur ' .. tostring(src)))
end
local function staffOnline(perm)
    local out = {}
    for s in pairs(G.Players()) do if S.OnDuty(s) and P.Has(s, perm or 'staff.players') then out[#out + 1] = s end end
    return out
end
local function alertStaff(title, text, perm)
    for _, s in ipairs(staffOnline(perm)) do G.Notify(s, { type = 'warn', title = title, text = text, duration = 12000 }) end
    if PB.Discord and PB.Discord.Send then pcall(PB.Discord.Send, 'alerts', { title = title, description = text }) end
end

local DEFAULT_MOTIFS = { 'Freekill|ban|1440', 'Freekill (récidive)|ban|10080', 'HRP|warn|0', 'HRP vocal / insultes|mute|60', 'Metagaming|jail|30', 'Powergaming|jail|20',
        'NoFear / NoPain|warn|0', 'Carkill|jail|20', 'Freepunch|warn|0', 'Troll|kick|0', 'Fuite de scène (déco RP)|ban|1440', 'Cheat / menu|ban|0' }
PB.Cfg.Define('staffmod', {
    motifs = DEFAULT_MOTIFS,
    evasion_block = false, freekill_on = true, freekill_kills = 3, freekill_minutes = 10, rate_on = true, replay_on = true,
})
local function cfg(k, d) return PB.Cfg.Get('staffmod', k, d) end

PB.Migrate('580_staffmod', 'Menu staff : comptes liés, surveillance, notes des reports, statistiques, rediffusions', {
    [[CREATE TABLE IF NOT EXISTS pb_idents (license VARCHAR(64) NOT NULL, kind VARCHAR(12) NOT NULL, value VARCHAR(128) NOT NULL, first INT NOT NULL DEFAULT 0, last INT NOT NULL DEFAULT 0,
        PRIMARY KEY (license, kind, value), KEY k_val (kind, value))]],
    [[CREATE TABLE IF NOT EXISTS pb_watch (license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', reason VARCHAR(200) NOT NULL DEFAULT '', by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_report_ratings (report_id INT NOT NULL, license VARCHAR(64) NOT NULL, staff_license VARCHAR(64) NOT NULL DEFAULT '', staff_name VARCHAR(64) NOT NULL DEFAULT '',
        score INT NOT NULL, comment VARCHAR(200) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (report_id), KEY k_staff (staff_license))]],
    [[CREATE TABLE IF NOT EXISTS pb_report_claims (report_id INT NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (report_id), KEY k_lic (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_staff_duty (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', start INT NOT NULL, stop INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_lic (license), KEY k_start (start))]],
    [[CREATE TABLE IF NOT EXISTS pb_kill_replays (kill_id INT NOT NULL, at INT NOT NULL, data MEDIUMTEXT NOT NULL, PRIMARY KEY (kill_id), KEY k_at (at))]],
})

-- Motifs prêts ----------------------------------------------------------------------------------------------------------------------------------
local KIND_LABEL = { warn = 'Avertissement', kick = 'Expulsion', ban = 'Bannissement', jail = 'Prison', mute = 'Mute' }
local function motifs()
    local out = {}
    for _, line in ipairs(cfg('motifs', {}) or {}) do
        local l, k, m = tostring(line):match('^(.-)|(%a+)|(%d+)$')
        if l and KIND_LABEL[k] and l ~= '' then out[#out + 1] = { label = l, kind = k, minutes = tonumber(m) or 0 } end
    end
    return out
end
local function durText(k, m)
    if k == 'warn' or k == 'kick' then return KIND_LABEL[k] end
    if m == 0 then return KIND_LABEL[k] .. (k == 'ban' and ' définitif' or ' (jusqu\'à la levée)') end
    if m >= 1440 and m % 1440 == 0 then return ('%s %d j'):format(KIND_LABEL[k], m // 1440) end
    if m >= 60 and m % 60 == 0 then return ('%s %d h'):format(KIND_LABEL[k], m // 60) end
    return ('%s %d min'):format(KIND_LABEL[k], m)
end
S.Def('motif', 'staff.warn', { target = true, rank = true, quiet = true, run = function(src, t, p)
    local m = motifs()[math.floor(tonumber(p.motif) or 0)]
    if not m then return false, 'Motif inconnu (liste modifiée ?) : rouvre le menu.' end
    local detail = clean(p.detail, 80)
    local reason = m.label .. (detail ~= '' and (' : ' .. detail) or '')
    local q = { id = t, reason = reason }
    if m.kind == 'ban' then q.motif_minutes = m.minutes q.duration = durText('ban', m.minutes) end
    if m.kind == 'jail' then q.minutes = math.max(1, m.minutes) end
    if m.kind == 'mute' then q.minutes = m.minutes end
    return S.Do(src, m.kind, q)
end })

-- Comptes liés ----------------------------------------------------------------------------------------------------------------------------------
local KIND_FR = { license = 'Rockstar', license2 = 'Rockstar (2)', steam = 'Steam', discord = 'Discord', xbl = 'Xbox', live = 'Microsoft', fivem = 'FiveM', ip = 'IP', tok = 'Empreinte du PC' }
local STRONG = { license = true, license2 = true, steam = true, discord = true, xbl = true, live = true, fivem = true, tok = true }
local function ipHash(ip) return (PB.Zip and PB.Zip.Sha256) and PB.Zip.Sha256('wbase-ip|' .. ip):sub(1, 32) or nil end
local function identsNow(src)
    local out = {}
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
        local k, v = tostring(id):match('^(%w+):(.+)$')
        if k == 'ip' then local h = ipHash(v) if h then out[#out + 1] = { 'ip', h } end
        elseif k and KIND_FR[k] then out[#out + 1] = { k, v:sub(1, 128) } end
    end
    if GetNumPlayerTokens and GetPlayerToken then
        for i = 0, math.min(15, (GetNumPlayerTokens(src) or 0) - 1) do local tk = GetPlayerToken(src, i) if tk and tk ~= '' then out[#out + 1] = { 'tok', tostring(tk):sub(1, 128) } end end
    end
    return out
end
local function recordIdents(src)
    local l = lic(src)
    if not l then return end
    local t = now()
    for _, x in ipairs(identsNow(src)) do
        DB.exec('INSERT INTO pb_idents (license, kind, value, first, last) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE last = ?', { l, x[1], x[2], t, t, t })
    end
end
-- comptes qui partagent un identifiant avec ce compte : { license -> { kinds = { kind = true }, strong = bool } }
local function linksOf(license, list)
    local mine = list
    if not mine then
        mine = {}
        for _, r in ipairs(DB.q('SELECT kind, value FROM pb_idents WHERE license = ? LIMIT 80', { license }) or {}) do mine[#mine + 1] = { r.kind, r.value } end
    end
    local out = {}
    for _, x in ipairs(mine) do
        if x[1] ~= 'license' then
            for _, r in ipairs(DB.q('SELECT license FROM pb_idents WHERE kind = ? AND value = ? AND license <> ? LIMIT 20', { x[1], x[2], license }) or {}) do
                local o = out[r.license] or { kinds = {}, strong = false }
                o.kinds[x[1]] = true
                if STRONG[x[1]] then o.strong = true end
                out[r.license] = o
            end
        end
    end
    return out
end
G.LinkedAccounts = linksOf
local function activeBan(license)
    return DB.one("SELECT id, reason, expires, by_name FROM pb_sanctions WHERE (license = ? OR license LIKE ?) AND kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) ORDER BY id DESC LIMIT 1", { license, baseOf(license) .. '#%', now() })
end
-- connexion : compte lié à un banni par l'empreinte du PC (les autres identifiants sont déjà vérifiés par S.BanOf)
local origBanOf = S.BanOf
function S.BanOf(src)
    local b = origBanOf(src)
    if b then return b end
    local l = lic(src)
    if not l then return nil end
    local ok, links = pcall(linksOf, l, identsNow(src))
    if not ok then return nil end
    for other, o in pairs(links) do
        if o.kinds.tok or o.kinds.steam or o.kinds.discord then
            local ban = activeBan(other)
            if ban then
                local kinds = {}
                for k in pairs(o.kinds) do kinds[#kinds + 1] = KIND_FR[k] or k end
                local who = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ? LIMIT 1', { other })
                local n = who and ((who.firstname or '') .. ' ' .. (who.lastname or '')) or other
                SetTimeout(0, function() alertStaff('Contournement de ban ?', ('%s se connecte avec un compte lié à %s, banni (ban n°%s : %s). Points communs : %s.'):format(GetPlayerName(src) or l, n, tostring(ban.id), tostring(ban.reason), table.concat(kinds, ', '))) end)
                if cfg('evasion_block', false) == true then
                    return { id = ban.id, reason = 'Compte lié à un compte banni (' .. tostring(ban.reason) .. ')', expires = ban.expires, by_name = ban.by_name }
                end
                return nil
            end
        end
    end
    return nil
end

-- Liste de surveillance -------------------------------------------------------------------------------------------------------------------------
local watched = {}   -- license -> { reason, by }
CreateThread(function()
    while not PB.IsReady do Wait(500) end
    for _, r in ipairs(DB.q('SELECT license, reason, by_name FROM pb_watch') or {}) do watched[r.license] = { reason = r.reason, by = r.by_name } end
end)
S.Def('watch', 'staff.warn', { target = true, rank = true, run = function(src, t, p)
    local l = G.Get(t).license
    if watched[l] then
        watched[l] = nil
        DB.exec('DELETE FROM pb_watch WHERE license = ?', { l })
        return true, name(t) .. " n'est plus surveillé."
    end
    local r = clean(p.reason, 200)
    if r == '' then return false, 'Motif obligatoire.' end
    watched[l] = { reason = r, by = PB.Actor(src).name }
    DB.exec('REPLACE INTO pb_watch (license, name, reason, by_name, at) VALUES (?, ?, ?, ?, ?)', { l, name(t):sub(1, 64), r, PB.Actor(src).name:sub(1, 64), now() })
    return true, name(t) .. ' est surveillé : le staff en service sera prévenu à chaque connexion.'
end, log = true })
S.Def('watch_del', 'staff.warn', { run = function(src, _, p)
    local l = tostring(p.license or '')
    if not watched[l] then return false, "Ce joueur n'est pas surveillé." end
    watched[l] = nil
    DB.exec('DELETE FROM pb_watch WHERE license = ?', { l })
    return true, 'Retiré de la liste de surveillance.'
end, log = true })

table.insert(G.beginHooks, function(src)
    SetTimeout(3000, function()
        if not G.Get(src) then return end
        pcall(recordIdents, src)
        local p = G.Get(src)
        local w = p and watched[p.license]
        if w then alertStaff('Joueur surveillé connecté', ('%s (%s) : %s · ajouté par %s'):format(name(src), G.Tag and G.Tag(src) or ('#' .. src), w.reason, w.by)) end
    end)
end)

-- Note des reports -------------------------------------------------------------------------------------------------------------------------------
local pendingRate = {}   -- license -> { rid, until }
AddEventHandler('pb_panel:reportClosed', function(rid)
    if cfg('rate_on', true) == false then return end
    local r = DB.one('SELECT id, license FROM pb_reports WHERE id = ?', { tonumber(rid) or 0 })
    if not r then return end
    local c = DB.one('SELECT license FROM pb_report_claims WHERE report_id = ?', { r.id })
    if not c then return end   -- personne ne l'a pris : rien à noter
    pendingRate[r.license] = { rid = r.id, til = now() + 900 }
    for s, pl in pairs(G.Players()) do
        if pl.license == r.license then G.Notify(s, { type = 'info', title = 'Report #' .. r.id .. ' clos', text = "Note l'aide du staff : /noter 1 à 5 (et un commentaire si tu veux). Ex. /noter 5 merci !", duration = 15000 }) end
    end
end)
RegisterCommand('noter', function(src, args)
    if src == 0 then return end
    local p = G.Get(src)
    if not p then return end
    local pend = pendingRate[p.license]
    if not pend or pend.til < now() then G.Notify(src, { type = 'info', title = 'Noter le staff', text = "Aucun report récent à noter." }) return end
    local n = math.floor(tonumber(args[1]) or 0)
    if n < 1 or n > 5 then G.Notify(src, { type = 'info', title = 'Noter le staff', text = 'Écris /noter puis une note de 1 à 5.' }) return end
    local c = DB.one('SELECT license, name FROM pb_report_claims WHERE report_id = ?', { pend.rid })
    DB.exec('REPLACE INTO pb_report_ratings (report_id, license, staff_license, staff_name, score, comment, at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        { pend.rid, p.license, c and c.license or '', c and c.name or '', n, clean(table.concat(args, ' ', 2), 200), now() })
    pendingRate[p.license] = nil
    G.Notify(src, { type = 'success', title = 'Merci !', text = ('Note %d/5 enregistrée pour le report #%d.'):format(n, pend.rid) })
end, false)

-- Statistiques : heures de service et reports pris ----------------------------------------------------------------------------------------------
local dutyRow = {}   -- src -> id de la ligne pb_staff_duty en cours
local function dutyStart(src)
    if dutyRow[src] then return end
    local l = lic(src)
    if l then dutyRow[src] = DB.insert('INSERT INTO pb_staff_duty (license, name, start) VALUES (?, ?, ?)', { l, PB.Actor(src).name:sub(1, 64), now() }) end
end
local function dutyStop(src)
    local id = dutyRow[src]
    dutyRow[src] = nil
    if id then DB.exec('UPDATE pb_staff_duty SET stop = ? WHERE id = ?', { now(), id }) end
end
do
    local a = S.ACT.duty
    local run = a.run
    a.run = function(src, t, p)
        local ok, msg = run(src, t, p)
        if ok ~= false then if S.OnDuty(src) then dutyStart(src) else dutyStop(src) end end
        return ok, msg
    end
    local c = S.ACT.report_claim
    if c then
        local crun = c.run
        c.run = function(src, t, p)
            local ok, msg = crun(src, t, p)
            if ok then
                local rid = math.floor(tonumber(p and p.rid) or 0)
                if rid > 0 and lic(src) then DB.exec('INSERT IGNORE INTO pb_report_claims (report_id, license, name, at) VALUES (?, ?, ?, ?)', { rid, lic(src), PB.Actor(src).name:sub(1, 64), now() }) end
            end
            return ok, msg
        end
    end
end
AddEventHandler('playerDropped', function() local src = source dutyStop(src) end)
-- au démarrage : les services restés ouverts (arrêt brutal) sont fermés à leur dernière minute connue
CreateThread(function() while not PB.IsReady do Wait(500) end DB.exec('UPDATE pb_staff_duty SET stop = start WHERE stop = 0') end)

local function staffStats(days)
    local since = now() - days * 86400
    local by = {}
    local function row(l, n) local r = by[l] or { license = l, name = n or l, secs = 0, claims = 0, resp = 0, respN = 0, sanc = 0, rate = 0, rateN = 0 } if n and n ~= '' then r.name = n end by[l] = r return r end
    for _, d in ipairs(DB.q('SELECT license, name, start, stop FROM pb_staff_duty WHERE start > ? OR stop = 0 OR stop > ?', { since, since }) or {}) do
        local a, b = math.max(tonumber(d.start) or 0, since), (tonumber(d.stop) or 0) > 0 and tonumber(d.stop) or now()
        if b > a then local r = row(d.license, d.name) r.secs = r.secs + (b - a) end
    end
    for _, c in ipairs(DB.q('SELECT c.license, c.name, c.at, r.created FROM pb_report_claims c LEFT JOIN pb_reports r ON r.id = c.report_id WHERE c.at > ?', { since }) or {}) do
        local r = row(c.license, c.name)
        r.claims = r.claims + 1
        local w = (tonumber(c.at) or 0) - (tonumber(c.created) or 0)
        if tonumber(c.created) and w >= 0 and w < 86400 then r.resp = r.resp + w r.respN = r.respN + 1 end
    end
    for _, s in ipairs(DB.q("SELECT by_license, by_name, COUNT(*) AS n FROM pb_sanctions WHERE created > ? AND by_license <> '' GROUP BY by_license, by_name", { since }) or {}) do
        local r = row(s.by_license, s.by_name) r.sanc = r.sanc + (tonumber(s.n) or 0)
    end
    for _, x in ipairs(DB.q("SELECT staff_license, staff_name, score FROM pb_report_ratings WHERE at > ? AND staff_license <> ''", { since }) or {}) do
        local r = row(x.staff_license, x.staff_name) r.rate = r.rate + (tonumber(x.score) or 0) r.rateN = r.rateN + 1
    end
    local out = {}
    for _, r in pairs(by) do out[#out + 1] = r end
    table.sort(out, function(a, b) return a.secs > b.secs end)
    return out
end
G.StaffStats = staffStats
local function hm(secs) secs = math.floor(secs or 0) return ('%d h %02d'):format(secs // 3600, (secs % 3600) // 60) end
local function fmtStat(r)
    return { name = r.name, hours = hm(r.secs), claims = r.claims, resp = r.respN > 0 and (math.floor(r.resp / r.respN / 60 * 10 + 0.5) / 10 .. ' min') or '—', sanc = r.sanc,
        rate = r.rateN > 0 and (('%.1f / 5 (%d)'):format(r.rate / r.rateN, r.rateN)) or '—' }
end

-- Morts : alerte freekill, rediffusion ---------------------------------------------------------------------------------------------------------
local trail = {}   -- src -> liste de { t (ms), x, y, z, h, w, v, d }
local STEP, KEEP = 500, 70   -- un relevé toutes les 0,5 s, 35 s gardées
CreateThread(function()
    while true do
        Wait(STEP)
        local ok, err = pcall(function()
            if cfg('replay_on', true) == false then return end
            local t = GetGameTimer()
            for src in pairs(G.Players()) do
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 and DoesEntityExist(ped) then
                    local c = GetEntityCoords(ped)
                    local tr = trail[src] or {}
                    tr[#tr + 1] = { t = t, x = math.floor(c.x * 10) / 10, y = math.floor(c.y * 10) / 10, z = math.floor(c.z * 10) / 10, h = math.floor(GetEntityHeading(ped)),
                        w = GetSelectedPedWeapon and GetSelectedPedWeapon(ped) or 0, v = (GetVehiclePedIsIn(ped, false) or 0) ~= 0 or nil, d = (GetEntityHealth(ped) or 200) <= 101 or nil }
                    if #tr > KEEP then table.remove(tr, 1) end
                    trail[src] = tr
                end
            end
        end)
        if not ok then   -- une seule fois : on arrête les relevés plutôt que remplir la console
            PB.Warn('staffmod', 'rediffusions coupées (relevés impossibles) : ' .. tostring(err))
            trail = {}
            while true do Wait(600000) end
        end
    end
end)
AddEventHandler('playerDropped', function() trail[source] = nil end)

local recentKillsBy = {}   -- licence du tueur -> { at, ... }
AddEventHandler('pb_panel:kill', function(row)
    if type(row) ~= 'table' then return end
    -- alerte freekill : N victimes en M minutes (policiers en service exclus)
    if row.ksrc and cfg('freekill_on', true) ~= false then
        local j = G.Biz and G.Biz.Job and G.Biz.Job(row.ksrc)
        if not (j and j.onDuty and j.kind == 'police') and not S.OnDuty(row.ksrc) then
            local win = math.max(1, tonumber(cfg('freekill_minutes', 10)) or 10) * 60
            local list = recentKillsBy[row.killer] or {}
            local keep = {}
            for _, at in ipairs(list) do if row.at - at < win then keep[#keep + 1] = at end end
            keep[#keep + 1] = row.at
            recentKillsBy[row.killer] = keep
            local n = math.max(2, tonumber(cfg('freekill_kills', 3)) or 3)
            if #keep >= n then
                alertStaff('Freekill possible', ('%s (%s) a tué %d personnes en %d min (dernière : %s, %s, %d m). À vérifier : F10 › Modération › Morts récentes.'):format(row.killerName, G.Tag and G.Tag(row.ksrc) or '', #keep, win // 60, row.victimName, row.weapon, row.dist or 0))
                recentKillsBy[row.killer] = {}
            end
        end
    end
    -- rediffusion : on attend 3 s pour garder aussi la suite, puis on garde les joueurs à moins de 150 m
    if cfg('replay_on', true) == false or not row.id then return end
    local tKill = GetGameTimer()
    SetTimeout(3000, function()
        local ok, err = pcall(function()
            local actors = {}
            for src, tr in pairs(trail) do
                local near = src == row.vsrc or src == row.ksrc
                if not near then
                    for i = #tr, 1, -1 do
                        local s = tr[i]
                        if math.abs(s.t - tKill) <= 1000 then near = ((s.x - row.x) ^ 2 + (s.y - row.y) ^ 2) < 150 * 150 break end
                    end
                end
                if near then
                    local pts = {}
                    for _, s in ipairs(tr) do
                        if s.t >= tKill - 30000 and s.t <= tKill + 3000 then
                            pts[#pts + 1] = { math.floor((s.t - tKill) / 100), s.x, s.y, s.z, s.h, s.w ~= 0 and (G.Kills and G.Kills.WeaponName(s.w)) or nil, s.v and 1 or nil, s.d and 1 or nil }
                        end
                    end
                    if #pts > 0 then
                        actors[#actors + 1] = { n = name(src), u = G.UidOf and G.UidOf(src) or src, role = src == row.ksrc and 'killer' or (src == row.vsrc and 'victim' or nil), p = pts }
                    end
                end
            end
            if #actors == 0 then return end
            DB.exec('REPLACE INTO pb_kill_replays (kill_id, at, data) VALUES (?, ?, ?)', { row.id, row.at, PB.Json({ kill = { x = row.x, y = row.y, z = row.z, weapon = row.weapon, dist = row.dist, killer = row.killerName, victim = row.victimName, at = row.at }, actors = actors }) })
        end)
        if not ok then PB.Warn('staffmod', 'rediffusion : ' .. tostring(err)) end
    end)
end)
CreateThread(function()
    while true do
        Wait(3600000)
        local ok, err = pcall(function()
            local d = tonumber(PB.Cfg.Get('kills', 'keep_days', 30)) or 30
            DB.exec('DELETE FROM pb_kill_replays WHERE at < ?', { now() - math.min(d, 14) * 86400 })   -- 14 jours au plus : c'est lourd
        end)
        if not ok then PB.Warn('staffmod', 'nettoyage : ' .. tostring(err)) end
    end
end)

S.Def('kill_replay', 'kills.view', { quiet = true, run = function(src, _, p)
    local r = DB.one('SELECT data FROM pb_kill_replays WHERE kill_id = ?', { math.floor(tonumber(p.kid) or 0) })
    if not r then return false, "Pas de rediffusion pour cette mort (trop ancienne, ou aucun joueur autour)." end
    TriggerClientEvent('pb:g:staff:replay', src, r.data)
    return true
end })
S.Def('kill_goto', 'staff.teleport', { quiet = true, run = function(src, _, p)
    local k = DB.one('SELECT x, y, z FROM pb_kills WHERE id = ?', { math.floor(tonumber(p.kid) or 0) })
    if not k then return false, 'Mort introuvable.' end
    TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = k.x, y = k.y, z = k.z }))
    return true
end, log = true })

-- Comptes liés d'un joueur (connecté ou non)
S.Def('p_links', 'staff.players', { quiet = true, run = function(src, _, p)
    local license = tostring(p.license or '')
    if not license:match('^license:%x+') and tonumber(p.id) then local pl = G.Get(tonumber(p.id)) license = pl and pl.license or '' end
    license = baseOf(license)
    if license == '' then return false, 'Joueur introuvable.' end
    local rows = {}
    for other, o in pairs(linksOf(license)) do
        local who = DB.one('SELECT firstname, lastname, last_seen FROM pb_players WHERE license = ? OR license LIKE ? ORDER BY last_seen DESC LIMIT 1', { other, other .. '#%' })
        local kinds = {}
        for k in pairs(o.kinds) do kinds[#kinds + 1] = KIND_FR[k] or k end
        table.sort(kinds)
        local ban = activeBan(other)
        rows[#rows + 1] = { license = other, name = who and (((who.firstname or '') .. ' ' .. (who.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) or 'Sans personnage', seen = who and tonumber(who.last_seen) or 0,
            kinds = table.concat(kinds, ', '), strong = o.strong or nil, banned = ban and (ban.reason or 'oui') or nil, watched = watched[other] and watched[other].reason or nil }
    end
    table.sort(rows, function(a, b) if (a.banned ~= nil) ~= (b.banned ~= nil) then return a.banned ~= nil end return (a.seen or 0) > (b.seen or 0) end)
    TriggerClientEvent('pb:g:staff:links', src, PB.Json({ license = license, rows = rows }))
    return true
end })

-- Menu F10 : catégorie « Modération » et données de la fiche joueur
do
    local at = #S.CATS + 1
    for i, c in ipairs(S.CATS) do if c.id == 'sanctions' then at = i + 1 break end end
    table.insert(S.CATS, at, { id = 'mod', label = 'Modération', icon = 'eye', perm = 'staff.players' })
end
local statsCache
table.insert(S.SpecExtra, function(src, spec)
    local ms = motifs()
    local can = {}
    for i, m in ipairs(ms) do
        local perm = S.ACT[m.kind] and S.ACT[m.kind].perm
        if perm and P.Has(src, perm) then can[#can + 1] = { i = i, label = m.label, kind = m.kind, dur = durText(m.kind, m.minutes) } end
    end
    spec.motifs = can
    if not P.Has(src, 'staff.players') then return end
    for _, pl in ipairs(spec.players or {}) do
        local g = G.Get(pl.id)
        local w = g and watched[g.license]
        if w then pl.watch = w.reason end
    end
    local kills = {}
    for _, r in ipairs(DB.q('SELECT k.id, k.at, k.victim, k.victim_name, k.killer, k.killer_name, k.weapon, k.dist, (SELECT 1 FROM pb_kill_replays x WHERE x.kill_id = k.id) AS rp FROM pb_kills k ORDER BY k.id DESC LIMIT 30') or {}) do
        kills[#kills + 1] = { id = r.id, at = tonumber(r.at) or 0, v = r.victim_name, vl = r.victim, k = r.killer_name ~= '' and r.killer_name or nil, kl = r.killer ~= '' and r.killer or nil, w = r.weapon, d = tonumber(r.dist) or 0, rp = r.rp and true or nil }
    end
    local wl, names = {}, {}
    if next(watched) then for _, r in ipairs(DB.q('SELECT license, name FROM pb_watch') or {}) do names[r.license] = r.name end end   -- (patch 311) une requête au lieu d'une par joueur suivi
    for l, w in pairs(watched) do
        local on
        for s, pl in pairs(G.Players()) do if pl.license == l then on = s end end
        wl[#wl + 1] = { license = l, name = names[l] or l, reason = w.reason, by = w.by, online = on }
    end
    table.sort(wl, function(a, b) return (a.online and 1 or 0) > (b.online and 1 or 0) end)
    local st = {}
    if not statsCache or now() - statsCache.at > 60 then statsCache = { at = now(), rows = staffStats(7) } end
    for i, r in ipairs(statsCache.rows) do if i <= 15 then local f = fmtStat(r) f.me = r.license == lic(src) or nil st[#st + 1] = f end end
    spec.mod = { kills = kills, watch = wl, stats = st, replay = P.Has(src, 'kills.view') or nil, now = now() }
end)

-- Panel : réglages et statistiques
local form = PB.Form.Cfg({ ns = 'staffmod', id = 'settings', title = 'Modération', perm = 'staff.edit', cols = 2, fields = {
    { k = 'motifs', type = 'list', label = 'Motifs prêts (libellé|sanction|minutes) — sanctions : warn, kick, ban, jail, mute ; 0 = définitif', default = DEFAULT_MOTIFS, maxitems = 30, maxlen = 80, pattern = '^[^|]+|%a+|%d+$', wide = true },
    { k = 'evasion_block', type = 'toggle', label = "Refuser un compte lié à un banni (même PC, Steam ou Discord)", default = false, hint = "Coupé : le staff est seulement prévenu. Attention, une famille peut partager un PC." },
    { k = 'freekill_on', type = 'toggle', label = 'Alerte freekill', default = true },
    { k = 'freekill_kills', type = 'number', label = 'Alerte à partir de … victimes', default = 3, min = 2, max = 20 },
    { k = 'freekill_minutes', type = 'number', label = '… en (minutes)', default = 10, min = 1, max = 120 },
    { k = 'rate_on', type = 'toggle', label = 'Proposer au joueur de noter son report (/noter)', default = true },
    { k = 'replay_on', type = 'toggle', label = 'Enregistrer les rediffusions des morts (30 s)', default = true },
} })
G.StaffModForm = form
PB.Module({
    id = 'staffstats', label = 'Statistiques du staff', icon = 'chart', group = 'Serveur', order = 99, perm = 'staff.edit', hint = 'Heures, reports, sanctions, notes',
    doc = "## Statistiques du staff\nHeures de service, reports pris (et le temps avant de les prendre), sanctions données, note moyenne laissée par les joueurs (/noter).",
    view = function(ctx)
        local function tab(days, id, label)
            return { id = id, label = label, icon = 'chart', build = function()
                local rows = {}
                for _, r in ipairs(staffStats(days)) do rows[#rows + 1] = fmtStat(r) end
                return { PB.B.table({ id = 'st' .. id, title = label, search = true, columns = { { k = 'name', label = 'Staff' }, { k = 'hours', label = 'En service' }, { k = 'claims', label = 'Reports pris', type = 'num' },
                    { k = 'resp', label = 'Temps de réponse moyen' }, { k = 'sanc', label = 'Sanctions', type = 'num' }, { k = 'rate', label = 'Note des joueurs' } }, rows = rows, empty = 'Aucune activité du staff sur cette période.' }) }
            end }
        end
        return { tabs = { tab(7, 'w', '7 derniers jours'), tab(30, 'm', '30 derniers jours'), { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end } } }
    end,
})
