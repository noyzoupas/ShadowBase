-- (v1.2.97) Menu staff › un joueur › Historique complet : tout ce qui concerne un joueur, sur une seule page, du plus récent au plus ancien.
--   · sanctions (avertissements, expulsions, bannissements, mutes, prison staff), levées comprises
--   · reports qu'il a envoyés (et qui les a pris)
--   · notes privées du staff
--   · amendes et peines de la police (journal de la justice)
--   · expulsions automatiques (anti-triche, ping, AFK…)
--   · actions du staff sur lui : retours en arrière d'inventaire, argent, objets, téléportations, soins, register, wipe, mort RP…
-- Connecté ou non : le dossier d'un joueur hors ligne a le même bouton. Lecture seule, droit « staff.players ».
local G, DB, P = PB.G, PB.DB, PB.Perm
local S = G.Staff
if not (S and S.Def) then return end

local function baseOf(l) return tostring(l or ''):match('^[^#]+') or '' end
local function validLicense(l) return tostring(l or ''):match('^license:%x+#?%d*$') end
local function fullName(r)
    local n = ((r and r.firstname or '') .. ' ' .. (r and r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    return n ~= '' and n or 'Sans personnage'
end
local function short(s, n) s = tostring(s or ''):gsub('[%c]', ' ') if #s > n then s = s:sub(1, n - 1) .. '…' end return s end

-- date du journal d'audit : oxmysql la rend en millisecondes, d'autres pilotes en texte
local function stamp(v)
    local n = tonumber(v)
    if n then return n > 1e11 and math.floor(n / 1000) or n end
    local y, mo, d, h, mi, se = tostring(v or ''):match('^(%d+)-(%d+)-(%d+)[ T](%d+):(%d+):(%d+)')
    if y then return os.time({ year = tonumber(y), month = tonumber(mo), day = tonumber(d), hour = tonumber(h), min = tonumber(mi), sec = tonumber(se) }) end
    return 0
end
local SANC = { warn = 'Avertissement', kick = 'Expulsion', ban = 'Bannissement', mute = 'Mute', jail = 'Prison (staff)', unban = 'Débannissement' }
local ACT = {   -- actions du staff : libellé lisible (les autres gardent leur identifiant ; false = déjà montré par une autre source)
    rollback = "Retour en arrière d'inventaire", rollback_do = "Retour en arrière d'inventaire", register = 'Register (personnage recréé)', wipe = 'Wipe du personnage',
    mortrp = 'Mort RP', cash = 'Espèces données / retirées', bank = 'Banque créditée / débitée', item = 'Objet donné', weapon = 'Arme donnée', give_vehicle = 'Véhicule donné',
    off_money = 'Argent (hors ligne)', ['goto'] = 'Téléportation vers lui', bring = 'Téléporté vers le staff', tp_player = 'Téléporté', revive = 'Réanimé', heal = 'Soigné',
    armor = 'Armure donnée', feed = 'Nourri', freeze = 'Gelé / dégelé', kill = 'Tué par le staff', slap = 'Claque du staff', uncuff = 'Démenotté', leave_veh = 'Sorti du véhicule',
    spectate = 'Observé', job = 'Emploi changé', gang = 'Gang changé', inv_view = 'Inventaire consulté', inv_clear = 'Inventaire vidé', newbie_clear = 'Protection nouveau levée',
    whisper = 'Message chuchoté', dm = 'Message privé du staff',
    warn = false, kick = false, ban = false, ban_offline = false, off_warn = false, off_jail = false, jail = false, mute = false, unban = false, note = false, off_note = false, history = false, p_timeline = false,
}

local function timeline(license)
    local base = baseOf(license)
    local r = DB.one('SELECT license, firstname, lastname FROM pb_players WHERE license = ?', { license })
    if not r then return nil end
    local uid = G.Uid and G.Uid.OfLicense and G.Uid.OfLicense(base)
    local out, count = {}, { sanctions = 0, reports = 0, notes = 0, police = 0, staff = 0, auto = 0 }
    local function add(at, cat, title, text, by, tone)
        out[#out + 1] = { at = tonumber(at) or 0, cat = cat, title = title, text = text ~= '' and text or nil, by = (by and by ~= '') and by or nil, tone = tone }
        count[cat] = (count[cat] or 0) + 1
    end
    local like = base .. '%'

    for _, s in ipairs(DB.q('SELECT kind, reason, by_name, created, expires, revoked, revoked_by FROM pb_sanctions WHERE license = ? OR license LIKE ? ORDER BY id DESC LIMIT 80', { license, like }) or {}) do
        local t = SANC[s.kind] or tostring(s.kind)
        local exp = tonumber(s.expires) or 0
        if s.kind == 'ban' then t = t .. (exp == 0 and ' définitif' or (" jusqu'au " .. os.date('%d/%m/%Y %H:%M', exp))) end
        if PB.ToBool(s.revoked) then t = t .. ' · levé' .. ((s.revoked_by or '') ~= '' and (' par ' .. s.revoked_by) or '') end
        add(s.created, 'sanctions', t, short(s.reason, 200), s.by_name, (s.kind == 'ban' or s.kind == 'kick') and 'bad' or 'warn')
    end
    for _, x in ipairs(DB.q('SELECT id, text, status, claimed_by, created FROM pb_reports WHERE license = ? OR license LIKE ? ORDER BY id DESC LIMIT 60', { license, like }) or {}) do
        local st = ({ open = 'en attente', claimed = 'pris', closed = 'clos' })[x.status] or tostring(x.status)
        add(x.created, 'reports', ('Report #%d · %s'):format(tonumber(x.id) or 0, st), short(x.text, 200), (x.claimed_by or '') ~= '' and ('pris par ' .. x.claimed_by) or nil, 'info')
    end
    for _, n in ipairs(DB.q('SELECT text, by_name, created FROM pb_staff_notes WHERE license = ? OR license LIKE ? ORDER BY id DESC LIMIT 40', { license, like }) or {}) do
        add(n.created, 'notes', 'Note du staff', short(n.text, 250), n.by_name, 'info')
    end
    local okJ, jrows = pcall(DB.q, 'SELECT kind, text, amount, by_name, at FROM pb_justice_log WHERE license = ? OR license LIKE ? ORDER BY id DESC LIMIT 60', { license, like })
    for _, j in ipairs(okJ and jrows or {}) do
        local amt = tonumber(j.amount) or 0
        add(j.at, 'police', ({ fine = 'Amende', cuff = 'Arrestation', search = 'Fouille', seize = 'Saisie', note = 'Note de police', jail = 'Prison', tig = 'TIG', release = 'Libération', care = 'Soin', repair = 'Réparation' })[j.kind] or ('Justice · ' .. tostring(j.kind)),
            short(j.text, 200) .. (amt > 0 and (' · ' .. amt .. ' $') or ''), j.by_name, 'warn')
    end
    local okK, krows = pcall(DB.q, "SELECT at, kind, origin, reason, actor FROM pb_kicks WHERE (license = ? OR license LIKE ?) AND kind IN ('kick', 'ban') ORDER BY id DESC LIMIT 40", { license, like })
    for _, k in ipairs(okK and krows or {}) do
        add(k.at, 'auto', (k.kind == 'ban' and 'Connexion refusée / banni' or 'Expulsé') .. ((k.origin or '') ~= '' and (' · ' .. k.origin) or ''), short(k.reason, 200), k.actor, 'bad')
    end
    -- journal d'audit : cible « Nom #uid », licence, ou licence dans les données
    local w, pr = { 'target LIKE ?', 'data LIKE ?' }, { '%' .. base .. '%', '%' .. base .. '%' }
    if uid then w[#w + 1] = 'target LIKE ?' pr[#pr + 1] = '% #' .. uid end
    w = table.concat(w, ' OR ')
    local okA, arows = pcall(DB.q, "SELECT action, actor, data, created_at FROM pb_audit WHERE cat = 'staff' AND (" .. w .. ') ORDER BY id DESC LIMIT 120', pr)
    for _, a in ipairs(okA and arows or {}) do
        local lbl = ACT[a.action]
        if lbl ~= false then
            local d = PB.FromJson(a.data, {}) or {}
            local bits = {}
            if d.amount then bits[#bits + 1] = tostring(d.amount) .. ' $' end
            if d.item then bits[#bits + 1] = tostring(d.qty or 1) .. ' × ' .. tostring(d.item) end
            if d.model then bits[#bits + 1] = tostring(d.model) end
            if d.reason and d.reason ~= '' then bits[#bits + 1] = tostring(d.reason) end
            if d.text and d.text ~= '' then bits[#bits + 1] = short(d.text, 120) end
            if a.action == 'rollback' then bits[#bits + 1] = d.money == false and 'objets seulement' or 'objets et argent' end
            add(stamp(a.created_at), 'staff', lbl or ('Staff · ' .. tostring(a.action)), table.concat(bits, ' · '), a.actor, (a.action == 'wipe' or a.action == 'register' or a.action == 'mortrp') and 'bad' or nil)
        end
    end
    table.sort(out, function(a, b) return a.at > b.at end)
    while #out > 200 do table.remove(out) end
    return { license = license, name = fullName(r), uid = uid, items = out, count = count }
end
G.StaffTimeline = timeline

local function sendTimeline(src, license)
    local t = timeline(license)
    if not t then return false, 'Joueur introuvable.' end
    TriggerClientEvent('pb:g:staff:timeline', src, PB.Json(t))
    return true
end
S.SendTimeline = sendTimeline

S.Def('p_timeline', 'staff.players', { quiet = true, run = function(src, _, p)
    p = type(p) == 'table' and p or {}
    local license = validLicense(p.license)
    if not license and tonumber(p.id) then local pl = G.Get(tonumber(p.id)) license = pl and pl.license end
    if not license then return false, 'Joueur introuvable.' end
    return sendTimeline(src, license)
end })
