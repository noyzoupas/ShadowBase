-- Module 18 : Discord (webhooks par canal, alertes, jeton du bot, synchronisation rôles → grades). Secrets stockés côté serveur uniquement.

local B, P, Form, D = PB.B, PB.Perm, PB.Form, PB.Discord

P.Register('discord.edit', 'Modifier les réglages Discord', 'discord')
P.Register('discord.secrets', 'Définir les webhooks et le jeton du bot', 'discord', true)
P.Register('discord.test', 'Envoyer un message de test', 'discord')
P.Register('discord.roles', 'Associer des rôles Discord à des grades', 'discord', true)

local general = Form.Cfg({
    ns = 'discord', id = 'general', title = 'Réglages généraux', perm = 'discord.edit', cols = 2,
    desc = "Active ou coupe toutes les notifications Discord du panel. Les webhooks se règlent dans l'onglet Canaux.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Envoyer des messages sur Discord', default = true },
        { k = 'guild_id', type = 'text', label = 'Identifiant du serveur Discord', default = '', pattern = '^%d*$', maxlen = 24, hint = "Mode développeur Discord → clic droit sur le serveur → Copier l'identifiant." },
        { k = 'username', type = 'text', label = "Nom d'affichage des messages", default = 'Panel', maxlen = 32, hint = "« Panel » ou vide : le nom du serveur est utilisé." },
        { k = 'avatar', type = 'text', label = "Image d'avatar (https)", default = '', maxlen = 300, pattern = '^https://[^%s]+$' },
        { k = 'alert_crash', type = 'toggle', label = 'Alerter sur les erreurs Lua', default = true },
        { k = 'alert_backup', type = 'toggle', label = 'Alerter sur les sauvegardes', default = true },
        { k = 'alert_security', type = 'toggle', label = 'Alerter sur les évènements de sécurité', default = true },
    },
})

PB.Action('discord.webhook.set', 'discord.secrets', function(ctx, p)
    local key = tostring(p.key or '')
    local url = PB.Trim(tostring(p.values and p.values.url or ''))
    local ok, err = D.SetWebhook(key, url, ctx.actor)
    if not ok then return false, err end
    ctx.audit('config', url == '' and 'discord.webhook.retirer' or 'discord.webhook.definir', key)
    ctx.toast = url == '' and 'Webhook retiré.' or 'Webhook enregistré (il ne sera plus réaffiché).'
    return true
end)

PB.Action('discord.channel.save', 'discord.edit', function(ctx, p)
    local key = tostring(p.key or '')
    if not D.Channel(key) then return false, 'Canal inconnu.' end
    local v = p.values or {}
    local mention = tostring(v.mention or '')
    if mention ~= '' and not mention:match('^%d+$') then return false, 'Le rôle à mentionner est un identifiant numérique.' end
    local all = PB.DeepCopy(PB.Cfg.Get('discord', 'channels', {}))
    local before = all[key]
    all[key] = { enabled = PB.ToBool(v.enabled), mention = mention }
    PB.Cfg.Set('discord', 'channels', all, ctx.actor, 'Canal ' .. key)
    ctx.audit('config', 'discord.canal', key, before, all[key])
    ctx.toast = 'Canal enregistré.'
    return true
end)

PB.Action('discord.test', 'discord.test', function(ctx, p)
    local key = tostring(p.key or '')
    if not D.Channel(key) then return false, 'Canal inconnu.' end
    local ok, err = D.Test(key)
    if not ok then return false, err end
    ctx.audit('config', 'discord.test', key)
    ctx.toast = 'Message de test envoyé.'
    return true
end, { rate = 6 })

PB.Action('discord.bot.set', 'discord.secrets', function(ctx, p)
    local token = PB.Trim(tostring(p.values and p.values.token or ''))
    if token ~= '' and (#token < 40 or token:find('%s')) then return false, 'Jeton invalide.' end
    PB.Secret.Set('discord_bot_token', token, ctx.actor)
    ctx.audit('config', token == '' and 'discord.bot.retirer' or 'discord.bot.definir', 'discord_bot_token')
    ctx.toast = token == '' and 'Jeton retiré.' or 'Jeton enregistré (il ne sera plus réaffiché).'
    return true
end, { critical = true, pin = true, confirm = { title = 'Modifier le jeton du bot ?', text = "Le bot peut lire les rôles des membres de ton serveur." } })

PB.Action('discord.roles.fetch', 'discord.roles', function(ctx)
    local roles, err = D.GuildRoles()
    if not roles then return false, err end
    local out = {}
    for _, r in ipairs(roles) do if r.name ~= '@everyone' then out[#out + 1] = { id = tostring(r.id), name = r.name } end end
    table.sort(out, function(a, b) return a.name < b.name end)
    return true, { rows = out }
end, { read = true, rate = 6 })

PB.Action('discord.rolemap.save', 'discord.roles', function(ctx, p)
    local map, rows = {}, p.values and p.values.map or {}
    if type(rows) ~= 'table' or #rows > 50 then return false, 'Table invalide.' end
    local myLevel = P.Level(ctx.src)
    for _, r in ipairs(rows) do
        local role, grade = tostring(r.role or ''), tostring(r.grade or '')
        if role ~= '' then
            if not role:match('^%d+$') then return false, 'Identifiant de rôle invalide : ' .. role end
            local g = P.Grade(grade)
            if not g then return false, 'Grade inconnu : ' .. grade end
            if g.name == 'owner' then return false, 'Le grade propriétaire ne peut pas être attribué par Discord.' end
            if g.level >= myLevel and not P.IsOwner(ctx.src) then return false, 'Tu ne peux pas lier un rôle à un grade égal ou supérieur au tien.' end
            map[role] = grade
        end
    end
    local before = PB.Cfg.Get('discord', 'role_map', {})
    PB.Cfg.Set('discord', 'role_map', map, ctx.actor, 'Rôles Discord')
    PB.Cfg.Set('discord', 'role_sync', PB.ToBool(p.values and p.values.role_sync), ctx.actor, 'Rôles Discord')
    ctx.audit('permission', 'discord.rolemap', 'role_map', before, map)
    ctx.toast = 'Associations enregistrées.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Enregistrer ces associations ?', text = "Les joueurs ayant ces rôles Discord recevront le grade à leur prochaine connexion." } })

PB.Module({
    id = 'discord', label = 'Discord', icon = 'message', group = 'Système', order = 160, perm = 'discord.view', hint = 'Webhooks, alertes, rôles',
    caps = D.Caps,
    doc = "## Discord\nChaque canal a son propre webhook, stocké côté serveur et jamais réaffiché. La synchronisation des rôles exige un bot dans ton serveur Discord.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('general', 'Général', 'sliders', function()
                return { B.stats({ { label = 'Messages en attente', value = D.QueueSize(), icon = 'send' }, { label = 'Envoyés', value = D.Stats.sent, icon = 'check' }, { label = 'Échecs', value = D.Stats.failed, icon = 'alert' } }), general(ctx),
                    PB.G and PB.G.StatusForm and PB.G.StatusForm(ctx) or nil,
                    D.Stats.lastError and B.notice('warn', tostring(D.Stats.lastError), 'Dernière erreur') or nil }
            end),
            tab('channels', 'Canaux', 'hash', function()
                local cfg = PB.Cfg.Get('discord', 'channels', {})
                local blocks = {}
                for _, c in ipairs(D.Channels) do
                    local cc = cfg[c.key] or {}
                    local set = D.WebhookSource(c.key)
                    local fields = { { k = 'enabled', type = 'toggle', label = 'Actif' }, { k = 'mention', type = 'text', label = 'Rôle à mentionner (identifiant)', maxlen = 24, pattern = '^%d*$' } }
                    blocks[#blocks + 1] = { type = 'form', id = 'dc.' .. c.key, title = c.label, desc = set and ('Webhook : ' .. D.WebhookMask(c.key) .. ' (' .. (set == 'convar' and 'convar' or 'base') .. ')') or 'Aucun webhook configuré.', cols = 2, fields = fields,
                        values = { enabled = cc.enabled ~= false, mention = cc.mention or '' }, submit = { action = 'discord.channel.save', label = 'Enregistrer', payload = { key = c.key } },
                        extra = ctx.has('discord.test') and set and { { action = 'discord.test', label = 'Envoyer un test', icon = 'send', payload = { key = c.key } } } or nil }
                    if ctx.has('discord.secrets') and set ~= 'convar' then
                        blocks[#blocks + 1] = { type = 'form', id = 'dcw.' .. c.key, title = 'Webhook — ' .. c.label, cols = 1, fields = { { k = 'url', type = 'secret', label = 'Adresse du webhook', hint = 'Laisse vide pour retirer. Format : https://discord.com/api/webhooks/…', set = set ~= nil } },
                            values = { url = '' }, submit = { action = 'discord.webhook.set', label = 'Enregistrer le webhook', payload = { key = c.key } } }
                    end
                end
                return blocks
            end),
            tab('roles', 'Rôles → grades', 'users', function()
                local map = PB.Cfg.Get('discord', 'role_map', {})
                local rows = {}
                for role, grade in pairs(map) do rows[#rows + 1] = { role = role, grade = grade } end
                table.sort(rows, function(a, b) return a.role < b.role end)
                local gopts = {}
                for _, g in ipairs(P.Grades()) do if g.name ~= 'owner' then gopts[#gopts + 1] = { g.name, g.label } end end
                local blocks = {}
                if not D.BotToken() then blocks[#blocks + 1] = B.notice('warn', "Aucun jeton de bot : la synchronisation est impossible tant qu'il n'est pas défini ci-dessous.") end
                blocks[#blocks + 1] = { type = 'form', id = 'dc.roles', title = 'Associations', cols = 1, fields = {
                    { k = 'role_sync', type = 'toggle', label = 'Appliquer les grades à la connexion' },
                    { k = 'map', type = 'rows', label = 'Rôle Discord → grade', cols = { { k = 'role', label = 'Identifiant du rôle', type = 'text' }, { k = 'grade', label = 'Grade', type = 'select', options = gopts } } } },
                    values = { role_sync = PB.Cfg.Get('discord', 'role_sync', false), map = rows }, submit = { action = 'discord.rolemap.save', label = 'Enregistrer' },
                    extra = D.BotToken() and { { action = 'discord.roles.fetch', label = 'Lister les rôles de mon serveur', icon = 'list', show = 'rows' } } or nil }
                if ctx.has('discord.secrets') then
                    blocks[#blocks + 1] = { type = 'form', id = 'dc.bot', title = 'Jeton du bot', desc = D.BotToken() and ('Jeton défini : ' .. PB.Secret.Mask('discord_bot_token')) or 'Aucun jeton.', cols = 1,
                        fields = { { k = 'token', type = 'secret', label = 'Jeton', set = D.BotToken() ~= nil, hint = 'Laisse vide pour le retirer.' } }, values = { token = '' }, submit = { action = 'discord.bot.set', label = 'Enregistrer le jeton' } }
                end
                return blocks
            end, 'discord.roles'),
        } }
    end,
})
