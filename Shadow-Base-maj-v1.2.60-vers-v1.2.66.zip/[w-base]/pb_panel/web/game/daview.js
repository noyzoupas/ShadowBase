/* Fenêtre « DA du serveur » pour les interfaces à pages (banque, logement, tickets) : barre latérale avec le logo, le lieu et les pages,
   contenu à droite (cartes, tableaux, formulaires, actions, avis), touches en bas. Même contrat que l'ancienne tablette : le serveur envoie
   frame { brand, name, nav[], cash, bank } et page { title, blocks[] } ; on ne fait qu'afficher et renvoyer les actions. Texte : textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

// Carte déplaçable : on glisse avec la souris, la molette zoome autour du curseur. « inner » est l'image carrée (et ce qu'il y a dessus)
// posée en absolu dans « view ». set(taille, gauche, haut) la place ; zoom(facteur, x, y) zoome autour d'un point de la vue.
G.panZoom = function (view, inner, o) {
  o = o || {};
  const st = { size: 0, x: 0, y: 0 };
  const minSize = () => Math.min(view.clientWidth, view.clientHeight) * (o.minFit || 0.9);
  const maxSize = () => Math.max(view.clientWidth, view.clientHeight) * (o.maxZoom || 60);
  function apply() {
    const W = view.clientWidth, H = view.clientHeight, m = 60;   // on ne perd jamais complètement la carte de vue
    st.x = Math.min(W - m, Math.max(m - st.size, st.x)); st.y = Math.min(H - m, Math.max(m - st.size, st.y));
    inner.style.width = st.size + 'px'; inner.style.height = st.size + 'px'; inner.style.left = st.x + 'px'; inner.style.top = st.y + 'px';
    if (o.onChange) o.onChange(st);
  }
  function set(size, x, y) { st.size = Math.max(minSize(), Math.min(maxSize(), size)); st.x = x; st.y = y; apply(); }
  function zoom(f, cx, cy) {
    const W = view.clientWidth, H = view.clientHeight;
    if (cx == null) { cx = W / 2; cy = H / 2; }
    const ns = Math.max(minSize(), Math.min(maxSize(), st.size * f)), k = ns / (st.size || ns);
    st.x = cx - (cx - st.x) * k; st.y = cy - (cy - st.y) * k; st.size = ns; apply();
  }
  let drag = null;
  view.addEventListener('mousedown', (e) => { if (e.button !== 0 || e.target.closest('button')) return; drag = { x: e.clientX, y: e.clientY, sx: st.x, sy: st.y, moved: false }; view.classList.add('grab'); e.preventDefault(); });
  window.addEventListener('mousemove', (e) => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true; st.x = drag.sx + dx; st.y = drag.sy + dy; apply(); });
  window.addEventListener('mouseup', (e) => { if (!drag) return; const d = drag; drag = null; view.classList.remove('grab'); if (!d.moved && o.onClick) { const r = view.getBoundingClientRect(); o.onClick((e.clientX - r.left - st.x) / st.size, (e.clientY - r.top - st.y) / st.size); } });
  view.addEventListener('wheel', (e) => { e.preventDefault(); e.stopPropagation(); const r = view.getBoundingClientRect(); zoom(e.deltaY < 0 ? 1.25 : 0.8, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
  return { set, zoom, st, apply };
};

function daView(opt) {
  opt = opt || {};
  let frame = opt.frame || { nav: [] }, page = opt.page || null, cur = (page && page.page) || 'home';
  const permSel = {};   // grade choisi dans chaque bloc de droits : gardé quand la page se recharge
  let drawnPage = null;
  // le serveur ignore les actions trop rapprochées : les cases cochées vite partent l'une après l'autre
  const permQueue = []; let permTimer = null;
  const permNext = () => { const q = permQueue.shift(); if (!q) { permTimer = null; return; } opt.onAct && opt.onAct(q[0], q[1], cur); permTimer = setTimeout(permNext, 320); };
  const permSend = (name, payload) => { G.click(); permQueue.push([name, payload]); if (!permTimer) permNext(); };
  const side = h('aside', { class: 'dv-side' }), main = h('main', { class: 'dv-main' }), toast = h('div', { class: 'dv-toast hidden' }), keys = h('footer', { class: 'dv-keys' });
  const el = h('div', { class: 'dv' }, h('div', { class: 'dv-win' }, side, h('div', { class: 'dv-right' }, main, keys), toast));
  let tt = null;
  const say = (ok, msg) => { if (!msg) return; toast.textContent = String(msg); toast.className = 'dv-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(tt); tt = setTimeout(() => toast.classList.add('hidden'), 4200); };
  const act = (name, payload) => { if (name) { G.click(); opt.onAct && opt.onAct(name, payload || {}, cur); } };
  const go = (id) => { cur = id; drawSide(); opt.onPage && opt.onPage(id); };

  function btn(a, cls) {
    let armed = false;
    const label = String(a.label || a.act || '');
    const b = h('button', { type: 'button', class: 'dv-btn' + (a.primary ? ' pri' : '') + (a.danger ? ' dng' : '') + (cls ? ' ' + cls : ''), disabled: a.disabled || null }, a.icon ? ico(a.icon) : null, h('span', null, label));
    b.addEventListener('click', () => {
      if (a.confirm && !armed) { armed = true; b.classList.add('arm'); b.lastChild.textContent = 'Confirmer ?'; setTimeout(() => { armed = false; b.classList.remove('arm'); b.lastChild.textContent = label; }, 3000); return; }
      act(a.act, a.payload);
    });
    return b;
  }
  const sec = (title, ...kids) => h('section', { class: 'dv-sec' }, title ? h('h3', null, String(title)) : null, ...kids);

  const B = {
    hero(b) {
      return h('section', { class: 'dv-hero' }, h('div', null, b.eyebrow ? h('small', null, String(b.eyebrow)) : null, h('b', null, String(b.title || '')), b.sub ? h('p', null, String(b.sub)) : null),
        b.chips ? h('div', { class: 'dv-chips' }, b.chips.map((c) => h('span', null, h('small', null, String(c[0])), h('b', null, String(c[1]))))) : null);
    },
    cards(b) {
      return h('section', { class: 'dv-cards' + (b.big ? ' big' : '') }, (b.items || []).map((it) => h('article', { class: 'dv-card' },
        h('div', { class: 'dv-card-h' }, h('span', { class: 'dv-ic' }, ico(it.icon || 'info')), h('small', null, String(it.title || '')), it.badge ? h('em', null, String(it.badge)) : null),
        it.value != null && it.value !== '' ? h('strong', null, String(it.value)) : null, it.sub ? h('p', null, String(it.sub)) : null, it.text ? h('p', { class: 'dim' }, String(it.text)) : null,
        it.stats ? h('div', { class: 'dv-cs' }, it.stats.map((s) => h('span', null, h('b', null, String(s.value)), h('small', null, String(s.label))))) : null)));
    },
    tiles(b) {
      return sec(b.title, h('div', { class: 'dv-tiles' }, (b.items || []).map((it) => h('button', { type: 'button', class: 'dv-tile', onclick: () => { if (it.page) go(it.page); else act(it.act, it.payload); } },
        h('span', { class: 'dv-ic' }, ico(it.icon || 'info')), h('b', null, String(it.title || '')), it.sub ? h('small', null, String(it.sub)) : null))));
    },
    actions(b) { return sec(b.title, h('div', { class: 'dv-row' }, (b.items || []).map((a) => btn(a)))); },
    // droits d'un grade : on choisit le grade, puis on coche ; chaque case part tout de suite au serveur
    perms(b) {
      const grades = b.grades || [], key = String(b.id || b.act);
      let g = grades.find((x) => x.id === permSel[key]) || grades.find((x) => !x.locked) || grades[0];
      if (!g) return null;
      const tabs = h('div', { class: 'dv-ptabs' }), list = h('div', { class: 'dv-pl' });
      const count = (x) => (b.items || []).filter((i) => x.perms && x.perms[i.k]).length;
      const draw = () => {
        G.clear(tabs); G.clear(list);
        grades.forEach((x) => tabs.appendChild(h('button', { type: 'button', class: 'dv-ptab' + (x === g ? ' on' : ''), onclick: () => { G.click(); g = x; permSel[key] = x.id; draw(); } },
          x.locked ? ico('crown') : null, String(x.label), x.locked ? null : h('em', null, String(count(x))))));
        if (g.locked) list.appendChild(h('p', { class: 'dv-plock' }, String(b.lockedText || 'Ce grade a tous les droits.')));
        (b.items || []).forEach((it) => {
          const on = !!g.locked || !!(g.perms && g.perms[it.k]);
          list.appendChild(h('button', { type: 'button', role: 'checkbox', 'aria-checked': String(on), class: 'dv-pr' + (on ? ' on' : ''), disabled: g.locked ? true : null, onclick: () => {
            if (!g.perms || Array.isArray(g.perms)) g.perms = {};
            g.perms[it.k] = !on; draw();
            permSend(b.act, { grade: g.id, perm: it.k, on: on ? '0' : '1' });
          } }, h('span', { class: 'dv-pc' }, on ? ico('check') : null), h('span', { class: 'dv-pt' }, h('b', null, String(it.label || it.k)), it.desc ? h('small', null, String(it.desc)) : null)));
        });
      };
      permSel[key] = g.id;
      draw();
      return h('section', { class: 'dv-sec dv-perms' }, h('h3', null, String(b.title || 'Droits')), b.desc ? h('p', { class: 'dim' }, String(b.desc)) : null, tabs, list);
    },
    notice(b) { return h('div', { class: 'dv-note ' + (b.kind || b.tone || '') }, ico('info'), h('span', null, String(b.text || ''))); },
    table(b) {
      const cols = b.columns || [], rows = b.rows || [];
      if (!rows.length) return sec(b.title, h('div', { class: 'dv-empty' }, String(b.empty || 'Rien à afficher.')));
      const hasAct = rows.some((r) => r.actions && r.actions.length);
      const t = h('table', null, h('thead', null, h('tr', null, cols.map((c) => h('th', null, String(c.label))), hasAct ? h('th') : null)),
        h('tbody', null, rows.map((r) => h('tr', null, cols.map((c) => h('td', null, r[c.k] == null ? '' : String(r[c.k]))), hasAct ? h('td', { class: 'dv-ra' }, (r.actions || []).map((a) => btn(a, 'sm'))) : null))));
      return sec(b.title, h('div', { class: 'dv-tw' }, t));
    },
    form(b) {
      const inputs = [];
      const fields = (b.fields || []).map((f) => {
        let inp;
        if (f.type === 'select') {
          inp = h('select', null, (f.opts || []).map((o) => h('option', { value: Array.isArray(o) ? o[0] : o }, String(Array.isArray(o) ? o[1] : o))));
          if (!(f.opts || []).length) { inp.appendChild(h('option', { value: '' }, 'Personne à proximité')); inp.disabled = true; }
        } else if (f.type === 'area') inp = h('textarea', { rows: 4, maxlength: f.maxlen || 500, placeholder: f.label });
        else if (f.type === 'toggle') inp = h('input', { type: 'checkbox' });
        else if (f.type === 'number') inp = h('input', { type: 'number', min: f.min, max: f.max, placeholder: f.label });
        else inp = h('input', { type: 'text', maxlength: f.maxlen || 120, placeholder: f.label });
        if (f.value != null) { if (f.type === 'toggle') inp.checked = !!f.value; else inp.value = f.value; }
        inputs.push([f, inp]);
        return h('label', { class: 'dv-f' + (f.type === 'area' ? ' wide' : '') + (f.type === 'toggle' ? ' tg' : '') }, h('small', null, String(f.label || '')), inp);
      });
      const sb = b.submit || {};
      const go2 = h('button', { type: 'button', class: 'dv-btn pri', disabled: sb.disabled || null }, ico('check'), h('span', null, String(sb.label || 'Valider')));
      go2.addEventListener('click', () => { const p = {}; inputs.forEach(([f, i]) => { p[f.k] = f.type === 'number' ? (i.value === '' ? null : Number(i.value)) : f.type === 'toggle' ? i.checked : i.value; }); act(sb.act, p); });
      return h('section', { class: 'dv-sec dv-form' }, h('h3', null, String(b.title || '')), b.desc ? h('p', { class: 'dim' }, String(b.desc)) : null, h('div', { class: 'dv-fg' }, fields), h('div', { class: 'dv-row' }, go2));
    },
    // Blanchiment : anneau de progression (dégradé sale -> propre), billets qui passent dans la machine, temps restant qui défile
    washring(b) {
      const NS = 'http://www.w3.org/2000/svg', R = 74, C = 2 * Math.PI * R;
      const mk = (n, a) => { const e = document.createElementNS(NS, n); Object.keys(a).forEach((k) => e.setAttribute(k, a[k])); return e; };
      const svg = mk('svg', { viewBox: '0 0 180 180', class: 'wr-svg' });
      const defs = mk('defs', {}), grad = mk('linearGradient', { id: 'wrg', x1: '0', y1: '0', x2: '1', y2: '1' });
      grad.appendChild(mk('stop', { offset: '0', 'stop-color': 'rgba(255,255,255,.35)' })); grad.appendChild(mk('stop', { offset: '1', 'stop-color': '#ffffff' }));
      defs.appendChild(grad); svg.appendChild(defs);
      svg.appendChild(mk('circle', { cx: 90, cy: 90, r: R, fill: 'none', stroke: 'rgba(255,255,255,.08)', 'stroke-width': 12 }));
      const arc = mk('circle', { cx: 90, cy: 90, r: R, fill: 'none', stroke: 'url(#wrg)', 'stroke-width': 12, 'stroke-linecap': 'round', 'stroke-dasharray': C, 'stroke-dashoffset': C, transform: 'rotate(-90 90 90)', class: 'wr-arc' });
      svg.appendChild(arc);
      // lumière qui file le long de la partie remplie, du début jusqu'au bout, puis repart (flux qui pousse)
      const SEG = 26;
      const glow = mk('circle', { cx: 90, cy: 90, r: R, fill: 'none', stroke: '#ffffff', 'stroke-width': 12, 'stroke-linecap': 'round', 'stroke-dasharray': SEG + ' ' + C, 'stroke-dashoffset': 0, transform: 'rotate(-90 90 90)', class: 'wr-glow' });
      svg.appendChild(glow);
      const pctEl = h('b', null, '0 %'), leftEl = h('small', null, '');
      const ring = h('div', { class: 'wr-ring' }, svg, h('div', { class: 'wr-mid' }, pctEl, leftEl));
      let left = Math.max(0, Number(b.left) || 0);
      const total = Math.max(1, Number(b.total) || 1);
      const paint = () => {
        const p = b.done ? 1 : Math.max(0, Math.min(1, 1 - left / total));
        arc.setAttribute('stroke-dashoffset', String(C * (1 - p)));
        pctEl.textContent = Math.floor(p * 100) + ' %';
        const s = Math.floor(left);
        leftEl.textContent = b.done ? 'Prêt à récupérer' : (s >= 3600 ? Math.floor(s / 3600) + ' h ' + String(Math.floor((s % 3600) / 60)).padStart(2, '0') : Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0')) + ' restant';
      };
      paint();
      if (!b.done) { const t = setInterval(() => { if (!ring.isConnected) { clearInterval(t); return; } left = Math.max(0, left - 1); paint(); }, 1000); }
      // la lumière : 1,8 s pour aller du début au bout de l'arc, s'éteint en arrivant, repart
      const t0 = Date.now();
      const run = setInterval(() => {
        if (!ring.isConnected) { clearInterval(run); return; }
        const p = b.done ? 1 : Math.max(0, Math.min(1, 1 - left / total));
        const len = Math.max(0, C * p - SEG);
        const k = ((Date.now() - t0) % 1800) / 1800;
        glow.setAttribute('stroke-dashoffset', String(-len * k));
        glow.setAttribute('opacity', String(len <= 0 ? 0 : (k < 0.12 ? k / 0.12 : k > 0.85 ? (1 - k) / 0.15 : 1)));
      }, 33);
      const money = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
      const stat = (k, v) => h('div', null, h('small', null, k), h('b', null, v));
      return h('section', { class: 'wr-box' + (b.done ? ' done' : '') }, ring,
        h('div', { class: 'wr-side' }, h('small', { class: 'wr-k' }, b.done ? 'Terminé' : 'Le contact lave ton argent'),
          h('div', { class: 'wr-flow' }, h('span', { class: 'dirty' }, money(b.dirty)), h('em', null, '→'), h('span', { class: 'clean' }, money(b.clean))),
          h('div', { class: 'wr-stats' }, stat('Commission', (Number(b.cut) || 0) + ' %'), stat('Argent sale confié', money(b.dirty)), stat('Argent propre', money(b.clean)))));
    },
    // Carte des territoires : la carte du serveur (img/map.jpg, même calage que le panel), chaque zone avec sa vraie forme,
    // bleue si libre, à la couleur du gang qui la tient sinon ; cadrée sur les zones, bouton pour voir toute la carte.
    terrmap(b) {
      const CAL = { ax: -5206.4, bx: 11493.2, ay: 8271.8, by: 12556 };
      const uv = (x, y) => [(Number(x) - CAL.ax) / CAL.bx, (CAL.ay - Number(y)) / CAL.by];
      const FREE = '#4a9fe8', NS = 'http://www.w3.org/2000/svg';
      const col = (z) => (/^#[0-9a-fA-F]{6}$/.test(z.color || '') ? z.color : FREE);
      const zones = (b.zones || []).filter((z) => Number.isFinite(Number(z.x)) && Number.isFinite(Number(z.y)));
      const svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 1 1'); svg.setAttribute('preserveAspectRatio', 'none'); svg.setAttribute('class', 'dv-tm-svg');
      let style = 'map';
      try { style = localStorage.getItem('pb_map_style') === 'plan' ? 'map-plan' : 'map'; } catch (e) { /* rien */ }
      const img = h('img', { src: 'img/' + style + '.jpg', alt: '', draggable: 'false' });
      const inner = h('div', { class: 'dv-tm-in' }, img, svg);
      let u0 = 1, v0 = 1, u1 = 0, v1 = 0;
      const grow = (u, v) => { u0 = Math.min(u0, u); v0 = Math.min(v0, v); u1 = Math.max(u1, u); v1 = Math.max(v1, v); };
      zones.forEach((z) => {
        const c = col(z);
        let shape;
        if (Array.isArray(z.poly) && z.poly.length >= 3) {
          shape = document.createElementNS(NS, 'polygon');
          shape.setAttribute('points', z.poly.map((p) => { const q = uv(p[0] != null ? p[0] : p.x, p[1] != null ? p[1] : p.y); grow(q[0], q[1]); return q[0] + ',' + q[1]; }).join(' '));
        } else {
          const q = uv(z.x, z.y), r = Number(z.r) || 30;
          shape = document.createElementNS(NS, 'ellipse');
          shape.setAttribute('cx', q[0]); shape.setAttribute('cy', q[1]); shape.setAttribute('rx', r / CAL.bx); shape.setAttribute('ry', r / CAL.by);
          grow(q[0] - r / CAL.bx, q[1] - r / CAL.by); grow(q[0] + r / CAL.bx, q[1] + r / CAL.by);
        }
        shape.setAttribute('fill', c); shape.setAttribute('fill-opacity', z.mine ? '.62' : '.5');
        shape.setAttribute('stroke', z.mine ? '#ffffff' : c); shape.setAttribute('stroke-width', z.mine ? '2.2' : '1.4'); shape.setAttribute('vector-effect', 'non-scaling-stroke');
        svg.appendChild(shape);
        const q = uv(z.x, z.y);
        inner.appendChild(h('div', { class: 'dv-tm-lb', style: { left: q[0] * 100 + '%', top: q[1] * 100 + '%' } }, h('b', null, String(z.label || '')), h('small', null, z.owner ? String(z.owner) : 'Libre')));
      });
      const view = h('div', { class: 'dv-tm' }, inner);
      let whole = false;
      // cadrage : la boîte des zones (avec une marge) remplit la vue ; « toute la carte » montre l'image entière
      const fit = () => {
        const W = view.clientWidth, H = view.clientHeight;
        if (!W || !H) return;
        let cu = 0.5, cv = 0.5, span = 1;
        if (!whole && zones.length) {
          const pad = 0.012;
          cu = (u0 + u1) / 2; cv = (v0 + v1) / 2;
          span = Math.min(1, Math.max(0.03, (u1 - u0) + pad * 2, ((v1 - v0) + pad * 2) * H / W));
        }
        const size = W / span;   // côté de l'image (carrée) en pixels
        pz.set(size, W / 2 - cu * size, H / 2 - cv * size);
      };
      const pz = G.panZoom(view, inner);   // glisser pour déplacer, molette ou + / − pour zoomer
      view.appendChild(h('div', { class: 'dv-tm-zoom' },
        h('button', { type: 'button', title: 'Zoomer', onclick: () => { G.click(); pz.zoom(1.4); } }, '+'),
        h('button', { type: 'button', title: 'Dézoomer', onclick: () => { G.click(); pz.zoom(1 / 1.4); } }, '−')));
      requestAnimationFrame(fit); setTimeout(fit, 120);
      const sw = h('button', { type: 'button', class: 'dv-btn sm', onclick: () => { G.click(); whole = !whole; sw.lastChild.textContent = whole ? 'Cadrer sur les zones' : 'Toute la carte'; fit(); } }, ico('map'), h('span', null, 'Toute la carte'));
      const legend = h('div', { class: 'dv-tm-leg' });
      const seen = {};
      zones.forEach((z) => { const k = z.owner || 'Libre'; if (seen[k]) return; seen[k] = 1; legend.appendChild(h('span', null, h('i', { style: { background: col(z) } }), String(k))); });
      if (!zones.length) return sec(b.title, h('div', { class: 'dv-empty' }, 'Aucun territoire sur le serveur.'));
      // même choix Satellite / Plan que les cartes du panel (pb_map_style)
      const st = h('button', { type: 'button', class: 'dv-btn sm', onclick: () => { G.click(); style = style === 'map' ? 'map-plan' : 'map'; img.src = 'img/' + style + '.jpg'; st.lastChild.textContent = style === 'map' ? 'Plan' : 'Satellite'; try { localStorage.setItem('pb_map_style', style === 'map' ? 'sat' : 'plan'); } catch (e) { /* rien */ } } },
        ico('map'), h('span', null, style === 'map' ? 'Plan' : 'Satellite'));
      return sec(b.title, view, h('div', { class: 'dv-row dv-tm-foot' }, legend, h('div', { class: 'dv-row' }, st, sw)));
    },
  };

  function drawSide() {
    G.clear(side);
    const logo = G.logoUrl();
    side.append(h('div', { class: 'dv-brand' }, h('img', { src: logo, alt: '', 'data-pblogo': '1' }), h('small', null, String((frame.nav && frame.nav[0] && frame.nav[0].group) || ''))),
      h('div', { class: 'dv-place' }, h('b', null, String(frame.brand || frame.title || '')), h('span', null, String(frame.name || ''))));
    const nav = h('nav', { class: 'dv-nav' });
    (frame.nav || []).forEach((n) => nav.appendChild(h('button', { type: 'button', class: 'dv-nv' + (n.id === cur ? ' on' : ''), onclick: () => { if (n.id !== cur) { G.click(); go(n.id); } } },
      ico(n.icon || 'info'), h('span', null, String(n.label || '')), n.count != null ? h('em', null, String(n.count)) : null)));
    side.appendChild(nav);
    const money = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
    side.appendChild(h('div', { class: 'dv-wallet' },
      frame.cash != null ? h('div', null, h('small', null, 'Espèces'), h('b', null, money(frame.cash))) : null,
      frame.bank != null ? h('div', null, h('small', null, 'Banque'), h('b', null, money(frame.bank))) : null));
  }
  function drawPage() {
    const y = drawnPage === cur ? main.scrollTop : 0;   // même page rechargée (après une action) : on reste au même endroit
    drawnPage = cur;
    G.clear(main);
    if (!page) { main.appendChild(h('div', { class: 'dv-empty' }, 'Chargement…')); return; }
    main.appendChild(h('header', { class: 'dv-top' }, h('div', null, h('small', null, String(frame.brand || '')), h('h1', null, String(page.title || '')), page.sub ? h('p', null, String(page.sub)) : null),
      h('button', { type: 'button', class: 'dv-rf', title: 'Actualiser', onclick: () => { G.click(); opt.onPage && opt.onPage(cur); } }, ico('refresh'))));
    (page.blocks || []).forEach((b) => { const f = b && B[b.type]; const n = f ? f(b) : null; if (n) main.appendChild(n); });
    main.scrollTop = y;
  }
  function drawKeys() {
    G.clear(keys);
    const k = (key, t) => h('span', null, h('kbd', null, key), t);
    keys.append(k('Clic', 'Choisir'), k('Molette', 'Faire défiler'), k('Échap', 'Fermer'));
    if (opt.onClose) keys.appendChild(h('button', { type: 'button', class: 'dv-x', onclick: () => { G.click(); opt.onClose(); } }, ico('x'), 'Fermer'));
  }
  drawSide(); drawPage(); drawKeys();
  return { el, set(d) { if (d.frame) frame = d.frame; if (d.page) { page = d.page; cur = d.page.page || cur; } drawSide(); drawPage(); if (d.err) say(false, d.err); }, say };
}
G.daView = daView;
})();
