-- Boutique du serveur (coins) : armes permanentes, véhicules, VIP, villas, argent en jeu, objets, plaques personnalisées.
-- Les coins s'achètent UNIQUEMENT avec de l'argent réel, hors du jeu (Tebex ou autre) : la boutique en ligne lance la commande console
-- « shadowcoins add … » ; le staff peut aussi créditer depuis le panel (droit dédié, motif obligatoire, journal). Aucun chemin du jeu ne
-- transforme de l'argent du jeu en coins, et les coins ne se donnent pas entre joueurs. Les coins sont ceux du COMPTE (licence Rockstar) :
-- partagés par ses personnages. Ce qui est acheté va au personnage joué (véhicule, argent, objets) ou au compte (VIP, armes permanentes).

local G, P, B, DB = PB.G, PB.Perm, PB.B, PB.DB
local Pm = {}
G.Premium = Pm

P.Register('premium.edit', 'Boutique : modifier le catalogue et les réglages', 'premium', true)
P.Register('premium.coins', 'Boutique : créditer ou retirer des coins à un joueur', 'premium', true)
P.Register('premium.view', 'Boutique : voir les soldes et les achats', 'premium')

PB.Migrate('379_premium', 'Boutique : coins, catalogue, achats', {
    [[CREATE TABLE IF NOT EXISTS pb_coins (license VARCHAR(64) NOT NULL, balance INT NOT NULL DEFAULT 0, bought INT NOT NULL DEFAULT 0, spent INT NOT NULL DEFAULT 0,
        updated INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_coin_tx (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, delta INT NOT NULL, balance INT NOT NULL DEFAULT 0,
        kind VARCHAR(12) NOT NULL, label VARCHAR(120) NOT NULL DEFAULT '', ref VARCHAR(80) NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id), UNIQUE KEY uq_ref (ref), KEY k_lic (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_premium_items (id INT NOT NULL AUTO_INCREMENT, cat VARCHAR(12) NOT NULL, label VARCHAR(60) NOT NULL, descr VARCHAR(240) NOT NULL DEFAULT '',
        price INT NOT NULL DEFAULT 0, image VARCHAR(255) NOT NULL DEFAULT '', data TEXT NULL, per_player INT NOT NULL DEFAULT 0, stock INT NOT NULL DEFAULT -1,
        sold INT NOT NULL DEFAULT 0, enabled TINYINT(1) NOT NULL DEFAULT 1, sort INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_premium_owned (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, char_license VARCHAR(80) NOT NULL DEFAULT '', item_id INT NOT NULL,
        cat VARCHAR(12) NOT NULL, label VARCHAR(60) NOT NULL, data TEXT NULL, price INT NOT NULL DEFAULT 0, at INT NOT NULL DEFAULT 0, claimed_at INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY k_lic (license))]],
})

PB.Migrate('380_premium_promo', 'Boutique : promotions', {
    "ALTER TABLE pb_premium_items ADD COLUMN promo_pct INT NOT NULL DEFAULT 0",
    "ALTER TABLE pb_premium_items ADD COLUMN promo_until INT NOT NULL DEFAULT 0",
})
PB.Migrate('381_premium_daily', 'Boutique : offres du jour, boosts', {
    [[CREATE TABLE IF NOT EXISTS pb_premium_daily (license VARCHAR(64) NOT NULL, day INT NOT NULL, item_id INT NOT NULL, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license, day, item_id))]],
    [[CREATE TABLE IF NOT EXISTS pb_premium_boosts (license VARCHAR(64) NOT NULL, kind VARCHAR(12) NOT NULL, pct INT NOT NULL DEFAULT 0, until_at INT NOT NULL DEFAULT 0, PRIMARY KEY (license, kind))]],
})
PB.Cfg.Define('premium', { enabled = true, name = 'Boutique', coin = 'Coins', store_url = '', key = 'F11', claim_hours = 6, weapon_permit = false, seeded = false,
    daily_count = 4, daily_discount = 25, daily_salt = 0, accent = '', seeded2 = false })
local function cfg(k, d) return PB.Cfg.Get('premium', k, d) end
local function now() return os.time() end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end
local function int(v) local n = tonumber(v) return n and math.floor(n) or nil end
local function fmt(n) n = math.floor(tonumber(n) or 0) local s = tostring(math.abs(n)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') return (n < 0 and '-' or '') .. s end
local function coins(n) return fmt(n) .. ' ' .. tostring(cfg('coin', 'Coins')) end
local function money(n) return fmt(n) .. ' $' end
local function account(src) local l = P.GetLicense(tonumber(src) or -1) return l and (tostring(l):gsub('#%d+$', '')) or nil end
local function display(src) local i = G.Identity and G.Identity(src) if i and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return GetPlayerName(src) or ('Joueur ' .. tostring(src)) end

Pm.CATS = {
    { id = 'vehicle', label = 'Véhicules', icon = 'car', limit = 1, sub = 'Livré à ton garage, à toi pour toujours.' },
    { id = 'weapon', label = 'Armes', icon = 'crosshair', limit = 1, sub = 'Arme permanente : perdue ou saisie, tu la récupères dans « Mes achats ».' },
    { id = 'vip', label = 'VIP', icon = 'crown', limit = 0, sub = 'Paie toutes les 15 min, pêche automatique, multi-personnages, meubles…' },
    { id = 'boost', label = 'Boosts', icon = 'bolt', limit = 0, sub = 'Bonus temporaire sur ta paie ou tes missions.' },
    { id = 'villa', label = 'Villas', icon = 'home', limit = 1, sub = 'Sans impôt ni loyer, intérieur et meubles au choix.' },
    { id = 'money', label = 'Argent en jeu', icon = 'coins', limit = 0, sub = 'Versé sur le compte en banque du personnage joué.' },
    { id = 'item', label = 'Objets', icon = 'box', limit = 0, sub = 'Ajoutés au sac du personnage joué.' },
    { id = 'plate', label = 'Plaque personnalisée', icon = 'card', limit = 0, sub = 'Choisis le texte de la plaque d\'un de tes véhicules.' },
}
local CAT = {} for _, c in ipairs(Pm.CATS) do CAT[c.id] = c end
-- raretés (couleur des cartes)
Pm.RARITY = { { 'commun', 'Commun', '#9aa3b2', 60 }, { 'rare', 'Rare', '#4aa3ff', 25 }, { 'epique', 'Épique', '#b06bff', 11 }, { 'legendaire', 'Légendaire', '#f2b440', 4 } }
local RAR = {} for i, r in ipairs(Pm.RARITY) do RAR[r[1]] = { id = r[1], label = r[2], color = r[3], w = r[4], rank = i } end
local function rarityOf(it) return RAR[tostring(it.data and it.data.rarity or '')] or RAR.commun end
local BOOSTS = { pay = 'Paie', mission = 'Missions' }

-- Coins --------------------------------------------------------------------------------------------------------------------------------
function Pm.Balance(license)
    if not license then return 0 end
    local r = DB.one('SELECT balance FROM pb_coins WHERE license = ?', { license })
    return r and tonumber(r.balance) or 0
end
local function txRow(license, delta, kind, label, ref, by)
    -- sans référence : la colonne reste vide (un nil au milieu des paramètres faisait échouer l'écriture du mouvement)
    if ref then
        DB.insert('INSERT INTO pb_coin_tx (license, delta, balance, kind, label, ref, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            { license, delta, Pm.Balance(license), kind, clean(label, 120), ref, clean(by or 'système', 64), now() })
    else
        DB.insert('INSERT INTO pb_coin_tx (license, delta, balance, kind, label, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            { license, delta, Pm.Balance(license), kind, clean(label, 120), clean(by or 'système', 64), now() })
    end
end
local function onlineOf(license) for s, p in pairs(G.Players()) do if account(s) == license or p.license == license then return s end end end
local function pushBalance(license)
    local s = onlineOf(license)
    if s then TriggerClientEvent('pb:g:premium:coins', s, Pm.Balance(license)) end
end
-- crédit (achat réel, geste du staff). ref = identifiant de la transaction de la boutique en ligne : un même ref n'est jamais crédité deux fois.
function Pm.Credit(license, amount, kind, label, ref, by)
    amount = int(amount)
    if not license or license == '' then return false, 'Compte introuvable.' end
    if not amount or amount == 0 or math.abs(amount) > 10000000 then return false, 'Montant invalide.' end
    ref = ref and clean(ref, 80) or nil
    if ref == '' then ref = nil end
    if ref and DB.one('SELECT id FROM pb_coin_tx WHERE ref = ?', { ref }) then return false, 'Transaction déjà créditée (' .. ref .. ').' end
    if amount > 0 then
        DB.exec('INSERT INTO pb_coins (license, balance, bought, spent, updated) VALUES (?, ?, ?, 0, ?) ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance), bought = bought + VALUES(bought), updated = VALUES(updated)',
            { license, amount, kind == 'credit' and amount or 0, now() })
    elseif (tonumber(DB.exec('UPDATE pb_coins SET balance = balance + ?, updated = ? WHERE license = ? AND balance >= ?', { amount, now(), license, -amount })) or 0) < 1 then
        return false, 'Solde insuffisant pour retirer ' .. coins(-amount) .. '.'
    end
    txRow(license, amount, kind or 'credit', label or (amount > 0 and 'Crédit' or 'Retrait'), ref, by)
    PB.Audit.Log('boutique', amount > 0 and 'coins.credit' or 'coins.debit', by or 0, license, nil, nil, { amount = amount, ref = ref, kind = kind, label = label })
    pushBalance(license)
    local s = onlineOf(license)
    if s and amount > 0 then G.Notify(s, { type = 'success', title = cfg('name', 'Boutique'), text = ('%s ajoutés à ton compte. Merci pour ton soutien !'):format(coins(amount)), duration = 9000 }) end
    return true, ('%s %s. Nouveau solde : %s.'):format(coins(math.abs(amount)), amount > 0 and 'crédités' or 'retirés', coins(Pm.Balance(license)))
end
-- débit d'un achat : atomique (jamais de solde négatif, même avec deux achats en même temps)
local function debit(license, price, label)
    if price <= 0 then return true end
    if (tonumber(DB.exec('UPDATE pb_coins SET balance = balance - ?, spent = spent + ?, updated = ? WHERE license = ? AND balance >= ?', { price, price, now(), license, price })) or 0) < 1 then return false end
    txRow(license, -price, 'buy', label, nil, nil)
    return true
end
local function refund(license, price, label)
    if price <= 0 then return end
    DB.exec('UPDATE pb_coins SET balance = balance + ?, spent = spent - ?, updated = ? WHERE license = ?', { price, price, now(), license })
    txRow(license, price, 'refund', 'Remboursé : ' .. label, nil, nil)
end

-- Catalogue ----------------------------------------------------------------------------------------------------------------------------
local cache
function Pm.Items(all)
    if not cache then
        cache = DB.q('SELECT * FROM pb_premium_items ORDER BY sort, price, id') or {}
        for _, it in ipairs(cache) do it.data = PB.FromJson(it.data or '', {}) or {} it.enabled = PB.ToBool(it.enabled) end
    end
    if all then return cache end
    local out = {}
    for _, it in ipairs(cache) do if it.enabled and CAT[it.cat] then out[#out + 1] = it end end
    return out
end
-- prix du moment (promotion en cours comprise)
function Pm.PriceOf(it)
    local pct = int(it.promo_pct) or 0
    if pct > 0 and pct < 100 and (int(it.promo_until) or 0) > now() then return math.max(1, math.floor(it.price * (100 - pct) / 100)) end
    return it.price
end
function Pm.Item(id) id = int(id) for _, it in ipairs(Pm.Items(true)) do if it.id == id then return it end end end
local function invalidate() cache = nil end
Pm.Invalidate = invalidate

-- arme permanente : un objet à part (weapon_xxx_perm), lié au joueur (ni donné, ni jeté, ni pris), recréé si besoin
local function permItem(it) local h = tostring(it.data.hash or ''):upper() local base = h:match('^WEAPON_([%w_]+)$') return base and ('weapon_' .. base:lower() .. '_perm'):sub(1, 40) or nil end
local function weaponImage(it) local h = tostring(it.data.hash or ''):upper() return G.OxImage and G.OxImage('weapon_' .. (h:match('^WEAPON_([%w_]+)$') or ''):lower()) or nil end
local function ensureWeapon(it)
    local item = permItem(it)
    if not item or not (G.Weapons and G.Weapons.EnsureWeapon) then return nil end
    if not (G.Inv.Def(item) and G.Weapons.ByItem and G.Weapons.ByItem(item)) then
        G.Weapons.EnsureWeapon({ item = item, label = (clean(it.label, 30) .. ' ★'):sub(1, 40), hash = tostring(it.data.hash):upper(), ammo_item = tostring(it.data.ammo_item or ''):lower(),
            weight = 1000, permit = cfg('weapon_permit', false) == true, image = weaponImage(it) or '', description = 'Arme permanente de la boutique : elle reste à toi.' })
    end
    if G.Inv.Bind then G.Inv.Bind(item) end
    return item
end
local function bindAll() for _, it in ipairs(Pm.Items(true)) do if it.cat == 'weapon' then pcall(ensureWeapon, it) end end end

local function newPlate()
    local pre = tostring(PB.Cfg.Get('shops', 'plate_prefix', 'PB') or 'PB'):upper():gsub('[^A-Z0-9]', ''):sub(1, 3)
    for _ = 1, 40 do
        local pl = pre .. tostring(math.random(10 ^ (7 - #pre - 1), 10 ^ (7 - #pre) - 1))
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { pl }) then return pl end
    end
end
local function vehLabel(it) local m = tostring(it.data.model or '') return clean(it.data.vlabel or it.label or m, 40) end
local function giveVehicle(src, it)
    local m = tostring(it.data.model or ''):lower()
    if not m:match('^[%w_]+$') then return nil, 'Modèle invalide (catalogue).' end
    local plate = newPlate() if not plate then return nil, 'Aucune plaque disponible.' end
    DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price) VALUES (?, ?, ?, ?, ?, ?)', { G.Get(src).license, plate, m, vehLabel(it), now(), 0 })
    return plate
end
local function villaOf(it) return it.data.prop and G.Housing and G.Housing.Get(it.data.prop) or nil end

-- ce que le joueur possède déjà de cet article
local function ownedCount(license, itemId) local r = DB.one('SELECT COUNT(*) AS n FROM pb_premium_owned WHERE license = ? AND item_id = ?', { license, itemId }) return r and tonumber(r.n) or 0 end
local function limitOf(it) local l = int(it.per_player) if l and l > 0 then return l end return (CAT[it.cat] or {}).limit or 0 end

-- Livraison (après le débit ; un échec rembourse) -----------------------------------------------------------------------------------
local DELIVER = {}
DELIVER.weapon = function(src, it)
    local item = ensureWeapon(it)
    if not item then return nil, 'Arme mal réglée dans le catalogue (hash WEAPON_…).' end
    local o = G.Inv.PlayerOwner(src)
    if not G.Inv.Add(o, item, 1) then return nil, 'Ton sac est plein : fais de la place.' end
    local am, ai = int(it.data.ammo) or 0, tostring(it.data.ammo_item or '')
    if am > 0 and ai ~= '' and G.Inv.Def(ai) then G.Inv.Add(o, ai, am) end
    return { item = item }, 'L\'arme est dans ton sac. Perdue ou saisie, récupère-la dans « Mes achats ».'
end
DELIVER.vehicle = function(src, it)
    local plate, err = giveVehicle(src, it)
    if not plate then return nil, err end
    return { plate = plate, model = it.data.model }, ('Véhicule livré à ton garage (plaque %s).'):format(plate)
end
DELIVER.vip = function(src, it)
    if not G.Vip then return nil, 'VIP indisponible.' end
    local ok, msg = G.Vip.Give(src, int(it.data.days) or 0, 'Boutique')
    if not ok then return nil, msg end
    return { days = int(it.data.days) or 0 }, msg
end
DELIVER.villa = function(src, it)
    local h = villaOf(it)
    if not h then return nil, 'Villa introuvable (catalogue).' end
    local lic = G.Get(src).license
    if (tonumber(DB.exec("UPDATE pb_properties SET owner = ?, since = ?, paid_until = 0, arrears = 0, locked = 1, premium = 1 WHERE id = ? AND owner = ''", { lic, now(), h.id })) or 0) < 1 then
        return nil, 'Cette villa vient d\'être prise.'
    end
    if G.PushConfig then G.PushConfig() end
    return { prop = h.id, x = h.x, y = h.y }, ('« %s » est à toi. Le GPS est dans « Mes achats ».'):format(h.label)
end
DELIVER.money = function(src, it)
    local a = int(it.data.amount) or 0
    if a <= 0 then return nil, 'Montant mal réglé (catalogue).' end
    G.AddMoney(src, 'bank', a, 'Boutique : ' .. it.label)
    return { amount = a }, money(a) .. ' versés sur ton compte en banque.'
end
DELIVER.item = function(src, it)
    local name, q = tostring(it.data.item or ''), math.max(1, int(it.data.qty) or 1)
    if not G.Inv.Def(name) then return nil, 'Objet inconnu (catalogue).' end
    local o = G.Inv.PlayerOwner(src)
    local ok = G.Inv.CanCarry(o, name, q)
    if not ok or not G.Inv.Add(o, name, q) then return nil, 'Ton sac est plein : fais de la place.' end
    return { item = name, qty = q }, ('%d × %s ajouté(s) à ton sac.'):format(q, G.Inv.Def(name).label or name)
end
-- plaque : mêmes règles que le changement de plaque du garage (le coffre, les clés et le compteur suivent)
local function plateCheck(src, p)
    local Gr = G.Garage
    if not (Gr and Gr.Vehicle and Gr.PlateOk and Gr.Rename) then return nil, 'Garage indisponible.' end
    local v = Gr.Vehicle(tostring(p.vplate or ''))
    if not v or v.license ~= G.Get(src).license then return nil, 'Choisis un de tes véhicules.' end
    if v.state ~= 'garage' then return nil, 'Range d\'abord ce véhicule au garage.' end
    local new, err = Gr.PlateOk(p.text)
    if not new then return nil, err end
    return v, new
end
DELIVER.plate = function(src, it, p)
    local v, new = plateCheck(src, p)
    if not v then return nil, new end
    if not G.Garage.Rename(v.plate, new) then return nil, 'Changement impossible.' end
    return { old = v.plate, plate = new }, ('Nouvelle plaque : %s.'):format(new)
end

-- Boost : bonus temporaire (paie, missions) du compte ; racheter le même boost prolonge sa durée
DELIVER.boost = function(src, it)
    local lic = account(src)
    local kind = BOOSTS[it.data.kind] and it.data.kind or 'pay'
    local pct = math.max(1, math.min(200, int(it.data.pct) or 10))
    local hours = math.max(1, math.min(720, int(it.data.hours) or 24))
    local r = DB.one('SELECT pct, until_at FROM pb_premium_boosts WHERE license = ? AND kind = ?', { lic, kind })
    local base = (r and (tonumber(r.until_at) or 0) > now()) and tonumber(r.until_at) or now()
    local untilAt = base + hours * 3600
    pct = math.max(pct, r and (tonumber(r.until_at) or 0) > now() and tonumber(r.pct) or 0)
    DB.exec('INSERT INTO pb_premium_boosts (license, kind, pct, until_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE pct = VALUES(pct), until_at = VALUES(until_at)', { lic, kind, pct, untilAt })
    return { kind = kind, pct = pct, hours = hours, until_at = untilAt }, ('Boost %s +%d %% actif jusqu\'au %s.'):format(BOOSTS[kind]:lower(), pct, os.date('%d/%m à %H:%M', untilAt))
end
function Pm.Boosts(license)
    local out = {}
    for _, r in ipairs(DB.q('SELECT kind, pct, until_at FROM pb_premium_boosts WHERE license = ? AND until_at > ?', { license, now() }) or {}) do out[#out + 1] = { kind = r.kind, label = BOOSTS[r.kind] or r.kind, pct = tonumber(r.pct), left = tonumber(r.until_at) - now() } end
    return out
end
-- bonus versé en plus (création monétaire, jamais pris sur une caisse) : appelé par la paie (biz.lua) et les missions (civil.lua)
function Pm.Boost(src, kind, amount)
    amount = math.floor(tonumber(amount) or 0)
    local lic = account(src)
    if amount <= 0 or not lic then return 0 end
    local r = DB.one('SELECT pct FROM pb_premium_boosts WHERE license = ? AND kind = ? AND until_at > ?', { lic, kind, now() })
    if not r then return 0 end
    local bonus = math.floor(amount * (tonumber(r.pct) or 0) / 100)
    if bonus <= 0 then return 0 end
    G.AddMoney(src, 'bank', bonus, 'Boost ' .. (BOOSTS[kind] or kind))
    G.Notify(src, { type = 'success', title = 'Boost', text = ('Bonus %s +%d %% : %s'):format((BOOSTS[kind] or kind):lower(), tonumber(r.pct) or 0, money(bonus)) })
    return bonus
end

-- Offres du jour : une sélection qui change à minuit (même pour tous), prix réduit, un achat par joueur et par jour
local DAILY_CATS = { weapon = true, vehicle = true, money = true, item = true, boost = true }
PB.Migrate('530_no_crates', 'Boutique : caisses mystère retirées', { "DELETE FROM pb_premium_items WHERE cat = 'crate'" })
local function dayKey(t) return tonumber(os.date('%Y%m%d', t or now())) end
function Pm.ResetIn() local t = os.date('*t', now()) return (24 - t.hour) * 3600 - t.min * 60 - t.sec end
function Pm.Daily(day)
    day = day or dayKey()
    local pool = {}
    for _, it in ipairs(Pm.Items()) do if DAILY_CATS[it.cat] and it.data.daily ~= false and it.price > 0 then pool[#pool + 1] = it end end
    table.sort(pool, function(a, b) return a.id < b.id end)
    -- tirage déterministe (graine = date du jour) : tout le serveur voit les mêmes offres, sans toucher au hasard global
    local seed = (day * 7919 + (int(cfg('daily_salt', 0)) or 0) * 104729) % 2147483647
    local function rnd(n) seed = (seed * 48271) % 2147483647 return seed % n + 1 end
    local out, n = {}, math.max(1, math.min(8, int(cfg('daily_count', 4)) or 4))
    while #out < n and #pool > 0 do out[#out + 1] = table.remove(pool, rnd(#pool)) end
    return out
end
function Pm.DailyPrice(it) return math.max(1, math.floor(Pm.PriceOf(it) * (100 - math.max(0, math.min(90, int(cfg('daily_discount', 25)) or 25))) / 100)) end
local function inDaily(id) for _, it in ipairs(Pm.Daily()) do if it.id == id then return it end end end
local function boughtToday(lic, id) return DB.one('SELECT item_id FROM pb_premium_daily WHERE license = ? AND day = ? AND item_id = ?', { lic, dayKey(), id }) ~= nil end


-- vérifications avant de débiter (rien n'est retiré si l'achat ne peut pas aboutir)
local function precheck(src, it, p)
    if it.cat == 'villa' then
        local h = villaOf(it)
        if not h then return false, 'Villa introuvable.' end
        if h.owner ~= '' then return false, 'Cette villa est déjà prise.' end
    elseif it.cat == 'plate' then
        local v, err = plateCheck(src, p)
        if not v then return false, err end
    elseif it.cat == 'item' or it.cat == 'weapon' then
        local o = G.Inv.PlayerOwner(src)
        local name = it.cat == 'weapon' and ensureWeapon(it) or tostring(it.data.item or '')
        if not name or not G.Inv.Def(name) then return false, 'Article mal réglé : préviens le staff.' end
        local ok = G.Inv.CanCarry(o, name, it.cat == 'item' and math.max(1, int(it.data.qty) or 1) or 1)
        if not ok then return false, 'Ton sac est plein : fais de la place.' end
    end
    return true
end

-- articles qui s'achètent en plusieurs exemplaires d'un coup (les autres : un seul)
local BUY_MANY, MAX_QTY = { money = true, item = true, boost = true }, 5
local busy = {}
function Pm.Buy(src, id, p)
    p = type(p) == 'table' and p or {}
    if cfg('enabled', true) == false then return false, 'La boutique est fermée.' end
    local pl, lic = G.Get(src), account(src)
    if not pl or not lic or not PB.ToBool(pl.row.created) then return false, 'Crée d\'abord ton personnage.' end
    local it = Pm.Item(id)
    if not it or not it.enabled or not CAT[it.cat] then return false, 'Article introuvable.' end
    local daily = p.daily == true
    if daily then
        if not inDaily(it.id) then return false, "Cette offre du jour est terminée : la boutique s'est renouvelée." end
        if boughtToday(lic, it.id) then return false, "Déjà acheté aujourd'hui : reviens demain." end
        p.gift = nil
    end
    if it.stock >= 0 and it.sold >= it.stock then return false, 'Article épuisé.' end
    -- cadeau : l'article est livré à un autre joueur connecté (ID permanent) ; c'est l'acheteur qui paie
    local to = src
    if p.gift ~= nil and p.gift ~= '' then
        if it.cat == 'plate' then return false, 'Une plaque personnalisée ne s\'offre pas.' end
        to = G.SrcOfUid(p.gift)
        local tp = to and G.Get(to)
        if not tp or not PB.ToBool(tp.row.created) then return false, 'Aucun joueur connecté avec cet ID.' end
        if to == src then return false, 'Pour toi, utilise « Acheter ».' end
    end
    local toLic, toPl = account(to), G.Get(to)
    local lim = limitOf(it)
    if lim > 0 and ownedCount(toLic, it.id) >= lim then
        if to ~= src then return false, display(to) .. ' possède déjà cet article.' end
        return false, lim == 1 and 'Tu possèdes déjà cet article.' or ('Maximum %d par joueur.'):format(lim)
    end
    if busy[src] then return false, 'Achat déjà en cours.' end
    if not DELIVER[it.cat] then return false, 'Article indisponible.' end
    local ok, why = precheck(to, it, p)
    if not ok then return false, to ~= src and (display(to) .. ' : ' .. tostring(why)) or why end
    local price = daily and Pm.DailyPrice(it) or Pm.PriceOf(it)
    if Pm.Balance(lic) < price then return false, ('Il te faut %s (tu as %s).'):format(coins(price), coins(Pm.Balance(lic))) end
    busy[src] = true
    local label = to ~= src and (it.label .. ' (offert à ' .. display(to) .. ')') or it.label
    local done, res, msg = pcall(function()
        if not debit(lic, price, label) then return nil, 'Solde insuffisant.' end
        local data, m = DELIVER[it.cat](to, it, p)
        if not data then refund(lic, price, label) return nil, m end
        return data, m
    end)
    busy[src] = nil
    if not done then print('[pb_panel] boutique : ' .. tostring(res)) refund(lic, price, label) return false, 'Erreur : coins remboursés.' end
    if not res then pushBalance(lic) return false, msg end
    if to ~= src then res.from = display(src) end
    DB.insert('INSERT INTO pb_premium_owned (license, char_license, item_id, cat, label, data, price, at, claimed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { toLic, toPl.license, it.id, it.cat, it.label, PB.Json(res), price, now(), now() })
    DB.exec('UPDATE pb_premium_items SET sold = sold + 1 WHERE id = ?', { it.id })
    if daily then DB.exec('INSERT IGNORE INTO pb_premium_daily (license, day, item_id, at) VALUES (?, ?, ?, ?)', { lic, dayKey(), it.id, now() }) end
    invalidate()
    PB.Audit.Log('boutique', to ~= src and 'premium.gift' or 'premium.buy', src, display(src) .. ' ' .. G.Tag(src), nil, nil, { item = it.label, cat = it.cat, price = price, daily = daily or nil, to = to ~= src and (display(to) .. ' ' .. G.Tag(to)) or nil, data = res })
    pushBalance(lic)
    if to ~= src then
        G.Notify(to, { type = 'success', title = cfg('name', 'Boutique'), text = ('%s t\'offre « %s » ! %s'):format(display(src), it.label, tostring(msg)), duration = 12000 })
        return true, ('« %s » offert à %s. Merci !'):format(it.label, display(to))
    end
    return true, it.label .. ' : ' .. tostring(msg)
end

-- Plusieurs exemplaires : autant d'achats normaux (chacun vérifie le solde, le stock et la place, et se rembourse s'il échoue)
function Pm.BuyMany(src, id, p)
    p = type(p) == 'table' and p or {}
    local it = Pm.Item(id)
    local n = math.floor(tonumber(p.qty) or 1)
    p.qty = nil
    if not it or not BUY_MANY[it.cat] or limitOf(it) > 0 or p.daily == true then n = 1 end
    n = math.max(1, math.min(MAX_QTY, n))
    local done, last = 0, nil
    for _ = 1, n do
        local ok, msg = Pm.Buy(src, id, p)
        if not ok then
            if done == 0 then return false, msg end
            return true, ('%d sur %d achetés. %s'):format(done, n, tostring(msg))
        end
        done, last = done + 1, msg
    end
    if done > 1 then return true, ('%s × %d achetés.'):format(it.label, done) end
    return true, last
end

-- « Mes achats » : récupérer une arme ou un véhicule disparu, GPS de la villa
local function ownedRow(src, oid)
    local r = DB.one('SELECT * FROM pb_premium_owned WHERE id = ? AND license = ?', { int(oid) or 0, account(src) })
    if r then r.data = PB.FromJson(r.data or '', {}) or {} end
    return r
end
local function claimWait(r) local w = math.floor((tonumber(cfg('claim_hours', 6)) or 6) * 3600) return math.max(0, (tonumber(r.claimed_at) or 0) + w - now()) end
local function waitText(s) local h, m = s // 3600, (s % 3600) // 60 return h > 0 and ('%d h %02d'):format(h, m) or ('%d min'):format(math.max(1, m)) end
function Pm.Claim(src, oid)
    local r = ownedRow(src, oid)
    if not r then return false, 'Achat introuvable.' end
    local it = Pm.Item(r.item_id)
    if r.cat == 'weapon' then
        if not it then return false, 'Cette arme n\'est plus au catalogue : contacte le staff.' end
        local item = ensureWeapon(it)
        local o = G.Inv.PlayerOwner(src)
        if not item then return false, 'Arme mal réglée : préviens le staff.' end
        if (G.Inv.Count(o, item) or 0) > 0 then return false, 'Tu l\'as déjà sur toi.' end
        local w = claimWait(r) if w > 0 then return false, 'Récupération possible dans ' .. waitText(w) .. '.' end
        if not G.Inv.CanCarry(o, item, 1) or not G.Inv.Add(o, item, 1) then return false, 'Ton sac est plein.' end
        DB.exec('UPDATE pb_premium_owned SET claimed_at = ? WHERE id = ?', { now(), r.id })
        PB.Audit.Log('boutique', 'premium.claim', src, display(src) .. ' ' .. G.Tag(src), nil, nil, { item = r.label })
        return true, r.label .. ' récupérée : elle est dans ton sac.'
    elseif r.cat == 'vehicle' then
        if r.data.plate and DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { r.data.plate }) then return false, ('Ton véhicule existe toujours (plaque %s) : regarde au garage ou à la fourrière.'):format(r.data.plate) end
        if not it then return false, 'Ce véhicule n\'est plus au catalogue : contacte le staff.' end
        local w = claimWait(r) if w > 0 then return false, 'Nouvelle livraison possible dans ' .. waitText(w) .. '.' end
        local plate, err = giveVehicle(src, it)
        if not plate then return false, err end
        r.data.plate = plate
        DB.exec('UPDATE pb_premium_owned SET claimed_at = ?, data = ? WHERE id = ?', { now(), PB.Json(r.data), r.id })
        PB.Audit.Log('boutique', 'premium.claim', src, display(src) .. ' ' .. G.Tag(src), nil, nil, { item = r.label, plate = plate })
        return true, ('Véhicule relivré à ton garage (plaque %s).'):format(plate)
    elseif r.cat == 'villa' then
        local h = G.Housing and G.Housing.Get(r.data.prop)
        if not h then return false, 'Villa introuvable.' end
        TriggerClientEvent('pb:g:premium:gps', src, h.x, h.y)
        return true, 'GPS réglé sur « ' .. h.label .. ' ».'
    end
    return false, 'Rien à récupérer pour cet achat.'
end

-- plaque changée (garage, plaque personnalisée) : l'achat suit la nouvelle plaque, sinon « Récupérer » croyait le véhicule disparu
-- et en livrait un deuxième
AddEventHandler('pb_panel:plateChanged', function(old, new)
    old, new = tostring(old or ''), tostring(new or '')
    if old == '' or new == '' then return end
    for _, r in ipairs(DB.q("SELECT id, data FROM pb_premium_owned WHERE cat = 'vehicle' AND data LIKE ?", { '%' .. old .. '%' }) or {}) do
        local d = PB.FromJson(r.data or '', {}) or {}
        if d.plate == old then d.plate = new DB.exec('UPDATE pb_premium_owned SET data = ? WHERE id = ?', { PB.Json(d), r.id }) end
    end
end)

-- Vue envoyée à l'interface -----------------------------------------------------------------------------------------------------------
local function cardOf(it, lic, mineCount)
    local img = it.image ~= '' and it.image or nil
    if not img and it.cat == 'vehicle' and tostring(it.data.model or ''):match('^[%w_]+$') then img = 'https://docs.fivem.net/vehicles/' .. tostring(it.data.model):lower() .. '.webp' end
    if not img and it.cat == 'weapon' then img = weaponImage(it) end
    if not img and it.cat == 'item' and G.Inv.Def(tostring(it.data.item or '')) then img = G.Inv.Image(G.Inv.Def(it.data.item)) end
    local lim = limitOf(it)
    local c = { id = it.id, cat = it.cat, label = it.label, descr = it.descr, price = Pm.PriceOf(it), img = img, icon = (CAT[it.cat] or {}).icon }
    if c.price < it.price then c.was, c.promo, c.until_at = it.price, int(it.promo_pct), int(it.promo_until) end
    if it.cat ~= 'plate' then c.gift = true end
    -- pour les fiches techniques calculées par le jeu (client) : modèle du véhicule, arme
    if it.cat == 'vehicle' then c.model = tostring(it.data.model or '') end
    if it.cat == 'weapon' then c.hash = tostring(it.data.hash or '') end
    if it.stock >= 0 then c.stock = math.max(0, it.stock - it.sold) end
    if lim > 0 and (mineCount[it.id] or 0) >= lim then c.owned = true end
    if it.cat == 'villa' then local h = villaOf(it) if not h then c.off = true elseif h.owner ~= '' then c.taken = true end end
    if it.cat == 'vip' then c.sub = (int(it.data.days) or 0) == 0 and 'À vie' or ((int(it.data.days)) .. ' jours') end
    if it.cat == 'money' then c.sub = money(it.data.amount) end
    if it.cat == 'item' then c.sub = (math.max(1, int(it.data.qty) or 1)) .. ' × ' .. tostring((G.Inv.Def(tostring(it.data.item or '')) or {}).label or it.data.item or '') end
    if it.cat == 'boost' then c.sub = ('%s +%d %% · %d h'):format(BOOSTS[it.data.kind] or 'Paie', int(it.data.pct) or 10, int(it.data.hours) or 24) end
    c.rarity = rarityOf(it).id
    -- contenu affiché sur la fiche ; « ; » dans la description : une ligne par élément
    local incl = {}
    if it.cat == 'vehicle' then incl = { 'Véhicule : ' .. vehLabel(it), 'Livré à ton garage', 'Récupérable dans « Mes achats »' }
    elseif it.cat == 'weapon' then
        incl = { 'Arme : ' .. it.label, 'Récupérable si perdue ou saisie' }
        if (int(it.data.ammo) or 0) > 0 then incl[#incl + 1] = int(it.data.ammo) .. ' munitions' end
    elseif it.cat == 'villa' then incl = { 'Sans impôt ni loyer', 'Intérieur et meubles au choix', 'GPS dans « Mes achats »' }
    elseif it.cat == 'plate' then incl = { 'Texte de ton choix (8 caractères)', "Le coffre et les clés suivent" }
    elseif c.sub then incl = { (it.cat == 'money' and (c.sub .. ' en banque')) or (it.cat == 'vip' and ('VIP : ' .. c.sub)) or c.sub } end
    if tostring(it.descr or ''):find(';', 1, true) then
        for part in tostring(it.descr):gmatch('[^;]+') do
            local t = part:gsub('^%s+', ''):gsub('%s+$', '')
            if t ~= '' then incl[#incl + 1] = t end
        end
        c.descr_in_list = true
    end
    c.incl = incl
    if BUY_MANY[it.cat] and lim == 0 then c.maxq = math.min(MAX_QTY, c.stock or MAX_QTY) end
    return c
end
function Pm.View(src)
    local lic, pl = account(src), G.Get(src)
    local mineCount, owned = {}, {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_premium_owned WHERE license = ? ORDER BY id DESC LIMIT 100', { lic }) or {}) do
        mineCount[r.item_id] = (mineCount[r.item_id] or 0) + 1
        local d = PB.FromJson(r.data or '', {}) or {}
        local o = { id = r.id, cat = r.cat, label = r.label, at = r.at, price = r.price, from = d.from and clean(d.from, 60) or nil }
        if r.cat == 'weapon' then
            local w = claimWait(r)
            o.info = 'Arme permanente' o.act = 'Récupérer' o.wait = w > 0 and waitText(w) or nil
        elseif r.cat == 'vehicle' then
            -- « Récupérer » seulement si le véhicule n'existe plus (supprimé) ; sinon on dit où il est
            local exists = d.plate and DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { d.plate })
            o.info = 'Plaque ' .. tostring(d.plate or '?') .. (exists and ' · garage ou fourrière' or ' · véhicule disparu')
            if not exists then local w = claimWait(r) o.act = 'Récupérer' o.wait = w > 0 and waitText(w) or nil end
        elseif r.cat == 'villa' then o.info = 'Villa' o.act = 'GPS'
        elseif r.cat == 'vip' then o.info = (tonumber(d.days) or 0) == 0 and 'VIP à vie' or ('VIP ' .. tostring(d.days) .. ' jours')
        elseif r.cat == 'money' then o.info = money(d.amount)
        elseif r.cat == 'plate' then o.info = tostring(d.old or '') .. ' → ' .. tostring(d.plate or '')
        elseif r.cat == 'item' then o.info = tostring(d.qty or 1) .. ' × ' .. tostring(d.item or '') end
        owned[#owned + 1] = o
    end
    local items = {}
    for _, it in ipairs(Pm.Items()) do items[#items + 1] = cardOf(it, lic, mineCount) end
    local hist = {}
    for _, t in ipairs(DB.q('SELECT delta, kind, label, at FROM pb_coin_tx WHERE license = ? ORDER BY id DESC LIMIT 30', { lic }) or {}) do hist[#hist + 1] = { d = t.delta, k = t.kind, l = t.label, at = t.at } end
    local vehs = {}
    for _, v in ipairs(DB.q('SELECT plate, label, model FROM pb_vehicles WHERE license = ? ORDER BY id LIMIT 40', { pl and pl.license or '' }) or {}) do vehs[#vehs + 1] = { plate = v.plate, label = v.label ~= '' and v.label or v.model } end
    local cats = {}
    for _, c in ipairs(Pm.CATS) do cats[#cats + 1] = { id = c.id, label = c.label, icon = c.icon, sub = c.sub } end
    -- offres du jour
    local daily = {}
    for _, it in ipairs(Pm.Daily()) do
        local c = cardOf(it, lic, mineCount)
        c.was, c.price, c.daily = Pm.PriceOf(it), Pm.DailyPrice(it), true
        c.bought = boughtToday(lic, it.id) or nil
        c.gift = nil
        daily[#daily + 1] = c
    end
    local rar = {}
    for _, r in ipairs(Pm.RARITY) do rar[#rar + 1] = { id = r[1], label = r[2], color = r[3] } end
    local vip = G.Vip and G.Vip.Until and G.Vip.Until(src)
    return { name = cfg('name', 'Boutique'), coin = cfg('coin', 'Coins'), url = cfg('store_url', ''), coins = Pm.Balance(lic), who = display(src), id = G.UidOf(src),
        cats = cats, items = items, owned = owned, hist = hist, vehs = vehs, hours = tonumber(cfg('claim_hours', 6)) or 6,
        daily = daily, reset_in = Pm.ResetIn(), daily_pct = int(cfg('daily_discount', 25)) or 25, rarity = rar, boosts = Pm.Boosts(lic), accent = cfg('accent', ''),
        vip = vip and { on = true, life = vip == true or (tonumber(vip) or 0) == 0, until_at = (tonumber(vip) or 0) > 0 and tonumber(vip) or nil } or nil }
end

-- Réseau --------------------------------------------------------------------------------------------------------------------------------
local last = {}
local function slow(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return true end last[src] = t return false end
AddEventHandler('playerDropped', function() last[source] = nil busy[source] = nil end)
local function send(src, ev, extra) local m = { ev = ev, d = Pm.View(src) } for k, v in pairs(extra or {}) do m[k] = v end TriggerClientEvent('pb:g:premium:ui', src, PB.Json(m)) end
RegisterNetEvent('pb:g:premium:open', function()
    local src = source
    if slow(src, 600) or not G.Get(src) then return end
    if cfg('enabled', true) == false then G.Notify(src, { type = 'warn', text = 'La boutique est fermée.' }) return end
    send(src, 'open')
end)
RegisterNetEvent('pb:g:premium:buy', function(id, p)
    local src = source
    if slow(src, 900) then return end
    local ok, msg = Pm.BuyMany(src, id, p)
    send(src, 'result', { ok = ok, msg = msg })
end)
RegisterNetEvent('pb:g:premium:claim', function(oid)
    local src = source
    if slow(src, 900) then return end
    local ok, msg = Pm.Claim(src, oid)
    send(src, 'result', { ok = ok, msg = msg })
end)
RegisterCommand('boutique', function(src) if src > 0 then TriggerClientEvent('pb:g:premium:key', src) end end, false)
RegisterCommand('coins', function(src)
    if src <= 0 or not G.Get(src) then return end
    G.Notify(src, { type = 'info', title = cfg('name', 'Boutique'), text = 'Ton solde : ' .. coins(Pm.Balance(account(src))) .. '. Ouvre la boutique avec /boutique.' })
end, false)

-- Console (boutique en ligne / Tebex) -------------------------------------------------------------------------------------------------
-- shadowcoins add <cible> <montant> [référence]   cible = ID permanent (12), sid:<ID de connexion> ou license:xxxx
-- shadowcoins remove <cible> <montant> [motif]    (remboursement / litige bancaire)
-- shadowcoins show <cible>
local function resolve(t)
    t = tostring(t or '')
    local sid = t:match('^sid:(%d+)$')
    if sid then return account(tonumber(sid)) end
    if t:match('^license:%x+$') then return t end
    local uid = tonumber(t)
    if uid and G.Uid then return G.Uid.LicenseOf(uid) end
    return nil
end
Pm.Resolve = resolve
RegisterCommand('shadowcoins', function(src, args)
    if src ~= 0 then return end   -- console du serveur uniquement (la boutique en ligne passe par là)
    local op, lic = tostring(args[1] or ''), resolve(args[2])
    local function out(m) print('[boutique] ' .. m) end
    if op == '' or not lic then out('Usage : shadowcoins add|remove|show <ID permanent | sid:<id> | license:xxx> <montant> [référence]') return end
    if op == 'show' then out(lic .. ' : ' .. coins(Pm.Balance(lic))) return end
    local n = int(args[3])
    if not n or n <= 0 then out('Montant invalide.') return end
    local ok, msg
    if op == 'add' then ok, msg = Pm.Credit(lic, n, 'credit', 'Achat boutique en ligne', args[4], 'Boutique en ligne')
    elseif op == 'remove' then ok, msg = Pm.Credit(lic, -n, 'staff', 'Retrait : ' .. table.concat(args, ' ', 4), nil, 'Console')
    else out('Opération inconnue : ' .. op) return end
    out((ok and 'OK ' or 'REFUSÉ ') .. tostring(msg))
end, true)

-- Démarrage : catalogue d'exemple (une seule fois) et armes liées --------------------------------------------------------------------
local SEED = {
    { 'weapon', 'Pistolet .50', 'Pistolet lourd, toujours à toi.', 1200, { hash = 'WEAPON_PISTOL50', ammo_item = 'ammo_pistol', ammo = 4 }, 10 },
    { 'weapon', 'Revolver lourd', 'Le revolver des connaisseurs.', 1500, { hash = 'WEAPON_REVOLVER', ammo_item = 'ammo_pistol', ammo = 4 }, 11 },
    { 'weapon', 'Couteau papillon', 'Discret et permanent.', 400, { hash = 'WEAPON_SWITCHBLADE' }, 12 },
    { 'vehicle', 'Pegassi Zentorno', 'Supercar, livrée au garage.', 3500, { model = 'zentorno' }, 20 },
    { 'vehicle', 'Obey 10F', 'Sportive élégante.', 2200, { model = 'tenf' }, 21 },
    { 'vehicle', 'Pegassi Bati 801', 'Moto sportive.', 900, { model = 'bati' }, 22 },
    { 'vip', 'VIP 30 jours', 'Tous les avantages VIP pendant 30 jours.', 800, { days = 30 }, 30 },
    { 'vip', 'VIP 90 jours', '3 mois de VIP.', 2000, { days = 90 }, 31 },
    { 'vip', 'VIP à vie', 'Le VIP pour toujours.', 6000, { days = 0 }, 32 },
    { 'money', '50 000 $', 'Versés sur ton compte en banque.', 300, { amount = 50000 }, 50 },
    { 'money', '250 000 $', 'Versés sur ton compte en banque.', 1300, { amount = 250000 }, 51 },
    { 'plate', 'Plaque personnalisée', 'Change le texte de la plaque d\'un de tes véhicules.', 250, {}, 70 },
}
PB.OnReady(function()
    if not cfg('seeded', false) then
        if not DB.one('SELECT id FROM pb_premium_items LIMIT 1') then
            for _, s in ipairs(SEED) do DB.insert('INSERT INTO pb_premium_items (cat, label, descr, price, data, sort) VALUES (?, ?, ?, ?, ?, ?)', { s[1], s[2], s[3], s[4], PB.Json(s[5]), s[6] }) end
        end
        PB.Cfg.Set('premium', 'seeded', true, nil, 'Boutique : catalogue d\'exemple')
        invalidate()
    end
    -- nouveautés : boosts d'exemple (une seule fois)
    if not cfg('seeded2', false) then
        local function add(cat, label, descr, price, data, sort) return DB.insert('INSERT INTO pb_premium_items (cat, label, descr, price, data, sort) VALUES (?, ?, ?, ?, ?, ?)', { cat, label, descr, price, PB.Json(data), sort }) end
        add('boost', 'Boost de paie +25 %', 'Ta paie augmente de 25 % pendant 24 heures.', 200, { kind = 'pay', pct = 25, hours = 24, rarity = 'rare' }, 80)
        add('boost', 'Boost de paie +50 %', 'Ta paie augmente de 50 % pendant 3 jours.', 650, { kind = 'pay', pct = 50, hours = 72, rarity = 'epique' }, 81)
        add('boost', 'Boost de missions +50 %', 'Les missions des métiers civils rapportent 50 % de plus pendant 24 heures.', 250, { kind = 'mission', pct = 50, hours = 24, rarity = 'rare' }, 82)
        invalidate()
        PB.Cfg.Set('premium', 'seeded2', true, nil, 'Boutique : boosts d\'exemple')
        invalidate()
    end
    bindAll()
end)

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
local CAT_OPTS = {} for _, c in ipairs(Pm.CATS) do CAT_OPTS[#CAT_OPTS + 1] = { c.id, c.label } end
local RAR_OPTS = {} for _, r in ipairs(Pm.RARITY) do RAR_OPTS[#RAR_OPTS + 1] = { r[1], r[2] } end
-- (v1.2.45) Ajouter un article : la catégorie, puis le choix dans la liste complète (photos), puis le prix. Rien à taper à la main.
local function fmtN(n) return fmt(n) end
local PICKS = {}
Pm.PICKS = PICKS
PICKS.vehicle = function()
    local out, mil = {}, {}
    for _, c in ipairs(G.VehCat and G.VehCat.classes or {}) do if c.kind == 'mil' then mil[c.id] = true end end
    for _, v in ipairs(G.VehCat and G.VehCat.Effective and G.VehCat.Effective() or {}) do
        if not mil[v.class] then out[#out + 1] = { key = v.model, title = v.label, sub = v.class, group = v.class, img = 'https://docs.fivem.net/vehicles/' .. v.model .. '.webp', fill = { label = v.label, descr = 'Livré à ton garage, à toi pour toujours.', model = v.model } } end
    end
    -- (v1.2.46) véhicules addon installés sur le serveur : donne-leur ton nom à l'étape suivante
    for _, v in ipairs(G.TpPlaces and G.TpPlaces.AddonVehicles and G.TpPlaces.AddonVehicles() or {}) do
        out[#out + 1] = { key = v.model, title = v.label, sub = v.model .. ' · ' .. v.res, group = 'Véhicules addon', icon = 'car', fill = { label = v.label, descr = 'Livré à ton garage, à toi pour toujours.', model = v.model } }
    end
    return out
end
PICKS.weapon = function()
    local out, seen = {}, {}
    local function add(name, label, group, ammo)
        local base = tostring(name or ''):lower():match('^weapon_([%w_]+)$')
        if not base or seen[base] or base:find('_perm', 1, true) then return end
        seen[base] = true
        local hash = 'WEAPON_' .. base:upper()
        ammo = tostring(ammo or '')
        local def = G.Inv and G.Inv.Def('weapon_' .. base)
        local vanilla = G.OxImage and G.OxImage('weapon_' .. base)
        if not vanilla then group = 'Armes addon' end
        out[#out + 1] = { key = hash, title = tostring(label or hash), sub = group, group = group, img = vanilla or (def and G.Inv.Image(def)) or nil,
            fill = { label = tostring(label or hash), descr = 'Arme permanente : perdue ou saisie, tu la récupères dans « Mes achats ».', hash = hash, ammo_item = ammo, ammo = ammo ~= '' and 4 or 0 } }
    end
    for _, w in ipairs(G.AllWeapons or {}) do if w.type == 'weapon' then add(w.name, w.label, w.category or 'Armes', w.ammo_item) end end
    for _, w in ipairs(G.Weapons and G.Weapons.Catalog and G.Weapons.Catalog() or {}) do add(w.item, w.label, 'Armes du serveur', w.ammo_item) end
    -- armes addon qui ne sont que des objets du sac (packs)
    for name, d in pairs(G.Inv and G.Inv.Defs and G.Inv.Defs() or {}) do
        if d.kind == 'weapon' and tostring(name):lower():find('^weapon_') then add(name, d.label, 'Armes addon', '') end
    end
    table.sort(out, function(x, y) return x.title:lower() < y.title:lower() end)
    return out
end
PICKS.item = function()
    local out = {}
    for _, e in ipairs(G.Staff and G.Staff.ItemList and G.Staff.ItemList() or {}) do
        local d = G.Inv.Def(e[1])
        if d and d.kind ~= 'weapon' then
            out[#out + 1] = { key = e[1], title = e[2], sub = e[3], group = e[3], img = G.Inv.Image(d), fill = { label = e[2], descr = e[4] ~= '' and e[4] or 'Ajouté au sac du personnage joué.', item = e[1], qty = 1 } }
        end
    end
    return out
end
PICKS.villa = function()
    local out = {}
    for _, h in ipairs(G.Housing and G.Housing.All and G.Housing.All() or {}) do
        if (h.owner or '') == '' or PB.ToBool(h.premium) then out[#out + 1] = { key = h.id, title = h.label, sub = (h.owner or '') ~= '' and 'Déjà vendue' or 'Libre', icon = 'home', fill = { label = h.label, descr = 'Sans impôt ni loyer, intérieur et meubles au choix.', prop = h.id } } end
    end
    return out
end
PICKS.vip = function()
    local out = {}
    for _, d in ipairs({ 7, 30, 90, 180, 365, 0 }) do
        local t = d == 0 and 'VIP à vie' or ('VIP ' .. d .. ' jours')
        out[#out + 1] = { key = 'days' .. d, title = t, sub = 'Tous les avantages VIP', icon = 'crown', fill = { label = t, descr = d == 0 and 'Le VIP pour toujours.' or ('Tous les avantages VIP pendant ' .. d .. ' jours.'), days = d } }
    end
    return out
end
PICKS.money = function()
    local out = {}
    for _, a in ipairs({ 10000, 25000, 50000, 100000, 250000, 500000, 1000000, 5000000 }) do
        out[#out + 1] = { key = 'amount' .. a, title = money(a), sub = 'Sur le compte en banque', icon = 'coins', fill = { label = money(a), descr = 'Versés sur ton compte en banque.', amount = a } }
    end
    return out
end
PICKS.boost = function()
    local out = {}
    for _, k in ipairs({ { 'pay', 'paie', 'Ta paie augmente' }, { 'mission', 'missions', 'Les missions des métiers civils rapportent plus' } }) do
        for _, b in ipairs({ { 25, 24 }, { 50, 24 }, { 50, 72 }, { 100, 24 }, { 100, 168 } }) do
            local t = ('Boost de %s +%d %%'):format(k[2], b[1])
            out[#out + 1] = { key = k[1] .. b[1] .. '_' .. b[2], title = t, sub = b[2] .. ' heures', group = 'Boost de ' .. k[2], icon = 'bolt',
                fill = { label = t, descr = ('%s pendant %d heures.'):format(k[3], b[2]), boost_kind = k[1], boost_pct = b[1], boost_hours = b[2] } }
        end
    end
    return out
end
Pm.PICKS = PICKS
local function pickOf(cat, key)
    if not PICKS[cat] then return nil end
    for _, x in ipairs(PICKS[cat]()) do if tostring(x.key) == tostring(key) then return x end end
end
-- photo d'un article (celle montrée aux joueurs, sauf image choisie)
local function autoImage(cat, d)
    if cat == 'vehicle' and tostring(d.model or ''):match('^[%w_]+$') then return 'https://docs.fivem.net/vehicles/' .. tostring(d.model):lower() .. '.webp' end
    if cat == 'weapon' then return weaponImage({ data = d }) end
    if cat == 'item' and G.Inv.Def(tostring(d.item or '')) then return G.Inv.Image(G.Inv.Def(d.item)) end
    return nil
end
local function dataFrom(cat, v)
    if cat == 'weapon' then
        local h = tostring(v.hash or ''):upper()
        if not h:match('^WEAPON_[%w_]+$') then return nil, 'Arme : nom du jeu attendu (ex. WEAPON_PISTOL50).' end
        return { hash = h, ammo_item = clean(v.ammo_item, 40):lower(), ammo = math.max(0, int(v.ammo) or 0) }
    elseif cat == 'vehicle' then
        local m = tostring(v.model or ''):lower()
        if not m:match('^[%w_]+$') then return nil, 'Véhicule : modèle du jeu attendu (ex. zentorno).' end
        return { model = m }
    elseif cat == 'vip' then return { days = math.max(0, math.min(3650, int(v.days) or 0)) }
    elseif cat == 'villa' then
        local id = tostring(v.prop or '')
        local h = G.Housing and G.Housing.Get(id)
        if not h then return nil, 'Villa : identifiant d\'un logement existant (module Logements).' end
        if h.owner ~= '' and not PB.ToBool(h.premium) then return nil, 'Ce logement appartient déjà à quelqu\'un.' end
        DB.exec('UPDATE pb_properties SET premium = 1 WHERE id = ?', { id })   -- plus achetable avec l'argent du jeu
        return { prop = id }
    elseif cat == 'money' then local a = int(v.amount) or 0 if a <= 0 then return nil, 'Montant en $ attendu.' end return { amount = a }
    elseif cat == 'item' then
        local n = tostring(v.item or '')
        if not G.Inv.Def(n) then return nil, 'Objet : nom d\'un objet existant (module Inventaire).' end
        return { item = n, qty = math.max(1, int(v.qty) or 1) }
    elseif cat == 'plate' then return {}
    elseif cat == 'boost' then
        local k = tostring(v.boost_kind or 'pay')
        if not BOOSTS[k] then return nil, 'Boost : type « pay » (paie) ou « mission » (missions).' end
        return { kind = k, pct = math.max(1, math.min(200, int(v.boost_pct) or 25)), hours = math.max(1, math.min(720, int(v.boost_hours) or 24)) }
    end
    return nil, 'Catégorie inconnue.'
end
PB.Action('premium.item.save', 'premium.edit', function(ctx, p)
    local v = p.values or p
    -- catégorie et contenu choisis dans la liste : envoyés à côté du formulaire
    if p.values then for k, x in pairs(p) do if k ~= 'values' and v[k] == nil then v[k] = x end end end
    local cat = tostring(v.cat or '')
    if not CAT[cat] then return false, 'Choisis une catégorie.' end
    local label = clean(v.label, 60) if label == '' then return false, 'Nom obligatoire.' end
    local price = int(v.price) or 0 if price < 1 or price > 1000000 then return false, 'Prix en coins : 1 à 1 000 000.' end
    local img = clean(v.image, 255)
    if img ~= '' and not (img:match('^https://[%w%.%-]+/[%w%./_%-%%]+$') or img:match('^img/[%w/_%-]+%.%a+$')) then return false, 'Image : lien https:// ou chemin img/… .' end
    local data, err = dataFrom(cat, v)
    if not data then return false, err end
    data.rarity = RAR[tostring(v.rarity or '')] and tostring(v.rarity) or 'commun'
    if v.daily == false then data.daily = false end
    local id = int(v.id)
    local before = id and Pm.Item(id)
    -- promotion : pourcentage + durée en jours (0 jour = on garde la date en cours, 0 % = pas de promotion)
    local pct = math.max(0, math.min(90, int(v.promo_pct) or 0))
    local days = math.max(0, math.min(365, int(v.promo_days) or 0))
    local untilAt = pct == 0 and 0 or (days > 0 and (now() + days * 86400) or (before and int(before.promo_until) or 0))
    if pct > 0 and untilAt <= now() then return false, 'Promotion : indique sa durée en jours.' end
    local row = { cat, label, clean(v.descr, 240), price, img, PB.Json(data), math.max(0, int(v.per_player) or 0), int(v.stock) or -1, v.enabled == false and 0 or 1, int(v.sort) or 0, pct, untilAt }
    if before then
        row[#row + 1] = id
        DB.exec('UPDATE pb_premium_items SET cat = ?, label = ?, descr = ?, price = ?, image = ?, data = ?, per_player = ?, stock = ?, enabled = ?, sort = ?, promo_pct = ?, promo_until = ? WHERE id = ?', row)
    else
        DB.insert('INSERT INTO pb_premium_items (cat, label, descr, price, image, data, per_player, stock, enabled, sort, promo_pct, promo_until) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', row)
    end
    invalidate() bindAll()
    ctx.audit('boutique', before and 'premium.item.edit' or 'premium.item.add', label, before and { price = before.price, data = before.data } or nil, { price = price, data = data })
    ctx.toast = 'Article enregistré.'
    return true
end)
PB.Action('premium.item.toggle', 'premium.edit', function(ctx, p)
    local it = Pm.Item(p.id) if not it then return false, 'Introuvable.' end
    DB.exec('UPDATE pb_premium_items SET enabled = ? WHERE id = ?', { it.enabled and 0 or 1, it.id })
    invalidate()
    ctx.audit('boutique', 'premium.item.toggle', it.label, { enabled = it.enabled }, { enabled = not it.enabled })
    ctx.toast = it.enabled and 'Article retiré de la vente (les achats restent).' or 'Article remis en vente.'
    return true
end)
PB.Action('premium.coins.adjust', 'premium.coins', function(ctx, p)
    local v = p.values or p
    local lic = resolve(v.who)
    if not lic then return false, 'Joueur introuvable : ID permanent ou license:… .' end
    local n = int(v.amount) or 0
    if n == 0 then return false, 'Montant non nul attendu (négatif pour retirer).' end
    local why = clean(v.reason, 100) if #why < 3 then return false, 'Motif obligatoire.' end
    local ok, msg = Pm.Credit(lic, n, 'staff', 'Staff : ' .. why, nil, ctx.actor and ctx.actor.name or 'Panel')
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end, { confirm = { title = 'Modifier le solde de coins ?', text = 'Les coins représentent de l\'argent réel : l\'opération est tracée.' } })

local settings = PB.Form.Cfg({ ns = 'premium', id = 'settings', title = 'Réglages de la boutique', perm = 'premium.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Boutique ouverte', default = true },
    { k = 'name', type = 'text', label = 'Nom de la boutique', default = 'Boutique', maxlen = 32 },
    { k = 'coin', type = 'text', label = 'Nom de la monnaie', default = 'Coins', maxlen = 20 },
    { k = 'key', type = 'text', label = 'Touche par défaut', default = 'F11', maxlen = 12, pattern = '^[%w_]*$', hint = 'Chaque joueur peut la changer dans les raccourcis FiveM. Commande : /boutique.' },
    { k = 'store_url', type = 'text', label = 'Adresse de la boutique en ligne (achat des coins)', default = '', maxlen = 120, wide = true, hint = 'Affichée aux joueurs : « Acheter des coins ». Exemple : https://monserveur.tebex.io' },
    { k = 'claim_hours', type = 'number', label = 'Délai entre deux récupérations (heures)', default = 6, min = 0, max = 168, hint = 'Arme permanente perdue, véhicule supprimé : le joueur la récupère dans « Mes achats ».' },
    { k = 'weapon_permit', type = 'toggle', label = 'Les armes de la boutique exigent le permis', default = false },
    { k = 'daily_count', type = 'number', label = 'Offres du jour : nombre d\'articles', default = 4, min = 1, max = 8, hint = 'Tirées chaque jour à minuit parmi les armes, véhicules, argent, objets, boosts et coffres (case « Peut sortir dans les offres du jour »).' },
    { k = 'daily_discount', type = 'number', label = 'Offres du jour : réduction (%)', default = 25, min = 0, max = 90, hint = 'Un achat par joueur et par article, chaque jour.' },
    { k = 'daily_salt', type = 'number', label = 'Offres du jour : changer le tirage (nombre au choix)', default = 0, min = 0, max = 99999, hint = 'Change ce nombre pour obtenir une autre sélection aujourd\'hui.' },
    { k = 'accent', type = 'text', label = 'Couleur de la boutique (#rrggbb, vide = rouge du serveur)', default = '', maxlen = 7, pattern = '^#?%x*$' },
} })

PB.Module({
    id = 'premium', label = 'Boutique (coins)', icon = 'star', group = 'Serveur', order = 62, perm = 'premium.view', hint = 'Coins achetés avec de l\'argent réel, catalogue, achats',
    caps = function()
        return PB.Capsify({
            { 'Boutique en jeu (/boutique, touche ' .. tostring(cfg('key', 'F11')) .. ')', cfg('enabled', true) ~= false and 'ok' or 'off', 'Armes permanentes, véhicules, VIP, villas, argent, objets, plaques.' },
            { 'Crédit automatique (commande console)', 'ok', 'shadowcoins add <ID permanent | sid:<id> | license:…> <montant> <référence>' },
            { 'Adresse de la boutique en ligne', cfg('store_url', '') ~= '' and 'ok' or 'off', cfg('store_url', '') ~= '' and cfg('store_url', '') or 'Renseigne-la dans Réglages.' },
        })
    end,
    doc = "## Boutique (coins)\n" ..
        "Les **coins** s'achètent uniquement avec de l'argent réel, hors du jeu. Rien dans le jeu ne transforme de l'argent du jeu en coins et les joueurs ne peuvent pas se les donner.\n\n" ..
        "### Brancher la boutique en ligne (Tebex)\n1. Relie Tebex à ton serveur FiveM (plugin officiel, clé secrète dans server.cfg).\n" ..
        "2. Pour chaque pack de coins, ajoute la commande à lancer **quand le joueur est en ligne** :\n   `shadowcoins add sid:{sid} 1000 {transaction}`\n   (vérifie le nom exact des variables dans ton tableau Tebex ; `{transaction}` évite qu'un achat soit crédité deux fois).\n" ..
        "3. Pour un remboursement ou un litige : `shadowcoins remove <ID permanent> <montant> <motif>`.\n\n" ..
        "La cible peut être l'**ID permanent** (12), `sid:<ID de connexion>` ou `license:…`. Les coins sont ceux du compte : partagés par ses personnages.\n\n" ..
        "### Catalogue\n- **Arme permanente** : objet à part (★), liée au joueur (ni donnée, ni jetée, ni prise). Perdue, il la récupère dans « Mes achats » (délai réglable).\n" ..
        "- **Véhicule** : livré au garage ; supprimé, il peut être relivré (délai réglable).\n- **VIP** : durée en jours (0 = à vie), s'ajoute au VIP en cours.\n" ..
        "- **Villa** : crée d'abord le logement (module Logements, avec son intérieur), puis l'article avec son identifiant. Il n'est plus achetable avec l'argent du jeu ; l'acheteur n'a ni impôt ni loyer, choisit l'intérieur et pose ses meubles même sans VIP.\n" ..
        "- **Argent**, **objets**, **plaque personnalisée**.\n\n" ..
        "### Offres du jour, boosts\n- **Journalières** : chaque jour à minuit, une sélection (nombre et réduction réglables) parmi les articles cochés « Peut sortir dans les offres du jour ». Un achat par joueur et par article, compte à rebours affiché.\n" ..
        "- **Boost** : bonus en % sur la paie ou les missions, pendant X heures ; racheter prolonge. Le bonus est versé en plus (jamais pris sur la caisse d'une entreprise).\n" ..
        "- **Rareté** : commun, rare, épique, légendaire (couleur des cartes).\n- **Code boutique** : l'ID permanent du joueur, à donner pour créditer ses coins.",
    view = function(ctx)
        return { tabs = {
            { id = 'catalog', label = 'Catalogue', icon = 'star', build = function()
                local rows = {}
                for _, it in ipairs(Pm.Items(true)) do
                    local d = it.data
                    local what = it.cat == 'weapon' and d.hash or it.cat == 'vehicle' and d.model or it.cat == 'vip' and ((d.days or 0) == 0 and 'à vie' or (d.days .. ' j')) or it.cat == 'villa' and d.prop or it.cat == 'money' and money(d.amount) or it.cat == 'item' and ((d.qty or 1) .. ' × ' .. tostring(d.item)) or ''
                    rows[#rows + 1] = { id = it.id, label = it.label .. (Pm.PriceOf(it) < it.price and ('  (−' .. tostring(it.promo_pct) .. ' % → ' .. Pm.PriceOf(it) .. ')') or ''), cat = (CAT[it.cat] or {}).label or it.cat, what = tostring(what or ''), price = it.price, sold = it.sold, stock = it.stock < 0 and '∞' or tostring(math.max(0, it.stock - it.sold)),
                        on = it.enabled and { text = 'En vente', tone = 'ok' } or { text = 'Retiré', tone = 'off' },
                        actions = ctx.has('premium.edit') and { { nav = { tab = 'edit', params = { id = it.id } }, label = 'Modifier', icon = 'edit' }, { action = 'premium.item.toggle', label = it.enabled and 'Retirer' or 'Remettre', icon = 'eye', payload = { id = it.id } } } or {} }
                end
                return { ctx.has('premium.edit') and B.actions({ { nav = { tab = 'new', params = {} }, label = 'Ajouter un article', icon = 'plus', primary = true } }) or nil,
                    B.table({ id = 'pmcat', title = 'Articles (' .. #rows .. ')', search = true, columns = { { k = 'id', label = 'N°' }, { k = 'label', label = 'Article' }, { k = 'cat', label = 'Catégorie' }, { k = 'what', label = 'Contenu', type = 'mono' },
                        { k = 'price', label = 'Prix (coins)', type = 'num' }, { k = 'sold', label = 'Vendus', type = 'num' }, { k = 'stock', label = 'Stock' }, { k = 'on', label = 'État', type = 'badge' } }, rows = rows, empty = 'Catalogue vide.' }) }
            end },
            { id = 'new', label = 'Ajouter', icon = 'plus', perm = 'premium.edit', build = function()
                local items = {}
                for _, c in ipairs(Pm.CATS) do
                    local direct = not PICKS[c.id]
                    items[#items + 1] = { title = c.label, sub = c.sub, icon = c.icon, value = PICKS[c.id] and tostring(#PICKS[c.id]()) or nil,
                        action = { nav = { tab = direct and 'edit' or 'pick', params = { cat = c.id } }, label = 'Choisir', icon = 'plus' } }
                end
                return { { type = 'cards', title = 'Que veux-tu vendre ?', items = items } }
            end },
            { id = 'pick', label = 'Choix', icon = 'list', hidden = true, perm = 'premium.edit', build = function(_, params)
                local cat = tostring(params and params.cat or '')
                if not PICKS[cat] then return { B.notice('info', "Choisis d'abord une catégorie dans l'onglet « Ajouter ».") } end
                local items = {}
                for _, x in ipairs(PICKS[cat]()) do
                    items[#items + 1] = { key = x.key, title = x.title, sub = x.sub, group = x.group, img = x.img, icon = x.icon or (CAT[cat] or {}).icon,
                        action = { nav = { tab = 'edit', params = { cat = cat, pick = x.key } }, label = 'Vendre', icon = 'plus' } }
                end
                return { B.actions({ { nav = { tab = 'new', params = {} }, label = 'Changer de catégorie', icon = 'back' }, { nav = { tab = 'edit', params = { cat = cat } }, label = 'Saisie manuelle', icon = 'edit' } }),
                    { type = 'catalog', title = (CAT[cat] or {}).label, desc = 'Choisis ce que tu veux vendre : la photo et le nom sont remplis tout seuls.', icon = (CAT[cat] or {}).icon, items = items,
                        empty = cat == 'villa' and "Aucun logement libre : crée-le d'abord (module Logements)." or nil } }
            end },
            { id = 'edit', label = 'Article', icon = 'edit', hidden = true, perm = 'premium.edit', build = function(_, params)
                local it = params and Pm.Item(params.id)
                local cat = it and it.cat or tostring(params and params.cat or '')
                if not CAT[cat] then return { B.notice('info', "Choisis d'abord une catégorie dans l'onglet « Ajouter ».") } end
                local d = it and it.data or {}
                local pk = not it and params and params.pick and pickOf(cat, params.pick) or nil
                local fill = pk and pk.fill or {}
                local function val(k, df) if fill[k] ~= nil then return fill[k] end if d[k] ~= nil then return d[k] end return df end
                local vals = { label = it and it.label or fill.label or '', descr = it and it.descr or fill.descr or '', price = it and it.price or 1000, image = it and it.image or '',
                    per_player = it and it.per_player or 0, stock = it and it.stock or -1, enabled = it == nil or it.enabled, sort = it and it.sort or 0,
                    promo_pct = it and (int(it.promo_until) or 0) > now() and int(it.promo_pct) or 0, promo_days = 0, rarity = d.rarity or 'commun', daily = d.daily ~= false,
                    hash = val('hash', ''), ammo_item = val('ammo_item', ''), ammo = val('ammo', 0), model = val('model', ''), days = val('days', 30), prop = val('prop', ''), amount = val('amount', 0), item = val('item', ''), qty = val('qty', 1),
                    boost_kind = fill.boost_kind or d.kind or 'pay', boost_pct = fill.boost_pct or d.pct or 25, boost_hours = fill.boost_hours or d.hours or 24,
                    loot = (function() local t = {} for _, e in ipairs(type(d.loot) == 'table' and d.loot or {}) do t[#t + 1] = tostring(e.id) .. (e.w and (':' .. e.w) or '') end return table.concat(t, ', ') end)() }
                -- seulement les champs de cette catégorie
                local fields = { { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 60 }, { k = 'price', type = 'number', label = 'Prix (coins)', min = 1, max = 1000000 }, { k = 'enabled', type = 'toggle', label = 'En vente' } }
                local function add(f) fields[#fields + 1] = f end
                add({ k = 'descr', type = 'text', label = 'Description', maxlen = 240, wide = true })
                local locked = {}
                if cat == 'weapon' then locked.hash = vals.hash
                    if vals.hash == '' then add({ k = 'hash', type = 'text', label = 'Arme : nom du jeu (WEAPON_…)', maxlen = 40 }) end
                    add({ k = 'ammo_item', type = 'text', label = 'Objet munitions (vide = aucune)', maxlen = 40 }) add({ k = 'ammo', type = 'number', label = 'Boîtes de munitions offertes', min = 0, max = 50 })
                elseif cat == 'vehicle' then locked.model = vals.model
                    if vals.model == '' then add({ k = 'model', type = 'text', label = 'Véhicule : modèle du jeu', maxlen = 32 }) end
                elseif cat == 'vip' then add({ k = 'days', type = 'number', label = 'Durée en jours (0 = à vie)', min = 0, max = 3650 })
                elseif cat == 'villa' then locked.prop = vals.prop
                    if vals.prop == '' then add({ k = 'prop', type = 'text', label = 'Identifiant du logement', maxlen = 32 }) end
                elseif cat == 'money' then add({ k = 'amount', type = 'number', label = 'Montant en $', min = 0, max = 100000000 })
                elseif cat == 'item' then locked.item = vals.item
                    if vals.item == '' then add({ k = 'item', type = 'text', label = 'Objet : nom technique', maxlen = 40 }) end
                    add({ k = 'qty', type = 'number', label = 'Quantité', min = 1, max = 1000 })
                elseif cat == 'boost' then
                    add({ k = 'boost_kind', type = 'select', label = 'Sur quoi', opts = { { 'pay', 'Paie (salaire, allocation)' }, { 'mission', 'Missions des métiers civils' } } })
                    add({ k = 'boost_pct', type = 'number', label = 'Bonus en %', min = 1, max = 200 }) add({ k = 'boost_hours', type = 'number', label = 'Durée (heures)', min = 1, max = 720 })
                end
                add({ k = 'rarity', type = 'select', label = 'Rareté (couleur de la carte)', opts = RAR_OPTS }) add({ k = 'daily', type = 'toggle', label = 'Peut sortir dans les offres du jour' })
                add({ k = 'image', type = 'text', label = 'Autre image (facultatif : https://… ou img/…)', maxlen = 255, wide = true })
                add({ k = 'per_player', type = 'number', label = 'Maximum par joueur (0 = règle de la catégorie)', min = 0, max = 999 }) add({ k = 'stock', type = 'number', label = 'Stock (-1 = illimité)', min = -1, max = 100000 })
                add({ k = 'sort', type = 'number', label = "Ordre d'affichage", min = -999, max = 9999 })
                add({ k = 'promo_pct', type = 'number', label = 'Promotion : réduction en % (0 = aucune)', min = 0, max = 90 })
                add({ k = 'promo_days', type = 'number', label = 'Promotion : durée en jours (0 = garder la date en cours)', min = 0, max = 365, hint = it and (int(it.promo_until) or 0) > now() and ('En cours jusqu\'au ' .. os.date('%d/%m/%Y %H:%M', it.promo_until)) or nil })
                local payload = { cat = cat, id = it and it.id or nil }
                for k, x in pairs(locked) do if x ~= '' then payload[k] = x end end
                local out = {}
                local pic = (it and it.image ~= '' and it.image) or autoImage(cat, it and d or fill)
                out[#out + 1] = { type = 'catalog', items = { { title = vals.label ~= '' and vals.label or (CAT[cat] or {}).label, sub = (CAT[cat] or {}).label, img = pic, icon = (CAT[cat] or {}).icon,
                    action = (not it and PICKS[cat]) and { nav = { tab = 'pick', params = { cat = cat } }, label = 'Choisir autre chose', icon = 'list' } or nil } } }
                out[#out + 1] = { type = 'form', id = 'premium.it', title = it and ('Modifier « ' .. it.label .. ' »') or 'Mettre en vente', cols = 3, values = vals, submit = { action = 'premium.item.save', label = 'Enregistrer', payload = payload }, fields = fields }
                return out
            end },
            { id = 'coins', label = 'Coins des joueurs', icon = 'coins', build = function(_, params)
                local rows = {}
                for _, r in ipairs(DB.q('SELECT c.*, u.uid FROM pb_coins c LEFT JOIN pb_uids u ON u.license = c.license ORDER BY c.updated DESC LIMIT 200') or {}) do
                    local s = onlineOf(r.license)
                    rows[#rows + 1] = { uid = r.uid and ('#' .. r.uid) or '—', who = s and display(s) or r.license, balance = r.balance, bought = r.bought, spent = r.spent, at = r.updated }
                end
                local blocks = { B.table({ id = 'pmcoins', title = 'Soldes', search = true, columns = { { k = 'uid', label = 'ID' }, { k = 'who', label = 'Joueur' }, { k = 'balance', label = 'Solde', type = 'num' }, { k = 'bought', label = 'Achetés', type = 'num' }, { k = 'spent', label = 'Dépensés', type = 'num' }, { k = 'at', label = 'Dernière opération', type = 'date' } }, rows = rows, empty = 'Aucun joueur n\'a encore de coins.' }) }
                if ctx.has('premium.coins') then table.insert(blocks, 1, { type = 'form', id = 'premium.adj', title = 'Créditer ou retirer des coins', desc = 'Geste commercial, correction, remboursement. Montant négatif pour retirer. Tracé dans l\'audit (catégorie boutique).', cols = 3,
                    values = { who = '', amount = 100, reason = '' }, submit = { action = 'premium.coins.adjust', label = 'Appliquer' }, fields = {
                        { k = 'who', type = 'text', label = 'ID permanent ou license:…', maxlen = 80, required = true }, { k = 'amount', type = 'number', label = 'Coins', min = -10000000, max = 10000000 }, { k = 'reason', type = 'text', label = 'Motif', maxlen = 100, required = true } } }) end
                return blocks
            end },
            { id = 'sales', label = 'Achats', icon = 'file', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT o.*, u.uid, p.firstname, p.lastname FROM pb_premium_owned o LEFT JOIN pb_uids u ON u.license = o.license LEFT JOIN pb_players p ON p.license = o.char_license ORDER BY o.id DESC LIMIT 300') or {}) do
                    rows[#rows + 1] = { at = r.at, uid = r.uid and ('#' .. r.uid) or '—', who = (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')), label = r.label, cat = (CAT[r.cat] or {}).label or r.cat, price = r.price }
                end
                local tx = {}
                for _, t in ipairs(DB.q('SELECT t.*, u.uid FROM pb_coin_tx t LEFT JOIN pb_uids u ON u.license = t.license ORDER BY t.id DESC LIMIT 300') or {}) do
                    tx[#tx + 1] = { at = t.at, uid = t.uid and ('#' .. t.uid) or '—', delta = t.delta, kind = t.kind, label = t.label, ref = t.ref or '', by = t.by_name }
                end
                return { B.table({ id = 'pmsales', title = 'Derniers achats', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'uid', label = 'ID' }, { k = 'who', label = 'Personnage' }, { k = 'label', label = 'Article' }, { k = 'cat', label = 'Catégorie' }, { k = 'price', label = 'Coins', type = 'num' } }, rows = rows, empty = 'Aucun achat.' }),
                    B.table({ id = 'pmtx', title = 'Mouvements de coins', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'uid', label = 'ID' }, { k = 'delta', label = 'Coins', type = 'num' }, { k = 'kind', label = 'Type' }, { k = 'label', label = 'Libellé' }, { k = 'ref', label = 'Référence', type = 'mono' }, { k = 'by', label = 'Par' } }, rows = tx, empty = 'Aucun mouvement.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'premium.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

-- Menu staff › un joueur › Coins : donner ou retirer (compte du joueur, tracé dans les mouvements et l'audit)
G.Staff.Def('coins', 'premium.coins', { target = true, inputs = { { k = 'amount', label = 'Coins (négatif pour retirer)', number = true, maxlen = 9 }, { k = 'reason', label = 'Motif', maxlen = 100 } }, run = function(src, t, p)
    local lic = account(t)
    local n = int(p.amount)
    if not lic then return false, 'Compte introuvable.' end
    if not n or n == 0 or math.abs(n) > 10000000 then return false, 'Montant invalide (0 ou trop grand).' end
    local why = clean(p.reason, 100)
    if #why < 3 then return false, 'Motif obligatoire.' end
    return Pm.Credit(lic, n, 'staff', 'Staff : ' .. why, nil, display(src))
end, log = true })

PB.SelfTest.Add('boutique (coins)', function(R)
    R.check(DB.TableExists == nil or DB.TableExists('pb_coins'), 'table pb_coins', 'migration non appliquée')
    for _, it in ipairs(Pm.Items()) do
        if it.cat == 'villa' then R.check(villaOf(it) ~= nil, 'villa « ' .. it.label .. ' »', 'logement introuvable : ' .. tostring(it.data.prop)) end
        if it.cat == 'item' then R.check(G.Inv.Def(tostring(it.data.item or '')) ~= nil, 'objet « ' .. it.label .. ' »', 'objet inconnu : ' .. tostring(it.data.item)) end
    end
end)
