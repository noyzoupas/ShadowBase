-- Commandes de chat essentielles. Côté staff, chaque commande est un raccourci d'une action du menu F10 : mêmes droits,
-- même obligation d'être en service, même contrôle de rang et même journal (G.Staff.Do). Côté joueurs : /id, /aide, /donner, /de…
-- La liste (avec l'aide et les paramètres) est envoyée au chat de chaque joueur selon ses droits : il ne voit que ce qu'il peut faire.

local G, P = PB.G, PB.Perm
local CC = { list = {} }
G.ChatCmds = CC

PB.Cfg.Define('chatcmds', { enabled = true, discord = '', rules = '', give_dist = 3.0, roll_max = 100 })
local function cfg(k, d) return PB.Cfg.Get('chatcmds', k, d) end
local function say(src, kind, text) G.Notify(src, { type = kind, title = 'Commandes', text = text }) end
local function S() return G.Staff end
local function name(src) return S() and S().RpName and S().RpName(src) or (GetPlayerName(src) or ('Joueur ' .. src)) end
local function int(v) local n = tonumber(v) return n and math.floor(n) or nil end
local function rest(args, from) local t = {} for i = from, #args do t[#t + 1] = tostring(args[i]) end return table.concat(t, ' ') end

local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
local function slow(src, ms)
    local t = GetGameTimer()
    if last[src] and t - last[src] < (ms or 700) then return true end
    last[src] = t
    return false
end

-- add(nom, aide, paramètres, droit (nil = tout le monde), fonction(src, args)) ; un nom peut avoir des alias (table)
local function add(names, help, params, perm, fn)
    if type(names) ~= 'table' then names = { names } end
    for i, n in ipairs(names) do
        CC.list[#CC.list + 1] = { name = n, help = help, params = params, perm = perm, alias = i > 1 }
        RegisterCommand(n, function(src, args)
            if src == 0 or not G.Get(src) or not cfg('enabled', true) then return end
            if slow(src) then return end
            if perm and not P.Has(src, perm) then say(src, 'error', 'Commande réservée au staff.') return end
            local ok, err = pcall(fn, src, args or {})
            if not ok then print(('[pb_panel] /%s : %s'):format(n, tostring(err))) end
        end, false)
    end
end
CC.Add = add

-- Commandes staff : action du menu F10 + construction de ses paramètres --------------------------------------------------------
local function staff(names, action, help, params, build)
    add(names, help, params, 'staff.menu', function(src, args)
        local payload, usage = build(src, args)
        if not payload then
            say(src, 'warn', usage or ('Utilisation : /' .. (type(names) == 'table' and names[1] or names) .. ' ' .. table.concat((function()
                local t = {} for _, p in ipairs(params) do t[#t + 1] = '<' .. p.name .. '>' end return t end)(), ' ')))
            return
        end
        local ok, msg = S().Do(src, type(action) == 'function' and action(args) or action, payload)
        if msg then say(src, ok and 'success' or 'error', tostring(msg)) end
    end)
end
local PID = { name = 'id', help = 'ID du joueur' }
local function target(i) return function(_, a) local t = int(a[i or 1]) if not t then return nil end return { id = t } end end
local function targetOrMe(src, a) return { id = int(a[1]) or src } end
local function none() return {} end
local function withText(key, need)
    return function(_, a)
        local t = int(a[1]) if not t then return nil end
        local txt = rest(a, 2) if need and txt == '' then return nil end
        return { id = t, [key] = txt }
    end
end

-- se déplacer
staff('goto', 'goto', 'Aller à un joueur', { PID }, target())
staff('bring', 'bring', 'Amener un joueur à toi', { PID }, target())
staff({ 'tp', 'teleport' }, function(a) return #a >= 3 and 'tp_coords' or 'tp_player' end, 'Se téléporter à des coordonnées ou à un joueur', { { name = 'x|id', help = 'x y z ou ID' } }, function(_, a)
    if #a >= 3 then return { text = ('%s %s %s'):format(a[1], a[2], a[3]):gsub(',', ' ') } end
    local t = int(a[1]) if not t then return nil end
    return { id = t }
end)
staff('tpm', 'tp_waypoint', 'Se téléporter au point GPS', {}, none)
staff({ 'back', 'retour' }, 'tp_back', 'Revenir à la position avant la téléportation', {}, none)
staff({ 'spec', 'spectate' }, 'spectate', 'Observer un joueur (refaire pour arrêter)', { PID }, target())

-- outils perso (bascule)
local function selfToggle(cmd, feature, help)
    staff(cmd, 'self', help, {}, function(src)
        local on = not (S().SelfOn and S().SelfOn(src, feature))
        return { feature = feature, on = on }
    end)
end
selfToggle('noclip', 'noclip', 'Activer / couper le noclip')
selfToggle({ 'god', 'godmode' }, 'god', 'Invincibilité on / off')
selfToggle({ 'invisible', 'invis' }, 'invisible', 'Invisibilité on / off')
selfToggle({ 'noms', 'names' }, 'names', 'Noms et ID au-dessus des joueurs on / off')
selfToggle('coords', 'coords', 'Afficher tes coordonnées on / off')
staff({ 'staff', 'service' }, 'duty', 'Prendre / quitter le service staff', {}, function(src) return { on = not (S().OnDuty and S().OnDuty(src)) } end)

-- soins
staff('heal', 'heal', 'Soigner (toi ou un joueur)', { { name = 'id', help = 'facultatif' } }, targetOrMe)
staff({ 'revive', 'rea' }, 'revive', 'Réanimer (toi ou un joueur)', { { name = 'id', help = 'facultatif' } }, targetOrMe)
staff({ 'armor', 'gilet' }, 'armor', 'Donner un gilet (toi ou un joueur)', { { name = 'id', help = 'facultatif' } }, targetOrMe)
staff({ 'feed', 'nourrir' }, 'feed', 'Faim, soif et stress au mieux', { { name = 'id', help = 'facultatif' } }, targetOrMe)
staff({ 'healall', 'soignertout' }, 'heal_all', 'Soigner tous les joueurs', {}, none)

-- contrôle d'un joueur
staff('freeze', 'freeze', 'Geler / dégeler un joueur', { PID }, target())
staff('kill', 'kill', 'Mettre un joueur à terre', { PID }, target())
staff('slap', 'slap', 'Projeter un joueur en l\'air', { PID }, target())
staff({ 'sortirveh', 'ejecter' }, 'leave_veh', 'Faire sortir un joueur de son véhicule', { PID }, target())
staff({ 'desarmer', 'strip' }, 'strip', 'Retirer les armes d\'un joueur', { PID }, target())
staff('info', 'info', 'Fiche d\'un joueur', { PID }, target())
staff({ 'inv', 'voirinv' }, 'inv_view', 'Voir l\'inventaire d\'un joueur', { PID }, target())
staff('clearinv', 'inv_clear', 'Vider l\'inventaire d\'un joueur', { PID }, target())
staff({ 'chercher', 'search' }, 'search', 'Chercher un joueur, une plaque, un numéro', { { name = 'texte', help = 'nom, ID, plaque…' } }, function(_, a)
    local q = rest(a, 1) if q == '' then return nil end return { q = q }
end)
staff({ 'msg', 'staffmsg' }, 'message', 'Message privé du staff à un joueur', { PID, { name = 'message', help = '' } }, withText('reason', true))

-- sanctions
staff('warn', 'warn', 'Avertir un joueur', { PID, { name = 'motif', help = '' } }, withText('reason', true))
staff('kick', 'kick', 'Expulser un joueur', { PID, { name = 'motif', help = '' } }, withText('reason', true))
staff('ban', 'ban', 'Bannir : /ban id durée motif (1h, 1j, 3j, 7j, 30j, def)', { PID, { name = 'durée', help = '1h, 1j, 3j, 7j, 30j, def' }, { name = 'motif', help = '' } }, function(_, a)
    local t = int(a[1]) if not t then return nil end
    local d = tostring(a[2] or ''):lower()
    local want = ({ ['1h'] = 60, ['1j'] = 1440, ['3j'] = 4320, ['7j'] = 10080, ['30j'] = 43200, def = 0, perm = 0 })[d]
    local unknown = 'Durée inconnue : 1h, 1j, 3j, 7j, 30j ou def (celles réglées dans le panel).'
    if want == nil then want = int(d) end
    if want == nil then return nil, unknown end
    local label
    for _, line in ipairs(PB.Cfg.Get('staff', 'ban_presets', {}) or {}) do
        local l, m = tostring(line):match('^(.-)|(%d+)$')
        if tonumber(m) == want then label = l end
    end
    if not label then return nil, unknown end
    local r = rest(a, 3) if r == '' then return nil end
    return { id = t, duration = label, reason = r }
end)
staff('mute', 'mute', 'Muter (chat et micro) : /mute id minutes motif', { PID, { name = 'minutes', help = '0 = jusqu\'à la levée' }, { name = 'motif', help = '' } }, function(_, a)
    local t, m = int(a[1]), int(a[2]) if not t or not m then return nil end
    local r = rest(a, 3) if r == '' then return nil end
    return { id = t, minutes = m, reason = r }
end)
staff('unmute', 'mute', 'Démuter un joueur', { PID }, function(_, a)
    local t = int(a[1]) if not t then return nil end
    if not (S().IsMuted and S().IsMuted(t)) then return nil, "Ce joueur n'est pas muté." end
    return { id = t }
end)
staff({ 'jail', 'prison' }, 'jail', 'Envoyer en prison : /jail id minutes motif', { PID, { name = 'minutes', help = '' }, { name = 'motif', help = '' } }, function(_, a)
    local t, m = int(a[1]), int(a[2]) if not t or not m then return nil end
    return { id = t, minutes = m, reason = rest(a, 3) }
end)
staff({ 'unjail', 'liberer' }, 'unjail', 'Libérer de prison', { PID }, target())

-- argent, objets, véhicules donnés
staff({ 'givecash', 'donnercash' }, 'cash', 'Espèces à un joueur (négatif pour retirer)', { PID, { name = 'montant', help = '' } }, function(_, a)
    local t, n = int(a[1]), int(a[2]) if not t or not n then return nil end return { id = t, amount = n }
end)
staff({ 'givebank', 'donnerbanque' }, 'bank', 'Banque d\'un joueur (négatif pour retirer)', { PID, { name = 'montant', help = '' } }, function(_, a)
    local t, n = int(a[1]), int(a[2]) if not t or not n then return nil end return { id = t, amount = n }
end)
staff({ 'giveitem', 'donnerobjet' }, 'item', 'Donner un objet', { PID, { name = 'objet', help = 'ex. water' }, { name = 'quantité', help = '' } }, function(_, a)
    local t = int(a[1]) if not t or not a[2] then return nil end return { id = t, item = tostring(a[2]):lower(), qty = int(a[3]) or 1 }
end)
staff({ 'giveweapon', 'donnerarme' }, 'weapon', 'Donner une arme', { PID, { name = 'arme', help = 'ex. weapon_pistol' }, { name = 'balles', help = '' } }, function(_, a)
    local t = int(a[1]) if not t or not a[2] then return nil end
    local w = tostring(a[2]):lower() if not w:match('^weapon_') then w = 'weapon_' .. w end
    return { id = t, name = w, ammo = int(a[3]) or 0 }
end)
staff({ 'givecar', 'donnerveh' }, 'give_vehicle', 'Donner un véhicule (garage du joueur)', { PID, { name = 'modèle', help = 'ex. sultan' } }, function(_, a)
    local t = int(a[1]) if not t or not a[2] then return nil end return { id = t, model = tostring(a[2]):lower() }
end)

-- véhicules du staff
staff({ 'car', 'veh' }, 'veh_spawn', 'Sortir un véhicule', { { name = 'modèle', help = 'ex. adder' } }, function(_, a)
    if not a[1] then return nil end return { model = tostring(a[1]):lower() }
end)
staff('dv', 'veh_delete', 'Supprimer le véhicule (dedans ou le plus proche)', {}, none)
staff({ 'dvall', 'purge' }, 'veh_purge', 'Supprimer les véhicules vides autour', {}, none)
staff({ 'fix', 'repair' }, 'veh_repair', 'Réparer ton véhicule', {}, none)
staff({ 'flip', 'retourner' }, 'veh_flip', 'Remettre le véhicule sur ses roues', {}, none)
staff({ 'clean', 'laver' }, 'veh_clean', 'Laver ton véhicule', {}, none)
staff({ 'plein', 'refuel' }, 'veh_fuel', 'Faire le plein de ton véhicule', {}, none)
staff({ 'unlock', 'ouvrirveh' }, 'veh_unlock', 'Déverrouiller le véhicule', {}, none)

-- monde et serveur
staff({ 'meteo', 'weather' }, 'weather', 'Changer la météo (ex. CLEAR, RAIN, THUNDER)', { { name = 'météo', help = '' } }, function(_, a)
    if not a[1] then return nil end return { value = tostring(a[1]):upper() }
end)
staff({ 'heurejeu', 'time' }, 'hour', 'Figer l\'heure (0-23) ou « cycle »', { { name = 'heure', help = '0-23 ou cycle' } }, function(_, a)
    if not a[1] then return nil end return { value = tostring(a[1]):lower() == 'cycle' and 'cycle' or tostring(int(a[1]) or '') }
end)
staff('blackout', 'blackout', 'Coupure de courant on / off', {}, none)
staff({ 'clearpeds', 'nettoyer' }, 'clear_peds', 'Retirer les PNJ autour de toi', {}, none)
staff({ 'restart', 'reboot' }, 'restart', 'Annoncer un redémarrage dans X minutes', { { name = 'minutes', help = '1 à 60' } }, function(_, a)
    local m = int(a[1]) if not m then return nil end return { minutes = m }
end)
staff({ 'annulerrestart' }, 'restart_cancel', 'Annuler le redémarrage annoncé', {}, none)

-- Pour tout le monde ---------------------------------------------------------------------------------------------------------------
add('id', 'Ton ID et celui des joueurs proches', {}, nil, function(src)
    local me = GetEntityCoords(GetPlayerPed(src))
    local near = {}
    for s in pairs(G.Players()) do
        if s ~= src then
            local c = GetEntityCoords(GetPlayerPed(s))
            if #(me - c) < 8.0 then near[#near + 1] = '#' .. s end
        end
    end
    say(src, 'info', 'Ton ID : ' .. src .. (#near > 0 and (' · Proches : ' .. table.concat(near, ', ')) or ''))
end)
add({ 'joueurs', 'online' }, 'Nombre de joueurs connectés', {}, nil, function(src)
    local n, staffOn = 0, 0
    for s in pairs(G.Players()) do n = n + 1 if S() and S().OnDuty and S().OnDuty(s) then staffOn = staffOn + 1 end end
    say(src, 'info', ('%d joueur(s) connecté(s) · %d staff en service · max %s'):format(n, staffOn, GetConvar('sv_maxclients', '?')))
end)
add('ping', 'Ta latence avec le serveur', {}, nil, function(src) say(src, 'info', 'Ping : ' .. GetPlayerPing(src) .. ' ms') end)
add('heure', 'Heure et date réelles', {}, nil, function(src) say(src, 'info', os.date('Il est %H:%M, le %d/%m/%Y.')) end)
add({ 'de', 'roll', 'des' }, 'Lancer un dé (vu par les joueurs proches)', { { name = 'faces', help = '6 par défaut' } }, nil, function(src, a)
    local f = math.max(2, math.min(int(a[1]) or 6, tonumber(cfg('roll_max', 100)) or 100))
    G.ChatSend(src, 'me', ('lance un dé à %d faces : %d'):format(f, math.random(1, f)))
end)
add({ 'pileface', 'coin' }, 'Pile ou face (vu par les joueurs proches)', {}, nil, function(src)
    G.ChatSend(src, 'me', 'lance une pièce : ' .. (math.random(2) == 1 and 'pile' or 'face'))
end)
add({ 'essayer', 'try' }, 'Tenter une action : réussite ou échec au hasard', { { name = 'action', help = '' } }, nil, function(src, a)
    local txt = rest(a, 1)
    if txt == '' then say(src, 'warn', 'Utilisation : /essayer <action>') return end
    G.ChatSend(src, 'me', ('essaie de %s : %s'):format(txt, math.random(2) == 1 and 'réussi' or 'raté'))
end)
add({ 'donner', 'payer' }, 'Donner des espèces au joueur à côté de toi', { PID, { name = 'montant', help = '' } }, nil, function(src, a)
    local t, n = int(a[1]), int(a[2])
    if not t or not n then say(src, 'warn', 'Utilisation : /donner <id> <montant>') return end
    if t == src or not G.Get(t) then say(src, 'error', 'Joueur introuvable.') return end
    local d = #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(GetPlayerPed(t)))
    if d > (tonumber(cfg('give_dist', 3.0)) or 3.0) then say(src, 'error', 'Approche-toi de la personne.') return end
    if PB.ToBool(G.Get(src).row.dead) then say(src, 'error', 'Impossible dans cet état.') return end
    local H = G.Ctx and G.Ctx.H
    if not H or not H.give_cash then say(src, 'error', 'Indisponible.') return end
    local ok, msg = H.give_cash(src, t, { amount = n })
    if msg then say(src, ok and 'success' or 'error', msg) end
end)
add('discord', 'Lien du Discord du serveur', {}, nil, function(src)
    local d = tostring(cfg('discord', '') or '')
    if d == '' then say(src, 'info', "Le lien du Discord n'est pas encore réglé (panel › Chat › Commandes).") return end
    G.ChatSystem(src, 'Discord', d)
end)
add({ 'regles', 'rules' }, 'Rappel des règles du serveur', {}, nil, function(src)
    local r = tostring(cfg('rules', '') or '')
    if r == '' then say(src, 'info', "Les règles ne sont pas encore écrites (panel › Chat › Commandes).") return end
    G.ChatSystem(src, 'Règles', r)
end)
add({ 'aide', 'help', 'commandes' }, 'Liste des commandes que tu peux utiliser', {}, nil, function(src)
    local pub, st = {}, {}
    for _, c in ipairs(CC.list) do
        if not c.alias and (not c.perm or P.Has(src, c.perm)) then
            local t = c.perm and st or pub
            t[#t + 1] = '/' .. c.name
        end
    end
    G.ChatSystem(src, 'Commandes', 'me, do, ooc, ' .. table.concat(pub, ', ') .. ', report, 112, annuler, e (emote), emotes, clear, moteur, coffre, capot, vitres, ceinture, siege, position')
    if #st > 0 then G.ChatSystem(src, 'Staff', table.concat(st, ', ')) end
end)

-- Liste envoyée au chat : aide + paramètres, uniquement les commandes que le joueur a le droit d'utiliser
function CC.For(src)
    local out = {}
    for _, c in ipairs(CC.list) do
        if not c.perm or P.Has(src, c.perm) then out[#out + 1] = { name = c.name, help = c.help, params = c.params, staff = c.perm and true or nil } end
    end
    return out
end
CC.Staff = {}
for _, c in ipairs(CC.list) do if c.perm then CC.Staff[c.name] = true end end

PB.SelfTest.Add('chatcmds', function(R)
    local seen, dup = {}, nil
    for _, c in ipairs(CC.list) do if seen[c.name] then dup = c.name end seen[c.name] = true end
    R.check(dup == nil, 'commandes de chat sans doublon', 'commande en double : /' .. tostring(dup))
    R.check(G.Staff ~= nil and G.Staff.Do ~= nil, 'commandes staff reliées au menu F10', 'menu staff absent')
end)
