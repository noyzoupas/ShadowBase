-- Zones du Builder : on voit le contour avant de poser. Zone ronde (← → : taille) ou tracée coin par coin.
-- Les contours sont des listes { { x, y, z }, … } ; z est au niveau des pieds.
local G = PBG

local function brand()
    local hex = tostring((G.cfg and G.cfg.brand and G.cfg.brand.color) or ''):match('^#(%x%x%x%x%x%x)$') or 'ffffff'
    return tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16)
end

-- un mur fin entre deux points : trait au sol, trait en haut, voile visible des deux côtés
local function wall(a, b, r, g, bl, alpha)
    local ax, ay, az, bx, by, bz = a[1], a[2], a[3] - 0.3, b[1], b[2], b[3] - 0.3
    local at, bt = az + 2.8, bz + 2.8
    DrawLine(ax, ay, az + 0.3, bx, by, bz + 0.3, r, g, bl, 230)
    DrawLine(ax, ay, at, bx, by, bt, r, g, bl, 150)
    DrawPoly(ax, ay, az, bx, by, bz, bx, by, bt, r, g, bl, alpha)
    DrawPoly(ax, ay, az, bx, by, bt, ax, ay, at, r, g, bl, alpha)
    DrawPoly(bx, by, bt, bx, by, bz, ax, ay, az, r, g, bl, alpha)
    DrawPoly(ax, ay, at, bx, by, bt, ax, ay, az, r, g, bl, alpha)
end

function G.ZoneWalls(pts, closed, r, g, b, alpha)
    for i = 1, #pts - 1 do wall(pts[i], pts[i + 1], r, g, b, alpha) end
    if closed and #pts >= 3 then wall(pts[#pts], pts[1], r, g, b, alpha) end
end

local function surface(pts)
    local n, s = #pts, 0.0
    for i = 1, n do
        local a, b = pts[i], pts[i % n + 1]
        s = s + a[1] * b[2] - b[1] * a[2]
    end
    return math.floor(math.abs(s) / 2.0 + 0.5)
end

local drawing = false
local function begin()
    if drawing then return false end
    drawing = true
    G.Menu.Suspend()
    return true
end
local function finish(cb, v)
    drawing = false
    G.send('prompt', { show = false })
    G.Menu.Resume()
    cb(v)
end
local function holdKeys()
    DisableControlAction(0, 200, true) DisableControlAction(0, 199, true)
    DisableControlAction(0, 174, true) DisableControlAction(0, 175, true)
end

-- Zone ronde : le cercle suit le joueur. Entrée : posée ici ; cb(rayon), ou cb(nil) si annulé.
function G.ZoneCircle(radius, cb)
    if not begin() then return end
    local R = math.max(4, math.min(50, math.floor(tonumber(radius) or 8)))
    local function help()
        G.send('prompt', { show = true, free = true, key = '↵', text = ('Zone de %d m  ·  ← → : taille  ·  Entrée : poser ici  ·  X : annuler'):format(R) })
    end
    help()
    CreateThread(function()
        local r, g, b = brand()
        local nextStep, result = 0, nil
        while drawing do
            Wait(0)
            holdKeys()
            local c = GetEntityCoords(PlayerPedId())
            local n = math.max(24, math.min(72, R * 2))
            local ring = {}
            for i = 1, n do
                local a = (i / n) * math.pi * 2.0
                ring[i] = { c.x + R * math.cos(a), c.y + R * math.sin(a), c.z - 0.9 }
            end
            G.ZoneWalls(ring, true, r, g, b, 45)
            local dir = (IsDisabledControlPressed(0, 175) and 1 or 0) - (IsDisabledControlPressed(0, 174) and 1 or 0)
            if dir ~= 0 and GetGameTimer() >= nextStep then
                local v = math.max(4, math.min(50, R + dir))
                if v ~= R then R = v help() end
                nextStep = GetGameTimer() + 110
            elseif dir == 0 then nextStep = 0 end
            if IsDisabledControlJustPressed(0, 191) or IsControlJustPressed(0, 191) then
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                result = R
                break
            elseif IsControlJustPressed(0, 73) then break end
        end
        finish(cb, result)
    end)
end

-- Zone tracée : on marche jusqu'à chaque coin et Entrée le pose. Le contour se dessine au fur et à mesure.
-- Retour arrière : retirer le dernier · E : terminer (3 coins minimum) · X : annuler. cb({ { x, y, z }, … }), ou cb(nil).
function G.ZoneCorners(title, cb)
    if not begin() then return end
    local pts = {}
    local function help()
        local more = #pts >= 3 and ('  ·  %d m²'):format(surface(pts)) or ''
        G.send('prompt', { show = true, free = true, key = '↵', text = ("Coin %d : Entrée pour l'ajouter ici  ·  Retour arrière : retirer  ·  E : terminer (3 coins min.)  ·  X : annuler%s"):format(#pts + 1, more) })
    end
    help()
    CreateThread(function()
        local r, g, b = brand()
        local result
        while drawing do
            Wait(0)
            holdKeys()
            local c = GetEntityCoords(PlayerPedId())
            local me = { c.x, c.y, c.z - 0.9 }
            G.ZoneWalls(pts, false, r, g, b, 60)
            -- le côté en cours suit le joueur, le dernier ferme la zone sur le premier coin
            if #pts > 0 then wall(pts[#pts], me, r, g, b, 35) end
            if #pts >= 2 then wall(me, pts[1], r, g, b, 18) end
            for _, q in ipairs(pts) do DrawMarker(28, q[1], q[2], q[3], 0, 0, 0, 0, 0, 0, 0.35, 0.35, 0.35, r, g, b, 210, false, false, 2, false, nil, nil, false) end
            if IsDisabledControlJustPressed(0, 191) or IsControlJustPressed(0, 191) then
                pts[#pts + 1] = me
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if #pts >= 40 then result = pts break end
                help()
            elseif IsDisabledControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                if #pts > 0 then table.remove(pts) help() end
            elseif IsControlJustPressed(0, 38) then
                if #pts >= 3 then result = pts break end
                G.send('notify', { type = 'warn', title = title, text = 'Pose au moins 3 coins.' })
            elseif IsControlJustPressed(0, 73) then break end
        end
        finish(cb, result)
    end)
end
