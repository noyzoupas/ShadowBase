-- Expulsions, bans et déconnexions : UN seul passage pour toutes les sanctions de la base, et un journal de chaque départ.
--   PB.Drop(src, kind, origin, reason, detail, actor)  -> expulse (kind = 'kick' | 'ban') avec une raison claire et un numéro de référence
--   PB.LogRefusal(src, origin, reason, ids)             -> connexion refusée (ban, liste blanche…)
-- Chaque ligne garde : date, joueur, identifiants, position, ping, temps de jeu, origine (module), raison, détail technique, auteur.
-- Les départs déclenchés AILLEURS (txAdmin, autre ressource, crash, timeout) sont aussi enregistrés avec la raison donnée par FiveM.

PB.Kicks = PB.Kicks or {}
local K = PB.Kicks

PB.Perm.Register('kicks.view', 'Voir les expulsions, bans et déconnexions', 'security')

PB.Migrate('205_kicks', 'Journal des expulsions, bans et déconnexions', {
    [[CREATE TABLE IF NOT EXISTS pb_kicks (
        id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, kind VARCHAR(12) NOT NULL, origin VARCHAR(32) NOT NULL DEFAULT '', src INT NOT NULL DEFAULT 0,
        name VARCHAR(64) NOT NULL DEFAULT '', license VARCHAR(64) NOT NULL DEFAULT '', idents TEXT NULL, reason VARCHAR(255) NOT NULL DEFAULT '',
        detail TEXT NULL, actor VARCHAR(96) NOT NULL DEFAULT '', ping INT NOT NULL DEFAULT 0, x DOUBLE NULL, y DOUBLE NULL, z DOUBLE NULL, played INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY k_at (at), KEY k_lic (license), KEY k_kind (kind))]],
})

local joinedAt, recent = {}, {}   -- src -> heure d'arrivée ; src -> départ provoqué par la base (pour ne pas le compter deux fois)
AddEventHandler('playerJoining', function() joinedAt[source] = os.time() end)

local KIND_FR = { kick = 'Expulsion', ban = 'Ban', refus = 'Connexion refusée', depart = 'Déconnexion' }
local function idents(src)
    local t = {}
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if not id:match('^ip:') then t[#t + 1] = id end end
    return t
end
local function licenseOf(list) for _, id in ipairs(list) do if id:sub(1, 8) == 'license:' then return id end end return list[1] or '' end
local function snapshot(src)
    local s = { name = (GetPlayerName and GetPlayerName(src)) or ('#' .. tostring(src)), ids = idents(src), ping = (GetPlayerPing and GetPlayerPing(src)) or 0 }
    s.license = licenseOf(s.ids)
    local ped = GetPlayerPed and GetPlayerPed(src)
    if ped and ped ~= 0 then local ok, c = pcall(GetEntityCoords, ped) if ok and c then s.x, s.y, s.z = c.x, c.y, c.z end end
    s.played = joinedAt[src] and (os.time() - joinedAt[src]) or 0
    return s
end

-- coupe un texte sans casser une lettre accentuée
local function cut(str, n)
    str = tostring(str or '')
    if #str <= n then return str end
    local i = n
    while i > 0 and (str:byte(i + 1) or 0) >= 0x80 and (str:byte(i + 1) or 0) < 0xC0 do i = i - 1 end
    return str:sub(1, i)
end
K.Cut = cut
local function store(kind, origin, src, s, reason, detail, actor)
    reason = cut(PB.FixUtf8((tostring(reason or ''):gsub('[%c]', ' '))), 250)
    detail = cut(PB.FixUtf8((tostring(detail or ''):gsub('\r', ''))), 2000)
    local id = PB.DB.insert('INSERT INTO pb_kicks (at, kind, origin, src, name, license, idents, reason, detail, actor, ping, x, y, z, played) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { os.time(), kind, tostring(origin or ''):sub(1, 32), tonumber(src) or 0, cut(PB.FixUtf8(tostring(s.name or '')), 64), s.license or '', PB.Json(s.ids or {}), reason, detail,
          cut(tostring(actor or ''), 96), tonumber(s.ping) or 0, s.x, s.y, s.z, tonumber(s.played) or 0 })
    local where = s.x and ('%.0f, %.0f, %.0f'):format(s.x, s.y, s.z) or '—'
    local col = (kind == 'ban' and '^6') or (kind == 'kick' and '^3') or '^5'
    print(('%s[%s #%s]^7 %s (#%s, %s) — %s : %s%s%s'):format(col, KIND_FR[kind] or kind, tostring(id or '?'), tostring(s.name), tostring(src), s.license ~= '' and s.license or 'sans licence',
        tostring(origin), reason, detail ~= '' and (' | ' .. detail:gsub('\n', ' | '):sub(1, 300)) or '', actor and actor ~= '' and (' | par ' .. actor) or ''))
    -- journal d'audit (catégorie « expulsion ») : panel Journaux + Discord (canal « Expulsions, bans et déconnexions »)
    if kind ~= 'depart' or K.Abnormal(reason) then
        pcall(PB.Audit.Log, 'expulsion', kind .. '.' .. tostring(origin), actor ~= '' and actor or 'système', ('%s (#%s)'):format(tostring(s.name), tostring(src)), nil,
            { ref = id, raison = reason, detail = detail ~= '' and cut(detail, 600) or nil, licence = s.license, position = where, ping = s.ping, joue = s.played })
    end
    return id
end

-- Départs normaux (le joueur quitte) : pas d'alerte Discord ; tout le reste (timeout, crash, expulsion externe) est signalé.
function K.Abnormal(reason)
    local r = PB.Trim(tostring(reason or '')):lower()
    if r == 'exiting' or r == 'disconnected.' or r == 'disconnected' or r:match('^quit') or r:match('^disconnected by user') or r:match('^client exited') then return false end
    return true
end

-- Expulser / bannir avec une raison précise. Le joueur voit la raison et la référence à donner au staff.
function PB.Drop(src, kind, origin, reason, detail, actor, playerText)
    src = tonumber(src)
    if not src or src <= 0 then return nil end
    kind = (kind == 'ban') and 'ban' or 'kick'
    local s = snapshot(src)
    local id = store(kind, origin, src, s, reason, detail, actor)
    recent[src] = { at = os.time(), id = id }
    local msg = tostring(playerText or reason or 'Expulsé.')
    if id then msg = msg .. ('\n\nRéférence : #%d (à donner au staff si tu penses que c\'est une erreur).'):format(id) end
    -- bannissement : capture d'écran du joueur AVANT de le couper (1,5 s au plus ; sans screenshot-basic ni webhook, rien n'attend)
    local function cut() if DropPlayer then DropPlayer(src, msg) end end
    if kind == 'ban' and PB.AC and PB.AC.Shot then
        local ok = pcall(PB.AC.Shot, src, 'ban', tostring(reason or ''), 'ban', cut)
        if not ok then cut() end
    else cut() end
    return id
end

-- Connexion refusée (avant d'entrer en jeu)
function PB.LogRefusal(src, origin, reason, detail)
    src = tonumber(src) or 0
    local s = snapshot(src)
    return store('refus', origin, src, s, reason, detail, '')
end

-- Tous les départs : ceux déjà notés par PB.Drop sont ignorés, les autres sont enregistrés avec la raison de FiveM
AddEventHandler('playerDropped', function(reason)
    local src = source
    local r = recent[src]
    recent[src] = nil
    if r and os.time() - r.at < 30 then joinedAt[src] = nil return end
    local s = snapshot(src)
    store('depart', K.Abnormal(reason) and 'externe' or 'joueur', src, s, tostring(reason or ''), '', '')
    joinedAt[src] = nil
end)

-- Panel : module « Expulsions et bans » -----------------------------------------------------------------------------------------------
local function dur(secs) secs = tonumber(secs) or 0 if secs < 60 then return secs .. ' s' end if secs < 3600 then return math.floor(secs / 60) .. ' min' end return ('%d h %02d'):format(math.floor(secs / 3600), math.floor(secs % 3600 / 60)) end
local TONE = { ban = 'off', kick = 'warn', refus = 'warn', depart = 'ok' }
local function rowsOf(where, params, limit)
    local out = {}
    for _, r in ipairs(PB.DB.q('SELECT * FROM pb_kicks ' .. where .. ' ORDER BY id DESC LIMIT ' .. (limit or 300), params) or {}) do
        out[#out + 1] = { ref = '#' .. r.id, at = r.at, kind = { text = KIND_FR[r.kind] or r.kind, tone = TONE[r.kind] or 'off' }, origin = r.origin, name = r.name, src = '#' .. tostring(r.src),
            reason = r.reason, detail = r.detail or '', actor = r.actor ~= '' and r.actor or '—', ping = tostring(r.ping) .. ' ms', played = dur(r.played),
            pos = r.x and ('%.0f, %.0f, %.0f'):format(r.x, r.y, r.z) or '—', license = r.license }
    end
    return out
end
local COLS = { { k = 'ref', label = 'Réf.' }, { k = 'at', label = 'Date', type = 'date' }, { k = 'kind', label = 'Type', type = 'badge' }, { k = 'name', label = 'Joueur' }, { k = 'src', label = 'ID de connexion' },
    { k = 'origin', label = 'Origine' }, { k = 'reason', label = 'Raison' }, { k = 'detail', label = 'Détail' }, { k = 'actor', label = 'Par' }, { k = 'played', label = 'Temps en jeu' },
    { k = 'ping', label = 'Ping' }, { k = 'pos', label = 'Position' }, { k = 'license', label = 'Licence', type = 'mono' } }

PB.Module({
    id = 'kicks', label = 'Expulsions et bans', icon = 'ban', group = 'Système', order = 905, perm = 'kicks.view', hint = 'Chaque kick, ban et déconnexion avec sa raison',
    doc = "## Expulsions et bans\nChaque **expulsion** et **ban** (anticheat, staff, licence, règlement, liste blanche, redémarrage) est enregistré avec sa **raison précise**, le **détail technique**, la position, le ping et le temps de jeu. Le joueur voit la raison et un **numéro de référence** : cherche-le ici.\n\nLes **déconnexions** sont aussi notées avec la raison donnée par FiveM : un départ « externe » (txAdmin, autre ressource, perte de connexion) est signalé en orange et envoyé sur Discord (canal « Expulsions, bans et déconnexions »).",
    view = function()
        return { tabs = {
            { id = 'sanctions', label = 'Expulsions et bans', icon = 'ban', build = function()
                local rows = rowsOf("WHERE kind IN ('kick','ban','refus')", {}, 300)
                local n24 = PB.DB.one("SELECT COUNT(*) AS n FROM pb_kicks WHERE kind IN ('kick','ban') AND at > ?", { os.time() - 86400 })
                local ac24 = PB.DB.one("SELECT COUNT(*) AS n FROM pb_kicks WHERE kind IN ('kick','ban') AND origin = 'anticheat' AND at > ?", { os.time() - 86400 })
                return { PB.B.stats({ { label = 'Expulsions et bans (24 h)', value = n24 and n24.n or 0, icon = 'ban' }, { label = 'Dont anticheat (24 h)', value = ac24 and ac24.n or 0, icon = 'shield' } }),
                    PB.B.table({ id = 'kk', title = 'Dernières sanctions', search = true, columns = COLS, rows = rows, empty = 'Aucune expulsion pour le moment.' }) }
            end },
            { id = 'departs', label = 'Déconnexions', icon = 'power', build = function()
                return { PB.B.notice('info', "« externe » = le joueur n'a pas quitté lui-même (perte de connexion, expulsion par txAdmin ou par une autre ressource, crash)."),
                    PB.B.table({ id = 'dd', title = 'Dernières déconnexions', search = true, columns = COLS, rows = rowsOf("WHERE kind = 'depart'", {}, 300), empty = 'Aucune déconnexion enregistrée.' }) }
            end },
        } }
    end,
})
