PB = PB or {}

-- Minuscules / majuscules : seulement A-Z. Sous Windows, les versions C de string.lower / upper dépendent de la langue du système
-- et abîment les lettres accentuées en UTF-8 (« Métiers » devenait illisible et le panel n'arrivait plus à envoyer la page).
do
    local low, up = {}, {}
    for i = 65, 90 do low[string.char(i)] = string.char(i + 32) up[string.char(i + 32)] = string.char(i) end
    string.lower = function(s) return (tostring(s):gsub('[A-Z]', low)) end
    string.upper = function(s) return (tostring(s):gsub('[a-z]', up)) end
end

function PB.Debug(...)
    if Config and Config.Debug then print('^3[pb_panel]^7', ...) end
end

function PB.Log(...) print('^2[pb_panel]^7', ...) end
function PB.Warn(...) print('^3[pb_panel]^7', ...) end
function PB.Err(...) print('^1[pb_panel]^7', ...) end

-- (v1.2.43) montant au format du serveur : 15000 -> « 15 000 $ » (avant, certains messages affichaient « 15000 $ » ou « $15000 »)
function PB.Money(n)
    local v = math.floor((tonumber(n) or 0) + 0.5)
    local s = tostring(math.abs(v)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')
    return (v < 0 and '-' or '') .. s .. ' $'
end

function PB.Trim(s)
    if type(s) ~= 'string' then return '' end
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
end

function PB.ToBool(v) return v == true or v == 1 or v == '1' or v == 'true' end

function PB.ToInt(v, default)
    local n = tonumber(v)
    if n == nil or n ~= n or n == math.huge or n == -math.huge then return default end
    return math.floor(n)
end

function PB.ToNum(v, default)
    local n = tonumber(v)
    if n == nil or n ~= n or n == math.huge or n == -math.huge then return default end
    return n
end

function PB.Clamp(n, lo, hi)
    if n < lo then return lo end
    if n > hi then return hi end
    return n
end

function PB.Round(n, d)
    local m = 10 ^ (d or 0)
    return math.floor(n * m + 0.5) / m
end

function PB.Count(t)
    local c = 0
    for _ in pairs(t or {}) do c = c + 1 end
    return c
end

function PB.Keys(t)
    local out = {}
    for k in pairs(t or {}) do out[#out + 1] = k end
    table.sort(out, function(a, b) return tostring(a) < tostring(b) end)
    return out
end

function PB.Contains(list, v)
    for _, x in ipairs(list or {}) do if x == v then return true end end
    return false
end

function PB.StartsWith(s, p) return type(s) == 'string' and s:sub(1, #p) == p end
function PB.EndsWith(s, p) return type(s) == 'string' and (p == '' or s:sub(-#p) == p) end

function PB.Split(s, sep)
    local out = {}
    if s == nil or s == '' then return out end
    local start = 1
    while true do
        local i, j = s:find(sep, start, true)
        if not i then out[#out + 1] = s:sub(start) break end
        out[#out + 1] = s:sub(start, i - 1)
        start = j + 1
    end
    return out
end

function PB.Sanitize(s, maxChars)
    if type(s) ~= 'string' then s = tostring(s or '') end
    s = s:gsub('[\0-\8\11\12\14-\31\127]', '')
    if not utf8.len(s) then s = s:gsub('[\128-\255]', '?') end
    local len = utf8.len(s)
    if maxChars and len > maxChars then s = s:sub(1, utf8.offset(s, maxChars + 1) - 1) end
    return s
end

function PB.DeepCopy(t, seen)
    if type(t) ~= 'table' then return t end
    seen = seen or {}
    if seen[t] then return seen[t] end
    local c = {}
    seen[t] = c
    for k, v in pairs(t) do c[PB.DeepCopy(k, seen)] = PB.DeepCopy(v, seen) end
    return c
end

function PB.DeepEqual(a, b)
    if a == b then return true end
    if type(a) ~= type(b) or type(a) ~= 'table' then return false end
    for k, v in pairs(a) do if not PB.DeepEqual(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end

function PB.IsArray(t)
    if type(t) ~= 'table' then return false end
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    for i = 1, n do if t[i] == nil then return false end end
    return true
end

-- Liste des différences entre deux valeurs (tables imbriquées) : { { path=, from=, to= }, ... }
function PB.Diff(a, b, prefix, out)
    out = out or {}
    prefix = prefix or ''
    if type(a) == 'table' and type(b) == 'table' then
        local keys = {}
        for k in pairs(a) do keys[tostring(k)] = k end
        for k in pairs(b) do keys[tostring(k)] = k end
        for _, ks in ipairs(PB.Keys(keys)) do
            local k = keys[ks]
            PB.Diff(a[k], b[k], prefix == '' and tostring(k) or (prefix .. '.' .. tostring(k)), out)
        end
    elseif not PB.DeepEqual(a, b) then
        out[#out + 1] = { path = prefix, from = a, to = b }
    end
    return out
end

function PB.SafeName(s) return type(s) == 'string' and #s > 0 and #s <= 64 and s:match('^[%w_%.%-]+$') ~= nil end

function PB.FormatBytes(n)
    n = tonumber(n) or 0
    local units = { 'o', 'Ko', 'Mo', 'Go', 'To' }
    local i = 1
    while n >= 1024 and i < #units do n = n / 1024 i = i + 1 end
    return (i == 1 and string.format('%d', n) or string.format('%.1f', n)) .. ' ' .. units[i]
end

-- Texte UTF-8 invalide (octet coupé au milieu d'une lettre) : remplacé par « ? » pour que l'encodage JSON ne tombe pas
function PB.FixUtf8(str)
    if utf8.len(str) then return str end
    local out, i = {}, 1
    while i <= #str do
        local ok, n = utf8.len(str, i)
        if ok then out[#out + 1] = str:sub(i) break end
        local bad = n                     -- position du premier octet invalide
        out[#out + 1] = str:sub(i, bad - 1) .. '?'
        i = bad + 1
    end
    return table.concat(out)
end
local function fixDeep(v, seen)
    local t = type(v)
    if t == 'string' then return PB.FixUtf8(v) end
    if t ~= 'table' then return v end
    seen = seen or {}
    if seen[v] then return nil end
    seen[v] = true
    local out = {}
    for k, x in pairs(v) do out[type(k) == 'string' and PB.FixUtf8(k) or k] = fixDeep(x, seen) end
    return out
end
function PB.Json(v)
    local ok, r = pcall(json.encode, v)
    if ok then return r end
    -- deuxième essai avec les textes réparés (au lieu d'envoyer « null » et d'afficher une page vide)
    local ok2, r2 = pcall(json.encode, fixDeep(v))
    if ok2 then
        if PB.Warn then PB.Warn('texte UTF-8 invalide réparé avant envoi : ' .. tostring(r):sub(1, 120)) end
        return r2
    end
    if PB.Err then PB.Err('encodage JSON impossible : ' .. tostring(r2 or r):sub(1, 200)) end
    return 'null'
end

function PB.FromJson(s, default)
    if type(s) ~= 'string' or s == '' then return default end
    local ok, r = pcall(json.decode, s)
    if ok and r ~= nil then return r end
    return default
end

-- Somme de contrôle rapide (Adler-32), suffisante pour détecter une corruption.
function PB.Checksum(s)
    local a, b = 1, 0
    for i = 1, #s do
        a = (a + s:byte(i)) % 65521
        b = (b + a) % 65521
    end
    return string.format('%08x', (b << 16) | a)
end

-- SHA-256 en Lua pur (utilisé pour les PIN et les empreintes de sauvegarde).
do
    local K = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    }
    local function rrot(x, n) return ((x >> n) | (x << (32 - n))) & 0xffffffff end

    function PB.Sha256(msg)
        local h0, h1, h2, h3, h4, h5, h6, h7 = 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
        local len = #msg
        msg = msg .. '\128' .. string.rep('\0', (55 - len) % 64) .. string.pack('>I8', len * 8)
        local w = {}
        for chunk = 1, #msg, 64 do
            for i = 0, 15 do w[i] = string.unpack('>I4', msg, chunk + i * 4) end
            for i = 16, 63 do
                local s0 = rrot(w[i - 15], 7) ~ rrot(w[i - 15], 18) ~ (w[i - 15] >> 3)
                local s1 = rrot(w[i - 2], 17) ~ rrot(w[i - 2], 19) ~ (w[i - 2] >> 10)
                w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xffffffff
            end
            local a, b, c, d, e, f, g, h = h0, h1, h2, h3, h4, h5, h6, h7
            for i = 0, 63 do
                local S1 = rrot(e, 6) ~ rrot(e, 11) ~ rrot(e, 25)
                local ch = (e & f) ~ ((~e) & g)
                local t1 = (h + S1 + ch + K[i + 1] + w[i]) & 0xffffffff
                local S0 = rrot(a, 2) ~ rrot(a, 13) ~ rrot(a, 22)
                local maj = (a & b) ~ (a & c) ~ (b & c)
                local t2 = (S0 + maj) & 0xffffffff
                h, g, f, e, d, c, b, a = g, f, e, (d + t1) & 0xffffffff, c, b, a, (t1 + t2) & 0xffffffff
            end
            h0 = (h0 + a) & 0xffffffff h1 = (h1 + b) & 0xffffffff h2 = (h2 + c) & 0xffffffff h3 = (h3 + d) & 0xffffffff
            h4 = (h4 + e) & 0xffffffff h5 = (h5 + f) & 0xffffffff h6 = (h6 + g) & 0xffffffff h7 = (h7 + h) & 0xffffffff
        end
        return string.format('%08x%08x%08x%08x%08x%08x%08x%08x', h0, h1, h2, h3, h4, h5, h6, h7)
    end
end

-- Base64 (images d'objets, logos).
do
    local B = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local rev = {}
    for i = 1, #B do rev[B:byte(i)] = i - 1 end
    function PB.B64Decode(s)
        s = s:gsub('[^%w%+/=]', '')
        local out, n = {}, 0
        for i = 1, #s, 4 do
            local a, b, c, d = s:byte(i, i + 3)
            local v = ((rev[a] or 0) << 18) | ((rev[b] or 0) << 12) | ((c and c ~= 61 and rev[c] or 0) << 6) | (d and d ~= 61 and rev[d] or 0)
            local chunk = string.char((v >> 16) & 255, (v >> 8) & 255, v & 255)
            if d == 61 or d == nil then chunk = chunk:sub(1, (c == 61 or c == nil) and 1 or 2) end
            n = n + 1
            out[n] = chunk
        end
        return table.concat(out)
    end
end

function PB.FormatDuration(sec)
    sec = math.floor(tonumber(sec) or 0)
    local d, h, m = sec // 86400, (sec % 86400) // 3600, (sec % 3600) // 60
    if d > 0 then return d .. ' j ' .. h .. ' h' end
    if h > 0 then return h .. ' h ' .. m .. ' min' end
    if m > 0 then return m .. ' min' end
    return sec .. ' s'
end
