-- Taxi : le client commande depuis son téléphone (app Taxi), les chauffeurs en service de la compagnie sont prévenus.
-- Tout le reste se fait dans le menu entreprise (F6) du chauffeur : accepter une course, démarrer le compteur, terminer la course,
-- puis envoyer la facture au client choisi (il la paie ou la garde pour plus tard). Le serveur mesure lui-même la distance parcourue.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

PB.Cfg.Define('taxi', { enabled = true, biz = 'taxi', base = 50, per_km = 40, per_min = 5, commission = 30, call_ttl = 10, max_fare = 5000 })
local Tx = { calls = {}, meters = {}, seq = 0, bills = {}, unpaid = {} }
G.Taxi = Tx
local function cfg(k, d) return PB.Cfg.Get('taxi', k, d) end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function now() return os.time() end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end local c = GetEntityCoords(ped) return c and { x = c.x, y = c.y, z = c.z } or nil end
local function dist2(a, b) return math.sqrt((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2) end

-- Chauffeur : employé EN SERVICE de la compagnie de taxi
function Tx.Biz() local b = G.Biz and G.Biz.Get(tostring(cfg('biz', 'taxi'))) return b end
function Tx.IsDriver(src)
    local c = G.Biz and G.Biz.Ctx(src)
    return c ~= nil and c.duty == true and c.biz.id == tostring(cfg('biz', 'taxi'))
end
local function drivers() local out = {} for id in pairs(G.Players()) do if Tx.IsDriver(id) then out[#out + 1] = id end end return out end
function Tx.Fare(m) return math.min(num('max_fare', 5000), math.floor(num('base', 50) + num('per_km', 40) * m.meters / 1000 + num('per_min', 5) * (now() - m.at) / 60 + 0.5)) end

-- Commandes ---------------------------------------------------------------------------------------------------------------------------------
local function callOf(src) for id, c in pairs(Tx.calls) do if c.client == src then return id, c end end end
function Tx.Call(src)
    if cfg('enabled', true) == false then return false, 'Le service de taxi est fermé.' end
    if not Tx.Biz() then return false, "Aucune compagnie de taxi en ville." end
    if callOf(src) then return false, 'Tu as déjà commandé un taxi.' end
    if Tx.IsDriver(src) then return false, 'Tu es toi-même chauffeur en service.' end
    local p = pos(src)
    if not p then return false, 'Position introuvable.' end
    local list = drivers()
    if #list == 0 then return false, "Aucun chauffeur n'est en service : réessaie plus tard ou écris à la compagnie (Annuaire)." end
    Tx.seq = Tx.seq + 1
    Tx.calls[Tx.seq] = { id = Tx.seq, client = src, name = display(src), x = p.x, y = p.y, z = p.z, at = now() }
    for _, d in ipairs(list) do
        G.Notify(d, { type = 'info', title = 'Course demandée', text = ('%s attend un taxi (%d m). F6 › Courses en attente pour accepter.'):format(display(src), math.floor(dist2(pos(d) or p, p))), duration = 10000 })
        TriggerClientEvent('pb:g:taxi:ping', d, PB.Json({ id = Tx.seq, x = p.x, y = p.y, z = p.z, name = display(src) }))
    end
    return true, ('Taxi demandé : %d chauffeur(s) prévenu(s).'):format(#list)
end
function Tx.Cancel(src)
    local id, c = callOf(src)
    if not c then return false, 'Aucune commande en cours.' end
    Tx.calls[id] = nil
    if c.driver then G.Notify(c.driver, { type = 'warn', title = 'Taxi', text = c.name .. ' a annulé sa commande.' }) TriggerClientEvent('pb:g:taxi:clear', c.driver, id) end
    return true, 'Commande annulée.'
end
function Tx.Accept(src, id)
    if not Tx.IsDriver(src) then return false, 'Prends ton service à la compagnie de taxi.' end
    local c = Tx.calls[tonumber(id) or -1]
    if not c then return false, 'Cette course n\'existe plus.' end
    if c.driver and c.driver ~= src then return false, 'Un autre chauffeur a déjà pris la course.' end
    c.driver, c.driverName = src, display(src)
    TriggerClientEvent('pb:g:phone:gps', src, c.x, c.y, 'Client : ' .. c.name)
    G.Notify(c.client, { type = 'success', title = 'Taxi', text = ('%s a accepté ta course et arrive.'):format(c.driverName), duration = 9000 })
    if G.Phone and G.Phone.Notice then local p = G.Get(c.client) if p then G.Phone.Notice(p.license, 'taxi', ('Votre chauffeur %s arrive. Restez où vous êtes.'):format(c.driverName)) end end
    for _, d in ipairs(drivers()) do if d ~= src then TriggerClientEvent('pb:g:taxi:clear', d, c.id) end end
    return true, 'Course acceptée : le client est sur ton GPS.'
end

-- Taximètre ---------------------------------------------------------------------------------------------------------------------------------
local function vehOf(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return 0 end local ok, v = pcall(GetVehiclePedIsIn, ped, false) return ok and v or 0 end
local function passengers(veh, driver)
    local out = {}
    if not veh or veh == 0 then return out end
    local byPed = {}
    for id in pairs(G.Players()) do local pp = GetPlayerPed(id) if pp and pp ~= 0 then byPed[pp] = id end end
    for seat = 0, 6 do
        local ok, ped = pcall(GetPedInVehicleSeat, veh, seat)
        local id = ok and ped and ped ~= 0 and byPed[ped]
        if id and id ~= driver then out[#out + 1] = id end
    end
    return out
end
Tx.Passengers = passengers
local function pushMeter(m, stop)
    local d = PB.Json({ on = not stop, fare = Tx.Fare(m), km = math.floor(m.meters / 100) / 10, mins = math.floor((now() - m.at) / 60), driver = m.driverName })
    TriggerClientEvent('pb:g:taxi:meter', m.driver, d)
    for _, id in ipairs(m.riders) do TriggerClientEvent('pb:g:taxi:meter', id, d) end
end
function Tx.Start(src)
    if not Tx.IsDriver(src) then return false, 'Prends ton service à la compagnie de taxi.' end
    if Tx.meters[src] then return false, 'Le compteur tourne déjà.' end
    local veh = vehOf(src)
    if veh == 0 then return false, 'Monte au volant de ton taxi.' end
    local ok, d = pcall(GetPedInVehicleSeat, veh, -1)
    if not ok or d ~= GetPlayerPed(src) then return false, 'Tu dois être au volant.' end
    local riders = passengers(veh, src)
    if #riders == 0 then return false, "Aucun client à bord." end
    Tx.meters[src] = { driver = src, driverName = display(src), veh = veh, riders = riders, at = now(), meters = 0, last = pos(src) }
    for _, r in ipairs(riders) do local id = callOf(r) if id then Tx.calls[id] = nil end end
    pushMeter(Tx.meters[src])
    return true, 'Compteur démarré.'
end
function Tx.Stop(src)
    local m = Tx.meters[src]
    if not m then return false, 'Le compteur ne tourne pas.' end
    Tx.meters[src] = nil
    local fare = Tx.Fare(m)
    local riders = {}
    for _, r in ipairs(m.riders) do if G.Get(r) then riders[#riders + 1] = { id = r, name = display(r) } end end
    pushMeter(m, true)
    PB.Audit.Log('economy', 'taxi.ride', src, ('%d passager(s)'):format(#riders), nil, nil, { prix = fare, km = math.floor(m.meters) / 1000 })
    if #riders == 0 or fare <= 0 then Tx.bills[src] = nil return true, 'Course terminée (aucun client à faire payer).' end
    Tx.bills[src] = { fare = fare, riders = riders, at = now() }
    return true, ('Course terminée : %s. F6 › Envoyer la facture au client.'):format(money(fare))
end
-- facture de la course au client choisi : il voit le détail et paie (banque puis espèces), ou la garde pour plus tard (tablette / téléphone)
function Tx.Bill(src, target)
    local b = Tx.bills[src]
    if not b then return false, 'Aucune course à facturer.' end
    if now() - b.at > 1800 then Tx.bills[src] = nil return false, 'Course trop ancienne pour être facturée.' end
    target = tonumber(target)
    local ok = false
    for _, r in ipairs(b.riders) do if r.id == target then ok = true end end
    local tp = target and G.Get(target)
    if not ok or not tp then return false, 'Choisis un des clients de la course.' end
    if G.DistBetween(src, target) > 15 then return false, 'Le client est trop loin.' end
    local biz = Tx.Biz()
    if not biz then return false, "Aucune compagnie de taxi en ville." end
    local reason = ('Course de taxi (%s)'):format(display(src))
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { biz.id, tp.license, display(target), b.fare, reason, 'invoice', 'pending', display(src), G.Get(src).license, now() })
    if not id then return false, 'Réessaie.' end
    Tx.bills[src] = nil
    Tx.unpaid[id] = { driver = src, lic = G.Get(src).license, amount = b.fare, at = now() }
    TriggerClientEvent('pb:g:bill:offer', target, PB.Json({ id = id, biz = biz.label, from = display(src), amount = b.fare, reason = reason }))
    TriggerEvent('pb_panel:invoice', src, target, biz.id, b.fare, reason)
    TriggerEvent('pb_panel:taxiRide', src, { target }, b.fare)
    return true, ('Facture de %s envoyée à %s.'):format(money(b.fare), display(target))
end
-- payée (tout de suite ou plus tard) : la part du chauffeur sort de la caisse de la compagnie
AddEventHandler('pb_panel:invoicePaid', function(id)
    local u = Tx.unpaid[id]
    if not u then return end
    Tx.unpaid[id] = nil
    local b = Tx.Biz()
    local cut = math.floor(u.amount * num('commission', 30) / 100)
    if not b or cut <= 0 or not G.Eco.Take('biz:' .. b.id, cut, 'Taxi : part du chauffeur', u.lic) then return end
    -- le chauffeur est retrouvé par sa licence (son numéro de joueur a pu changer ou être repris par quelqu'un d'autre)
    local online
    for s2, pl in pairs(G.Players()) do if pl.license == u.lic then online = s2 end end
    if online then
        G.AddMoney(online, 'bank', cut, 'Taxi : part du chauffeur')
        G.Notify(online, { type = 'success', title = 'Taxi', text = ('Course payée : ta part, %s, est sur ton compte.'):format(money(cut)) })
    else DB.exec('UPDATE pb_players SET bank = bank + ? WHERE license = ?', { cut, u.lic }) end
end)
-- fin de service : compteur arrêté
function Tx.OffDuty(src) if Tx.meters[src] then pcall(Tx.Stop, src) end end
-- courses en attente, pour le menu F6 du chauffeur
function Tx.CallList(src)
    local me = pos(src)
    local list = {}
    for _, c in pairs(Tx.calls) do
        if not c.driver or c.driver == src then
            list[#list + 1] = { id = c.id, label = c.name, right = (me and math.floor(dist2(me, c)) or 0) .. ' m', mine = c.driver == src or nil }
        end
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

-- mesure : distance parcourue au volant, mise à jour du compteur chez le chauffeur et les passagers
CreateThread(function()
    while true do
        Wait(2000)
        for src, m in pairs(Tx.meters) do
            if not G.Get(src) or vehOf(src) ~= m.veh then
                if G.Get(src) then pcall(Tx.Stop, src) else Tx.meters[src] = nil end
            else
                local p = pos(src)
                if p and m.last then local d = dist2(p, m.last) if d < 200 then m.meters = m.meters + d end end
                m.last = p
                local cur = passengers(m.veh, src)
                for _, r in ipairs(cur) do local known = false for _, x in ipairs(m.riders) do if x == r then known = true end end if not known then m.riders[#m.riders + 1] = r end end
                pushMeter(m)
            end
        end
        local ttl = num('call_ttl', 10) * 60
        for id, c in pairs(Tx.calls) do if now() - c.at > ttl or not G.Get(c.client) then Tx.calls[id] = nil if G.Get(c.client) then G.Notify(c.client, { type = 'warn', title = 'Taxi', text = 'Personne n\'a pris ta course : commande annulée.' }) end end end
    end
end)
AddEventHandler('playerDropped', function() local s = source local id = callOf(s) if id then Tx.calls[id] = nil end if Tx.meters[s] then Tx.meters[s] = nil end Tx.bills[s] = nil end)

-- Données de l'app Taxi du téléphone
function Tx.PhoneData(src)
    local me = pos(src)
    local id, mine = callOf(src)
    local out = { driver = Tx.IsDriver(src) and cfg('phone_driver', false) == true, company = Tx.Biz() and Tx.Biz().label or nil, rates = { base = num('base', 50), km = num('per_km', 40), min = num('per_min', 5) },
        mine = mine and { id = id, state = mine.driver and 'accepted' or 'waiting', driver = mine.driverName, since = now() - mine.at } or nil }
    if out.driver and cfg('phone_driver', false) == true then
        local list = {}
        for _, c in pairs(Tx.calls) do list[#list + 1] = { id = c.id, name = c.name, dist = me and math.floor(dist2(me, c)) or 0, mine = c.driver == src or nil, taken = (c.driver and c.driver ~= src) or nil, ago = math.floor((now() - c.at) / 60) } end
        table.sort(list, function(a, b) return a.dist < b.dist end)
        out.calls = list
        local m = Tx.meters[src]
        out.meter = m and { fare = Tx.Fare(m), km = math.floor(m.meters / 100) / 10, riders = #m.riders } or nil
    end
    return out
end

local form = PB.Form.Cfg({ ns = 'taxi', id = 'settings', title = 'Taxi', perm = 'biz.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Commandes de taxi (app Taxi du téléphone)', default = true },
    { k = 'phone_driver', type = 'toggle', label = 'Les chauffeurs gèrent aussi les courses au téléphone', default = false, hint = 'Par défaut tout se fait au menu entreprise (F6) ; le téléphone sert au client pour commander.' },
    { k = 'biz', type = 'text', label = "Identifiant de l'entreprise de taxi", default = 'taxi', maxlen = 32, pattern = '^[%w_]+$', hint = 'Ses employés en service reçoivent les courses.' },
    { k = 'base', type = 'number', label = 'Prise en charge ($)', default = 50, min = 0, max = 10000 },
    { k = 'per_km', type = 'number', label = 'Prix au kilomètre ($)', default = 40, min = 0, max = 10000 },
    { k = 'per_min', type = 'number', label = 'Prix à la minute ($)', default = 5, min = 0, max = 1000 },
    { k = 'commission', type = 'number', label = 'Part du chauffeur (%)', default = 30, min = 0, max = 100, hint = 'Le reste va à la caisse de la compagnie.' },
    { k = 'max_fare', type = 'number', label = "Prix maximal d'une course ($)", default = 5000, min = 10, max = 1000000 },
    { k = 'call_ttl', type = 'number', label = 'Une commande expire après (minutes)', default = 10, min = 1, max = 60 },
} })
PB.Module({
    id = 'taxi', label = 'Taxi', icon = 'car', group = 'Serveur', order = 87, perm = 'biz.edit', hint = 'Commandes, taximètre, tarifs',
    caps = function()
        return PB.Capsify({
            { 'Commande depuis le téléphone', 'ok', 'App Taxi : le client commande, les chauffeurs en service sont prévenus avec sa position.' },
            { 'Taximètre mesuré par le serveur', 'ok', 'Distance réellement parcourue au volant + temps ; affiché au chauffeur et aux passagers.' },
            { 'Facture à la fin de la course', 'ok', "Le chauffeur choisit le client (F6) : il paie tout de suite ou plus tard ; la part du chauffeur est versée au paiement." },
            { 'Compagnie de taxi', Tx.Biz() and 'ok' or 'warn', Tx.Biz() and ('Entreprise : ' .. Tx.Biz().label) or "Crée l'entreprise « Taxi Downtown Cab » (Builder › Entreprises) ou règle son identifiant ici." },
        })
    end,
    doc = "## Taxi\nLe client ouvre **Téléphone › Taxi › Commander**. Les chauffeurs **en service** reçoivent la course et l'acceptent avec **F6 › Courses en attente** (GPS vers le client).\nQuand le client est à bord : **F6 › Démarrer le compteur**. À l'arrivée : **F6 › Terminer la course**, puis **F6 › Envoyer la facture** et choisir le client (il est entouré à l'écran). Il paie tout de suite ou plus tard ; la part du chauffeur est versée au paiement.",
    view = function(ctx)
        return { tabs = {
            { id = 'live', label = 'En cours', icon = 'car', build = function()
                local rows = {}
                for _, c in pairs(Tx.calls) do rows[#rows + 1] = { who = c.name, state = c.driver and ('Prise par ' .. c.driverName) or 'En attente', at = c.at } end
                for src, m in pairs(Tx.meters) do rows[#rows + 1] = { who = m.driverName .. ' (chauffeur)', state = ('Compteur : %s, %.1f km'):format(money(Tx.Fare(m)), m.meters / 1000), at = m.at } end
                return { B.table({ id = 'txl', title = 'Commandes et courses', columns = { { k = 'who', label = 'Qui' }, { k = 'state', label = 'État' }, { k = 'at', label = 'Depuis', type = 'date' } }, rows = rows, empty = 'Aucune course en cours.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
