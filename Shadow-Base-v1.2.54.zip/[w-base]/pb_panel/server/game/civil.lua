-- Métiers civils : missions à étapes (livraison, collecte, coursier…) payées par le serveur après vérification.
-- Le client affiche le trajet et signale son arrivée ; le serveur revérifie distance, ordre des étapes et temps de trajet avant de payer.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('civil.edit', 'Créer, modifier et supprimer des missions de métiers civils', 'civil', true)

PB.Migrate('051_game_civil', 'Métiers civils : missions, journal', {
    [[CREATE TABLE IF NOT EXISTS pb_civil_jobs (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, descr VARCHAR(160) NOT NULL DEFAULT '', x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, steps TEXT NULL,
        pay INT NOT NULL DEFAULT 0, cooldown INT NOT NULL DEFAULT 120, min_secs INT NOT NULL DEFAULT 8, radius DOUBLE NOT NULL DEFAULT 6, source VARCHAR(8) NOT NULL DEFAULT 'free', biz VARCHAR(32) NOT NULL DEFAULT '',
        enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_civil_log (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, job VARCHAR(32) NOT NULL, pay INT NOT NULL DEFAULT 0, at INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license, at), KEY k_job (job, at))]],
})
local DEFAULT_JOBS = {
    { 'livraison', 'Livraison de colis', 'Récupère les colis au dépôt puis livre-les dans le centre-ville.', 180.0, -950.0, 30.1, { { 195.0, -934.0, 30.7, 'Legion Square' }, { 275.5, -345.6, 45.0, 'Pillbox Hill' }, { -621.0, 46.0, 43.6, 'Tinsel Towers' } }, 420, 180, 12 },
    { 'dechets', 'Collecte des déchets', 'Fais la tournée des points de collecte du sud de la ville.', -348.0, -1569.0, 25.2, { { -255.0, -1530.0, 31.5, 'Rue de Davis' }, { -180.0, -1432.0, 31.3, 'Strawberry' }, { -115.0, -1771.0, 29.9, 'Chamberlain Hills' } }, 380, 180, 12 },
    { 'coursier', 'Coursier express', 'Une enveloppe à porter vite : deux arrêts, un seul trajet.', 293.0, -590.0, 43.2, { { -47.2, -585.8, 37.9, 'Integrity Way' }, { -270.0, -962.0, 31.2, 'Alta Street' } }, 260, 120, 10 },
}
PB.Migrate('052_game_civil_seed', 'Missions par défaut', function()
    for _, j in ipairs(DEFAULT_JOBS) do
        local steps = {}
        for _, s in ipairs(j[7]) do steps[#steps + 1] = { x = s[1], y = s[2], z = s[3], label = s[4] } end
        DB.exec('INSERT IGNORE INTO pb_civil_jobs (id, label, descr, x, y, z, steps, pay, cooldown, min_secs) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', { j[1], j[2], j[3], j[4], j[5], j[6], PB.Json(steps), j[8], j[9], j[10] })
    end
end)

PB.Cfg.Define('civil', { enabled = true, max_per_hour = 12, pay_to = 'bank', max_speed = 70, blips = true, use_distance = 2.5, keep_days = 30 })

local Cv = {}
G.Civil = Cv
local function cfg(k, d) return PB.Cfg.Get('civil', k, d) end
local function now() return os.time() end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function acct(id) return 'biz:' .. id end

function Cv.All() return DB.q('SELECT * FROM pb_civil_jobs ORDER BY label') or {} end
function Cv.Get(id) return DB.one('SELECT * FROM pb_civil_jobs WHERE id = ?', { tostring(id) }) end
local function stepsOf(j) local t = PB.FromJson(j.steps, {}) return type(t) == 'table' and t or {} end
local function gross(j) return G.Eco and math.floor(j.pay * G.Eco.Get('income_mult') + 0.5) or j.pay end
local function dist3(a, b) return math.sqrt((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2 + (a.z - b.z) ^ 2) end

-- Missions en cours -----------------------------------------------------------------------------------------------------------------------
local runs = {}     -- src -> { job, idx, t, prev, steps }
function Cv.Active(src) return runs[tonumber(src) or -1] end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end

local function sendStep(src, r, j)
    local s = r.steps[r.idx]
    TriggerClientEvent('pb:g:civil:step', src, PB.Json({ job = j.id, label = j.label, idx = r.idx, total = #r.steps, step = { x = s.x, y = s.y, z = s.z, label = s.label }, radius = j.radius }))
end
local function stop(src, why)
    if runs[src] then
        runs[src] = nil
        TriggerClientEvent('pb:g:civil:stop', src, PB.Json({}))
        if why then G.Notify(src, { type = 'warn', title = 'Mission', text = why }) end
    end
end
Cv.Stop = stop
AddEventHandler('playerDropped', function() runs[source] = nil last[tostring(source)] = nil end)
local prevDead = G.SetDead
function G.SetDead(src, dead) if dead and runs[tonumber(src)] then stop(tonumber(src), 'Mission annulée : tu es à terre.') end return prevDead(src, dead) end

local function cooldownLeft(license, j)
    local r = DB.one('SELECT MAX(at) AS at FROM pb_civil_log WHERE license = ? AND job = ?', { license, j.id })
    if not r or not r.at then return 0 end
    return math.max(0, r.at + j.cooldown - now())
end

RegisterNetEvent('pb:g:civil:start', function(id)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 600) then return end
    local j = Cv.Get(id)
    local p = G.Get(src)
    if not j or not PB.ToBool(j.enabled) then return end
    if G.DistTo(src, j.x, j.y, j.z) > cfg('use_distance', 2.5) + 6 then return end
    if runs[src] then G.Notify(src, { type = 'error', text = 'Tu as déjà une mission en cours (/stopjob pour l\'abandonner).' }) return end
    local steps = stepsOf(j)
    if #steps == 0 then G.Notify(src, { type = 'error', text = "Cette mission n'a pas d'étape : préviens un administrateur." }) return end
    local cd = cooldownLeft(p.license, j)
    if cd > 0 then G.Notify(src, { type = 'error', text = ('Reviens dans %d s : le travail a été fait.'):format(cd) }) return end
    local hour = DB.one('SELECT COUNT(*) AS n FROM pb_civil_log WHERE license = ? AND at > ?', { p.license, now() - 3600 })
    if hour and hour.n >= cfg('max_per_hour', 12) then G.Notify(src, { type = 'error', text = ('Maximum %d missions par heure : repose-toi.'):format(cfg('max_per_hour', 12)) }) return end
    if j.source == 'society' and (not G.Eco or G.Eco.Balance(acct(j.biz)) < gross(j)) then G.Notify(src, { type = 'error', text = "L'entreprise n'a pas les fonds pour payer cette mission." }) return end
    runs[src] = { job = j.id, idx = 1, t = now(), prev = { x = j.x, y = j.y, z = j.z }, steps = steps }
    G.Notify(src, { type = 'info', title = j.label, text = ('Mission commencée : %d étape(s). /stopjob pour abandonner.'):format(#steps) })
    sendStep(src, runs[src], j)
end)

RegisterNetEvent('pb:g:civil:arrive', function(idx)
    local src = source
    local r = runs[src]
    if not r or not usable(src) then return end
    idx = math.floor(tonumber(idx) or 0)
    if idx ~= r.idx then return end
    local j = Cv.Get(r.job)
    if not j then stop(src) return end
    local s = r.steps[r.idx]
    if G.DistTo(src, s.x, s.y, s.z) > j.radius + 8 then return end
    -- temps de trajet plausible : au moins min_secs, et pas plus vite que max_speed
    local need = math.max(j.min_secs, math.floor(dist3(r.prev, s) / math.max(1, cfg('max_speed', 70))))
    if now() - r.t < need then G.Notify(src, { type = 'warn', text = 'Pas si vite : prends le temps de faire le travail.' }) return end
    r.prev, r.t = { x = s.x, y = s.y, z = s.z }, now()
    if r.idx < #r.steps then
        r.idx = r.idx + 1
        G.Notify(src, { type = 'success', title = j.label, text = ('Étape %d/%d terminée.'):format(r.idx - 1, #r.steps) })
        sendStep(src, r, j)
        return
    end
    -- dernière étape : paie
    local pay = gross(j)
    local pl = G.Get(src)
    local src_acct = j.source == 'society' and acct(j.biz) or 'salaires'
    if j.source == 'society' then
        if not G.Eco.Take(src_acct, pay, 'Mission ' .. j.id, pl.license) then stop(src, "L'entreprise n'a plus les fonds : mission non payée.") return end
    elseif G.Eco then G.Eco.Book(src_acct, -pay, 'Mission ' .. j.id, pl.license) end
    runs[src] = nil
    G.AddMoney(src, cfg('pay_to', 'bank') == 'cash' and 'cash' or 'bank', pay, 'Mission ' .. j.label)
    DB.exec('INSERT INTO pb_civil_log (license, job, pay, at) VALUES (?, ?, ?, ?)', { pl.license, j.id, pay, now() })
    TriggerClientEvent('pb:g:civil:stop', src, PB.Json({}))
    G.Notify(src, { type = 'success', title = j.label, text = ('Mission terminée : %s versés sur ton compte%s.'):format(money(pay), cfg('pay_to', 'bank') == 'cash' and ' (espèces)' or ' bancaire') })
    if G.Premium and G.Premium.Boost then G.Premium.Boost(src, 'mission', pay) end   -- boost de missions acheté à la boutique
    TriggerEvent('pb_panel:missionDone', src, j.id, pay)
end)

RegisterNetEvent('pb:g:civil:cancel', function() local src = source if runs[src] then stop(src, 'Mission abandonnée.') end end)

local function purge() local d = cfg('keep_days', 30) if d > 0 then DB.exec('DELETE FROM pb_civil_log WHERE at < ?', { now() - d * 86400 }) end end
Cv.Purge = purge
CreateThread(function() Wait(math.random(0, 3600000)) while true do Wait(3600000) pcall(purge) end end)

function G.CivilPoints()
    local out = {}
    for _, j in ipairs(Cv.All()) do if PB.ToBool(j.enabled) then out[#out + 1] = { id = j.id, label = j.label, desc = j.descr, x = j.x, y = j.y, z = j.z, pay = gross(j), steps = #stepsOf(j) } end end
    return out
end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
local function zero(c) return not c or (c.x == 0 and c.y == 0) end
PB.Action('civil.save', 'civil.edit', function(ctx, p)
    local v = p.values or {}
    local fields = {
        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'descr', type = 'text', label = 'Description', maxlen = 160 },
        { k = 'coords', type = 'coords', label = 'Point de départ' }, { k = 'pay', type = 'number', label = 'Paie', min = 1, max = 1000000 }, { k = 'cooldown', type = 'number', label = 'Délai avant de refaire la mission (s)', min = 0, max = 86400 },
        { k = 'min_secs', type = 'number', label = 'Durée minimale par étape (s)', min = 0, max = 600 }, { k = 'radius', type = 'number', label = "Rayon d'arrivée (m)", min = 2, max = 30, int = false },
        { k = 'source', type = 'select', label = 'Payée par', opts = { { 'free', 'Le serveur (compte « salaires »)' }, { 'society', "Une entreprise (sa caisse)" } } }, { k = 'biz', type = 'text', label = 'Entreprise', maxlen = 32, pattern = '^[%w_]*$' }, { k = 'enabled', type = 'toggle', label = 'Active' },
    }
    local data = { id = v.id, label = v.label, descr = v.descr or '', coords = v.coords or { x = 0, y = 0, z = 0, h = 0 }, pay = v.pay or 0, cooldown = v.cooldown or 120, min_secs = v.min_secs or 8, radius = v.radius or 6, source = v.source or 'free', biz = v.biz or '', enabled = v.enabled ~= false }
    for i = 1, 5 do fields[#fields + 1] = { k = 's' .. i, type = 'coords', label = 'Étape ' .. i } data['s' .. i] = v['s' .. i] or { x = 0, y = 0, z = 0, h = 0 } end
    local c, err = PB.Validate(fields, data)
    if not c then return false, err end
    if zero(c.coords) then return false, 'Place le point de départ.' end
    local steps = {}
    for i = 1, 5 do if not zero(c['s' .. i]) then steps[#steps + 1] = { x = c['s' .. i].x, y = c['s' .. i].y, z = c['s' .. i].z, label = 'Étape ' .. #steps + 1 } end end
    if #steps == 0 then return false, 'Place au moins une étape.' end
    if c.source == 'society' and (c.biz == '' or not (G.Biz and G.Biz.Get(c.biz))) then return false, 'Choisis une entreprise existante pour une mission payée par une entreprise.' end
    local before = Cv.Get(c.id)
    DB.exec('INSERT INTO pb_civil_jobs (id, label, descr, x, y, z, steps, pay, cooldown, min_secs, radius, source, biz, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), descr = VALUES(descr), x = VALUES(x), y = VALUES(y), z = VALUES(z), steps = VALUES(steps), pay = VALUES(pay), cooldown = VALUES(cooldown), min_secs = VALUES(min_secs), radius = VALUES(radius), source = VALUES(source), biz = VALUES(biz), enabled = VALUES(enabled)',
        { c.id, c.label, c.descr, c.coords.x, c.coords.y, c.coords.z, PB.Json(steps), c.pay, c.cooldown, c.min_secs, c.radius, c.source, c.source == 'society' and c.biz or '', c.enabled and 1 or 0 })
    ctx.audit('config', before and 'civil.edit' or 'civil.create', c.id, before, { id = c.id, pay = c.pay, steps = #steps })
    G.PushConfig()
    ctx.toast = 'Mission enregistrée.'
    return true
end)
PB.Action('civil.delete', 'civil.edit', function(ctx, p)
    local j = Cv.Get(p.id)
    if not j then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_civil_jobs WHERE id = ?', { j.id })
    for src, r in pairs(runs) do if r.job == j.id then stop(src, 'Cette mission a été supprimée.') end end
    ctx.audit('config', 'civil.delete', j.id, j, nil)
    G.PushConfig()
    ctx.toast = 'Mission supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette mission ?', text = 'Les missions en cours sont annulées.', danger = true } })

local settings = Form.Cfg({ ns = 'civil', id = 'settings', title = 'Réglages des métiers civils', perm = 'civil.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Missions actives', default = true }, { k = 'blips', type = 'toggle', label = 'Afficher les points de départ sur la carte', default = true },
    { k = 'pay_to', type = 'select', label = 'Versement de la paie', opts = { { 'bank', 'Sur le compte bancaire' }, { 'cash', 'En espèces' } }, default = 'bank' },
    { k = 'max_per_hour', type = 'number', label = 'Missions maximum par heure et par joueur', default = 12, min = 1, max = 100 },
    { k = 'max_speed', type = 'number', label = 'Vitesse maximale plausible (m/s)', default = 70, min = 10, max = 200, hint = 'Sert à refuser une arrivée trop rapide (70 m/s ≈ 250 km/h).' },
    { k = 'use_distance', type = 'number', label = 'Distance pour commencer (m)', default = 2.5, min = 1, max = 10, int = false, step = 0.5 }, { k = 'keep_days', type = 'number', label = 'Conservation du journal (jours)', default = 30, min = 1, max = 365 },
} })

PB.Module({
    id = 'civil', label = 'Métiers civils', icon = 'briefcase', group = 'Serveur', order = 99, perm = 'civil.view', hint = 'Missions à étapes payées',
    caps = function()
        return PB.Capsify({
            { 'Missions à étapes (livraison, collecte, coursier…)', 'ok', "Trajet affiché au joueur ; le serveur contrôle l'ordre, la distance et le temps de trajet." },
            { 'Paie par le serveur ou par la caisse d\'une entreprise', 'ok', 'Multiplicateur de salaires de l\'économie appliqué ; délai et plafond horaire contre l\'abus.' },
            { 'Véhicule de service, objets à transporter, animations de travail', 'off', "Non fournis : la mission valide la présence aux points, pas le véhicule utilisé." },
            { 'Récolte, craft, pêche, petits jobs', 'ok', "Ressources à part : wb_activites (récolte, transformation, craft), wb_peche (pêche avancée), wb_jobs (missions des entreprises)." },
            { 'Gangs et organisations', 'ok', "Utilise une entreprise de type « Entreprise » : grades, caisse, recrutement et factures depuis le menu F6." },
        })
    end,
    doc = "## Métiers civils\nUne mission a un **point de départ** (le joueur appuie sur E) et jusqu'à 5 **étapes**. À la dernière, le serveur paie. Chaque étape est contrôlée : distance, ordre, et temps de trajet minimum.\n\nCoordonnées par défaut : des lieux connus de Los Santos, à vérifier en jeu. Pour tes scripts : l'évènement `pb_panel:missionDone` (source, id de la mission, paie).",
    view = function(ctx)
        return { tabs = {
            { id = 'overview', label = "Vue d'ensemble", icon = 'chart', build = function()
                local d = DB.one('SELECT COUNT(*) AS n, COALESCE(SUM(pay), 0) AS s FROM pb_civil_log WHERE at > ?', { now() - 86400 })
                local act = 0 for _ in pairs(runs) do act = act + 1 end
                return { { type = 'cards', items = {
                    { title = 'Missions', value = tostring(#Cv.All()), icon = 'briefcase', tone = '#6fb4ff', sub = 'Disponibles' }, { title = 'En cours', value = tostring(act), icon = 'activity', tone = '#dfe2e7', sub = 'Joueurs en mission' },
                    { title = 'Terminées (24 h)', value = tostring(d and d.n or 0), icon = 'check', tone = '#7be0a4', sub = 'Sur tout le serveur' }, { title = 'Versé (24 h)', value = money(d and d.s or 0), icon = 'coins', tone = '#ffb457', sub = 'Paies de missions' } } } }
            end },
            { id = 'jobs', label = 'Missions', icon = 'route', build = function()
                local rows = {}
                for _, j in ipairs(Cv.All()) do
                    rows[#rows + 1] = { label = j.label, id = j.id, pay = money(gross(j)), steps = #stepsOf(j), by = j.source == 'society' and ('Entreprise : ' .. j.biz) or 'Serveur', on = PB.ToBool(j.enabled) and { text = 'Active', tone = 'ok' } or { text = 'Inactive', tone = 'off' },
                        actions = ctx.has('civil.edit') and { { action = 'civil.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = j.id } } } or {} }
                end
                local blocks = { B.table({ id = 'cj', title = 'Missions (' .. #rows .. ')', columns = { { k = 'label', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'pay', label = 'Paie' }, { k = 'steps', label = 'Étapes' }, { k = 'by', label = 'Payée par' }, { k = 'on', label = 'État', type = 'badge' } }, rows = rows, empty = 'Aucune mission.' }),
                    B.notice('info', "Coordonnées par défaut : des lieux connus de Los Santos. Vérifie le point de départ et chaque étape en jeu avant d'ouvrir.") }
                if ctx.has('civil.edit') then
                    local fields = {
                        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'descr', type = 'text', label = 'Description', maxlen = 160, wide = true },
                        { k = 'coords', type = 'coords', label = 'Point de départ', wide = true }, { k = 'pay', type = 'number', label = 'Paie', min = 1, max = 1000000 }, { k = 'cooldown', type = 'number', label = 'Délai avant de refaire la mission (s)', min = 0, max = 86400 },
                        { k = 'min_secs', type = 'number', label = 'Durée minimale par étape (s)', min = 0, max = 600 }, { k = 'radius', type = 'number', label = "Rayon d'arrivée (m)", min = 2, max = 30, int = false },
                        { k = 'source', type = 'select', label = 'Payée par', opts = { { 'free', 'Le serveur (compte « salaires »)' }, { 'society', "Une entreprise (sa caisse)" } } }, { k = 'biz', type = 'text', label = "Entreprise (si payée par une entreprise)", maxlen = 32 }, { k = 'enabled', type = 'toggle', label = 'Active' } }
                    local values = { id = '', label = '', descr = '', coords = { x = 0, y = 0, z = 0, h = 0 }, pay = 300, cooldown = 120, min_secs = 8, radius = 6, source = 'free', biz = '', enabled = true }
                    for i = 1, 5 do fields[#fields + 1] = { k = 's' .. i, type = 'coords', label = 'Étape ' .. i .. (i == 1 and '' or ' (facultative)'), wide = true } values['s' .. i] = { x = 0, y = 0, z = 0, h = 0 } end
                    blocks[#blocks + 1] = { type = 'form', id = 'civil.form', title = 'Ajouter ou modifier une mission', desc = 'Même identifiant = modification. Au moins une étape.', cols = 2, fields = fields, values = values, submit = { action = 'civil.save', label = 'Enregistrer' } }
                end
                return blocks
            end },
            { id = 'log', label = 'Activité', icon = 'clock', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT l.job, l.pay, l.at, p.firstname, p.lastname FROM pb_civil_log l LEFT JOIN pb_players p ON p.license = l.license ORDER BY l.id DESC LIMIT 60') or {}) do
                    rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at), who = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''), job = r.job, pay = money(r.pay) }
                end
                return { B.table({ id = 'cl', title = 'Dernières missions terminées', columns = { { k = 'at', label = 'Date' }, { k = 'who', label = 'Joueur' }, { k = 'job', label = 'Mission', type = 'mono' }, { k = 'pay', label = 'Paie' } }, rows = rows, empty = 'Aucune mission terminée.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'civil.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('métiers civils', function(R)
    for _, j in ipairs(Cv.All()) do
        local st = stepsOf(j)
        R.check(j.x ~= 0 or j.y ~= 0, 'mission ' .. j.id, 'point de départ non défini')
        R.check(#st > 0, 'mission ' .. j.id, "aucune étape : personne ne peut la terminer")
        R.check(j.pay > 0, 'mission ' .. j.id, 'paie nulle')
        if j.source == 'society' then R.check(G.Biz and G.Biz.Get(j.biz) ~= nil, 'mission ' .. j.id, "l'entreprise « " .. j.biz .. " » n'existe pas : la mission ne peut jamais être payée") end
        local prev = { x = j.x, y = j.y, z = j.z }
        for i, s in ipairs(st) do
            if prev then R.check(math.floor(dist3(prev, s) / math.max(1, cfg('max_speed', 70))) <= 600, 'mission ' .. j.id .. ' étape ' .. i, 'étape trop éloignée de la précédente (plus de 10 minutes de trajet à vitesse maximale)') end
            prev = s
        end
    end
    local any = DB.one('SELECT COUNT(*) AS n FROM pb_civil_jobs WHERE enabled = 1')
    if not (any and any.n > 0) then R.warn('missions actives', "aucune mission active : crée ou réactive une mission (panel › Métiers civils)") end
end)

-- Missions supprimables au Builder (F10 › « Supprimer le point le plus proche ») et repérées dans « Points posés »
PB.OnReady(function()
    if not (PB.Place and PB.Place.Register) then return end
    PB.Place.Register({ id = 'civil_job', label = 'Mission civile (départ)', group = 'Activités', icon = 'briefcase', hidden = true,
        create = function() return false, 'Les missions civiles se créent dans le panel (Métiers civils).' end,
        list = function()
            local out = {}
            for _, j in ipairs(Cv.All()) do out[#out + 1] = { id = j.id, label = j.label, x = tonumber(j.x), y = tonumber(j.y), z = tonumber(j.z) } end
            return out
        end,
        remove = function(id)
            local j = Cv.Get(id)
            if not j then return false end
            DB.exec('DELETE FROM pb_civil_jobs WHERE id = ?', { j.id })
            for src, r in pairs(runs) do if r.job == j.id then stop(src, 'Cette mission a été supprimée.') end end
            G.PushConfig()
            return true
        end })
end)
-- Une fois : les 3 missions d'exemple (livraison, déchets, coursier) avaient des positions par défaut, pas posées en jeu : désactivées.
-- Elles restent dans le panel (Métiers civils) pour être replacées et réactivées si le serveur en veut.
PB.OnReady(function()
    if PB.Cfg.Get('civil', 'demo_off_v1', false) == true then return end
    for _, d in ipairs(DEFAULT_JOBS) do
        local j = Cv.Get(d[1])
        if j and math.abs((tonumber(j.x) or 0) - d[4]) < 0.5 and math.abs((tonumber(j.y) or 0) - d[5]) < 0.5 then DB.exec('UPDATE pb_civil_jobs SET enabled = 0 WHERE id = ?', { j.id }) end
    end
    PB.Cfg.Set('civil', 'demo_off_v1', true, nil, 'Missions d\'exemple désactivées')
    G.PushConfig()
end)
