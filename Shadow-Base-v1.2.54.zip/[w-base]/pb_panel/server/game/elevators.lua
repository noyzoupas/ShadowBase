-- Ascenseurs (v1.2.43) : le staff les crée au Builder (F10 › Builder › Ascenseurs). Un ascenseur = une liste d'étages, chacun posé là où
-- se tient le staff (position + orientation lues ici, sur le serveur). Les joueurs appuient sur E à un étage, choisissent la destination
-- et sont téléportés avec un fondu. Accès : tout le monde, ou réservé à une entreprise / une organisation.
-- Le serveur revérifie tout : l'ascenseur, l'accès, que le joueur est bien à un étage, que l'étage visé existe.

local P = PB.Perm
local G, DB = PB.G, PB.DB
local S = G.Staff
local El = {}
G.Elevators = El

PB.Migrate('398_elevators', 'Ascenseurs du Builder', {
    [[CREATE TABLE IF NOT EXISTS pb_elevators (id INT NOT NULL AUTO_INCREMENT, label VARCHAR(40) NOT NULL, access VARCHAR(48) NOT NULL DEFAULT 'all',
        floors TEXT NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
})
PB.Cfg.Define('elevators', { enabled = true, use_dist = 2.0, fade_ms = 600 })
local function cfg(k, d) return PB.Cfg.Get('elevators', k, d) end
local MAX_ELEV, MAX_FLOORS = 100, 20
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>|"\\]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, n)) end

local cache = nil
function El.List()
    if cache then return cache end
    cache = {}
    for _, r in ipairs(DB.q('SELECT id, label, access, floors FROM pb_elevators ORDER BY id') or {}) do
        local floors = {}
        for _, f in ipairs(PB.FromJson(r.floors or '[]', {}) or {}) do
            if type(f) == 'table' and tonumber(f.x) and tonumber(f.y) and tonumber(f.z) then
                floors[#floors + 1] = { label = clean(f.label, 32), x = tonumber(f.x), y = tonumber(f.y), z = tonumber(f.z), h = tonumber(f.h) or 0 }
            end
        end
        cache[#cache + 1] = { id = tonumber(r.id), label = r.label, access = r.access or 'all', floors = floors }
    end
    return cache
end
function El.Get(id) id = tonumber(id) for _, e in ipairs(El.List()) do if e.id == id then return e end end return nil end
local function save(e)
    DB.exec('UPDATE pb_elevators SET label = ?, access = ?, floors = ? WHERE id = ?', { e.label, e.access, PB.Json(e.floors), e.id })
    cache = nil
end
local function pushAll(target)
    local out = {}
    if cfg('enabled', true) ~= false then
        for _, e in ipairs(El.List()) do if #e.floors >= 2 then out[#out + 1] = { id = e.id, label = e.label, floors = e.floors } end end
    end
    TriggerClientEvent('pb:g:elev:all', target or -1, PB.Json(out))
end
El.Push = pushAll
table.insert(G.beginHooks, function(src) pushAll(src) end)
PB.Cfg.OnChange('elevators', function() pushAll() end)

-- accès : 'all', 'biz:<id>' ou 'gang:<id>'
local function accessLabel(a)
    a = tostring(a or 'all')
    local k, id = a:match('^(%a+):(.+)$')
    if k == 'biz' then local b = G.Biz and G.Biz.Get(id) return 'Entreprise : ' .. (b and b.label or id) end
    if k == 'gang' then local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id] return 'Organisation : ' .. (d and d.label or id) end
    return 'Tout le monde'
end
El.AccessLabel = accessLabel
function El.CanUse(src, e)
    local k, id = tostring(e.access or 'all'):match('^(%a+):(.+)$')
    if not k then return true end
    local p = G.Get(src)
    if not p then return false end
    if k == 'biz' then
        local m = G.Biz and G.Biz.MemberOf(p.license)
        if m and m.biz_id == id then return true end
        local j2 = G.BizCat and G.BizCat.Job2 and G.BizCat.Job2(p.license)
        return j2 ~= nil and j2.biz == id
    elseif k == 'gang' then
        local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
        return g ~= nil and g.id == id
    end
    return false
end

local function pos(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return nil end
    return { x = math.floor(c.x * 100 + 0.5) / 100, y = math.floor(c.y * 100 + 0.5) / 100, z = math.floor((c.z - 0.98) * 100 + 0.5) / 100, h = math.floor((GetEntityHeading(ped) or 0) * 10 + 0.5) / 10 }
end
-- étage où se trouve le joueur (le plus proche, dans la distance d'utilisation)
function El.FloorAt(src, e)
    local best, bd
    for i, f in ipairs(e.floors) do
        local d = G.DistTo(src, f.x, f.y, f.z + 0.98)
        if d <= (tonumber(cfg('use_dist', 2.0)) or 2.0) + 1.0 and (not bd or d < bd) then best, bd = i, d end
    end
    return best
end

-- Utilisation par les joueurs -----------------------------------------------------------------------------------------------------------
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)
function El.Use(src, id, idx)
    if cfg('enabled', true) == false then return false, 'Les ascenseurs sont désactivés.' end
    local e = El.Get(id)
    if not e or #e.floors < 2 then return false, 'Ascenseur introuvable.' end
    local pl = G.Get(src)
    -- (v1.2.43) pas d'ascenseur pour s'enfuir menotté ou inconscient
    if not pl or PB.ToBool(pl.row.dead) or (G.IsCuffed and G.IsCuffed(src)) then return false, 'Impossible dans ton état.' end
    if not El.CanUse(src, e) then return false, 'Accès réservé : ' .. accessLabel(e.access) .. '.' end
    local from = El.FloorAt(src, e)
    if not from then return false, "Approche-toi de l'ascenseur." end
    idx = math.floor(tonumber(idx) or 0)
    local f = e.floors[idx]
    if not f then return false, 'Étage introuvable.' end
    if idx == from then return false, 'Tu es déjà à cet étage.' end
    TriggerClientEvent('pb:g:elev:go', src, PB.Json({ x = f.x, y = f.y, z = f.z, h = f.h, label = f.label, elev = e.label, fade = math.max(0, math.min(3000, tonumber(cfg('fade_ms', 600)) or 600)) }))
    return true
end
RegisterNetEvent('pb:g:elev:use', function(id, idx)
    local src = source
    if not throttle(src, 1200) then return end
    local ok, msg = El.Use(src, id, idx)
    if not ok then G.Notify(src, { type = 'error', title = 'Ascenseur', text = msg }) end
end)

-- Builder (menu staff) ---------------------------------------------------------------------------------------------------------------------
table.insert(S.SpecExtra, function(src, spec)
    if not P.Has(src, 'carte.place') then return end
    local list = {}
    for _, e in ipairs(El.List()) do
        local fl = {}
        for i, f in ipairs(e.floors) do fl[i] = { label = f.label, z = math.floor(f.z + 0.5) } end
        list[#list + 1] = { id = e.id, label = e.label, access = e.access, accessLabel = accessLabel(e.access), floors = fl }
    end
    local opts = { { 'all', 'Tout le monde' } }
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do opts[#opts + 1] = { 'biz:' .. b.id, 'Entreprise : ' .. b.label } end
    local gangs = {}
    for gid, d in pairs(G.Tags and G.Tags.GangDefs and G.Tags.GangDefs() or {}) do gangs[#gangs + 1] = { 'gang:' .. gid, 'Organisation : ' .. (d.label or gid) } end
    table.sort(gangs, function(a, b) return a[2] < b[2] end)
    for _, g in ipairs(gangs) do opts[#opts + 1] = g end
    spec.elevators = { list = list, access = opts, max = MAX_FLOORS }
end)

local function staffName(src) return PB.Actor and PB.Actor(src).name or ('#' .. tostring(src)) end
local function elevOf(p) local e = El.Get(p.id) if not e then return nil, 'Ascenseur introuvable.' end return e end
local function done(e, msg) save(e) pushAll() return true, msg end

S.Def('el_create', 'carte.place', { noduty = true, run = function(src, _, p)
    local label = clean(p.label, 40)
    if label == '' then return false, "Donne un nom à l'ascenseur." end
    if #El.List() >= MAX_ELEV then return false, MAX_ELEV .. ' ascenseurs au maximum.' end
    local here = pos(src)
    if not here then return false, 'Position introuvable.' end
    local first = clean(p.floor, 32)
    if first == '' then first = 'Rez-de-chaussée' end
    here.label = first
    DB.insert('INSERT INTO pb_elevators (label, access, floors, by_name, at) VALUES (?, ?, ?, ?, ?)', { label, 'all', PB.Json({ here }), tostring(staffName(src)):sub(1, 64), os.time() })
    cache = nil
    PB.Audit.Log('staff', 'elevator.create', src, label, nil, nil, {})
    return true, ('Ascenseur « %s » créé, premier étage « %s » posé ici. Va à l\'étage suivant et ajoute-le.'):format(label, first)
end, log = true })
S.Def('el_floor_add', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    if #e.floors >= MAX_FLOORS then return false, MAX_FLOORS .. ' étages au maximum.' end
    local here = pos(src)
    if not here then return false, 'Position introuvable.' end
    for _, f in ipairs(e.floors) do if math.sqrt((f.x - here.x) ^ 2 + (f.y - here.y) ^ 2 + (f.z - here.z) ^ 2) < 1.5 then return false, 'Un étage est déjà posé ici.' end end
    local label = clean(p.label, 32)
    if label == '' then label = 'Étage ' .. (#e.floors) end
    here.label = label
    e.floors[#e.floors + 1] = here
    return done(e, ('Étage « %s » ajouté (%d étages).'):format(label, #e.floors))
end })
S.Def('el_floor_move', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local f = e.floors[math.floor(tonumber(p.idx) or 0)]
    if not f then return false, 'Étage introuvable.' end
    local here = pos(src)
    if not here then return false, 'Position introuvable.' end
    f.x, f.y, f.z, f.h = here.x, here.y, here.z, here.h
    return done(e, ('« %s » déplacé ici.'):format(f.label))
end })
S.Def('el_floor_rename', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local f = e.floors[math.floor(tonumber(p.idx) or 0)]
    local label = clean(p.label, 32)
    if not f then return false, 'Étage introuvable.' end
    if label == '' then return false, "Donne un nom à l'étage." end
    f.label = label
    return done(e, 'Étage renommé : ' .. label .. '.')
end })
S.Def('el_floor_order', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local i = math.floor(tonumber(p.idx) or 0)
    local j = i + (tonumber(p.dir) == -1 and -1 or 1)
    if not e.floors[i] or not e.floors[j] then return false, 'Déjà en bout de liste.' end
    e.floors[i], e.floors[j] = e.floors[j], e.floors[i]
    return done(e, 'Ordre des étages modifié.')
end })
S.Def('el_floor_del', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local i = math.floor(tonumber(p.idx) or 0)
    if not e.floors[i] then return false, 'Étage introuvable.' end
    local f = table.remove(e.floors, i)
    return done(e, ('Étage « %s » supprimé.'):format(f.label))
end })
S.Def('el_floor_goto', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local f = e.floors[math.floor(tonumber(p.idx) or 0)]
    if not f then return false, 'Étage introuvable.' end
    TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = f.x, y = f.y, z = f.z + 0.5 }))
    return true
end })
S.Def('el_rename', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local label = clean(p.label, 40)
    if label == '' then return false, "Donne un nom à l'ascenseur." end
    e.label = label
    return done(e, 'Ascenseur renommé : ' .. label .. '.')
end })
S.Def('el_access', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    local a = tostring(p.access or 'all')
    local k, id = a:match('^(%a+):([%w_%-]+)$')
    if a ~= 'all' then
        if k == 'biz' and not (G.Biz and G.Biz.Get(id)) then return false, 'Entreprise inconnue.' end
        if k == 'gang' and not (G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id]) then return false, 'Organisation inconnue.' end
        if k ~= 'biz' and k ~= 'gang' then return false, 'Accès invalide.' end
    end
    e.access = a
    return done(e, 'Accès : ' .. accessLabel(a) .. '.')
end })
S.Def('el_delete', 'carte.place', { noduty = true, run = function(src, _, p)
    local e, err = elevOf(p)
    if not e then return false, err end
    DB.exec('DELETE FROM pb_elevators WHERE id = ?', { e.id })
    cache = nil
    pushAll()
    PB.Audit.Log('staff', 'elevator.delete', src, e.label, nil, nil, {})
    return true, ('Ascenseur « %s » supprimé.'):format(e.label)
end, log = true })

-- Panel : liste et réglages
local form = PB.Form.Cfg({ ns = 'elevators', id = 'settings', title = 'Ascenseurs', perm = 'carte.place', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Ascenseurs actifs', default = true },
    { k = 'use_dist', type = 'number', label = "Distance pour appeler l'ascenseur (m)", default = 2.0, min = 1, max = 5 },
    { k = 'fade_ms', type = 'number', label = 'Durée du fondu au noir (ms)', default = 600, min = 0, max = 3000 },
} })
PB.Module({
    id = 'elevators', label = 'Ascenseurs', icon = 'building', group = 'Serveur', order = 142, perm = 'carte.place', hint = 'Ascenseurs créés au Builder, plusieurs étages',
    caps = function() return PB.Capsify({
        { 'Création en jeu au Builder (F10 › Builder › Ascenseurs)', 'ok', "Chaque étage est posé là où tu te tiens (position et orientation)." },
        { 'Accès réservé à une entreprise ou une organisation', 'ok', 'Vérifié par le serveur à chaque trajet.' },
        { 'Vérifié dans un vrai client FiveM', 'off', 'Non : testé en simulation.' } }) end,
    doc = "## Ascenseurs\nMenu staff **F10 › Builder › Ascenseurs** (droit « placer des points ») :\n1. Place-toi devant l'ascenseur du premier étage, **Créer un ascenseur** (nom + nom du premier étage).\n2. Va à chaque autre étage (noclip, escaliers…) et **Ajouter un étage ici**.\n3. Optionnel : **Accès** réservé à une entreprise ou une organisation.\n\nEn jeu, le joueur s'approche d'un étage, appuie sur **E** et choisit sa destination : fondu au noir, il arrive à l'étage choisi, tourné comme le staff l'était en le posant.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Ascenseurs', icon = 'building', build = function()
                local rows = {}
                for _, e in ipairs(El.List()) do
                    local names = {}
                    for _, f in ipairs(e.floors) do names[#names + 1] = f.label end
                    rows[#rows + 1] = { id = e.id, label = e.label, floors = #e.floors .. ' : ' .. table.concat(names, ', '), access = accessLabel(e.access) }
                end
                return { PB.B.table({ id = 'elevl', title = 'Ascenseurs (' .. #rows .. ')', search = true, columns = { { k = 'id', label = 'N°' }, { k = 'label', label = 'Nom' }, { k = 'floors', label = 'Étages' }, { k = 'access', label = 'Accès' } }, rows = rows, empty = 'Aucun ascenseur : F10 › Builder › Ascenseurs.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
