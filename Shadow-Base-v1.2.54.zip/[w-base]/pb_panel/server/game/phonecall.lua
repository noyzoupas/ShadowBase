-- Appels vocaux du téléphone, portés par pma-voice. Le serveur décide de tout : qui sonne, qui décroche, sur quel canal on parle.
-- pma-voice ne fait que transporter la voix. Les canaux sont tirés au hasard et surveillés : un joueur qui rejoint un appel qui
-- n'est pas le sien (événement pma-voice:setPlayerCall envoyé à la main) en est retiré. Sans pma-voice démarré, les appels sont refusés.
local G, DB = PB.G, PB.DB
local Ph = G.Phone

PB.Cfg.Define('phone', { calls = true, ring_secs = 30, call_max_mins = 30, svc_calls = true, calls_per_min = 6, conf_max = 5, emergency = true })
PB.Migrate('052_phone_calls', 'Téléphone : journal des appels', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_calls (id INT NOT NULL AUTO_INCREMENT, from_num VARCHAR(40) NOT NULL, to_num VARCHAR(40) NOT NULL, at INT NOT NULL, secs INT NOT NULL DEFAULT 0, status VARCHAR(12) NOT NULL DEFAULT 'ring', seen TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_to (to_num), KEY k_from (from_num), KEY k_at (at))]]))
end)

local C = { list = {}, of = {}, listen = {} }   -- list : id -> appel ; of : joueur -> id de l'appel où il parle (ou qu'il passe) ;
                                                -- listen : joueur proche d'un haut-parleur -> id de l'appel qu'il entend
Ph.Calls = C
local function cfg(k, d) return PB.Cfg.Get('phone', k, d) end
local function now() return os.time() end
local nextId = 0

function C.VoiceUp() return GetResourceState and GetResourceState('pma-voice') == 'started' end
local function setVoice(src, ch) pcall(function() exports['pma-voice']:setPlayerCall(src, ch) end) end
local function channel()
    for _ = 1, 50 do
        local ch = math.random(100000, 2000000000)
        local used = false
        for _, c in pairs(C.list) do if c.ch == ch then used = true end end
        if not used then return ch end
    end
    return math.random(100000, 2000000000)
end

-- Ce que voit chaque côté : { state = outgoing | incoming | live | ended, id, label, num, svc, since, ring, reason }
local function push(src, state, c, extra)
    local d = { state = state, id = c and c.id or 0 }
    if c then
        local mine = src == c.from
        d.num = mine and c.to or c.fromNum
        d.svc = c.svc and true or nil
        d.label = mine and c.toLabel or (c.labels and c.labels[src]) or c.fromNum
        d.since = c.liveAt and (now() - c.liveAt) or 0
        d.ring = cfg('ring_secs', 30)
        d.speaker = c.speaker and c.speaker[src] or nil
        d.emergency = c.emergency or nil
        local n = 0 for _ in pairs(c.members or {}) do n = n + 1 end
        if n > 0 or c.conf then d.count = n + 2 d.label = 'Conférence (' .. (n + 2) .. ')' end
    end
    for k, v in pairs(extra or {}) do d[k] = v end
    TriggerClientEvent('pb:g:call', src, PB.Json(d))
end
local function logEnd(c, status)
    if not c.logId then return end
    DB.exec('UPDATE pb_phone_calls SET status = ?, secs = ? WHERE id = ?', { status, c.liveAt and (now() - c.liveAt) or 0, c.logId })
end

-- Fin d'appel : chacun reçoit une raison lisible ; la voix est coupée des deux côtés.
function C.End(c, status, reasonCaller, reasonOther)
    if not c or not C.list[c.id] then return end
    C.list[c.id] = nil
    logEnd(c, status)
    if c.state == 'live' then setVoice(c.from, 0) if c.peer then setVoice(c.peer, 0) end end
    for id in pairs(c.members or {}) do setVoice(id, 0) if C.of[id] == c.id then C.of[id] = nil end push(id, 'ended', c, { reason = reasonOther or reasonCaller }) end
    for id in pairs(c.invites or {}) do push(id, 'ended', c, { reason = 'Appel manqué.' }) end
    for id in pairs(c.listeners or {}) do setVoice(id, 0) C.listen[id] = nil end
    for _, s in pairs({ c.from, c.peer or false, c.dst or false }) do if s and C.of[s] == c.id then C.of[s] = nil end end
    push(c.from, 'ended', c, { reason = reasonCaller })
    if c.peer then push(c.peer, 'ended', c, { reason = reasonOther or reasonCaller }) end
    if c.state == 'ring' then for s in pairs(c.targets) do push(s, 'ended', c, { reason = reasonOther or 'Appel manqué.' }) end end
    TriggerEvent('pb_panel:callEnded', c.from, c.peer, status, c.liveAt and (now() - c.liveAt) or 0)
end

local recent = {}
local function rate(src)
    local t, keep = now(), {}
    for _, v in ipairs(recent[src] or {}) do if t - v < 60 then keep[#keep + 1] = v end end
    if #keep >= (tonumber(cfg('calls_per_min', 6)) or 6) then recent[src] = keep return false end
    keep[#keep + 1] = t
    recent[src] = keep
    return true
end
local function missed(fromNum, to)
    DB.insert('INSERT INTO pb_phone_calls (from_num, to_num, at, status) VALUES (?, ?, ?, ?)', { fromNum, to, now(), 'missed' })
end

-- Passer un appel : à un numéro (555-0123) ou à un service de l'annuaire (svc:police) ; renvoie true ou false + raison
function C.Start(src, to)
    if cfg('calls', true) == false or cfg('enabled', true) == false then return false, 'Les appels sont désactivés.' end
    if not C.VoiceUp() then return false, 'Appels indisponibles : la voix (pma-voice) ne tourne pas sur le serveur.' end
    local p = G.Get(src)
    if not p or not Ph.Usable(src) then return false, 'Impossible pour le moment.' end
    if not Ph.HasPhone(src) then return false, "Tu n'as pas de téléphone sur toi." end
    if C.of[src] then return false, 'Tu es déjà en ligne.' end
    local me = Ph.Number(p.license)
    local mu = DB.one('SELECT muted_until FROM pb_phone_numbers WHERE license = ?', { p.license })
    if mu and mu.muted_until > now() then return false, 'Ton téléphone est suspendu par le staff.' end
    to = tostring(to or ''):sub(1, 40):gsub('%-$', '')
    local svc = to:match('^svc:([%w_]+)$')
    local targets, labels, dst = {}, {}, nil
    local emergency = to == '911'
    if emergency then
        if cfg('emergency', true) == false then return false, 'Le 911 est désactivé : appelle un service de l\'annuaire.' end
        if not rate(src) then return false, "Trop d'appels : attends un instant." end
        local any = false
        for id in pairs(G.Players()) do
            local bc = id ~= src and G.Biz and G.Biz.Ctx(id)
            if bc and bc.duty and (bc.biz.kind == 'police' or bc.biz.kind == 'ems') and not C.of[id] and Ph.Usable(id) and Ph.HasPhone(id) then
                targets[id] = true any = true
                labels[id] = 'URGENCE 911 · ' .. (Ph.ContactName(G.Get(id).license, me) or me)
            end
        end
        if not any then missed(me, to) return false, 'Aucun policier ni secouriste en service pour le moment.' end
    elseif svc then
        if cfg('svc_calls', true) == false then return false, 'Les services ne prennent pas les appels : envoie-leur un message.' end
        local b = G.Biz and G.Biz.Get(svc)
        if not b or not PB.ToBool(b.enabled) then return false, 'Service introuvable.' end
        if not rate(src) then return false, "Trop d'appels : attends un instant." end
        local any = false
        for _, id in ipairs(Ph.OnDutyOf(svc)) do
            if id ~= src and not C.of[id] and Ph.Usable(id) and Ph.HasPhone(id) then
                targets[id] = true any = true
                local lic = G.Get(id).license
                labels[id] = b.label .. ' · ' .. (Ph.ContactName(lic, me) or me)
            end
        end
        if not any then missed(me, to) return false, 'Personne ne peut répondre au service pour le moment. Laisse-lui un message.' end
    else
        if not Ph.ValidNumber(to) then return false, 'Numéro invalide (ex. 555-0123).' end
        if to == me then return false, 'Tu ne peux pas t\'appeler toi-même.' end
        local lic = Ph.LicenseOf(to)
        if not lic then return false, "Ce numéro n'existe pas." end
        if not rate(src) then return false, "Trop d'appels : attends un instant." end
        dst = Ph.SourceOf(lic)
        if not dst or not Ph.Usable(dst) or not Ph.HasPhone(dst) then missed(me, to) return false, 'Ton correspondant est injoignable.' end
        if C.of[dst] then missed(me, to) return false, 'Ligne occupée.' end
        if Ph.QuietFor and Ph.QuietFor(lic) then missed(me, to) return false, 'Ton correspondant ne répond pas.' end
        if Ph.Blocked and Ph.Blocked(lic, me) then return false, 'Ton correspondant ne répond pas.' end
        targets[dst] = true
        labels[dst] = Ph.ContactName(lic, me) or me
    end
    nextId = nextId + 1
    local c = { id = nextId, from = src, fromNum = me, to = to, toLabel = emergency and 'Urgences 911' or Ph.LabelOf(p.license, to), svc = svc, dst = dst, targets = targets, labels = labels, state = 'ring', t0 = now(), emergency = emergency or nil, members = {}, invites = {} }
    c.logId = DB.insert('INSERT INTO pb_phone_calls (from_num, to_num, at, status) VALUES (?, ?, ?, ?)', { me, to, now(), 'ring' })
    C.list[c.id] = c
    C.of[src] = c.id
    if dst then C.of[dst] = c.id end
    push(src, 'outgoing', c)
    -- 911 : la position de l'appelant part tout de suite sur la carte des policiers et secouristes en service
    local ped = emergency and GetPlayerPed(src)
    local pos = ped and ped ~= 0 and GetEntityCoords(ped)
    for id in pairs(targets) do
        local pf = Ph.Prefs and Ph.Prefs(G.Get(id).license) or {}
        push(id, 'incoming', c, { sound = emergency or pf.sound ~= false })
        if pos then TriggerClientEvent('pb:g:phone:alert', id, PB.Json({ id = src, x = pos.x, y = pos.y, z = pos.z, label = 'Appel 911 · ' .. me })) end
    end
    if emergency then PB.Audit.Log('police', 'call.911', me, '', nil, nil, { x = pos and pos.x, y = pos and pos.y }) end
    return true
end

-- Conférence : pendant un appel, un participant fait sonner un autre numéro ; s'il décroche, il rejoint le même canal
local function count(c) local n = 2 for _ in pairs(c.members or {}) do n = n + 1 end return n end
local function pushAll(c) push(c.from, 'live', c) push(c.peer, 'live', c) for id in pairs(c.members) do push(id, 'live', c) end end
function C.Invite(src, num)
    local c = C.of[src] and C.list[C.of[src]]
    if not c or c.state ~= 'live' or c.emergency then return false, 'Tu dois être en ligne (hors appel d\'urgence).' end
    local inv = 0 for _ in pairs(c.invites) do inv = inv + 1 end
    if count(c) + inv >= (tonumber(cfg('conf_max', 5)) or 5) then return false, ('Conférence pleine (%d personnes maximum).'):format(tonumber(cfg('conf_max', 5)) or 5) end
    num = tostring(num or ''):sub(1, 12)
    if not Ph.ValidNumber(num) then return false, 'Numéro invalide (ex. 555-0123).' end
    local p = G.Get(src)
    local me = Ph.Number(p.license)
    local lic = Ph.LicenseOf(num)
    local dst = lic and Ph.SourceOf(lic)
    if not dst or num == me or not Ph.Usable(dst) or not Ph.HasPhone(dst) then return false, 'Ce correspondant est injoignable.' end
    if C.of[dst] then return false, 'Ligne occupée.' end
    if (Ph.QuietFor and Ph.QuietFor(lic)) or (Ph.Blocked and Ph.Blocked(lic, me)) then return false, 'Ce correspondant ne répond pas.' end
    if not rate(src) then return false, "Trop d'appels : attends un instant." end
    c.invites[dst] = now()
    c.labels[dst] = 'Conférence · ' .. (Ph.ContactName(lic, me) or me)
    push(dst, 'incoming', c, { sound = true })
    return true, 'Ça sonne chez ' .. (Ph.ContactName(p.license, num) or num) .. '…'
end

local function ringingFor(src, id)
    local c = C.list[tonumber(id) or -1]
    if c and ((c.state == 'ring' and c.targets[src]) or (c.invites and c.invites[src])) then return c end
    for _, x in pairs(C.list) do if (x.state == 'ring' and x.targets[src]) or (x.invites and x.invites[src]) then return x end end
end

function C.Answer(src, id)
    local c = ringingFor(src, id)
    if not c then return false, "Plus personne n'appelle." end
    if C.of[src] and C.of[src] ~= c.id then return false, 'Raccroche d\'abord ton appel en cours.' end
    if not Ph.Usable(src) then return false, 'Impossible pour le moment.' end
    if c.state == 'live' and c.invites[src] then   -- rejoint la conférence
        c.invites[src] = nil
        c.members[src] = true c.conf = true
        C.of[src] = c.id
        setVoice(src, c.ch)
        pushAll(c)
        return true
    end
    c.state, c.peer, c.liveAt, c.ch = 'live', src, now(), channel()
    c.speaker, c.listeners = {}, {}
    C.of[src] = c.id
    for id2 in pairs(c.targets) do if id2 ~= src then push(id2, 'ended', c, { reason = 'Un collègue a décroché.' }) end end
    c.targets = {}
    if c.dst and c.dst ~= src then C.of[c.dst] = nil end
    DB.exec('UPDATE pb_phone_calls SET status = ? WHERE id = ?', { 'live', c.logId })
    setVoice(c.from, c.ch)
    setVoice(src, c.ch)
    push(c.from, 'live', c)
    push(src, 'live', c)
    return true
end

-- Raccrocher : met fin à l'appel en cours, annule l'appel qui sonne, ou refuse un appel entrant
function C.Hangup(src, id)
    local mine = C.of[src] and C.list[C.of[src]]
    if mine then
        if mine.state == 'ring' and src == mine.dst then C.End(mine, 'declined', 'Appel refusé.', 'Appel refusé.') return true end
        if mine.state == 'ring' then C.End(mine, 'cancel', 'Appel annulé.', 'Appel manqué.') return true end
        if count(mine) > 2 then   -- conférence : seul celui qui raccroche s'en va
            local first = next(mine.members)
            if src == mine.from then mine.from, mine.peer = mine.peer, first mine.members[first] = nil
            elseif src == mine.peer then mine.peer = first mine.members[first] = nil
            else mine.members[src] = nil end
            mine.speaker[src] = nil
            C.of[src] = nil
            setVoice(src, 0)
            push(src, 'ended', mine, { reason = 'Tu as quitté la conférence.' })
            pushAll(mine)
            return true
        end
        C.End(mine, 'done', 'Appel terminé.', 'Ton correspondant a raccroché.')
        return true
    end
    local c = ringingFor(src, id)
    if not c then return false end
    if c.invites[src] then c.invites[src] = nil push(src, 'ended', c, { reason = 'Appel refusé.' }) G.Notify(c.from, { type = 'warn', title = 'Conférence', text = 'Invitation refusée.' }) return true end
    c.targets[src] = nil
    push(src, 'ended', c, { reason = 'Appel refusé.' })
    if next(c.targets) == nil then C.End(c, 'declined', c.svc and 'Le service ne répond pas.' or 'Appel refusé.') end
    return true
end

-- Haut-parleur : les joueurs à moins de 3 m de celui qui l'a activé entendent l'appel (et peuvent y parler, comme un vrai haut-parleur).
local SPK_IN, SPK_OUT = 3.0, 4.5
local function coords(id) local ped = GetPlayerPed(id) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function dist(a, b) local dx, dy, dz = a.x - b.x, a.y - b.y, (a.z or 0) - (b.z or 0) return math.sqrt(dx * dx + dy * dy + dz * dz) end
function C.Speaker(src)
    local c = C.of[src] and C.list[C.of[src]]
    if not c or c.state ~= 'live' then return false end
    c.speaker[src] = not c.speaker[src] or nil
    pushAll(c)
    if not c.speaker[src] then C.Speakers() end
    return true
end
function C.Speakers()
    for _, c in pairs(C.list) do
        if c.state == 'live' then
            local srcs = {}
            for s in pairs(c.speaker) do local p = coords(s) if p then srcs[#srcs + 1] = p end end
            local function nearest(id) local p = coords(id) if not p then return 1e9 end local best = 1e9 for _, q in ipairs(srcs) do best = math.min(best, dist(p, q)) end return best end
            for id in pairs(c.listeners) do
                if nearest(id) > SPK_OUT or not G.Get(id) then c.listeners[id] = nil C.listen[id] = nil setVoice(id, 0) end
            end
            if #srcs > 0 then
                for id in pairs(G.Players()) do
                    if id ~= c.from and id ~= c.peer and not C.of[id] and not C.listen[id] and Ph.Usable(id) and nearest(id) <= SPK_IN then
                        c.listeners[id] = true C.listen[id] = c.id
                        setVoice(id, c.ch)
                        G.Notify(id, { type = 'info', title = 'Haut-parleur', text = 'Tu entends un appel téléphonique à côté de toi.' })
                    end
                end
            end
        end
    end
end

-- Surveillance (toutes les secondes) : sonnerie trop longue, durée maximale, joueur à terre ou parti, canaux usurpés
local tick = 0
function C.Tick()
    tick = tick + 1
    local t = now()
    for _, c in pairs(C.list) do
        if c.state == 'ring' then
            if t - c.t0 >= (tonumber(cfg('ring_secs', 30)) or 30) then C.End(c, 'missed', 'Pas de réponse.', 'Appel manqué.')
            elseif not G.Get(c.from) or not Ph.Usable(c.from) then C.End(c, 'cancel', 'Appel coupé.', 'Appel manqué.') end
        else
            local max = tonumber(cfg('call_max_mins', 30)) or 0
            for id, at in pairs(c.invites) do if t - at >= (tonumber(cfg('ring_secs', 30)) or 30) or not G.Get(id) then c.invites[id] = nil push(id, 'ended', c, { reason = 'Appel manqué.' }) end end
            for id in pairs(c.members) do if not G.Get(id) or not Ph.Usable(id) then c.members[id] = nil C.of[id] = nil setVoice(id, 0) push(id, 'ended', c, { reason = 'Appel coupé.' }) pushAll(c) end end
            if max > 0 and t - c.liveAt >= max * 60 then C.End(c, 'done', 'Durée maximale atteinte : appel coupé.')
            elseif not Ph.Usable(c.from) or not Ph.Usable(c.peer) then C.End(c, 'done', 'Appel coupé.') end
        end
    end
    if tick % 3 == 0 and C.VoiceUp() and Player then
        for id in pairs(G.Players()) do
            local ok, ch = pcall(function() return Player(id).state.callChannel end)
            ch = ok and tonumber(ch) or 0
            if ch ~= 0 then
                local c = C.of[id] and C.list[C.of[id]]
                local l = C.listen[id] and C.list[C.listen[id]]
                if (not c or c.state ~= 'live' or c.ch ~= ch) and not (l and l.ch == ch) then
                    setVoice(id, 0)
                    PB.Audit.Log('anticheat', 'call_channel', 'système', GetPlayerName(id) or tostring(id), nil, nil, { canal = ch })
                end
            end
        end
    end
end
CreateThread(function() while true do Wait(1000) pcall(C.Tick) pcall(C.Speakers) end end)

AddEventHandler('playerDropped', function()
    local src = source
    recent[src] = nil
    local l = C.listen[src] and C.list[C.listen[src]]
    if l then l.listeners[src] = nil end
    C.listen[src] = nil
    for _, c in pairs(C.list) do if c.invites then c.invites[src] = nil end end
    local cm = C.of[src] and C.list[C.of[src]]
    if cm and cm.members[src] then cm.members[src] = nil C.of[src] = nil pushAll(cm) end
    local mine = C.of[src] and C.list[C.of[src]]
    if mine then C.End(mine, mine.state == 'ring' and 'missed' or 'done', 'Appel coupé.', mine.state == 'ring' and 'Appel manqué.' or 'Ton correspondant a été coupé.') end
    for _, c in pairs(C.list) do
        if c.targets[src] then
            c.targets[src] = nil
            if c.state == 'ring' and next(c.targets) == nil then C.End(c, 'missed', 'Pas de réponse.') end
        end
    end
end)

RegisterNetEvent('pb:g:call:start', function(to)
    local src = source
    if G.DutyGate and G.DutyGate(src) then return end
    local ok, why = C.Start(src, to)
    if not ok then push(src, 'ended', nil, { reason = why }) end
end)
RegisterNetEvent('pb:g:call:answer', function(id)
    local src = source
    local ok, why = C.Answer(src, id)
    if not ok and why then G.Notify(src, { type = 'error', text = why }) end
end)
RegisterNetEvent('pb:g:call:hangup', function(id) C.Hangup(source, id) end)
RegisterNetEvent('pb:g:call:speaker', function() C.Speaker(source) end)
RegisterNetEvent('pb:g:call:invite', function(num)
    local src = source
    local ok, msg = C.Invite(src, num)
    G.Notify(src, { type = ok and 'info' or 'error', title = 'Conférence', text = msg })
end)
-- Le client redemande l'état à l'ouverture du téléphone (écran d'appel)
RegisterNetEvent('pb:g:call:sync', function()
    local src = source
    local c = C.of[src] and C.list[C.of[src]]
    if c then push(src, c.state == 'live' and 'live' or (src == c.from and 'outgoing' or 'incoming'), c) return end
    c = ringingFor(src)
    if c then push(src, 'incoming', c) end
end)

exports('IsInCall', function(src) local c = C.of[tonumber(src)] and C.list[C.of[tonumber(src)]] return c ~= nil and c.state == 'live' end)
exports('EndCall', function(src) local c = C.of[tonumber(src)] and C.list[C.of[tonumber(src)]] if c then C.End(c, 'done', 'Appel coupé.') return true end return false end)

-- Application « Appels » du téléphone : clavier, appels récents, appels manqués -----------------------------------------------------
function Ph.Missed(license)
    local me = Ph.Number(license)
    local r = DB.one("SELECT COUNT(*) AS n FROM pb_phone_calls WHERE to_num = ? AND status = 'missed' AND seen = 0", { me })
    return r and r.n or 0
end
Ph.DATA.calls = function(src)
    local p = G.Get(src)
    local me = Ph.Number(p.license)
    local out = {}
    for _, r in ipairs(DB.q('SELECT id, from_num, to_num, at, secs, status FROM pb_phone_calls WHERE from_num = ? OR to_num = ? ORDER BY id DESC LIMIT 30', { me, me }) or {}) do
        local mine = r.from_num == me
        local other = mine and r.to_num or r.from_num
        out[#out + 1] = { num = other, label = Ph.LabelOf(p.license, other), out = mine, missed = (not mine) and r.status == 'missed', status = r.status, secs = r.secs, at = Ph.Stamp(r.at), svc = other:match('^svc:') ~= nil }
    end
    DB.exec("UPDATE pb_phone_calls SET seen = 1 WHERE to_num = ? AND status = 'missed' AND seen = 0", { me })
    local contacts = {}
    for _, c in ipairs(DB.q('SELECT name, number FROM pb_phone_contacts WHERE license = ? ORDER BY name LIMIT 60', { p.license }) or {}) do contacts[#contacts + 1] = { name = c.name, number = c.number } end
    return { recent = out, contacts = contacts, voice = C.VoiceUp() and cfg('calls', true) ~= false, svc = cfg('svc_calls', true) ~= false }
end
Ph.ACT.call = function(_, src, p)
    if G.DutyGate and G.DutyGate(src) then return false, 'Indisponible en service staff.' end
    local ok, why = C.Start(src, p.num)
    return ok, why
end

-- Ménage : même durée de conservation que les messages
CreateThread(function()
    Wait(math.random(0, 3600000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(3600000)
        local d = tonumber(cfg('keep_days', 30)) or 30
        if d > 0 then pcall(DB.exec, 'DELETE FROM pb_phone_calls WHERE at < ?', { now() - d * 86400 }) end
    end
end)

PB.SelfTest.Add('appels', function(R)
    if cfg('calls', true) == false then return end
    if C.VoiceUp() then R.ok() else R.warn('appels vocaux', 'pma-voice ne tourne pas : personne ne pourra appeler (ajoute ensure pma-voice ou coupe les appels dans Téléphone › Réglages)') end
end)
