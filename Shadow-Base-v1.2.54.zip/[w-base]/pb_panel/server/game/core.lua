-- Noyau des interfaces et scripts en jeu : joueurs (identité, apparence, statuts, argent), configuration envoyée aux clients, exports.
-- Autonome : tables propres (pb_players, pb_vehicles), aucun framework requis. Si ESX / QBCore est installé, ne lance pas deux systèmes de personnages en même temps.

PB.G = PB.G or {}
local G = PB.G
local DB, P = PB.DB, PB.Perm

PB.Migrate('040_game_players', 'Joueurs (identité, apparence, statuts, argent)', {
    [[CREATE TABLE IF NOT EXISTS pb_players (
        license VARCHAR(64) NOT NULL, firstname VARCHAR(32) NOT NULL DEFAULT '', lastname VARCHAR(32) NOT NULL DEFAULT '',
        dob VARCHAR(10) NOT NULL DEFAULT '', sex VARCHAR(1) NOT NULL DEFAULT 'm', height INT NOT NULL DEFAULT 175, nationality VARCHAR(32) NOT NULL DEFAULT '',
        appearance MEDIUMTEXT NULL, hunger DOUBLE NOT NULL DEFAULT 100, thirst DOUBLE NOT NULL DEFAULT 100, stress DOUBLE NOT NULL DEFAULT 0,
        cash BIGINT NOT NULL DEFAULT 0, bank BIGINT NOT NULL DEFAULT 0, dead TINYINT(1) NOT NULL DEFAULT 0, created TINYINT(1) NOT NULL DEFAULT 0,
        last_seen INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_vehicles (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, plate VARCHAR(8) NOT NULL, model VARCHAR(48) NOT NULL, label VARCHAR(64) NOT NULL DEFAULT '',
        bought_at INT NOT NULL DEFAULT 0, price BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (id), UNIQUE KEY uq_plate (plate))]],
})

P.Register('game.view', 'Voir les interfaces en jeu', 'game')

G.beginHooks = {}
PB.Cfg.Define('ambience', { mute_shop_music = true })
local NS = { 'ambience', 'hud', 'death', 'character', 'notify', 'chat', 'interact', 'biz', 'flow', 'inv', 'bank', 'garage', 'housing', 'phone', 'civil', 'menus', 'quick', 'personal', 'staff', 'tags', 'justice', 'ctx', 'fuel', 'mech', 'crime', 'weapons', 'territories', 'flags', 'me3d', 'tablets', 'pause', 'graffiti', 'trunk', 'place', 'animmenu', 'rental', 'radio', 'premium', 'minimap', 'launder', 'ems' }
local players = {}        -- src -> { license, row, dirty }
local STATUS = { hunger = true, thirst = true, stress = true }

local function row(license)
    local r = DB.one('SELECT * FROM pb_players WHERE license = ?', { license })
    if r then return r end
    DB.exec('INSERT INTO pb_players (license, last_seen) VALUES (?, ?)', { license, os.time() })
    return DB.one('SELECT * FROM pb_players WHERE license = ?', { license })
end

-- Configuration envoyée aux clients ------------------------------------------------------------------------------------------------
function G.ClientConfig()
    local c = {}
    for _, ns in ipairs(NS) do c[ns] = PB.Cfg.All(ns) or {} end
    c.staffmenu = PB.Cfg.Get('interface', 'staffmenu')
    c.gta_police = PB.Cfg.Get('world', 'police_wanted', false) == true   -- serveur GTA RP : par défaut aucune étoile ni police du jeu
    c.ui = { glass = PB.Cfg.Get('interface', 'glass_level', 'solid'), style = 'nova' }   -- v1.2.37 : un seul style, Shadow Studio V2
    c.shops = G.ShopList and G.ShopList() or {}
    c.shops_settings = PB.Cfg.All('shops')
    c.stashes = G.StashList and G.StashList() or {}
    c.bank_points = G.BankPoints and G.BankPoints() or {}
    c.garage_points = G.GaragePoints and G.GaragePoints() or {}
    c.housing_points = G.HousingPoints and G.HousingPoints() or {}
    c.civil_points = G.CivilPoints and G.CivilPoints() or {}
    if c.crime and G.Crime and G.Crime.AllHeists then
        local cr = {}
        for k, v in pairs(c.crime) do cr[k] = v end
        cr.heists = G.Crime.AllHeists()
        c.crime = cr
    end
    -- économie (v1.2.42) : les menus du jeu affichent les mêmes prix que ceux payés (multiplicateur × TVA)
    c.eco = { factor = G.Eco and G.Eco.Factor and G.Eco.Factor() or 1, income = G.Eco and G.Eco.IncomeMult and G.Eco.IncomeMult() or 1 }
    local season = PB.Season and PB.Season.Info()
    local fest = season and season.game and season or nil   -- fête active ET appliquée au jeu
    c.brand = { name = PB.Cfg.Get('general', 'server_name', ''), color = fest and fest.color or PB.Cfg.Get('general', 'color_primary', '#dfe2e7'), color2 = fest and fest.color2 or PB.Cfg.Get('general', 'color_secondary', '#8e95a1'), logo = (PB.Cfg.Get('general', 'server_logo', '') ~= '' and PB.Cfg.Get('general', 'server_logo', '')) or PB.Cfg.Get('general', 'logo_url', '') or '',   -- logo en jeu, sinon le logo https du panel
        banner = PB.Cfg.Get('general', 'server_banner', ''),
        season = fest and { id = fest.id, decor = fest.decor } or nil }
    -- v1.2.37 : sans réglage dans le panel, on reprend le server.cfg (nom du serveur, bannière de la liste des serveurs)
    if c.brand.name == '' then c.brand.name = (tostring(GetConvar('sv_projectName', '')):gsub('%^%d', ''):gsub('|.*$', ''):gsub('^%s+', ''):gsub('%s+$', '')) end
    if c.brand.name == '' then c.brand.name = (tostring(GetConvar('sv_hostname', '')):gsub('%^%d', ''):gsub('^%s+', ''):gsub('%s+$', '')) end
    return c
end

local pushPending = false
function G.PushConfig(target)
    if target then TriggerClientEvent('pb:g:cfg', target, PB.Json(G.ClientConfig())) return end
    if pushPending then return end
    pushPending = true
    SetTimeout(300, function() pushPending = false TriggerClientEvent('pb:g:cfg', -1, PB.Json(G.ClientConfig())) end)
end
for _, ns in ipairs(NS) do PB.Cfg.OnChange(ns, function() G.PushConfig() end) end
PB.Cfg.OnChange('shops', function() G.PushConfig() end)
PB.Cfg.OnChange('interface', function(k) if k == 'staffmenu' or k == 'glass_level' or k == 'ui_style' then G.PushConfig() end end)
PB.Cfg.OnChange('general', function() G.PushConfig() end)
PB.Cfg.OnChange('eco', function(k) if k ~= 'backup' and k ~= 'custom_presets' then G.PushConfig() end end)
PB.Cfg.OnChange('world', function(k) if k == 'police_wanted' then G.PushConfig() end end)
-- Mode automatique : la fête change à minuit sans que personne ne touche à rien
local lastFest = PB.Season and PB.Season.Current() or nil
CreateThread(function()
    Wait(math.random(0, 600000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(600000)
        local cur = PB.Season and PB.Season.Current() or nil
        if cur ~= lastFest then lastFest = cur G.PushConfig() if PB.PushBrand then PB.PushBrand() end end
    end
end)

-- Joueurs -----------------------------------------------------------------------------------------------------------------------------
-- joueur qui vient de se déconnecter : encore lisible quelques secondes par les autres gestionnaires de « playerDropped »
-- (service remis à zéro, chronologie, menottes…), mais plus dans G.Players()
local leaving = {}
function G.Get(src) local k = tonumber(src) or -1 return players[k] or leaving[k] end

local function snapshot(p)
    local r = p.row
    return { hunger = math.floor(r.hunger + 0.5), thirst = math.floor(r.thirst + 0.5), stress = math.floor(r.stress + 0.5), cash = r.cash, bank = r.bank, dead = PB.ToBool(r.dead) }
end

function G.PushState(src)
    local p = players[src]
    if p then TriggerClientEvent('pb:g:state', src, PB.Json(snapshot(p))) end
end

local function save(p)
    if not p or not p.dirty then return end
    local r = p.row
    DB.exec('UPDATE pb_players SET hunger = ?, thirst = ?, stress = ?, cash = ?, bank = ?, dead = ?, last_pos = ?, last_seen = ? WHERE license = ?',
        { r.hunger, r.thirst, r.stress, r.cash, r.bank, PB.ToBool(r.dead) and 1 or 0, r.last_pos or '', os.time(), p.license })
    p.dirty = false
end

-- Dernière position (reconnexion à l'endroit de la déconnexion) : lue par le serveur (OneSync), jamais envoyée par le client.
-- Pas de relevé en prison ni dans une instance (intérieur, création) : on garde la position précédente.
local function capturePos(src, p)
    if not p or not PB.ToBool(p.row.created) then return end
    pcall(function()
        if G.IsJailed and G.IsJailed(src) then return end
        if GetPlayerRoutingBucket and (tonumber(GetPlayerRoutingBucket(src)) or 0) ~= 0 then return end
        local ped = GetPlayerPed(src)
        if not ped or ped == 0 then return end
        local c = GetEntityCoords(ped)
        if not c or (math.abs(c.x) < 1.0 and math.abs(c.y) < 1.0) or c.z < -50.0 or c.z > 2000.0 then return end
        local h = GetEntityHeading and GetEntityHeading(ped) or 0.0
        local pos = ('{"x":%.2f,"y":%.2f,"z":%.2f,"h":%.1f}'):format(c.x, c.y, c.z, tonumber(h) or 0.0)
        if pos ~= p.row.last_pos then p.row.last_pos = pos p.dirty = true end
    end)
end

function G.SaveAll() for src, p in pairs(players) do capturePos(src, p) save(p) end end
-- relevé régulier : la position reste à jour même si le serveur s'arrête brutalement
-- (v1.2.38) une sauvegarde toutes les 60 ms au lieu de tout le serveur à la même seconde
CreateThread(function() Wait(math.random(0, 120000)) while true do Wait(120000)
    local list = {} for src in pairs(players) do list[#list + 1] = src end
    for _, src in ipairs(list) do local p = players[src] if p then capturePos(src, p) save(p) end Wait(60) end
end end)

function G.Identity(src)
    local p = players[src]
    if not p then return nil end
    local r = p.row
    return { firstname = r.firstname, lastname = r.lastname, dob = r.dob, sex = r.sex, height = r.height, nationality = r.nationality, created = PB.ToBool(r.created) }
end

function G.Appearance(src)
    local p = players[src]
    return p and PB.FromJson(p.row.appearance, nil) or nil
end

-- Multi-personnages (VIP) : chaque personnage a sa propre identité de jeu (personnage 2 = « license:xxx#2 ») ; inventaire, argent, métier,
-- véhicules, logements suivent le personnage. Le staff, les bans et le VIP restent ceux du compte (identifiants FiveM).
local charChoice = {}   -- src -> numéro du personnage choisi à la connexion
local function maxChars(base) return (G.Vip and G.Vip.IsLicense(base)) and math.max(1, math.min(5, math.floor(tonumber(PB.Cfg.Get('vip', 'chars', 3)) or 3))) or 1 end
local function charLicense(base, slot) return slot > 1 and (base .. '#' .. slot) or base end
function G.CharSlot(src) return charChoice[tonumber(src) or -1] or 1 end
-- rich = true : tout ce que l'écran d'entrée affiche (apparence pour le personnage accoudé, argent, métier, dernière connexion),
-- plus les emplacements réservés aux VIP (verrouillés) pour donner envie
function G.CharList(base, rich)
    local out = {}
    local max = maxChars(base)
    for slot = 1, max do
        local r = DB.one('SELECT firstname, lastname, created, cash, bank, dob, sex, appearance, last_seen FROM pb_players WHERE license = ?', { charLicense(base, slot) })
        local made = r and PB.ToBool(r.created) and (r.firstname or '') ~= ''
        local c = { slot = slot, name = made and (r.firstname .. ' ' .. (r.lastname or '')) or nil, money = made and ((tonumber(r.cash) or 0) + (tonumber(r.bank) or 0)) or nil }
        if rich and made then
            c.first, c.last, c.dob, c.sex = r.firstname, r.lastname or '', r.dob or '', r.sex or 'm'
            c.cash, c.bank, c.seen = tonumber(r.cash) or 0, tonumber(r.bank) or 0, tonumber(r.last_seen) or 0
            c.appearance = PB.FromJson(r.appearance, nil)
            local m = DB.one('SELECT m.grade, b.label FROM pb_biz_members m LEFT JOIN pb_biz b ON b.id = m.biz_id WHERE m.license = ?', { charLicense(base, slot) })
            if m and m.label then c.job = m.label end
        end
        out[#out + 1] = c
    end
    if rich then
        local show = math.floor(tonumber(PB.Cfg.Get('entrance', 'show_locked', 3)) or 3)
        for slot = max + 1, math.min(5, show) do out[#out + 1] = { slot = slot, locked = true } end
    end
    return out
end
RegisterNetEvent('pb:g:charpick', function(slot)
    local src = source
    if players[src] or charChoice[src] then return end
    local base = P.GetLicense(src)
    slot = math.floor(tonumber(slot) or 1)
    if not base or slot < 1 or slot > maxChars(base) then return end
    charChoice[src] = slot
    G.Begin(src)
end)
AddEventHandler('playerDropped', function() charChoice[source] = nil end)

function G.Begin(src)
    local license = P.GetLicense(src)
    if not license then PB.Drop(src, 'kick', 'connexion', 'Identifiant Rockstar introuvable.', 'Aucun identifiant « license: » parmi : ' .. table.concat(GetPlayerIdentifiers(src) or {}, ', ')) return end
    -- VIP avec plusieurs personnages : choix à la connexion
    -- écran d'entrée (boîte de nuit) pour tout le monde, sinon le simple menu des VIP à plusieurs personnages
    local scene = G.Entrance and G.Entrance.On() or false
    if not charChoice[src] and (scene or maxChars(license) > 1) then
        TriggerClientEvent('pb:g:charselect', src, PB.Json({ list = G.CharList(license, scene), scene = scene and G.Entrance.Scene() or nil,
            vip = (G.Vip and G.Vip.IsLicense(license)) or false }))
        return
    end
    license = charLicense(license, charChoice[src] or 1)
    local p = { license = license, row = row(license), dirty = false }
    players[src] = p
    if p.row.created == 0 and not PB.Cfg.Get('character', 'enabled', true) then
        p.row.created = 1
        DB.exec('UPDATE pb_players SET created = 1 WHERE license = ?', { license })
    end
    G.PushConfig(src)
    G.PushState(src)
    for _, fn in ipairs(G.beginHooks) do pcall(fn, src, p) end
    -- reconnexion à la dernière position (réglage Personnage > « Reconnexion à la dernière position ») ; en prison, la justice place déjà le joueur
    local pos
    if PB.Cfg.Get('character', 'spawn_last', true) ~= false and PB.ToBool(p.row.created) and not (G.IsJailed and G.IsJailed(src)) then
        local t = PB.FromJson(p.row.last_pos or '', nil)
        if type(t) == 'table' and tonumber(t.x) and tonumber(t.y) and tonumber(t.z) then
            pos = { x = tonumber(t.x), y = tonumber(t.y), z = tonumber(t.z), h = tonumber(t.h) or 0 }
            if G.AC and G.AC.Grace then G.AC.Grace(src, 20) end
        end
    end
    TriggerClientEvent('pb:g:begin', src, PB.Json({ created = PB.ToBool(p.row.created), dead = PB.ToBool(p.row.dead), appearance = PB.FromJson(p.row.appearance, nil), sex = p.row.sex, identity = G.Identity(src), pos = pos }))
end
RegisterNetEvent('pb:clientReady', function() G.Begin(source) end)
-- identifiant du personnage joué (différent de la licence du compte pour les personnages 2 et 3 des VIP)
exports('GetCharId', function(src) local p = players[tonumber(src) or -1] return p and p.license or nil end)

AddEventHandler('playerDropped', function()
    local src = source
    local p = players[src]
    capturePos(src, p)
    save(p)
    players[src] = nil
    if p then
        leaving[src] = p
        SetTimeout(3000, function()
            if leaving[src] == p then leaving[src] = nil end
            if p.dirty then save(p) end   -- un autre script a changé son argent pendant la déconnexion : on l'enregistre aussi
        end)
    end
end)

-- Statuts (faim, soif, stress) et argent : le serveur fait foi, le client ne fait qu'afficher --------------------------------------------------------------
function G.AddStatus(src, name, delta)
    local p = players[tonumber(src) or -1]
    if not p or not STATUS[name] then return false end
    delta = tonumber(delta)
    if not delta or delta ~= delta then return false end
    p.row[name] = PB.Clamp(p.row[name] + delta, 0, 100)
    p.dirty = true
    G.PushState(tonumber(src))
    return true
end

function G.GetStatus(src, name)
    local p = players[tonumber(src) or -1]
    return p and STATUS[name] and p.row[name] or nil
end

function G.GetMoney(src, account)
    local p = players[tonumber(src) or -1]
    if not p or (account ~= 'cash' and account ~= 'bank') then return nil end
    return p.row[account]
end

function G.AddMoney(src, account, amount, reason)
    local p = players[tonumber(src) or -1]
    amount = math.floor(tonumber(amount) or 0)
    if not p or (account ~= 'cash' and account ~= 'bank') or amount <= 0 then return false end
    p.row[account] = p.row[account] + amount
    p.dirty = true
    G.PushState(tonumber(src))
    return true
end

function G.RemoveMoney(src, account, amount, reason)
    local p = players[tonumber(src) or -1]
    amount = math.floor(tonumber(amount) or 0)
    if not p or (account ~= 'cash' and account ~= 'bank') or amount <= 0 then return false end
    if p.row[account] < amount then return false end
    p.row[account] = p.row[account] - amount
    p.dirty = true
    G.PushState(tonumber(src))
    return true
end

-- Paiement : espèces d'abord ou banque d'abord selon le réglage du magasin ; renvoie le compte débité.
function G.Pay(src, amount, prefer)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return 'cash' end
    local order = prefer == 'bank' and { 'bank', 'cash' } or { 'cash', 'bank' }
    for _, acc in ipairs(order) do
        if (G.GetMoney(src, acc) or 0) >= amount then
            G.RemoveMoney(src, acc, amount)
            return acc
        end
    end
    return nil
end

-- Véhicules vus par le serveur (OneSync) : sans OneSync, le serveur ne voit pas les entités et on garde l'ancien comportement.
function G.ServerSees() return GetConvar('onesync', 'off') ~= 'off' end
-- Véhicule réseau près d'un joueur : renvoie l'entité et sa plaque (lue par le serveur), ou nil + raison.
function G.VehNear(src, netId, maxDist)
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, math.floor(tonumber(netId) or 0))
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) then return nil, 'Aucun véhicule à proximité.' end
    local c = GetEntityCoords(ent)
    if maxDist and G.DistTo(src, c.x, c.y, c.z) > maxDist then return nil, 'Le véhicule est trop loin.' end
    local okp, plate = pcall(GetVehicleNumberPlateText, ent)
    plate = tostring(okp and plate or ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, 12)
    return ent, plate
end

function G.SetDead(src, dead)
    local p = players[tonumber(src) or -1]
    if not p then return false end
    p.row.dead = dead and 1 or 0
    p.dirty = true
    save(p)
    G.PushState(tonumber(src))
    return true
end

-- Coma de faim ou de soif : le client tombe (écran d'inconscience habituel, réanimation possible par les secours)
function G.Coma(src, why)
    local p = players[tonumber(src) or -1]
    if not p or PB.ToBool(p.row.dead) then return false end
    TriggerClientEvent('pb:g:coma', src, why == 'thirst' and 'thirst' or 'hunger')
    return true
end

function G.Revive(src)
    src = tonumber(src)
    local p = players[src]
    if not p then return false end
    if PB.AC then PB.AC.Grace(src, 15) end
    -- sorti du coma : de quoi tenir le temps de manger, sinon il retomberait aussitôt
    if p.row.hunger < 15 then p.row.hunger = 15 end
    if p.row.thirst < 15 then p.row.thirst = 15 end
    G.SetDead(src, false)
    TriggerClientEvent('pb:g:revive', src)
    return true
end

-- Fiche d'informations affichée à côté du menu (au lieu d'une notification) : G.Info(src, { title = 'Informations', rows = { { 'Nom', 'Camille' }, … } })
function G.Info(src, n)
    if type(n) ~= 'table' or type(n.rows) ~= 'table' then return end
    local rows = {}
    for i = 1, math.min(#n.rows, 16) do
        local r = n.rows[i]
        if type(r) == 'table' then rows[#rows + 1] = { tostring(r[1] or ''):sub(1, 40), tostring(r[2] == nil and '' or r[2]):sub(1, 90) } end
    end
    TriggerClientEvent('pb:g:info', src, PB.Json({ title = tostring(n.title or 'Informations'):sub(1, 40), rows = rows, secs = math.max(4, math.min(60, tonumber(n.secs) or 14)) }))
end

function G.Notify(src, n)
    if type(n) ~= 'table' then return end
    TriggerClientEvent('pb:g:notify', src, PB.Json({ type = n.type or 'info', title = n.title, text = tostring(n.text or ''):sub(1, 400), duration = n.duration, click = (n.click == 'reports') and 'reports' or nil, kind = (n.kind == 'announce') and 'announce' or nil }))
end

-- Boucle de statuts : toutes les 10 s, un seul message par joueur et seulement si une valeur affichée change.
CreateThread(function()
    local tick = 0
    while true do
        Wait(10000)
        tick = tick + 1
        local hungerRate = PB.Cfg.Get('hud', 'hunger_rate', 1.0)    -- points perdus par minute
        local thirstRate = PB.Cfg.Get('hud', 'thirst_rate', 1.4)
        local stressDecay = PB.Cfg.Get('hud', 'stress_decay', 0.5)
        local enabled = PB.Cfg.Get('hud', 'needs_enabled', true)
        for src, p in pairs(players) do
            local r = p.row
            if enabled and r.created ~= 0 and not PB.ToBool(r.dead) then
                local before = snapshot(p)
                r.hunger = PB.Clamp(r.hunger - hungerRate / 6, 0, 100)
                r.thirst = PB.Clamp(r.thirst - thirstRate / 6, 0, 100)
                r.stress = PB.Clamp(r.stress - stressDecay / 6, 0, 100)
                p.dirty = true
                local after = snapshot(p)
                if after.hunger ~= before.hunger or after.thirst ~= before.thirst or after.stress ~= before.stress then G.PushState(src) end
                -- prévenir une fois sous 10, puis coma (ou dégâts) à 0
                for _, k in ipairs({ 'hunger', 'thirst' }) do
                    if r[k] <= 10 and r[k] > 0 and not (p.needWarn or {})[k] then
                        p.needWarn = p.needWarn or {} p.needWarn[k] = true
                        G.Notify(src, { type = 'warn', title = k == 'hunger' and 'Tu as très faim' or 'Tu as très soif', text = k == 'hunger' and 'Mange vite, sinon tu vas tomber dans le coma.' or 'Bois vite, sinon tu vas tomber dans le coma.' })
                    elseif r[k] > 10 and p.needWarn then p.needWarn[k] = nil end
                end
                if r.hunger <= 0 or r.thirst <= 0 then
                    if PB.Cfg.Get('hud', 'starve_coma', true) ~= false then G.Coma(src, r.hunger <= 0 and 'hunger' or 'thirst')
                    else TriggerClientEvent('pb:g:starve', src, PB.Cfg.Get('hud', 'starve_damage', 2)) end
                end
            end
            if tick % 6 == 0 then save(p) end
        end
    end
end)

-- Exports pour tes autres scripts (nourriture, boissons, boutiques, métiers…) ------------------------------------------------------------
exports('AddStatus', function(src, name, delta) return G.AddStatus(src, name, delta) end)
exports('GetStatus', function(src, name) return G.GetStatus(src, name) end)
exports('AddMoney', function(src, account, amount, reason) return G.AddMoney(src, account, amount, reason) end)
exports('RemoveMoney', function(src, account, amount, reason) return G.RemoveMoney(src, account, amount, reason) end)
exports('GetMoney', function(src, account) return G.GetMoney(src, account) end)
exports('GetIdentity', function(src) return G.Identity(src) end)
exports('IsDead', function(src) local p = players[tonumber(src) or -1] return p and PB.ToBool(p.row.dead) or false end)
exports('Revive', function(src) return G.Revive(src) end)
exports('Notify', function(src, n) return G.Notify(src, n) end)

-- Restauration d'un statut quand un script de nourriture appelle l'événement ESX / QB classique n'est volontairement pas faite :
-- utilise exports.pb_panel:AddStatus(src, 'hunger', 25).

function G.Players() return players end
