-- Ascenseurs (v1.2.43) : E à un étage -> choix de la destination -> fondu au noir et arrivée. Le serveur décide (accès, étage, distance).
-- Builder (F10 › Builder › Ascenseurs) : créer, ajouter un étage là où l'on se tient, renommer, réordonner, accès, supprimer.
local G = PBG
local list = {}
RegisterNetEvent('pb:g:elev:all', function(j) list = G.decode(j) or {} end)

local USE = 2.0
local function nearest(me)
    local best, bd, bi
    for _, e in ipairs(list) do
        for i, f in ipairs(e.floors or {}) do
            local d = #(me - vector3(f.x, f.y, f.z + 0.98))
            if not bd or d < bd then best, bd, bi = e, d, i end
        end
    end
    return best, bd, bi
end

local function openMenu(e, here)
    local items = {}
    for i, f in ipairs(e.floors) do
        local cur = i == here
        items[#items + 1] = { label = f.label, icon = cur and 'gps' or 'arrow', right = cur and 'Tu es ici' or nil, disabled = cur or nil,
            description = cur and 'Étage actuel.' or ('Entrée : aller à « %s ».'):format(f.label),
            onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:elev:use', e.id, i) end }
    end
    G.Menu.Open({ id = 'elev.' .. e.id, title = e.label, subtitle = 'Ascenseur · choisis un étage', banner = { text = 'Ascenseur' }, items = items })
end

CreateThread(function()
    local shown = false
    local function hide() if shown then shown = false G.send('prompt2', { id = 'elev', show = false }) end end
    while true do
        local wait = 600
        if #list > 0 and G.begun and not G.creating then
            local ped = PlayerPedId()
            local me = GetEntityCoords(ped)
            local e, d, i = nearest(me)
            if e and d < 25.0 then
                wait = 0
                local f = e.floors[i]
                G.Point(f.x, f.y, f.z)
                if d < USE and not IsPedInAnyVehicle(ped, false) and not G.Menu.IsOpen() then
                    if not shown then shown = true G.send('prompt2', { id = 'elev', show = true, key = 'E', text = e.label .. ' · ' .. f.label }) end
                    if IsControlJustPressed(0, 38) then hide() openMenu(e, i) end
                else hide() end
            else hide() end
        else hide() end
        Wait(wait)
    end
end)

RegisterNetEvent('pb:g:elev:go', function(j)
    local d = G.decode(j)
    if not d or not d.x then return end
    CreateThread(function()
        local ped = PlayerPedId()
        local fade = math.floor(tonumber(d.fade) or 600)
        if fade > 0 then DoScreenFadeOut(fade) local t = GetGameTimer() + fade + 400 while not IsScreenFadedOut() and GetGameTimer() < t do Wait(0) end end
        FreezeEntityPosition(ped, true)
        RequestCollisionAtCoord(d.x + 0.0, d.y + 0.0, d.z + 0.0)
        SetEntityCoords(ped, d.x + 0.0, d.y + 0.0, d.z + 0.0, false, false, false, false)
        SetEntityHeading(ped, (tonumber(d.h) or 0) + 0.0)
        local t = GetGameTimer() + 2500
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < t do Wait(0) end
        Wait(250)
        FreezeEntityPosition(ped, false)
        PlaySoundFrontend(-1, 'CHECKPOINT_NORMAL', 'HUD_MINI_GAME_SOUNDSET', true)
        if fade > 0 then DoScreenFadeIn(fade) end
        G.send('notify', { type = 'info', title = tostring(d.elev or 'Ascenseur'), text = 'Tu es à : ' .. tostring(d.label or '') .. '.' })
    end)
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then G.send('prompt2', { id = 'elev', show = false }) end end)

-- Builder : section « Ascenseurs » (les sous-menus se reconstruisent avec la liste à jour du serveur)
function G.ElevatorItems(getSpec, send)
    local function data() local s = getSpec() return s and s.elevators or { list = {}, access = {} } end
    local function find(id) for _, e in ipairs(data().list) do if e.id == id then return e end end return nil end
    local function floorMenu(id, idx)
        return { id = 'b.el.' .. id .. '.f' .. idx, title = 'Étage', refreshOnReturn = true, build = function()
            local e = find(id)
            local f = e and e.floors[idx]
            if not f then return { { label = 'Étage supprimé', disabled = true } } end
            return {
                { label = 'Y aller', icon = 'gps', description = 'Te téléporte à cet étage.', onSelect = function() send('el_floor_goto', { id = id, idx = idx }) end },
                { label = 'Déplacer ici', icon = 'pin', description = "Repose l'étage là où tu te tiens (position et orientation).", onSelect = function() send('el_floor_move', { id = id, idx = idx }) end },
                { label = 'Renommer', icon = 'edit', right = f.label, onSelect = function() local v = G.Menu.Ask("Nom de l'étage", f.label, 32) if v and v ~= '' then send('el_floor_rename', { id = id, idx = idx, label = v }) end end },
                { label = 'Monter dans la liste', icon = 'arrow', disabled = idx <= 1 or nil, onSelect = function() send('el_floor_order', { id = id, idx = idx, dir = -1 }) G.Menu.Stack:Back() end },
                { label = 'Descendre dans la liste', icon = 'arrow', disabled = idx >= #e.floors or nil, onSelect = function() send('el_floor_order', { id = id, idx = idx, dir = 1 }) G.Menu.Stack:Back() end },
                { label = 'Supprimer cet étage', icon = 'trash', onSelect = function() send('el_floor_del', { id = id, idx = idx }) G.Menu.Stack:Back() end },
            }
        end }
    end
    local function elevMenu(id)
        return { id = 'b.el.' .. id, title = 'Ascenseur', refreshOnReturn = true, build = function()
            local e = find(id)
            if not e then return { { label = 'Ascenseur supprimé', disabled = true } } end
            local items = { { type = 'separator', label = ('Étages · %d'):format(#e.floors) } }
            for i, f in ipairs(e.floors) do items[#items + 1] = { type = 'submenu', label = i .. '. ' .. f.label, right = 'z ' .. f.z, submenu = floorMenu(id, i) } end
            if #e.floors < 2 then items[#items + 1] = { label = 'Ajoute au moins 2 étages', icon = 'info', disabled = true, description = "L'ascenseur n'apparaît pour les joueurs qu'à partir de 2 étages." } end
            items[#items + 1] = { label = 'Ajouter un étage ici', icon = 'plus', description = "Pose un étage là où tu te tiens, tourné comme toi. Les joueurs arriveront dans cette direction.", onSelect = function()
                local v = G.Menu.Ask("Nom de l'étage (ex. Toit, Parking, 2e étage)", '', 32)
                if v ~= nil then send('el_floor_add', { id = id, label = v }) end
            end }
            items[#items + 1] = { type = 'separator', label = 'Réglages' }
            local opts, idx = {}, 1
            for k, o in ipairs(data().access or {}) do opts[#opts + 1] = o[2] if o[1] == e.access then idx = k end end
            if #opts > 0 then
                items[#items + 1] = { type = 'list', label = 'Accès', icon = 'lock', list = opts, index = idx, description = '← → pour choisir, Entrée pour appliquer.',
                    onSelect = function(it) local o = data().access[it.index or idx] if o then send('el_access', { id = id, access = o[1] }) end end }
            end
            items[#items + 1] = { label = 'Renommer', icon = 'edit', right = e.label, onSelect = function() local v = G.Menu.Ask("Nom de l'ascenseur", e.label, 40) if v and v ~= '' then send('el_rename', { id = id, label = v }) end end }
            items[#items + 1] = { label = "Supprimer l'ascenseur", icon = 'trash', description = 'Supprime tous ses étages pour tout le monde.', onSelect = function()
                local v = G.Menu.Ask('Tape OUI pour supprimer « ' .. e.label .. ' »', '', 3)
                if v and v:upper() == 'OUI' then send('el_delete', { id = id }) G.Menu.Stack:Back() end
            end }
            return items
        end }
    end
    -- (v1.2.43) Builder › Créer : un nouvel ascenseur ; Builder › Existant : la liste (étages, accès, suppression)
    local create = { label = 'Ascenseur (ici)', icon = 'plus', description = "Place-toi devant l'ascenseur du premier étage : son nom, puis le nom de cet étage. Ajoute ensuite les autres étages dans Existant › Ascenseurs.", onSelect = function()
        local n = G.Menu.Ask("Nom de l'ascenseur (ex. Hôpital, Tour Maze Bank)", '', 40)
        if not n or n == '' then return end
        local f = G.Menu.Ask('Nom de cet étage (ex. Rez-de-chaussée)', 'Rez-de-chaussée', 32)
        send('el_create', { label = n, floor = f or '' })
    end }
    local existing = { type = 'submenu', label = 'Ascenseurs', icon = 'building', badge = tostring(#data().list), description = 'Ajouter un étage là où tu te tiens, renommer, réordonner, accès, supprimer.',
        submenu = { id = 'b.elev', title = 'Ascenseurs', refreshOnReturn = true, build = function()
            local items = {}
            for _, e in ipairs(data().list) do
                items[#items + 1] = { type = 'submenu', label = e.label, right = #e.floors .. ' étage' .. (#e.floors > 1 and 's' or ''), description = e.accessLabel, submenu = elevMenu(e.id) }
            end
            if #items == 0 then items[1] = { label = 'Aucun ascenseur : Builder › Créer › Ascenseurs', disabled = true } end
            return items
        end } }
    return create, existing
end
