-- Espace citoyen / entreprise : ouvert en menu lib (client/pagesmenu.lua), plus de tablette. Réparation du garage. Tout vient du serveur.
local G = PBG

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function open(where)
    if busy() or not G.begun then return end
    TriggerServerEvent('pb:g:biz:open', where)
end

-- ouverture demandée par un point : 'boss' (bureau du patron), 'hq' (siège), 'desk' (accueil) : chacun ouvre sa page
RegisterNetEvent('pb:g:biz:open', function(where) open(type(where) == 'string' and where or nil) end)

RegisterNetEvent('pb:g:biz:job', function(j) G.job = G.decode(j) end)

-- Réparation demandée par le serveur (le mécanicien a le droit « repair » et est en service)
RegisterNetEvent('pb:g:biz:repair', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    if veh == 0 or not DoesEntityExist(veh) then G.send('notify', { type = 'error', text = 'Aucun véhicule à proximité.' }) return end
    SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    G.send('notify', { type = 'success', text = 'Véhicule réparé.' })
end)

RegisterCommand('pb_tablet', open, false)
-- /pbversion : version installée et touches, pour vérifier qu'une mise à jour est bien arrivée chez le joueur
RegisterCommand('pbversion', function()
    local v = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '?'
    local q = (G.cfg.quick and G.cfg.quick.key) or 'F6'
    local o = (G.cfg.tablets and G.cfg.tablets.orga_key) or 'F7'
    G.send('notify', { type = 'info', title = 'Shadow Base ' .. v, text = ('%s : menu de l\'entreprise (/entreprise) · %s : menu de l\'organisation (/organisation).'):format(q, o), duration = 12000 })
    print(('[pb_panel] version %s · menu entreprise %s · menu organisation %s'):format(v, q, o))
end, false)
RegisterCommand('tablette', open, false)

-- L'espace entreprise s'ouvre au siège / bureau (point du Builder), par /tablette, ou dans le menu F6 (client/quick.lua).
-- Une touche n'est posée que si le serveur en a choisi une autre que F6.
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.biz and GetGameTimer() < t do Wait(250) end
    local k = G.cfg.biz and G.cfg.biz.tablet_key
    if type(k) == 'string' and k ~= '' and k:upper() ~= 'F6' and k:upper() ~= ((G.cfg.quick and G.cfg.quick.key) or 'F6'):upper() then RegisterKeyMapping('pb_tablet', 'Espace citoyen / entreprise', 'keyboard', k) end
end)

