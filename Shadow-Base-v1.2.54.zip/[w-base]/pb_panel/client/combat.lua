-- Combat (v1.2.39) : tir entre joueurs autorisé et balle dans la tête mortelle.
-- Réglages : panel › Écran de mort (« Combat entre joueurs », « Balle dans la tête mortelle »).
local G = PBG
local function cfg() return (G.cfg and G.cfg.death) or {} end

-- FiveM ne laisse pas toujours les joueurs se blesser entre eux : on l'autorise explicitement (et on le réaffirme après un respawn)
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local pvp = cfg().pvp ~= false
        NetworkSetFriendlyFireOption(pvp)
        SetCanAttackFriendly(ped, pvp, false)
        SetPedSuffersCriticalHits(ped, true)
        Wait(2000)
    end
end)

-- Balle dans la tête : mort immédiate (pas pour une arme de mêlée, ni si le joueur est invincible : staff, cinématique…)
local HEAD = { [31086] = true, [12844] = true, [65068] = true }   -- tête, tête (IK), visage
AddEventHandler('gameEventTriggered', function(name, args)
    if name ~= 'CEventNetworkEntityDamage' or cfg().headshot_kill == false then return end
    local ped = PlayerPedId()
    if args[1] ~= ped or IsEntityDead(ped) or G.dead then return end
    if GetPlayerInvincible(PlayerId()) or GetEntityHealth(ped) <= 0 then return end
    if G.vestOn and GetPedArmour(ped) > 0 then return end   -- (v1.2.42) gilet pare-balles encore résistant : pas de mort immédiate
    local weapon = args[7]
    if not weapon or weapon == 0 or args[11] == 1 or GetWeaponDamageType(weapon) ~= 3 then return end   -- 3 = balle
    local hit, bone = GetPedLastDamageBone(ped)
    if hit and HEAD[bone] then SetEntityHealth(ped, 0) end
end)

-- (v1.2.42) Gilet pare-balles porté (case Gilet de l'inventaire) : blindage appliqué, et renvoyé au serveur quand il baisse
local lastHp = -1
RegisterNetEvent('pb:g:inv:vest', function(j)
    local d = G.decode(j) or {}
    local ped = PlayerPedId()
    if d.on then
        G.vestOn = true
        lastHp = math.floor(tonumber(d.hp) or 0)
        SetPedArmour(ped, lastHp)
    else
        G.vestOn = false
        lastHp = -1
        SetPedArmour(ped, 0)
    end
end)
CreateThread(function()
    while true do
        Wait(1000)
        if G.vestOn then
            local hp = GetPedArmour(PlayerPedId())
            if hp ~= lastHp then
                lastHp = hp
                TriggerServerEvent('pb:g:inv:vesthp', hp)
            end
        end
    end
end)
