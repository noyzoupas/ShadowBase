-- Poste radio (F4) : menu lib (v1.2.43, à la place de l'ancienne interface). Le serveur valide chaque fréquence (plages réservées, objet,
-- état du joueur) et place le joueur avec pma-voice ; on parle ensuite avec la touche radio de pma-voice.
local G = PBG
local data = nil      -- dernier état reçu du serveur : { ch, label, max, ranges, voice }
local isOpen = false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end
G.radioOpen = function() return isOpen and G.Menu.IsOpen() end

local function volume()
    local ok, v = pcall(function() return exports['pma-voice']:getRadioVolume() end)
    return ok and math.floor((tonumber(v) or 30) + 0.5) or 30
end
local function setVolume(v)
    v = math.max(0, math.min(100, math.floor(tonumber(v) or 30)))
    pcall(function() exports['pma-voice']:setRadioVolume(v) end)
    SetResourceKvpInt('pb_radio_vol', v + 1)
end
-- fréquences récentes (mémorisées sur le poste du joueur)
local function recents()
    local out = {}
    for n in tostring(GetResourceKvpString('pb_radio_recent') or ''):gmatch('%d+') do out[#out + 1] = tonumber(n) end
    return out
end
local function remember(ch)
    local list = { ch }
    for _, n in ipairs(recents()) do if n ~= ch and #list < 5 then list[#list + 1] = n end end
    local parts = {}
    for _, n in ipairs(list) do parts[#parts + 1] = tostring(n) end
    SetResourceKvp('pb_radio_recent', table.concat(parts, ','))
end
local function join(ch)
    ch = math.floor(tonumber(ch) or 0)
    if ch < 1 then return end
    remember(ch)
    TriggerServerEvent('pb:g:radio:join', ch)
end

local def
def = { id = 'radio', title = 'Radio', banner = { text = 'Radio' }, refreshOnReturn = true, build = function()
    local d = data or {}
    local ch = tonumber(d.ch) or 0
    local items = {}
    local talk = GetConvar('voice_defaultRadio', 'LMENU')
    local KEYN = { LMENU = 'ALT gauche', RMENU = 'ALT droit', CAPITAL = 'Verr. Maj', LCONTROL = 'CTRL gauche', LSHIFT = 'MAJ gauche', TAB = 'TAB' }
    items[#items + 1] = { type = 'separator', label = ch > 0 and ('Sur la fréquence ' .. ch .. ((d.label or '') ~= '' and (' · ' .. d.label) or '')) or 'Radio coupée' }
    if d.voice == false then items[#items + 1] = { label = 'Voix indisponible (pma-voice)', icon = 'alert', disabled = true, description = "Le serveur n'a pas de pma-voice : la radio ne peut pas fonctionner." } end
    items[#items + 1] = { label = 'Choisir une fréquence', icon = 'radio', right = ch > 0 and tostring(ch) or nil,
        description = ('Tape un numéro de 1 à %d.'):format(tonumber(d.max) or 999),
        onSelect = function() local v = G.Menu.Ask(('Fréquence (1 à %d)'):format(tonumber(d.max) or 999), ch > 0 and tostring(ch) or '', 5) if tonumber(v) then join(v) end end }
    if ch > 0 then items[#items + 1] = { label = 'Couper la radio', icon = 'close', description = 'Quitte la fréquence.', onSelect = function() TriggerServerEvent('pb:g:radio:leave') end } end
    items[#items + 1] = { type = 'slider', label = 'Volume', icon = 'music', min = 0, max = 100, step = 5, value = volume(), description = '← → pour régler. Mémorisé sur ton poste.',
        onChange = function(_, v) setVolume(v) end }
    local rec = recents()
    if #rec > 0 then
        items[#items + 1] = { type = 'separator', label = 'Récentes' }
        for _, n in ipairs(rec) do
            items[#items + 1] = { label = 'Fréquence ' .. n, icon = 'radio', right = n == ch and 'Active' or nil, disabled = n == ch or nil, onSelect = function() join(n) end }
        end
    end
    if type(d.ranges) == 'table' and #d.ranges > 0 then
        items[#items + 1] = { type = 'separator', label = 'Fréquences réservées' }
        for _, r in ipairs(d.ranges) do
            items[#items + 1] = { label = tostring(r.label), icon = r.ok and 'radio' or 'lock', right = r.from == r.to and tostring(r.from) or (r.from .. '–' .. r.to), disabled = (not r.ok) or nil,
                description = r.ok and ('Entrée : rejoindre la ' .. r.from .. '.') or 'Réservée à un autre métier (ou hors service).', onSelect = function() join(r.from) end }
        end
    end
    items[#items + 1] = { type = 'separator', label = 'Parler : maintiens ' .. (KEYN[tostring(talk):upper()] or tostring(talk)) }
    -- (v1.2.43) pma-voice parle à la radio avec ALT par défaut, la même touche que le menu d'interaction : on le signale
    local ctxKey = tostring((G.cfg.ctx and G.cfg.ctx.key) or 'LMENU'):upper()
    if tostring(talk):upper() == ctxKey then items[#items + 1] = { label = 'Touche radio = touche du menu ALT', icon = 'alert', disabled = true,
        description = "Parler à la radio et ouvrir le menu d'interaction utilisent la même touche. Change ta touche radio : Paramètres FiveM › Raccourcis › FiveM › pma-voice (ou demande au staff)." } end
    return items
end, onClose = function() isOpen = false end }

RegisterNetEvent('pb:g:radio', function(j)
    local d = G.decode(j)
    if not d then return end
    data = d
    G.radioCh = tonumber(d.ch) or 0
    if d.ev == 'open' then
        if busy() then return end
        isOpen = true
        G.Menu.Open(def)
    elseif d.ev == 'state' then
        if d.msg then G.send('notify', { type = d.ok and 'success' or 'error', title = 'Radio', text = tostring(d.msg) })
        elseif d.ok and (tonumber(d.ch) or 0) > 0 then G.send('notify', { type = 'success', title = 'Radio', text = 'Fréquence ' .. d.ch .. ((d.label or '') ~= '' and (' · ' .. d.label) or '') .. '.' }) end
        if isOpen and G.Menu.IsOpen() then G.Menu.Refresh() end
    end
end)

RegisterCommand('pb_radio', function()
    if not G.begun or busy() then return end
    if not (G.cfg.radio and G.cfg.radio.ui ~= false) then return end
    if isOpen and G.Menu.IsOpen() then G.Menu.Close() isOpen = false return end
    TriggerServerEvent('pb:g:radio:open')
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.radio and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_radio', 'Ouvrir la radio', 'keyboard', (G.cfg.radio and G.cfg.radio.key) or 'F4')
    -- volume radio retenu d'une session à l'autre (0 = jamais réglé)
    local v = GetResourceKvpInt('pb_radio_vol')
    if v > 0 then pcall(function() exports['pma-voice']:setRadioVolume(v - 1) end) end
end)
CreateThread(function() while true do Wait(500) if isOpen and busy() and G.Menu.IsOpen() then G.Menu.Close() isOpen = false end end end)
G.onForceClose(function() isOpen = false end)
