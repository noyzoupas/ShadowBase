-- Salon de tatouage : catalogue des tatouages du jeu (lu dans les salons GTA), classé par zone du corps, aperçu en direct.
-- Le serveur ne garde que la liste des tatouages, revalide tout et fait payer chaque NOUVEAU tatouage (retirer est gratuit).
local G = PBG

local ZONES = { [0] = 'Torse et dos', [1] = 'Tête et cou', [2] = 'Bras gauche', [3] = 'Bras droit', [4] = 'Jambe gauche', [5] = 'Jambe droite' }
local ZONE_ORDER = { 0, 1, 2, 3, 4, 5 }
local catalog = {}      -- [sexe] = { [zone] = { { c, o, label } } }
local shopId, saved, owned, heading0
local busy = false

-- Lecture du catalogue : GET_TATTOO_SHOP_DLC_ITEM_DATA remplit une structure (champs de 8 octets, nom du tatouage à l'octet 56)
local function readCatalog(female)
    local key = female and 'f' or 'm'
    if catalog[key] then return catalog[key] end
    local out = {}
    for z in pairs(ZONES) do out[z] = {} end
    local char = female and 4 or 3
    local n = GetNumTattooShopDlcItems(char) or 0
    local seen = {}
    for i = 0, n - 1 do
        local blob = string.rep('\0', 8 * 16)
        local ok = Citizen.InvokeNative(0xFF56381874F82086, char, i, blob, Citizen.ReturnResultAnyway())
        if ok then
            local _, _, coll, preset = string.unpack('<i4xxxxi4xxxxi4xxxxi4', blob)
            local name = blob:sub(57, 120):match('^[%w_]+') or ''
            if coll ~= 0 and preset ~= 0 and not seen[coll .. ':' .. preset] then
                seen[coll .. ':' .. preset] = true
                local zone = GetPedDecorationZoneFromHashes(coll, preset)
                if out[zone] then
                    local label = name ~= '' and GetLabelText(name) or ''
                    if label == '' or label == 'NULL' then label = 'Tatouage n°' .. (#out[zone] + 1) end
                    out[zone][#out[zone] + 1] = { c = coll, o = preset, label = label }
                end
            end
        end
    end
    for _, l in pairs(out) do table.sort(l, function(a, b) return a.label < b.label end) end
    catalog[key] = out
    return out
end

local function apply()
    local ped = PlayerPedId()
    ClearPedDecorations(ped)
    for k in pairs(owned) do local c, o = k:match('^(-?%d+):(-?%d+)$') AddPedDecorationFromHashes(ped, tonumber(c), tonumber(o)) end
end
local function list() local out = {} for k in pairs(owned) do local c, o = k:match('^(-?%d+):(-?%d+)$') out[#out + 1] = { c = tonumber(c), o = tonumber(o) } end return out end

-- torse, jambes et bras visibles pendant le choix
local function undress(female)
    local ped = PlayerPedId()
    SetPedComponentVariation(ped, 11, 15, 0, 2) SetPedComponentVariation(ped, 8, female and 14 or 15, 0, 2) SetPedComponentVariation(ped, 3, 15, 0, 2)
    SetPedComponentVariation(ped, 4, female and 15 or 21, 0, 2)
end

local function finish(restore)
    if not shopId then return end
    shopId, busy = nil, false
    G.barberOpen = false
    local ped = PlayerPedId()
    if restore and saved then G.applyAppearance(saved, false) elseif G.appearance then G.applyAppearance(G.appearance, false) end
    saved = nil
    if heading0 then SetEntityHeading(ped, heading0) end
    FreezeEntityPosition(ped, false)
    G.camOff()
    if G.closeShop then G.closeShop() end
end

function G.openTattoo(d)
    if shopId or type(d.appearance) ~= 'table' then if G.closeShop then G.closeShop() end return end
    local female = d.sex == 'female'
    local cat = readCatalog(female)
    shopId, saved, owned = d.id, d.appearance, {}
    for _, t in ipairs(d.appearance.tattoos or {}) do owned[tostring(t.c) .. ':' .. tostring(t.o)] = true end
    local ped = PlayerPedId()
    heading0 = GetEntityHeading(ped)
    FreezeEntityPosition(ped, true)
    undress(female)
    apply()
    G.setCam('body')
    local price = tonumber(d.price) or 0
    local total = 0
    for _, z in ipairs(ZONE_ORDER) do total = total + #cat[z] end
    local function countNew()
        local had, n = {}, 0
        for _, t in ipairs(saved.tattoos or {}) do had[tostring(t.c) .. ':' .. tostring(t.o)] = true end
        for k in pairs(owned) do if not had[k] then n = n + 1 end end
        return n
    end
    local items = {}
    if total == 0 then items[#items + 1] = { label = 'Catalogue indisponible', description = "Le jeu n'a renvoyé aucun tatouage.", disabled = true } end
    for _, z in ipairs(ZONE_ORDER) do
        local sub = {}
        for _, t in ipairs(cat[z]) do
            local k = tostring(t.c) .. ':' .. tostring(t.o)
            sub[#sub + 1] = { type = 'checkbox', label = t.label, checked = owned[k] or false, onChange = function(_, on) owned[k] = on or nil apply() end }
        end
        if #sub > 0 then items[#items + 1] = { type = 'submenu', label = ZONES[z], icon = 'brush', right = tostring(#sub), submenu = { id = 'tattoo.z' .. z, title = ZONES[z], subtitle = d.label, items = sub } } end
    end
    items[#items + 1] = { type = 'separator', label = 'Vue' }
    items[#items + 1] = { type = 'slider', label = 'Tourner', min = -4, max = 4, value = 0, description = 'Voir le dos et les côtés', onChange = function(_, v) SetEntityHeading(PlayerPedId(), heading0 + v * 45.0) end }
    items[#items + 1] = { type = 'separator', label = '' }
    items[#items + 1] = { label = 'Valider', icon = 'check', description = price > 0 and ('%s par nouveau tatouage (retirer est gratuit).'):format(PB.Money(price)) or 'Enregistre tes tatouages.',
        onSelect = function()
            if busy or not shopId then return end
            local n = countNew()
            if n > 0 and price > 0 then G.send('notify', { type = 'info', title = d.label, text = ('%d nouveau(x) tatouage(s) : %s.'):format(n, PB.Money(n * price)) }) end
            busy = true
            TriggerServerEvent('pb:g:shop:tattoo', shopId, list())
        end }
    items[#items + 1] = { label = 'Annuler', icon = 'x', onSelect = function() G.Menu.Close() finish(true) end }
    G.barberOpen = true
    local ok = G.Menu.Open({ id = 'tattoo', title = d.label or 'Salon de tatouage', subtitle = d.tagline or 'Tatouages', items = items,
        onClose = function() if shopId and not busy then finish(true) end end })
    if not ok then finish(true) end
end

RegisterNetEvent('pb:g:shop:tattooOk', function(j)
    local a = G.decode(j)
    if a then G.appearance = a end
    local id = shopId
    shopId = nil
    G.Menu.Close()
    shopId = id
    finish(false)
end)
RegisterNetEvent('pb:g:shop:cancel', function() if shopId then busy = false end end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and shopId then finish(true) end end)
