-- Service au bar : menu de préparation au point « cuisine / bar », menu « Servir » (ALT sur un client), commande reçue par le client.
-- Le serveur décide de tout : ce fichier n'affiche que ce qu'il reçoit et renvoie des choix.
local G = PBG
local function money(n) return PB.Money(n) end
local function askQty(max)
    local v = G.Menu.Ask('Quantité (1 à ' .. max .. ')', '1', 2)
    local n = math.floor(tonumber(v or '') or 0)
    if n < 1 then return nil end
    return math.min(n, max)
end

RegisterNetEvent('pb:g:bar:menu', function(j)
    local d = G.decode(j)
    if not d then return end
    local items = {}
    if d.mode == 'prep' then
        items[#items + 1] = { type = 'separator', label = ('Caisse : %s · ingrédients payés par l\'entreprise'):format(money(d.balance)) }
        for _, a in ipairs(d.items or {}) do
            items[#items + 1] = { label = a.label, icon = 'food', right = money(a.price), description = ('Ingrédients : %s par produit · %d s de préparation.'):format(money(a.cost), d.secs or 4),
                onSelect = function() local n = askQty(d.max or 10) if n then G.Menu.Close() TriggerServerEvent('pb:g:bar:prep', a.name, n) end end }
        end
        if d.recipes then items[#items + 1] = { label = 'Recettes avec ingrédients', icon = 'list', description = 'Les recettes de l\'entreprise (Activités › Recettes).', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:bar:recipes') end } end
        G.Menu.Open({ id = 'bar.prep', title = d.label or 'Bar', subtitle = d.biz, items = items, banner = { text = 'Préparer' } })
    elseif d.mode == 'serve' then
        for _, a in ipairs(d.items or {}) do
            items[#items + 1] = { label = a.label, icon = 'food', right = money(a.price), description = ('Tu en as %d sur toi.'):format(a.have),
                onSelect = function() local n = askQty(math.min(a.have, 20)) if n then G.Menu.Close() TriggerServerEvent('pb:g:bar:offer', d.target, a.name, n) end end }
        end
        G.Menu.Open({ id = 'bar.serve', title = 'Servir ' .. tostring(d.targetName or ''), subtitle = d.biz, items = items, banner = { text = 'Servir' } })
    end
end)

-- Préparation : animation + barre de progression ; on prévient le serveur à la fin (il vérifie le temps et la présence au bar)
RegisterNetEvent('pb:g:bar:progress', function(j)
    local d = G.decode(j)
    if not d then return end
    local secs = tonumber(d.secs) or 4
    CreateThread(function()
        local ped = PlayerPedId()
        local start = GetEntityCoords(ped)
        TaskStartScenarioInPlace(ped, 'PROP_HUMAN_BBQ', 0, true)
        G.send('crime.progress', { label = tostring(d.label or 'Préparation'), secs = secs })
        local t = GetGameTimer() + secs * 1000
        while GetGameTimer() < t do
            Wait(250)
            if #(GetEntityCoords(ped) - start) > 3.0 or IsEntityDead(ped) then
                ClearPedTasks(ped) G.send('crime.progress', { cancel = true })
                TriggerServerEvent('pb:g:bar:prepCancel')
                G.send('notify', { type = 'warn', title = 'Bar', text = 'Préparation abandonnée.' })
                return
            end
        end
        ClearPedTasks(ped)
        TriggerServerEvent('pb:g:bar:prepDone')
    end)
end)

-- Commande reçue : accepter (et payer) ou refuser
RegisterNetEvent('pb:g:bar:offer', function(j)
    local d = G.decode(j)
    if not d then return end
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    G.Menu.Open({ id = 'bar.offer', title = tostring(d.biz or 'Commande'), subtitle = tostring(d.from or '') .. ' te sert', banner = { text = 'Commande' }, items = {
        { type = 'separator', label = ('%d × %s'):format(d.qty or 1, tostring(d.label or '')) },
        { label = 'Accepter et payer ' .. money(d.price), icon = 'check', description = 'Espèces d\'abord, sinon la banque.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:bar:answer', true) end },
        { label = 'Refuser', icon = 'x', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:bar:answer', false) end },
    } })
end)
