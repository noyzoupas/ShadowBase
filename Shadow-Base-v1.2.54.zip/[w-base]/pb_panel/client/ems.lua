-- EMS : animation de réanimation / soins, choix de la personne à facturer (mise en surbrillance), médecin PNJ payant.
local G = PBG
-- « 2 500 $ »
local function fmtMoney(n) local s = tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') return s .. ' $' end

local function loadDict(d)
    RequestAnimDict(d)
    local t = GetGameTimer() + 3000
    while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end
    return HasAnimDictLoaded(d)
end

-- Animation du soignant pendant la durée donnée par le serveur (massage cardiaque ou soins à genoux)
RegisterNetEvent('pb:g:ems:anim', function(j)
    local d = G.decode(j)
    if not d then return end
    local ped = PlayerPedId()
    local secs = math.max(2, math.min(30, tonumber(d.secs) or 8))
    local tpl = GetPlayerFromServerId(tonumber(d.target) or -1)
    local tped = tpl and tpl ~= -1 and GetPlayerPed(tpl) or 0
    if tped ~= 0 then TaskTurnPedToFaceEntity(ped, tped, 600) Wait(600) end
    if d.kind == 'cpr' and loadDict('mini@cpr@char_a@cpr_str') then
        TaskPlayAnim(ped, 'mini@cpr@char_a@cpr_str', 'cpr_pumpchest', 8.0, -8.0, -1, 1, 0, false, false, false)
    else
        TaskStartScenarioInPlace(ped, 'CODE_HUMAN_MEDIC_TEND_TO_DEAD', 0, true)
    end
    G.send('crime.progress', { label = d.kind == 'cpr' and 'Réanimation en cours…' or 'Soins en cours…', secs = secs })
    local stop = GetGameTimer() + secs * 1000
    while GetGameTimer() < stop do
        DisableControlAction(0, 21, true) DisableControlAction(0, 22, true) DisableControlAction(0, 24, true)
        Wait(0)
    end
    ClearPedTasks(ped)
end)

-- Facture : la personne survolée est entourée, comme dans les autres menus de sélection
RegisterNetEvent('pb:g:ems:bill', function(j)
    local d = G.decode(j)
    if not d or type(d.near) ~= 'table' then return end
    local title = ('Facture : %s (%s)'):format(tostring(d.reason or 'Soins'), fmtMoney(d.amount))
    G.Menu.Open(G.PickMenu('ems.bill', 'À qui envoyer la facture ?', d.near, function(id)
        G.Menu.Close()
        TriggerServerEvent('pb:g:ems:bill', id)
    end, title))
end)

-- Médecin (PNJ) : E pour des soins complets, payants
local doctors, docPrice = {}, 0
RegisterNetEvent('pb:g:ems:doctors', function(j)
    local d = G.decode(j)
    doctors = d and d.list or {}
    docPrice = d and tonumber(d.price) or 0
    local npcs = {}
    for _, x in ipairs(doctors) do npcs[#npcs + 1] = { id = x.id, model = 's_m_m_doctor_01', x = x.x, y = x.y, z = x.z, h = x.h, scenario = 'WORLD_HUMAN_CLIPBOARD' } end
    G.Npcs('ems_doctors', npcs)
end)
RegisterNetEvent('pb:g:ems:doctorfx', function(secs)
    local ped = PlayerPedId()
    DoScreenFadeOut(600)
    Wait(700)
    FreezeEntityPosition(ped, true)
    G.send('crime.progress', { label = 'Soins en cours…', secs = tonumber(secs) or 10 })
    Wait(math.max(2000, (tonumber(secs) or 10) * 1000 - 800))
    FreezeEntityPosition(ped, false)
    DoScreenFadeIn(800)
end)
CreateThread(function()
    local shown = nil
    while true do
        local best, bd = nil, 1e9
        if #doctors > 0 and G.begun and not G.state.dead then
            local c = GetEntityCoords(PlayerPedId())
            for _, x in ipairs(doctors) do local d = #(c - vector3(x.x + 0.0, x.y + 0.0, x.z + 0.0)) if d < bd then best, bd = x, d end end
        end
        if best and bd <= 10.0 then
            G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
            if bd <= 2.2 and not G.Menu.IsOpen() then
                if shown ~= best.id then shown = best.id G.send('prompt', { show = true, key = 'E', text = ('%s : soins complets (%s)'):format(best.label, fmtMoney(docPrice)) }) end
                if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:ems:doctor', best.id) end
            elseif shown then shown = nil G.send('prompt', { show = false }) end
            Wait(0)
        else
            if shown then shown = nil G.send('prompt', { show = false }) end
            Wait(800)
        end
    end
end)
