-- Vestiaire d'entreprise / de gang (client) : menu des tenues, tenue civile, enregistrement de la tenue portée (patron / staff).
local G = PBG

local COMPS = { 1, 3, 4, 5, 6, 7, 8, 9, 10, 11 }
local PROPS = { 0, 1, 2, 6, 7 }

-- tenue portée en ce moment (vêtements et accessoires seulement : le visage et les cheveux ne bougent pas)
local function current()
    local ped = PlayerPedId()
    local d = { comps = {}, props = {} }
    for _, c in ipairs(COMPS) do d.comps[#d.comps + 1] = { c, GetPedDrawableVariation(ped, c), GetPedTextureVariation(ped, c) } end
    for _, id in ipairs(PROPS) do d.props[#d.props + 1] = { id, GetPedPropIndex(ped, id), math.max(0, GetPedPropTextureIndex(ped, id)) } end
    return d
end

local function changeAnim()
    local ped = PlayerPedId()
    RequestAnimDict('clothingtie')
    local t = GetGameTimer() + 1000
    while not HasAnimDictLoaded('clothingtie') and GetGameTimer() < t do Wait(10) end
    if HasAnimDictLoaded('clothingtie') then TaskPlayAnim(ped, 'clothingtie', 'try_tie_positive_a', 8.0, -8.0, 1800, 48, 0, false, false, false) Wait(1200) end
end

-- vêtements civils gardés au moment où l'on enfile une tenue de service (rendus à la fin du service)
local civil
local function snapshot(ped)
    local t = { comps = {}, props = {} }
    for c = 0, 11 do t.comps[#t.comps + 1] = { c, GetPedDrawableVariation(ped, c), GetPedTextureVariation(ped, c) } end
    for _, id in ipairs(PROPS) do t.props[#t.props + 1] = { id, GetPedPropIndex(ped, id), GetPedPropTextureIndex(ped, id) } end
    return t
end
RegisterNetEvent('pb:g:wardrobe:civil', function()
    if not civil then return end
    local ped, d = PlayerPedId(), civil
    civil = nil
    changeAnim()
    for _, c in ipairs(d.comps) do SetPedComponentVariation(ped, c[1], c[2], c[3], 2) end
    for _, id in ipairs(PROPS) do ClearPedProp(ped, id) end
    for _, p in ipairs(d.props) do if p[2] >= 0 then SetPedPropIndex(ped, p[1], p[2], p[3], true) end end
    G.send('notify', { type = 'info', title = 'Fin de service', text = 'Tu as remis tes vêtements.' })
end)

RegisterNetEvent('pb:g:wardrobe:apply', function(payload, label, duty)
    local d = G.decode(payload)
    if type(d) ~= 'table' then return end
    if duty and not civil then civil = snapshot(PlayerPedId()) end
    changeAnim()
    local ped = PlayerPedId()
    for _, c in ipairs(d.comps or {}) do SetPedComponentVariation(ped, c[1], c[2], c[3], 2) end
    for _, id in ipairs(PROPS) do ClearPedProp(ped, id) end
    for _, p in ipairs(d.props or {}) do if p[2] >= 0 then SetPedPropIndex(ped, p[1], p[2], p[3], true) end end
    G.send('notify', { type = 'success', title = 'Vestiaire', text = 'Tenue « ' .. tostring(label) .. ' » enfilée.' })
end)

RegisterNetEvent('pb:g:wardrobe:open', function(payload)
    local d = G.decode(payload)
    if type(d) ~= 'table' then return end
    local items = {}
    local point = d.point
    items[#items + 1] = { label = 'Tenue civile', icon = 'user', description = 'Remet tes vêtements personnels.', onSelect = function()
        G.Menu.Close() changeAnim()
        if G.appearance then G.applyAppearance(G.appearance, false) end
        G.send('notify', { type = 'info', title = 'Vestiaire', text = 'Tenue civile remise.' })
    end }
    if #d.outfits > 0 then items[#items + 1] = { type = 'separator', label = 'Tenues' } end
    for _, o in ipairs(d.outfits) do
        local isPref = d.duty and d.duty.auto and d.duty.pref == o.id
        items[#items + 1] = { label = o.label, icon = 'hanger', right = isPref and 'Tenue de service' or (o.min > 0 and ('Grade ' .. o.min .. '+') or nil), disabled = (not o.ok) or nil,
            description = o.ok and ('Enfiler cette tenue.' .. ((d.duty and d.duty.auto) and ' Elle devient ta tenue de service.' or '')) or ('Réservée au grade ' .. o.min .. ' et plus.'),
            onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:wardrobe:wear', d.point, o.id) end }
    end
    if d.duty then
        items[#items + 1] = { type = 'separator', label = 'Prise de service' }
        items[#items + 1] = { label = 'Tenue automatique', icon = 'clock', right = d.duty.auto and 'Oui' or 'Non',
            description = d.duty.auto and "Ta tenue de service est enfilée quand tu prends ton service, et tes vêtements reviennent à la fin. Clique pour t'habiller toi-même." or 'Clique pour que la tenue de service soit enfilée toute seule à chaque prise de service.',
            onSelect = function() TriggerServerEvent('pb:g:wardrobe:auto', point, not d.duty.auto) end }
    end
    if #d.outfits == 0 then items[#items + 1] = { label = 'Aucune tenue enregistrée', disabled = true, description = d.manage and 'Habille-toi puis « Enregistrer ma tenue actuelle ».' or 'Le patron doit en enregistrer.' } end
    if d.manage then
        items[#items + 1] = { type = 'separator', label = 'Gestion' }
        items[#items + 1] = { label = 'Enregistrer ma tenue actuelle', icon = 'plus', description = ('Tenue %s : elle sera proposée aux membres du même sexe.'):format(d.sex == 'f' and 'femme' or 'homme'), onSelect = function()
            local name = G.Menu.Ask('Nom de la tenue (ex. Patrouille)', '', 40)
            if not name or #name < 2 then return end
            local g = G.Menu.Ask('Grade minimum (0 = tout le monde)', '0', 2)
            if g == nil then return end
            TriggerServerEvent('pb:g:wardrobe:save', d.point, name, tonumber(g) or 0, json.encode(current()))
        end }
        items[#items + 1] = { label = 'Accessoires du grade (gilet, badge)', icon = 'shield', description = "Enregistre le gilet et le badge que tu portes : ils seront ajoutés automatiquement à toutes les tenues de ce grade et des grades au-dessus. Retire-les pour effacer.",
            onSelect = function()
                local g = G.Menu.Ask('À partir du grade (0 = tout le monde)', '0', 2)
                if g == nil then return end
                local ped = PlayerPedId()
                local d = { comps = {} }
                for _, c in ipairs({ 9, 10 }) do
                    local dr = GetPedDrawableVariation(ped, c)
                    if dr > 0 then d.comps[#d.comps + 1] = { c, dr, GetPedTextureVariation(ped, c) } end
                end
                TriggerServerEvent('pb:g:wardrobe:acc', point, tonumber(g) or 0, json.encode(d))
            end }
        local del = {}
        for _, o in ipairs(d.outfits) do del[#del + 1] = { label = o.label, icon = 'x', onSelect = function() TriggerServerEvent('pb:g:wardrobe:del', d.point, o.id) end } end
        if #del > 0 then items[#items + 1] = { type = 'submenu', label = 'Supprimer une tenue', icon = 'trash', submenu = { id = 'wardrobe.del', title = 'Supprimer', subtitle = d.title, items = del } } end
    end
    G.Menu.Close()
    G.Menu.Open({ id = 'wardrobe', title = d.title, subtitle = 'Vestiaire', items = items })
end)

-- (v1.2.42) Tenues enregistrées : appliquer une tenue (sac de vêtements) et garde-robe « Mes tenues » dans un logement
RegisterNetEvent('pb:g:tenue:apply', function(j)
    local a = G.decode(j)
    if not a then return end
    G.appearance = a
    if G.applyAppearance then G.applyAppearance(a, false) end
end)
RegisterNetEvent('pb:g:tenue:list', function(j)
    local list = G.decode(j) or {}
    local items = {}
    if #list == 0 then items[1] = { type = 'separator', label = 'Aucune tenue enregistrée' } end
    for _, o in ipairs(list) do
        items[#items + 1] = { type = 'submenu', label = tostring(o.label), icon = 'hanger', description = 'Enfiler cette tenue ou la supprimer.', submenu = { id = 'tenues.one', title = tostring(o.label), items = {
            { label = 'Enfiler', icon = 'hanger', onSelect = function() TriggerServerEvent('pb:g:tenue:wear', o.id) G.Menu.Close() end },
            { label = 'Supprimer', icon = 'trash', description = 'Le sac de vêtements disparaît aussi de ton inventaire.', onSelect = function() TriggerServerEvent('pb:g:tenue:delete', o.id) end },
        } } }
    end
    items[#items + 1] = { type = 'separator', label = 'Garde-robe' }
    items[#items + 1] = { label = 'Enregistrer la tenue portée', icon = 'plus', description = 'Range ta tenue actuelle dans un sac de vêtements.', onSelect = function()
        local name = G.Menu.Ask('Nom de la tenue', '', 32)
        if name then TriggerServerEvent('pb:g:tenue:save', name) G.Menu.Close() end
    end }
    G.Menu.Open({ id = 'tenues', title = 'Mes tenues', subtitle = 'Garde-robe', items = items })
end)
