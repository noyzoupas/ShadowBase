-- Menu F7 de l'organisation (menu lib) : actions sur une personne, QG, coffre, caisse et toutes les pages de gestion
-- (crypto, classement, territoires, grades, effectif…), sans tablette. Tout vient du serveur, qui revérifie chaque action.
local G = PBG

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end
local function open()
    if busy() or not G.begun then return end
    TriggerServerEvent('pb:g:orga:open')
end
RegisterNetEvent('pb:g:orga:gps', function(j)
    local d = G.decode(j)
    if d and tonumber(d.x) and tonumber(d.y) then SetNewWaypoint(d.x + 0.0, d.y + 0.0) end
end)
RegisterCommand('pb_orga', open, false)
RegisterCommand('orga', open, false)
-- Menu de mon organisation (F7) : ligoter, escorter, fouiller, GPS du QG, coffre, caisse, puis les pages de gestion.
local gspec
local function gsend(id, payload) TriggerServerEvent('pb:g:gang:act', id, payload or {}) end
local function gangItems()
    local out = { { type = 'separator', label = tostring(gspec.gang) .. (gspec.grade ~= '' and (' · ' .. gspec.grade) or '') } }
    for _, e in ipairs(gspec.entries) do
        if e.type == 'separator' then out[#out + 1] = { type = 'separator', label = e.label }
        elseif e.type == 'info' then
            local list = {}
            for _, m in ipairs(e.items or {}) do list[#list + 1] = { label = m.label, right = m.right, disabled = true } end
            if #list == 0 then list[1] = { label = 'Personne', disabled = true } end
            out[#out + 1] = { type = 'submenu', label = e.label, icon = e.icon, right = e.right, submenu = { id = 'gang.' .. e.id, title = e.label, items = list } }
        elseif e.needs == 'target' then
            local list = {}
            for _, n in ipairs(gspec.near or {}) do if e.only ~= 'tied' or n.tied then list[#list + 1] = n end end
            out[#out + 1] = { type = 'submenu', label = e.label, icon = e.icon, description = e.desc, submenu = function()
                return G.PickMenu('gang.' .. e.id .. '.who', e.label, list, function(id) gsend(e.id, { id = id }) end, e.only == 'tied' and 'Personnes ligotées à côté de toi' or nil)
            end }
        elseif e.type == 'fleet' and G.FleetItem then
            out[#out + 1] = G.FleetItem(e, gsend, 'gang.fleet')
        elseif e.type == 'page' then
            out[#out + 1] = G.PagesMenu.Item('orga', e)
        else
            out[#out + 1] = { type = 'button', label = e.label, icon = e.icon, description = e.desc, disabled = e.disabled, onSelect = function()
                local p = {}
                for _, inp in ipairs(e.inputs or {}) do
                    local v = G.Menu.Ask(inp.label, '', inp.maxlen or 20)
                    if v == nil or v == '' then return end
                    p[inp.k] = inp.number and tonumber(v) or v
                end
                gsend(e.id, p)
            end }
        end
    end
    return out
end
local gdef = { id = 'gang', title = 'Organisation', refreshOnReturn = true, build = function() return gangItems() end }
RegisterNetEvent('pb:g:gang:ui', function(j)
    local d = G.decode(j)
    if not d or not d.spec then return end
    gspec = d.spec
    gdef.subtitle = gspec.boss and 'Chef' or 'Membre'
    gdef.banner = { text = tostring(gspec.gang) }
    local mine = G.Menu.IsOpen() and G.Menu.Stack.menus[1] and G.Menu.Stack.menus[1].def == gdef
    if d.ev == 'open' then G.Menu.Open(gdef) elseif mine then G.Menu.Refresh() end
end)
local lastToggle = 0
local function gangToggle()
    local t = GetGameTimer()
    if t - lastToggle < 400 then return end   -- deux raccourcis sur la même touche : une seule action
    lastToggle = t
    if not G.begun or G.creating or G.wardrobe or G.state.dead then return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    TriggerServerEvent('pb:g:gang:open')
end
RegisterCommand('pb_gang', gangToggle, false)
RegisterCommand('organisation', gangToggle, false)
-- ancienne touche « F7 = tablette » mémorisée par FiveM : elle ouvre maintenant le menu F7
RegisterCommand('pb_orga__F7', gangToggle, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.tablets and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_gang', 'Menu de mon organisation', 'keyboard', (G.cfg.tablets and G.cfg.tablets.orga_key) or 'F7')
end)

-- Cagoule (menu F7) : écran noir tant qu'on la porte
local hood = false
RegisterNetEvent('pb:g:gang:hood', function(on)
    hood = on == true
    if not hood then return end
    CreateThread(function()
        while hood do
            DrawRect(0.5, 0.5, 1.0, 1.0, 0, 0, 0, 252)
            HideHudAndRadarThisFrame()
            Wait(0)
        end
    end)
end)
-- Braquage (menu F7) : mains en l'air pendant quelques secondes
RegisterNetEvent('pb:g:gang:handsup', function(secs)
    local ped = PlayerPedId()
    local dict = 'missminuteman_1ig_2'
    RequestAnimDict(dict)
    local t = GetGameTimer() + 2000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(10) end
    TaskPlayAnim(ped, dict, 'handsup_base', 8.0, -8.0, -1, 49, 0, false, false, false)
    local stop = GetGameTimer() + math.max(5, math.min(60, tonumber(secs) or 20)) * 1000
    CreateThread(function()
        while GetGameTimer() < stop do
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 140, true)
            if not IsEntityPlayingAnim(ped, dict, 'handsup_base', 3) then TaskPlayAnim(ped, dict, 'handsup_base', 8.0, -8.0, -1, 49, 0, false, false, false) end
            Wait(0)
        end
        StopAnimTask(ped, dict, 'handsup_base', 2.0)
    end)
end)
