-- Graffitis : menu des tags, aperçu transparent sur le mur visé, pose, effacement et affichage des tags proches.
-- Le serveur relit la position du joueur et refuse ce qui ne va pas ; ici on ne fait que viser, dessiner et envoyer une demande.
local G = PBG
local list, near = {}, {}           -- id -> tag ; tags proches (recalculés régulièrement)
local duis, assets = {}, {}         -- clé -> { dui, tex, sent, at } ; id d'image -> données
local placing, erasing = false, false
local TXD
local RES = GetCurrentResourceName()
local function cfg() return G.cfg and G.cfg.graffiti or {} end

-- Textures ----------------------------------------------------------------------------------------------------------------------------------
local function keyOf(g)
    if g.kind == 'img' then return 'i:' .. tostring(g.img or '') end
    return ('t:%s|%s|%s|%s'):format(tostring(g.text or ''), tostring(g.font or ''), tostring(g.color or ''), tostring(g.outline or ''))
end
local seq = 0
-- texte encodé dans l'adresse de la page : elle se dessine toute seule au chargement (plus de message perdu)
local function urlenc(str) return (tostring(str):gsub('[^%w%-_%.~]', function(ch) return ('%%%02X'):format(string.byte(ch)) end)) end
local function txtSpec(g) return { kind = 'txt', text = g.text, font = g.font, color = g.color, outline = g.outline } end
local function ensure(g)
    local k = keyOf(g)
    local d = duis[k]
    local now = GetGameTimer()
    if d then d.at = now return d end
    local n = 0
    for _ in pairs(duis) do n = n + 1 end
    if n >= 12 then
        -- trop de pages ouvertes : on libère la plus ancienne inutilisée depuis 5 s au lieu de ne plus rien afficher
        local oldK, oldAt
        for kk, dd in pairs(duis) do if now - dd.at > 5000 and (not oldAt or dd.at < oldAt) then oldK, oldAt = kk, dd.at end end
        if not oldK then return nil end
        DestroyDui(duis[oldK].dui) duis[oldK] = nil
    end
    seq = seq + 1
    local url = ('nui://%s/web/tagdui.html'):format(RES)
    if g.kind == 'txt' then url = url .. '#' .. urlenc(json.encode(txtSpec(g))) end
    local dui = CreateDui(url, 1024, 512)
    if not dui then return nil end
    if not TXD then TXD = CreateRuntimeTxd('pbgfx') end
    local name = 'g' .. seq
    local tex = CreateRuntimeTextureFromDuiHandle(TXD, name, GetDuiHandle(dui))
    d = { dui = dui, name = name, tex = tex, sent = false, sends = 0, nextSend = now + 600, at = now, born = now, g = g }
    duis[k] = d
    return d
end
-- Envoi du tag à la page : répété quelques fois (0,6 s, 1,6 s, 4 s, 9 s) car un message envoyé avant la fin du chargement
-- de la page est perdu, et c'était la cause des tags posés mais invisibles.
local RESEND = { 1000, 2400, 5000 }
local function pump()
    local now = GetGameTimer()
    for k, d in pairs(duis) do
        if now - d.at > 60000 then
            DestroyDui(d.dui) duis[k] = nil
        elseif d.sends <= #RESEND and now >= d.nextSend and (IsDuiAvailable(d.dui) or now - d.born > 3000) then
            local msg
            if d.g.kind == 'txt' then msg = txtSpec(d.g)
            else
                local id = tostring(d.g.img or ''):gsub('^asset:', '')
                local uri = assets[id]
                if uri then msg = { kind = 'img', src = uri }
                elseif not d.asked or now - d.asked > 6000 then d.asked = now TriggerServerEvent('pb:g:asset:get', id) end
            end
            if msg then
                SendDuiMessage(d.dui, json.encode(msg))
                d.sends = d.sends + 1
                d.sent = true
                d.nextSend = now + (RESEND[d.sends] or 0)
            end
        end
    end
end
G.onAsset = function(id, uri) assets[tostring(id)] = uri end

-- Dessin d'un tag : deux triangles texturés projetés sur le mur (dans les deux sens pour être sûr de les voir)
local function quad(g, alpha, tint)
    local d = ensure(g)
    if not d or not d.sent then return end
    local n = vector3(g.nx, g.ny, g.nz)
    local right = vector3(-n.y, n.x, 0.0)   -- droite vue de face (avant : inversée, le tag sortait retourné)
    local rl = #right
    if rl < 0.001 then return end
    right = right / rl
    local up = vector3(n.y * right.z - n.z * right.y, n.z * right.x - n.x * right.z, n.x * right.y - n.y * right.x)
    local a = math.rad(g.rot or 0.0)
    local ca, sa = math.cos(a), math.sin(a)
    local r2 = right * ca + up * sa
    local u2 = up * ca - right * sa
    local hw, hh = (g.w or 1.0) / 2.0, (g.w or 1.0) / 4.0
    local c = vector3(g.x, g.y, g.z) + n * 0.012
    local tl, tr, br, bl = c - r2 * hw + u2 * hh, c + r2 * hw + u2 * hh, c + r2 * hw - u2 * hh, c - r2 * hw - u2 * hh
    local cr, cg, cb = tint and tint[1] or 255, tint and tint[2] or 255, tint and tint[3] or 255
    DrawSpritePoly(tl.x, tl.y, tl.z, tr.x, tr.y, tr.z, br.x, br.y, br.z, cr, cg, cb, alpha, 'pbgfx', d.name, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0)
    DrawSpritePoly(tl.x, tl.y, tl.z, br.x, br.y, br.z, bl.x, bl.y, bl.z, cr, cg, cb, alpha, 'pbgfx', d.name, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0)
    DrawSpritePoly(tl.x, tl.y, tl.z, br.x, br.y, br.z, tr.x, tr.y, tr.z, cr, cg, cb, alpha, 'pbgfx', d.name, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0)
    DrawSpritePoly(tl.x, tl.y, tl.z, bl.x, bl.y, bl.z, br.x, br.y, br.z, cr, cg, cb, alpha, 'pbgfx', d.name, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0)
end

-- Réception ----------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent('pb:g:gfx:all', function(j)
    local d = G.decode(j)
    list = {}
    for _, g in ipairs(d and d.list or {}) do if type(g) == 'table' and g.id then list[g.id] = g end end
end)
RegisterNetEvent('pb:g:gfx:add', function(j) local d = G.decode(j) if d and d.g and d.g.id then list[d.g.id] = d.g end end)
RegisterNetEvent('pb:g:gfx:del', function(j) local d = G.decode(j) if d and d.id then list[d.id] = nil end end)

-- Boucle d'affichage : on ne dessine que les tags proches
CreateThread(function()
    local nextScan = 0
    while true do
        local c = cfg()
        if c.enabled == false or not G.begun or next(list) == nil then
            Wait(1000)
        else
            Wait(0)
            local now = GetGameTimer()
            local me = GetEntityCoords(PlayerPedId())
            if now >= nextScan then
                nextScan = now + 600
                near = {}
                for _, g in pairs(list) do
                    local dx, dy, dz = g.x - me.x, g.y - me.y, g.z - me.z
                    local d2 = dx * dx + dy * dy + dz * dz
                    if d2 < 45 * 45 then near[#near + 1] = { g = g, d = math.sqrt(d2) } end
                end
                table.sort(near, function(a, b) return a.d < b.d end)
                pump()
            end
            for i = 1, math.min(#near, 24) do
                local e = near[i]
                if e.d < 45 then quad(e.g, e.d > 30 and math.floor(255 * (45 - e.d) / 15) or 255) end
            end
            if #near == 0 then Wait(250) end      -- rien à dessiner autour : pas besoin de repasser à chaque image
        end
    end
end)

-- Menu ----------------------------------------------------------------------------------------------------------------------------------------
local menuOpen = false
local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) or (G.IsCuffed and G.IsCuffed()) or placing or erasing end
local function closeMenu()
    if not menuOpen then return end
    menuOpen = false
    G.send('gfx.close', {})
    G.focus(false)
end
local function open()
    if menuOpen or busy() or not G.begun or IsPedInAnyVehicle(PlayerPedId(), false) then return end
    TriggerServerEvent('pb:g:gfx:menu')
end
RegisterNetEvent('pb:g:gfx:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if menuOpen or busy() then return end
        menuOpen = true
        G.focus(true)
        G.send('gfx.open', d)
    end
end)
G.nui['gfx.close'] = function() closeMenu() return {} end

-- Pose : un aperçu transparent suit le mur visé -------------------------------------------------------------------------------------------
local function camRay(maxd)
    local c = GetGameplayCamCoord()
    local r = GetGameplayCamRot(2)
    local rx, rz = math.rad(r.x), math.rad(r.z)
    local dir = vector3(-math.sin(rz) * math.abs(math.cos(rx)), math.cos(rz) * math.abs(math.cos(rx)), math.sin(rx))
    local e = c + dir * maxd
    local h = StartExpensiveSynchronousShapeTestLosProbe(c.x, c.y, c.z, e.x, e.y, e.z, 1, PlayerPedId(), 4)
    local _, hit, pos, normal = GetShapeTestResult(h)
    return hit == 1, pos, normal
end
local function placeLoop(ch)
    placing = true
    local g = { kind = ch.kind, text = ch.text, font = ch.font, color = ch.color, outline = ch.outline, img = nil, w = tonumber(ch.w) or 1.4, rot = 0.0 }
    if ch.kind == 'img' then g.img = G.gfxRef and G.gfxRef[ch.ref] or nil end
    local lastHelp, nextPump = '', 0
    local function help(text, bad) local k = text .. (bad and '!' or '') if k ~= lastHelp then lastHelp = k G.send('gfx.help', { text = text, bad = bad }) end end
    local c = cfg()
    local maxd = (tonumber(c.place_dist) or 6) + 0.0
    local wmin, wmax = tonumber(c.w_min) or 0.6, tonumber(c.w_max) or 2.5
    while placing do
        Wait(0)
        local ped = PlayerPedId()
        if G.state.dead or IsPedInAnyVehicle(ped, false) or (G.IsCuffed and G.IsCuffed()) then break end
        DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 140, true) DisableControlAction(0, 141, true) DisableControlAction(0, 142, true)
        DisableControlAction(0, 14, true) DisableControlAction(0, 15, true) DisableControlAction(0, 44, true) DisableControlAction(0, 38, true) DisableControlAction(0, 257, true) DisableControlAction(0, 200, true)
        if IsDisabledControlJustPressed(0, 15) then g.w = math.min(wmax, g.w + 0.1) end
        if IsDisabledControlJustPressed(0, 14) then g.w = math.max(wmin, g.w - 0.1) end
        if IsDisabledControlPressed(0, 44) then g.rot = ((g.rot or 0.0) - 1.5 + 180.0) % 360.0 - 180.0 end
        if IsDisabledControlPressed(0, 38) then g.rot = ((g.rot or 0.0) + 1.5 + 180.0) % 360.0 - 180.0 end
        if GetGameTimer() >= nextPump then nextPump = GetGameTimer() + 250 pump() end
        local hit, pos, n = camRay(maxd + 4.0)
        local me = GetEntityCoords(ped)
        local ok = hit and math.abs(n.z) < 0.5 and #(pos - me) <= maxd
        if hit then
            g.x, g.y, g.z, g.nx, g.ny, g.nz = pos.x, pos.y, pos.z, n.x, n.y, n.z
            -- le tag doit être prêt (texture) pour être dessiné ; sinon on affiche seulement le texte d'aide
            quad(g, 120, (not ok) and { 255, 90, 90 } or nil)
        end
        help(hit and (ok and ('Clic gauche : poser · Molette : taille (%.1f m) · Q / E : tourner · Clic droit : annuler'):format(g.w) or 'Vise un mur à portée (pas le sol).') or 'Vise un mur à portée.', hit and not ok)
        if IsDisabledControlJustPressed(0, 25) or IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 200) then break end
        if ok and IsDisabledControlJustPressed(0, 24) then
            local msg = { kind = ch.kind, ref = ch.ref, text = ch.text, font = ch.font, color = ch.color, outline = ch.outline, x = g.x, y = g.y, z = g.z, nx = g.nx, ny = g.ny, nz = g.nz, w = g.w, rot = g.rot }
            G.send('gfx.help', { stop = true })
            TaskTurnPedToFaceCoord(ped, g.x, g.y, g.z, 500)
            RequestAnimDict('switch@franklin@lamar_tagging_wall')
            local t = GetGameTimer() + 2000
            while not HasAnimDictLoaded('switch@franklin@lamar_tagging_wall') and GetGameTimer() < t do Wait(10) end
            if HasAnimDictLoaded('switch@franklin@lamar_tagging_wall') then TaskPlayAnim(ped, 'switch@franklin@lamar_tagging_wall', 'lamar_tagging_exit_loop_lamar', 8.0, -8.0, 3500, 1, 0, false, false, false) end
            Wait(3500)
            ClearPedTasks(ped)
            TriggerServerEvent('pb:g:gfx:place', msg)
            break
        end
    end
    G.send('gfx.help', { stop = true })
    placing = false
end
G.nui['gfx.choose'] = function(d)
    if type(d) ~= 'table' or (d.kind ~= 'img' and d.kind ~= 'txt') then return {} end
    closeMenu()
    -- l'image du tag choisi : on retrouve son identifiant dans la configuration (le serveur revalide à la pose)
    local c = cfg()
    local ref = tostring(d.ref or '')
    G.gfxRef = G.gfxRef or {}
    if d.kind == 'img' and ref:match('^t%d+$') then G.gfxRef[ref] = c[ref .. '_img'] end
    CreateThread(function() placeLoop({ kind = d.kind, ref = ref, text = tostring(d.text or ''):sub(1, 20), font = tostring(d.font or 'street'), color = tostring(d.color or '#ffffff'), outline = tostring(d.outline or '#111111'), w = tonumber(d.w) or 1.4 }) end)
    return {}
end

-- Effacer le tag le plus proche ---------------------------------------------------------------------------------------------------------------
local function nearest()
    local me = GetEntityCoords(PlayerPedId())
    local best, bd = nil, (tonumber(cfg().erase_dist) or 4) + 0.0
    for _, g in pairs(list) do
        local d = #(vector3(g.x, g.y, g.z) - me)
        if d < bd then best, bd = g, d end
    end
    return best
end
local function erase()
    if busy() or not G.begun then return end
    local g = nearest()
    if not g then G.send('notify', { type = 'warn', text = 'Aucun tag à portée.' }) return end
    TriggerServerEvent('pb:g:gfx:erase:start', g.id)
end
RegisterNetEvent('pb:g:gfx:erase:go', function(j)
    local d = G.decode(j)
    if not d or erasing then return end
    erasing = true
    local ped = PlayerPedId()
    local secs = math.max(2, tonumber(d.secs) or 8)
    local g = list[d.id]
    if g then TaskTurnPedToFaceCoord(ped, g.x, g.y, g.z, 500) end
    RequestAnimDict('timetable@floyd@clean_kitchen@base')
    local t = GetGameTimer() + 2000
    while not HasAnimDictLoaded('timetable@floyd@clean_kitchen@base') and GetGameTimer() < t do Wait(10) end
    if HasAnimDictLoaded('timetable@floyd@clean_kitchen@base') then TaskPlayAnim(ped, 'timetable@floyd@clean_kitchen@base', 'base', 8.0, -8.0, secs * 1000, 1, 0, false, false, false) end
    G.send('crime.progress', { label = 'Effacer le tag', secs = secs })
    local done, endAt = true, GetGameTimer() + secs * 1000
    while GetGameTimer() < endAt do
        Wait(100)
        if G.state.dead or (g and #(GetEntityCoords(PlayerPedId()) - vector3(g.x, g.y, g.z)) > (tonumber(cfg().erase_dist) or 4) + 2.5) or IsControlJustPressed(0, 73) then done = false break end
    end
    ClearPedTasks(PlayerPedId())
    if not done then G.send('crime.progress', { cancel = true }) end
    TriggerServerEvent('pb:g:gfx:erase:end', done)
    erasing = false
end)

RegisterCommand('tag', open, false)
RegisterCommand('pb_tag', open, false)
RegisterCommand('tagerase', erase, false)
RegisterCommand('pb_tagerase', erase, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.graffiti and GetGameTimer() < t do Wait(250) end
    local k = G.cfg.graffiti and G.cfg.graffiti.key
    if type(k) == 'string' and k ~= '' then RegisterKeyMapping('pb_tag', 'Menu des tags (graffiti)', 'keyboard', k) end
end)
CreateThread(function() while true do Wait(500) if menuOpen and busy() then closeMenu() end end end)
AddEventHandler('onResourceStop', function(r) if r == RES then for _, d in pairs(duis) do DestroyDui(d.dui) end end end)
G.onForceClose(function() closeMenu() end)
