/* Atelier v2 : la voiture au centre (caméra du jeu), pièces à gauche par onglets, performances et panier à droite.
   ↑/↓ pièce · ←/→ réglage (appliqué tout de suite sur la voiture, le client le voit) · Q/E onglet · Entrée valider · Échap annuler.
   Le client Lua garde l'état et applique ; le serveur recalcule les prix à la validation du devis. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const money = (n) => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' $';
let S = null;

function host() { let r = document.getElementById('g-mech'); if (!r) { r = h('div', { id: 'g-mech', class: 'hidden' }); G.root.appendChild(r); } return r; }
// prix d'une pièce pour le réglage choisi (performances : prix du niveau 1 × niveau)
function priceOf(p, i) {
  const o = p.opts[i - 1];
  if (!o || i === p.base) return 0;
  if (p.style === 'level' || p.perLevel) return Math.max(0, (Number(o.v) + 1)) * (Number(p.price) || 0);
  if (p.style === 'toggle' && o.v === false) return 0;
  return Number(p.price) || 0;
}
function cart() {
  const out = [];
  S.tabs.forEach((t) => t.pieces.forEach((p) => { if (!p.local_ && p.sel !== p.base && p.base !== undefined) out.push({ tab: t.id, label: p.label, opt: p.opts[p.sel - 1].label, price: priceOf(p, p.sel) }); }));
  // pneus seuls (les jantes ne changent pas) : une ligne à part
  const all = S.tabs.flatMap((t) => t.pieces), ty = all.find((p) => p.k === 'tyre'), wh = all.find((p) => p.k === 'wheel');
  if (ty && ty.sel !== ty.base && !(wh && wh.sel !== wh.base)) out.push({ tab: 'roues', label: 'Pneus', opt: ty.opts[ty.sel - 1].label, price: Number(ty.price) || 0 });
  return out;
}
function tabCount(t) { return t.pieces.filter((p) => !p.local_ && p.sel !== p.base).length; }

// statistiques : d'origine (lues par le jeu) et après les pièces de performance
function after() {
  const b = S.stats, lv = (mod) => { const p = S.tabs[0].pieces.find((x) => x.perf === mod); if (!p) return [0, 0]; const v = Number(p.opts[p.sel - 1].v) + 1, v0 = Number(p.opts[p.base - 1] ? p.opts[p.base - 1].v : -1) + 1; return [v, v0]; };
  const turbo = S.tabs[0].pieces.find((x) => x.k === 'turbo'), tOn = turbo && turbo.opts[turbo.sel - 1].v === true, t0 = turbo && turbo.opts[turbo.base - 1].v === true;
  const [e, e0] = lv(11), [br, br0] = lv(12), [tr, tr0] = lv(13), [su, su0] = lv(15);
  const clamp = (n) => Math.max(0, Math.min(100, Math.round(n)));
  return {
    speed: [b.speed, clamp(b.speed + (e - e0) * 2.5 + (tr - tr0) * 1.5 + ((tOn ? 1 : 0) - (t0 ? 1 : 0)) * 3)],
    accel: [b.accel, clamp(b.accel + (e - e0) * 3 + (tr - tr0) * 2.5 + ((tOn ? 1 : 0) - (t0 ? 1 : 0)) * 6)],
    brake: [b.brake, clamp(b.brake + (br - br0) * 5)],
    grip: [b.grip, clamp(b.grip + (su - su0) * 4)],
  };
}

function draw() {
  const r = host(); G.clear(r);
  const tab = S.tabs[S.tab], list = tab.pieces, items = cart(), total = items.reduce((a, c) => a + c.price, 0);
  // en-tête : fil d'Ariane et onglets
  const tabs = h('div', { class: 'mv-tabs' }, h('kbd', { class: 'mv-key' }, 'Q'),
    S.tabs.map((t, i) => { const n = tabCount(t); return h('button', { type: 'button', class: 'mv-tab' + (i === S.tab ? ' on' : ''), onclick: () => setTab(i) }, t.label, n ? h('em', null, String(n)) : null); }),
    h('kbd', { class: 'mv-key' }, 'E'),
    h('button', { type: 'button', class: 'mv-doors' + (S.doors ? ' on' : ''), onclick: doors }, svg('<path d="M5 3h10v18H5z" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M15 6l4 1v12l-4 1" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="1" fill="currentColor"/>'), S.doors ? 'Fermer les portes' : 'Ouvrir les portes'));
  const head = h('div', { class: 'mv-head' }, h('div', { class: 'mv-crumb' }, svg('<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>'),
    h('span', null, String(S.biz || 'Atelier').toUpperCase()), h('i', null, '•'), h('b', null, S.label || 'Véhicule'), h('small', null, S.plate || '')), tabs);
  // pièces
  const cards = list.map((p, i) => card(p, i === S.row, i));
  const left = h('div', { class: 'mv-list' }, cards.length ? cards : h('div', { class: 'mv-empty' }, 'Rien à modifier dans cet onglet pour ce véhicule.'));
  // performances
  const a = after();
  const stat = (label, k) => { const v = a[k], d = v[1] - v[0]; return h('div', { class: 'mv-st' }, h('div', { class: 'mv-sth' }, h('span', null, label), d ? h('em', { class: d > 0 ? 'up' : 'down' }, (d > 0 ? '+' : '') + d) : null, h('b', null, String(v[1]))),
    h('div', { class: 'mv-bar' }, h('i', { style: { width: v[1] + '%' } }), d > 0 ? h('u', { style: { left: v[0] + '%', width: d + '%' } }) : null, h('s', { style: { left: v[0] + '%' } }))); };
  const perf = h('div', { class: 'mv-panel mv-perf' }, h('div', { class: 'mv-ph' }, h('b', null, 'PERFORMANCES'), h('span', { class: 'mv-leg' }, h('i', { class: 'o' }), "D'origine", h('i', { class: 'a' }), 'Après')),
    stat('Vitesse de pointe', 'speed'), stat('Accélération', 'accel'), stat('Freinage', 'brake'), stat('Tenue de route', 'grip'));
  // panier
  const basket = h('div', { class: 'mv-panel mv-cart' }, h('div', { class: 'mv-ph' }, h('b', null, 'PANIER'), h('span', null, items.length + ' modification' + (items.length > 1 ? 's' : ''))),
    h('div', { class: 'mv-lines' }, items.length ? items.map((c) => h('div', { class: 'mv-line' }, h('span', null, c.label, h('small', null, c.opt)), h('b', null, money(c.price)))) : h('div', { class: 'mv-none' }, 'Change une pièce avec ← → : elle s’ajoute ici.')),
    h('div', { class: 'mv-total' }, h('small', null, 'TOTAL'), h('strong', null, money(total))),
    h('p', { class: 'mv-note2' }, 'Le client voit chaque changement sur sa voiture. Le devis validé part au serveur ; ensuite F6 › Envoyer la facture.'));
  const btns = h('div', { class: 'mv-btns' }, h('button', { type: 'button', class: 'mv-cancel', onclick: cancel }, 'Annuler', h('kbd', null, 'ÉCHAP')),
    h('button', { type: 'button', class: 'mv-pay', disabled: items.length ? null : true, onclick: validate }, items.length ? 'Valider · ' + money(total) : 'Valider le devis'));
  const hints = h('div', { class: 'mv-hints' }, h('span', null, 'Pièce'), h('kbd', null, '↑'), h('kbd', null, '↓'), h('span', null, 'Réglage'), h('kbd', null, '←'), h('kbd', null, '→'), h('span', null, 'Valider'), h('kbd', { class: 'w' }, 'Entrée'), h('span', null, 'Caméra'), h('kbd', { class: 'w' }, 'Glisser'), h('kbd', { class: 'w' }, 'Molette'));
  r.appendChild(h('div', { class: 'mv' }, dragLayer(), h('div', { class: 'mv-lc' }, head, left), h('div', { class: 'mv-right' }, perf, h('div', { class: 'mv-sp' }), basket, btns), hints));
  const sel = left.children[S.row]; if (sel && sel.scrollIntoView) sel.scrollIntoView({ block: 'nearest' });
}
// zone libre autour de la voiture : clic maintenu + glisser pour tourner la caméra, molette pour zoomer
let drag = null, pend = { dx: 0, dy: 0, zoom: 0 }, raf = 0;
function flush() { raf = 0; if (!pend.dx && !pend.dy && !pend.zoom) return; const p = pend; pend = { dx: 0, dy: 0, zoom: 0 }; G.post('mech.orbit', p); }
function queue() { if (!raf) raf = requestAnimationFrame(flush); }
function dragLayer() {
  const el = h('div', { class: 'mv-drag', title: 'Clic maintenu : tourner autour de la voiture · molette : zoom' });
  el.addEventListener('mousedown', (e) => { if (e.button !== 0 && e.button !== 2) return; drag = { x: e.clientX, y: e.clientY }; el.classList.add('on'); e.preventDefault(); });
  el.addEventListener('wheel', (e) => { pend.zoom += e.deltaY > 0 ? 1 : -1; queue(); e.preventDefault(); }, { passive: false });
  el.addEventListener('contextmenu', (e) => e.preventDefault());
  return el;
}
window.addEventListener('mousemove', (e) => { if (!drag || !S) return; pend.dx += e.clientX - drag.x; pend.dy += e.clientY - drag.y; drag = { x: e.clientX, y: e.clientY }; queue(); });
window.addEventListener('mouseup', () => { if (!drag) return; drag = null; const d = document.querySelector('.mv-drag'); if (d) d.classList.remove('on'); });
function svg(inner) { const s = h('i', { class: 'mv-ic' }); s.innerHTML = '<svg viewBox="0 0 24 24">' + inner + '</svg>'; return s; }   // pictogrammes fixes du fichier

function card(p, on, idx) {
  const o = p.opts[p.sel - 1] || { label: '' }, changed = p.sel !== p.base, pr = priceOf(p, p.sel) || (p.style === 'level' ? (Number(p.price) || 0) : Number(p.price) || 0);
  const priceTxt = h('span', { class: 'mv-pr' }, changed ? h('i', { class: 'dot' }) : null, (p.local_ && !p.price) ? '' : (pr ? money(pr) : 'Gratuit'));
  const segs = (n, k) => h('div', { class: 'mv-segs' }, Array.from({ length: n }, (_, i) => h('i', { class: i < k ? 'on' : '' })));
  const isLevel = p.style === 'level';
  if (!on) {
    let right;
    if (isLevel) right = segs(p.opts.length - 1, p.sel - 1);
    else if (p.style === 'toggle') right = h('i', { class: 'mv-tg' + (o.v === true ? ' on' : '') });
    else if (p.style === 'swatch' && o.sw) right = h('i', { class: 'mv-sw', style: { background: o.sw } });
    return h('div', { class: 'mv-card' + (changed ? ' ch' : ''), onclick: () => { S.row = idx; draw(); } },
      h('div', { class: 'mv-ct' }, h('b', null, p.label), h('small', null, o.label)), h('div', { class: 'mv-cr' }, priceTxt, right || null));
  }
  const step = (d) => h('button', { type: 'button', class: 'mv-ar', onclick: (e) => { e.stopPropagation(); move(d); } }, d < 0 ? '‹' : '›');
  let body;
  if (p.style === 'swatch') {
    const n = p.opts.length, from = Math.max(0, Math.min(p.sel - 1 - 5, n - 11)), to = Math.min(n, from + 11);
    body = h('div', { class: 'mv-sws' }, step(-1), h('div', { class: 'mv-swl' }, p.opts.slice(from, to).map((x, j) => h('button', { type: 'button', class: 'mv-sw' + (from + j + 1 === p.sel ? ' on' : '') + (x.sw ? '' : ' none'), title: x.label, style: { background: x.sw || 'transparent' }, onclick: (e) => { e.stopPropagation(); set(p, from + j + 1); } }))), step(1));
  } else body = h('div', { class: 'mv-val' }, step(-1), h('span', null, o.label), step(1));
  const base = p.opts[p.base - 1];
  return h('div', { class: 'mv-card on' + (changed ? ' ch' : '') },
    h('div', { class: 'mv-cth' }, h('b', null, p.label), priceTxt), body,
    isLevel ? segs(p.opts.length - 1, p.sel - 1) : (p.style === 'swatch' ? h('div', { class: 'mv-swn' }, o.label) : null),
    h('small', { class: 'mv-before' }, (isLevel ? 'Accélération et vitesse de pointe' : p.style === 'swatch' ? 'Couleur' : 'Réglage') + (base ? ' · Avant : ' : ''), base ? h('b', null, base.label) : null));
}

function set(p, i) {
  if (!S || i < 1 || i > p.opts.length || i === p.sel) return;
  p.sel = i;
  G.post('mech.set', { k: p.k, i }).then((res) => {
    if (res && res.wheel) { const w = S.tabs.flatMap((t) => t.pieces).find((x) => x.k === 'wheel'); if (w) { w.opts = res.wheel.opts; w.base = res.wheel.base; w.sel = res.wheel.sel; draw(); } }
  });
  draw();
}
function move(d) { const p = S.tabs[S.tab].pieces[S.row]; if (!p) return; const n = p.opts.length; set(p, ((p.sel - 1 + d + n) % n) + 1); }
function setTab(i) { S.tab = (i + S.tabs.length) % S.tabs.length; S.row = 0; G.post('mech.tab', { id: S.tabs[S.tab].id }); draw(); }
function doors() { G.post('mech.doors', {}).then((r) => { if (S && r) { S.doors = !!r.open; draw(); } }); }
function cancel() { G.post('mech.cancel', {}); }
function validate() { if (cart().length) G.post('mech.quote', {}); }

function onKey(e) {
  if (!S) return;
  const k = e.key;
  if (k === 'ArrowDown' || k === 'ArrowUp') { const n = S.tabs[S.tab].pieces.length; if (n) { S.row = (S.row + (k === 'ArrowDown' ? 1 : -1) + n) % n; draw(); } }
  else if (k === 'ArrowLeft') move(-1);
  else if (k === 'ArrowRight') move(1);
  else if (k === 'q' || k === 'Q' || k === 'a' || k === 'A') setTab(S.tab - 1);
  else if (k === 'e' || k === 'E') setTab(S.tab + 1);
  else if (k === 'Enter') validate();
  else if (k === 'Escape' || k === 'Backspace') cancel();
  else return;
  e.preventDefault(); e.stopPropagation();
}

G.on('mech.open', (d) => {
  S = { biz: d.biz, plate: d.plate, label: d.label, tabs: (d.tabs || []).filter((t) => t.pieces && t.pieces.length), stats: d.stats || { speed: 50, accel: 50, brake: 50, grip: 50 }, tab: 0, row: 0, doors: false };
  if (!S.tabs.length) { S = null; return; }
  host().classList.remove('hidden');
  document.addEventListener('keydown', onKey, true);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'mech'); G.uiStack.push({ id: 'mech', onEscape: cancel });
  draw();
});
G.on('mech.close', () => { S = null; const r = host(); G.clear(r); r.classList.add('hidden'); document.removeEventListener('keydown', onKey, true); G.uiStack = G.uiStack.filter((u) => u.id !== 'mech'); });

// aperçu (panel / harnais) : un véhicule d'exemple
G.preview.mechv2 = function (box) {
  const lvl = (n, b, s) => ({ k: 'mod:x' + n, label: n, style: 'level', perLevel: true, price: 1000, base: b, sel: s, opts: [{ label: 'Aucun', v: -1 }, { label: 'Niveau 1', v: 0 }, { label: 'Niveau 2', v: 1 }, { label: 'Niveau 3', v: 2 }, { label: 'Niveau 4', v: 3 }] });
  const eng = lvl('Moteur', 3, 4); eng.perf = 11; eng.price = 1000;
  const brk = lvl('Freins', 2, 2); brk.perf = 12; brk.opts = brk.opts.slice(0, 4);
  const tr = lvl('Transmission', 1, 1); tr.perf = 13; tr.opts = tr.opts.slice(0, 4);
  const su = lvl('Suspension', 1, 1); su.perf = 15;
  G.handlers['mech.open'].forEach((fn) => fn({ biz: 'Atelier', label: 'Véhicule', plate: 'LM 482 KS', stats: { speed: 62, accel: 57, brake: 63, grip: 55 }, tabs: [
    { id: 'performances', label: 'Performances', pieces: [eng, brk, tr, su, { k: 'turbo', label: 'Turbo', style: 'toggle', price: 0, base: 1, sel: 1, opts: [{ label: 'Sans', v: false }, { label: 'Installé', v: true }] }] },
    { id: 'exterieur', label: 'Extérieur', pieces: [{ k: 'tint', label: 'Vitres teintées', price: 250, base: 1, sel: 1, opts: [{ label: 'Aucune', v: 0 }, { label: 'Fumée', v: 5 }] }] },
    { id: 'interieur', label: 'Intérieur', pieces: [{ k: 'int', label: 'Couleur intérieure', style: 'swatch', price: 300, base: 1, sel: 1, opts: [{ label: 'Noir', v: 0, sw: '#0d0d0f' }, { label: 'Crème', v: 107, sw: '#efe5cc' }] }] },
    { id: 'peinture', label: 'Peinture', pieces: [{ k: 'col1', label: 'Couleur principale', style: 'swatch', price: 600, base: 1, sel: 1, opts: [{ label: 'Noir', v: [0], sw: '#0d0d0f' }, { label: 'Rouge', v: [27], sw: '#c0131d' }, { label: 'Bleu', v: [64], sw: '#1f4fbf' }] }] },
    { id: 'roues', label: 'Roues', pieces: [{ k: 'wheel', label: 'Jantes', price: 900, base: 1, sel: 1, opts: [{ label: "D'origine", v: [0, -1, false] }, { label: 'Sport 1', v: [0, 0, false] }] }] },
    { id: 'extras', label: 'Extras', pieces: [{ k: 'xenon', label: 'Phares xénon', style: 'toggle', price: 800, base: 1, sel: 1, opts: [{ label: "D'origine", v: false }, { label: 'Xénon', v: true }] }] },
  ] }));
  const r = host(); if (box && r.parentNode !== box) box.appendChild(r);
};
})();
