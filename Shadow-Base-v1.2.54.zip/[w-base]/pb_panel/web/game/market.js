/* Vitrine à cartes : supérette, concession, garage. Plein écran, fond transparent, cartes avec image.
   marketView({ title, sub, logo, money, tabs, tabOn, onTab, onClose, search, searchPlaceholder, empty })
   → { el, setMoney, setTabs, setCards(cards, cats), note(el|null), say(ok, msg) }
   carte : { id, title, sub, price, img, fallback, icon, chips[], stats[{l,v,neg}], stock, badge, qty, max, category, desc, actions[{label, primary, ghost, disabled, onclick(qty)}] }
   Les images viennent de l'article ; sans image, une illustration neutre. Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const ART = { store: 'img/cards/city.jpg', car: 'img/cards/veh.jpg' };

function marketView(o) {
  o = o || {};
  const hexOk = (c) => /^#[0-9a-fA-F]{6}$/.test(c || ''), br = (G.cfg && G.cfg.brand) || {};
  const st = { cat: '', q: '', cards: [], cats: [], qty: {}, sel: null };
  const det = h('aside', { class: 'mk-det hidden' });   // style Nova : fiche de la carte choisie, à droite
  const cash = h('b', null, ''), bank = h('b', null, '');
  const grid = h('div', { class: 'mk-grid' }), cats = h('div', { class: 'mk-cats' }), tabs = h('div', { class: 'mk-tabs' }), noteBox = h('div', { class: 'mk-note' }), toast = h('div', { class: 'mk-toast hidden' });
  const ownLogo = G.assetUrl(o.logo || ''), logoUrl = ownLogo || (G.nova && G.nova() ? G.logoUrl() : '');
  const search = o.search === false ? null : h('input', { class: 'mk-s', type: 'text', placeholder: o.searchPlaceholder || 'Rechercher…', oninput: (e) => { st.q = e.target.value.trim().toLowerCase(); draw(); } });
  if (search) search.addEventListener('keydown', (e) => e.stopPropagation());
  const el = h('div', { class: 'mk', style: G.season() && hexOk(br.color) ? { '--acc': br.color } : {} },
    h('header', { class: 'mk-top' },
      h('div', { class: 'mk-ttl' }, logoUrl ? h('img', { src: logoUrl, alt: '', 'data-pblogo': ownLogo ? null : '1' }) : null, h('div', null, G.brandName() ? h('small', { class: 'mk-eb' }, G.brandName()) : null, h('b', null, o.title || ''), o.sub ? h('small', null, o.sub) : null)),
      h('div', { class: 'mk-tr' }, o.money ? [h('span', { class: 'mk-m' }, ico('coins'), cash), h('span', { class: 'mk-m' }, ico('card'), bank)] : null, search,
        o.onClose ? h('button', { class: 'mk-x', title: 'Fermer', onclick: o.onClose }, ico('x')) : null)),
    h('div', { class: 'mk-bar' }, tabs, cats), h('div', { class: 'mk-side' }, det, noteBox), toast, grid, G.festEl());

  function setTabs(list, on) {
    G.clear(tabs);
    (list || []).forEach((t) => tabs.appendChild(h('button', { class: 'mk-tab' + (t.id === on ? ' on' : ''), onclick: () => { setTabs(list, t.id); o.onTab && o.onTab(t.id); } }, ico(t.icon || 'car'), t.label)));
    tabs.classList.toggle('hidden', !(list || []).length);
  }
  function drawCats() {
    G.clear(cats);
    cats.classList.toggle('hidden', st.cats.length < 2);
    if (st.cats.length < 2) return;
    [{ id: '', label: 'Tout' }].concat(st.cats.map((c) => ({ id: c, label: c }))).forEach((c) => cats.appendChild(h('button', { class: 'mk-chip' + (st.cat === c.id ? ' on' : ''), onclick: () => { st.cat = c.id; drawCats(); draw(); } }, c.label)));
  }
  function media(c) {
    const fb = c.fallback || ART[c.art || 'store'];
    const m = h('div', { class: 'mk-img' });
    const bg = h('div', { class: 'mk-bg', style: { backgroundImage: 'url("' + fb + '")' } });
    m.appendChild(bg);
    const src = G.assetUrl(c.img || '') || (c.img && /^https:\/\//.test(c.img) ? c.img : '');
    if (src) {
      const im = h('img', { alt: '', src, loading: 'lazy' });
      im.addEventListener('error', () => im.remove());
      m.appendChild(im);
    } else m.appendChild(h('span', { class: 'mk-big' }, ico(c.icon || 'cart')));
    return m;
  }
  function card(c) {
    const out = c.stock !== undefined && c.stock !== null && c.stock <= 0;
    const q0 = st.qty[c.id] || 1;
    const qEl = h('b', null, String(q0));
    const priceEl = h('span', { class: 'mk-p' }, '');
    const max = Math.max(1, Math.min(c.max || 10, c.stock == null ? 99 : Math.max(1, c.stock)));
    const showP = () => { priceEl.textContent = c.price == null ? '' : G.money(c.price * (c.qty ? (st.qty[c.id] || 1) : 1)); };
    const bump = (d) => { const n = Math.max(1, Math.min(max, (st.qty[c.id] || 1) + d)); st.qty[c.id] = n; qEl.textContent = String(n); showP(); };
    showP();
    const chips = (c.chips || []).length ? h('div', { class: 'mk-chips' }, c.chips) : null;
    const stats = (c.stats || []).length ? h('div', { class: 'mk-stats' }, c.stats.map((s) => h('div', { class: 'mk-st' }, h('span', null, s.l), h('i', null, h('u', { class: s.neg ? 'neg' : '', style: { width: Math.max(4, Math.min(100, Math.abs(s.v))) + '%' } })), s.t ? h('em', null, s.t) : null))) : null;
    const acts = (c.actions || []).map((a) => h('button', { class: 'mk-b' + (a.primary ? ' pri' : '') + (a.ghost ? ' ghost' : ''), disabled: (a.disabled || out && a.primary) || null, onclick: () => a.onclick && a.onclick(c.qty ? (st.qty[c.id] || 1) : 1) }, out && a.primary ? 'Épuisé' : a.label));
    return h('article', { class: 'mk-c' + (out ? ' out' : '') + (st.sel === c.id ? ' on' : ''), 'data-id': c.id, onclick: (e) => { if (!G.nova() || (e.target.closest && e.target.closest('button'))) return; st.sel = c.id; grid.querySelectorAll('.mk-c').forEach((x) => x.classList.toggle('on', x.getAttribute('data-id') === c.id)); drawDet(); } },
      media(c),
      h('div', { class: 'mk-ic' }, ico(c.icon || 'cart')), c.badge ? h('span', { class: 'mk-badge' }, c.badge) : null, c.price != null ? h('div', { class: 'mk-pp' }, priceEl) : null,
      h('div', { class: 'mk-body' }, h('b', null, c.title), c.sub ? h('small', null, c.sub) : null, c.desc ? h('p', null, c.desc) : null, chips, stats,
        c.stock != null ? h('small', { class: 'mk-sk' + (out ? ' bad' : '') }, out ? 'Épuisé' : 'En stock : ' + c.stock) : null),
      h('footer', null, c.qty && !out ? h('div', { class: 'mk-q' }, h('button', { onclick: () => bump(-1) }, '−'), qEl, h('button', { onclick: () => bump(1) }, '+')) : null, acts));
  }
  // fiche à droite (Nova) : titre, plaque, état, détails et les mêmes boutons que la carte, en grand
  function drawDet() {
    G.clear(det);
    // (v1.2.43) la fiche reste affichée même avec un formulaire (il passe dessous) : avant, elle disparaissait et les boutons
    // revenaient dans les cartes, qui écrasaient alors le nom du véhicule
    const c = G.nova() ? st.cards.find((x) => x.id === st.sel) : null;
    det.classList.toggle('hidden', !c);
    el.classList.toggle('has-det', !!c);
    el.classList.toggle('has-side', !!c || !noteBox.classList.contains('hidden'));
    if (!c) return;
    det.appendChild(h('div', { class: 'mk-dh' }, h('b', null, c.title), c.badge ? h('span', { class: 'mk-dbadge' }, c.badge) : null));
    if (c.sub) det.appendChild(h('div', { class: 'mk-dplate' }, c.sub));
    // (v1.2.43) chaque ligne de la fiche porte son libellé (avant : « 0 % », « 100 % » sans dire ce que c'était)
    const kv = (c.chips || []).map((x) => { const l = x.getAttribute && x.getAttribute('data-l'); return l ? h('div', { class: 'mk-dkv kv' }, h('span', null, l), h('b', null, x.textContent)) : h('div', { class: 'mk-dkv' }, x.textContent); });
    if (kv.length) det.appendChild(h('div', { class: 'mk-dkvs' }, kv));
    const acts = (c.actions || []).map((a) => h('button', { class: 'mk-b' + (a.primary ? ' pri' : ' ghost'), disabled: a.disabled || null, onclick: () => a.onclick && a.onclick(1) }, a.label));
    det.appendChild(acts.length ? h('div', { class: 'mk-dacts' }, acts) : h('p', { class: 'mk-dnone' }, 'Aucune action possible ici pour ce véhicule.'));
  }
  function draw() {
    if (G.nova() && st.cards.length && !st.cards.some((x) => x.id === st.sel)) st.sel = st.cards[0].id;
    G.clear(grid);
    const list = st.cards.filter((c) => (!st.cat || c.category === st.cat) && (!st.q || String(c.title).toLowerCase().indexOf(st.q) >= 0 || String(c.sub || '').toLowerCase().indexOf(st.q) >= 0));
    if (!st.cards.length) grid.appendChild(h('div', { class: 'mk-empty' }, o.empty || 'Rien à afficher pour le moment.'));
    else if (!list.length) grid.appendChild(h('div', { class: 'mk-empty' }, 'Aucun résultat.'));
    list.forEach((c) => grid.appendChild(card(c)));
    drawDet();
  }
  let tt = null;
  const api = {
    el, setTabs,
    setMoney: (m) => { if (!m) return; cash.textContent = G.money(m.cash); bank.textContent = G.money(m.bank); },
    setCards(cards, cs) { st.cards = cards || []; st.cats = cs || []; if (st.cat && st.cats.indexOf(st.cat) < 0) st.cat = ''; drawCats(); draw(); },
    note(node) { G.clear(noteBox); noteBox.classList.toggle('hidden', !node); if (node) noteBox.appendChild(node); drawDet(); },
    say(ok, msg) { toast.textContent = msg || ''; toast.className = 'mk-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(tt); tt = setTimeout(() => toast.classList.add('hidden'), 3500); },
  };
  if (o.money) api.setMoney(o.money);
  setTabs(o.tabs, o.tabOn);
  api.setCards([], []);
  return api;
}
G.marketView = marketView;
})();
