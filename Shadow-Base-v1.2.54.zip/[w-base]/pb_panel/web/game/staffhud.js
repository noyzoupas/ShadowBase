/* Mini-tableau de bord du staff en service : 3 à 4 chiffres calculés par le serveur. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null;
function view(d) {
  const items = (d && d.items) || [];
  if (!items.length) return null;
  if (d.style !== 'box') {
    // barre en haut de l'écran : pastille « STAFF » puis une case par information (texte inséré avec textContent)
    // une petite case carrée par information : icône, chiffre, libellé dessous (comme la référence)
    return h('div', { class: 'gsb gsb-tiles', style: { top: Math.max(0, Math.min(30, Number(d.top) || 0.8)) + '%' } },
      items.map((it) => h('div', { class: 'gsb-c' + (it.warn ? ' warn' : ''), title: String(it.label || '') }, h('span', { class: 'gsb-i' }, G.ico(String(it.icon || 'bolt'))),
        h('div', { class: 'gsb-v' }, h('b', null, String(it.value == null ? '' : it.value)), h('span', { class: 'gsb-l' }, String(it.label || ''))))));
  }
  return h('div', { class: 'gsh', style: { left: (Number(d.x) || 1.2) + '%', top: (Number(d.y) || 30) + '%' } },
    h('div', { class: 'gsh-t' }, h('i', { class: 'gsh-dot' }), 'EN SERVICE'),
    items.map((it) => h('div', { class: 'gsh-r' + (it.warn ? ' warn' : '') }, h('span', { class: 'gsh-i' }, G.ico(String(it.icon || 'bolt'))), h('span', { class: 'gsh-l' }, String(it.label || '')), h('b', null, String(it.value == null ? '' : it.value)))));
}
G.staffHudView = view;
let lastJson = '';
function show(d) {
  // (v1.2.43) renvoyée toutes les 5 s : on ne reconstruit que si elle a changé ou a été retirée de la page
  const j = JSON.stringify(d || {});
  if (el && el.isConnected && j === lastJson) return;
  lastJson = j;
  if (el) { el.remove(); el = null; }
  const v = view(d);
  if (v) { if (d && d.pin) v.classList.add('pin'); el = v; G.root.appendChild(el); }
}
G.on('staff.hud', show);
// Pastille « joueur suivi » sous la barre staff : Alt + clic ouvre sa fiche (le serveur choisit ce qui s'ouvre).
let pill = null;
G.on('staff.follow', (d) => {
  if (pill) { pill.remove(); pill = null; }
  if (!d || d.id == null) return;
  pill = h('div', { id: 'g-follow', title: 'Alt + clic : ouvrir sa fiche' }, h('i', { class: 'gsh-dot' }), h('span', null, 'Suivi : ' + String(d.name || '').slice(0, 40) + ' #' + Number(d.id)));
  pill.addEventListener('click', () => G.post('staff.follow.open', {}));
  G.root.appendChild(pill);
});
// (v1.2.43) Viseur staff : réticule au centre, nom et ID du joueur visé, « Clic : actions rapides »
let aim = null;
G.on('staff.aim', (d) => {
  if (!d || !d.on) { if (aim) { aim.remove(); aim = null; } return; }
  if (!aim) {
    aim = h('div', { id: 'g-aim' }, h('div', { class: 'sa-ret' }, h('i', { class: 'sa-h' }), h('i', { class: 'sa-v' }), h('b', { class: 'sa-dot' })), h('div', { class: 'sa-tag' }));
    document.body.appendChild(aim);   // hors du cadre mis à l'échelle : le centre est le vrai centre de l'écran
  }
  const t = d.target, tag = aim.querySelector('.sa-tag');
  aim.classList.toggle('on', !!t);
  G.clear(tag);
  if (t) {
    tag.appendChild(h('b', null, String(t.name || '').slice(0, 32) + '  #' + Number(t.id)));
    tag.appendChild(h('span', null, Number(t.dist || 0) + ' m · Clic : actions rapides'));
  } else tag.appendChild(h('span', null, 'Viseur staff · vise un joueur'));
});
G.preview.staffhud = function (box) {
  G.clear(box);
  const items = [{ label: 'Reports en attente', value: 3, icon: 'help', warn: true }, { label: 'Pris par moi', value: 1, icon: 'check' }, { label: 'Joueurs', value: 42, icon: 'users' }, { label: 'Staff en service', value: '2/3', icon: 'crown' }, { label: 'À terre', value: 1, icon: 'skull', warn: true }, { label: 'Police en service', value: 4, icon: 'shield' }, { label: 'Secours en service', value: 2, icon: 'heart' }];
  box.appendChild(G.fitStage(h('div', { class: 'tg-scene', style: { width: '1300px', height: '240px' } }, view({ style: 'bar', top: 3, items })), 1300, 240));
};
})();
