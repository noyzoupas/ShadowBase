-- Shadow Base — Chasse (serveur). Dans une zone de chasse posée au Builder, des animaux apparaissent (ou sont attirés avec un appeau) ;
-- le serveur choisit l'espèce et remet un jeton. Abattu puis dépecé au couteau, l'animal donne viande, peaux et trophées, revendus au
-- marché du chasseur : chaque vente fait baisser le cours du produit, qui remonte avec le temps. Bonus de revente pour les VIP.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'

local cache = {}
local function cfg(k, d)
    local v = cache[k]
    if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end
    if v == nil then return d end
    return v
end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Chasse', text) end
local function label(item) local i = W:ItemInfo(item) return i and i.label or item end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end
local function d2(c, s) return #(vector2(c.x, c.y) - vector2(s.x + 0.0, s.y + 0.0)) end
local function isVip(src) local ok, v = pcall(function() return W:IsVip(src) end) return ok and v == true end
-- Onglet Économie du panel (v1.2.42) : prix × multiplicateur × TVA, gains × salaires (× illégal / × activités)
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function ecoIn(n, kind) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoIncome(n, kind) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end


-- Marché : coefficient de prix par produit ----------------------------------------------------------------------------------------------------------
local factor, dirty = {}, {}
local DROP = { c = 0.004, pc = 0.006, r = 0.012, e = 0.025, l = 0.05 }
local function f(item) return factor[item] or 1.0 end
local function setF(item, v) factor[item] = math.max((tonumber(cfg('min_factor', 40)) or 40) / 100, math.min(1.4, v)) dirty[item] = true end
local function unitPrice(item)
    local g = HUNT_GOOD_BY[item]
    if not g then return 0 end
    return math.max(1, ecoIn(g.price * f(item) * ((tonumber(cfg('price_mult', 35)) or 35) / 100), 'activity'))
end
local function saveMarket()
    for item in pairs(dirty) do MySQL.insert('REPLACE INTO wb_chasse_market (item, factor, updated) VALUES (?, ?, ?)', { item, factor[item] or 1, os.time() }) end
    dirty = {}
end
CreateThread(function()
    while true do
        Wait(5 * 60000)
        local rec = (tonumber(cfg('recover', 6)) or 6) / 100
        for _, g in ipairs(HUNT_GOODS) do
            local cur = f(g.name)
            local nv = cur + (1 - cur) * rec + (math.random() - 0.5) * 0.04
            if math.abs(nv - cur) > 0.0005 then setF(g.name, nv) end
        end
        saveMarket()
    end
end)

-- Réglages et page du panel --------------------------------------------------------------------------------------------------------------------------------
local forms, marketBlocks = {}, nil
local XYZ = { { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } }
local useCall
local function setup()
    W:ExtRegister({ label = 'Chasse', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier la chasse (zones, marché, boutique)', true)
    W:ExtMigrate(RES .. '_001', 'Chasse : marché et journal', {
        [[CREATE TABLE IF NOT EXISTS wb_chasse_market (item VARCHAR(40) NOT NULL, factor DOUBLE NOT NULL DEFAULT 1, updated INT NOT NULL DEFAULT 0, PRIMARY KEY (item))]],
        [[CREATE TABLE IF NOT EXISTS wb_chasse_log (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, animal VARCHAR(24) NOT NULL DEFAULT '', item VARCHAR(40) NOT NULL DEFAULT '',
            qty INT NOT NULL DEFAULT 0, money INT NOT NULL DEFAULT 0, kind VARCHAR(6) NOT NULL DEFAULT 'kill', at INT NOT NULL, PRIMARY KEY (id), KEY k_at (at))]],
    })
    W:ExtMigrate(RES .. '_002', 'Chasse : matériel prêté par le guide', {
        [[CREATE TABLE IF NOT EXISTS wb_chasse_loans (license VARCHAR(64) NOT NULL, knife TINYINT NOT NULL DEFAULT 0, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    })
    -- rééquilibrage une seule fois : plus de gibier, mais il rapporte peu
    if W:CfgGet(NS, 'eco_v2', false) ~= true then
        W:CfgSet(NS, 'spawn_secs', 20, 'système', 'Chasse : plus de gibier') W:CfgSet(NS, 'max_alive', 6, 'système', 'Chasse : plus de gibier')
        W:CfgSet(NS, 'max_per_hour', 120, 'système', 'Chasse : plus de gibier') W:CfgSet(NS, 'price_mult', 35, 'système', 'Chasse : revenus réduits')
        W:CfgSet(NS, 'eco_v2', true, 'système', 'Chasse : rééquilibrage v1.2.42')
        cache = {}
    end
    pcall(function()
        W:EnsureWeapon({ item = HUNT_KIT.weapon, label = HUNT_KIT.weapon_label, hash = cfg('weapon', 'WEAPON_MUSKET'), ammo_item = HUNT_KIT.ammo, ammo_label = HUNT_KIT.ammo_label,
            weight = 3000, permit = false, description = "Prêté par le guide de chasse : ne blesse que le gibier. Rendu tout seul au marché du chasseur." })
    end)
    for _, g in ipairs(HUNT_GOODS) do W:EnsureItem({ name = g.name, label = g.label, weight = g.weight, stack = 50, kind = 'misc', usable = false, description = HUNT_RARITY_BY[g.rarity].label .. ' · se revend au marché du chasseur.' }) end
    for _, c in ipairs(CALLS) do W:EnsureItem({ name = c.name, label = c.label, weight = 100, stack = 10, kind = 'misc', usable = true, description = (c.vip and 'Réservé aux VIP. ' or '') .. 'À utiliser dans une zone de chasse : attire un animal.' }) end
    W:EnsureItem({ name = KNIFE.name, label = KNIFE.label, weight = 400, stack = 1, kind = 'tool', usable = false, description = 'Pour dépecer le gibier.' })
    for _, r in ipairs(MySQL.query.await('SELECT item, factor FROM wb_chasse_market') or {}) do factor[r.item] = tonumber(r.factor) or 1 end
    forms.main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = 'Chasse active', default = true },
        { k = 'spawn_secs', type = 'number', label = 'Un animal apparaît toutes les (s) dans une zone', default = 20, min = 5, max = 900 },
        { k = 'max_alive', type = 'number', label = 'Animaux en même temps par chasseur', default = 6, min = 1, max = 12 },
        { k = 'max_per_hour', type = 'number', label = 'Animaux dépecés maximum par heure', default = 120, min = 1, max = 500 },
        { k = 'price_mult', type = 'number', label = 'Prix du marché (% des prix de base)', default = 35, min = 0, max = 1000, hint = 'Bas par défaut : la chasse est un loisir, pas une source de revenus face aux entreprises.' },
        { k = 'min_factor', type = 'number', label = 'Prix plancher (% du prix de base)', default = 40, min = 5, max = 100 },
        { k = 'recover', type = 'number', label = 'Remontée des prix toutes les 5 min (%)', default = 6, min = 0, max = 100 },
        { k = 'vip_bonus', type = 'number', label = 'Bonus de revente des VIP (%)', default = 15, min = 0, max = 200 },
        { k = 'pay', type = 'select', label = 'Paiement des ventes', opts = { { 'cash', 'Espèces' }, { 'bank', 'Banque' } }, default = 'cash' },
        { k = 'blips', type = 'toggle', label = 'Zones, marchés et boutiques sur la carte', default = true },
        { k = 'weapon', type = 'select', label = 'Arme prêtée par le guide', opts = HUNT_WEAPONS, default = 'WEAPON_MUSKET', hint = 'Elle ne blesse que le gibier de la chasse, jamais un joueur.' },
        { k = 'kit_ammo', type = 'number', label = 'Cartouches prêtées (le fusil se recharge tout seul)', default = 250, min = 1, max = 5000 },
    } })
    forms.spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Points posés', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Zones de chasse, marchés et boutiques', default = {}, wide = true, maxitems = 60, unique = 'id',
          hint = 'Pose-les en jeu : menu staff (F10) › Builder › Chasse. Type : zone, market ou shop. Rayon : zones seulement.',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true },
            { k = 'label', label = 'Nom', required = true, maxlen = 40 }, XYZ[1], XYZ[2], XYZ[3], { k = 'radius', label = 'Rayon (m)', type = 'number', min = 20, max = 800 } } } } })
    W:ExtModule({
        id = RES, label = 'Chasse', icon = 'gem', perm = PERM, hint = 'Animaux, appeaux, dépeçage, marché aux prix variables',
        caps = {
            { 'Zones de chasse', 'ok', 'Posées au Builder : des animaux y apparaissent régulièrement (plus rares avec un appeau).' },
            { 'Raretés', 'ok', 'Lapin, biche, coyote, sanglier, cerf, puma (attaque), panthère noire légendaire.' },
            { 'Dépeçage', 'ok', 'Au couteau sur l\'animal abattu : viande, peaux, bois et griffes.' },
            { 'Marché vivant', 'ok', 'Chaque vente fait baisser le cours du produit, qui remonte avec le temps. Bonus VIP.' },
        },
        doc = "## Chasse\nVa voir le **guide de chasse** : « Demander à chasser » te prête un **fusil** (cartouches illimitées, il ne blesse que le gibier), des cartouches et un couteau. Va dans une **zone de chasse**. Les animaux apparaissent tout seuls ; un appeau en attire un tout de suite (et plus souvent rare). Abats-le, approche-toi et **dépèce-le avec E**. Revends au **marché du chasseur** : le marchand reprend d'abord le matériel prêté. Les prix sont volontairement bas.\n\nPoser les points : **F10 › Builder › Chasse**.",
        tabs = {
            { id = 'market', label = 'Marché', icon = 'coins', build = function() return marketBlocks() end },
            { id = 'main', label = 'Réglages', icon = 'sliders', form = forms.main },
            { id = 'spots', label = 'Points posés', icon = 'pin', form = forms.spots },
        },
    })
    for _, c in ipairs(CALLS) do local name = c.name W:RegisterUsable(name, function(src) return useCall(src, name) end) end
end
marketBlocks = function()
    local rows = {}
    for _, g in ipairs(HUNT_GOODS) do rows[#rows + 1] = { label = g.label, rarity = HUNT_RARITY_BY[g.rarity].label, base = '$' .. g.price, now = '$' .. unitPrice(g.name), trend = math.floor(f(g.name) * 100 + 0.5) .. ' %' } end
    local kills = MySQL.scalar.await("SELECT COUNT(*) FROM wb_chasse_log WHERE kind = 'kill' AND at > ?", { os.time() - 86400 }) or 0
    return { { type = 'stats', items = { { label = 'Animaux dépecés (24 h)', value = kills, icon = 'gem' } } },
        { type = 'table', id = 'm', title = 'Cours du marché du chasseur', rows = rows, columns = { { k = 'label', label = 'Produit' }, { k = 'rarity', label = 'Rareté' }, { k = 'base', label = 'Prix de base' }, { k = 'now', label = 'Prix actuel' }, { k = 'trend', label = 'Cours' } } } }
end

local function publicCfg()
    local spots = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do spots[#spots + 1] = { id = s.id, kind = s.kind, label = s.label, x = s.x, y = s.y, z = s.z, r = tonumber(s.radius) or 150 } end
    return { enabled = cfg('enabled', true) ~= false, blips = cfg('blips', true) ~= false, spawn = tonumber(cfg('spawn_secs', 20)) or 20, spots = spots, weapon = cfg('weapon', 'WEAPON_MUSKET') }
end
local function push(target) TriggerClientEvent(RES .. ':cfg', target or -1, json.encode(publicCfg())) end
AddEventHandler('pb_panel:cfgChanged', function(ns, k)
    if ns ~= NS then return end
    cache = {}
    push()
    if k == 'weapon' then pcall(function() W:EnsureWeapon({ item = HUNT_KIT.weapon, label = HUNT_KIT.weapon_label, hash = cfg('weapon', 'WEAPON_MUSKET'), ammo_item = HUNT_KIT.ammo, ammo_label = HUNT_KIT.ammo_label, weight = 3000, permit = false }) end) end
end)
RegisterNetEvent(RES .. ':hello', function() push(source) end)

-- Animaux : le serveur tire l'espèce, le client la fait apparaître -------------------------------------------------------------------------------------------
local alive, lastSpawn, hourly = {}, {}, {}     -- src -> { [token] = { animal, zone, at } }
local seq = 0
AddEventHandler('playerDropped', function() local s = source alive[s], lastSpawn[s], hourly[s] = nil, nil, nil end)
local function zoneOf(src)
    local c = pos(src)
    if not c then return nil end
    for _, s in ipairs(cfg('spots', {}) or {}) do if s.kind == 'zone' and d2(c, s) <= (tonumber(s.radius) or 150) then return s end end
end
local function roll(mult)
    local w, total = {}, 0
    for i, r in ipairs(HUNT_RARITY) do w[i] = r.weight * (mult and mult[i] or 1) total = total + w[i] end
    local x, tier = math.random() * total, 1
    for i = 1, #w do x = x - w[i] if x <= 0 then tier = i break end end
    for t = tier, 1, -1 do
        local pool = {}
        for _, a in ipairs(ANIMALS) do if HUNT_RARITY_BY[a.rarity].n == t then pool[#pool + 1] = a end end
        if #pool > 0 then return pool[math.random(#pool)] end
    end
    return ANIMALS[1]
end
local function count(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end
local function spawnFor(src, mult, why)
    local z = zoneOf(src)
    if not z then return false, 'Tu n\'es pas dans une zone de chasse.' end
    alive[src] = alive[src] or {}
    if count(alive[src]) >= (tonumber(cfg('max_alive', 6)) or 6) then return false, 'Il y a déjà assez de gibier autour de toi.' end
    local a = roll(mult)
    seq = seq + 1
    local token = ('%d_%d'):format(seq, math.random(1000, 9999))
    alive[src][token] = { animal = a.id, zone = z.id, at = os.time() }
    TriggerClientEvent(RES .. ':spawn', src, token, a.id, why == 'call')
    return true, a
end
RegisterNetEvent(RES .. ':want', function()
    local src = source
    if not cfg('enabled', true) or not W:CanAct(src) then return end
    local now = os.time()
    if lastSpawn[src] and now - lastSpawn[src] < (tonumber(cfg('spawn_secs', 20)) or 20) then return end
    lastSpawn[src] = now
    spawnFor(src, nil, 'auto')
end)
RegisterNetEvent(RES .. ':gone', function(token) local a = alive[source] if a then a[tostring(token)] = nil end end)

useCall = function(src, name)
    local c = CALL_BY[name]
    if not c or not cfg('enabled', true) then return false end
    if c.vip and not isVip(src) then return false, 'Appeau réservé aux VIP.' end
    local ok, a = spawnFor(src, c.mult, 'call')
    if not ok then return false, a end
    return true, 'Tu souffles dans l\'appeau… quelque chose approche.'
end

-- Dépeçage : couteau, jeton valide, au moins 6 s après l'apparition, toujours près de la zone
RegisterNetEvent(RES .. ':skin', function(token)
    local src = source
    local mine = alive[src]
    local t = mine and mine[tostring(token)]
    if not t then return end
    if os.time() - t.at < 6 then return end
    if not W:HasItem(src, KNIFE.name, 1) then notify(src, 'error', 'Il te faut un couteau de dépeçage (boutique du chasseur).') return end
    local z = find(cfg('spots', {}), t.zone)
    local c = pos(src)
    if not z or not c or d2(c, z) > (tonumber(z.radius) or 150) + 80 then return end
    local now = os.time()
    local h = hourly[src]
    if not h or now - h.t >= 3600 then h = { t = now, n = 0 } hourly[src] = h end
    if h.n >= (tonumber(cfg('max_per_hour', 120)) or 120) then notify(src, 'warn', 'Tu as assez chassé pour cette heure.') return end
    mine[tostring(token)] = nil
    h.n = h.n + 1
    local a = ANIMAL_BY[t.animal]
    local parts = {}
    for _, l in ipairs(a.loot) do
        local q = math.random(l[2], l[3])
        if q > 0 and W:CanCarryItem(src, l[1], q) and W:AddItem(src, l[1], q) then parts[#parts + 1] = q .. ' × ' .. label(l[1]) end
    end
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO wb_chasse_log (license, animal, kind, at) VALUES (?, ?, ?, ?)', { lic, a.id, 'kill', now }) end
    notify(src, #parts > 0 and 'success' or 'warn', ('%s (%s) : %s.'):format(a.label, HUNT_RARITY_BY[a.rarity].label, #parts > 0 and table.concat(parts, ', ') or 'ton sac est plein'))
    TriggerEvent(RES .. ':killed', src, a.id)
end)

-- Matériel prêté par le guide ------------------------------------------------------------------------------------------------------------------------------------
local function loanOf(src) local lic = W:GetLicense(src) return lic and MySQL.single.await('SELECT * FROM wb_chasse_loans WHERE license = ?', { lic }) or nil, lic end
local function unequip(src) pcall(function() W:UnequipWeapon(src, HUNT_KIT.weapon) end) TriggerClientEvent(RES .. ':holster', src, cfg('weapon', 'WEAPON_MUSKET')) end
local function giveKit(src)
    local loan, lic = loanOf(src)
    if not lic then return false, 'Joueur introuvable.' end
    if loan or (W:GetItemCount(src, HUNT_KIT.weapon) or 0) > 0 then return false, 'Tu as déjà le fusil du guide. Rends-le au marché du chasseur en vendant ton gibier.' end
    local ammo = math.max(1, math.floor(tonumber(cfg('kit_ammo', 250)) or 250))
    local knife = not W:HasItem(src, KNIFE.name, 1)
    if not W:CanCarryItem(src, HUNT_KIT.weapon, 1) then return false, 'Ton sac est plein : fais de la place pour le fusil.' end
    if not W:AddItem(src, HUNT_KIT.weapon, 1) then return false, 'Impossible de te donner le fusil.' end
    W:AddItem(src, HUNT_KIT.ammo, ammo)
    if knife then W:AddItem(src, KNIFE.name, 1) end
    MySQL.insert('REPLACE INTO wb_chasse_loans (license, knife, at) VALUES (?, ?, ?)', { lic, knife and 1 or 0, os.time() })
    return true, ('Le guide te prête un fusil, des cartouches%s. Équipe le fusil depuis ton inventaire : il ne blesse que le gibier. Tu le rendras au marché du chasseur.'):format(knife and ' et un couteau de dépeçage' or '')
end
-- Reprend tout le matériel prêté (et tout fusil / cartouches de chasse, même donnés par un autre joueur). Renvoie false si le fusil manque.
local function takeKit(src, strict)
    local loan, lic = loanOf(src)
    local hasW = (W:GetItemCount(src, HUNT_KIT.weapon) or 0) > 0
    if loan and not hasW and strict then return false end
    local nw, na = W:GetItemCount(src, HUNT_KIT.weapon) or 0, W:GetItemCount(src, HUNT_KIT.ammo) or 0
    if nw > 0 or na > 0 or loan then unequip(src) end
    if nw > 0 then W:RemoveItem(src, HUNT_KIT.weapon, nw) end
    if na > 0 then W:RemoveItem(src, HUNT_KIT.ammo, na) end
    if loan and tonumber(loan.knife) == 1 and W:HasItem(src, KNIFE.name, 1) then W:RemoveItem(src, KNIFE.name, 1) end
    if loan then MySQL.update('DELETE FROM wb_chasse_loans WHERE license = ?', { lic }) end
    return true, (nw > 0 or loan) and true or false
end
-- Le fusil prêté ne blesse que le gibier : le gibier est créé sur le jeu du chasseur seulement (hors réseau), donc tout dégât réseau
-- (joueur, PNJ partagé, véhicule) fait avec cette arme est annulé par le serveur.
local function u32(h) h = tonumber(h) or 0 if h < 0 then h = h + 4294967296 end return h end
AddEventHandler('weaponDamageEvent', function(sender, data)
    if type(data) == 'table' and u32(data.weaponType) == u32(GetHashKey(cfg('weapon', 'WEAPON_MUSKET'))) then CancelEvent() end
end)

-- Marché et boutique ------------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent(RES .. ':open', function(id)
    local src = source
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s then notify(src, 'error', "Ce point n'existe plus.") return end
    if not c or d2(c, s) > 5 then notify(src, 'warn', 'Rapproche-toi du comptoir.') return end
    local list = {}
    if s.kind == 'market' then
        -- fin de chasse : le marchand reprend d'abord le matériel prêté
        local ok, had = takeKit(src, true)
        if not ok then notify(src, 'error', "Rapporte d'abord le fusil prêté par le guide : sans lui, pas de vente.") return end
        if had then notify(src, 'info', 'Le marchand reprend le fusil et les cartouches du guide.') end
        for _, g in ipairs(HUNT_GOODS) do list[#list + 1] = { item = g.name, label = g.label, n = W:GetItemCount(src, g.name) or 0, price = unitPrice(g.name), base = g.price, rarity = g.rarity, pct = math.floor(f(g.name) * 100 + 0.5) } end
    elseif s.kind == 'shop' then
        local vip = isVip(src)
        local loan = loanOf(src)
        list[#list + 1] = { item = '__kit', label = loan and 'Rendre le matériel du guide' or 'Demander à chasser', kit = loan and 'return' or 'take' }
        list[#list + 1] = { item = KNIFE.name, label = KNIFE.label, price = ecoPrice(KNIFE.price), tool = true }
        for _, cl in ipairs(CALLS) do list[#list + 1] = { item = cl.name, label = cl.label, price = ecoPrice(cl.price), vip = cl.vip or nil, locked = (cl.vip and not vip) or nil } end
    else return end
    TriggerClientEvent(RES .. ':shop', src, s.id, s.kind, s.label, json.encode(list), isVip(src))
end)
local lastAct = {}
local function throttle(src) local t = GetGameTimer() if lastAct[src] and t - lastAct[src] < 700 then return false end lastAct[src] = t return true end
AddEventHandler('playerDropped', function() lastAct[source] = nil end)
RegisterNetEvent(RES .. ':sell', function(id, item)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local g = HUNT_GOOD_BY[tostring(item)]
    local c = pos(src)
    if not s or s.kind ~= 'market' or not g or not c or d2(c, s) > 4 then return end
    local n = math.min(W:GetItemCount(src, g.name) or 0, 100)
    if n <= 0 or not W:RemoveItem(src, g.name, n) then return end
    local total = 0
    for _ = 1, n do total = total + unitPrice(g.name) setF(g.name, f(g.name) - DROP[g.rarity]) end
    local bonus = isVip(src) and math.floor(total * (tonumber(cfg('vip_bonus', 15)) or 15) / 100) or 0
    total = total + bonus
    W:AddMoney(src, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash', total, 'Vente de gibier')
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO wb_chasse_log (license, item, qty, money, kind, at) VALUES (?, ?, ?, ?, ?, ?)', { lic, g.name, n, total, 'sell', os.time() }) end
    notify(src, 'success', ('Vendu : %d × %s pour $%d%s. Nouveau cours : $%d.'):format(n, g.label, total, bonus > 0 and (' (dont bonus VIP $' .. bonus .. ')') or '', unitPrice(g.name)))
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)
RegisterNetEvent(RES .. ':kit', function(id, what)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or s.kind ~= 'shop' or not c or d2(c, s) > 5 then return end
    if what == 'take' then
        local ok, msg = giveKit(src)
        notify(src, ok and 'success' or 'error', msg)
    else
        takeKit(src, false)
        notify(src, 'success', 'Tu as rendu le matériel au guide.')
    end
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)
RegisterNetEvent(RES .. ':buy', function(id, item, qty)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or s.kind ~= 'shop' or not c or d2(c, s) > 4 then return end
    local price, stack, vipOnly
    if item == KNIFE.name then price, stack = KNIFE.price, 1 end
    local cl = CALL_BY[tostring(item)]
    if cl then price, stack, vipOnly = cl.price, 10, cl.vip end
    if not price then return end
    price = ecoPrice(price)
    if vipOnly and not isVip(src) then notify(src, 'error', 'Réservé aux VIP.') return end
    qty = math.max(1, math.min(stack, math.floor(tonumber(qty) or 1)))
    if not W:CanCarryItem(src, item, qty) then notify(src, 'error', 'Ton sac est plein.') return end
    if not W:Pay(src, price * qty, 'cash', 'Boutique du chasseur') then notify(src, 'error', 'Pas assez d\'argent.') return end
    W:AddItem(src, item, qty)
    notify(src, 'success', ('Acheté : %d × %s pour $%d.'):format(qty, label(item), price * qty))
end)

-- Builder (F10 › Builder › Chasse) -------------------------------------------------------------------------------------------------------------------------------
local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = d2(c, s) if d < 15 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Aucun point de chasse à moins de 15 m.') return false end
        local s = table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', ('« %s » supprimé.'):format(s.label))
        return true
    end
    if what ~= 'zone' and what ~= 'market' and what ~= 'shop' then return false end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    local n = 1
    while find(spots, what .. '_' .. n) do n = n + 1 end
    local def = { zone = 'Zone de chasse', market = 'Marché du chasseur', shop = 'Guide de chasse' }
    local row = { id = what .. '_' .. n, kind = what, label = name ~= '' and name or def[what], x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100 }
    if what == 'zone' then row.radius = 150 end
    spots[#spots + 1] = row
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : ' .. row.label)
    notify(src, 'success', row.label .. ' posé ici' .. (what == 'zone' and ' (rayon 150 m, modifiable dans le panel).' or '.'))
    return true
end

local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        W:RegisterBuilder({ list = true, id = 'chasse', label = 'Chasse', icon = 'map', points = {
            { id = 'zone', label = 'Zone de chasse (rayon 150 m, au centre)', ask = 'Nom affiché (vide = « Zone de chasse »)' },
            { id = 'market', label = 'Marché du chasseur (revente, prix variables)', ask = 'Nom affiché (vide = « Marché du chasseur »)' },
            { id = 'shop', label = 'Guide de chasse (prête le fusil, vend couteau et appeaux)', ask = 'Nom affiché (vide = « Guide de chasse »)' },
            { id = 'delete', label = 'Supprimer le point de chasse le plus proche' },
        } }, function(src, what, extra)
            -- Builder › Existant : liste des points posés et suppression d'un point précis (plus seulement « le plus proche »)
            if what == '__list' then
                local out = {}
                for _, s in ipairs(cfg('spots', {}) or {}) do out[#out + 1] = { key = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
                return out
            elseif what == '__delete' then
                local spots = cfg('spots', {}) or {}
                for i, s in ipairs(spots) do
                    if tostring(s.id) == tostring(extra) then table.remove(spots, i) W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression') return true end
                end
                return false
            end
            return placeSpot(src, tostring(what), tostring(extra or ''))
        end)
    end)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
AddEventHandler('onResourceStop', function(res) if res == RES then saveMarket() end end)
