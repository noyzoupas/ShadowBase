# wb_chasse — chasse (extension Shadow Base)

- **Guide de chasse** (PNJ, posé au Builder : F10 › Builder › Chasse) : « Demander à chasser » prête un **fusil de chasse**, des cartouches et un couteau de dépeçage. Le fusil ne blesse **que le gibier** (jamais un joueur ni un véhicule) et ses cartouches ne s'épuisent pas. Le guide vend aussi le couteau et les appeaux.
- **Zones de chasse** (rayon 150 m réglable) : beaucoup de gibier (un animal toutes les 20 s, 6 en même temps par chasseur par défaut).
- **Raretés** : lapin et biche (communs), coyote et sanglier (peu communs), cerf (rare), puma (épique, il attaque), panthère noire (légendaire, elle attaque).
- **Dépeçage** : E sur l'animal abattu → viande, peaux, bois, griffes.
- **Marché du chasseur** (PNJ) : le marchand reprend d'abord le fusil, les cartouches et le couteau prêtés (sans le fusil, pas de vente), puis rachète le gibier. Les prix sont volontairement bas (35 % des prix de base) : la chasse est un loisir, les entreprises restent la vraie source de revenus. Chaque vente fait baisser le cours, qui remonte avec le temps.
- Réglages (arme prêtée, cartouches, prix, apparitions) : panel › Extensions › Chasse.
