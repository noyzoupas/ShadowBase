fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_loading'
description 'Shadow Base — écran de chargement épuré : logo, nom du serveur, vraie progression du chargement, astuces.'
author 'Shadow Base'
version '1.1.0'

loadscreen 'index.html'

files {
    'index.html',
    'logo.png',
    'Montserrat-400.woff2',
    'Montserrat-500.woff2',
    'Montserrat-600.woff2',
    'Montserrat-700.woff2',
}
