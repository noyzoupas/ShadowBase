-- Shadow Base — Petits jobs des entreprises (serveur).
-- Un employé en service ouvre le menu (O ou /jobs), choisit une mission adaptée à son entreprise et l'enchaîne étape par étape.
-- Le client propose chaque destination (point de route) ; le serveur vérifie la distance, la position à l'arrivée, le temps écoulé,
-- le service, puis paie. Réglages : panel › Extensions › Petits jobs.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'

local cache = {}
local function cfg(k, d)
    local v = cache[k]
    if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end
    if v == nil then return d end
    return v
end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Petits jobs', text) end
-- Onglet Économie du panel (v1.2.42) : prix × multiplicateur × TVA, gains × salaires (× illégal / × activités)
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function ecoIn(n, kind) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoIncome(n, kind) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function split(s) local out = {} for w in tostring(s or ''):gmatch('[%w_]+') do if JOB_TYPES[w] then out[#out + 1] = w end end return out end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function d2(a, b) local dx, dy = a.x - b.x, a.y - b.y return math.sqrt(dx * dx + dy * dy) end

-- Entreprise : catégorie, modèle du catalogue, points posés ---------------------------------------------------------------------------------------------
local bizInfo = {}
local function bizOf(id)
    local b = bizInfo[id]
    if b and os.time() - b.t < 60 then return b end
    local r = MySQL.single.await('SELECT * FROM pb_biz WHERE id = ?', { id })   -- * : la colonne « activity » n'existe pas sur les très vieilles bases
    if not r then return nil end
    local pts = {}
    for _, p in ipairs(MySQL.query.await("SELECT x, y, z FROM pb_points WHERE owner_kind = 'biz' AND owner = ?", { id }) or {}) do pts[#pts + 1] = { x = tonumber(p.x), y = tonumber(p.y), z = tonumber(p.z) } end
    if tonumber(r.hx) and (tonumber(r.hx) ~= 0 or tonumber(r.hy) ~= 0) then pts[#pts + 1] = { x = tonumber(r.hx), y = tonumber(r.hy), z = tonumber(r.hz) or 0 } end
    b = { id = r.id, label = r.label, kind = r.kind, cat = r.category or 'services', activity = r.activity or '', pts = pts, t = os.time() }
    bizInfo[id] = b
    return b
end
local function typesFor(b)
    for _, o in ipairs(cfg('overrides', {}) or {}) do if o.biz == b.id then return split(o.types) end end
    local s = JOB_BY_BIZ[b.id] or JOB_BY_BIZ[b.activity or '']   -- entreprise sur mesure : missions de son type (ex. un garage renommé = dépannage)
    if not s then
        if b.kind == 'police' then s = 'patrouille' elseif b.kind == 'ems' then s = 'secours' elseif b.kind == 'garage' then s = 'depannage'
        else s = JOB_BY_CAT[b.cat] or 'service' end
    end
    local out = {}
    for _, t in ipairs(split(s)) do if cfg('type_' .. t, true) ~= false then out[#out + 1] = t end end
    return out
end
local function tasksFor(b)
    if b.cat == 'resto' then return JOB_TASKS.resto elseif b.cat == 'auto' then return JOB_TASKS.auto end
    return JOB_TASKS.default
end

-- Réglages et page du panel ----------------------------------------------------------------------------------------------------------------------------
local forms, statsBlocks, catalogBlocks = {}, nil, nil
local function setup()
    W:ExtRegister({ label = 'Petits jobs', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier les petits jobs des entreprises', true)
    W:ExtMigrate(RES .. '_001_log', 'Petits jobs : journal', {
        [[CREATE TABLE IF NOT EXISTS wb_jobs_log (
            id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, biz VARCHAR(32) NOT NULL, type VARCHAR(16) NOT NULL, steps INT NOT NULL DEFAULT 0,
            money INT NOT NULL DEFAULT 0, done TINYINT(1) NOT NULL DEFAULT 0, at INT NOT NULL, PRIMARY KEY (id), KEY k_at (at), KEY k_biz (biz))]],
    })
    local fields = {
        { k = 'enabled', type = 'toggle', label = 'Petits jobs actifs', default = true },
        { k = 'pay_mult', type = 'number', label = 'Paie (% des montants de base)', default = 100, min = 0, max = 1000, hint = 'Par étape : livraison ~120 $, course ~120 $ + 70 $/km, dépannage ~200 $…' },
        { k = 'biz_share', type = 'number', label = 'Bonus versé à l\'entreprise (% de la paie)', default = 25, min = 0, max = 300, hint = "En plus de la paie de l'employé : alimente le compte de l'entreprise." },
        { k = 'pay', type = 'select', label = 'Paie de l\'employé', opts = { { 'bank', 'Banque' }, { 'cash', 'Espèces' } }, default = 'bank' },
        { k = 'max_per_hour', type = 'number', label = 'Missions maximum par joueur et par heure', default = 6, min = 1, max = 60 },
        { k = 'cooldown', type = 'number', label = 'Pause entre deux missions (s)', default = 30, min = 0, max = 3600 },
        { k = 'near_biz', type = 'number', label = 'Distance maximale de l\'entreprise pour commencer (m, 0 = partout)', default = 150, min = 0, max = 5000, hint = "Mesurée depuis les points de l'entreprise (siège, service, bureau…). Sans point posé : partout." },
        { k = 'vehicle', type = 'toggle', label = 'Fournir un véhicule de service', default = true, hint = 'Rendu automatiquement à la fin. Désactivé : l\'employé utilise le sien.' },
    }
    for _, id in ipairs(JOB_ORDER) do fields[#fields + 1] = { k = 'type_' .. id, type = 'toggle', label = 'Mission : ' .. JOB_TYPES[id].label, default = true } end
    forms.main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = fields })
    local names = {}
    for _, id in ipairs(JOB_ORDER) do names[#names + 1] = id end
    forms.overrides = W:ExtSettings({ ns = NS, id = 'overrides', title = 'Missions par entreprise', perm = PERM, fields = {
        { k = 'overrides', type = 'rows', label = 'Remplacer les missions d\'une entreprise', default = {}, wide = true, maxitems = 200, unique = 'biz',
          hint = 'Identifiant de l\'entreprise et missions séparées par des virgules, parmi : ' .. table.concat(names, ', ') .. '. Sans ligne : missions par défaut (onglet Catalogue).',
          cols = { { k = 'biz', label = 'Entreprise (identifiant)', pattern = '^[%w_]+$', required = true, maxlen = 32, lower = true }, { k = 'types', label = 'Missions', pattern = '^[%w_, ]*$', maxlen = 160, lower = true } } } } })
    W:ExtModule({
        id = RES, label = 'Petits jobs', icon = 'briefcase', perm = PERM, hint = 'Missions des entreprises : livraisons, taxi, dépannage, patrouille, secours…',
        caps = {
            { 'Missions adaptées à chaque entreprise', 'ok', 'Livraisons, repas, courses de taxi, dépannages, patrouilles, secours, chantiers, poubelles, reportages, transport, convoyage, service sur place.' },
            { 'Véhicule de service', 'ok', 'Fourni au début, rendu à la fin (désactivable).' },
            { 'Anti-triche', 'ok', 'Destinations, positions, temps et service revérifiés par le serveur, plafond horaire.' },
        },
        doc = "## Petits jobs\nUn employé **en service** appuie sur **O** (ou tape /jobs) près de son entreprise et choisit une mission. Chaque étape est indiquée par un point GPS. La paie tombe à chaque étape ; l'entreprise touche un bonus.\n\nLes missions proposées dépendent du métier (onglet **Catalogue**) et se remplacent dans **Missions par entreprise**.",
        tabs = {
            { id = 'stats', label = 'Activité', icon = 'chart', build = function() return statsBlocks() end },
            { id = 'catalog', label = 'Catalogue', icon = 'list', build = function() return catalogBlocks() end },
            { id = 'main', label = 'Réglages', icon = 'sliders', form = forms.main },
            { id = 'overrides', label = 'Missions par entreprise', icon = 'briefcase', form = forms.overrides },
        },
    })
end

statsBlocks = function()
    local since = os.time() - 86400
    local rows = MySQL.query.await('SELECT biz, type, COUNT(*) AS n, SUM(done) AS done, SUM(money) AS money, COUNT(DISTINCT license) AS players FROM wb_jobs_log WHERE at > ? GROUP BY biz, type ORDER BY money DESC LIMIT 100', { since }) or {}
    local total, out = 0, {}
    for _, r in ipairs(rows) do
        total = total + (tonumber(r.money) or 0)
        out[#out + 1] = { biz = r.biz, type = (JOB_TYPES[r.type] or {}).label or r.type, n = tonumber(r.n) or 0, done = tonumber(r.done) or 0, money = '$' .. (tonumber(r.money) or 0), players = tonumber(r.players) or 0 }
    end
    return {
        { type = 'stats', items = { { label = 'Paie versée (24 h)', value = '$' .. total, icon = 'coins' }, { label = 'Missions (24 h)', value = #rows > 0 and (function() local n = 0 for _, r in ipairs(out) do n = n + r.n end return n end)() or 0, icon = 'briefcase' } } },
        { type = 'table', id = 'jobs', title = 'Missions des dernières 24 h', search = true, rows = out, empty = 'Aucune mission pour le moment.',
          columns = { { k = 'biz', label = 'Entreprise' }, { k = 'type', label = 'Mission' }, { k = 'n', label = 'Lancées' }, { k = 'done', label = 'Terminées' }, { k = 'money', label = 'Paie' }, { k = 'players', label = 'Employés' } } },
    }
end
catalogBlocks = function()
    local rows = {}
    for _, r in ipairs(MySQL.query.await('SELECT id, label, kind, category FROM pb_biz ORDER BY label') or {}) do
        local b = { id = r.id, label = r.label, kind = r.kind, cat = r.category or 'services' }
        local names = {}
        for _, t in ipairs(typesFor(b)) do names[#names + 1] = JOB_TYPES[t].label end
        rows[#rows + 1] = { id = r.id, label = r.label, jobs = #names > 0 and table.concat(names, ', ') or '—' }
    end
    local types = {}
    for _, id in ipairs(JOB_ORDER) do local t = JOB_TYPES[id] types[#types + 1] = { id = id, label = t.label, desc = t.desc, veh = t.veh or 'à pied' } end
    return {
        { type = 'table', id = 'biz', title = 'Missions de chaque entreprise', search = true, rows = rows, empty = 'Aucune entreprise.', columns = { { k = 'label', label = 'Entreprise' }, { k = 'id', label = 'Identifiant' }, { k = 'jobs', label = 'Missions' } } },
        { type = 'table', id = 'types', title = 'Types de missions', rows = types, columns = { { k = 'id', label = 'Identifiant' }, { k = 'label', label = 'Mission' }, { k = 'desc', label = 'Déroulement' }, { k = 'veh', label = 'Véhicule' } } },
    }
end

-- Missions -------------------------------------------------------------------------------------------------------------------------------------------------
local M, hourly, lastEnd = {}, {}, {}
local function log(src, m, done)
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO wb_jobs_log (license, biz, type, steps, money, done, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { lic, m.biz, m.type, m.i - 1, m.earned, done and 1 or 0, os.time() }) end
end
local function stop(src, reason, done)
    local m = M[src]
    if not m then return end
    M[src] = nil
    lastEnd[src] = os.time()
    log(src, m, done)
    TriggerClientEvent(RES .. ':ended', src, done and true or false, reason or '')
end
AddEventHandler('playerDropped', function() local src = source if M[src] then stop(src, 'départ', false) end hourly[src], lastEnd[src] = nil, nil end)

local function job(src) local ok, j = pcall(function() return W:GetJob(src) end) return ok and j or nil end

RegisterNetEvent(RES .. ':menu', function()
    local src = source
    if not cfg('enabled', true) then notify(src, 'error', 'Les petits jobs sont désactivés.') return end
    local j = job(src)
    if not j then notify(src, 'error', 'Tu n\'as pas d\'emploi : les petits jobs sont réservés aux employés.') return end
    local b = bizOf(j.biz)
    if not b then return end
    local list = {}
    for _, t in ipairs(typesFor(b)) do local d = JOB_TYPES[t] list[#list + 1] = { id = t, label = d.label, desc = d.desc, icon = d.icon, veh = d.veh ~= nil } end
    local m = M[src]
    TriggerClientEvent(RES .. ':menu', src, json.encode({ biz = b.label, duty = j.onDuty == true, list = list, active = m and { label = JOB_TYPES[m.type].label, i = m.i, n = #m.phases, earned = m.earned } or nil }))
end)

RegisterNetEvent(RES .. ':start', function(typeId)
    local src = source
    if not cfg('enabled', true) or M[src] then return end
    if not W:CanAct(src) then return end
    local j = job(src)
    if not j or not j.onDuty then notify(src, 'error', 'Prends ton service avant de lancer une mission.') return end
    local b = bizOf(j.biz)
    if not b then return end
    local ok = false
    for _, t in ipairs(typesFor(b)) do if t == typeId then ok = true end end
    if not ok then return end
    local now = os.time()
    local cd = tonumber(cfg('cooldown', 30)) or 30
    if lastEnd[src] and now - lastEnd[src] < cd then notify(src, 'warn', ('Souffle un peu : prochaine mission dans %d s.'):format(cd - (now - lastEnd[src]))) return end
    local h = hourly[src]
    if not h or now - h.t >= 3600 then h = { t = now, n = 0 } hourly[src] = h end
    if h.n >= (tonumber(cfg('max_per_hour', 6)) or 6) then notify(src, 'warn', 'Tu as fait assez de missions pour cette heure.') return end
    local c = pos(src)
    if not c then return end
    local near = tonumber(cfg('near_biz', 150)) or 150
    if near > 0 and #b.pts > 0 then
        local best
        for _, p in ipairs(b.pts) do local d = d2(c, p) if not best or d < best then best = d end end
        if best > near then notify(src, 'error', ('Les missions se prennent à l\'entreprise (à moins de %d m).'):format(near)) return end
    end
    local T = JOB_TYPES[typeId]
    local phases = {}
    for _, p in ipairs(T.head or {}) do phases[#phases + 1] = p end
    for _ = 1, math.random(T.units[1], T.units[2]) do for _, p in ipairs(T.unit) do phases[#phases + 1] = p end end
    -- détails envoyés au client (gestes propres au métier, tâches sur place)
    local tasks, out = tasksFor(b), {}
    for i, name in ipairs(phases) do
        local P = JOB_PHASES[name]
        local o = { name = name, kind = P.kind, label = P.label, goal = P.goal or P.label, secs = P.secs, anim = P.anim, prop = P.prop, npc = P.npc, range = P.range, leaveveh = P.leaveveh }
        if name == 'worksite' and JOB_WORK_ANIM[b.id] then o.anim = JOB_WORK_ANIM[b.id] end
        if name == 'task' then local t = tasks[math.random(#tasks)] o.label, o.goal, o.anim = t[1], t[1], t[2] end
        out[i] = o
    end
    local veh
    if T.veh == '@client' then veh = JOB_CLIENT_CARS[math.random(#JOB_CLIENT_CARS)]          -- convoyage : la voiture du client, toujours fournie
    elseif T.veh and cfg('vehicle', true) ~= false then veh = JOB_VEH_BY_BIZ[b.id] or T.veh end
    h.n = h.n + 1
    M[src] = { type = typeId, biz = b.id, b = b, phases = phases, info = out, i = 1, start = { x = c.x, y = c.y, z = c.z }, last = { x = c.x, y = c.y, z = c.z }, earned = 0 }
    TriggerClientEvent(RES .. ':begin', src, json.encode({ type = typeId, label = T.label, veh = veh, phases = out }))
end)

RegisterNetEvent(RES .. ':stop', function() local src = source if M[src] then stop(src, 'abandon', false) end end)

-- Destination proposée par le client (point de route) : vérifiée puis confirmée
RegisterNetEvent(RES .. ':target', function(i, x, y, z)
    local src = source
    local m = M[src]
    if not m or i ~= m.i or m.target then return end
    x, y, z = tonumber(x), tonumber(y), tonumber(z)
    if not x or not y or not z then return end
    if x < -4200 or x > 4500 or y < -4200 or y > 8200 then TriggerClientEvent(RES .. ':retarget', src, m.i) return end
    local P = JOB_PHASES[m.phases[m.i]]
    local t = { x = x, y = y, z = z }
    if P.kind == 'here' then
        local c = pos(src)
        if not c or d2(c, m.start) > 80 then notify(src, 'error', 'Reviens à l\'entreprise pour cette étape.') stop(src, 'trop loin', false) return end
        t = { x = c.x, y = c.y, z = c.z }
    elseif P.kind == 'service' then
        local cand = {}
        for _, p in ipairs(m.b.pts) do if d2(p, m.start) < 80 and d2(p, m.last) > 1.5 then cand[#cand + 1] = p end end
        if #cand > 0 then t = cand[math.random(#cand)]
        elseif d2(t, m.start) > 25 then t = { x = m.start.x, y = m.start.y, z = m.start.z } end   -- pas de point posé : autour du départ (client)
    else
        local d = d2(t, m.last)
        if d < P.range[1] * 0.5 or d > P.range[2] * 1.6 then TriggerClientEvent(RES .. ':retarget', src, m.i) return end
    end
    m.target, m.tAt = t, os.time()
    TriggerClientEvent(RES .. ':goto', src, m.i, t.x, t.y, t.z)
end)

RegisterNetEvent(RES .. ':step', function(i)
    local src = source
    local m = M[src]
    if not m or i ~= m.i or not m.target then return end
    local P = JOB_PHASES[m.phases[m.i]]
    local j = job(src)
    if not j or j.biz ~= m.biz or not j.onDuty then notify(src, 'error', 'Tu n\'es plus en service : mission arrêtée.') stop(src, 'hors service', false) return end
    local c = pos(src)
    if not c then return end
    local reach = (P.kind == 'stop' and 35) or (P.kind == 'drive' and 30) or 15
    if d2(c, m.target) > reach then TriggerClientEvent(RES .. ':retry', src, m.i, 'Rapproche-toi du point.') return end
    local leg = d2(m.target, m.last)
    local minT = (P.kind == 'drive' or P.kind == 'stop') and math.floor(leg / 60) or 0
    if os.time() - m.tAt < minT + math.max(0, (P.secs or 0) - 2) then TriggerClientEvent(RES .. ':retry', src, m.i, '') return end    -- trop rapide : client modifié
    local pay = ecoIn(((P.pay or 0) + (P.perkm or 0) * leg / 1000) * (tonumber(cfg('pay_mult', 100)) or 100) / 100, 'job')
    if pay > 0 then
        W:AddMoney(src, cfg('pay', 'bank') == 'cash' and 'cash' or 'bank', pay, 'Petit job : ' .. JOB_TYPES[m.type].label)
        local share = math.floor(pay * (tonumber(cfg('biz_share', 25)) or 25) / 100)
        if share > 0 then pcall(function() W:AddBusinessMoney(m.biz, share, 'Petits jobs : ' .. JOB_TYPES[m.type].label) end) end
        m.earned = m.earned + pay
    end
    m.last, m.target = m.target, nil
    m.i = m.i + 1
    if m.i > #m.phases then
        notify(src, 'success', ('Mission terminée : $%d gagnés.'):format(m.earned))
        TriggerEvent(RES .. ':done', src, m.biz, m.type, m.earned)
        stop(src, 'terminée', true)
        return
    end
    TriggerClientEvent(RES .. ':advance', src, m.i, pay)
end)

AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == NS then cache = {} end end)

-- Prise de service : rappel de la touche ; fin de service : la mission s'arrête
AddEventHandler('pb_panel:duty', function(src, bizId, on)
    src = tonumber(src)
    if not src or not cfg('enabled', true) then return end
    if not on then if M[src] then stop(src, 'fin de service', false) end return end
    local b = bizOf(tostring(bizId))
    if b and #typesFor(b) > 0 then notify(src, 'info', 'Petits jobs disponibles : appuie sur O (ou /jobs).') end
end)

-- Démarrage : attendre pb_panel ---------------------------------------------------------------------------------------------------------------------------
local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) end
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
AddEventHandler('onResourceStop', function(res) if res == RES then for src in pairs(M) do TriggerClientEvent(RES .. ':ended', src, false, 'redémarrage') end end end)
