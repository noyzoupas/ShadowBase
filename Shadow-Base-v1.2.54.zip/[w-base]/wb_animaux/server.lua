-- Shadow Base — Animaux de compagnie (VIP). Achat à l'animalerie (posée au Builder), un animal par personnage, nom au choix.
-- Commande /animal : l'appeler, le renvoyer, assis / couché, suivre / rester, le renommer.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'

PETS = {
    { model = 'a_c_husky',      label = 'Husky',             price = 15000, kind = 'big' },
    { model = 'a_c_retriever',  label = 'Golden retriever',  price = 12000, kind = 'big' },
    { model = 'a_c_shepherd',   label = 'Berger allemand',   price = 14000, kind = 'big' },
    { model = 'a_c_rottweiler', label = 'Rottweiler',        price = 14000, kind = 'big' },
    { model = 'a_c_pug',        label = 'Carlin',            price = 8000,  kind = 'small' },
    { model = 'a_c_poodle',     label = 'Caniche',           price = 8000,  kind = 'small' },
    { model = 'a_c_westy',      label = 'Westie',            price = 9000,  kind = 'small' },
    { model = 'a_c_cat_01',     label = 'Chat',              price = 6000,  kind = 'cat' },
}
local PET_BY = {}
for _, p in ipairs(PETS) do PET_BY[p.model] = p end

local cache = {}
local function cfg(k, d) local v = cache[k] if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end if v == nil then return d end return v end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Animaux', text) end
-- Onglet Économie du panel (v1.2.42) : prix × multiplicateur × TVA, gains × salaires (× illégal / × activités)
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function ecoIn(n, kind) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoIncome(n, kind) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function isVip(src) local ok, v = pcall(function() return W:IsVip(src) end) return ok and v == true end
local function charLicense(src) local ok, id = pcall(function() return W:GetCharId(src) end) return (ok and id) or W:GetLicense(src) end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end

local function petOf(src)
    local lic = charLicense(src)
    return lic and MySQL.single.await('SELECT * FROM wb_animaux WHERE license = ?', { lic }) or nil
end

local function setup()
    W:ExtRegister({ label = 'Animaux de compagnie', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier les animaux de compagnie (animaleries, prix)', true)
    W:ExtMigrate(RES .. '_001', 'Animaux de compagnie', {
        [[CREATE TABLE IF NOT EXISTS wb_animaux (license VARCHAR(64) NOT NULL, model VARCHAR(32) NOT NULL, name VARCHAR(24) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    })
    local fields = {
        { k = 'enabled', type = 'toggle', label = 'Animaux de compagnie actifs', default = true },
        { k = 'vip_only', type = 'toggle', label = 'Réservés aux VIP', default = true },
        { k = 'blips', type = 'toggle', label = 'Animaleries sur la carte', default = true },
    }
    for _, p in ipairs(PETS) do fields[#fields + 1] = { k = 'price_' .. p.model, type = 'number', label = 'Prix : ' .. p.label .. ' ($)', default = p.price, min = 0, max = 10000000 } end
    local main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = fields })
    local spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Animaleries', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Animaleries', default = {}, wide = true, maxitems = 20, unique = 'id', hint = 'Pose-les en jeu : F10 › Builder › Animaux.',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
            { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } } } } })
    W:ExtModule({
        id = RES, label = 'Animaux de compagnie', icon = 'star', perm = PERM, hint = 'Chiens et chats des joueurs (VIP)',
        doc = "## Animaux de compagnie\nUn **VIP** achète un animal à l'**animalerie** (posée au Builder : F10 › Builder › Animaux). Ensuite, **/animal** : l'appeler, le renvoyer, assis, couché, suivre ou rester, le renommer. Un animal par personnage.",
        tabs = { { id = 'main', label = 'Réglages', icon = 'sliders', form = main }, { id = 'spots', label = 'Animaleries', icon = 'pin', form = spots } },
    })
end

local function publicCfg()
    local list = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do list[#list + 1] = { id = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
    return { enabled = cfg('enabled', true) ~= false, blips = cfg('blips', true) ~= false, spots = list }
end
local function push(t) TriggerClientEvent(RES .. ':cfg', t or -1, json.encode(publicCfg())) end
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == NS then cache = {} push() end end)
RegisterNetEvent(RES .. ':hello', function()
    local src = source
    push(src)
    local p = petOf(src)
    TriggerClientEvent(RES .. ':mine', src, p and json.encode({ model = p.model, name = p.name, kind = (PET_BY[p.model] or {}).kind }) or nil)
end)

local function allowed(src)
    if cfg('enabled', true) == false then return false, 'Les animaux de compagnie sont désactivés.' end
    if cfg('vip_only', true) ~= false and not isVip(src) then return false, 'Les animaux de compagnie sont réservés aux VIP.' end
    return true
end

-- /animal : le client ouvre son menu ; le serveur valide ce qui touche à l'argent et à la base
RegisterNetEvent(RES .. ':menu', function()
    local src = source
    local ok, why = allowed(src)
    if not ok then notify(src, 'error', why) return end
    local p = petOf(src)
    if not p then notify(src, 'info', "Tu n'as pas encore d'animal : passe à l'animalerie.") return end
    TriggerClientEvent(RES .. ':open', src, json.encode({ model = p.model, name = p.name, kind = (PET_BY[p.model] or {}).kind }))
end)

RegisterNetEvent(RES .. ':shop', function(id)
    local src = source
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or not c or #(c - vector3(s.x, s.y, s.z)) > 4.0 then return end
    local ok, why = allowed(src)
    if not ok then notify(src, 'error', why) return end
    local list = {}
    for _, p in ipairs(PETS) do list[#list + 1] = { model = p.model, label = p.label, price = ecoPrice(tonumber(cfg('price_' .. p.model, p.price)) or p.price) } end
    local mine = petOf(src)
    TriggerClientEvent(RES .. ':shopmenu', src, s.id, s.label, json.encode(list), mine and mine.name or nil)
end)

local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
RegisterNetEvent(RES .. ':buy', function(id, model, name)
    local src = source
    local t = GetGameTimer()
    if last[src] and t - last[src] < 1500 then return end
    last[src] = t
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    local p = PET_BY[tostring(model)]
    if not s or not p or not c or #(c - vector3(s.x, s.y, s.z)) > 4.0 then return end
    local ok, why = allowed(src)
    if not ok then notify(src, 'error', why) return end
    name = tostring(name or ''):gsub('[%c<>"\\]', ''):sub(1, 24)
    if #name < 2 then name = p.label end
    local price = ecoPrice(tonumber(cfg('price_' .. p.model, p.price)) or p.price)
    if price > 0 and not W:Pay(src, price, 'bank', 'Animalerie') then notify(src, 'error', "Pas assez d'argent.") return end
    local lic = charLicense(src)
    MySQL.insert.await('REPLACE INTO wb_animaux (license, model, name, at) VALUES (?, ?, ?, ?)', { lic, p.model, name, os.time() })
    notify(src, 'success', ('Bienvenue à %s (%s) ! Utilise /animal pour l\'appeler.'):format(name, p.label))
    TriggerClientEvent(RES .. ':mine', src, json.encode({ model = p.model, name = name, kind = p.kind }))
end)
RegisterNetEvent(RES .. ':rename', function(name)
    local src = source
    local p = petOf(src)
    if not p then return end
    name = tostring(name or ''):gsub('[%c<>"\\]', ''):sub(1, 24)
    if #name < 2 then return end
    MySQL.update.await('UPDATE wb_animaux SET name = ? WHERE license = ?', { name, charLicense(src) })
    notify(src, 'success', 'Il s\'appelle maintenant ' .. name .. '.')
    TriggerClientEvent(RES .. ':mine', src, json.encode({ model = p.model, name = name, kind = (PET_BY[p.model] or {}).kind }))
end)
-- fin du VIP : l'animal rentre (il revient si le VIP est redonné)
AddEventHandler('pb_panel:vipChanged', function(src, on) if not on and cfg('vip_only', true) ~= false then TriggerClientEvent(RES .. ':dismiss', src) end end)

local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = #(vector2(c.x, c.y) - vector2(s.x, s.y)) if d < 10 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Aucune animalerie à moins de 10 m.') return false end
        table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', 'Animalerie supprimée.')
        return true
    end
    if what ~= 'shop' then return false end
    local n = 1
    while find(spots, 'animalerie_' .. n) do n = n + 1 end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    spots[#spots + 1] = { id = 'animalerie_' .. n, label = name ~= '' and name or 'Animalerie', x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100 }
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : animalerie')
    notify(src, 'success', 'Animalerie posée ici.')
    return true
end

local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        W:RegisterBuilder({ list = true, id = 'animaux', label = 'Animaux', icon = 'star', points = {
            { id = 'shop', label = 'Animalerie (chiens et chats, VIP)', ask = 'Nom affiché (vide = « Animalerie »)' },
            { id = 'delete', label = "Supprimer l'animalerie la plus proche" },
        } }, function(src, what, extra)
            -- Builder › Existant : liste des points posés et suppression d'un point précis (plus seulement « le plus proche »)
            if what == '__list' then
                local out = {}
                for _, s in ipairs(cfg('spots', {}) or {}) do out[#out + 1] = { key = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
                return out
            elseif what == '__delete' then
                local spots = cfg('spots', {}) or {}
                for i, s in ipairs(spots) do
                    if tostring(s.id) == tostring(extra) then table.remove(spots, i) W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression') return true end
                end
                return false
            end
            return placeSpot(src, tostring(what), tostring(extra or ''))
        end)
    end)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
