-- Shadow Base — Zones safe (client) : dans une zone, pas de tirs, pas de coups, invincible (chaque règle est réglable).
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, zones = {} }
local blips, inside, duty = {}, nil, false

local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, z in ipairs(C.zones or {}) do
        local b = AddBlipForRadius(z.x + 0.0, z.y + 0.0, z.z + 0.0, (tonumber(z.r) or 50) + 0.0)
        SetBlipColour(b, 2) SetBlipAlpha(b, 90)
        blips[#blips + 1] = b
    end
end)
RegisterNetEvent(RES .. ':dutyIs', function(on) duty = on == true end)
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
    while true do Wait(15000) if C.bypass then TriggerServerEvent(RES .. ':duty') end end
end)

local function zoneAt(c)
    for _, z in ipairs(C.zones or {}) do
        if #(vector3(c.x, c.y, c.z) - vector3(z.x + 0.0, z.y + 0.0, z.z + 0.0)) <= (tonumber(z.r) or 50) + 0.0 then return z end
    end
end

CreateThread(function()
    local wasGod = false
    while true do
        local ped = PlayerPedId()
        local z = (C.enabled and not (C.bypass and duty)) and zoneAt(GetEntityCoords(ped)) or nil
        if z ~= inside and (z and z.id) ~= (inside and inside.id) then
            local okSZ = pcall(function() exports.pb_panel:SafeZone(z ~= nil) end)   -- bandeau « Zone sécurisée » (vert, bouclier)
            if C.msg and not okSZ then W:Notify({ type = z and 'info' or 'success', title = 'Zone safe', text = z and ('Tu entres dans « ' .. z.label .. ' » : pas de violence ici.') or 'Tu quittes la zone safe.' }) end
            if z and C.unarm then SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true) end
            if not z and wasGod then SetEntityInvincible(ped, false) SetPlayerInvincible(PlayerId(), false) wasGod = false end
            inside = z
        end
        if z then
            if C.god then SetEntityInvincible(ped, true) SetPlayerInvincible(PlayerId(), true) wasGod = true end
            Wait(0)
            if C.nofire then
                DisablePlayerFiring(PlayerId(), true)
                DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 47, true) DisableControlAction(0, 58, true)
                DisableControlAction(0, 69, true) DisableControlAction(0, 70, true) DisableControlAction(0, 92, true) DisableControlAction(0, 257, true)
            end
            if C.nomelee then
                DisableControlAction(0, 140, true) DisableControlAction(0, 141, true) DisableControlAction(0, 142, true) DisableControlAction(0, 143, true) DisableControlAction(0, 263, true) DisableControlAction(0, 264, true)
            end
        else
            if wasGod then SetEntityInvincible(ped, false) SetPlayerInvincible(PlayerId(), false) wasGod = false end
            Wait(C.enabled and #(C.zones or {}) > 0 and 500 or 2000)
        end
    end
end)
