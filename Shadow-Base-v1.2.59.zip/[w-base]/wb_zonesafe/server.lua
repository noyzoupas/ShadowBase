-- Shadow Base — Zones safe (serveur). Les zones sont posées en jeu : F10 › Builder › Zones safe (petite, moyenne, grande, ou rayon libre).
-- Le serveur garde la liste et la pousse aux joueurs ; la protection (pas de tirs, pas de coups, invincibilité) est appliquée côté client.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'
local SIZES = { small = { 25, 'Petite' }, medium = { 50, 'Moyenne' }, large = { 100, 'Grande' }, custom = { nil, 'Rayon libre' } }

local cache = {}
local function cfg(k, d) local v = W:CfgGet(NS, k, d) if v == nil then return d end return v end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Zones safe', text) end

local function publicCfg()
    return { enabled = cfg('enabled', true) ~= false, god = cfg('invincible', true) ~= false, nofire = cfg('no_fire', true) ~= false,
        nomelee = cfg('no_melee', true) ~= false, unarm = cfg('unarm', false) == true, blips = cfg('blips', true) ~= false, msg = cfg('messages', true) ~= false,
        bypass = cfg('staff_bypass', false) == true, zones = cfg('zones', {}) or {} }
end
local function push(target)
    local j = json.encode(publicCfg())
    if target then TriggerClientEvent(RES .. ':cfg', target, j) else TriggerClientEvent(RES .. ':cfg', -1, j) end
end
RegisterNetEvent(RES .. ':hello', function() push(source) end)
-- un joueur qui n'a plus le droit d'être « hors de portée » (staff retiré) : le serveur dit s'il est vraiment en service
RegisterNetEvent(RES .. ':duty', function()
    local src = source
    local ok, on = pcall(function() return W:IsStaffOnDuty(src) end)
    TriggerClientEvent(RES .. ':dutyIs', src, ok and on == true)
end)

local function place(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local zones = cfg('zones', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, z in ipairs(zones) do local d = #(vector2(c.x, c.y) - vector2(z.x + 0.0, z.y + 0.0)) if d <= (tonumber(z.r) or 50) + 5 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Tu n\'es dans aucune zone safe.') return false end
        local z = table.remove(zones, bi)
        W:CfgSet(NS, 'zones', zones, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', ('« %s » supprimée.'):format(z.label)) push()
        return true
    end
    local sz = SIZES[what]
    if not sz then return false end
    local r = sz[1] or tonumber(tostring(extra or ''):match('%d+'))
    if not r then notify(src, 'error', 'Rayon invalide (en mètres).') return false end
    r = math.max(5, math.min(500, math.floor(r)))
    local n = 0
    for _, z in ipairs(zones) do local k = tonumber(tostring(z.id):match('^zone_(%d+)$')) if k and k > n then n = k end end
    if #zones >= 60 then notify(src, 'error', 'Maximum 60 zones.') return false end
    local label = (sz[1] and tostring(extra or '') ~= '') and tostring(extra) or ('Zone safe ' .. (n + 1))
    label = label:gsub('[%c<>"\\]', ''):sub(1, 40)
    zones[#zones + 1] = { id = 'zone_' .. (n + 1), label = label, x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, r = r }
    W:CfgSet(NS, 'zones', zones, GetPlayerName(src), 'Builder : ajout')
    notify(src, 'success', ('« %s » posée (%d m).'):format(label, r))
    push()
    return true
end

local function setup()
    W:ExtRegister({ label = 'Zones safe', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier : zones safe', true)
    local main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = 'Zones safe actives', default = true },
        { k = 'invincible', type = 'toggle', label = 'Invincible dans la zone', default = true },
        { k = 'no_fire', type = 'toggle', label = 'Tirs interdits', default = true },
        { k = 'no_melee', type = 'toggle', label = 'Coups interdits (poings, armes blanches)', default = true },
        { k = 'unarm', type = 'toggle', label = 'Ranger l\'arme en entrant', default = false },
        { k = 'staff_bypass', type = 'toggle', label = 'Le staff en service n\'est pas limité', default = false },
        { k = 'blips', type = 'toggle', label = 'Zones visibles sur la carte', default = true },
        { k = 'messages', type = 'toggle', label = 'Message à l\'entrée et à la sortie', default = true },
    } })
    local zones = W:ExtSettings({ ns = NS, id = 'zones', title = 'Zones posées', perm = PERM, fields = {
        { k = 'zones', type = 'rows', label = 'Zones safe', default = {}, wide = true, maxitems = 60, unique = 'id',
          hint = 'Pose-les en jeu : menu staff (F10) › Builder › Zones safe, debout au centre de la zone. Le rayon est en mètres.',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
            { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false },
            { k = 'z', label = 'Z', type = 'number', min = -1000, max = 3000, int = false }, { k = 'r', label = 'Rayon (m)', type = 'number', min = 5, max = 500, int = false } } } } })
    W:ExtModule({
        id = RES, label = 'Zones safe', icon = 'shield', perm = PERM, hint = 'Zones où personne ne peut tirer, frapper ou être blessé.',
        caps = { { 'Protection', 'ok', 'Pas de tirs, pas de coups, invincibilité : chaque règle se coupe dans les réglages.' }, { 'Builder', 'ok', 'Petite (25 m), moyenne (50 m), grande (100 m) ou rayon libre.' } },
        doc = "## Zones safe\nF10 › Builder › Zones safe : place-toi au **centre** de la zone puis choisis sa taille. « Supprimer la zone où je suis » enlève la zone dans laquelle tu te trouves.\n\nChaque règle (invincible, tirs, coups, arme rangée) se règle dans l'onglet Réglages.",
        tabs = { { id = 'main', label = 'Réglages', icon = 'sliders', form = main }, { id = 'zones', label = 'Zones posées', icon = 'pin', form = zones } },
    })
    pcall(function()
        W:RegisterBuilder({ list = true, id = 'zonesafe', label = 'Zones safe', icon = 'shield', points = {
            { id = 'small', label = 'Zone petite (25 m)', ask = 'Nom (vide = « Zone safe »)' },
            { id = 'medium', label = 'Zone moyenne (50 m)', ask = 'Nom (vide = « Zone safe »)' },
            { id = 'large', label = 'Zone grande (100 m)', ask = 'Nom (vide = « Zone safe »)' },
            { id = 'custom', label = 'Zone au rayon libre', ask = 'Rayon en mètres (5 à 500)' },
            { id = 'delete', label = 'Supprimer la zone où je suis' },
        } }, function(src, what, extra)
            if what == '__list' then
                local out = {}
                for _, z in ipairs(cfg('zones', {}) or {}) do out[#out + 1] = { key = z.id, label = z.label .. ' (' .. tostring(z.r) .. ' m)', x = z.x, y = z.y, z = z.z } end
                return out
            elseif what == '__delete' then
                local zs = cfg('zones', {}) or {}
                for i, z in ipairs(zs) do if tostring(z.id) == tostring(extra) then table.remove(zs, i) W:CfgSet(NS, 'zones', zs, GetPlayerName(src), 'Builder : suppression') push() return true end end
                return false
            end
            return place(src, tostring(what), tostring(extra or ''))
        end)
    end)
    push()
end
local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) end
end
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns ~= NS then return end SetTimeout(300, function() push() end) end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
