# wb_zonesafe — zones safe (Shadow Base)

Zones où l'on ne peut ni tirer, ni frapper, ni être blessé.

- Pose : **F10 › Builder › Zones safe**, debout au centre de la zone → petite (25 m), moyenne (50 m), grande (100 m) ou rayon libre.
- « Supprimer la zone où je suis » enlève la zone dans laquelle tu te trouves.
- Réglages (panel › Zones safe) : invincibilité, tirs, coups, arme rangée à l'entrée, staff en service non limité, blips, messages.
- Installation : `ensure wb_zonesafe` après `pb_panel`.
