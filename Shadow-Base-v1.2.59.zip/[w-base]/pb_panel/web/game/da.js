/* Couleur d'accent commune des interfaces « tableau de bord » : réglage cfg.inv.da_color (#rrggbb), rouge Sensity par défaut.
   Posée en variables CSS (--da-ac, --da-rgb) : l'inventaire, la station, le choix du personnage et l'habillage global la lisent. */
(function () {
'use strict';
const G = window.PBGame;
G.daAccent = function (cfg) {
  const c = (cfg && cfg.inv) || {}, m = String(c.da_color || '').match(/^#([0-9a-f]{6})$/i);
  return m ? [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16)).join(',') : '255,31,255';
};
function apply(c) {
  const rgb = G.daAccent(c || G.cfg), r = document.documentElement.style;
  r.setProperty('--da-rgb', rgb); r.setProperty('--da-ac', 'rgb(' + rgb + ')');
}
G.on('cfg', apply);
apply();
})();
