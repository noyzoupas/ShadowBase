/* Station-service : jauge du réservoir en arc (ce qui est déjà dedans, ce qui va être ajouté), montant qui défile, curseur de litres, paiement.
   Le serveur décide du prix et du paiement (pb:g:fuel:buy) ; ici on choisit seulement les litres. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, fx = G.fx, NSV = 'http://www.w3.org/2000/svg';
const money = (n, dec) => Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: dec ? 2 : 0, maximumFractionDigits: dec ? 2 : 0 }) + ' $';
const sv = (tag, a) => { const e = document.createElementNS(NSV, tag); Object.keys(a || {}).forEach((k) => e.setAttribute(k, a[k])); return e; };
const R = 230, CX = 260, CY = 262, LEN = Math.PI * R;
const arcD = 'M ' + (CX - R) + ' ' + CY + ' A ' + R + ' ' + R + ' 0 0 1 ' + (CX + R) + ' ' + CY;
const pump = () => { const e = sv('svg', { viewBox: '0 0 24 24' }), q = sv('path', { d: 'M5 21V5a2 2 0 012-2h6a2 2 0 012 2v16M4 21h12M16 9h2a2 2 0 012 2v6a1.2 1.2 0 002.4 0v-7l-3-3M7.5 8h5' }); q.setAttribute('stroke-linecap', 'round'); q.setAttribute('stroke-linejoin', 'round'); e.appendChild(q); return e; };
let box = null;
function close(post) { if (!box) return; box.stopCount && box.stopCount(); box.el.remove(); G.uiStack = G.uiStack.filter((u) => u.id !== 'gas'); box = null; if (post) G.post('gas.close', {}); }
G.on('gas.close', () => close(false));
G.on('gas.open', (d) => {
  close(false);
  d = d || {};
  const tank = Math.max(1, Number(d.tank) || 60), lvl = Math.max(0, Math.min(tank, Number(d.level) || 0)), need = Math.max(1, Math.floor(Number(d.need) || (tank - lvl))), max = Math.min(need, Number(d.max) || need);
  const price = Number(d.price) || 3, wallet = (Number(d.cash) || 0) + (Number(d.bank) || 0);
  let liters = Math.min(max, 25), shown = 0, stopCount = null;
  const track = sv('path', { d: arcD, class: 'tr' }), cur = sv('path', { d: arcD, class: 'cu' }), add = sv('path', { d: arcD, class: 'ad' }), head = sv('circle', { r: 7, class: 'hd' });
  [cur, add].forEach((p) => { p.style.strokeDasharray = String(LEN); p.style.strokeDashoffset = String(LEN); });
  const svg = sv('svg', { viewBox: '0 0 520 290', class: 'gs-arc' }); svg.append(track, add, cur, head);
  const pct = h('small', null, ''), amt = h('strong', null, '0,00 $'), sub = h('em', null, '');
  const range = h('input', { type: 'range', min: 0, max: String(max), step: '1', value: String(liters), class: 'gs-range' });
  const lbl = h('b', { class: 'gs-lv' }, ''), warn = h('p', { class: 'gs-warn' }, ''), go = h('button', { type: 'button', class: 'gs-go' }, 'Payer et remplir');
  const quick = [[10, '10 L'], [25, '25 L'], [max, 'Plein']].filter((q, i, a) => q[0] > 0 && a.findIndex((z) => z[0] === q[0]) === i);
  const qBtns = quick.map((q) => h('button', { type: 'button', class: 'gs-q', onclick: () => { liters = Math.min(max, q[0]); range.value = String(liters); update(); } }, q[1]));
  function update() {
    liters = Math.max(0, Math.min(max, Number(range.value) || 0));
    const cost = Math.round(price * liters * 100) / 100, after = (lvl + liters) / tank;
    const set = (p, v) => { p.style.strokeDashoffset = String(LEN * (1 - Math.max(0, Math.min(1, v)))); };
    set(cur, lvl / tank); set(add, after);
    const a = Math.PI * (1 - after);
    head.setAttribute('cx', (CX + R * Math.cos(a)).toFixed(1)); head.setAttribute('cy', (CY - R * Math.sin(a)).toFixed(1));
    pct.textContent = 'Remplissage · ' + Math.round(after * 100) + ' %';
    sub.textContent = liters > 0 ? '+ ' + liters.toLocaleString('fr-FR') + ' L' : 'Choisis une quantité';
    if (stopCount) stopCount();
    const from = shown; stopCount = fx.count(amt, from, cost, 350, (v) => { shown = v; return money(v, true); }); box && (box.stopCount = stopCount);
    lbl.textContent = liters + ' L';
    qBtns.forEach((b, i) => b.classList.toggle('on', liters === quick[i][0]));
    const poor = cost > wallet;
    warn.textContent = poor ? 'Il te faut ' + money(cost, true) + ' (tu as ' + money(wallet) + ').' : '';
    go.disabled = liters < 1 || poor;
    range.style.setProperty('--p', (max ? liters / max * 100 : 0) + '%');
  }
  range.addEventListener('input', update);
  go.addEventListener('click', () => { if (go.disabled) return; const n = liters; close(false); G.post('gas.buy', { liters: n }); });
  const el = h('div', { class: 'gs' }, h('div', { class: 'gs-pan' },
    h('header', null, h('div', null, h('b', null, 'Plein · ' + String(d.label || 'Station')), h('small', null, d.pump ? String(d.pump) : 'Carburant')), h('i', { class: 'gs-fl' }),
      h('span', { class: 'gs-w' }, h('small', null, 'Espèces'), money(d.cash)), h('span', { class: 'gs-w' }, h('small', null, 'Banque'), money(d.bank)),
      h('button', { type: 'button', class: 'gs-x', 'aria-label': 'Fermer', onclick: () => close(true) }, G.ico('close'))),
    h('div', { class: 'gs-dial' }, svg, h('div', { class: 'gs-side l' }, h('small', null, 'Véhicule'), h('b', null, String(d.model || 'Véhicule')), d.plate ? h('span', null, String(d.plate)) : null),
      h('div', { class: 'gs-side r' }, h('small', null, 'Réservoir'), h('b', null, Math.round(lvl) + ' / ' + Math.round(tank) + ' L'), h('span', null, Math.round(lvl / tank * 100) + ' % · il manque ' + need + ' L')),
      h('div', { class: 'gs-mid' }, pct, amt, sub)),
    h('div', { class: 'gs-prod' }, h('div', { class: 'gs-pi' }, pump()), h('div', null, h('b', null, 'Carburant'), h('small', null, 'Plein accepté par tous les véhicules')), h('i', { class: 'gs-fl' }), h('span', { class: 'gs-pr' }, h('b', null, money(price, true)), ' / L')),
    h('div', { class: 'gs-sl' }, h('span', null, '0 L'), range, h('span', null, max + ' L'), lbl),
    h('div', { class: 'gs-btns' }, ...qBtns, h('i', { class: 'gs-fl' }), warn, h('button', { type: 'button', class: 'gs-no', onclick: () => close(true) }, 'Annuler'), go)));
  const rgb = G.daAccent ? G.daAccent(G.cfg) : '255,31,255'; el.style.setProperty('--ac-rgb', rgb); el.style.setProperty('--ac', 'rgb(' + rgb + ')');
  G.root.appendChild(el);
  box = { el, stopCount: null };
  G.uiStack.push({ id: 'gas', onEscape: () => close(true) });
  const fit = () => el.style.setProperty('--k', String(Math.min(1.2, window.innerWidth / 1000, window.innerHeight / 640)));
  fit(); window.addEventListener('resize', fit);
  update();
});
})();
