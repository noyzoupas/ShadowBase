/* Coque commune des interfaces « boutique » : titre en haut à gauche, rail d'icônes, recherche + liste, panneau d'infos à droite, bouton d'action en bas.
   Utilisée par la supérette, la concession, le vestiaire et le garage. Tout texte est inséré avec textContent (constructeur DOM). */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

// shell({ title, sub, logo, banner, accent, rail, railOn, onRail, search, onSearch, money, onClose, dim })
function shell(o) {
  o = o || {};
  const hexOk = (c) => /^#[0-9a-fA-F]{6}$/.test(c || '');
  const br = (G.cfg && G.cfg.brand) || {};
  // pendant une fête appliquée au jeu, toutes les fenêtres prennent la couleur de la fête
  const acc = G.season() && hexOk(br.color) ? br.color : (hexOk(o.accent) ? o.accent : '#dfe2e7');
  const rail = h('nav', { class: 'sh-rail' }), items = h('div', { class: 'sh-items' }), info = h('aside', { class: 'sh-info' }), act = h('div', { class: 'sh-act' });
  const cash = h('b', null, ''), bank = h('b', null, '');
  const logoUrl = G.assetUrl(o.logo || '') || (G.nova && G.nova() ? G.logoUrl() : '');
  const top = h('header', { class: 'sh-top' },
    h('div', { class: 'sh-ttl' }, logoUrl ? h('img', { class: 'sh-logo', src: logoUrl, alt: '' }) : null, h('div', null, G.brandName() ? h('small', { class: 'sh-eb' }, G.brandName()) : null, h('b', null, o.title || ''), o.sub ? h('small', null, o.sub) : null)),
    h('div', { class: 'sh-tr' }, o.money ? [h('span', { class: 'sh-m' }, ico('coins'), 'Espèces ', cash), h('span', { class: 'sh-m' }, ico('card'), 'Banque ', bank)] : null,
      o.onClose ? h('button', { class: 'sh-x', title: 'Fermer', onclick: o.onClose }, ico('x')) : null));
  let q = '';
  const search = o.search === false ? null : h('input', { class: 'sh-s', type: 'text', placeholder: o.searchPlaceholder || 'Rechercher…', oninput: (e) => { q = e.target.value.trim().toLowerCase(); o.onSearch && o.onSearch(q); } });
  if (search) search.addEventListener('keydown', (e) => e.stopPropagation());
  const hasRail = (o.rail || []).length > 0;
  const el = h('div', { class: 'sh' + (o.dim === false ? '' : ' dim') + (hasRail ? '' : ' norail'), style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } },
    top, h('div', { class: 'sh-main' }, hasRail ? rail : null, h('section', { class: 'sh-list' }, search, items), h('div', { class: 'sh-sp' }), h('div', { class: 'sh-side' }, info, act)), G.festEl());

  function setRail(list, on) {
    G.clear(rail);
    (list || []).forEach((r) => rail.appendChild(h('button', { class: 'sh-rb' + (r.id === on ? ' on' : ''), title: r.label, onclick: () => { setRail(list, r.id); o.onRail && o.onRail(r.id); } },
      ico(r.icon || 'cart'), h('span', null, r.label), r.badge ? h('em', null, String(r.badge)) : null)));
  }
  if (hasRail) setRail(o.rail, o.railOn);
  const api = {
    el, items, info, act, rail: setRail, query: () => q,
    setMoney: (m) => { if (!m) return; cash.textContent = G.money(m.cash); bank.textContent = G.money(m.bank); },
    // ligne de liste standard
    row: (r) => h('button', { class: 'sh-row' + (r.on ? ' on' : '') + (r.off ? ' off' : ''), onclick: r.onclick },
      r.icon ? h('span', { class: 'sh-ri' }, ico(r.icon)) : null, h('span', { class: 'sh-rt' }, h('b', null, r.title), r.sub ? h('small', null, r.sub) : null, r.chips ? h('span', { class: 'sh-rc' }, r.chips) : null),
      r.right ? h('span', { class: 'sh-rr' }, r.right) : null),
    button: (label, onclick, opt) => h('button', { class: 'sh-btn' + (opt && opt.ghost ? ' ghost' : ''), disabled: (opt && opt.disabled) || null, onclick }, label),
  };
  if (o.money) api.setMoney(o.money);
  return api;
}
G.shell = shell;
})();
