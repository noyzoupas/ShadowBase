/* Fenêtre « DA du serveur » pour les interfaces à pages (banque, logement, tickets) : barre latérale avec le logo, le lieu et les pages,
   contenu à droite (cartes, tableaux, formulaires, actions, avis), touches en bas. Même contrat que l'ancienne tablette : le serveur envoie
   frame { brand, name, nav[], cash, bank } et page { title, blocks[] } ; on ne fait qu'afficher et renvoyer les actions. Texte : textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

function daView(opt) {
  opt = opt || {};
  let frame = opt.frame || { nav: [] }, page = opt.page || null, cur = (page && page.page) || 'home';
  const side = h('aside', { class: 'dv-side' }), main = h('main', { class: 'dv-main' }), toast = h('div', { class: 'dv-toast hidden' }), keys = h('footer', { class: 'dv-keys' });
  const el = h('div', { class: 'dv' }, h('div', { class: 'dv-win' }, side, h('div', { class: 'dv-right' }, main, keys), toast));
  let tt = null;
  const say = (ok, msg) => { if (!msg) return; toast.textContent = String(msg); toast.className = 'dv-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(tt); tt = setTimeout(() => toast.classList.add('hidden'), 4200); };
  const act = (name, payload) => { if (name) { G.click(); opt.onAct && opt.onAct(name, payload || {}, cur); } };
  const go = (id) => { cur = id; drawSide(); opt.onPage && opt.onPage(id); };

  function btn(a, cls) {
    let armed = false;
    const label = String(a.label || a.act || '');
    const b = h('button', { type: 'button', class: 'dv-btn' + (a.primary ? ' pri' : '') + (a.danger ? ' dng' : '') + (cls ? ' ' + cls : ''), disabled: a.disabled || null }, a.icon ? ico(a.icon) : null, h('span', null, label));
    b.addEventListener('click', () => {
      if (a.confirm && !armed) { armed = true; b.classList.add('arm'); b.lastChild.textContent = 'Confirmer ?'; setTimeout(() => { armed = false; b.classList.remove('arm'); b.lastChild.textContent = label; }, 3000); return; }
      act(a.act, a.payload);
    });
    return b;
  }
  const sec = (title, ...kids) => h('section', { class: 'dv-sec' }, title ? h('h3', null, String(title)) : null, ...kids);

  const B = {
    hero(b) {
      return h('section', { class: 'dv-hero' }, h('div', null, b.eyebrow ? h('small', null, String(b.eyebrow)) : null, h('b', null, String(b.title || '')), b.sub ? h('p', null, String(b.sub)) : null),
        b.chips ? h('div', { class: 'dv-chips' }, b.chips.map((c) => h('span', null, h('small', null, String(c[0])), h('b', null, String(c[1]))))) : null);
    },
    cards(b) {
      return h('section', { class: 'dv-cards' + (b.big ? ' big' : '') }, (b.items || []).map((it) => h('article', { class: 'dv-card' },
        h('div', { class: 'dv-card-h' }, h('span', { class: 'dv-ic' }, ico(it.icon || 'info')), h('small', null, String(it.title || '')), it.badge ? h('em', null, String(it.badge)) : null),
        it.value != null && it.value !== '' ? h('strong', null, String(it.value)) : null, it.sub ? h('p', null, String(it.sub)) : null, it.text ? h('p', { class: 'dim' }, String(it.text)) : null,
        it.stats ? h('div', { class: 'dv-cs' }, it.stats.map((s) => h('span', null, h('b', null, String(s.value)), h('small', null, String(s.label))))) : null)));
    },
    tiles(b) {
      return sec(b.title, h('div', { class: 'dv-tiles' }, (b.items || []).map((it) => h('button', { type: 'button', class: 'dv-tile', onclick: () => { if (it.page) go(it.page); else act(it.act, it.payload); } },
        h('span', { class: 'dv-ic' }, ico(it.icon || 'info')), h('b', null, String(it.title || '')), it.sub ? h('small', null, String(it.sub)) : null))));
    },
    actions(b) { return sec(b.title, h('div', { class: 'dv-row' }, (b.items || []).map((a) => btn(a)))); },
    notice(b) { return h('div', { class: 'dv-note ' + (b.kind || b.tone || '') }, ico('info'), h('span', null, String(b.text || ''))); },
    table(b) {
      const cols = b.columns || [], rows = b.rows || [];
      if (!rows.length) return sec(b.title, h('div', { class: 'dv-empty' }, String(b.empty || 'Rien à afficher.')));
      const hasAct = rows.some((r) => r.actions && r.actions.length);
      const t = h('table', null, h('thead', null, h('tr', null, cols.map((c) => h('th', null, String(c.label))), hasAct ? h('th') : null)),
        h('tbody', null, rows.map((r) => h('tr', null, cols.map((c) => h('td', null, r[c.k] == null ? '' : String(r[c.k]))), hasAct ? h('td', { class: 'dv-ra' }, (r.actions || []).map((a) => btn(a, 'sm'))) : null))));
      return sec(b.title, h('div', { class: 'dv-tw' }, t));
    },
    form(b) {
      const inputs = [];
      const fields = (b.fields || []).map((f) => {
        let inp;
        if (f.type === 'select') {
          inp = h('select', null, (f.opts || []).map((o) => h('option', { value: Array.isArray(o) ? o[0] : o }, String(Array.isArray(o) ? o[1] : o))));
          if (!(f.opts || []).length) { inp.appendChild(h('option', { value: '' }, 'Personne à proximité')); inp.disabled = true; }
        } else if (f.type === 'area') inp = h('textarea', { rows: 4, maxlength: f.maxlen || 500, placeholder: f.label });
        else if (f.type === 'toggle') inp = h('input', { type: 'checkbox' });
        else if (f.type === 'number') inp = h('input', { type: 'number', min: f.min, max: f.max, placeholder: f.label });
        else inp = h('input', { type: 'text', maxlength: f.maxlen || 120, placeholder: f.label });
        if (f.value != null) { if (f.type === 'toggle') inp.checked = !!f.value; else inp.value = f.value; }
        inputs.push([f, inp]);
        return h('label', { class: 'dv-f' + (f.type === 'area' ? ' wide' : '') + (f.type === 'toggle' ? ' tg' : '') }, h('small', null, String(f.label || '')), inp);
      });
      const sb = b.submit || {};
      const go2 = h('button', { type: 'button', class: 'dv-btn pri', disabled: sb.disabled || null }, ico('check'), h('span', null, String(sb.label || 'Valider')));
      go2.addEventListener('click', () => { const p = {}; inputs.forEach(([f, i]) => { p[f.k] = f.type === 'number' ? (i.value === '' ? null : Number(i.value)) : f.type === 'toggle' ? i.checked : i.value; }); act(sb.act, p); });
      return h('section', { class: 'dv-sec dv-form' }, h('h3', null, String(b.title || '')), b.desc ? h('p', { class: 'dim' }, String(b.desc)) : null, h('div', { class: 'dv-fg' }, fields), h('div', { class: 'dv-row' }, go2));
    },
  };

  function drawSide() {
    G.clear(side);
    const logo = (G.cfg && G.cfg.brand && G.cfg.brand.logo) ? G.assetUrl(G.cfg.brand.logo) : 'img/brand/shadow-logo.png';
    side.append(h('div', { class: 'dv-brand' }, h('img', { src: logo, alt: '' }), h('small', null, String((frame.nav && frame.nav[0] && frame.nav[0].group) || ''))),
      h('div', { class: 'dv-place' }, h('b', null, String(frame.brand || frame.title || '')), h('span', null, String(frame.name || ''))));
    const nav = h('nav', { class: 'dv-nav' });
    (frame.nav || []).forEach((n) => nav.appendChild(h('button', { type: 'button', class: 'dv-nv' + (n.id === cur ? ' on' : ''), onclick: () => { if (n.id !== cur) { G.click(); go(n.id); } } },
      ico(n.icon || 'info'), h('span', null, String(n.label || '')), n.count != null ? h('em', null, String(n.count)) : null)));
    side.appendChild(nav);
    const money = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
    side.appendChild(h('div', { class: 'dv-wallet' },
      frame.cash != null ? h('div', null, h('small', null, 'Espèces'), h('b', null, money(frame.cash))) : null,
      frame.bank != null ? h('div', null, h('small', null, 'Banque'), h('b', null, money(frame.bank))) : null));
  }
  function drawPage() {
    G.clear(main);
    if (!page) { main.appendChild(h('div', { class: 'dv-empty' }, 'Chargement…')); return; }
    main.appendChild(h('header', { class: 'dv-top' }, h('div', null, h('small', null, String(frame.brand || '')), h('h1', null, String(page.title || '')), page.sub ? h('p', null, String(page.sub)) : null),
      h('button', { type: 'button', class: 'dv-rf', title: 'Actualiser', onclick: () => { G.click(); opt.onPage && opt.onPage(cur); } }, ico('refresh'))));
    (page.blocks || []).forEach((b) => { const f = b && B[b.type]; const n = f ? f(b) : null; if (n) main.appendChild(n); });
  }
  function drawKeys() {
    G.clear(keys);
    const k = (key, t) => h('span', null, h('kbd', null, key), t);
    keys.append(k('Clic', 'Choisir'), k('Molette', 'Faire défiler'), k('Échap', 'Fermer'));
    if (opt.onClose) keys.appendChild(h('button', { type: 'button', class: 'dv-x', onclick: () => { G.click(); opt.onClose(); } }, ico('x'), 'Fermer'));
  }
  drawSide(); drawPage(); drawKeys();
  return { el, set(d) { if (d.frame) frame = d.frame; if (d.page) { page = d.page; cur = d.page.page || cur; } drawSide(); drawPage(); if (d.err) say(false, d.err); }, say };
}
G.daView = daView;
})();
