-- Mises à jour de Shadow Base : le serveur lit régulièrement un fichier latest.json publié gratuitement (GitHub Pages / Releases),
-- vérifie sa signature Ed25519 (même clé publique que les licences : une fausse mise à jour est refusée), et prévient les administrateurs
-- (console, notification du panel, module « Mises à jour » avec les patch notes et le lien de téléchargement).
-- (v1.2.78) « wupdate » (console txAdmin) ou « Installer et redémarrer » (panel) installe la mise à jour puis redémarre.
--
-- latest.json : { "v":1, "version":"1.2.0", "date":"2026-10-20", "title":"…", "notes":["…"], "download":"https://…zip", "sha256":"…", "site":"https://…", "sig":"<hex>" }
-- Signature sur :  WBUPD1|version|date|download|sha256   (outil : W-Base/outils/publier.py)

PB.Update = PB.Update or {}
local U = PB.Update
local E = PB.Ed25519
local RES = GetCurrentResourceName()

local P = PB.Perm
P.Register('updates.view', 'Voir les mises à jour de Shadow Base', 'panel')

local function cfg() return (Config and Config.Update) or {} end
-- adresse : convar wbase_update_url > Config.Update.url > fichier update_url.txt (écrit par l'outil de publication, livré dans le zip)
local function url()
    local c = GetConvar('wbase_update_url', '') if c ~= '' then return c end
    local u = tostring(cfg().url or '') if u ~= '' then return u end
    return (tostring(LoadResourceFile(RES, 'update_url.txt') or ''):gsub('%s+', ''))
end
U.Current = GetResourceMetadata(RES, 'version', 0) or '0.0.0'
U.Latest, U.Checked, U.Error = nil, 0, nil

local function parts(v) local a, b, c = tostring(v or ''):match('^(%d+)%.(%d+)%.(%d+)') return tonumber(a) or 0, tonumber(b) or 0, tonumber(c) or 0 end
function U.Newer(a, b)   -- a plus récente que b ?
    local a1, a2, a3 = parts(a)
    local b1, b2, b3 = parts(b)
    if a1 ~= b1 then return a1 > b1 end
    if a2 ~= b2 then return a2 > b2 end
    return a3 > b3
end

function U.Verify(doc)
    if type(doc) ~= 'table' or doc.v ~= 1 then return false, 'Fichier de mise à jour illisible.' end
    for _, k in ipairs({ 'version', 'date', 'download', 'sha256', 'sig' }) do if type(doc[k]) ~= 'string' or doc[k] == '' then return false, 'Champ manquant : ' .. k end end
    if not tostring(doc.download):match('^https://') then return false, 'Lien de téléchargement non sécurisé.' end
    local pub = E.unhex(PB.LicensePub or '')
    local sig = E.unhex(doc.sig)
    if not pub or #pub ~= 32 or not sig or #sig ~= 64 then return false, 'Signature absente.' end
    local msg = ('WBUPD1|%s|%s|%s|%s'):format(doc.version, doc.date, doc.download, doc.sha256)
    if not E.verify(sig, msg, pub) then return false, 'Signature incorrecte : mise à jour ignorée (fichier modifié ou faux).' end
    return true
end

-- Mise à jour rapide : le petit zip prévu pour la version installée (seulement les fichiers changés). Signé lui aussi, sinon on l'ignore.
function U.Delta(doc)
    if type(doc) ~= 'table' or type(doc.deltas) ~= 'table' then return nil end
    for _, d in ipairs(doc.deltas) do
        if type(d) == 'table' and d.from == U.Current and type(d.url) == 'string' and d.url:match('^https://') and type(d.sha256) == 'string' and type(d.sig) == 'string' then
            local pub, sig = E.unhex(PB.LicensePub or ''), E.unhex(d.sig)
            if pub and #pub == 32 and sig and #sig == 64 and E.verify(sig, ('WBDELTA1|%s|%s|%s|%s'):format(doc.version, d.from, d.url, d.sha256), pub) then return d end
            return nil
        end
    end
    return nil
end

-- (v1.2.95) Le site GitHub Pages se met parfois à jour avec des heures de retard (file d'attente de GitHub) : on lit d'abord
-- la copie « raw » du dépôt, à jour dès la publication, puis le site en secours. Les fichiers restent vérifiés (signature, SHA-256).
local function rawOf(u)
    local user, repo, path = tostring(u or ''):match('^https://([%w%-]+)%.github%.io/([%w%-_%.]+)/(.+)$')
    if not user then return nil end
    return ('https://raw.githubusercontent.com/%s/%s/main/%s'):format(user, repo, path)
end
U.RawOf = rawOf
local function fetch(urls, i, cb)
    local u = urls[i]
    if not u then return cb(nil, 0) end
    PerformHttpRequest(u, function(status, body)
        if status == 200 and type(body) == 'string' and #body > 0 then return cb(body, status, u) end
        if urls[i + 1] then return fetch(urls, i + 1, cb) end
        cb(nil, status)
    end, 'GET', '', { ['Cache-Control'] = 'no-cache' })
end
function U.Check(cb)
    local u = url()
    if not u:match('^https://') then U.Error = 'Adresse de mise à jour non renseignée (Config.Update.url).' if cb then cb(false) end return end
    local q = (u:find('?', 1, true) and '&' or '?') .. 't=' .. os.time()
    local list = {}
    local raw = rawOf(u)
    if raw then list[#list + 1] = raw .. '?t=' .. os.time() end
    list[#list + 1] = u .. q
    fetch(list, 1, function(body, status)
        U.Checked = os.time()
        if not body then U.Error = 'Serveur de mises à jour injoignable (' .. tostring(status) .. ').' if cb then cb(false) end return end
        local doc = PB.FromJson(body, nil)
        local ok, why = U.Verify(doc)
        if not ok then U.Error = why PB.Warn('[mises à jour] ' .. why) if cb then cb(false) end return end
        U.Error = nil
        local was = U.Latest and U.Latest.version
        U.Latest = doc
        if U.Newer(doc.version, U.Current) and was ~= doc.version then
            print('^3============================================================^7')
            print(('^3[Shadow Base]^7 Mise à jour disponible : ^2%s^7 (installée : %s) — %s'):format(doc.version, U.Current, tostring(doc.title or '')))
            local d = U.Delta(doc)
            print('^3[Shadow Base]^7 Téléchargement : ' .. (d and (d.url .. (' (%d fichiers changés)'):format(tonumber(d.files) or 0)) or doc.download))
            print('^3============================================================^7')
            if PB.Notify then PB.Notify('info', 'Mise à jour Shadow Base ' .. doc.version, tostring(doc.title or 'Nouvelle version disponible.')) end
        end
        if cb then cb(true) end
    end)
end

-- (v1.2.81) Installation automatique : dès qu'une nouvelle version est publiée, le serveur l'installe tout seul et redémarre
-- (annonce aux joueurs « Redémarrage dans X minutes » ; 15 s s'il n'y a personne). Plus besoin de savoir quand taper « wupdate ».
-- Réglable dans le panel › Mises à jour (désactivable). Vérification toutes les 10 minutes.
local function acfg(k, d) local v = PB.Cfg and PB.Cfg.Get('updates', k, nil) if v == nil then return d end return v end
local tried = {}   -- version -> true : une seule tentative automatique par version (pas de boucle si l'installation échoue)
local told = {}
function U.AutoTick()
    if U.Busy or not U.Latest or not U.Newer(U.Latest.version, U.Current) then return end
    local v = U.Latest.version
    -- (v1.2.88) par défaut : rien ne s'installe ni ne redémarre tout seul ; la console et le staff en ligne sont prévenus, « wupdate » installe
    if acfg('auto', false) ~= true or (GetResourceKvpString and GetResourceKvpString('pb_upd_skip') == v) then   -- (v1.2.97) version annulée par wrollback : jamais réinstallée seule
        if told[v] then return end
        told[v] = true
        print(('^3[Shadow Base]^7 Version %s disponible : tape ^2wupdate^7 dans la console pour l\'installer et redémarrer.'):format(v))
        for _, id in ipairs(GetPlayers()) do
            local s = tonumber(id)
            if P.Has(s, 'updates.install') and PB.G and PB.G.Notify then
                PB.G.Notify(s, { type = 'info', title = 'Mise à jour ' .. v, text = 'Nouvelle version de Shadow Base disponible : « wupdate » dans la console txAdmin pour l\'installer.', duration = 12000 })
            end
        end
        return
    end
    if tried[v] then return end
    tried[v] = true
    local n = #GetPlayers()
    local secs = n > 0 and math.max(1, math.min(60, math.floor(tonumber(acfg('auto_minutes', 5)) or 5))) * 60 or 15
    print(('^3[Shadow Base]^7 Installation automatique de la version %s (redémarrage dans %d s, %d joueur(s) en ligne).'):format(v, secs, n))
    U.Install('automatique', secs, function(ok, msg)
        print(('%s[Shadow Base]^7 %s'):format(ok and '^2' or '^1', tostring(msg)))
        if PB.Notify then PB.Notify(ok and 'success' or 'error', 'Mise à jour automatique', tostring(msg)) end
    end)
end
CreateThread(function()
    Wait(20000)
    while true do
        pcall(U.Check, function(ok) if ok then pcall(U.AutoTick) end end)
        Wait(math.max(2, math.min(360, math.floor(tonumber(acfg('check_minutes', 10)) or 10))) * 60 * 1000)
    end
end)

RegisterCommand('wbase_update', function(src)
    if src ~= 0 then return end
    U.Check(function(ok)
        if not ok then print('^1[Shadow Base]^7 ' .. tostring(U.Error)) return end
        if U.Newer(U.Latest.version, U.Current) then print(('^3[Shadow Base]^7 Version %s disponible (installée : %s) : %s'):format(U.Latest.version, U.Current, U.Latest.download))
        else print(('^2[Shadow Base]^7 À jour (%s).'):format(U.Current)) end
    end)
end, true)

-- (v1.2.78) Installation automatique : « wupdate » dans la console (txAdmin › Console) ou le bouton du panel.
-- 1. lit latest.json et vérifie sa signature ; 2. télécharge le petit zip prévu pour la version installée (sinon le zip complet) ;
-- 3. vérifie son empreinte SHA-256 (publiée et signée) et chaque fichier (CRC) ; 4. écrit les fichiers dans resources/[w-base]
--    (jamais pb_panel/config.lua, license.key ni server.cfg) ; 5. redémarre le serveur avec le compte à rebours habituel (txAdmin le relance).
-- Tout est vérifié AVANT d'écrire le premier fichier : un téléchargement abîmé n'installe rien.
U.Busy = false
local PROTECT = { ['pb_panel/config.lua'] = true, ['pb_panel/license.key'] = true }
local WIN = (type(package) == 'table' and package.config and package.config:sub(1, 1) == '\\') or tostring(GetResourcePath and GetResourcePath(RES) or ''):match('^%a:[/\\]') ~= nil
local function say(msg, kind) print(('%s[Shadow Base]^7 %s'):format(kind == 'err' and '^1' or (kind == 'ok' and '^2' or '^3'), msg)) end
local function baseDir()
    local p = (GetResourcePath and GetResourcePath(RES) or ''):gsub('\\', '/')
    return p:match('^(.*)/[^/]+$')   -- dossier qui contient pb_panel ([w-base])
end
local function mkdirs(dir)
    if WIN then os.execute(('mkdir "%s" >nul 2>nul'):format(dir:gsub('/', '\\'))) else os.execute(("mkdir -p '%s'"):format(dir:gsub("'", ""))) end
end
local function writeFile(path, data)
    local f = io.open(path, 'wb')
    if not f then mkdirs(path:match('^(.*)/[^/]+$') or '.') f = io.open(path, 'wb') end
    if not f then return false end
    f:write(data) f:close()
    return true
end
-- Cède la main au serveur dès qu'on a travaillé plus de 20 ms (le plus long travail d'un seul tenant reste sous 50 ms, loin du seuil d'alerte de 200 ms) : SHA-256, décompression et CRC tournent en Lua sur le fil principal, sans cela le serveur saccade pendant toute la mise à jour
local lastYield = os.clock()
local function yield()
    if os.clock() - lastYield >= 0.02 then Wait(0) lastYield = os.clock() end
end
function U.Install(by, restartSecs, done, force)
    if U.Busy then return done(false, 'Une installation est déjà en cours.') end
    if not (PB.Zip and io and io.open) then return done(false, "Ce serveur ne permet pas d'écrire les fichiers (bibliothèque io absente) : installe le zip à la main.") end
    local base = baseDir()
    if not base then return done(false, 'Dossier des ressources introuvable.') end
    U.Busy = true
    local function fin(ok, msg) U.Busy = false done(ok, msg) end
    U.Check(function(ok)
        if not ok then return fin(false, tostring(U.Error)) end
        local L = U.Latest
        if not force and not U.Newer(L.version, U.Current) then return fin(false, ('Déjà à jour (%s). Pour réinstaller tous les fichiers (réparation) : wupdate full'):format(U.Current)) end
        local d = (not force) and U.Delta(L) or nil
        local link, sha = d and d.url or L.download, d and d.sha256 or L.sha256
        say(('Téléchargement de la version %s (%s)…'):format(L.version, d and ('mise à jour rapide, %d fichiers'):format(tonumber(d.files) or 0) or 'zip complet'))
        local links = {}
        if rawOf(link) then links[#links + 1] = rawOf(link) end
        links[#links + 1] = link
        fetch(links, 1, function(body, status)
            CreateThread(function()
                if type(body) ~= 'string' or #body < 100 then return fin(false, 'Téléchargement impossible (' .. tostring(status) .. ').') end
                say(('Zip reçu (%.1f Mo) : vérification…'):format(#body / 1e6))
                local shown = 0
                local function progress(p) local pc = math.floor(p * 10) * 10 if pc > shown then shown = pc say(('Vérification de l\'empreinte : %d %%'):format(pc)) end end
                if PB.Zip.Sha256(body, yield, progress) ~= tostring(sha):lower() then return fin(false, "Empreinte SHA-256 différente de celle publiée : rien n'est installé.") end
                local list, err = PB.Zip.Entries(body)
                if not list then return fin(false, err) end
                local files = {}
                local total, count = #list, 0
                for _, e in ipairs(list) do
                    count = count + 1
                    if count % 300 == 0 then say(('Décompression : %d / %d fichiers'):format(count, total)) end
                    local rel = e.name:match('^%[w%-base%]/(.+)$')
                    if rel and not rel:match('/$') and not rel:find('..', 1, true) and not rel:match('^/') and not PROTECT[rel] and not rel:match('server%.cfg$') then
                        local data, why = PB.Zip.Read(body, e, yield)
                        if not data then return fin(false, why) end
                        files[#files + 1] = { rel = rel, data = data }
                        yield()
                    end
                end
                if #files == 0 then return fin(false, 'Le zip ne contient aucun fichier de [w-base].') end
                -- Avant d'écrire quoi que ce soit : chaque fichier qui existe doit être modifiable, et chaque NOUVEAU fichier doit pouvoir être créé dans son dossier
                -- (un hébergeur peut laisser modifier les fichiers existants tout en interdisant d'en créer) : jamais de mise à jour à moitié installée.
                local function canWrite(d)
                    local probe = d .. '/.wbprobe'
                    local h = io.open(probe, 'wb')
                    if not h then return false end
                    h:close() os.remove(probe)
                    return true
                end
                local CODE_EXT = { lua = true, js = true, json = true, html = true, css = true, meta = true, cfg = true, xml = true, ymt = true }
                local dirOk, noCreate, noModify, skipped = {}, {}, {}, {}
                for _, f in ipairs(files) do
                    local path = base .. '/' .. f.rel
                    local h = io.open(path, 'rb')
                    if h then
                        h:close()
                        local w = io.open(path, 'r+b')
                        if w then w:close() else noModify[#noModify + 1] = f.rel end
                    else
                        local d = path:match('^(.*)/[^/]+$')
                        if d and dirOk[d] == nil then
                            local ok = canWrite(d)
                            if not ok then mkdirs(d) ok = canWrite(d) end
                            dirOk[d] = ok
                        end
                        if d and not dirOk[d] then
                            local ext = f.rel:match('%.([%w]+)$') or ''
                            if CODE_EXT[ext:lower()] then noCreate[#noCreate + 1] = f.rel else skipped[#skipped + 1] = f.rel f.skip = true end
                        end
                    end
                end
                if #noCreate > 0 or #noModify > 0 then
                    local names, seen = {}, {}
                    for _, rel in ipairs(noCreate) do local t = rel:match('^(.*)/[^/]+$') or rel if not seen[t] then seen[t] = true names[#names + 1] = t end end
                    for _, rel in ipairs(noModify) do if not seen[rel] then seen[rel] = true names[#names + 1] = rel end end
                    table.sort(names)
                    local full = {}
                    for _, n in ipairs(names) do full[#full + 1] = base .. '/' .. n end
                    names = full
                    local msg = ("Rien n'a été installé : le serveur n'a pas le droit de créer %d nouveau(x) fichier(s) ni de modifier %d fichier(s). Dossiers/fichiers concernés (chemins complets, qui doivent se trouver À CÔTÉ de pb_panel) : %s. Donne les droits d'écriture au dossier [w-base] et à tout ce qu'il contient (chmod -R 775, propriétaire = utilisateur du serveur), ou ajoute « add_unsafe_child_process_permission pb_panel » dans server.cfg, puis relance wupdate."):format(#noCreate, #noModify, table.concat(names, ', '):sub(1, 700))
                    return fin(false, msg)
                end
                if #skipped > 0 then
                    local keep, dirsS, seenS = {}, {}, {}
                    for _, f in ipairs(files) do if not f.skip then keep[#keep + 1] = f end end
                    files = keep
                    for _, rel in ipairs(skipped) do local t = rel:match('^(.*)/[^/]+$') or rel if not seenS[t] then seenS[t] = true dirsS[#dirsS + 1] = t end end
                    table.sort(dirsS)
                    say(("%d fichier(s) de contenu (images, polices, sons) ne peuvent pas être créés et sont ignorés : %s. Donne les droits d'écriture à ces dossiers puis relance « wupdate full » pour les ajouter."):format(#skipped, table.concat(dirsS, ', '):sub(1, 300)), 'err')
                end
                -- (v1.2.97) point de retour : anciens fichiers + sauvegarde de la base et de la config, avant d'écrire quoi que ce soit
                if U.BeforeWrite then
                    say('Sauvegarde avant la mise à jour (fichiers remplacés, base de données, configuration)…')
                    local okB, pt, why = pcall(U.BeforeWrite, by, L.version, files, base)
                    if not okB or not pt then   -- (v1.2.104) plus bloquant : sans point de retour, la mise à jour s'installe quand même
                        say('Point de retour impossible (' .. tostring(okB and why or pt) .. ') : installation quand même, sans retour en arrière possible.', 'err')
                    else
                    say(('Point de retour #%d créé : %d fichier(s) gardé(s)%s. Pour revenir en arrière : wrollback'):format(pt.id, pt.files, pt.db and ', base sauvegardée' or ' (base NON sauvegardée : ' .. tostring(pt.dbErr) .. ')'), pt.db and 'ok' or 'err') end
                end
                local n, failed = 0, {}
                for _, f in ipairs(files) do
                    if writeFile(base .. '/' .. f.rel, f.data) then n = n + 1 else failed[#failed + 1] = f.rel end
                    if n % 25 == 0 then yield() end
                end
                PB.Audit.Log('serveur', 'update.install', by or 'console', L.version, U.Current, nil, { files = n, failed = #failed })
                if #failed > 0 then return fin(false, ('%d fichier(s) installé(s), %d impossible(s) à écrire (droits du dossier ?) : %s. Pas de redémarrage.'):format(n, #failed, table.concat(failed, ', '):sub(1, 300))) end
                say(('Version %s installée : %d fichier(s) remplacé(s). Ta config et ta licence n\'ont pas bougé.'):format(L.version, n), 'ok')
                local secs = math.max(10, math.min(3600, math.floor(tonumber(restartSecs) or 60)))
                if PB.Restart and PB.Restart.Start then
                    local okR, msgR = PB.Restart.Start(secs, 'Mise à jour ' .. L.version)
                    if not okR then say(tostring(msgR), 'err') end
                    if PB.Restart.Supervised and not PB.Restart.Supervised() then say("Aucun superviseur (txAdmin) détecté : relance le serveur toi-même après l'arrêt.", 'err') end
                else ExecuteCommand('quit') end   -- (PB.Restart.Quit gère le droit manquant)
                fin(true, ('Version %s installée (%d fichiers). Redémarrage dans %d s.'):format(L.version, n, secs))
            end)
        end)
    end)
end
-- (v1.2.97) Points de retour ------------------------------------------------------------------------------------------------------------------
-- Avant chaque installation : les fichiers qui vont être remplacés (seulement ceux qui changent) sont copiés dans pb_panel/data/rollback,
-- avec la liste des fichiers nouveaux, plus une sauvegarde de la base et de la configuration (module Sauvegardes).
-- « wrollback » remet les anciens fichiers (et, si on le demande, la base) puis redémarre : on revient à la version d'avant en une commande.
PB.Migrate('570_update_points', "Mises à jour : points de retour", {
    [[CREATE TABLE IF NOT EXISTS pb_update_points (id INT NOT NULL AUTO_INCREMENT, from_v VARCHAR(24) NOT NULL, to_v VARCHAR(24) NOT NULL, at INT NOT NULL, by_name VARCHAR(96) NOT NULL DEFAULT '',
        file VARCHAR(255) NOT NULL, files INT NOT NULL DEFAULT 0, added INT NOT NULL DEFAULT 0, size INT NOT NULL DEFAULT 0, db_backup INT NOT NULL DEFAULT 0, cfg_backup INT NOT NULL DEFAULT 0,
        used INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
})
local KEEP_POINTS = 3
local function resDir() return ((GetResourcePath and GetResourcePath(RES) or '.'):gsub('\\', '/')) end
local function rbDir() return resDir() .. '/data/rollback' end
-- (v1.2.104) certains hébergeurs interdisent de créer un dossier depuis le serveur : on essaie data/rollback, puis data, puis pb_panel lui-même.
-- Le chemin gardé est relatif à pb_panel (« data/rollback/x.wbr », « data/x.wbr » ou « x.wbr »).
local function rbPath(file)
    file = tostring(file or '')
    if file:find('/', 1, true) then return resDir() .. '/' .. file end
    for _, a in ipairs({ rbDir() .. '/' .. file, resDir() .. '/data/' .. file, resDir() .. '/' .. file }) do
        local f = io.open(a, 'rb') if f then f:close() return a end
    end
    return rbDir() .. '/' .. file
end
local function readAll(path) local f = io.open(path, 'rb') if not f then return nil end local d = f:read('a') f:close() return d end

function U.BeforeWrite(by, toV, files, base)
    local name = ('%s-vers-%s-%d.wbr'):format(tostring(U.Current):gsub('[^%w%.]', ''), tostring(toV):gsub('[^%w%.]', ''), os.time())
    local rel, path
    for _, sub in ipairs({ 'data/rollback/', 'data/', '' }) do
        local f = io.open(resDir() .. '/' .. sub .. name, 'wb')
        if f then f:write('WBR1\n') f:close() rel, path = sub .. name, resDir() .. '/' .. sub .. name break end
    end
    if not path then
        return nil, ("impossible d'écrire dans %s (ni dans data/, ni dans pb_panel/). Crée un DOSSIER « rollback » dans pb_panel/data et donne-lui les droits d'écriture (777), ou installe le zip de mise à jour à la main."):format(rbDir())
    end
    name = rel
    local out = io.open(path, 'ab')
    if not out then return nil, 'fichier de retour impossible à ouvrir' end
    local kept, added, size = 0, 0, 0
    for i, f in ipairs(files) do
        local old = readAll(base .. '/' .. f.rel)
        if old == nil then
            out:write(('N %d\n'):format(#f.rel), f.rel) added = added + 1
        elseif old ~= f.data then
            out:write(('F %d %d\n'):format(#f.rel, #old), f.rel, old) kept = kept + 1 size = size + #old
        end
        if i % 20 == 0 then yield() end
    end
    out:write('E\n') out:close()
    local dbId, dbErr, cfgId
    if PB.CreateBackup then
        local ok1, a, e = pcall(PB.CreateBackup, 'database', 'avant mise à jour ' .. tostring(toV), true)
        if ok1 and a then dbId = a else dbErr = ok1 and e or a end
        local ok2, c = pcall(PB.CreateBackup, 'config', 'avant mise à jour ' .. tostring(toV), true)
        if ok2 and c then cfgId = c end
    else dbErr = 'module Sauvegardes absent' end
    local id = PB.DB.insert('INSERT INTO pb_update_points (from_v, to_v, at, by_name, file, files, added, size, db_backup, cfg_backup) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { tostring(U.Current):sub(1, 24), tostring(toV):sub(1, 24), os.time(), tostring(by or 'console'):sub(1, 96), name, kept, added, size, dbId or 0, cfgId or 0 })
    if not id then os.remove(path) return nil, "écriture du point de retour dans la base impossible" end
    -- on garde les 3 derniers points
    for _, r in ipairs(PB.DB.q('SELECT id, file FROM pb_update_points ORDER BY id DESC LIMIT 100 OFFSET ' .. KEEP_POINTS) or {}) do
        os.remove(rbPath(r.file))
        PB.DB.exec('DELETE FROM pb_update_points WHERE id = ?', { r.id })
    end
    return { id = id, files = kept, added = added, db = dbId ~= nil, dbErr = dbErr }
end

function U.Points() return PB.DB.q('SELECT * FROM pb_update_points ORDER BY id DESC LIMIT ' .. KEEP_POINTS) or {} end

-- withDb : remet aussi la base telle qu'elle était juste avant la mise à jour (tout ce que les joueurs ont fait depuis est perdu)
function U.Rollback(pointId, withDb, by, restartSecs, done)
    if U.Busy then return done(false, 'Une installation est déjà en cours.') end
    local pt = PB.DB.one('SELECT * FROM pb_update_points WHERE id = ?', { math.floor(tonumber(pointId) or 0) })
    if not pt then return done(false, 'Point de retour introuvable (wrollback pour la liste).') end
    local base = baseDir()
    local raw = base and readAll(rbPath(pt.file))
    if not raw or raw:sub(1, 5) ~= 'WBR1\n' then return done(false, 'Fichier du point de retour absent ou abîmé (' .. tostring(pt.file) .. ').') end
    -- lecture complète AVANT d'écrire : un fichier tronqué ne remet rien
    local list, pos = {}, 6
    while true do
        local e = raw:find('\n', pos, true)
        if not e then return done(false, 'Point de retour incomplet : rien n\'a été modifié.') end
        local head = raw:sub(pos, e - 1)
        pos = e + 1
        if head == 'E' then break end
        local a, b = head:match('^F (%d+) (%d+)$')
        if a then
            a, b = tonumber(a), tonumber(b)
            list[#list + 1] = { rel = raw:sub(pos, pos + a - 1), data = raw:sub(pos + a, pos + a + b - 1) }
            pos = pos + a + b
        else
            local n = tonumber(head:match('^N (%d+)$') or '')
            if not n then return done(false, 'Point de retour illisible : rien n\'a été modifié.') end
            list[#list + 1] = { rel = raw:sub(pos, pos + n - 1), remove = true }
            pos = pos + n
        end
    end
    for _, f in ipairs(list) do
        if f.rel:find('..', 1, true) or f.rel:match('^/') or PROTECT[f.rel] then return done(false, 'Point de retour refusé (chemin interdit : ' .. f.rel .. ').') end
    end
    U.Busy = true
    CreateThread(function()
        local function fin(ok, msg) U.Busy = false done(ok, msg) end
        if withDb then
            if (tonumber(pt.db_backup) or 0) == 0 or not PB.RestoreBackup then return fin(false, "Ce point de retour n'a pas de sauvegarde de la base : relance sans « base » pour remettre seulement les fichiers.") end
            say('Restauration de la base telle qu\'elle était avant la mise à jour…')
            local ok, msg = PB.RestoreBackup(pt.db_backup, by or 'console')
            if not ok then return fin(false, 'Base non restaurée, rien n\'a été modifié : ' .. tostring(msg)) end
            say(tostring(msg), 'ok')
        end
        local n, failed = 0, {}
        for i, f in ipairs(list) do
            if f.remove then os.remove(base .. '/' .. f.rel)
            elseif writeFile(base .. '/' .. f.rel, f.data) then n = n + 1 else failed[#failed + 1] = f.rel end
            if i % 25 == 0 then yield() end
        end
        PB.DB.exec('UPDATE pb_update_points SET used = ? WHERE id = ?', { os.time(), pt.id })
        if SetResourceKvp then SetResourceKvp('pb_upd_skip', tostring(pt.to_v)) end
        PB.Audit.Log('serveur', 'update.rollback', by or 'console', pt.from_v, pt.to_v, nil, { files = n, db = withDb and true or false, failed = #failed })
        if #failed > 0 then return fin(false, ('%d fichier(s) remis, %d impossible(s) à écrire : %s. Pas de redémarrage.'):format(n, #failed, table.concat(failed, ', '):sub(1, 300))) end
        local secs = math.max(10, math.min(3600, math.floor(tonumber(restartSecs) or 60)))
        say(('Retour à la version %s : %d fichier(s) remis%s. La version %s ne sera pas réinstallée toute seule.'):format(pt.from_v, n, withDb and ', base restaurée' or '', pt.to_v), 'ok')
        if PB.Restart and PB.Restart.Start then
            local okR, msgR = PB.Restart.Start(secs, 'Retour à la version ' .. pt.from_v)
            if not okR then say(tostring(msgR), 'err') end
        else ExecuteCommand('quit') end
        fin(true, ('Retour à la version %s fait. Redémarrage dans %d s.'):format(pt.from_v, secs))
    end)
end

-- console : wrollback (liste) · wrollback <n> (fichiers) · wrollback <n> base (fichiers + base)
RegisterCommand('wrollback', function(src, args)
    if src ~= 0 and not (PB.Perm.IsOwner and PB.Perm.IsOwner(src)) then return end
    local pts = U.Points()
    if not args[1] then
        if #pts == 0 then say("Aucun point de retour : il s'en crée un à chaque « wupdate ».") return end
        say('Points de retour (le plus récent en premier) :')
        for _, p in ipairs(pts) do
            print(('   ^2%d^7 · %s : %s → %s par %s · %d fichier(s)%s%s'):format(p.id, os.date('%d/%m %H:%M', p.at), p.from_v, p.to_v, p.by_name, p.files,
                (tonumber(p.db_backup) or 0) > 0 and ' · base sauvegardée' or ' · sans base', (tonumber(p.used) or 0) > 0 and ' · déjà utilisé' or ''))
        end
        say('wrollback NUMÉRO = remettre les fichiers · wrollback NUMÉRO base = fichiers ET base (les progrès des joueurs depuis la mise à jour sont perdus)')
        return
    end
    local who = src == 0 and 'console' or (GetPlayerName(src) or ('#' .. src))
    U.Rollback(tonumber(args[1]), tostring(args[2] or ''):lower() == 'base', who, tonumber(args[3]) or 60, function(ok, msg) say(tostring(msg), ok and 'ok' or 'err') end)
end, false)
PB.Action('updates.rollback', 'updates.install', function(ctx, p)
    U.Rollback(p.id, p.db == true, ctx.actor and ctx.actor.name or 'panel', 60, function(ok, msg) if PB.Notify then PB.Notify(ok and 'success' or 'error', 'Retour en arrière', tostring(msg)) end end)
    ctx.toast = 'Retour en arrière lancé : suis-le dans la console.'
    ctx.refresh = false
    return true
end, { rate = 2, critical = true, confirm = { title = 'Revenir à la version d\'avant ?', text = 'Les fichiers de la mise à jour sont remplacés par les anciens, puis le serveur redémarre.' } })

-- console (txAdmin) : wupdate [secondes avant le redémarrage, 60 par défaut]
RegisterCommand('wupdate', function(src, args)
    if src ~= 0 and not (PB.Perm.IsOwner and PB.Perm.IsOwner(src)) then return end
    local who = src == 0 and 'console' or (GetPlayerName(src) or ('#' .. src))
    -- « wupdate full » : réinstalle TOUS les fichiers depuis le zip complet, même à jour (répare une installation à laquelle il manque des fichiers)
    local full = tostring(args[1] or ''):lower() == 'full'
    say(full and 'Réparation : réinstallation de tous les fichiers depuis le zip complet…' or 'Recherche de la mise à jour…')
    U.Install(who, tonumber(full and args[2] or args[1]) or 60, function(ok, msg)
        say(tostring(msg), ok and 'ok' or 'err')
        if src ~= 0 and PB.Notify then PB.Notify(ok and 'success' or 'error', 'Mise à jour', tostring(msg)) end
    end, full)
end, false)

-- Le manifeste de pb_panel charge wb_shield : s'il manque (installation incomplète), on le dit tout de suite
CreateThread(function()
    Wait(20000)
    if GetResourceState('wb_shield') == 'missing' then
        say("La ressource wb_shield est introuvable (installation incomplète). Tape « wupdate full » dans la console pour réinstaller tous les fichiers, puis ajoute « ensure wb_shield » en premier dans server.cfg.", 'err')
    end
end)

exports('UpdateInfo', function()
    return { current = U.Current, latest = U.Latest and U.Latest.version or nil, available = U.Latest ~= nil and U.Newer(U.Latest.version, U.Current) or false }
end)

PB.Action('updates.check', 'updates.view', function(ctx)
    U.Check()
    ctx.toast = 'Vérification lancée : rouvre l\'onglet dans quelques secondes.'
    ctx.refresh = false
    return true
end, { rate = 6 })

P.Register('updates.install', 'Installer une mise à jour de Shadow Base et redémarrer le serveur', 'panel', true)
PB.Action('updates.install', 'updates.install', function(ctx)
    U.Install(ctx.actor and ctx.actor.name or 'panel', 60, function(ok, msg) if PB.Notify then PB.Notify(ok and 'success' or 'error', 'Mise à jour', tostring(msg)) end end)
    ctx.toast = 'Installation lancée : suis-la dans la console. Le serveur redémarrera tout seul.'
    ctx.refresh = false
    return true
end, { rate = 2 })

local autoForm = PB.Form and PB.Form.Cfg({ ns = 'updates', id = 'auto', title = 'Installation automatique', perm = 'updates.install', cols = 2, fields = {
    { k = 'auto', type = 'toggle', label = 'Installer et redémarrer tout seul à chaque nouvelle version', default = false, hint = 'Coupé : le serveur prévient seulement (console et staff en ligne) ; tu installes avec « wupdate » quand tu veux. Activé : installation, annonce aux joueurs, puis redémarrage.' },
    { k = 'auto_minutes', type = 'number', label = 'Délai avant le redémarrage quand des joueurs sont en ligne (minutes)', default = 5, min = 1, max = 60, hint = 'Sans personne en ligne : 15 secondes.' },
    { k = 'check_minutes', type = 'number', label = 'Vérifier toutes les (minutes)', default = 10, min = 2, max = 360 },
} }) or nil

PB.Module({
    id = 'updates', label = 'Mises à jour', icon = 'download', group = 'Système', order = 960, perm = 'updates.view', hint = 'Nouvelle version de Shadow Base',
    doc = "## Mises à jour\nShadow Base vérifie toutes les 6 heures si une nouvelle version est publiée. Le fichier est **signé** : une fausse mise à jour est refusée.\n\nPour installer : télécharge le zip, arrête le serveur, remplace les dossiers des ressources **sans écraser** `pb_panel/config.lua` ni `pb_panel/license.key`, puis redémarre. Les tables de la base se mettent à jour seules.",
    view = function(ctx)
        return { tabs = { { id = 'main', label = 'Version', icon = 'download', build = function()
            local L = U.Latest
            local avail = L ~= nil and U.Newer(L.version, U.Current)
            local blocks = {
                PB.B.stats({ { label = 'Installée', value = U.Current, icon = 'cpu' }, { label = 'Dernière publiée', value = L and L.version or '—', icon = 'download' },
                    { label = 'Vérifiée', value = U.Checked > 0 and os.date('%d/%m %H:%M', U.Checked) or 'jamais', icon = 'clock' } }),
            }
            if U.Error then blocks[#blocks + 1] = PB.B.notice('warn', U.Error) end
            if PB.Restart and PB.Restart.CanQuit and not PB.Restart.CanQuit() then
                blocks[#blocks + 1] = PB.B.notice('info', ("Conseil : ajoute la ligne « %s » dans server.cfg. Sans elle, le redémarrage après « wupdate » arrête le serveur directement (txAdmin le relance quand même)."):format(PB.Restart.ACE_LINE), 'Redémarrage')
            end
            if avail then
                local d = U.Delta(L)
                if d then
                    blocks[#blocks + 1] = PB.B.notice('info', ('Version %s disponible (%s). Mise à jour rapide : %d fichier(s) à remplacer. Arrête le serveur, extrais le zip dans resources/ en acceptant de remplacer, puis redémarre. Ta licence et ta config ne bougent pas.'):format(L.version, L.date, tonumber(d.files) or 0), L.title)
                    blocks[#blocks + 1] = PB.B.kv('Mise à jour rapide', { { 'Zip', d.url }, { 'Taille', ('%.1f Mo'):format((tonumber(d.size) or 0) / 1e6) }, { 'Fichiers modifiés', tostring(tonumber(d.files) or 0) }, { 'Empreinte SHA-256', d.sha256 }, { 'Patch notes', L.site or '—' } })
                    if (tonumber(d.removed) or 0) > 0 then blocks[#blocks + 1] = PB.B.notice('warn', ('%d ancien(s) fichier(s) à retirer : lance supprimer-anciens-fichiers.bat, extrait avec le zip.'):format(tonumber(d.removed) or 0)) end
                else
                    blocks[#blocks + 1] = PB.B.notice('info', ('Version %s disponible (%s). Télécharge le zip, arrête le serveur, remplace les ressources sans écraser pb_panel/config.lua ni license.key, puis redémarre.'):format(L.version, L.date), L.title)
                    blocks[#blocks + 1] = PB.B.kv('Téléchargement (gratuit)', { { 'Zip', L.download }, { 'Empreinte SHA-256', L.sha256 }, { 'Patch notes', L.site or '—' } })
                end
                local rows = {}
                for i, n in ipairs(type(L.notes) == 'table' and L.notes or {}) do if i <= 60 then rows[#rows + 1] = { n = tostring(n):sub(1, 300) } end end
                if #rows > 0 then blocks[#blocks + 1] = PB.B.table({ id = 'notes', title = 'Nouveautés', columns = { { k = 'n', label = '' } }, rows = rows }) end
            elseif L then
                blocks[#blocks + 1] = PB.B.notice('info', 'Shadow Base est à jour.')
            end
            local acts = { { action = 'updates.check', label = 'Vérifier maintenant', icon = 'refresh' } }
            if avail then acts[#acts + 1] = { action = 'updates.install', label = 'Installer et redémarrer', icon = 'download', confirm = "Installer la version " .. L.version .. " puis redémarrer le serveur (compte à rebours de 60 s) ?" } end
            blocks[#blocks + 1] = PB.B.actions(acts)
            blocks[#blocks + 1] = PB.B.notice('info', 'Ou dans la console txAdmin : wupdate (installe puis redémarre ; wupdate 300 = redémarrage dans 5 minutes).')
            do   -- (v1.2.97) points de retour
                local rows = {}
                for _, p in ipairs(U.Points()) do
                    local acts = { { action = 'updates.rollback', label = 'Revenir (fichiers)', icon = 'undo', danger = true, payload = { id = p.id } } }
                    if (tonumber(p.db_backup) or 0) > 0 then acts[#acts + 1] = { action = 'updates.rollback', label = 'Revenir (fichiers + base)', icon = 'database', danger = true, payload = { id = p.id, db = true } } end
                    rows[#rows + 1] = { at = os.date('%d/%m/%Y %H:%M', p.at), v = p.from_v .. ' → ' .. p.to_v, by = p.by_name, n = tostring(p.files), db = (tonumber(p.db_backup) or 0) > 0 and 'oui' or 'non', used = (tonumber(p.used) or 0) > 0 and 'oui' or '', actions = acts }
                end
                blocks[#blocks + 1] = PB.B.table({ id = 'points', title = 'Points de retour (avant chaque mise à jour)', columns = { { k = 'at', label = 'Date' }, { k = 'v', label = 'Versions' }, { k = 'by', label = 'Par' }, { k = 'n', label = 'Fichiers gardés' }, { k = 'db', label = 'Base sauvegardée' }, { k = 'used', label = 'Utilisé' } },
                    rows = rows, empty = "Aucun point de retour : il s'en crée un à chaque installation (wupdate). Console : wrollback." })
            end
            if autoForm then blocks[#blocks + 1] = autoForm(ctx) end
            return blocks
        end } } }
    end,
})
