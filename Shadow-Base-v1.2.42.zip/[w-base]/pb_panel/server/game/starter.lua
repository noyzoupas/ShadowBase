-- Pack de base : installe d'un coup de quoi faire tourner un serveur neuf (entreprises, gangs, supérettes, vêtements, concession, quincaillerie,
-- garages, distributeurs, stations, filières, braquages, territoires). Installation automatique au premier lancement, relançable depuis le panel.
-- Rien n'est jamais écrasé : ce qui existe déjà (même identifiant ou même nom) est laissé tel quel. Les coordonnées sont des points de la carte
-- standard, à vérifier en jeu (panel « Ma position » pour corriger).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local S = {}
G.Starter = S

P.Register('starter.install', 'Installer ou compléter le pack de base', 'starter', true)
PB.Cfg.Define('starter', { installed = false, auto = true })

local function now() return os.time() end
local function jlist(v) if type(v) == 'table' then return v end return {} end

-- Données -----------------------------------------------------------------------------------------------------------------------------
local BIZ = {
    { id = 'lspd', tpl = 'police', label = 'Police de Los Santos', hq = { 441.0, -981.0, 30.7 }, hiring = 0 },
    { id = 'sheriff', tpl = 'police', label = 'Shérif du comté de Blaine', hq = { 1853.0, 3689.0, 34.2 }, hiring = 0 },
    { id = 'ems', tpl = 'ems', label = 'Secours de Los Santos', hq = { 311.0, -593.0, 43.3 }, hiring = 0 },
    { id = 'mecano', tpl = 'garage', label = 'Garage Los Santos Customs', hq = { -347.3, -133.0, 39.0 }, hiring = 1 },
    { id = 'taxi', tpl = 'generic', label = 'Taxi Downtown Cab', hq = { 903.0, -170.0, 74.1 }, hiring = 1, desc = 'Transport de passagers dans toute la ville.' },
    { id = 'burgershot', tpl = 'generic', label = 'Burger Shot', hq = { -1192.0, -884.0, 13.9 }, hiring = 1, desc = 'Restauration rapide : caisse et factures.' },
    { id = 'bean', tpl = 'generic', label = 'Bean Machine', hq = { 280.0, -963.0, 29.4 }, hiring = 1, desc = 'Café et pâtisseries.' },
    { id = 'bahamas', tpl = 'generic', label = 'Bahama Mamas', hq = { -1388.0, -586.0, 30.2 }, hiring = 1, desc = 'Boîte de nuit : bar, entrées et soirées.' },
}

local GANGS = { 'ballas|Ballas|#b58cff', 'families|Families|#7be0a4', 'vagos|Vagos|#ffb457', 'lostmc|Lost MC|#ff9d9d', 'marabunta|Marabunta|#6fb4ff', 'triads|Triades|#ff6b7d' }

local FOOD = {
    { name = 'water', label = "Bouteille d'eau", price = 3, hunger = 0, thirst = 35, stress = 0, category = 'Boissons' },
    { name = 'soda', label = 'Soda', price = 4, hunger = 0, thirst = 25, stress = -3, category = 'Boissons' },
    { name = 'coffee', label = 'Café', price = 4, hunger = 0, thirst = 15, stress = -5, category = 'Boissons' },
    { name = 'sandwich', label = 'Sandwich', price = 7, hunger = 35, thirst = 0, stress = 0, category = 'Nourriture' },
    { name = 'burger', label = 'Burger', price = 9, hunger = 50, thirst = -5, stress = -4, category = 'Nourriture' },
    { name = 'chips', label = 'Paquet de chips', price = 3, hunger = 18, thirst = -4, stress = -2, category = 'Nourriture' },
    { name = 'bandage', label = 'Bandage', price = 25, hunger = 0, thirst = 0, stress = 0, category = 'Soins' },
}
local TOOLS = {
    { name = 'lockpick', label = 'Crochet', price = 120, hunger = 0, thirst = 0, stress = 0, category = 'Outils' },
    { name = 'repair_kit', label = 'Kit de réparation', price = 450, hunger = 0, thirst = 0, stress = 0, category = 'Outils' },
    { name = 'rope', label = 'Corde', price = 40, hunger = 0, thirst = 0, stress = 0, category = 'Outils' },
    { name = 'phone', label = 'Téléphone', price = 350, hunger = 0, thirst = 0, stress = 0, category = 'Outils' },
}
local CARS = {
    { model = 'panto', label = 'Benefactor Panto', price = 6500, category = 'Citadines' }, { model = 'asea', label = 'Declasse Asea', price = 9000, category = 'Berlines' },
    { model = 'premier', label = 'Declasse Premier', price = 11000, category = 'Berlines' }, { model = 'blista', label = 'Dinka Blista', price = 15000, category = 'Citadines' },
    { model = 'ruiner', label = 'Imponte Ruiner', price = 19000, category = 'Sportives' }, { model = 'sultan', label = 'Karin Sultan', price = 32000, category = 'Sportives' },
    { model = 'buffalo', label = 'Bravado Buffalo', price = 38000, category = 'Sportives' }, { model = 'sentinel', label = 'Ubermacht Sentinel', price = 42000, category = 'Sportives' },
    { model = 'bison', label = 'Bravado Bison', price = 26000, category = 'Utilitaires' }, { model = 'rebel2', label = 'Karin Rebel', price = 24000, category = 'Utilitaires' },
    { model = 'sanchez', label = 'Maibatsu Sanchez', price = 9000, category = 'Motos' }, { model = 'bati', label = 'Pegassi Bati 801', price = 20000, category = 'Motos' },
}

-- {label, x, y, z, h}
local STORES = {
    { 'Supérette 24/7 — Strawberry', 25.7, -1347.3, 29.5, 270 }, { 'Supérette LTD — Davis', -47.0, -1757.5, 29.4, 50 }, { 'Supérette LTD — Little Seoul', -707.4, -914.3, 19.2, 90 },
    { 'Supérette LTD — Mirror Park', 1163.4, -323.8, 69.2, 100 }, { 'Supérette LTD — Rockford Hills', -1820.5, 792.5, 138.1, 130 }, { 'Supérette 24/7 — Banham Canyon', -3039.5, 585.0, 7.9, 15 },
    { 'Supérette 24/7 — Chumash', -3242.0, 1000.0, 12.8, 350 }, { 'Supérette 24/7 — Sandy Shores', 1961.1, 3740.7, 32.3, 300 }, { 'Supérette 24/7 — Grapeseed', 1698.4, 4924.4, 42.1, 325 },
    { 'Supérette 24/7 — Paleto Bay', 1728.7, 6414.4, 35.0, 245 },
}
local CLOTHES = {
    { 'Binco — Strawberry', 75.3, -1392.9, 29.4, 270, 40 }, { 'Binco — Legion Square', 425.6, -806.2, 29.5, 90, 40 }, { 'Suburban — Vinewood', 127.4, -223.4, 54.6, 70, 90 },
    { 'Ponsonbys — Rockford Hills', -167.9, -299.0, 39.7, 250, 200 }, { 'Binco — Sandy Shores', 1196.7, 2710.2, 38.2, 180, 40 }, { 'Binco — Paleto Bay', 4.9, 6512.5, 31.9, 130, 40 },
}

local GARAGES = {   -- id, label, kind, x, y, z, sx, sy, sz, sh, biz
    { 'sandy', 'Garage public — Sandy Shores', 'public', 1737.0, 3718.0, 34.1, 1730.0, 3714.0, 34.1, 20.0, '' },
    { 'paleto', 'Garage public — Paleto Bay', 'public', -773.0, 5598.0, 33.6, -768.0, 5592.0, 33.6, 170.0, '' },
    { 'vespucci', 'Garage public — Vespucci', 'public', -1183.0, -1498.0, 4.4, -1178.0, -1503.0, 4.4, 305.0, '' },
    { 'lspd_gar', 'Garage de la police', 'biz', 454.6, -1017.4, 28.4, 438.4, -1018.3, 27.7, 90.0, 'lspd' },
    { 'ems_gar', 'Garage des secours', 'biz', 340.4, -584.3, 28.8, 335.0, -579.0, 28.8, 340.0, 'ems' },
    { 'mecano_gar', 'Garage du mécano', 'biz', -341.0, -136.0, 39.0, -335.0, -141.0, 39.0, 70.0, 'mecano' },
}
local ATMS = {   -- id, label, x, y, z
    { 'atm_legion', 'Distributeur — Legion Square', 147.6, -1035.8, 29.3 }, { 'atm_pillbox', 'Distributeur — Pillbox Hill', 236.4, 217.5, 106.3 }, { 'atm_vespucci', 'Distributeur — Vespucci', -821.6, -1081.9, 11.1 },
    { 'atm_strawberry', 'Distributeur — Strawberry', 289.0, -1256.8, 29.4 }, { 'atm_mirror', 'Distributeur — Mirror Park', 1153.7, -326.8, 69.2 }, { 'atm_burton', 'Distributeur — Burton', -57.7, -92.3, 57.8 },
    { 'atm_sandy', 'Distributeur — Sandy Shores', 1968.1, 3743.6, 32.3 }, { 'atm_grapeseed', 'Distributeur — Grapeseed', 1686.7, 4815.8, 42.0 }, { 'atm_paleto', 'Distributeur — Paleto Bay', -386.7, 6045.7, 31.5 },
    { 'atm_palomino', 'Distributeur — Palomino', 2558.8, 351.0, 108.6 },
}
local STATIONS = {
    { id = 'davis', label = 'Station Davis', x = -70.2, y = -1761.8, z = 29.5, price = 0 }, { id = 'vinewood', label = 'Station Vinewood', x = 620.8, y = 269.1, z = 103.1, price = 0 },
    { id = 'rockford', label = 'Station Rockford Hills', x = -1437.0, y = -276.7, z = 46.2, price = 0 }, { id = 'chumash', label = 'Station Chumash', x = -2096.2, y = -320.3, z = 13.2, price = 0 },
    { id = 'harmony', label = 'Station Harmony', x = 263.9, y = 2606.5, z = 44.9, price = 0 }, { id = 'grapeseed', label = 'Station Grapeseed', x = 1687.2, y = 4929.4, z = 42.1, price = 0 },
}
local CHAIN = {   -- filière de recyclage (légale)
    { id = 'scrap_yard', kind = 'harvest', label = 'Casse automobile', x = 2351.0, y = 3132.0, z = 48.2, radius = 8, item_in = '', qty_in = 0, item_out = 'scrap_metal', qty_out = 4, price = 0, time = 8, alert = 0 },
    { id = 'foundry', kind = 'process', label = 'Fonderie', x = 1085.0, y = -1998.0, z = 30.9, radius = 4, item_in = 'scrap_metal', qty_in = 4, item_out = 'copper_bar', qty_out = 2, price = 0, time = 10, alert = 0 },
    { id = 'metal_buyer', kind = 'sell', label = 'Ferrailleur', x = 1695.0, y = 3280.0, z = 41.1, radius = 4, item_in = 'copper_bar', qty_in = 1, item_out = '', qty_out = 0, price = 60, time = 5, alert = 0 },
}
local HEISTS = {
    { id = 'store_rob2', label = 'Braquage de supérette (Davis)', x = -47.0, y = -1757.5, z = 29.4, radius = 4, min = 700, max = 1900, time = 30, cooldown = 30, police = 0, need = '', alert = 100 },
    { id = 'store_rob3', label = 'Braquage de supérette (Sandy)', x = 1961.1, y = 3740.7, z = 32.3, radius = 4, min = 600, max = 1600, time = 30, cooldown = 30, police = 0, need = '', alert = 100 },
    { id = 'fleeca', label = 'Braquage de banque Fleeca', x = 311.2, y = -284.5, z = 54.2, radius = 4, min = 15000, max = 30000, time = 90, cooldown = 180, police = 2, need = 'lockpick', alert = 100 },
}
local LAUNDER = { { id = 'carwash', label = 'Station de lavage', x = 25.4, y = -1391.9, z = 29.3, rate = 65, max = 15000, time = 12 } }
local ZONES = {
    { id = 'rancho', label = 'Rancho', x = 400.0, y = -1790.0, z = 29.0, radius = 45, income = 350, time = 90, cooldown = 60, min = 1 },
    { id = 'davis', label = 'Davis', x = 85.0, y = -1730.0, z = 29.1, radius = 45, income = 350, time = 90, cooldown = 60, min = 1 },
    { id = 'elburro', label = 'El Burro Heights', x = 1380.0, y = -1530.0, z = 57.0, radius = 45, income = 300, time = 90, cooldown = 60, min = 1 },
    { id = 'sandyzone', label = 'Sandy Shores', x = 1900.0, y = 3790.0, z = 32.5, radius = 50, income = 250, time = 90, cooldown = 60, min = 1 },
}
local ITEMS = {   -- name, label, weight, stack, kind, usable, description
    { 'scrap_metal', 'Ferraille', 800, 40, 'misc', 0, 'À fondre à la fonderie.' }, { 'copper_bar', 'Lingot de cuivre', 1500, 20, 'misc', 0, 'À revendre au ferrailleur.' },
}

-- Installation (chaque fonction renvoie le nombre d'éléments ajoutés ; rien n'est écrasé) -------------------------------------------------
local function mergeById(ns, key, rows)
    local cur = jlist(PB.Cfg.Get(ns, key, {}))
    local have, added = {}, 0
    for _, r in ipairs(cur) do have[type(r) == 'table' and r.id or tostring(r):match('^([^|]+)')] = true end
    local out = {}
    for _, r in ipairs(cur) do out[#out + 1] = r end
    for _, r in ipairs(rows) do
        local id = type(r) == 'table' and r.id or tostring(r):match('^([^|]+)')
        if not have[id] then out[#out + 1] = r have[id] = true added = added + 1 end
    end
    if added > 0 then PB.Cfg.Set(ns, key, out, 0, 'Pack de base') end
    return added
end

function S.Items()
    local n = 0
    for _, d in ipairs(ITEMS) do
        if not DB.one('SELECT name FROM pb_inv_items WHERE name = ?', { d[1] }) then
            DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, ?, ?, ?, ?)', d) n = n + 1
        end
    end
    return n
end

function S.Business()
    local n, T = 0, G.Biz and G.Biz.Templates or {}
    for _, b in ipairs(BIZ) do
        local t = T[b.tpl]
        if t and not DB.one('SELECT id FROM pb_biz WHERE id = ?', { b.id }) then
            DB.exec('INSERT INTO pb_biz (id, label, kind, color, icon, pay_from, enabled, hx, hy, hz, hiring, description, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?)',
                { b.id, b.label, t.kind, t.color, t.icon, 'free', b.hq[1], b.hq[2], b.hq[3], b.hiring, b.desc or t.description, now() })
            for _, g in ipairs(t.grades) do
                DB.exec('INSERT INTO pb_biz_grades (biz_id, grade, label, salary, boss, perms) VALUES (?, ?, ?, ?, ?, ?)', { b.id, g[1], g[2], g[3], g[4] and 1 or 0, g[5] })
            end
            n = n + 1
        end
    end
    return n
end

function S.Gangs() return mergeById('tags', 'gangs', GANGS) end

local function addShop(kind, label, x, y, z, h, sprite, color, price, catalog, opts, spawn)
    if DB.one('SELECT id FROM pb_shops WHERE label = ?', { label }) then return 0 end
    local cols, qs, params = { 'kind', 'label', 'x', 'y', 'z', 'h', 'sprite', 'color', 'blip', 'price', 'catalog', 'enabled', 'opts' }, {}, { kind, label, x, y, z, h, sprite, color, 1, price, PB.Json(catalog), 1, PB.Json(opts) }
    if spawn then cols[#cols + 1] = 'spawn' params[#params + 1] = PB.Json(spawn) end
    for _ = 1, #cols do qs[#qs + 1] = '?' end
    DB.exec('INSERT INTO pb_shops (' .. table.concat(cols, ', ') .. ') VALUES (' .. table.concat(qs, ', ') .. ')', params)
    return 1
end

function S.Shops()
    local n = 0
    for _, s in ipairs(STORES) do
        n = n + addShop('store', s[1], s[2], s[3], s[4], s[5], 52, 2, 0, FOOD, { tagline = 'Ouvert jour et nuit', accent = '#7be0a4', pay_mode = 'both', max_qty = 10, npc_on = true, npc_model = 'mp_m_shopkeep_01' })
    end
    for _, s in ipairs(CLOTHES) do
        n = n + addShop('clothes', s[1], s[2], s[3], s[4], s[5], 73, 47, s[6], {}, { tagline = 'Essaie, choisis, repars habillé', accent = '#b58cff', pay_mode = 'both' })
    end
    n = n + addShop('store', 'Quincaillerie — Strawberry', 46.0, -1749.3, 29.6, 50, 402, 17, 0, TOOLS, { tagline = 'Outils et petit matériel', accent = '#ffb457', pay_mode = 'both', max_qty = 5 })
    n = n + addShop('dealer', 'Premium Deluxe Motorsport', -56.8, -1097.0, 26.4, 28, 225, 3, 0, CARS, { tagline = 'Le choix du connaisseur', accent = '#6fb4ff', pay_mode = 'both' }, { x = -47.5, y = -1081.5, z = 26.7, h = 70.0 })
    return n
end

function S.Garages()
    local n = 0
    for _, g in ipairs(GARAGES) do
        if not DB.one('SELECT id FROM pb_garages WHERE id = ?', { g[1] }) and (g[11] == '' or DB.one('SELECT id FROM pb_biz WHERE id = ?', { g[11] })) then
            DB.exec('INSERT INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh, biz) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', g) n = n + 1
        end
    end
    return n
end

function S.Banks()
    local n = 0
    for _, a in ipairs(ATMS) do
        if not DB.one('SELECT id FROM pb_bank_points WHERE id = ?', { a[1] }) then
            DB.exec("INSERT INTO pb_bank_points (id, kind, label, x, y, z) VALUES (?, 'atm', ?, ?, ?, ?)", a) n = n + 1
        end
    end
    return n
end

function S.Fuel() if G.Fuel and G.Fuel.MergeStations then return G.Fuel.MergeStations(STATIONS) end return mergeById('fuel', 'stations', STATIONS) end   -- (v1.2.42) sans doublon à moins de 30 m
function S.Crime() return mergeById('crime', 'chain', CHAIN) + mergeById('crime', 'heists', HEISTS) + mergeById('crime', 'launder', LAUNDER) end
function S.Zones() return mergeById('territories', 'zones', ZONES) end

local PARTS = {
    { 'items', 'Objets (ferraille, lingots)', S.Items }, { 'biz', 'Entreprises (police, shérif, secours, mécano, taxi, restauration, boîte)', S.Business },
    { 'gangs', 'Gangs (6)', S.Gangs }, { 'shops', 'Magasins (supérettes, vêtements, quincaillerie, concession)', S.Shops },
    { 'garages', 'Garages publics et d\'entreprise', S.Garages }, { 'banks', 'Distributeurs', S.Banks }, { 'fuel', 'Stations-service', S.Fuel },
    { 'crime', 'Filière de recyclage, braquages, laverie', S.Crime }, { 'zones', 'Territoires', S.Zones },
}
S.Parts = PARTS

-- Renvoie { part = ajoutés }
function S.Install()
    local out = {}
    for _, p in ipairs(PARTS) do
        local ok, n = pcall(p[3])
        if ok then out[p[1]] = n or 0 else out[p[1]] = 0 PB.Err('pack de base (' .. p[1] .. ') : ' .. tostring(n)) end
    end
    PB.Cfg.Set('starter', 'installed', true, 0, 'Pack de base')
    if G.PushConfig then G.PushConfig() end
    return out
end
local function total(t) local n = 0 for _, v in pairs(t) do n = n + v end return n end

PB.OnReady(function()
    CreateThread(function()
        Wait(2500)
        if GetConvar('pb_starter', 'on') ~= 'off' and PB.Cfg.Get('starter', 'auto', true) and not PB.Cfg.Get('starter', 'installed', false) then
            local r = S.Install()
            print(('^2[pb_panel]^7 Pack de base installé : %d élément(s) ajouté(s). Vérifie les positions en jeu (panel › Pack de base).'):format(total(r)))
        end
    end)
end)

PB.Action('starter.install', 'starter.install', function(ctx)
    local r = S.Install()
    local n = total(r)
    ctx.audit('config', 'starter.install', 'pack', nil, r)
    ctx.toast = n > 0 and (n .. ' élément(s) ajouté(s). Rien de ce qui existait n\'a été modifié.') or 'Tout est déjà en place : rien à ajouter.'
    return true
end)

local settings = Form.Cfg({ ns = 'starter', id = 'settings', title = 'Pack de base', perm = 'starter.install', fields = {
    { k = 'auto', type = 'toggle', label = "Installer automatiquement au premier lancement", default = true, hint = "Une seule fois, sur une base vide. Ensuite, utilise le bouton de l'onglet Contenu." },
} })

PB.Module({
    id = 'starter', label = 'Pack de base', icon = 'box', group = 'Serveur', order = 146, perm = 'starter.install', hint = 'Contenu de départ du serveur',
    caps = function() return PB.Capsify({
        { 'Contenu fourni', 'ok', "Entreprises, gangs, supérettes, vêtements, concession, quincaillerie, garages, distributeurs, stations, filières, braquages, territoires." },
        { 'Installation sans écrasement', 'ok', "Ce qui existe déjà (même identifiant ou même nom) n'est jamais modifié ni supprimé." },
        { 'Coordonnées', 'partial', "Points de la carte standard donnés de mémoire : certains peuvent tomber à côté d'un mur. Vérifie-les en jeu et corrige avec « Ma position »." },
        { 'Modèles de véhicules et de PNJ', 'partial', "Noms standards du jeu non testés dans un vrai serveur : un modèle inconnu se corrige dans le magasin concerné." },
    }) end,
    doc = "## Pack de base\nInstalle un serveur de départ complet. Relançable sans risque : seul ce qui manque est ajouté.",
    view = function(ctx) return { tabs = {
        { id = 'content', label = 'Contenu', icon = 'box', build = function()
            local rows = {}
            for _, p in ipairs(PARTS) do rows[#rows + 1] = { part = p[2] } end
            local blocks = {
                B.notice(PB.Cfg.Get('starter', 'installed', false) and 'ok' or 'info', PB.Cfg.Get('starter', 'installed', false) and 'Le pack de base a été installé. Tu peux le relancer pour compléter ce qui manque.' or "Le pack n'est pas encore installé."),
                B.table({ id = 'sp', title = 'Ce que le pack ajoute', columns = { { k = 'part', label = 'Élément' } }, rows = rows }),
            }
            if ctx.has('starter.install') then blocks[#blocks + 1] = B.actions({ { action = 'starter.install', label = 'Installer / compléter le pack', icon = 'download' } }) end
            return blocks
        end },
        { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
    } } end,
})

PB.SelfTest.Add('pack de base', function(R)
    if not PB.Cfg.Get('starter', 'installed', false) then R.warn('pack de base', "pas installé", "Panel › Pack de base › Installer (entreprises, magasins, garages… de départ). Ignore si tu as tout créé toi-même.") return end
    if (tonumber(DB.scalar('SELECT COUNT(*) FROM pb_biz')) or 0) == 0 then R.warn('pack de base', 'aucune entreprise', 'Relance le pack de base.') end
    if (tonumber(DB.scalar("SELECT COUNT(*) FROM pb_shops WHERE kind = 'store'")) or 0) == 0 then R.warn('pack de base', 'aucune supérette', 'Relance le pack de base.') end
end)
