@echo off
chcp 65001 >nul
cd /d "%~dp0"
del /f /q "[w-base]\pb_panel\client\pause.lua" 2>nul
del /f /q "[w-base]\pb_panel\web\game\pause.js" 2>nul
echo Anciens fichiers supprimes.
pause