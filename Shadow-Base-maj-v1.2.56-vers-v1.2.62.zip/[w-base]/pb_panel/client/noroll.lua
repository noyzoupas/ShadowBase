-- Pas de roulades : la roulade de combat (Espace pendant qu'on vise ou avec une arme en main) est désactivée.
-- Réglable : « setr pb_noroll 0 » dans server.cfg pour la rétablir.
CreateThread(function()
    while true do
        if GetConvarInt('pb_noroll', 1) ~= 1 then Wait(5000)
        else
            local ped = PlayerPedId()
            local sleep = 250
            if not IsPedInAnyVehicle(ped, false) and not IsPedSwimming(ped) then
                local armed = IsPedArmed(ped, 4) or IsPedArmed(ped, 2)
                if armed or IsPlayerFreeAiming(PlayerId()) or IsPedInMeleeCombat(ped) then
                    sleep = 0
                    DisableControlAction(0, 22, true)     -- saut : sert aussi de roulade quand on vise ou qu'on est armé
                end
            end
            Wait(sleep)
        end
    end
end)
