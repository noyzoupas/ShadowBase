-- Créateur de personnage, application de l'apparence, écran de mort. Les règles viennent du panel, le serveur valide chaque envoi.

local G = PBG

local function loadModel(name)
    local h = GetHashKey(name)
    RequestModel(h)
    local t = GetGameTimer()
    while not HasModelLoaded(h) and GetGameTimer() - t < 6000 do Wait(10) end
    return h
end
G.loadModel = loadModel

-- Apparence ------------------------------------------------------------------------------------------------------------------------
local OVERLAY_COLOR = { [1] = 1, [2] = 1, [10] = 1, [5] = 2, [8] = 2 }   -- barbe, sourcils, torse : teinte cheveux ; blush, rouge à lèvres : teinte maquillage
local COMP_ORDER = { 1, 3, 4, 5, 6, 7, 8, 9, 10, 11 }

-- target (facultatif) : un autre ped à habiller (ex. les personnages de l'écran d'entrée) ; sans target, le joueur
function G.applyAppearance(a, setModel, target)
    if type(a) ~= 'table' or not a.head then return end
    -- ped de service staff : on garde le ped ; la tenue / coiffure sera remise en quittant le service
    if G.staffPed and not target then G.appearance = a return end
    local ped = target or PlayerPedId()
    if setModel and not target and a.model and GetEntityModel(ped) ~= GetHashKey(a.model) then
        local h = loadModel(a.model)
        SetPlayerModel(PlayerId(), h)
        SetModelAsNoLongerNeeded(h)
        ped = PlayerPedId()
    end
    SetPedDefaultComponentVariation(ped)
    SetPedHeadBlendData(ped, a.head.mother, a.head.father, a.head.third or 0, a.head.mother, a.head.father, a.head.third or 0, a.head.shape + 0.0, a.head.skin + 0.0, (a.head.mix or 0) + 0.0, false)
    for i = 1, 20 do SetPedFaceFeature(ped, i - 1, (a.face[i] or 0.0) + 0.0) end
    SetPedComponentVariation(ped, 2, a.hair.style, 0, 2)
    SetPedHairColor(ped, a.hair.color, a.hair.highlight)
    SetPedEyeColor(ped, a.eye)
    for i = 1, 13 do
        local o = a.ov[i]
        if o then
            SetPedHeadOverlay(ped, i - 1, o.s, o.o + 0.0)
            local ct = OVERLAY_COLOR[i - 1]
            if ct and o.s ~= 255 then SetPedHeadOverlayColor(ped, i - 1, ct, o.c, o.c) end
        end
    end
    for _, comp in ipairs(COMP_ORDER) do
        local c = a.comps[comp + 1]
        if c then SetPedComponentVariation(ped, comp, c.d, c.t, 2) end
    end
    for id = 0, 7 do if id == 0 or id == 1 or id == 2 or id == 6 or id == 7 then ClearPedProp(ped, id) end end
    for _, pr in ipairs(a.props or {}) do
        if pr.d >= 0 then SetPedPropIndex(ped, pr.id, pr.d, pr.t, true) end
    end
    ClearPedDecorations(ped)
    for _, t in ipairs(a.tattoos or {}) do AddPedDecorationFromHashes(ped, t.c, t.o) end
end

-- le modèle est remis à zéro à chaque (re)apparition : on réapplique l'apparence enregistrée
AddEventHandler('playerSpawned', function()
    if G.appearance and G.begun and not G.creating then
        CreateThread(function() Wait(600) G.applyAppearance(G.appearance, true) end)
    end
end)
exports('ApplyAppearance', function(a) G.applyAppearance(a, true) end)
exports('GetAppearance', function() return G.appearance end)

-- Créateur --------------------------------------------------------------------------------------------------------------------------
local cam, camMode = nil, 'face'
local CAMS = { face = { 0.0, 0.85, 0.66, 0.66 }, body = { 0.0, 2.4, 0.2, 0.15 }, feet = { 0.0, 1.5, -0.55, -0.6 } }
local camZoom, roomH = 1.0, nil   -- pendant le créateur : caméra fixe, seul le personnage tourne

local function setCam(mode)
    if G.flying then ClearFocus() G.flying = false end
    camMode = mode or camMode
    local ped = PlayerPedId()
    local c = CAMS[camMode] or CAMS.face
    local pos = GetOffsetFromEntityInWorldCoords(ped, c[1], c[2] * camZoom, c[3])
    local tgt = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.0, c[4])
    if G.creating and roomH then
        local p, a = GetEntityCoords(ped), math.rad(roomH)
        local fx, fy, d = -math.sin(a), math.cos(a), c[2] * camZoom
        local rx, ry = fy * -1.0, fx          -- droite de la caméra
        local side = d * 0.27                  -- le panneau est à gauche : la caméra vise à gauche du personnage
        pos = vector3(p.x + fx * d - rx * side, p.y + fy * d - ry * side, p.z + c[3])
        tgt = vector3(p.x - rx * side, p.y - ry * side, p.z + c[4])
    end
    if not cam then
        cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        RenderScriptCams(true, true, 400, true, true)
    end
    SetCamCoord(cam, pos.x, pos.y, pos.z)
    PointCamAtCoord(cam, tgt.x, tgt.y, tgt.z)
    SetCamActive(cam, true)
end

local function limits()
    local ped = PlayerPedId()
    local L = { comps = {}, props = {}, overlays = {}, hairColors = GetNumHairColors(), makeupColors = GetNumMakeupColors(), hairRgb = {}, makeupRgb = {} }
    -- (v1.2.60) les vraies couleurs du jeu : une pastille rose donne du rose
    for i = 0, L.hairColors - 1 do local r, g, b = GetPedHairRgbColor(i) L.hairRgb[i + 1] = ('#%02x%02x%02x'):format(r, g, b) end
    for i = 0, L.makeupColors - 1 do local r, g, b = GetPedMakeupRgbColor(i) L.makeupRgb[i + 1] = ('#%02x%02x%02x'):format(r, g, b) end
    for i = 0, 11 do L.comps[i + 1] = GetNumberOfPedDrawableVariations(ped, i) end
    for _, id in ipairs({ 0, 1, 2, 6, 7 }) do L.props[tostring(id)] = GetNumberOfPedPropDrawableVariations(ped, id) end
    for i = 0, 12 do L.overlays[i + 1] = GetPedHeadOverlayNum(i) end
    return L
end

-- Survol du point de départ choisi : la caméra se déplace au-dessus de l'endroit (le serveur ne reçoit que l'identifiant à la validation).
local function flyTo(p)
    local x, y, z = p.x + 0.0, p.y + 0.0, p.z + 0.0
    G.flying = true
    SetFocusPosAndVel(x, y, z, 0.0, 0.0, 0.0)
    RequestCollisionAtCoord(x, y, z)
    local c2 = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', x, y - 48.0, z + 26.0, -22.0, 0.0, (p.h or 0) + 0.0, 55.0, true, 2)
    PointCamAtCoord(c2, x, y, z + 4.0)
    if cam then
        SetCamActiveWithInterp(c2, cam, 1400, 1, 1)
        local old = cam
        CreateThread(function() Wait(1500) DestroyCam(old, false) end)
    else
        SetCamActive(c2, true) RenderScriptCams(true, true, 800, true, true)
    end
    cam = c2
end

G.setCam, G.limits = setCam, limits
function G.camOff() if cam then RenderScriptCams(false, true, 300, true, true) DestroyCam(cam, false) cam = nil end end

-- Salle d'identité : le choix homme / femme se fait entre deux personnages debout, puis le créateur y reste
local room, pickPeds = nil, {}
local PICK = { m = { model = 'mp_m_freemode_01', comps = { [11] = { 5, 0 }, [3] = { 5, 0 }, [8] = { 15, 0 }, [4] = { 1, 0 }, [6] = { 1, 0 } } },
    f = { model = 'mp_f_freemode_01', comps = { [11] = { 5, 0 }, [3] = { 4, 0 }, [8] = { 14, 0 }, [4] = { 0, 0 }, [6] = { 1, 0 } } } }
local function roomOf()
    local r = (G.cfg.uida or {}).room
    if type(r) ~= 'table' or not tonumber(r.x) or tonumber(r.x) == 0 then r = { x = 402.92, y = -996.72, z = -100.0, h = 180.0 } end
    return { x = r.x + 0.0, y = r.y + 0.0, z = r.z + 0.0, h = (r.h or 180.0) + 0.0 }
end
-- hauteur où poser un personnage sur le sol de la salle
local function floorZ(x, y, z)
    local ok, g = GetGroundZFor_3dCoord(x, y, z + 2.0, false)
    return (ok and g or z) + 1.0
end
local function clearPick()
    for k, p in pairs(pickPeds) do if DoesEntityExist(p) then DeleteEntity(p) end pickPeds[k] = nil end
end
local function showPick()
    clearPick()
    local r = room
    local a = math.rad(r.h)
    local fx, fy = -math.sin(a), math.cos(a)   -- devant les personnages, vers la caméra
    local rx, ry = -fy, fx                     -- droite de la caméra
    for k, side in pairs({ m = -1.05, f = 1.05 }) do
        local d = PICK[k]
        local h = loadModel(d.model)
        local x, y = r.x + rx * side, r.y + ry * side
        local ped = CreatePed(4, h, x, y, floorZ(x, y, r.z) - 1.0, r.h, false, false)   -- CreatePed pose les pieds à cette hauteur, floorZ donne celle du centre du corps
        SetModelAsNoLongerNeeded(h)
        SetPedDefaultComponentVariation(ped)
        SetPedHeadBlendData(ped, k == 'm' and 0 or 21, k == 'm' and 0 or 21, 0, k == 'm' and 0 or 21, k == 'm' and 0 or 21, 0, 0.5, 0.5, 0.0, false)
        for id, v in pairs(d.comps) do SetPedComponentVariation(ped, id, v[1], v[2], 2) end
        SetEntityInvincible(ped, true) SetBlockingOfNonTemporaryEvents(ped, true) FreezeEntityPosition(ped, true)
        pickPeds[k] = ped
    end
    SetEntityVisible(PlayerPedId(), false, false)
    local cz = floorZ(r.x, r.y, r.z)
    if not cam then cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true) RenderScriptCams(true, false, 0, true, true) end
    SetCamCoord(cam, r.x + fx * 3.5, r.y + fy * 3.5, cz + 0.1)
    PointCamAtCoord(cam, r.x, r.y, cz - 0.05)
    SetCamFov(cam, 50.0)
    SetCamActive(cam, true)
end
G.nui['creator.room'] = function(d)
    if not G.creating or not room then return {} end
    if d.on then showPick() return {} end
    clearPick()
    if type(d.appearance) == 'table' then G.applyAppearance(d.appearance, true) end
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true) SetEntityVisible(ped, true, false)
    SetEntityHeading(ped, room.h)
    return limits()
end
G.nui['creator.zoom'] = function(d)
    if G.creating or G.wardrobe then camZoom = math.max(0.55, math.min(1.8, camZoom + (tonumber(d.d) or 0) * 0.08)) setCam(camMode) end
    return {}
end
function G.camZoomReset() camZoom = 1.0 end
G.nui['creator.recenter'] = function()
    if G.creating and room then camZoom = 1.0 SetEntityHeading(PlayerPedId(), room.h) setCam(camMode) end
    return {}
end

function G.startCreator()
    G.creating, G.hidden = true, true
    DoScreenFadeOut(300) Wait(450)
    pcall(ShutdownLoadingScreen) if ShutdownLoadingScreenNui then pcall(ShutdownLoadingScreenNui) end
    room = roomOf()
    roomH, camZoom = room.h, 1.0
    local ped = PlayerPedId()
    local c = vector3(room.x, room.y, floorZ(room.x, room.y, room.z))
    G.applyAppearance({ model = 'mp_m_freemode_01', head = { mother = 21, father = 0, shape = 0.5, skin = 0.5 }, face = (function() local t = {} for i = 1, 20 do t[i] = 0.0 end return t end)(),
        hair = { style = 0, color = 0, highlight = 0 }, eye = 0, ov = (function() local t = {} for i = 1, 13 do t[i] = { s = 255, o = 1.0, c = 0 } end return t end)(),
        comps = (function() local t = {} for i = 1, 12 do t[i] = { d = 0, t = 0 } end return t end)(), props = {} }, true)
    ped = PlayerPedId()
    if G.LoadScene then G.LoadScene(room.x, room.y, room.z + 1.0) end
    c = vector3(room.x, room.y, floorZ(room.x, room.y, room.z))
    SetEntityCoordsNoOffset(ped, c.x, c.y, c.z, false, false, false)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetEntityHeading(ped, room.h)
    SetEntityVisible(ped, true, false)
    setCam('face')
    RequestStreamedTextureDict('char_creator_portraits', false)   -- portraits des parents (https://nui-img/char_creator_portraits/…)
    G.focus(true)
    G.send('creator.open', { cfg = G.cfg.character or {}, limits = limits(), brand = G.cfg.brand, spawn = G.pickSpawn })
    Wait(250)
    DoScreenFadeIn(500)
    CreateThread(function()
        while G.creating do DisableAllControlActions(0) Wait(0) end
    end)
end

local function endCreator(spawn, name)
    -- l'écran « Bonjour … » couvre l'arrivée : le décor se charge derrière
    G.send('arrive.open', { name = name or '' })
    Wait(300)
    G.send('creator.close', {})
    clearPick()
    roomH = nil
    SetStreamedTextureDictAsNoLongerNeeded('char_creator_portraits')
    if cam then RenderScriptCams(false, false, 0, true, true) DestroyCam(cam, false) cam = nil end
    local ped = PlayerPedId()
    SetEntityVisible(ped, false, false)
    if type(spawn) == 'table' then
        SetEntityCoordsNoOffset(ped, spawn.x + 0.0, spawn.y + 0.0, spawn.z + 0.0, false, false, false)
        SetEntityHeading(ped, (spawn.h or 0) + 0.0)
        pcall(G.LoadScene, spawn.x + 0.0, spawn.y + 0.0, spawn.z + 0.0, function(pct, text) G.send('arrive.step', { pct = pct, text = text }) end)   -- une erreur ici ne doit pas bloquer l'arrivée
    end
    ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    SetEntityInvincible(ped, false)
    SetEntityVisible(ped, true, false)
    ClearFocus()
    G.flying = false
    G.creating, G.hidden = false, false
    G.pickSpawn = nil
    G.focus(false)
    G.send('arrive.step', { pct = 100, text = 'Bienvenue en ville' })
    Wait(500)
    G.send('arrive.done', {})
end

G.nui['creator.limits'] = function(d) return limits() end
G.nui['creator.textures'] = function(d)
    local ped = PlayerPedId()
    local id, dr = tonumber(d.id), tonumber(d.drawable)
    if not id or not dr then return { n = 1 } end
    if d.kind == 'prop' then return { n = math.max(1, GetNumberOfPedPropTextureVariations(ped, id, dr)) } end
    return { n = math.max(1, GetNumberOfPedTextureVariations(ped, id, dr)) }
end
G.nui['creator.preview'] = function(d)
    if not (G.creating or G.wardrobe) or type(d.appearance) ~= 'table' then return {} end
    G.applyAppearance(d.appearance, true)
    if d.sexChanged then
        FreezeEntityPosition(PlayerPedId(), true) SetEntityInvincible(PlayerPedId(), true)
        setCam(camMode)
        return limits()
    end
    return {}
end
G.nui['creator.spawn'] = function(d)
    if not G.creating then return {} end
    local pts = (G.cfg.character or {}).spawn_points or {}
    for _, p in ipairs(pts) do
        if p.id == tostring(d.id) and p.enabled ~= false then flyTo(p) break end
    end
    return {}
end
G.nui['creator.cam'] = function(d) if G.creating or G.wardrobe then setCam(tostring(d.mode)) end return {} end
G.nui['creator.rotate'] = function(d)
    if G.creating or G.wardrobe then local ped = PlayerPedId() SetEntityHeading(ped, GetEntityHeading(ped) + (tonumber(d.delta) or 0) * 1.0) end
    return {}
end
G.nui['creator.submit'] = function(d)
    if G.creating and type(d.data) == 'table' then G.createdName = tostring(d.data.firstname or '') TriggerServerEvent('pb:g:create', d.data) end
    return {}
end

RegisterNetEvent('pb:g:createError', function(msg) G.send('creator.error', { text = tostring(msg) }) end)
RegisterNetEvent('pb:g:created', function(j)
    local d = G.decode(j)
    if not d then return end
    G.appearance = d.appearance
    G.applyAppearance(d.appearance, true)
    endCreator(d.spawn, G.createdName)
end)

-- Début de session ------------------------------------------------------------------------------------------------------------------
RegisterNetEvent('pb:g:begin', function(j)
    local d = G.decode(j)
    if not d then return end
    G.begun = true
    G.identity, G.appearance = d.identity, d.appearance
    G.state.dead = d.dead and true or false
    local creator = G.cfg.character
    if not d.created and (not creator or creator.enabled ~= false) then
        if G.LoadingDone then G.LoadingDone({ keep = true, delay = 1500 }) end
        G.startCreator()
        return
    end
    -- arrivée depuis l'écran d'entrée : la transition du jeu (ciel puis zooms) place le joueur (client/entrance.lua)
    if G.arriving and G.EntranceArrive then G.EntranceArrive(d) return end
    if d.appearance then CreateThread(function() Wait(900) G.applyAppearance(d.appearance, true) end) end
    if type(d.pos) == 'table' and tonumber(d.pos.x) then
        -- reconnexion à la dernière position : fondu, chargement du décor, placement, puis l'écran de mort s'il y a lieu
        CreateThread(function()
            DoScreenFadeOut(300) Wait(350)
            local x, y, z = d.pos.x + 0.0, d.pos.y + 0.0, d.pos.z + 0.0
            RequestCollisionAtCoord(x, y, z)
            local ped = PlayerPedId()
            FreezeEntityPosition(ped, true)
            SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)
            SetEntityHeading(ped, (tonumber(d.pos.h) or 0) + 0.0)
            G.LoadScene(x, y, z)
            if G.LoadingDone then G.LoadingDone() end
            FreezeEntityPosition(ped, false)
            Wait(200)
            DoScreenFadeIn(600)
            if d.dead then Wait(300) G.startDeath() end
        end)
        return
    end
    if G.LoadingDone then G.LoadingDone() end
    if d.dead then CreateThread(function() Wait(1500) G.startDeath() end) end
end)

exports('GetIdentity', function() return G.identity end)

-- Mort ---------------------------------------------------------------------------------------------------------------------------------
local deathAnim = { dict = 'dead', name = 'dead_a' }

-- (v1.2.46) G se lit aussi au clavier brut (touche Windows 0x47) : la commande du jeu « Détoner » peut être réassignée dans les réglages de GTA
local function respawnKeyDown()
    return IsControlPressed(0, 47) or IsDisabledControlPressed(0, 47) or (IsRawKeyDown and IsRawKeyDown(0x47)) or false
end

local function resurrect(x, y, z, h, healthPct)
    local ped = PlayerPedId()
    NetworkResurrectLocalPlayer(x, y, z, h, true, false)
    ped = PlayerPedId()
    ClearPedTasksImmediately(ped)
    ClearPedBloodDamage(ped)
    local maxHp = GetEntityMaxHealth(ped)
    SetEntityHealth(ped, math.floor(100 + (maxHp - 100) * (healthPct or 100) / 100))
    SetPlayerInvincible(PlayerId(), false)
    StopScreenEffect('DeathFailOut')
end

function G.startDeath()
    local d = G.cfg.death or {}
    if G.dead or d.enabled == false or G.mortrp then return end
    G.dead = true
    G.state.dead = true
    -- (v1.2.43) tomber avec une interface ouverte (téléphone, sac, banque, magasin, menu…) la laissait par-dessus l'écran de mort, souris comprise
    if G.Menu and G.Menu.IsOpen and G.Menu.IsOpen() then pcall(G.Menu.Close) end
    if G.ForceClose then pcall(G.ForceClose, 'mort') end
    local c = GetEntityCoords(PlayerPedId())
    local h = GetEntityHeading(PlayerPedId())
    resurrect(c.x, c.y, c.z, h, 20)
    SetPlayerInvincible(PlayerId(), true)
    LocalPlayer.state:set('pbDown', true, true)   -- les autres joueurs ne peuvent plus le frapper (voir plus bas)
    StartScreenEffect('DeathFailOut', 0, false)
    G.staffRevive = false
    local shown = d
    if G.comaWhy then
        shown = {}
        for k, v in pairs(d) do shown[k] = v end
        shown.title = 'Coma'
        shown.subtitle = G.comaWhy == 'thirst' and "Tu t'es évanoui de soif. Un secouriste peut te réanimer." or "Tu t'es évanoui de faim. Un secouriste peut te réanimer."
        G.comaWhy = nil
    end
    G.send('death.open', { cfg = shown, delay = d.respawn_delay or 120 })
    TriggerServerEvent('pb:g:staff:canrevive')
    RequestAnimDict(deathAnim.dict)
    local started = GetGameTimer()
    -- le serveur ne nous savait pas à terre : on le lui redit et le délai repart de zéro
    G.deathResync = function()
        started = GetGameTimer()
        G.send('death.open', { cfg = shown, delay = d.respawn_delay or 120 })
        TriggerServerEvent('pb:g:died', 0, 0)
    end
    CreateThread(function()
        local holdStart, heldAt
        local lastAsk = -1e9
        local lastEms, lastStaff = -1e9, -1e9
        while G.dead do
            local ped = PlayerPedId()
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true) EnableControlAction(0, 2, true)           -- regarder autour
            EnableControlAction(0, 38, true) EnableControlAction(0, 47, true) EnableControlAction(0, 74, true)   -- E, G, H
            EnableControlAction(0, 245, true) EnableControlAction(0, 249, true)       -- chat, push-to-talk
            SetPedCanRagdoll(ped, false)
            -- un coup interrompt l'animation : elle reprend d'un coup, sans que le personnage ait le temps de se relever
            if not IsEntityPlayingAnim(ped, deathAnim.dict, deathAnim.name, 3) and HasAnimDictLoaded(deathAnim.dict) then
                TaskPlayAnim(ped, deathAnim.dict, deathAnim.name, 1000.0, -8.0, -1, 1, 0.0, false, false, false)
            end
            local elapsed = (GetGameTimer() - started) / 1000
            local ready = elapsed >= (d.respawn_delay or 120)
            if d.allow_ems ~= false and (IsControlJustPressed(0, 38) or IsDisabledControlJustPressed(0, 38)) and GetGameTimer() - lastEms > 3000 then
                lastEms = GetGameTimer()
                local p = GetEntityCoords(ped)
                TriggerServerEvent('pb:g:ems', p.x, p.y, p.z)
            end
            if G.staffRevive and (IsControlJustPressed(0, 74) or IsDisabledControlJustPressed(0, 74)) and GetGameTimer() - lastStaff > 1500 then
                lastStaff = GetGameTimer()
                TriggerServerEvent('pb:g:staff:selfrevive')
            end
            local now = GetGameTimer()
            if ready and respawnKeyDown() then
                heldAt = now
                holdStart = holdStart or now
                G.send('death.hold', { p = math.min(1, (now - holdStart) / 1500) })
                if now - holdStart >= 1500 and now - lastAsk > 3000 then
                    lastAsk = now
                    holdStart = nil
                    print('[pb_panel] réapparition demandée au serveur')
                    TriggerServerEvent('pb:g:respawn')
                end
            elseif holdStart and now - (heldAt or 0) > 250 then   -- une lecture manquée ne remet pas la jauge à zéro
                holdStart = nil
                G.send('death.hold', { p = 0 })
            end
            Wait(0)
        end
    end)
end

-- Pas de coups de poing ni d'arme de mêlée à côté d'un joueur à terre
CreateThread(function()
    local near, nextCheck = false, 0
    while true do
        local now = GetGameTimer()
        if now >= nextCheck then
            nextCheck = now + 300
            near = false
            local me = PlayerId()
            local pos = GetEntityCoords(PlayerPedId())
            for _, id in ipairs(GetActivePlayers()) do
                if id ~= me and #(GetEntityCoords(GetPlayerPed(id)) - pos) < 3.0 and Player(GetPlayerServerId(id)).state.pbDown then near = true break end
            end
        end
        if near and not IsPedArmed(PlayerPedId(), 6) then   -- 6 = armes à feu et explosifs : tirer reste possible
            DisableControlAction(0, 24, true) DisableControlAction(0, 257, true)
            DisableControlAction(0, 140, true) DisableControlAction(0, 141, true) DisableControlAction(0, 142, true)
            DisableControlAction(0, 263, true) DisableControlAction(0, 264, true)
            Wait(0)
        else
            Wait(near and 0 or 300)
        end
    end
end)

local function stopDeath()
    SetPedCanRagdoll(PlayerPedId(), true)
    LocalPlayer.state:set('pbDown', false, true)
    G.dead = false
    G.staffRevive = false
    G.state.dead = false
    G.send('death.close', {})
end

CreateThread(function()
    while true do
        Wait(400)
        local d = G.cfg.death
        if G.begun and not G.dead and not G.creating and (not d or d.enabled ~= false) and IsEntityDead(PlayerPedId()) then
            -- qui m'a tué (joueur à pied ou conducteur du véhicule), avec quelle arme : journal des morts du staff
            local ped = PlayerPedId()
            local by, killer = GetPedSourceOfDeath(ped), 0
            if by and by ~= 0 and DoesEntityExist(by) then
                if IsEntityAVehicle(by) then by = GetPedInVehicleSeat(by, -1) end
                if by and by ~= 0 and IsPedAPlayer(by) and by ~= ped then killer = GetPlayerServerId(NetworkGetPlayerIndexFromPed(by)) end
            end
            TriggerServerEvent('pb:g:died', killer, GetPedCauseOfDeath(ped))
            G.startDeath()
        end
    end
end)

RegisterNetEvent('pb:g:respawnAt', function(j)
    local d = G.decode(j)
    if not d or not d.pos then return end
    DoScreenFadeOut(500) Wait(600)
    stopDeath()
    local x, y, z = d.pos.x + 0.0, d.pos.y + 0.0, d.pos.z + 0.0
    resurrect(x, y, z, (d.pos.h or 0) + 0.0, d.health or 100)
    -- l'hôpital peut être loin : on attend le sol, sinon le personnage passe à travers la carte et retombe à terre
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true)
    RequestCollisionAtCoord(x, y, z)
    local t = GetGameTimer()
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 5000 do Wait(50) ped = PlayerPedId() end
    FreezeEntityPosition(ped, false)
    Wait(300)
    DoScreenFadeIn(800)
end)

RegisterNetEvent('pb:g:death:sync', function()
    if G.dead and G.deathResync then G.deathResync() end
end)

-- secours si la touche ne répond pas : le serveur vérifie le délai et les frais comme pour G
RegisterCommand('reapparaitre', function()
    if G.dead then TriggerServerEvent('pb:g:respawn') end
end, false)

RegisterNetEvent('pb:g:staff:canrevive', function(ok)
    if not G.dead then return end
    G.staffRevive = ok == true
    G.send('death.staff', { on = G.staffRevive })
end)

RegisterNetEvent('pb:g:revive', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local pct = (G.cfg.death and G.cfg.death.revive_health) or 50
    stopDeath()
    resurrect(c.x, c.y, c.z, GetEntityHeading(ped), pct)
end)

-- Point de secours sur la carte des secouristes
local emsBlips = {}
RegisterNetEvent('pb:g:emsBlip', function(j)
    local p = G.decode(j)
    if not p then return end
    local key = tostring(p.id or (math.floor(p.x) .. ':' .. math.floor(p.y)))
    if emsBlips[key] and DoesBlipExist(emsBlips[key]) then RemoveBlip(emsBlips[key]) end   -- nouvel appel du même joueur : on remplace, on n'empile pas
    local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
    emsBlips[key] = b
    SetBlipSprite(b, 153) SetBlipColour(b, 1) SetBlipScale(b, 1.0) SetBlipFlashes(b, true) SetBlipRoute(b, true)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Joueur à terre') EndTextCommandSetBlipName(b)
    SetTimeout(300000, function() if DoesBlipExist(b) then RemoveBlip(b) end if emsBlips[key] == b then emsBlips[key] = nil end end)
end)
