-- Personnage en pied (inventaire, « Joueurs à proximité ») : capture du personnage devant un fond vert dessiné par le jeu (screenshot-basic requis),
-- l'interface retire le vert et réduit l'image, le serveur la garde en mémoire et la donne aux joueurs proches qui la demandent.
local G = PBG
local busy, lastAt = false, 0

local function capture(cb)
    local ok = pcall(function() exports['screenshot-basic']:requestScreenshot({ encoding = 'jpg', quality = 0.9 }, cb) end)
    if not ok then pcall(function() exports['screenshot-basic']:requestScreenshot(cb) end) end
end
local function quad(a, b, c, d)
    DrawPoly(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z, 0, 255, 0, 255)
    DrawPoly(c.x, c.y, c.z, b.x, b.y, b.z, a.x, a.y, a.z, 0, 255, 0, 255)
    DrawPoly(a.x, a.y, a.z, c.x, c.y, c.z, d.x, d.y, d.z, 0, 255, 0, 255)
    DrawPoly(d.x, d.y, d.z, c.x, c.y, c.z, a.x, a.y, a.z, 0, 255, 0, 255)
end

local function snap()
    if busy or GetResourceState('screenshot-basic') ~= 'started' then return false end
    local ped = PlayerPedId()
    if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) or (G.IsCuffed and G.IsCuffed()) or not G.begun or G.creating or G.invOpen or IsPedRagdoll(ped) or GetEntitySpeed(ped) > 0.3 then return false end
    busy = true
    CreateThread(function()
        local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        local o = GetOffsetFromEntityInWorldCoords(ped, 0.0, 3.1, 0.1)
        SetCamCoord(cam, o.x, o.y, o.z) PointCamAtCoord(cam, GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.0, 0.05)) SetCamFov(cam, 34.0)
        RenderScriptCams(true, false, 0, true, false)
        local t0, shot, got = GetGameTimer(), false, false
        while GetGameTimer() - t0 < 4500 and not got do
            local ped2 = PlayerPedId()
            local a = GetOffsetFromEntityInWorldCoords(ped2, -3.0, -1.1, -1.4)
            local b = GetOffsetFromEntityInWorldCoords(ped2, 3.0, -1.1, -1.4)
            local c = GetOffsetFromEntityInWorldCoords(ped2, 3.0, -1.1, 2.4)
            local d = GetOffsetFromEntityInWorldCoords(ped2, -3.0, -1.1, 2.4)
            quad(a, b, c, d)
            if not shot and GetGameTimer() - t0 > 900 then shot = true capture(function(data) got = true G.send('body.shrink', { img = tostring(data or '') }) end) end
            Wait(0)
        end
        RenderScriptCams(false, false, 0, true, false) DestroyCam(cam, false)
        busy = false
    end)
    return true
end
G.SnapBody = snap

G.nui['body.result'] = function(d)
    if type(d.img) == 'string' and #d.img < 90000 and d.img:sub(1, 23) == 'data:image/webp;base64,' then TriggerServerEvent('pb:g:body:set', d.img) end
    return {}
end
G.nui['body.need'] = function(d)
    if type(d.ids) == 'table' then
        local ids = {}
        for i = 1, math.min(#d.ids, 12) do ids[#ids + 1] = math.floor(tonumber(d.ids[i]) or 0) end
        TriggerServerEvent('pb:g:body:need', ids)
    end
    return {}
end
RegisterNetEvent('pb:g:body:data', function(map) if type(map) == 'table' then G.send('body.data', map) end end)
RegisterNetEvent('pb:g:body:ask', function() snap() end)

-- à la connexion, puis après un changement de tenue (au plus une fois toutes les 20 s)
local function later(ms)
    CreateThread(function()
        Wait(ms)
        local n = 0
        while n < 12 and not snap() do n = n + 1 Wait(3000) end
    end)
end
CreateThread(function() while not G.begun do Wait(1000) end later(12000) end)
RegisterNetEvent('pb:g:inv:wear', function() if GetGameTimer() - lastAt > 20000 then lastAt = GetGameTimer() later(2500) end end)
