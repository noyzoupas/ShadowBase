-- Tablette de police (MDT) : ouvre la fenêtre (web/game/mdt.js), relaie ses requêtes au serveur (server/game/mdt.lua), tient la tablette en main.
local G = PBG
local isOpen = false
local prop = nil

local ANIM_DICT, ANIM_CLIP, PROP_MODEL = 'amb@world_human_tourist_map@male@base', 'base', 'prop_cs_tablet'

local function stopAnim()
    if prop and DoesEntityExist(prop) then DeleteEntity(prop) end
    prop = nil
    ClearPedSecondaryTask(PlayerPedId())
end
local function load(request, loaded, what)
    request(what)
    local t = GetGameTimer() + 2000
    while not loaded(what) and GetGameTimer() < t do Wait(10) end
    return loaded(what)
end
local function startAnim()
    CreateThread(function()
        local model = GetHashKey(PROP_MODEL)
        if not load(RequestAnimDict, HasAnimDictLoaded, ANIM_DICT) or not load(RequestModel, HasModelLoaded, model) or not isOpen then return end
        local ped = PlayerPedId()
        TaskPlayAnim(ped, ANIM_DICT, ANIM_CLIP, 3.0, 3.0, -1, 49, 0, false, false, false)
        local c = GetEntityCoords(ped)
        prop = CreateObject(model, c.x, c.y, c.z, true, true, false)
        AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 28422), 0.0, -0.03, 0.0, 20.0, -90.0, 0.0, true, true, false, true, 1, true)
        SetModelAsNoLongerNeeded(model)
    end)
end

local function close()
    if not isOpen then return end
    isOpen = false
    stopAnim()
    G.focus(false)
    G.send('mdt.close', {})
end

RegisterNetEvent('pb:g:mdt:open', function(j)
    local d = G.decode(j)
    if not d or isOpen or G.creating or G.wardrobe or (G.state and G.state.dead) then return end
    if G.Menu.IsOpen() then G.Menu.Close() end
    isOpen = true
    G.focus(true)
    G.send('mdt.open', d)
    startAnim()
end)
RegisterNetEvent('pb:g:mdt:res', function(j)
    local d = G.decode(j)
    if not d or not isOpen then return end
    G.send('mdt.res', d)
    if d.closed then close() end
end)
RegisterNetEvent('pb:g:police:cuff', function(j) local d = G.decode(j) if d and d.on then close() end end)

G.nui['mdt.req'] = function(d)
    if isOpen then TriggerServerEvent('pb:g:mdt:req', tonumber(d.rid) or 0, tostring(d.op or ''), type(d.p) == 'table' and d.p or {}) end
    return {}
end
G.nui['mdt.close'] = function() close() return {} end
G.onForceClose(close)

CreateThread(function()
    while true do
        Wait(600)
        if isOpen and G.state and G.state.dead then close() end
    end
end)

local function toggle()
    if isOpen then close() return end
    if not G.begun or G.creating or G.wardrobe or (G.state and G.state.dead) then return end
    TriggerServerEvent('pb:g:mdt:open')
end
RegisterCommand('mdt', toggle, false)
RegisterKeyMapping('pb_mdt', 'Tablette de police (MDT)', 'keyboard', '')
RegisterCommand('pb_mdt', toggle, false)

AddEventHandler('onResourceStop', function(r)
    if r == GetCurrentResourceName() and isOpen then stopAnim() end
end)
