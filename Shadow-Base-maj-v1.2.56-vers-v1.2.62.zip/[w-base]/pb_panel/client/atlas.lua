-- Panneau de la carte du jeu : s'affiche à gauche de la carte d'origine (celle du menu pause) avec la liste des lieux par catégorie.
-- La carte et ses repères restent ceux du jeu ; le panneau les pilote : le lieu choisi clignote et reçoit le GPS, l'œil masque tous les repères,
-- « Territoires » montre ou cache les zones. Les lieux viennent du registre des repères (client/blips.lua).
-- Panneau à droite. La souris est à la carte du jeu ; elle passe au panneau seulement quand elle le survole.
local G = PBG
local open, focused, rightEdge = false, false, 0.66
local sel, flashed, hiddenAll = nil, {}, false
local style, styleDict = 0, nil   -- style de carte choisi (0 = carte d'origine)

-- Styles de carte : l'image de la carte du menu pause est remplacée par une texture streamée (réglée dans le panel › Carte du jeu).
-- Le jeu n'a pas de « type de carte » natif : sans pack de carte streamé, seul le style d'origine existe.
local TXD = 'platform:/textures/graphics'
local function styles() local c = G.cfg and G.cfg.pause return c and type(c.map_styles) == 'table' and c.map_styles or {} end
local function target() local c = G.cfg and G.cfg.pause return c and type(c.map_target) == 'string' and c.map_target ~= '' and c.map_target or 'radarmasterhi' end
local function applyStyle(i, silent)
    pcall(function() if styleDict then RemoveReplaceTexture(TXD, target()) styleDict = nil end end)
    style = 0
    local st = styles()[i]
    if st and type(st.dict) == 'string' and type(st.tex) == 'string' then
        RequestStreamedTextureDict(st.dict, true)
        local t0 = GetGameTimer()
        while not HasStreamedTextureDictLoaded(st.dict) and GetGameTimer() - t0 < 4000 do Wait(50) end
        if HasStreamedTextureDictLoaded(st.dict) then
            AddReplaceTexture(TXD, target(), st.dict, st.tex)
            styleDict, style = st.dict, i
        elseif not silent then G.send('notify', { type = 'warn', text = "Ce style de carte n'est pas installé sur le serveur (fichier .ytd manquant)." }) end
    end
    SetResourceKvpInt('pb_map_style', style)
end
CreateThread(function()
    Wait(8000)
    local i = GetResourceKvpInt and GetResourceKvpInt('pb_map_style') or 0
    if i and i > 0 then applyStyle(i, true) end
end)

local function names() return PBBlips and PBBlips.reg or {} end
local function collect()
    local pts, seen = {}, {}
    for b, d in pairs(names()) do
        if d.k == 'c' and not d.ill and DoesBlipExist(b) and #pts < 900 then   -- (v1.2.45) jamais les points de vente de drogue
            local disp = GetBlipInfoIdDisplay and GetBlipInfoIdDisplay(b) or 2
            local sp = GetBlipSprite(b)
            if (disp ~= 0 or hiddenAll) and sp ~= 8 and (d.n or '') ~= '' then
                local k = ('%d:%d:%d'):format(math.floor(d.x), math.floor(d.y), sp)
                if not seen[k] then
                    seen[k] = true
                    pts[#pts + 1] = { x = math.floor(d.x * 10) / 10, y = math.floor(d.y * 10) / 10, s = sp, c = GetBlipColour(b), n = d.n }
                end
            end
        end
    end
    return pts
end
local function me()
    local c = GetEntityCoords(PlayerPedId())
    return { x = c.x, y = c.y, h = GetEntityHeading(PlayerPedId()), name = GetPlayerName(PlayerId()) }   -- nom FiveM, en tête de la liste
end
local function unflash()
    for b in pairs(flashed) do if DoesBlipExist(b) then SetBlipFlashes(b, false) end end
    flashed = {}
end
local function setFocus(on)
    if on == focused then return end
    focused = on
    SetNuiFocus(on, on)
    if on and SetNuiFocusKeepInput then SetNuiFocusKeepInput(false) end
end
local function norm(s) return tostring(s or ''):lower() end
local function setAllDisplay(hide)
    hiddenAll = hide
    for b, d in pairs(names()) do
        if d.k == 'c' and DoesBlipExist(b) then
            if hide then SetBlipDisplay(b, 0)
            elseif not (PBBlips.hidden and PBBlips.hidden[b]) then SetBlipDisplay(b, d.disp or 2) end
        end
    end
end

local function close()
    if not open then return end
    open = false
    unflash()
    if hiddenAll then setAllDisplay(false) end
    sel = nil
    G.send('atlas.close', {})
    if focused then focused = false SetNuiFocus(false, false) end
end

-- (v1.2.45) carte de base de GTA, sans notre panneau (le panneau reste ci-dessous, inutilisé : G.AtlasPanelOpen)
function G.AtlasOpen()
    if not G.begun or G.state.dead or G.creating then return end
    CreateThread(function()
        pcall(function() ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), false, -1) end)
        Wait(400)
        pcall(function() PauseMenuceptionGoDeeper(0) end)
    end)
end
function G.AtlasPanelOpen()
    if open or not G.begun or G.state.dead or G.creating then return end
    open = true
    CreateThread(function()
        pcall(function() ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), false, -1) end)
        Wait(400)
        pcall(function() PauseMenuceptionGoDeeper(0) end)
        Wait(300)
        if not open then return end
        local names = {}
        for _, st in ipairs(styles()) do names[#names + 1] = tostring(st.label or '') end
        G.send('atlas.open', { points = collect(), me = me(), zones = G.terrZoneList and G.terrZoneList() or {}, styles = names, style = style })
        local t0 = GetGameTimer()
        while open do
            Wait(0)
            if not IsPauseMenuActive() and GetGameTimer() - t0 > 1500 then close() break end
            -- la souris est au panneau quand elle le survole (sinon elle sert à la carte)
            if not focused then
                local cx, cy = GetDisabledControlNormal(2, 239), GetDisabledControlNormal(2, 240)
                if cx and cx > rightEdge and cy > 0.07 and cy < 0.96 then setFocus(true) end
            end
        end
    end)
end
G.nui['atlas.rect'] = function(d) local r = tonumber(d.r) if r and r > 0.4 and r < 0.95 then rightEdge = r end return {} end
G.nui['atlas.leave'] = function() if open then setFocus(false) end return {} end
G.nui['atlas.close'] = function() close() return {} end
G.nui['atlas.gpsoff'] = function() if open then SetWaypointOff() end return {} end
G.nui['atlas.hide'] = function(d) if open then setAllDisplay(d.on == true) end return {} end
G.nui['atlas.zones'] = function(d) if open and G.terrShow then G.terrShow(d.on ~= false) end return {} end
-- lieu choisi : ses repères clignotent sur la carte du jeu, et le GPS se pose sur celui qu'on regarde
G.nui['atlas.select'] = function(d)
    if not open then return {} end
    unflash()
    local k = norm(d.k)
    for b, bd in pairs(names()) do
        if bd.k == 'c' and DoesBlipExist(b) and norm(bd.n) == k then SetBlipFlashes(b, true) flashed[b] = true end
    end
    local x, y = tonumber(d.x), tonumber(d.y)
    if x and y and math.abs(x) < 10000 and math.abs(y) < 10000 then SetNewWaypoint(x + 0.0, y + 0.0) end
    return {}
end
-- ligne du joueur : sa position clignote sur la carte
G.nui['atlas.me'] = function()
    if not open then return {} end
    unflash()
    local b = GetMainPlayerBlipId()
    if b and DoesBlipExist(b) then SetBlipFlashes(b, true) flashed[b] = true end
    return {}
end
G.nui['atlas.style'] = function(d)
    if open then local i = math.floor(tonumber(d.i) or 0) CreateThread(function() applyStyle(i) end) end
    return {}
end
RegisterCommand('carte', function() if open then close() else G.AtlasOpen() end end, false)
G.onForceClose(function() open = false focused = false end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then unflash() if hiddenAll then setAllDisplay(false) end end end)

-- touche P : la carte du serveur à la place de celle de GTA (réglage map_on_p, coupé par défaut)
G.frameHooks = G.frameHooks or {}
G.frameHooks[#G.frameHooks + 1] = function()
    local c = G.cfg.pause
    if not (c and c.map_on_p == true and G.begun) then return false end
    if G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) or G.locked > 0 or (G.Menu and G.Menu.IsOpen and G.Menu.IsOpen()) then return false end
    if IsPauseMenuActive() or G.qmapOpen then return false end
    DisableControlAction(0, 199, true)
    if IsDisabledControlJustReleased(0, 199) then G.AtlasOpen() end
    return true
end
