-- Magasins : marqueurs, blips, invite « E », ouverture des interfaces (supérette, concession, vestiaire). Prix et catalogues viennent du serveur.

local G = PBG
local shops, blips = {}, {}
local near, promptShown = nil, false
local closeShop
local current = nil         -- magasin ouvert (données du serveur)
local savedApp = nil
local vsession = nil      -- visualisation / essai d'un véhicule en cours

local function hexToRgb(hex)
    hex = tostring(hex or '#dfe2e7'):gsub('#', '')
    return tonumber(hex:sub(1, 2), 16) or 201, tonumber(hex:sub(3, 4), 16) or 143, tonumber(hex:sub(5, 6), 16) or 186
end

local function rebuild()
    local npcs = {}
    for _, s in ipairs(shops) do if s.npc and s.npc.model then npcs[#npcs + 1] = { id = s.id, model = s.npc.model, scenario = s.npc.scenario, x = s.npc.x or s.x, y = s.npc.y or s.y, z = s.npc.z or s.z, h = s.npc.h or s.h } end end
    G.Npcs('shops', npcs)   -- vendeurs posés au sol (game.lua)
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    for _, s in ipairs(shops) do
        if s.blip then
            local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
            SetBlipSprite(b, s.sprite or 52) SetBlipColour(b, s.color or 2) SetBlipScale(b, 0.8) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        end
    end
end

G.onCfg = function(c)
    shops = c.shops or {} G.cfg.shops_settings = c.shops_settings rebuild()
    if current and (current.kind == 'store' or current.kind == 'weapons' or current.kind == 'dealer') then
        local still = false
        for _, s in ipairs(shops) do if s.id == current.id then still = true end end
        if still then TriggerServerEvent('pb:g:shop:open', current.id, true) else closeShop() end
    end
end

local function hidePrompt() if promptShown then promptShown = false G.send('prompt', { show = false }) end end

CreateThread(function()
    local cand, nextScan = {}, 0   -- magasins proches, recalculés toutes les 0,5 s (pas toute la liste à chaque image)
    while true do
        local sc = G.cfg.shops_settings or {}
        local md = (sc.marker_distance or 20) + 0.0
        local ud = (sc.use_distance or 2.0) + 0.0
        if not G.begun or G.dead or G.creating or current or vsession or #shops == 0 then
            hidePrompt()
            Wait(700)
        else
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local now = GetGameTimer()
            if now >= nextScan then
                nextScan = now + 500
                cand = {}
                for _, s in ipairs(shops) do if #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) <= md + 15.0 then cand[#cand + 1] = s end end
            end
            local best, bd = nil, 1e9
            for _, s in ipairs(cand) do
                local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0))
                if d < bd then best, bd = s, d end
            end
            if best and bd <= md then
                local r, g, b = hexToRgb(sc.c_marker)
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, r, g, b, 1.4)
                if bd <= ud + 0.6 and not IsPedInAnyVehicle(ped, false) then
                    if not promptShown or near ~= best.id then
                        promptShown, near = true, best.id
                        G.send('prompt', { show = true, key = 'E', text = best.label })
                    end
                    if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:shop:open', best.id) end
                else hidePrompt() near = nil end
                Wait(0)
            else
                hidePrompt() near = nil
                Wait(400)
            end
        end
    end
end)

function G.shopIsOpen() return current ~= nil end
function G.closeShop() closeShop() end

-- Armurerie : caméra sur le vendeur, l'article en 3D devant lui. Rien n'est visible des autres joueurs.
local gun = nil   -- { cam, obj, rot, dist, center... }
local function gunObjDel() if gun and gun.obj and DoesEntityExist(gun.obj) then DeleteEntity(gun.obj) end if gun then gun.obj = nil end end
local function gunPlace()
    if not gun or not gun.obj or not DoesEntityExist(gun.obj) then return end
    local c, f, r = gun.c, gun.f, gun.r
    SetEntityCoordsNoOffset(gun.obj, c.x + f.x * gun.dist + r.x * 0.1, c.y + f.y * gun.dist + r.y * 0.1, c.z - 0.03, false, false, false)
    SetEntityRotation(gun.obj, 0.0, 0.0, gun.yaw + gun.rot, 2, true)
end
local function gunStart(s)
    local n = s and s.npc
    if not n or not n.model then return end
    local a = math.rad((n.h or s.h or 0.0) + 0.0)
    local fx, fy = -math.sin(a), math.cos(a)
    local nx, ny, nz = (n.x or s.x) + 0.0, (n.y or s.y) + 0.0, (n.z or s.z) + 0.0
    local cz = nz + 0.62
    local c = vector3(nx + fx * 1.2, ny + fy * 1.2, cz)
    local cam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', c.x, c.y, c.z, 0.0, 0.0, 0.0, 42.0, false, 2)
    PointCamAtCoord(cam, nx, ny, cz)
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 500, true, true)
    gun = { cam = cam, c = c, f = vector3(-fx, -fy, 0.0), r = vector3(fy * -1.0, fx, 0.0) * -1.0, dist = 0.62, rot = 0.0, yaw = (n.h or s.h or 0.0) + 90.0 }
    FreezeEntityPosition(PlayerPedId(), true)
end
local function gunStop()
    if not gun then return end
    gunObjDel()
    RenderScriptCams(false, true, 400, true, true)
    DestroyCam(gun.cam, false)
    gun = nil
    FreezeEntityPosition(PlayerPedId(), false)
end
G.nui['shop.view3d'] = function(d)
    local out = {}
    local hash = tostring(d.hash or '')
    local isW = hash:sub(1, 7) == 'WEAPON_' and IsWeaponValid(GetHashKey(hash))
    if isW then
        local wh = GetHashKey(hash)
        out = { damage = GetWeaponDamage(wh, 0) or 0, clip = GetMaxAmmoInClip(PlayerPedId(), wh, true) or 0 }
    else out = { damage = 0, clip = 0 } end
    if not gun then return out end
    local token = {}
    gun.token = token
    CreateThread(function()
        local obj
        if isW then
            local wh = GetHashKey(hash)
            RequestWeaponAsset(wh, 31, 0)
            local t = GetGameTimer()
            while not HasWeaponAssetLoaded(wh) and GetGameTimer() - t < 3000 do Wait(10) end
            if gun and gun.token == token then obj = CreateWeaponObject(wh, 0, gun.c.x, gun.c.y, gun.c.z, true, 1.0, 0) end
        else
            local mh = GetHashKey('prop_ld_ammo_pack_01')
            RequestModel(mh)
            local t = GetGameTimer()
            while not HasModelLoaded(mh) and GetGameTimer() - t < 3000 do Wait(10) end
            if gun and gun.token == token then obj = CreateObject(mh, gun.c.x, gun.c.y, gun.c.z, false, false, false) end
            SetModelAsNoLongerNeeded(mh)
        end
        if not gun or gun.token ~= token then if obj and DoesEntityExist(obj) then DeleteEntity(obj) end return end
        gunObjDel()
        gun.obj = obj
        if obj then SetEntityCollision(obj, false, false) FreezeEntityPosition(obj, true) gunPlace() end
    end)
    return out
end
G.nui['shop.view3d.rot'] = function(d) if gun then gun.rot = gun.rot + (tonumber(d.d) or 0) gunPlace() end return {} end
G.nui['shop.view3d.zoom'] = function(d) if gun then gun.dist = math.max(0.38, math.min(1.0, gun.dist + (tonumber(d.d) or 0) * 0.05)) gunPlace() end return {} end
G.nui['shop.view3d.reset'] = function() if gun then gun.rot, gun.dist = 0.0, 0.62 gunPlace() end return {} end

function closeShop()
    gunStop()
    if G.endWeaponTest then G.endWeaponTest() end
    if current and current.clerk then TriggerServerEvent('pb:g:shop:closed') end
    current = nil
    G.send('shop.close', {})
    G.focus(false)
end

RegisterNetEvent('pb:g:shop:data', function(j)
    local d = G.decode(j)
    if not d then return end
    if current then
        -- mise à jour des prix pendant que le magasin est ouvert (le serveur a modifié le catalogue)
        if d.refresh and current.id == d.id and (d.kind == 'store' or d.kind == 'weapons' or d.kind == 'dealer') then current = d G.send('shop.open', d) end
        return
    end
    -- en ped de service staff, les vêtements et la coiffure ne s'appliqueraient pas (et enlevaient le ped) : on prévient
    if G.staffPed and (d.kind == 'clothes' or d.kind == 'barber' or d.kind == 'tattoo') then
        G.send('notify', { type = 'warn', title = 'Service staff', text = 'Tu es en ped de service : quitte ton service staff (F10) pour changer de tenue ou de coiffure.' })
        TriggerServerEvent('pb:g:shop:closed')
        return
    end
    current = d
    hidePrompt()
    if d.kind == 'barber' then G.openBarber(d) return end
    if d.kind == 'tattoo' then G.openTattoo(d) return end   -- client/tattoo.lua   -- client/barber.lua : menu du jeu, pas d'interface à la souris
    G.focus(true)
    if d.kind == 'clothes' then
        G.wardrobe = true
        savedApp = d.appearance
        local ped = PlayerPedId()
        FreezeEntityPosition(ped, true)
        if G.camZoomReset then G.camZoomReset() end
        G.setCam('body')
        G.send('wardrobe.open', { shop = { id = d.id, label = d.label, price = d.price or 0, scope = d.scope, gear = d.gear, img = d.img, hidenp = d.hidenp, sex = d.sex, piece = d.piece, color = d.color }, limits = G.limits(), appearance = d.appearance, cfg = G.cfg.character or {}, cash = d.cash, bank = d.bank })
    else
        if d.kind == 'weapons' and d.flow == 'direct' and not d.clerk then
            for _, s in ipairs(shops) do if s.id == d.id then gunStart(s) break end end
        end
        G.send('shop.open', d)
    end
end)

RegisterNetEvent('pb:g:shop:money', function(j) local d = G.decode(j) if d then G.send('shop.money', d) end end)

local function endWardrobe(restore)
    if restore and savedApp then G.applyAppearance(savedApp, false) end
    G.wardrobe = false
    G.camOff()
    FreezeEntityPosition(PlayerPedId(), false)
    G.send('wardrobe.close', {})
    closeShop()
end

RegisterNetEvent('pb:g:shop:clothesOk', function(j) local a = G.decode(j) if a then G.appearance = a G.applyAppearance(a, false) end endWardrobe(false) end)
RegisterNetEvent('pb:g:shop:cancel', function() if G.wardrobe then endWardrobe(true) end end)

RegisterNetEvent('pb:g:shop:vehicle', function(j)
    local d = G.decode(j)
    if not d then return end
    local hash = GetHashKey(d.model)
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then closeShop() G.send('notify', { type = 'error', text = "Ce modèle n'existe pas sur ce serveur." }) return end
    RequestModel(hash)
    local t = GetGameTimer()
    while not HasModelLoaded(hash) and GetGameTimer() - t < 8000 do Wait(10) end
    if not HasModelLoaded(hash) then closeShop() return end
    local sp = d.spawn or {}
    local veh = CreateVehicle(hash, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, (sp.h or 0) + 0.0, true, false)
    SetVehicleNumberPlateText(veh, d.plate)
    SetVehicleOnGroundProperly(veh)
    SetPedIntoVehicle(PlayerPedId(), veh, -1)
    SetModelAsNoLongerNeeded(hash)
    closeShop()
end)

G.nui['shop.buy'] = function(d) if current and (current.kind == 'store' or current.kind == 'weapons') then TriggerServerEvent('pb:g:shop:buy', current.id, tostring(d.name), tonumber(d.qty) or 1) end return {} end
G.nui['shop.restock'] = function(d) if current and (current.kind == 'store' or current.kind == 'weapons') then TriggerServerEvent('pb:g:shop:restock', current.id, tostring(d.name), tonumber(d.qty) or 1) end return {} end
G.nui['shop.buyVehicle'] = function(d) if current and current.kind == 'dealer' then TriggerServerEvent('pb:g:shop:buyVehicle', current.id, tostring(d.model)) end return {} end
G.nui['shop.close'] = function() if G.wardrobe then endWardrobe(true) else closeShop() end return {} end
G.nui['wardrobe.buy'] = function(d)   -- masques et sacs : un article à la fois, livré dans le sac
    if current and current.kind == 'clothes' and current.gear then TriggerServerEvent('pb:g:shop:gear', current.id, tostring(d.kind), tonumber(d.d) or -1, tonumber(d.t) or 0) end
    return {}
end
G.nui['wardrobe.pay'] = function(d)
    if current and current.kind == 'clothes' and type(d.appearance) == 'table' then TriggerServerEvent('pb:g:shop:clothes', current.id, d.appearance, d.method, tonumber(d.shared)) end
    return {}
end
-- tenues : le serveur garde la liste, ici on relaie
G.nui['wardrobe.list'] = function() if G.wardrobe then TriggerServerEvent('pb:g:wd:list') end return {} end
G.nui['wardrobe.save'] = function(d) if G.wardrobe then TriggerServerEvent('pb:g:wd:save', tostring(d.label or '')) end return {} end
G.nui['wardrobe.del'] = function(d) if G.wardrobe then TriggerServerEvent('pb:g:wd:delete', tonumber(d.id)) end return {} end
G.nui['wardrobe.pub'] = function(d) if G.wardrobe then TriggerServerEvent('pb:g:wd:publish', tonumber(d.id)) end return {} end
G.nui['wardrobe.unpub'] = function(d) if G.wardrobe then TriggerServerEvent('pb:g:wd:unpublish', tonumber(d.id)) end return {} end
RegisterNetEvent('pb:g:wd:data', function(j) local t = G.decode(j) if t then G.send('wardrobe.data', t) end end)

-- Essai d'une arme (armurerie) : mise en main quelques secondes avec des munitions de test, retirée à la fin ou quand la boutique se ferme.
local testWeapon, testUntil = nil, 0
local function endTest()
    if testWeapon then
        local ped = PlayerPedId()
        RemoveWeaponFromPed(ped, testWeapon)
        SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
        testWeapon = nil
    end
end
G.endWeaponTest = endTest
RegisterNetEvent('pb:g:shop:testweapon', function(j)
    local d = G.decode(j)
    if not d or not d.hash or tostring(d.hash):sub(1, 7) ~= 'WEAPON_' then return end
    endTest()
    local ped = PlayerPedId()
    local h = GetHashKey(tostring(d.hash))
    if not IsWeaponValid(h) then G.send('shop.testState', { text = "Cette arme n'existe pas dans le jeu." }) return end
    if HasPedGotWeapon(ped, h, false) then G.send('shop.testState', { text = 'Tu as déjà cette arme sur toi.' }) return end
    local sid = current and current.id
    GiveWeaponToPed(ped, h, math.floor(tonumber(d.ammo) or 24), false, true)
    SetCurrentPedWeapon(ped, h, true)
    testWeapon, testUntil = h, GetGameTimer() + math.floor((tonumber(d.seconds) or 20) * 1000)
    -- on libère la souris pour pouvoir tirer ; la boutique se rouvre à la fin de l'essai
    gunStop()
    current = nil
    G.send('shop.close', {})
    G.focus(false)
    G.send('shop.testState', { seconds = tonumber(d.seconds) or 20 })
    CreateThread(function()
        while testWeapon == h and GetGameTimer() < testUntil and not IsControlJustPressed(0, 73) do Wait(0) end
        if testWeapon == h then
            endTest()
            G.send('shop.testState', { done = true })
            if sid then TriggerServerEvent('pb:g:shop:open', sid) end
        end
    end)
end)
G.nui['shop.test'] = function(d) if current and current.kind == 'weapons' then TriggerServerEvent('pb:g:shop:test', current.id, tostring(d.name)) end return {} end


-- Commandes : le serveur décide de tout, on relaie l'état à l'interface ---------------------------------------------------------------------
local assignedFocus = false
RegisterNetEvent('pb:g:shop:order', function(j)
    local d = G.decode(j)
    if not d then return end
    G.send('shop.order', d)
    -- panier attribué par un vendeur : fenêtre de confirmation (Y / N) même si le magasin n'est pas ouvert chez moi
    if d.assigned and not current then
        if d.state == 'billed' and not assignedFocus and not G.creating and not G.wardrobe then assignedFocus = true G.focus(true)
        elseif d.state ~= 'billed' and assignedFocus then assignedFocus = false G.focus(false) end
    end
end)
G.nui['shop.assignedDone'] = function() if assignedFocus then assignedFocus = false G.focus(false) end return {} end
RegisterNetEvent('pb:g:shop:orders', function(j) local d = G.decode(j) if d then G.send('shop.orders', { list = d }) end end)
RegisterNetEvent('pb:g:shop:ticket', function(j) local d = G.decode(j) if d then G.send('shop.ticket', d) end end)
RegisterNetEvent('pb:g:shop:catdata', function(j) local d = G.decode(j) if d then G.send('shop.catdata', d) end end)
local function inShop() return current ~= nil and current.kind ~= 'clothes' and current.kind ~= 'barber' and current.kind ~= 'tattoo' end
G.nui['shop.send'] = function(d) if inShop() and type(d.cart) == 'table' then TriggerServerEvent('pb:g:shop:send', current.id, d.cart) end return {} end
G.nui['shop.bell'] = function(d) if inShop() then TriggerServerEvent('pb:g:shop:bell', tonumber(d.id) or 0) end return {} end
G.nui['shop.opay'] = function(d) TriggerServerEvent('pb:g:shop:opay', tonumber(d.id) or 0) return {} end
G.nui['shop.ocancel'] = function(d) TriggerServerEvent('pb:g:shop:ocancel', tonumber(d.id) or 0) return {} end
G.nui['shop.assign'] = function(d) if inShop() and current.clerk and type(d.cart) == 'table' then TriggerServerEvent('pb:g:shop:assign', current.id, d.cart, tonumber(d.target) or -1) end return {} end
G.nui['shop.ostate'] = function(d) if inShop() then TriggerServerEvent('pb:g:shop:ostate', tonumber(d.id) or 0) end return {} end
G.nui['shop.oclerk'] = function(d) if inShop() then TriggerServerEvent('pb:g:shop:oclerk', tonumber(d.id) or 0, tostring(d.act or '')) end return {} end
G.nui['shop.vstat'] = function(d)
    local m = GetHashKey(tostring(d.model or ''))
    if not IsModelInCdimage(m) or not IsModelAVehicle(m) then return { ok = false } end
    local spd = GetVehicleModelEstimatedMaxSpeed(m) * 3.6
    local function pct(v, mx) return math.max(0, math.min(100, (v / mx) * 100)) end
    return { ok = true, spd = spd, acc = pct(GetVehicleModelAcceleration(m), 0.5), brk = pct(GetVehicleModelMaxBraking(m), 2.0), trc = pct(GetVehicleModelMaxTraction(m), 3.0), seats = GetVehicleModelNumberOfSeats(m) }
end
G.nui['shop.cat'] = function(d) if current and current.kind == 'dealer' then TriggerServerEvent('pb:g:shop:cat', current.id, tostring(d.cat or '')) end return {} end
G.nui['shop.testreq'] = function(d) if current and current.kind == 'dealer' then TriggerServerEvent('pb:g:shop:testreq', current.id, tostring(d.model or '')) end return {} end
G.nui['shop.vview'] = function(d) if current and current.kind == 'dealer' then TriggerServerEvent('pb:g:shop:vview', current.id, tostring(d.model), d.mode == 'test' and 'test' or 'view') end return {} end

-- Voir / essayer un véhicule : véhicule local (visible de toi seul), choisi et validé par le serveur ------------------------------------------
local function endTry(reopen)
    local v = vsession
    if not v then return end
    vsession = nil
    local ped = PlayerPedId()
    if v.cam then RenderScriptCams(false, false, 0, true, true) DestroyCam(v.cam, false) end
    if v.veh and DoesEntityExist(v.veh) then
        if IsPedInVehicle(ped, v.veh, false) then TaskLeaveVehicle(ped, v.veh, 16) end
        DeleteEntity(v.veh)
    end
    if v.back then SetEntityCoords(ped, v.back.x, v.back.y, v.back.z, false, false, false, false) end
    FreezeEntityPosition(ped, false)
    G.send('prompt', { show = false })
    TriggerServerEvent('pb:g:shop:vend')
    if reopen and v.shop then TriggerServerEvent('pb:g:shop:open', v.shop) end
end
G.endVehicleTry = endTry
RegisterNetEvent('pb:g:shop:vgo', function(j)
    local d = G.decode(j)
    if not d or vsession then return end
    local hash = GetHashKey(tostring(d.model))
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then G.send('notify', { type = 'warn', text = "Ce véhicule n'existe pas dans ta version du jeu." }) return end
    RequestModel(hash)
    local t0 = GetGameTimer()
    while not HasModelLoaded(hash) and GetGameTimer() - t0 < 8000 do Wait(10) end
    if not HasModelLoaded(hash) then return end
    local ped = PlayerPedId()
    local pc = GetEntityCoords(ped)
    local sp = d.spawn or {}
    local sx, sy, sz, sh = (sp.x or pc.x) + 0.0, (sp.y or pc.y) + 0.0, (sp.z or pc.z) + 0.0, (sp.h or 0) + 0.0
    -- l'interface se ferme (le serveur garde la commande en cours)
    if current and current.clerk then TriggerServerEvent('pb:g:shop:closed') end
    current = nil
    G.send('shop.close', {})
    G.focus(false)
    local veh = CreateVehicle(hash, sx, sy, sz, sh, false, false)
    SetEntityAsMissionEntity(veh, true, true)
    SetVehicleOnGroundProperly(veh)
    SetVehicleNumberPlateText(veh, 'ESSAI')
    SetModelAsNoLongerNeeded(hash)
    vsession = { shop = d.shop, veh = veh, back = { x = pc.x, y = pc.y, z = pc.z }, mode = d.mode }
    local me = vsession
    if d.mode == 'test' then
        SetPedIntoVehicle(ped, veh, -1)
        local untilT = GetGameTimer() + math.floor((tonumber(d.seconds) or 60) * 1000)
        CreateThread(function()
            local lastSec
            while vsession == me do
                Wait(0)
                local left = math.max(0, math.ceil((untilT - GetGameTimer()) / 1000))
                if left ~= lastSec then lastSec = left G.send('prompt', { show = true, key = 'RETOUR', text = ('Essai de %s : %d s'):format(tostring(d.label or ''), left) }) end
                local c = GetEntityCoords(PlayerPedId())
                if left <= 0 or G.dead or IsControlJustPressed(0, 177) or #(c - vector3(sx, sy, sz)) > 700.0 or not DoesEntityExist(veh) then endTry(true) end
            end
        end)
    else
        FreezeEntityPosition(veh, true)
        FreezeEntityPosition(ped, true)
        local mn, mx = GetModelDimensions(hash)
        local size = math.max(mx.x - mn.x, mx.y - mn.y, 3.0)
        local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        vsession.cam = cam
        RenderScriptCams(true, true, 400, true, true)
        G.send('prompt', { show = true, key = '← →', text = ('%s : tourner, RETOUR pour revenir'):format(tostring(d.label or '')) })
        CreateThread(function()
            local ang, dist, lift = sh + 35.0, size * 1.6 + 1.5, size * 0.28 + 0.6
            while vsession == me do
                Wait(0)
                DisableAllControlActions(0)
                if IsDisabledControlPressed(0, 174) then ang = ang - 1.6 end
                if IsDisabledControlPressed(0, 175) then ang = ang + 1.6 end
                if IsDisabledControlPressed(0, 172) then dist = math.max(size * 0.9, dist - 0.08) end
                if IsDisabledControlPressed(0, 173) then dist = math.min(size * 3.5, dist + 0.08) end
                if not DoesEntityExist(veh) then break end
                local vc = GetEntityCoords(veh)
                local r = math.rad(ang)
                SetCamCoord(cam, vc.x + math.cos(r) * dist, vc.y + math.sin(r) * dist, vc.z + lift)
                PointCamAtCoord(cam, vc.x, vc.y, vc.z + (mx.z - mn.z) * 0.4)
                if IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 200) or G.dead then break end
            end
            endTry(true)
        end)
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and vsession then endTry(false) end end)


-- Sélecteur de destinataire (vendeur) : les joueurs proches sont repérés au-dessus de leur tête ; le vendeur clique sur l'un d'eux.
-- Le serveur fournit la liste (noms, distances) ; ici on projette les têtes à l'écran. L'attribution est revérifiée par le serveur.
local nearNames = {}
RegisterNetEvent('pb:g:shop:nearlist', function(j) local d = G.decode(j) if type(d) == 'table' then nearNames = d end end)
CreateThread(function()
    local lastAsk = 0
    while true do
        if current and current.clerk and (current.kind == 'store' or current.kind == 'weapons') then
            local t = GetGameTimer()
            if t - lastAsk > 1000 then lastAsk = t TriggerServerEvent('pb:g:shop:near', current.id) end
            local out = {}
            for _, n in ipairs(nearNames) do
                local pid = GetPlayerFromServerId(tonumber(n.id) or -1)
                local ped = pid ~= -1 and GetPlayerPed(pid) or 0
                if ped ~= 0 and DoesEntityExist(ped) then
                    local c = GetEntityCoords(ped)
                    local ok, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z + 1.05)
                    if ok then out[#out + 1] = { id = n.id, name = n.name, d = n.d, x = sx, y = sy } end
                else out[#out + 1] = { id = n.id, name = n.name, d = n.d } end
            end
            G.send('shop.targets', { list = out })
            Wait(80)
        else Wait(500) end
    end
end)
G.onForceClose(function() assignedFocus = false if G.endWeaponTest then pcall(G.endWeaponTest) end if G.endVehicleTry then pcall(G.endVehicleTry, false) end if G.wardrobe then endWardrobe(true) elseif current then closeShop() end end)
