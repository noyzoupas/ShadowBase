-- Extensions (côté client) : affichages communs de Shadow Base utilisables par une autre ressource, pour garder le même style partout.
--   exports.pb_panel:Prompt('Couper du bois', 'E')  /  exports.pb_panel:HidePrompt()
--   exports.pb_panel:Progress('Coupe du bois', 6)    /  exports.pb_panel:CancelProgress()
--   exports.pb_panel:Marker(x, y, z)                 (à appeler à chaque image, comme DrawMarker)
--   exports.pb_panel:IsFree()                        (personnage chargé, aucun menu ni interface ouverts)
-- Menus : exports.pb_panel:OpenMenu(def) (voir le module Menus du panel). Notifications : exports.pb_panel:Notify({ type, title, text }).
local G = PBG

local promptOwner
-- x, y, z (facultatifs) : position du point d'interaction, l'étiquette s'y accroche dans le monde
exports('Prompt', function(text, key, x, y, z)
    promptOwner = GetInvokingResource()
    local at = tonumber(x) and tonumber(y) and { x = tonumber(x), y = tonumber(y), z = tonumber(z) or 0 } or nil
    G.send('prompt', { show = true, key = tostring(key or 'E'), text = tostring(text or ''), at = at })
end)
exports('HidePrompt', function()
    if promptOwner and promptOwner ~= GetInvokingResource() then return end
    promptOwner = nil
    G.send('prompt', { show = false })
end)
exports('Progress', function(label, secs) G.send('crime.progress', { label = tostring(label or ''), secs = math.max(0.5, tonumber(secs) or 5), x = true }) end)   -- les extensions annulent avec X
-- Jauge en arc (même affichage que Progress, avec une valeur qui défile) :
--   exports.pb_panel:Gauge({ label = 'Plein', secs = 8, from = 0, to = 36.5, unit = '$', dec = 2, sub = 'Superplus 98' })
--   pilotée à la main : exports.pb_panel:GaugeSet(0.4, '14,2', 'Remplissage')  puis  exports.pb_panel:GaugeEnd(true, 'Plein terminé') / GaugeCancel()
exports('MenuSuspend', function() return G.Menu.Suspend() end)
exports('MenuResume', function() return G.Menu.Resume() end)
exports('SafeZone', function(on) G.send('safezone', { on = on and true or false }) end)
exports('Gauge', function(o) o = type(o) == 'table' and o or {} G.send('gauge', { label = tostring(o.label or ''), secs = math.max(0.5, tonumber(o.secs) or 5), from = tonumber(o.from), to = tonumber(o.to), unit = o.unit and tostring(o.unit) or nil, dec = tonumber(o.dec), sub = o.sub and tostring(o.sub) or nil, done = o.done and tostring(o.done) or nil }) end)
exports('GaugeSet', function(pct, value, sub, label) G.send('gauge', { set = true, pct = tonumber(pct) or 0, value = value ~= nil and tostring(value) or nil, sub = sub ~= nil and tostring(sub) or nil, label = label and tostring(label) or '' }) end)
exports('GaugeEnd', function(ok, text) G.send('gauge', { ['end'] = true, ok = ok ~= false, text = text and tostring(text) or nil }) end)
exports('GaugeCancel', function() G.send('gauge', { cancel = true }) end)
exports('CancelProgress', function() G.send('crime.progress', { cancel = true }) end)
exports('Marker', function(x, y, z, r, g, b, size) G.Point(x + 0.0, y + 0.0, z + 0.0, r or 255, g or 255, b or 255, (size or 1.0) + 0.0) end)
-- Libre = aucune interface réellement ouverte. (On ne lit plus G.nuiOpen : cette valeur n'est rafraîchie que par le chien de garde
-- et pouvait rester à « ouvert » après la fermeture d'un magasin, ce qui bloquait toutes les invites E des extensions.)
exports('IsFree', function()
    return G.begun == true and not G.Menu.IsOpen() and (G.locked or 0) <= 0 and not G.wardrobe and not G.creating and not G.barberOpen
        and not (G.shopIsOpen and G.shopIsOpen()) and not (G.radioOpen and G.radioOpen()) and not (G.state and G.state.dead) and not IsPauseMenuActive()
end)

-- une extension qui s'arrête ne laisse pas son invite à l'écran
AddEventHandler('onClientResourceStop', function(res)
    if promptOwner == res then promptOwner = nil G.send('prompt', { show = false }) end
end)
