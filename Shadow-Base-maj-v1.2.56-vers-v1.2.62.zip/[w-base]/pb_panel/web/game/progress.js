/* Barre de progression d'une activité (filière, braquage, blanchiment) : nom + barre qui se remplit. */
(function () {
const G = window.PBGame, h = G.h; let box, boxIv;
function dropBox() { clearInterval(boxIv); if (box) { box.remove(); box = null; } }
G.on('crime.progress', (d) => {
  dropBox();
  if (d.cancel) return;
  const secs = Number(d.secs) || 5, t0 = Date.now(), pct = h('span', { class: 'gpb-pct' }, '0%'), fill = h('i');
  box = h('div', { class: 'gp-box gpb' }, h('div', { class: 'gpb-top' }, h('b', null, String(d.label || '')), pct),
    h('div', { class: 'gpb-bar' }, fill),
    d.x ? h('div', { class: 'gpb-x' }, 'Appuyez sur ', h('kbd', null, 'X'), ' pour annuler') : null);
  G.root.appendChild(box);
  boxIv = setInterval(() => {
    const p = Math.min(1, (Date.now() - t0) / (secs * 1000));
    pct.textContent = Math.round(p * 100) + '%';
    fill.style.width = (p * 100).toFixed(1) + '%';
    if (p >= 1) { clearInterval(boxIv); const mine = box; setTimeout(() => { if (box === mine) dropBox(); }, 150); }
  }, 100);
});
// Braquage en cours : minuteur (temps d'attente du niveau), zone à tenir, compte à rebours quand on sort de la zone
let hb = null;
const TIER = { superette: 'Supérette', bijouterie: 'Bijouterie', fleeca: 'Banque Fleeca', maze: 'Grande banque' };
const mmss = (n) => { n = Math.max(0, Math.ceil(n)); return String(Math.floor(n / 60)).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0'); };
function heistEnd() { if (hb) { clearInterval(hb.iv); hb.el.remove(); hb = null; } }
G.on('crime.heist', (d) => {
  d = d || {};
  if (d.done) {
    if (!hb) return;
    hb.el.classList.add(d.ok ? 'ok' : 'ko');
    hb.sub.textContent = d.ok ? 'Butin récupéré : file !' : 'Braquage raté';
    clearInterval(hb.iv); const mine = hb; setTimeout(() => { if (hb === mine) heistEnd(); }, 2500);
    return;
  }
  if (d.out !== undefined) {
    if (!hb) return;
    hb.out = d.out ? Date.now() + Number(d.out) * 1000 : 0; hb.el.classList.toggle('out', !!d.out); return;
  }
  heistEnd();
  const secs = Number(d.secs) || 60, t = h('b', { class: 'hst-t' }, mmss(secs)), sub = h('small', null, ''), bar = h('i');
  const el = h('div', { class: 'gp-box gh-box' }, h('div', { class: 'hst-top' }, h('span', null, 'Braquage' + (TIER[d.tier] ? ' · ' + TIER[d.tier] : '')), t),
    h('b', { class: 'hst-l' }, String(d.label || '')), h('div', { class: 'gp-bar' }, bar), sub);
  G.root.appendChild(el);
  hb = { el, t, sub, bar, end: Date.now() + secs * 1000, secs, out: 0, zone: Number(d.zone) || 0 };
  const tick = () => {
    if (!hb) return;
    const left = (hb.end - Date.now()) / 1000;
    hb.t.textContent = mmss(left);
    hb.bar.style.width = Math.min(100, Math.max(0, (1 - left / hb.secs) * 100)).toFixed(1) + '%';
    if (hb.out) hb.sub.textContent = 'Hors de la zone : reviens ! ' + Math.max(0, Math.ceil((hb.out - Date.now()) / 1000)) + ' s';
    else hb.sub.textContent = left > 0 ? 'Police prévenue · tiens la zone (' + hb.zone + ' m) jusqu\'à la fin' : 'Reviens dans la zone pour récupérer le butin';
  };
  tick(); hb.iv = setInterval(tick, 250);
});
G.preview.crime = (el) => {
  G.clear(el);
  const row = (label, node) => h('div', { style: { display: 'grid', gap: '8px', justifyItems: 'center', alignContent: 'start' } }, h('small', { style: { opacity: '.6' } }, label), node);
  const prompt = h('div', { class: 'gp-box', style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none', width: 'auto', display: 'flex', gap: '10px', alignItems: 'center' } }, h('kbd', { style: { padding: '2px 8px', border: '1px solid rgba(223,226,231,.4)', borderRadius: '4px' } }, 'E'), h('b', null, 'Labo de séchage'));
  const bar = h('div', { class: 'gp-box', style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none' } }, h('b', null, 'Braquage de supérette'), h('div', { class: 'gp-bar' }, h('i', { style: { animation: 'none', width: '60%' } })));
  const terr = h('div', { class: 'gp-box', style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none' } }, h('b', null, 'Capture : Grove Street'), h('div', { class: 'gp-bar' }, h('i', { style: { animation: 'none', width: '35%' } })));
  el.appendChild(h('div', { class: 'cx-stage', style: { display: 'grid', gap: '18px', padding: '24px 10px', justifyItems: 'center', alignContent: 'center', height: 'auto' } }, row("Invite près d'un point", prompt), row('Braquage en cours', bar), row('Prise de territoire', terr)));
};
})();
