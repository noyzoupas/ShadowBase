/* Kit d'animations + jauge en arc.
   G.fx.ease / G.fx.count(el, de, à, durée, format) / G.fx.tween(durée, fn) : briques communes (chiffres qui défilent, valeurs qui glissent).
   G.gauge.start({ label, sub, secs, from, to, unit, dec }) : jauge chronométrée ; la valeur affichée va de « from » à « to » (sinon un pourcentage).
   G.gauge.set(pct, valeur, sous-titre) : jauge pilotée à la main ; G.gauge.end(ok, texte) : fin animée ; G.gauge.cancel() : disparaît. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, NS = 'http://www.w3.org/2000/svg';
const fx = G.fx = {
  ease: { out: (t) => 1 - Math.pow(1 - t, 3), inOut: (t) => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2), lin: (t) => t },
  // appelle fn(progression 0..1) à chaque image ; renvoie une fonction qui arrête l'animation
  tween(ms, fn, ease) {
    const e = ease || fx.ease.out, t0 = performance.now(); let raf = 0, dead = false;
    const step = (t) => { if (dead) return; const p = Math.min(1, (t - t0) / Math.max(1, ms)); fn(e(p), p); if (p < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => { dead = true; cancelAnimationFrame(raf); };
  },
  // fait défiler un nombre dans un élément
  count(el, from, to, ms, fmt) { return fx.tween(ms || 600, (k) => { el.textContent = (fmt || ((v) => Math.round(v)))(from + (to - from) * k); }); },
  num(v, dec) { return Number(v).toLocaleString('fr-FR', { minimumFractionDigits: dec || 0, maximumFractionDigits: dec || 0 }); },
};
// arc de 180° : de (20,110) à (210,110) par le haut, rayon 95
const R = 95, CX = 115, CY = 112, LEN = Math.PI * R;
const arcD = 'M ' + (CX - R) + ' ' + CY + ' A ' + R + ' ' + R + ' 0 0 1 ' + (CX + R) + ' ' + CY;
const sv = (tag, a) => { const e = document.createElementNS(NS, tag); Object.keys(a || {}).forEach((k) => e.setAttribute(k, a[k])); return e; };
let cur = null;
function drop(c) { if (!c) return; if (c.stop) c.stop(); if (c.iv) clearInterval(c.iv); c.el.remove(); if (cur === c) cur = null; }
function build(o) {
  const tr = sv('path', { d: arcD, class: 'tr' }), fl = sv('path', { d: arcD, class: 'fl' }), hd = sv('circle', { r: 4.5, class: 'hd' });
  fl.style.strokeDasharray = String(LEN); fl.style.strokeDashoffset = String(LEN);
  const svg = sv('svg', { viewBox: '0 0 230 122' }); svg.append(tr, fl, hd);
  const small = h('small', null, ''), val = h('strong'), unit = h('i', null, '');
  val.append(document.createTextNode('0'), unit);
  const right = h('span', null, ''), ckSvg = sv('svg', { viewBox: '0 0 24 24' }), ckP = sv('path', { d: 'M5 12.5l4.5 4.5L19 7' }); ckSvg.appendChild(ckP);
  const doneT = h('em', null, 'Terminé');
  const el = h('div', { class: 'gx' }, h('div', { class: 'gx-top' }, h('b', null, String(o.label || '')), right),
    h('div', { class: 'gx-dial' }, svg, h('div', { class: 'gx-mid' }, small, val), h('div', { class: 'gx-done' }, h('div', { class: 'ck' }, ckSvg), doneT)));
  G.root.appendChild(el);
  return { el, fl, hd, small, val, unit, right, doneT, ckP, shown: 0, last: 0 };
}
function paint(c, p) {   // p : 0..1
  p = Math.max(0, Math.min(1, p));
  c.fl.style.strokeDashoffset = String(LEN * (1 - p));
  const a = Math.PI * (1 - p), x = CX + R * Math.cos(a), y = CY - R * Math.sin(a);
  c.hd.setAttribute('cx', x.toFixed(1)); c.hd.setAttribute('cy', y.toFixed(1)); c.hd.style.opacity = p > 0.005 && p < 0.995 ? 1 : 0;
}
function start(o) {
  o = o || {};
  drop(cur);
  const c = cur = build(o);
  const secs = Math.max(0.5, Number(o.secs) || 5), t0 = Date.now(), hasVal = typeof o.to === 'number';
  const dec = o.dec || 0, from = Number(o.from) || 0, to = Number(o.to) || 0;
  c.unit.textContent = o.unit ? o.unit : (hasVal ? '' : '%');
  c.small.textContent = o.sub || (hasVal ? '' : 'Progression');
  const tick = () => {
    const p = Math.min(1, (Date.now() - t0) / (secs * 1000));
    paint(c, p);
    c.val.firstChild.nodeValue = hasVal ? fx.num(from + (to - from) * p, dec) : String(Math.round(p * 100));
    c.right.textContent = Math.max(0, secs * (1 - p)).toFixed(1).replace('.', ',') + ' s';
    if (p >= 1 && !c.finish) { c.finish = true; clearInterval(c.iv); c.timer = setTimeout(() => end(true, o.done), 120); }
  };
  c.val.firstChild.nodeValue = hasVal ? fx.num(from, dec) : '0';
  tick(); c.iv = setInterval(tick, 50);
  return c;
}
function set(pct, value, sub, o) {
  if (!cur) cur = build(o || { label: '' });
  const c = cur, to = Math.max(0, Math.min(1, Number(pct) || 0));
  const from = c.last; c.last = to;
  if (c.stop) c.stop();
  c.stop = fx.tween(260, (k) => paint(c, from + (to - from) * k));
  if (value !== undefined && value !== null) c.val.firstChild.nodeValue = String(value); else c.val.firstChild.nodeValue = String(Math.round(to * 100));
  if (sub !== undefined) c.small.textContent = String(sub);
}
function end(ok, text) {
  const c = cur; if (!c || c.ended) return;
  c.ended = true; clearInterval(c.iv); if (c.timer) clearTimeout(c.timer);
  if (ok !== false) paint(c, 1);
  c.doneT.textContent = text || (ok === false ? 'Interrompu' : 'Terminé');
  if (ok === false) c.ckP.setAttribute('d', 'M6 6l12 12M18 6L6 18');
  c.el.classList.add(ok === false ? 'ko' : 'ok');
  setTimeout(() => { c.el.classList.add('out'); setTimeout(() => drop(c), 360); }, ok === false ? 1100 : 1000);
}
function cancel() { const c = cur; if (!c) return; c.ended = true; if (c.timer) clearTimeout(c.timer); c.el.classList.add('out'); setTimeout(() => drop(c), 200); cur = null; }
G.gauge = { start, set, end, cancel };
// messages envoyés par les exports Lua (Gauge, GaugeSet, GaugeEnd, GaugeCancel)
G.on('gauge', (d) => {
  d = d || {};
  if (d.cancel) return cancel();
  if (d.end) return end(d.ok !== false, d.text);
  if (d.set) return set(d.pct, d.value, d.sub, d);
  start(d);
});
})();
