/* Notifications : position, style, durée et couleurs réglés depuis le panel. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const ICON = { info: 'info', success: 'check', warn: 'alert', error: 'alert' };
const TYPES = { success: 'success', ok: 'success', warn: 'warn', warning: 'warn', error: 'error', danger: 'error', info: 'info', inform: 'info' };

// Logo du serveur détouré : si l'image a un fond plein (carré noir, blanc…), ce fond est rendu transparent depuis les bords.
// Le résultat est gardé en mémoire (une seule fois par logo).
const detoured = {};
function detour(u, cb) {
  if (!u) return cb(u);
  if (detoured[u]) return cb(detoured[u]);
  const im = new Image();
  im.crossOrigin = 'anonymous';
  im.onload = () => {
    try {
      const w = im.naturalWidth, hh = im.naturalHeight, c = document.createElement('canvas');
      c.width = w; c.height = hh;
      const x = c.getContext('2d');
      x.drawImage(im, 0, 0);
      const d = x.getImageData(0, 0, w, hh), p = d.data;
      if (p[3] < 200) { detoured[u] = u; return cb(u); }   // déjà transparent sur les bords
      const r0 = p[0], g0 = p[1], b0 = p[2], seen = new Uint8Array(w * hh), st = [0, w - 1, (hh - 1) * w, hh * w - 1];
      const same = (i) => { const k = i * 4; return p[k + 3] > 150 && Math.abs(p[k] - r0) + Math.abs(p[k + 1] - g0) + Math.abs(p[k + 2] - b0) < 60; };
      while (st.length) {
        const i = st.pop();
        if (i < 0 || i >= w * hh || seen[i]) continue;
        seen[i] = 1;
        if (!same(i)) continue;
        p[i * 4 + 3] = 0;
        const xx = i % w;
        if (xx > 0) st.push(i - 1);
        if (xx < w - 1) st.push(i + 1);
        st.push(i - w, i + w);
      }
      x.putImageData(d, 0, 0);
      detoured[u] = c.toDataURL('image/png');
    } catch (e) { detoured[u] = u; }   // image d'un autre site (lecture interdite) : telle quelle
    cb(detoured[u]);
  };
  im.onerror = () => cb(null);
  im.src = u;
}
function logoImg(box) {
  const img = h('img', { alt: '', style: { visibility: 'hidden' } });
  detour(G.logoUrl(), (v) => { if (v) { img.src = v; img.style.visibility = ''; } else if (box) box.remove(); });   // pas de logo : on ne garde pas un trou vide
  return img;
}

// Chiffres, montants et x/y mis en valeur (orange), comme sur les notifications d'un serveur "pro" : « Vous avez ajouté 10.32L »
const NUM = /(?<![\p{L}\d])(\$?\d[\d.,]*(?:\/\d[\d.,]*)?(?:\s?(?:\$|€|%|kg|km|mg|ml|cl|L|g|h|min|s|m)(?![\p{L}\d]))?)(?![\p{L}])/gu;
function hl(text) {
  const out = []; let last = 0, m;
  NUM.lastIndex = 0;
  while ((m = NUM.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    out.push(h('em', { class: 'tn-v' }, m[1]));
    last = m.index + m[1].length;
    if (m[1].length === 0) NUM.lastIndex++;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}
G.hlText = hl;

function toastEl(cfg, n) {
  const type = TYPES[n.type] || 'info';
  const col = cfg['c_' + type] || { info: '#7cc8ff', success: '#5ee09a', warn: '#ffc65c', error: '#ff7a8c' }[type];
  const dur = Math.max(1000, Number(n.duration) || Number(cfg.duration) || 5000);
  const announce = n.kind === 'announce';
  const style = { '--tc': col, '--tc-rgb': G.hexToRgb(col), '--dur': dur + 'ms' };
  // D'après la photo de référence : logo sur tuile, type en gras (nom du serveur en petit dessous), barre de temps, message
  const CAT = { info: 'Informations', success: 'Succès', warn: 'Attention', error: 'Erreur' };
  const sub = String(n.sub || (announce ? (n.title || 'Annonce') : (n.title && !/^informations?$/i.test(n.title) ? n.title : CAT[type]))).slice(0, 60);
  const brand = String((G.brandName && G.brandName()) || 'Notification').slice(0, 40);
  const el = h('div', { class: 'tn tn-sh tn-ph tn-' + type + (announce ? ' tn-ann' : ''), style },
    h('div', { class: 'tn-hd' }, (function () { const lg = h('span', { class: 'tn-lg' }); lg.appendChild(logoImg(lg)); return lg; })(), h('div', { class: 'tn-ht' }, h('b', null, sub), h('small', null, brand))),
    h('i', { class: 'tn-p' }, h('em')),
    h('div', { class: 'tn-tx' }, hl(String(n.text || '').slice(0, 300))));
  if (n.click === 'reports') { el.setAttribute('data-click', 'reports'); el.addEventListener('click', () => G.post('staff.notif.click', { k: 'reports' })); }
  return { el, dur };
}

G.toastEl = toastEl;
let box = null;
function container() {
  if (!box) { box = h('div', { id: 'g-notify' }); G.root.appendChild(box); }
  const nc = G.cfg.notify || {};
  box.className = 'gp-' + (nc.position || 'map');
  box.style.bottom = (nc.position || 'map') === 'map' ? Math.max(5, Math.min(60, Number(nc.lift) || 24)) + 'vh' : '';
  // emplacement libre (placement en jeu) : coin haut-gauche de la pile, en % de l'écran
  const free = nc.position === 'custom';
  box.style.left = free ? Math.max(0, Math.min(80, Number(nc.x) || 0)) + 'vw' : '';
  box.style.top = free ? Math.max(0, Math.min(92, Number(nc.y) || 0)) + 'vh' : '';
  if (free) box.style.bottom = 'auto';
  return box;
}
G.on('cfg', () => { if (box) container(); });
// Une notification identique (même type, titre et texte) encore à l'écran ne s'empile pas : la carte existante affiche « x2, x3… »,
// remonte en tête et repart pour sa durée complète.
function hide(el) { el.classList.add('out'); setTimeout(() => el.remove(), 300); }
G.on('notify', (n) => {
  n = n || {};
  const cfg = G.cfg.notify || {}, c = container(), max = Math.max(1, Math.min(8, cfg.max || 4));
  const bottom = (cfg.position || 'map').indexOf('bottom') === 0;
  const key = [TYPES[n.type] || 'info', n.kind || '', n.title || '', n.text || ''].join('|');
  const same = Array.from(c.children).find((x) => x.__key === key && !x.classList.contains('out'));
  if (same) {
    same.__count = (same.__count || 1) + 1;
    let badge = same.querySelector('.tn-n');
    if (!badge) { badge = h('span', { class: 'tn-n' }); same.querySelector('.tn-hd b').appendChild(badge); }
    badge.textContent = 'x' + same.__count;
    const bar = same.querySelector('.tn-p'); if (bar) { const em = h('em'); G.clear(bar); bar.appendChild(em); }   // la barre de temps repart
    if (bottom) c.insertBefore(same, c.firstChild); else c.appendChild(same);
    clearTimeout(same.__t); same.__t = setTimeout(() => hide(same), same.__dur);
    return;
  }
  const { el, dur } = toastEl(cfg, n);
  el.__key = key; el.__dur = dur;
  if (bottom) c.insertBefore(el, c.firstChild); else c.appendChild(el);
  while (c.children.length > max) (bottom ? c.lastChild : c.firstChild).remove();
  el.__t = setTimeout(() => hide(el), dur);
});

// Bandeau « Zone capturée » : milieu droit de l'écran, petit, qui s'efface seul
G.on('zone.banner', (d) => {
  let el = document.getElementById('g-zone');
  if (!el) { el = h('div', { id: 'g-zone' }); G.root.appendChild(el); }
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color || '') ? d.color : '#e5384f';
  G.clear(el); el.style.setProperty('--zc', col); el.classList.remove('out');
  el.appendChild(h('b', null, String(d.title || 'Zone capturée').slice(0, 40))); el.appendChild(h('span', null, String(d.sub || '').slice(0, 60)));
  clearTimeout(el.__t); el.__t = setTimeout(() => { el.classList.add('out'); }, 7000);
});

// Point de vente (drapeau) : tant qu'on est dans la zone, en bas à droite : son état, puis une ligne par groupe présent (nom, effectif, progression)
G.on('flag.hud', (d) => {
  let el = document.getElementById('g-flagzone');
  const lift = () => {   // les munitions montent au-dessus
    const a = document.getElementById('g-flagzone');
    document.documentElement.style.setProperty('--flagpres-h', a && !a.classList.contains('out') ? (a.offsetHeight + 10) + 'px' : '0px');
  };
  if (!d || d.show === false || !d.title) { if (el) el.classList.add('out'); lift(); return; }
  if (!el) { el = h('div', { id: 'g-flagzone', class: 'out' }); G.root.appendChild(el); }
  G.clear(el);
  const flag = () => G.ico('flag');
  const title = [d.title, d.sub].filter(Boolean).join(' · ').slice(0, 44);
  el.appendChild(h('div', { class: 'fz-row fz-top' }, flag(), h('b', null, title), d.info ? h('small', null, String(d.info).slice(0, 60)) : null));
  (Array.isArray(d.pres) ? d.pres.slice(0, 6) : []).forEach((x) => {
    const pct = Math.max(0, Math.min(100, Math.floor(Number(x.prog) || 0)));
    el.appendChild(h('div', { class: 'fz-row fz-g' }, flag(),
      h('span', null, String(x.label || '').slice(0, 20) + ' (' + (Number(x.n) || 0) + ')'),
      h('b', null, pct + '%'), h('i', null, h('em', { style: { width: pct + '%' } }))));
  });
  el.classList.remove('out');
  lift();
});

// Entrée dans un territoire : carte au-dessus de la mini-carte (badge du gang, nom de la zone, gang qui la contrôle), dégradé à la couleur du gang
G.on('zone.enter', (d) => {
  const old = document.getElementById('g-terr');
  if (old) old.remove();
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color || '') ? d.color : '#9aa0aa';
  const gang = String(d.gang || '').slice(0, 32);
  const initials = gang ? gang.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() : '—';
  const el = h('div', { id: 'g-terr', class: gang ? '' : 'free' });
  el.style.setProperty('--tc', col);
  el.appendChild(h('div', { class: 'gt-top' },
    h('div', { class: 'gt-badge' }, initials),
    h('div', { class: 'gt-head' }, h('b', null, String(d.zone || 'Territoire').slice(0, 40)), h('span', null, 'Vous entrez en territoire'))));
  el.appendChild(h('div', { class: 'gt-foot' }, gang ? 'Sous le contrôle de ' : 'Territoire libre', gang ? h('em', null, gang) : null));
  G.root.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  setTimeout(() => { el.classList.remove('in'); el.classList.add('out'); setTimeout(() => el.remove(), 450); }, 6500);
});

G.preview.notify = function (box, cfg) {
  G.clear(box);
  const stage = h('div', { class: 'gstage' }), c = h('div', { class: 'gp-' + (cfg.position || 'map'), style: { position: 'absolute', inset: '14px' } });
  [['success', 'Achat réussi', 'Tu as payé 120 $ en espèces.'], ['announce', 'Annonce', 'Redémarrage du serveur dans 10 minutes.'], ['warn', 'Attention', 'Ta soif est très basse.'], ['error', 'Impossible', "Tu n'as pas assez d'argent."]]
    .slice(0, Math.max(1, Math.min(4, cfg.max || 4))).forEach((s) => { const t = toastEl(cfg, { type: s[0] === 'announce' ? 'info' : s[0], kind: s[0] === 'announce' ? 'announce' : undefined, title: s[1], text: s[2], duration: 1e6 }); t.el.classList.add('static'); c.appendChild(t.el); });
  stage.appendChild(c); box.appendChild(stage);
};
})();
