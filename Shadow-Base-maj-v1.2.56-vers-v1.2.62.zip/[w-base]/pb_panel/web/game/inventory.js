/* Inventaire : deux grilles (sac / coffre ou sol), glisser-déposer, double-clic, panneau de l'objet choisi. Le texte des objets passe par textContent uniquement. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const KIC = { food: 'food', drink: 'drop', medical: 'heart', tool: 'engine', doc: 'id', misc: 'cart' };
const KTONE = { food: '#ffb457', drink: '#6fb4ff', medical: '#ff6b7d', tool: '#dfe2e7', doc: '#9aa3b2', misc: '#7be0a4' };
const kg = (g) => (g / 1000).toFixed(g % 1000 === 0 ? 0 : 1) + ' kg';

const QUICK = 5;   // raccourcis d'armes : toujours 5, touches 1 à 5
const PER = 30;   // 5 colonnes × 6 lignes par page
const SAFE_IMG = /^(img\/[a-z]+\/[\w-]+\.[a-z]{3,4}|https:\/\/[\w.-]+\/[\w.%\/-]+)$/i;
  // Image d'un objet (illustration ou photo) ; si elle ne charge pas, l'icône de son type la remplace.
  function itemPic(it, cls) {
    const fb = () => h('span', { class: cls + ' ph' }, ico(KIC[it.kind] || 'cart'));
    if (!it.image || !SAFE_IMG.test(it.image)) return fb();
    const im = h('img', { class: cls, src: it.image, alt: '', draggable: false });
    im.onerror = () => { if (im.parentNode) im.parentNode.replaceChild(fb(), im); };
    return im;
  }
const SAFE_PH = /^(data:image\/jpeg;base64,[A-Za-z0-9+\/=]+|https:\/\/cdn\.discordapp\.com\/avatars\/\d+\/\w+\.png\?size=\d+)$/;
function inventoryView(opt) {
  opt = opt || {};
  let data = opt.data || { me: { slots: 0, items: [], weight: 0, maxw: 1, owner: 'p:x' }, near: [] }, sel = null, hov = null, hotbar = QUICK, filter = 'all', pos = opt.pos || null;
  const qty = h('input', { type: 'number', min: 1, value: '', placeholder: 'Tout', class: 'gv-qty' });
  const panels = {};
  const FILTERS = [['all', 'Tout', 'bag'], ['use', 'Utilisables', 'engine'], ['cons', 'Consommables', 'food'], ['weapons', 'Armes', 'crosshair'], ['clothes', 'Vêtements', 'tag'], ['misc', 'Divers', 'cart']];
  const FKIND = { cons: ['food', 'drink', 'medical'], weapons: ['weapon'], clothes: ['clothes', 'clothing'] };
  const matches = (it) => {
    if (filter === 'all') return true;
    if (filter === 'use') return !!it.usable;
    if (filter === 'weapons') return !!it.weapon || it.kind === 'weapon';
    const inKind = (k) => (FKIND[k] || []).indexOf(it.kind) >= 0;
    if (filter === 'misc') return !it.weapon && !Object.keys(FKIND).some(inKind);
    return inKind(filter);
  };
  const tabs = h('div', { class: 'gv-tabs' }), tabWt = h('span', { class: 'gv-twt' }, '');
  function drawTabs() { G.clear(tabs); FILTERS.forEach((f) => tabs.appendChild(h('button', { type: 'button', class: 'gv-tab' + (filter === f[0] ? ' on' : ''), title: f[1], 'aria-label': f[1], onclick: () => { filter = f[0]; drawTabs(); refresh(); } }, ico(f[2])))); tabs.appendChild(tabWt); }
  const left = h('div', { class: 'gv-left' }), info = h('div', { class: 'gv-info hidden' }), acts = h('div', { class: 'gv-acts hidden' });
  const panelsBox = h('div', { class: 'gv-panels' });
  left.appendChild(tabs); left.appendChild(panelsBox); left.appendChild(info); left.appendChild(acts);
  // centre : vêtements portés + raccourcis d'armes
  const SLOTS_L = [['hat', 'Casquette', 'user'], ['shirt', 'T-shirt', 'tag'], ['top', 'Veste / haut', 'tag'], ['vest', 'Gilet', 'shield'], ['gloves', 'Gants', 'paw'], ['legs', 'Pantalon', 'tag'], ['shoes', 'Chaussures', 'tag']];
  const SLOTS_R = [['mask', 'Masque', 'user'], ['glasses', 'Lunettes', 'eye'], ['ears', 'Boucles', 'star'], ['chain', 'Collier', 'star'], ['bracelet', 'Bracelet', 'coins'], ['watch', 'Montre', 'clock'], ['bag', 'Sac', 'bag']];
  const worn = () => (data && data.worn) || {};
  const ws = (d) => h('div', { class: 'gv-ws' + (worn()[d[0]] ? ' on' : ''), title: d[1] + (worn()[d[0]] ? ' : ' + worn()[d[0]] : '') }, ico(d[2]));
  const mid = h('div', { class: 'gv-mid' }), pager = h('div', { class: 'gv-pager' });
  const clothes = h('section', { class: 'gv-cl' });
  const quick = h('section', { class: 'gv-qk' });
  mid.appendChild(clothes); mid.appendChild(pager); left.appendChild(quick);
  function drawClothes() {
    G.clear(clothes);
    clothes.appendChild(h('div', { class: 'gv-wl' }, SLOTS_L.map(ws)));
    clothes.appendChild(h('div', { class: 'gv-wr' }, SLOTS_R.map(ws)));
  }
  function drawQuick() {
    G.clear(quick);
    quick.appendChild(h('b', { class: 'gv-h' }, 'RACCOURCI'));
    const rows = h('div', { class: 'gv-qr' });
    const mine = (data.me && data.me.items) || [];
    for (let i = 1; i <= QUICK; i++) {
      const it = mine.find((x) => x.slot === i);
      rows.appendChild(h('div', { class: 'gv-qs' + (it ? ' has' : ''), title: it ? it.label : 'Emplacement ' + i + ' (touche ' + i + ')' }, it ? h('span', { class: 'gv-ic' }, itemPic(it, 'gv-im')) : null, h('small', null, String(i)), it ? h('em', { class: 'gv-nm' }, it.label) : null));
    }
    quick.appendChild(rows);
  }
  // droite : joueurs à proximité
  const right = h('div', { class: 'gv-right' }), people = h('div', { class: 'gv-people' });
  right.appendChild(people);
  const el = h('div', { class: 'gv-win' }, left, h('i', { class: 'gv-sep' }), mid, right);
  drawTabs();
  const boxes = () => [data.me, data.other].filter(Boolean);
  const amount = (it) => { const n = parseInt(qty.value, 10); return n > 0 ? Math.min(n, it.qty) : it.qty; };
  function find(owner, slot) { const b = boxes().find((x) => x.owner === owner); return b && b.items.find((i) => i.slot === slot); }
  function firstFree(box, it) {
    const used = {}; box.items.forEach((i) => { used[i.slot] = i; });
    for (let s = 1; s <= box.slots; s++) { const i = used[s]; if (i && i.item === it.item && i.qty < i.stack) return s; }
    for (let s = 1; s <= box.slots; s++) if (!used[s]) return s;
    return null;
  }
  const sigOf = (box, slot, it, pg) => (it ? [it.item, it.qty, it.label, it.kind, it.image, matches(it) ? 1 : 0, it.usable ? 1 : 0].join('|') : '') + '#' + (sel && sel.owner === box.owner && sel.slot === slot ? 1 : 0) + (box.owner.indexOf('p:') === 0 && slot <= QUICK ? 'k' : '') + 'f' + filter + '@' + (Math.ceil(slot / PER) === pg ? 1 : 0);
  function paintCell(c, box, slot, it, show) {
    G.clear(c);
    c.className = 'gv-c' + (it ? ' has' : '') + (sel && sel.owner === box.owner && sel.slot === slot ? ' on' : '') + (show ? '' : ' hidden');
    c.title = '';
    c.draggable = false;
    if (box.owner.indexOf('p:') === 0 && slot <= QUICK) c.appendChild(h('kbd', null, String(slot)));
    if (!it) return;
    c.appendChild(h('span', { class: 'gv-ic' }, itemPic(it, 'gv-im')));
    c.appendChild(h('b', { class: 'gv-q' }, it.qty + 'x'));
    c.appendChild(h('em', { class: 'gv-nm' }, it.label));
  }
  let noClick = 0, drag = null;
  function dropTarget(x, y) {
    const t = document.elementFromPoint(x, y); if (!t || !t.closest) return null;
    const pp = t.closest('.gv-pp'); if (pp) return { kind: 'person', el: pp };
    const c = t.closest('.gv-c'), g = t.closest('.gv-grid');
    if (g) return { kind: 'slot', el: c || g, owner: g.getAttribute('data-owner'), slot: c ? Number(c.getAttribute('data-slot')) : 0 };
    return null;
  }
  function beginDrag(e, owner, slot, it) {
    const x0 = e.clientX, y0 = e.clientY; let ghost = null, lastEl = null;
    const mark = (el) => { if (lastEl && lastEl !== el) lastEl.classList.remove('over'); lastEl = el; if (el) el.classList.add('over'); };
    const move = (ev) => {
      if (!ghost) {
        if (Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) < 6) return;
        ghost = h('div', { class: 'gv-ghost' }, itemPic(it, 'gv-im'), h('b', null, amount(it) + 'x'));
        document.body.appendChild(ghost); sel = { owner, slot }; renderInfo(); drag = { owner, slot };
      }
      ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px';
      const tg = dropTarget(ev.clientX, ev.clientY);
      mark(tg && (tg.kind === 'person' ? (tg.el.classList.contains('far') ? null : tg.el) : (tg.slot ? tg.el : null)));
    };
    const end = (ev) => {
      document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', end); document.removeEventListener('pointercancel', end);
      if (!ghost) return;
      noClick = Date.now() + 250; ghost.remove(); mark(null); drag = null;
      if (ev.type === 'pointercancel') return;
      const tg = dropTarget(ev.clientX, ev.clientY); if (!tg) return;
      const src = find(owner, slot); if (!src) return;
      if (tg.kind === 'person') {
        if (owner !== data.me.owner || tg.el.classList.contains('far')) return;
        const pid = Number(tg.el.getAttribute('data-id')); if (pid) opt.onGive && opt.onGive(pid, slot, amount(src));
        return;
      }
      const box = boxes().find((b) => b.owner === tg.owner); if (!box) return;
      const ts = tg.slot || firstFree(box, src); if (!ts) return;
      if (tg.owner === owner && ts === slot) return;
      opt.onMove && opt.onMove(owner, slot, tg.owner, ts, amount(src));
    };
    document.addEventListener('pointermove', move); document.addEventListener('pointerup', end); document.addEventListener('pointercancel', end);
  }
  function buildPanel(box, title) {
    const grid = h('div', { class: 'gv-grid', 'data-owner': box.owner });
    const wt = h('span', { class: 'gv-wt' }, ''), bar = h('i'), ttl = h('b', null, ''), pg = h('div', { class: 'gv-pg' });
    const cells = [], sig = [];
    for (let s = 1; s <= box.slots; s++) { const c = h('div', { 'data-slot': s }); cells[s] = c; sig[s] = null; grid.appendChild(c); }
    const pn = { el: null, cells, sig, wt, bar, ttl, slots: box.slots, title, page: 1, pg };
    pn.el = h('section', { class: 'gv-p' }, h('header', null, ttl, wt), h('div', { class: 'gv-bar' }, bar), grid, pg);
    const slotOf = (e) => { const c = e.target.closest && e.target.closest('.gv-c'); return c ? Number(c.getAttribute('data-slot')) : 0; };
    grid.addEventListener('click', (e) => { if (Date.now() < noClick) return; const s = slotOf(e); if (!s) return; const it = find(box.owner, s); if (it) { sel = { owner: box.owner, slot: s }; refresh(); } });
    grid.addEventListener('mouseover', (e) => { const s = slotOf(e), it = s && find(box.owner, s); const n = it ? { owner: box.owner, slot: s } : null; if ((hov && hov.slot) !== (n && n.slot) || (hov && hov.owner) !== (n && n.owner)) { hov = n; renderInfo(); } });
    grid.addEventListener('mouseleave', () => { if (hov) { hov = null; renderInfo(); } });
    grid.addEventListener('dblclick', (e) => {
      const s = slotOf(e), it = s && find(box.owner, s); if (!it) return;
      if (box.owner === data.me.owner) { if (it.usable && !it.weapon) opt.onUse && opt.onUse(s); }
      else { const free = firstFree(data.me, it); if (free) opt.onMove && opt.onMove(box.owner, s, data.me.owner, free, amount(it)); }
    });
    grid.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const sl = slotOf(e), it = sl && find(box.owner, sl); if (!it) return;
      beginDrag(e, box.owner, sl, it);
    });
    return pn;
  }
  function fillPanel(pn, box) {
    const used = {}; box.items.forEach((i) => { used[i.slot] = i; });
    const pages = Math.max(1, Math.ceil(box.slots / PER)); pn.page = Math.min(pn.page, pages);
    pn.ttl.textContent = pn.title || box.label;
    pn.wt.textContent = (box.weight / 1000).toFixed(2) + ' / ' + (box.maxw / 1000).toFixed(1) + 'kg';
    pn.bar.style.width = Math.min(100, Math.round(box.weight / Math.max(1, box.maxw) * 100)) + '%';
    for (let s = 1; s <= box.slots; s++) {
      const sg = sigOf(box, s, used[s], pn.page);
      if (pn.sig[s] !== sg) { pn.sig[s] = sg; paintCell(pn.cells[s], box, s, used[s], filter === 'all' ? Math.ceil(s / PER) === pn.page : !!(used[s] && matches(used[s]))); }
    }
    const mine = box.owner === (data.me && data.me.owner);
    const tgt = mine ? pager : pn.pg;
    G.clear(tgt);
    if (filter !== 'all') { if (mine) tabWt.textContent = (box.weight / 1000).toFixed(1) + ' / ' + (box.maxw / 1000).toFixed(0) + 'kg'; if (mine) pn.el.classList.add('mine'); return; }
    tgt.appendChild(h('button', { type: 'button', class: 'gv-pb', disabled: pn.page <= 1, 'aria-label': 'Page précédente', onclick: () => { pn.page--; pn.sig = []; refresh(); } }, '‹'));
    tgt.appendChild(h('span', null, mine ? String(pn.page - 1) : 'Page ' + pn.page + ' / ' + pages));
    tgt.appendChild(h('button', { type: 'button', class: 'gv-pb', disabled: pn.page >= pages, 'aria-label': 'Page suivante', onclick: () => { pn.page++; pn.sig = []; refresh(); } }, '›'));
    if (mine) { tabWt.textContent = (box.weight / 1000).toFixed(1) + ' / ' + (box.maxw / 1000).toFixed(0) + 'kg'; pn.el.classList.add('mine'); }
  }
  function drawPeople() {
    G.clear(people);
    const list = data.near || [];
    people.appendChild(h('div', { class: 'gv-ph' }, h('b', { class: 'gv-h' }, 'Joueurs à proximité'), h('small', null, list.length + ' joueur' + (list.length > 1 ? 's' : ''))));
    const row = h('div', { class: 'gv-pl' + (pos ? ' abs' : '') });
    list.forEach((n) => {
      const p = pos && pos.find((x) => x.id === n.id);
      const ph = typeof n.photo === 'string' && n.photo.length < 120000 && SAFE_PH.test(n.photo) ? n.photo : '';
      const card = h('div', { class: 'gv-pp' + (n.far ? ' far' : ''), 'data-id': String(n.id), title: n.far ? 'Trop loin pour donner' : 'Glisse un objet ici pour le donner' },
        ph ? h('img', { class: 'gv-pi', src: ph, alt: '' }) : h('span', { class: 'gv-pi ph' }, ico('user')), h('b', null, n.name || ('Joueur ' + n.id)), h('i', { class: 'gv-plat' }));
      if (p) { card.style.left = (p.x * 100) + '%'; card.style.top = (p.y * 100) + '%'; card.style.width = (p.w * 100) + '%'; card.style.height = (p.h * 100) + '%'; }
      row.appendChild(card);
    });
    if (!list.length) row.appendChild(h('span', { class: 'gv-none' }, 'Personne autour de toi.'));
    people.appendChild(row);
  }
  function renderInfo() {
    G.clear(info); G.clear(acts);
    const pick = hov || sel;
    const it = pick && find(pick.owner, pick.slot);
    info.classList.toggle('hidden', !it);
    if (it) {
      info.appendChild(h('span', { class: 'gv-ii' }, itemPic(it, 'gv-im')));
      info.appendChild(h('div', { class: 'gv-it' }, h('b', null, it.label), h('small', null, it.desc || 'Aucune description.'),
        h('em', null, 'Quantité (' + it.qty + ') | Poids unitaire (' + (it.weight / 1000).toFixed(1) + ' kg) | Poids total (' + ((it.weight * it.qty) / 1000).toFixed(1) + ' kg)')));
    }
    const s = sel && find(sel.owner, sel.slot);
    acts.classList.toggle('hidden', !s && !opt.onClose);
    if (s) {
      const mine = sel.owner === data.me.owner;
      acts.appendChild(h('label', { class: 'gv-ql' }, h('small', null, 'Quantité'), qty));
      if (mine && s.weapon) acts.appendChild(h('small', { class: 'gv-hint' }, s.slot <= QUICK ? 'Arme : touche ' + s.slot + ' pour l\'équiper ou la ranger.' : 'Arme : place-la dans un raccourci (1 à 5) pour l\'équiper.'));
      if (mine && s.usable && !s.weapon) acts.appendChild(h('button', { type: 'button', class: 'gv-b pri', onclick: () => opt.onUse && opt.onUse(sel.slot) }, s.cloth ? ((data.worn && Object.keys(data.worn).some((k) => data.worn[k] === s.label)) ? 'Retirer' : 'Enfiler') : 'Utiliser'));
      if (mine) acts.appendChild(h('button', { type: 'button', class: 'gv-b', onclick: () => opt.onDrop && opt.onDrop(sel.slot, amount(s)) }, 'Jeter'));
    }
    if (opt.onClose) acts.appendChild(h('button', { type: 'button', class: 'gv-b', onclick: opt.onClose }, 'Fermer'));
  }
  function refresh() {
    const want = boxes();
    Object.keys(panels).forEach((k) => { const b = want.find((x) => x.owner === k); if (!b || panels[k].slots !== b.slots) { panels[k].el.remove(); delete panels[k]; } });
    want.forEach((b, i) => {
      if (!panels[b.owner]) { panels[b.owner] = buildPanel(b, i === 0 ? 'Inventaire' : (b.label || 'Sac')); panelsBox.insertBefore(panels[b.owner].el, panelsBox.children[i] || null); }
      fillPanel(panels[b.owner], b);
    });
    drawClothes(); drawQuick(); drawPeople(); renderInfo();
  }
  refresh();
  return { el, set(d) { data = d; if (sel && !find(sel.owner, sel.slot)) sel = null; hov = null; refresh(); }, setPos(p) { pos = p && p.length ? p : null; drawPeople(); } };
}
G.inventoryView = inventoryView;

let cur = null, pending = null;
const host = () => document.getElementById('g-inv') || (function () { const e = h('div', { id: 'g-inv', class: 'hidden' }); G.root.appendChild(e); return e; })();
// Lecture seule (coffre d'un véhicule vu depuis F5) : on regarde seulement. Les gestes (glisser, clic droit, double-clic, molette) sont
// bloqués avant d'atteindre les cases ; seuls les boutons de fermeture répondent. Le serveur refuse de toute façon.
let ro = false;
function setRo(on) {
  ro = !!on; document.body.classList.toggle('inv-ro', ro);
  const r = host(); const bar = r.querySelector('.inv-robar');
  if (ro && !bar) r.appendChild(h('div', { class: 'inv-robar' }, G.ico('eye'), 'Lecture seule · rien ne peut être pris'));
  else if (!ro && bar) bar.remove();
}
const isClose = (t) => !!(t && t.closest && t.closest('.e4-close, .gv-b'));
['pointerdown', 'mousedown', 'contextmenu', 'dblclick', 'wheel'].forEach((ev) => host().addEventListener(ev, (e) => {
  if (!ro || isClose(e.target)) return;
  e.stopPropagation(); if (ev !== 'wheel') e.preventDefault();
}, { capture: true, passive: false }));
G.on('inv.sync', (d) => { pending = d; if (cur) cur.set(d); setRo(d && d.ro); });
G.on('inv.pos', (d) => { if (cur) cur.setPos(Array.isArray(d.list) ? d.list.slice(0, 8) : null); });
// Style choisi dans le panel (Inventaire > Réglages) : « e4 » = maquette Figma (inventory-e4.js), « classic » = celui-ci
const useE4 = () => typeof G.inventoryE4 === 'function';   // v1.2.37 : un seul inventaire, Shadow Studio V2
G.on('inv.open', () => {
  if (G.sfx) G.sfx('inv_open');
  const r = host(); G.clear(r); r.classList.remove('hidden'); document.body.classList.add('inv-open');
  const o = { data: pending || undefined, hotbar: (G.cfg.inv || {}).hotbar, cfg: G.cfg, onClose: () => G.post('inv.close', {}),
    onMove: (fo, fs, to, ts, q) => G.post('inv.move', { fo, fs, to, ts, qty: q }), onUse: (s) => G.post('inv.use', { slot: s }),
    onGive: (t, s, q) => G.post('inv.give', { target: t, slot: s, qty: q }), onDrop: (s, q) => G.post('inv.drop', { slot: s, qty: q }), onDestroy: (s, q) => G.post('inv.destroy', { slot: s, qty: q }), onRename: (s, l) => G.post('inv.rename', { slot: s, label: l }) };
  if (cur && cur.destroy) cur.destroy();
  cur = useE4() ? G.inventoryE4(o) : inventoryView(o);
  r.appendChild(cur.el);
  setRo(pending && pending.ro);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'inv'); G.uiStack.push({ id: 'inv', onEscape: () => G.post('inv.close', {}) });
});
// Tab ferme l'inventaire (Tab l'ouvre côté jeu, réglage « Tab ouvre et ferme l'inventaire »)
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Tab' || !cur || (G.cfg.inv || {}).tab_opens === false || (G.cfg.inv || {}).no_weapon_wheel === false) return;
  if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
  const top = G.uiStack[G.uiStack.length - 1];
  if (top && top.id === 'inv') { e.preventDefault(); G.post('inv.close', {}); }
});
G.on('cfg', (c) => { if (cur && cur.setCfg) cur.setCfg(c); });
G.on('inv.close', () => { if (G.sfx && document.body.classList.contains('inv-open')) G.sfx('inv_open'); setRo(false); document.body.classList.remove('inv-open'); const r = host(); G.clear(r); r.classList.add('hidden'); if (cur && cur.destroy) cur.destroy(); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'inv'); });

G.preview.inventory = function (box) {
  G.clear(box);
  const it = (slot, item, label, kind, qty, weight, usable, stack) => ({ slot, item, label, kind, qty, weight, usable, stack: stack || 10, desc: '' });
  const data = { near: [{ id: 4, name: 'Camille Durand' }],
    me: { owner: 'p:demo', label: 'Sac à dos', slots: 18, maxw: 30000, weight: 4850, items: [it(1, 'water', "Bouteille d'eau", 'drink', 3, 500, true), it(2, 'burger', 'Burger', 'food', 2, 350, true), it(3, 'bandage', 'Bandage', 'medical', 4, 150, true), it(5, 'lockpick', 'Crochet', 'tool', 1, 100, false), it(9, 'id_card', "Carte d'identité", 'doc', 1, 20, false, 1)] },
    other: { owner: 's:demo', label: 'Coffre du commissariat', slots: 18, maxw: 200000, weight: 1200, items: [it(1, 'medkit', 'Trousse de soins', 'medical', 2, 900, true, 3), it(2, 'repair_kit', 'Kit de réparation', 'tool', 1, 2500, false, 3)] } };
  data.me.slots = 30; data.me.items.push(it(2, 'pistol', 'Glock-18', 'weapon', 1, 1100, false, 1)); data.me.items[1].slot = 24; data.me.items[1].qty = 2;
  data.worn = { hat: 'Casquette' };
  const o = { data, hotbar: 5, cfg: G.cfg, preview: true, onMove: (fo, fs, to, ts, q) => G.post('inv.move', { fo, fs, to, ts, qty: q }), onGive: (t, s, q) => G.post('inv.give', { target: t, slot: s, qty: q }) };
  const v = useE4() ? G.inventoryE4(o) : inventoryView(o);
  box.appendChild(h('div', { class: 'gstage tall' }, v.el));
};
})();
