/* Ammu-Nation : rayons à gauche, liste au centre, fiche de l'article. L'arme ou la boîte s'affiche en 3D devant le vendeur (client/shops.lua). Achat direct : shop.buy ; le serveur vérifie et encaisse. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const add = (el, ...k) => el.append(...k.filter((x) => x != null));   // append(null) écrirait « null »
const n0 = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR');
const isAmmo = (it) => it.type === 'ammo' || /^ammo/i.test(String(it.name || ''));
const rayOf = (it) => (it.type === 'weapon' && !isAmmo(it) ? 'weapons' : isAmmo(it) ? 'ammo' : 'kits');
const RAYS = [['weapons', 'Armes', 'crosshair', 'armes en vente'], ['ammo', 'Munitions', 'bag', 'calibres'], ['kits', 'Kits', 'tag', 'articles']];

G.gunshopView = function (data, opt) {
  opt = opt || {};
  const st = { data, ray: 'weapons', q: '', sort: 'asc', detail: null, qty: {}, cash: data.cash, bank: data.bank, stats: {} };
  const acc = G.accentHex();
  const rail = h('nav', { class: 'gu-rail' }), list = h('section', { class: 'gu-list' }), top = h('header', { class: 'gu-top' });
  const cap = h('div', { class: 'gu-cap' });
  const el = h('div', { class: 'gu', style: { '--gu': acc, '--gu-rgb': G.hexToRgb(acc) } },
    h('div', { class: 'gu-drag', onmousedown: (e) => { down = e.clientX; }, onwheel: (e) => post3d('shop.view3d.zoom', { d: e.deltaY > 0 ? 1 : -1 }) }), top, rail, list, cap,
    h('button', { class: 'gu-center', onclick: () => post3d('shop.view3d.reset', {}) }, 'Recentrer la vue'),
    h('footer', { class: 'gu-keys' }, h('span', null, h('kbd', null, 'Clic'), 'Tourner l\'aperçu'), h('span', null, h('kbd', null, 'Molette'), 'Zoomer'), h('span', null, h('kbd', null, 'ÉCHAP'), 'Fermer')));
  const fit = () => el.style.setProperty('--k', String(Math.min(window.innerWidth / 1920, window.innerHeight / 1080)));
  fit(); window.addEventListener('resize', fit);
  let down = null, hov = null;
  const post3d = (e, d) => (opt.static ? Promise.resolve({}) : G.post(e, d));
  const mv = (e) => { if (down === null) return; const dx = e.clientX - down; if (Math.abs(dx) >= 2) { post3d('shop.view3d.rot', { d: dx * 0.6 }); down = e.clientX; } };
  const up = () => { down = null; };
  document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);

  const items = () => st.data.items || [];
  const locked = (it) => it.vip && st.data.is_vip === false;
  function drawTop() {
    G.clear(top);
    const logo = st.data.logo && /^https:\/\//.test(st.data.logo) ? h('img', { src: st.data.logo, alt: '' }) : h('span', { class: 'gu-lg' }, ico('crosshair'));
    add(top, logo, h('div', { class: 'gu-tt' }, h('b', null, String(st.data.label || 'Ammu-Nation')), h('small', null, String(st.data.tagline || 'Armurerie'))), h('em'),
      h('span', { class: 'gu-mo' }, 'Banque', h('b', null, n0(st.bank) + ' $')), h('span', { class: 'gu-mo' }, 'Espèces', h('b', null, n0(st.cash) + ' $')), h('button', { class: 'gu-x', 'aria-label': 'Fermer', onclick: opt.onClose }, ico('close')));
  }
  function drawRail() {
    G.clear(rail);
    rail.appendChild(h('small', null, 'Rayons'));
    RAYS.forEach(([k, l, ic]) => { const n = items().filter((it) => rayOf(it) === k).length; if (n) rail.appendChild(h('button', { class: st.ray === k ? 'on' : '', onclick: () => { st.ray = k; st.detail = null; draw(); } }, ico(ic), h('span', null, l), h('em', null, String(n)))); });
    rail.appendChild(h('div', { class: 'gu-note' }, h('b', null, 'Paiement'), h('small', null, st.data.pay_mode === 'bank' ? 'Achats débités sur votre compte bancaire.' : st.data.pay_mode === 'cash' ? 'Paiement en espèces uniquement.' : 'En espèces, ou sur votre compte si elles ne suffisent pas.')));
  }
  function showCap(it, s) {
    G.clear(cap);
    if (!it) return;
    const chips = [];
    if (s && s.damage > 0) chips.push('Dégâts ' + Math.round(s.damage));
    if (s && s.clip > 0) chips.push('Chargeur ' + s.clip);
    if (locked(it)) chips.push('Réservé VIP');
    chips.push(n0(it.price) + ' $');
    add(cap, h('small', null, isAmmo(it) ? 'Munitions' : 'Catalogue'), h('b', null, String(it.label)), h('div', null, chips.map((c) => h('span', null, c))));
  }
  function preview(it) {
    if (!it) return;
    hov = it.name;
    showCap(it, st.stats[it.name]);
    post3d('shop.view3d', { name: it.name, hash: it.hash || '', ammo: isAmmo(it) }).then((r) => { if (r && (r.damage != null)) { st.stats[it.name] = r; if (hov === it.name) showCap(it, r); if (st.detail && st.detail.name === it.name) drawList(); } });
  }
  const buy = (it, qty) => G.post('shop.buy', { name: it.name, qty: qty || 1 });
  const thumb = (it) => { const u = it.image; return h('span', { class: 'gu-th' }, u ? h('img', { src: u, alt: '', loading: 'lazy', onerror: (e) => e.target.remove() }) : null); };
  function drawDetail(it) {
    const s = st.stats[it.name] || {};
    const stat = (v, l, bar) => h('div', { class: 'gu-st' }, h('b', null, String(v)), bar != null ? h('i', null, h('u', { style: { width: Math.min(100, bar) + '%' } })) : null, h('small', null, l));
    const stats = [];
    if (s.damage > 0) stats.push(stat(Math.round(s.damage), 'Dégâts', s.damage));
    if (Number(it.weight) > 0) stats.push(stat((Number(it.weight) / 1000).toFixed(2).replace('.', ',') + ' kg', 'Poids'));
    if (s.clip > 0) stats.push(stat(s.clip, 'Chargeur'));
    const out = it.stock != null && it.stock <= 0;
    add(list, h('div', { class: 'gu-lh' }, h('b', null, RAYS.find((r) => r[0] === st.ray)[1])),
      h('button', { class: 'gu-back', onclick: () => { st.detail = null; drawList(); } }, ico('back'), RAYS.find((r) => r[0] === st.ray)[1]),
      h('div', { class: 'gu-pic' }, it.image ? h('img', { src: it.image, alt: '', onerror: (e) => e.target.remove() }) : null),
      h('div', { class: 'gu-dt' }, h('b', null, String(it.label)), h('em', null, n0(it.price), h('small', null, ' $'))), it.desc ? h('p', { class: 'gu-desc' }, String(it.desc)) : null,
      stats.length ? h('div', { class: 'gu-stats' }, stats) : null, h('i', { class: 'gu-grow' }),
      locked(it) ? h('div', { class: 'gu-lock' }, ico('key'), 'Réservé aux abonnés VIP') : h('div', { class: 'gu-acts' },
        it.type === 'weapon' && st.data.test_sec && it.test !== false && opt.onTest ? h('button', { class: 'gu-ghost', onclick: () => opt.onTest(it) }, 'Tester ' + st.data.test_sec + ' s') : null,
        h('button', { class: 'gu-buy', disabled: out || null, onclick: () => buy(it, 1) }, out ? 'Épuisé' : 'Acheter')));
  }
  function drawList() {
    G.clear(list);
    if (st.detail) { drawDetail(st.detail); return; }
    const ray = RAYS.find((r) => r[0] === st.ray);
    let rows = items().filter((it) => rayOf(it) === st.ray && (!st.q || String(it.label).toLowerCase().indexOf(st.q) >= 0));
    rows = rows.slice().sort((a, b) => (st.sort === 'asc' ? a.price - b.price : b.price - a.price));
    add(list, h('div', { class: 'gu-lh' }, h('b', null, ray[1]), h('small', null, items().filter((it) => rayOf(it) === st.ray).length + ' ' + ray[3])));
    const find = h('input', { type: 'text', value: st.q, placeholder: 'Nom, calibre', oninput: (e) => { st.q = e.target.value.trim().toLowerCase(); drawRows(); } });
    list.appendChild(h('div', { class: 'gu-fil' }, h('div', { class: 'gu-find' }, ico('calc'), find), h('button', { class: 'gu-sort', onclick: () => { st.sort = st.sort === 'asc' ? 'desc' : 'asc'; drawRows(); } }, sortTxt())));
    const box = h('div', { class: 'gu-rows' });
    list.appendChild(box);
    function sortTxt() { return st.sort === 'asc' ? 'Prix croissant' : 'Prix décroissant'; }
    function drawRows() {
      list.querySelector('.gu-sort').textContent = sortTxt();
      G.clear(box);
      let r = items().filter((it) => rayOf(it) === st.ray && (!st.q || String(it.label).toLowerCase().indexOf(st.q) >= 0));
      r = r.slice().sort((a, b) => (st.sort === 'asc' ? a.price - b.price : b.price - a.price));
      if (!r.length) box.appendChild(h('p', { class: 'gu-none' }, 'Aucun résultat.'));
      r.forEach((it) => {
        const out = it.stock != null && it.stock <= 0;
        if (isAmmo(it)) {
          const q = st.qty[it.name] || 1, mx = Number(st.data.max_qty) || 10;
          box.appendChild(h('div', { class: 'gu-am' + (locked(it) ? ' lock' : ''), onmouseenter: () => preview(it) }, thumb(it), h('div', { class: 'gu-ai' }, h('b', null, String(it.label)), it.stock != null ? h('small', null, 'Stock : ' + it.stock) : null, h('small', null, h('b', null, n0(it.price) + ' $'), " l'unité")),
            locked(it) ? h('span', { class: 'gu-tag warn' }, 'Réservé VIP') : h('div', { class: 'gu-buyq' }, h('div', { class: 'gu-q' }, h('button', { onclick: () => { st.qty[it.name] = Math.max(1, q - 1); drawRows(); } }, '−'), h('b', null, String(q)), h('button', { onclick: () => { st.qty[it.name] = Math.min(mx, q + 1); drawRows(); } }, '+')),
              h('button', { class: 'gu-pay', disabled: out || null, onclick: () => buy(it, q) }, out ? 'Épuisé' : n0(it.price * q) + ' $'))));
          return;
        }
        box.appendChild(h('button', { class: 'gu-row' + (locked(it) ? ' lock' : ''), onmouseenter: () => preview(it), onclick: () => { st.detail = it; preview(it); drawList(); } }, thumb(it),
          h('div', { class: 'gu-ri' }, h('b', null, String(it.label)), h('small', null, it.category ? String(it.category) : '', Number(it.weight) > 0 ? ' · ' + (Number(it.weight) / 1000).toFixed(2).replace('.', ',') + ' kg' : '')),
          h('div', { class: 'gu-rp' }, h('b', null, n0(it.price), h('small', null, ' $')), locked(it) ? h('span', { class: 'gu-tag warn' }, 'Réservé VIP') : out ? h('span', { class: 'gu-tag warn' }, 'Épuisé') : null)));
      });
    }
    drawRows();
    const first = rows[0];
    if (first) preview(first); else showCap(null);
  }
  function draw() { drawTop(); drawRail(); drawList(); }
  draw();
  return { el, state: st, setMoney: (m) => { if (!m) return; st.cash = m.cash; st.bank = m.bank; drawTop(); }, update: (d) => { st.data = d; st.cash = d.cash; st.bank = d.bank; if (st.detail) st.detail = items().find((x) => x.name === st.detail.name) || null; draw(); },
    escape: () => { if (st.detail) { st.detail = null; drawList(); return true; } return false; }, onOrder() {}, onOrders() {}, onTicket() {}, onCat() {},
    destroy() { window.removeEventListener('resize', fit); document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); } };
};
})();
