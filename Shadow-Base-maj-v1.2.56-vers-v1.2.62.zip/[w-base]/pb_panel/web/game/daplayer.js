/* Petit lecteur de musique (panel › Interfaces › Musiques) : au choix du personnage et au créateur, retiré à l'arrivée en ville. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const SAFE = /^(https:\/\/[^\s"'<>()]+|musique\/[\w.\- /]+)$/;
const ICO = { prev: 'M6 5h2v14H6zM20 5v14L9 12z', next: 'M16 5h2v14h-2zM4 5v14l11-7z', pause: 'M7 5h4v14H7zM13 5h4v14h-4z', play: 'M7 5v14l12-7z', vol: 'M4 9v6h4l5 4V5L8 9zM16 9a4 4 0 010 6' };
const svg = (d) => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); const p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', d); s.appendChild(p); return s; };
let el = null, snd = null;
function stop() { if (snd) { snd.pause(); snd.src = ''; snd = null; } if (el) { el.remove(); el = null; } }
function start() {
  if (el) return;
  const u = (G.cfg && G.cfg.uida) || {};
  const list = (Array.isArray(u.ls_music) ? u.ls_music : []).map(String).filter((x) => SAFE.test(x)).map((x) => (x.indexOf('musique/') === 0 ? 'nui://wb_loading/' + x : x).replace(/ /g, '%20'));
  if (!list.length) return;
  let n = 0;
  snd = new Audio();
  try { snd.volume = Math.max(0, Math.min(1, Number(localStorage.getItem('pb_da_vol') || 0.3))); } catch (e) { snd.volume = 0.3; }
  const sub = h('small', null, '');
  const name = (x) => { try { return decodeURIComponent(x.split('/').pop().replace(/\.[a-z0-9]+$/i, '')).replace(/[_-]+/g, ' '); } catch (e) { return ''; } };
  const play = () => { snd.src = list[n]; sub.textContent = u.ls_music_sub || name(list[n]); snd.play().catch(() => {}); };
  const pp = h('button', { type: 'button', class: 'pl', 'aria-label': 'Lecture', onclick: () => { if (snd.paused) snd.play().catch(() => {}); else snd.pause(); } }, svg(ICO.pause));
  const sync = () => { G.clear(pp); pp.appendChild(svg(snd.paused ? ICO.play : ICO.pause)); };
  snd.addEventListener('play', sync); snd.addEventListener('pause', sync);
  snd.addEventListener('ended', () => { n = (n + 1) % list.length; play(); });
  const vol = h('input', { type: 'range', min: 0, max: 100, value: Math.round(snd.volume * 100), 'aria-label': 'Volume', oninput: (e) => { snd.volume = e.target.value / 100; try { localStorage.setItem('pb_da_vol', String(snd.volume)); } catch (x) { /* rien */ } } });
  el = h('div', { id: 'g-daplayer' }, h('button', { type: 'button', 'aria-label': 'Précédent', onclick: () => { n = (n - 1 + list.length) % list.length; play(); } }, svg(ICO.prev)), pp,
    h('button', { type: 'button', 'aria-label': 'Suivant', onclick: () => { n = (n + 1) % list.length; play(); } }, svg(ICO.next)),
    h('div', { class: 'dp-t' }, h('b', null, u.ls_music_title || 'Ambiance'), sub), h('span', { class: 'dp-v' }, svg(ICO.vol), vol));
  G.root.appendChild(el);
  play();
}
G.on('entrance.open', start);
G.on('creator.open', start);
G.on('arrive.open', stop);
G.on('creator.close', stop);
})();
