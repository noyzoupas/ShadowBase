/* Couleur d'accent commune des interfaces « tableau de bord » : la couleur principale du serveur (Général › Couleur principale).
   Posée en variables CSS (--da-ac, --da-rgb) : l'inventaire, la station, le choix du personnage et l'habillage global la lisent. */
(function () {
'use strict';
const G = window.PBGame;
G.daAccent = (cfg) => G.brandRgb(cfg).join(',');
function apply(c) {
  const rgb = G.daAccent(c || G.cfg), r = document.documentElement.style;
  r.setProperty('--da-rgb', rgb); r.setProperty('--da-ac', 'rgb(' + rgb + ')');
}
G.on('cfg', apply);
apply();
})();
