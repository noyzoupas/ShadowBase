/* Fiche d'informations posée à côté du menu ouvert (infos d'un joueur, papiers, argent, plaque…), à la place d'une notification.
   Jeu → NUI : G.send('infopanel', { title, rows: [[libellé, valeur], …], secs }). Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, timer = 0, watch = 0, sideOn = false;
const MENUS = ['#g-ctx .sx-menu', '#g-rmenu .rm', '#g-umenu .rm', '#g-staffhud .rm'];

function anchorRect() {
  for (const q of MENUS) { const m = document.querySelector(q); if (m && m.offsetWidth > 0) return m.getBoundingClientRect(); }
  return null;
}
function drop() { sideOn = false; clearTimeout(timer); clearInterval(watch); if (el) { el.remove(); el = null; } }
function show(d) {
  drop();
  d = d || {};
  const rows = (Array.isArray(d.rows) ? d.rows : []).slice(0, 16);
  if (!rows.length && !d.side) return;
  el = h('div', { id: 'g-info' },
    h('div', { class: 'if-t' }, String(d.title || 'Informations').slice(0, d.side ? 120 : 40)),
    h('div', { class: 'if-l' }, rows.map((r) => h('div', { class: 'if-r' }, h('span', null, String((r && r[0]) || '').slice(0, 40)), h('b', null, String((r && r[1]) == null ? '' : r[1]).slice(0, 90))))));
  G.root.appendChild(el);
  const a = anchorRect(), w = el.offsetWidth || 300, vw = window.innerWidth;
  if (a) {
    let left = a.right + 14; if (left + w > vw - 10) left = Math.max(10, a.left - 14 - w);
    el.style.left = left + 'px'; el.style.top = Math.max(10, a.top) + 'px';
  } else { el.style.right = '3vw'; el.style.top = '14vh'; }
  timer = setTimeout(drop, Math.max(4, Math.min(a ? 60 : 12, Number(d.secs) || 14)) * 1000);
  // accrochée à un menu : elle disparaît dès que ce menu se ferme (avant, elle restait jusqu'à la fin du délai)
  if (a) watch = setInterval(() => { if (!anchorRect()) drop(); }, 150);
}
// La ligne choisie d'un menu : même fiche, sans durée et sans animation à chaque déplacement. Une fiche demandée (Informations d'un joueur…) reste prioritaire.
G.infoSide = function (d) {
  if (el && !sideOn) return;
  if (!d) { if (sideOn) drop(); return; }
  show(Object.assign({ side: true }, d));
  if (!el) return;
  sideOn = true;
  clearTimeout(timer);
  el.style.animation = 'none';
};
G.on('infopanel', show);
G.on('infopanel.clear', drop);
G.on('rmenu.close', drop); G.on('umenu.close', drop); G.on('ctx.close', drop);
G.preview = G.preview || {};
G.preview.info = function (box) {
  G.clear(box);
  const demo = h('div', { id: 'g-info', class: 'in-preview' }, h('div', { class: 'if-t' }, 'Informations'),
    h('div', { class: 'if-l' }, [['Nom RP', 'Moha Wayne'], ['Emploi', 'Chômeur'], ['Argent', '$4 120'], ['Banque', '$0']].map((r) => h('div', { class: 'if-r' }, h('span', null, r[0]), h('b', null, r[1])))));
  box.appendChild(h('div', { class: 'hn-stage' }, demo));
};
})();
