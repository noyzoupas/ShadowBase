/* Réduit une capture d'écran en petit portrait carré (JPEG) avant de l'envoyer au serveur. */
(function () {
'use strict';
const G = window.PBGame;
G.on('photo.shrink', (d) => {
  const src = String(d.img || '');
  if (!/^data:image\/(jpeg|jpg|png);base64,/.test(src) || src.length > 6000000) return;
  const im = new Image();
  im.onload = () => {
    const side = Math.min(im.width, im.height) * 0.8, sx = (im.width - side) / 2, sy = (im.height - side) / 2;
    const c = document.createElement('canvas'); c.width = c.height = 112;
    c.getContext('2d').drawImage(im, sx, sy, side, side, 0, 0, 112, 112);
    G.post('photo.result', { img: c.toDataURL('image/jpeg', 0.7) });
  };
  im.src = src;
});
})();

// Personnage en pied : retire le fond vert, recadre, réduit, rend en WebP transparent
(() => {
const G = window.PBGame;
G.on('body.shrink', (d) => {
  const src = String(d.img || '');
  if (!/^data:image\/(jpeg|jpg|png);base64,/.test(src) || src.length > 6000000) return;
  const im = new Image();
  im.onload = () => {
    const W = im.width, H = im.height, c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0);
    const px = x.getImageData(0, 0, W, H), a = px.data;
    let x0 = W, y0 = H, x1 = 0, y1 = 0;
    for (let i = 0; i < a.length; i += 4) {
      const r = a[i], g = a[i + 1], b = a[i + 2], dom = g - Math.max(r, b);
      if (dom > 38 && g > 90) { a[i + 3] = 0; continue; }
      if (dom > 14) { a[i + 1] = Math.max(r, b); a[i + 3] = Math.max(0, 255 - (dom - 14) * 10); }   // reflet vert sur les bords
      if (a[i + 3] > 40) { const p = i / 4, X = p % W, Y = (p / W) | 0; if (X < x0) x0 = X; if (X > x1) x1 = X; if (Y < y0) y0 = Y; if (Y > y1) y1 = Y; }
    }
    if (x1 <= x0 || y1 <= y0) return;
    x.putImageData(px, 0, 0);
    const bw = x1 - x0 + 1, bh = y1 - y0 + 1, th = 260, tw = Math.max(40, Math.round(bw * th / bh));
    const o = document.createElement('canvas'); o.width = tw; o.height = th;
    o.getContext('2d').drawImage(c, x0, y0, bw, bh, 0, 0, tw, th);
    const out = o.toDataURL('image/webp', 0.8);
    if (out.slice(0, 23) === 'data:image/webp;base64,') G.post('body.result', { img: out });
  };
  im.src = src;
});
})();
