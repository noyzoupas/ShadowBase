/* Écran d'entrée (boîte de nuit) : titre « Appuyez sur E pour commencer » en haut à gauche (comme la référence), puis la fiche du
   personnage visé, les emplacements en bas, et la barre des touches. Le jeu déplace la caméra (client/entrance.lua).
   Envois : entrance.focus { i }, entrance.overview, entrance.play { i }. Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
let cur = null;
const host = () => document.getElementById('g-entrance') || (function () { const e = h('div', { id: 'g-entrance', class: 'hidden' }); G.root.appendChild(e); return e; })();
const money = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
function ago(t) {
  if (!t) return '—';
  const s = Math.max(0, Date.now() / 1000 - t), d = Math.floor(s / 86400);
  if (d >= 1) return d === 1 ? 'hier' : 'il y a ' + d + ' jours';
  const hh = Math.floor(s / 3600); return hh >= 1 ? 'il y a ' + hh + ' h' : "il y a moins d'une heure";
}

function entranceView(o) {
  const d = o.d || {};
  const list = d.list || [];
  const st = { phase: 'title', i: Math.max(0, list.findIndex((c) => c.name)) };
  // logo sans fond (celui du panel s'il est réglé, sinon le logo argent du serveur) et nom du serveur, sans cadre
  const logo = (G.cfg && G.cfg.brand && G.cfg.brand.logo) ? G.assetUrl(G.cfg.brand.logo) : '';
  const title = h('section', { class: 'en-title' },
    h('img', { src: 'img/brand/entree-logo.png', alt: '' }), h('b', null, String(d.title || 'Bienvenue')));
  const start = h('div', { class: 'en-start' }, h('kbd', null, 'E'), h('span', null, 'Commencer'));
  const card = h('section', { class: 'en-card hidden' });
  const slots = h('nav', { class: 'en-slots hidden' });
  const keys = h('footer', { class: 'en-keys hidden' });
  const leave = h('div', { class: 'en-leave hidden' });
  // Intro animée (panel › Écran d'entrée › Style de l'accueil) : bandes de cinéma, logo qui sort du flou, nom du serveur balayé par la lumière
  const isIntro = d.intro === 'intro';
  const intro = isIntro ? h('section', { class: 'en-intro' },
    h('div', { class: 'ei-shade' }), h('div', { class: 'ei-bar t' }), h('div', { class: 'ei-bar b' }),
    h('div', { class: 'ei-mid' }, h('div', { class: 'ei-halo' }), h('div', { class: 'ei-ring' }), h('img', { class: 'ei-logo', src: logo || G.logoUrl(), alt: '', 'data-pblogo': '1' }),
      h('div', { class: 'ei-title' }, String(d.title || 'Bienvenue')), h('div', { class: 'ei-line' }), d.slogan ? h('div', { class: 'ei-sub' }, String(d.slogan)) : null),
    h('div', { class: 'ei-load' }, h('i')),
    h('div', { class: 'ei-press' }, h('span', null, 'APPUIE SUR'), h('kbd', null, 'ENTRÉE'), h('span', null, 'POUR CONTINUER')),
    Number(d.maxp) > 0 ? h('div', { class: 'ei-meta', style: { left: '3.1%' } }, 'Joueurs en ligne ', h('b', null, String(Number(d.online) || 0) + ' / ' + String(Number(d.maxp)))) : null,
    d.discord ? h('div', { class: 'ei-meta', style: { right: '3.1%' } }, 'Discord ', h('b', null, String(d.discord))) : null) : null;
  const el = h('div', { class: 'en' + (isIntro ? ' intro' : '') }, h('div', { class: 'en-vig' }), title, start, card, slots, keys, leave, intro);

  const key = (k, t) => h('span', { class: 'en-k' }, [].concat(k).map((x) => h('kbd', null, x)), h('span', null, t));
  function drawKeys() {
    G.clear(keys);
    keys.appendChild(key(['←', '→'], 'Changer de personnage'));
    const c = list[st.i] || {};
    if (!c.locked) keys.appendChild(key('ENTRÉE', c.name ? 'Entrer en ville' : 'Créer ce personnage'));
    keys.appendChild(key('ÉCHAP', "Vue d'ensemble"));
  }
  function drawSlots() {
    G.clear(slots);
    slots.appendChild(h('button', { class: 'en-arr', onclick: () => step(-1) }, ico('back')));
    list.forEach((c, i) => slots.appendChild(h('button', { class: 'en-slot' + (i === st.i ? ' on' : '') + (c.locked ? ' lock' : '') + (!c.name && !c.locked ? ' new' : ''), onclick: () => pick(i) },
      h('i', null, c.locked ? ico('key') : (c.name ? String(i + 1) : ico('plus'))),
      h('span', null, c.locked ? 'Réservé VIP' : (c.name ? (c.first || c.name) : 'Nouveau')))));
    slots.appendChild(h('button', { class: 'en-arr', onclick: () => step(1) }, ico('chevron')));
  }
  function row(k, v) { return h('div', { class: 'en-row' }, h('span', null, k), h('b', null, v)); }
  function drawCard() {
    G.clear(card);
    const c = list[st.i] || {};
    card.appendChild(h('small', { class: 'en-kick' }, 'Personnage ' + (st.i + 1) + ' / ' + list.length));
    if (c.locked) {
      card.classList.add('locked');
      card.appendChild(h('h2', null, 'Emplacement verrouillé'));
      card.appendChild(h('p', { class: 'en-note' }, 'Joue plusieurs personnages avec le VIP. Il est disponible dans la boutique du serveur (/boutique).'));
      card.appendChild(h('div', { class: 'en-acts' }, h('button', { class: 'en-btn ghost', disabled: true }, ico('key'), 'Réservé VIP')));
      return;
    }
    card.classList.remove('locked');
    if (!c.name) {
      card.appendChild(h('h2', null, 'Nouveau personnage'));
      card.appendChild(h('p', { class: 'en-note' }, 'Crée ton personnage : visage, coupe, tenue, identité. Tu arriveras ensuite en ville.'));
      card.appendChild(h('div', { class: 'en-acts' }, h('button', { class: 'en-btn pri', onclick: play }, ico('plus'), 'Créer ce personnage')));
      return;
    }
    card.appendChild(h('h2', null, h('span', null, String(c.first || c.name)), c.last ? h('em', null, ' ' + c.last) : null));
    card.appendChild(h('div', { class: 'en-rows' },
      c.dob ? row('Né(e) le', String(c.dob)) : null,
      row('Métier', c.job ? String(c.job) : 'Sans emploi'),
      row('Liquide', money(c.cash)), row('Banque', money(c.bank)),
      row('Dernière connexion', ago(c.seen))));
    card.appendChild(h('div', { class: 'en-acts' }, h('button', { class: 'en-btn pri', onclick: play }, 'Entrer en ville', ico('arrow'))));
    // fondateur seulement (le serveur revérifie) : suppression définitive, il faut écrire SUPPRIMER
    if (o.d && o.d.founder) {
      const slotI = st.i;
      const acts = h('div', { class: 'en-acts' });
      const ask = () => {
        G.clear(acts);
        const go = h('button', { class: 'en-btn pri', disabled: true, onclick: () => o.onDelete(slotI + 1) }, 'Supprimer');
        const inp = h('input', { class: 'en-delin', type: 'text', maxlength: 9, placeholder: 'Écris SUPPRIMER', oninput: () => { go.disabled = inp.value !== 'SUPPRIMER'; }, onkeydown: (e) => e.stopPropagation() });
        acts.appendChild(inp); acts.appendChild(go);
        acts.appendChild(h('button', { class: 'en-btn ghost', onclick: drawCard }, 'Annuler'));
        setTimeout(() => inp.focus(), 30);
      };
      acts.appendChild(h('button', { class: 'en-btn ghost', onclick: ask }, ico('x'), 'Supprimer ce personnage'));
      card.appendChild(acts);
    }
  }
  function show(phase) {
    st.phase = phase;
    const sel = phase === 'select';
    title.classList.toggle('gone', sel);
    if (intro) intro.classList.toggle('gone', sel);
    start.classList.toggle('gone', sel);
    [card, slots, keys].forEach((x) => x.classList.toggle('hidden', !sel));
    if (sel) { drawCard(); drawSlots(); drawKeys(); }
  }
  function pick(i) {
    if (i < 0 || i >= list.length) return;
    const moved = i !== st.i || st.phase !== 'select';
    st.i = i; show('select');
    if (moved) o.onFocus(i + 1);
    card.classList.remove('swap'); void card.offsetWidth; card.classList.add('swap');
  }
  function step(dlt) { pick((st.i + dlt + list.length) % list.length); G.click(); }
  function play() { const c = list[st.i]; if (!c || c.locked) return; o.onPlay(st.i + 1); }
  function begin() { if (st.phase !== 'title') return; G.click(); pick(st.i); }
  function back() { if (st.phase === 'select') { show('title'); o.onOverview(); return true; } return false; }

  function onKey(e) {
    if (!el.isConnected || st.phase === 'leaving') return;
    const k = e.key;
    if (st.phase === 'title' && (k === 'e' || k === 'E' || k === 'Enter' || k === ' ')) { e.preventDefault(); begin(); return; }
    if (st.phase !== 'select') return;
    if (k === 'ArrowLeft' || k === 'ArrowUp') { e.preventDefault(); step(-1); }
    else if (k === 'ArrowRight' || k === 'ArrowDown') { e.preventDefault(); step(1); }
    else if (k === 'Enter') { e.preventDefault(); play(); }
  }
  document.addEventListener('keydown', onKey);
  title.addEventListener('click', begin);
  if (intro) { intro.style.pointerEvents = 'auto'; intro.addEventListener('click', begin); }
  return {
    el,
    leaving(name) {
      st.phase = 'leaving';
      [title, start, card, slots, keys].forEach((x) => x.classList.add('out'));
      if (intro) intro.classList.add('gone');
      G.clear(leave);
      leave.appendChild(h('small', null, 'Arrivée en ville')); leave.appendChild(h('b', null, String(name || ''))); leave.appendChild(h('i'));
      leave.classList.remove('hidden');
    },
    escape: back,
    destroy() { document.removeEventListener('keydown', onKey); },
  };
}
G.entranceView = entranceView;

function closeUi() { if (cur) cur.destroy(); const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'entrance'); document.body.classList.remove('en-on'); }
G.on('entrance.open', (d) => {
  if (cur) cur.destroy();
  const r = host(); G.clear(r); r.classList.remove('hidden');
  document.body.classList.add('en-on');
  cur = entranceView({ d, onFocus: (i) => G.post('entrance.focus', { i }), onOverview: () => G.post('entrance.overview', {}), onPlay: (i) => G.post('entrance.play', { i }), onDelete: (i) => G.post('entrance.delete', { i }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'entrance');
  G.uiStack.push({ id: 'entrance', onEscape: () => { if (cur) cur.escape(); } });
});
G.on('entrance.leaving', (d) => { if (cur) cur.leaving(d && d.name); G.uiStack = G.uiStack.filter((u) => u.id !== 'entrance'); });
G.on('entrance.close', closeUi);

G.preview.entrance = function (box, o) {
  G.clear(box);
  const s = h('div', { class: 'gstage en-stage' }); box.appendChild(s);
  const v = entranceView({ d: { title: 'Shadow', sub: 'Appuyez sur E pour commencer.', vip: false, intro: o && o.intro ? 'intro' : 'club', slogan: 'Roleplay', discord: 'discord.gg/monserveur', online: 42, maxp: 128,
    list: [{ slot: 1, name: 'Karl Wilmo', first: 'Karl', last: 'Wilmo', dob: '12/04/1994', job: 'Police de Los Santos', cash: 874969, bank: 19329, seen: Date.now() / 1000 - 86400 * 2 },
      { slot: 2, new: true }, { slot: 3, locked: true }] }, onFocus: () => {}, onOverview: () => {}, onPlay: () => {} });
  s.appendChild(v.el);
  if (o && o.phase === 'select') setTimeout(() => { const t = v.el.querySelector('.en-title'); if (t) t.click(); }, 0);
};
})();
