/* Bandeau « Zone sécurisée » : G.send('safezone', { on }) */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const SHIELD = 'M12 3l7 3v5c0 4.6-2.9 8.3-7 10-4.1-1.7-7-5.4-7-10V6zM8.8 12.2l2.2 2.2 4.2-4.4';
function svg(d) { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'), p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); s.setAttribute('viewBox', '0 0 24 24'); p.setAttribute('d', d); s.appendChild(p); return s; }
G.on('safezone', (d) => {
  let el = document.getElementById('g-safezone');
  if (!(d && d.on)) { if (el) el.remove(); return; }
  if (el) return;
  el = h('div', { id: 'g-safezone' }, h('div', { class: 'sx-safe' }, h('span', null, 'Zone sécurisée'), h('i', null, svg(SHIELD)))); G.root.appendChild(el);
});
})();
