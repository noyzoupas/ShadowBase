/* Tablette de police (MDT) : très transparente, tout en carrés et en rectangles. Ouverte par client/mdt.lua, données servies par server/game/mdt.lua.
   Rien n'est décidé ici : chaque requête est revérifiée par le serveur. Aucune donnée n'est insérée via innerHTML. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const PAGES = [
  { id: 'home', label: 'Accueil', icon: 'grid' }, { id: 'citizens', label: 'Citoyens', icon: 'users' },
  { id: 'vehicles', label: 'Véhicules', icon: 'car' }, { id: 'calls', label: 'Appels', icon: 'siren' },
  { id: 'wanted', label: 'Avis', icon: 'alert' }, { id: 'reports', label: 'Rapports', icon: 'file' },
  { id: 'units', label: 'Unités', icon: 'shield' }, { id: 'jail', label: 'Détenus', icon: 'lock' },
  { id: 'penal', label: 'Code pénal', icon: 'scale' },
];
const DANGER = { 1: 'Faible', 2: 'Modéré', 3: 'Élevé' };
const REPORT_KIND = { intervention: 'Intervention', arrestation: 'Arrestation', enquete: 'Enquête' };

let me = null, page = 'home', body = null, toastEl = null, statusEl = null, clockT = null, drawId = 0, ridNext = 0;
const pending = {};
const memo = { citQ: '', cit: null, vehQ: '', repQ: '', draft: null };

const host = () => document.getElementById('g-mdt') || (function () { const e = h('div', { id: 'g-mdt', class: 'hidden' }); G.root.appendChild(e); return e; })();

function req(op, p) {
  return new Promise((resolve, reject) => {
    const rid = ++ridNext;
    const timer = setTimeout(() => { delete pending[rid]; reject(new Error('Le serveur ne répond pas.')); }, 8000);
    pending[rid] = { resolve, reject, timer };
    G.post('mdt.req', { rid, op, p: p || {} });
  });
}
G.on('mdt.res', (d) => {
  const w = pending[d.rid]; if (!w) return;
  delete pending[d.rid]; clearTimeout(w.timer);
  if (d.err) w.reject(new Error(d.err)); else w.resolve(d.data || {});
});

function toast(ok, text) {
  if (!toastEl || !text) return;
  G.clear(toastEl).className = 'md-toast ' + (ok ? 'ok' : 'err');
  toastEl.appendChild(h('span', null, String(text)));
  clearTimeout(toastEl._t); toastEl._t = setTimeout(() => { toastEl.className = 'md-toast hidden'; }, 4000);
}
// action qui écrit : message du serveur, puis page redessinée
function act(op, p, after) {
  return req(op, p).then((d) => { toast(true, d.msg); if (after) after(d); else draw(); return d; }).catch((e) => toast(false, e.message));
}

// Briques ------------------------------------------------------------------------------------------------------------------------------
const box = (title, right, ...kids) => h('section', { class: 'md-box' }, title ? h('header', null, h('h3', null, title), right || null) : null, h('div', { class: 'md-box-b' }, kids));
const btn = (label, onclick, o) => { o = o || {}; return h('button', { type: 'button', class: 'md-btn' + (o.kind ? ' ' + o.kind : ''), onclick, disabled: o.disabled }, o.icon ? G.ico(o.icon) : null, label); };
const tag = (text, kind) => h('span', { class: 'md-tag' + (kind ? ' ' + kind : '') }, String(text));
const empty = (text) => h('div', { class: 'md-empty' }, text);
const cell = (label, value, kind) => h('div', { class: 'md-cell' + (kind ? ' ' + kind : '') }, h('small', null, label), h('b', null, value == null || value === '' ? '—' : String(value)));
const input = (o) => h('input', Object.assign({ class: 'md-in', type: 'text', spellcheck: 'false' }, o));
const select = (opts, value, onchange) => h('select', { class: 'md-in', onchange }, opts.map((x) => h('option', { value: x[0], selected: String(x[0]) === String(value) }, x[1])));
function searchBar(placeholder, value, onsearch, maxlength) {
  const i = input({ placeholder, value, maxlength: maxlength || 40, onkeydown: (e) => { if (e.key === 'Enter') onsearch(i.value); } });
  setTimeout(() => { if (i.isConnected) i.focus(); }, 0);
  return h('div', { class: 'md-search' }, G.ico('search'), i, btn('Chercher', () => onsearch(i.value), { kind: 'pri' }));
}
function table(cols, rows, onrow) {
  return h('div', { class: 'md-table' }, h('div', { class: 'md-tr md-th', style: { gridTemplateColumns: cols.map((c) => c.w || '1fr').join(' ') } }, cols.map((c) => h('span', null, c.label))),
    rows.map((r) => h('div', { class: 'md-tr' + (onrow ? ' click' : ''), style: { gridTemplateColumns: cols.map((c) => c.w || '1fr').join(' ') }, onclick: onrow ? () => onrow(r) : null },
      cols.map((c) => { const v = c.get ? c.get(r) : r[c.k]; return h('span', { title: typeof v === 'string' ? v : null }, v == null || v === '' ? '—' : v); }))));
}
const dangerTag = (n) => tag(DANGER[n] || DANGER[1], n >= 3 ? 'red' : n === 2 ? 'amber' : 'dim');

// lignes partagées par l'accueil et les pages
function callRow(c) {
  return h('div', { class: 'md-row' + (c.claimed ? '' : ' hot') },
    h('div', { class: 'md-num' }, '#' + c.id),
    h('div', { class: 'md-row-m' }, h('b', null, c.who), h('p', null, c.text), c.units ? h('small', null, 'Unités : ' + c.units) : null),
    h('div', { class: 'md-row-r' }, h('small', null, 'il y a ' + c.ago), h('div', { class: 'md-acts' },
      c.mine ? null : btn('Répondre', () => act('call', { id: c.id, act: 'claim' }), { kind: 'pri' }),
      c.pos ? btn('GPS', () => act('call', { id: c.id, act: 'gps' }, () => {})) : null,
      btn('Clore', () => act('call', { id: c.id, act: 'close' })))));
}
function wantedRow(w, withActs) {
  return h('div', { class: 'md-row' + (w.danger >= 3 ? ' hot' : '') },
    h('div', { class: 'md-num' }, G.ico(w.kind === 'vehicle' ? 'car' : 'user')),
    h('div', { class: 'md-row-m' }, h('b', null, w.label), h('p', null, w.reason), withActs ? h('small', null, w.by + ' · ' + w.at) : null),
    h('div', { class: 'md-row-r' }, dangerTag(w.danger), withActs ? h('div', { class: 'md-acts' },
      w.cid ? btn('Fiche', () => openCitizen(w.cid)) : null,
      w.plate ? btn('Plaque', () => { memo.vehQ = w.plate; go('vehicles'); }) : null,
      me.canRecords ? btn('Lever', () => act('wanted_del', { id: w.id })) : null) : null));
}
function unitTile(u) {
  return h('div', { class: 'md-unit c' + u.code.replace('-', '') }, h('b', null, u.code), h('span', { title: u.name }, u.name), h('small', null, u.grade + ' · ' + u.status));
}
// petit formulaire d'avis de recherche (personne : depuis sa fiche ; véhicule : plaque)
function wantedForm(base, after) {
  let danger = 1;
  const reason = input({ placeholder: 'Motif de la recherche', maxlength: 160 });
  const plate = base.kind === 'vehicle' && !base.plate ? input({ placeholder: 'Plaque', maxlength: 8, class: 'md-in md-plate' }) : null;
  return h('div', { class: 'md-form' }, plate, reason,
    select([[1, 'Danger faible'], [2, 'Danger modéré'], [3, 'Danger élevé']], 1, (e) => { danger = Number(e.target.value); }),
    btn('Diffuser', () => act('wanted_add', Object.assign({}, base, { plate: plate ? plate.value : base.plate, reason: reason.value, danger }), after), { kind: 'red', icon: 'alert' }));
}

// Pages -------------------------------------------------------------------------------------------------------------------------------
const VIEWS = {};
VIEWS.home = async function () {
  const d = await req('home');
  const stat = (label, value, icon, to, kind) => h('button', { type: 'button', class: 'md-stat' + (kind ? ' ' + kind : ''), onclick: () => go(to) }, G.ico(icon), h('b', null, String(value)), h('small', null, label));
  return h('div', { class: 'md-home' },
    h('div', { class: 'md-stats' },
      stat('Appels ouverts', d.nCalls, 'siren', 'calls', d.nCalls > 0 ? 'red' : ''),
      stat('Unités en service', d.units.length, 'shield', 'units'),
      stat('Avis de recherche', d.nWanted, 'alert', 'wanted', d.nWanted > 0 ? 'amber' : ''),
      stat('Détenus', d.nJailed, 'lock', 'jail')),
    h('div', { class: 'md-two' },
      box('Derniers appels', null, d.calls.length ? d.calls.map(callRow) : empty('Aucun appel ouvert.')),
      box('Avis prioritaires', null, d.wanted.length ? d.wanted.map((w) => wantedRow(w)) : empty('Aucun avis en cours.'))),
    box('Unités en service', null, d.units.length ? h('div', { class: 'md-units' }, d.units.map(unitTile)) : empty('Personne en service.')));
};

function openCitizen(cid) { memo.cit = cid; page = 'citizens'; rail(); draw(); }
VIEWS.citizens = async function () {
  const list = h('div', { class: 'md-list' });
  const detail = h('div', { class: 'md-detail' });
  const search = (q) => {
    memo.citQ = q;
    req('citizens', { q }).then((d) => {
      G.clear(list);
      if (!d.rows.length) { list.appendChild(empty('Aucun citoyen trouvé.')); return; }
      d.rows.forEach((r) => list.appendChild(h('button', { type: 'button', class: 'md-li' + (memo.cit === r.cid ? ' on' : ''), onclick: () => { memo.cit = r.cid; draw(); } },
        h('b', null, r.name), h('small', null, (r.dob || '') + (r.phone ? ' · ' + r.phone : '')), r.wanted ? tag('Recherché', 'red') : null)));
    }).catch((e) => toast(false, e.message));
  };
  if (memo.citQ) search(memo.citQ); else list.appendChild(empty('Cherche par nom ou par numéro de téléphone.'));
  if (memo.cit) detail.appendChild(citizenSheet(await req('citizen', { cid: memo.cit })));
  else detail.appendChild(empty('Choisis un citoyen dans la liste.'));
  return h('div', { class: 'md-split' }, h('div', { class: 'md-side' }, searchBar('Nom ou téléphone', memo.citQ, search), list), detail);
};
function citizenSheet(c) {
  const note = input({ placeholder: 'Ajouter une note au dossier', maxlength: 240 });
  const initials = c.name.split(/\s+/).map((x) => x.charAt(0)).join('').slice(0, 2).toUpperCase();
  return h('div', { class: 'md-sheet' },
    h('div', { class: 'md-head' + (c.wanted.length ? ' hot' : '') }, h('div', { class: 'md-avatar' }, initials),
      h('div', { class: 'md-head-m' }, h('h2', null, c.name), h('div', { class: 'md-tags' },
        c.wanted.length ? tag('Recherché', 'red') : tag('Aucun avis', 'dim'), c.jail ? tag(c.jail.kind + ' · ' + c.jail.left, 'amber') : null, tag(c.online ? 'En ville' : 'Absent', c.online ? 'blue' : 'dim')))),
    h('div', { class: 'md-cells' }, cell('Naissance', c.dob), cell('Sexe', c.sex), cell('Taille', c.height ? c.height + ' cm' : ''), cell('Nationalité', c.nationality), cell('Téléphone', c.phone),
      cell("Permis d'arme", c.permit ? 'Oui' : 'Non', c.permit ? 'ok' : ''), cell('Amendes impayées', c.unpaid ? c.unpaid + ' · ' + G.money(c.unpaidTotal) : 'Aucune', c.unpaid ? 'warn' : ''), cell('Véhicules', c.vehicles.length)),
    c.wanted.length ? box('Avis en cours', null, c.wanted.map((w) => wantedRow(w, true))) : (me.canRecords ? box('Émettre un avis de recherche', null, wantedForm({ kind: 'person', cid: c.cid })) : null),
    c.vehicles.length ? box('Véhicules', null, table([{ label: 'Plaque', w: '110px', get: (v) => h('span', { class: 'md-plate-v' }, v.plate) }, { label: 'Modèle', k: 'label' }, { label: 'État', w: '130px', k: 'state' }, { label: '', w: '100px', get: (v) => (v.wanted ? tag('Signalé', 'red') : '') }], c.vehicles, (v) => { memo.vehQ = v.plate; go('vehicles'); })) : null,
    box('Casier judiciaire', null, c.casier.length ? table([{ label: 'Date', w: '100px', k: 'at' }, { label: 'Type', w: '100px', k: 'kind' }, { label: 'Détail', k: 'text' }, { label: 'Par', w: '130px', k: 'by' }], c.casier) : empty('Casier vierge.')),
    c.reports.length ? box('Rapports liés', null, table([{ label: 'Date', w: '100px', k: 'at' }, { label: 'Titre', k: 'title' }], c.reports, (r) => { memo.report = r.id; go('reports'); })) : null,
    me.canRecords ? h('div', { class: 'md-form' }, note, btn('Ajouter', () => act('note', { cid: c.cid, text: note.value })), btn('Rédiger un rapport', () => { memo.draft = { cid: c.cid, name: c.name }; memo.report = null; go('reports'); }, { icon: 'file' })) : null);
}

VIEWS.vehicles = async function () {
  const res = h('div', { class: 'md-stack' });
  const search = (q) => {
    memo.vehQ = q;
    req('vehicles', { q }).then((d) => {
      G.clear(res);
      if (d.unknown) res.appendChild(box('Plaque inconnue', d.unknownWanted ? tag('Signalée', 'red') : null, h('p', { class: 'md-p' }, 'Aucun véhicule enregistré avec la plaque ' + d.unknown + '. Elle peut être fausse.'), (me.canRecords && !d.unknownWanted) ? wantedForm({ kind: 'vehicle', plate: d.unknown }) : null));
      d.rows.forEach((v) => res.appendChild(h('div', { class: 'md-veh' + (v.wanted ? ' hot' : '') },
        h('div', { class: 'md-plate-big' }, v.plate),
        h('div', { class: 'md-cells' }, cell('Modèle', v.label), cell('État', v.state, v.state === 'En fourrière' ? 'warn' : ''), cell('Motif', v.reason),
          v.cid ? h('button', { type: 'button', class: 'md-cell link', onclick: () => openCitizen(v.cid) }, h('small', null, 'Propriétaire'), h('b', null, v.owner)) : cell('Propriétaire', 'Flotte / inconnu')),
        v.wanted ? tag('Signalé', 'red') : (me.canRecords ? wantedForm({ kind: 'vehicle', plate: v.plate }) : null))));
    }).catch((e) => toast(false, e.message));
  };
  if (memo.vehQ) search(memo.vehQ); else res.appendChild(empty('Saisis une plaque, même partielle.'));
  return h('div', { class: 'md-stack' }, searchBar('Plaque', memo.vehQ, search, 8), res);
};

VIEWS.calls = async function () {
  const d = await req('calls');
  return box("Appels d'urgence (" + d.rows.length + ')', btn('Actualiser', () => draw(), { icon: 'refresh' }), d.rows.length ? d.rows.map(callRow) : empty('Aucun appel ouvert.'));
};
VIEWS.wanted = async function () {
  const d = await req('wanted');
  return h('div', { class: 'md-stack' },
    me.canRecords ? box('Signaler un véhicule', h('small', null, 'Une personne : depuis sa fiche, page Citoyens'), wantedForm({ kind: 'vehicle' })) : null,
    box('Avis en cours (' + d.rows.length + ')', null, d.rows.length ? d.rows.map((w) => wantedRow(w, true)) : empty('Aucun avis en cours.')));
};

VIEWS.reports = async function () {
  const list = h('div', { class: 'md-list' }), detail = h('div', { class: 'md-detail' });
  const load = (q) => {
    memo.repQ = q;
    req('reports', { q }).then((d) => {
      G.clear(list);
      if (!d.rows.length) { list.appendChild(empty('Aucun rapport.')); return; }
      d.rows.forEach((r) => list.appendChild(h('button', { type: 'button', class: 'md-li' + (memo.report === r.id ? ' on' : ''), onclick: () => { memo.report = r.id; memo.draft = null; draw(); } },
        h('b', null, r.title), h('small', null, r.at + ' · ' + r.by + (r.cit ? ' · ' + r.cit : '')))));
    }).catch((e) => toast(false, e.message));
  };
  load(memo.repQ);
  if (memo.report) {
    const r = await req('report', { id: memo.report });
    detail.appendChild(box(r.title, tag(REPORT_KIND[r.kind] || r.kind, 'blue'),
      h('div', { class: 'md-cells' }, cell('Rédigé par', r.by), cell('Date', r.at), r.cid ? h('button', { type: 'button', class: 'md-cell link', onclick: () => openCitizen(r.cid) }, h('small', null, 'Citoyen'), h('b', null, r.cit)) : cell('Citoyen', '')),
      h('p', { class: 'md-p md-pre' }, r.body),
      r.canDelete ? h('div', { class: 'md-acts' }, btn('Supprimer', () => act('report_del', { id: r.id }, () => { memo.report = null; draw(); }), { icon: 'trash' })) : null));
  } else if (me.canRecords) detail.appendChild(reportForm());
  else detail.appendChild(empty('Choisis un rapport.'));
  return h('div', { class: 'md-split' }, h('div', { class: 'md-side' }, searchBar('Titre ou citoyen', memo.repQ, load),
    me.canRecords ? btn('Nouveau rapport', () => { memo.report = null; memo.draft = null; draw(); }, { icon: 'plus', kind: 'pri' }) : null, list), detail);
};
function reportForm() {
  const f = memo.draft || {};
  let kind = 'intervention';
  const title = input({ placeholder: 'Titre', maxlength: 80 });
  const text = h('textarea', { class: 'md-in md-area', placeholder: 'Déroulé des faits', maxlength: 4000, spellcheck: 'false' });
  return box('Nouveau rapport', f.name ? tag('Lié à ' + f.name, 'blue') : null, h('div', { class: 'md-form' }, title, select(Object.entries(REPORT_KIND), kind, (e) => { kind = e.target.value; })), text,
    h('div', { class: 'md-acts' }, btn('Enregistrer', () => act('report_add', { kind, title: title.value, body: text.value, cid: f.cid }, (d) => { memo.report = d.id; memo.draft = null; draw(); }), { kind: 'pri', icon: 'check' })));
}

VIEWS.units = async function () {
  const d = await req('units');
  return box('Unités en service (' + d.rows.length + ')', null, d.rows.length ? h('div', { class: 'md-units big' }, d.rows.map(unitTile)) : empty('Personne en service.'));
};
VIEWS.jail = async function () {
  const d = await req('jail');
  return box('Détenus (' + d.rows.length + ')', null, d.rows.length ? table([{ label: 'Nom', k: 'name' }, { label: 'Peine', w: '80px', k: 'kind' }, { label: 'Reste', w: '100px', k: 'left' }, { label: 'Motif', k: 'reason' }, { label: 'Par', w: '130px', k: 'by' },
    { label: '', w: '170px', get: (r) => h('div', { class: 'md-acts' }, btn('Fiche', (e) => { e.stopPropagation(); openCitizen(r.cid); }), d.canRelease ? btn('Libérer', () => act('release', { cid: r.cid })) : null) }], d.rows) : empty('Aucun détenu.'));
};
VIEWS.penal = async function () {
  const d = await req('penal');
  const groups = {};
  d.rows.forEach((r) => { (groups[r.category || 'Autres'] = groups[r.category || 'Autres'] || []).push(r); });
  return h('div', { class: 'md-stack' },
    h('div', { class: 'md-cells' }, cell('Prison maximale', d.maxJail + ' min'), cell('TIG maximum', d.maxTig + ' tâches'), cell('Infractions', d.rows.length)),
    d.rows.length ? Object.keys(groups).map((g) => box(g, null, h('div', { class: 'md-fines' }, groups[g].map((f) => h('div', { class: 'md-fine' }, h('span', null, f.label), h('b', null, G.money(f.amount))))))) : empty('Le catalogue des amendes est vide (panel › Économie).'));
};

// Cadre ------------------------------------------------------------------------------------------------------------------------------
function draw() {
  if (!body) return;
  const id = ++drawId, p = page;
  VIEWS[p]().then((el) => {
    if (id !== drawId || !body) return;
    G.clear(body).appendChild(el);
    body.scrollTop = 0;
  }).catch((e) => {
    if (id !== drawId || !body) return;
    G.clear(body).appendChild(h('div', { class: 'md-empty err' }, e.message));
  });
}
let railEl = null;
function rail() {
  if (!railEl) return;
  G.clear(railEl);
  PAGES.forEach((x) => railEl.appendChild(h('button', { type: 'button', class: 'md-tile' + (page === x.id ? ' on' : ''), onclick: () => go(x.id) }, G.ico(x.icon), h('span', null, x.label))));
  railEl.appendChild(h('button', { type: 'button', class: 'md-tile off', onclick: () => G.post('mdt.close', {}) }, G.ico('x'), h('span', null, 'Fermer')));
}
function go(id) { page = id; rail(); draw(); }
function statusBar() {
  G.clear(statusEl);
  Object.keys(me.statuses).sort((a, b) => ['10-8', '10-97', '10-23', '10-6', '10-7'].indexOf(a) - ['10-8', '10-97', '10-23', '10-6', '10-7'].indexOf(b)).forEach((code) => statusEl.appendChild(
    h('button', { type: 'button', class: 'md-st' + (me.code === code ? ' on' : ''), onclick: () => req('status', { code }).then((d) => { me.code = d.code; statusBar(); if (page === 'units' || page === 'home') draw(); }).catch((e) => toast(false, e.message)) }, h('b', null, code), h('small', null, me.statuses[code]))));
}

G.on('mdt.open', (d) => {
  me = d; page = 'home'; memo.citQ = ''; memo.cit = null; memo.vehQ = ''; memo.repQ = ''; memo.report = null; memo.draft = null;
  const r = host(); G.clear(r); r.classList.remove('hidden');
  const a = Math.max(0, Math.min(70, Number(d.opacity) || 0)) / 100;
  r.style.setProperty('--md-a', String(a));
  r.style.setProperty('--md-c', /^#[0-9a-f]{6}$/i.test(d.color || '') ? d.color : '#4da3ff');
  railEl = h('nav', { class: 'md-rail' });
  statusEl = h('div', { class: 'md-status' });
  body = h('main', { class: 'md-body' });
  toastEl = h('div', { class: 'md-toast hidden' });
  const clock = h('b', { class: 'md-clock' });
  const tick = () => { const n = new Date(); clock.textContent = String(n.getHours()).padStart(2, '0') + ':' + String(n.getMinutes()).padStart(2, '0'); };
  tick(); clearInterval(clockT); clockT = setInterval(tick, 5000);
  r.appendChild(h('div', { class: 'md-tablet' }, h('i', { class: 'md-c tl' }), h('i', { class: 'md-c tr' }), h('i', { class: 'md-c bl' }), h('i', { class: 'md-c br' }),
    h('header', { class: 'md-top' },
      h('div', { class: 'md-brand' }, h('span', { class: 'md-logo' }, G.ico('shield')), h('div', null, h('b', null, d.biz), h('small', null, 'Mobile Data Terminal'))),
      statusEl,
      h('div', { class: 'md-me' }, h('div', null, h('b', null, d.name), h('small', null, d.grade)), clock)),
    railEl, body, toastEl));
  rail(); statusBar(); draw();
  G.uiStack = G.uiStack.filter((u) => u.id !== 'mdt'); G.uiStack.push({ id: 'mdt', onEscape: () => G.post('mdt.close', {}) });
});
G.on('mdt.close', () => {
  const r = host(); G.clear(r); r.classList.add('hidden');
  clearInterval(clockT); me = null; body = null; railEl = null; statusEl = null; toastEl = null; drawId++;
  G.uiStack = G.uiStack.filter((u) => u.id !== 'mdt');
});
})();
