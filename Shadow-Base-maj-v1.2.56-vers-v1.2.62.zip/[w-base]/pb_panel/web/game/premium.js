/* Boutique du serveur (coins) v4 — mise en page « boutique de serveur » : en-tête (logo, nom, code boutique, VIP, coins, acheter des coins),
   catégories à gauche (offres du jour, véhicules, coffres, armes, VIP, boosts…), cartes par rareté, fenêtre de confirmation, ouverture de coffre.
   Le serveur décide de tout (prix, offres du jour, tirage des coffres) ; ici on affiche et on envoie premium.buy / premium.claim / premium.close.
   Tout texte venant du serveur est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
let cur = null;
const host = () => document.getElementById('g-premium') || (function () { const e = h('div', { id: 'g-premium', class: 'hidden' }); G.root.appendChild(e); return e; })();
const num = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR');
const okHex = (c) => /^#?[0-9a-f]{6}$/i.test(c || '');
const hexRgb = (c) => { c = String(c).replace('#', ''); return [0, 2, 4].map((i) => parseInt(c.substr(i, 2), 16)).join(','); };
const CAT_IMG = { vehicle: 'img/cards/veh.jpg', villa: 'img/cards/city.jpg', money: 'img/cards/wallet.jpg', vip: 'img/cards/sky.jpg', boost: 'img/cards/sea.jpg', weapon: 'img/cards/city.jpg', item: 'img/cards/inv.jpg', plate: 'img/cards/veh.jpg' };
const CAT_ICO = { vehicle: 'car', weapon: 'crosshair', vip: 'crown', boost: 'bolt', villa: 'home', money: 'coins', item: 'box', plate: 'card' };
const pad = (n) => String(Math.max(0, Math.floor(n))).padStart(2, '0');
const clock = (s) => pad(s / 3600) + 'H ' + pad((s % 3600) / 60) + 'M ' + pad(s % 60) + 'S';

function premiumView(o) {
  let d = o.d || {};
  const rar = {};
  (d.rarity || [{ id: 'commun', label: 'Commun', color: '#9aa3b2' }]).forEach((r) => { rar[r.id] = r; });
  const R = (id) => rar[id] || rar.commun || { label: 'Commun', color: '#9aa3b2' };
  const accent = G.accentHex();
  const st = { view: d.daily && d.daily.length ? 'daily' : ((d.cats || [])[0] || {}).id, q: '' };
  const coinName = () => String(d.coin || 'Coins');
  let resetAt = Date.now() + (Number(d.reset_in) || 0) * 1000;

  // --- squelette ---
  const logo = (G.cfg && G.cfg.brand && G.cfg.brand.logo) ? G.assetUrl(G.cfg.brand.logo) : 'img/brand/shadow-logo.png';
  const headR = h('div', { class: 'zs-hr' });
  const side = h('nav', { class: 'zs-side' });
  const title = h('h2', null, ''), timer = h('span', { class: 'zs-timer hidden' }), tools = h('div', { class: 'zs-tools' });
  const grid = h('div', { class: 'zs-grid' });
  const modal = h('div', { class: 'zs-modal hidden' });
  const toast = h('div', { class: 'zs-toast hidden' });
  const el = h('div', { class: 'zs', style: { '--acc': accent, '--acc-rgb': hexRgb(accent) } },
    h('div', { class: 'zs-win' },
      h('header', { class: 'zs-head' }, h('div', { class: 'zs-hl' }, h('img', { src: logo, alt: '' }), h('b', null, h('span', null, 'Boutique '), h('em', null, String(d.name || '').replace(/^Boutique\s*/i, '') || 'du serveur'))), headR),
      h('div', { class: 'zs-body' }, side, h('main', { class: 'zs-main' }, h('div', { class: 'zs-mh' }, title, h('div', { class: 'zs-mr' }, tools, timer)), grid))),
    modal, toast);
  let tt = null;
  function say(ok, msg) { if (!msg) return; toast.textContent = String(msg); toast.className = 'zs-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(tt); tt = setTimeout(() => toast.classList.add('hidden'), 4500); }

  // --- en-tête : code boutique, VIP, coins, acheter des coins ---
  function drawHead() {
    G.clear(headR);
    headR.appendChild(h('div', { class: 'zs-code', title: 'Donne ce code pour créditer tes coins (boutique en ligne)' }, h('small', null, 'Code', h('br'), 'boutique'), h('b', null, String(d.id != null ? d.id : '—'))));
    headR.appendChild(h('i', { class: 'zs-sep' }));
    const vip = d.vip;
    headR.appendChild(h('div', { class: 'zs-badge vip' + (vip ? '' : ' off') }, ico('crown'), h('div', null, h('b', null, vip ? 'VIP' : 'Sans VIP'),
      h('small', null, vip ? (vip.life ? 'À vie' : (vip.until_at ? "Jusqu'au " + new Date(vip.until_at * 1000).toLocaleDateString('fr-FR') : 'Actif')) : 'Voir la catégorie VIP'))));
    headR.appendChild(h('div', { class: 'zs-badge coin' }, ico('coins'), h('div', null, h('b', null, num(d.coins)), h('small', null, coinName()))));
    headR.appendChild(h('button', { type: 'button', class: 'zs-badge buy', onclick: buyCoins }, ico('gem'), h('div', null, h('b', null, 'Acheter des ' + coinName().toLowerCase()), h('small', null, 'Se rendre sur la boutique'))));
    headR.appendChild(h('button', { type: 'button', class: 'zs-x', title: 'Fermer', onclick: () => o.onClose && o.onClose() }, ico('x')));
  }
  function buyCoins() {
    G.click();
    const url = String(d.url || '');
    if (!/^https:\/\//.test(url)) { say(false, "La boutique en ligne n'est pas encore configurée : demande au staff."); return; }
    try { if (window.invokeNative) { window.invokeNative('openUrl', url); say(true, "La boutique en ligne s'ouvre dans ton navigateur."); return; } } catch (e) { /* hors jeu */ }
    say(true, 'Boutique en ligne : ' + url + ' — ton code boutique : ' + (d.id != null ? d.id : '?'));
  }

  // --- catégories ---
  const SUBS = { daily: 'Offres à durée limitée', mine: 'Ce que tu as acheté', hist: 'Mouvements de ' + coinName().toLowerCase() };
  function navBtn(id, icon, label, sub, count) {
    return h('button', { type: 'button', class: 'zs-nv' + (st.view === id ? ' on' : ''), onclick: () => { if (st.view !== id) { G.click(); st.view = id; draw(); } } },
      h('span', { class: 'zs-ni' }, ico(icon)), h('div', null, h('b', null, label), h('small', null, sub || '')), count != null ? h('em', null, String(count)) : null);
  }
  function drawSide() {
    G.clear(side);
    if ((d.daily || []).length) side.appendChild(navBtn('daily', 'clock', 'Journalières', SUBS.daily));
    (d.cats || []).forEach((c) => { const n = (d.items || []).filter((i) => i.cat === c.id).length; if (n) side.appendChild(navBtn(c.id, c.icon || 'star', c.label, 'Liste des ' + String(c.label).toLowerCase(), null)); });
    side.appendChild(h('i', { class: 'zs-gap' }));
    side.appendChild(navBtn('mine', 'box', 'Mes achats', SUBS.mine, (d.owned || []).length || null));
    side.appendChild(navBtn('hist', 'file', 'Historique', SUBS.hist));
    if ((d.boosts || []).length) {
      side.appendChild(h('div', { class: 'zs-boosts' }, h('small', null, 'Boosts actifs'), (d.boosts || []).map((b) => h('span', null, ico('bolt'), String(b.label) + ' +' + b.pct + ' %', h('em', null, Math.ceil(b.left / 3600) + ' h')))));
    }
  }

  // --- cartes ---
  function img(c) {
    const box = h('div', { class: 'zs-img' }, h('i', { class: 'zs-bgimg', style: { backgroundImage: 'url("' + (CAT_IMG[c.cat] || CAT_IMG.item) + '")' } }));
    const src = G.assetUrl(c.img || '') || (c.img && /^https:\/\//.test(c.img) ? c.img : '');
    if (src) { const im = h('img', { src, alt: '', loading: 'lazy' }); im.addEventListener('error', () => { im.remove(); box.appendChild(h('span', { class: 'zs-big' }, ico(CAT_ICO[c.cat] || c.icon || 'star'))); }); box.appendChild(im); }
    else box.appendChild(h('span', { class: 'zs-big' }, ico(CAT_ICO[c.cat] || c.icon || 'star')));
    return box;
  }
  function state(c) {
    if (c.daily && c.bought) return h('span', { class: 'zs-chip done' }, ico('check'), 'Déjà acheté');
    if (c.owned) return h('span', { class: 'zs-chip done' }, ico('check'), 'Possédé');
    if (c.taken) return h('span', { class: 'zs-chip off' }, 'Déjà prise');
    if (c.off || c.stock === 0) return h('span', { class: 'zs-chip off' }, 'Indisponible');
    return h('span', { class: 'zs-price' }, ico('coins'), h('b', null, num(c.price)), c.was && c.was > c.price ? h('s', null, num(c.was)) : null);
  }
  function card(c) {
    const r = R(c.rarity);
    const el2 = h('button', { type: 'button', class: 'zs-card' + (c.owned || (c.daily && c.bought) ? ' is-done' : ''), style: { '--rc': r.color, '--rc-rgb': hexRgb(r.color) }, onclick: () => { G.click(); confirm(c); } },
      img(c), h('i', { class: 'zs-shade' }),
      h('span', { class: 'zs-rar' }, r.label),
      c.promo || (c.daily && c.was > c.price) ? h('span', { class: 'zs-promo' }, '−' + (c.promo || Math.round((1 - c.price / c.was) * 100)) + ' %') : null,
      h('div', { class: 'zs-cb' }, h('b', null, String(c.label || '')), c.sub ? h('small', null, String(c.sub)) : null, state(c)));
    return el2;
  }
  const empty = (icon, t, s) => h('div', { class: 'zs-empty' }, ico(icon), h('b', null, t), s ? h('small', null, s) : null);
  function drawMain() {
    G.clear(grid); G.clear(tools);
    grid.className = 'zs-grid';
    timer.classList.toggle('hidden', st.view !== 'daily');
    if (st.view === 'daily') {
      title.textContent = 'Boutique journalière';
      tools.appendChild(h('span', { class: 'zs-tag' }, '−' + (d.daily_pct || 0) + ' % · un achat par jour'));
      (d.daily || []).forEach((c) => grid.appendChild(card(c)));
      return;
    }
    if (st.view === 'mine') {
      title.textContent = 'Mes achats'; grid.className = 'zs-list';
      if (!(d.owned || []).length) { grid.appendChild(empty('box', 'Aucun achat pour le moment', 'Tes achats apparaissent ici : arme ou véhicule à récupérer, GPS de ta villa…')); return; }
      (d.owned || []).forEach((r) => grid.appendChild(h('div', { class: 'zs-row' }, h('span', { class: 'zs-ri' }, ico(((d.cats || []).find((c) => c.id === r.cat) || {}).icon || 'star')),
        h('div', null, h('b', null, String(r.label)), h('small', null, [r.info, r.from ? 'offert par ' + r.from : null, r.at ? new Date(r.at * 1000).toLocaleDateString('fr-FR') : null].filter(Boolean).join(' · '))),
        r.act ? h('button', { type: 'button', class: 'zs-btn' + (r.wait ? ' ghost' : ' pri'), disabled: r.wait ? true : null, onclick: () => { G.click(); o.onClaim && o.onClaim(r.id); } }, r.wait ? 'Dans ' + r.wait : r.act) : null)));
      return;
    }
    if (st.view === 'hist') {
      title.textContent = 'Historique'; grid.className = 'zs-list';
      if (!(d.hist || []).length) { grid.appendChild(empty('file', 'Aucun mouvement')); return; }
      (d.hist || []).forEach((t) => grid.appendChild(h('div', { class: 'zs-row' }, h('span', { class: 'zs-ri' + (t.d > 0 ? ' plus' : '') }, ico(t.d > 0 ? 'plus' : 'minus')),
        h('div', null, h('b', null, String(t.l || '')), h('small', null, t.at ? new Date(t.at * 1000).toLocaleString('fr-FR') : '')), h('strong', { class: t.d > 0 ? 'plus' : '' }, (t.d > 0 ? '+' : '') + num(t.d) + ' ' + coinName()))));
      return;
    }
    const cat = (d.cats || []).find((c) => c.id === st.view) || {};
    title.textContent = cat.label || 'Boutique';
    if (cat.sub) tools.appendChild(h('span', { class: 'zs-tag' }, String(cat.sub)));
    const list = (d.items || []).filter((i) => i.cat === st.view);
    if (!list.length) { grid.appendChild(empty('star', 'Rien pour le moment', 'Le staff prépare cette catégorie.')); return; }
    list.forEach((c) => grid.appendChild(card(c)));
  }
  function draw() { drawHead(); drawSide(); drawMain(); }

  // --- fiche d'un article, en pleine page : image, contenu, quantité, prix ; options : offrir, plaque ---
  let lastBuy = null;
  function closeModal() { modal.classList.add('hidden'); modal.classList.remove('zs-dp'); G.clear(modal); }
  function confirm(c) {
    G.clear(modal); modal.classList.remove('hidden'); modal.classList.add('zs-dp');
    const blocked = c.owned || c.taken || c.off || c.stock === 0 || (c.daily && c.bought);
    const cat = (d.cats || []).find((x) => x.id === c.cat) || {};
    const incl = Array.isArray(c.incl) ? c.incl : [];
    const r = R(c.rarity);
    const extra = h('div', { class: 'zs-mx' });
    let gift = null, plate = null, veh = null, qty = 1;
    if (c.stats && c.stats.bars) extra.appendChild(h('div', { class: 'zs-stats' }, c.stats.bars.map((b) => h('div', null, h('span', null, String(b[0])), h('i', null, h('u', { style: { width: Math.max(3, Math.min(100, Number(b[1]) || 0)) + '%' } }))))));
    if (c.cat === 'plate') {
      veh = h('select', null, (d.vehs || []).map((v) => h('option', { value: v.plate }, String(v.label) + ' — ' + String(v.plate))));
      plate = h('input', { type: 'text', maxlength: 8, placeholder: 'NOUVELLE PLAQUE', oninput: (e) => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9 ]/g, ''); } });
      extra.appendChild(h('div', { class: 'zs-form' }, h('label', null, h('small', null, 'Véhicule'), veh), h('label', null, h('small', null, 'Texte (8 max.)'), plate)));
    }
    if (c.gift && !blocked) {
      gift = h('input', { type: 'number', min: 1, placeholder: 'ID du joueur (facultatif)' });
      extra.appendChild(h('div', { class: 'zs-form' }, h('label', null, h('small', null, 'Offrir à un joueur connecté'), gift)));
    }
    const total = h('b', { class: 'zs-dtotal' }, num(c.price));
    const was = c.was && c.was > c.price ? h('s', null, num(c.was)) : null;
    const pct = c.promo || (c.was > c.price ? Math.round((1 - c.price / c.was) * 100) : 0);
    const maxq = Math.max(1, Number(c.maxq) || 1);
    const qn = h('b', null, '1');
    const setQty = (n) => {
      qty = Math.max(1, Math.min(maxq, n));
      qn.textContent = String(qty);
      total.textContent = num(c.price * qty);
      if (was) was.textContent = num(c.was * qty);
    };
    const buyBtn = h('button', { type: 'button', class: 'zs-mbuy', disabled: blocked || null }, blocked ? (c.owned ? 'Déjà possédé' : c.daily && c.bought ? 'Déjà acheté' : 'Indisponible') : 'Acheter');
    buyBtn.addEventListener('click', () => {
      if (blocked) return;
      if (Number(d.coins) < Number(c.price) * qty) { say(false, 'Il te manque ' + num(c.price * qty - d.coins) + ' ' + coinName() + '.'); return; }
      G.click();
      const p = {};
      if (qty > 1) p.qty = qty;
      if (c.daily) p.daily = true;
      if (gift && gift.value) p.gift = Number(gift.value);
      if (plate) { p.text = plate.value.trim(); p.vplate = veh && veh.value; if (!p.text) { say(false, 'Écris le texte de la plaque.'); return; } }
      lastBuy = c; buyBtn.disabled = true; buyBtn.classList.add('wait');
      o.onBuy && o.onBuy(c.id, p);
    });
    const badges = [
      pct ? h('span', { class: 'zs-db promo' }, ico('tag'), 'Promotion') : null,
      c.stock != null ? h('span', { class: 'zs-db lim' }, ico('star'), 'Édition limitée') : null,
      c.daily ? h('span', { class: 'zs-db day' }, ico('clock'), 'Offre du jour') : null,
    ].filter(Boolean);
    const info = (icon, t, v) => h('div', { class: 'zs-di' }, h('span', { class: 'zs-dii' }, ico(icon)), h('div', null, h('small', null, t), h('b', null, v)));
    modal.appendChild(h('div', { class: 'zs-dpage' },
      h('header', { class: 'zs-dtop' }, h('b', null, String(cat.label || 'Boutique')), h('span', null, String(cat.sub || ''))),
      h('div', { class: 'zs-dnav' },
        h('button', { type: 'button', class: 'zs-dback', onclick: () => { G.click(); closeModal(); } }, ico('chevron'), 'Retour'),
        h('span', { class: 'zs-dcr' }, String(cat.label || 'Boutique'), h('i'), h('b', null, String(c.label || '')))),
      h('div', { class: 'zs-dgrid' },
        h('div', { class: 'zs-dleft' },
          h('div', { class: 'zs-dimg' }, img(c), h('span', { class: 'zs-dtag' }, r.label)),
          h('div', { class: 'zs-dinfos' }, info('cart', 'Achat maximum', maxq + ' par achat'), info('gift', 'Avantages', incl.length + ' inclus'))),
        h('aside', { class: 'zs-dside' },
          h('small', { class: 'zs-dkind' }, String(cat.label || '')),
          h('h3', null, String(c.label || '')),
          badges.length ? h('div', { class: 'zs-dbs' }, badges) : null,
          h('i', { class: 'zs-dsep' }),
          c.descr && !c.descr_in_list ? h('p', { class: 'zs-ddesc' }, String(c.descr)) : null,
          incl.length ? h('h4', null, 'Ce qui est inclus') : null,
          incl.length ? h('ul', { class: 'zs-dincl' }, incl.map((t) => h('li', null, ico('check'), h('span', null, String(t))))) : null,
          extra,
          h('i', { class: 'zs-dfill' }),
          maxq > 1 && !blocked ? h('div', { class: 'zs-dq' }, h('span', null, 'Quantité'),
            h('button', { type: 'button', onclick: () => { G.click(); setQty(qty - 1); } }, '−'), qn,
            h('button', { type: 'button', onclick: () => { G.click(); setQty(qty + 1); } }, '+'), h('small', null, 'max. ' + maxq)) : null,
          h('div', { class: 'zs-dbuy' }, h('span', { class: 'zs-dcoin' }, ico('coins')), was, total, pct ? h('em', null, '−' + pct + ' %') : null, buyBtn)))));
  }

  // --- coffre : bande qui défile puis s'arrête sur le gain ---

  // compte à rebours des offres du jour
  const tick = setInterval(() => { const left = Math.max(0, Math.round((resetAt - Date.now()) / 1000)); G.clear(timer); timer.append(ico('clock'), clock(left)); }, 1000);
  draw();
  timer.append(ico('clock'), clock(Math.max(0, (resetAt - Date.now()) / 1000)));

  return {
    el,
    set(nd, ok, msg) {
      if (nd) { d = nd; resetAt = Date.now() + (Number(d.reset_in) || 0) * 1000; }
      const c = lastBuy; lastBuy = null;
      draw();
      if (c && ok) { closeModal(); say(true, msg); return true; }
      if (c && !ok) { const btn = modal.querySelector('.zs-mbuy'); if (btn) { btn.disabled = false; btn.classList.remove('wait'); } }
      return false;
    },
    coins(n) { d.coins = n; drawHead(); },
    say,
    escape() { if (!modal.classList.contains('hidden')) { closeModal(); return true; } return false; },
    destroy() { clearInterval(tick); clearTimeout(tt); },
  };
}
G.premiumView = premiumView;

function closeUi() { if (cur && cur.destroy) cur.destroy(); const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'premium'); }
G.on('premium.open', (m) => {
  if (cur && cur.destroy) cur.destroy();
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = premiumView({ d: m.d, onClose: () => G.post('premium.close', {}), onBuy: (id, p) => G.post('premium.buy', { id, p }), onClaim: (id) => G.post('premium.claim', { id }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'premium');
  G.uiStack.push({ id: 'premium', onEscape: () => { if (!(cur && cur.escape())) G.post('premium.close', {}); } });
});
G.on('premium.result', (m) => { if (!cur) return; if (!cur.set(m.d, m.ok, m.msg)) cur.say(m.ok, m.msg); });
G.on('premium.coins', (m) => { if (cur) cur.coins(m.coins); });
G.on('premium.close', closeUi);

// données d'exemple (aperçu du panel et tests)
G.premiumSample = function () {
  return { name: 'Boutique Shadow', coin: 'Coins', who: 'Karl Wilmo', id: 12, coins: 2450, hours: 6, url: 'https://exemple.tebex.io', reset_in: 34384, daily_pct: 25,
    vip: { on: true, until_at: 1763000000 }, boosts: [{ kind: 'pay', label: 'Paie', pct: 25, left: 50000 }],
    rarity: [{ id: 'commun', label: 'Commun', color: '#9aa3b2' }, { id: 'rare', label: 'Rare', color: '#4aa3ff' }, { id: 'epique', label: 'Épique', color: '#b06bff' }, { id: 'legendaire', label: 'Légendaire', color: '#f2b440' }],
    cats: [{ id: 'vehicle', label: 'Véhicules', icon: 'car' }, { id: 'weapon', label: 'Armes', icon: 'crosshair' }, { id: 'vip', label: 'VIP', icon: 'crown' }, { id: 'boost', label: 'Boosts', icon: 'bolt' }, { id: 'money', label: 'Argent en jeu', icon: 'coins' }],
    daily: [{ id: 5, cat: 'money', label: '50 000 $', sub: 'Versés en banque', price: 225, was: 300, daily: true, rarity: 'commun' },
      { id: 13, cat: 'vehicle', label: 'Pegassi Bati 801', price: 675, was: 900, daily: true, rarity: 'rare', img: 'https://docs.fivem.net/vehicles/bati.webp' },
      { id: 20, cat: 'boost', label: 'Boost de paie +25 %', sub: 'Paie +25 % · 24 h', price: 150, was: 200, daily: true, bought: true, rarity: 'rare' }],
    items: [{ id: 2, cat: 'vehicle', label: 'Pegassi Zentorno', descr: 'Supercar, livrée au garage.', price: 3500, img: 'https://docs.fivem.net/vehicles/zentorno.webp', gift: true, rarity: 'legendaire', model: 'zentorno',
        stats: { kmh: 213, bars: [['Vitesse', 92], ['Accélération', 81], ['Freinage', 64], ['Adhérence', 77]] } },
      { id: 13, cat: 'vehicle', label: 'Pegassi Bati 801', descr: 'Moto sportive.', price: 900, img: 'https://docs.fivem.net/vehicles/bati.webp', gift: true, rarity: 'rare' },
      { id: 14, cat: 'vehicle', label: 'Obey 10F', descr: 'Sportive élégante.', price: 2200, img: 'https://docs.fivem.net/vehicles/tenf.webp', gift: true, rarity: 'epique', owned: true },
      { id: 1, cat: 'weapon', label: 'Pistolet .50', descr: 'Pistolet lourd, toujours à toi.', price: 1200, img: 'img/ox/WEAPON_PISTOL50.png', gift: true, rarity: 'rare' },
      { id: 3, cat: 'vip', label: 'VIP 30 jours', sub: '30 jours', descr: 'Tous les avantages VIP pendant un mois.', price: 600, was: 800, promo: 25, gift: true, rarity: 'epique' },
      { id: 20, cat: 'boost', label: 'Boost de paie +25 %', sub: 'Paie +25 % · 24 h', descr: 'Ta paie augmente de 25 % pendant 24 heures.', price: 200, gift: true, rarity: 'rare' },
      { id: 5, cat: 'money', label: '50 000 $', sub: 'Versés en banque', descr: 'Versés sur ton compte en banque.', price: 300, gift: true, rarity: 'commun' }],
    owned: [{ id: 9, cat: 'weapon', label: 'Revolver lourd', info: 'Arme permanente', act: 'Récupérer', wait: '2 h 10', at: 1760000000 }, { id: 10, cat: 'vip', label: 'VIP 30 jours', info: 'VIP 30 jours', at: 1760100000, from: 'Alex Martin' }],
    hist: [{ d: 5000, l: 'Achat boutique en ligne', at: 1760000000 }, { d: -1500, l: 'Revolver lourd', at: 1760003600 }], vehs: [{ plate: 'PB12345', label: 'Sultan' }] };
};
G.preview.premium = function (box) {
  G.clear(box);
  const s = h('div', { class: 'gstage ps-stage' }); box.appendChild(s);
  s.appendChild(premiumView({ d: G.premiumSample(), onClose: () => {}, onBuy: () => {}, onClaim: () => {} }).el);
};
})();
