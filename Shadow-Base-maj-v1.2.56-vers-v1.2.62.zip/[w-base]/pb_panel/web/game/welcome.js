/* Écran d'accueil et règlement. Le bouton « accepter » s'active après la lecture minimale (le serveur la vérifie aussi). Texte inséré uniquement via textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

function welcomeView(d, opt) {
  opt = opt || {};
  const acc = G.accentHex();
  let left = Math.max(0, Number(d.min_read) || 0), timer = null;
  const accept = h('button', { class: 'gw-btn pri', disabled: left > 0 }, '');
  const label = () => { accept.textContent = left > 0 ? (d.accept || "J'accepte") + ' (' + left + ')' : (d.accept || "J'accepte"); accept.disabled = left > 0; };
  label();
  if (left > 0 && !opt.static) timer = setInterval(() => { left--; label(); if (left <= 0) clearInterval(timer); }, 1000);
  accept.addEventListener('click', () => { if (left <= 0 && opt.onAccept) opt.onAccept(); });
  const decline = h('button', { class: 'gw-btn', onclick: () => opt.onDecline && opt.onDecline() }, d.decline || 'Quitter');
  const list = (arr) => (arr || []).filter(Boolean);
  const bgU = G.assetUrl(d.bg || '');
  const logoU = G.assetUrl(d.logo || '') || G.assetUrl((G.cfg && G.cfg.brand && G.cfg.brand.logo) || '') || 'img/brand/shadow-logo.png';
  let el;
  if (d.style === 'card') {
  el = h('div', { class: 'gw', style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } },
    (function () { const u = G.assetUrl(d.banner || ''); return u ? h('div', { class: 'gw-ban', style: { backgroundImage: 'url("' + u + '")' } }) : null; })(),
    h('div', { class: 'gw-head' }, logoU ? h('img', { class: 'gw-logo', src: logoU, alt: '' }) : null, d.brand ? h('small', null, d.brand) : null, h('h1', null, d.title || 'Bienvenue'), d.sub ? h('p', null, d.sub) : null),
    h('div', { class: 'gw-body' },
      list(d.intro).map((t) => h('p', { class: 'gw-intro' }, t)),
      list(d.news).length ? h('div', { class: 'gw-news' }, list(d.news).map((t) => h('div', { class: 'gw-n' }, ico('sparkle'), h('span', null, t)))) : null,
      list(d.rules).length ? h('div', { class: 'gw-rules' }, h('h3', null, 'Règlement'), list(d.rules).map((t) => h('div', { class: 'gw-r' }, ico('check'), h('span', null, t)))) : null,
      list(d.links).length ? h('div', { class: 'gw-links' }, list(d.links).map((t) => h('span', null, ico('chat'), t))) : null),
    h('div', { class: 'gw-foot' }, decline, accept));
  } else {
    // plein écran : logo, petit losange, titre en deux tons, paragraphe (photo de référence)
    const para = d.text || d.sub || (list(d.intro)[0] || '');
    const rules = d.show_rules === false ? [] : list(d.rules);
    el = h('div', { class: 'gw gw-hero', style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } },
      bgU ? h('div', { class: 'gw-bg', style: { backgroundImage: 'url("' + bgU + '")' } }) : null,
      h('div', { class: 'gw-shade' }),
      h('div', { class: 'gw-mid' },
        logoU ? h('img', { class: 'gw-logo', src: logoU, alt: '' }) : (d.brand ? h('div', { class: 'gw-brand' }, d.brand) : null),
        h('i', { class: 'gw-dia' }),
        h('h1', null, (d.title || 'Bienvenue') + ' ', d.hl ? h('em', null, d.hl) : null),
        para ? h('p', { class: 'gw-para' }, para) : null,
        rules.length ? h('div', { class: 'gw-rl' }, h('h3', null, 'Règlement'), rules.map((t, i) => h('div', { class: 'gw-r' }, h('b', null, String(i + 1)), h('span', null, t)))) : null,
        list(d.links).length ? h('div', { class: 'gw-links' }, list(d.links).map((t) => h('span', null, ico('chat'), t))) : null,
        h('div', { class: 'gw-foot' }, decline, accept)));
  }
  el.__stop = () => timer && clearInterval(timer);
  return el;
}
G.welcomeView = welcomeView;

function host() { return document.getElementById('g-welcome') || (function () { const e = h('div', { id: 'g-welcome', class: 'hidden' }); G.root.appendChild(e); return e; })(); }
let lastW = null;
function showW(d) {
  const r = host(); const old = r.firstChild; if (old && old.__stop) old.__stop(); G.clear(r); r.classList.remove('hidden');
  r.appendChild(welcomeView(d, { onAccept: () => G.post('welcome.accept', {}), onDecline: () => G.post('welcome.decline', {}) }));
}
G.on('welcome.open', (d) => { lastW = d; showW(d); });
G.on('asset', () => { if (lastW && !host().classList.contains('hidden')) showW(lastW); });
G.on('welcome.close', () => { lastW = null; const r = host(); const w = r.firstChild; if (w && w.__stop) w.__stop(); G.clear(r); r.classList.add('hidden'); });

G.preview.welcome = function (box, cfg) {
  G.clear(box);
  const d = { title: 'Bienvenue sur le', hl: 'serveur', style: 'hero', show_rules: true, sub: "Avant d'entrer, prends une minute pour lire le règlement.", brand: 'Ma ville RP', color: '#dfe2e7', min_read: 0, accept: "J'accepte et j'entre", decline: 'Quitter',
    intro: ['Ce serveur est un serveur de jeu de rôle : tu incarnes un personnage et tu respectes celui des autres.'], news: ['Nouvelle économie équilibrée.'],
    rules: ['Reste dans ton rôle.', 'Pas de meurtre sans raison valable.', 'Respecte les autres joueurs et le staff.'], links: ['Discord : discord.gg/exemple'] };
  box.appendChild(h('div', { class: 'gstage tall' }, welcomeView(d, { static: true })));
};
})();
