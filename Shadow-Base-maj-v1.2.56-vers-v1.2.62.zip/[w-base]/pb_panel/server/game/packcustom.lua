-- Pack de départ sur mesure (organisations et entreprises) : armes, objets et véhicules choisis dans les listes ou écrits à la main.
-- Tout est revérifié ici : un nom inconnu n'est pas donné, il est signalé à celui qui compose le pack.
local G = PB.G
local P = PB.Perm
local Pack = {}
G.PackCustom = Pack

local MAX_ITEMS, MAX_CARS, MAX_QTY, MAX_CASH = 40, 10, 10000, 10000000

local function trim(s) return (tostring(s or ''):gsub('[%c<>|]', ''):gsub('^%s+', ''):gsub('%s+$', '')) end

-- L'arme et ses munitions doivent exister comme objets avant d'entrer dans un coffre (comme « donner une arme » au menu staff)
local function ensureWeapon(entry)
    if not G.SyncArmory then return end
    local ammo = entry[4] or ''
    local def = { { type = 'weapon', name = entry[1], label = entry[2], ammo_item = ammo } }
    if ammo ~= '' then def[#def + 1] = { type = 'ammo', name = ammo, label = ammo } end
    pcall(G.SyncArmory, def)
end

-- Accepte le nom technique ou le nom affiché, sans tenir compte des majuscules. Renvoie le nom technique, ou nil.
local function resolve(txt)
    local low = txt:lower()
    for _, e in ipairs(G.Staff.WeaponList()) do
        if e[1] == low or (e[4] or '') == low or tostring(e[2]):lower() == low then
            if not (G.Inv and G.Inv.Def(low)) then ensureWeapon(e) end
            if (e[4] or '') == low then return low end
            return e[1]
        end
    end
    if not G.Inv then return nil end
    if G.Inv.Def(txt) then return txt end
    if G.Inv.Def(low) then return low end
    for name, d in pairs(G.Inv.Defs and G.Inv.Defs() or {}) do
        if name:lower() == low or tostring(d.label or ''):lower() == low then return name end
    end
end

-- raw = { cash, items = { { item, qty } }, vehicles = { { model, label } } }. Renvoie un pack pour Orgs.Starter / Biz.Starter, ou nil + message.
function Pack.Parse(raw)
    if type(raw) ~= 'table' then return nil, 'Pack invalide.' end
    local cash = math.floor(tonumber(raw.cash) or 0)
    if cash < 0 or cash > MAX_CASH then return nil, ('Argent du pack : de 0 à %s.'):format(PB.Money(MAX_CASH)) end
    local pack = { custom = true, name = 'Pack sur mesure', cash = cash, items = {}, vehicles = {}, skipped = {} }
    local rawItems, rawCars = type(raw.items) == 'table' and raw.items or {}, type(raw.vehicles) == 'table' and raw.vehicles or {}
    if #rawItems > MAX_ITEMS then return nil, ('%d objets différents au maximum dans un pack.'):format(MAX_ITEMS) end
    if #rawCars > MAX_CARS then return nil, ('%d véhicules au maximum dans un pack.'):format(MAX_CARS) end
    local qtys, order = {}, {}
    for _, line in ipairs(rawItems) do
        local txt = type(line) == 'table' and trim(line.item):sub(1, 48) or ''
        if txt ~= '' then
            local name = resolve(txt)
            -- une ligne de panel sans quantité vaut 1 ; une quantité négative est refusée
            local n = math.floor(tonumber(line.qty) or 1)
            if n == 0 then n = 1 end
            if not name then pack.skipped[#pack.skipped + 1] = txt .. ' (inconnu)'
            elseif n < 1 or n > MAX_QTY then pack.skipped[#pack.skipped + 1] = txt .. ' (quantité : 1 à ' .. MAX_QTY .. ')'
            else
                if not qtys[name] then qtys[name] = 0 order[#order + 1] = name end
                qtys[name] = math.min(MAX_QTY, qtys[name] + n)
            end
        end
    end
    for _, name in ipairs(order) do pack.items[#pack.items + 1] = name .. ':' .. qtys[name] end
    for _, line in ipairs(rawCars) do
        local model = type(line) == 'table' and trim(line.model):lower() or ''
        if model ~= '' then
            if model:match('^[%w_]+$') and #model >= 3 and #model <= 32 then
                pack.vehicles[#pack.vehicles + 1] = model .. '|' .. trim(line.label):sub(1, 48)
            else pack.skipped[#pack.skipped + 1] = model .. ' (modèle invalide)' end
        end
    end
    if cash == 0 and #pack.items == 0 and #pack.vehicles == 0 then
        if #pack.skipped > 0 then return nil, 'Rien à donner : ' .. table.concat(pack.skipped, ', ') .. '.' end
        return nil, 'Le pack est vide.'
    end
    return pack
end

-- Au Builder : composer un pack revient à donner des armes et de l'argent, il faut donc aussi ces droits-là
function Pack.ForStaff(src, raw)
    if not P.Has(src, 'staff.items') then return nil, "Il te faut le droit « donner des objets » pour composer un pack." end
    if type(raw) == 'table' and (tonumber(raw.cash) or 0) ~= 0 and not P.Has(src, 'staff.money') then return nil, "Il te faut le droit « donner de l'argent » pour mettre de l'argent dans un pack." end
    return Pack.Parse(raw)
end

function Pack.Text(sum)
    local cars = #sum.cars
    local t = ('%s : %s, %s, %d véhicule(s).'):format(sum.pack or 'Pack', PB.Money(sum.cash or 0), sum.waiting and 'objets livrés dès que le coffre sera posé' or ((sum.items or 0) .. ' objet(s) au coffre'), cars)
    if #sum.skipped > 0 then t = t .. ' Non donné : ' .. table.concat(sum.skipped, ', ') .. '.' end
    return t
end

-- Listes pour le panel (choisir ou écrire) : { valeur, nom affiché }
function Pack.ItemChoices()
    local out, seen = {}, {}
    local function add(v, l) if v ~= '' and not seen[v] then seen[v] = true out[#out + 1] = { v, l } end end
    for _, e in ipairs(G.Staff.WeaponList()) do
        add(e[1], e[2] .. ' (arme)')
        if (e[4] or '') ~= '' then add(e[4], 'Munitions : ' .. e[2]) end
    end
    for _, it in ipairs(G.Staff.ItemList()) do add(it[1], it[2]) end
    return out
end
function Pack.VehRows()
    local out = {}
    for _, v in ipairs(G.VehCat and G.VehCat.Effective() or {}) do out[#out + 1] = { v.model, v.label, v.class } end
    return out
end
function Pack.VehChoices()
    local out = {}
    for _, v in ipairs(Pack.VehRows()) do out[#out + 1] = { v[1], v[2] .. ' (' .. tostring(v[3]) .. ')' } end
    return out
end

-- Le formulaire du panel. o = { id, action, target = libellé de la liste, opts = { { id, nom } } }
function Pack.Form(o)
    return { type = 'form', id = o.id, title = 'Composer un pack sur mesure', cols = 2,
        desc = "Choisis dans la liste en tapant, ou écris un nom exact. Ce pack s'ajoute à ce que possède déjà " .. o.owner .. ". Les noms inconnus ne sont pas donnés : ils sont signalés à la fin.",
        fields = {
            { k = 'target', type = 'select', label = o.target, opts = o.opts, required = true },
            { k = 'cash', type = 'number', label = 'Argent en caisse ($)', min = 0, max = MAX_CASH },
            { k = 'items', type = 'rows', label = 'Armes et objets', wide = true, cols = {
                { k = 'item', label = 'Arme ou objet (liste ou nom exact)', list = Pack.ItemChoices() },
                { k = 'qty', label = 'Quantité', type = 'number', min = 1, max = MAX_QTY, first = 1 } } },
            { k = 'vehicles', type = 'rows', label = 'Véhicules', wide = true, cols = {
                { k = 'model', label = 'Modèle (liste ou nom exact)', list = Pack.VehChoices() },
                { k = 'label', label = 'Nom affiché (facultatif)' } } },
        },
        values = { target = o.opts[1] and o.opts[1][1] or '', cash = 0, items = {}, vehicles = {} },
        submit = { action = o.action, label = 'Donner ce pack' } }
end
