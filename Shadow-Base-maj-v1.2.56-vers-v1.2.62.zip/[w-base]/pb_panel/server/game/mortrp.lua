-- Mort RP (menu staff › un joueur › Mort RP) : le staff l'active sur un joueur ; à la prochaine balle reçue, son personnage meurt pour de bon.
-- Écran « MORT RP », puis : les objets qu'il a donnés à d'autres joueurs dans les 24 dernières heures leur sont retirés (pas de
-- récupération sur le prochain personnage), il est expulsé au bout de 10 s, et toutes les données de son personnage sont effacées
-- (identité, argent, inventaire, véhicules, logements, téléphone, emploi, organisation…). Le compte, lui, reste : bans, sanctions, VIP, coins.
local G, P, DB = PB.G, PB.Perm, PB.DB
local M = {}
G.MortRP = M
P.Register('staff.mortrp', 'Mort RP : tuer définitivement le personnage d\'un joueur', 'staff', true)
PB.Migrate('522_inv_gives', 'Inventaire : journal des dons entre joueurs (Mort RP)', {
    [[CREATE TABLE IF NOT EXISTS pb_inv_gives (id INT NOT NULL AUTO_INCREMENT, from_lic VARCHAR(64) NOT NULL, to_owner VARCHAR(80) NOT NULL, item VARCHAR(64) NOT NULL,
        qty INT NOT NULL DEFAULT 1, at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_from (from_lic, at))]],
})

-- journal des dons (gardé 2 jours)
AddEventHandler('pb_panel:itemGiven', function(src, target, item, qty)
    local a, b = G.Get(tonumber(src) or -1), G.Get(tonumber(target) or -1)
    if not a or not b then return end
    DB.exec('INSERT INTO pb_inv_gives (from_lic, to_owner, item, qty, at) VALUES (?, ?, ?, ?, ?)', { a.license, 'p:' .. b.license, tostring(item), math.floor(tonumber(qty) or 1), os.time() })
end)
CreateThread(function() while true do Wait(3600000) pcall(DB.exec, 'DELETE FROM pb_inv_gives WHERE at < ?', { os.time() - 2 * 86400 }) end end)

-- Objets donnés dans les dernières 24 h : retirés à ceux qui les ont reçus (dans la limite de ce qu'ils ont encore)
function M.PurgeGives(license)
    local n = 0
    for _, r in ipairs(DB.q('SELECT to_owner, item, qty FROM pb_inv_gives WHERE from_lic = ? AND at >= ?', { license, os.time() - 86400 }) or {}) do
        local have = G.Inv and G.Inv.Count(r.to_owner, r.item) or 0
        local take = math.min(have, tonumber(r.qty) or 0)
        if take > 0 then G.Inv.Remove(r.to_owner, r.item, take) n = n + take end
    end
    DB.exec('DELETE FROM pb_inv_gives WHERE from_lic = ?', { license })
    return n
end

-- Toutes les données du personnage (le compte reste : bans, sanctions, notes du staff, VIP, coins, identifiant permanent)
local BY_LICENSE = { 'pb_bank_accounts', 'pb_inv_worn', 'pb_launder_jobs', 'pb_orga_crypto', 'pb_orga_grade', 'pb_orga_xp', 'pb_outfit_pref', 'pb_pause_places', 'pb_pause_path',
    'pb_permits', 'pb_phone_contacts', 'pb_phone_notes', 'pb_phone_numbers', 'pb_phone_prefs', 'pb_phone_blocks', 'pb_phone_given', 'pb_phone_group_members', 'pb_phone_ads',
    'pb_saved_outfits', 'pb_tag_gang', 'pb_vest_hp', 'pb_warrants', 'pb_jail', 'pb_biz_members', 'pb_property_access',
    -- (v1.2.45) restaient après une Mort RP : 2e métier, clés prêtées, factures, casier, comptes, appels, tickets de loterie, gang, photo…
    'pb_biz_job2', 'pb_vehicle_keys', 'pb_biz_invoices', 'pb_biz_records', 'pb_justice_log', 'pb_bank_tx', 'pb_calls', 'pb_casino_lotto', 'pb_civil_log', 'pb_gang_boss', 'pb_org_members', 'pb_inv_snap', 'pb_photos' }
function M.Wipe(license)
    local function run(q, p) pcall(DB.exec, q, p) end
    for _, r in ipairs(DB.q('SELECT plate FROM pb_vehicles WHERE license = ?', { license }) or {}) do
        run('DELETE FROM pb_vehicle_state WHERE plate = ?', { r.plate })
        run('DELETE FROM pb_vehicle_keys WHERE plate = ?', { r.plate })
        run('DELETE FROM pb_inv WHERE owner = ?', { 'v:' .. r.plate })
    end
    run('DELETE FROM pb_vehicles WHERE license = ?', { license })
    run('DELETE FROM pb_inv WHERE owner = ?', { 'p:' .. license })
    if G.Inv and G.Inv.ForgetNames then pcall(G.Inv.ForgetNames, 'p:' .. license) end
    run("UPDATE pb_properties SET owner = '', since = 0, paid_until = 0, arrears = 0, locked = 1 WHERE owner = ?", { license })
    for _, t in ipairs(BY_LICENSE) do run('DELETE FROM ' .. t .. ' WHERE license = ?', { license }) end
    run("UPDATE pb_players SET created = 0, firstname = '', lastname = '', dob = '', appearance = NULL, cash = 0, bank = 0, dead = 0, hunger = 100, thirst = 100, stress = 0 WHERE license = ?", { license })
    if G.Points and G.Points.PushAll then pcall(G.Points.PushAll) end
    if G.PushConfig then pcall(G.PushConfig) end
end

local armed = {}   -- src -> nom du staff qui l'a activée
AddEventHandler('playerDropped', function() armed[source] = nil end)
function M.Arm(src, t, by)
    armed[t] = by or 'Staff'
    TriggerClientEvent('pb:g:mortrp:arm', t, true)
    return true
end
function M.Disarm(t) armed[t] = nil TriggerClientEvent('pb:g:mortrp:arm', t, false) end
function M.Armed(t) return armed[t] ~= nil end

function M.Kill(src)
    local p = G.Get(src)
    if not p then return false end
    local by = armed[src] or 'Staff'
    armed[src] = nil
    local license, name = p.license, ((p.row.firstname or '') .. ' ' .. (p.row.lastname or ''))
    TriggerClientEvent('pb:g:mortrp:screen', src, PB.Json({ name = name, secs = 10 }))
    local n = M.PurgeGives(license)
    PB.Audit.Log('staff', 'mortrp', by, name .. ' ' .. (G.Tag and G.Tag(src) or ''), nil, nil, { license = license, given_back = n })
    SetTimeout(10000, function()
        if G.Get(src) then PB.Drop(src, 'kick', 'staff', 'Mort RP : ton personnage est mort. Reconnecte-toi pour en créer un nouveau.', 'Mort RP', by) end
        -- l'effacement attend la sauvegarde de déconnexion (sinon l'argent en mémoire serait réécrit)
        SetTimeout(5000, function() M.Wipe(license) end)
    end)
    return true
end
-- le client signale la balle reçue ; le serveur vérifie que la Mort RP est bien active sur lui
RegisterNetEvent('pb:g:mortrp:hit', function()
    local src = source
    if armed[src] then M.Kill(src) end
end)

local S = G.Staff
if S and S.Def then
    S.Def('mortrp', 'staff.mortrp', { target = true, rank = true, run = function(src, t)
        if armed[t] then M.Disarm(t) return true, 'Mort RP désactivée.' end
        M.Arm(src, t, PB.Actor(src).name)
        return true, 'Mort RP active : à la prochaine balle reçue, son personnage meurt définitivement.'
    end, log = true })
end
