-- Justice : casier judiciaire, prison, travaux d'intérêt général (TIG), appels d'urgence et répartiteur (police / secours).
-- Le serveur fait foi : droits du métier, service, distance, bornes de peine, délais. Le client affiche et exécute (téléportation, marqueurs, animations).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Biz = G.Biz
local J = {}
G.Justice = J

P.Register('justice.edit', "Modifier les réglages de la justice (prison, TIG, appels d'urgence)", 'justice', true)
P.Register('justice.manage', "Libérer un détenu ou clore un appel depuis le panel", 'justice', true)
P.Register('staff.jail', 'Envoyer un joueur en prison ou le libérer (menu staff)', 'staff', true)

PB.Migrate('070_justice', 'Justice : détenus, journal, appels', {
    [[CREATE TABLE IF NOT EXISTS pb_jail (
        license VARCHAR(64) NOT NULL, kind VARCHAR(4) NOT NULL DEFAULT 'jail', remaining INT NOT NULL DEFAULT 0, reason VARCHAR(160) NOT NULL DEFAULT '',
        by_name VARCHAR(64) NOT NULL DEFAULT '', name VARCHAR(64) NOT NULL DEFAULT '', since INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_justice_log (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', kind VARCHAR(10) NOT NULL, text VARCHAR(200) NOT NULL DEFAULT '',
        amount INT NOT NULL DEFAULT 0, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_calls (
        id INT NOT NULL AUTO_INCREMENT, service VARCHAR(16) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', text VARCHAR(200) NOT NULL,
        x DOUBLE NULL, y DOUBLE NULL, z DOUBLE NULL, status VARCHAR(8) NOT NULL DEFAULT 'open', units TEXT NULL, created INT NOT NULL, closed_at INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY k_st (status))]],
})

PB.Cfg.Define('justice', {
    enabled = true,
    jail_x = 1691.0, jail_y = 2565.0, jail_z = 45.6, jail_radius = 70, release_x = 1846.0, release_y = 2585.9, release_z = 45.7,
    -- (v1.2.45) prison du staff (peines du menu staff / /jail) : posée au Builder ; 0 = la prison de la police
    sjail_x = 0.0, sjail_y = 0.0, sjail_z = 0.0, sjail_radius = 25, srelease_x = 0.0, srelease_y = 0.0, srelease_z = 0.0,
    max_jail = 180, jail_needs_cuffs = true,
    tig_on = true, tig_max = 30, tig_secs = 8, tig_radius = 3.0,
    tig_points = { '195.0|-934.0|30.7|Legion Square', '-267.0|-958.0|31.2|Alta Street', '-47.0|-585.0|37.9|Integrity Way' },
    calls_on = true, call_cd = 45, call_max = 3, call_ttl = 30, self_claim = true,
    services = { 'police|Police|police', 'ems|Secours|ems' },
    casier_lines = 12,
})
local function cfg(k, d) return PB.Cfg.Get('justice', k, d) end
local function now() return os.time() end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n or 120)) end
local function display(src) return Biz.Display(src) end
local function money(n) return tostring(math.floor((tonumber(n) or 0) + 0.5)) end

-- Peines ---------------------------------------------------------------------------------------------------------------------------------
local jailed = {}        -- src -> { kind, remaining, reason, license, saved }
function J.State(src) return jailed[tonumber(src) or -1] end
function G.IsJailed(src) return jailed[tonumber(src) or -1] ~= nil end
exports('IsJailed', function(src) return G.IsJailed(src) end)

-- 'jail' : prison de la police ; 'ajal' : prison du staff (ses propres lieu, sortie et zone si elles sont posées au Builder)
local function isJail(kind) return kind == 'jail' or kind == 'ajal' end
J.IsJail = isJail
local function staffSet() return (tonumber(cfg('sjail_x', 0)) or 0) ~= 0 or (tonumber(cfg('sjail_y', 0)) or 0) ~= 0 end
local function jailPos(kind)
    if kind == 'ajal' and staffSet() then return { x = tonumber(cfg('sjail_x', 0)) or 0, y = tonumber(cfg('sjail_y', 0)) or 0, z = tonumber(cfg('sjail_z', 0)) or 0 } end
    return { x = tonumber(cfg('jail_x', 0)) or 0, y = tonumber(cfg('jail_y', 0)) or 0, z = tonumber(cfg('jail_z', 0)) or 0 }
end
local function jailRadius(kind) if kind == 'ajal' and staffSet() then return tonumber(cfg('sjail_radius', 25)) or 25 end return tonumber(cfg('jail_radius', 70)) or 70 end
local function releasePos(kind)
    if kind == 'ajal' and ((tonumber(cfg('srelease_x', 0)) or 0) ~= 0 or (tonumber(cfg('srelease_y', 0)) or 0) ~= 0) then
        return { x = tonumber(cfg('srelease_x', 0)) or 0, y = tonumber(cfg('srelease_y', 0)) or 0, z = tonumber(cfg('srelease_z', 0)) or 0 }
    end
    return { x = tonumber(cfg('release_x', 0)) or 0, y = tonumber(cfg('release_y', 0)) or 0, z = tonumber(cfg('release_z', 0)) or 0 }
end
local function fx(src, kind, data) TriggerClientEvent('pb:g:justice:fx', src, kind, PB.Json(data or {})) end
local function push(src)
    local j = jailed[src]
    local jp = j and isJail(j.kind) and jailPos(j.kind) or nil
    TriggerClientEvent('pb:g:justice:state', src, PB.Json(j and { kind = isJail(j.kind) and 'jail' or j.kind, remaining = j.remaining, reason = j.reason,
        jx = jp and jp.x, jy = jp and jp.y, jz = jp and jp.z, jr = jp and jailRadius(j.kind) } or { kind = 'none' }))
end
local function logEntry(license, name, kind, text, amount, by)
    DB.exec('INSERT INTO pb_justice_log (license, name, kind, text, amount, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { license, clean(name, 64), kind, clean(text, 200), math.floor(tonumber(amount) or 0), clean(by, 64), now() })
end
local function tigPoints()
    local out = {}
    for _, line in ipairs(cfg('tig_points', {}) or {}) do
        local x, y, z, l = tostring(line):match('^(-?[%d%.]+)|(-?[%d%.]+)|(-?[%d%.]+)|(.*)$')
        if x then out[#out + 1] = { x = tonumber(x), y = tonumber(y), z = tonumber(z), label = clean(l, 40) } end
    end
    return out
end
J.TigPoints = tigPoints

-- kind : 'jail' (amount = minutes) ou 'tig' (amount = nombre de tâches)
function J.Sentence(byName, tid, kind, amount, reason)
    if not cfg('enabled', true) then return false, 'La justice est désactivée.' end
    local p = G.Get(tid)
    if not p or not PB.ToBool(p.row.created) then return false, "Ce joueur n'est pas disponible." end
    if jailed[tid] then return false, 'Cette personne purge déjà une peine.' end
    reason = clean(reason, 160)
    if reason == '' then return false, 'Indique le motif.' end
    amount = math.floor(tonumber(amount) or 0)
    local remaining, label
    if kind == 'tig' then
        if cfg('tig_on', true) == false or #tigPoints() == 0 then return false, "Les travaux d'intérêt général ne sont pas disponibles." end
        local max = cfg('tig_max', 30)
        if amount < 1 or amount > max then return false, ('TIG : 1 à %d tâches.'):format(max) end
        remaining, label = amount, ('TIG : %d tâche(s)'):format(amount)
    else
        kind = kind == 'ajal' and 'ajal' or 'jail'   -- ajal : prison du staff
        local max = cfg('max_jail', 180)
        if amount < 1 or amount > max then return false, ('Prison : 1 à %d minutes.'):format(max) end
        remaining, label = amount * 60, ('Prison : %d min'):format(amount)
    end
    local name = display(tid)
    DB.exec('INSERT INTO pb_jail (license, kind, remaining, reason, by_name, name, since) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE kind = VALUES(kind), remaining = VALUES(remaining), reason = VALUES(reason), by_name = VALUES(by_name), name = VALUES(name), since = VALUES(since)',
        { p.license, kind, remaining, reason, clean(byName, 64), clean(name, 64), now() })
    jailed[tid] = { kind = kind, remaining = remaining, reason = reason, license = p.license, name = name }
    if G.Police and G.IsCuffed(tid) then G.Police.SetCuffed(tid, false) end
    if isJail(kind) then fx(tid, 'tp', jailPos(kind)) end
    push(tid)
    logEntry(p.license, name, kind, label .. ' — ' .. reason, amount, byName)
    G.Notify(tid, { type = 'warn', title = 'Justice', text = label .. ' : ' .. reason, duration = 12000 })
    TriggerEvent('pb_panel:jailed', tid, kind, amount, reason)
    return true, ('%s : %s.'):format(name, label)
end

function J.Release(tid, byName, why)
    local j = jailed[tid]
    if not j then return false, "Cette personne n'est pas détenue." end
    jailed[tid] = nil
    DB.exec('DELETE FROM pb_jail WHERE license = ?', { j.license })
    push(tid)
    if isJail(j.kind) then fx(tid, 'tp', releasePos(j.kind)) end
    logEntry(j.license, j.name or '', 'release', why or 'Libéré(e)', 0, byName or 'Système')
    G.Notify(tid, { type = 'success', title = 'Justice', text = why or 'Tu es libre.', duration = 9000 })
    TriggerEvent('pb_panel:released', tid, j.kind)
    return true, (j.name or 'Le joueur') .. ' est libéré(e).'
end

-- détenu hors ligne (panel) : on supprime simplement sa peine
function J.SentenceLicense(byName, license, name, minutes, reason)
    if DB.one('SELECT license FROM pb_jail WHERE license = ?', { license }) then return false, 'Cette personne purge déjà une peine.' end
    reason = clean(reason, 160)
    if reason == '' then return false, 'Indique le motif.' end
    minutes = math.floor(tonumber(minutes) or 0)
    local max = cfg('max_jail', 180)
    if minutes < 1 or minutes > max then return false, ('Prison : 1 à %d minutes.'):format(max) end
    DB.exec('INSERT INTO pb_jail (license, kind, remaining, reason, by_name, name, since) VALUES (?, ?, ?, ?, ?, ?, ?)', { license, 'ajal', minutes * 60, reason, clean(byName, 64), clean(name, 64), now() })
    logEntry(license, name, 'ajal', reason, minutes * 60, byName or 'Staff')
    return true, ('%s ira en prison %d min à son retour.'):format(name, minutes)
end
function J.ReleaseLicense(license, byName)
    local r = DB.one('SELECT name FROM pb_jail WHERE license = ?', { license })
    if not r then return false, "Cette personne n'est pas détenue." end
    for src, j in pairs(jailed) do if j.license == license then return J.Release(src, byName) end end
    DB.exec('DELETE FROM pb_jail WHERE license = ?', { license })
    logEntry(license, r.name, 'release', 'Libéré(e) depuis le panel', 0, byName or 'Panel')
    return true, (r.name ~= '' and r.name or 'Le joueur') .. ' est libéré(e).'
end

local function persist(src)
    local j = jailed[src]
    if j then DB.exec('UPDATE pb_jail SET remaining = ? WHERE license = ?', { j.remaining, j.license }) end
end
local tickCount = 0
function J.Tick(dt)
    dt = dt or 5
    tickCount = tickCount + 1
    for src, j in pairs(jailed) do
        local p = G.Get(src)
        if p and PB.ToBool(p.row.created) then
            if isJail(j.kind) then
                j.remaining = j.remaining - dt
                if j.remaining <= 0 then J.Release(src, 'Système', 'Ta peine est terminée.')
                else
                    local jp = jailPos(j.kind)
                    local d = G.DistTo(src, jp.x, jp.y, jp.z)
                    if d > jailRadius(j.kind) + 15 then fx(src, 'tp', jp) G.Notify(src, { type = 'warn', title = 'Justice', text = 'Tu ne peux pas quitter la prison.' }) end
                end
            end
            if tickCount % 6 == 0 and jailed[src] then persist(src) push(src) end
        end
    end
    if tickCount % 12 == 0 then J.ExpireCalls() end
end
CreateThread(function() while true do Wait(5000) pcall(J.Tick, 5) end end)

AddEventHandler('playerDropped', function()
    local src = source
    persist(src)
    jailed[src] = nil
end)
table.insert(G.beginHooks, function(src, p)
    local r = DB.one('SELECT * FROM pb_jail WHERE license = ?', { p.license })
    if r then
        jailed[src] = { kind = r.kind, remaining = r.remaining, reason = r.reason, license = p.license, name = r.name }
        push(src)
        if isJail(r.kind) then fx(src, 'tp', jailPos(r.kind)) end
    else push(src) end
end)

-- TIG : le client signale une tâche terminée ; le serveur revérifie la distance et le délai
local lastTig = {}
RegisterNetEvent('pb:g:justice:tig', function(idx)
    local src = source
    local j = jailed[src]
    if not j or j.kind ~= 'tig' then return end
    local pt = tigPoints()[math.floor(tonumber(idx) or 0)]
    if not pt then return end
    if G.DistTo(src, pt.x, pt.y, pt.z) > cfg('tig_radius', 3.0) + 6 then G.Notify(src, { type = 'warn', title = 'TIG', text = "Tu es trop loin du chantier." }) return end
    local t = GetGameTimer and GetGameTimer() or now() * 1000
    if lastTig[src] and t - lastTig[src] < math.max(1, cfg('tig_secs', 8) - 1) * 1000 then return end
    lastTig[src] = t
    j.remaining = j.remaining - 1
    if j.remaining <= 0 then J.Release(src, 'Système', "Tes travaux d'intérêt général sont terminés.")
    else
        persist(src) push(src)
        G.Notify(src, { type = 'success', title = 'TIG', text = ('Tâche terminée : encore %d.'):format(j.remaining) })
    end
end)
AddEventHandler('playerDropped', function() lastTig[source] = nil end)

-- Casier judiciaire -----------------------------------------------------------------------------------------------------------------
local KIND_FR = { fine = 'Amende', cuff = 'Arrestation', search = 'Fouille', seize = 'Saisie', note = 'Note', jail = 'Prison', tig = 'TIG', release = 'Libération', care = 'Soin', repair = 'Réparation' }
J.KindLabel = KIND_FR
function J.Casier(license, limit)
    limit = limit or cfg('casier_lines', 12)
    local rows = {}
    for _, r in ipairs(DB.q('SELECT kind, text, amount, by_name, at FROM pb_biz_records WHERE license = ? AND kind IN (?, ?, ?, ?, ?) ORDER BY id DESC LIMIT ?', { license, 'fine', 'cuff', 'seize', 'note', 'search', limit }) or {}) do
        rows[#rows + 1] = { kind = r.kind, text = r.text, amount = r.amount, by = r.by_name, at = r.at }
    end
    for _, r in ipairs(DB.q('SELECT kind, text, amount, by_name, at FROM pb_justice_log WHERE license = ? ORDER BY id DESC LIMIT ?', { license, limit }) or {}) do
        rows[#rows + 1] = { kind = r.kind, text = r.text, amount = r.amount, by = r.by_name, at = r.at }
    end
    table.sort(rows, function(a, b) return (a.at or 0) > (b.at or 0) end)
    while #rows > limit do table.remove(rows) end
    return rows
end
function J.CasierText(license, name)
    local rows = J.Casier(license, 4)
    if #rows == 0 then return (name or 'Cette personne') .. ' : casier vierge.' end
    local out = {}
    for _, r in ipairs(rows) do out[#out + 1] = ('%s %s : %s'):format(os.date('%d/%m', r.at or 0), KIND_FR[r.kind] or r.kind, r.text) end
    return (name or '') .. ' · ' .. table.concat(out, ' | ')
end
exports('GetCriminalRecord', function(src)
    local p = G.Get(tonumber(src))
    return p and J.Casier(p.license, 50) or {}
end)

-- Appels d'urgence ---------------------------------------------------------------------------------------------------------------------
local function services()
    local out = {}
    for _, line in ipairs(cfg('services', {}) or {}) do
        local id, label, kind = tostring(line):match('^([%w_]+)|([^|]+)|([%w_]+)$')
        if id then out[#out + 1] = { id = id, label = clean(label, 30), kind = kind } end
    end
    return out
end
local function serviceById(id) for _, s in ipairs(services()) do if s.id == id then return s end end end
local function serviceByKind(kind) for _, s in ipairs(services()) do if s.kind == kind then return s end end end
J.Services = services
local function unitsOf(kind)
    local out = {}
    for src in pairs(G.Players()) do
        local c = Biz.Ctx(src)
        if c and c.duty and c.biz.kind == kind then out[#out + 1] = { src = src, name = display(src), c = c } end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end
J.UnitsOf = unitsOf
local function callRow(id) return DB.one('SELECT * FROM pb_calls WHERE id = ?', { math.floor(tonumber(id) or 0) }) end
J.Call = callRow
local function unitList(row) local t = PB.FromJson(row.units, {}) return type(t) == 'table' and t or {} end
local lastCall = {}

function J.NewCall(src, serviceId, text)
    if not cfg('calls_on', true) then return false, "Les appels d'urgence sont désactivés." end
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) then return false, 'Crée ton personnage avant.' end
    local sv = serviceById(serviceId)
    if not sv then return false, 'Service inconnu.' end
    text = clean(text, 200)
    if #text < 5 then return false, 'Décris la situation (5 caractères au moins).' end
    local t = now()
    if lastCall[src] and t - lastCall[src] < cfg('call_cd', 45) then return false, 'Patiente un peu avant un nouvel appel.' end
    local open = DB.one("SELECT COUNT(*) AS n FROM pb_calls WHERE license = ? AND status <> 'closed'", { p.license })
    if open and open.n >= cfg('call_max', 3) then return false, 'Tu as déjà trop d\'appels en cours (/annuler pour en clore).' end
    lastCall[src] = t
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped) or nil
    local x, y, z
    if c and not (c.x == 0 and c.y == 0 and c.z == 0) then x, y, z = c.x, c.y, c.z end
    local id = DB.insert('INSERT INTO pb_calls (service, license, name, text, x, y, z, status, units, created) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', { sv.id, p.license, display(src), text, x, y, z, 'open', '[]', t })
    local us = unitsOf(sv.kind)
    for _, u in ipairs(us) do
        G.Notify(u.src, { type = 'warn', title = ('Appel #%d · %s'):format(id, sv.label), text = display(src) .. ' : ' .. text, duration = 12000 })
        if x then fx(u.src, 'blip', { id = id, x = x, y = y, z = z }) end
    end
    G.Notify(src, { type = #us > 0 and 'success' or 'info', title = sv.label, text = #us > 0 and ('Appel transmis à %d unité(s) en service.'):format(#us) or "Aucune unité en service : ton appel est enregistré." })
    TriggerEvent('pb_panel:callCreated', src, id, sv.id)
    return true, id
end

-- Alerte automatique (braquage, trafic) : crée un appel anonyme visible des unités en service du type demandé
function J.Alert(kind, text, x, y, z)
    local sv = serviceByKind(kind or 'police')
    if not sv then return 0 end
    local t = now()
    local id = DB.insert('INSERT INTO pb_calls (service, license, name, text, x, y, z, status, units, created) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', { sv.id, '', 'Alerte automatique', clean(text, 200), x, y, z, 'open', '[]', t })
    local us = unitsOf(sv.kind)
    for _, u in ipairs(us) do
        G.Notify(u.src, { type = 'warn', title = ('Alerte #%d · %s'):format(id, sv.label), text = clean(text, 200), duration = 12000 })
        if x then fx(u.src, 'blip', { id = id, x = x, y = y, z = z }) end
    end
    return #us
end
function J.CountUnits(kind) return #unitsOf(kind or 'police') end
-- pour les autres ressources (braquages, cambriolages, GoFast…)
exports('PoliceAlert', function(text, x, y, z) return J.Alert('police', tostring(text or 'Alerte'), tonumber(x), tonumber(y), tonumber(z)) end)
exports('CountPolice', function() return J.CountUnits('police') end)

local function callAllowed(c, row)
    local sv = serviceById(row.service)
    return sv and c and c.duty and c.biz.kind == sv.kind
end

function J.ClaimCall(c, src, id)
    local row = callRow(id)
    if not row or row.status == 'closed' then return false, 'Appel introuvable ou clos.' end
    if not callAllowed(c, row) then return false, "Cet appel ne concerne pas ton service (ou tu n'es pas en service)." end
    if not (cfg('self_claim', true) or Biz.Allowed(c, 'dispatch')) then return false, 'Seul le répartiteur attribue les appels.' end
    local list = unitList(row)
    local me = display(src)
    for _, n in ipairs(list) do if n == me then return false, 'Tu es déjà sur cet appel.' end end
    list[#list + 1] = me
    DB.exec("UPDATE pb_calls SET status = 'claimed', units = ? WHERE id = ?", { PB.Json(list), row.id })
    if row.x then fx(src, 'gps', { x = row.x, y = row.y }) end
    for s, pl in pairs(G.Players()) do if pl.license == row.license then G.Notify(s, { type = 'success', title = 'Appel d\'urgence', text = me .. ' est en route.' }) end end
    return true, ('Appel #%d : tu es en route.'):format(row.id)
end

function J.AssignCall(c, src, id, unitSrc)
    if not Biz.Allowed(c, 'dispatch') or not c.duty then return false, "Tu n'es pas répartiteur en service." end
    local row = callRow(id)
    if not row or row.status == 'closed' then return false, 'Appel introuvable ou clos.' end
    if not callAllowed(c, row) then return false, "Cet appel ne concerne pas ton service." end
    unitSrc = tonumber(unitSrc)
    local uc = unitSrc and Biz.Ctx(unitSrc)
    if not uc or not uc.duty or uc.biz.kind ~= c.biz.kind then return false, "Cette unité n'est pas en service." end
    local list = unitList(row)
    local un = display(unitSrc)
    for _, n in ipairs(list) do if n == un then return false, 'Cette unité est déjà sur cet appel.' end end
    list[#list + 1] = un
    DB.exec("UPDATE pb_calls SET status = 'claimed', units = ? WHERE id = ?", { PB.Json(list), row.id })
    G.Notify(unitSrc, { type = 'warn', title = ('Appel #%d'):format(row.id), text = ('%s vous envoie : %s'):format(display(src), row.text), duration = 12000 })
    if row.x then fx(unitSrc, 'gps', { x = row.x, y = row.y }) end
    for s, pl in pairs(G.Players()) do if pl.license == row.license then G.Notify(s, { type = 'success', title = "Appel d'urgence", text = un .. ' est en route.' }) end end
    return true, ('%s envoyé sur l\'appel #%d.'):format(un, row.id)
end

function J.CloseCall(c, src, id)
    local row = callRow(id)
    if not row or row.status == 'closed' then return false, 'Appel introuvable ou clos.' end
    if not callAllowed(c, row) then return false, "Cet appel ne concerne pas ton service." end
    local me = display(src)
    local mine = false
    for _, n in ipairs(unitList(row)) do if n == me then mine = true end end
    if not (Biz.Allowed(c, 'dispatch') or mine) then return false, 'Seul le répartiteur ou une unité engagée peut clore.' end
    DB.exec("UPDATE pb_calls SET status = 'closed', closed_at = ? WHERE id = ?", { now(), row.id })
    return true, ('Appel #%d clos.'):format(row.id)
end

function J.ExpireCalls()
    local ttl = cfg('call_ttl', 30) * 60
    DB.exec("UPDATE pb_calls SET status = 'closed', closed_at = ? WHERE status <> 'closed' AND created < ?", { now(), now() - ttl })
end

local function callCmd(src, kindOrId, args, byKind)
    if src == 0 then return end
    local text = table.concat(args, ' ')
    local sv = byKind and serviceByKind(kindOrId) or serviceById(kindOrId)
    if not sv then G.Notify(src, { type = 'warn', title = "Appel d'urgence", text = "Ce service n'est pas disponible." }) return end
    local ok, msg = J.NewCall(src, sv.id, text)
    if not ok then G.Notify(src, { type = 'warn', title = sv.label, text = tostring(msg) }) end
end
RegisterCommand('911', function(src, args) callCmd(src, 'police', args, true) end, false)
RegisterCommand('112', function(src, args) callCmd(src, 'ems', args, true) end, false)
RegisterCommand('appel', function(src, args)
    local id = table.remove(args, 1)
    callCmd(src, tostring(id or ''), args, false)
end, false)
RegisterCommand('annuler', function(src)
    local p = src ~= 0 and G.Get(src)
    if not p then return end
    local n = DB.one("SELECT COUNT(*) AS n FROM pb_calls WHERE license = ? AND status <> 'closed'", { p.license })
    DB.exec("UPDATE pb_calls SET status = 'closed', closed_at = ? WHERE license = ? AND status <> 'closed'", { now(), p.license })
    G.Notify(src, { type = 'info', title = "Appel d'urgence", text = (n and n.n or 0) > 0 and 'Tes appels sont annulés.' or "Tu n'as aucun appel en cours." })
end, false)
AddEventHandler('playerDropped', function() lastCall[source] = nil end)

-- Actions du menu F6 ----------------------------------------------------------------------------------------------------
local viewing = {}   -- src -> { license, name } : casier consulté
AddEventHandler('playerDropped', function() viewing[source] = nil end)

local function jailAct(kind)
    return function(c, src, p)
        if not Biz.Allowed(c, 'jail') then return false, "Tu n'as pas le droit d'envoyer quelqu'un en prison." end
        if not c.duty then return false, 'Prends ton service.' end
        local tp, err, tid = Biz.Target(src, p.id)
        if not tp then return false, err end
        if cfg('jail_needs_cuffs', true) and not G.IsCuffed(tid) then return false, 'Menotte la personne avant de la condamner.' end
        local k = p.kind == 'tig' and 'tig' or kind
        local ok, msg = J.Sentence(display(src), tid, k, p.amount, p.reason)
        if ok then Biz.Record(c, tp.license, display(tid), k, ('%s — %s'):format(k == 'tig' and ('TIG ' .. math.floor(tonumber(p.amount) or 0) .. ' tâche(s)') or ('Prison ' .. math.floor(tonumber(p.amount) or 0) .. ' min'), clean(p.reason, 120)), 0) end
        return ok, msg
    end
end
Biz.ACT.jail = jailAct('jail')
Biz.ACT.tig = jailAct('tig')
Biz.ACT.release = function(c, src, p)
    if not Biz.Allowed(c, 'jail') then return false, "Tu n'as pas le droit de libérer un détenu." end
    if not c.duty then return false, 'Prends ton service.' end
    local tid = tonumber(p.id)
    if not tid or not jailed[tid] then return false, "Cette personne n'est pas détenue." end
    return J.Release(tid, display(src), 'Libéré(e) par ' .. display(src) .. '.')
end
local function findByName(q)
    q = clean(q, 40):lower()
    if #q < 3 then return nil, 'Saisis au moins 3 lettres du nom.' end
    local like = '%' .. q:gsub('[%%_]', '') .. '%'
    local rows = DB.q("SELECT license, firstname, lastname FROM pb_players WHERE created = 1 AND LOWER(CONCAT(firstname, ' ', lastname)) LIKE ? LIMIT 3", { like }) or {}
    if #rows == 0 then return nil, 'Aucun citoyen trouvé.' end
    if #rows > 1 then return nil, 'Plusieurs citoyens correspondent : précise le nom.' end
    return { license = rows[1].license, name = ((rows[1].firstname or '') .. ' ' .. (rows[1].lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') }
end
Biz.ACT.casier_open = function(c, src, p)
    if c.biz.kind ~= 'police' or not (Biz.Allowed(c, 'records') or Biz.Allowed(c, 'jail')) then return false, "Tu n'as pas accès aux casiers." end
    if not c.duty then return false, 'Prends ton service.' end
    local who
    if tostring(p.name or '') ~= '' then
        local r, err = findByName(p.name)
        if not r then return false, err end
        who = r
    else
        local tp, err, tid = Biz.Target(src, p.id, true)
        if not tp then return false, err end
        who = { license = tp.license, name = display(tid) }
    end
    viewing[src] = who
    return true, 'Casier de ' .. who.name .. ' ouvert.'
end
Biz.ACT.casier = function(c, src, p)
    if c.biz.kind ~= 'police' or not (Biz.Allowed(c, 'records') or Biz.Allowed(c, 'jail')) then return false, "Tu n'as pas accès aux casiers." end
    if not c.duty then return false, 'Prends ton service.' end
    local tp, err, tid = Biz.Target(src, p.id, true)
    if not tp then return false, err end
    return true, J.CasierText(tp.license, display(tid))
end
Biz.ACT.dispatch_claim = function(c, src, p) return J.ClaimCall(c, src, p.id) end
Biz.ACT.dispatch_assign = function(c, src, p) return J.AssignCall(c, src, p.id, p.unit) end
Biz.ACT.dispatch_close = function(c, src, p) return J.CloseCall(c, src, p.id) end
Biz.ACT.dispatch_gps = function(c, src, p)
    local row = callRow(p.id)
    if not row or row.status == 'closed' or not row.x then return false, 'Appel sans position.' end
    if not callAllowed(c, row) then return false, "Cet appel ne concerne pas ton service." end
    fx(src, 'gps', { x = row.x, y = row.y })
    return true, 'Point placé sur ta carte.'
end

-- Pages de la tablette ------------------------------------------------------------------------------------------------------------------
local function ago(t) local s = math.max(0, now() - (t or 0)) if s < 90 then return s .. ' s' elseif s < 5400 then return math.floor(s / 60) .. ' min' else return math.floor(s / 3600) .. ' h' end end
local function nearOpts(src, withSelf)
    local opts = {}
    for _, n in ipairs(Biz.Nearby(src)) do opts[#opts + 1] = { tostring(n.id), n.name .. ' (' .. n.id .. ')' } end
    if withSelf then opts[#opts + 1] = { tostring(src), 'Moi-même (' .. src .. ')' } end
    return opts
end

Biz.PAGE_META.justice = { label = 'Justice', icon = 'book', group = 'Entreprise' }
Biz.PAGE_META.dispatch = { label = 'Appels', icon = 'siren', group = 'Entreprise' }
table.insert(Biz.ORDER, 'justice')
table.insert(Biz.ORDER, 'dispatch')
Biz.NavAllow.justice = function(c) return c.biz.kind == 'police' and (Biz.Allowed(c, 'records') or Biz.Allowed(c, 'jail')) end
Biz.NavAllow.dispatch = function(c) return (c.biz.kind == 'police' or c.biz.kind == 'ems') and cfg('calls_on', true) end

Biz.PAGES.justice = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.NavAllow.justice(c) then return nil end
    local blocks = {}
    local detainees = {}
    for sid, j in pairs(jailed) do
        detainees[#detainees + 1] = { id = sid, name = j.name or display(sid), kind = j.kind == 'tig' and 'TIG' or 'Prison', left = j.kind == 'tig' and (j.remaining .. ' tâche(s)') or (math.ceil(j.remaining / 60) .. ' min'), reason = j.reason,
            actions = Biz.Allowed(c, 'jail') and { { act = 'release', label = 'Libérer', payload = { id = sid }, primary = true } } or nil }
    end
    table.sort(detainees, function(a, b) return a.name < b.name end)
    blocks[#blocks + 1] = { type = 'notice', text = c.duty and 'Condamner exige une personne menottée à portée. Le casier regroupe amendes, arrestations, prison et TIG.' or 'Prends ton service pour utiliser la justice.' }
    blocks[#blocks + 1] = { type = 'form', id = 'casier', title = 'Consulter un casier', desc = 'Choisis une personne à proximité, ou saisis son nom (3 lettres au moins).', fields = {
        { k = 'id', type = 'select', label = 'Citoyen (à proximité)', opts = nearOpts(src, true) }, { k = 'name', type = 'text', label = 'Ou nom du citoyen', maxlen = 40 } }, submit = { act = 'casier_open', label = 'Ouvrir le casier' } }
    local v = viewing[src]
    if v then
        local rows = {}
        for _, r in ipairs(J.Casier(v.license, 40)) do rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at or 0), kind = KIND_FR[r.kind] or r.kind, text = r.text, amount = (r.amount or 0) > 0 and tostring(r.amount) or '', by = r.by } end
        blocks[#blocks + 1] = { type = 'table', title = 'Casier de ' .. v.name, columns = { { k = 'at', label = 'Date' }, { k = 'kind', label = 'Type' }, { k = 'text', label = 'Détail' }, { k = 'by', label = 'Par' } }, rows = rows, empty = 'Casier vierge.' }
    end
    if Biz.Allowed(c, 'jail') then
        blocks[#blocks + 1] = { type = 'form', id = 'jail', title = 'Condamner', desc = ('Prison : jusqu\'à %d min. TIG : jusqu\'à %d tâches.'):format(cfg('max_jail', 180), cfg('tig_max', 30)), fields = {
            { k = 'id', type = 'select', label = 'Citoyen (à proximité)', opts = nearOpts(src) }, { k = 'kind', type = 'select', label = 'Peine', opts = { { 'jail', 'Prison (minutes)' }, { 'tig', "Travaux d'intérêt général (tâches)" } } },
            { k = 'amount', type = 'number', label = 'Minutes ou tâches', min = 1, max = math.max(cfg('max_jail', 180), cfg('tig_max', 30)) }, { k = 'reason', type = 'text', label = 'Motif', maxlen = 120 } }, submit = { act = 'jail', label = 'Prononcer la peine' } }
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Détenus en ligne', columns = { { k = 'name', label = 'Nom' }, { k = 'kind', label = 'Peine' }, { k = 'left', label = 'Reste' }, { k = 'reason', label = 'Motif' } }, rows = detainees, empty = 'Aucun détenu.' }
    return blocks, 'Justice'
end

Biz.PAGES.dispatch = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.NavAllow.dispatch(c) then return nil end
    local isDisp = Biz.Allowed(c, 'dispatch')
    local units = unitsOf(c.biz.kind)
    local rows, nOpen = {}, 0
    for _, row in ipairs(DB.q("SELECT * FROM pb_calls WHERE status <> 'closed' ORDER BY id DESC LIMIT 40") or {}) do
        local sv = serviceById(row.service)
        if sv and sv.kind == c.biz.kind then
            nOpen = nOpen + 1
            local acts = {}
            if c.duty and (cfg('self_claim', true) or isDisp) then acts[#acts + 1] = { act = 'dispatch_claim', label = 'Répondre', payload = { id = row.id }, primary = true } end
            if row.x then acts[#acts + 1] = { act = 'dispatch_gps', label = 'GPS', payload = { id = row.id } } end
            if c.duty then acts[#acts + 1] = { act = 'dispatch_close', label = 'Clore', payload = { id = row.id } } end
            rows[#rows + 1] = { id = '#' .. row.id, who = row.name, text = row.text, state = row.status == 'claimed' and 'Prise en charge' or 'Nouveau', units = table.concat(unitList(row), ', '), ago = ago(row.created), actions = acts }
        end
    end
    local blocks = {
        { type = 'cards', items = { { title = 'Appels ouverts', value = tostring(nOpen), icon = 'siren', tone = '#ffb457', sub = c.biz.label }, { title = 'Unités en service', value = tostring(#units), icon = 'users', tone = '#6fb4ff', sub = isDisp and 'Tu es répartiteur' or 'Équipes disponibles' } } },
        { type = 'notice', text = c.duty and (isDisp and 'Tu peux envoyer une unité précise sur un appel.' or 'Réponds à un appel pour recevoir le point GPS.') or 'Prends ton service pour recevoir et traiter les appels.' },
        { type = 'table', title = "Appels d'urgence", columns = { { k = 'id', label = 'N°' }, { k = 'who', label = 'Appelant' }, { k = 'text', label = 'Situation' }, { k = 'state', label = 'État' }, { k = 'units', label = 'Unités' }, { k = 'ago', label = 'Il y a' } }, rows = rows, empty = 'Aucun appel ouvert.' } }
    if isDisp and c.duty and #units > 0 and nOpen > 0 then
        local callOpts, unitOpts = {}, {}
        for _, r in ipairs(rows) do callOpts[#callOpts + 1] = { tostring(r.id):gsub('#', ''), r.id .. ' · ' .. r.who } end
        for _, u in ipairs(units) do unitOpts[#unitOpts + 1] = { tostring(u.src), u.name .. ' (' .. u.src .. ')' } end
        table.insert(blocks, 3, { type = 'form', id = 'assign', title = 'Envoyer une unité', desc = "L'unité reçoit une notification et le point GPS.", fields = {
            { k = 'id', type = 'select', label = 'Appel', opts = callOpts }, { k = 'unit', type = 'select', label = 'Unité en service', opts = unitOpts } }, submit = { act = 'dispatch_assign', label = 'Envoyer' } })
    end
    return blocks, 'Appels'
end

-- Panel : réglages, détenus, appels, journal ----------------------------------------------------------------------------------------------
-- Prisons : les lieux se règlent ici ou, plus simplement, en jeu (F10 › Builder › Prison)
local prisons = Form.Cfg({ ns = 'justice', id = 'prisons', title = 'Prison de la police et prison du staff', perm = 'justice.edit', cols = 2, fields = {
    { k = 'jail_x', type = 'number', label = 'Prison : X', default = 1691.0, min = -10000, max = 10000, int = false, step = 0.1 }, { k = 'jail_y', type = 'number', label = 'Prison : Y', default = 2565.0, min = -10000, max = 10000, int = false, step = 0.1 },
    { k = 'jail_z', type = 'number', label = 'Prison : Z', default = 45.6, min = -500, max = 3000, int = false, step = 0.1 }, { k = 'jail_radius', type = 'number', label = 'Prison : rayon (m)', default = 70, min = 10, max = 500 },
    { k = 'release_x', type = 'number', label = 'Sortie : X', default = 1846.0, min = -10000, max = 10000, int = false, step = 0.1 }, { k = 'release_y', type = 'number', label = 'Sortie : Y', default = 2585.9, min = -10000, max = 10000, int = false, step = 0.1 },
    { k = 'release_z', type = 'number', label = 'Sortie : Z', default = 45.7, min = -500, max = 3000, int = false, step = 0.1 },
    { k = 'sjail_x', type = 'number', label = "Prison du staff : X", default = 0.0, min = -10000, max = 10000, int = false, step = 0.1 }, { k = 'sjail_y', type = 'number', label = "Prison du staff : Y", default = 0.0, min = -10000, max = 10000, int = false, step = 0.1 },
    { k = 'sjail_z', type = 'number', label = 'Prison du staff : Z', default = 0.0, min = -500, max = 3000, int = false, step = 0.1 }, { k = 'sjail_radius', type = 'number', label = 'Prison du staff : rayon (m)', default = 25, min = 5, max = 500 },
    { k = 'srelease_x', type = 'number', label = "Sortie du staff : X", default = 0.0, min = -10000, max = 10000, int = false, step = 0.1 }, { k = 'srelease_y', type = 'number', label = "Sortie du staff : Y", default = 0.0, min = -10000, max = 10000, int = false, step = 0.1 },
    { k = 'srelease_z', type = 'number', label = 'Sortie du staff : Z', default = 0.0, min = -500, max = 3000, int = false, step = 0.1 },
} })

local settings = Form.Cfg({ ns = 'justice', id = 'settings', title = 'Justice', perm = 'justice.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Justice active (prison, TIG)', default = true },
    { k = 'max_jail', type = 'number', label = 'Peine de prison maximale (minutes)', default = 180, min = 1, max = 1440 },
    { k = 'jail_needs_cuffs', type = 'toggle', label = 'Condamner : exiger que la personne soit menottée', default = true },
    { k = 'tig_on', type = 'toggle', label = "Travaux d'intérêt général (TIG) actifs", default = true },
    { k = 'tig_max', type = 'number', label = 'TIG : tâches maximales', default = 30, min = 1, max = 200 }, { k = 'tig_secs', type = 'number', label = "TIG : durée d'une tâche (secondes)", default = 8, min = 3, max = 60 },
    { k = 'tig_radius', type = 'number', label = 'TIG : rayon du chantier (m)', default = 3.0, min = 1, max = 15, int = false, step = 0.5 },
    { k = 'tig_points', type = 'list', label = 'Chantiers TIG (x|y|z|nom)', default = { '195.0|-934.0|30.7|Legion Square', '-267.0|-958.0|31.2|Alta Street', '-47.0|-585.0|37.9|Integrity Way' }, maxitems = 12, maxlen = 80, pattern = '^%-?[%d%.]+|%-?[%d%.]+|%-?[%d%.]+|.*$', wide = true },
    { k = 'calls_on', type = 'toggle', label = "Appels d'urgence (/911, /112, /appel) actifs", default = true },
    { k = 'call_cd', type = 'number', label = 'Délai entre deux appels (secondes)', default = 45, min = 5, max = 600 }, { k = 'call_max', type = 'number', label = "Appels ouverts maximum par joueur", default = 3, min = 1, max = 10 },
    { k = 'call_ttl', type = 'number', label = 'Clôture automatique après (minutes)', default = 30, min = 5, max = 240 },
    { k = 'self_claim', type = 'toggle', label = 'Les unités peuvent répondre elles-mêmes (sinon seul le répartiteur attribue)', default = true },
    { k = 'services', type = 'list', label = 'Services appelables (identifiant|nom|type de métier)', default = { 'police|Police|police', 'ems|Secours|ems' }, maxitems = 6, maxlen = 60, pattern = '^[%w_]+|[^|]+|[%w_]+$', wide = true, hint = "Le type de métier est celui de l'entreprise : police, ems, garage… /911 appelle le premier service « police », /112 le premier « ems », /appel <identifiant> n'importe lequel." },
    { k = 'casier_lines', type = 'number', label = 'Lignes du casier (aperçu F6)', default = 12, min = 3, max = 50 },
} })

PB.Action('justice.release', 'justice.manage', function(ctx, p)
    local ok, msg = J.ReleaseLicense(tostring(p.license or ''), ctx.actor.name)
    if not ok then return false, msg end
    ctx.audit('justice', 'release', tostring(p.license or ''), nil, nil)
    ctx.toast = msg
    return true
end, { critical = true, confirm = { title = 'Libérer ce détenu ?', text = 'Sa peine est supprimée immédiatement.' } })
PB.Action('justice.call.close', 'justice.manage', function(ctx, p)
    local id = math.floor(tonumber(p.cid) or 0)
    if not callRow(id) then return false, 'Appel introuvable.' end
    DB.exec("UPDATE pb_calls SET status = 'closed', closed_at = ? WHERE id = ?", { now(), id })
    ctx.toast = 'Appel clos.'
    return true
end)

PB.Module({
    id = 'justice', label = 'Justice et urgences', icon = 'siren', group = 'Serveur', order = 143, perm = 'justice.edit', hint = 'Prison, TIG, casiers, appels et répartiteur',
    caps = function()
        return PB.Capsify({
            { 'Casier judiciaire', 'ok', 'Amendes, arrestations, saisies, notes, prison et TIG, consultable depuis le menu F6 (page Citoyens) ou le contrôle d\'identité.' },
            { 'Prison avec minuteur', 'ok', "Le temps ne s'écoule qu'en ligne ; le joueur est ramené s'il sort du périmètre ; la peine survit à la déconnexion." },
            { "Travaux d'intérêt général", 'ok', 'Chantiers à rejoindre, une tâche = quelques secondes, vérifiées par le serveur.' },
            { "Appels d'urgence et répartiteur", 'ok', '/911, /112 et /appel ; page « Appels » dans le menu F6 : répondre, envoyer une unité, point GPS, clore.' },
            { 'Procès, avocats, tribunaux', 'off', "Non pris en charge : la peine est prononcée par un agent habilité." },
            { 'Menottes, escorte, mise en véhicule', 'ok', "Menu ALT (sur la personne) ou F6 de la police : escorter, mettre dans le véhicule ; ALT sur le véhicule pour la sortir." },
        })
    end,
    doc = "## Justice\n- **Droits** : dans *Entreprises*, les grades de la police reçoivent `jail` (prison et TIG) et `dispatch` (répartiteur). Les secours reçoivent `dispatch`.\n- **Appels** : `/911 message` (police), `/112 message` (secours), `/appel <service> message`, `/annuler`.\n- **Coordonnées** : prison, sortie et chantiers TIG se règlent dans l'onglet *Réglages*.",
    view = function(ctx)
        return { tabs = {
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
            { id = 'prisons', label = 'Prisons', icon = 'lock', build = function() return { B.notice('info', "Le plus simple : en jeu, F10 › Builder › Prison. Place-toi à l'endroit voulu : lieu du détenu, sortie, limite de la zone, et chantiers TIG. Prison de la police : peines prononcées par la police. Prison du staff : peines du menu staff et de /jail ; X et Y à 0 = les détenus vont dans la prison de la police."), prisons(ctx) } end },
            { id = 'jailed', label = 'Détenus', icon = 'lock', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT license, name, kind, remaining, reason, by_name, since FROM pb_jail ORDER BY since DESC LIMIT 200') or {}) do
                    rows[#rows + 1] = { name = r.name, kind = r.kind == 'tig' and 'TIG' or 'Prison', left = r.kind == 'tig' and (r.remaining .. ' tâche(s)') or (math.ceil(r.remaining / 60) .. ' min'), reason = r.reason, by = r.by_name, at = r.since,
                        actions = ctx.has('justice.manage') and { { action = 'justice.release', label = 'Libérer', icon = 'check', payload = { license = r.license } } } or nil }
                end
                return { B.table({ id = 'jailed', title = 'Détenus (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'kind', label = 'Peine', type = 'badge' }, { k = 'left', label = 'Reste' }, { k = 'reason', label = 'Motif' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Depuis', type = 'date' } }, rows = rows, empty = 'Aucun détenu.' }) }
            end },
            { id = 'calls', label = 'Appels', icon = 'siren', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT id, service, name, text, status, units, created FROM pb_calls ORDER BY id DESC LIMIT 100') or {}) do
                    rows[#rows + 1] = { id = '#' .. r.id, service = r.service, who = r.name, text = r.text, status = r.status, units = table.concat(unitList(r), ', '), at = r.created,
                        actions = (ctx.has('justice.manage') and r.status ~= 'closed') and { { action = 'justice.call.close', label = 'Clore', icon = 'check', payload = { cid = r.id } } } or nil }
                end
                return { B.table({ id = 'calls', title = "Appels d'urgence", search = true, columns = { { k = 'id', label = 'N°' }, { k = 'service', label = 'Service', type = 'badge' }, { k = 'who', label = 'Appelant' }, { k = 'text', label = 'Situation' }, { k = 'status', label = 'État', type = 'badge' }, { k = 'units', label = 'Unités' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Aucun appel.' }) }
            end },
            { id = 'log', label = 'Journal', icon = 'history', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT name, kind, text, by_name, at FROM pb_justice_log ORDER BY id DESC LIMIT 200') or {}) do rows[#rows + 1] = { name = r.name, kind = KIND_FR[r.kind] or r.kind, text = r.text, by = r.by_name, at = r.at } end
                return { B.table({ id = 'jlog', title = 'Journal de la justice', search = true, columns = { { k = 'name', label = 'Citoyen' }, { k = 'kind', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Rien pour le moment.' }) }
            end },
        } }
    end,
})

PB.SelfTest.Add('justice', function(R)
    R.check(G.Biz ~= nil and G.Police ~= nil, 'prison', "les entreprises ou la police ne sont pas chargées : impossible de condamner")
    local s = services()
    R.check(#s > 0, "services d'urgence", 'aucun service configuré')
    R.check(#tigPoints() > 0 or cfg('tig_on', true) == false, 'chantiers TIG', 'aucun chantier alors que les TIG sont actifs')
    local jp = jailPos()
    R.check(not (jp.x == 0 and jp.y == 0), 'position de la prison', 'coordonnées à zéro')
end)
