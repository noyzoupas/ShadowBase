-- Carte du jeu : styles de carte et lieux communs. (Le menu Échap du serveur a été retiré : Échap ouvre le menu de GTA.)
-- Les tables restent en base : les lieux déjà enregistrés par les joueurs s'affichent toujours dans la carte rapide.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local U = {}
G.Pause = U

P.Register('pause.edit', 'Modifier la carte du jeu (styles, lieux communs)', 'pause', true)
PB.Migrate('096_pause', 'Menu Échap : parcours et lieux enregistrés', {
    [[CREATE TABLE IF NOT EXISTS pb_pause_path (id INT AUTO_INCREMENT PRIMARY KEY, license VARCHAR(64) NOT NULL, kind VARCHAR(8) NOT NULL, ref VARCHAR(48) NOT NULL DEFAULT '', label VARCHAR(80) NOT NULL, grade VARCHAR(40) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, KEY k_lic (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_pause_places (id INT AUTO_INCREMENT PRIMARY KEY, license VARCHAR(64) NOT NULL, label VARCHAR(40) NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, at INT NOT NULL DEFAULT 0, KEY k_lic (license))]],
})
PB.Cfg.Define('pause', { map_on_p = false, places = {}, map_styles = {}, map_target = 'radarmasterhi' })
local function cfg(k, d) return PB.Cfg.Get('pause', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

local function sharedPlaces()
    local out = {}
    for i, l in ipairs(cfg('places', {}) or {}) do
        if type(l) == 'table' and tonumber(l.x) and tonumber(l.y) then out[#out + 1] = { id = 's' .. i, label = clean(l.label, 40), x = tonumber(l.x), y = tonumber(l.y), z = tonumber(l.z) or 0, shared = true } end
    end
    return out
end
function U.Places(src)
    local p = G.Get(src)
    local out = sharedPlaces()
    if p then
        for _, r in ipairs(DB.q('SELECT id, label, x, y, z FROM pb_pause_places WHERE license = ? ORDER BY id', { p.license }) or {}) do
            out[#out + 1] = { id = 'p' .. r.id, label = r.label, x = r.x, y = r.y, z = r.z }
        end
    end
    return out
end

local mapForm = Form.Cfg({ ns = 'pause', id = 'map_styles', title = 'Styles de carte (menu « Type de carte »)', perm = 'pause.edit', cols = 2, fields = {
    { k = 'map_target', type = 'text', label = 'Texture de la carte du jeu à remplacer', default = 'radarmasterhi', maxlen = 40, hint = "Nom de la texture de la carte du menu pause (platform:/textures/graphics). Laisse radarmasterhi sauf si ton pack de carte dit autre chose." },
    { k = 'map_styles', type = 'rows', label = 'Styles proposés aux joueurs', default = {}, wide = true, maxitems = 8,
      hint = "Chaque style est une image de carte que tu streames toi-même (dossier stream/ d'une ressource : un .ytd par style). Nom = ce que voit le joueur ; Dictionnaire = nom du .ytd (sans l'extension) ; Texture = nom de l'image dedans. Le style d'origine du jeu reste toujours proposé.",
      cols = { { k = 'label', label = 'Nom', required = true, maxlen = 30 }, { k = 'dict', label = 'Dictionnaire (.ytd)', required = true, maxlen = 40, pattern = '^[%w_%-]+$' }, { k = 'tex', label = 'Texture', required = true, maxlen = 40, pattern = '^[%w_%-]+$' } } } } })
local placeForm = Form.Cfg({ ns = 'pause', id = 'places', title = 'Lieux proposés à tous', perm = 'pause.edit', fields = {
    { k = 'places', type = 'rows', label = 'Lieux (coordonnées du jeu)', default = {}, wide = true, maxitems = 40,
      hint = 'Visibles par tous les joueurs dans la carte rapide (M).',
      cols = { { k = 'label', label = 'Nom', required = true, maxlen = 40 }, { k = 'x', label = 'X', number = true, required = true }, { k = 'y', label = 'Y', number = true, required = true }, { k = 'z', label = 'Z', number = true } } } } })

PB.Module({
    id = 'pause', label = 'Carte du jeu', icon = 'map', group = 'Serveur', order = 147, perm = 'pause.edit', hint = 'Styles de carte, lieux communs',
    doc = "## Carte du jeu\n**Échap** ouvre le menu de pause de GTA. Ici : les styles de carte proposés aux joueurs et les lieux communs affichés dans la carte rapide (M).",
    view = function(ctx)
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'eye', build = function() return { mapForm(ctx), B.notice('info', "Le panneau à droite de la carte du jeu (/carte). Les lieux viennent des repères que les scripts posent sur la carte. Icônes : web/img/blips."), { type = 'gpreview', kind = 'atlas', title = 'Panneau de la carte vu par le joueur (exemple)', cfg = {} } } end },
            { id = 'places', label = 'Lieux', icon = 'gps', build = function() return { placeForm(ctx) } end },
        } }
    end,
})
