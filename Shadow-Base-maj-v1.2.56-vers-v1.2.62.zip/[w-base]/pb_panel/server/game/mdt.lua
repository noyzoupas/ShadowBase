-- Tablette de police (MDT) : fiches citoyens, plaques, appels, avis de recherche, rapports, unités, détenus, code pénal.
-- Ouverte depuis le menu F6 ou /mdt, partout en ville, seulement en service. Le serveur revérifie les droits à chaque requête.
-- Les licences ne partent jamais au client : il ne reçoit qu'un numéro (tok) valable jusqu'au redémarrage de la ressource.
-- Amendes, prison et menottes restent dans le menu F6 / ALT : elles demandent d'être à côté de la personne.

local Form = PB.Form
local G, DB = PB.G, PB.DB
local Biz, J, Q = G.Biz, G.Justice, G.Quick
local M = {}
G.Mdt = M

PB.Migrate('390_mdt', 'Tablette de police : avis de recherche et rapports', {
    [[CREATE TABLE IF NOT EXISTS pb_mdt_wanted (
        id INT NOT NULL AUTO_INCREMENT, kind VARCHAR(8) NOT NULL, ref VARCHAR(64) NOT NULL, label VARCHAR(80) NOT NULL DEFAULT '', reason VARCHAR(160) NOT NULL DEFAULT '',
        danger TINYINT NOT NULL DEFAULT 1, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, closed_at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_ref (kind, ref, closed_at))]],
    [[CREATE TABLE IF NOT EXISTS pb_mdt_reports (
        id INT NOT NULL AUTO_INCREMENT, kind VARCHAR(12) NOT NULL DEFAULT 'intervention', title VARCHAR(80) NOT NULL DEFAULT '', body TEXT NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', by_license VARCHAR(64) NOT NULL DEFAULT '',
        cit_license VARCHAR(64) NOT NULL DEFAULT '', cit_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_cit (cit_license))]],
})

PB.Cfg.Define('mdt', { enabled = true, opacity = 12 })
local function cfg(k, d) return PB.Cfg.Get('mdt', k, d) end
local function now() return os.time() end
local function date(t) return os.date('%d/%m %H:%M', t or 0) end
local function ago(t) local s = math.max(0, now() - (t or 0)) if s < 90 then return s .. ' s' elseif s < 5400 then return math.floor(s / 60) .. ' min' else return math.floor(s / 3600) .. ' h' end end

-- coupe sans casser un caractère accentué ; keepLines garde les retours à la ligne (corps d'un rapport)
local function clean(s, n, keepLines)
    s = tostring(s or ''):gsub(keepLines and '[\0-\9\11-\31<>]' or '[%c<>]', '')
    s = s:gsub('^%s+', ''):gsub('%s+$', '')
    if #s <= n then return s end
    local e = n
    while e > 0 do local b = s:byte(e + 1) if b and b >= 0x80 and b < 0xC0 then e = e - 1 else break end end
    return s:sub(1, e)
end
local function fullName(r) return (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) end
local function like(q) return '%' .. q:gsub('[%%_\\]', '') .. '%' end

-- Numéros à la place des licences
local toks, licOf, nextTok = {}, {}, 0
local function tok(license)
    if not license or license == '' then return nil end
    if not toks[license] then nextTok = nextTok + 1 toks[license] = nextTok licOf[nextTok] = license end
    return toks[license]
end
local function citizen(cid)
    local license = licOf[math.floor(tonumber(cid) or 0)]
    local r = license and DB.one('SELECT * FROM pb_players WHERE license = ? AND created = 1', { license })
    if not r then return nil, 'Citoyen introuvable.' end
    return r, fullName(r)
end
local function isOnline(license) for _, pl in pairs(G.Players()) do if pl.license == license then return true end end return false end

-- Droits ------------------------------------------------------------------------------------------------------------------------------
local function access(src)
    if not cfg('enabled', true) then return nil, 'La tablette de police est désactivée.' end
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) or G.IsCuffed(src) then return nil, 'Tablette indisponible pour le moment.' end
    local c = Biz.Ctx(src)
    if not c or c.biz.kind ~= 'police' or not (Biz.Allowed(c, 'records') or Biz.Allowed(c, 'jail')) then return nil, 'Réservé à la police.' end
    if not c.duty then return nil, 'Prends ton service pour utiliser la tablette.' end
    return c
end
M.Access = access

-- Statut des unités (en mémoire) : remis à « Disponible » à chaque connexion
local STATUS = { ['10-8'] = 'Disponible', ['10-6'] = 'Occupé', ['10-97'] = 'En route', ['10-23'] = 'Sur place', ['10-7'] = 'Pause' }
local unitStatus = {}
local function statusOf(src) return unitStatus[src] or '10-8' end

-- Lignes communes -----------------------------------------------------------------------------------------------------------------------
local function callList(c, limit)
    local out, me = {}, Biz.Display(c.src)
    local kinds = {}
    for _, s in ipairs(J.Services()) do kinds[s.id] = s.kind end
    for _, r in ipairs(DB.q("SELECT * FROM pb_calls WHERE status <> 'closed' ORDER BY id DESC LIMIT 40") or {}) do
        if kinds[r.service] == c.biz.kind and #out < (limit or 40) then
            local units, mine = PB.FromJson(r.units, {}), false
            if type(units) ~= 'table' then units = {} end
            for _, n in ipairs(units) do if n == me then mine = true end end
            out[#out + 1] = { id = r.id, who = r.name, text = r.text, claimed = r.status == 'claimed', units = table.concat(units, ', '), ago = ago(r.created), pos = r.x ~= nil, mine = mine }
        end
    end
    return out
end
local function wantedRow(r)
    return { id = r.id, kind = r.kind, label = r.label, reason = r.reason, danger = r.danger, by = r.by_name, at = date(r.at), cid = r.kind == 'person' and tok(r.ref) or nil, plate = r.kind == 'vehicle' and r.ref or nil }
end
local function wantedList(limit)
    local out = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_mdt_wanted WHERE closed_at = 0 ORDER BY danger DESC, id DESC LIMIT ?', { limit or 80 }) or {}) do out[#out + 1] = wantedRow(r) end
    return out
end
local function wantedOf(kind, ref)
    local out = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_mdt_wanted WHERE kind = ? AND ref = ? AND closed_at = 0 ORDER BY id DESC', { kind, ref }) or {}) do out[#out + 1] = wantedRow(r) end
    return out
end
local function wantedSet(kind)
    local set = {}
    for _, r in ipairs(DB.q('SELECT ref FROM pb_mdt_wanted WHERE kind = ? AND closed_at = 0', { kind }) or {}) do set[r.ref] = true end
    return set
end
local function unitList()
    local out = {}
    for _, u in ipairs(J.UnitsOf('police')) do
        local code = statusOf(u.src)
        out[#out + 1] = { name = u.name, grade = u.c.grade.label, code = code, status = STATUS[code] }
    end
    return out
end
local VEH_STATE = { garage = 'Au garage', out = 'En circulation', impound = 'En fourrière' }
local function vehRow(r, set)
    return { plate = r.plate, label = r.label ~= '' and r.label or r.model, state = VEH_STATE[r.state or 'garage'] or tostring(r.state), reason = r.reason, wanted = set[r.plate] == true,
        owner = r.firstname and fullName(r) or nil, cid = r.firstname and tok(r.license) or nil }
end

-- Requêtes de la tablette : chacune renvoie ses données, ou nil + l'erreur ---------------------------------------------------------------
local OP = {}

OP.home = function(c)
    local jailed = DB.one("SELECT COUNT(*) AS n FROM pb_jail WHERE kind <> 'ajal'")
    local calls, wanted = callList(c, 40), wantedList(80)
    return { nCalls = #calls, nWanted = #wanted, nJailed = jailed and jailed.n or 0, calls = { table.unpack(calls, 1, 5) }, wanted = { table.unpack(wanted, 1, 5) }, units = unitList() }
end

OP.citizens = function(_, _, p)
    local q = clean(p.q, 40):lower()
    if #q < 2 then return nil, 'Saisis au moins 2 caractères.' end
    local set, rows = wantedSet('person'), {}
    for _, r in ipairs(DB.q("SELECT p.license, p.firstname, p.lastname, p.dob, p.sex, n.number FROM pb_players p LEFT JOIN pb_phone_numbers n ON n.license = p.license WHERE p.created = 1 AND (LOWER(CONCAT(p.firstname, ' ', p.lastname)) LIKE ? OR n.number LIKE ?) ORDER BY p.lastname, p.firstname LIMIT 30", { like(q), like(q) }) or {}) do
        rows[#rows + 1] = { cid = tok(r.license), name = fullName(r), dob = r.dob, phone = r.number, wanted = set[r.license] == true, online = isOnline(r.license) }
    end
    return { rows = rows }
end

OP.citizen = function(_, _, p)
    local r, name = citizen(p.cid)
    if not r then return nil, name end
    local lic = r.license
    local phone = DB.one('SELECT number FROM pb_phone_numbers WHERE license = ?', { lic })
    local permit = DB.one("SELECT by_name, at FROM pb_permits WHERE license = ? AND kind = 'weapon'", { lic })
    local unpaid = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS total FROM pb_biz_invoices WHERE license = ? AND kind = 'fine' AND status = 'pending'", { lic })
    local jail = DB.one('SELECT kind, remaining, reason FROM pb_jail WHERE license = ?', { lic })
    local set, vehicles, casier, reports = wantedSet('vehicle'), {}, {}, {}
    for _, v in ipairs(DB.q('SELECT v.plate, v.model, v.label, s.state, s.reason FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.license = ? ORDER BY v.id LIMIT 20', { lic }) or {}) do vehicles[#vehicles + 1] = vehRow(v, set) end
    for _, l in ipairs(J.Casier(lic, 40)) do casier[#casier + 1] = { at = date(l.at), kind = J.KindLabel[l.kind] or l.kind, text = l.text, amount = l.amount, by = l.by } end
    for _, x in ipairs(DB.q('SELECT id, title, at FROM pb_mdt_reports WHERE cit_license = ? ORDER BY id DESC LIMIT 10', { lic }) or {}) do reports[#reports + 1] = { id = x.id, title = x.title, at = date(x.at) } end
    return { cid = tok(lic), name = name, dob = r.dob, sex = r.sex == 'f' and 'Femme' or 'Homme', height = r.height, nationality = r.nationality, phone = phone and phone.number or nil, online = isOnline(lic),
        permit = permit and true or false, unpaid = unpaid and unpaid.n or 0, unpaidTotal = unpaid and unpaid.total or 0,
        jail = jail and jail.kind ~= 'ajal' and { kind = jail.kind == 'tig' and 'TIG' or 'Prison', left = jail.kind == 'tig' and (jail.remaining .. ' tâche(s)') or (math.ceil(jail.remaining / 60) .. ' min'), reason = jail.reason } or nil,
        wanted = wantedOf('person', lic), vehicles = vehicles, casier = casier, reports = reports }
end

OP.note = function(c, src, p)
    if not Biz.Allowed(c, 'records') then return nil, "Tu n'as pas accès aux dossiers." end
    local r, name = citizen(p.cid)
    if not r then return nil, name end
    local text = clean(p.text, 240)
    if #text < 3 then return nil, 'La note est trop courte.' end
    Biz.Record(c, r.license, name, 'note', text, 0)
    PB.Audit.Log('police', 'mdt.note', src, name, nil, text, nil)
    return { msg = 'Note ajoutée au dossier.' }
end

OP.vehicles = function(_, _, p)
    local q = clean(p.q, 8):upper()
    if #q < 2 then return nil, 'Saisis au moins 2 caractères de la plaque.' end
    local set, rows = wantedSet('vehicle'), {}
    -- une fausse plaque n'est pas résolue : elle ressort inconnue, c'est tout l'intérêt de la poser
    for _, r in ipairs(DB.q('SELECT v.plate, v.model, v.label, v.license, s.state, s.reason, o.firstname, o.lastname FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate LEFT JOIN pb_players o ON o.license = v.license WHERE v.plate LIKE ? ORDER BY v.plate LIMIT 30', { like(q) }) or {}) do
        rows[#rows + 1] = vehRow(r, set)
    end
    return { rows = rows, unknown = #rows == 0 and q or nil, unknownWanted = #rows == 0 and set[q] == true or nil }
end

OP.calls = function(c) return { rows = callList(c) } end
OP.call = function(c, src, p)
    local act, ok, msg = tostring(p.act or ''), nil, nil
    if act == 'claim' then ok, msg = J.ClaimCall(c, src, p.id)
    elseif act == 'close' then ok, msg = J.CloseCall(c, src, p.id)
    elseif act == 'gps' then ok, msg = Biz.ACT.dispatch_gps(c, src, { id = p.id })
    else return nil, 'Action inconnue.' end
    if not ok then return nil, msg end
    return { msg = msg }
end

OP.wanted = function() return { rows = wantedList(), canEdit = true } end
OP.wanted_add = function(c, src, p)
    if not Biz.Allowed(c, 'records') then return nil, "Tu n'as pas accès aux dossiers." end
    local reason = clean(p.reason, 160)
    if #reason < 3 then return nil, 'Indique le motif.' end
    local danger = math.max(1, math.min(3, math.floor(tonumber(p.danger) or 1)))
    local kind, ref, label
    if p.kind == 'vehicle' then
        kind, ref = 'vehicle', clean(p.plate, 8):upper()
        if not ref:match('^[%w ]+$') or #ref < 2 then return nil, 'Plaque invalide.' end
        local v = DB.one('SELECT model, label FROM pb_vehicles WHERE plate = ?', { ref })
        label = ref .. (v and (' · ' .. (v.label ~= '' and v.label or v.model)) or '')
    else
        local r, name = citizen(p.cid)
        if not r then return nil, name end
        kind, ref, label = 'person', r.license, name
    end
    if #wantedOf(kind, ref) > 0 then return nil, 'Un avis est déjà en cours.' end
    DB.insert('INSERT INTO pb_mdt_wanted (kind, ref, label, reason, danger, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { kind, ref, clean(label, 80), reason, danger, Biz.Display(src), now() })
    for _, u in ipairs(J.UnitsOf('police')) do G.Notify(u.src, { type = 'warn', title = 'Avis de recherche', text = label .. ' : ' .. reason, duration = 10000 }) end
    PB.Audit.Log('police', 'mdt.wanted', src, label, nil, reason, nil)
    return { msg = 'Avis de recherche diffusé.' }
end
OP.wanted_del = function(c, src, p)
    if not Biz.Allowed(c, 'records') then return nil, "Tu n'as pas accès aux dossiers." end
    local r = DB.one('SELECT id, label FROM pb_mdt_wanted WHERE id = ? AND closed_at = 0', { math.floor(tonumber(p.id) or 0) })
    if not r then return nil, 'Avis introuvable.' end
    DB.exec('UPDATE pb_mdt_wanted SET closed_at = ? WHERE id = ?', { now(), r.id })
    PB.Audit.Log('police', 'mdt.wanted.close', src, r.label, nil, nil, nil)
    return { msg = 'Avis levé.' }
end

local REPORT_KIND = { intervention = true, arrestation = true, enquete = true }
OP.reports = function(c, _, p)
    local q, rows = clean(p.q, 40):lower(), {}
    local sql = 'SELECT id, kind, title, by_name, cit_name, at FROM pb_mdt_reports'
    local args = {}
    if q ~= '' then sql = sql .. ' WHERE LOWER(title) LIKE ? OR LOWER(cit_name) LIKE ?' args = { like(q), like(q) } end
    args[#args + 1] = 60
    for _, r in ipairs(DB.q(sql .. ' ORDER BY id DESC LIMIT ?', args) or {}) do rows[#rows + 1] = { id = r.id, kind = r.kind, title = r.title, by = r.by_name, cit = r.cit_name, at = date(r.at) } end
    return { rows = rows }
end
OP.report = function(c, _, p)
    local r = DB.one('SELECT * FROM pb_mdt_reports WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    if not r then return nil, 'Rapport introuvable.' end
    return { id = r.id, kind = r.kind, title = r.title, body = r.body, by = r.by_name, cit = r.cit_name, cid = tok(r.cit_license), at = date(r.at), canDelete = c.boss or r.by_license == c.license }
end
OP.report_add = function(c, src, p)
    if not Biz.Allowed(c, 'records') then return nil, "Tu n'as pas accès aux dossiers." end
    local title, body = clean(p.title, 80), clean(p.body, 4000, true)
    if #title < 3 then return nil, 'Donne un titre au rapport.' end
    if #body < 10 then return nil, 'Le rapport est trop court.' end
    local lic, name = '', ''
    if p.cid then
        local r, n = citizen(p.cid)
        if not r then return nil, n end
        lic, name = r.license, n
    end
    local id = DB.insert('INSERT INTO pb_mdt_reports (kind, title, body, by_name, by_license, cit_license, cit_name, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        { REPORT_KIND[p.kind] and p.kind or 'intervention', title, body, Biz.Display(src), c.license, lic, clean(name, 64), now() })
    PB.Audit.Log('police', 'mdt.report', src, title, nil, nil, nil)
    return { msg = 'Rapport enregistré.', id = id }
end
OP.report_del = function(c, src, p)
    local r = DB.one('SELECT id, title, by_license FROM pb_mdt_reports WHERE id = ?', { math.floor(tonumber(p.id) or 0) })
    if not r then return nil, 'Rapport introuvable.' end
    if not (c.boss or r.by_license == c.license) then return nil, 'Seul son auteur ou le chef peut le supprimer.' end
    DB.exec('DELETE FROM pb_mdt_reports WHERE id = ?', { r.id })
    PB.Audit.Log('police', 'mdt.report.delete', src, r.title, nil, nil, nil)
    return { msg = 'Rapport supprimé.' }
end

OP.units = function() return { rows = unitList() } end
OP.status = function(_, src, p)
    local code = tostring(p.code or '')
    if not STATUS[code] then return nil, 'Statut inconnu.' end
    unitStatus[src] = code
    return { code = code }
end

-- la prison du staff est une sanction d'administration : ni listée ni libérable ici
OP.jail = function(c)
    local rows = {}
    for _, r in ipairs(DB.q("SELECT license, name, kind, remaining, reason, by_name, since FROM pb_jail WHERE kind <> 'ajal' ORDER BY since DESC LIMIT 100") or {}) do
        rows[#rows + 1] = { cid = tok(r.license), name = r.name, kind = r.kind == 'tig' and 'TIG' or 'Prison', left = r.kind == 'tig' and (r.remaining .. ' tâche(s)') or (math.ceil(r.remaining / 60) .. ' min'), reason = r.reason, by = r.by_name, at = date(r.since), online = isOnline(r.license) }
    end
    return { rows = rows, canRelease = Biz.Allowed(c, 'jail') }
end
OP.release = function(c, src, p)
    if not Biz.Allowed(c, 'jail') then return nil, "Tu n'as pas le droit de libérer un détenu." end
    local license = licOf[math.floor(tonumber(p.cid) or 0)]
    local r = license and DB.one('SELECT kind FROM pb_jail WHERE license = ?', { license })
    if not r or r.kind == 'ajal' then return nil, "Cette personne n'est pas détenue." end
    local ok, msg = J.ReleaseLicense(license, Biz.Display(src))
    if not ok then return nil, msg end
    return { msg = msg }
end

OP.penal = function()
    local rows = {}
    for _, f in ipairs(DB.q('SELECT code, label, amount, category FROM pb_fines ORDER BY category, label') or {}) do rows[#rows + 1] = { code = f.code, label = f.label, amount = G.Eco.Fine(f.amount), category = f.category } end
    return { rows = rows, maxJail = PB.Cfg.Get('justice', 'max_jail', 180), maxTig = PB.Cfg.Get('justice', 'tig_max', 30) }
end
M.OP = OP

-- Échanges avec le client ---------------------------------------------------------------------------------------------------------------
function M.Open(src)
    local c, err = access(src)
    if not c then return false, err end
    TriggerClientEvent('pb:g:mdt:open', src, PB.Json({ name = Biz.Display(src), grade = c.grade.label, biz = c.biz.label, color = c.biz.color, code = statusOf(src), statuses = STATUS,
        opacity = tonumber(cfg('opacity', 12)) or 12, canRecords = Biz.Allowed(c, 'records'), canJail = Biz.Allowed(c, 'jail') }))
    return true
end

local last = {}
AddEventHandler('playerDropped', function() last[source] = nil unitStatus[source] = nil end)
RegisterNetEvent('pb:g:mdt:open', function()
    local src = source
    local ok, err = M.Open(src)
    if not ok then G.Notify(src, { type = 'warn', title = 'Tablette de police', text = err }) end
end)
RegisterNetEvent('pb:g:mdt:req', function(rid, op, p)
    local src = source
    local res = { rid = tonumber(rid) or 0 }
    local t = GetGameTimer()
    local fn = type(op) == 'string' and OP[op] or nil
    if last[src] and t - last[src] < 80 then res.err = 'Doucement…'
    elseif not fn then res.err = 'Requête inconnue.'
    else
        last[src] = t
        local c, err = access(src)
        if not c then res.err, res.closed = err, true
        else
            local ok, data, why = pcall(fn, c, src, type(p) == 'table' and p or {})
            if not ok then print(('[pb_panel] tablette de police (%s) : %s'):format(op, tostring(data))) res.err = 'Erreur du serveur.'
            elseif data == nil then res.err = why or 'Impossible.'
            else res.data = data end
        end
    end
    TriggerClientEvent('pb:g:mdt:res', src, PB.Json(res))
end)

-- Entrée du menu F6
table.insert(Q.Common, function(src, c, add)
    if c.duty and access(src) then add({ id = 'mdt', label = 'Tablette de police (MDT)', desc = 'Citoyens, plaques, appels, avis de recherche, rapports.', icon = 'tablet' }) end
end)
Q.Handlers.mdt = function(src) return M.Open(src) end

-- Panel ----------------------------------------------------------------------------------------------------------------------------------
table.insert(Biz.ExtraSettings, Form.Cfg({ ns = 'mdt', id = 'settings', title = 'Tablette de police (MDT)', perm = 'biz.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Tablette active (/mdt et menu F6)', default = true },
    { k = 'opacity', type = 'number', label = 'Opacité du fond (%, 0 = totalement transparent)', default = 12, min = 0, max = 70 },
} }))

PB.SelfTest.Add('tablette de police', function(R)
    R.check(J ~= nil and J.Casier ~= nil and J.UnitsOf ~= nil, 'justice', "le module Justice n'est pas chargé : la tablette est inutilisable")
    R.check(Q ~= nil and Q.Common ~= nil, 'menu F6', "le menu F6 n'est pas chargé : la tablette ne s'ouvre qu'avec /mdt")
end)
