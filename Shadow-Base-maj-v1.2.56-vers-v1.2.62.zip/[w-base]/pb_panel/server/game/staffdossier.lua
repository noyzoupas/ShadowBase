-- Menu staff : retrouver n'importe quel joueur, connecté ou non, voir son dossier et agir dessus.
-- Le client ne reçoit que ce que son droit « staff.players » permet de voir ; chaque action revérifie son propre droit et le rang du joueur visé.
local G, DB, P = PB.G, PB.DB, PB.Perm
local S = G.Staff
if not (S and S.Def) then return end
local function now() return os.time() end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n or 120)) end
local function validLicense(l) return tostring(l or ''):match('^license:%x+#?%d*$') end
local function baseOf(l) return tostring(l):match('^[^#]+') end
local function fullName(r)
    local n = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    return n ~= '' and n or 'Sans personnage'
end
local function onlineOf(license)
    for src, pl in pairs(G.Players()) do if pl.license == license then return src end end
end
local function isBanned(license)
    return DB.one("SELECT id FROM pb_sanctions WHERE (license = ? OR license LIKE ?) AND kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) LIMIT 1", { license, baseOf(license) .. '%', now() }) ~= nil
end
-- Un membre du staff ne se sanctionne que par plus haut gradé que lui
local function outranksLicense(src, license)
    local g = P.GradeOf(baseOf(license)) or P.GradeOf(license)
    local def = g and P.Grade(g)
    return P.Level(src) > ((def and def.level) or 0)
end

S.Def('p_find', 'staff.players', { quiet = true, run = function(src, _, p)
    local q = tostring(p.q or ''):gsub('[%c%%_]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, 48)
    if #q < 2 then return false, 'Tape au moins 2 caractères.' end
    local rows, seen = {}, {}
    local function add(r)
        if seen[r.license] or #rows >= 25 then return end
        seen[r.license] = true
        local on = onlineOf(r.license)
        rows[#rows + 1] = { license = r.license, name = fullName(r), online = on, uid = G.Uid and G.Uid.OfLicense(baseOf(r.license)) or nil, seen = tonumber(r.last_seen) or 0,
            jailed = DB.one('SELECT license FROM pb_jail WHERE license = ?', { r.license }) ~= nil or nil, banned = isBanned(r.license) or nil }
    end
    local COLS = 'SELECT license, firstname, lastname, last_seen FROM pb_players '
    local uid = tonumber(q:match('^#?(%d+)$') or '')
    local lic = uid and G.Uid and G.Uid.LicenseOf(uid)
    if lic then for _, r in ipairs(DB.q(COLS .. 'WHERE license = ? OR license LIKE ? LIMIT 5', { lic, lic .. '#%' }) or {}) do add(r) end end
    -- connectés : aussi par leur nom FiveM
    local low = q:lower()
    for s, pl in pairs(G.Players()) do
        if tostring(GetPlayerName(s) or ''):lower():find(low, 1, true) then add(DB.one(COLS .. 'WHERE license = ?', { pl.license }) or { license = pl.license, firstname = GetPlayerName(s) }) end
    end
    local like = '%' .. q .. '%'
    for _, r in ipairs(DB.q(COLS .. "WHERE firstname LIKE ? OR lastname LIKE ? OR license LIKE ? OR (firstname LIKE ? AND lastname LIKE ?) OR CONCAT(firstname, ' ', lastname) LIKE ? ORDER BY last_seen DESC LIMIT 25",
        { like, like, like, '%' .. (q:match('^(%S+)') or '') .. '%', '%' .. (q:match('(%S+)$') or '') .. '%', like }) or {}) do add(r) end
    TriggerClientEvent('pb:g:staff:find', src, PB.Json({ q = q, rows = rows }))
    return true
end })

-- Le dossier : identité, argent, emploi, groupe, véhicules, peine, bannissement, sanctions et notes (tous les personnages du compte)
local function card(license)
    local r = DB.one('SELECT license, firstname, lastname, cash, bank, dead, last_seen FROM pb_players WHERE license = ?', { license })
    if not r then return nil end
    local base, on = baseOf(license), onlineOf(license)
    local c = { license = license, name = fullName(r), online = on, uid = G.Uid and G.Uid.OfLicense(base) or nil, seen = tonumber(r.last_seen) or 0, cash = tonumber(r.cash) or 0, bank = tonumber(r.bank) or 0, dead = PB.ToBool(r.dead) or nil }
    if on then local live = G.Get(on) if live then c.cash, c.bank = tonumber(live.row.cash) or 0, tonumber(live.row.bank) or 0 end c.ata = (G.Ata and G.Ata.Left(on)) or 0 end
    local m = G.Biz and G.Biz.MemberOf(license)
    if m then
        local b = G.Biz.Get(m.biz_id)
        c.job = b and b.label or tostring(m.biz_id)
    end
    local gg = DB.one('SELECT gang FROM pb_tag_gang WHERE license = ?', { license })
    if gg then
        local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[gg.gang]
        c.gang = d and (d.label or d.name) or gg.gang
    end
    c.cars = {}
    for _, v in ipairs(DB.q('SELECT plate, model, label FROM pb_vehicles WHERE license = ? LIMIT 12', { license }) or {}) do c.cars[#c.cars + 1] = { plate = v.plate, label = (v.label ~= '' and v.label) or v.model } end
    local j = DB.one('SELECT kind, remaining, reason, by_name FROM pb_jail WHERE license = ?', { license })
    if j then
        c.jail = { kind = j.kind, remaining = tonumber(j.remaining) or 0, reason = j.reason, by = j.by_name }
        local live = on and S.JailInfo(on)
        if live then c.jail.remaining = live.remaining end
    end
    local b = DB.one("SELECT id, reason, by_name, expires FROM pb_sanctions WHERE (license = ? OR license LIKE ?) AND kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) ORDER BY id DESC LIMIT 1", { license, base .. '%', now() })
    if b then c.ban = { id = b.id, reason = b.reason, by = b.by_name, expires = tonumber(b.expires) or 0 } end
    c.sanctions = {}
    for _, s in ipairs(DB.q('SELECT kind, reason, by_name, created FROM pb_sanctions WHERE license = ? OR license LIKE ? ORDER BY id DESC LIMIT 12', { license, base .. '%' }) or {}) do
        c.sanctions[#c.sanctions + 1] = { kind = s.kind, reason = s.reason, by = s.by_name, at = tonumber(s.created) or 0 }
    end
    c.notes = {}
    for _, n in ipairs(DB.q('SELECT text, by_name, created FROM pb_staff_notes WHERE license = ? ORDER BY id DESC LIMIT 8', { license }) or {}) do
        c.notes[#c.notes + 1] = { text = n.text, by = n.by_name, at = tonumber(n.created) or 0 }
    end
    return c
end
local function sendCard(src, license)
    local c = card(license)
    if not c then return false end
    TriggerClientEvent('pb:g:staff:card', src, PB.Json(c))
    return true
end
S.Def('p_card', 'staff.players', { quiet = true, run = function(src, _, p)
    local license = validLicense(p.license)
    if not license or not sendCard(src, license) then return false, 'Joueur introuvable.' end
    return true
end })

-- Cible d'une action : le joueur existe, il est absent, et le rang est respecté. Connecté, on passe par sa fiche en direct.
local function offTarget(src, p)
    local license = validLicense(p.license)
    local r = license and DB.one('SELECT license, firstname, lastname FROM pb_players WHERE license = ?', { license })
    if not r then return nil, 'Joueur introuvable.' end
    if onlineOf(license) then return nil, 'Ce joueur est connecté : utilise sa fiche dans la liste des joueurs.' end
    return r
end
S.Def('off_warn', 'staff.warn', { run = function(src, _, p)
    local r, e = offTarget(src, p)
    if not r then return false, e end
    if not outranksLicense(src, r.license) then return false, 'Ce joueur a un rang égal ou supérieur au tien.' end
    local why = clean(p.reason, 120)
    if why == '' then return false, 'Motif obligatoire.' end
    S.AddSanction('warn', r.license, fullName(r), why, src, 0, { r.license })
    sendCard(src, r.license)
    return true, 'Avertissement enregistré dans le dossier de ' .. fullName(r) .. '.'
end, log = true })
S.Def('off_jail', 'staff.jail', { run = function(src, _, p)
    local r, e = offTarget(src, p)
    if not r then return false, e end
    if not outranksLicense(src, r.license) then return false, 'Ce joueur a un rang égal ou supérieur au tien.' end
    if not G.Justice or not G.Justice.SentenceLicense then return false, 'La justice est indisponible.' end
    local ok, msg = G.Justice.SentenceLicense(PB.Actor(src).name, r.license, fullName(r), p.minutes, p.reason)
    if ok then sendCard(src, r.license) end
    return ok, msg
end, log = true })
S.Def('off_money', 'staff.money', { run = function(src, _, p)
    local r, e = offTarget(src, p)
    if not r then return false, e end
    local field = p.field == 'bank' and 'bank' or 'cash'
    local n = math.floor(tonumber(p.amount) or 0)
    if n == 0 or math.abs(n) > (tonumber(PB.Cfg.Get('staff', 'money_max', 1000000)) or 1000000) then return false, 'Montant invalide (0 ou trop grand).' end
    local cur = DB.one(('SELECT %s AS v FROM pb_players WHERE license = ?'):format(field), { r.license })
    DB.exec(('UPDATE pb_players SET %s = ? WHERE license = ?'):format(field), { math.max(0, (tonumber(cur and cur.v) or 0) + n), r.license })
    PB.Audit.Log('staff', 'off_money', src, fullName(r) .. ' ' .. r.license, nil, nil, { field = field, amount = n })
    sendCard(src, r.license)
    return true, ('%s, %s : %+d $.'):format(fullName(r), field == 'bank' and 'banque' or 'espèces', n)
end, log = true })
S.Def('off_note', 'staff.notes', { run = function(src, _, p)
    local license = validLicense(p.license)
    local r = license and DB.one('SELECT license, firstname, lastname FROM pb_players WHERE license = ?', { license })
    if not r then return false, 'Joueur introuvable.' end
    local text = clean(p.text, 250)
    if text == '' then return false, 'Note vide.' end
    DB.insert('INSERT INTO pb_staff_notes (license, name, text, by_name, created) VALUES (?, ?, ?, ?, ?)', { r.license, clean(fullName(r), 64), text, PB.Actor(src).name:sub(1, 64), now() })
    sendCard(src, r.license)
    return true, 'Note enregistrée.'
end, log = true })
