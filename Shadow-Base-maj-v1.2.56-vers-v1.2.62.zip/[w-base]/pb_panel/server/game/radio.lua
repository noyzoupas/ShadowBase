-- Fréquences radio réservées : des plages de canaux sont réservées à un métier (police, secours, mécanos…). Les autres joueurs ne peuvent
-- pas les rejoindre. Le contrôle passe par pma-voice (export addChannelCheck, côté serveur) : sans pma-voice, rien n'est appliqué et
-- le panel l'indique. Le staff en service peut passer outre (réglable). Tout le reste (canaux libres) reste ouvert à tous.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G = PB.G

P.Register('radio.edit', 'Régler les fréquences radio réservées', 'radio', true)
PB.Cfg.Define('radio', { enabled = false, ranges = {}, need_duty = true, staff_bypass = true, message = "Cette fréquence est réservée." })
local function cfg(k, d) return PB.Cfg.Get('radio', k, d) end
local R = {}
G.Radio = R

-- Une plage : « libellé|de|à|qui » ; « qui » = identifiants d'entreprise ou types (police, ems, garage…) séparés par des virgules.
function R.Ranges()
    local out = {}
    for _, line in ipairs(cfg('ranges', {}) or {}) do
        local label, a, b, who = tostring(line):match('^([^|]+)|(%d+)|(%d+)|([%w_,%-]+)$')
        a, b = tonumber(a), tonumber(b)
        if label and a and b and a <= b and b <= 99999 then
            local set = {}
            for w in who:gmatch('[^,]+') do set[w] = true end
            out[#out + 1] = { label = label, from = a, to = b, who = set, whoText = who }
        end
    end
    return out
end
function R.ReservedFor(channel)
    channel = math.floor(tonumber(channel) or 0)
    for _, r in ipairs(R.Ranges()) do if channel >= r.from and channel <= r.to then return r end end
end
-- true si `src` peut rejoindre ce canal
function R.Allowed(src, channel)
    if cfg('enabled', false) ~= true then return true end
    local r = R.ReservedFor(channel)
    if not r then return true end
    if cfg('staff_bypass', true) and G.Staff and G.Staff.OnDuty and G.Staff.OnDuty(src) then return true end
    local c = G.Biz and G.Biz.Ctx and G.Biz.Ctx(src)
    if not c then return false end
    if cfg('need_duty', true) and not c.duty then return false end
    return (r.who[c.biz.id] or r.who[c.biz.kind or ''] or false) == true
end

-- Branchement sur pma-voice
local checked = {}      -- canaux déjà enregistrés
function R.Hook()
    if GetResourceState and GetResourceState('pma-voice') ~= 'started' then return false, 'pma-voice absent' end
    local ok = pcall(function()
        local api = exports['pma-voice']
        for _, r in ipairs(R.Ranges()) do
            for ch = r.from, math.min(r.to, r.from + 999) do
                if not checked[ch] then
                    checked[ch] = true
                    api:addChannelCheck(ch, function(source) return R.Allowed(source, ch) end)
                end
            end
        end
    end)
    return ok, ok and nil or 'pma-voice ne propose pas addChannelCheck (mets-le à jour)'
end
R.hooked = nil
function R.Status()
    if cfg('enabled', false) ~= true then return 'off', 'Désactivé.' end
    if not (GetResourceState and GetResourceState('pma-voice') == 'started') then return 'off', 'pma-voice ne tourne pas : aucune fréquence n\'est protégée.' end
    local ok, why = R.Hook()
    if not ok then return 'partial', why end
    return 'ok', 'Les plages réservées sont contrôlées par pma-voice.'
end
exports('CanUseRadio', function(src, channel) return R.Allowed(tonumber(src), channel) end)

PB.OnReady(function() CreateThread(function() Wait(2000) pcall(R.Hook) end) end)
AddEventHandler('onResourceStart', function(res) if res == 'pma-voice' then SetTimeout(1500, function() pcall(R.Hook) end) end end)
PB.Cfg.OnChange('radio', function() pcall(R.Hook) end)

-- Poste radio (touche F4) ------------------------------------------------------------------------------------------------------------------------------
-- Le joueur choisit une fréquence dans l'interface ; le serveur vérifie (entier, plage, métier, objet « radio ») puis place le joueur
-- avec l'export serveur de pma-voice. Toutes les 3 s, un joueur entré sur une fréquence interdite par l'évènement brut de pma-voice
-- (ou qui a perdu son métier / son service / son poste) en est retiré.
PB.Cfg.Define('radio', { ui = true, key = 'F4', require_item = true, max_channel = 999, leave_on_death = true })
local function voiceUp() return GetResourceState and GetResourceState('pma-voice') == 'started' end
local function setRadio(src, ch) pcall(function() exports['pma-voice']:setPlayerRadio(src, ch) end) end
local function radioUsable(src)
    local p = G.Get and G.Get(src)
    if not p or not PB.ToBool(p.row.created) then return false end
    if cfg('leave_on_death', true) and PB.ToBool(p.row.dead) then return false end
    return not (G.IsCuffed and G.IsCuffed(src))
end
local function hasRadio(src)
    if not cfg('require_item', true) then return true end
    local o = G.Inv and G.Inv.PlayerOwner(src)
    return o ~= nil and G.Inv.Count(o, 'radio') > 0
end
-- Pourquoi `src` ne peut pas être sur `ch` (nil = il peut)
function R.Refuse(src, ch)
    ch = tonumber(ch)
    if not ch or ch ~= math.floor(ch) or ch < 1 or ch > (tonumber(cfg('max_channel', 999)) or 999) then return ('Fréquence invalide (1 à %d).'):format(tonumber(cfg('max_channel', 999)) or 999) end
    if not radioUsable(src) then return 'Impossible de se servir de la radio maintenant.' end
    if not hasRadio(src) then return "Tu n'as pas de radio sur toi. Il s'en vend dans les supérettes LTD." end
    if not R.Allowed(src, ch) then return cfg('message', 'Cette fréquence est réservée.') end
end
R.on = {}   -- joueur -> fréquence choisie par l'interface

local function view(src)
    local list = {}
    for _, r in ipairs(R.Ranges()) do list[#list + 1] = { label = r.label, from = r.from, to = r.to, ok = R.Allowed(src, r.from) } end
    local ch = R.on[src] or 0
    local r = ch > 0 and R.ReservedFor(ch)
    return { ch = ch, label = r and r.label or '', max = tonumber(cfg('max_channel', 999)) or 999, ranges = cfg('enabled', false) == true and list or {}, voice = voiceUp() }
end
local function send(src, ev, extra)
    local d = view(src)
    d.ev = ev
    for k, v in pairs(extra or {}) do d[k] = v end
    TriggerClientEvent('pb:g:radio', src, PB.Json(d))
end
function R.Join(src, ch)
    if cfg('ui', true) == false then return false, 'La radio est désactivée.' end
    if not voiceUp() then return false, 'Radio indisponible : la voix (pma-voice) ne tourne pas.' end
    local why = R.Refuse(src, ch)
    if why then return false, why end
    ch = math.floor(tonumber(ch))
    R.on[src] = ch
    setRadio(src, ch)
    return true
end
function R.Leave(src)
    if R.on[src] then R.on[src] = nil setRadio(src, 0) end
end

local rlast = {}
local function rthrottle(src) local t = GetGameTimer() if rlast[src] and t - rlast[src] < 400 then return false end rlast[src] = t return true end
RegisterNetEvent('pb:g:radio:open', function()
    local src = source
    if cfg('ui', true) == false or not rthrottle(src) then return end
    if not radioUsable(src) then return end
    if not hasRadio(src) then G.Notify(src, { type = 'error', title = 'Radio', text = "Tu n'as pas de radio sur toi. Il s'en vend dans les supérettes LTD." }) return end
    send(src, 'open')
end)
RegisterNetEvent('pb:g:radio:join', function(ch)
    local src = source
    if not rthrottle(src) then return end
    local ok, why = R.Join(src, ch)
    send(src, 'state', { ok = ok, msg = ok and nil or why })
end)
RegisterNetEvent('pb:g:radio:leave', function()
    local src = source
    R.Leave(src)
    send(src, 'state', { ok = true })
end)
AddEventHandler('playerDropped', function() R.on[source] = nil rlast[source] = nil end)
-- L'objet radio : acheté au LTD ; l'utiliser depuis l'inventaire ouvre le poste. L'obligation est activée une fois (réglable ensuite).
PB.OnReady(function()
    if G.Inv and G.Inv.EnsureItem then
        G.Inv.EnsureItem({ name = 'radio', label = 'Radio', weight = 300, stack = 1, kind = 'tool', usable = true, description = 'Poste radio : permet de rejoindre une fréquence (F4).' })
        G.Inv.RegisterUsable('radio', function(src) send(src, 'open') return true, nil, true end)
    end
    if PB.Cfg.Get('radio', 'item_v210', false) ~= true then
        PB.Cfg.Set('radio', 'require_item', true, nil, 'La radio s\'achète au LTD')
        PB.Cfg.Set('radio', 'item_v210', true, nil, 'Migration')
    end
end)

-- Surveillance : fréquence lue dans l'état pma-voice du joueur
function R.Tick()
    if not voiceUp() or not Player then return end
    for id in pairs(G.Players and G.Players() or {}) do
        local ok, ch = pcall(function() return Player(id).state.radioChannel end)
        ch = ok and tonumber(ch) or 0
        if ch ~= 0 then
            local why = R.Refuse(id, ch)
            if why then
                setRadio(id, 0)
                local was = R.on[id]
                R.on[id] = nil
                if was ~= ch then PB.Audit.Log('anticheat', 'radio_channel', 'système', GetPlayerName(id) or tostring(id), nil, nil, { canal = ch }) end
                G.Notify(id, { type = 'warn', title = 'Radio', text = 'Tu as été retiré de la fréquence ' .. ch .. ' : ' .. why })
                TriggerClientEvent('pb:g:radio', id, PB.Json({ ev = 'state', ch = 0, label = '', kicked = true }))
            else
                R.on[id] = ch
            end
        elseif R.on[id] then R.on[id] = nil end
    end
end
CreateThread(function() while true do Wait(3000) pcall(R.Tick) end end)

local form = Form.Cfg({ ns = 'radio', id = 'ranges', title = 'Fréquences réservées', perm = 'radio.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Fréquences réservées actives', default = false, hint = 'Nécessite pma-voice. Désactivé : toutes les fréquences restent libres.' },
    { k = 'need_duty', type = 'toggle', label = 'Exiger d\'être en service', default = true },
    { k = 'staff_bypass', type = 'toggle', label = 'Le staff en service peut tout rejoindre', default = true },
    { k = 'ranges', type = 'list', label = 'Plages réservées : libellé|de|à|qui (ex. Police|1|10|police)', default = {}, maxitems = 30, maxlen = 90, pattern = '^[^|]+|%d+|%d+|[%w_,%-]+$', wide = true,
      hint = "« qui » : identifiants d'entreprise ou types (police, ems, garage), séparés par des virgules. Exemples : Police|1|10|police · Secours|11|20|ems · Mécanos|21|30|garage,bennys." },
} })

local postForm = Form.Cfg({ ns = 'radio', id = 'post', title = 'Poste radio des joueurs', perm = 'radio.edit', cols = 2, fields = {
    { k = 'ui', type = 'toggle', label = 'Poste radio (interface en jeu)', default = true },
    { k = 'key', type = 'text', label = 'Touche d\'ouverture', default = 'F4', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
    { k = 'require_item', type = 'toggle', label = 'Exiger l\'objet « Radio » dans l\'inventaire (vendu au LTD)', default = true },
    { k = 'leave_on_death', type = 'toggle', label = 'Couper la radio quand le joueur est à terre', default = true },
    { k = 'max_channel', type = 'number', label = 'Fréquence la plus haute', default = 999, min = 10, max = 9999 },
} })

PB.Module({
    id = 'radio', label = 'Radio', icon = 'mic', group = 'Serveur', order = 80, perm = 'radio.edit', hint = 'Poste radio (F4) et fréquences réservées aux métiers',
    caps = function()
        local st, why = R.Status()
        return PB.Capsify({
            { 'Plages réservées par métier', st, why },
            { 'Canaux libres pour tout le monde', 'ok', 'Les canaux hors plages restent ouverts à tous.' },
            { 'Prise en charge de pma-voice', GetResourceState and GetResourceState('pma-voice') == 'started' and 'partial' or 'off', "Utilise l'export serveur addChannelCheck de pma-voice. Non testé sur ton serveur : vérifie en rejoignant une fréquence réservée sans le métier." },
            { 'Poste radio en jeu (F4)', cfg('ui', true) ~= false and 'ok' or 'off', "Choix de la fréquence, volume, raccourcis vers les canaux de ton métier. Le serveur valide chaque fréquence et retire toutes les 3 s un joueur entré sur une fréquence interdite." },
            { 'Autres systèmes radio (saltychat, tokovoip…)', 'off', "Non pris en charge : seul pma-voice est branché." },
        })
    end,
    doc = "## Radio\nLes joueurs ouvrent leur **poste radio** avec **F4** : fréquence, volume, canaux de leur métier. On parle avec la touche radio de pma-voice.\n\nRéserve des **plages de fréquences** à des métiers : par exemple `Police|1|10|police` rend les canaux 1 à 10 accessibles aux seuls policiers en service. Les autres joueurs sont refusés par pma-voice. Les canaux hors plages restent libres.\n\n### Pour développeurs\n`exports.pb_panel:CanUseRadio(source, canal)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'ranges', label = 'Fréquences', icon = 'mic', build = function()
                local rows = {}
                for _, r in ipairs(R.Ranges()) do rows[#rows + 1] = { label = r.label, range = r.from .. ' – ' .. r.to, who = r.whoText } end
                return { postForm(ctx), form(ctx), B.table({ id = 'rr', title = 'Plages actives', columns = { { k = 'label', label = 'Nom' }, { k = 'range', label = 'Canaux' }, { k = 'who', label = 'Réservé à' } }, rows = rows, empty = 'Aucune plage réservée.' }) }
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'radio', title = 'Poste radio vu par le joueur (F4)', cfg = {} } } end },
        } }
    end,
})

PB.SelfTest.Add('radio', function(R_)
    for _, line in ipairs(cfg('ranges', {}) or {}) do R_.check(tostring(line):match('^([^|]+)|(%d+)|(%d+)|([%w_,%-]+)$') ~= nil, 'plage radio « ' .. tostring(line) .. ' »', 'format libellé|de|à|qui') end
end)
