-- Personnage en pied : gardé en mémoire (jamais en base), donné seulement aux joueurs proches.
local G = PBG
local Body, last = {}, {}
RegisterNetEvent('pb:g:body:set', function(data)
    local src = source
    if type(data) ~= 'string' or #data > 90000 or data:sub(1, 23) ~= 'data:image/webp;base64,' or not data:match('^data:image/webp;base64,[A-Za-z0-9+/=]+$') then return end
    local t = GetGameTimer()
    if last[src] and t - last[src] < 10000 then return end
    last[src] = t
    Body[src] = data
end)
RegisterNetEvent('pb:g:body:need', function(ids)
    local src = source
    if type(ids) ~= 'table' then return end
    local me = GetEntityCoords(GetPlayerPed(src))
    local out = {}
    for i = 1, math.min(#ids, 12) do
        local id = math.floor(tonumber(ids[i]) or 0)
        if Body[id] and #(GetEntityCoords(GetPlayerPed(id)) - me) < 25.0 then out[tostring(id)] = Body[id] end
    end
    TriggerClientEvent('pb:g:body:data', src, out)
end)
AddEventHandler('playerDropped', function() Body[source] = nil last[source] = nil end)
