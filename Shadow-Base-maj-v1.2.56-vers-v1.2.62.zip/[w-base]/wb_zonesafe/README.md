# wb_zonesafe — zones safe (Shadow Base)

Zones où l'on ne peut ni tirer, ni frapper, ni être blessé.

- Tracé : **F10 › Builder › Zones safe › Tracer une zone** : Entrée à chaque coin, Y pour terminer (noclip possible).
- Ou zone ronde, debout au centre : petite (25 m), moyenne (50 m), grande (100 m) ou rayon libre.
- Les zones se voient sur la grande carte seulement ; une notification signale l'entrée et la sortie.
- « Supprimer la zone où je suis » enlève la zone dans laquelle tu te trouves.
- Réglages (panel › Zones safe) : invincibilité, tirs, coups, arme rangée à l'entrée, staff en service non limité, blips, messages.
- Installation : `ensure wb_zonesafe` après `pb_panel`.
