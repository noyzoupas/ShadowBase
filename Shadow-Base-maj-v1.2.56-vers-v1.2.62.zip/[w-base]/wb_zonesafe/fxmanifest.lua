fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_zonesafe'
description 'Shadow Base — zones safe : zones posées au Builder (F10 › Builder › Zones safe) où l\'on ne peut ni tirer, ni frapper, ni être blessé. Extension de pb_panel.'
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

server_script 'server.lua'
client_script 'client.lua'
