/* Tablette de l'atelier d'armes : recettes, matériaux et où les trouver. Le serveur vérifie tout ; ici on affiche et on demande.
   Tout texte reçu est inséré avec textContent ; les images sont les dessins de Shadow Base (pb_panel/web/img/items). */
'use strict';
const $ = (id) => document.getElementById(id);
const h = (tag, attrs, ...kids) => {
  const e = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v == null) return; if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); });
  kids.flat().forEach((c) => { if (c != null) e.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c))); });
  return e;
};
const post = (name, d) => { if (typeof GetParentResourceName !== 'function') { window.__posts = (window.__posts || []).concat([[name, d]]); return; } fetch('https://' + GetParentResourceName() + '/' + name, { method: 'POST', body: JSON.stringify(d || {}) }).catch(() => {}); };
let D = null, page = 'weapons', sel = null, qty = 1;

/* Icônes maison : traits blancs unis, même style partout (pas les images de l'inventaire, trop chargées pour une tablette). */
const SHAPES = {
  pistol: '<rect class="f" x="4" y="13" width="38" height="8.5" rx="2.2"/><path class="f" d="M10 21.5h13l-3 17h-8.4z"/><path d="M28 21.5v4.5c0 1.5-1 2.5-2.5 2.5H22"/><path class="d" d="M9 17.2h22"/><path d="M36 13v-2h4v2"/>',
  smg: '<rect class="f" x="3" y="14" width="34" height="8" rx="2"/><path class="f" d="M12 22h10l-1 6h-3l-1 11h-6.5l2-11z"/><path class="f" d="M37 15h4l4 2.5V22h-8z"/><path d="M27 22v4h-4"/><path class="d" d="M8 18h24"/>',
  shotgun: '<rect class="f" x="2" y="16" width="32" height="4.5" rx="2"/><rect x="2" y="22" width="24" height="3.2" rx="1.6"/><path class="f" d="M30 15h6l9 4 2 10h-6.5l-3-4H30z"/><path d="M22 20.5h6"/><path class="d" d="M8 18.2h22"/>',
  rifle: '<rect class="f" x="2" y="19" width="30" height="5" rx="2"/><path class="f" d="M30 17h8l8 3 1 10h-6l-2-4h-9z"/><path class="f" d="M22 24h6l-1 5h-2l-1 9h-5.5l1.5-9z"/><path d="M13 19v-3h8v3M8 16h4"/><path class="d" d="M6 21.5h22"/>',
  scrap: '<path class="d f" d="M7 36l5-13 11 4-2 11z"/><path class="d f" d="M23 38l3-17 12 4 4 13z"/><path d="M7 36l5-13 11 4-2 11zM23 38l3-17 12 4 4 13zM13 22l10-9 6 6"/>',
  steel: '<rect x="7" y="13" width="34" height="22" rx="4"/><circle class="f" cx="13" cy="19" r="1.7"/><circle class="f" cx="35" cy="19" r="1.7"/><circle class="f" cx="13" cy="29" r="1.7"/><circle class="f" cx="35" cy="29" r="1.7"/><path d="M19 24h10" class="d"/>',
  spring: '<path d="M4 24h7l3-11 6 22 6-22 6 22 3-11h9"/>',
  barrel: '<rect x="4" y="20" width="40" height="8" rx="3"/><path d="M4 24h7M40 20v8" class="d"/><circle cx="43" cy="24" r="1.4" class="f"/>',
  barrelS: '<rect x="12" y="20" width="26" height="8" rx="3"/><path d="M12 24h7" class="d"/><circle cx="37" cy="24" r="1.4" class="f"/>',
  breech: '<rect x="8" y="14" width="32" height="20" rx="4"/><path d="M8 22h32M18 14v8"/><rect x="24" y="26" width="10" height="4" rx="1.5" class="f"/>',
  frame: '<path d="M6 16h30l4 4v6H28l-3 10h-8l3-10H6z"/><path d="M12 16v-4h12v4" class="d"/><circle cx="30" cy="22" r="1.6" class="f"/>',
  stock: '<path d="M6 14h22l6 4h8v16H30l-6-6H6z"/><path d="M14 20h8" class="d"/>',
  plan: '<path d="M12 6h18l8 8v28H12z"/><path d="M30 6v8h8M17 22h16M17 28h16M17 34h10"/>',
  coin: '<circle cx="24" cy="24" r="13"/><path d="M24 17v14M20 20.5c0-2 7-2 7 0s-7 2-7 4 7 2 7 0"/>',
  box: '<path d="M8 15l16-8 16 8v18l-16 8-16-8z"/><path d="M8 15l16 8 16-8M24 23v18" class="d"/>',
};
const KEY = [[/^_?pistol|^weapon_(pistol|combatpistol|snspistol|heavypistol|revolver|vintagepistol)/, 'pistol'], [/smg|microsmg|machinepistol/, 'smg'], [/shotgun|pump/, 'shotgun'], [/rifle|carbine|assault/, 'rifle'],
  [/^plan/, 'plan'], [/ferraille|scrap/, 'scrap'], [/acier|steel/, 'steel'], [/ressort|spring/, 'spring'], [/canon_court/, 'barrelS'], [/canon/, 'barrel'], [/culasse/, 'breech'], [/carcasse|frame/, 'frame'], [/crosse|stock/, 'stock']];
const img = (icon) => {
  const k = String(icon || ''); let shape = 'box';
  for (const [re, name] of KEY) if (re.test(k)) { shape = name; break; }
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 48 48'); s.setAttribute('class', 'ic'); s.innerHTML = SHAPES[shape]; return s;
};
const ICONS = {
  weapons: '<path d="M3 9h11l2 2h5v3h-3l-1 3h-3l-1-3H8l-1 4H4l1-4H3z"/>',
  parts: '<circle cx="12" cy="12" r="3.2"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
  scrap: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
  sources: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.4"/>',
  market: '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h7M9 17h7"/>',
};
const svg = (k) => { const e = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); e.setAttribute('viewBox', '0 0 24 24'); e.innerHTML = ICONS[k] || ICONS.parts; return e; };
const ORDER = ['weapons', 'parts', 'scrap'];
const pages = () => (D.cats || []).slice().sort((a, b) => ORDER.indexOf(a.id) - ORDER.indexOf(b.id))
  .map((c) => ({ id: c.id, label: c.label, desc: c.desc, n: (D.recipes || []).filter((r) => r.cat === c.id).length }))
  .concat([{ id: 'sources', label: 'Où trouver', desc: 'La ferraille se récupère sur place, ou s\'achète au marché noir de l\'atelier (argent sale d\'abord).' },
    { id: 'market', label: 'Plans', desc: 'Chaque famille d\'armes demande un plan. Un plan ne se consomme jamais : on l\'achète une seule fois.' }]);
const state = (r) => {
  if (!r.lvOk) return ['Niveau ' + r.level, 'bad'];
  if (r.plan && !r.planOk) return ['Plan manquant', 'bad'];
  return r.can ? ['Prêt', 'ok'] : ['Matériaux', ''];
};
const rawOf = (item) => (D.raw || []).find((x) => x.item === item);
const recipeFor = (item) => (D.recipes || []).find((r) => r.item === item);

function scale() { document.documentElement.style.setProperty('--k', String(Math.min(1.2, Math.min(window.innerWidth / 1260, window.innerHeight / 780)))); }
window.addEventListener('resize', scale);
function tick() { const d = new Date(); $('clock').textContent = d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
setInterval(tick, 10000);

function draw() {
  if (!D) return;
  $('spot').textContent = D.label || 'Atelier';
  $('lvl').textContent = 'Armurier niv. ' + D.level;
  $('xp').textContent = D.next ? D.xp + ' / ' + D.next + ' XP' : D.xp + ' XP';
  $('xpbar').style.width = (D.next ? Math.min(100, D.xp / D.next * 100) : 100) + '%';
  const nav = $('nav'); nav.textContent = '';
  const list = pages();
  list.forEach((p) => nav.appendChild(h('button', { class: 'nv' + (p.id === page ? ' on' : ''), onclick: () => { page = p.id; sel = null; qty = 1; draw(); } },
    svg(p.id), p.label, p.n ? h('em', null, p.n) : null)));
  const cur = list.find((p) => p.id === page) || list[0];
  $('intro').textContent = cur.desc || '';
  const body = $('body'); body.textContent = '';
  if (page === 'sources') viewSources(body); else if (page === 'market') viewPlans(body); else viewRecipes(body);
  drawDetail();
}

function viewRecipes(body) {
  const rec = (D.recipes || []).filter((r) => r.cat === page);
  if (!sel || sel.cat !== page) sel = rec.find((r) => r.can) || rec[0] || null;
  rec.forEach((r) => {
    const s = state(r);
    const have = r.needs.filter((x) => x.have >= x.need).length;
    body.appendChild(h('button', { class: 'card' + (sel && sel.id === r.id ? ' on' : '') + (r.lvOk ? '' : ' dim'), onclick: () => { sel = r; qty = 1; draw(); } },
      h('div', { class: 'pic' }, img(r.icon)),
      h('span', { class: 'tag ' + s[1] }, s[0]),
      h('b', null, r.label),
      h('small', null, r.needs.length ? have + ' / ' + r.needs.length + ' matériaux' : '')));
  });
  if (!rec.length) body.appendChild(h('p', { class: 'wide' }, 'Rien à faire ici pour le moment.'));
}

function need(ok, thumb, label, right, ratio, action) {
  const e = h('div', { class: 'need ' + (ok ? 'yes' : 'no') }, h('div', { class: 'th' }, thumb), h('span', null, label), h('em', null, right));
  if (ratio != null) e.appendChild(h('div', { class: 'mb' }, h('i', { style: 'width:' + Math.round(Math.min(1, ratio) * 100) + '%' })));
  if (action) e.appendChild(h('button', { class: 'act', onclick: action[1] }, action[0]));
  return e;
}
function drawDetail() {
  const d = $('detail'); d.textContent = '';
  if (page === 'sources' || page === 'market' || !sel) {
    d.appendChild(h('h2', null, 'Comment ça marche'));
    d.appendChild(h('ul', { class: 'steps' },
      h('li', null, h('b', null, '1'), h('div', null, 'Récupère de la ferraille', h('small', null, 'Sur les tas indiqués dans « Où trouver », ou achète-la ici.'))),
      h('li', null, h('b', null, '2'), h('div', null, 'Fabrique des pièces', h('small', null, 'Pièces d\'acier, ressorts, canons, culasses… dans l\'onglet Pièces.'))),
      h('li', null, h('b', null, '3'), h('div', null, 'Assemble ton arme', h('small', null, 'Il faut le plan de la famille d\'armes (onglet Plans) et le bon niveau.'))),
      h('li', null, h('b', null, '+'), h('div', null, 'Les munitions', h('small', null, 'Elles ne se fabriquent pas : achète-les à l\'Ammu-Nation.')))));
    return;
  }
  const r = sel;
  d.appendChild(h('div', { class: 'hero' }, img(r.icon)));
  d.appendChild(h('h2', null, r.label));
  d.appendChild(h('div', { class: 'facts' }, h('span', null, r.time + ' s'), r.fail > 0 ? h('span', null, r.fail + ' % de risque de raté') : null, r.qty > 1 ? h('span', null, 'Donne × ' + r.qty) : null));
  d.appendChild(h('div', { class: 'sec' }, 'Ce qu\'il te faut'));
  r.needs.forEach((x) => {
    const n = x.need * qty, ok = x.have >= n;
    const made = recipeFor(x.item), raw = rawOf(x.item);
    d.appendChild(need(ok, img(x.icon), x.label, x.have + ' / ' + n, x.have / Math.max(1, n),
      !ok && raw ? ['Où en trouver', () => { page = 'sources'; sel = null; draw(); }] : (!ok && made ? ['Se fabrique ici : voir la recette', () => { page = made.cat; sel = made; qty = 1; draw(); }] : null)));
  });
  if (r.plan) d.appendChild(need(r.planOk, img('plan'), r.plan, r.planOk ? 'Possédé' : 'Manquant', null, r.planOk ? null : ['Acheter le plan', () => { page = 'market'; sel = null; draw(); }]));
  d.appendChild(need(r.lvOk, svg('weapons'), 'Niveau d\'armurier ' + r.level, r.lvOk ? 'Atteint' : 'Tu es niveau ' + D.level, null, null));
  d.appendChild(h('div', { class: 'sp' }));
  if (r.batch > 1) d.appendChild(h('div', { class: 'qty' }, h('button', { onclick: () => { qty = Math.max(1, qty - 1); draw(); } }, '−'), h('span', null, 'Quantité : ' + qty), h('button', { onclick: () => { qty = Math.min(r.batch, qty + 1); draw(); } }, '+')));
  const enough = r.needs.every((x) => x.have >= x.need * qty);
  const why = !r.lvOk ? 'Niveau d\'armurier ' + r.level + ' requis.' : (r.plan && !r.planOk) ? 'Il te manque le plan.' : !enough ? 'Il te manque des matériaux.' : null;
  d.appendChild(h('button', { class: 'go', disabled: why ? 'disabled' : null, onclick: () => post('start', { id: D.id, rid: r.id, n: qty }) }, 'Fabriquer'));
  d.appendChild(h('p', { class: 'why' }, why || (r.cat === 'weapons' ? 'Un assemblage minutieux améliore la finition.' : 'Reste près de l\'établi pendant la fabrication.')));
}

function viewSources(body) {
  (D.raw || []).forEach((m) => {
    const box = h('div', { class: 'box wide' }, h('h3', null, h('div', { class: 'th' }, img(m.icon)), m.label, h('span', null, 'Tu en as ' + m.have)));
    (m.places || []).forEach((p) => box.appendChild(h('div', { class: 'place' }, h('div', null, h('b', null, p.label), h('small', null, 'À ' + (p.dist >= 1000 ? (p.dist / 1000).toFixed(1) + ' km' : p.dist + ' m'))),
      h('button', { class: 'mini', onclick: () => post('gps', { x: p.x, y: p.y }) }, 'Marquer sur la carte'))));
    if (!(m.places || []).length) box.appendChild(h('div', { class: 'place' }, h('div', null, h('small', null, 'Aucun lieu indiqué pour le moment.'))));
    if (m.price) box.appendChild(h('div', { class: 'place' }, h('div', null, h('b', null, 'Marché noir de cet atelier'), h('small', null, '$' + m.price + ' l\'unité')),
      h('button', { class: 'mini alt', onclick: () => post('buy', { id: D.id, item: m.item, qty: 5 }) }, 'Acheter 5'), h('button', { class: 'mini alt', onclick: () => post('buy', { id: D.id, item: m.item, qty: 25 }) }, 'Acheter 25')));
    body.appendChild(box);
  });
}
function viewPlans(body) {
  (D.market || []).filter((m) => m.plan).forEach((m) => body.appendChild(h('div', { class: 'card' },
    h('div', { class: 'pic' }, img(m.icon)), h('span', { class: 'tag ' + (m.owned ? 'ok' : '') }, m.owned ? 'Possédé' : '$' + m.price), h('b', null, m.label),
    m.owned ? h('small', null, 'Débloque ses armes pour toujours.') : h('button', { class: 'mini buy', onclick: () => post('buy', { id: D.id, item: m.item, qty: 1 }) }, 'Acheter · $' + m.price))));
}

function open(data) {
  const keep = sel && sel.id;
  D = data; scale(); tick();
  sel = keep ? (D.recipes || []).find((x) => x.id === keep) || null : null;
  $('scr').hidden = false;
  draw();
}
window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.a === 'open') open(m.data);
  else if (m.a === 'close') $('scr').hidden = true;
});
const quit = () => { $('scr').hidden = true; post('close', {}); };
$('quit').addEventListener('click', quit);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('scr').hidden) quit(); });

