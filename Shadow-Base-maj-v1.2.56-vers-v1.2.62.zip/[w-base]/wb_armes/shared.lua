-- Shadow Base — Atelier d'armes clandestin : pièces, plans, armes créées, recettes, niveaux.

PARTS = {   -- objets de fabrication
    { name = 'ferraille',   label = 'Ferraille',            weight = 500,  stack = 50,  desc = "Métal de récupération : se transforme en pièces à l'atelier." },
    { name = 'piece_acier', label = "Pièces d'acier",       weight = 300,  stack = 50,  desc = "Base de toutes les pièces d'arme." },
    { name = 'ressort',     label = 'Ressorts',             weight = 50,   stack = 100, desc = "Pour les culasses et les chargeurs." },
    { name = 'canon_court', label = 'Canon court',          weight = 600,  stack = 10,  desc = "Pistolets et pistolets-mitrailleurs." },
    { name = 'canon_long',  label = 'Canon long',           weight = 1200, stack = 5,   desc = "Fusils." },
    { name = 'culasse',     label = 'Culasse',              weight = 700,  stack = 10,  desc = "Le cœur du mécanisme." },
    { name = 'carcasse',    label = 'Carcasse polymère',    weight = 500,  stack = 10,  desc = "Le corps de l'arme." },
    { name = 'crosse',      label = 'Crosse',               weight = 800,  stack = 5,   desc = "Fusils et fusils à pompe." },
}

PLANS = {   -- plans : jamais consommés, ils débloquent une famille d'armes
    { name = 'plan_pistolet', label = 'Plan : pistolets',               price = 8000 },
    { name = 'plan_smg',      label = 'Plan : pistolets-mitrailleurs',  price = 22000 },
    { name = 'plan_pompe',    label = 'Plan : fusils à pompe',          price = 26000 },
    { name = 'plan_fusil',    label = "Plan : fusils d'assaut",         price = 48000 },
}

WEAPONS = { -- armes ajoutées au catalogue du serveur si elles n'existent pas encore
    { item = 'weapon_snspistol',      label = 'Pistolet SNS',        hash = 'WEAPON_SNSPISTOL',      ammo_item = 'ammo_pistol',  ammo_label = 'Boîte de munitions 9 mm', weight = 900 },
    { item = 'weapon_pistol',         label = 'Pistolet',            hash = 'WEAPON_PISTOL',         ammo_item = 'ammo_pistol',  ammo_label = 'Boîte de munitions 9 mm', weight = 1100 },
    { item = 'weapon_microsmg',       label = 'Micro SMG',           hash = 'WEAPON_MICROSMG',       ammo_item = 'ammo_smg',     ammo_label = 'Munitions SMG',          weight = 1600 },
    { item = 'weapon_sawnoffshotgun', label = 'Fusil à canon scié',  hash = 'WEAPON_SAWNOFFSHOTGUN', ammo_item = 'ammo_shotgun', ammo_label = 'Cartouches',             weight = 2200 },
    { item = 'weapon_compactrifle',   label = 'Fusil compact',       hash = 'WEAPON_COMPACTRIFLE',   ammo_item = 'ammo_rifle',   ammo_label = 'Munitions de fusil',     weight = 2600 },
    { item = 'weapon_assaultrifle',   label = "Fusil d'assaut",      hash = 'WEAPON_ASSAULTRIFLE',   ammo_item = 'ammo_rifle',   ammo_label = 'Munitions de fusil',     weight = 3200 },
}

-- Recettes : needs = { { objet, quantité } }, out / qty = ce qui sort, plan = plan nécessaire, level = niveau d'armurier, time = secondes, xp = gagnée
RECIPES = {
    { id = 'acier',       cat = 'parts', label = "Pièces d'acier",     out = 'piece_acier', qty = 2,  needs = { { 'ferraille', 3 } }, time = 8, level = 1, xp = 4 },
    { id = 'ressort',     cat = 'parts', label = 'Ressorts',           out = 'ressort',     qty = 3,  needs = { { 'piece_acier', 1 } }, time = 6, level = 1, xp = 3 },
    { id = 'carcasse',    cat = 'parts', label = 'Carcasse polymère',  out = 'carcasse',    qty = 1,  needs = { { 'piece_acier', 2 }, { 'ferraille', 2 } }, time = 12, level = 1, xp = 6 },
    { id = 'canon_court', cat = 'parts', label = 'Canon court',        out = 'canon_court', qty = 1,  needs = { { 'piece_acier', 3 } }, time = 15, level = 1, xp = 8 },
    { id = 'culasse',     cat = 'parts', label = 'Culasse',            out = 'culasse',     qty = 1,  needs = { { 'piece_acier', 4 }, { 'ressort', 2 } }, time = 18, level = 2, xp = 10 },
    { id = 'crosse',      cat = 'parts', label = 'Crosse',             out = 'crosse',      qty = 1,  needs = { { 'ferraille', 4 }, { 'piece_acier', 1 } }, time = 14, level = 2, xp = 8 },
    { id = 'canon_long',  cat = 'parts', label = 'Canon long',         out = 'canon_long',  qty = 1,  needs = { { 'piece_acier', 6 } }, time = 25, level = 3, xp = 14 },


    { id = 'snspistol',    cat = 'weapons', label = 'Pistolet SNS',       out = 'weapon_snspistol',      qty = 1, plan = 'plan_pistolet', needs = { { 'carcasse', 1 }, { 'canon_court', 1 }, { 'culasse', 1 }, { 'ressort', 2 } }, time = 45, level = 2, xp = 30 },
    { id = 'pistol',       cat = 'weapons', label = 'Pistolet',           out = 'weapon_pistol',         qty = 1, plan = 'plan_pistolet', needs = { { 'carcasse', 1 }, { 'canon_court', 1 }, { 'culasse', 1 }, { 'ressort', 3 }, { 'piece_acier', 2 } }, time = 60, level = 3, xp = 40 },
    { id = 'microsmg',     cat = 'weapons', label = 'Micro SMG',          out = 'weapon_microsmg',       qty = 1, plan = 'plan_smg',      needs = { { 'carcasse', 1 }, { 'canon_court', 1 }, { 'culasse', 2 }, { 'ressort', 4 }, { 'piece_acier', 4 } }, time = 90, level = 5, xp = 60 },
    { id = 'sawnoff',      cat = 'weapons', label = 'Fusil à canon scié', out = 'weapon_sawnoffshotgun', qty = 1, plan = 'plan_pompe',    needs = { { 'crosse', 1 }, { 'canon_long', 1 }, { 'culasse', 1 }, { 'ressort', 2 } }, time = 80, level = 5, xp = 60 },
    { id = 'compactrifle', cat = 'weapons', label = 'Fusil compact',      out = 'weapon_compactrifle',   qty = 1, plan = 'plan_fusil',    needs = { { 'crosse', 1 }, { 'canon_long', 1 }, { 'culasse', 2 }, { 'ressort', 4 }, { 'piece_acier', 6 } }, time = 120, level = 7, xp = 90 },
    { id = 'assaultrifle', cat = 'weapons', label = "Fusil d'assaut",     out = 'weapon_assaultrifle',   qty = 1, plan = 'plan_fusil',    needs = { { 'crosse', 1 }, { 'canon_long', 1 }, { 'culasse', 2 }, { 'ressort', 5 }, { 'piece_acier', 8 }, { 'carcasse', 1 } }, time = 150, level = 9, xp = 120 },

    -- démontage : une arme redonne une partie de ses pièces
    { id = 'dem_pistol', cat = 'scrap', label = 'Démonter un pistolet',       out = 'piece_acier', qty = 3, extra = { { 'ressort', 2 } }, needs = { { 'weapon_pistol', 1 } }, time = 20, level = 1, xp = 2 },
    { id = 'dem_sns',    cat = 'scrap', label = 'Démonter un pistolet SNS',   out = 'piece_acier', qty = 2, extra = { { 'ressort', 1 } }, needs = { { 'weapon_snspistol', 1 } }, time = 15, level = 1, xp = 2 },
}
RECIPE_BY = {}
for _, r in ipairs(RECIPES) do RECIPE_BY[r.id] = r end

CATS = {
    { id = 'parts',   label = 'Pièces',     icon = 'wrench', desc = 'Ferraille → pièces d\'acier → pièces d\'arme.' },
    { id = 'weapons', label = 'Armes',      icon = 'shield', desc = 'Plan nécessaire. Assemblage minutieux.' },
    { id = 'scrap',   label = 'Démontage',  icon = 'trash',  desc = 'Récupérer des pièces sur une arme.' },
}

-- XP minimum de chaque niveau (niveau 1 à 10)
LEVELS = { 0, 60, 160, 320, 560, 900, 1350, 1900, 2600, 3500 }

-- marché noir de l'atelier (argent sale en priorité)
MARKET = {
    { item = 'ferraille', price = 35 },
}

-- Matériaux de base : ce qui ne se fabrique pas. Ils se récupèrent aux lieux posés au Builder, ou s'achètent au marché noir de l'atelier.
RAW_ITEMS = {
    { item = 'ferraille', label = 'Ferraille', builder = 'src_ferraille', place = 'Tas de ferraille', min = 2, max = 5, verb = 'Fouiller la ferraille' },
}
RAW_BY = {}
for _, r in ipairs(RAW_ITEMS) do RAW_BY[r.item] = r end
