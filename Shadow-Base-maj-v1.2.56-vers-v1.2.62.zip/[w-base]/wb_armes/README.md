# wb_armes — Atelier d'armes clandestin

Extension de Shadow Base (pb_panel).

- **Ateliers cachés** posés au Builder (F10 › Builder › Atelier d'armes) : aucune icône sur la carte, le joueur voit l'invite **E** seulement à côté de l'établi. Le serveur n'envoie jamais leur position à l'avance.
- **Accès** : tout le monde, ou réservé à des gangs / entreprises (panel › Atelier d'armes › Ateliers, colonne Accès : `gang:ballas,biz:mecano`).
- **Chaîne de fabrication** : ferraille → pièces d'acier → ressorts, canons, culasses, carcasses, crosses → armes. Démontage d'armes. **Les munitions ne se fabriquent pas** : elles s'achètent à l'Ammu-Nation.
- **Plans** (jamais consommés) pour chaque famille d'armes : pistolets, pistolets-mitrailleurs, fusils à pompe, fusils d'assaut.
- **Niveau d'armurier** de 1 à 10 par personnage : recettes débloquées, moins de ratés, meilleure finition.
- **Tablette** : interface translucide (menu à gauche, cartes avec images, détail à droite avec ✓ / ✕, quantité réglable, bouton Fabriquer qui explique pourquoi il est grisé) : Armes, Pièces, Démontage, Où trouver, Plans.
- **Qualité** artisanale / correcte / excellente selon le niveau et le **mini-jeu d'assemblage** (3 touches à presser à temps). Une finition excellente rapporte plus d'expérience.
- **Raté** : la moitié des pièces est perdue.
- **Marché noir** dans l'atelier : ferraille et plans (argent sale en priorité, sinon espèces).
- **Police** : chaque arme terminée peut déclencher une alerte (réglable).
- Journal `wb_armes_log` (purgé automatiquement avec les autres journaux).

Installation : `ensure wb_armes` après `pb_panel` (déjà inclus dans le dossier `[w-base]`).
