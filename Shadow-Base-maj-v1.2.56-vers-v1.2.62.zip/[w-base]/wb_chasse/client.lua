-- Shadow Base — Chasse (client) : zones, apparition du gibier choisi par le serveur, dépeçage (E), marché et boutique.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {} }
local blips, animals = {}, {}     -- animals : token -> { ped, id }
local busy = false

local function notify(kind, text) W:Notify({ type = kind, title = 'Chasse', text = text }) end
local _keyTex, _keyChk = nil, 0
local function marker(x, y, z)
    -- (v1.2.43) même touche « E » arrondie que Shadow Base (texture pb_ui/key_e créée par pb_panel), sinon petit point lumineux
    local pz = z + 1.0
    if _keyTex == nil or GetGameTimer() > (_keyChk or 0) then
        _keyChk = GetGameTimer() + 5000
        local res = GetTextureResolution('pb_ui', 'key_e')
        _keyTex = res and res.x and res.x > 4 or false
    end
    if _keyTex then
        local ok, sx, sy = GetScreenCoordFromWorldCoord(x + 0.0, y + 0.0, pz + 0.0)
        if not ok then return end
        local d = #(GetEntityCoords(PlayerPedId()) - vector3(x + 0.0, y + 0.0, pz + 0.0))
        local k = math.max(0.55, 1.0 - d / 30.0)
        local hs = 0.036 * k
        DrawSprite('pb_ui', 'key_e', sx, sy, hs / GetAspectRatio(false), hs, 0.0, 255, 255, 255, math.floor(math.max(90, 235 - d * 9)))
        return
    end
    local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end

local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, s in ipairs(C.spots or {}) do
        if s.kind == 'zone' then
            local r = AddBlipForRadius(s.x + 0.0, s.y + 0.0, s.z + 0.0, (s.r or 150) + 0.0)
            SetBlipColour(r, 25) SetBlipAlpha(r, 60)
            blips[#blips + 1] = r
        end
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, s.kind == 'zone' and 141 or (s.kind == 'market' and 52 or 154)) SetBlipColour(b, 25) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end)
-- Réinitialisation des repères (/blips reset ou panel) : on efface les nôtres et on redemande la liste
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
end)

-- Dans une zone : demande régulière de gibier au serveur
local function inZone()
    local c = GetEntityCoords(PlayerPedId())
    for _, s in ipairs(C.spots or {}) do
        if s.kind == 'zone' and #(vector2(c.x, c.y) - vector2(s.x + 0.0, s.y + 0.0)) <= (s.r or 150) then return s end
    end
end
CreateThread(function()
    while true do
        Wait(2000)
        if C.enabled and inZone() and not IsPedInAnyVehicle(PlayerPedId(), false) then TriggerServerEvent(RES .. ':want') end
        -- nettoyage : animaux trop loin ou disparus
        local c = GetEntityCoords(PlayerPedId())
        for tok, a in pairs(animals) do
            if not DoesEntityExist(a.ped) or #(GetEntityCoords(a.ped) - c) > 300.0 then
                if DoesEntityExist(a.ped) then DeleteEntity(a.ped) end
                animals[tok] = nil
                TriggerServerEvent(RES .. ':gone', tok)
            elseif not a.dead and IsEntityDead(a.ped) then
                a.dead = true
                TriggerServerEvent(RES .. ':dead', tok)   -- la carcasse reste à dépecer, mais ne compte plus dans le gibier vivant
            end
        end
    end
end)

-- Prédateurs moins mortels : plus lents et leurs coups font 4 fois moins de dégâts (avant : un coup suffisait)
local predators = {}
-- Animal « calme » : ne voit ni n'entend le joueur, ne fuit pas et n'attaque jamais (gibier de la chasse et animaux sauvages du monde)
local ANIMAL_GROUPS = { 'WILD_ANIMAL', 'COUGAR', 'SHARK', 'DEER', 'HEN', 'DOMESTIC_ANIMAL', 'GUARD_DOG', 'PRIVATE_SECURITY_DOG' }
local function calm(ped)
    if not DoesEntityExist(ped) then return end
    SetPedSeeingRange(ped, 0.0) SetPedHearingRange(ped, 0.0)
    SetPedFleeAttributes(ped, 0, false)
    SetPedCombatAttributes(ped, 46, false) SetPedCombatAttributes(ped, 5, false)
    SetPedRelationshipGroupHash(ped, joaat('WILD_ANIMAL'))
end
CreateThread(function()
    -- les groupes d'animaux respectent le joueur (et inversement) : plus d'attaque des animaux sauvages du monde
    for _, g in ipairs(ANIMAL_GROUPS) do
        local h = joaat(g)
        SetRelationshipBetweenGroups(1, h, joaat('PLAYER'))
        SetRelationshipBetweenGroups(1, joaat('PLAYER'), h)
    end
    -- animaux proches (gibier et faune du jeu) : rendus calmes au fur et à mesure qu'ils apparaissent
    local done = {}
    while true do
        Wait(1500)
        local me = GetEntityCoords(PlayerPedId())
        for _, ped in ipairs(GetGamePool('CPed')) do
            if not done[ped] and not IsPedAPlayer(ped) and GetPedType(ped) == 28 and #(GetEntityCoords(ped) - me) < 150.0 then
                done[ped] = true
                calm(ped)
                if IsPedInCombat(ped, PlayerPedId()) then ClearPedTasks(ped) TaskWanderStandard(ped, 10.0, 10) end
            end
        end
        for ped in pairs(done) do if not DoesEntityExist(ped) then done[ped] = nil end end
    end
end)
CreateThread(function()
    while true do
        if next(predators) then
            SetWeaponDamageModifierThisFrame(joaat('WEAPON_COUGAR'), 0.25)
            SetWeaponDamageModifierThisFrame(joaat('WEAPON_ANIMAL'), 0.25)
            for ped in pairs(predators) do if DoesEntityExist(ped) then SetPedMoveRateOverride(ped, 0.75) end end
            Wait(0)
        else Wait(500) end
    end
end)

-- Apparition à 40-70 m, hors de vue directe ; les prédateurs s'approchent du chasseur
RegisterNetEvent(RES .. ':spawn', function(token, id, called)
    local a = ANIMAL_BY[id]
    if not a then return end
    local h = joaat(a.model)
    if not IsModelInCdimage(h) then TriggerServerEvent(RES .. ':gone', token) return end
    RequestModel(h)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
    if not HasModelLoaded(h) then TriggerServerEvent(RES .. ':gone', token) return end
    local me = PlayerPedId()
    local c = GetEntityCoords(me)
    local ang, dist = math.random() * math.pi * 2, 40 + math.random() * 30
    local x, y = c.x + math.cos(ang) * dist, c.y + math.sin(ang) * dist
    local ok, gz = GetGroundZFor_3dCoord(x, y, c.z + 50.0, false)
    local ped = CreatePed(28, h, x, y, ok and gz or c.z, math.random(0, 359) + 0.0, false, true)
    SetModelAsNoLongerNeeded(h)
    SetEntityAsMissionEntity(ped, true, true)
    -- (v1.2.45) aucun animal n'attaque ni ne voit le chasseur, même les prédateurs (puma, panthère…) : on ne meurt pas en chassant
    calm(ped)
    if a.hostile then SetEntityMaxHealth(ped, 300) SetEntityHealth(ped, 300) end   -- un prédateur reste plus résistant
    if called then
        TaskGoToEntity(ped, me, -1, 25.0, 1.5, 0, 0)
    else
        TaskWanderStandard(ped, 10.0, 10)
    end
    animals[token] = { ped = ped, id = id }
    if called then notify('info', ('Quelque chose approche… (%s)'):format(a.label)) end
end)

-- Dépeçage : E près d'un animal abattu
local function knifeAnim(secs)
    local ped = PlayerPedId()
    RequestAnimDict('amb@medic@standing@kneel@base')
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded('amb@medic@standing@kneel@base') and GetGameTimer() < t do Wait(10) end
    TaskPlayAnim(ped, 'amb@medic@standing@kneel@base', 'base', 3.0, 3.0, -1, 1, 0, false, false, false)
    W:Progress('Dépeçage', secs)
    local stop, ok = GetGameTimer() + secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) then ok = false break end
    end
    ClearPedTasks(ped)
    if not ok then W:CancelProgress() end
    return ok
end
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 500
        if next(animals) and not busy and isFree() then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for tok, a in pairs(animals) do
                if DoesEntityExist(a.ped) and IsEntityDead(a.ped) then
                    local d = #(GetEntityCoords(a.ped) - c)
                    if d < 25.0 then sleep = 0 end
                    if d < 2.5 and (not bd or d < bd) then best, bd = tok, d end
                end
            end
            if best then
                if shown ~= best then shown = best local ac = GetEntityCoords(animals[best].ped) W:Prompt('Dépecer : ' .. (ANIMAL_BY[animals[best].id] or {}).label, 'E', ac.x, ac.y, ac.z) end
                if IsControlJustPressed(0, 38) then
                    hide()
                    busy = true
                    local tok = best
                    if knifeAnim(8) then
                        TriggerServerEvent(RES .. ':skin', tok)
                        local a = animals[tok]
                        animals[tok] = nil
                        if a and DoesEntityExist(a.ped) then SetTimeout(1500, function() if DoesEntityExist(a.ped) then DeleteEntity(a.ped) end end) end
                    end
                    busy = false
                end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Marchés et boutiques
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if C.enabled and isFree() then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(C.spots or {}) do
                if s.kind ~= 'zone' then local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end
            end
            if best and bd < 30.0 then
                sleep = 0
                if not (NPCS and NPCS[best.id] and DoesEntityExist(NPCS[best.id])) then marker(best.x, best.y, best.z - 0.95) end
                if bd < 2.5 then
                    if shown ~= best.id then shown = best.id W:Prompt((best.kind == 'market' and 'Vendre ton gibier : ' or 'Parler au guide : ') .. best.label, 'E', best.x, best.y, best.z) end
                    if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':open', best.id) Wait(500) end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

local function pickModel(list)
    for _, name in ipairs(list) do
        local m = joaat(name)
        if IsModelInCdimage(m) then
            RequestModel(m)
            local t = GetGameTimer() + 3000
            while not HasModelLoaded(m) and GetGameTimer() < t do Wait(20) end
            if HasModelLoaded(m) then return m end
        end
    end
end
-- (v1.2.58) véhicule prêté par le guide : posé à sa sortie (Builder), sinon sur la route la plus proche
RegisterNetEvent(RES .. ':vehspawn', function(x, y, z, hd)
    local V = HUNT_VEHICLE
    if not V then return end
    local h = pickModel(V.models)
    if not h then notify('error', 'Véhicule indisponible.') return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    if not x then
        local ok, node, heading = GetClosestVehicleNodeWithHeading(c.x, c.y, c.z, 1, 3.0, 0)
        if ok and node and #(node - c) < 60.0 then x, y, z, hd = node.x, node.y, node.z, heading
        else local p = c + GetEntityForwardVector(ped) * 5.0 x, y, z, hd = p.x, p.y, p.z, GetEntityHeading(ped) end
    end
    local v = CreateVehicle(h, x + 0.0, y + 0.0, z + 0.5, (hd or 0.0) + 0.0, true, false)
    SetModelAsNoLongerNeeded(h)
    if not v or v == 0 then return end
    SetVehicleOnGroundProperly(v)
    SetVehicleNumberPlateText(v, (V.plate .. '%04d'):format(math.random(0, 9999)))
    SetVehicleDoorsLocked(v, 1)
    SetEntityAsMissionEntity(v, true, true)
    TriggerServerEvent(RES .. ':vehnet', NetworkGetNetworkIdFromEntity(v))
end)

local openSpot
RegisterNetEvent(RES .. ':shop', function(id, kind, title, j, vip, allT, allN)
    local ok, list = pcall(json.decode, j)
    if not ok or type(list) ~= 'table' then return end
    openSpot = id
    local items = {}
    if kind == 'market' then
        if vip then items[#items + 1] = { label = 'Bonus VIP actif', icon = 'crown', description = 'Tu touches un bonus sur chaque vente.', disabled = true } end
        if (allN or 0) > 0 then
            items[#items + 1] = { label = 'Tout vendre', icon = 'coins', right = ('$%d'):format(allT), description = ('%d objets pour $%d. Le cours baisse à chaque unité vendue : ce prix en tient compte.'):format(allN, allT),
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sellall', id) end }
            items[#items + 1] = { type = 'separator', label = 'À l\'unité' }
        end
        for _, x in ipairs(list) do
            local trend = x.pct >= 105 and ' ▲' or (x.pct <= 95 and ' ▼' or '')
            local it = { label = x.label, right = (x.n > 0 and (x.n .. ' × ') or '') .. ('$%d%s'):format(x.price, trend), description = ('%s · cours %d %% du prix normal ($%d)'):format((HUNT_RARITY_BY[x.rarity] or {}).label or '', x.pct, x.base) }
            if x.n > 0 then it.onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sell', id, x.item) end else it.disabled = true end
            items[#items + 1] = it
        end
        W:OpenMenu({ id = RES .. '.market', title = title, subtitle = 'Vendre ton gibier', items = items })
    else
        for _, x in ipairs(list) do
          if x.veh then
            items[#items + 1] = { label = x.label, icon = 'engine', right = x.veh == 'take' and 'Gratuit' or nil, description = x.desc,
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':veh', id, x.veh) end }
          elseif x.kit then
            items[#items + 1] = { label = x.label, icon = 'target', right = x.kit == 'take' and 'Gratuit' or nil,
                description = x.kit == 'take' and 'Le guide te prête un fusil (il ne blesse que le gibier, cartouches illimitées), des cartouches et un couteau. Le marché les reprend avant la vente.' or 'Rends le fusil, les cartouches et le couteau prêtés.',
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':kit', id, x.kit) end }
            items[#items + 1] = { type = 'separator', label = 'Boutique' }
          else
            local qty = x.tool and 1 or 3
            items[#items + 1] = { label = x.label .. (qty > 1 and (' ×' .. qty) or '') .. (x.vip and ' (VIP)' or ''), right = '$' .. (x.price * qty), disabled = x.locked or nil,
                description = x.locked and 'Réservé aux VIP.' or (x.tool and 'Indispensable pour dépecer le gibier.' or 'À utiliser dans une zone de chasse : attire un animal tout de suite.'),
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':buy', id, x.item, qty) end }
          end
        end
        W:OpenMenu({ id = RES .. '.shop', title = title, subtitle = 'Guide de chasse', items = items })
    end
end)
RegisterNetEvent(RES .. ':refresh', function(id) if openSpot == id then TriggerServerEvent(RES .. ':open', id) end end)

-- Fusil prêté : cartouches qui ne s'épuisent pas, et impossible de tirer sur autre chose que le gibier de la chasse
RegisterNetEvent(RES .. ':holster', function(hash)
    local ped = PlayerPedId()
    local h = joaat(tostring(hash or 'WEAPON_MUSKET'))
    if HasPedGotWeapon(ped, h, false) then RemoveWeaponFromPed(ped, h) SetCurrentPedWeapon(ped, joaat('WEAPON_UNARMED'), true) end
end)
local function isGame(ent) for _, a in pairs(animals) do if a.ped == ent then return true end end return false end
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local h = joaat(tostring(C.weapon or 'WEAPON_MUSKET'))
        if GetSelectedPedWeapon(ped) ~= h then Wait(500) else
            Wait(0)
            SetPedInfiniteAmmo(ped, true, h)
            if GetAmmoInPedWeapon(ped, h) < 20 then SetPedAmmo(ped, h, 100) end
            local ok, ent = GetEntityPlayerIsFreeAimingAt(PlayerId())
            if ok and ent and ent ~= 0 then
                local t = GetEntityType(ent)
                if t == 2 or (t == 1 and (IsPedAPlayer(ent) or not isGame(ent))) then DisablePlayerFiring(PlayerId(), true) end
            end
        end
    end
end)

-- PNJ du guide et du marchand (posés seulement quand on est à moins de 60 m)
local npcs = {}
NPCS = npcs
local NPC_MODEL = { shop = 'cs_hunter', market = 'ig_hunter' }
CreateThread(function()
    while true do
        Wait(1500)
        local c = GetEntityCoords(PlayerPedId())
        local want = {}
        if C.enabled then
            for _, s in ipairs(C.spots or {}) do
                if s.kind ~= 'zone' and #(c - vector3(s.x, s.y, s.z)) < 60.0 then
                    want[s.id] = true
                    if not (npcs[s.id] and DoesEntityExist(npcs[s.id])) then
                        local m = joaat(NPC_MODEL[s.kind] or 'cs_hunter')
                        if not IsModelInCdimage(m) then m = joaat('a_m_m_hillbilly_01') end
                        RequestModel(m)
                        local t = GetGameTimer() + 3000
                        while not HasModelLoaded(m) and GetGameTimer() < t do Wait(20) end
                        if HasModelLoaded(m) then
                            local ok, gz = GetGroundZFor_3dCoord(s.x + 0.0, s.y + 0.0, s.z + 2.0, false)
                            local p = CreatePed(4, m, s.x + 0.0, s.y + 0.0, ok and gz or (s.z - 1.0), (tonumber(s.h) or 0.0) + 0.0, false, false)
                            SetEntityInvincible(p, true) FreezeEntityPosition(p, true) SetBlockingOfNonTemporaryEvents(p, true)
                            TaskStartScenarioInPlace(p, s.kind == 'shop' and 'WORLD_HUMAN_CLIPBOARD' or 'WORLD_HUMAN_STAND_IMPATIENT', 0, true)
                            SetModelAsNoLongerNeeded(m)
                            npcs[s.id] = p
                        end
                    end
                end
            end
        end
        for id, p in pairs(npcs) do if not want[id] then if DoesEntityExist(p) then DeleteEntity(p) end npcs[id] = nil end end
    end
end)

AddEventHandler('onClientResourceStop', function(res)
    if res ~= RES then return end
    for _, p in pairs(npcs) do if DoesEntityExist(p) then DeleteEntity(p) end end
    clearBlips()
    for _, a in pairs(animals) do if DoesEntityExist(a.ped) then DeleteEntity(a.ped) end end
end)
