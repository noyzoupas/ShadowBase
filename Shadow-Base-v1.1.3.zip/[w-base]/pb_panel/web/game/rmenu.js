/* pb_menu — rendu du menu « RageUI » : bannière, titre + compteur, ligne de progression, sous-titre, éléments, description.
   Tout texte reçu est inséré avec textContent. Le thème vient de la configuration « menus » (panel > Menus). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;

const DEFAULTS = { accent: '#dfe2e7', bg: '#111216', bg2: '#2b2e35', text: '#ffffff', muted: '#8d939e', banner_mode: 'anim', banner_text: '', banner_sub: '', banner_image: '', banner_height: 110, banner_band: true,
  chips: ['discord|DISCORD.GG/MONSERVEUR', 'globe|HTTPS://MONSERVEUR.FR'], width: 440, radius: 10, opacity: 88, blur: 0, row_height: 44, font_scale: 100, position: 'center', offset_x: 0, offset_y: -300,
  show_counter: true, show_desc: true, show_progress: true, title_case: 'upper', selected_style: 'bar', skin: 'shadow', banner_logo: '' };

const num = (v, d, lo, hi) => { v = Number(v); if (!isFinite(v)) v = d; return Math.max(lo, Math.min(hi, v)); };
function themeOf(cfg) {
  const t = Object.assign({}, DEFAULTS, cfg || {});
  t.banner_height = num(t.banner_height, 130, 0, 260); t.width = num(t.width, 440, 280, 640); t.radius = num(t.radius, 16, 0, 32);
  t.opacity = num(t.opacity, 96, 40, 100); t.blur = num(t.blur, 0, 0, 30); t.row_height = num(t.row_height, 44, 32, 72); t.font_scale = num(t.font_scale, 100, 70, 160);
  t.offset_x = num(t.offset_x, 0, -2000, 2000); t.offset_y = num(t.offset_y, 0, -2000, 2000);
  if (!/^#[0-9a-f]{6}$/i.test(t.accent)) t.accent = DEFAULTS.accent;
  ['bg', 'bg2', 'text', 'muted'].forEach((k) => { if (!/^#[0-9a-f]{6}$/i.test(t[k])) t[k] = DEFAULTS[k]; });
  return t;
}
const safeUrl = (u) => G.assetUrl(u);

function chip(spec) {
  const parts = String(spec || '').split('|');
  const name = parts.length > 1 ? parts[0].trim() : 'link', text = (parts.length > 1 ? parts.slice(1).join('|') : parts[0]).trim();
  return h('span', { class: 'rm-chip' }, G.ico(name, 'rm-chi'), h('b', null, text));
}

// ---- habillage « Shadow » (maquette Shadow Studio) : fond et bannière dessinés, lignes à puce, coche blanche, description sous le menu
function buildShadow(t, snap, cb) {
  const k = t.width / 342;
  const el = h('div', { class: 'rm rms pos-' + t.position + (cb ? ' ui' : ''), style: { '--k': k, '--ox': t.offset_x + 'px', '--oy': t.offset_y + 'px', '--op': t.opacity / 100 } });
  const box = h('div', { class: 'rms-box' });
  // texture du fond (graffitis de la maquette) : calque décoratif, jamais cliquable
  box.appendChild(h('i', { class: 'rms-tex' }));
  // Le « + » blanc du bandeau-logo sert de bouton de fermeture : la zone cliquable est posée dessus (le glyphe est déjà dans l'image).
  if (cb) box.appendChild(h('button', { class: 'rms-x', type: 'button', title: 'Fermer (Échap)', 'aria-label': 'Fermer', onclick: () => cb.close() }));
  const total = (snap.counter && snap.counter[1]) || 0, cur = (snap.counter && snap.counter[0]) || 0;
  box.appendChild(h('div', { class: 'rms-head' },
    (cb && snap.depth > 1) ? h('button', { class: 'rms-back', type: 'button', title: 'Retour', 'aria-label': 'Retour', onclick: () => cb.back() }, G.ico('chevron')) : null,
    h('span', { class: 'rms-t' }, String(snap.title || ''), snap.subtitle ? h('i', null, ' - ') : null, snap.subtitle ? h('em', null, String(snap.subtitle)) : null),
    t.show_counter && total ? h('span', { class: 'rms-n' }, cur + '/' + total) : null));
  const list = h('div', { class: 'rms-list rm-list' });
  (snap.items || []).forEach((it) => list.appendChild(rowShadow(it, cb)));
  box.appendChild(list);
  // La flèche du bas fait partie de la maquette ; en interface elle sert aussi à faire défiler une liste trop longue.
  const more = h('button', {
    class: 'rms-more dn' + (cb ? ' scroll' : ''), type: 'button', tabindex: '-1', title: 'Plus bas', 'aria-label': 'Plus bas',
    onclick: cb ? () => {
      const max = Math.max(0, list.scrollHeight - list.clientHeight);
      const step = Math.max(70, list.clientHeight * .85);
      list.scrollTop = Math.min(max, list.scrollTop + step);
    } : null
  }, G.ico('chevron'));
  box.appendChild(more);
  if (cb) {
    const sync = () => {
      const max = list.scrollHeight - list.clientHeight;
      box.classList.toggle('has-scroll', max > 2);
    };
    list.addEventListener('scroll', sync, { passive: true });
    requestAnimationFrame(sync);
  } else {
    // mode « lib » : la fenêtre glissante peut envoyer une 10e ligne sous la zone visible ; on la remonte.
    requestAnimationFrame(() => {
      const on = list.querySelector('.rms-r.on');
      if (!on) return;
      const lr = list.getBoundingClientRect(), rr = on.getBoundingClientRect();
      if (rr.bottom > lr.bottom) list.scrollTop += rr.bottom - lr.bottom + 8;
      else if (rr.top < lr.top) list.scrollTop -= Math.min(lr.top - rr.top + 8, list.scrollTop);
    });
  }
  el.appendChild(box);
  if (t.show_desc && snap.desc) el.appendChild(h('div', { class: 'rms-desc' }, String(snap.desc)));
  return el;
}
function rowShadow(it, cb) {
  if (it.kind === 'separator') return h('div', { class: 'rms-sep' }, it.label ? h('span', null, String(it.label)) : null);
  let right = null;
  if (it.kind === 'list') right = h('span', { class: 'rms-val' }, it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, -1); } : null }, '‹') : null, String(it.value || ''), it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, 1); } : null }, '›') : null);
  else if (it.kind === 'checkbox') right = h('span', { class: 'rms-chk' + (it.checked ? ' on' : '') });
  else if (it.kind === 'slider') { const p = it.max > it.min ? (it.value - it.min) / (it.max - it.min) * 100 : 0; right = h('span', { class: 'rms-sl' }, h('u', null, h('i', { style: { width: p + '%' } })), h('b', null, String(it.value))); }
  else if (it.kind === 'input') right = h('span', { class: 'rms-val' }, String(it.value || '…'));
  else right = h('span', { class: 'rms-ic' }, G.ico(it.icon || 'chevron'));
  const ev = cb ? { onmouseenter: () => { if (!it.active && !it.disabled) cb.hover(it.i); },
    onclick: (e) => { if (it.disabled) return; if (it.kind === 'list' || it.kind === 'slider') { const r = e.currentTarget.getBoundingClientRect(); cb.change(it.i, (e.clientX - r.left) < r.width / 2 ? -1 : 1); } else cb.select(it.i); } } : null;
  return h('div', Object.assign({ class: 'rms-r' + (it.active ? ' on' : '') + (it.disabled ? ' off' : ''), 'data-i': it.i }, ev || {}),
    h('i', { class: 'rms-dot' }), h('span', { class: 'rms-l' }, String(it.label || '')),
    it.right ? h('span', { class: 'rms-rt' }, String(it.right)) : null, it.badge ? h('span', { class: 'rms-bd' }, String(it.badge)) : null, right);
}

let banKey = '', banT0 = 0, banFresh = true;
function build(theme, snap, brandName, cb) {
  const t = themeOf(theme);
  snap = snap || {};
  if (t.skin === 'shadow') return buildShadow(t, snap, cb);
  const ban = snap.banner || {};
  const name = (ban.text != null ? ban.text : (t.banner_text || brandName || 'MON SERVEUR'));
  const imgUrl = safeUrl(ban.image != null ? ban.image : t.banner_image);
  const mode = ban.mode || t.banner_mode;
  const flat = t.skin !== 'classic';
  const el = h('div', { class: 'rm pos-' + t.position + ' sel-' + t.selected_style + (flat ? ' skin-flat' : '') + (cb ? ' ui' : ''), style: {
    '--ac': t.accent, '--acr': G.hexToRgb(t.accent), '--bg': t.bg, '--bgr': G.hexToRgb(t.bg), '--bg2': t.bg2, '--bg2r': G.hexToRgb(t.bg2), '--tx': t.text, '--mu': t.muted,
    '--w': t.width + 'px', '--rd': t.radius + 'px', '--op': t.opacity / 100, '--bl': t.blur + 'px', '--rh': t.row_height + 'px', '--fs': t.font_scale / 100, '--bh': t.banner_height + 'px', '--ox': t.offset_x + 'px', '--oy': t.offset_y + 'px' } });

  if (t.banner_height > 0) {
    const bn = h('div', { class: 'rm-ban' + (mode === 'image' && imgUrl ? ' img' : '') + (mode === 'anim' ? ' anim' : '') });
    if (mode === 'anim') {
      // bannière animée : le W se dessine, puis le nom du menu ouvert apparaît. Le texte suit le menu (Menu admin, Menu police…) ; rien d'autre.
      const root0 = (snap.path && snap.path[0]) || snap.title || '';
      const raw = ban.text != null ? String(ban.text) : (t.banner_text ? String(t.banner_text) : String(root0 || brandName || 'Menu'));
      const raw2 = /^menu staff$/i.test(raw) ? 'Menu admin' : raw;
      const label = (/^menu\b/i.test(raw2) ? raw2 : 'Menu ' + raw2.charAt(0).toLowerCase() + raw2.slice(1)).slice(0, 32);
      const now = performance.now();
      if (label !== banKey || banFresh) { banKey = label; banT0 = now; banFresh = false; }
      bn.style.setProperty('--bt', (-(now - banT0)) + 'ms');          // reprend l'animation là où elle en était quand le menu se redessine
      if (G.season && G.season()) bn.classList.add('hw');
      const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 1024 1024'); svg.setAttribute('class', 'rm-wsvg');
      const mk = (cls) => { const e = document.createElementNS(NS, 'path'); e.setAttribute('d', G.WPATH || ''); e.setAttribute('class', cls); if (cls === 'rm-wp') e.setAttribute('pathLength', '1'); return e; };
      svg.appendChild(mk('rm-wf')); svg.appendChild(mk('rm-wp'));
      bn.appendChild(h('i', { class: 'rm-aur a1' })); bn.appendChild(h('i', { class: 'rm-aur a2' }));
      bn.appendChild(h('div', { class: 'rm-an' }, h('span', { class: 'rm-anw' }, svg), h('div', { class: 'rm-ant' }, h('b', null, label.toUpperCase()))));
      bn.appendChild(h('i', { class: 'rm-line' }));
    } else if (mode === 'image' && imgUrl) bn.style.backgroundImage = 'linear-gradient(180deg,rgba(0,0,0,.05),rgba(var(--bgr),.85)),url("' + imgUrl + '")';
    else {
      if (t.banner_band) bn.appendChild(h('i', { class: 'rm-band' }));
      const nm = String(name), room = t.width - ((Array.isArray(t.chips) && t.chips.filter(Boolean).length) ? 150 : 40);
      const lg = h('div', { class: 'rm-logo', style: { '--lf': Math.max(18, Math.min(t.banner_height * .46, room / Math.max(4, nm.length) / .5)) + 'px' } }, h('b', null, String(name).toUpperCase()), (ban.sub != null ? ban.sub : t.banner_sub) ? h('small', null, String(ban.sub != null ? ban.sub : t.banner_sub).toUpperCase()) : null);
      bn.appendChild(lg);
    }
    const logoUrl = safeUrl(ban.logo != null ? ban.logo : (t.banner_logo || (G.cfg.brand && G.cfg.brand.logo) || ''));
    if (flat && logoUrl && mode !== 'anim') { G.clear(bn); bn.classList.add('haslogo'); bn.appendChild(h('img', { class: 'rm-logoimg', src: logoUrl, alt: '' })); }
    const chips = (Array.isArray(t.chips) ? t.chips : []).filter(Boolean).slice(0, 3);
    if (chips.length && !flat) bn.appendChild(h('div', { class: 'rm-chips' }, chips.map(chip)));
    if (cb && flat) bn.appendChild(h('button', { class: 'rm-x', title: 'Fermer', onclick: () => cb.close() }, G.ico('close')));
    el.appendChild(bn);
  }
  const total = (snap.counter && snap.counter[1]) || 0, cur = (snap.counter && snap.counter[0]) || 0;
  const title = t.title_case === 'upper' ? String(snap.title || '').toUpperCase() : String(snap.title || '');
  if (flat) {
    el.appendChild(h('div', { class: 'rm-head' },
      (cb && snap.depth > 1) ? h('button', { class: 'rm-back', title: 'Retour', onclick: () => cb.back() }, G.ico('chevron')) : null,
      h('span', { class: 'rm-t' }, String(snap.title || '')), h('span', { class: 'rm-s' }, snap.subtitle ? String(snap.subtitle) : ''),
      t.show_counter && total ? h('span', { class: 'rm-n' }, cur + '/' + total) : null,
      (cb && cb.style) ? h('button', { class: 'rm-sw', title: 'Passer au menu à flèches', onclick: () => cb.style('lib') }, G.ico('refresh')) : null));
  } else {
    el.appendChild(h('div', { class: 'rm-head' }, h('span', { class: 'rm-t' }, title), t.show_counter && total ? h('span', { class: 'rm-n' }, cur + ' / ' + total) : null));
    if (t.show_progress && total) el.appendChild(h('div', { class: 'rm-pr' }, h('i', { style: { left: ((cur - 1) / total * 100) + '%', width: (100 / total) + '%' } })));
    if (snap.subtitle) el.appendChild(h('div', { class: 'rm-sub' }, h('span', null, String(snap.subtitle).toUpperCase()), h('hr')));
  }
  const list = h('div', { class: 'rm-list' });
  if (snap.up) list.appendChild(h('div', { class: 'rm-more up' }, G.ico('chevron')));
  (snap.items || []).forEach((it, i) => list.appendChild(row(it, cb)));
  if (snap.down) list.appendChild(h('div', { class: 'rm-more dn' }, G.ico('chevron')));
  el.appendChild(list);
  if (t.show_desc && snap.desc) el.appendChild(h('div', { class: 'rm-desc' }, String(snap.desc)));
  return el;
}

function row(it, cb) {
  if (it.kind === 'separator') return h('div', { class: 'rm-sep' }, h('span', null, String(it.label || '')));
  const cls = 'rm-r' + (it.active ? ' on' : '') + (it.disabled ? ' off' : '');
  let right;
  if (it.kind === 'list') right = h('span', { class: 'rm-val' }, it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, -1); } : null }, '‹') : null, String(it.value || ''), it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, 1); } : null }, '›') : null);
  else if (it.kind === 'checkbox') right = h('span', { class: 'rm-chk' + (it.checked ? ' on' : '') }, h('i'));
  else if (it.kind === 'slider') { const p = it.max > it.min ? (it.value - it.min) / (it.max - it.min) * 100 : 0; right = h('span', { class: 'rm-sl' }, h('i', { style: { width: p + '%' } }), h('b', null, String(it.value))); }
  else if (it.kind === 'input') right = h('span', { class: 'rm-val' }, String(it.value || '…'));
  else right = null;
  const ev = cb ? { onmouseenter: () => { if (!it.active && !it.disabled) cb.hover(it.i); },
    onclick: (e) => { if (it.disabled) return; if (it.kind === 'list' || it.kind === 'slider') { const r = e.currentTarget.getBoundingClientRect(); cb.change(it.i, (e.clientX - r.left) < r.width / 2 ? -1 : 1); } else cb.select(it.i); } } : null;
  return h('div', Object.assign({ class: cls, 'data-i': it.i }, ev || {}), h('span', { class: 'rm-l' }, String(it.label || '')),
    it.right ? h('span', { class: 'rm-rt' }, String(it.right)) : null,
    it.badge ? h('span', { class: 'rm-bd' }, String(it.badge), h('i')) : null,
    right, (it.kind === 'button' || it.kind === 'submenu' || it.kind === 'list' && false) ? h('span', { class: 'rm-ic' }, G.ico(it.icon || 'chevron')) : null);
}
// Position / taille / opacité du menu staff réglées dans le panel (Interface > Menu de la librairie admin) : x et y sont le centre, en % de l'écran.
// x = milieu du menu, y = HAUT de la bannière (le haut reste fixe quand la liste s'allonge ou se raccourcit), en % de l'écran.
function staffTheme(theme, layIn, vw, vh) {
  const lay = layIn || (G.cfg && G.cfg.staffmenu);
  vw = vw || window.innerWidth; vh = vh || window.innerHeight;
  if (!lay || typeof lay !== 'object') return theme;
  const t = Object.assign({}, DEFAULTS, theme || {}), sc = num(lay.scale, 1, 0.6, 1.6);
  t.position = 'center';
  t.offset_x = Math.round((num(lay.x, 50, 0, 100) - 50) / 100 * vw);
  t.offset_y = Math.round((num(lay.y, 12, 0, 100) - 50) / 100 * vh);
  t.font_scale = num(t.font_scale, 100, 70, 160) * sc; t.width = num(t.width, 440, 280, 640) * sc; t.row_height = num(t.row_height, 44, 32, 72) * sc;
  t.opacity = Math.max(30, Math.round(num(t.opacity, 96, 40, 100) * num(lay.opacity, 1, 0.3, 1)));
  return t;
}
G.rmenu = { build, themeOf, DEFAULTS, staffTheme, restartBanner() { banFresh = true; } };

// ---- en jeu : la bibliothèque Lua envoie l'état à afficher, les touches sont lues côté Lua (pas de focus souris)
let host = null;
const box = () => host || (host = (function () { const e = h('div', { id: 'g-rmenu', class: 'hidden' }); G.root.appendChild(e); return e; })());
function draw(d, fresh) {
  const b = box(); G.clear(b);
  const m = build(d.staff ? staffTheme(d.theme || G.cfg.menus) : (d.theme || G.cfg.menus), d.menu, (G.cfg.brand && G.cfg.brand.name) || '');
  if (!fresh) m.classList.add('still');
  b.appendChild(m);
}
G.on('rmenu.open', (d) => { banFresh = true; box().classList.remove('hidden'); draw(d, true); });
G.on('rmenu.render', (d) => { if (host && !host.classList.contains('hidden')) draw(d); });
G.on('rmenu.close', () => { if (host) { G.clear(host); host.classList.add('hidden'); } });

// ---- aperçu du panel : même rendu, flèches / clic pour naviguer
G.preview.rmenu = function (host2, cfg, opts) {
  G.clear(host2);
  opts = opts || {};
  const items = opts.items || [
    { label: 'Mon Inventaire', desc: "Ouvre ton inventaire.", icon: 'bag' }, { label: 'Ma Tablette', desc: 'Ta tablette citoyen : finances, factures, entreprise.', icon: 'tablet' }, { label: 'Mon Portefeuille', desc: 'Espèces, banque et factures.', icon: 'card' },
    { label: 'Status des Entreprises', desc: 'Emploi, grade, service et caisse.', icon: 'building' }, { label: 'Mon VIP', badge: 'GOLD', desc: 'Avantages de ton abonnement.', icon: 'crown' }, { label: 'Mes Animaux', desc: 'Gère tes compagnons.', icon: 'paw' },
    { label: 'Accéder aux zone GunFight', desc: 'Permet de rentrer en zone GF.', icon: 'bolt' }, { label: 'Mes Paramètres', desc: 'Préférences personnelles.', icon: 'sliders' }];
  const title = opts.menuTitle || 'Voici votre menu personnel', subtitle = opts.subtitle || 'Votre ID est : 1 | Votre unique ID est : 1';
  let sel = opts.sel != null ? opts.sel : 6;
  const wrap = h('div', { class: 'rm-stage', tabindex: '0' });
  let render = function () {
    G.clear(wrap);
    const snap = { banner: { text: opts.bannerText || 'Menu personnel' }, title, subtitle, items: items.map((it, i) => Object.assign({ kind: 'button' }, it, { active: i === sel })), counter: [sel + 1, items.length], desc: items[sel].desc };
    const m = build(cfg, snap, (opts.brand || (G.cfg.brand && G.cfg.brand.name) || 'Shadow Base'));
    m.classList.add('static'); wrap.appendChild(m);
    m.querySelectorAll('.rm-r').forEach((r, i) => r.addEventListener('click', () => { sel = i; render(); }));
  };
  wrap.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { sel = (sel + 1) % items.length; render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = (sel + items.length - 1) % items.length; render(); e.preventDefault(); }
  });
  const stage = h('div', { class: 'gstage auto' }, wrap);
  // aperçu en entier même sur téléphone : le menu est réduit pour tenir dans la largeur disponible
  function fit() {
    const m = wrap.firstChild; if (!m) return;
    wrap.style.transform = ''; wrap.style.marginBottom = '';
    const avail = stage.clientWidth - 8, need = m.offsetWidth + 24;
    const k = need > avail && avail > 0 ? avail / need : 1;
    wrap.style.transformOrigin = 'top center'; wrap.style.transform = k < 1 ? 'scale(' + k + ')' : '';
    wrap.style.marginBottom = k < 1 ? (-(wrap.offsetHeight) * (1 - k)) + 'px' : '';
  }
  render(); host2.appendChild(stage);
  requestAnimationFrame(fit); if (window.ResizeObserver) new ResizeObserver(fit).observe(stage);
  const r0 = render; render = function () { r0(); fit(); };
};
G.preview.quick = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu police', menuTitle: 'Actions rapides', subtitle: 'Police · Officier · En service', sel: 2, items: [
    { kind: 'separator', label: 'Police · Officier' }, { label: 'Cible', kind: 'list', value: 'Alex Martin (#12)', desc: 'Joueur proche sur lequel agiront les actions ci-dessous.' },
    { label: 'En service', kind: 'checkbox', checked: true, desc: 'Prends ou quitte ton service.' }, { label: 'Menotter', icon: 'lock', desc: 'Menotte la personne ciblée, tout près de toi.' },
    { label: 'Fouiller', icon: 'search', desc: 'Fouille une personne menottée.' }, { label: 'Amende', kind: 'submenu', icon: 'tag', desc: "Choisis l'infraction du catalogue." },
    { label: 'Facturer', icon: 'card', desc: 'Envoie une facture à la personne ciblée.' }, { label: 'Ouvrir la tablette', icon: 'tablet', desc: 'Tableau de bord complet de ton entreprise.' }] });
};
G.preview.staff = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu admin', menuTitle: 'Menu staff', subtitle: 'Administrateur · en service', sel: 3, items: [
    { kind: 'separator', label: 'Administrateur · en service' }, { label: 'Prendre mon service', kind: 'checkbox', checked: true, icon: 'bolt', desc: 'Obligatoire pour utiliser les outils.' },
    { label: 'Gestion des joueurs (12)', kind: 'submenu', icon: 'users', desc: 'Infos, téléportation, soins, argent, sanctions.' }, { label: 'Gestion personnelle', kind: 'submenu', icon: 'bolt', desc: 'Noclip, invincibilité, invisibilité, noms.' },
    { label: 'Gestion des véhicules', kind: 'submenu', icon: 'engine', desc: 'Créer, réparer, supprimer.' }, { label: 'Gestion du serveur', kind: 'submenu', icon: 'globe', desc: 'Annonces, météo, heure, maintenance.' },
    { label: 'Gestion des reports (2)', kind: 'submenu', icon: 'help', desc: 'Les demandes des joueurs.' }, { label: 'Gestion des sanctions', kind: 'submenu', icon: 'shield', desc: 'Lever un bannissement.' },
    { label: 'Options supplémentaires', icon: 'sliders', desc: 'Ouvre le panel de configuration (propriétaire).' }, { label: 'Réorganiser ce menu', kind: 'submenu', icon: 'sliders', desc: 'Change l\'ordre des entrées.' }] });
};
G.preview.fuel = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu station', menuTitle: 'Station Mirror Park', subtitle: '3 $ le litre · il manque 41 L', sel: 1, items: [
    { label: 'Un peu — 10 L', right: '≈ 30 $', desc: 'Ajoute 10 litres.' }, { label: 'Moyen — 25 L', right: '≈ 75 $' }, { label: 'Faire le plein — 41 L', right: '≈ 123 $' }] });
};
G.preview.mech = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu atelier', menuTitle: 'Atelier', subtitle: 'PB 4821', sel: 2, items: [
    { kind: 'separator', label: 'Garage Benny · caisse 18 400 $' }, { label: 'Réparation complète', right: '150 $', desc: 'Carrosserie, moteur, pneus et propreté.' }, { label: 'Moteur', kind: 'submenu' }, { label: 'Freins', kind: 'submenu' },
    { label: 'Transmission', kind: 'submenu' }, { label: 'Suspension', kind: 'submenu' }, { label: 'Blindage', kind: 'submenu' }, { label: 'Turbo', kind: 'submenu' }, { label: 'Vitres teintées', kind: 'submenu' }, { label: 'Peinture', kind: 'submenu' }] });
};
})();
