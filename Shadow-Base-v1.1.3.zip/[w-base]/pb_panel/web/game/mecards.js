/* Menu personnel en grandes cartes : image de fond (GTA) teintée par la couleur de la carte ou du serveur.
   Tout texte reçu est inséré avec textContent ; les images ne sont choisies que parmi des clés [a-z0-9_]. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const keyOk = (k) => typeof k === 'string' && /^[a-z0-9_]{1,24}$/.test(k);
const imgSrc = (k) => keyOk(k) ? ((G.cardImgs && G.cardImgs[k]) || ('img/cards/' + k + '.jpg')) : '';
const hex = (c, d) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : d);

function view(data, opts) {
  opts = opts || {};
  const brand = (opts.brand || G.cfg.brand || {});
  const server = hex(brand.color, '#dfe2e7');
  const server2 = hex(brand.color2, '#8e95a1');
  const strength = Math.max(15, Math.min(90, Number(data.strength) || 55)) / 100;
  const root = h('div', { class: 'mc' + (opts.static ? ' static' : ''), style: { '--srv': server, '--srvr': G.hexToRgb(server), '--srv2': server2 } });
  let detail = null, detailBox = h('div', { class: 'mc-detail hidden' });

  const head = h('div', { class: 'mc-head' },
    h('div', { class: 'mc-hl' }, h('h1', null, String(data.title || 'Voici votre menu personnel')), h('p', null, String(data.subtitle || '') + (data.name ? ' · ' + data.name : ''))),
    h('div', { class: 'mc-hr' },
      h('span', { class: 'mc-pill' }, G.ico('wallet', 'mc-pi'), h('b', null, G.money(data.cash)), h('small', null, 'Espèces')),
      h('span', { class: 'mc-pill' }, G.ico('card', 'mc-pi'), h('b', null, G.money(data.bank)), h('small', null, 'Banque')),
      opts.onClose ? h('button', { class: 'mc-x', type: 'button', 'aria-label': 'Fermer', onclick: opts.onClose }, G.ico('close')) : null));
  root.appendChild(head);

  const grid = h('div', { class: 'mc-grid' });
  (data.entries || []).forEach((e) => {
    const tone = data.tint === 'server' ? server : hex(e.tone, server);
    const src = imgSrc(e.img);
    const card = h('button', { type: 'button', class: 'mc-card' + (e.disabled ? ' off' : ''), style: { '--tone': tone, '--tr': G.hexToRgb(tone), '--is': strength } },
      src ? h('i', { class: 'mc-img', style: { backgroundImage: 'url("' + src + '")' } }) : h('i', { class: 'mc-img none' }),
      h('i', { class: 'mc-shade' }),
      h('span', { class: 'mc-ic' }, G.ico(e.icon || 'star')),
      e.badge ? h('span', { class: 'mc-bd' }, h('i'), String(e.badge)) : null,
      h('span', { class: 'mc-tx' }, h('small', null, String(e.sub || '')), e.value != null ? h('strong', null, String(e.value)) : null, h('b', null, String(e.label || ''))));
    card.addEventListener('click', () => {
      if (e.disabled) return;
      if (e.list || e.id === 'settings') { showDetail(e); return; }
      if (opts.onAct) opts.onAct(e);
    });
    grid.appendChild(card);
  });
  root.appendChild(grid);
  root.appendChild(detailBox);

  // Un clic sur une carte ouvre sa propre page (la grille est remplacée) avec un bouton Retour.
  function closeDetail() { detail = null; detailBox.classList.add('hidden'); grid.classList.remove('hidden'); G.clear(detailBox); }
  function showDetail(e) {
    detail = e.id; G.clear(detailBox); detailBox.classList.remove('hidden'); grid.classList.add('hidden');
    detailBox.style.setProperty('--tone', data.tint === 'server' ? server : hex(e.tone, server));
    detailBox.appendChild(h('div', { class: 'mc-dh' },
      h('button', { type: 'button', class: 'mc-back', onclick: closeDetail }, G.ico('chevron'), 'Retour'),
      h('span', { class: 'mc-dic' }, G.ico(e.icon || 'star')),
      h('div', null, h('h3', null, String(e.label)), e.sub ? h('p', null, String(e.sub)) : null)));
    const body = h('div', { class: 'mc-dg' });
    if (e.id === 'settings') {
      const cur = (opts.mode || data.mode || 'cards');
      body.appendChild(h('div', { class: 'mc-ds' }, h('p', null, data.allow_choice === false ? 'Le serveur impose cet affichage.' : "Choisis l'affichage de ce menu (mémorisé sur ton poste)."),
        h('div', { class: 'mc-seg' }, [['cards', 'Grandes cartes'], ['lib', 'Menu RageUI (flèches + Entrée)']].map(([m, l]) => h('button', { type: 'button', class: 'mc-sb' + (cur === m ? ' on' : ''), disabled: data.allow_choice === false || null, onclick: () => { if (opts.onMode) opts.onMode(m); } }, l)))));
    } else {
      const list = e.list || [];
      if (!list.length) body.appendChild(h('div', { class: 'mc-ds' }, h('p', null, 'Rien à afficher pour le moment.')));
      list.forEach((x) => body.appendChild(h('div', { class: 'mc-li' + (x.gps ? ' gps' : ''), title: x.gps ? 'Mettre le GPS' : null, onclick: x.gps ? () => G.post('me.gps', { ref: x.gps }) : null }, h('span', null, String(x.label || '')), h('em', null, String(x.plate || x.kind || '')), x.state ? h('b', null, String(x.state)) : null, x.gps ? h('i', { class: 'mc-gps' }, G.ico('pin')) : null)));
    }
    detailBox.appendChild(body);
  }
  return { el: root };
}

G.mecards = { view };

let host = null;
const box = () => host || (host = (function () { const e = h('div', { id: 'g-me', class: 'hidden' }); G.root.appendChild(e); return e; })());
G.on('me.open', (d) => {
  const b = box(); G.clear(b); b.classList.remove('hidden');
  const v = view(d.data || {}, { brand: d.brand, mode: d.mode, onClose: () => G.post('me.close', {}), onAct: (e) => G.post('me.act', { id: e.id, cmd: e.cmd }), onMode: (m) => G.post('me.mode', { mode: m }) });
  b.appendChild(v.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'me'); G.uiStack.push({ id: 'me', onEscape: () => G.post('me.close', {}) });
});
G.on('me.close', () => { if (host) { G.clear(host); host.classList.add('hidden'); } G.uiStack = G.uiStack.filter((u) => u.id !== 'me'); });

// ---- aperçu du panel : mise à l'échelle pour tenir dans la largeur (téléphone compris)
const SAMPLE = {
  title: 'Voici votre menu personnel', subtitle: 'Votre ID est : 1', name: 'Alex Martin', cash: 1250, bank: 48200, tint: 'card', strength: 55, mode: 'cards', allow_choice: true,
  entries: [
    { id: 'inventory', label: 'Mon inventaire', icon: 'bag', img: 'inv', tone: '#dfe2e7', sub: 'Sac et raccourcis' },
    { id: 'tablet', label: 'Ma tablette', icon: 'tablet', img: 'sky', tone: '#6fb4ff', sub: 'Finances et entreprise', badge: '2 à régler' },
    { id: 'wallet', label: 'Mon portefeuille', icon: 'wallet', img: 'wallet', tone: '#7be0a4', value: '$49 450', sub: 'Espèces $1 250 · Banque $48 200' },
    { id: 'company', label: 'Mon entreprise', icon: 'building', img: 'city', tone: '#ffb457', value: 'Police', sub: 'Officier · En service', badge: 'EN SERVICE' },
    { id: 'vehicles', label: 'Mes véhicules', icon: 'engine', img: 'veh', tone: '#ff6b7d', value: '3', sub: 'véhicules', list: [{ label: 'Karin Sultan', plate: 'AB 123 CD', state: 'Au garage' }, { label: 'Pegassi Zentorno', plate: 'ZX 777 TT', state: 'Dehors' }, { label: 'Dinka Blista', plate: 'KL 042 MN', state: 'Fourrière' }] },
    { id: 'properties', label: 'Mes propriétés', icon: 'home', img: 'sea', tone: '#5fd0d0', value: '1', sub: 'logement', list: [{ label: 'Appartement Tinsel Towers', kind: 'Propriété' }] },
    { id: 'phone', label: 'Mon téléphone', icon: 'phone', img: 'sky', tone: '#dfe2e7', value: '555-0123', sub: '3 messages non lus', badge: '3' },
    { id: 'settings', label: 'Mes paramètres', icon: 'sliders', tone: '#8d939e', sub: 'Affichage du menu' }] };
G.preview.personal = function (box2, cfg) {
  G.clear(box2);
  const p = (cfg && cfg.personal) || {};
  const data = Object.assign({}, SAMPLE, { title: p.title || SAMPLE.title, tint: p.tint || 'card', strength: p.image_strength != null ? p.image_strength : 55, mode: p.mode || 'cards', allow_choice: p.allow_choice !== false });
  const show = { inventory: 'show_inventory', tablet: 'show_tablet', wallet: 'show_wallet', company: 'show_company', vehicles: 'show_vehicles', properties: 'show_properties', phone: 'show_phone', settings: 'show_settings' };
  data.entries = SAMPLE.entries.filter((e) => p[show[e.id]] !== false);
  const v = view(data, { static: true });
  const DW = 1180;
  const wrap = h('div', { class: 'mc-fit', style: { width: DW + 'px' } }, v.el);
  const stage = h('div', { class: 'gstage auto mc-stage' }, wrap);
  box2.appendChild(stage);
  function fit() {
    const avail = stage.clientWidth - 8; if (avail <= 0) return;
    const k = Math.min(1, avail / DW);
    wrap.style.transformOrigin = 'top left'; wrap.style.transform = k < 1 ? 'scale(' + k + ')' : '';
    wrap.style.marginLeft = k < 1 ? '4px' : 'auto'; wrap.style.marginRight = k < 1 ? '0' : 'auto';
    wrap.style.marginBottom = k < 1 ? (-(wrap.offsetHeight) * (1 - k)) + 'px' : '';
  }
  requestAnimationFrame(fit); if (window.ResizeObserver) new ResizeObserver(fit).observe(stage);
};
})();
