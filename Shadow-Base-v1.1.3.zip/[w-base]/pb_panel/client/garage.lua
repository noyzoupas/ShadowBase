-- Garages et fourrière : blips, marqueurs, menu (E à pied), rangement (E en véhicule), apparition des véhicules, verrouillage (touche réglable).
local G = PBG
local isOpen = false
local points, blips = {}, {}
local locked = {}

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if not isOpen then return end
    isOpen = false
    TriggerServerEvent('pb:g:garage:close')
    G.focus(false)
    G.send('garage.close', {})
end

RegisterNetEvent('pb:g:garage:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then TriggerServerEvent('pb:g:garage:close') return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('garage.' .. tostring(d.ev), d)
end)
G.nui['garage.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:garage:page', tostring(d.page or 'cars')) end return {} end
G.nui['garage.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:garage:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'cars')) end return {} end
G.nui['garage.close'] = function() close() return {} end

local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', '') end

local function props(veh)
    local c1, c2 = GetVehicleColours(veh)
    if G.VehProps then return G.VehProps(veh) end
    local fuel = GetVehicleFuelLevel and GetVehicleFuelLevel(veh) or 100.0
    return { eh = GetVehicleEngineHealth(veh), bh = GetVehicleBodyHealth(veh), th = GetVehiclePetrolTankHealth(veh), fuel = fuel, c1 = c1, c2 = c2, dirt = GetVehicleDirtLevel(veh) }
end

RegisterNetEvent('pb:g:veh:spawn', function(j)
    local d = G.decode(j)
    if not d then return end
    local hash = GetHashKey(d.model)
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then return end
    RequestModel(hash)
    local t = GetGameTimer()
    while not HasModelLoaded(hash) and GetGameTimer() - t < 8000 do Wait(10) end
    if not HasModelLoaded(hash) then return end
    local sp = d.spawn or {}
    local veh = CreateVehicle(hash, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, (sp.h or 0) + 0.0, true, false)
    SetVehicleNumberPlateText(veh, d.plate)
    SetVehicleOnGroundProperly(veh)
    local p = d.props
    if p then
        if p.c1 and p.c2 then SetVehicleColours(veh, math.floor(p.c1), math.floor(p.c2)) end
        if p.eh then SetVehicleEngineHealth(veh, p.eh + 0.0) end
        if p.bh then SetVehicleBodyHealth(veh, p.bh + 0.0) end
        if p.th then SetVehiclePetrolTankHealth(veh, p.th + 0.0) end
        if p.fuel and SetVehicleFuelLevel then SetVehicleFuelLevel(veh, p.fuel + 0.0) end
        if p.dirt then SetVehicleDirtLevel(veh, p.dirt + 0.0) end
        if G.ApplyMods and type(p.mods) == 'table' then G.ApplyMods(veh, p.mods) end
        if G.ApplyDamage then G.ApplyDamage(veh, p) end
    end
    SetModelAsNoLongerNeeded(hash)
    SetPedIntoVehicle(PlayerPedId(), veh, -1)
    TriggerServerEvent('pb:g:veh:spawned', d.plate, NetworkGetNetworkIdFromEntity(veh))
    close()
end)
RegisterNetEvent('pb:g:veh:stored', function(plate)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and plateOf(veh) == plate then TaskLeaveVehicle(ped, veh, 0) Wait(900) SetEntityAsMissionEntity(veh, true, true) DeleteVehicle(veh) end
end)

-- Verrouillage
RegisterNetEvent('pb:g:veh:lockState', function(j)
    local d = G.decode(j)
    if not d then return end
    locked[d.plate] = d.locked
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local veh = GetClosestVehicle(c.x, c.y, c.z, 60.0, 0, 71)
    if veh ~= 0 and plateOf(veh) == d.plate then
        SetVehicleDoorsLocked(veh, d.locked and 2 or 1)
        SetVehicleDoorsLockedForAllPlayers(veh, d.locked)
        StartVehicleHorn(veh, 80, GetHashKey('HELDDOWN'), false)
        SetVehicleLights(veh, 2) Wait(180) SetVehicleLights(veh, 0)
    end
end)
RegisterCommand('pb_lock', function()
    if busy() or not G.begun then return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    local c = GetEntityCoords(ped)
    if veh == 0 then veh = GetClosestVehicle(c.x, c.y, c.z, (G.cfg.garage and G.cfg.garage.lock_dist or 6) + 0.0, 0, 71) end
    if veh ~= 0 then TriggerServerEvent('pb:g:veh:lock', plateOf(veh), NetworkGetNetworkIdFromEntity(veh)) end
end, false)

local prev = G.onCfg
local allPoints, myGang, lastCfg = {}, '', nil
-- Les garages de gang ne sont visibles (blip, marqueur, touche E) que par les membres du gang concerné
local function rebuild(c)
    points = {}
    for _, p in ipairs(allPoints) do if p.kind ~= 'gang' or (p.gang and p.gang == myGang) then points[#points + 1] = p end end
    -- gardien à chaque garage public et à chaque fourrière (modèles réglables dans la configuration des garages)
    local gc, npcs = (c and c.garage) or {}, {}
    if gc.npc ~= false then
        for _, p in ipairs(points) do
            local m = p.kind == 'impound' and (gc.npc_impound or 'a_m_m_hasjew_01') or p.kind == 'public' and (gc.npc_public or 'a_m_y_business_02') or nil
            if m then npcs[#npcs + 1] = { id = p.id, model = m, x = p.x, y = p.y, z = p.z, h = p.h, ghost = true } end
        end
    end
    G.Npcs('garages', npcs)
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (c and c.garage and c.garage.blips) then return end
    for _, p in ipairs(points) do
        if p.kind == 'biz' then goto skip end   -- garage d'entreprise : pas de repère public (les employés connaissent l'adresse)
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(b, p.kind == 'impound' and 68 or 357) SetBlipColour(b, p.kind == 'impound' and 17 or 3) SetBlipScale(b, 0.8) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
        ::skip::
    end
end
G.onCfg = function(c)
    if prev then prev(c) end
    allPoints, lastCfg = c.garage_points or {}, c
    rebuild(c)
end
RegisterNetEvent('pb:g:mygang', function(id) myGang = tostring(id or '') rebuild(lastCfg) end)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.garage and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_lock', 'Verrouiller / déverrouiller le véhicule', 'keyboard', (G.cfg.garage and G.cfg.garage.lock_key) or 'L')
    while not G.begun do Wait(1000) end
    TriggerServerEvent('pb:g:veh:needLocks')
end)

CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or busy() or isOpen or #points == 0 then hide() Wait(700)
        else
            local gc = G.cfg.garage or {}
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd = nil, 1e9
            for _, p in ipairs(points) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd = p, d end end
            if best and bd <= 15.0 then
                local inVeh = IsPedInAnyVehicle(ped, false)
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, best.kind == 'impound' and 255 or 111, 180, best.kind == 'impound' and 87 or 255, 1.8)
                local reach = inVeh and (gc.store_dist or 25.0) * 0.4 or (gc.use_distance or 2.5)
                if bd <= reach then
                    local txt = inVeh and (best.kind == 'impound' and nil or ('Ranger le véhicule : ' .. best.label)) or ((best.kind == 'impound' and 'Fourrière : ' or 'Garage : ') .. best.label)
                    if txt then
                        if not shown or key ~= best.id .. (inVeh and 'v' or 'p') then shown, key = true, best.id .. (inVeh and 'v' or 'p') G.send('prompt', { show = true, key = 'E', text = txt }) end
                        if IsControlJustPressed(0, 38) then
                            if inVeh then
                                local veh = GetVehiclePedIsIn(ped, false)
                                if GetPedInVehicleSeat(veh, -1) == ped then TriggerServerEvent('pb:g:garage:store', best.id, plateOf(veh), props(veh), NetworkGetNetworkIdFromEntity(veh)) end
                            else TriggerServerEvent('pb:g:garage:open', best.id) end
                        end
                    else hide() end
                else hide() end
                Wait(0)
            else hide() Wait(500) end
        end
    end
end)

CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
