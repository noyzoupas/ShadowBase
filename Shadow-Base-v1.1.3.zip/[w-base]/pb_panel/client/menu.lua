-- Menu « RageUI » : navigation aux flèches / manette (sans souris), rendu dans l'interface NUI, exports pour d'autres scripts.
-- La logique (éléments, sous-menus, listes, curseurs) est dans client/lib/menu_core.lua ; ici on lit les touches et on parle à l'interface.
local G = PBG
local Core = PBMenuCore
local stack = Core.NewStack({ maxVisible = 10, wrap = true })
local rep = Core.NewRepeater(380, 85)
local running = false
local rootId = ''
local uiOn, uiFocus = false, false     -- affichage « UI » (souris) au lieu de « lib » (flèches)
local askBox = nil

-- Mode d'affichage d'un menu : choix du joueur (si permis) > règle par menu (« id|ui ») > réglage global > mode demandé par le script
local function modeFor(def)
    local c = (G.cfg and G.cfg.menus) or {}
    local m = (type(def) == 'table' and (def.mode == 'ui' or def.mode == 'lib')) and def.mode or 'lib'
    if c.ui_mode == 'ui' or c.ui_mode == 'lib' then m = c.ui_mode end
    local id = type(def) == 'table' and tostring(def.id or '') or ''
    local best = -1
    for _, line in ipairs(c.ui_overrides or {}) do
        local pre, md = tostring(line):match('^([%w_%.%-]+)|(%a+)$')
        if pre and (md == 'ui' or md == 'lib') and (id == pre or id:sub(1, #pre + 1) == pre .. '.') and #pre > best then m = md best = #pre end
    end
    if c.ui_allow_choice ~= false then
        local v = GetResourceKvpString('pb_menu_style')
        if v == 'ui' or v == 'lib' then m = v end
    end
    return m
end

local function mcfg() return (G.cfg and G.cfg.menus) or {} end
local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen() and not G.barberOpen) end   -- le coiffeur utilise ce menu

local function sound(kind)
    if mcfg().sounds == false or not kind then return end
    if kind == 'nav' then PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    elseif kind == 'select' then PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    elseif kind == 'back' then PlaySoundFrontend(-1, 'BACK', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    elseif kind == 'change' then PlaySoundFrontend(-1, 'NAV_LEFT_RIGHT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    elseif kind == 'error' then PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
end

local function push(ev)
    if uiOn then
        local snap = stack:Full()
        if not snap then G.send('umenu.close', {}) return end
        G.send((ev == 'rmenu.open') and 'umenu.open' or 'umenu.render', { menu = snap, brand = G.cfg and G.cfg.brand, staff = rootId:sub(1, 5) == 'staff' })
        return
    end
    local snap = stack:Snapshot()
    if not snap then G.send('rmenu.close', {}) return end
    G.send(ev or 'rmenu.render', { menu = snap, staff = rootId:sub(1, 5) == 'staff' })
end

-- Accepte askText(item) avec item = { prompt, label, value, maxlen } ou askText(libellé, valeur par défaut, longueur max)
local function askText(item, default, maxlen)
    if type(item) ~= 'table' then item = { prompt = item, value = default, maxlen = maxlen } end
    if uiOn then
        askBox = { done = false, text = nil }
        G.send('umenu.ask', { prompt = tostring(item.prompt or item.label or 'Saisie'), value = tostring(item.value or ''), maxlen = tonumber(item.maxlen) or 120 })
        local box = askBox
        local t = GetGameTimer() + 120000
        while not box.done and GetGameTimer() < t and uiOn do Wait(50) end
        askBox = nil
        return box.text
    end
    AddTextEntry('PB_MENU_INPUT', tostring(item.prompt or item.label or 'Saisie'))
    DisplayOnscreenKeyboard(1, 'PB_MENU_INPUT', '', tostring(item.value or ''), '', '', '', tonumber(item.maxlen) or 120)
    while UpdateOnscreenKeyboard() == 0 do DisableAllControlActions(0) Wait(0) end
    if UpdateOnscreenKeyboard() == 1 then return GetOnscreenKeyboardResult() end
    return nil
end

local function closeAll()
    if not stack:IsOpen() then return end
    stack:Close()
    if uiOn then
        G.send('umenu.close', {})
        if uiFocus then uiFocus = false G.focus(false) end
        uiOn = false
    else
        G.send('rmenu.close', {})
    end
end

local BLOCK = { 172, 173, 174, 175, 176, 177, 199, 200, 201, 202, 24, 25, 140, 141, 142, 143, 257, 263, 264 }

local function loop()
    if running then return end
    running = true
    CreateThread(function()
        while stack:IsOpen() do
            Wait(0)
            if busy() then closeAll() break end
            if uiOn then goto continue end
            for i = 1, #BLOCK do DisableControlAction(0, BLOCK[i], true) end
            local c = mcfg()
            local now = GetGameTimer()
            local dirty = false
            local function press(id) return IsDisabledControlPressed(0, id) end
            do
                local first, every = tonumber(c.repeat_first) or 380, tonumber(c.repeat_every) or 85
                if rep('up', press(172), now, first, every) then sound(stack:Move(-1)) dirty = true
                elseif rep('down', press(173), now, first, every) then sound(stack:Move(1)) dirty = true
                elseif rep('left', press(174), now, first, every) then sound(stack:Change(-1)) dirty = true
                elseif rep('right', press(175), now, first, every) then sound(stack:Change(1)) dirty = true end
            end
            if IsDisabledControlJustPressed(0, 201) then
                local snd, req = stack:Select()
                sound(snd)
                if req and req.input then
                    local text = askText(req.input)
                    sound(stack:SetInput(req.input, text))
                end
                dirty = true
            elseif IsDisabledControlJustPressed(0, 202) or IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 200) then
                sound(stack:Back())
                if not stack:IsOpen() then G.send('rmenu.close', {}) break end
                dirty = true
            end
            if dirty and stack:IsOpen() then push() end
            ::continue::
        end
        running = false
    end)
end

local function open(def)
    if type(def) ~= 'table' or busy() then return false end
    local c = mcfg()
    stack.maxVisible = tonumber(c.max_visible) or 10
    stack.wrap = c.wrap ~= false
    if stack:IsOpen() then closeAll() end
    if not stack:Open(def) then return false end
    rootId = tostring(def.id or '')
    uiOn = modeFor(def) == 'ui'
    if uiOn then uiFocus = true G.focus(true) end
    push('rmenu.open')
    sound('select')
    loop()
    return true
end

-- Ordre personnalisable : l'ordre choisi par le joueur est mémorisé sur son poste (KVP), `default` vient du panel.
local function loadOrder(key)
    local v = GetResourceKvpString('pb_order_' .. key)
    if v and v ~= '' then local ok, t = pcall(json.decode, v) if ok and type(t) == 'table' then return t end end
    return nil
end
local function saveOrder(key, ids) SetResourceKvp('pb_order_' .. key, json.encode(ids)) end
local function sortedItems(key, items, default) return Core.SortItems(items, loadOrder(key) or default) end
-- Élément « Réorganiser ce menu » : getItems() renvoie les éléments (avec `id`) tels qu'ils sont proposés.
local function orderEntry(key, getItems, default)
    local function current()
        local items = sortedItems(key, getItems(), default)
        local ids, label = {}, {}
        for _, it in ipairs(items) do if it.id and not it.hidden then ids[#ids + 1] = it.id label[it.id] = it.label end end
        return ids, label
    end
    local function moveItem(id, label)
        local function mv(how, text) return { label = text, onSelect = function() local ids = current() saveOrder(key, Core.MoveId(ids, id, how)) G.Menu.Refresh() end } end
        return { id = key .. '.order.' .. id, title = label, subtitle = 'Déplacer cet élément', refreshOnReturn = true, items = {
            mv('top', 'Tout en haut'), mv('up', 'Monter'), mv('down', 'Descendre'), mv('bottom', 'Tout en bas') } }
    end
    return { type = 'submenu', label = 'Réorganiser ce menu', icon = 'sliders', description = "Choisis un élément puis déplace-le. Réglage personnel, mémorisé sur ton poste.",
        submenu = { id = key .. '.order', title = 'Réorganiser', subtitle = 'Ton ordre personnel', refreshOnReturn = true, build = function()
            local ids, label = current()
            local out = {}
            for pos, id in ipairs(ids) do out[#out + 1] = { type = 'submenu', label = label[id] or id, right = pos .. ' / ' .. #ids, submenu = moveItem(id, label[id] or id) } end
            out[#out + 1] = { type = 'button', label = "Remettre l'ordre d'origine", description = "Retrouve l'ordre choisi par le serveur.", onSelect = function() DeleteResourceKvp('pb_order_' .. key) G.Menu.Refresh() end }
            return out
        end } }
end

G.Menu = { Sorted = sortedItems, OrderEntry = orderEntry, Ask = askText, Open = open, Close = closeAll, IsOpen = function() return stack:IsOpen() end, Refresh = function() if stack:IsOpen() then stack:Rebuild() push() end end, Stack = stack }

-- Rendu « UI » : la souris envoie l'indice de la ligne ; la logique reste celle de la pile (aucune règle dupliquée)
local function afterUi()
    if stack:IsOpen() then push() return end
    if uiOn then
        G.send('umenu.close', {})
        if uiFocus then uiFocus = false G.focus(false) end
        uiOn = false
    end
end
G.nui['umenu.select'] = function(d)
    if not uiOn or not stack:IsOpen() or not stack:SetSel(d.i) then return {} end
    stack:Select()
    afterUi()
    return {}
end
G.nui['umenu.hover'] = function(d)
    if not uiOn or not stack:IsOpen() then return {} end
    if stack:SetSel(d.i) then afterUi() end
    return {}
end
G.nui['umenu.change'] = function(d)
    if not uiOn or not stack:IsOpen() or not stack:SetSel(d.i) then return {} end
    stack:Change(tonumber(d.dir) == -1 and -1 or 1)
    afterUi()
    return {}
end
G.nui['umenu.input'] = function(d)
    if not uiOn or not stack:IsOpen() or not stack:SetSel(d.i) then return {} end
    local m = stack:Current()
    local it = m and m.items[math.floor(tonumber(d.i) or 0)]
    if it and it.type == 'input' and type(d.text) == 'string' then stack:SetInput(it, d.text) end
    afterUi()
    return {}
end
G.nui['umenu.move'] = function(d)
    if not uiOn or not stack:IsOpen() then return {} end
    stack:Move(tonumber(d.dir) == -1 and -1 or 1)
    afterUi()
    return {}
end
G.nui['umenu.close'] = function() if uiOn then closeAll() end return {} end
G.nui['umenu.back'] = function()
    if not uiOn or not stack:IsOpen() then return {} end
    stack:Back()
    afterUi()
    return {}
end
G.nui['umenu.asked'] = function(d)
    if askBox then askBox.text = (type(d.text) == 'string') and d.text or nil askBox.done = true end
    return {}
end

-- Le joueur change de style (si le serveur le permet) : « ui » (souris) ou « lib » (flèches)
local function switchStyle(to)
    if (G.cfg.menus or {}).ui_allow_choice == false then return false end
    SetResourceKvp('pb_menu_style', to)
    if not stack:IsOpen() then return true end
    local want = to == 'ui'
    if want == uiOn then return true end
    if uiOn then G.send('umenu.close', {}) if uiFocus then uiFocus = false G.focus(false) end else G.send('rmenu.close', {}) end
    uiOn = want
    if uiOn then uiFocus = true G.focus(true) end
    push('rmenu.open')
    return true
end
G.nui['umenu.style'] = function(d) switchStyle(d.style == 'ui' and 'ui' or 'lib') return {} end
RegisterCommand('menustyle', function()
    if (G.cfg.menus or {}).ui_allow_choice == false then G.send('notify', { type = 'warn', title = 'Menus', text = "Le serveur impose le style des menus." }) return end
    local cur = GetResourceKvpString('pb_menu_style')
    local to = (cur == 'ui' or (cur ~= 'lib' and uiOn)) and 'lib' or 'ui'
    switchStyle(to)
    G.send('notify', { type = 'info', title = 'Menus', text = to == 'ui' and 'Style : interface (souris).' or 'Style : flèches + Entrée.' })
end, false)
G.Menu.SwitchStyle = switchStyle
G.Menu.Style = function() return uiOn and 'ui' or 'lib' end

exports('OpenMenu', function(def) return open(def) end)
exports('CloseMenu', function() closeAll() end)
exports('IsMenuOpen', function() return stack:IsOpen() end)
exports('RefreshMenu', function() G.Menu.Refresh() end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and stack:IsOpen() then closeAll() end end)
