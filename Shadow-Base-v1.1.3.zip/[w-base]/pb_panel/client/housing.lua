-- Logements : blips, marqueur et invite (E) devant la porte, menu, ouverture du coffre, entrée / sortie sur ordre du serveur.
local G = PBG
local isOpen = false
local points, blips = {}, {}
local inside = nil   -- { id } quand le joueur est dans un intérieur configuré

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if not isOpen then return end
    isOpen = false
    TriggerServerEvent('pb:g:housing:close')
    G.focus(false)
    G.send('housing.close', {})
end

RegisterNetEvent('pb:g:housing:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then TriggerServerEvent('pb:g:housing:close') return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('housing.' .. tostring(d.ev), d)
end)
G.nui['housing.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:housing:page', tostring(d.page or 'home')) end return {} end
G.nui['housing.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:housing:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end return {} end
G.nui['housing.close'] = function() close() return {} end

-- Le coffre s'ouvre dans la fenêtre d'inventaire
RegisterNetEvent('pb:g:housing:stash', function(owner)
    close()
    Wait(150)
    TriggerServerEvent('pb:g:inv:open', tostring(owner))
end)

RegisterNetEvent('pb:g:housing:teleport', function(j)
    local d = G.decode(j)
    if not d then return end
    local ped = PlayerPedId()
    DoScreenFadeOut(400)
    while not IsScreenFadedOut() do Wait(20) end
    close()
    RequestCollisionAtCoord(d.x + 0.0, d.y + 0.0, d.z + 0.0)
    SetEntityCoords(ped, d.x + 0.0, d.y + 0.0, d.z + 0.0, false, false, false, false)
    if d.h then SetEntityHeading(ped, d.h + 0.0) end
    local t = GetGameTimer()
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 4000 do Wait(20) end
    inside = d.exit and nil or { id = d.id, label = d.label }
    DoScreenFadeIn(400)
end)

local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    points = c.housing_points or {}
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (c.housing and c.housing.blips) then return end
    for _, p in ipairs(points) do
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(b, 40) SetBlipColour(b, p.free and 2 or 1) SetBlipScale(b, 0.7) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end

CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or busy() or isOpen then hide() Wait(700)
        elseif inside then
            -- à l'intérieur : E pour sortir (le serveur vérifie les droits)
            if not shown or key ~= 'out' then shown, key = true, 'out' G.send('prompt', { show = true, key = 'E', text = 'Sortir : ' .. tostring(inside.label) }) end
            if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:housing:exit', inside.id) end
            Wait(0)
        elseif #points == 0 then hide() Wait(1000)
        else
            local hc = G.cfg.housing or {}
            local c = GetEntityCoords(PlayerPedId())
            local best, bd = nil, 1e9
            for _, p in ipairs(points) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd = p, d end end
            if best and bd <= 12.0 and not IsPedInAnyVehicle(PlayerPedId(), false) then
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
                if bd <= (hc.use_distance or 2.5) then
                    if not shown or key ~= best.id then shown, key = true, best.id G.send('prompt', { show = true, key = 'E', text = best.label }) end
                    if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:housing:open', best.id) end
                else hide() end
                Wait(0)
            else hide() Wait(500) end
        end
    end
end)

CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
