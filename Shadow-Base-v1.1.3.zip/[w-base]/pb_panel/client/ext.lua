-- Extensions (côté client) : affichages communs de Shadow Base utilisables par une autre ressource, pour garder le même style partout.
--   exports.pb_panel:Prompt('Couper du bois', 'E')  /  exports.pb_panel:HidePrompt()
--   exports.pb_panel:Progress('Coupe du bois', 6)    /  exports.pb_panel:CancelProgress()
--   exports.pb_panel:Marker(x, y, z)                 (à appeler à chaque image, comme DrawMarker)
--   exports.pb_panel:IsFree()                        (personnage chargé, aucun menu ni interface ouverts)
-- Menus : exports.pb_panel:OpenMenu(def) (voir le module Menus du panel). Notifications : exports.pb_panel:Notify({ type, title, text }).
local G = PBG

local promptOwner
exports('Prompt', function(text, key)
    promptOwner = GetInvokingResource()
    G.send('prompt', { show = true, key = tostring(key or 'E'), text = tostring(text or '') })
end)
exports('HidePrompt', function()
    if promptOwner and promptOwner ~= GetInvokingResource() then return end
    promptOwner = nil
    G.send('prompt', { show = false })
end)
exports('Progress', function(label, secs) G.send('crime.progress', { label = tostring(label or ''), secs = math.max(0.5, tonumber(secs) or 5) }) end)
exports('CancelProgress', function() G.send('crime.progress', { cancel = true }) end)
exports('Marker', function(x, y, z, r, g, b, size) G.Point(x + 0.0, y + 0.0, z + 0.0, r or 255, g or 255, b or 255, (size or 1.0) + 0.0) end)
exports('IsFree', function() return G.begun == true and not G.Menu.IsOpen() and not G.nuiOpen and not IsPauseMenuActive() end)

-- une extension qui s'arrête ne laisse pas son invite à l'écran
AddEventHandler('onClientResourceStop', function(res)
    if promptOwner == res then promptOwner = nil G.send('prompt', { show = false }) end
end)
