-- Touches du véhicule : coffre (ouvre aussi le sac du coffre), capot, moteur, ceinture, vitres. Réglables dans le panel et dans les raccourcis FiveM.
local G = PBG
local openedNet, belt = nil, false

local function cfg(k, d) local c = G.cfg and G.cfg.trunk return c and c[k] ~= nil and c[k] or d end

local function nearest(dist)
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local v = GetVehiclePedIsIn(ped, false)
    if v ~= 0 then return v end
    v = GetClosestVehicle(c.x, c.y, c.z, (dist or 5.0) + 0.0, 0, 71)
    return v ~= 0 and v or nil
end

local function trunkPos(veh)
    local b = GetEntityBoneIndexByName(veh, 'boot')
    if b ~= -1 then return GetWorldPositionOfEntityBone(veh, b) end
    local mn, mx = GetModelDimensions(GetEntityModel(veh))
    return GetOffsetFromEntityInWorldCoords(veh, 0.0, mn.y - 0.4, 0.0)
end

local function say(t, ty) G.send('notify', { type = ty or 'info', text = t }) end

local function engine()
    local ped = PlayerPedId()
    local v = GetVehiclePedIsIn(ped, false)
    if v == 0 or GetPedInVehicleSeat(v, -1) ~= ped then say('Il faut être au volant.', 'warn') return end
    local on = not GetIsVehicleEngineRunning(v)
    SetVehicleEngineOn(v, on, false, true)
    say(on and 'Moteur allumé.' or 'Moteur coupé.')
end

local function hood()
    local v = nearest(5.0)
    if not v then say('Aucun véhicule à proximité.', 'warn') return end
    if GetVehicleDoorAngleRatio(v, 4) > 0.1 then SetVehicleDoorShut(v, 4, false) else SetVehicleDoorOpen(v, 4, false, false) end
end

local function windows()
    local v = GetVehiclePedIsIn(PlayerPedId(), false)
    if v == 0 then say('Il faut être dans un véhicule.', 'warn') return end
    local down = IsVehicleWindowIntact(v, 0) and not G._winDown
    for i = 0, 3 do if down then RollDownWindow(v, i) else RollUpWindow(v, i) end end
    G._winDown = down
end

local function toggleBelt()
    local ped = PlayerPedId()
    if GetVehiclePedIsIn(ped, false) == 0 then return end
    belt = not belt
    say(belt and 'Ceinture bouclée.' or 'Ceinture détachée.')
end

local function trunk()
    if cfg('enabled', true) == false then return end
    if G.invIsOpen and G.invIsOpen() then return end
    local ped = PlayerPedId()
    if GetVehiclePedIsIn(ped, false) ~= 0 then say('Sors du véhicule pour ouvrir le coffre.', 'warn') return end
    local v = nearest(6.0)
    if not v then say('Aucun véhicule à proximité.', 'warn') return end
    local p = GetEntityCoords(ped)
    local t = trunkPos(v)
    if #(p - t) > (tonumber(cfg('open_dist', 3.5)) or 3.5) then say("Place-toi derrière le véhicule pour ouvrir le coffre.", 'warn') return end
    openedNet = NetworkGetNetworkIdFromEntity(v)
    SetVehicleDoorOpen(v, 5, false, false)
    TriggerServerEvent('pb:g:veh:trunk', openedNet, GetVehicleClass(v))
end

RegisterNetEvent('pb:g:veh:trunkok', function() end)

-- fermeture du coffre dès que l'inventaire se ferme ou qu'on s'éloigne
CreateThread(function()
    while true do
        if openedNet then
            local v = NetworkDoesNetworkIdExist(openedNet) and NetworkGetEntityFromNetworkId(openedNet) or 0
            local open = G.invIsOpen and G.invIsOpen()
            local far = v == 0 or not DoesEntityExist(v) or #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(v)) > 8.0
            if not open or far then
                if v ~= 0 and DoesEntityExist(v) then SetVehicleDoorShut(v, 5, false) end
                openedNet = nil
            end
            Wait(250)
        else Wait(500) end
    end
end)

-- ceinture : sans ceinture, un choc violent éjecte le conducteur
CreateThread(function()
    local last = 0.0
    while true do
        local ped = PlayerPedId()
        local v = GetVehiclePedIsIn(ped, false)
        if v ~= 0 then
            local sp = GetEntitySpeed(v)
            if not belt and last > 17.0 and sp < last - 12.0 and GetPedInVehicleSeat(v, -1) == ped then
                local c = GetEntityCoords(ped)
                SetEntityCoords(ped, c.x, c.y, c.z + 0.5, false, false, false, false)
                SetPedToRagdoll(ped, 1500, 1500, 0, false, false, false)
            end
            last = sp
            Wait(100)
        else belt = false last = 0.0 Wait(600) end
    end
end)

RegisterCommand('pb_trunk', trunk, false)
RegisterCommand('pb_hood', hood, false)
RegisterCommand('pb_engine', engine, false)
RegisterCommand('pb_belt', toggleBelt, false)
RegisterCommand('pb_windows', windows, false)

-- appelé par le menu contextuel (« Coffre »)
G.openTrunk = trunk
G.isBelted = function() return belt end

CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.trunk and GetGameTimer() < t do Wait(250) end
    local c = G.cfg.trunk or {}
    RegisterKeyMapping('pb_trunk', 'Véhicule : ouvrir le coffre', 'keyboard', c.key_trunk or 'K')
    RegisterKeyMapping('pb_hood', 'Véhicule : capot', 'keyboard', c.key_hood or 'J')
    RegisterKeyMapping('pb_engine', 'Véhicule : moteur', 'keyboard', c.key_engine or 'Y')
    RegisterKeyMapping('pb_belt', 'Véhicule : ceinture', 'keyboard', c.key_belt or 'B')
    RegisterKeyMapping('pb_windows', 'Véhicule : vitres', 'keyboard', c.key_windows or 'U')
end)

-- Invites près d'un véhicule (en haut à gauche, sous l'invite principale) : verrouiller / déverrouiller si on a la clé,
-- ouvrir le coffre et monter dedans quand on est derrière. Dans le coffre : sortir.
local sendNui = G.send
G.send = function(ev, d) if ev == 'prompt' then G.promptOn = d and d.show == true end return sendNui(ev, d) end
local keyOf = {}        -- plaque -> { ok, t }
RegisterNetEvent('pb:g:veh:keyInfo', function(plate, ok) keyOf[tostring(plate)] = { ok = ok == true, t = GetGameTimer() } end)
local function plateOf(v) return (GetVehicleNumberPlateText(v) or ''):gsub('^%s+', ''):gsub('%s+$', '') end
local function hasKey(v)
    local p = plateOf(v)
    local k = keyOf[p]
    if not k or GetGameTimer() - k.t > 30000 then
        if not k or not k.asked or GetGameTimer() - k.asked > 5000 then
            keyOf[p] = { ok = k and k.ok or false, t = k and k.t or 0, asked = GetGameTimer() }
            TriggerServerEvent('pb:g:veh:hasKey', p)
        end
        return k and k.ok or false
    end
    return k.ok
end
local NO_BOOT = { [8] = true, [13] = true, [14] = true, [15] = true, [16] = true, [21] = true }
local inTrunk = nil
local function trunkFits(v) return not NO_BOOT[GetVehicleClass(v)] and GetEntityBoneIndexByName(v, 'boot') ~= -1 end
local function enterTrunk(v)
    local ped = PlayerPedId()
    local mn = GetModelDimensions(GetEntityModel(v))
    SetVehicleDoorOpen(v, 5, false, false)
    RequestAnimDict('fin_ext_p1-7')
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded('fin_ext_p1-7') and GetGameTimer() < t do Wait(10) end
    AttachEntityToEntity(ped, v, -1, 0.0, mn.y + 0.85, 0.35, 0.0, 0.0, 0.0, false, false, false, false, 20, true)
    if HasAnimDictLoaded('fin_ext_p1-7') then TaskPlayAnim(ped, 'fin_ext_p1-7', 'cs_devin_dual-7', 8.0, -8.0, -1, 1, 0, false, false, false) end
    inTrunk = v
    SetTimeout(900, function() if inTrunk == v and DoesEntityExist(v) then SetVehicleDoorShut(v, 5, false) end end)
end
local function leaveTrunk()
    local v, ped = inTrunk, PlayerPedId()
    inTrunk = nil
    DetachEntity(ped, true, true)
    ClearPedTasks(ped)
    if v and DoesEntityExist(v) then
        SetVehicleDoorOpen(v, 5, false, false)
        local p = GetOffsetFromEntityInWorldCoords(v, 0.0, GetModelDimensions(GetEntityModel(v)).y - 0.9, 0.0)
        SetEntityCoords(ped, p.x, p.y, p.z, false, false, false, false)
        SetTimeout(900, function() if DoesEntityExist(v) then SetVehicleDoorShut(v, 5, false) end end)
    end
end
CreateThread(function()
    local last = ''
    local function show(lines)
        local sig = json.encode(lines)
        if sig ~= last then last = sig G.send('vprompt', { lines = lines }) end
    end
    while true do
        local sleep = 500
        local lines = {}
        local ped = PlayerPedId()
        if inTrunk then
            sleep = 0
            if not DoesEntityExist(inTrunk) or IsEntityDead(ped) then leaveTrunk()
            else
                DisableControlAction(0, 23, true)   -- pas de « monter dans le véhicule » depuis le coffre
                lines[#lines + 1] = { key = 'E', text = 'Sortir du coffre' }
                if IsControlJustPressed(0, 38) then
                    if GetVehicleDoorLockStatus(inTrunk) >= 2 then say('Le véhicule est verrouillé : impossible d\'ouvrir le coffre.', 'warn') else leaveTrunk() end
                end
            end
        elseif G.begun and GetVehiclePedIsIn(ped, false) == 0 and not (G.invIsOpen and G.invIsOpen()) and not (G.Menu and G.Menu.IsOpen and G.Menu.IsOpen()) then
            local c = GetEntityCoords(ped)
            local v = GetClosestVehicle(c.x, c.y, c.z, 4.0, 0, 71)
            if v ~= 0 and DoesEntityExist(v) then
                sleep = 0
                local locked = GetVehicleDoorLockStatus(v) >= 2
                if hasKey(v) then lines[#lines + 1] = { key = (G.cfg.garage and G.cfg.garage.lock_key) or 'L', text = locked and 'Déverrouiller' or 'Verrouiller' } end
                if cfg('enabled', true) ~= false and not locked and #(c - trunkPos(v)) <= (tonumber(cfg('open_dist', 3.5)) or 3.5) - 1.0 then
                    lines[#lines + 1] = { key = cfg('key_trunk', 'K'), text = 'Ouvrir le coffre' }
                    if trunkFits(v) and not G.promptOn then
                        lines[#lines + 1] = { key = 'E', text = 'Monter dans le coffre' }
                        if IsControlJustPressed(0, 38) then enterTrunk(v) end
                    end
                end
            end
        end
        show(lines)
        Wait(sleep)
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and inTrunk then DetachEntity(PlayerPedId(), true, true) ClearPedTasks(PlayerPedId()) end end)
