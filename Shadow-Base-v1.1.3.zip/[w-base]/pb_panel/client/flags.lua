-- Drapeaux de territoire : mât + tissu dessinés avec les natives de tracé (pas d'objet du jeu), cercle au sol, invite pour le chef.
-- Neutre = tissu noir en bas du mât ; tenu = tissu à la couleur du gang tout en haut ; prise en cours = le tissu monte.
-- Le serveur décide de tout : ici on dessine et on demande « E ».
local G = PBG
local spots, me, boss, rad, enabled = {}, nil, false, 25.0, true
local model, POLE = '', 6.0
local objs = {}
local prog = {}
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local f = c.flags or {}
    enabled = f.enabled ~= false and f.show ~= false
    rad = (tonumber(f.radius) or 25) + 0.0
    model = type(f.pole_model) == 'string' and f.pole_model or model
    POLE = (tonumber(f.pole_height) or 6) + 0.0
end
local function rgb(hex)
    if type(hex) ~= 'string' then return 223, 226, 231 end
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 223, 226, 231 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
-- Points de vente / drapeaux sur la carte : seulement pour les membres d'un groupe illégal
local flagBlips = {}
local function drawFlagBlips()
    for _, b in ipairs(flagBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    flagBlips = {}
    if not enabled or not me or me == '' then return end
    for _, s in ipairs(spots) do
        local o = s.owner
        local col = o and G.blipColourFor and G.blipColourFor(o.color) or 4
        local a = AddBlipForRadius(s.x + 0.0, s.y + 0.0, s.z + 0.0, rad)
        SetBlipColour(a, col) SetBlipAlpha(a, o and 110 or 50)
        flagBlips[#flagBlips + 1] = a
        local c = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(c, 38) SetBlipColour(c, col) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Drapeau · ' .. tostring(s.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
        flagBlips[#flagBlips + 1] = c
    end
end
local lastSig = ''
RegisterNetEvent('pb:g:flag:state', function(j)
    local d = G.decode(j)
    if not d then return end
    spots, me, boss = d.spots or {}, d.me, d.boss == true
    local sig = tostring(me)
    for _, s in ipairs(spots) do sig = sig .. '|' .. s.id .. ':' .. tostring(s.owner and s.owner.gang or '') end
    if sig ~= lastSig then lastSig = sig drawFlagBlips() end
    if d.cfg then
        if d.cfg.radius then rad = (tonumber(d.cfg.radius) or 25) + 0.0 end
        if d.cfg.model ~= nil then model = tostring(d.cfg.model) end
        if d.cfg.height then POLE = (tonumber(d.cfg.height) or 6) + 0.0 end
    end
end)

local CLOTH_W, CLOTH_H = 2.2, 1.3
local function cloth(x, y, z, r, g, b, t)
    -- fanion qui ondule : 12 bandes, plus hautes au mât et effilées vers la pointe ; deux faces (le jeu n'en affiche qu'une)
    local N, W, H = 12, 2.6, CLOTH_H * 1.15
    local px, py, ptop, pbot
    for i = 0, N do
        local k = i / N
        local wave = math.sin(t * 3.2 - k * 5.0) * 0.28 * k
        local hh = H * (1.0 - 0.72 * k)
        local cx, cy = x + W * k, y + wave
        local top, bot = z + (H - hh) * 0.5 + hh, z + (H - hh) * 0.5
        if px then
            local sh = 1.0 - 0.28 * k
            local rr, gg, bb = math.floor(r * sh), math.floor(g * sh), math.floor(b * sh)
            DrawPoly(px, py, pbot, cx, cy, bot, cx, cy, top, rr, gg, bb, 240)
            DrawPoly(px, py, pbot, cx, cy, top, px, py, ptop, rr, gg, bb, 240)
            DrawPoly(cx, cy, top, cx, cy, bot, px, py, pbot, rr, gg, bb, 240)
            DrawPoly(px, py, ptop, cx, cy, top, px, py, pbot, rr, gg, bb, 240)
        end
        px, py, ptop, pbot = cx, cy, top, bot
    end
end
local function label3d(x, y, z, text)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.0, 0.34) SetTextFont(4) SetTextCentre(true) SetTextColour(255, 255, 255, 235) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(text) EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end
-- mât : objet du jeu posé au sol, créé à l'approche, supprimé en s'éloignant (ou si le modèle est inconnu : mât dessiné)
local function pole(s, near)
    local o = objs[s.id]
    if not near or model == '' then
        if o and o.e and DoesEntityExist(o.e) then DeleteEntity(o.e) end
        objs[s.id] = nil
        return false
    end
    if o then return o.e ~= nil and DoesEntityExist(o.e) end
    objs[s.id] = { e = nil, bad = false }
    CreateThread(function()
        local h = GetHashKey(model)
        if not IsModelInCdimage(h) then objs[s.id].bad = true return end
        RequestModel(h)
        local t = GetGameTimer()
        while not HasModelLoaded(h) and GetGameTimer() - t < 3000 do Wait(50) end
        if not HasModelLoaded(h) then objs[s.id].bad = true return end
        local e = CreateObject(h, s.x + 0.0, s.y + 0.0, s.z - 0.95, false, false, false)
        SetEntityAsMissionEntity(e, true, true)
        PlaceObjectOnGroundProperly(e)
        FreezeEntityPosition(e, true)
        SetModelAsNoLongerNeeded(h)
        if objs[s.id] then objs[s.id].e = e else DeleteEntity(e) end
    end)
    return false
end
local function fmt(sec) sec = math.max(0, math.floor(sec)) return ('%d h %02d'):format(sec // 3600, sec % 3600 // 60) end

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    local t0 = GetGameTimer()
    while true do
        if not G.begun or not enabled or #spots == 0 then hide() Wait(800)
        else
            local c = GetEntityCoords(PlayerPedId())
            local near, nd
            for _, s in ipairs(spots) do
                local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0))
                if d < 90.0 then
                    local x, y, z = s.x + 0.0, s.y + 0.0, s.z - 0.95
                    local r, g, b = 17, 17, 17
                    local height = 0.15
                    if s.owner then r, g, b = rgb(s.owner.color) height = POLE - CLOTH_H - 0.1
                    elseif s.ready and s.ready.color then r, g, b = rgb(s.ready.color) height = POLE - CLOTH_H - 0.1
                    elseif s.by and (tonumber(s.prog) or 0) > 0 then local k = math.min(1.0, (tonumber(s.prog) or 0) / 100.0) r, g, b = rgb(s.by.color) r, g, b = math.floor(17 + (r - 17) * k), math.floor(17 + (g - 17) * k), math.floor(17 + (b - 17) * k) height = 0.15 + (POLE - CLOTH_H - 0.25) * math.min(1.0, (tonumber(s.prog) or 0) / 100.0) end
                    -- cercle + mât
                    PBG.Zone(x, y, z, r > 30 and r or 120, g > 30 and g or 120, b > 30 and b or 120, rad)
                    -- mât = objet du jeu sans drapeau intégré (modèle réglable) ; si le modèle est introuvable, un fil sombre le remplace
                    local hasObj = pole(s, d < 70.0)
                    if not hasObj and not (objs[s.id] and not objs[s.id].bad and model ~= '') then
                        DrawLine(x, y, z, x, y, z + POLE, 28, 28, 30, 255)
                    end
                    cloth(x + 0.06, y, z + height, r, g, b, (GetGameTimer() - t0) / 1000.0)
                    if d < 45.0 then
                        local txt = s.owner and (s.owner.label .. ' · ' .. fmt(s.owner.left)) or (s.ready and 'Drapeau prêt : le chef doit le récupérer' or ((s.by and (tonumber(s.prog) or 0) > 0) and ('CAPTURE EN COURS · ' .. s.by.label .. ' · ' .. tostring(s.prog) .. ' %') or 'Neutre'))
                        label3d(x, y, z + POLE + 0.7, s.label .. ' — ' .. txt)
                    end
                    if not nd or d < nd then near, nd = s, d end
                end
            end
            for _, s in ipairs(spots) do if objs[s.id] and #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) >= 90.0 then pole(s, false) end end
            -- invite : le chef du gang dont le drapeau est prêt, dans le cercle
            if near and nd <= rad and near.ready and near.ready.gang == me and boss and not G.Menu.IsOpen() then
                if shown ~= near.id then shown = near.id G.send('prompt', { show = true, key = 'E', text = 'Récupérer le drapeau' }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:flag:claim', near.id) end
            else hide() end
            Wait(0)
            if not near then Wait(500) end
        end
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    for _, o in pairs(objs) do if o.e and DoesEntityExist(o.e) then DeleteEntity(o.e) end end
end)
