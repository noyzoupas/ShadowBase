-- Atelier : menu de tuning (F2 › Atelier) et application des pièces demandées par le serveur. Le serveur vérifie métier, service, caisse et distance.
local G = PBG

local function nearestVeh()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then local c = GetEntityCoords(ped) veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    return veh ~= 0 and DoesEntityExist(veh) and veh or nil
end
local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', '') end
local function grab(veh) if NetworkHasControlOfEntity(veh) then return true end NetworkRequestControlOfEntity(veh) local t = GetGameTimer() + 1500 while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(30) end return NetworkHasControlOfEntity(veh) end

-- Applique une pièce (aussi utilisée à la sortie du garage)
function G.ApplyPart(veh, kind, mod, level)
    level = math.floor(tonumber(level) or 0)
    if kind == 'mod' then
        SetVehicleModKit(veh, 0)
        SetVehicleMod(veh, mod, level - 1, false)
    elseif kind == 'toggle' then SetVehicleModKit(veh, 0) ToggleVehicleMod(veh, mod, level > 0)
    elseif kind == 'tint' then SetVehicleModKit(veh, 0) SetVehicleWindowTint(veh, level)
    elseif kind == 'plate' then SetVehicleNumberPlateTextIndex(veh, level)
    elseif kind == 'paint' then local _, c2 = GetVehicleColours(veh) SetVehicleColours(veh, level, c2) end
end
function G.ApplyMods(veh, mods)
    local parts = (G.cfg.mech and G.cfg.mech.parts) or {}
    for _, p in ipairs(parts) do
        local lv = mods and mods[p.key]
        if lv then G.ApplyPart(veh, p.kind, p.mod, lv) end
    end
end

local function openMenu(d)
    local veh = nearestVeh()
    if not veh then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun véhicule à proximité.' }) return end
    local function apply(key, lv) TriggerServerEvent('pb:g:mech:apply', NetworkGetNetworkIdFromEntity(veh), plateOf(veh), key, lv) end
    local items = { { type = 'separator', label = (d.biz or 'Atelier') .. ' · caisse ' .. tostring(math.floor(d.balance or 0)) .. ' $' },
        { label = 'Réparation complète', right = (d.repair or 0) .. ' $', description = 'Carrosserie, moteur, pneus et propreté.', onSelect = function() apply('repair', 1) end } }
    for _, p in ipairs(d.parts or {}) do
        local sub = {}
        local top = p.max
        if p.kind == 'mod' then SetVehicleModKit(veh, 0) top = math.min(p.max, (GetNumVehicleMods(veh, p.mod) or 0) + 0) end
        for lv = 0, top do
            local price = lv == 0 and 0 or (p.kind == 'paint' and p.price or p.price * lv)
            sub[#sub + 1] = { label = lv == 0 and 'Retirer / d\'origine' or (p.kind == 'toggle' and 'Installer' or ('Niveau ' .. lv)), right = price > 0 and (math.floor(price) .. ' $') or nil, onSelect = function() apply(p.key, lv) end }
            if p.kind == 'paint' and lv >= 12 and lv % 12 ~= 0 then sub[#sub] = nil end   -- peinture : une teinte sur douze, pour garder la liste courte
        end
        if top >= 1 or p.kind == 'toggle' or p.kind == 'tint' or p.kind == 'plate' or p.kind == 'paint' then
            items[#items + 1] = { type = 'submenu', label = p.label, submenu = { id = 'mech.' .. p.key, title = p.label, subtitle = 'Choisis un niveau', items = sub } }
        end
    end
    G.Menu.Open({ id = 'mechanic', title = 'Atelier', subtitle = plateOf(veh), items = items })
end
RegisterNetEvent('pb:g:mech:ui', function(j) local d = G.decode(j) if d then openMenu(d) end end)
RegisterNetEvent('pb:g:quick:workshop', function() G.Menu.Close() TriggerServerEvent('pb:g:mech:open') end)

RegisterNetEvent('pb:g:mech:do', function(j)
    local d = G.decode(j)
    if not d then return end
    local veh = NetworkGetEntityFromNetworkId(d.netId or 0)
    if not veh or veh == 0 or not DoesEntityExist(veh) then veh = nearestVeh() end
    if not veh or not grab(veh) then G.send('notify', { type = 'error', title = 'Atelier', text = 'Impossible de travailler sur ce véhicule.' }) return end
    if d.kind == 'repair' then
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    else G.ApplyPart(veh, d.kind, d.mod, d.level) end
end)
