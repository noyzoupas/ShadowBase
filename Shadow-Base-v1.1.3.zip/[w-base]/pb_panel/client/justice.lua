-- Justice : prison (périmètre, minuteur), chantiers TIG, repères et GPS des appels d'urgence. Le serveur décide ; ici on affiche et on exécute.
local G = PBG
local state = { kind = 'none', remaining = 0 }
local tigBusy = false
local blips = {}

local function cfg() return G.cfg and G.cfg.justice or {} end
local function jpos() local c = cfg() return vector3((c.jail_x or 0) + 0.0, (c.jail_y or 0) + 0.0, (c.jail_z or 0) + 0.0) end
local function tigPoints()
    local out = {}
    for _, line in ipairs(cfg().tig_points or {}) do
        local x, y, z, l = tostring(line):match('^(-?[%d%.]+)|(-?[%d%.]+)|(-?[%d%.]+)|(.*)$')
        if x then out[#out + 1] = { x = tonumber(x) + 0.0, y = tonumber(y) + 0.0, z = tonumber(z) + 0.0, label = l } end
    end
    return out
end

local function teleport(c)
    local ped = PlayerPedId()
    local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
    RequestCollisionAtCoord(c.x + 0.0, c.y + 0.0, c.z + 0.0)
    local t = GetGameTimer() + 1500
    while not HasCollisionLoadedAroundEntity(ent) and GetGameTimer() < t do Wait(0) end
    SetEntityCoordsNoOffset(ent, c.x + 0.0, c.y + 0.0, c.z + 0.5, false, false, false)
end

RegisterNetEvent('pb:g:justice:state', function(j)
    local d = G.decode(j)
    if not d then return end
    state = { kind = d.kind or 'none', remaining = tonumber(d.remaining) or 0, reason = d.reason }
    G.send('justice.state', state)
end)

RegisterNetEvent('pb:g:justice:fx', function(kind, j)
    local d = G.decode(j) or {}
    if kind == 'tp' and type(d.x) == 'number' then teleport(d)
    elseif kind == 'gps' and type(d.x) == 'number' then SetNewWaypoint(d.x + 0.0, d.y + 0.0)
    elseif kind == 'blip' and type(d.x) == 'number' then
        local b = AddBlipForCoord(d.x + 0.0, d.y + 0.0, (d.z or 0) + 0.0)
        SetBlipSprite(b, 161) SetBlipColour(b, 1) SetBlipScale(b, 1.0) SetBlipFlashes(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentString('Appel #' .. tostring(d.id)) EndTextCommandSetBlipName(b)
        PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', true)
        blips[#blips + 1] = b
        SetTimeout(120000, function() if DoesBlipExist(b) then RemoveBlip(b) end end)
    end
end)

-- décompte local (resynchronisé par le serveur toutes les 30 s)
CreateThread(function()
    while true do
        Wait(1000)
        if state.kind == 'jail' and state.remaining > 0 then state.remaining = state.remaining - 1 end
    end
end)

-- prison : on ramène le joueur s'il sort du périmètre
CreateThread(function()
    while true do
        if state.kind == 'jail' then
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local jp = jpos()
            if #(c - jp) > (cfg().jail_radius or 70) + 5.0 then teleport(jp) end
            DisablePlayerFiring(PlayerId(), true)
            Wait(1000)
        else Wait(1500) end
    end
end)

-- TIG : marqueurs et tâche (E)
CreateThread(function()
    while true do
        if state.kind == 'tig' and not tigBusy then
            local c = GetEntityCoords(PlayerPedId())
            local near = false
            for i, pt in ipairs(tigPoints()) do
                local d = #(c - vector3(pt.x, pt.y, pt.z))
                if d < 40.0 then
                    near = true
                    G.Point(pt.x + 0.0, pt.y + 0.0, pt.z - 0.95, 223, 226, 231, 1.6)
                    if d < (cfg().tig_radius or 3.0) then
                        BeginTextCommandDisplayHelp('STRING') AddTextComponentSubstringPlayerName('~INPUT_CONTEXT~ Travailler (' .. (pt.label or '') .. ')') EndTextCommandDisplayHelp(0, false, true, -1)
                        if IsControlJustPressed(0, 38) then
                            tigBusy = true
                            local ped = PlayerPedId()
                            TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_JANITOR', 0, true)
                            local secs = cfg().tig_secs or 8
                            G.send('justice.progress', { secs = secs })
                            Wait(secs * 1000)
                            ClearPedTasks(ped)
                            TriggerServerEvent('pb:g:justice:tig', i)
                            tigBusy = false
                        end
                    end
                end
            end
            Wait(near and 0 or 500)
        else Wait(500) end
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
end)
