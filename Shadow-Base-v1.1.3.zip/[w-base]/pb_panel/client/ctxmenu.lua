-- Menu ALT : tant que la touche est maintenue, on affiche un point sur soi et sur les personnes visibles à portée ; un clic envoie
-- seulement l'identifiant choisi au serveur, qui renvoie la liste des entrées permises. Ce fichier ne décide d'aucun droit.
local G = PBG
local holding, menuOpen, lastKey = false, false, ''
local visible = {}              -- clés « type:identifiant » cliquables en ce moment (p = personne, v = véhicule, o = objet)
local pickKind = 'p'
local ents, hovered = {}, nil     -- clé « type:identifiant » -> entité ; entité survolée (rendue translucide)


local function r4(v) return math.floor(v * 10000) / 10000 end
-- Rectangle écran (centre + taille, 0..1) qui entoure l'entité : on projette les 8 coins de sa boîte. nil si illisible.
local function screenBox(ent)
    local ok, mn, mx = pcall(function() local a, b = GetModelDimensions(GetEntityModel(ent)) return a, b end)
    if not ok or not mn or not mx then return nil end
    local x0, y0, x1, y1 = 2, 2, -1, -1
    for _, cx in ipairs({ mn.x, mx.x }) do for _, cy in ipairs({ mn.y, mx.y }) do for _, cz in ipairs({ mn.z, mx.z }) do
        local w = GetOffsetFromEntityInWorldCoords(ent, cx, cy, cz)
        local o, sx, sy = GetScreenCoordFromWorldCoord(w.x, w.y, w.z)
        if o then x0, y0, x1, y1 = math.min(x0, sx), math.min(y0, sy), math.max(x1, sx), math.max(y1, sy) end
    end end end
    if x1 < x0 or y1 < y0 then return nil end
    x0, y0, x1, y1 = math.max(0, x0), math.max(0, y0), math.min(1, x1), math.min(1, y1)
    if x1 - x0 < 0.015 or y1 - y0 < 0.03 then return nil end
    return r4((x0 + x1) / 2), r4((y0 + y1) / 2), r4(x1 - x0), r4(y1 - y0)
end

local function cfg() return G.cfg and G.cfg.ctx or {} end
local function busy() return G.locked > 0 and not menuOpen or G.creating or G.wardrobe or G.state.dead or not G.begun or (G.shopIsOpen and G.shopIsOpen()) end

local function restoreFocus()
    SetNuiFocusKeepInput(false)
    SetNuiFocus(G.locked > 0, G.locked > 0)
end

local function unhover()
    if hovered and DoesEntityExist(hovered) then ResetEntityAlpha(hovered) end
    hovered = nil
end

local function stopHold()
    unhover()
    if not holding then return end
    holding = false
    lastKey = ''
    G.send('ctx.spots', { p = {} })
    if not menuOpen then restoreFocus() G.send('ctx.hide', {}) end
end

local function closeMenu()
    if not menuOpen then return end
    menuOpen = false
    G.send('ctx.close', {})
    if holding then SetNuiFocus(true, true) SetNuiFocusKeepInput(true) else restoreFocus() end
end

RegisterCommand('+pb_ctx', function()
    local c = cfg()
    if c.enabled == false or holding or menuOpen or busy() or IsPauseMenuActive() then return end
    holding = true
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(true)
    CreateThread(function()
        local me = PlayerPedId()
        while holding do
            Wait(0)
            -- le curseur est libre : on empêche la caméra de bouger et les clics d'attaquer
            for _, k in ipairs({ 1, 2, 24, 25, 68, 69, 70, 91, 92, 140, 141, 142, 257, 263, 264 }) do DisableControlAction(0, k, true) end
            if IsEntityDead(PlayerPedId()) then stopHold() break end
        end
    end)
    CreateThread(function()
        while holding do
            local cc = cfg()
            local me = PlayerPedId()
            local mc = GetEntityCoords(me)
            local maxd = (tonumber(cc.range) or 15) + 0.0
            local out, ids = {}, {}
            local myId = GetPlayerServerId(PlayerId())
            local function add(pl, ped, self_)
                local sid = GetPlayerServerId(pl)
                local bc = GetPedBoneCoords(ped, 24818, 0.0, 0.0, 0.0)
                local ok, x, y = GetScreenCoordFromWorldCoord(bc.x, bc.y, bc.z + 0.1)
                local bx, by, bw, bh = screenBox(ped)
                if bx then ok, x, y = true, bx, by end
                if ok then
                    out[#out + 1] = { i = sid, k = 'p', x = r4(x), y = r4(y), w = bw, h = bh, me = self_ and 1 or 0 }
                    ids['p:' .. sid] = true
                    ents['p:' .. sid] = ped
                end
            end
            if cc.show_self ~= false then add(PlayerId(), me, true) end
            if cc.show_others ~= false then
                for _, pl in ipairs(GetActivePlayers()) do
                    if pl ~= PlayerId() then
                        local ped = GetPlayerPed(pl)
                        if ped ~= 0 and DoesEntityExist(ped) and IsEntityVisible(ped) and #(GetEntityCoords(ped) - mc) <= maxd and (cc.walls == true or HasEntityClearLosToEntity(me, ped, 17)) then add(pl, ped, false) end
                    end
                end
            end
            -- véhicules visibles à portée
            if cc.show_vehicles ~= false and GetGamePool then
                local myVeh = GetVehiclePedIsIn(me, false)
                for _, veh in ipairs(GetGamePool('CVehicle')) do
                    if veh ~= myVeh and DoesEntityExist(veh) and IsEntityVisible(veh) then
                        local vc = GetEntityCoords(veh)
                        if #(vc - mc) <= maxd and (cc.walls == true or HasEntityClearLosToEntity(me, veh, 17)) and NetworkGetEntityIsNetworked(veh) then
                            local ok, x, y = GetScreenCoordFromWorldCoord(vc.x, vc.y, vc.z + 0.6)
                            local bx, by, bw, bh = screenBox(veh)
                            if bx then ok, x, y = true, bx, by end
                            if ok then
                                local net = NetworkGetNetworkIdFromEntity(veh)
                                out[#out + 1] = { i = net, k = 'v', x = r4(x), y = r4(y), w = bw, h = bh }
                                ids['v:' .. net] = true
                                ents['v:' .. net] = veh
                            end
                        end
                    end
                end
            end
            -- objets du décor réglés dans le panel
            if cc.show_objects ~= false and type(cc.objects) == 'table' then
                for idx, o in ipairs(cc.objects) do
                    local obj = GetClosestObjectOfType(mc.x, mc.y, mc.z, maxd, GetHashKey(tostring(o.model)), false, false, false)
                    if obj and obj ~= 0 and DoesEntityExist(obj) then
                        local oc = GetEntityCoords(obj)
                        local ok, x, y = GetScreenCoordFromWorldCoord(oc.x, oc.y, oc.z + 0.3)
                        local bx, by, bw, bh = screenBox(obj)
                        if bx then ok, x, y = true, bx, by end
                        if ok and (cc.walls == true or HasEntityClearLosToEntity(me, obj, 17)) then
                            out[#out + 1] = { i = idx, k = 'o', x = r4(x), y = r4(y), w = bw, h = bh }
                            ids['o:' .. idx] = true
                            ents['o:' .. idx] = obj
                        end
                    end
                end
            end
            visible = ids
            local key = json.encode(out)
            if key ~= lastKey then lastKey = key G.send('ctx.spots', { p = out, show = true }) end
            Wait(33)
        end
    end)
end, false)
RegisterCommand('-pb_ctx', function() stopHold() end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.ctx and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('+pb_ctx', 'Menu contextuel (maintenir)', 'keyboard', (G.cfg.ctx and G.cfg.ctx.key) or 'LMENU')
end)

-- Survol d'une cible pendant ALT : l'entité devient translucide (on la remet normale dès qu'on la quitte).
G.nui['ctx.hover'] = function(d)
    local id = tonumber(d.i)
    local k = (d.k == 'v' or d.k == 'o') and d.k or 'p'
    local ent = id and holding and ents[k .. ':' .. id] or nil
    if ent == hovered then return {} end
    unhover()
    if ent and DoesEntityExist(ent) then hovered = ent SetEntityAlpha(ent, 150, false) end
    return {}
end
G.nui['ctx.pick'] = function(d)
    local id = tonumber(d.i)
    local k = (d.k == 'v' or d.k == 'o') and d.k or 'p'
    if not id or not visible[k .. ':' .. id] then return {} end
    pickKind = k
    TriggerServerEvent(k == 'v' and 'pb:g:ctx:openv' or k == 'o' and 'pb:g:ctx:openo' or 'pb:g:ctx:open', id)
    return {}
end
G.nui['ctx.act'] = function(d)
    local t = tonumber(d.t)
    if not t or type(d.id) ~= 'string' then return {} end
    local payload = type(d.payload) == 'table' and d.payload or {}
    if pickKind == 'v' then TriggerServerEvent('pb:g:ctx:actv', t, d.id, payload)
    elseif pickKind == 'o' then TriggerServerEvent('pb:g:ctx:acto', t, d.id)
    else TriggerServerEvent('pb:g:ctx:act', t, d.id, payload) end
    return {}
end
G.nui['ctx.close'] = function() closeMenu() return {} end

RegisterNetEvent('pb:g:ctx:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' and d.spec then
        menuOpen = true
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(false)
        G.send('ctx.open', { spec = d.spec })
    elseif d.ev == 'done' then
        closeMenu()
    end
end)

RegisterNetEvent('pb:g:ctx:run', function(j)
    local d = G.decode(j)
    if not d or type(d.v) ~= 'string' then return end
    closeMenu()
    if d.kind == 'cmd' and d.v:match('^[%w_:%-]+$') then
        local t = tonumber(d.target)
        ExecuteCommand(d.v .. (t and (' ' .. math.floor(t)) or ''))
    elseif d.kind == 'gest' then
        if G.CtxGestPlay then G.CtxGestPlay(d.v) end
    elseif d.kind == 'copy' then
        if G.CtxCopy then G.CtxCopy(d.v) end
    elseif d.kind == 'anim' then
        if d.v == 'stop' then ClearPedTasks(PlayerPedId()) elseif G.PlayAnim then G.PlayAnim(d.v) end
    end
end)

-- Moteur / coffre d'un véhicule choisi dans le menu (le serveur a déjà vérifié la clé)
RegisterNetEvent('pb:g:ctx:veh', function(j)
    local d = G.decode(j)
    if not d or not d.net then return end
    local veh = NetworkGetEntityFromNetworkId(math.floor(d.net))
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    if d.act == 'engine' then
        local on = not GetIsVehicleEngineRunning(veh)
        SetVehicleEngineOn(veh, on, false, true)
    elseif d.act == 'flip' then
        NetworkRequestControlOfEntity(veh)
        local t = GetGameTimer() + 1500
        while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(0) end
        SetVehicleOnGroundProperly(veh)
    elseif d.act == 'unlock' then
        local ped = PlayerPedId()
        RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
        local t = GetGameTimer() + 1500
        while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') and GetGameTimer() < t do Wait(10) end
        if HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') then TaskPlayAnim(ped, 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', 'machinic_loop_mechandplayer', 8.0, -8.0, 4500, 49, 0, false, false, false) end
        Wait(4500)
        ClearPedTasks(ped)
        SetVehicleDoorsLocked(veh, 1) SetVehicleDoorsLockedForAllPlayers(veh, false)
    elseif d.act == 'trunk' then
        if GetVehicleDoorAngleRatio(veh, 5) > 0.1 then SetVehicleDoorShut(veh, 5, false) elseif G.openTrunk then G.openTrunk() else SetVehicleDoorOpen(veh, 5, false, false) end
    end
end)

-- Escorte : le personnage menotté s'attache à celui qui l'escorte (le serveur a déjà vérifié les droits et la distance)
local escortBy
RegisterNetEvent('pb:g:ctx:escort', function(j)
    local d = G.decode(j)
    local ped = PlayerPedId()
    if not d or d.on ~= true then
        escortBy = nil
        if IsEntityAttached(ped) then DetachEntity(ped, true, false) end
        return
    end
    escortBy = math.floor(tonumber(d.by) or 0)
    CreateThread(function()
        local attached = false
        while escortBy do
            Wait(250)
            local me = PlayerPedId()
            local pid = GetPlayerFromServerId(escortBy)
            local cop = pid ~= -1 and GetPlayerPed(pid) or 0
            if cop ~= 0 and DoesEntityExist(cop) and not IsPedInAnyVehicle(me, false) then
                if not attached or not IsEntityAttachedToEntity(me, cop) then
                    AttachEntityToEntity(me, cop, 11816, 0.38, 0.5, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
                    attached = true
                end
            end
        end
    end)
end)

-- Mise en véhicule : le personnage menotté prend une place libre dans le véhicule le plus proche de celui qui l'a désigné
RegisterNetEvent('pb:g:ctx:intoveh', function(j)
    local d = G.decode(j)
    local me = PlayerPedId()
    escortBy = nil
    if IsEntityAttached(me) then DetachEntity(me, true, false) end
    local pid = d and GetPlayerFromServerId(math.floor(tonumber(d.by) or 0)) or -1
    local cop = pid ~= -1 and GetPlayerPed(pid) or 0
    local placed = false
    if cop ~= 0 and DoesEntityExist(cop) then
        local c = GetEntityCoords(cop)
        local veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71)
        if veh ~= 0 and DoesEntityExist(veh) then
            local n = GetVehicleModelNumberOfSeats(GetEntityModel(veh))
            for seat = n - 2, 0, -1 do
                if IsVehicleSeatFree(veh, seat) then SetPedIntoVehicle(me, veh, seat) placed = true break end
            end
        end
    end
    TriggerServerEvent('pb:g:ctx:intovehres', placed)
end)
RegisterNetEvent('pb:g:ctx:leaveveh', function()
    local me = PlayerPedId()
    if IsPedInAnyVehicle(me, false) then TaskLeaveVehicle(me, GetVehiclePedIsIn(me, false), 16) end
end)
