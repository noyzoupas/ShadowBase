-- Nouveautés : journal des mises à jour affiché dans le panel (carte sur l'accueil + module « Nouveautés »).
-- Chaque lot ajoute une entrée à PB.Changelog (voir la liste plus bas). Le « lu / non lu » est mémorisé par administrateur (licence).
-- Pour ajouter une nouveauté : PB.News.Add({ id = 'lot37', date = 'AAAA-MM-JJ', title = '…', items = { { tag = 'Nouveau', text = '…', module = 'id-du-module' } } }).

local B, P, DB = PB.B, PB.Perm, PB.DB
local N = {}
PB.News = N

PB.Migrate('192_news_seen', 'Nouveautés : dernier lot lu par administrateur', {
    [[CREATE TABLE IF NOT EXISTS pb_news_seen (license VARCHAR(64) NOT NULL PRIMARY KEY, seq INT NOT NULL DEFAULT 0)]],
})

N.list = {}   -- du plus ancien au plus récent ; seq = position
function N.Add(e)
    if type(e) ~= 'table' or not e.id then return end
    for _, x in ipairs(N.list) do if x.id == e.id then return end end
    local items = {}
    for _, it in ipairs(e.items or {}) do
        items[#items + 1] = { tag = tostring(it.tag or 'Nouveau'):sub(1, 16), text = tostring(it.text or ''):sub(1, 240), module = it.module and tostring(it.module) or nil }
    end
    N.list[#N.list + 1] = { id = tostring(e.id), seq = #N.list + 1, date = tostring(e.date or ''), title = tostring(e.title or e.id):sub(1, 160), items = items }
end

local function seenOf(license)
    local r = license and DB.one('SELECT seq FROM pb_news_seen WHERE license = ?', { license })
    return r and tonumber(r.seq) or 0
end
-- Entrées pour un administrateur : { unseen, entries (les plus récentes d'abord) }
function N.For(license, limit)
    local seen, out, unseen = seenOf(license), {}, 0
    for i = #N.list, 1, -1 do
        local e = N.list[i]
        local isNew = e.seq > seen
        if isNew then unseen = unseen + 1 end
        if #out < (limit or 50) then out[#out + 1] = { id = e.id, date = e.date, title = e.title, items = e.items, new = isNew } end
    end
    return unseen, out
end
function N.MarkRead(license)
    if not license or #N.list == 0 then return end
    DB.exec('REPLACE INTO pb_news_seen (license, seq) VALUES (?, ?)', { license, N.list[#N.list].seq })
end

-- Journal des lots ----------------------------------------------------------------------------------------------------------------------
N.Add({ id = 'lot34', date = '2026-10-17', title = 'Patch notes 34 : téléphone, inventaire, boutiques', items = {
    { tag = 'Amélioré', text = "Boutiques, inventaire, notifications et HUD repensés.", module = 'shops' },
} })
N.Add({ id = 'lot35', date = '2026-10-17', title = 'Patch notes 35 : entreprises, gangs, carte', items = {
    { tag = 'Nouveau', text = "130 entreprises et gangs prêts à installer, rangés en 10 catégories.", module = 'biz' },
    { tag = 'Nouveau', text = "Module « Carte du jeu » : clique sur la carte, tu es téléporté, E pour poser un point.", module = 'carte' },
    { tag = 'Nouveau', text = "Menu staff : emploi, second emploi, gang, grade, armes dans l'inventaire, redémarrage planifié.", module = 'staff' },
    { tag = 'Corrigé', text = "Boutiques bloquées, noclip en véhicule, boutons grisés, éditeur d'automatisations." },
} })
N.Add({ id = 'lot36', date = '2026-10-17', title = 'Patch notes 36 : coffres, concession, tablettes', items = {
    { tag = 'Nouveau', text = "Coffre de véhicule (touche K) et touches capot, moteur, ceinture, vitres.", module = 'vehtrunk' },
    { tag = 'Nouveau', text = "Concession : 45 véhicules par défaut et nouvelle fiche (vitesse, places, coffre).", module = 'shops' },
    { tag = 'Nouveau', text = "Tablettes entreprise et gang complétées : équipe, annonces, journal, stats, paie, caisse commune, territoires…", module = 'orga' },
    { tag = 'Changé', text = "Noms au-dessus des têtes réservés au staff, couleur par grade.", module = 'tags' },
    { tag = 'Changé', text = "Créateur de personnage redessiné ; tablette transparente.", module = 'character' },
} })
N.Add({ id = 'fix37', date = '2026-10-17', title = 'Gros correctif de présentation', items = {
    { tag = 'Corrigé', text = "Commandes « restreintes » : la restriction ne s'appliquait jamais (faille corrigée).", module = 'commands' },
    { tag = 'Corrigé', text = "Second emploi : il est maintenant payé à chaque paie (pourcentage réglable).", module = 'biz' },
    { tag = 'Corrigé', text = "Points « bureau du patron / siège » : la tablette s'ouvre enfin." },
    { tag = 'Corrigé', text = "Garage : une page avec une note faisait planter l'écran." },
    { tag = 'Amélioré', text = "290 actions du panel et 119 événements du jeu testés avec des données absurdes : plus aucun plantage." },
} })

-- Actions -------------------------------------------------------------------------------------------------------------------------------
PB.Action('news.read', nil, function(ctx) N.MarkRead(ctx.license) return true, { unseen = 0 } end, { read = true })

-- Module --------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'whatsnew', label = 'Nouveautés', icon = 'sparkle', group = 'Pilotage', order = 5, perm = 'whatsnew.view', hint = 'Ce qui change à chaque mise à jour',
    doc = "## Nouveautés\nChaque mise à jour de Shadow Base ajoute une entrée ici, avec un lien direct vers le module concerné. Une pastille signale ce que tu n'as pas encore lu ; « Tout marquer comme lu » l'efface pour ton compte.",
    view = function(ctx)
        return { tabs = { { id = 'all', label = 'Mises à jour', icon = 'sparkle', build = function()
            local unseen, entries = N.For(ctx.license, 50)
            local blocks = {}
            if unseen > 0 then blocks[#blocks + 1] = B.actions({ { action = 'news.read', label = 'Tout marquer comme lu (' .. unseen .. ')', icon = 'check', primary = true } }) end
            for _, e in ipairs(entries) do
                local rows = {}
                for _, it in ipairs(e.items) do
                    local row = { tag = it.tag, text = it.text }
                    if it.module then row.actions = { { nav = it.module, label = 'Ouvrir', icon = 'arrow' } } end
                    rows[#rows + 1] = row
                end
                blocks[#blocks + 1] = B.table({ id = 'news_' .. e.id, title = (e.new and 'NOUVEAU · ' or '') .. e.title .. (e.date ~= '' and ('  (' .. e.date .. ')') or ''), columns = { { k = 'tag', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' } }, rows = rows })
            end
            if #blocks == 0 then blocks[1] = B.notice('info', 'Aucune nouveauté pour le moment.') end
            return blocks
        end } } }
    end,
})

N.Add({ id = 'lot39', date = '2026-10-17', title = 'Patch notes 39 : images, tablettes, placement, nettoyage', items = {
    { tag = 'Corrigé', text = "Images d'objets de l'inventaire et tablette des organisations (mise en page)." },
    { tag = 'Changé', text = "Tablette entreprise : uniquement les outils du métier (police : appels, détenus, amendes, dossiers).", module = 'biz' },
    { tag = 'Nouveau', text = "Placement à l'écran : déplace le vrai HUD, le chat, les menus et l'invite.", module = 'placement' },
    { tag = 'Changé', text = "Onglets en double supprimés (Services, Argent, Documentation, Garages).", module = 'general' },
} })

PB.SelfTest.Add('nouveautés', function(R)
    R.check(#N.list >= 3, 'journal', 'aucune entrée')
    local seen = {}
    for _, e in ipairs(N.list) do
        R.check(not seen[e.id], 'journal', 'identifiant en double : ' .. e.id)
        seen[e.id] = true
        R.check(#e.items > 0, 'journal', 'entrée vide : ' .. e.id)
    end
end)

N.Add({ id = 'patch40', date = '2026-10-18', title = 'Patch notes 40 : inventaire, territoires, points, identité', items = {
    { tag = 'Corrigé', text = "Inventaire : glisser-déposer, vrais filtres, armes jamais consommées (touches 1 à 5)." },
    { tag = 'Nouveau', text = "Tablette illégale : carte des territoires ; Mirror Park donne un gilet toutes les 10 h dans le coffre de l'organisation." },
    { tag = 'Nouveau', text = "Carte : « Configurer tout » pose tous les points d'une entreprise ou d'un gang d'une traite.", module = 'carte' },
    { tag = 'Changé', text = "Supérette : interface d'origine avec panier. Notifications : déplacement corrigé." },
    { tag = 'Nouveau', text = "Logo W et bannières Shadow Base (offres, Halloween, patch notes)." },
    { tag = 'Nouveau', text = "Menus : bannière animée Shadow Base (réglable dans Menus > Apparence).", module = 'menus' },
} })

N.Add({ id = 'patch41', date = '2026-10-18', title = 'Patch notes 41 : aides, infos, ALT, bannière, chuchoter', items = {
    { tag = 'Nouveau', text = "Barre d'aide en bas de l'écran : noclip (molette = vitesse, Ctrl, Maj) et cabine de vêtements." },
    { tag = 'Changé', text = "Les infos d'un joueur, l'argent, les papiers et la plaque s'affichent dans une fiche à côté du menu, plus en notification." },
    { tag = 'Nouveau', text = "Menu ALT en cascade, épuré (nouvelle version par défaut).", module = 'interface' },
    { tag = 'Nouveau', text = "Bannière des menus : le W se dessine, le texte suit le menu ouvert (Menu admin, Menu police…).", module = 'menus' },
    { tag = 'Nouveau', text = "Menu staff : Chuchoter, message que seul le joueur reçoit (voix privée en option).", module = 'staff' },
    { tag = 'Changé', text = "Le W de Shadow Base est le logo par défaut du panel.", module = 'general' },
} })
N.Add({ id = 'patch42', date = '2026-10-18', title = 'Patch notes 42 : organisations, starter pack, véhicules de gang', items = {
    { tag = 'Nouveau', text = "Carte du jeu › Entreprise / organisation : tu remplis les infos, puis tu es guidé en jeu pour poser le point coffre, le point boss, le rangement des véhicules et la sortie du garage.", module = 'carte' },
    { tag = 'Nouveau', text = "Module Organisations : création d'un gang avec ses grades, liste (membres, véhicules, caisse), réglages.", module = 'orgs' },
    { tag = 'Nouveau', text = "Starter pack à la création : objets dans le coffre, argent dans la caisse et trois véhicules de départ (tout est réglable).", module = 'orgs' },
    { tag = 'Nouveau', text = "Garage de gang : tu y retrouves tes véhicules et ceux de l'organisation ; les membres ont la clé des véhicules du gang.", module = 'garage' },
    { tag = 'Nouveau', text = "Donner un de tes véhicules à l'organisation, le reprendre, et le chef peut attribuer un véhicule du gang à un membre.", module = 'garage' },
    { tag = 'Nouveau', text = "Panel : ajouter un véhicule neuf à une organisation ou en attribuer un existant (par plaque).", module = 'orgs' },
    { tag = 'Changé', text = "Un garage de gang n'apparaît (carte, marqueur, touche E) que pour les membres de ce gang.", module = 'garage' },
} })


N.Add({ id = 'patch43', date = '2026-10-20', title = 'Patch notes 43 : extensions, staff, PNJ, correctif images', items = {
    { tag = 'Nouveau', text = 'Extensions : une autre ressource se branche sur Shadow Base (pages, réglages, actions, permissions). Module Extensions.', module = 'extensions' },
    { tag = 'Nouveau', text = 'Menu staff : « Libérer de prison » et liste des détenus dans Gestion des sanctions.' },
    { tag = 'Nouveau', text = 'Monde : supprimer les PNJ et les PNJ police (activés par défaut).', module = 'world' },
    { tag = 'Correctif', text = "Envoyer une image depuis le PC (bannière, logo) ne déconnecte plus." },
} })
N.Add({ id = 'patch44', date = '2026-10-20', title = 'Patch notes 44 : activités, blips, inventaire, territoires, HUD', items = {
    { tag = 'Nouveau', text = 'Activités ouvertes à tous (pêche, mine, bois, agriculture, cueillette, décharge, craft), posées au Builder.', module = 'wb_activites' },
    { tag = 'Nouveau', text = 'Blips : coffres en dégradé aux couleurs du serveur, QG de gang, vraie icône Burger Shot.' },
    { tag = 'Nouveau', text = "Message en entrant dans un territoire ; HUD faim / soif / micro et barres vie / armure." },
    { tag = 'Correctif', text = "Fond de l'inventaire : le jeu se voit derrière (plus noir opaque)." },
} })
N.Add({ id = 'patch45', date = '2026-10-20', title = 'Patch notes 45 : portes, menu boss, builder, GPS, animations', items = {
    { tag = 'Nouveau', text = 'Portes verrouillables par groupes (F10 › Builder › Portes ou /portes).', module = 'wb_portes' },
    { tag = 'Nouveau', text = 'Gestion des entreprises et organisations seulement au point boss.' },
    { tag = 'Nouveau', text = 'Builder : supprimer un point ou tous les points ; GPS dans le F5 ; animations manger et boire.' },
    { tag = 'Correctif', text = 'Burger Shot : menus qui clignotaient, client PNJ mal placé ; menu F2 retiré (tout est dans ALT).' },
} })
N.Add({ id = 'patch46', date = '2026-10-20', title = 'Patch notes 46 : points de métier pour toutes les entreprises', items = {
    { tag = 'Nouveau', text = 'Builder : accueil, atelier (garages), cuisine / bar et comptoir de vente selon le métier.', module = 'carte' },
} })
N.Add({ id = 'patch47', date = '2026-10-20', title = 'Patch notes 47 : agence immobilière, mises à jour', items = {
    { tag = 'Nouveau', text = 'Agence immobilière : annonces, intérieurs, visites et commission (menu ALT des agents).' },
    { tag = 'Nouveau', text = 'Module Mises à jour : nouvelles versions signées, patch notes et téléchargement gratuit.', module = 'updates' },
} })

N.Add({ id = 'patch48', date = '2026-10-21', title = 'Patch notes 48 : écran de chargement', items = {
    { tag = 'Nouveau', text = 'Écran de chargement : logo, barre de progression et bandeau de messages qui défile (ressource wb_loading).' },
} })
N.Add({ id = 'patch49', date = '2026-10-21', title = 'Patch notes 49 : la base devient Shadow Base', items = {
    { tag = 'Nouveau', text = 'Nouveau nom et nouveau logo : Shadow Base.', module = 'general' },
} })
N.Add({ id = 'patch50', date = '2026-10-21', title = 'Patch notes 50 : corrections, journal des expulsions, vestiaires, braquages', items = {
    { tag = 'Nouveau', text = "Journal des expulsions et bans : raison précise, origine et référence pour chaque kick.", module = 'kicks' },
    { tag = 'Correctif', text = "Anticheat : plus d'éjections pendant un restart ou un lag.", module = 'general' },
    { tag = 'Correctif', text = "Staff affiché hors ligne, touches des menus, onglets vides, suppression des anciens points.", module = 'general' },
    { tag = 'Nouveau', text = "Vrais vestiaires d'entreprise et de gang, vendeurs derrière le comptoir et braquages animés.", module = 'general' },
} })
N.Add({ id = 'patch51', date = '2026-10-21', title = 'Patch notes 51 : petits jobs, vraie pêche, vendeurs derrière le comptoir', items = {
    { tag = 'Nouveau', text = "Petits jobs pour chaque entreprise (touche O) : livraisons, taxi, dépannage, patrouille, secours, chantiers…", module = 'general' },
    { tag = 'Nouveau', text = "Pêche : raretés de poissons et de leurres, cannes, ferrage, marché aux prix variables, records.", module = 'general' },
    { tag = 'Correctif', text = "Vendeurs placés derrière le comptoir dans toutes les supérettes, magasins comme braquages.", module = 'shops' },
    { tag = 'Correctif', text = "Menotté : plus d'animations ; saisies au casier ; annonces visibles dans le chat ; couleur des gangs.", module = 'general' },
} })
N.Add({ id = 'patch52', date = '2026-10-21', title = 'Patch notes 52 : coiffeur / barbier, bandeau de démarrage', items = {
    { tag = 'Nouveau', text = "Coiffeur / barbier : coupe, couleurs, barbe, sourcils, maquillage, aperçu en direct. Builder › Commerces.", module = 'shops' },
    { tag = 'Nouveau', text = "Au démarrage, la console affiche la version, le numéro du dernier patch notes et l'état de la licence.", module = 'general' },
} })
N.Add({ id = 'patch53', date = '2026-10-21', title = 'Patch notes 53 : moins de métiers, Builder plus rapide, Auto Exotic, packs', items = {
    { tag = 'Amélioré', text = "Catalogue court : 14 entreprises utiles (dont Auto Exotic) ; les inutilisées sont retirées.", module = 'biz' },
    { tag = 'Amélioré', text = "Builder : Entrée pose le point tout de suite ; icône du siège au choix ; patron choisi parmi les joueurs connectés.", module = 'carte' },
    { tag = 'Nouveau', text = "3 packs de départ pour les organisations, donnés à la création.", module = 'orgs' },
    { tag = 'Correctif', text = "Points accueil / atelier / cuisine et points du Burger Shot : posés, affichés et supprimables.", module = 'carte' },
    { tag = 'Amélioré', text = "Inventaire : cases moins vertes, fond plus transparent.", module = 'inv' },
} })
