-- Économie du serveur : presets complets (pauvre, équilibrée, riche, réaliste…), paramètres, simulation de pouvoir d'achat, comptes et journal.
-- Les valeurs agissent réellement : prix des magasins (+ TVA), intérêts bancaires, salaires et impôts (module Entreprises), amendes, argent de départ, frais de mort.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('eco.edit', "Modifier l'économie du serveur et appliquer un preset", 'eco', true)
P.Register('eco.ledger', 'Voir le journal des comptes', 'eco')

PB.Migrate('043_game_economy', 'Comptes et journal économique', {
    [[CREATE TABLE IF NOT EXISTS pb_accounts (
        id VARCHAR(48) NOT NULL, label VARCHAR(64) NOT NULL DEFAULT '', balance BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_ledger (
        id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, account VARCHAR(48) NOT NULL, delta BIGINT NOT NULL, reason VARCHAR(96) NOT NULL DEFAULT '', who VARCHAR(64) NOT NULL DEFAULT '',
        PRIMARY KEY (id), KEY k_at (at), KEY k_acc (account))]],
})

-- Paramètres : k (clé unique), ns/key (où la valeur est stockée), bornes -----------------------------------------------------------------
local PARAMS = {
    { k = 'price_mult', ns = 'eco', key = 'price_mult', label = 'Prix des magasins et concessions (×)', group = 'Prix et taxes', min = 0.1, max = 10, int = false, step = 0.05, hint = '1 = prix du catalogue. Appliqué aussi aux véhicules.' },
    { k = 'tax_sales', ns = 'eco', key = 'tax_sales', label = 'TVA sur les achats (%)', group = 'Prix et taxes', min = 0, max = 50, int = false, step = 0.5, hint = 'Incluse dans le prix affiché, versée au compte « État ».' },
    { k = 'fine_mult', ns = 'eco', key = 'fine_mult', label = 'Amendes (×)', group = 'Prix et taxes', min = 0.1, max = 20, int = false, step = 0.1, hint = 'Multiplie les montants du catalogue d\'amendes.' },
    { k = 'income_mult', ns = 'eco', key = 'income_mult', label = 'Salaires (×)', group = 'Revenus', min = 0.1, max = 10, int = false, step = 0.05, hint = 'Multiplie la paie de tous les métiers.' },
    { k = 'paycheck_interval', ns = 'eco', key = 'paycheck_interval', label = 'Intervalle de paie (minutes)', group = 'Revenus', min = 1, max = 180 },
    { k = 'tax_income', ns = 'eco', key = 'tax_income', label = 'Impôt sur le revenu (%)', group = 'Revenus', min = 0, max = 80, int = false, step = 0.5, hint = 'Prélevé sur chaque paie, versé au compte « État ».' },
    { k = 'unemployed_allowance', ns = 'eco', key = 'unemployed_allowance', label = 'Allocation sans emploi (par paie)', group = 'Revenus', min = 0, max = 10000 },
    { k = 'bank_interest', ns = 'eco', key = 'bank_interest', label = 'Intérêts bancaires (% par heure de jeu)', group = 'Banque', min = 0, max = 20, int = false, step = 0.05, hint = 'Versés aux joueurs connectés, toutes les 10 minutes.' },
    { k = 'bank_interest_cap', ns = 'eco', key = 'bank_interest_cap', label = "Plafond du solde qui rapporte", group = 'Banque', min = 0, max = 100000000 },
    { k = 'start_cash', ns = 'character', key = 'start_cash', label = 'Espèces de départ', group = 'Départ et mort', min = 0, max = 10000000 },
    { k = 'start_bank', ns = 'character', key = 'start_bank', label = 'Banque de départ', group = 'Départ et mort', min = 0, max = 10000000 },
    { k = 'respawn_cost', ns = 'death', key = 'respawn_cost', label = 'Frais de soins à la réapparition', group = 'Départ et mort', min = 0, max = 1000000 },
    { k = 'lose_cash_pct', ns = 'death', key = 'lose_cash_pct', label = 'Espèces perdues à la mort (%)', group = 'Départ et mort', min = 0, max = 100 },
}
local PBY = {}
for _, p in ipairs(PARAMS) do PBY[p.k] = p end

PB.Cfg.Define('eco', { price_mult = 1, tax_sales = 8, fine_mult = 1, income_mult = 1, paycheck_interval = 15, tax_income = 10, unemployed_allowance = 150, bank_interest = 0.2, bank_interest_cap = 5000,
    active_preset = 'equilibree', custom_presets = {}, backup = {} })

local function values(ns, key) return PB.Cfg.Get(ns, key) end
local function snapshotNow() local t = {} for _, p in ipairs(PARAMS) do t[p.k] = values(p.ns, p.key) end return t end

-- Presets ---------------------------------------------------------------------------------------------------------------------------
local PRESETS = {
    { id = 'equilibree', label = 'Équilibrée', icon = 'scale', tone = '#7be0a4', stars = 3, for_ = 'Serveur roleplay classique',
        text = "Une voiture s'obtient après quelques dizaines d'heures. Salaires corrects, TVA raisonnable, argent de départ modeste.",
        v = { price_mult = 1, tax_sales = 8, fine_mult = 1, income_mult = 1, paycheck_interval = 15, tax_income = 10, unemployed_allowance = 150, bank_interest = 0.2, bank_interest_cap = 5000, start_cash = 500, start_bank = 2500, respawn_cost = 250, lose_cash_pct = 0 } },
    { id = 'pauvre', label = 'Pauvre / survie', icon = 'flame', tone = '#ff8a5c', stars = 5, for_ = 'Roleplay de rue et survie',
        text = 'Tout est cher, les salaires sont bas et la mort coûte. Chaque dollar compte, les petits boulots et les trafics deviennent tentants.',
        v = { price_mult = 1.5, tax_sales = 12, fine_mult = 1.5, income_mult = 0.6, paycheck_interval = 20, tax_income = 15, unemployed_allowance = 60, bank_interest = 0, bank_interest_cap = 0, start_cash = 100, start_bank = 500, respawn_cost = 500, lose_cash_pct = 10 } },
    { id = 'realiste', label = 'Réaliste', icon = 'building', tone = '#6fb4ff', stars = 4, for_ = 'Roleplay sérieux, vie quotidienne',
        text = "Impôts et TVA élevés, paies espacées, intérêts faibles. On épargne longtemps avant un gros achat.",
        v = { price_mult = 1.2, tax_sales = 20, fine_mult = 1.2, income_mult = 0.8, paycheck_interval = 30, tax_income = 22, unemployed_allowance = 250, bank_interest = 0.1, bank_interest_cap = 2000, start_cash = 300, start_bank = 1500, respawn_cost = 400, lose_cash_pct = 5 } },
    { id = 'rp_ouvrier', label = 'Populaire', icon = 'users', tone = '#ffc65c', stars = 2, for_ = 'Serveur accueillant aux nouveaux',
        text = "Prix doux, paies fréquentes, allocation généreuse : on avance vite sans s'enrichir à l'excès.",
        v = { price_mult = 0.9, tax_sales = 6, fine_mult = 1, income_mult = 1.2, paycheck_interval = 15, tax_income = 8, unemployed_allowance = 220, bank_interest = 0.3, bank_interest_cap = 3000, start_cash = 400, start_bank = 2000, respawn_cost = 200, lose_cash_pct = 0 } },
    { id = 'riche', label = 'Riche / luxe', icon = 'gem', tone = '#d78bff', stars = 1, for_ = 'Serveur « vie de luxe »',
        text = "Gros salaires, prix réduits, beaucoup d'argent au départ. Les voitures de sport sont accessibles très vite.",
        v = { price_mult = 0.7, tax_sales = 5, fine_mult = 0.8, income_mult = 1.8, paycheck_interval = 10, tax_income = 5, unemployed_allowance = 400, bank_interest = 0.5, bank_interest_cap = 25000, start_cash = 5000, start_bank = 25000, respawn_cost = 100, lose_cash_pct = 0 } },
    { id = 'hardcore', label = 'Hardcore', icon = 'skull', tone = '#ff5a6e', stars = 5, for_ = 'Joueurs expérimentés',
        text = "Aucune aide, amendes lourdes, pertes à la mort : l'argent se gagne durement et se perd vite.",
        v = { price_mult = 2, tax_sales = 15, fine_mult = 2.5, income_mult = 0.5, paycheck_interval = 30, tax_income = 25, unemployed_allowance = 0, bank_interest = 0, bank_interest_cap = 0, start_cash = 0, start_bank = 300, respawn_cost = 1000, lose_cash_pct = 25 } },
    { id = 'sandbox', label = 'Bac à sable', icon = 'sparkle', tone = '#58d6ff', stars = 1, for_ = 'Freeroam et tests',
        text = "Presque tout est gratuit : on teste, on s'amuse, on achète ce qu'on veut dès le départ.",
        v = { price_mult = 0.2, tax_sales = 0, fine_mult = 0.3, income_mult = 3, paycheck_interval = 5, tax_income = 0, unemployed_allowance = 800, bank_interest = 1, bank_interest_cap = 100000, start_cash = 25000, start_bank = 100000, respawn_cost = 0, lose_cash_pct = 0 } },
}
local PRESET_BY = {}
for _, p in ipairs(PRESETS) do PRESET_BY[p.id] = p end

-- Références pour la simulation : un métier moyen, un panier de courses, une voiture de milieu de gamme.
local REF = { salary = 300, basket = 23, car = 30000 }

local function metrics(v)
    local per_hour = 60 / math.max(1, v.paycheck_interval)
    local net_hour = REF.salary * v.income_mult * per_hour * (1 - v.tax_income / 100)
    local car = REF.car * v.price_mult * (1 + v.tax_sales / 100)
    local basket = REF.basket * v.price_mult * (1 + v.tax_sales / 100)
    local hours_car = net_hour > 0 and car / net_hour or 9999
    local label, tone
    if hours_car < 8 then label, tone = 'Très riche', '#d78bff'
    elseif hours_car < 20 then label, tone = 'Riche', '#58d6ff'
    elseif hours_car < 45 then label, tone = 'Équilibrée', '#7be0a4'
    elseif hours_car < 90 then label, tone = 'Difficile', '#ffc65c'
    else label, tone = 'Très difficile', '#ff5a6e' end
    return { net_hour = net_hour, car = car, basket = basket, hours_car = hours_car, label = label, tone = tone, start = (v.start_cash or 0) + (v.start_bank or 0),
        start_baskets = basket > 0 and ((v.start_cash or 0) + (v.start_bank or 0)) / basket or 9999 }
end
G.EcoMetrics = metrics

local function money(n) return ('%s $'):format(tostring(math.floor(n + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end

-- API économique (utilisée par magasins, entreprises, banque) ----------------------------------------------------------------------------
G.Eco = G.Eco or {}
local Eco = G.Eco
function Eco.Get(k) return PB.Cfg.Get('eco', k) end
-- Prix affiché : prix catalogue × multiplicateur, TVA incluse (arrondi à l'entier).
function Eco.Final(base) return math.floor((tonumber(base) or 0) * Eco.Get('price_mult') * (1 + Eco.Get('tax_sales') / 100) + 0.5) end
-- Part de TVA contenue dans un montant TTC.
function Eco.TaxIn(final) local r = Eco.Get('tax_sales') / 100 return math.floor(final - final / (1 + r) + 0.5) end
function Eco.Fine(base) return math.floor((tonumber(base) or 0) * Eco.Get('fine_mult') + 0.5) end

function Eco.Book(account, delta, reason, who)
    delta = math.floor(tonumber(delta) or 0)
    if delta == 0 or type(account) ~= 'string' or account == '' then return false end
    DB.exec('INSERT INTO pb_accounts (id, label, balance) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?', { account, account, delta, delta })
    DB.exec('INSERT INTO pb_ledger (at, account, delta, reason, who) VALUES (?, ?, ?, ?, ?)', { os.time(), account, delta, tostring(reason or ''):sub(1, 96), tostring(who or ''):sub(1, 64) })
    return true
end
function Eco.Balance(account) local r = DB.one('SELECT balance FROM pb_accounts WHERE id = ?', { tostring(account) }) return r and tonumber(r.balance) or 0 end
exports('GetBalance', function(a) return Eco.Balance(a) end)
exports('EcoPrice', function(base) return Eco.Final(base) end)

-- Intérêts : toutes les 10 minutes, pour les joueurs connectés avec un personnage.
function Eco.InterestTick()
    local rate, cap = Eco.Get('bank_interest'), Eco.Get('bank_interest_cap')
    if rate <= 0 or cap <= 0 then return 0 end
    local total = 0
    for src, p in pairs(G.Players()) do
        if PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) then
            local base = math.min(math.max(0, p.row.bank), cap)
            local gain = math.floor(base * rate / 100 / 6)
            if gain > 0 and G.AddMoney(src, 'bank', gain) then
                total = total + gain
                G.Notify(src, { type = 'success', title = 'Banque', text = ('Intérêts : +%s'):format(money(gain)) })
                Eco.Book('interets', -gain, 'Intérêts bancaires', p.license)
            end
        end
    end
    return total
end
CreateThread(function() while true do Wait(600000) Eco.InterestTick() end end)

-- Application d'un preset -----------------------------------------------------------------------------------------------------------------
local function applyValues(ctx, vals, presetId, reason)
    local patches = {}
    for k, v in pairs(vals) do
        local p = PBY[k]
        if p then patches[p.ns] = patches[p.ns] or {} patches[p.ns][p.key] = v end
    end
    for ns, patch in pairs(patches) do
        local ok, e = PB.Cfg.SetMany(ns, patch, ctx.actor, reason)
        if ok == false then return false, e end
    end
    PB.Cfg.Set('eco', 'active_preset', presetId or '', ctx.actor, reason)
    return true
end

local function customPresets() return PB.Cfg.Get('eco', 'custom_presets', {}) end
local function findPreset(id)
    if PRESET_BY[id] then return PRESET_BY[id] end
    for _, c in ipairs(customPresets()) do if c.id == id then return { id = c.id, label = c.label, v = c.v, custom = true } end end
end

PB.Action('eco.preset.apply', 'eco.edit', function(ctx, p)
    local pr = findPreset(tostring(p.id or ''))
    if not pr then return false, 'Preset inconnu.' end
    local before = snapshotNow()
    PB.Cfg.Set('eco', 'backup', { at = os.time(), preset = PB.Cfg.Get('eco', 'active_preset'), v = before }, ctx.actor, 'Sauvegarde avant preset')
    local ok, err = applyValues(ctx, pr.v, pr.id, 'Preset économie : ' .. pr.label)
    if not ok then return false, err end
    ctx.audit('config', 'eco.preset', pr.id, before, pr.v)
    ctx.toast = ('Preset « %s » appliqué. Tu peux revenir en arrière avec « Annuler le dernier preset ».'):format(pr.label)
    return true
end, { critical = true, confirm = { title = 'Appliquer ce preset ?', text = "Prix, salaires, taxes, intérêts, argent de départ et frais de mort changent immédiatement pour tout le serveur. Les réglages actuels sont sauvegardés pour pouvoir revenir en arrière.", danger = false } })

PB.Action('eco.preset.undo', 'eco.edit', function(ctx)
    local b = PB.Cfg.Get('eco', 'backup', {})
    if type(b) ~= 'table' or type(b.v) ~= 'table' then return false, 'Aucune sauvegarde à restaurer.' end
    local ok, err = applyValues(ctx, b.v, b.preset, 'Retour avant preset')
    if not ok then return false, err end
    PB.Cfg.Set('eco', 'backup', {}, ctx.actor, 'Sauvegarde utilisée')
    ctx.audit('config', 'eco.preset.undo', tostring(b.preset), nil, b.v)
    ctx.toast = 'Réglages précédents restaurés.'
    return true
end, { critical = true, confirm = { text = 'Restaurer les réglages économiques d\'avant le dernier preset ?' } })

PB.Action('eco.params.save', 'eco.edit', function(ctx, p)
    local v = p.values or {}
    local fields, input = {}, {}
    for _, d in ipairs(PARAMS) do fields[#fields + 1] = { k = d.k, type = 'number', label = d.label, min = d.min, max = d.max, int = d.int, step = d.step } input[d.k] = v[d.k] end
    local c, err = PB.Validate(fields, input)
    if not c then return false, err end
    local before = snapshotNow()
    PB.Cfg.Set('eco', 'backup', { at = os.time(), preset = PB.Cfg.Get('eco', 'active_preset'), v = before }, ctx.actor, 'Sauvegarde avant modification')
    local ok, e = applyValues(ctx, c, '', 'Réglages économiques')
    if not ok then return false, e end
    -- si les valeurs correspondent exactement à un preset, on l'indique
    for _, pr in ipairs(PRESETS) do
        local same = true
        for k, x in pairs(pr.v) do if math.abs((c[k] or 0) - x) > 1e-9 then same = false break end end
        if same then PB.Cfg.Set('eco', 'active_preset', pr.id, ctx.actor, 'Réglages économiques') break end
    end
    ctx.audit('config', 'eco.params', 'eco', before, c)
    ctx.toast = 'Économie enregistrée et appliquée.'
    return true
end)

PB.Action('eco.preset.save_custom', 'eco.edit', function(ctx, p)
    local label = PB.Trim(PB.Sanitize(tostring((p.values or {}).label or ''), 32))
    if label == '' then return false, 'Donne un nom à ton preset.' end
    local list = PB.DeepCopy(customPresets())
    if #list >= 10 then return false, 'Dix presets personnalisés au maximum : supprime-en un.' end
    local id = 'perso_' .. label:lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', ''):sub(1, 20)
    for _, c in ipairs(list) do if c.id == id then return false, 'Ce nom existe déjà.' end end
    list[#list + 1] = { id = id, label = label, v = snapshotNow() }
    PB.Cfg.Set('eco', 'custom_presets', list, ctx.actor, 'Preset personnalisé')
    ctx.audit('config', 'eco.preset.save_custom', id, nil, nil)
    ctx.toast = 'Preset « ' .. label .. ' » enregistré.'
    return true
end)

PB.Action('eco.preset.delete_custom', 'eco.edit', function(ctx, p)
    local id, list, out = tostring(p.id or ''), customPresets(), {}
    for _, c in ipairs(list) do if c.id ~= id then out[#out + 1] = c end end
    if #out == #list then return false, 'Preset introuvable.' end
    PB.Cfg.Set('eco', 'custom_presets', out, ctx.actor, 'Preset supprimé')
    ctx.audit('config', 'eco.preset.delete_custom', id, nil, nil)
    ctx.toast = 'Preset supprimé.'
    return true
end, { critical = true, confirm = { text = 'Supprimer ce preset personnalisé ?' } })

PB.Action('eco.state.withdraw', 'eco.edit', function(ctx, p)
    return false, "Le compte « État » se vide depuis les caisses publiques des entreprises (module Entreprises)."
end)

-- Vue -------------------------------------------------------------------------------------------------------------------------------------
local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end

local function diffRows(cur, v)
    local rows = {}
    for _, d in ipairs(PARAMS) do
        local a, b = cur[d.k], v[d.k]
        rows[#rows + 1] = { group = d.group, label = d.label, cur = tostring(a), new = tostring(b), change = math.abs((a or 0) - (b or 0)) < 1e-9 and '=' or ((b > a) and '▲' or '▼') }
    end
    return rows
end

local function presetCards(ctx)
    local cur = snapshotNow()
    local active = PB.Cfg.Get('eco', 'active_preset', '')
    local items = {}
    local function card(pr)
        local m = metrics(pr.v)
        items[#items + 1] = { title = pr.label, sub = pr.for_ or 'Preset personnalisé', icon = pr.icon or 'star', tone = pr.tone or '#dfe2e7', active = active == pr.id, badge = active == pr.id and 'Actif' or (pr.stars and ('Difficulté ' .. pr.stars .. '/5') or nil),
            text = pr.text, stats = { { label = 'Voiture (30 000 $)', value = math.floor(m.hours_car + 0.5) .. ' h' }, { label = 'Revenu net / h', value = money(m.net_hour) }, { label = 'Départ', value = money(m.start) } },
            action = ctx.has('eco.edit') and { action = 'eco.preset.apply', label = active == pr.id and 'Réappliquer' or 'Appliquer', payload = { id = pr.id } } or nil }
    end
    for _, pr in ipairs(PRESETS) do card(pr) end
    for _, c in ipairs(customPresets()) do card({ id = c.id, label = c.label, v = c.v, tone = '#9aa3b2', icon = 'user' }) end
    return items
end

-- Bloc « tous les paramètres » (aussi affiché par le module Économie quand aucun framework n'est installé)
function Eco.ParamsBlock(ctx)
    local fields, vals = {}, {}
    for _, d in ipairs(PARAMS) do
        fields[#fields + 1] = { k = d.k, type = 'number', label = d.label, min = d.min, max = d.max, int = d.int, step = d.step, hint = d.hint }
        vals[d.k] = values(d.ns, d.key)
    end
    return { type = 'form', id = 'eco.params.native', title = 'Argent et salaires de Shadow Base', desc = "Réglages de l'économie intégrée (salaires, impôts, prix, banque, argent de départ). Ils s'appliquent à tous les joueurs dès l'enregistrement.", cols = 2, fields = fields, values = vals,
        submit = ctx.has('eco.edit') and { action = 'eco.params.save', label = 'Enregistrer' } or nil }
end

PB.Module({
    id = 'eco', label = 'Économie', icon = 'coins', group = 'Serveur', order = 90, perm = 'eco.view', hint = 'Presets, prix, taxes, intérêts, simulation',
    caps = function()
        return PB.Capsify({
            { 'Presets complets (7 + les tiens) avec retour arrière', 'ok', 'Chaque preset règle 13 paramètres d\'un coup ; les réglages précédents sont sauvegardés.' },
            { 'Prix des magasins et concessions, TVA', 'ok', 'Appliqués à chaque achat par le serveur. La TVA est versée au compte « État ».' },
            { 'Intérêts bancaires', 'ok', 'Versés aux joueurs connectés toutes les 10 minutes.' },
            { 'Salaires, impôt, allocation, amendes', 'ok', 'Utilisés par le module Entreprises (paie) et les amendes de la police.' },
            { 'Comptes ESX / QBCore (société, banque)', 'off', "Cette économie est autonome : elle ne lit ni n'écrit les tables du framework." },
            { 'Inflation automatique, marché boursier', 'off', "Non inclus : les prix changent quand tu les changes, pas tout seuls." },
        })
    end,
    doc = "## Économie\nChoisis un **preset** (équilibrée, pauvre, réaliste, populaire, riche, hardcore, bac à sable) ou règle chaque paramètre. La **simulation** te dit combien d'heures un joueur doit travailler pour s'acheter une voiture de 30 000 $.\n\n- Rien n'est définitif : « Annuler le dernier preset » rétablit les valeurs d'avant.\n- Les scripts peuvent lire les prix avec `exports.pb_panel:EcoPrice(prix)` et le solde d'un compte avec `exports.pb_panel:GetBalance('state')`.\n- Les montants sont **entiers** et arrondis à l'unité.",
    view = function(ctx)
        return { tabs = {
            tab('presets', 'Presets', 'star', function(_, params)
                local cur = snapshotNow()
                local active = PB.Cfg.Get('eco', 'active_preset', '')
                local m = metrics(cur)
                local blocks = {
                    B.stats({ { label = 'Preset actif', value = (findPreset(active) and findPreset(active).label) or 'Personnalisé', icon = 'star' }, { label = 'Voiture à 30 000 $', value = math.floor(m.hours_car + 0.5) .. ' h de travail', icon = 'car' },
                        { label = 'Revenu net par heure', value = money(m.net_hour), icon = 'coins' }, { label = 'Ambiance', value = m.label, icon = 'activity' } }),
                    { type = 'cards', title = 'Choisis une économie', desc = "Un clic règle les prix, taxes, salaires, intérêts, argent de départ et frais de mort. Les réglages d'avant sont sauvegardés.", items = presetCards(ctx) } }
                local bk = PB.Cfg.Get('eco', 'backup', {})
                if ctx.has('eco.edit') and type(bk) == 'table' and bk.v then
                    blocks[#blocks + 1] = B.actions({ { action = 'eco.preset.undo', label = 'Annuler le dernier changement', icon = 'undo' } }, 'Retour arrière')
                end
                -- comparaison avec un preset choisi
                local opts = {}
                for _, pr in ipairs(PRESETS) do opts[#opts + 1] = { pr.id, pr.label } end
                for _, c in ipairs(customPresets()) do opts[#opts + 1] = { c.id, c.label .. ' (perso)' } end
                local sel = findPreset(tostring(params.cmp or 'equilibree')) or PRESETS[1]
                blocks[#blocks + 1] = { type = 'picker', id = 'cmp', label = 'Comparer mes réglages avec', options = opts, value = sel.id }
                blocks[#blocks + 1] = B.table({ id = 'cmpt', title = 'Différences avec « ' .. sel.label .. ' »', columns = { { k = 'group', label = 'Groupe' }, { k = 'label', label = 'Paramètre' }, { k = 'cur', label = 'Actuel', type = 'num' }, { k = 'new', label = sel.label, type = 'num' }, { k = 'change', label = '' } }, rows = diffRows(cur, sel.v) })
                return blocks
            end),
            tab('params', 'Paramètres', 'sliders', function()
                local fields, vals, last = {}, {}, nil
                for _, d in ipairs(PARAMS) do
                    fields[#fields + 1] = { k = d.k, type = 'number', label = d.label, min = d.min, max = d.max, int = d.int, step = d.step, hint = d.hint }
                    vals[d.k] = values(d.ns, d.key)
                end
                local sub = ctx.has('eco.edit')
                local blocks = { { type = 'form', id = 'eco.params', title = 'Tous les paramètres', desc = "Ils s'appliquent à tous les joueurs dès l'enregistrement. Les montants sont entiers.", cols = 2, fields = fields, values = vals,
                    submit = sub and { action = 'eco.params.save', label = 'Enregistrer' } or nil } }
                if sub then
                    blocks[#blocks + 1] = { type = 'form', id = 'eco.custom', title = 'Garder ces réglages comme preset', cols = 2, fields = { { k = 'label', type = 'text', label = 'Nom du preset', required = true, maxlen = 32 } }, values = { label = '' },
                        submit = { action = 'eco.preset.save_custom', label = 'Enregistrer le preset' } }
                    local rows = {}
                    for _, c in ipairs(customPresets()) do rows[#rows + 1] = { name = c.label, actions = { { action = 'eco.preset.delete_custom', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = c.id } } } } end
                    if #rows > 0 then blocks[#blocks + 1] = B.table({ id = 'cust', title = 'Mes presets', columns = { { k = 'name', label = 'Nom' } }, rows = rows }) end
                end
                return blocks
            end),
            tab('sim', 'Simulation', 'chart', function()
                local cur = snapshotNow()
                local m = metrics(cur)
                local rows, labels, hours = {}, {}, {}
                local function add(label, v)
                    local x = metrics(v)
                    rows[#rows + 1] = { name = label, hours = math.floor(x.hours_car + 0.5) .. ' h', net = money(x.net_hour), basket = money(x.basket), start = math.floor(x.start_baskets) .. ' paniers', mood = x.label }
                    labels[#labels + 1] = label hours[#hours + 1] = math.floor(x.hours_car + 0.5)
                end
                add('Mes réglages', cur)
                for _, pr in ipairs(PRESETS) do add(pr.label, pr.v) end
                return {
                    { type = 'cards', big = true, items = {
                        { title = 'Temps pour une voiture', sub = '30 000 $ au catalogue', icon = 'car', tone = m.tone, value = math.floor(m.hours_car + 0.5) .. ' h', text = 'Prix final ' .. money(m.car) .. ' (TVA incluse) avec un métier moyen.', bar = math.min(100, m.hours_car / 90 * 100) },
                        { title = 'Revenu net par heure', sub = 'Après impôt', icon = 'coins', tone = '#7be0a4', value = money(m.net_hour), text = ('Métier moyen de référence : %s par paie, toutes les %d min.'):format(money(REF.salary * cur.income_mult), cur.paycheck_interval) },
                        { title = 'Panier de courses', sub = 'Burger + eau + sandwich', icon = 'food', tone = '#ffc65c', value = money(m.basket), text = ('Un nouveau joueur peut s\'en offrir %d avec son départ.'):format(math.floor(m.start_baskets)) },
                        { title = 'Ambiance', sub = 'Selon le temps pour une voiture', icon = 'activity', tone = m.tone, value = m.label, text = 'Moins de 8 h : très riche · 20 h : riche · 45 h : équilibrée · 90 h : difficile.' } } },
                    { type = 'chart', id = 'simh', title = 'Heures pour une voiture, par preset (mes réglages en premier)', labels = labels, series = { { name = 'Heures', values = hours } } },
                    B.table({ id = 'simt', title = 'Comparaison des presets', columns = { { k = 'name', label = 'Preset' }, { k = 'hours', label = 'Voiture', type = 'num' }, { k = 'net', label = 'Net / h', type = 'num' }, { k = 'basket', label = 'Panier', type = 'num' }, { k = 'start', label = 'Départ' }, { k = 'mood', label = 'Ambiance' } }, rows = rows }),
                }
            end),
            tab('accounts', 'Comptes et journal', 'coins', function()
                local accs = DB.q('SELECT id, balance FROM pb_accounts ORDER BY balance DESC LIMIT 40') or {}
                local items = {}
                for _, a in ipairs(accs) do items[#items + 1] = { title = a.id == 'state' and 'État' or a.id, sub = a.id == 'state' and 'TVA et impôts' or 'Compte', icon = 'coins', tone = a.id == 'state' and '#6fb4ff' or '#dfe2e7', value = money(a.balance) } end
                if #items == 0 then items[1] = { title = 'État', sub = 'TVA et impôts', icon = 'coins', tone = '#6fb4ff', value = money(0), text = "Le compte se remplit dès les premiers achats." } end
                local rows = {}
                if ctx.has('eco.ledger') then
                    for _, r in ipairs(DB.q('SELECT at, account, delta, reason, who FROM pb_ledger ORDER BY id DESC LIMIT 150') or {}) do rows[#rows + 1] = { at = r.at, account = r.account, delta = r.delta, reason = r.reason, who = r.who } end
                end
                return { { type = 'cards', items = items }, ctx.has('eco.ledger') and B.table({ id = 'ledger', title = 'Journal (150 dernières écritures)', search = true,
                    columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'account', label = 'Compte' }, { k = 'delta', label = 'Montant', type = 'num' }, { k = 'reason', label = 'Motif' }, { k = 'who', label = 'Licence', type = 'mono' } }, rows = rows, empty = 'Aucune écriture pour le moment.' }) or nil }
            end),
        } }
    end,
})

PB.SelfTest.Add('economie', function(R)
    for _, pr in ipairs(PRESETS) do
        for _, d in ipairs(PARAMS) do
            local x = pr.v[d.k]
            R.check(type(x) == 'number' and x >= d.min and x <= d.max, 'preset ' .. pr.id, 'valeur hors bornes pour ' .. d.k, tostring(x))
        end
    end
    R.check(Eco.Final(100) >= 0 and Eco.TaxIn(Eco.Final(100)) >= 0, 'économie', 'calcul de prix invalide')
    R.check(pcall(metrics, snapshotNow()), 'économie', 'la simulation plante')
end)
