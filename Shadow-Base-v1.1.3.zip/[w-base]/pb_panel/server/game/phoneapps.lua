-- Applications du téléphone : Messages, Contacts, Annuaire, Banque, Factures, Garage, GPS, Notes, Réglages (+ Calculatrice côté interface).
-- Tout passe par le serveur : le client n'envoie que des demandes (page, action) et le serveur répond avec les données déjà filtrées.
-- Les pages « blocs » de phone.lua restent en place (compatibilité) ; l'interface téléphone lit le champ `data`.
local G, DB = PB.G, PB.DB
local Ph = G.Phone

local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function cfg(k, d) return PB.Cfg.Get('phone', k, d) end

PB.Cfg.Define('phone', {
    anim = true, hide_apps = {},
    places = { 'Hôpital Pillbox|298.0|-584.0', 'Commissariat de Mission Row|441.0|-981.0', 'Legion Square|195.0|-934.0', 'Concessionnaire Simeon|-56.0|-1097.0', 'Aéroport de Los Santos|-1037.0|-2737.0', 'Plage de Vespucci|-1600.0|-1000.0' },
})

PB.Migrate('051_phone_apps', 'Téléphone : notes et préférences', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_notes (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, title VARCHAR(60) NOT NULL DEFAULT '', body VARCHAR(1500) NOT NULL DEFAULT '', updated INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_lic (license))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_prefs (license VARCHAR(64) NOT NULL, wall VARCHAR(12) NOT NULL DEFAULT 'dusk', dnd TINYINT(1) NOT NULL DEFAULT 0, sound TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (license))]]))
end)

local WALLS = { 'dusk', 'ocean', 'ember', 'forest', 'rose', 'mono', 'banner' }
local APPS = {   -- id, libellé, icône, page serveur (nil = côté interface seulement)
    { 'messages', 'Messages', 'chat', 'messages' }, { 'contacts', 'Contacts', 'users', 'contacts' }, { 'services', 'Annuaire', 'building', 'services' },
    { 'bank', 'Banque', 'card', 'bank' }, { 'bills', 'Factures', 'file', 'bills' }, { 'garage', 'Garage', 'car', 'garage' },
    { 'gps', 'GPS', 'pin', 'gps' }, { 'notes', 'Notes', 'list', 'notes' }, { 'calc', 'Calculatrice', 'calc', nil }, { 'settings', 'Réglages', 'sliders', 'settings' },
}

local function prefs(license)
    local r = DB.one('SELECT wall, dnd, sound FROM pb_phone_prefs WHERE license = ?', { license })
    return { wall = r and r.wall or 'dusk', dnd = r and PB.ToBool(r.dnd) or false, sound = r == nil or PB.ToBool(r.sound) }
end
function Ph.Prefs(license) return prefs(license) end
local function savePrefs(license, p)
    DB.exec('INSERT INTO pb_phone_prefs (license, wall, dnd, sound) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE wall = VALUES(wall), dnd = VALUES(dnd), sound = VALUES(sound)', { license, p.wall, p.dnd and 1 or 0, p.sound and 1 or 0 })
end
local function pendingBills(license)
    local r = DB.one("SELECT COUNT(*) AS n FROM pb_biz_invoices WHERE license = ? AND status = 'pending'", { license })
    return r and r.n or 0
end
local function places()
    local out = {}
    for i, line in ipairs(cfg('places', {}) or {}) do
        local l, x, y = tostring(line):match('^([^|]+)|(%-?%d+%.?%d*)|(%-?%d+%.?%d*)$')
        if l then out[#out + 1] = { id = i, label = l, x = tonumber(x), y = tonumber(y) } end
    end
    return out
end
local function hiddenApps() local t = {} for _, a in ipairs(cfg('hide_apps', {}) or {}) do t[tostring(a)] = true end return t end

function Ph.Info(src)
    local p = G.Get(src)
    if not p then return nil end
    local pf = prefs(p.license)
    local hide, apps = hiddenApps(), {}
    local un, bills = Ph.Unread(p.license), pendingBills(p.license)
    for _, a in ipairs(APPS) do
        if not hide[a[1]] then apps[#apps + 1] = { id = a[1], label = a[2], icon = a[3], page = a[4], badge = a[1] == 'messages' and un or (a[1] == 'bills' and bills) or 0 } end
    end
    return { number = Ph.Number(p.license), name = Ph.Display(src), unread = un, bills = bills, wall = pf.wall, dnd = pf.dnd, sound = pf.sound, apps = apps, cash = p.row.cash, bank = p.row.bank, anim = cfg('anim', true) ~= false }
end

-- Pages (données structurées) ---------------------------------------------------------------------------------------------------------------
local DATA = {}
local function reg(name, title) Ph.PAGES[name] = Ph.PAGES[name] or function() return {}, title end end
for _, n in ipairs({ { 'bank', 'Banque' }, { 'bills', 'Factures' }, { 'garage', 'Garage' }, { 'gps', 'GPS' }, { 'notes', 'Notes' }, { 'settings', 'Réglages' } }) do reg(n[1], n[2]) end

DATA.home = function(src) return { info = Ph.Info(src) } end
DATA.messages = function(src)
    local p = G.Get(src)
    local out = {}
    for _, t in ipairs(Ph.Threads(p.license)) do
        out[#out + 1] = { num = t.num, label = Ph.LabelOf(p.license, t.num), last = t.last:sub(1, 80), mine = t.mine, at = Ph.Stamp(t.at), unread = t.unread, svc = t.num:match('^svc:') ~= nil }
    end
    return { threads = out }
end
DATA.thread = function(src, s)
    local p = G.Get(src)
    local me, num = Ph.Number(p.license), s.thread
    if not num then return { empty = true } end
    local list = DB.q('SELECT id, from_num, body, at, reported FROM pb_phone_msgs WHERE ((from_num = ? AND to_num = ? AND del_from = 0) OR (from_num = ? AND to_num = ? AND del_to = 0)) ORDER BY id DESC LIMIT ?', { me, num, num, me, cfg('thread_view', 40) }) or {}
    local msgs = {}
    for i = #list, 1, -1 do local m = list[i] msgs[#msgs + 1] = { id = m.id, mine = m.from_num == me, body = m.body, at = Ph.Stamp(m.at), reported = PB.ToBool(m.reported) } end
    local svc = num:match('^svc:') ~= nil
    return { num = num, label = Ph.LabelOf(p.license, num), svc = svc, msgs = msgs, canAdd = not svc and Ph.ContactName(p.license, num) == nil, maxlen = cfg('msg_maxlen', 240) }
end
DATA.contacts = function(src)
    local p = G.Get(src)
    local out = {}
    for _, c in ipairs(DB.q('SELECT id, name, number FROM pb_phone_contacts WHERE license = ? ORDER BY name', { p.license }) or {}) do out[#out + 1] = { id = c.id, name = c.name, number = c.number } end
    return { list = out, max = cfg('max_contacts', 60), me = Ph.Number(p.license) }
end
DATA.services = function()
    local out = {}
    for _, b in ipairs(Ph.Services()) do out[#out + 1] = { id = b.id, name = b.label, duty = #Ph.OnDutyOf(b.id) } end
    return { list = out }
end
DATA.bank = function(src)
    local p = G.Get(src)
    local kinds = { deposit = 'Dépôt', withdraw = 'Retrait', transfer_out = 'Virement émis', transfer_in = 'Virement reçu', fee = 'Frais', admin = 'Ajustement', salary = 'Salaire' }
    local tx = {}
    for _, r in ipairs(DB.q('SELECT kind, amount, other, note, at FROM pb_bank_tx WHERE license = ? ORDER BY id DESC LIMIT 14', { p.license }) or {}) do
        local plus = r.kind == 'deposit' or r.kind == 'transfer_in' or r.kind == 'salary' or (r.kind == 'admin' and r.amount > 0)
        tx[#tx + 1] = { label = kinds[r.kind] or r.kind, amount = r.amount, plus = plus, note = r.note, at = Ph.Stamp(r.at) }
    end
    local contacts = {}
    for _, c in ipairs(DB.q('SELECT name, number FROM pb_phone_contacts WHERE license = ? ORDER BY name LIMIT 30', { p.license }) or {}) do contacts[#contacts + 1] = { name = c.name, number = c.number } end
    local B = PB.Cfg.All('bank')
    return { bank = p.row.bank, cash = p.row.cash, iban = G.Bank and G.Bank.Iban(p.license) or '', tx = tx, contacts = contacts, min = tonumber(B.transfer_min) or 1, max = tonumber(B.transfer_max) or 250000, fee = tonumber(B.transfer_fee) or 0 }
end
DATA.bills = function(src)
    local p = G.Get(src)
    local out = {}
    for _, i in ipairs(DB.q('SELECT i.id, i.amount, i.reason, i.kind, i.status, i.at, b.label AS blabel FROM pb_biz_invoices i LEFT JOIN pb_biz b ON b.id = i.biz_id WHERE i.license = ? ORDER BY (i.status = ?) DESC, i.id DESC LIMIT 30', { p.license, 'pending' }) or {}) do
        out[#out + 1] = { id = i.id, from = i.blabel or '', reason = i.reason, amount = i.amount, fine = i.kind == 'fine', status = i.status, at = Ph.Stamp(i.at or 0) }
    end
    return { list = out, bank = p.row.bank }
end
DATA.garage = function(src)
    local p = G.Get(src)
    local out, pts = {}, {}
    for _, g in ipairs(G.Garage and G.Garage.Points() or {}) do pts[g.id] = g.label end
    for _, v in ipairs(G.Garage and G.Garage.Owned(p.license) or {}) do
        out[#out + 1] = { plate = v.plate, label = v.label or v.model or v.plate, state = v.state, garage = pts[v.garage] or '' }
    end
    return { list = out }
end
DATA.gps = function() return { places = places() } end
DATA.notes = function(src)
    local p = G.Get(src)
    local out = {}
    for _, n in ipairs(DB.q('SELECT id, title, body, updated FROM pb_phone_notes WHERE license = ? ORDER BY updated DESC, id DESC LIMIT 60', { p.license }) or {}) do out[#out + 1] = { id = n.id, title = n.title, body = n.body, at = Ph.Stamp(n.updated) } end
    return { list = out }
end
DATA.settings = function(src)
    local p = G.Get(src)
    local pf = prefs(p.license)
    return { wall = pf.wall, walls = WALLS, dnd = pf.dnd, sound = pf.sound, number = Ph.Number(p.license), name = Ph.Display(src), iban = G.Bank and G.Bank.Iban(p.license) or '' }
end
function Ph.Data(src, name, s)
    local fn = DATA[name]
    if not fn then return nil end
    local ok, d = pcall(fn, src, s or {})
    return ok and d or nil
end

-- Actions -------------------------------------------------------------------------------------------------------------------------------------
local ACT = Ph.ACT
local function cleanText(s, n) return PB.Trim(PB.Sanitize(tostring(s or ''), n)) end

ACT.set_wall = function(_, src, p)
    local w = tostring(p.wall or '')
    local ok = false
    for _, k in ipairs(WALLS) do if k == w then ok = true end end
    if not ok then return false, 'Fond inconnu.' end
    local pl = G.Get(src)
    local pf = prefs(pl.license) pf.wall = w
    savePrefs(pl.license, pf)
    return true, 'Fond d\'écran changé.', 'settings'
end
ACT.set_dnd = function(_, src, p)
    local pl = G.Get(src)
    local pf = prefs(pl.license) pf.dnd = p.on == true
    savePrefs(pl.license, pf)
    return true, pf.dnd and 'Ne pas déranger activé.' or 'Notifications rétablies.', 'settings'
end
ACT.set_sound = function(_, src, p)
    local pl = G.Get(src)
    local pf = prefs(pl.license) pf.sound = p.on == true
    savePrefs(pl.license, pf)
    return true, pf.sound and 'Sons activés.' or 'Sons coupés.', 'settings'
end

ACT.note_save = function(_, src, p)
    local pl = G.Get(src)
    local title, body = cleanText(p.title, 60), PB.Sanitize(tostring(p.body or ''):gsub('\r', ''), 1500)
    if title == '' and body == '' then return false, 'Écris quelque chose.' end
    if title == '' then title = (body:gsub('\n.*', '')):sub(1, 40) end
    local id = math.floor(tonumber(p.id) or 0)
    if id > 0 then
        local own = DB.one('SELECT id FROM pb_phone_notes WHERE id = ? AND license = ?', { id, pl.license })
        if not own then return false, 'Note introuvable.' end
        DB.exec('UPDATE pb_phone_notes SET title = ?, body = ?, updated = ? WHERE id = ?', { title, body, now(), id })
    else
        local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_notes WHERE license = ?', { pl.license })
        if n and n.n >= 40 then return false, 'Maximum 40 notes : supprime-en une.' end
        DB.insert('INSERT INTO pb_phone_notes (license, title, body, updated) VALUES (?, ?, ?, ?)', { pl.license, title, body, now() })
    end
    return true, 'Note enregistrée.', 'notes'
end
ACT.note_del = function(_, src, p)
    local pl = G.Get(src)
    DB.exec('DELETE FROM pb_phone_notes WHERE id = ? AND license = ?', { math.floor(tonumber(p.id) or 0), pl.license })
    return true, 'Note supprimée.', 'notes'
end

ACT.gps_set = function(_, src, p)
    local id = math.floor(tonumber(p.id) or 0)
    for _, pl in ipairs(places()) do
        if pl.id == id then TriggerClientEvent('pb:g:phone:gps', src, pl.x, pl.y, pl.label) return true, 'Itinéraire placé : ' .. pl.label .. '.', 'gps' end
    end
    return false, 'Lieu inconnu.'
end
ACT.gps_clear = function(_, src)
    TriggerClientEvent('pb:g:phone:gps', src, nil, nil, nil)
    return true, 'Itinéraire effacé.', 'gps'
end
ACT.gps_car = function(_, src, p)
    local pl = G.Get(src)
    local plate = tostring(p.plate or '')
    local mine
    for _, v in ipairs(G.Garage and G.Garage.Owned(pl.license) or {}) do if v.plate == plate then mine = v end end
    if not mine then return false, 'Ce véhicule ne t\'appartient pas.' end
    if mine.state ~= 'out' then return false, 'Ce véhicule est rangé : rien à localiser.' end
    local v = G.Garage.Vehicle(plate)
    local ok, ent = pcall(function() return NetworkGetEntityFromNetworkId(v and v.net or 0) end)
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) then return false, 'Véhicule introuvable (trop loin ou plus dans le monde).' end
    local c = GetEntityCoords(ent)
    TriggerClientEvent('pb:g:phone:gps', src, c.x, c.y, mine.label or plate)
    return true, 'Ton véhicule est repéré sur la carte.', 'garage'
end

ACT.pay_bill = function(_, src, p)
    if not (G.Biz and G.Biz.PayInvoice) then return false, 'Paiement indisponible.' end
    local ok, inv = G.Biz.PayInvoice(src, p.id)
    if not ok then return false, inv end
    return true, ('Facture réglée : %s.'):format(money(inv.amount)), 'bills'
end

ACT.bank_send = function(_, src, p)
    local me = G.Get(src)
    local num = tostring(p.num or '')
    if not Ph.ValidNumber(num) then return false, 'Numéro invalide (ex. 555-0123).' end
    local lic = Ph.LicenseOf(num)
    if not lic then return false, "Ce numéro n'existe pas." end
    if lic == me.license then return false, "Tu ne peux pas t'envoyer de l'argent." end
    local iban = G.Bank and G.Bank.Iban(lic)
    if not iban then return false, 'Compte du destinataire introuvable.' end
    local ok, msg = G.Bank.Transfer(src, { amount = p.amount, iban = iban, note = p.note }, 'phone')
    return ok, msg, 'bank'
end

-- Appui sur le bouton « ouvrir » : rien de plus ici ; les évènements d'ouverture/fermeture restent dans phone.lua.
-- Notification de message : le son ne part que si le destinataire n'a pas activé « ne pas déranger ».
function Ph.QuietFor(license) local pf = prefs(license) return pf.dnd end
