-- Magasins : vêtements, supérettes (nourriture et boissons), concessions. Emplacements, catalogues, prix et points de livraison se règlent dans le panel.
-- Chaque achat est validé par le serveur : distance, article présent au catalogue, quantité, paiement.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('shops.edit', 'Créer et modifier des magasins', 'shops')
P.Register('shops.delete', 'Supprimer des magasins', 'shops', true)

PB.Migrate('041_game_shops', 'Magasins en jeu', {
    [[CREATE TABLE IF NOT EXISTS pb_shops (
        id INT NOT NULL AUTO_INCREMENT, kind VARCHAR(12) NOT NULL DEFAULT 'store', label VARCHAR(48) NOT NULL DEFAULT '',
        x DOUBLE NOT NULL DEFAULT 0, y DOUBLE NOT NULL DEFAULT 0, z DOUBLE NOT NULL DEFAULT 0, h DOUBLE NOT NULL DEFAULT 0,
        sprite INT NOT NULL DEFAULT 52, color INT NOT NULL DEFAULT 2, blip TINYINT(1) NOT NULL DEFAULT 1, price BIGINT NOT NULL DEFAULT 0,
        spawn TEXT NULL, catalog MEDIUMTEXT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
})

PB.Migrate('079_shop_stock', 'Magasins : stock', {
    [[CREATE TABLE IF NOT EXISTS pb_shop_stock (shop INT NOT NULL, item VARCHAR(32) NOT NULL, qty INT NOT NULL DEFAULT 0, PRIMARY KEY (shop, item))]],
})
PB.Migrate('211_clerk_pos', 'Magasins : position du vendeur derrière le comptoir', {
    [[CREATE TABLE IF NOT EXISTS pb_clerk_pos (shop_id INT NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, h DOUBLE NOT NULL DEFAULT 0, PRIMARY KEY (shop_id))]],
})
PB.Migrate('073_shop_opts', 'Magasins : options (apparence, vendeur, horaires, accès, remise)', {
    [[ALTER TABLE pb_shops ADD COLUMN opts MEDIUMTEXT NULL]],
})

local KINDS = { clothes = 'Vêtements', store = 'Supérette (nourriture et boissons)', dealer = 'Concession de véhicules', weapons = 'Armurerie (armes, munitions, accessoires)', barber = 'Coiffeur / barbier' }
local SPRITE = { clothes = 73, store = 52, dealer = 225, weapons = 110, barber = 71 }
local function styling(k) return k == 'clothes' or k == 'barber' end   -- passage payant (pas de catalogue ni de panier)
local function goods(k) return k == 'store' or k == 'weapons' end   -- les deux se vendent comme des articles du sac
local LIMIT = 200

PB.Cfg.Define('shops', {})
local settings = Form.Cfg({
    ns = 'shops', id = 'settings', title = 'Réglages des magasins', perm = 'shops.edit', cols = 2,
    desc = "S'applique à tous les magasins.",
    fields = {
        { k = 'marker_distance', type = 'number', label = "Distance d'affichage du marqueur (m)", default = 20, min = 5, max = 80 },
        { k = 'use_distance', type = 'number', label = "Distance d'interaction (m)", default = 2, min = 1, max = 6, int = false, step = 0.5 },
        { k = 'c_marker', type = 'color', label = 'Couleur du marqueur', default = '#dfe2e7' },
        { k = 'pay_first', type = 'select', label = 'Payer d\'abord avec', opts = { { 'cash', 'Les espèces' }, { 'bank', 'La banque' } }, default = 'cash' },
        { k = 'delivery', type = 'select', label = 'Objets de la supérette', opts = { { 'auto', 'Automatique' }, { 'instant', 'Consommés tout de suite' }, { 'builtin', "Dans le sac (inventaire intégré)" }, { 'inventory', "Donnés à l'inventaire ox / qb" } }, default = 'auto',
          hint = "Automatique : dans le sac de Shadow Base." },
        { k = 'vehicle_images', type = 'toggle', label = 'Photos des véhicules (docs.fivem.net, nécessite Internet)', default = true, hint = "Sans connexion ou si le modèle n'existe pas, une illustration neutre est affichée." },
        { k = 'clothes_img', type = 'text', label = 'Images des vêtements (dossier ou adresse)', default = 'img/clothes/{sex}_{type}_{id}_{d}.png', maxlen = 200, wide = true,
          hint = "{sex} = male / female, {type} = clothing / prop, {id} = composant, {d} = modèle (0 = premier), {t} = variante. Par défaut : le dossier web/img/clothes de pb_panel (noms de fivem-greenscreener). Une image absente laisse le numéro." },
        { k = 'mask_price', type = 'number', label = 'Prix d\'un masque (magasin de masques et sacs)', default = 250, min = 0, max = 100000 },
        { k = 'bag_price_kg', type = 'number', label = 'Prix d\'un sac par kg porté en plus', default = 150, min = 0, max = 100000 },
        { k = 'plate_prefix', type = 'text', label = 'Début des plaques vendues', default = 'PB', maxlen = 3, pattern = '^[A-Z0-9]*$', hint = 'Majuscules et chiffres, 3 caractères au plus.' },
    },
})

-- Catalogues par défaut ----------------------------------------------------------------------------------------------------------------------
local DEFAULT_STORE = {
    { name = 'water', label = "Bouteille d'eau", price = 3, hunger = 0, thirst = 35, stress = 0 },
    { name = 'soda', label = 'Soda', price = 5, hunger = 0, thirst = 25, stress = -3 },
    { name = 'coffee', label = 'Café', price = 4, hunger = 0, thirst = 15, stress = -5 },
    { name = 'sandwich', label = 'Sandwich', price = 8, hunger = 35, thirst = 0, stress = 0 },
    { name = 'burger', label = 'Burger', price = 12, hunger = 50, thirst = -5, stress = -4 },
    { name = 'chips', label = 'Paquet de chips', price = 4, hunger = 18, thirst = -4, stress = -2 },
}
local DEFAULT_DEALER = {
    { model = 'blista', label = 'Blista', price = 15000, category = 'Compactes' },
    { model = 'brioso', label = 'Brioso', price = 10500, category = 'Compactes' },
    { model = 'issi3', label = 'Issi 3', price = 14800, category = 'Compactes' },
    { model = 'asea', label = 'Asea', price = 12000, category = 'Berlines' },
    { model = 'premier', label = 'Premier', price = 28500, category = 'Berlines' },
    { model = 'primo2', label = 'Primo 2', price = 18000, category = 'Berlines' },
    { model = 'fugitive', label = 'Fugitive', price = 25900, category = 'Berlines' },
    { model = 'sultan', label = 'Sultan', price = 38000, category = 'Berlines' },
    { model = 'felon', label = 'Felon', price = 42000, category = 'Coupés' },
    { model = 'zion', label = 'Zion', price = 36000, category = 'Coupés' },
    { model = 'oracle2', label = 'Oracle 2', price = 46000, category = 'Coupés' },
    { model = 'dominator', label = 'Dominator', price = 55000, category = 'Muscle' },
    { model = 'gauntlet', label = 'Gauntlet', price = 52000, category = 'Muscle' },
    { model = 'buffalo', label = 'Buffalo', price = 48000, category = 'Sportives' },
    { model = 'elegy2', label = 'Elegy RH8', price = 95000, category = 'Sportives' },
    { model = 'jester', label = 'Jester', price = 120000, category = 'Sportives' },
    { model = 'comet2', label = 'Comet', price = 110000, category = 'Sportives' },
    { model = 'ninef', label = '9F', price = 130000, category = 'Sportives' },
    { model = 'zentorno', label = 'Zentorno', price = 725000, category = 'Supercars' },
    { model = 'adder', label = 'Adder', price = 1000000, category = 'Supercars' },
    { model = 'turismor', label = 'Turismo R', price = 500000, category = 'Supercars' },
    { model = 'bati', label = 'Bati 801', price = 21000, category = 'Motos' },
    { model = 'akuma', label = 'Akuma', price = 9000, category = 'Motos' },
    { model = 'double', label = 'Double-T', price = 12000, category = 'Motos' },
    { model = 'sanchez', label = 'Sanchez', price = 8000, category = 'Motos' },
    { model = 'faggio', label = 'Faggio', price = 4000, category = 'Motos' },
    { model = 'baller', label = 'Baller', price = 45000, category = 'SUV' },
    { model = 'granger', label = 'Granger', price = 35000, category = 'SUV' },
    { model = 'cavalcade', label = 'Cavalcade', price = 40000, category = 'SUV' },
    { model = 'mesa', label = 'Mesa', price = 30000, category = 'SUV' },
    { model = 'sandking', label = 'Sandking XL', price = 45000, category = 'Tout-terrain' },
    { model = 'bifta', label = 'Bifta', price = 75000, category = 'Tout-terrain' },
    { model = 'kamacho', label = 'Kamacho', price = 115000, category = 'Tout-terrain' },
    { model = 'speedo', label = 'Speedo', price = 22000, category = 'Utilitaires' },
    { model = 'burrito', label = 'Burrito', price = 24000, category = 'Utilitaires' },
    { model = 'rumpo', label = 'Rumpo', price = 20000, category = 'Utilitaires' },
    { model = 'bison', label = 'Bison', price = 26000, category = 'Utilitaires' },
    { model = 'sadler', label = 'Sadler', price = 23000, category = 'Utilitaires' },
    { model = 'bmx', label = 'BMX', price = 500, category = 'Cyclistes' },
    { model = 'scorcher', label = 'Scorcher', price = 700, category = 'Cyclistes' },
    { model = 'dinghy', label = 'Dinghy', price = 60000, category = 'Bateaux' },
    { model = 'seashark', label = 'Seashark', price = 20000, category = 'Bateaux' },
    { model = 'maverick', label = 'Maverick', price = 780000, category = 'Hélicoptères' },
}

-- Options d'un magasin : apparence, vendeur (PNJ), horaires, accès, paiement, remise -------------------------------------------------------
local OPT_DEFAULTS = { tagline = '', banner = '', logo = '', accent = '#dfe2e7', npc_on = false, npc_model = 'mp_m_shopkeep_01', npc_scenario = 'WORLD_HUMAN_STAND_IMPATIENT',
    hours_on = false, open_h = 8, close_h = 22, job = '', min_grade = 0, pay_mode = 'both', discount = 0, max_qty = 10, permit = '',
    stock_on = false, stock_start = 20, stock_max = 50, restock_min = 0, restock_qty = 5, biz = '', need_clerk = false, wholesale = 50, test_sec = 20, test_ammo = 24, give_ammo = true, scope = 'all',
    seller_mode = 'auto', bell_secs = 120, drive_sec = 60, gta_all = true, gta_extra = false, gta_factor = 100 }
local OPT_FIELDS = {
    { k = 'tagline', type = 'text', label = 'Phrase d\'accueil', maxlen = 80, default = '', hint = "Affichée sous le nom dans l'interface d'achat." },
    { k = 'banner', type = 'asset', label = 'Bannière (depuis mon PC)', default = '', wide = true, maxw = 1000, maxh = 300 },
    { k = 'logo', type = 'asset', label = 'Logo (depuis mon PC)', default = '', maxw = 400, maxh = 160 },
    { k = 'accent', type = 'color', label = "Couleur d'accent de la boutique", default = '#dfe2e7' },
    { k = 'scope', type = 'select', label = 'Rayons proposés (magasin de vêtements)', opts = { { 'all', 'Tous les vêtements' }, { 'masks', 'Masques' }, { 'hats', 'Chapeaux, lunettes, oreilles' }, { 'tops', 'Hauts' }, { 'bottoms', 'Pantalons' }, { 'shoes', 'Chaussures' }, { 'accessories', 'Accessoires, sacs, montres' }, { 'masks_bags', 'Masques et sacs (vendus dans le sac)' } }, default = 'all', hint = "Toutes les pièces de base du jeu sont proposées dans le rayon choisi. « Masques » en fait une boutique de masques." },
    { k = 'npc_on', type = 'toggle', label = 'Vendeur (personnage) derrière le comptoir', default = false },
    { k = 'npc_model', type = 'cards', label = 'Vendeur', default = 'mp_m_shopkeep_01', opts = { { 'mp_m_shopkeep_01', 'Vendeur', 'img/peds/vendeur.svg' }, { 's_f_y_shop_low', 'Vendeuse', 'img/peds/vendeuse.svg' }, { 'a_m_y_business_01', 'Costume', 'img/peds/costume.svg' }, { 'a_m_m_business_01', 'Homme d\'affaires', 'img/peds/costume.svg' } }, hint = 'Le personnage qui se tient derrière le comptoir.' },
    { k = 'npc_scenario', type = 'select', label = 'Attitude du vendeur', opts = { { 'WORLD_HUMAN_STAND_IMPATIENT', 'Debout, attend' }, { 'WORLD_HUMAN_CLIPBOARD', 'Écrit sur un bloc' }, { 'WORLD_HUMAN_STAND_MOBILE', 'Au téléphone' }, { 'WORLD_HUMAN_GUARD_STAND', 'Garde' } }, default = 'WORLD_HUMAN_STAND_IMPATIENT' },
    { k = 'hours_on', type = 'toggle', label = 'Horaires d\'ouverture', default = false, hint = "Heure du serveur. Fermé : le magasin ne s'ouvre pas." },
    { k = 'open_h', type = 'number', label = 'Ouvre à (heure)', default = 8, min = 0, max = 23 },
    { k = 'close_h', type = 'number', label = 'Ferme à (heure)', default = 22, min = 0, max = 23, hint = "Si l'heure de fermeture est plus petite que l'ouverture, le magasin ferme après minuit." },
    { k = 'job', type = 'text', label = 'Réservé aux employés de (identifiant d\'entreprise)', default = '', maxlen = 32, pattern = '^[%w_%-]*$', hint = 'Vide = ouvert à tous.' },
    { k = 'min_grade', type = 'number', label = 'Grade minimum (si réservé)', default = 0, min = 0, max = 20 },
    { k = 'permit', type = 'select', label = "Permis exigé à l'entrée", opts = { { '', 'Aucun' }, { 'weapon', "Permis de port d'arme" } }, default = '', hint = "Le permis est délivré par la police (F2 › Délivrer un permis d'arme)." },
    { k = 'pay_mode', type = 'select', label = 'Moyens de paiement', opts = { { 'both', 'Espèces et banque' }, { 'cash', 'Espèces seulement' }, { 'bank', 'Carte (banque) seulement' } }, default = 'both' },
    { k = 'discount', type = 'number', label = 'Remise sur tous les prix (%)', default = 0, min = 0, max = 90 },
    { k = 'max_qty', type = 'number', label = 'Quantité maximum par article (supérette)', default = 10, min = 1, max = 10 },
    { k = 'stock_on', type = 'toggle', label = 'Stock limité (supérette)', default = false, hint = "Chaque achat diminue le stock ; à zéro l'article est épuisé." },
    { k = 'stock_start', type = 'number', label = 'Stock de départ par article', default = 20, min = 0, max = 1000 },
    { k = 'stock_max', type = 'number', label = 'Stock maximum par article', default = 50, min = 1, max = 1000 },
    { k = 'restock_min', type = 'number', label = 'Réapprovisionnement automatique (minutes, 0 = jamais)', default = 0, min = 0, max = 10080, hint = "Sans vendeur joueur, le magasin se remplit tout seul." },
    { k = 'restock_qty', type = 'number', label = 'Unités ajoutées à chaque réapprovisionnement', default = 5, min = 1, max = 1000 },
    { k = 'biz', type = 'text', label = 'Entreprise propriétaire (identifiant)', default = '', maxlen = 32, pattern = '^[%w_%-]*$', hint = "Vide = magasin de la ville. Sinon les ventes (hors TVA) vont dans la caisse de l'entreprise et ses employés en service peuvent réapprovisionner." },
    { k = 'need_clerk', type = 'toggle', label = "Un employé en service est obligatoire pour acheter", default = false, hint = "Nécessite une entreprise propriétaire. Aucun employé en service : le magasin est fermé." },
    { k = 'seller_mode', type = 'select', label = 'Paiement par vendeur', opts = { { 'auto', 'Automatique : vendeur seulement si une entreprise est liée' }, { 'always', 'Toujours (vendeur ou sonnette)' }, { 'off', 'Jamais : le client paie seul, tout de suite' } }, default = 'auto',
      hint = "Le client remplit son panier puis l'envoie au vendeur en service, qui l'encaisse (remboursement et ticket possibles). Sans vendeur, il sonne et peut payer seul après le délai." },
    { k = 'bell_secs', type = 'number', label = "Sonnette : délai avant de pouvoir payer seul (secondes)", default = 120, min = 10, max = 900 },
    { k = 'drive_sec', type = 'number', label = "Durée de l'essai d'un véhicule (secondes, 0 = pas d'essai)", default = 60, min = 0, max = 300, hint = "Le véhicule d'essai apparaît devant la concession ; il disparaît à la fin ou si le joueur s'éloigne trop." },
    { k = 'gta_all', type = 'toggle', label = 'Proposer tout le catalogue GTA (véhicules terrestres)', default = false, hint = "Ajoute les véhicules du jeu rangés par catégories. Les lignes du catalogue ci-dessous remplacent le prix / le nom d'un modèle." },
    { k = 'gta_extra', type = 'toggle', label = 'Y ajouter bateaux, hélicoptères, avions et vélos', default = false },
    { k = 'gta_factor', type = 'number', label = 'Prix du catalogue GTA (% des prix de départ)', default = 100, min = 10, max = 1000 },
    { k = 'wholesale', type = 'number', label = 'Coût du réapprovisionnement (% du prix de vente)', default = 50, min = 0, max = 100 },
    { k = 'test_sec', type = 'number', label = "Durée de l'essai d'une arme (secondes, 0 = pas de bouton « Tester »)", default = 20, min = 0, max = 120, hint = "L'arme est mise en main quelques secondes, avec des munitions de test, puis retirée. Rien n'est ajouté au sac." },
    { k = 'test_ammo', type = 'number', label = "Munitions de l'essai", default = 24, min = 1, max = 250 },
    { k = 'give_ammo', type = 'toggle', label = "Donner les munitions « avec l'arme » prévues dans le catalogue", default = true },
}
local function optsOf(raw)
    local o = PB.FromJson(raw, nil)
    if type(o) ~= 'table' then o = {} end
    local out = {}
    for k, v in pairs(OPT_DEFAULTS) do if o[k] == nil then out[k] = v else out[k] = o[k] end end
    return out
end

-- Lecture / validation -------------------------------------------------------------------------------------------------------------------------
local function decodeRow(r)
    return { id = r.id, kind = r.kind, label = r.label, x = r.x, y = r.y, z = r.z, h = r.h, sprite = r.sprite, color = r.color, blip = PB.ToBool(r.blip), price = r.price,
        spawn = PB.FromJson(r.spawn, nil), catalog = PB.FromJson(r.catalog, {}), enabled = PB.ToBool(r.enabled), opts = optsOf(r.opts) }
end

local function allShops(onlyEnabled)
    local out = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_shops' .. (onlyEnabled and ' WHERE enabled = 1' or '') .. ' ORDER BY kind, label') or {}) do out[#out + 1] = decodeRow(r) end
    return out
end

local function getShop(id)
    local r = DB.one('SELECT * FROM pb_shops WHERE id = ?', { PB.ToInt(id, 0) })
    return r and decodeRow(r) or nil
end

-- Vendeur d'un magasin : celui choisi dans les options ; une concession a toujours son vendeur en costume.
-- Position : celle posée au Builder (« position du vendeur »), sinon derrière le comptoir de la supérette GTA la plus proche, sinon le point du magasin.
local function npcOf(s, posMap)
    local n
    if s.kind == 'dealer' then
        local m = s.opts.npc_model
        n = { model = (s.opts.npc_on and m ~= 'mp_m_shopkeep_01' and m) or 'a_m_m_business_01', scenario = s.opts.npc_scenario }
    elseif s.opts.npc_on then n = { model = s.opts.npc_model, scenario = s.opts.npc_scenario } end
    if not n then return nil end
    local p = posMap and posMap[s.id] or (s.kind ~= 'dealer' and PB.ClerkSpot(s.x, s.y, s.z)) or nil
    if p then n.x, n.y, n.z, n.h = p.x, p.y, p.z, p.h end
    return n
end
function G.ShopClerkPositions()
    local map = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_clerk_pos') or {}) do map[tonumber(r.shop_id)] = { x = tonumber(r.x), y = tonumber(r.y), z = tonumber(r.z), h = tonumber(r.h) or 0 } end
    return map
end
-- Liste publique envoyée aux clients (sans catalogue : il est envoyé à l'ouverture, avec les prix du serveur).
function G.ShopList()
    local out = {}
    local posMap = G.ShopClerkPositions()
    for _, s in ipairs(allShops(true)) do out[#out + 1] = { id = s.id, kind = s.kind, label = s.label, x = s.x, y = s.y, z = s.z, h = s.h, sprite = s.sprite, color = s.color, blip = s.blip, price = styling(s.kind) and s.price or nil,
            npc = npcOf(s, posMap) } end
    return out
end

local function cleanImage(img, label)
    img = tostring(img or '')
    if img ~= '' and not (#img <= 400 and (img:match('^https://[^"\'()<>%s]+$') or img:match('^asset:[a-z0-9]+$') or img:match('^img/[%w_%-%./]+$'))) then return nil, 'Image de ' .. label .. " : adresse https://… ou image envoyée depuis le PC." end
    return img
end

-- Image par défaut : chaque article a TOUJOURS une image (celle du catalogue, sinon une illustration fournie, sinon la photo du véhicule).
local ICON_BY_NAME = { water = 'water', soda = 'soda', coffee = 'coffee', sandwich = 'sandwich', burger = 'burger', chips = 'chips' }
local GUN_WORDS = { { 'doubleaction', '_revolver' }, { 'revolver', '_revolver' }, { 'flaregun', '_pistol' }, { 'sniper', '_sniper' }, { 'marksmanrifle', '_sniper' }, { 'precisionrifle', '_sniper' }, { 'musket', '_sniper' },
    { 'pumpshotgun', '_shotgun' }, { 'shotgun', '_shotgun' }, { 'rayminigun', '_launcher' }, { 'minigun', '_launcher' }, { 'launcher', '_launcher' }, { 'rpg', '_launcher' }, { 'firework', '_launcher' }, { 'railgun', '_launcher' },
    { 'molotov', '_molotov' }, { 'petrolcan', '_molotov' }, { 'grenade', '_grenade' }, { 'stickybomb', '_grenade' }, { 'proxmine', '_grenade' }, { 'pipebomb', '_grenade' }, { 'bzgas', '_grenade' },
    { 'battleaxe', '_axe' }, { 'hatchet', '_axe' }, { 'hammer', '_axe' }, { 'golfclub', '_golf' }, { 'machete', '_machete' }, { 'knife', '_knife' }, { 'switchblade', '_knife' },
    { 'bat', '_bat' }, { 'crowbar', '_crowbar' }, { 'nightstick', '_bat' }, { 'wrench', '_crowbar' }, { 'flashlight', '_bat' }, { 'knuckle', '_knife' },
    { 'combatmg', '_rifle' }, { 'rifle', '_rifle' }, { 'carbine', '_rifle' }, { 'gusenberg', '_smg' }, { 'smg', '_smg' }, { 'pdw', '_smg' }, { 'machinepistol', '_smg' }, { 'tecpistol', '_smg' }, { 'pistol', '_pistol' }, { 'stungun', '_pistol' } }
function G.ItemImage(kind, it, withPhotos)
    if kind == 'dealer' then
        if it.image and it.image ~= '' then return it.image end
        if withPhotos ~= false and tostring(it.model or ''):match('^[a-z0-9_]+$') then return 'https://docs.fivem.net/vehicles/' .. it.model .. '.webp' end
        return 'img/cards/veh.jpg'
    end
    if it.image and it.image ~= '' then return it.image end
    local ox = G.OxImage and G.OxImage(it.name)
    if ox then return ox end
    local n = tostring(it.name or ''):lower()
    if ICON_BY_NAME[n] then return 'img/items/' .. ICON_BY_NAME[n] .. '.svg' end
    if kind == 'weapons' or it.type then
        if it.type == 'ammo' then return 'img/items/_ammo.svg' end
        for _, g in ipairs(GUN_WORDS) do if n:find(g[1], 1, true) then return 'img/items/' .. g[2] .. '.svg' end end
        return it.type == 'weapon' and 'img/items/_pistol.svg' or 'img/items/_item.svg'
    end
    if (it.hunger or 0) > 0 then return 'img/items/_food.svg' end
    if (it.thirst or 0) > 0 then return 'img/items/_drink.svg' end
    return 'img/items/_snack.svg'
end

local function cleanCatalog(kind, rows)
    if type(rows) ~= 'table' then return {}, nil end
    local out, seen = {}, {}
    if #rows > (kind == 'dealer' and 300 or kind == 'weapons' and 150 or 60) then return nil, 'Au plus ' .. (kind == 'dealer' and 300 or kind == 'weapons' and 150 or 60) .. ' lignes par catalogue.' end
    for _, r in ipairs(rows) do
        if type(r) == 'table' then
            if kind == 'store' then
                local name, label = tostring(r.name or ''):lower(), PB.Trim(PB.Sanitize(tostring(r.label or ''), 48))
                if not name:match('^[a-z0-9_]+$') or #name > 32 then return nil, 'Identifiant d\'objet invalide : « ' .. name .. ' » (minuscules, chiffres, _).' end
                if label == '' then return nil, 'Chaque objet doit avoir un nom affiché.' end
                if seen[name] then return nil, 'Objet en double : ' .. name end
                seen[name] = true
                local price = PB.ToInt(r.price, -1)
                if price < 0 or price > 1000000 then return nil, 'Prix invalide pour ' .. label .. '.' end
                local e = {}
                for _, k in ipairs({ 'hunger', 'thirst', 'stress' }) do
                    local v = tonumber(r[k]) or 0
                    if v < -100 or v > 100 then return nil, 'Effet « ' .. k .. ' » hors de -100 à 100.' end
                    e[k] = math.floor(v)
                end
                local img, ierr = cleanImage(r.image, label)
                if not img then return nil, ierr end
                out[#out + 1] = { name = name, label = label, price = price, hunger = e.hunger, thirst = e.thirst, stress = e.stress, category = PB.Sanitize(tostring(r.category or ''), 32), image = img }
            elseif kind == 'weapons' then
                local name, label = tostring(r.name or ''):lower(), PB.Trim(PB.Sanitize(tostring(r.label or ''), 48))
                if not name:match('^[a-z0-9_]+$') or #name > 32 then return nil, 'Identifiant d\'objet invalide : « ' .. name .. ' » (minuscules, chiffres, _).' end
                if label == '' then return nil, 'Chaque article doit avoir un nom affiché.' end
                if seen[name] then return nil, 'Article en double : ' .. name end
                seen[name] = true
                local price = PB.ToInt(r.price, -1)
                if price < 0 or price > 10000000 then return nil, 'Prix invalide pour ' .. label .. '.' end
                local typ = tostring(r.type or 'weapon')
                if typ ~= 'weapon' and typ ~= 'ammo' and typ ~= 'item' then return nil, 'Type invalide pour ' .. label .. ' (arme, munition ou accessoire).' end
                if typ == 'weapon' and not name:match('^weapon_') then return nil, "L'identifiant d'une arme commence par weapon_ (ex. weapon_pistol) : " .. name .. '.' end
                local ammo = tostring(r.ammo_item or ''):lower()
                if ammo ~= '' and (not ammo:match('^[a-z0-9_]+$') or #ammo > 32) then return nil, 'Munition invalide pour ' .. label .. '.' end
                local img, ierr = cleanImage(r.image, label)
                if not img then return nil, ierr end
                local function stat(k) local v = math.floor(tonumber(r[k]) or 0) if v < 0 or v > 100 then return nil end return v end
                local st = { stat('dmg'), stat('range'), stat('rate'), stat('mag') }
                if not (st[1] and st[2] and st[3] and st[4]) then return nil, 'Statistiques de ' .. label .. ' : de 0 à 100.' end
                local aq = PB.ToInt(r.ammo_qty, 0)
                if aq < 0 or aq > 500 then return nil, 'Munitions fournies avec ' .. label .. ' : de 0 à 500.' end
                out[#out + 1] = { type = typ, name = name, label = label, price = price, hunger = 0, thirst = 0, stress = 0, category = PB.Sanitize(tostring(r.category or ''), 32), image = img,
                    desc = PB.Sanitize(tostring(r.desc or ''), 140), ammo_item = ammo, ammo_qty = aq, dmg = st[1], range = st[2], rate = st[3], mag = st[4], test = r.test ~= false }
            elseif kind == 'dealer' then
                local model, label = tostring(r.model or ''):lower(), PB.Trim(PB.Sanitize(tostring(r.label or ''), 48))
                if not model:match('^[a-z0-9_]+$') or #model > 40 then return nil, 'Modèle invalide : « ' .. model .. ' ».' end
                if label == '' then return nil, 'Chaque véhicule doit avoir un nom affiché.' end
                if seen[model] then return nil, 'Véhicule en double : ' .. model end
                seen[model] = true
                local price = PB.ToInt(r.price, -1)
                if price < 0 or price > 100000000 then return nil, 'Prix invalide pour ' .. label .. '.' end
                local img, ierr = cleanImage(r.image, label)
                if not img then return nil, ierr end
                out[#out + 1] = { model = model, label = label, price = price, category = PB.Sanitize(tostring(r.category or ''), 32), image = img }
            end
        end
    end
    return out
end


-- Catalogue d'armurerie par défaut : noms de jeu courants, prix modifiables dans l'éditeur ------------------------------------------------------
local function wp(name, label, cat, price, ammo, aq, dmg, rng, rate, mag, desc) return { type = 'weapon', name = name, label = label, category = cat, price = price, ammo_item = ammo, ammo_qty = aq, dmg = dmg, range = rng, rate = rate, mag = mag, desc = desc, image = '', test = true } end
local DEFAULT_WEAPONS = {
    wp('weapon_pistol', 'Pistolet', 'Armes de poing', 2500, 'ammo_pistol', 1, 35, 40, 55, 40, 'Pistolet semi-automatique fiable.'),
    wp('weapon_combatpistol', 'Pistolet de combat', 'Armes de poing', 3200, 'ammo_pistol', 1, 40, 45, 55, 45, 'Plus précis, chargeur étendu.'),
    wp('weapon_appistol', 'Pistolet automatique', 'Armes de poing', 7500, 'ammo_pistol', 1, 32, 38, 85, 55, 'Tir en rafale, chargeur 18 coups.'),
    wp('weapon_pistol50', 'Pistolet .50', 'Armes de poing', 5200, 'ammo_pistol', 1, 60, 50, 40, 30, 'Très gros calibre.'),
    wp('weapon_snspistol', 'Pistolet compact', 'Armes de poing', 1800, 'ammo_pistol', 1, 28, 30, 50, 30, 'Petit, discret, peu puissant.'),
    wp('weapon_heavypistol', 'Pistolet lourd', 'Armes de poing', 4200, 'ammo_pistol', 1, 50, 45, 45, 40, 'Gros calibre, recul marqué.'),
    wp('weapon_vintagepistol', 'Pistolet vintage', 'Armes de poing', 3000, 'ammo_pistol', 1, 38, 38, 45, 35, 'Un classique élégant.'),
    wp('weapon_marksmanpistol', 'Pistolet de précision', 'Armes de poing', 6000, 'ammo_pistol', 1, 70, 65, 15, 10, 'Un coup, longue portée.'),
    wp('weapon_ceramicpistol', 'Pistolet céramique', 'Armes de poing', 3600, 'ammo_pistol', 1, 36, 38, 55, 40, 'Léger, difficile à détecter.'),
    wp('weapon_revolver', 'Revolver', 'Armes de poing', 6500, 'ammo_pistol', 1, 80, 55, 25, 15, 'Six coups, très puissant.'),
    wp('weapon_doubleaction', 'Revolver double action', 'Armes de poing', 5800, 'ammo_pistol', 1, 70, 50, 30, 15, 'Revolver à tir rapide.'),
    wp('weapon_flaregun', 'Pistolet de détresse', 'Armes de poing', 900, '', 0, 10, 30, 10, 5, 'Tire une fusée lumineuse.'),
    wp('weapon_stungun', 'Taser', 'Armes de poing', 1200, '', 0, 5, 10, 20, 10, 'Paralyse brièvement la cible.'),
    wp('weapon_assaultrifle', 'Fusil d\'assaut', 'Fusils d\'assaut', 22000, 'ammo_rifle', 1, 55, 65, 75, 60, 'Polyvalent et robuste.'),
    wp('weapon_carbinerifle', 'Carabine', 'Fusils d\'assaut', 24000, 'ammo_rifle', 1, 52, 68, 80, 70, 'Précise, bon chargeur.'),
    wp('weapon_advancedrifle', 'Fusil avancé', 'Fusils d\'assaut', 28000, 'ammo_rifle', 1, 50, 72, 78, 65, 'Léger et stable.'),
    wp('weapon_specialcarbine', 'Carabine spéciale', 'Fusils d\'assaut', 30000, 'ammo_rifle', 1, 54, 70, 80, 75, 'Cadence élevée, recul faible.'),
    wp('weapon_bullpuprifle', 'Fusil bullpup', 'Fusils d\'assaut', 26000, 'ammo_rifle', 1, 53, 66, 78, 65, 'Compact pour sa portée.'),
    wp('weapon_compactrifle', 'Carabine compacte', 'Fusils d\'assaut', 20000, 'ammo_rifle', 1, 48, 55, 80, 75, 'Petit gabarit, chargeur tambour.'),
    wp('weapon_gusenberg', 'Gusenberg', 'Fusils d\'assaut', 32000, 'ammo_smg', 1, 45, 50, 85, 80, 'Mitraillette à chargeur tambour.'),
    wp('weapon_combatmg', 'Mitrailleuse de combat', 'Fusils d\'assaut', 60000, 'ammo_mg', 1, 60, 75, 85, 100, 'Feu de suppression.'),
    wp('weapon_microsmg', 'Micro SMG', 'Mitraillettes', 12000, 'ammo_smg', 1, 30, 35, 90, 60, 'Cadence très élevée.'),
    wp('weapon_smg', 'SMG', 'Mitraillettes', 15000, 'ammo_smg', 1, 34, 45, 85, 60, 'Équilibrée.'),
    wp('weapon_assaultsmg', 'SMG d\'assaut', 'Mitraillettes', 18000, 'ammo_smg', 1, 38, 50, 85, 70, 'Plus de dégâts, plus lourde.'),
    wp('weapon_machinepistol', 'Pistolet-mitrailleur', 'Mitraillettes', 9500, 'ammo_smg', 1, 28, 30, 90, 40, 'Rafale compacte.'),
    wp('weapon_minismg', 'Mini SMG', 'Mitraillettes', 11000, 'ammo_smg', 1, 26, 32, 92, 50, 'Très compacte.'),
    wp('weapon_combatpdw', 'PDW de combat', 'Mitraillettes', 20000, 'ammo_smg', 1, 36, 52, 82, 70, 'Arme de défense personnelle.'),
    wp('weapon_tecpistol', 'SMG tactique', 'Mitraillettes', 10500, 'ammo_smg', 1, 29, 34, 88, 45, 'Compacte et vive.'),
    wp('weapon_raycarbine', 'Unholy Hellbringer', 'Mitraillettes', 45000, '', 0, 50, 60, 85, 80, 'Arme futuriste à énergie.'),
    wp('weapon_sniperrifle', 'Fusil de sniper', 'Fusils de sniper', 40000, 'ammo_sniper', 1, 90, 100, 15, 10, 'Longue portée, tir par tir.'),
    wp('weapon_heavysniper', 'Sniper lourd', 'Fusils de sniper', 65000, 'ammo_sniper', 1, 100, 100, 10, 6, 'Dégâts maximum.'),
    wp('weapon_marksmanrifle', 'Fusil de précision', 'Fusils de sniper', 48000, 'ammo_sniper', 1, 80, 95, 30, 8, 'Semi-automatique précis.'),
    wp('weapon_precisionrifle', 'Fusil de précision lourd', 'Fusils de sniper', 52000, 'ammo_sniper', 1, 85, 98, 20, 5, 'Tir de précision à grande distance.'),
    wp('weapon_pumpshotgun', 'Fusil à pompe', 'Fusils à pompe', 9000, 'ammo_shotgun', 1, 85, 25, 25, 30, 'Dévastateur à courte distance.'),
    wp('weapon_sawnoffshotgun', 'Fusil à canon scié', 'Fusils à pompe', 6500, 'ammo_shotgun', 1, 90, 15, 20, 20, 'Deux coups, très court.'),
    wp('weapon_assaultshotgun', 'Fusil à pompe d\'assaut', 'Fusils à pompe', 24000, 'ammo_shotgun', 1, 70, 28, 60, 50, 'Semi-automatique, chargeur 8 coups.'),
    wp('weapon_bullpupshotgun', 'Fusil à pompe bullpup', 'Fusils à pompe', 17000, 'ammo_shotgun', 1, 75, 28, 45, 40, 'Compact et puissant.'),
    wp('weapon_heavyshotgun', 'Fusil à pompe lourd', 'Fusils à pompe', 30000, 'ammo_shotgun', 1, 80, 30, 55, 60, 'Gros chargeur, gros dégâts.'),
    wp('weapon_minigun', 'Minigun', 'Armes lourdes', 250000, 'ammo_mg', 1, 70, 70, 100, 100, 'Rafale continue, très lourde.'),
    wp('weapon_rpg', 'Lance-roquettes', 'Armes lourdes', 180000, 'ammo_rocket', 1, 100, 90, 5, 1, 'Roquette explosive.'),
    wp('weapon_grenadelauncher', 'Lance-grenades', 'Armes lourdes', 120000, 'ammo_rocket', 1, 90, 70, 10, 10, 'Grenades à fragmentation.'),
    wp('weapon_compactlauncher', 'Lance-grenades compact', 'Armes lourdes', 95000, 'ammo_rocket', 1, 85, 60, 15, 10, 'Version légère.'),
    wp('weapon_rayminigun', 'Widowmaker', 'Armes lourdes', 300000, '', 0, 75, 75, 100, 100, 'Minigun à énergie.'),
    wp('weapon_firework', 'Lance-feux d\'artifice', 'Armes lourdes', 20000, 'ammo_rocket', 1, 40, 60, 10, 10, 'Pour les fêtes (ou presque).'),
    wp('weapon_railgun', 'Railgun', 'Armes lourdes', 350000, 'ammo_rocket', 1, 100, 100, 5, 1, 'Projectile électromagnétique.'),
    wp('weapon_hominglauncher', 'Lanceur guidé', 'Armes lourdes', 280000, 'ammo_rocket', 1, 100, 95, 5, 1, 'Missile à tête chercheuse.'),
    wp('weapon_musket', 'Mousquet', 'Armes lourdes', 4000, 'ammo_sniper', 1, 80, 50, 5, 1, 'Un coup, rechargement lent.'),
    wp('weapon_grenade', 'Grenade', 'Explosifs', 3500, '', 0, 90, 20, 5, 1, 'Explose après quelques secondes.'),
    wp('weapon_stickybomb', 'Bombe collante', 'Explosifs', 5200, '', 0, 95, 15, 5, 1, 'Se fixe, détonation à distance.'),
    wp('weapon_proxmine', 'Mine de proximité', 'Explosifs', 6500, '', 0, 95, 10, 5, 1, 'Explose au passage.'),
    wp('weapon_pipebomb', 'Bombe artisanale', 'Explosifs', 4500, '', 0, 90, 18, 5, 1, 'Tuyau explosif.'),
    wp('weapon_molotov', 'Cocktail Molotov', 'Explosifs', 800, '', 0, 50, 20, 5, 1, 'Bouteille incendiaire.'),
    wp('weapon_bzgas', 'Gaz BZ', 'Explosifs', 2500, '', 0, 20, 20, 5, 1, 'Gaz irritant.'),
    wp('weapon_smokegrenade', 'Grenade fumigène', 'Explosifs', 900, '', 0, 0, 20, 5, 1, 'Écran de fumée.'),
    wp('weapon_petrolcan', 'Jerrican d\'essence', 'Explosifs', 150, '', 0, 0, 5, 5, 1, 'Verse de l\'essence.'),
    wp('weapon_knife', 'Couteau', 'Armes blanches', 150, '', 0, 25, 5, 70, 0, 'Lame de 15 cm.'),
    wp('weapon_bat', 'Batte', 'Armes blanches', 120, '', 0, 30, 8, 50, 0, 'Batte de baseball en bois.'),
    wp('weapon_crowbar', 'Pied-de-biche', 'Armes blanches', 90, '', 0, 28, 8, 45, 0, 'Outil et arme improvisée.'),
    wp('weapon_machete', 'Machette', 'Armes blanches', 220, '', 0, 40, 9, 55, 0, 'Longue lame de débroussaillage.'),
    wp('weapon_golfclub', 'Club de golf', 'Armes blanches', 110, '', 0, 26, 9, 45, 0, 'Pour un swing peu orthodoxe.'),
    wp('weapon_hammer', 'Marteau', 'Armes blanches', 60, '', 0, 24, 6, 55, 0, 'Outil de menuisier.'),
    wp('weapon_hatchet', 'Hachette', 'Armes blanches', 180, '', 0, 38, 7, 50, 0, 'Petite hache.'),
    wp('weapon_battleaxe', 'Hache de combat', 'Armes blanches', 320, '', 0, 48, 9, 40, 0, 'Lourde, dévastatrice.'),
    wp('weapon_switchblade', 'Couteau à cran d\'arrêt', 'Armes blanches', 130, '', 0, 24, 5, 75, 0, 'Lame rétractable.'),
    wp('weapon_knuckle', 'Poing américain', 'Armes blanches', 80, '', 0, 22, 3, 80, 0, 'Pour les combats rapprochés.'),
    wp('weapon_nightstick', 'Matraque', 'Armes blanches', 100, '', 0, 22, 7, 60, 0, 'Matraque de service.'),
    wp('weapon_flashlight', 'Lampe torche', 'Armes blanches', 45, '', 0, 12, 7, 60, 0, 'Éclaire… et assomme.'),
    wp('weapon_wrench', 'Clé à molette', 'Armes blanches', 70, '', 0, 26, 6, 50, 0, 'Outil de mécano.'),
    wp('weapon_raypistol', 'Up-n-Atomizer', 'Armes de poing', 48000, '', 0, 45, 45, 60, 50, 'Pistolet à énergie.'),
    { type = 'ammo', name = 'ammo_pistol', label = 'Munitions 9 mm', category = 'Munitions', price = 90, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
    { type = 'ammo', name = 'ammo_shotgun', label = 'Cartouches calibre 12', category = 'Munitions', price = 120, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
    { type = 'ammo', name = 'ammo_smg', label = 'Munitions SMG', category = 'Munitions', price = 140, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
    { type = 'ammo', name = 'ammo_rifle', label = 'Munitions de fusil', category = 'Munitions', price = 180, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
    { type = 'ammo', name = 'ammo_sniper', label = 'Munitions de sniper', category = 'Munitions', price = 250, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
    { type = 'ammo', name = 'ammo_mg', label = 'Munitions de mitrailleuse', category = 'Munitions', price = 300, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
    { type = 'ammo', name = 'ammo_rocket', label = 'Roquettes et grenades', category = 'Munitions', price = 900, ammo_item = '', ammo_qty = 0, dmg = 0, range = 0, rate = 0, mag = 0, desc = '', image = '', test = false },
}
G.DefaultArmory = DEFAULT_WEAPONS
G.DefaultStore = DEFAULT_STORE
G.DefaultDealer = DEFAULT_DEALER

-- Les articles vendus doivent exister dans le sac et, pour les armes, dans le catalogue du module Armes (sinon on ne peut pas les équiper).
local function syncArmory(catalog)
    local W = G.Weapons
    if not (W and G.Inv and G.Inv.Def) then return end
    local cur, have, changed = W.Catalog(), {}, false
    for _, w in ipairs(cur) do have[w.item] = true end
    local function ensure(name, label, kind, stack, weight, usable)
        if not G.Inv.Def(name) then
            DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, ?, ?, ?, ?)', { name, label, weight, stack, kind, usable, '' })
            G.Inv.Ensure({ name = name, label = label })
        end
    end
    for _, e in ipairs(catalog) do
        if e.type == 'weapon' then
            ensure(e.name, e.label, 'weapon', 1, 1500, 1)
            if not have[e.name] then cur[#cur + 1] = { item = e.name, label = e.label, hash = e.name:upper(), ammo_item = e.ammo_item or '', permit = true, weight = 1500 } have[e.name] = true changed = true end
            if (e.ammo_item or '') ~= '' then ensure(e.ammo_item, e.ammo_item, 'ammo', 50, 250, 1) end
        elseif e.type == 'ammo' then ensure(e.name, e.label, 'ammo', 50, 250, 1)
        else ensure(e.name, e.label, 'misc', 10, 300, 0) end
    end
    if changed then PB.Cfg.Set('weapons', 'catalog', cur, 0, 'armurerie') end
    if W.Register then W.Register() end
end
G.SyncArmory = syncArmory
PB.OnReady(function()
    for _, r in ipairs(DB.q("SELECT catalog FROM pb_shops WHERE kind = 'weapons'") or {}) do
        local cat = PB.FromJson(r.catalog, {})
        if type(cat) == 'table' then pcall(syncArmory, cat) end
    end
end)

local SHOP_FIELDS = {
    { k = 'kind', type = 'select', label = 'Type de magasin', opts = { { 'store', KINDS.store }, { 'clothes', KINDS.clothes }, { 'dealer', KINDS.dealer }, { 'weapons', KINDS.weapons }, { 'barber', KINDS.barber } }, required = true },
    { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
    { k = 'coords', type = 'coords', label = 'Emplacement', required = true, wide = true },
    { k = 'spawn', type = 'coords', label = 'Sortie des véhicules (concession)', wide = true, hint = 'Où le véhicule acheté apparaît. Si vide : devant le magasin.' },
    { k = 'price', type = 'number', label = 'Prix du passage (vêtements, coiffeur)', default = 0, min = 0, max = 100000 },
    { k = 'blip', type = 'toggle', label = 'Afficher sur la carte', default = true },
    { k = 'sprite', type = 'number', label = 'Icône de la carte (n°)', default = 52, min = 0, max = 900 },
    { k = 'color', type = 'number', label = 'Couleur de la carte (n°)', default = 2, min = 0, max = 85 },
    { k = 'enabled', type = 'toggle', label = 'Actif', default = true },
}

PB.Action('shops.save', 'shops.edit', function(ctx, p)
    local v = p.values or {}
    local fields = {}
    for _, f in ipairs(SHOP_FIELDS) do fields[#fields + 1] = f end
    local c, err = PB.Validate(fields, v)
    if not c then return false, err end
    local okm = { mp_m_shopkeep_01 = true, s_f_y_shop_low = true, a_m_y_business_01 = true, a_m_m_business_01 = true }
    if v.npc_model ~= nil and not okm[v.npc_model] then v.npc_model = 'mp_m_shopkeep_01' end   -- ancien modèle libre : remplacé par le vendeur par défaut
    local oc, oerr = PB.Validate(OPT_FIELDS, v)
    if not oc then return false, oerr end
    for k, d in pairs(OPT_DEFAULTS) do if oc[k] == nil then oc[k] = d end end
    if oc.hours_on and oc.open_h == oc.close_h then return false, "Horaires : l'ouverture et la fermeture ne peuvent pas être à la même heure." end
    if oc.biz ~= '' and not (G.Biz and G.Biz.Get(oc.biz)) then return false, "Entreprise propriétaire « " .. oc.biz .. " » introuvable." end
    if oc.need_clerk and oc.biz == '' then return false, "« Un employé en service est obligatoire » demande une entreprise propriétaire." end
    if oc.stock_start > oc.stock_max then return false, 'Le stock de départ dépasse le stock maximum.' end
    if oc.job ~= '' and not (G.Biz and G.Biz.Get(oc.job)) then return false, "Entreprise « " .. oc.job .. " » introuvable." end
    if c.coords.x == 0 and c.coords.y == 0 then return false, 'Place le magasin : clique sur « Ma position » en te mettant à l\'endroit voulu en jeu.' end
    if c.spawn and c.spawn.x == 0 and c.spawn.y == 0 then c.spawn = nil end
    local id = PB.ToInt(p.id, 0)
    local before = id > 0 and getShop(id) or nil
    if id > 0 and not before then return false, 'Magasin introuvable.' end
    if not before and (tonumber(DB.scalar('SELECT COUNT(*) FROM pb_shops')) or 0) >= LIMIT then return false, 'Limite de ' .. LIMIT .. ' magasins atteinte.' end
    local catalog = {}
    if not styling(c.kind) then
        local cat, cerr = cleanCatalog(c.kind, v.catalog)
        if not cat then return false, cerr end
        catalog = cat
    end
    if c.kind == 'weapons' then syncArmory(catalog) end
    local row = { kind = c.kind, label = c.label, x = c.coords.x, y = c.coords.y, z = c.coords.z, h = c.coords.h or 0, sprite = c.sprite or SPRITE[c.kind], color = c.color or 2, blip = c.blip and 1 or 0,
        price = c.price or 0, spawn = c.spawn and PB.Json(c.spawn) or nil, catalog = PB.Json(catalog), enabled = c.enabled and 1 or 0, opts = PB.Json(oc) }
    if before then
        row.id = id
        DB.upsert('pb_shops', row, { 'id' })
    else
        local keys, qs, params = {}, {}, {}
        for _, k in ipairs(PB.Keys(row)) do keys[#keys + 1] = k qs[#qs + 1] = '?' params[#params + 1] = row[k] end
        id = DB.insert('INSERT INTO pb_shops (' .. table.concat(keys, ',') .. ') VALUES (' .. table.concat(qs, ',') .. ')', params)
    end
    G.PushConfig()
    ctx.audit('config', before and 'magasin.modifier' or 'magasin.creer', c.label, before and { label = before.label, kind = before.kind, items = #(before.catalog or {}) } or nil, { label = c.label, kind = c.kind, items = #catalog })
    ctx.toast = 'Magasin enregistré et envoyé aux joueurs connectés.'
    return true, { open = { tab = 'edit', params = { id = id } } }
end)

PB.Action('shops.addweapons', 'shops.edit', function(ctx, p)
    local s = getShop(p.id)
    if not s or s.kind ~= 'weapons' then return false, 'Armurerie introuvable.' end
    local have, added = {}, 0
    for _, it in ipairs(s.catalog) do have[it.name] = true end
    for _, it in ipairs(DEFAULT_WEAPONS) do
        if not have[it.name] and #s.catalog < 150 then s.catalog[#s.catalog + 1] = PB.DeepCopy(it) added = added + 1 end
    end
    if added == 0 then return false, 'Toutes les armes du jeu proposées par défaut sont déjà au catalogue.' end
    syncArmory(s.catalog)
    DB.exec('UPDATE pb_shops SET catalog = ? WHERE id = ?', { PB.Json(s.catalog), s.id })
    G.PushConfig()
    ctx.audit('config', 'magasin.armes', s.label, nil, { added = added })
    ctx.toast = added .. ' arme(s) et munitions ajoutées au catalogue.'
    return true, { open = { tab = 'edit', params = { id = s.id } } }
end)

PB.Action('shops.delete', 'shops.delete', function(ctx, p)
    local s = getShop(p.id)
    if not s then return false, 'Magasin introuvable.' end
    DB.exec('DELETE FROM pb_shops WHERE id = ?', { s.id })
    G.PushConfig()
    ctx.audit('config', 'magasin.supprimer', s.label, { label = s.label, kind = s.kind })
    ctx.toast = 'Magasin supprimé.'
    return true, { open = { tab = 'list' } }
end, { critical = true, confirm = { title = 'Supprimer ce magasin ?', text = 'Le magasin disparaît pour tous les joueurs.', danger = true } })

-- Achats (serveur) ------------------------------------------------------------------------------------------------------------------------------
local last = {}
local ORD, OSEQ, VIEW, DRIVE, olast = {}, 0, {}, {}, {}   -- commandes en cours, clerks qui regardent un magasin, essais de véhicules
local function throttle(src, ms)
    local now = GetGameTimer()
    if last[src] and now - last[src] < ms then return false end
    last[src] = now
    return true
end

local function near(src, s)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return true end   -- lecture impossible (tests / hors jeu)
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return true end
    local dx, dy, dz = c.x - s.x, c.y - s.y, c.z - s.z
    local d = PB.Cfg.Get('shops', 'use_distance', 2) + 6
    return dx * dx + dy * dy + dz * dz <= d * d
end

-- Prix finaux : catalogue × multiplicateur économique, TVA comprise (voir le module Économie).
local function fp(base) return G.Eco and G.Eco.Final(base) or base end
local function book(src, s, total, what)
    if not G.Eco or total <= 0 then return end
    local p = G.Get(src)
    G.Eco.Book('state', G.Eco.TaxIn(total), 'TVA ' .. s.label .. (what and (' · ' .. what) or ''), p and p.license or '')
end
-- prix d'un magasin : catalogue × économie, puis remise du magasin
local function sp(s, base)
    local v = fp(base)
    local d = tonumber(s.opts and s.opts.discount) or 0
    if d > 0 then v = math.floor(v * (100 - d) / 100 + 0.5) end
    return v
end
local stockOf
local function priced(catalog, s)
    local out = {}
    for _, it in ipairs(catalog or {}) do
        local c = {} for k, v in pairs(it) do c[k] = v end
        c.price = sp(s, it.price)
        if goods(s.kind) then c.stock = stockOf(s, it.name) end
        c.image = G.ItemImage(s.kind, it, PB.Cfg.Get('shops', 'vehicle_images', true))
        if s.kind == 'dealer' and G.VehCat and G.VehCat.StatOf then
            local st = G.VehCat.StatOf(it.category)
            c.spd, c.seats = st.speed, st.seats
            local cs = G.Inv and G.VehTrunk and G.VehTrunk.Cap and G.VehTrunk.Cap(st.gta)
            if cs then c.slots, c.kg = cs[1], math.floor(cs[2] / 1000) end
        end
        out[#out + 1] = c
    end
    return out
end

-- Catalogue d'une concession : lignes du panel (prioritaires) + catalogue GTA complet si activé. Renvoie une liste sans prix final.
local function dealerList(s)
    local out, have = {}, {}
    for _, it in ipairs(s.catalog or {}) do out[#out + 1] = it have[it.model] = true end
    local o = s.opts or {}
    if o.gta_all and G.VehCat then
        local classes
        if o.gta_extra then classes = {} for _, c in ipairs(G.VehCat.classes) do classes[c.id] = true end end
        for _, v in ipairs(G.VehCat.Select(classes, o.gta_factor)) do if not have[v.model] then out[#out + 1] = v end end
    end
    return out
end
G.DealerList = dealerList
local function dealerCats(s, list)
    local order, cnt, first = {}, {}, {}
    for _, v in ipairs(list) do
        local c = (v.category and v.category ~= '') and v.category or 'Autres'
        if not cnt[c] then cnt[c] = 0 order[#order + 1] = c first[c] = v end
        cnt[c] = cnt[c] + 1
    end
    local out = {}
    for _, c in ipairs(order) do out[#out + 1] = { id = c, count = cnt[c], image = G.ItemImage('dealer', first[c], PB.Cfg.Get('shops', 'vehicle_images', true)) } end
    return out
end
-- seller : le client paie via un vendeur / une sonnette ; direct : il paie seul tout de suite
local function flowOf(s)
    local m = s.opts and s.opts.seller_mode or 'auto'
    if styling(s.kind) then return 'direct' end
    if m == 'always' then return 'seller' end
    if m == 'off' then return 'direct' end
    return ((s.opts.biz or '') ~= '' and G.Biz) and 'seller' or 'direct'
end

-- Stock : une ligne absente = stock de départ
stockOf = function(s, name)
    if not (s.opts and s.opts.stock_on) then return nil end
    local r = DB.one('SELECT qty FROM pb_shop_stock WHERE shop = ? AND item = ?', { s.id, name })
    return r and tonumber(r.qty) or (tonumber(s.opts.stock_start) or 0)
end
local function stockSet(s, name, qty)
    qty = math.max(0, math.min(math.floor(qty), tonumber(s.opts.stock_max) or 50))
    DB.exec('REPLACE INTO pb_shop_stock (shop, item, qty) VALUES (?, ?, ?)', { s.id, name, qty })
    return qty
end
G.ShopStock = stockOf
local function clerks(s)
    local n = 0
    if (s.opts.biz or '') == '' or not G.Biz then return 0 end
    for src in pairs(G.Players()) do local j = G.Biz.Job(src) if j and j.biz == s.opts.biz and j.onDuty then n = n + 1 end end
    return n
end
local function isClerk(src, s)
    if (s.opts.biz or '') == '' or not G.Biz then return false end
    local j = G.Biz.Job(src)
    return j ~= nil and j.biz == s.opts.biz and j.onDuty
end

-- Horaires et réservation aux employés
local function access(src, s)
    local o = s.opts or {}
    if o.hours_on then
        local h = tonumber(os.date('%H', os.time())) or 0
        local op, cl = tonumber(o.open_h) or 8, tonumber(o.close_h) or 22
        local open
        if op < cl then open = h >= op and h < cl else open = h >= op or h < cl end
        if not open then return false, ('Fermé : ouvert de %02d h à %02d h.'):format(op, cl) end
    end
    if (o.job or '') ~= '' then
        local j = G.Biz and G.Biz.Job(src)
        if not j or j.biz ~= o.job or (j.grade or 0) < (tonumber(o.min_grade) or 0) then return false, 'Réservé aux employés de ce commerce.' end
    end
    if o.need_clerk and (o.biz or '') ~= '' and not isClerk(src, s) and clerks(s) == 0 then return false, "Fermé : aucun vendeur en service." end
    if (o.permit or '') == 'weapon' and not (G.Weapons and G.Weapons.HasPermit(src)) then return false, "Il faut un permis de port d'arme (à demander à la police)." end
    return true
end

-- Moyen de paiement imposé par le magasin
local function canPay(src, s, total)
    local m = s.opts and s.opts.pay_mode or 'both'
    if m == 'cash' then return (G.GetMoney(src, 'cash') or 0) >= total end
    if m == 'bank' then return (G.GetMoney(src, 'bank') or 0) >= total end
    return (G.GetMoney(src, 'cash') + G.GetMoney(src, 'bank')) >= total
end
local function pay(src, s, total)
    local m = s.opts and s.opts.pay_mode or 'both'
    if total <= 0 then return 'cash' end
    if m == 'cash' or m == 'bank' then
        if (G.GetMoney(src, m) or 0) < total then return nil end
        return G.Pay(src, total, m)
    end
    return G.Pay(src, total, PB.Cfg.Get('shops', 'pay_first', 'cash'))
end

local function openable(src)
    local p = G.Get(src)
    return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src))
end

local gearOf
-- Magasin « masques et sacs » : chaque article acheté arrive dans le sac du joueur (objet vêtement à équiper), pas sur la tenue.
local function bagPrice(s, kg) return sp(s, math.floor(kg * (tonumber(PB.Cfg.Get('shops', 'bag_price_kg', 150)) or 150))) end
gearOf = function(s)
    local bags, kgs = {}, G.Inv and G.Inv.BagKg and G.Inv.BagKg() or {}
    for _, b in ipairs(G.Inv and G.Inv.BAGS or {}) do
        local d, t = tostring(b.cloth):match('^bag:(%d+):(%d+)$')
        local kg = kgs[b.name]
        if d and kg then bags[#bags + 1] = { name = b.name, label = b.label, d = tonumber(d), t = tonumber(t), kg = kg, price = bagPrice(s, kg) } end
    end
    return { mask_price = sp(s, tonumber(PB.Cfg.Get('shops', 'mask_price', 250)) or 250), bags = bags }
end
RegisterNetEvent('pb:g:shop:gear', function(id, kind, d, t)
    local src = source
    if not openable(src) or not throttle(src, 600) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'clothes' or s.opts.scope ~= 'masks_bags' or not near(src, s) or not access(src, s) then return end
    if not (G.Inv and G.Inv.Add) then return end
    d, t = math.floor(tonumber(d) or -1), math.floor(tonumber(t) or 0)
    if d < 0 or d > 400 or t < 0 or t > 40 then return end
    local item, label, price
    if kind == 'mask' then
        if d == 0 then return end   -- modèle 0 = pas de masque
        item = 'mask_' .. d .. (t > 0 and ('_' .. t) or '')
        label = 'Masque n°' .. (d + 1) .. (t > 0 and (' · variante ' .. (t + 1)) or '')
        if not G.Inv.EnsureCloth({ name = item, label = label, cloth = 'mask:' .. d .. ':' .. t, weight = 200, description = 'Équipe-le (case Masque).' }) then return end
        price = gearOf(s).mask_price
    elseif kind == 'bag' then
        for _, b in ipairs(gearOf(s).bags) do if b.d == d and b.t == t then item, label, price = b.name, b.label, b.price end end
        if not item then return end
    else return end
    local owner = 'p:' .. G.Get(src).license
    local can, why = true, nil
    if G.Inv.CanCarry then can, why = G.Inv.CanCarry(owner, item, 1) end
    if not can then G.Notify(src, { type = 'error', title = s.label, text = tostring(why or 'Ton sac est plein.') }) return end
    if price > 0 and not pay(src, s, price) then G.Notify(src, { type = 'error', text = "Tu n'as pas assez d'argent." }) return end
    local ok = G.Inv.Add(owner, item, 1)
    if not ok then G.Notify(src, { type = 'error', title = s.label, text = 'Impossible de le mettre dans ton sac.' }) return end
    book(src, s, price, label)
    G.Notify(src, { type = 'success', title = s.label, text = label .. ' ajouté à ton sac' .. (price > 0 and (' — ' .. price .. ' $') or '') .. '. Équipe-le depuis l\'inventaire.' })
    local p = G.Get(src)
    TriggerClientEvent('pb:g:shop:money', src, PB.Json({ cash = p.row.cash, bank = p.row.bank }))
end)

local function sendData(src, s, refresh)
    local st = G.Get(src).row
    local o = s.opts
    if isClerk(src, s) then VIEW[src] = s.id end
    TriggerClientEvent('pb:g:shop:data', src, PB.Json({ refresh = refresh == true or nil, id = s.id, kind = s.kind, label = s.label, price = styling(s.kind) and sp(s, s.price) or nil,
        tagline = o.tagline ~= '' and o.tagline or nil, banner = o.banner ~= '' and o.banner or nil, logo = o.logo ~= '' and o.logo or nil, accent = o.accent, discount = o.discount > 0 and o.discount or nil,
        pay_mode = o.pay_mode, max_qty = o.max_qty, restock = (goods(s.kind) and o.stock_on and isClerk(src, s)) or nil, stock_max = o.stock_on and o.stock_max or nil,
        items = goods(s.kind) and priced(s.catalog, s) or nil, test_sec = s.kind == 'weapons' and o.test_sec > 0 and o.test_sec or nil, who = (function() local i = G.Identity(src) return i and i.created and (((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) or nil end)(), cats = s.kind == 'dealer' and dealerCats(s, dealerList(s)) or nil, vehicles = (s.kind == 'dealer' and not s.opts.gta_all) and priced(s.catalog, s) or nil, drive_sec = s.kind == 'dealer' and (tonumber(o.drive_sec) or 0) > 0 and o.drive_sec or nil,
        flow = flowOf(s), order = G.ShopMyOrder and G.ShopMyOrder(src, s.id) or nil, bell_secs = o.bell_secs, clerk = isClerk(src, s) or nil, clerks = clerks(s), orders = isClerk(src, s) and G.ShopOrders and G.ShopOrders(s.id) or nil, cash = st.cash, bank = st.bank, spawn = s.kind == 'dealer' and (s.spawn or { x = s.x, y = s.y, z = s.z, h = s.h }) or nil,
        appearance = styling(s.kind) and PB.FromJson(st.appearance, nil) or nil, scope = s.kind == 'clothes' and o.scope or nil,
        sex = styling(s.kind) and (st.sex == 'f' or st.sex == 'female' or st.sex == 1) and 'female' or 'male', img = s.kind == 'clothes' and PB.Cfg.Get('shops', 'clothes_img', 'img/clothes/{sex}_{type}_{id}_{d}.png') or nil,
        gear = s.kind == 'clothes' and o.scope == 'masks_bags' and gearOf(s) or nil }))
end
RegisterNetEvent('pb:g:shop:open', function(id, refresh)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not openable(src) or (refresh ~= true and not throttle(src, 400)) then return end
    local s = getShop(id)
    if not s or not s.enabled or not near(src, s) then return end
    local okA, whyA = access(src, s)
    if not okA then if refresh ~= true then G.Notify(src, { type = 'warn', title = s.label, text = whyA }) end return end
    -- employé en service : ce qu'il a préparé (articles du catalogue présents dans son sac) est mis en rayon, sans frais
    if refresh ~= true and goods(s.kind) and s.opts.stock_on and isClerk(src, s) and G.Inv then
        local owner, moved = 'p:' .. G.Get(src).license, {}
        for _, it in ipairs(s.catalog) do
            local n = G.Inv.Count(owner, it.name)
            local room = (tonumber(s.opts.stock_max) or 50) - stockOf(s, it.name)
            local q = math.min(n, room)
            if q > 0 and G.Inv.Remove(owner, it.name, q) then stockSet(s, it.name, stockOf(s, it.name) + q) moved[#moved + 1] = q .. ' × ' .. it.label end
        end
        if #moved > 0 then
            if G.Inv.PushOwners then pcall(G.Inv.PushOwners, owner) end
            G.Notify(src, { type = 'success', title = s.label, text = 'Mis en rayon : ' .. table.concat(moved, ', ') .. '.' })
        end
    end
    sendData(src, s, refresh)
end)

local function deliver(src, item, qty)
    local mode = PB.Cfg.Get('shops', 'delivery', 'auto')
    local kind = PB.Inv.Detect()
    local canGive = (kind == 'ox' or kind == 'qb')
    if mode == 'builtin' or (mode == 'auto' and not canGive and G.Inv) then
        local owner = G.Inv.PlayerOwner(src)
        if not owner then return false, 'Joueur introuvable.' end
        G.Inv.Ensure(item)
        local ok, why = G.Inv.Add(owner, item.name, qty)
        if not ok then return false, 'Ton sac ne peut pas le contenir (' .. tostring(why):lower():gsub('%.$', '') .. ').' end
        G.Inv.PushOwners(owner)
        return true, 'builtin'
    end
    if mode == 'inventory' or (mode == 'auto' and canGive) then
        if not canGive then return false, "Aucun inventaire pris en charge n'est détecté : choisis « Consommés tout de suite » dans les réglages." end
        if not PB.Inv.Give(src, item.name, qty) then return false, "L'inventaire a refusé l'objet (plein ou objet inconnu)." end
        return true, 'inventory'
    end
    if (item.hunger or 0) == 0 and (item.thirst or 0) == 0 and (item.stress or 0) == 0 then return false, "Cet objet n'a aucun effet et il n'y a pas d'inventaire pour le ranger." end
    for _, k in ipairs({ 'hunger', 'thirst', 'stress' }) do if (item[k] or 0) ~= 0 then G.AddStatus(src, k, item[k] * qty) end end
    return true, 'instant'
end

RegisterNetEvent('pb:g:shop:buy', function(id, name, qty)
    local src = source
    if not openable(src) or not throttle(src, 300) then return end
    local s = getShop(id)
    if not s or not s.enabled or not goods(s.kind) or not near(src, s) then return end
    if flowOf(s) ~= 'direct' then G.Notify(src, { type = 'warn', title = s.label, text = 'Ce magasin passe par un vendeur : envoie ton panier.' }) return end
    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 or qty > math.min(10, tonumber(s.opts.max_qty) or 10) then return end
    if not access(src, s) then return end
    local item
    for _, it in ipairs(s.catalog) do if it.name == name then item = it end end
    if not item then return end
    local total = sp(s, item.price) * qty
    local have = stockOf(s, item.name)
    if have and have < qty then G.Notify(src, { type = 'warn', title = s.label, text = have <= 0 and ('%s : épuisé.'):format(item.label) or ('Il n\'en reste que %d.'):format(have) }) return end
    if total > 0 and not canPay(src, s, total) then G.Notify(src, { type = 'error', text = (s.opts.pay_mode == 'cash' and "Ce magasin n'accepte que les espèces, et tu n'en as pas assez." or s.opts.pay_mode == 'bank' and "Ce magasin n'accepte que la carte, et ton compte est insuffisant." or "Tu n'as pas assez d'argent.") }) return end
    -- on vérifie la livraison avant de débiter : pas de paiement perdu
    local snapshot = { hunger = G.GetStatus(src, 'hunger'), thirst = G.GetStatus(src, 'thirst'), stress = G.GetStatus(src, 'stress') }
    local ok, how = deliver(src, item, qty)
    if not ok then G.Notify(src, { type = 'error', text = how }) return end
    local acc = pay(src, s, total)
    if total > 0 and not acc then
        for k, v in pairs(snapshot) do local cur = G.GetStatus(src, k) G.AddStatus(src, k, v - cur) end
        if how == 'builtin' then G.Inv.Remove(G.Inv.PlayerOwner(src), item.name, qty) G.Inv.PushOwners(G.Inv.PlayerOwner(src)) end
        G.Notify(src, { type = 'error', text = "Paiement impossible." })
        return
    end
    book(src, s, total, item.name)
    if have then stockSet(s, item.name, have - qty) end
    if (s.opts.biz or '') ~= '' and G.Eco and G.Biz and G.Biz.Get(s.opts.biz) and total > 0 then
        local tax = G.Eco.TaxIn and G.Eco.TaxIn(total) or 0
        G.Eco.Book('biz:' .. s.opts.biz, total - tax, 'Vente ' .. s.label .. ' · ' .. item.name, G.Get(src).license)
    end
    if item.type == 'weapon' and s.opts.give_ammo and (item.ammo_item or '') ~= '' and (item.ammo_qty or 0) > 0 then
        local okA = deliver(src, { name = item.ammo_item, label = item.ammo_item }, item.ammo_qty * qty)
        if not okA then G.Notify(src, { type = 'warn', title = s.label, text = "Les munitions offertes n'ont pas pu être ajoutées (sac plein)." }) end
    end
    G.Notify(src, { type = 'success', title = s.label, text = ('%d × %s — %s $'):format(qty, item.label, total) })
    TriggerEvent('pb_panel:purchase', src, { shop = s.id, kind = s.kind, item = item.name, qty = qty, total = total })
    local p = G.Get(src)
    TriggerClientEvent('pb:g:shop:money', src, PB.Json({ cash = p.row.cash, bank = p.row.bank }))
    if have then sendData(src, getShop(s.id), true) end
end)

-- Essai d'une arme : elle est mise en main quelques secondes côté joueur (munitions de test), puis retirée. Rien n'entre dans le sac.
RegisterNetEvent('pb:g:shop:test', function(id, name)
    local src = source
    if not openable(src) or not throttle(src, 1500) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'weapons' or not near(src, s) or not access(src, s) then return end
    local sec = tonumber(s.opts.test_sec) or 0
    if sec <= 0 then return end
    local item
    for _, it in ipairs(s.catalog) do if it.name == name then item = it end end
    if not item or item.type ~= 'weapon' or item.test == false then return end
    TriggerClientEvent('pb:g:shop:testweapon', src, PB.Json({ hash = item.name:upper(), seconds = sec, ammo = tonumber(s.opts.test_ammo) or 24 }))
    TriggerEvent('pb_panel:weaponTest', src, { shop = s.id, item = item.name })
end)

-- Réapprovisionnement par un employé en service (coût prélevé sur la caisse de l'entreprise) ---------------------------------------------
RegisterNetEvent('pb:g:shop:restock', function(id, name, qty)
    local src = source
    if not openable(src) or not throttle(src, 400) then return end
    local s = getShop(id)
    if not s or not s.enabled or not goods(s.kind) or not s.opts.stock_on or not near(src, s) then return end
    if not isClerk(src, s) then G.Notify(src, { type = 'error', title = s.label, text = "Réservé aux employés en service de l'entreprise." }) return end
    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 or qty > 100 then return end
    local item
    for _, it in ipairs(s.catalog) do if it.name == name then item = it end end
    if not item then return end
    local have = stockOf(s, item.name)
    local room = (tonumber(s.opts.stock_max) or 50) - have
    if room <= 0 then G.Notify(src, { type = 'warn', title = s.label, text = 'Le rayon est plein.' }) return end
    qty = math.min(qty, room)
    local cost = math.floor(sp(s, item.price) * qty * (tonumber(s.opts.wholesale) or 50) / 100 + 0.5)
    if cost > 0 then
        if (G.Eco.Balance('biz:' .. s.opts.biz) or 0) < cost then G.Notify(src, { type = 'error', title = s.label, text = ("La caisse de l'entreprise ne couvre pas %s $."):format(cost) }) return end
        G.Eco.Book('biz:' .. s.opts.biz, -cost, 'Réapprovisionnement ' .. s.label .. ' · ' .. item.name, G.Get(src).license)
    end
    stockSet(s, item.name, have + qty)
    PB.Audit.Log('economie', 'shop.restock', src, s.label, item.name, nil, { qty = qty, cost = cost })
    G.Notify(src, { type = 'success', title = s.label, text = ('+%d × %s (coût %s $).'):format(qty, item.label, cost) })
    sendData(src, getShop(s.id), true)
end)

-- Réapprovisionnement automatique
CreateThread(function()
    local lastAuto = {}
    while true do
        Wait(60000)
        for _, s in ipairs(allShops(true)) do
            local o = s.opts
            if goods(s.kind) and o.stock_on and (tonumber(o.restock_min) or 0) > 0 and (o.biz or '') == '' then
                local t = os.time()
                lastAuto[s.id] = lastAuto[s.id] or t
                if t - lastAuto[s.id] >= o.restock_min * 60 then
                    lastAuto[s.id] = t
                    for _, it in ipairs(s.catalog) do stockSet(s, it.name, stockOf(s, it.name) + (tonumber(o.restock_qty) or 5)) end
                end
            end
        end
    end
end)

local function newPlate()
    local pre = PB.Cfg.Get('shops', 'plate_prefix', 'PB')
    local chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789'
    for _ = 1, 30 do
        local pl = pre
        while #pl < 8 do local i = math.random(#chars) pl = pl .. chars:sub(i, i) end
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { pl }) then return pl end
    end
    return nil
end

local function findVehicle(s, model)
    for _, it in ipairs(dealerList(s)) do if it.model == model then return it end end
end
-- Achat d'un véhicule (sans les contrôles de distance / flux) : plaque unique, enregistrement, apparition. Renvoie ok, plaque | message.
local function sellVehicle(src, s, v, vprice)
    if not canPay(src, s, vprice) then return false, "Tu n'as pas assez d'argent (moyen de paiement accepté : " .. (s.opts.pay_mode == 'cash' and 'espèces' or s.opts.pay_mode == 'bank' and 'carte' or 'espèces ou carte') .. ')' end
    if G.Garage then
        local owned = DB.one("SELECT COUNT(*) AS n FROM pb_vehicles WHERE license = ? AND gang = ''", { G.Get(src).license })
        local mx = PB.Cfg.Get('garage', 'max_vehicles', 12)
        if owned and owned.n >= mx then return false, ('Tu possèdes déjà %d véhicules (maximum).'):format(mx) end
    end
    local plate = newPlate()
    if not plate then return false, 'Aucune plaque disponible, réessaie.' end
    local acc = pay(src, s, vprice)
    if vprice > 0 and not acc then return false, 'Paiement impossible.' end
    local lic = G.Get(src).license
    DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price) VALUES (?, ?, ?, ?, ?, ?)', { lic, plate, v.model, v.label, os.time(), vprice })
    if G.Garage then G.Garage.MarkOut(plate) end
    book(src, s, vprice, v.model)
    if (s.opts.biz or '') ~= '' and G.Eco and G.Biz and G.Biz.Get(s.opts.biz) and vprice > 0 then
        local tax = G.Eco.TaxIn and G.Eco.TaxIn(vprice) or 0
        G.Eco.Book('biz:' .. s.opts.biz, vprice - tax, 'Vente ' .. s.label .. ' · ' .. v.model, lic)
    end
    G.Notify(src, { type = 'success', title = s.label, text = ('%s acheté — plaque %s'):format(v.label, plate) })
    TriggerEvent('pb_panel:purchase', src, { shop = s.id, kind = 'dealer', item = v.model, qty = 1, total = vprice, plate = plate })
    local p = G.Get(src)
    TriggerClientEvent('pb:g:shop:vehicle', src, PB.Json({ model = v.model, plate = plate, spawn = s.spawn or { x = s.x, y = s.y, z = s.z, h = s.h } }))
    TriggerClientEvent('pb:g:shop:money', src, PB.Json({ cash = p.row.cash, bank = p.row.bank }))
    return true, plate, acc
end

RegisterNetEvent('pb:g:shop:buyVehicle', function(id, model)
    local src = source
    if not openable(src) or not throttle(src, 800) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'dealer' or not near(src, s) then return end
    if flowOf(s) ~= 'direct' then G.Notify(src, { type = 'warn', title = s.label, text = 'Cette concession passe par un vendeur : fais une demande d\'achat.' }) return end
    local v = findVehicle(s, model)
    if not v then return end
    if not access(src, s) then return end
    local ok, why = sellVehicle(src, s, v, sp(s, v.price))
    if not ok then G.Notify(src, { type = 'error', text = why }) end
end)

-- Commandes : panier -> « envoyer au vendeur » -> le vendeur facture -> le client paie -> il récupère ses articles ----------------------------
-- Sans vendeur en service : le client sonne ; après bell_secs il peut payer seul. Le vendeur peut aussi rembourser (30 min) et donner un ticket.
-- Tout est décidé par le serveur : prix, stock, quantités, distance, droits du vendeur, paiement.
local function otl(src, key, ms)
    olast[src] = olast[src] or {}
    local t = GetGameTimer()
    if olast[src][key] and t - olast[src][key] < ms then return false end
    olast[src][key] = t
    return true
end
local function now() return math.floor(GetGameTimer() / 1000) end   -- secondes écoulées (horloge du serveur de jeu)
local function whoOf(src)
    local i = G.Identity(src)
    local n = i and i.created and (((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) or nil
    return (n and n ~= '') and n or ('Client ' .. tostring(src))
end

local function resolveCart(s, cart)
    if type(cart) ~= 'table' then return nil, 'Panier vide.' end
    local lines, idx, total = {}, {}, 0
    if #cart < 1 or #cart > 20 then return nil, 'Le panier doit contenir de 1 à 20 articles.' end
    if s.kind == 'dealer' then
        if #cart ~= 1 then return nil, 'Une demande d\'achat concerne un seul véhicule.' end
        local v = findVehicle(s, tostring(type(cart[1]) == 'table' and cart[1].k or ''))
        if not v then return nil, 'Véhicule introuvable.' end
        local price = sp(s, v.price)
        return { { k = v.model, model = v.model, label = v.label, qty = 1, price = price, image = G.ItemImage('dealer', v, PB.Cfg.Get('shops', 'vehicle_images', true)) } }, price
    end
    local maxq = math.min(10, tonumber(s.opts.max_qty) or 10)
    for _, r in ipairs(cart) do
        if type(r) ~= 'table' then return nil, 'Panier invalide.' end
        local k, q = tostring(r.k or ''), math.floor(tonumber(r.qty) or 0)
        local item
        for _, it in ipairs(s.catalog) do if it.name == k then item = it end end
        if not item then return nil, 'Article introuvable : ' .. k end
        if q < 1 or q > maxq then return nil, ('Quantité de %s : de 1 à %d.'):format(item.label, maxq) end
        local l = idx[k]
        if l then l.qty = l.qty + q else l = { k = k, label = item.label, qty = q, price = sp(s, item.price), image = G.ItemImage(s.kind, item) } idx[k] = l lines[#lines + 1] = l end
        if l.qty > maxq then return nil, ('Quantité de %s : de 1 à %d.'):format(item.label, maxq) end
        local have = stockOf(s, k)
        if have and have < l.qty then return nil, have <= 0 and ('%s : épuisé.'):format(item.label) or ('%s : il n\'en reste que %d.'):format(item.label, have) end
    end
    for _, l in ipairs(lines) do total = total + l.price * l.qty end
    return lines, total
end

local function waitOf(o, s)
    if o.state ~= 'sent' or flowOf(s) ~= 'seller' or clerks(s) > 0 or not o.bellAt then return nil end
    return math.max(0, (tonumber(s.opts.bell_secs) or 120) - (now() - o.bellAt))
end
local function ticketOf(o, s)
    local lines = {}
    for _, l in ipairs(o.lines) do lines[#lines + 1] = { label = l.label, qty = l.qty, price = l.price } end
    return { no = ('%s-%05d'):format((s.label:gsub('[^A-Za-z0-9]', ''):sub(1, 3)):upper(), o.id), shop = s.label, date = os.date('%d/%m/%Y %H:%M', o.paid_wall or os.time()), who = o.who, lines = lines, total = o.total, acc = o.acc, state = o.state }
end
local function publicOrder(o)
    local s = getShop(o.shop)
    if not s then return nil end
    local pub = { id = o.id, shop = o.shop, state = o.state, total = o.total, lines = o.lines, flow = flowOf(s), clerks = clerks(s), bell_secs = tonumber(s.opts.bell_secs) or 120,
        rung = o.bellAt ~= nil or nil, wait = waitOf(o, s), kind = s.kind, assigned = o.assigned or nil, label = o.assigned and s.label or nil, by = o.assigned and o.byName or nil }
    if o.state == 'paid' or o.state == 'refunded' then pub.ticket = ticketOf(o, s) end
    return pub
end
local function pushBuyer(o)
    local pub = publicOrder(o)
    if pub and G.Players()[o.buyer] then TriggerClientEvent('pb:g:shop:order', o.buyer, PB.Json(pub)) end
end
function G.ShopOrders(shopId)
    local t, list = now(), {}
    for id, o in pairs(ORD) do
        if o.shop == shopId then
            local old = (o.state == 'sent' or o.state == 'billed') and t - o.at > 900 or ((o.state == 'paid' or o.state == 'refunded') and t - (o.paid_at or o.at) > 3600)
            if old then ORD[id] = nil
            else
                local lines = {}
                for _, l in ipairs(o.lines) do lines[#lines + 1] = l.qty .. ' × ' .. l.label end
                list[#list + 1] = { id = o.id, who = o.who, state = o.state, total = o.total, items = table.concat(lines, ', '), at = o.at, rung = o.bellAt ~= nil or nil, can_refund = o.state == 'paid' and t - (o.paid_at or t) <= 1800 or nil }
            end
        end
    end
    table.sort(list, function(a, b) return a.id > b.id end)
    while #list > 25 do list[#list] = nil end
    return list
end
function G.ShopMyOrder(src, shopId)
    for _, o in pairs(ORD) do
        if o.buyer == src and o.shop == shopId and (o.state == 'sent' or o.state == 'billed' or (o.state == 'paid' and now() - (o.paid_at or 0) < 600)) then return publicOrder(o) end
    end
end
local function pushClerks(s)
    local list = G.ShopOrders(s.id)
    for src, sid in pairs(VIEW) do
        if sid == s.id and isClerk(src, s) then TriggerClientEvent('pb:g:shop:orders', src, PB.Json(list)) else if sid == s.id then VIEW[src] = nil end end
    end
end
local function moneyPush(src)
    local p = G.Get(src)
    if p then TriggerClientEvent('pb:g:shop:money', src, PB.Json({ cash = p.row.cash, bank = p.row.bank })) end
end

RegisterNetEvent('pb:g:shop:send', function(id, cart)
    local src = source
    if not openable(src) or not otl(src, 'send', 700) then return end
    local s = getShop(id)
    if not s or not s.enabled or styling(s.kind) or not near(src, s) then return end
    local okA, whyA = access(src, s)
    if not okA then G.Notify(src, { type = 'warn', title = s.label, text = whyA }) return end
    local lines, total = resolveCart(s, cart)
    if not lines then G.Notify(src, { type = 'warn', title = s.label, text = total }) return end
    for oid, o in pairs(ORD) do if o.buyer == src and (o.state == 'sent' or o.state == 'billed') then ORD[oid] = nil end end
    OSEQ = OSEQ + 1
    local o = { id = OSEQ, shop = s.id, buyer = src, license = G.Get(src).license, who = whoOf(src), lines = lines, total = total, at = now(), state = (flowOf(s) == 'direct' or isClerk(src, s)) and 'billed' or 'sent' }
    ORD[o.id] = o
    pushBuyer(o)
    if o.state == 'sent' then
        local n = 0
        for _, l in ipairs(lines) do n = n + l.qty end
        for c in pairs(G.Players()) do if isClerk(c, s) then G.Notify(c, { type = 'info', title = s.label, text = ('Nouvelle commande de %s : %d article(s), %s $.'):format(o.who, n, total) }) end end
        pushClerks(s)
        if clerks(s) == 0 then G.Notify(src, { type = 'info', title = s.label, text = 'Aucun vendeur en service : sonne pour appeler quelqu\'un.' }) end
    end
end)

-- Le vendeur attribue le panier à un client proche : la commande est déjà « encaissée », le client confirme et paie (Y / N).
local function dist2(a, b)
    local pa, pb = GetEntityCoords(GetPlayerPed(a)), GetEntityCoords(GetPlayerPed(b))
    return math.sqrt((pa.x - pb.x) ^ 2 + (pa.y - pb.y) ^ 2 + (pa.z - pb.z) ^ 2)
end
local ASSIGN_DIST = 8.0
function G.ShopNear(src, s)
    local out = {}
    for t in pairs(G.Players()) do
        if t ~= src and openable(t) then
            local ok, d = pcall(dist2, src, t)
            if ok and d <= ASSIGN_DIST then out[#out + 1] = { id = t, name = whoOf(t), d = math.floor(d * 10) / 10 } end
        end
    end
    table.sort(out, function(a, b) return a.d < b.d end)
    return out
end
RegisterNetEvent('pb:g:shop:near', function(id)
    local src = source
    if not openable(src) or not otl(src, 'near', 600) then return end
    local s = getShop(id)
    if not s or not s.enabled or not isClerk(src, s) then return end
    TriggerClientEvent('pb:g:shop:nearlist', src, PB.Json(G.ShopNear(src, s)))
end)
RegisterNetEvent('pb:g:shop:assign', function(id, cart, target)
    local src = source
    if not openable(src) or not otl(src, 'assign', 700) then return end
    local s = getShop(id)
    if not s or not s.enabled or (s.kind ~= 'store' and s.kind ~= 'weapons') or not near(src, s) then return end
    if not isClerk(src, s) then G.Notify(src, { type = 'error', title = s.label, text = "Réservé aux employés en service." }) return end
    target = math.floor(tonumber(target) or -1)
    if target == src or not G.Get(target) or not openable(target) then G.Notify(src, { type = 'warn', title = s.label, text = 'Aucun client sélectionné.' }) return end
    local okD, d = pcall(dist2, src, target)
    if not okD or d > ASSIGN_DIST or not near(target, s) then G.Notify(src, { type = 'warn', title = s.label, text = 'Ce client est trop loin.' }) return end
    local lines, total = resolveCart(s, cart)
    if not lines then G.Notify(src, { type = 'warn', title = s.label, text = total }) return end
    for oid, o in pairs(ORD) do if o.buyer == target and (o.state == 'sent' or o.state == 'billed') then ORD[oid] = nil end end
    OSEQ = OSEQ + 1
    local o = { id = OSEQ, shop = s.id, buyer = target, license = G.Get(target).license, who = whoOf(target), lines = lines, total = total, at = now(), state = 'billed', billedBy = src, assigned = true, byName = whoOf(src) }
    ORD[o.id] = o
    pushBuyer(o)
    pushClerks(s)
    G.Notify(src, { type = 'success', title = s.label, text = ('Panier attribué à %s : %s $. En attente de sa réponse.'):format(o.who, total) })
    PB.Audit.Log('economie', 'shop.order.assign', src, s.label, '#' .. o.id, nil, { total = total, to = G.Get(target).license })
end)

RegisterNetEvent('pb:g:shop:bell', function(oid)
    local src = source
    if not openable(src) or not otl(src, 'bell', 1500) then return end
    local o = ORD[math.floor(tonumber(oid) or 0)]
    if not o or o.buyer ~= src or o.state ~= 'sent' then return end
    local s = getShop(o.shop)
    if not s or not s.enabled or not near(src, s) or flowOf(s) ~= 'seller' then return end
    if clerks(s) > 0 then G.Notify(src, { type = 'info', title = s.label, text = 'Un vendeur est en service : il va te servir.' }) pushBuyer(o) return end
    if not o.bellAt then o.bellAt = now() end
    local secs = tonumber(s.opts.bell_secs) or 120
    G.Notify(src, { type = 'info', title = s.label, text = ('Tu as sonné. Si personne ne vient, tu pourras payer ton panier toi-même dans %d s.'):format(math.max(0, secs - (now() - o.bellAt))) })
    TriggerEvent('pb_panel:shopBell', src, { shop = s.id, order = o.id })
    pushBuyer(o)
end)

RegisterNetEvent('pb:g:shop:ostate', function(oid)
    local src = source
    if not otl(src, 'ostate', 800) then return end
    local o = ORD[math.floor(tonumber(oid) or 0)]
    if o and o.buyer == src then pushBuyer(o) end
end)

RegisterNetEvent('pb:g:shop:ocancel', function(oid)
    local src = source
    if not otl(src, 'ocancel', 500) then return end
    local o = ORD[math.floor(tonumber(oid) or 0)]
    if not o or o.buyer ~= src or (o.state ~= 'sent' and o.state ~= 'billed') then return end
    o.state = 'cancelled'
    ORD[o.id] = nil
    TriggerClientEvent('pb:g:shop:order', src, PB.Json({ id = o.id, state = 'cancelled' }))
    local s = getShop(o.shop)
    if s then pushClerks(s) end
end)

-- Encaissement côté serveur : articles du sac
local function settleGoods(src, s, o)
    local items, total = {}, 0
    for _, l in ipairs(o.lines) do
        local item
        for _, it in ipairs(s.catalog) do if it.name == l.k then item = it end end
        if not item then return false, "Un article n'est plus au catalogue." end
        local have = stockOf(s, item.name)
        if have and have < l.qty then return false, ('%s : il n\'en reste que %d.'):format(item.label, have) end
        items[#items + 1] = { item = item, qty = l.qty, have = have }
        total = total + sp(s, item.price) * l.qty
    end
    if total ~= o.total then
        o.total = total
        for i, l in ipairs(o.lines) do l.price = sp(s, items[i].item.price) end
        pushBuyer(o)
        return false, 'Les prix ont changé : vérifie le nouveau total puis paie.'
    end
    if total > 0 and not canPay(src, s, total) then return false, (s.opts.pay_mode == 'cash' and "Ce magasin n'accepte que les espèces, et tu n'en as pas assez." or s.opts.pay_mode == 'bank' and "Ce magasin n'accepte que la carte, et ton compte est insuffisant." or "Tu n'as pas assez d'argent.") end
    local snapshot = { hunger = G.GetStatus(src, 'hunger'), thirst = G.GetStatus(src, 'thirst'), stress = G.GetStatus(src, 'stress') }
    local done = {}
    local function rollback(how)
        for k, v in pairs(snapshot) do local cur = G.GetStatus(src, k) G.AddStatus(src, k, v - cur) end
        for _, d in ipairs(done) do if d.how == 'builtin' then G.Inv.Remove(G.Inv.PlayerOwner(src), d.item.name, d.qty) end end
        if G.Inv and G.Inv.PlayerOwner(src) then G.Inv.PushOwners(G.Inv.PlayerOwner(src)) end
    end
    for _, e in ipairs(items) do
        local ok, how = deliver(src, e.item, e.qty)
        if not ok then rollback() return false, how end
        done[#done + 1] = { item = e.item, qty = e.qty, how = how }
    end
    local acc = pay(src, s, total)
    if total > 0 and not acc then rollback() return false, 'Paiement impossible.' end
    book(src, s, total, 'commande #' .. o.id)
    local net = total
    if (s.opts.biz or '') ~= '' and G.Eco and G.Biz and G.Biz.Get(s.opts.biz) and total > 0 then
        local tax = G.Eco.TaxIn and G.Eco.TaxIn(total) or 0
        net = total - tax
        G.Eco.Book('biz:' .. s.opts.biz, net, 'Vente ' .. s.label .. ' · commande #' .. o.id, G.Get(src).license)
    end
    for _, e in ipairs(items) do
        if e.have then stockSet(s, e.item.name, e.have - e.qty) end
        if e.item.type == 'weapon' and s.opts.give_ammo and (e.item.ammo_item or '') ~= '' and (e.item.ammo_qty or 0) > 0 then
            local okA = deliver(src, { name = e.item.ammo_item, label = e.item.ammo_item }, e.item.ammo_qty * e.qty)
            if not okA then G.Notify(src, { type = 'warn', title = s.label, text = "Les munitions offertes n'ont pas pu être ajoutées (sac plein)." }) end
        end
        TriggerEvent('pb_panel:purchase', src, { shop = s.id, kind = s.kind, item = e.item.name, qty = e.qty, total = sp(s, e.item.price) * e.qty })
    end
    o.acc, o.net = acc or 'cash', net
    G.Notify(src, { type = 'success', title = s.label, text = ('Commande payée — %s $.'):format(total) })
    return true
end

RegisterNetEvent('pb:g:shop:opay', function(oid)
    local src = source
    if not openable(src) or not otl(src, 'opay', 800) then return end
    local o = ORD[math.floor(tonumber(oid) or 0)]
    if not o or o.buyer ~= src then return end
    local s = getShop(o.shop)
    if not s or not s.enabled or not near(src, s) then return end
    local okA, whyA = access(src, s)
    if not okA then G.Notify(src, { type = 'warn', title = s.label, text = whyA }) return end
    if o.state == 'sent' then
        -- paiement sans vendeur : seulement si personne n'est en service ET que le délai de la sonnette est écoulé
        if flowOf(s) ~= 'seller' or clerks(s) > 0 then G.Notify(src, { type = 'warn', title = s.label, text = 'Attends que le vendeur encaisse ton panier.' }) return end
        local w = waitOf(o, s)
        if not o.bellAt then G.Notify(src, { type = 'warn', title = s.label, text = "Sonne d'abord pour appeler un vendeur." }) return end
        if w and w > 0 then G.Notify(src, { type = 'warn', title = s.label, text = ('Patiente encore %d s avant de pouvoir payer seul.'):format(w) }) pushBuyer(o) return end
    elseif o.state ~= 'billed' then return end
    local ok, why, plate
    if s.kind == 'dealer' then
        local v = findVehicle(s, o.lines[1].k)
        if not v then G.Notify(src, { type = 'error', text = "Ce véhicule n'est plus au catalogue." }) return end
        local price = sp(s, v.price)
        if price ~= o.total then o.total = price o.lines[1].price = price pushBuyer(o) G.Notify(src, { type = 'warn', title = s.label, text = 'Le prix a changé : vérifie le nouveau total puis paie.' }) return end
        ok, why, o.acc = sellVehicle(src, s, v, price)
        plate = ok and why or nil
        if ok then o.plate = plate o.net = price if (s.opts.biz or '') ~= '' and G.Eco and price > 0 then o.net = price - (G.Eco.TaxIn and G.Eco.TaxIn(price) or 0) end end
    else
        ok, why = settleGoods(src, s, o)
    end
    if not ok then G.Notify(src, { type = 'error', title = s.label, text = why }) return end
    o.state, o.paid_at, o.paid_wall = 'paid', now(), os.time()
    pushBuyer(o)
    moneyPush(src)
    pushClerks(s)
    if s.kind ~= 'dealer' and s.opts.stock_on then sendData(src, getShop(s.id), true) end
    PB.Audit.Log('economie', 'shop.order.pay', src, s.label, '#' .. o.id, nil, { total = o.total, seller = o.billedBy and tostring(o.billedBy) or 'sonnette/direct' })
end)

local function refundOrder(src, s, o)
    local t = now()
    if o.state ~= 'paid' then return false, 'Seule une commande payée peut être remboursée.' end
    if t - (o.paid_at or t) > 1800 then return false, 'Remboursement possible pendant 30 minutes après le paiement.' end
    local p = G.Get(o.buyer)
    if not p or p.license ~= o.license then return false, "Le client n'est plus connecté." end
    local biz = s.opts.biz or ''
    local net = o.net or o.total
    if biz ~= '' and G.Eco and o.total > 0 then
        if (G.Eco.Balance('biz:' .. biz) or 0) < net then return false, ("La caisse de l'entreprise ne couvre pas %s $."):format(net) end
        G.Eco.Book('biz:' .. biz, -net, 'Remboursement ' .. s.label .. ' · commande #' .. o.id, p.license)
        if o.total - net > 0 then pcall(G.Eco.Book, 'state', -(o.total - net), 'Remboursement TVA ' .. s.label, p.license) end
    end
    G.AddMoney(o.buyer, o.acc or 'bank', o.total, 'remboursement')
    if s.kind == 'dealer' then
        if o.plate then DB.exec('DELETE FROM pb_vehicles WHERE plate = ? AND license = ?', { o.plate, o.license }) end
    else
        local owner = G.Inv and G.Inv.PlayerOwner(o.buyer)
        for _, l in ipairs(o.lines) do
            if owner and PB.Inv.Detect() ~= 'ox' and PB.Inv.Detect() ~= 'qb' then pcall(G.Inv.Remove, owner, l.k, l.qty) end
            local have = stockOf(s, l.k)
            if have then stockSet(s, l.k, have + l.qty) end
        end
        if owner then G.Inv.PushOwners(owner) end
    end
    o.state = 'refunded'
    moneyPush(o.buyer)
    G.Notify(o.buyer, { type = 'info', title = s.label, text = ('Remboursement de %s $ reçu.'):format(o.total) })
    return true
end

RegisterNetEvent('pb:g:shop:oclerk', function(oid, act)
    local src = source
    if not openable(src) or not otl(src, 'oclerk', 400) then return end
    local o = ORD[math.floor(tonumber(oid) or 0)]
    if not o then return end
    local s = getShop(o.shop)
    if not s or not s.enabled or not near(src, s) then return end
    if not isClerk(src, s) then G.Notify(src, { type = 'error', title = s.label, text = "Réservé aux employés en service de l'entreprise." }) return end
    if o.buyer == src then G.Notify(src, { type = 'error', title = s.label, text = 'Tu ne peux pas traiter ta propre commande.' }) return end
    act = tostring(act)
    if act == 'bill' and o.state == 'sent' then
        o.state, o.billedBy = 'billed', src
        G.Notify(o.buyer, { type = 'success', title = s.label, text = ('Le vendeur a encaissé ta commande : %s $ à payer.'):format(o.total) })
        pushBuyer(o)
    elseif act == 'refuse' and (o.state == 'sent' or o.state == 'billed') then
        o.state = 'cancelled'
        G.Notify(o.buyer, { type = 'warn', title = s.label, text = 'Le vendeur a refusé ta commande.' })
        TriggerClientEvent('pb:g:shop:order', o.buyer, PB.Json({ id = o.id, state = 'cancelled' }))
        ORD[o.id] = nil
    elseif act == 'refund' then
        local ok, why = refundOrder(src, s, o)
        if not ok then G.Notify(src, { type = 'error', title = s.label, text = why }) return end
        PB.Audit.Log('economie', 'shop.order.refund', src, s.label, '#' .. o.id, nil, { total = o.total })
        pushBuyer(o)
    elseif act == 'ticket' and (o.state == 'paid' or o.state == 'refunded') then
        TriggerClientEvent('pb:g:shop:ticket', o.buyer, PB.Json(ticketOf(o, s)))
        G.Notify(o.buyer, { type = 'info', title = s.label, text = 'Le vendeur t\'a remis un ticket.' })
    else return end
    pushClerks(s)
end)

RegisterNetEvent('pb:g:shop:cat', function(id, cat)
    local src = source
    if not openable(src) or not otl(src, 'cat', 250) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'dealer' or not near(src, s) or not access(src, s) then return end
    local list = {}
    cat = tostring(cat or '')
    for _, v in ipairs(dealerList(s)) do
        local c = (v.category and v.category ~= '') and v.category or 'Autres'
        if c == cat then list[#list + 1] = v end
    end
    TriggerClientEvent('pb:g:shop:catdata', src, PB.Json({ id = s.id, cat = cat, vehicles = priced(list, s) }))
end)
RegisterNetEvent('pb:g:shop:closed', function() VIEW[source] = nil end)

-- Voir / essayer un véhicule avant achat : le serveur valide, le client fait apparaître un véhicule local (visible de lui seul).
RegisterNetEvent('pb:g:shop:vview', function(id, model, mode)
    local src = source
    if not openable(src) or not otl(src, 'vview', 1500) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'dealer' or not near(src, s) or not access(src, s) then return end
    local v = findVehicle(s, tostring(model))
    if not v then return end
    mode = mode == 'test' and 'test' or 'view'
    local sec = mode == 'test' and (tonumber(s.opts.drive_sec) or 0) or 0
    if mode == 'test' then
        if sec <= 0 then G.Notify(src, { type = 'warn', title = s.label, text = "Les essais sont désactivés ici." }) return end
        if DRIVE[src] and DRIVE[src] > now() then G.Notify(src, { type = 'warn', title = s.label, text = 'Un essai est déjà en cours.' }) return end
        DRIVE[src] = now() + sec + 15
    end
    TriggerClientEvent('pb:g:shop:vgo', src, PB.Json({ shop = s.id, model = v.model, label = v.label, mode = mode, seconds = sec, spawn = s.spawn or { x = s.x, y = s.y, z = s.z, h = s.h } }))
    TriggerEvent('pb_panel:vehicleTry', src, { shop = s.id, model = v.model, mode = mode })
end)
RegisterNetEvent('pb:g:shop:vend', function() DRIVE[source] = nil end)

AddEventHandler('playerDropped', function()
    local src = source
    VIEW[src], DRIVE[src], olast[src] = nil, nil, nil
    for oid, o in pairs(ORD) do if o.buyer == src and (o.state == 'sent' or o.state == 'billed') then ORD[oid] = nil end end
end)

RegisterNetEvent('pb:g:shop:clothes', function(id, appearance)
    local src = source
    if not openable(src) or not throttle(src, 800) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'clothes' or not near(src, s) then return end
    local p = G.Get(src)
    local stored = PB.FromJson(p.row.appearance, nil)
    if not stored or type(appearance) ~= 'table' then return end
    -- seuls les vêtements et accessoires changent : le visage reste celui du créateur
    local merged = PB.DeepCopy(stored)
    merged.comps, merged.props = appearance.comps, appearance.props
    local v, err = G.ValidAppearance(merged, p.row.sex)
    if not v then G.Notify(src, { type = 'error', text = err }) return end
    if not access(src, s) then return end
    local cprice = sp(s, s.price)
    if cprice > 0 and not pay(src, s, cprice) then G.Notify(src, { type = 'error', text = "Tu n'as pas assez d'argent." }) TriggerClientEvent('pb:g:shop:cancel', src) return end
    G.SaveAppearance(src, v)
    book(src, s, cprice, 'tenue')
    G.Notify(src, { type = 'success', title = s.label, text = cprice > 0 and ('Nouvelle tenue — %d $'):format(cprice) or 'Nouvelle tenue enregistrée.' })
    TriggerClientEvent('pb:g:shop:clothesOk', src, PB.Json(v))
    TriggerClientEvent('pb:g:shop:money', src, PB.Json({ cash = p.row.cash, bank = p.row.bank }))
end)

-- Coiffeur / barbier : seuls les cheveux et les détails du visage (barbe, sourcils, poils, maquillage, blush, rouge à lèvres) changent.
local BARBER_OV = { [2] = true, [3] = true, [5] = true, [6] = true, [9] = true, [11] = true }   -- index des détails (1 = imperfections… 13)
RegisterNetEvent('pb:g:shop:barber', function(id, look)
    local src = source
    if not openable(src) or not throttle(src, 800) then return end
    local s = getShop(id)
    if not s or not s.enabled or s.kind ~= 'barber' or not near(src, s) then return end
    local p = G.Get(src)
    local stored = PB.FromJson(p.row.appearance, nil)
    if not stored or type(look) ~= 'table' or type(look.hair) ~= 'table' or type(look.ov) ~= 'table' then return end
    local merged = PB.DeepCopy(stored)
    merged.hair = look.hair
    for i in pairs(BARBER_OV) do if type(look.ov[i]) == 'table' then merged.ov[i] = look.ov[i] end end
    local v, err = G.ValidAppearance(merged, p.row.sex)
    if not v then G.Notify(src, { type = 'error', text = err }) TriggerClientEvent('pb:g:shop:cancel', src) return end
    if not access(src, s) then TriggerClientEvent('pb:g:shop:cancel', src) return end
    local cprice = sp(s, s.price)
    if cprice > 0 and not pay(src, s, cprice) then G.Notify(src, { type = 'error', text = "Tu n'as pas assez d'argent." }) TriggerClientEvent('pb:g:shop:cancel', src) return end
    G.SaveAppearance(src, v)
    book(src, s, cprice, 'coupe')
    G.Notify(src, { type = 'success', title = s.label, text = cprice > 0 and ('Nouvelle coupe — %d $'):format(cprice) or 'Nouvelle coupe enregistrée.' })
    TriggerClientEvent('pb:g:shop:barberOk', src, PB.Json(v))
end)

AddEventHandler('playerDropped', function() last[source] = nil end)

exports('GetOwnedVehicles', function(src)
    local p = G.Get(src)
    return p and (DB.q("SELECT plate, model, label FROM pb_vehicles WHERE license = ? AND gang = ''", { p.license }) or {}) or {}
end)

-- Module du panel -------------------------------------------------------------------------------------------------------------------------------
local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end

PB.Module({
    id = 'shops', label = 'Magasins', icon = 'shop', group = 'Serveur', order = 137, perm = 'shops.view', hint = 'Vêtements, supérettes, concessions, armurerie',
    caps = function()
        local kind = PB.Inv.Detect()
        local inv = (kind == 'ox' or kind == 'qb')
        local others = {}
        return PB.Capsify({
            { 'Magasins de vêtements (prix, emplacements)', 'ok', 'Enregistre la tenue dans pb_players ; le visage reste celui du créateur.' },
            { 'Supérettes : catalogue, prix, effets sur faim / soif / stress', 'ok', "Livraison dans le sac de Shadow Base ou effet immédiat." },
            { 'Livraison dans un inventaire', inv and 'ok' or 'partial', 'Sac de Shadow Base.' },
            { 'Concessions : catalogue, prix, plaque, apparition', 'ok', 'Le véhicule acheté est enregistré dans pb_vehicles (plaque unique) et apparaît à la sortie du magasin.' },
            { 'Garages, clés et fourrière', 'off', "Non inclus : les véhicules achetés sont listés (onglet Ventes) mais aucun garage ne les range." },
            { 'Vendeur (personnage décoratif), horaires, accès employés, remise, moyens de paiement', 'ok', 'Réglables par magasin dans l\'éditeur.' },
            { 'Stock limité et réapprovisionnement', 'ok', "Option par magasin : stock de départ, maximum, remplissage automatique ou par un employé." },
            { 'Vendeur joueur', 'ok', "Avec une entreprise propriétaire : ventes dans sa caisse, magasin fermé sans employé en service, réapprovisionnement payé par la caisse." },
            { 'Autre script de magasins actif', #others == 0 and 'ok' or 'partial', #others == 0 and 'Aucun conflit détecté.' or ('Détecté : ' .. table.concat(others, ', ')) },
        })
    end,
    doc = "## Magasins\nQuatre types : **vêtements**, **supérette**, **armurerie** (cartes avec image, statistiques, bouton Tester) et **concession**. Détail : **supérette** (articles avec effet sur la faim, la soif et le stress) et **concession** (véhicules).\n\n- Place le magasin avec « Ma position » depuis le panel ; il apparaît tout de suite pour les joueurs.\n- Chaque achat est vérifié par le serveur (distance, article, quantité, paiement).\n- **Stock et vendeur joueur** : options par supérette (stock limité, réapprovisionnement, entreprise propriétaire).",
    view = function(ctx)
        return { tabs = {
            tab('map', 'Carte', 'map', function()
                local pts = {}
                local COL = { store = '#7bd88f', dealer = '#6fd3ff', clothes = '#f2c14e', weapons = '#ff7a7a', barber = '#b58cff' }
                for _, s in ipairs(allShops(false)) do pts[#pts + 1] = { id = s.id, x = s.x, y = s.y, color = COL[s.kind] or '#ffffff', label = s.label, sub = KINDS[s.kind] or s.kind } end
                return { { type = 'map', id = 'smap', title = 'Magasins', points = pts, open = { tab = 'edit', key = 'id' }, legend = { { color = '#7bd88f', label = 'Supérette' }, { color = '#6fd3ff', label = 'Concession' }, { color = '#f2c14e', label = 'Vêtements' }, { color = '#ff7a7a', label = 'Armurerie' } } } }
            end),
            tab('list', 'Magasins', 'shop', function()
                local rows = {}
                for _, s in ipairs(allShops(false)) do
                    local acts = { { nav = { tab = 'edit', params = { id = s.id } }, label = 'Modifier', icon = 'edit' } }
                    if ctx.has('shops.delete') then acts[#acts + 1] = { action = 'shops.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = s.id } } end
                    rows[#rows + 1] = { id = s.id, label = s.label, kind = KINDS[s.kind] or s.kind, items = styling(s.kind) and '—' or #s.catalog, pos = ('%.0f, %.0f'):format(s.x, s.y),
                        on = s.enabled and { text = 'Actif', tone = 'ok' } or { text = 'Masqué', tone = 'off' }, actions = acts }
                end
                return { B.table({ id = 'shops', title = 'Magasins', search = true, columns = { { k = 'label', label = 'Nom' }, { k = 'kind', label = 'Type' }, { k = 'items', label = 'Articles', type = 'num' }, { k = 'pos', label = 'Position', type = 'mono' }, { k = 'on', label = 'État', type = 'badge' } },
                    rows = rows, empty = 'Aucun magasin : crée le premier avec « Nouveau magasin ».', toolbar = { { nav = { tab = 'edit', params = { id = '' } }, label = 'Nouveau magasin', icon = 'plus', perm = 'shops.edit' } } }) }
            end),
            tab('edit', 'Éditeur', 'edit', function(_, params)
                local s = PB.ToInt(params.id, 0) > 0 and getShop(params.id) or nil
                local kind = tostring(params.kind or (s and s.kind) or 'store')
                if not KINDS[kind] then kind = 'store' end
                local function F(list, k) for _, f in ipairs(list) do if f.k == k then return PB.DeepCopy(f) end end end
                local function pick(list, keys) local out = {} for _, k in ipairs(keys) do local f = F(list, k) if f then out[#out + 1] = f end end return out end
                local kindF = F(SHOP_FIELDS, 'kind') kindF.readonly = s ~= nil
                local general = { kindF, F(SHOP_FIELDS, 'label') }
                for _, f in ipairs(pick(OPT_FIELDS, { 'tagline' })) do general[#general + 1] = f end
                general[#general + 1] = F(SHOP_FIELDS, 'enabled')
                local where = { F(SHOP_FIELDS, 'coords') }
                if kind == 'dealer' then where[#where + 1] = F(SHOP_FIELDS, 'spawn') end
                for _, k in ipairs({ 'blip', 'sprite', 'color' }) do where[#where + 1] = F(SHOP_FIELDS, k) end
                local money = {}
                if styling(kind) then money[#money + 1] = F(SHOP_FIELDS, 'price') end
                for _, f in ipairs(pick(OPT_FIELDS, { 'pay_mode', 'discount' })) do money[#money + 1] = f end
                if goods(kind) then money[#money + 1] = F(OPT_FIELDS, 'max_qty') end
                local fields = {
                    { type = 'group', label = '1 · Général', fields = general },
                    { type = 'group', label = '2 · Emplacement et carte', fields = where },
                    { type = 'group', label = "3 · Apparence de l'interface", fields = pick(OPT_FIELDS, kind == 'clothes' and { 'banner', 'logo', 'accent', 'scope' } or { 'banner', 'logo', 'accent' }) },
                    { type = 'group', label = '4 · Vendeur', fields = pick(OPT_FIELDS, { 'npc_on', 'npc_model', 'npc_scenario', 'seller_mode', 'bell_secs' }) },
                    { type = 'group', label = '5 · Horaires et accès', fields = pick(OPT_FIELDS, { 'permit', 'hours_on', 'open_h', 'close_h', 'job', 'min_grade' }) },
                    { type = 'group', label = '6 · Prix et paiement', fields = money },
                }
                if goods(kind) then
                    fields[#fields + 1] = { type = 'group', label = '8 · Stock et vendeur joueur', fields = pick(OPT_FIELDS, { 'stock_on', 'stock_start', 'stock_max', 'restock_min', 'restock_qty', 'biz', 'need_clerk', 'wholesale' }) }
                    if kind == 'weapons' then
                        fields[#fields + 1] = { type = 'group', label = '9 · Essai et munitions', fields = pick(OPT_FIELDS, { 'test_sec', 'test_ammo', 'give_ammo' }) }
                        fields[#fields + 1] = { type = 'group', label = '7 · Catalogue (armes, munitions, accessoires)', fields = { { k = 'catalog', type = 'rows', label = 'Articles', wide = true, cols = {
                            { k = 'type', label = 'Type', type = 'select', opts = { { 'weapon', 'Arme' }, { 'ammo', 'Munition' }, { 'item', 'Accessoire' } } },
                            { k = 'name', label = 'Objet (weapon_… pour une arme)' }, { k = 'label', label = 'Nom affiché' }, { k = 'category', label = 'Rayon' }, { k = 'price', label = 'Prix', type = 'number', min = 0, max = 10000000 },
                            { k = 'image', label = 'Image (https://… ou asset:…)' }, { k = 'desc', label = 'Description' },
                            { k = 'ammo_item', label = 'Munition utilisée' }, { k = 'ammo_qty', label = 'Boîtes offertes', type = 'number', min = 0, max = 500 },
                            { k = 'dmg', label = 'Dégâts', type = 'number', min = 0, max = 100 }, { k = 'range', label = 'Portée', type = 'number', min = 0, max = 100 },
                            { k = 'rate', label = 'Cadence', type = 'number', min = 0, max = 100 }, { k = 'mag', label = 'Chargeur', type = 'number', min = 0, max = 100 },
                            { k = 'test', label = 'Essai', type = 'toggle' } } } } }
                    else
                        fields[#fields + 1] = { type = 'group', label = '7 · Catalogue', fields = { { k = 'catalog', type = 'rows', label = 'Articles', wide = true, cols = {
                            { k = 'name', label = 'Objet (identifiant)' }, { k = 'label', label = 'Nom affiché' }, { k = 'category', label = 'Rayon' }, { k = 'price', label = 'Prix', type = 'number', min = 0, max = 1000000 }, { k = 'image', label = 'Image (vide = illustration fournie)' },
                            { k = 'hunger', label = 'Faim', type = 'number', min = -100, max = 100 }, { k = 'thirst', label = 'Soif', type = 'number', min = -100, max = 100 }, { k = 'stress', label = 'Stress', type = 'number', min = -100, max = 100 } } } } }
                    end
                elseif kind == 'dealer' then
                    fields[#fields + 1] = { type = 'group', label = '7 · Catalogue', fields = { { k = 'catalog', type = 'rows', label = 'Véhicules', wide = true, cols = {
                        { k = 'model', label = 'Modèle (nom de spawn)' }, { k = 'label', label = 'Nom affiché' }, { k = 'price', label = 'Prix', type = 'number', min = 0, max = 100000000 }, { k = 'category', label = 'Catégorie' }, { k = 'image', label = 'Image (vide = photo du modèle)' } } } } }
                    for _, f in ipairs(pick(OPT_FIELDS, { 'gta_all', 'gta_extra', 'gta_factor', 'drive_sec' })) do table.insert(fields[#fields].fields, 1, f) end
                end
                local values = {}
                if s then
                    values = { kind = s.kind, label = s.label, coords = { x = s.x, y = s.y, z = s.z, h = s.h }, spawn = s.spawn, price = s.price, blip = s.blip, sprite = s.sprite, color = s.color, enabled = s.enabled, catalog = s.catalog }
                    for k, v in pairs(s.opts) do values[k] = v end
                else
                    values = { kind = kind, label = '', coords = { x = 0, y = 0, z = 0, h = 0 }, price = 0, blip = true, sprite = SPRITE[kind], color = 2, enabled = true, catalog = kind == 'store' and DEFAULT_STORE or (kind == 'dealer' and DEFAULT_DEALER or (kind == 'weapons' and PB.DeepCopy(DEFAULT_WEAPONS) or {})) }
                    for k, v in pairs(OPT_DEFAULTS) do values[k] = v end
                    if kind == 'dealer' then values.gta_all = true end
                    if kind == 'weapons' then values.permit = 'weapon' values.accent = '#5b4ae6' values.tagline = "Permis de port d'arme obligatoire" values.color = 1 values.max_qty = 5 values.pay_mode = 'both' end
                end
                local items = {}
                for _, sh in ipairs(allShops(false)) do
                    items[#items + 1] = { label = sh.label, sub = KINDS[sh.kind] or sh.kind, icon = sh.kind == 'dealer' and 'car' or sh.kind == 'clothes' and 'user' or sh.kind == 'barber' and 'users' or sh.kind == 'weapons' and 'shield' or 'shop', off = not sh.enabled, active = s and s.id == sh.id,
                        nav = { tab = 'edit', params = { id = sh.id } } }
                end
                local right = {}
                if not s then right[#right + 1] = { type = 'picker', id = 'kind', label = 'Type de magasin', options = { { 'store', KINDS.store }, { 'clothes', KINDS.clothes }, { 'dealer', KINDS.dealer }, { 'weapons', KINDS.weapons }, { 'barber', KINDS.barber } }, value = kind } end
                right[#right + 1] = { type = 'form', id = 'shop.edit', title = s and ('Modifier « ' .. s.label .. ' »') or 'Nouveau magasin', cols = 2, fields = fields, values = values,
                    submit = ctx.has('shops.edit') and { action = 'shops.save', label = s and 'Enregistrer' or 'Créer le magasin', payload = { id = s and s.id or nil } } or nil }
                if kind == 'weapons' and s and ctx.has('shops.edit') then right[#right + 1] = B.actions({ { action = 'shops.addweapons', label = 'Ajouter toutes les armes du jeu manquantes', icon = 'plus', payload = { id = s.id } } }) end
                if kind == 'weapons' then right[#right + 1] = B.notice('info', "Armes : l'identifiant commence par weapon_ (ex. weapon_pistol). Les armes vendues sont ajoutées automatiquement au catalogue du module Armes et au sac. Les images viennent d'une adresse https:// ou d'une image envoyée depuis le PC (asset:…). Le permis d'arme se règle dans « 5 · Horaires et accès ».") end
                if kind == 'store' then right[#right + 1] = B.notice('info', "Les effets s'ajoutent à la faim, la soif et le stress du joueur (valeurs de -100 à 100). L'objet est donné dans le sac de Shadow Base.") end
                if s and ctx.has('shops.delete') then right[#right + 1] = B.actions({ { action = 'shops.delete', label = 'Supprimer ce magasin', icon = 'trash', danger = true, payload = { id = s.id } } }) end
                return { { type = 'columns', widths = 'minmax(220px,300px) minmax(0,1fr)', cols = { { { type = 'mlist', title = 'Magasins (' .. #items .. ')', items = items, empty = 'Aucun magasin.', toolbar = ctx.has('shops.edit') and { label = 'Nouveau', nav = { tab = 'edit', params = { id = '' } } } or nil } }, right } } }
            end, 'shops.edit'),
            tab('sales', 'Ventes de véhicules', 'car', function(_, params)
                local rows = {}
                for _, r in ipairs(DB.q('SELECT v.plate, v.model, v.label, v.price, v.bought_at, p.firstname, p.lastname FROM pb_vehicles v LEFT JOIN pb_players p ON p.license = v.license ORDER BY v.bought_at DESC LIMIT 200') or {}) do
                    rows[#rows + 1] = { plate = r.plate, label = r.label, model = r.model, price = r.price, owner = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''), at = r.bought_at }
                end
                return { B.table({ id = 'sales', title = 'Véhicules vendus', search = true, columns = { { k = 'plate', label = 'Plaque', type = 'mono' }, { k = 'label', label = 'Véhicule' }, { k = 'model', label = 'Modèle', type = 'mono' }, { k = 'price', label = 'Prix', type = 'num' }, { k = 'owner', label = 'Acheteur' }, { k = 'at', label = 'Date', type = 'date' } },
                    rows = rows, empty = 'Aucune vente pour le moment.' }) }
            end),
            tab('preview', 'Aperçus', 'eye', function() return {
                { type = 'gpreview', kind = 'shop', shopKind = 'store', title = 'Supérette (catégories en cartes, panier, paiement)', cfg = PB.Cfg.All('shops') },
                { type = 'gpreview', kind = 'shop', shopKind = 'stock', title = 'Épicerie avec stock et vendeur joueur (vue employé)', cfg = PB.Cfg.All('shops') },
                { type = 'gpreview', kind = 'shop', shopKind = 'weapons', title = "Armurerie (armes avec statistiques, munitions, accessoires)", cfg = PB.Cfg.All('shops') },
                { type = 'gpreview', kind = 'shop', shopKind = 'dealer', title = 'Concession (catégories de véhicules, voir / essayer / acheter)', cfg = PB.Cfg.All('shops') } } end),
            tab('settings', 'Réglages', 'sliders', function() return { settings(ctx) } end),
        } }
    end,
})

PB.SelfTest.Add('magasins', function(R)
    local ok, list = pcall(G.ShopList)
    R.check(ok and type(list) == 'table', 'magasins', 'la liste des magasins ne se charge pas', list)
    if ok then for _, s in ipairs(list) do R.check(not (s.x == 0 and s.y == 0), 'magasin ' .. tostring(s.label), 'position 0,0 : le point est au milieu de la mer') end end
end)

PB.SelfTest.Add('armurerie', function(R)
    local rows = DB.q("SELECT id, label, catalog, opts FROM pb_shops WHERE kind = 'weapons'") or {}
    for _, r in ipairs(rows) do
        local cat = PB.FromJson(r.catalog, {})
        R.check(type(cat) == 'table' and #cat > 0, 'armurerie ' .. tostring(r.label), 'catalogue vide : rien à vendre')
        for _, e in ipairs(type(cat) == 'table' and cat or {}) do
            if e.type == 'weapon' then
                R.check(tostring(e.name):match('^weapon_'), 'arme « ' .. tostring(e.name) .. ' »', "l'identifiant doit commencer par weapon_")
                R.check(G.Weapons and G.Weapons.ByItem(e.name) ~= nil, 'arme « ' .. tostring(e.name) .. ' »', "absente du catalogue du module Armes : impossible de l'équiper")
            end
            R.check(G.Inv and G.Inv.Def(e.name) ~= nil, 'article « ' .. tostring(e.name) .. ' »', "l'objet du sac n'existe pas (Inventaire › Objets)")
        end
        local o = PB.FromJson(r.opts, {})
        if type(o) == 'table' and (o.permit or '') == '' then R.warn('armurerie ' .. tostring(r.label), 'sans permis', "Aucun permis exigé : n'importe qui peut acheter des armes. Règle « Permis exigé » dans l'éditeur (5 · Horaires et accès).") end
    end
end)

PB.SelfTest.Add('boutiques: images et catalogue GTA', function(R)
    R.check(G.VehCat and #G.VehCat.list > 400, 'catalogue GTA', 'catalogue de véhicules absent ou incomplet')
    local seen = {}
    for _, v in ipairs(G.VehCat and G.VehCat.list or {}) do
        R.check(tostring(v.model):match('^[a-z0-9_]+$') and not seen[v.model], 'véhicule ' .. tostring(v.model), 'modèle invalide ou en double')
        seen[v.model] = true
    end
    for _, sh in ipairs(allShops(false)) do
        if sh.kind == 'store' or sh.kind == 'weapons' then
            for _, it in ipairs(sh.catalog) do R.check((G.ItemImage(sh.kind, it) or '') ~= '', 'image de ' .. tostring(it.name), 'article sans image') end
        end
    end
end)

PB.SelfTest.Add('images: toutes declarees dans fxmanifest', function(R)
    local res = GetCurrentResourceName()
    local man = LoadResourceFile(res, 'fxmanifest.lua') or ''
    local bad = {}
    for path in man:gmatch("'(web/img/[^']+)'") do
        if path:find('*', 1, true) then bad[#bad + 1] = path .. ' (glob)'
        elseif path:sub(-4) ~= '.jpg' and not LoadResourceFile(res, path) then bad[#bad + 1] = path .. ' (absent)' end
    end
    R.ok(#bad == 0, 'images fxmanifest: ' .. table.concat(bad, ', '))
end)
