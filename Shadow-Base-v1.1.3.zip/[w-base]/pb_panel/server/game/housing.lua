-- Logements : achat / location, accès partagés, coffre du logement (inventaire 'h:<id>'), loyers, porte verrouillable, entrée/sortie optionnelle.
-- Le serveur décide (propriété, loyer, droits, distance). Le client affiche l'invite et téléporte seulement sur ordre du serveur.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('housing.edit', 'Créer, modifier ou supprimer des logements et leurs réglages', 'housing', true)
P.Register('housing.manage', 'Attribuer, reprendre ou libérer un logement depuis le panel', 'housing', true)

local HOUSING_SQL = {
    [[CREATE TABLE IF NOT EXISTS pb_properties (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, kind VARCHAR(8) NOT NULL DEFAULT 'buy', price INT NOT NULL DEFAULT 0, rent INT NOT NULL DEFAULT 0,
        x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, ix DOUBLE NOT NULL DEFAULT 0, iy DOUBLE NOT NULL DEFAULT 0, iz DOUBLE NOT NULL DEFAULT 0, ih DOUBLE NOT NULL DEFAULT 0,
        owner VARCHAR(64) NOT NULL DEFAULT '', since INT NOT NULL DEFAULT 0, paid_until INT NOT NULL DEFAULT 0, arrears INT NOT NULL DEFAULT 0, locked TINYINT(1) NOT NULL DEFAULT 1, enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_property_access (prop VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, by_license VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (prop, license))]],
}
local DEFAULT_PROPS = {
    { 'tinsel', 'Appartement — Tinsel Towers', 'buy', 85000, 0, -621.0, 46.0, 43.6 },
    { 'integrity', 'Appartement — Integrity Way', 'rent', 0, 650, -47.2, -585.8, 37.9 },
    { 'alta', 'Studio — Alta Street', 'rent', 0, 420, -270.0, -962.0, 31.2 },
    { 'vinewood', 'Maison — Vinewood Hills', 'buy', 240000, 0, -174.0, 502.0, 137.4 },
}
PB.Migrate('049_game_housing', 'Logements, accès, loyers', function()
    for _, sql in ipairs(HOUSING_SQL) do DB.exec(PB.Table(sql)) end
    for _, d in ipairs(DEFAULT_PROPS) do DB.exec('INSERT IGNORE INTO pb_properties (id, label, kind, price, rent, x, y, z) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', d) end
end)

PB.Cfg.Define('housing', { realtor_biz = 'realestate', realtor_pct = 5, enabled = true, max_owned = 2, rent_days = 7, grace_periods = 3, sell_ratio = 70, use_distance = 2.5, blips = true, guests_max = 6, enter_cooldown = 2 })

local Hs = {}
G.Housing = Hs
local function cfg(k, d) return PB.Cfg.Get('housing', k, d) end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function period() return cfg('rent_days', 7) * 86400 end

-- Données --------------------------------------------------------------------------------------------------------------------------------
function Hs.All() return DB.q('SELECT * FROM pb_properties ORDER BY label') or {} end
function Hs.Get(id) return DB.one('SELECT * FROM pb_properties WHERE id = ?', { tostring(id) }) end
function Hs.OwnedBy(license) return DB.q('SELECT * FROM pb_properties WHERE owner = ? ORDER BY label', { license }) or {} end
function Hs.Guests(id) return DB.q('SELECT a.license, a.at, p.firstname, p.lastname FROM pb_property_access a LEFT JOIN pb_players p ON p.license = a.license WHERE a.prop = ? ORDER BY a.at', { tostring(id) }) or {} end
function Hs.StashOwner(id) return 'h:' .. tostring(id) end
function Hs.StashEmpty(id)
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { Hs.StashOwner(id) })
    return not n or n.n == 0
end
local function inArrears(h) return h.owner ~= '' and (h.arrears or 0) > 0 end

-- A-t-on le droit d'entrer / utiliser le coffre ?
function Hs.HasAccess(license, h)
    if not h or h.owner == '' or inArrears(h) then return false end
    if h.owner == license then return true end
    return DB.one('SELECT prop FROM pb_property_access WHERE prop = ? AND license = ?', { h.id, license }) ~= nil
end


-- Agence immobilière : ses agents en service mettent des logements en vente / en location à leur position, règlent le prix et l'intérieur,
-- et font visiter (accès de 15 minutes à un logement libre). Menu ALT › Métier. L'agence touche une commission sur chaque vente.
PB.Migrate('200_realtor', "Logements : agence immobilière", { "ALTER TABLE pb_properties ADD COLUMN listed_by VARCHAR(32) NOT NULL DEFAULT ''" })
local Re = {}
G.Realtor = Re
local visits = {}   -- licence -> { [logement] = fin de la visite }
function Re.Biz() local b = tostring(cfg('realtor_biz', 'realestate') or '') return b ~= '' and b or nil end
function Re.IsAgent(src)
    local b = Re.Biz()
    local j = b and G.Biz and G.Biz.Job(tonumber(src))
    return j ~= nil and j.biz == b and j.onDuty == true
end
function Re.Visiting(license, id) local v = visits[license] return v ~= nil and (v[id] or 0) > os.time() end
local function posOf(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped), GetEntityHeading(ped) end
-- logement le plus proche de l'agent (porte), libre, mis en vente par l'agence
local function nearestListed(src, maxd)
    local c = posOf(src)
    if not c then return nil, 'Position illisible.' end
    local best, bd
    for _, h in ipairs(DB.q("SELECT * FROM pb_properties WHERE owner = '' AND listed_by = ?", { Re.Biz() or '' }) or {}) do
        local d = #(c - vector3(h.x, h.y, h.z))
        if d <= maxd and (not bd or d < bd) then best, bd = h, d end
    end
    if not best then return nil, ("Aucun logement libre de l'agence à moins de %d m."):format(maxd) end
    return best
end
local function rid() return ('re_' .. tostring(os.time() % 1000000) .. tostring(math.random(100, 999))):sub(1, 32) end
function Re.List(src, kind, name, amount)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    name = tostring(name or ''):gsub('[%c<>"\\]', ''):sub(1, 48)
    amount = math.floor(tonumber(amount) or 0)
    if #name < 3 then return false, 'Donne un nom au logement (3 caractères au moins).' end
    if amount < 1 or amount > 100000000 then return false, 'Prix invalide.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_properties WHERE listed_by = ?', { Re.Biz() })
    if n and tonumber(n.n) >= (tonumber(cfg('realtor_max', 40)) or 40) then return false, "L'agence a atteint son nombre maximum d'annonces." end
    local c, hd = posOf(src)
    if not c then return false, 'Position illisible.' end
    DB.exec('INSERT INTO pb_properties (id, label, kind, price, rent, x, y, z, enabled, listed_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
        { rid(), name, kind, kind == 'buy' and amount or 0, kind == 'rent' and amount or 0, c.x, c.y, c.z, Re.Biz() })
    PB.Audit.Log('serveur', 'realtor.list', src, name, nil, { kind = kind, amount = amount })
    G.PushConfig()
    return true, ('« %s » %s pour %s. La porte est ici ; ajoute un intérieur avec « Définir l\'intérieur ».'):format(name, kind == 'buy' and 'mis en vente' or 'mis en location', money(amount))
end
function Re.Price(src, amount)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    amount = math.floor(tonumber(amount) or 0)
    if amount < 1 or amount > 100000000 then return false, 'Prix invalide.' end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    DB.exec(h.kind == 'buy' and 'UPDATE pb_properties SET price = ? WHERE id = ?' or 'UPDATE pb_properties SET rent = ? WHERE id = ?', { amount, h.id })
    G.PushConfig()
    return true, ('%s : %s.'):format(h.label, money(amount))
end
function Re.Unlist(src)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    DB.exec("DELETE FROM pb_properties WHERE id = ? AND owner = ''", { h.id })
    PB.Audit.Log('serveur', 'realtor.unlist', src, h.label)
    G.PushConfig()
    return true, h.label .. ' retiré des annonces.'
end
function Re.Interior(src)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 120) if not h then return false, err end
    local c, hd = posOf(src)
    DB.exec('UPDATE pb_properties SET ix = ?, iy = ?, iz = ?, ih = ? WHERE id = ?', { c.x, c.y, c.z, hd or 0.0, h.id })
    G.PushConfig()
    return true, ("Intérieur de « %s » placé ici : on y arrive en entrant par la porte."):format(h.label)
end
function Re.Visit(src, t)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    if h.ix == 0 and h.iy == 0 then return false, "Ce logement n'a pas encore d'intérieur." end
    local tp = G.Get(t)
    if not tp then return false, 'Personne introuvable.' end
    visits[tp.license] = visits[tp.license] or {}
    visits[tp.license][h.id] = os.time() + 900
    G.Notify(t, { type = 'info', title = 'Visite', text = ("Tu peux visiter « %s » pendant 15 minutes : entre par la porte."):format(h.label) })
    return true, ('Visite de « %s » ouverte pour 15 minutes.'):format(h.label)
end

local function nameOf(license)
    local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { license })
    if not r then return '—' end
    local n = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    return n ~= '' and n or '—'
end

exports('HasHousingAccess', function(src, id) local p = G.Get(tonumber(src)) return p ~= nil and Hs.HasAccess(p.license, Hs.Get(id)) end)
exports('GetProperties', function(src) local p = G.Get(tonumber(src)) local out = {} if p then for _, h in ipairs(Hs.OwnedBy(p.license)) do out[#out + 1] = { id = h.id, label = h.label, kind = h.kind } end end return out end)

-- Coffre du logement : branché sur l'inventaire (Inv.ExtraAccess)
local Inv = G.Inv
local prevExtra = Inv and Inv.ExtraAccess
if Inv then
    Inv.ExtraAccess = function(src, kind, id)
        if kind == 'h' then
            local p = G.Get(src)
            local h = p and Hs.Get(id)
            if not h or not PB.ToBool(h.enabled) or not Hs.HasAccess(p.license, h) then return false end
            return G.DistTo(src, h.x, h.y, h.z) <= cfg('use_distance', 2.5) + 6
        end
        if prevExtra then return prevExtra(src, kind, id) end
        return false
    end
end

-- Sessions de menu -----------------------------------------------------------------------------------------------------------------------
local sessions = {}
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function near(src, h, extra) return G.DistTo(src, h.x, h.y, h.z) <= (extra or cfg('use_distance', 2.5) + 5) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end

local function rentDue(h)
    if h.kind ~= 'rent' or h.owner == '' then return 0 end
    return math.max(0, (h.arrears or 0)) * h.rent
end

-- Pages ---------------------------------------------------------------------------------------------------------------------------------
local PAGES = {}
local function statusOf(src, h)
    local p = G.Get(src)
    if h.owner == '' then return 'free' end
    if h.owner == p.license then return inArrears(h) and 'arrears' or 'mine' end
    if Hs.HasAccess(p.license, h) then return 'guest' end
    return 'taken'
end
PAGES.home = function(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    local st = statusOf(src, h)
    local acts, blocks = {}, {}
    local owned = #Hs.OwnedBy(p.license)
    if st == 'free' then
        if owned >= cfg('max_owned', 2) then
            blocks[#blocks + 1] = { type = 'notice', tone = 'warn', text = ('Tu possèdes déjà %d logement(s) : c\'est le maximum autorisé.'):format(cfg('max_owned', 2)) }
        elseif h.kind == 'buy' then
            acts[#acts + 1] = { act = 'buy', label = 'Acheter pour ' .. money(h.price), primary = true }
        else
            acts[#acts + 1] = { act = 'rent', label = ('Louer : %s par période de %d j'):format(money(h.rent), cfg('rent_days', 7)), primary = true }
        end
        -- visite (accordée par un agent) ou agent de l'agence : on peut entrer dans le logement libre
        if (h.ix ~= 0 or h.iy ~= 0) and (Re.Visiting(p.license, h.id) or (Re.IsAgent(src) and h.listed_by == Re.Biz())) then acts[#acts + 1] = { act = 'enter', label = 'Visiter' } end
    elseif st == 'mine' or st == 'arrears' then
        if st == 'arrears' then
            blocks[#blocks + 1] = { type = 'notice', tone = 'warn', text = ('Loyer impayé : %s. Tant que tu ne régularises pas, l\'accès et le coffre sont suspendus (rien n\'est supprimé).'):format(money(rentDue(h))) }
            acts[#acts + 1] = { act = 'pay', label = 'Régler ' .. money(rentDue(h)), primary = true }
        end
        if st == 'mine' and h.kind == 'rent' then acts[#acts + 1] = { act = 'pay', label = 'Payer d\'avance une période (' .. money(h.rent) .. ')' } end
        acts[#acts + 1] = { act = 'lock', label = PB.ToBool(h.locked) and 'Déverrouiller la porte' or 'Verrouiller la porte' }
        acts[#acts + 1] = { act = 'leave', label = h.kind == 'buy' and ('Vendre (%s)'):format(money(math.floor(h.price * cfg('sell_ratio', 70) / 100))) or 'Résilier la location', danger = true }
    elseif st == 'guest' then
        blocks[#blocks + 1] = { type = 'notice', tone = 'info', text = 'Le propriétaire t\'a donné accès à ce logement.' }
    else
        blocks[#blocks + 1] = { type = 'notice', tone = 'info', text = 'Ce logement est occupé.' }
    end
    local access = st == 'mine' or st == 'guest'
    if access then
        if not PB.ToBool(h.locked) or st == 'mine' or st == 'guest' then
            acts[#acts + 1] = { act = 'stash', label = 'Ouvrir le coffre', primary = st == 'guest' }
            if h.ix ~= 0 or h.iy ~= 0 then acts[#acts + 1] = { act = 'enter', label = 'Entrer' } end
        end
    elseif st == 'taken' and h.ix ~= 0 and not PB.ToBool(h.locked) then
        acts[#acts + 1] = { act = 'enter', label = 'Entrer (porte ouverte)' }
    end
    local info = { { 'Type', h.kind == 'buy' and 'À vendre' or 'À louer' }, { 'Prix', h.kind == 'buy' and money(h.price) or (money(h.rent) .. ' / ' .. cfg('rent_days', 7) .. ' jours') },
        { 'Occupant', h.owner == '' and 'Libre' or (st == 'mine' and 'Toi' or nameOf(h.owner)) },
        { 'Porte', PB.ToBool(h.locked) and 'Verrouillée' or 'Ouverte' } }
    if st == 'mine' and h.kind == 'rent' then info[#info + 1] = { 'Loyer payé jusqu\'au', os.date('%d/%m/%Y', h.paid_until) } end
    table.insert(blocks, 1, { type = 'cards', items = {
        { title = 'Statut', value = ({ free = 'Libre', mine = 'Chez toi', arrears = 'Impayé', guest = 'Invité', taken = 'Occupé' })[st], icon = 'home', tone = st == 'arrears' and '#ffb457' or '#7be0a4', sub = h.kind == 'buy' and 'Achat' or 'Location' },
        { title = h.kind == 'buy' and 'Prix' or 'Loyer', value = h.kind == 'buy' and money(h.price) or money(h.rent), icon = 'card', tone = '#6fb4ff', sub = h.kind == 'buy' and '' or ('toutes les ' .. cfg('rent_days', 7) .. ' jours') } } })
    blocks[#blocks + 1] = { type = 'actions', items = acts }
    blocks[#blocks + 1] = { type = 'table', title = 'Informations', columns = { { k = 'k', label = '' }, { k = 'v', label = '' } }, rows = (function() local r = {} for _, i in ipairs(info) do r[#r + 1] = { k = i[1], v = i[2] } end return r end)() }
    return blocks, h.label
end
PAGES.access = function(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= p.license then return { { type = 'notice', tone = 'info', text = 'Seul le propriétaire gère les accès.' } }, 'Accès' end
    local rows, opts = {}, {}
    for _, g in ipairs(Hs.Guests(h.id)) do
        rows[#rows + 1] = { who = ((g.firstname or '') .. ' ' .. (g.lastname or '')):gsub('^%s+', ''), since = os.date('%d/%m/%Y', g.at), actions = { { act = 'revoke', label = 'Retirer', danger = true, payload = { license = g.license } } } }
    end
    for id, pl in pairs(G.Players()) do if id ~= src and PB.ToBool(pl.row.created) and G.DistBetween(src, id) <= 8 then opts[#opts + 1] = { tostring(id), display(id) .. ' (' .. id .. ')' } end end
    return { { type = 'form', id = 'invite', title = 'Donner l\'accès à une personne proche', desc = 'Elle pourra entrer et utiliser le coffre, même porte verrouillée.', fields = { { k = 'id', type = 'select', label = 'Personne', opts = opts } }, submit = { act = 'invite', label = 'Donner l\'accès', disabled = #opts == 0 } },
        { type = 'table', title = 'Personnes avec accès', columns = { { k = 'who', label = 'Personne' }, { k = 'since', label = 'Depuis le' } }, rows = rows, empty = 'Personne d\'autre n\'a accès à ce logement.' } }, 'Accès'
end

local function frame(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    local nav = { { id = 'home', label = 'Logement', icon = 'home', group = 'Logement' } }
    if h and h.owner == p.license then nav[#nav + 1] = { id = 'access', label = 'Accès', icon = 'lock', group = 'Logement' } end
    return { name = display(src), id = src, nav = nav, tone = '#dfe2e7', brand = h and h.label or 'Logement', cash = p.row.cash, bank = p.row.bank }
end
local function page(src, name)
    local s = sessions[src]
    local fn = s and PAGES[name or 'home']
    if not fn or not Hs.Get(s.id) then return nil end
    local blocks, title = fn(src, s)
    local clean = {}
    for _, b in ipairs(blocks) do if b then clean[#clean + 1] = b end end
    return { page = name or 'home', title = title, blocks = clean }
end
local function ui(src, ev, extra)
    local s = sessions[src]
    local msg = { ev = ev, frame = frame(src, s) }
    for k, v in pairs(extra or {}) do msg[k] = v end
    TriggerClientEvent('pb:g:housing:ui', src, PB.Json(msg))
end

RegisterNetEvent('pb:g:housing:open', function(id)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 400) then return end
    local h = Hs.Get(id)
    if not h or not PB.ToBool(h.enabled) or not near(src, h) then return end
    sessions[src] = { id = h.id }
    ui(src, 'open', { page = page(src, 'home') })
end)
RegisterNetEvent('pb:g:housing:page', function(name)
    local src = source
    if not sessions[src] or not throttle(src, 150) then return end
    local pg = page(src, tostring(name))
    ui(src, 'page', { page = pg, err = pg == nil and 'Page indisponible.' or nil })
end)
RegisterNetEvent('pb:g:housing:close', function() sessions[source] = nil end)
AddEventHandler('playerDropped', function() sessions[source] = nil last[tostring(source)] = nil end)

-- Actions --------------------------------------------------------------------------------------------------------------------------------
local ACT = {}
local function mine(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if not h or h.owner ~= p.license then return nil end
    return h, p
end

-- Commission de l'agence immobilière (entreprise réglable) sur chaque achat et chaque première location
local function realtorCommission(amount, what, license)
    local biz = tostring(cfg('realtor_biz', 'realestate') or '')
    local pct = tonumber(cfg('realtor_pct', 5)) or 0
    if biz == '' or pct <= 0 or not G.Eco or not (G.Biz and G.Biz.Get(biz)) then return end
    local c = math.floor(amount * pct / 100)
    if c <= 0 then return end
    G.Eco.Book('state', -c, 'Commission agence : ' .. what, license)
    G.Eco.Book('biz:' .. biz, c, 'Commission : ' .. what, license)
    for s in pairs(G.Players()) do
        local j = G.Biz.Job(s)
        if j and j.biz == biz and j.onDuty then G.Notify(s, { type = 'success', title = 'Agence immobilière', text = ('Commission de %s : %s.'):format(money(c), what) }) end
    end
end

ACT.buy = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= '' then return false, 'Ce logement est déjà pris.' end
    if h.kind ~= 'buy' then return false, 'Ce logement est à louer.' end
    if #Hs.OwnedBy(p.license) >= cfg('max_owned', 2) then return false, 'Tu as atteint le maximum de logements.' end
    local acc = G.Pay(src, h.price, 'bank')
    if not acc then return false, ('Il te faut %s.'):format(money(h.price)) end
    local ok = DB.exec("UPDATE pb_properties SET owner = ?, since = ?, paid_until = 0, arrears = 0, locked = 1 WHERE id = ? AND owner = ''", { p.license, now(), h.id })
    if ok == 0 then G.AddMoney(src, acc, h.price, 'Remboursement logement') return false, 'Un autre joueur vient de le prendre.' end
    if G.Eco then G.Eco.Book('state', h.price, 'Achat logement ' .. h.id, p.license) end
    realtorCommission(h.price, 'vente de ' .. h.label, p.license)
    TriggerEvent('pb_panel:propertyBought', src, h.id, h.price)
    return true, ('Bienvenue chez toi ! %s acheté.'):format(h.label)
end
ACT.rent = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= '' then return false, 'Ce logement est déjà pris.' end
    if h.kind ~= 'rent' then return false, 'Ce logement est à vendre.' end
    if #Hs.OwnedBy(p.license) >= cfg('max_owned', 2) then return false, 'Tu as atteint le maximum de logements.' end
    local acc = G.Pay(src, h.rent, 'bank')
    if not acc then return false, ('Il te faut %s pour la première période.'):format(money(h.rent)) end
    local ok = DB.exec("UPDATE pb_properties SET owner = ?, since = ?, paid_until = ?, arrears = 0, locked = 1 WHERE id = ? AND owner = ''", { p.license, now(), now() + period(), h.id })
    if ok == 0 then G.AddMoney(src, acc, h.rent, 'Remboursement loyer') return false, 'Un autre joueur vient de le prendre.' end
    if G.Eco then G.Eco.Book('state', h.rent, 'Loyer ' .. h.id, p.license) end
    realtorCommission(h.rent, 'location de ' .. h.label, p.license)
    return true, ('Location commencée : %s.'):format(h.label)
end
ACT.pay = function(s, src)
    local h, p = mine(src, s)
    if not h or h.kind ~= 'rent' then return false, 'Rien à payer.' end
    local periods = math.max(1, h.arrears or 0)
    local total = periods * h.rent
    local acc = G.Pay(src, total, 'bank')
    if not acc then return false, ('Il te faut %s.'):format(money(total)) end
    -- impayé : la période repart d'aujourd'hui ; sinon on prolonge d'une période
    local newUntil = (h.arrears or 0) > 0 and (now() + period()) or (math.max(h.paid_until, now()) + period())
    DB.exec('UPDATE pb_properties SET arrears = 0, paid_until = ? WHERE id = ?', { newUntil, h.id })
    if G.Eco then G.Eco.Book('state', total, 'Loyer ' .. h.id, p.license) end
    return true, ('Loyer réglé (%s).'):format(money(total))
end
ACT.lock = function(s, src)
    local h = mine(src, s)
    if not h then return false, 'Ce logement n\'est pas à toi.' end
    if inArrears(h) then return false, 'Accès suspendu : règle ton loyer.' end
    local l = PB.ToBool(h.locked) and 0 or 1
    DB.exec('UPDATE pb_properties SET locked = ? WHERE id = ?', { l, h.id })
    return true, l == 1 and 'Porte verrouillée.' or 'Porte déverrouillée.'
end
ACT.leave = function(s, src)
    local h, p = mine(src, s)
    if not h then return false, 'Ce logement n\'est pas à toi.' end
    if inArrears(h) then return false, 'Règle d\'abord ton loyer impayé.' end
    if not Hs.StashEmpty(h.id) then return false, 'Vide d\'abord le coffre du logement.' end
    local refund = 0
    if h.kind == 'buy' then
        refund = math.floor(h.price * cfg('sell_ratio', 70) / 100)
        if G.Eco and G.Eco.Balance('state') < refund then return false, "La banque d'État n'a pas les fonds pour te racheter ce logement." end
    end
    DB.exec("UPDATE pb_properties SET owner = '', since = 0, paid_until = 0, arrears = 0, locked = 1 WHERE id = ?", { h.id })
    DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    if refund > 0 then G.AddMoney(src, 'bank', refund, 'Vente logement') if G.Eco then G.Eco.Book('state', -refund, 'Rachat logement ' .. h.id, p.license) end end
    return true, h.kind == 'buy' and ('Logement vendu : %s reçus en banque.'):format(money(refund)) or 'Location résiliée.'
end
ACT.invite = function(s, src, p)
    local h, me = mine(src, s)
    if not h then return false, 'Seul le propriétaire donne un accès.' end
    if inArrears(h) then return false, 'Accès suspendu : règle ton loyer.' end
    local id = tonumber(p.id)
    local tp = id and G.Get(id)
    if not tp or id == src or not PB.ToBool(tp.row.created) then return false, 'Choisis une personne proche.' end
    if G.DistBetween(src, id) > 10 then return false, 'Cette personne est trop loin.' end
    if #Hs.Guests(h.id) >= cfg('guests_max', 6) then return false, ('Maximum %d personnes avec accès.'):format(cfg('guests_max', 6)) end
    DB.exec('INSERT IGNORE INTO pb_property_access (prop, license, by_license, at) VALUES (?, ?, ?, ?)', { h.id, tp.license, me.license, now() })
    G.Notify(id, { type = 'info', title = 'Accès reçu', text = ('Tu as maintenant accès à « %s ».'):format(h.label) })
    return true, ('Accès donné à %s.'):format(display(id))
end
ACT.revoke = function(s, src, p)
    local h = mine(src, s)
    if not h then return false, 'Seul le propriétaire retire un accès.' end
    DB.exec('DELETE FROM pb_property_access WHERE prop = ? AND license = ?', { h.id, tostring(p.license or '') })
    return true, 'Accès retiré.'
end
ACT.stash = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if not Hs.HasAccess(p.license, h) then return false, 'Tu n\'as pas accès au coffre.' end
    TriggerClientEvent('pb:g:housing:stash', src, Hs.StashOwner(h.id))
    return true, 'Coffre ouvert.'
end
ACT.enter = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.ix == 0 and h.iy == 0 then return false, 'Pas d\'intérieur configuré : entre par la porte du bâtiment.' end
    local visit = h.owner == '' and (Re.Visiting(p.license, h.id) or (Re.IsAgent(src) and h.listed_by == Re.Biz()))
    if not (visit or Hs.HasAccess(p.license, h) or (h.owner ~= '' and not PB.ToBool(h.locked))) then return false, 'La porte est verrouillée.' end
    TriggerClientEvent('pb:g:housing:teleport', src, PB.Json({ x = h.ix, y = h.iy, z = h.iz, h = h.ih, id = h.id, label = h.label }))
    return true, 'Entrée.'
end

RegisterNetEvent('pb:g:housing:act', function(name, payload, pgname)
    local src = source
    local s = sessions[src]
    if not s or not usable(src) or not throttle(src, 400) then return end
    local fn = ACT[tostring(name)]
    local ok, msg = false, 'Action inconnue.'
    local h = Hs.Get(s.id)
    if fn and h then
        if not near(src, h, cfg('use_distance', 2.5) + 8) then ok, msg = false, 'Tu es trop loin.'
        else ok, msg = fn(s, src, type(payload) == 'table' and payload or {}) end
    end
    ui(src, 'result', { ok = ok and true or false, msg = msg, page = page(src, tostring(pgname or 'home')) })
end)

-- Sortie de l'intérieur : retour devant la porte
RegisterNetEvent('pb:g:housing:exit', function(id)
    local src = source
    local h = usable(src) and Hs.Get(id)
    if not h or not throttle(src, 800) then return end
    local p = G.Get(src)
    if not (Hs.HasAccess(p.license, h) or h.ix ~= 0) then return end
    if h.ix ~= 0 and G.DistTo(src, h.ix, h.iy, h.iz) > 60 then return end
    TriggerClientEvent('pb:g:housing:teleport', src, PB.Json({ x = h.x, y = h.y, z = h.z, h = 0, exit = true }))
end)

-- Loyers : toutes les minutes, pour les locataires en ligne ----------------------------------------------------------------------------
function Hs.Settle(src)
    local p = G.Get(src)
    if not p then return end
    for _, h in ipairs(DB.q("SELECT * FROM pb_properties WHERE owner = ? AND kind = 'rent' AND paid_until > 0 AND paid_until <= ?", { p.license, now() }) or {}) do
        local due = math.floor((now() - h.paid_until) / period()) + 1
        local arrears = h.arrears or 0
        local paidPeriods = 0
        for _ = 1, due do
            if G.Pay(src, h.rent, 'bank') then
                paidPeriods = paidPeriods + 1
                if G.Eco then G.Eco.Book('state', h.rent, 'Loyer ' .. h.id, p.license) end
            else arrears = arrears + 1 end
        end
        DB.exec('UPDATE pb_properties SET paid_until = ?, arrears = ? WHERE id = ?', { h.paid_until + due * period(), math.min(arrears, cfg('grace_periods', 3) * 99), h.id })
        if arrears > (h.arrears or 0) then G.Notify(src, { type = 'error', title = 'Loyer impayé', text = ('%s : %s à régler. L\'accès est suspendu jusqu\'au paiement.'):format(h.label, money(arrears * h.rent)) })
        elseif paidPeriods > 0 then G.Notify(src, { type = 'info', title = 'Loyer prélevé', text = ('%s : %s prélevés.'):format(h.label, money(paidPeriods * h.rent)) }) end
    end
end
CreateThread(function()
    while true do
        Wait(60000)
        for src in pairs(G.Players()) do pcall(Hs.Settle, src) end
    end
end)

function G.HousingPoints()
    local out = {}
    for _, h in ipairs(Hs.All()) do
        if PB.ToBool(h.enabled) then out[#out + 1] = { id = h.id, label = h.label, kind = h.kind, x = h.x, y = h.y, z = h.z, free = h.owner == '' } end
    end
    return out
end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
PB.Action('housing.save', 'housing.edit', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
        { k = 'kind', type = 'select', label = 'Type', opts = { { 'buy', 'À vendre' }, { 'rent', 'À louer' } } },
        { k = 'price', type = 'number', label = 'Prix', min = 0, max = 100000000 }, { k = 'rent', type = 'number', label = 'Loyer', min = 0, max = 10000000 },
        { k = 'coords', type = 'coords', label = 'Porte' }, { k = 'inside', type = 'coords', label = 'Intérieur' }, { k = 'enabled', type = 'toggle', label = 'Actif' },
    }, { id = v.id, label = v.label, kind = v.kind or 'buy', price = v.price or 0, rent = v.rent or 0, coords = v.coords or { x = 0, y = 0, z = 0, h = 0 }, inside = v.inside or { x = 0, y = 0, z = 0, h = 0 }, enabled = v.enabled ~= false })
    if not c then return false, err end
    if c.coords.x == 0 and c.coords.y == 0 then return false, 'Place la porte sur la carte.' end
    if c.kind == 'buy' and c.price <= 0 then return false, 'Indique un prix de vente.' end
    if c.kind == 'rent' and c.rent <= 0 then return false, 'Indique un loyer.' end
    local before = Hs.Get(c.id)
    if before and before.owner ~= '' and before.kind ~= c.kind then return false, 'Libère le logement avant de changer son type.' end
    DB.exec('INSERT INTO pb_properties (id, label, kind, price, rent, x, y, z, ix, iy, iz, ih, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), kind = VALUES(kind), price = VALUES(price), rent = VALUES(rent), x = VALUES(x), y = VALUES(y), z = VALUES(z), ix = VALUES(ix), iy = VALUES(iy), iz = VALUES(iz), ih = VALUES(ih), enabled = VALUES(enabled)',
        { c.id, c.label, c.kind, c.price, c.rent, c.coords.x, c.coords.y, c.coords.z, c.inside.x, c.inside.y, c.inside.z, c.inside.h, c.enabled and 1 or 0 })
    ctx.audit('config', before and 'housing.edit' or 'housing.create', c.id, before, c)
    G.PushConfig()
    ctx.toast = 'Logement enregistré.'
    return true
end)
PB.Action('housing.delete', 'housing.edit', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h then return false, 'Introuvable.' end
    if h.owner ~= '' then return false, 'Un joueur y vit : libère-le avant de le supprimer.' end
    if not Hs.StashEmpty(h.id) then return false, 'Le coffre contient des objets.' end
    DB.exec('DELETE FROM pb_properties WHERE id = ?', { h.id }) DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    ctx.audit('config', 'housing.delete', h.id, h, nil)
    G.PushConfig()
    ctx.toast = 'Logement supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce logement ?', text = 'Il disparaît de la carte.', danger = true } })
PB.Action('housing.release', 'housing.manage', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h or h.owner == '' then return false, 'Ce logement est déjà libre.' end
    DB.exec("UPDATE pb_properties SET owner = '', since = 0, paid_until = 0, arrears = 0, locked = 1 WHERE id = ?", { h.id })
    DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    ctx.audit('serveur', 'housing.release', h.id, { owner = h.owner }, { owner = '' })
    ctx.toast = Hs.StashEmpty(h.id) and 'Logement libéré.' or 'Logement libéré. Attention : son coffre contient encore des objets.'
    return true
end, { critical = true, confirm = { title = 'Libérer ce logement ?', text = "L'occupant perd l'accès. Aucun remboursement n'est fait.", danger = true } })
PB.Action('housing.clear_stash', 'housing.manage', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h then return false, 'Introuvable.' end
    if h.owner ~= '' then return false, "Le logement est occupé : le contenu appartient à l'occupant." end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { Hs.StashOwner(h.id) })
    DB.exec('DELETE FROM pb_inv WHERE owner = ?', { Hs.StashOwner(h.id) })
    ctx.audit('serveur', 'housing.clear_stash', h.id, { stacks = n and n.n or 0 }, nil)
    ctx.toast = 'Coffre vidé.'
    return true
end, { critical = true, confirm = { title = 'Vider le coffre ?', text = 'Les objets sont supprimés définitivement.', danger = true } })
PB.Action('housing.forgive', 'housing.manage', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h or (h.arrears or 0) == 0 then return false, 'Pas de loyer impayé.' end
    DB.exec('UPDATE pb_properties SET arrears = 0, paid_until = ? WHERE id = ?', { now() + period(), h.id })
    ctx.audit('serveur', 'housing.forgive', h.id, { arrears = h.arrears }, { arrears = 0 })
    ctx.toast = 'Dette effacée.'
    return true
end)

local settings = Form.Cfg({ ns = 'housing', id = 'settings', title = 'Réglages des logements', perm = 'housing.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Logements actifs', default = true }, { k = 'blips', type = 'toggle', label = 'Afficher les logements sur la carte', default = true },
    { k = 'realtor_biz', type = 'text', label = "Agence immobilière (identifiant de l'entreprise)", default = 'realestate', maxlen = 32, pattern = '^[%w_]*$', hint = 'Elle touche une commission sur chaque vente et chaque première location. Vide = aucune.' },
    { k = 'realtor_pct', type = 'number', label = "Commission de l'agence (%)", default = 5, min = 0, max = 50 },
    { k = 'realtor_max', type = 'number', label = "Annonces maximum de l'agence", default = 40, min = 1, max = 500, hint = 'Logements mis en vente / en location par les agents (menu ALT).' },
    { k = 'max_owned', type = 'number', label = 'Logements maximum par joueur', default = 2, min = 1, max = 20 }, { k = 'rent_days', type = 'number', label = 'Durée d\'une période de loyer (jours)', default = 7, min = 1, max = 60 },
    { k = 'grace_periods', type = 'number', label = 'Périodes d\'impayé tolérées avant alerte', default = 3, min = 1, max = 20, hint = "Un impayé suspend l'accès et le coffre ; rien n'est jamais supprimé automatiquement." },
    { k = 'sell_ratio', type = 'number', label = 'Revente : % du prix remboursé', default = 70, min = 0, max = 100 }, { k = 'guests_max', type = 'number', label = 'Personnes avec accès par logement', default = 6, min = 0, max = 30 },
    { k = 'use_distance', type = 'number', label = 'Distance pour ouvrir le menu (m)', default = 2.5, min = 1, max = 10, int = false, step = 0.5 },
} })

PB.Module({
    id = 'housing', label = 'Logements', icon = 'home', group = 'Serveur', order = 97, perm = 'housing.view', hint = 'Achat, location, accès, coffre',
    caps = function()
        return PB.Capsify({
            { 'Achat et location de logements', 'ok', 'Paiement par la banque en priorité ; l\'argent va au compte « État ».' },
            { 'Loyers automatiques', 'ok', 'Prélevés par période pour les locataires en ligne ; impayé = accès suspendu, jamais de suppression.' },
            { 'Accès partagés et porte verrouillable', 'ok', 'Invités à proximité, retirables à tout moment.' },
            { 'Coffre du logement', 'ok', "Branché sur l'inventaire (contenu protégé : on ne peut pas vendre un coffre plein)." },
            { 'Intérieurs (IPL / MLO)', 'off', "Aucun intérieur n'est fourni : place les coordonnées d'un intérieur existant ou utilise l'entrée du bâtiment." },
            { 'Garde-robe, décoration, cambriolage', 'off', 'Non prévus. Pour changer de tenue, utilise une boutique de vêtements.' },
        })
    end,
    doc = "## Logements\nChaque logement a une **porte** sur la carte. Le joueur appuie sur E, puis achète ou loue. Le propriétaire peut verrouiller, donner un accès à des proches et utiliser le **coffre** (dans l'inventaire).\n\nUn **intérieur** est facultatif : indique ses coordonnées pour que « Entrer » y téléporte. Sans intérieur, le logement sert de point de coffre et de droits d'accès pour un bâtiment que tu as déjà cartographié.\n\nPour tes scripts : `HasHousingAccess(source, id)`, `GetProperties(source)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                for _, p in ipairs(Hs.All()) do pts[#pts + 1] = { id = p.id, x = p.x, y = p.y, on = PB.ToBool(p.enabled), color = (p.owner or '') ~= '' and '#ff7a7a' or '#7bd88f', label = p.label, sub = (p.owner or '') ~= '' and 'occupé' or 'libre' } end
                return { { type = 'map', id = 'hmap', title = 'Logements', points = pts, legend = { { color = '#7bd88f', label = 'Libre' }, { color = '#ff7a7a', label = 'Occupé' } } } }
            end },
            { id = 'overview', label = "Vue d'ensemble", icon = 'chart', build = function()
                local all = Hs.All()
                local taken, arrears = 0, 0
                for _, h in ipairs(all) do if h.owner ~= '' then taken = taken + 1 end if inArrears(h) then arrears = arrears + 1 end end
                return { { type = 'cards', items = {
                    { title = 'Logements', value = tostring(#all), icon = 'home', tone = '#6fb4ff', sub = 'Sur la carte' }, { title = 'Occupés', value = tostring(taken), icon = 'user', tone = '#7be0a4', sub = ('%d libres'):format(#all - taken) },
                    { title = 'Loyers impayés', value = tostring(arrears), icon = 'card', tone = arrears > 0 and '#ffb457' or '#7be0a4', sub = 'Accès suspendus' } } } }
            end },
            { id = 'list', label = 'Logements', icon = 'building', build = function()
                local rows = {}
                for _, h in ipairs(Hs.All()) do
                    local acts = {}
                    if ctx.has('housing.manage') and h.owner ~= '' then
                        if (h.arrears or 0) > 0 then acts[#acts + 1] = { action = 'housing.forgive', label = 'Effacer la dette', icon = 'check', payload = { id = h.id } } end
                        acts[#acts + 1] = { action = 'housing.release', label = 'Libérer', icon = 'refresh', danger = true, payload = { id = h.id } }
                    elseif ctx.has('housing.manage') and not Hs.StashEmpty(h.id) then acts[#acts + 1] = { action = 'housing.clear_stash', label = 'Vider le coffre', icon = 'trash', danger = true, payload = { id = h.id } } end
                    if ctx.has('housing.edit') and h.owner == '' then acts[#acts + 1] = { action = 'housing.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = h.id } } end
                    rows[#rows + 1] = { label = h.label, id = h.id, kind = h.kind == 'buy' and 'Vente' or 'Location', price = h.kind == 'buy' and money(h.price) or (money(h.rent) .. '/' .. cfg('rent_days', 7) .. 'j'),
                        who = h.owner == '' and 'Libre' or nameOf(h.owner), state = h.owner == '' and { text = 'Libre', tone = 'ok' } or (inArrears(h) and { text = 'Impayé', tone = 'warn' } or { text = 'Occupé', tone = 'off' }), actions = acts }
                end
                local blocks = { B.table({ id = 'hl', title = 'Logements (' .. #rows .. ')', search = true, columns = { { k = 'label', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'kind', label = 'Type' }, { k = 'price', label = 'Prix' }, { k = 'who', label = 'Occupant' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows }),
                    B.notice('info', "Coordonnées par défaut : des lieux connus de Los Santos, sans intérieur. Vérifie chaque porte en jeu avant d'ouvrir.") }
                if ctx.has('housing.edit') then blocks[#blocks + 1] = { type = 'form', id = 'housing.form', title = 'Ajouter ou modifier un logement', desc = 'Même identifiant = modification. « Intérieur » est facultatif.', cols = 2, fields = {
                    { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
                    { k = 'kind', type = 'select', label = 'Type', opts = { { 'buy', 'À vendre' }, { 'rent', 'À louer' } } }, { k = 'price', type = 'number', label = 'Prix de vente', min = 0, max = 100000000 }, { k = 'rent', type = 'number', label = 'Loyer par période', min = 0, max = 10000000 },
                    { k = 'coords', type = 'coords', label = 'Porte (menu)', wide = true }, { k = 'inside', type = 'coords', label = 'Intérieur (facultatif)', wide = true }, { k = 'enabled', type = 'toggle', label = 'Actif' } },
                    values = { id = '', label = '', kind = 'buy', price = 100000, rent = 500, coords = { x = 0, y = 0, z = 0, h = 0 }, inside = { x = 0, y = 0, z = 0, h = 0 }, enabled = true }, submit = { action = 'housing.save', label = 'Enregistrer' } } end
                return blocks
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'housing', title = 'Logement vu par le joueur', cfg = {} } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'housing.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('logements', function(R)
    for _, h in ipairs(Hs.All()) do
        R.check(h.x ~= 0 or h.y ~= 0, 'logement ' .. h.id, 'porte non définie')
        R.check(h.kind == 'buy' and h.price > 0 or h.kind == 'rent' and h.rent > 0, 'logement ' .. h.id, h.kind == 'buy' and 'prix de vente nul' or 'loyer nul')
        R.check(h.owner == '' or DB.one('SELECT license FROM pb_players WHERE license = ?', { h.owner }) ~= nil, 'logement ' .. h.id, "le propriétaire n'existe plus")
    end
    local orphan = DB.one('SELECT COUNT(*) AS n FROM pb_property_access a LEFT JOIN pb_properties p ON p.id = a.prop WHERE p.id IS NULL')
    R.check(not orphan or orphan.n == 0, 'accès aux logements', 'des accès référencent un logement supprimé')
    R.check(Inv ~= nil and Inv.ExtraAccess ~= nil, 'coffre du logement', "l'inventaire n'est pas chargé : les coffres de logement sont inutilisables")
end)
