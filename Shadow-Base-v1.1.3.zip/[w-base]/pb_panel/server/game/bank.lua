-- Banque : agences, distributeurs, dépôt / retrait / virement par IBAN, historique, frais et plafonds. Autonome (pb_bank_*).
-- Le serveur vérifie : session ouverte, proximité (agences et points configurés), plafonds, solde, destinataire.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('bank.edit', 'Modifier les agences, distributeurs et réglages de la banque', 'bank', true)
P.Register('bank.adjust', "Ajuster le solde d'un joueur (audité)", 'bank', true)
P.Register('bank.ledger', 'Voir toutes les transactions bancaires', 'bank')

local DEFAULT_POINTS = {
    { 'branch_legion', 'branch', 'Fleeca — Legion Square', 149.9, -1040.2, 29.4 }, { 'branch_rockford', 'branch', 'Fleeca — Rockford Plaza', -1212.98, -330.84, 37.78 },
    { 'branch_greatocean', 'branch', 'Fleeca — Great Ocean Highway', -2962.58, 482.63, 15.7 }, { 'branch_hawick', 'branch', 'Fleeca — Hawick Avenue', 314.19, -278.62, 54.17 },
    { 'branch_burton', 'branch', 'Fleeca — Burton', -351.53, -49.53, 49.04 }, { 'branch_pacific', 'branch', 'Pacific Standard', 247.7, 224.0, 106.3 },
}
local BANK_SQL = {
    [[CREATE TABLE IF NOT EXISTS pb_bank_points (id VARCHAR(32) NOT NULL, kind VARCHAR(8) NOT NULL DEFAULT 'branch', label VARCHAR(48) NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_bank_accounts (license VARCHAR(64) NOT NULL, iban VARCHAR(16) NOT NULL, created_at INT NOT NULL DEFAULT 0, PRIMARY KEY (license), UNIQUE KEY u_iban (iban))]],
    [[CREATE TABLE IF NOT EXISTS pb_bank_tx (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, kind VARCHAR(12) NOT NULL, amount BIGINT NOT NULL, balance BIGINT NOT NULL DEFAULT 0, other VARCHAR(80) NOT NULL DEFAULT '', note VARCHAR(80) NOT NULL DEFAULT '',
        via VARCHAR(8) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license, id), KEY k_at (at))]],
}
PB.Migrate('047_game_bank', 'Banque : points, comptes, transactions', function()
    for _, sql in ipairs(BANK_SQL) do DB.exec(PB.Table(sql)) end
    for _, d in ipairs(DEFAULT_POINTS) do DB.exec('INSERT IGNORE INTO pb_bank_points (id, kind, label, x, y, z) VALUES (?, ?, ?, ?, ?, ?)', d) end
end)

PB.Cfg.Define('bank', { atm_props = true, atm_fee = 2, atm_max_withdraw = 5000, atm_daily_limit = 20000, branch_daily_limit = 0, transfer_fee = 1, transfer_max = 250000, transfer_min = 1, atm_models = 'prop_atm_01,prop_atm_02,prop_atm_03,prop_fleeca_atm', use_distance = 2.0, blips = true, interest_note = true })

local Bk = {}
G.Bank = Bk
local function cfg(k, d) return PB.Cfg.Get('bank', k, d) end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end

-- Comptes -----------------------------------------------------------------------------------------------------------------------------
function Bk.Iban(license)
    local r = DB.one('SELECT iban FROM pb_bank_accounts WHERE license = ?', { license })
    if r then return r.iban end
    for _ = 1, 40 do
        local n = ('PB%08d'):format(math.random(0, 99999999))
        if not DB.one('SELECT iban FROM pb_bank_accounts WHERE iban = ?', { n }) then
            DB.exec('INSERT INTO pb_bank_accounts (license, iban, created_at) VALUES (?, ?, ?)', { license, n, now() })
            return n
        end
    end
end
exports('GetIban', function(src) local p = G.Get(tonumber(src)) return p and Bk.Iban(p.license) or nil end)

local function tx(license, kind, amount, balance, other, note, via)
    DB.exec('INSERT INTO pb_bank_tx (license, kind, amount, balance, other, note, via, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', { license, kind, amount, balance, tostring(other or ''):sub(1, 80), tostring(note or ''):sub(1, 80), via or '', now() })
end
function Bk.Log(license, kind, amount, balance, other, note, via) tx(license, kind, amount, balance, other, note, via) end

local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end

-- Plafonds ----------------------------------------------------------------------------------------------------------------------------
local function usedToday(license, via)
    local r = DB.one("SELECT COALESCE(SUM(amount), 0) AS s FROM pb_bank_tx WHERE license = ? AND kind = 'withdraw' AND via = ? AND at >= ?", { license, via, now() - 86400 })
    return r and tonumber(r.s) or 0
end

-- Sessions : la banque est « ouverte » par un point (agence) ou un distributeur ---------------------------------------------------------
local sessions = {}
function Bk.Points() return DB.q('SELECT * FROM pb_bank_points ORDER BY label') or {} end
function Bk.Point(id) return DB.one('SELECT * FROM pb_bank_points WHERE id = ?', { tostring(id) }) end
local function nearPoint(src, p) return G.DistTo(src, p.x, p.y, p.z) <= cfg('use_distance', 2.0) + 4 end

-- Un joueur est-il à côté d'un distributeur configuré ? (les props du jeu ne sont pas vérifiables côté serveur : voir caps)
function Bk.OpenFor(src, ref)
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) or (G.IsCuffed and G.IsCuffed(src)) then return nil, 'Indisponible.' end
    ref = tostring(ref or '')
    if ref == 'atm' then
        if not cfg('atm_props', true) then return nil, 'Les distributeurs du décor sont désactivés.' end
        return { kind = 'atm', via = 'atm' }
    end
    local pt = Bk.Point(ref)
    if not pt or not PB.ToBool(pt.enabled) then return nil, 'Point introuvable.' end
    if not nearPoint(src, pt) then return nil, 'Tu es trop loin.' end
    return { kind = pt.kind, via = pt.kind == 'atm' and 'atm' or 'branch', point = pt }
end

local ACT = {}

ACT.deposit = function(s, src, p)
    local a = math.floor(tonumber(p.amount) or 0)
    if a < 1 then return false, 'Montant invalide.' end
    if s.kind == 'atm' then return false, "Ce distributeur n'accepte pas les dépôts : va en agence." end
    if not G.RemoveMoney(src, 'cash', a) then return false, "Tu n'as pas assez d'espèces." end
    G.AddMoney(src, 'bank', a)
    local pl = G.Get(src)
    tx(pl.license, 'deposit', a, pl.row.bank, '', '', s.via)
    return true, ('%s déposés.'):format(money(a))
end

ACT.withdraw = function(s, src, p)
    local a = math.floor(tonumber(p.amount) or 0)
    if a < 1 then return false, 'Montant invalide.' end
    local pl = G.Get(src)
    local fee = 0
    if s.via == 'atm' then
        local mx = cfg('atm_max_withdraw', 5000)
        if mx > 0 and a > mx then return false, ('Plafond par retrait au distributeur : %s.'):format(money(mx)) end
        local day = cfg('atm_daily_limit', 20000)
        if day > 0 and usedToday(pl.license, 'atm') + a > day then return false, ('Plafond journalier atteint (%s). Il reste %s.'):format(money(day), money(math.max(0, day - usedToday(pl.license, 'atm')))) end
        fee = math.floor(a * cfg('atm_fee', 2) / 100 + 0.5)
    else
        local day = cfg('branch_daily_limit', 0)
        if day > 0 and usedToday(pl.license, 'branch') + a > day then return false, ('Plafond journalier en agence atteint (%s).'):format(money(day)) end
    end
    if G.GetMoney(src, 'bank') < a + fee then return false, ('Solde insuffisant%s.'):format(fee > 0 and (' (frais : ' .. money(fee) .. ')') or '') end
    G.RemoveMoney(src, 'bank', a + fee)
    G.AddMoney(src, 'cash', a)
    if fee > 0 and G.Eco then G.Eco.Book('state', fee, 'Frais de distributeur', pl.license) end
    tx(pl.license, 'withdraw', a, pl.row.bank, '', '', s.via)
    if fee > 0 then tx(pl.license, 'fee', fee, pl.row.bank, '', 'Frais de distributeur', s.via) end
    return true, ('%s retirés%s.'):format(money(a), fee > 0 and (' (frais ' .. money(fee) .. ')') or '')
end

-- Virement vers un IBAN (agence, tablette ou téléphone) : mêmes limites, mêmes frais, mêmes écritures.
function Bk.Transfer(src, p, via)
    local a = math.floor(tonumber(p.amount) or 0)
    local mn, mx = cfg('transfer_min', 1), cfg('transfer_max', 250000)
    if a < mn or a > mx then return false, ('Montant : %s à %s.'):format(money(mn), money(mx)) end
    local iban = tostring(p.iban or ''):upper():gsub('%s', '')
    if not iban:match('^PB%d%d%d%d%d%d%d%d$') then return false, 'IBAN invalide (format PB + 8 chiffres).' end
    local me = G.Get(src)
    local dest = DB.one('SELECT license FROM pb_bank_accounts WHERE iban = ?', { iban })
    if not dest then return false, 'Aucun compte avec cet IBAN.' end
    if dest.license == me.license then return false, 'Tu ne peux pas te virer de l\'argent à toi-même.' end
    local fee = math.floor(a * cfg('transfer_fee', 1) / 100 + 0.5)
    if G.GetMoney(src, 'bank') < a + fee then return false, ('Solde insuffisant (frais : %s).'):format(money(fee)) end
    G.RemoveMoney(src, 'bank', a + fee)
    local onlineId
    for id, pl in pairs(G.Players()) do if pl.license == dest.license then onlineId = id end end
    if onlineId then G.AddMoney(onlineId, 'bank', a)
    else DB.exec('UPDATE pb_players SET bank = bank + ? WHERE license = ?', { a, dest.license }) end
    if fee > 0 and G.Eco then G.Eco.Book('state', fee, 'Frais de virement', me.license) end
    local reason = PB.Trim(PB.Sanitize(tostring(p.note or ''), 80))
    local destBal = onlineId and G.Get(onlineId).row.bank or (DB.one('SELECT bank FROM pb_players WHERE license = ?', { dest.license }) or {}).bank or 0
    tx(me.license, 'transfer_out', a, me.row.bank, iban, reason, via)
    tx(dest.license, 'transfer_in', a, destBal, Bk.Iban(me.license) or '', reason, via)
    if fee > 0 then tx(me.license, 'fee', fee, me.row.bank, '', 'Frais de virement', via) end
    if onlineId then G.Notify(onlineId, { type = 'success', title = 'Virement reçu', text = ('%s de %s%s'):format(money(a), display(src), reason ~= '' and (' — ' .. reason) or '') }) end
    TriggerEvent('pb_panel:transfer', src, dest.license, a)
    return true, ('Virement de %s envoyé.'):format(money(a))
end

ACT.transfer = function(s, src, p)
    if s.kind == 'atm' then return false, 'Les virements se font en agence ou depuis la tablette.' end
    return Bk.Transfer(src, p, s.via)
end

-- Pages -------------------------------------------------------------------------------------------------------------------------------
local KIND = { deposit = 'Dépôt', withdraw = 'Retrait', transfer_out = 'Virement émis', transfer_in = 'Virement reçu', fee = 'Frais', admin = 'Ajustement', salary = 'Salaire' }
local function stat(title, value, icon, tone, sub) return { title = title, value = value, icon = icon, tone = tone, sub = sub } end

local PAGES = {}
PAGES.home = function(src, s)
    local pl = G.Get(src)
    local iban = Bk.Iban(pl.license)
    local rows = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_bank_tx WHERE license = ? ORDER BY id DESC LIMIT 5', { pl.license }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at), kind = KIND[r.kind] or r.kind, amount = ((r.kind == 'deposit' or r.kind == 'transfer_in' or r.kind == 'salary') and '+' or '−') .. money(r.amount), note = r.note ~= '' and r.note or r.other }
    end
    return { { type = 'hero', title = display(src), sub = s.kind == 'atm' and 'Distributeur automatique' or 'Ton compte bancaire', tone = '#6fb4ff', chips = { { 'IBAN', iban or '—' }, { 'Solde', money(pl.row.bank) }, { 'Espèces', money(pl.row.cash) } } },
        { type = 'cards', items = { stat('Compte bancaire', money(pl.row.bank), 'card', '#6fb4ff', 'Disponible'), stat('Argent liquide', money(pl.row.cash), 'coins', '#7be0a4', 'Sur toi'),
            s.via == 'atm' and stat('Retraits du jour', money(usedToday(pl.license, 'atm')), 'clock', '#ffb457', cfg('atm_daily_limit', 20000) > 0 and ('Plafond ' .. money(cfg('atm_daily_limit', 20000))) or 'Sans plafond') or stat('Frais de virement', cfg('transfer_fee', 1) .. ' %', 'file', '#ffb457', 'Dépôt et retrait gratuits') } },
        { type = 'table', title = 'Dernières opérations', columns = { { k = 'at', label = 'Date' }, { k = 'kind', label = 'Opération' }, { k = 'amount', label = 'Montant' }, { k = 'note', label = 'Détail' } }, rows = rows, empty = 'Aucune opération.' } }, 'Mon compte'
end
PAGES.ops = function(src, s)
    local blocks = {}
    if s.kind ~= 'atm' then blocks[#blocks + 1] = { type = 'form', id = 'dep', title = 'Déposer des espèces', desc = 'Gratuit.', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1 } }, submit = { act = 'deposit', label = 'Déposer' } } end
    local fee = s.via == 'atm' and cfg('atm_fee', 2) or 0
    local mx = s.via == 'atm' and cfg('atm_max_withdraw', 5000) or nil
    blocks[#blocks + 1] = { type = 'form', id = 'wd', title = 'Retirer des espèces', desc = s.via == 'atm' and (('Frais : %s %% · plafond par retrait : %s'):format(fee, money(mx))) or 'Gratuit en agence.', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = mx } }, submit = { act = 'withdraw', label = 'Retirer' } }
    return blocks, 'Dépôt et retrait'
end
PAGES.transfer = function(src, s)
    if s.kind == 'atm' then return nil end
    return { { type = 'form', id = 'tr', title = 'Virement par IBAN', desc = ('Frais : %s %% · maximum %s'):format(cfg('transfer_fee', 1), money(cfg('transfer_max', 250000))), fields = {
        { k = 'iban', type = 'text', label = 'IBAN du destinataire (PB…)', maxlen = 16 }, { k = 'amount', type = 'number', label = 'Montant', min = 1, max = cfg('transfer_max', 250000) }, { k = 'note', type = 'text', label = 'Motif (facultatif)', maxlen = 80 } },
        submit = { act = 'transfer', label = 'Envoyer le virement' } } }, 'Virement'
end
PAGES.history = function(src)
    local pl = G.Get(src)
    local rows = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_bank_tx WHERE license = ? ORDER BY id DESC LIMIT 60', { pl.license }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at), kind = KIND[r.kind] or r.kind, amount = ((r.kind == 'deposit' or r.kind == 'transfer_in' or r.kind == 'salary') and '+' or '−') .. money(r.amount), bal = money(r.balance), note = r.note ~= '' and r.note or r.other }
    end
    return { { type = 'table', title = 'Historique', columns = { { k = 'at', label = 'Date' }, { k = 'kind', label = 'Opération' }, { k = 'amount', label = 'Montant' }, { k = 'bal', label = 'Solde après' }, { k = 'note', label = 'Détail' } }, rows = rows, empty = 'Aucune opération.' } }, 'Historique'
end
local META = { { 'home', 'Mon compte', 'card' }, { 'ops', 'Dépôt / retrait', 'coins' }, { 'transfer', 'Virement', 'file' }, { 'history', 'Historique', 'clock' } }

local function frame(src, s)
    local pl = G.Get(src)
    local nav = {}
    for _, m in ipairs(META) do if not (m[1] == 'transfer' and s.kind == 'atm') then nav[#nav + 1] = { id = m[1], label = m[2], icon = m[3], group = s.kind == 'atm' and 'Distributeur' or 'Banque' } end end
    return { name = display(src), id = src, nav = nav, tone = '#6fb4ff', brand = (s.point and s.point.label) or 'Distributeur', cash = pl.row.cash, bank = pl.row.bank }
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end
local function page(src, name) local fn = PAGES[name or 'home'] if not fn then return nil end local blocks, title = fn(src, sessions[src]) if not blocks then return nil end return { page = name or 'home', title = title, blocks = blocks } end

RegisterNetEvent('pb:g:bank:open', function(ref)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not throttle(src, 400) then return end
    local s, err = Bk.OpenFor(src, ref)
    if not s then G.Notify(src, { type = 'error', text = err }) return end
    sessions[src] = s
    TriggerClientEvent('pb:g:bank:ui', src, PB.Json({ ev = 'open', frame = frame(src, s), page = page(src, 'home') }))
end)
RegisterNetEvent('pb:g:bank:page', function(name)
    local src = source
    local s = sessions[src]
    if not s or not throttle(src, 150) then return end
    local pg = page(src, tostring(name))
    TriggerClientEvent('pb:g:bank:ui', src, PB.Json({ ev = 'page', frame = frame(src, s), page = pg, err = pg == nil and 'Page indisponible.' or nil }))
end)
RegisterNetEvent('pb:g:bank:act', function(name, payload, pgname)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    local s = sessions[src]
    if not s or not throttle(src, 300) then return end
    local fn = ACT[tostring(name)]
    local ok, msg = false, 'Action inconnue.'
    local pl = G.Get(src)
    if fn and pl and not PB.ToBool(pl.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) then
        -- une agence se quitte : on revérifie la proximité à chaque opération
        if s.point and not nearPoint(src, s.point) then ok, msg = false, 'Tu es trop loin.'
        else ok, msg = fn(s, src, type(payload) == 'table' and payload or {}) end
    end
    TriggerClientEvent('pb:g:bank:ui', src, PB.Json({ ev = 'result', ok = ok and true or false, msg = msg, frame = frame(src, s), page = page(src, tostring(pgname or 'home')) }))
end)
RegisterNetEvent('pb:g:bank:close', function() sessions[source] = nil end)
AddEventHandler('playerDropped', function() sessions[source] = nil last[tostring(source)] = nil end)
Bk.__act = ACT

function G.BankPoints()
    local out = {}
    for _, p in ipairs(Bk.Points()) do if PB.ToBool(p.enabled) then out[#out + 1] = { id = p.id, kind = p.kind, label = p.label, x = p.x, y = p.y, z = p.z } end end
    return out
end

-- Panel ------------------------------------------------------------------------------------------------------------------------------
PB.Action('bank.point.save', 'bank.edit', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'kind', type = 'select', label = 'Type', opts = { { 'branch', 'Agence' }, { 'atm', 'Distributeur' } } },
        { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'coords', type = 'coords', label = 'Position' }, { k = 'enabled', type = 'toggle', label = 'Actif' },
    }, { id = v.id, kind = v.kind or 'branch', label = v.label, coords = v.coords or { x = 0, y = 0, z = 0, h = 0 }, enabled = v.enabled ~= false })
    if not c then return false, err end
    if c.coords.x == 0 and c.coords.y == 0 then return false, 'Place le point sur la carte (position 0, 0 refusée).' end
    local before = Bk.Point(c.id)
    DB.exec('INSERT INTO pb_bank_points (id, kind, label, x, y, z, enabled) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE kind = VALUES(kind), label = VALUES(label), x = VALUES(x), y = VALUES(y), z = VALUES(z), enabled = VALUES(enabled)',
        { c.id, c.kind, c.label, c.coords.x, c.coords.y, c.coords.z, c.enabled and 1 or 0 })
    ctx.audit('config', before and 'bank.point.edit' or 'bank.point.create', c.id, before, c)
    G.PushConfig()
    ctx.toast = 'Point enregistré.'
    return true
end)
PB.Action('bank.point.delete', 'bank.edit', function(ctx, p)
    local pt = Bk.Point(p.id)
    if not pt then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_bank_points WHERE id = ?', { pt.id })
    ctx.audit('config', 'bank.point.delete', pt.id, pt, nil)
    G.PushConfig()
    ctx.toast = 'Point supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce point ?', text = 'Les joueurs ne pourront plus l\'utiliser.' } })

PB.Action('bank.adjust', 'bank.adjust', function(ctx, p)
    local v = p.values or {}
    local id = tonumber(v.player)
    local pl = id and G.Get(id)
    if not pl or not PB.ToBool(pl.row.created) then return false, "Ce joueur n'est pas connecté avec un personnage." end
    local a = math.floor(tonumber(v.amount) or 0)
    if a < 1 or a > 100000000 then return false, 'Montant : 1 à 100 000 000.' end
    local mode = tostring(v.mode or 'add')
    if mode == 'add' then G.AddMoney(id, 'bank', a)
    elseif mode == 'remove' then if not G.RemoveMoney(id, 'bank', a) then return false, "Son solde est inférieur à ce montant." end
    else return false, 'Opération inconnue.' end
    tx(pl.license, 'admin', a, pl.row.bank, '', (mode == 'add' and 'Crédit' or 'Débit') .. ' par ' .. tostring(ctx.actor and ctx.actor.name or 'staff'), '')
    ctx.audit('serveur', 'bank.adjust', pl.license, nil, { mode = mode, amount = a })
    ctx.toast = 'Solde ajusté.'
    return true
end, { critical = true, confirm = { title = 'Ajuster ce solde ?', text = "L'opération est tracée à ton nom dans l'audit et dans l'historique du joueur." } })

local settings = Form.Cfg({ ns = 'bank', id = 'settings', title = 'Frais et plafonds', perm = 'bank.edit', cols = 2, fields = {
    { k = 'atm_props', type = 'toggle', label = 'Utiliser les distributeurs du décor (props)', default = true, wide = true, hint = 'Les distributeurs placés dans le jeu sont détectés par le client ; les retraits restent limités par les plafonds ci-dessous.' },
    { k = 'atm_models', type = 'text', label = 'Modèles de distributeurs (séparés par des virgules)', default = 'prop_atm_01,prop_atm_02,prop_atm_03,prop_fleeca_atm', maxlen = 200, pattern = '^[%w_,]+$', wide = true },
    { k = 'atm_fee', type = 'number', label = 'Frais de retrait au distributeur (%)', default = 2, min = 0, max = 50, int = false, step = 0.5 }, { k = 'atm_max_withdraw', type = 'number', label = 'Plafond par retrait (0 = aucun)', default = 5000, min = 0, max = 100000000 },
    { k = 'atm_daily_limit', type = 'number', label = 'Plafond journalier au distributeur (0 = aucun)', default = 20000, min = 0, max = 100000000 }, { k = 'branch_daily_limit', type = 'number', label = 'Plafond journalier en agence (0 = aucun)', default = 0, min = 0, max = 100000000 },
    { k = 'transfer_fee', type = 'number', label = 'Frais de virement (%)', default = 1, min = 0, max = 50, int = false, step = 0.5 }, { k = 'transfer_min', type = 'number', label = 'Virement minimal', default = 1, min = 1, max = 1000000 },
    { k = 'transfer_max', type = 'number', label = 'Virement maximal', default = 250000, min = 1, max = 1000000000 }, { k = 'use_distance', type = 'number', label = 'Distance pour utiliser un point (m)', default = 2.0, min = 1, max = 10, int = false, step = 0.5 },
    { k = 'blips', type = 'toggle', label = 'Afficher les agences sur la carte', default = true },
} })

PB.Module({
    id = 'bank', label = 'Banque', icon = 'coins', group = 'Serveur', order = 94, perm = 'bank.view', hint = 'Agences, distributeurs, virements, plafonds',
    caps = function()
        return PB.Capsify({
            { 'Agences avec dépôt, retrait, virement par IBAN', 'ok', "Proximité revérifiée à chaque opération ; virement possible vers un joueur hors ligne." },
            { 'Distributeurs du décor avec frais et plafonds', 'ok', 'Détectés par le client (props) : le serveur ne peut pas les vérifier, donc retraits plafonnés par retrait et par jour.' },
            { 'Historique et audit des ajustements du staff', 'ok', 'Tout crédit ou débit du panel est écrit à ton nom.' },
            { 'Cartes bancaires physiques, découvert, prêts', 'off', 'Non prévu.' },
            { 'Comptes partagés entre joueurs', 'off', "Les entreprises ont leur propre caisse (module Entreprises)." },
        })
    end,
    doc = "## Banque\nLes agences (blips + invite E) offrent dépôt, retrait et virement. Les **distributeurs** sont ceux du décor : les frais et plafonds s'appliquent.\n\n`exports.pb_panel:GetIban(source)` renvoie l'IBAN. Les intérêts sont réglés dans **Économie**.",
    view = function(ctx)
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                for _, b in ipairs(DB.q('SELECT id, kind, label, x, y FROM pb_bank_points ORDER BY label') or {}) do pts[#pts + 1] = { id = b.id, x = b.x, y = b.y, color = b.kind == 'atm' and '#f2c14e' or '#6fd3ff', label = b.label, sub = b.kind == 'atm' and 'distributeur' or 'agence' } end
                return { { type = 'map', id = 'bmap', title = 'Agences et distributeurs', points = pts, legend = { { color = '#6fd3ff', label = 'Agence' }, { color = '#f2c14e', label = 'Distributeur' } } } }
            end },
            { id = 'overview', label = "Vue d'ensemble", icon = 'chart', build = function()
                local tot = DB.one('SELECT COALESCE(SUM(bank), 0) AS s, COUNT(*) AS n FROM pb_players WHERE created = 1')
                local d = DB.one('SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_bank_tx WHERE at >= ?', { now() - 86400 })
                local wd = DB.one("SELECT COALESCE(SUM(amount), 0) AS s FROM pb_bank_tx WHERE kind = 'withdraw' AND via = 'atm' AND at >= ?", { now() - 86400 })
                local fees = G.Eco and G.Eco.Balance('state') or 0
                return { { type = 'cards', items = {
                    { title = 'Argent en banque', value = money(tot and tot.s or 0), icon = 'coins', tone = '#6fb4ff', sub = ('%d personnages'):format(tot and tot.n or 0) },
                    { title = 'Opérations (24 h)', value = tostring(d and d.n or 0), icon = 'activity', tone = '#dfe2e7', sub = money(d and d.s or 0) .. ' échangés' },
                    { title = 'Retraits distributeurs (24 h)', value = money(wd and wd.s or 0), icon = 'clock', tone = '#ffb457', sub = 'Plafond journalier par joueur : ' .. (cfg('atm_daily_limit', 20000) > 0 and money(cfg('atm_daily_limit', 20000)) or 'aucun') },
                    { title = "Compte « État »", value = money(fees), icon = 'building', tone = '#7be0a4', sub = 'Taxes, frais et amendes' } } } }
            end },
            { id = 'points', label = 'Agences et distributeurs', icon = 'pin', build = function()
                local list = {}
                for _, pt in ipairs(Bk.Points()) do list[#list + 1] = { label = pt.label, id = pt.id, kind = pt.kind == 'atm' and 'Distributeur' or 'Agence', on = PB.ToBool(pt.enabled) and { text = 'Actif', tone = 'ok' } or { text = 'Inactif', tone = 'off' }, pos = ('%.0f, %.0f'):format(pt.x, pt.y),
                    actions = ctx.has('bank.edit') and { { action = 'bank.point.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = pt.id } } } or {} } end
                local blocks = { B.table({ id = 'pt', title = 'Points (' .. #list .. ')', columns = { { k = 'label', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'kind', label = 'Type' }, { k = 'on', label = 'État', type = 'badge' }, { k = 'pos', label = 'Position' } }, rows = list }),
                    B.notice('info', 'Coordonnées par défaut : des agences connues de Los Santos. Vérifie-les en jeu et corrige-les au besoin.') }
                if ctx.has('bank.edit') then blocks[#blocks + 1] = { type = 'form', id = 'bank.pt', title = 'Ajouter ou modifier un point', desc = 'Même identifiant = modification.', cols = 2, fields = {
                    { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'kind', type = 'select', label = 'Type', opts = { { 'branch', 'Agence' }, { 'atm', 'Distributeur' } } },
                    { k = 'enabled', type = 'toggle', label = 'Actif' }, { k = 'coords', type = 'coords', label = 'Position', wide = true } },
                    values = { id = '', label = '', kind = 'branch', enabled = true, coords = { x = 0, y = 0, z = 0, h = 0 } }, submit = { action = 'bank.point.save', label = 'Enregistrer' } } end
                return blocks
            end },
            { id = 'accounts', label = 'Comptes', icon = 'users', build = function()
                local rows, opts = {}, {}
                for id, pl in pairs(G.Players()) do
                    if PB.ToBool(pl.row.created) then rows[#rows + 1] = { name = display(id) .. ' (' .. id .. ')', iban = Bk.Iban(pl.license), bank = pl.row.bank, cash = pl.row.cash } opts[#opts + 1] = { tostring(id), display(id) .. ' (' .. id .. ')' } end
                end
                local blocks = { B.table({ id = 'ac', title = 'Joueurs en ligne', columns = { { k = 'name', label = 'Joueur' }, { k = 'iban', label = 'IBAN', type = 'mono' }, { k = 'bank', label = 'Banque', type = 'num' }, { k = 'cash', label = 'Espèces', type = 'num' } }, rows = rows, empty = 'Personne en ligne.' }) }
                if ctx.has('bank.adjust') then blocks[#blocks + 1] = { type = 'form', id = 'bank.adj', title = "Ajuster un solde", desc = "Tracé dans l'audit et dans l'historique du joueur.", cols = 3, fields = {
                    { k = 'player', type = 'select', label = 'Joueur', opts = opts }, { k = 'mode', type = 'select', label = 'Opération', opts = { { 'add', 'Créditer' }, { 'remove', 'Débiter' } } }, { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 100000000 } },
                    values = { player = opts[1] and opts[1][1] or '', mode = 'add', amount = 1000 }, submit = { action = 'bank.adjust', label = 'Appliquer', disabled = #opts == 0 } } end
                return blocks
            end },
            { id = 'ledger', label = 'Transactions', icon = 'file', perm = 'bank.ledger', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT t.*, p.firstname, p.lastname FROM pb_bank_tx t LEFT JOIN pb_players p ON p.license = t.license ORDER BY t.id DESC LIMIT 200') or {}) do
                    rows[#rows + 1] = { at = r.at, who = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''), kind = KIND[r.kind] or r.kind, amount = r.amount, via = r.via, note = r.note ~= '' and r.note or r.other }
                end
                return { B.table({ id = 'tx', title = '200 dernières transactions', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'who', label = 'Joueur' }, { k = 'kind', label = 'Opération' }, { k = 'amount', label = 'Montant', type = 'num' }, { k = 'via', label = 'Canal' }, { k = 'note', label = 'Détail' } }, rows = rows, empty = 'Aucune transaction.' }) }
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'bank', title = 'Agence vue par le joueur', cfg = {} } } end },
            { id = 'settings', label = 'Frais et plafonds', icon = 'sliders', perm = 'bank.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('banque', function(R)
    local n = 0
    for _, pt in ipairs(Bk.Points()) do
        n = n + 1
        R.check(pt.x ~= 0 or pt.y ~= 0, 'point ' .. pt.id, 'position non définie')
    end
    R.check(n > 0, 'agences', "aucun point : les joueurs ne pourront pas utiliser la banque (les distributeurs du décor restent possibles)", nil)
    R.check(cfg('transfer_min', 1) <= cfg('transfer_max', 250000), 'virements', 'minimum supérieur au maximum')
    for _, a in ipairs(DB.q('SELECT iban FROM pb_bank_accounts') or {}) do R.check(a.iban:match('^PB%d%d%d%d%d%d%d%d$') ~= nil, 'IBAN ' .. a.iban, 'format invalide') end
end)
