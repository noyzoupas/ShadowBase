-- Fréquences radio réservées : des plages de canaux sont réservées à un métier (police, secours, mécanos…). Les autres joueurs ne peuvent
-- pas les rejoindre. Le contrôle passe par pma-voice (export addChannelCheck, côté serveur) : sans pma-voice, rien n'est appliqué et
-- le panel l'indique. Le staff en service peut passer outre (réglable). Tout le reste (canaux libres) reste ouvert à tous.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G = PB.G

P.Register('radio.edit', 'Régler les fréquences radio réservées', 'radio', true)
PB.Cfg.Define('radio', { enabled = false, ranges = {}, need_duty = true, staff_bypass = true, message = "Cette fréquence est réservée." })
local function cfg(k, d) return PB.Cfg.Get('radio', k, d) end
local R = {}
G.Radio = R

-- Une plage : « libellé|de|à|qui » ; « qui » = identifiants d'entreprise ou types (police, ems, garage…) séparés par des virgules.
function R.Ranges()
    local out = {}
    for _, line in ipairs(cfg('ranges', {}) or {}) do
        local label, a, b, who = tostring(line):match('^([^|]+)|(%d+)|(%d+)|([%w_,%-]+)$')
        a, b = tonumber(a), tonumber(b)
        if label and a and b and a <= b and b <= 99999 then
            local set = {}
            for w in who:gmatch('[^,]+') do set[w] = true end
            out[#out + 1] = { label = label, from = a, to = b, who = set, whoText = who }
        end
    end
    return out
end
function R.ReservedFor(channel)
    channel = math.floor(tonumber(channel) or 0)
    for _, r in ipairs(R.Ranges()) do if channel >= r.from and channel <= r.to then return r end end
end
-- true si `src` peut rejoindre ce canal
function R.Allowed(src, channel)
    if cfg('enabled', false) ~= true then return true end
    local r = R.ReservedFor(channel)
    if not r then return true end
    if cfg('staff_bypass', true) and G.Staff and G.Staff.OnDuty and G.Staff.OnDuty(src) then return true end
    local c = G.Biz and G.Biz.Ctx and G.Biz.Ctx(src)
    if not c then return false end
    if cfg('need_duty', true) and not c.duty then return false end
    return (r.who[c.biz.id] or r.who[c.biz.kind or ''] or false) == true
end

-- Branchement sur pma-voice
local checked = {}      -- canaux déjà enregistrés
function R.Hook()
    if GetResourceState and GetResourceState('pma-voice') ~= 'started' then return false, 'pma-voice absent' end
    local ok = pcall(function()
        local api = exports['pma-voice']
        for _, r in ipairs(R.Ranges()) do
            for ch = r.from, math.min(r.to, r.from + 999) do
                if not checked[ch] then
                    checked[ch] = true
                    api:addChannelCheck(ch, function(source) return R.Allowed(source, ch) end)
                end
            end
        end
    end)
    return ok, ok and nil or 'pma-voice ne propose pas addChannelCheck (mets-le à jour)'
end
R.hooked = nil
function R.Status()
    if cfg('enabled', false) ~= true then return 'off', 'Désactivé.' end
    if not (GetResourceState and GetResourceState('pma-voice') == 'started') then return 'off', 'pma-voice ne tourne pas : aucune fréquence n\'est protégée.' end
    local ok, why = R.Hook()
    if not ok then return 'partial', why end
    return 'ok', 'Les plages réservées sont contrôlées par pma-voice.'
end
exports('CanUseRadio', function(src, channel) return R.Allowed(tonumber(src), channel) end)

PB.OnReady(function() CreateThread(function() Wait(2000) pcall(R.Hook) end) end)
AddEventHandler('onResourceStart', function(res) if res == 'pma-voice' then SetTimeout(1500, function() pcall(R.Hook) end) end end)
PB.Cfg.OnChange('radio', function() pcall(R.Hook) end)

local form = Form.Cfg({ ns = 'radio', id = 'ranges', title = 'Fréquences réservées', perm = 'radio.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Fréquences réservées actives', default = false, hint = 'Nécessite pma-voice. Désactivé : toutes les fréquences restent libres.' },
    { k = 'need_duty', type = 'toggle', label = 'Exiger d\'être en service', default = true },
    { k = 'staff_bypass', type = 'toggle', label = 'Le staff en service peut tout rejoindre', default = true },
    { k = 'ranges', type = 'list', label = 'Plages réservées : libellé|de|à|qui (ex. Police|1|10|police)', default = {}, maxitems = 30, maxlen = 90, pattern = '^[^|]+|%d+|%d+|[%w_,%-]+$', wide = true,
      hint = "« qui » : identifiants d'entreprise ou types (police, ems, garage), séparés par des virgules. Exemples : Police|1|10|police · Secours|11|20|ems · Mécanos|21|30|garage,bennys." },
} })

PB.Module({
    id = 'radio', label = 'Radio', icon = 'mic', group = 'Serveur', order = 80, perm = 'radio.edit', hint = 'Fréquences réservées aux métiers',
    caps = function()
        local st, why = R.Status()
        return PB.Capsify({
            { 'Plages réservées par métier', st, why },
            { 'Canaux libres pour tout le monde', 'ok', 'Les canaux hors plages restent ouverts à tous.' },
            { 'Prise en charge de pma-voice', GetResourceState and GetResourceState('pma-voice') == 'started' and 'partial' or 'off', "Utilise l'export serveur addChannelCheck de pma-voice. Non testé sur ton serveur : vérifie en rejoignant une fréquence réservée sans le métier." },
            { 'Autres systèmes radio (saltychat, tokovoip…)', 'off', "Non pris en charge : seul pma-voice est branché." },
        })
    end,
    doc = "## Radio\nRéserve des **plages de fréquences** à des métiers : par exemple `Police|1|10|police` rend les canaux 1 à 10 accessibles aux seuls policiers en service. Les autres joueurs sont refusés par pma-voice. Les canaux hors plages restent libres.\n\n### Pour développeurs\n`exports.pb_panel:CanUseRadio(source, canal)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'ranges', label = 'Fréquences', icon = 'mic', build = function()
                local rows = {}
                for _, r in ipairs(R.Ranges()) do rows[#rows + 1] = { label = r.label, range = r.from .. ' – ' .. r.to, who = r.whoText } end
                return { form(ctx), B.table({ id = 'rr', title = 'Plages actives', columns = { { k = 'label', label = 'Nom' }, { k = 'range', label = 'Canaux' }, { k = 'who', label = 'Réservé à' } }, rows = rows, empty = 'Aucune plage réservée.' }) }
            end },
        } }
    end,
})

PB.SelfTest.Add('radio', function(R_)
    for _, line in ipairs(cfg('ranges', {}) or {}) do R_.check(tostring(line):match('^([^|]+)|(%d+)|(%d+)|([%w_,%-]+)$') ~= nil, 'plage radio « ' .. tostring(line) .. ' »', 'format libellé|de|à|qui') end
end)
