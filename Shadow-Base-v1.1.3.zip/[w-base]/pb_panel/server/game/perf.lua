-- Performances base de données : index sur les recherches fréquentes des tables qui grossissent avec le serveur
-- (véhicules par propriétaire à chaque ouverture de garage, appels et signalements par joueur, XP par gang…).
-- Chargé après les modules qui créent ces tables. Un index déjà présent est ignoré sans bloquer les suivants.

local DB = PB.DB

local INDEXES = {
    { 'pb_vehicles', 'k_veh_license', 'license' },
    { 'pb_vehicles', 'k_veh_gang', 'gang' },
    { 'pb_properties', 'k_prop_owner', 'owner' },
    { 'pb_calls', 'k_calls_license', 'license' },
    { 'pb_reports', 'k_reports_license', 'license' },
    { 'pb_orga_xp', 'k_orgaxp_gang', 'gang' },
}

PB.Migrate('301_perf_indexes', 'Performances : index des recherches fréquentes', function()
    for _, ix in ipairs(INDEXES) do
        local _, err = DB.exec(('CREATE INDEX %s ON %s (%s)'):format(ix[2], ix[1], ix[3]))
        if err and not tostring(err):lower():find('duplicate') and not tostring(err):lower():find('already exists') then
            print(('^3[Shadow Base]^7 index %s non créé : %s'):format(ix[2], tostring(err)))
        end
    end
end)
