-- Vestiaire d'entreprise / de gang : tenues enregistrées par le patron (ou le staff), choisies par les membres selon leur grade.
-- « Tenue civile » remet les vêtements du personnage. Le point se pose au Builder (Vestiaire). Le serveur vérifie l'appartenance et le grade.

local G, DB, P = PB.G, PB.DB, PB.Perm
local Wd = {}
G.Wardrobe = Wd

PB.Migrate('210_outfits', "Vestiaires : tenues d'entreprise et de gang", {
    [[CREATE TABLE IF NOT EXISTS pb_outfits (
        id INT NOT NULL AUTO_INCREMENT, owner_kind VARCHAR(8) NOT NULL, owner VARCHAR(48) NOT NULL, label VARCHAR(40) NOT NULL, min_grade INT NOT NULL DEFAULT 0,
        sex VARCHAR(1) NOT NULL DEFAULT '', data TEXT NOT NULL, created_by VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_owner (owner_kind, owner))]],
})

-- Appartenance au groupe du vestiaire : { grade, manager } ou nil
local function membership(src, kind, owner)
    if kind == 'biz' then
        local c = G.Biz and G.Biz.Ctx(src)
        if not c or c.biz.id ~= owner then return nil end
        return { grade = tonumber(c.grade.grade) or 0, manager = c.boss == true }
    elseif kind == 'gang' then
        local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
        if not g or g.id ~= owner then return nil end
        local boss = G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, g.id)
        return { grade = 0, manager = boss == true }
    end
end
local function isStaff(src) return P.Has(src, 'carte.place') and true or false end

local function nearPoint(src, p)
    local c = GetEntityCoords(GetPlayerPed(src))
    return c and #(c - vector3(p.x, p.y, p.z)) <= (tonumber(p.radius) or 2) + 4.0
end
local function pointOf(id) local p = DB.one('SELECT * FROM pb_points WHERE id = ?', { tonumber(id) or -1 }) return p and p.kind == 'wardrobe' and p or nil end
local function sexOf(src) local pl = G.Get(src) return pl and (pl.row.sex == 'f' and 'f' or 'm') or 'm' end

-- Ouverture (appelée par le point « vestiaire »)
function Wd.Open(src, p)
    local m = membership(src, p.owner_kind, p.owner)
    local staff = isStaff(src)
    if not m and not staff then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Réservé aux membres.' }) return end
    local sex, list = sexOf(src), {}
    for _, o in ipairs(DB.q('SELECT id, label, min_grade, sex FROM pb_outfits WHERE owner_kind = ? AND owner = ? ORDER BY min_grade, label', { p.owner_kind, p.owner }) or {}) do
        if o.sex == '' or o.sex == sex then
            list[#list + 1] = { id = o.id, label = o.label, min = tonumber(o.min_grade) or 0, ok = staff or (m and m.grade >= (tonumber(o.min_grade) or 0)) or false }
        end
    end
    TriggerClientEvent('pb:g:wardrobe:open', src, PB.Json({ point = p.id, title = p.label ~= '' and p.label or 'Vestiaire', outfits = list, manage = (m and m.manager) or staff, sex = sex }))
end

local last = {}
local function throttle(src) local t = GetGameTimer() if last[src] and t - last[src] < 700 then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

RegisterNetEvent('pb:g:wardrobe:wear', function(pointId, outfitId)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local o = DB.one('SELECT * FROM pb_outfits WHERE id = ? AND owner_kind = ? AND owner = ?', { tonumber(outfitId) or -1, p.owner_kind, p.owner })
    if not o then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not isStaff(src) and not (m and m.grade >= (tonumber(o.min_grade) or 0)) then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Ton grade ne permet pas cette tenue.' }) return end
    TriggerClientEvent('pb:g:wardrobe:apply', src, o.data, o.label)
end)

-- Enregistrer la tenue portée (patron du groupe ou staff). data = { comps = { {c, d, t} }, props = { {id, d, t} } } lu sur le personnage.
RegisterNetEvent('pb:g:wardrobe:save', function(pointId, label, minGrade, data)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not ((m and m.manager) or isStaff(src)) then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Seul le patron peut enregistrer une tenue.' }) return end
    label = PB.Trim(PB.Sanitize(tostring(label or ''), 40))
    if #label < 2 then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Donne un nom à la tenue.' }) return end
    local d = PB.FromJson(type(data) == 'string' and data or '', nil)
    if type(d) ~= 'table' or type(d.comps) ~= 'table' then return end
    -- on ne garde que des nombres entiers raisonnables (rien d'autre n'est réappliqué)
    local clean = { comps = {}, props = {} }
    for _, c in ipairs(d.comps) do
        local ci, di, ti = math.floor(tonumber(c[1]) or -1), math.floor(tonumber(c[2]) or -1), math.floor(tonumber(c[3]) or 0)
        if ci >= 1 and ci <= 11 and ci ~= 2 and di >= 0 and di < 1000 and ti >= 0 and ti < 100 then clean.comps[#clean.comps + 1] = { ci, di, ti } end
    end
    for _, c in ipairs(type(d.props) == 'table' and d.props or {}) do
        local id, di, ti = math.floor(tonumber(c[1]) or -1), math.floor(tonumber(c[2]) or -2), math.floor(tonumber(c[3]) or 0)
        if (id == 0 or id == 1 or id == 2 or id == 6 or id == 7) and di >= -1 and di < 1000 and ti >= 0 and ti < 100 then clean.props[#clean.props + 1] = { id, di, ti } end
    end
    if #clean.comps == 0 then return end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_outfits WHERE owner_kind = ? AND owner = ?', { p.owner_kind, p.owner })
    if n and tonumber(n.n) >= 40 then G.Notify(src, { type = 'error', title = 'Vestiaire', text = '40 tenues au maximum : supprimes-en une.' }) return end
    DB.insert('INSERT INTO pb_outfits (owner_kind, owner, label, min_grade, sex, data, created_by, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        { p.owner_kind, p.owner, label, math.max(0, math.min(50, math.floor(tonumber(minGrade) or 0))), sexOf(src), PB.Json(clean), PB.Actor(src).name:sub(1, 64), os.time() })
    PB.Audit.Log('config', 'vestiaire.tenue', src, p.owner_kind .. ':' .. p.owner, nil, { tenue = label, grade = minGrade })
    G.Notify(src, { type = 'success', title = 'Vestiaire', text = ('Tenue « %s » enregistrée (%s).'):format(label, sexOf(src) == 'f' and 'femmes' or 'hommes') })
    Wd.Open(src, p)
end)

RegisterNetEvent('pb:g:wardrobe:del', function(pointId, outfitId)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not ((m and m.manager) or isStaff(src)) then return end
    DB.exec('DELETE FROM pb_outfits WHERE id = ? AND owner_kind = ? AND owner = ?', { tonumber(outfitId) or -1, p.owner_kind, p.owner })
    G.Notify(src, { type = 'success', title = 'Vestiaire', text = 'Tenue supprimée.' })
    Wd.Open(src, p)
end)
