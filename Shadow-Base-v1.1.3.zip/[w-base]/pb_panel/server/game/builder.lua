-- Builder du menu staff (F10 › Builder) : tout créer et placer en jeu, à pied, avec E.
-- Groupes illégaux (gang, organisation, cartel, MC), entreprises du catalogue, drogues prêtes à l'emploi, magasins, location, banques,
-- garages, coffres, braquages, blanchiment, points de vente / drapeaux, points des autres ressources (ex. Burger Shot)…
-- Tout passe par la Carte (PB.Place) : la position est toujours lue côté serveur sur le joueur au moment où il appuie sur E.

local P = PB.Perm
local G, DB = PB.G, PB.DB
local S = G.Staff
local Place = PB.Place

-- Types de groupes illégaux : même fonctionnement (membres, grades, QG, coffre, garage, drapeaux), nom et couleur par défaut différents
local GROUP_TYPES = {
    { id = 'gang', label = 'Gang', color = '#e74c3c' },
    { id = 'orga', label = 'Organisation', color = '#9b59b6' },
    { id = 'cartel', label = 'Cartel', color = '#f39c12' },
    { id = 'mc', label = 'MC (club de motards)', color = '#7f8c8d' },
}
local GT = {}
for _, t in ipairs(GROUP_TYPES) do GT[t.id] = t end

local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):sub(1, n)) end

-- Ce que le menu affiche (seulement pour qui peut placer des points)
table.insert(S.SpecExtra, function(src, spec)
    if not P.Has(src, 'carte.place') then return end
    local groups = {}
    for _, t in ipairs(Place.Types()) do
        groups[t.group] = groups[t.group] or {}
        local g = groups[t.group]
        g[#g + 1] = { id = t.id, label = t.label, needs = t.needs, presets = t.presets }
    end
    local cats = {}
    for _, c in ipairs(G.BizCat and G.BizCat.Cats or {}) do cats[#cats + 1] = { id = c.id, label = c.label, items = {} } end
    local catBy = {}
    for _, c in ipairs(cats) do catBy[c.id] = c end
    for _, t in ipairs(G.BizCat and G.BizCat.List or {}) do
        local c = catBy[t.cat]
        if c and G.BizCat.Visible(t) then c.items[#c.items + 1] = { key = t.key, label = t.label, made = G.Biz.Get(t.key) ~= nil } end
    end
    local gangs = {}
    for gid, d in pairs(G.Tags.GangDefs()) do gangs[#gangs + 1] = { gid, d.label, d.type or 'gang' } end
    table.sort(gangs, function(a, b) return a[2] < b[2] end)
    local bizs = {}
    for _, b in ipairs(G.Biz.List()) do bizs[#bizs + 1] = { b.id, b.label } end
    local drugs = {}
    for _, k in ipairs(G.Crime.DRUG_ORDER) do local d = G.Crime.DRUGS[k] drugs[#drugs + 1] = { k, d.label, d.raw[2], d.pouch[2], d.price } end
    local ext = {}
    -- une ressource qui porte le nom d'une entreprise du catalogue (ex. burgershot) est rangée avec cette entreprise, pas dans « Ressources »
    for _, e in pairs(Place.ext or {}) do if not (G.BizCat and G.BizCat.ByKey and G.BizCat.ByKey[e.id]) then ext[#ext + 1] = e end end
    table.sort(ext, function(a, b) return a.label < b.label end)
    spec.builder = { groups = groups, gtypes = GROUP_TYPES, packs = G.Orgs and G.Orgs.Packs and G.Orgs.Packs() or nil, cats = cats, gangs = gangs, bizs = bizs, drugs = drugs, ext = ext, canDelete = P.Has(src, 'carte.delete') or nil }
end)

local function staffName(src) local p = G.Get(src) return p and p.license or ('#' .. tostring(src)) end

-- Poser un point de n'importe quel type : E pour placer, Retour arrière pour annuler
S.Def('b_place', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local ok, err = Place.Arm(src, tostring(p.type or ''), clean(p.name, 48), tostring(p.owner or ''), clean(p.preset, 48))
    if not ok then return false, err end
    return true, 'Va à l\'endroit voulu puis appuie sur E (Retour arrière : annuler).'
end })

-- Liste des points d'une cible ----------------------------------------------------------------------------------------------------------------
-- Cible = un groupe (gang), une entreprise (biz), une drogue (drug) ou une autre ressource (ext). Chaque point est « défini » (position connue)
-- ou non ; Entrée sur place le pose ou le DÉPLACE (jamais de doublon : un coffre déplacé garde son contenu, un garage ses véhicules).
local function f(v) return (tonumber(v) or 0) + 0.0 end
local function cfgList(ns, key) local out = {} for _, r in ipairs(PB.Cfg.Get(ns, key, {}) or {}) do out[#out + 1] = r end return out end

local function stepsOf(kind, owner)
    if kind == 'gang' or kind == 'biz' then
        local out = {}
        for _, st in ipairs(Place.PackSteps(kind, owner)) do out[#out + 1] = { key = st.type .. '|' .. st.name, type = st.type, name = st.name, hint = st.hint } end
        -- points de la ressource du même nom (ex. Burger Shot : bornes, postes de cuisine, comptoir, adresses de livraison)
        local e = kind == 'biz' and Place.ext and Place.ext[owner]
        for _, pt in ipairs(e and e.points or {}) do out[#out + 1] = { key = pt.id, type = pt.id, name = pt.label, ask = pt.ask, add = pt.multi or nil, ext = owner, pid = pt.pid, hint = pt.multi and ('Ajouté à ta position (géré par la ressource « ' .. e.res .. ' »).') or 'Un seul point : Entrée le place ou le déplace ici.' } end
        return out
    elseif kind == 'drug' then
        local d = G.Crime.DRUGS[owner]
        if not d then return {} end
        return { { key = 'drug_harvest', type = 'drug_harvest', name = 'Récolte', hint = 'Zone où l\'on ramasse ' .. d.raw[2]:lower() .. ' (2 s, penché).' },
            { key = 'drug_process', type = 'drug_process', name = 'Laboratoire', hint = '2 × ' .. d.raw[2]:lower() .. ' → 1 × ' .. d.pouch[2]:lower() .. '.' },
            { key = 'drug_sell', type = 'drug_sell', name = 'Vente et drapeau', hint = '3 pochons max par passage ; brut x0,4 ; drapeau x1,7.' } }
    elseif kind == 'ext' then
        local e = Place.ext and Place.ext[owner]
        local out = {}
        for _, pt in ipairs(e and e.points or {}) do out[#out + 1] = { key = pt.id, type = pt.id, name = pt.label, ask = pt.ask, add = pt.multi or nil, ext = owner, pid = pt.pid, hint = pt.multi and 'Ajoute un point à ta position (la ressource gère la liste).' or 'Un seul point : Entrée le place ou le déplace ici.' } end
        return out
    end
    return {}
end

local function garageOf(gk, owner) return DB.one('SELECT * FROM pb_garages WHERE kind = ? AND biz = ? ORDER BY id LIMIT 1', { gk, owner }) end
local PT_KIND = { gang_hq = { 'gang', 'hq' }, gang_boss = { 'gang', 'boss' }, gang_stash = { 'gang', 'stash' }, biz_hq = { 'biz', 'hq' }, biz_duty = { 'biz', 'duty' }, biz_boss = { 'biz', 'boss' },
    biz_desk = { 'biz', 'desk' }, biz_workshop = { 'biz', 'workshop' }, biz_kitchen = { 'biz', 'kitchen' }, biz_wardrobe = { 'biz', 'wardrobe' }, gang_wardrobe = { 'gang', 'wardrobe' } }

-- Où est le point (nil = aucune position) : { x, y, z, ref }
local function locate(kind, owner, st)
    local t = st.type
    local pk = PT_KIND[t]
    if pk then
        local r = DB.one('SELECT id, x, y, z FROM pb_points WHERE owner_kind = ? AND owner = ? AND kind = ? ORDER BY id LIMIT 1', { pk[1], owner, pk[2] })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t == 'biz_stash' then
        local r = DB.one('SELECT id, x, y, z FROM pb_inv_stashes WHERE biz = ? AND label = ? ORDER BY id LIMIT 1', { owner, st.name })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t == 'biz_garage' or t == 'gang_garage' then
        local g = garageOf(t == 'biz_garage' and 'biz' or 'gang', owner)
        return g and { x = g.x, y = g.y, z = g.z, ref = g.id } or nil
    elseif t == 'biz_garage_out' or t == 'gang_garage_out' then
        local g = garageOf(t == 'biz_garage_out' and 'biz' or 'gang', owner)
        return g and g.sx and { x = g.sx, y = g.sy, z = g.sz, ref = g.id } or nil
    elseif t == 'biz_wardrobe' then
        local r = DB.one("SELECT id, x, y, z FROM pb_shops WHERE kind = 'clothes' AND opts LIKE ? ORDER BY id LIMIT 1", { '%"biz_owner":"' .. owner .. '"%' })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t == 'biz_shop' then
        local r = DB.one("SELECT id, x, y, z FROM pb_shops WHERE kind = 'store' AND opts LIKE ? ORDER BY id LIMIT 1", { '%"biz_counter":"' .. owner .. '"%' })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t:sub(1, 5) == 'drug_' then
        local k = t:sub(6)
        for _, r in ipairs(PB.Cfg.Get('crime', 'chain', {}) or {}) do if r.drug == owner and r.kind == k then return { x = r.x, y = r.y, z = r.z, ref = r.id } end end
    end
    return nil
end

-- Déplace un point existant à la position du joueur
local function move(kind, owner, st, at, pos)
    local t = st.type
    if PT_KIND[t] then
        DB.exec('UPDATE pb_points SET x = ?, y = ?, z = ?, h = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
        if t == 'biz_hq' then DB.exec('UPDATE pb_biz SET hx = ?, hy = ?, hz = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), owner }) end
        G.Points.PushAll()
    elseif t == 'biz_stash' then DB.exec('UPDATE pb_inv_stashes SET x = ?, y = ?, z = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), at.ref })
    elseif t == 'biz_garage' or t == 'gang_garage' then DB.exec('UPDATE pb_garages SET x = ?, y = ?, z = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), at.ref })
    elseif t == 'biz_garage_out' or t == 'gang_garage_out' then DB.exec('UPDATE pb_garages SET sx = ?, sy = ?, sz = ?, sh = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
    elseif t == 'biz_wardrobe' or t == 'biz_shop' then DB.exec('UPDATE pb_shops SET x = ?, y = ?, z = ?, h = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
    elseif t:sub(1, 5) == 'drug_' then
        local list = cfgList('crime', 'chain')
        for _, r in ipairs(list) do if r.id == at.ref then r.x, r.y, r.z = f(pos.x), f(pos.y), f(pos.z) end end
        PB.Cfg.Set('crime', 'chain', list, 0, 'Builder : déplacement')
    else return false end
    G.PushConfig()
    return true
end

-- Supprime un point posé (et son blip). Les véhicules rangés dans un garage supprimé se sortent ensuite dans n'importe quel garage public.
local function remove(kind, owner, st, at)
    local t = st.type
    if PT_KIND[t] then G.Points.Remove(at.ref) G.Points.PushAll()
        if t == 'biz_hq' then DB.exec('UPDATE pb_biz SET hx = 0, hy = 0, hz = 0 WHERE id = ?', { owner }) end
    elseif t == 'biz_stash' then DB.exec('DELETE FROM pb_inv_stashes WHERE id = ?', { at.ref }) DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. tostring(at.ref) })
    elseif t == 'biz_garage' or t == 'gang_garage' then DB.exec('DELETE FROM pb_garages WHERE id = ?', { at.ref })
    elseif t == 'biz_garage_out' or t == 'gang_garage_out' then DB.exec('UPDATE pb_garages SET sx = 0, sy = 0, sz = 0, sh = 0 WHERE id = ?', { at.ref })
    elseif t == 'biz_wardrobe' or t == 'biz_shop' then DB.exec('DELETE FROM pb_shops WHERE id = ?', { at.ref }) DB.exec('DELETE FROM pb_shop_stock WHERE shop = ?', { at.ref })
    elseif t:sub(1, 5) == 'drug_' then
        local list, out = cfgList('crime', 'chain'), {}
        for _, r in ipairs(list) do if r.id ~= at.ref then out[#out + 1] = r end end
        PB.Cfg.Set('crime', 'chain', out, 0, 'Builder : suppression')
    else return false end
    G.PushConfig()
    return true
end

local function targetLabel(kind, owner)
    if kind == 'gang' then local d = G.Tags.GangDefs()[owner] return d and d.label, d and (GT[d.type or 'gang'] or GT.gang).label or 'Groupe' end
    if kind == 'biz' then local b = G.Biz.Get(owner) return b and b.label, 'Entreprise' end
    if kind == 'drug' then local d = G.Crime.DRUGS[owner] return d and d.label, 'Drogue' end
    if kind == 'ext' then local e = Place.ext and Place.ext[owner] return e and e.label, 'Ressource' end
end

-- TOUS les points d'une entreprise / d'un gang, quel que soit leur format (y compris ceux posés par d'anciennes versions) :
-- points (pb_points, toutes sortes), coffres, garages, vestiaires et boutiques. Chacun a une clé « table:id » pour le supprimer.
local KIND_FR = { hq = 'Siège / QG', duty = 'Prise de service', boss = 'Bureau du patron', stash = 'Coffre', wardrobe = 'Vestiaire', garage = 'Garage',
    desk = 'Accueil', workshop = 'Atelier', kitchen = 'Cuisine / bar' }
local function extList(id, src)
    local e = Place.ext and Place.ext[id]
    if not e or not e.cb or not e.listable then return {} end
    local ok, list = pcall(e.cb, src or 0, '__list', '')
    return (ok and type(list) == 'table') and list or {}
end
local function allPoints(kind, owner, src)
    local out = {}
    if (kind == 'biz' or kind == 'ext') and Place.ext and Place.ext[owner] then
        for _, p in ipairs(extList(owner, src)) do
            if type(p) == 'table' and p.key then out[#out + 1] = { key = 'ex:' .. tostring(p.key), label = Place.ext[owner].label .. ' — ' .. tostring(p.label or p.key), x = tonumber(p.x), y = tonumber(p.y), z = tonumber(p.z) } end
        end
    end
    if kind ~= 'biz' and kind ~= 'gang' then return out end
    for _, r in ipairs(DB.q('SELECT id, kind, label, x, y, z FROM pb_points WHERE owner_kind = ? AND owner = ? ORDER BY id', { kind, owner }) or {}) do
        out[#out + 1] = { key = 'pt:' .. r.id, label = (KIND_FR[r.kind] or r.kind) .. (r.label ~= '' and (' — ' .. r.label) or ''), x = r.x, y = r.y, z = r.z }
    end
    if kind == 'biz' then
        for _, r in ipairs(DB.q('SELECT id, label, x, y, z FROM pb_inv_stashes WHERE biz = ?', { owner }) or {}) do out[#out + 1] = { key = 'st:' .. r.id, label = 'Coffre — ' .. r.label, x = r.x, y = r.y, z = r.z } end
        for _, r in ipairs(DB.q("SELECT id, label, kind, x, y, z, opts FROM pb_shops WHERE opts LIKE ? OR opts LIKE ? OR opts LIKE ?", { '%"biz_owner":"' .. owner .. '"%', '%"biz_counter":"' .. owner .. '"%', '%"biz":"' .. owner .. '"%' }) or {}) do
            out[#out + 1] = { key = 'sh:' .. r.id, label = (r.kind == 'clothes' and 'Vestiaire — ' or 'Boutique — ') .. r.label, x = r.x, y = r.y, z = r.z }
        end
    end
    for _, r in ipairs(DB.q('SELECT id, label, x, y, z FROM pb_garages WHERE kind = ? AND biz = ?', { kind, owner }) or {}) do out[#out + 1] = { key = 'ga:' .. r.id, label = 'Garage — ' .. r.label, x = r.x, y = r.y, z = r.z } end
    return out
end
G.BuilderAllPoints = allPoints
-- supprime un élément de allPoints (vérifie qu'il appartient bien à cette cible)
local function removeRaw(kind, owner, key, src)
    local t, id = tostring(key):match('^(%a%a):(.+)$')
    if not t then return false end
    for _, p in ipairs(allPoints(kind, owner, src)) do
        if p.key == key then
            if t == 'ex' then
                local e = Place.ext and Place.ext[owner]
                local ok, r = pcall(e.cb, src or 0, '__delete', id)
                return ok and r ~= false
            elseif t == 'pt' then G.Points.Remove(tonumber(id))
            elseif t == 'st' then DB.exec('DELETE FROM pb_inv_stashes WHERE id = ?', { id }) DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. id })
            elseif t == 'sh' then DB.exec('DELETE FROM pb_shops WHERE id = ?', { tonumber(id) }) DB.exec('DELETE FROM pb_shop_stock WHERE shop = ?', { tonumber(id) })
            elseif t == 'ga' then DB.exec('DELETE FROM pb_garages WHERE id = ?', { id }) end
            if kind == 'biz' and t == 'pt' then DB.exec("UPDATE pb_biz SET hx = 0, hy = 0, hz = 0 WHERE id = ? AND NOT EXISTS (SELECT 1 FROM pb_points WHERE owner_kind = 'biz' AND owner = ? AND kind = 'hq')", { owner, owner }) end
            return true
        end
    end
    return false
end

-- Envoie la liste des points au client (le menu s'ouvre ou se met à jour)
local function sendPoints(src, kind, owner, sel)
    local label, what = targetLabel(kind, owner)
    if not label then return false, 'Introuvable.' end
    local list, n = {}, 0
    local ext = {}
    for _, p in ipairs((kind == 'biz' or kind == 'ext') and extList(owner, src) or {}) do if type(p) == 'table' and p.key then ext[tostring(p.key)] = p end end
    for _, st in ipairs(stepsOf(kind, owner)) do
        local at = not st.add and (st.ext and ext[tostring(st.pid)] or locate(kind, owner, st)) or nil
        if at then n = n + 1 end
        list[#list + 1] = { key = st.key, name = st.name, hint = st.hint, ask = st.ask, add = st.add or nil, raw = st.ext and ('ex:' .. tostring(st.pid)) or nil, x = at and tonumber(at.x), y = at and tonumber(at.y), z = at and tonumber(at.z) }
    end
    local all = allPoints(kind, owner, src)
    -- joueurs connectés (choix du patron / chef) et icône actuelle du siège
    local players = {}
    if kind == 'biz' or kind == 'gang' then
        for id in pairs(G.Players()) do
            local i = G.Identity(id)
            players[#players + 1] = { id = id, name = (i and i.created and (i.firstname or '') ~= '') and ((i.firstname .. ' ' .. (i.lastname or '')):sub(1, 40)) or (GetPlayerName(id) or ('Joueur ' .. id)) }
        end
        table.sort(players, function(a, b) return a.name < b.name end)
    end
    local hq = (kind == 'biz' or kind == 'gang') and DB.one("SELECT sprite, bcolor FROM pb_points WHERE owner_kind = ? AND owner = ? AND kind = 'hq' ORDER BY id LIMIT 1", { kind, owner }) or nil
    local cat = kind == 'biz' and G.BizCat and G.BizCat.ByKey and G.BizCat.ByKey[owner]
    local blip = hq and { tonumber(hq.sprite) or 0, tonumber(hq.bcolor) or 0 } or (kind == 'biz' and { cat and cat.blip and cat.blip[1] or 475, cat and cat.blip and cat.blip[2] or 3 }) or (kind == 'gang' and { 615, 1 }) or nil
    TriggerClientEvent('pb:g:builder:points', src, PB.Json({ kind = kind, owner = owner, label = label, what = what, steps = list, done = math.max(n, #all), sel = sel, all = all, players = players, blip = blip }))
    return true
end
local function canTarget(kind, owner) return targetLabel(kind, owner) ~= nil end

RegisterNetEvent('pb:g:builder:list', function(kind, owner)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    sendPoints(src, tostring(kind), tostring(owner))
end)

-- Entrée sur place : pose le point, ou le déplace s'il existe déjà
local lastSet = {}
RegisterNetEvent('pb:g:builder:set', function(kind, owner, key, extra)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    kind, owner, key = tostring(kind), tostring(owner), tostring(key)
    if not canTarget(kind, owner) then return end
    local st
    for i, s in ipairs(stepsOf(kind, owner)) do if s.key == key then st = s st.i = i end end
    if not st then return end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0) then G.Notify(src, { type = 'error', title = 'Builder', text = 'Position illisible.' }) return end
    local pos = { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped) or 0.0 }
    local at = not st.add and not st.ext and locate(kind, owner, st) or nil
    local ok, msg
    if at then
        ok = move(kind, owner, st, at, pos)
        msg = ok and (st.name .. ' déplacé ici.') or 'Déplacement impossible.'
    else
        local pt = Place.types[st.type]
        if not pt then return end
        local preset = ''
        if st.type == 'biz_garage_out' or st.type == 'gang_garage_out' then
            local g = garageOf(st.type == 'biz_garage_out' and 'biz' or 'gang', owner)
            if not g then G.Notify(src, { type = 'error', title = 'Builder', text = 'Pose d\'abord le garage (rangement).' }) sendPoints(src, kind, owner, st.i) return end
            preset = g.id
        elseif kind == 'drug' then preset = owner
        elseif kind == 'ext' or st.add or st.ext then preset = clean(extra, 40) end
        local name = kind == 'drug' and (st.name .. ' : ' .. (G.Crime.DRUGS[owner].label)) or st.name
        ok, msg = Place.CreateAt(src, pt, name, (kind == 'gang' or kind == 'biz') and owner or '', preset)
        if ok then msg = st.name .. ' placé ici.' end
    end
    PB.Audit.Log('config', ok and 'builder.set' or 'builder.fail', src, kind .. ':' .. owner, nil, { point = st.key, moved = at ~= nil })
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Builder', text = tostring(msg or '') })
    sendPoints(src, kind, owner, st.i)
end)
AddEventHandler('playerDropped', function() lastSet[source] = nil end)

-- Icône du siège / QG sur la carte (à la pose ou après) : numéro et couleur de blip GTA
RegisterNetEvent('pb:g:builder:blip', function(kind, owner, sprite, color)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    kind, owner = tostring(kind), tostring(owner)
    if (kind ~= 'biz' and kind ~= 'gang') or not canTarget(kind, owner) then return end
    sprite, color = math.floor(tonumber(sprite) or -1), math.floor(tonumber(color) or -1)
    if sprite < 0 or sprite > 900 or color < 0 or color > 85 then return end
    DB.exec("UPDATE pb_points SET sprite = ?, bcolor = ? WHERE owner_kind = ? AND owner = ? AND kind = 'hq'", { sprite, color, kind, owner })
    G.Points.PushAll()
    G.Notify(src, { type = 'success', title = 'Builder', text = sprite == 0 and 'Icône retirée de la carte.' or ('Icône %d (couleur %d) appliquée.'):format(sprite, color) })
    sendPoints(src, kind, owner)
end)

-- Patron de l'entreprise / chef du groupe : un joueur connecté, choisi à la fin de la pose des points
RegisterNetEvent('pb:g:builder:boss', function(kind, owner, target)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    kind, owner, target = tostring(kind), tostring(owner), tonumber(target)
    if not target or not G.Get(target) or not canTarget(kind, owner) then return end
    local ok, err
    if kind == 'biz' then
        local top
        for _, g in ipairs(G.Biz.Grades(owner)) do if PB.ToBool(g.boss) and (not top or g.grade > top) then top = g.grade end end
        if not top then for _, g in ipairs(G.Biz.Grades(owner)) do if not top or g.grade > top then top = g.grade end end end
        if not top then G.Notify(src, { type = 'error', title = 'Builder', text = "Cette entreprise n'a aucun grade." }) return end
        ok, err = G.Biz.SetJob(target, owner, top, 'Builder')
    elseif kind == 'gang' then
        ok, err = G.Tags.SetGang(target, owner)
        if ok ~= false and G.Flags and G.Flags.SetBoss then ok, err = G.Flags.SetBoss(owner, target) end
    else return end
    local name = (G.Identity(target) or {}).firstname or GetPlayerName(target) or ('#' .. target)
    PB.Audit.Log('config', 'builder.boss', src, kind .. ':' .. owner, nil, { joueur = name })
    G.Notify(src, { type = ok ~= false and 'success' or 'error', title = 'Builder', text = ok ~= false and (name .. (kind == 'biz' and ' est le patron.' or ' est le chef.')) or tostring(err or 'Impossible.') })
    if ok ~= false then G.Notify(target, { type = 'success', title = select(1, targetLabel(kind, owner)) or 'Builder', text = kind == 'biz' and 'Tu es nommé patron de cette entreprise.' or 'Tu es nommé chef de ce groupe.' }) end
    sendPoints(src, kind, owner)
end)

-- Supprimer un point (key) ou tous les points d'une cible (key = '*')
RegisterNetEvent('pb:g:builder:del', function(kind, owner, key)
    local src = source
    if not P.Has(src, 'carte.delete') and not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    kind, owner, key = tostring(kind), tostring(owner), tostring(key)
    if not canTarget(kind, owner) then return end
    if kind == 'ext' and not key:match('^ex:') then return end
    local n = 0
    if key:match('^%a%a:') then
        if removeRaw(kind, owner, key, src) then n = 1 end
        G.PushConfig() if G.Points and G.Points.PushAll then G.Points.PushAll() end
        PB.Audit.Log('config', 'builder.delete', src, kind .. ':' .. owner, nil, { point = key })
        G.Notify(src, { type = n > 0 and 'success' or 'warn', title = 'Builder', text = n > 0 and 'Point supprimé.' or 'Point introuvable.' })
        sendPoints(src, kind, owner)
        return
    end
    if key == '*' then
        for _, p in ipairs(allPoints(kind, owner, src)) do if removeRaw(kind, owner, p.key, src) then n = n + 1 end end
    end
    -- plusieurs passes : un même type peut avoir plusieurs points (ex. deux coffres), locate() renvoie le premier à chaque fois
    for _ = 1, 20 do
        local did = false
        for _, st in ipairs(stepsOf(kind, owner)) do
            if not st.add and (key == '*' or st.key == key) then
                local at = locate(kind, owner, st)
                if at and remove(kind, owner, st, at) then n = n + 1 did = true end
            end
        end
        if not did or key ~= '*' then break end
    end
    PB.Audit.Log('config', 'builder.delete', src, kind .. ':' .. owner, nil, { point = key, count = n })
    G.Notify(src, { type = n > 0 and 'success' or 'warn', title = 'Builder', text = n > 0 and (key == '*' and (n .. ' point(s) supprimé(s).') or 'Point supprimé.') or 'Rien à supprimer.' })
    sendPoints(src, kind, owner)
end)

-- Groupe illégal : créé, puis la liste de ses points s'ouvre
S.Def('b_group', 'carte.place', { noduty = true, run = function(src, _, p)
    local t = GT[tostring(p.gtype or '')] or GT.gang
    local label = clean(p.label, 24)
    if #label < 2 then return false, 'Donne un nom (2 caractères au moins).' end
    local color = tostring(p.color or ''):match('^#%x%x%x%x%x%x$') or t.color
    local id, msg = G.Orgs.Create({ label = label, color = color }, staffName(src))
    if not id then return false, msg end
    DB.exec("UPDATE pb_org_groups SET otype = ? WHERE kind = 'gang' AND name = ?", { t.id, id })
    if G.Tags.RefreshNative then G.Tags.RefreshNative() end
    if G.Tags.Push then pcall(G.Tags.Push, true) end
    local extra = ''
    local packN = math.floor(tonumber(p.pack) or 0)   -- 0 = aucun pack (le menu envoie toujours le choix)
    if packN >= 1 and packN <= 3 and PB.Cfg.Get('orgs', 'auto_starter', true) ~= false then
        local sum = G.Orgs.Starter(id, false, packN)
        if sum then extra = (' %s donné : %d objets au coffre, %s $ en caisse, %d véhicule(s) au garage.'):format(sum.pack, sum.items, tostring(sum.cash), #sum.cars) end
    end
    sendPoints(src, 'gang', id)
    return true, t.label .. ' « ' .. label .. ' » créé(e).' .. extra .. ' Pose ses points un par un.'
end })

-- Points d'une cible existante (groupe, entreprise, drogue, ressource)
S.Def('b_pack', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local kind = tostring(p.kind or '')
    local ok, e = sendPoints(src, kind == 'gang' and 'gang' or (kind == 'drug' and 'drug' or (kind == 'ext' and 'ext' or 'biz')), tostring(p.owner or ''))
    if not ok then return false, e end
    return true
end })

-- Entreprise du catalogue : créée si besoin (grades et métier prêts), puis la liste de ses points s'ouvre
S.Def('b_biz', 'carte.place', { noduty = true, run = function(src, _, p)
    local t = G.BizCat and G.BizCat.ByKey and G.BizCat.ByKey[tostring(p.key or '')]
    if not t then return false, 'Entreprise inconnue.' end
    local made = false
    if not G.Biz.Get(t.key) then
        local copy = {}
        for k, v in pairs(t) do copy[k] = v end
        copy.pos = nil   -- le siège sera posé en jeu
        local ok, e = G.BizCat.Create(copy, {})
        if not ok then return false, 'Création impossible : ' .. tostring(e) end
        made = true
    end
    sendPoints(src, 'biz', t.key)
    return true, made and ('« ' .. t.label .. ' » créée. Choisis ses points un par un.') or nil
end, quiet = true })

-- Drogue : objets créés, puis la liste récolte / labo / vente s'ouvre
S.Def('b_drug', 'carte.place', { noduty = true, run = function(src, _, p)
    local key = tostring(p.drug or '')
    local d = G.Crime.EnsureDrug(key)
    if not d then return false, 'Drogue inconnue.' end
    sendPoints(src, 'drug', key)
    return true, d.label .. ' : objets prêts. Choisis la récolte, le labo et la vente.'
end })

-- Supprimer le point le plus proche (tous types confondus, 8 m maximum)
S.Def('b_delete', 'carte.delete', { noduty = true, run = function(src, _, p)
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c then return false, 'Position illisible.' end
    local best, bd, bt
    for _, id in ipairs(Place.order) do
        local t = Place.types[id]
        if t.list and t.remove then
            for _, r in ipairs(t.list() or {}) do
                local x, y = tonumber(r.x), tonumber(r.y)
                if x and y then
                    local d = math.sqrt((c.x - x) ^ 2 + (c.y - y) ^ 2)
                    if d < 8.0 and (not bd or d < bd) then best, bd, bt = r, d, t end
                end
            end
        end
    end
    if not best then return false, 'Aucun point à moins de 8 m.' end
    if p.confirm ~= true then return false, ('Le plus proche : %s « %s » à %.1f m. Choisis « Confirmer la suppression ».'):format(bt.label, tostring(best.label), bd) end
    bt.remove(tostring(best.id))
    PB.Audit.Log('config', 'carte.delete', src, bt.id, nil, { id = best.id, label = best.label })
    return true, bt.label .. ' « ' .. tostring(best.label) .. ' » supprimé.'
end })

PB.SelfTest.Add('builder', function(R)
    R.check(S.ACT.b_place and S.ACT.b_group and S.ACT.b_biz and S.ACT.b_drug and S.ACT.b_pack and S.ACT.b_delete, 'builder', 'actions manquantes')
    R.check(#G.Crime.DRUG_ORDER == 5, 'builder', 'il faut 5 drogues prêtes')
end)
