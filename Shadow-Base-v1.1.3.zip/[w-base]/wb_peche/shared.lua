-- Shadow Base — Pêche : raretés, poissons, leurres, cannes.

FISH_RARITY = {
    { id = 'c',  label = 'Commun',      color = '#c9ced6', weight = 60,  diff = 1, hits = 1 },
    { id = 'pc', label = 'Peu commun',  color = '#7be0a4', weight = 25,  diff = 2, hits = 2 },
    { id = 'r',  label = 'Rare',        color = '#6fb4ff', weight = 10,  diff = 3, hits = 2 },
    { id = 'e',  label = 'Épique',      color = '#b58cff', weight = 4,   diff = 4, hits = 3 },
    { id = 'l',  label = 'Légendaire',  color = '#f2c14e', weight = 1,   diff = 5, hits = 4 },
}
FISH_RARITY_BY = {}
for i, r in ipairs(FISH_RARITY) do r.n = i FISH_RARITY_BY[r.id] = r end

-- Eaux : mer (côte), large (en bateau, loin des côtes), lac, riviere
-- price : prix de base au marché ; kg : poids min et max (affiché à la prise, sert aux records)
FISH = {
    { name = 'fish_sardine',    label = 'Sardine',               water = 'mer',     rarity = 'c',  price = 9,    kg = { 0.05, 0.2 } },
    { name = 'fish_maquereau',  label = 'Maquereau',             water = 'mer',     rarity = 'c',  price = 13,   kg = { 0.3, 1.2 } },
    { name = 'fish_dorade',     label = 'Dorade royale',         water = 'mer',     rarity = 'pc', price = 36,   kg = { 0.5, 3 } },
    { name = 'fish_bar',        label = 'Bar',                   water = 'mer',     rarity = 'pc', price = 42,   kg = { 1, 6 } },
    { name = 'fish_calamar',    label = 'Calamar',               water = 'mer',     rarity = 'r',  price = 95,   kg = { 0.5, 4 } },
    { name = 'fish_homard',     label = 'Homard',                water = 'mer',     rarity = 'r',  price = 140,  kg = { 0.5, 4 } },
    { name = 'fish_raie',       label = 'Raie manta',            water = 'mer',     rarity = 'e',  price = 280,  kg = { 20, 90 } },
    { name = 'fish_coelacanthe',label = 'Cœlacanthe',            water = 'mer',     rarity = 'l',  price = 1500, kg = { 30, 90 } },
    { name = 'fish_bonite',     label = 'Bonite',                water = 'large',   rarity = 'c',  price = 18,   kg = { 1, 5 } },
    { name = 'fish_dorado',     label = 'Coryphène',             water = 'large',   rarity = 'pc', price = 55,   kg = { 3, 20 } },
    { name = 'fish_thon',       label = 'Thon rouge',            water = 'large',   rarity = 'r',  price = 170,  kg = { 20, 200 } },
    { name = 'fish_espadon',    label = 'Espadon',               water = 'large',   rarity = 'e',  price = 380,  kg = { 40, 300 } },
    { name = 'fish_marlin',     label = 'Marlin bleu',           water = 'large',   rarity = 'e',  price = 450,  kg = { 60, 400 } },
    { name = 'fish_requin',     label = 'Requin-tigre',          water = 'large',   rarity = 'l',  price = 1400, kg = { 150, 600 } },
    { name = 'fish_gardon',     label = 'Gardon',                water = 'lac',     rarity = 'c',  price = 8,    kg = { 0.1, 0.6 } },
    { name = 'fish_perche',     label = 'Perche',                water = 'lac',     rarity = 'c',  price = 12,   kg = { 0.2, 1.5 } },
    { name = 'fish_carpe',      label = 'Carpe',                 water = 'lac',     rarity = 'pc', price = 30,   kg = { 2, 15 } },
    { name = 'fish_sandre',     label = 'Sandre',                water = 'lac',     rarity = 'pc', price = 45,   kg = { 1, 8 } },
    { name = 'fish_brochet',    label = 'Brochet',               water = 'lac',     rarity = 'r',  price = 110,  kg = { 2, 18 } },
    { name = 'fish_silure',     label = 'Silure',                water = 'lac',     rarity = 'e',  price = 300,  kg = { 15, 90 } },
    { name = 'fish_esturgeon',  label = 'Esturgeon',             water = 'lac',     rarity = 'l',  price = 1100, kg = { 30, 120 } },
    { name = 'fish_goujon',     label = 'Goujon',                water = 'riviere', rarity = 'c',  price = 8,    kg = { 0.03, 0.15 } },
    { name = 'fish_truite',     label = 'Truite fario',          water = 'riviere', rarity = 'c',  price = 15,   kg = { 0.3, 2 } },
    { name = 'fish_ombre',      label = 'Ombre commun',          water = 'riviere', rarity = 'pc', price = 38,   kg = { 0.3, 2 } },
    { name = 'fish_anguille',   label = 'Anguille',              water = 'riviere', rarity = 'r',  price = 100,  kg = { 0.5, 4 } },
    { name = 'fish_saumon',     label = 'Saumon sauvage',        water = 'riviere', rarity = 'r',  price = 130,  kg = { 3, 20 } },
    { name = 'fish_albinos',    label = 'Poisson-chat albinos',  water = 'riviere', rarity = 'l',  price = 1000, kg = { 5, 40 } },
    -- trouvailles (toutes les eaux)
    { name = 'fish_tresor',     label = 'Coffre englouti',       water = '*',       rarity = 'l',  price = 900,  kg = { 4, 12 }, find = true },
}
FISH_BY = {}
for _, f in ipairs(FISH) do FISH_BY[f.name] = f end
WATER_LABEL = { mer = 'Mer', large = 'Large (bateau)', lac = 'Lac', riviere = 'Rivière' }

-- Leurres et appâts : rareté, bonus sur chaque rareté de poisson (c, pc, r, e, l), vitesse de touche, risque de perte à chaque prise
LURES = {
    { name = 'appat_ver',      label = 'Vers de terre',       rarity = 'c',  price = 3,   stack = 50, mult = { 1.0, 1.0, 1.0, 1.0, 1.0 }, bite = 1.0,  loss = 100, best = 'lac' },
    { name = 'appat_crevette', label = 'Crevettes',           rarity = 'pc', price = 8,   stack = 50, mult = { 0.9, 1.4, 1.3, 1.1, 1.0 }, bite = 0.9,  loss = 100, best = 'mer' },
    { name = 'leurre_cuiller', label = 'Cuillère tournante',  rarity = 'r',  price = 140, stack = 10, mult = { 0.7, 1.4, 1.9, 1.4, 1.2 }, bite = 0.85, loss = 25,  best = 'riviere' },
    { name = 'leurre_nageur',  label = 'Poisson nageur',      rarity = 'e',  price = 480, stack = 10, mult = { 0.5, 1.2, 2.3, 2.4, 1.8 }, bite = 0.75, loss = 15,  best = 'large' },
    { name = 'leurre_dore',    label = 'Leurre doré',         rarity = 'l',  price = 0,   stack = 5,  mult = { 0.3, 1.0, 2.6, 3.6, 4.5 }, bite = 0.6,  loss = 8,   best = '*', nosell = true },
}
LURE_BY = {}
for _, l in ipairs(LURES) do LURE_BY[l.name] = l end

-- Cannes : la meilleure du sac est utilisée. power : marge au ferrage ; luck : bonus de rareté (c, pc, r, e, l)
RODS = {
    { name = 'canne_carbone', label = 'Canne carbone',    price = 2600, power = 3, luck = { 1.0, 1.15, 1.35, 1.5, 1.5 } },
    { name = 'canne_pro',     label = 'Canne renforcée',  price = 700,  power = 2, luck = { 1.0, 1.1, 1.2, 1.25, 1.2 } },
    { name = 'fishing_rod',   label = 'Canne à pêche',    price = 120,  power = 1, luck = { 1.0, 1.0, 1.0, 1.0, 1.0 } },
}
