/* (patch 343) « Créer une propriété » (agence immobilière) : panneau à gauche de l'écran, formulaire en un seul écran.
   Jeu → NUI : propform.open { tiers: [{ id, label, price, rent }], placed } · propform.placed { ok } · NUI → jeu : propform.place, propform.submit, propform.close. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let box = null;
function drop() { if (box) { box.remove(); box = null; } G.uiStack = G.uiStack.filter((u) => u.id !== 'propform'); }
const money = (n) => (Number(n) || 0).toLocaleString('fr-FR') + ' $';
G.on('propform.close', drop);
G.on('propform.placed', (d) => { if (box && box.__placed) box.__placed(d && d.ok !== false); });
G.on('propform.open', function (d) {
  drop();
  const tiers = Array.isArray(d.tiers) ? d.tiers : [];
  if (!tiers.length) return;
  const st = { name: '', placed: false, ptype: 'Maison', at: 0, mode: 'buy' };
  const grp = (label, kids) => h('div', { class: 'pf-g' }, h('label', null, label), kids);
  const nameIn = h('input', { class: 'pf-in', type: 'text', maxlength: '48', placeholder: 'Nom de la propriété', autocomplete: 'off', spellcheck: 'false' });
  nameIn.addEventListener('input', () => { st.name = nameIn.value; });
  nameIn.addEventListener('keydown', (e) => e.stopPropagation());
  const placeBtn = h('button', { type: 'button', class: 'pf-b wide', onclick: () => G.post('propform.place', {}) }, "Placer l'entrée ici");
  const clear = h('button', { type: 'button', class: 'pf-x', title: 'Retirer', onclick: () => { st.placed = false; sync(); } }, '×');
  const chips = (list, pick, on, off) => {
    const row = h('div', { class: 'pf-row' });
    list.forEach((o) => { const b = h('button', { type: 'button', class: 'pf-b' + (o.off ? ' off' : ''), title: o.off ? 'Bientôt' : '', onclick: () => { if (!o.off) { pick(o.v); Array.from(row.children).forEach((c) => c.classList.toggle('on', c === b)); } } }, o.l); if (o.v === on) b.classList.add('on'); row.appendChild(b); });
    return row;
  };
  const inst = chips([{ l: 'IPL', v: 'ipl' }, { l: 'MLO', v: 'mlo', off: 1 }, { l: 'SHELL', v: 'shell', off: 1 }], () => {}, 'ipl');
  const ptype = chips([{ l: 'Appartement', v: 'Appartement' }, { l: 'Local', v: 'Local' }, { l: 'Maison', v: 'Maison' }], (v) => { st.ptype = v; }, 'Maison');
  const zone = h('button', { type: 'button', class: 'pf-b wide off', title: 'Bientôt' }, 'Définir la zone');
  // intérieur : carrousel
  let ti = 0;
  const pic = h('div', { class: 'pf-pic' }), pname = h('b', null, ''), dots = h('span', { class: 'pf-dots' });
  const prev = h('button', { type: 'button', class: 'pf-ar l', onclick: () => go(-1) }, '‹'), next = h('button', { type: 'button', class: 'pf-ar r', onclick: () => go(1) }, '›');
  pic.appendChild(prev); pic.appendChild(next);
  const buyCb = h('i', { class: 'pf-cb on' }), rentCb = h('i', { class: 'pf-cb' });
  const buyPx = h('span', { class: 'pf-px' }), rentPx = h('span', { class: 'pf-px' });
  const buyBox = h('div', { class: 'pf-pay on', onclick: () => { st.mode = 'buy'; sync(); } }, h('div', { class: 'pf-pt' }, buyCb, 'Achat'), buyPx);
  const rentBox = h('div', { class: 'pf-pay', onclick: () => { st.mode = 'rent'; sync(); } }, h('div', { class: 'pf-pt' }, rentCb, 'Location'), rentPx);
  function go(dir) { ti = (ti + dir + tiers.length) % tiers.length; sync(); }
  function sync() {
    const t = tiers[ti];
    pname.textContent = String(t.label || '');
    pic.className = 'pf-pic t' + (ti % 4);
    G.clear(dots); tiers.forEach((_, i) => dots.appendChild(h('i', { class: i === ti ? 'on' : '' })));
    buyPx.textContent = money(t.price); rentPx.textContent = money(t.rent) + ' / jour';
    buyBox.classList.toggle('on', st.mode === 'buy'); rentBox.classList.toggle('on', st.mode === 'rent');
    buyCb.classList.toggle('on', st.mode === 'buy'); rentCb.classList.toggle('on', st.mode === 'rent');
    placeBtn.textContent = st.placed ? 'Entrée placée' : "Placer l'entrée ici";
    placeBtn.classList.toggle('on', st.placed); clear.style.display = st.placed ? '' : 'none';
  }
  const ok = h('button', { type: 'button', class: 'pf-ok', onclick: () => {
    if (st.name.trim().length < 3) { nameIn.classList.add('err'); nameIn.focus(); return; }
    if (!st.placed) { placeBtn.classList.add('err'); return; }
    G.post('propform.submit', { kind: st.mode, tier: tiers[ti].id, name: st.name.trim(), ptype: st.ptype });
  } }, 'Mettre en annonce');
  box = h('div', { id: 'g-propform' },
    h('div', { class: 'pf-h' }, h('b', null, 'Créer une propriété'), h('button', { type: 'button', class: 'pf-c', onclick: () => G.post('propform.close', {}) }, '×')),
    h('div', { class: 'pf-body' },
      grp('Nom de la propriété', nameIn),
      grp("Position de l'entrée", h('div', { class: 'pf-row' }, placeBtn, clear)),
      grp("Type d'instance", inst), grp('Type de propriété', ptype), grp('Zone de la propriété', zone),
      grp('Intérieur', h('div', null, pic, h('div', { class: 'pf-pn' }, pname, dots))),
      grp('Paiement', h('div', { class: 'pf-row two' }, buyBox, rentBox)),
      ok));
  box.__placed = (v) => { st.placed = v; sync(); };
  G.root.appendChild(box);
  sync();
  G.uiStack.push({ id: 'propform', onEscape: () => G.post('propform.close', {}) });
  setTimeout(() => nameIn.focus(), 40);
});
})();
