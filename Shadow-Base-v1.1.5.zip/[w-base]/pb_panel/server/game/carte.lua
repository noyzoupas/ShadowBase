-- Carte : unique endroit pour AJOUTER des points au monde (supérettes, banques, garages, coffres, filières, braquages, points d'entreprise et de gang…).
-- Parcours : on choisit un type, on clique sur la carte du jeu, le serveur téléporte l'admin à cet endroit, il se place exactement où il veut puis confirme (E).
-- La position enregistrée est toujours lue côté serveur sur le joueur : le panel ne fournit jamais les coordonnées finales.

local B, P, DB = PB.B, PB.Perm, PB.DB
local G = PB.G
local Place = { types = {}, order = {} }
PB.Place = Place

P.Register('carte.place', 'Ajouter des points au monde depuis la carte (magasins, banques, garages, filières, entreprises…)', 'carte', true)
P.Register('carte.delete', 'Supprimer des points depuis la carte', 'carte', true)

function Place.Register(t)
    if not t.id or not t.create then return end
    if not Place.types[t.id] then Place.order[#Place.order + 1] = t.id end
    Place.types[t.id] = t
end

local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):sub(1, n)) end
local function uid(prefix) return (prefix .. '_' .. tostring(os.time() % 1000000) .. tostring(math.random(10, 99))):sub(1, 32) end
local function ahead(pos, d)
    local r = math.rad(pos.h or 0)
    return { x = pos.x - math.sin(r) * d, y = pos.y + math.cos(r) * d, z = pos.z, h = pos.h or 0 }
end
local function f(v) return (tonumber(v) or 0) + 0.0 end

-- Types ----------------------------------------------------------------------------------------------------------------------------------
local function shopType(id, label, kind, sprite, color, icon, opts)
    Place.Register({ id = id, label = label, group = 'Commerces', icon = icon,
        create = function(pos, name)
            local cat = kind == 'store' and (G.DefaultStore or {}) or (kind == 'dealer' and (G.DefaultDealer or {}) or (kind == 'weapons' and PB.DeepCopy(G.DefaultArmory or {}) or {}))
            local spawn = kind == 'dealer' and ahead(pos, 6.0) or nil
            local cols = { 'kind', 'label', 'x', 'y', 'z', 'h', 'sprite', 'color', 'blip', 'price', 'catalog', 'enabled', 'opts' }
            local params = { kind, name, f(pos.x), f(pos.y), f(pos.z), f(pos.h), sprite, color, 1, (kind == 'barber' and 40) or (kind == 'tattoo' and 60) or 0, PB.Json(cat), 1, PB.Json(opts) }
            if spawn then cols[#cols + 1] = 'spawn' params[#params + 1] = PB.Json(spawn) end
            local qs = {}
            for _ = 1, #cols do qs[#qs + 1] = '?' end
            local sid = DB.insert('INSERT INTO pb_shops (' .. table.concat(cols, ', ') .. ') VALUES (' .. table.concat(qs, ', ') .. ')', params)
            if kind == 'weapons' and G.SyncArmory then pcall(G.SyncArmory, cat) end
            G.PushConfig()
            return sid ~= nil, name .. ' créé(e). Règle son catalogue dans Magasins › Modifier.'
        end,
        list = function() local out = {} for _, r in ipairs(DB.q('SELECT id, label, x, y FROM pb_shops WHERE kind = ?', { kind }) or {}) do out[#out + 1] = { id = tostring(r.id), label = r.label, x = r.x, y = r.y } end return out end,
        remove = function(rid) DB.exec('DELETE FROM pb_shops WHERE id = ? AND kind = ?', { tonumber(rid) or -1, kind }) G.PushConfig() return true end })
end
shopType('store', 'Supérette', 'store', 52, 2, 'cart', { tagline = 'Ouvert jour et nuit', accent = '#7be0a4', pay_mode = 'both', max_qty = 10, npc_on = true, npc_model = 'mp_m_shopkeep_01' })
shopType('clothes', 'Magasin de vêtements', 'clothes', 73, 47, 'hanger', { tagline = 'Essaie, choisis, repars habillé', accent = '#b58cff', pay_mode = 'both' })
shopType('weapons', 'Armurerie', 'weapons', 110, 1, 'shield', { tagline = "Permis de port d'arme obligatoire", accent = '#ff9d9d', pay_mode = 'both', max_qty = 10, test_sec = 20, test_ammo = 24, give_ammo = true })
shopType('dealer', 'Concessionnaire', 'dealer', 225, 3, 'engine', { tagline = 'Le choix du connaisseur', accent = '#6fb4ff', pay_mode = 'both' })
shopType('barber', 'Coiffeur / barbier', 'barber', 71, 4, 'scissors', { tagline = 'Coupe, barbe et maquillage', accent = '#b58cff', pay_mode = 'both' })
shopType('tattoo', 'Salon de tatouage', 'tattoo', 75, 1, 'brush', { tagline = 'Ton histoire, sur ta peau', accent = '#ff6b7d', pay_mode = 'both' })
-- Les 7 salons de coiffure de la carte GTA (Herr Kutz, Beach Combover, O'Sheas…) posés d'un coup (ceux déjà posés à moins de 15 m sont ignorés)
local GTA_BARBERS = { { -814.31, -183.82, 37.57, 'Coiffeur Rockford Hills' }, { 136.83, -1708.37, 29.29, 'Herr Kutz Davis' }, { -1282.60, -1116.76, 6.99, 'Beach Combover Vespucci' },
    { 1931.51, 3729.67, 32.84, "O'Sheas Sandy Shores" }, { 1212.84, -472.92, 66.21, 'Herr Kutz Mirror Park' }, { -32.89, -152.32, 57.08, 'Hair on Hawick' }, { -278.08, 6228.46, 31.70, 'Herr Kutz Paleto Bay' } }
Place.Register({ id = 'barber_all', label = 'Coiffeurs : les 7 salons de GTA d\'un coup', group = 'Commerces', icon = 'scissors',
    create = function()
        local n = 0
        for _, b in ipairs(GTA_BARBERS) do
            local near = DB.one('SELECT id FROM pb_shops WHERE kind = ? AND ABS(x - ?) < 15 AND ABS(y - ?) < 15', { 'barber', b[1], b[2] })
            if not near then
                DB.insert('INSERT INTO pb_shops (kind, label, x, y, z, h, sprite, color, blip, price, catalog, enabled, opts) VALUES (?, ?, ?, ?, ?, 0, 71, 4, 1, 40, ?, 1, ?)',
                    { 'barber', b[4], b[1], b[2], b[3], '[]', PB.Json({ tagline = 'Coupe, barbe et maquillage', accent = '#b58cff', pay_mode = 'both' }) })
                n = n + 1
            end
        end
        G.PushConfig()
        return true, n > 0 and (n .. ' salon(s) de coiffure ajouté(s) (40 $ la coupe, modifiable dans Magasins).') or 'Les 7 salons sont déjà posés.'
    end,
    list = function() return {} end, remove = function() return true end })

-- Magasins prêts à l'emploi (Builder) : sacs à dos et masques de l'inventaire, avec un prix par défaut modifiable dans Magasins
local function itemShop(id, label, sprite, color, icon, tagline, items, price, hidden)
    Place.Register({ id = id, label = label, group = 'Commerces', icon = icon, hidden = hidden,
        create = function(pos, name)
            local cat = {}
            for _, it in ipairs(items()) do cat[#cat + 1] = { name = it.name, label = it.label, price = price(it), hunger = 0, thirst = 0, stress = 0, category = label, image = '' } end
            local sid = DB.insert('INSERT INTO pb_shops (kind, label, x, y, z, h, sprite, color, blip, price, catalog, enabled, opts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, 1, ?)',
                { 'store', name, f(pos.x), f(pos.y), f(pos.z), f(pos.h), sprite, color, PB.Json(cat), PB.Json({ tagline = tagline, accent = '#7be0a4', pay_mode = 'both', max_qty = 2, npc_on = true, npc_model = 'mp_m_shopkeep_01', shop_tag = id }) })
            G.PushConfig()
            return sid ~= nil, name .. ' créé (' .. #cat .. ' articles). Prix modifiables dans Magasins › Modifier.'
        end,
        list = function() local out = {} for _, r in ipairs(DB.q('SELECT id, label, x, y FROM pb_shops WHERE kind = ? AND opts LIKE ?', { 'store', '%' .. id .. '%' }) or {}) do out[#out + 1] = { id = tostring(r.id), label = r.label, x = r.x, y = r.y } end return out end,
        remove = function(rid) DB.exec('DELETE FROM pb_shops WHERE id = ? AND opts LIKE ?', { tonumber(rid) or -1, '%' .. id .. '%' }) G.PushConfig() return true end })
end
itemShop('shop_bags', 'Magasin de sacs à dos', 586, 5, 'bag', 'Porte plus, va plus loin', function() return G.Inv and G.Inv.BAGS or {} end,
    function(it) local kg = tonumber(tostring(it.label):match('%+(%d+)')) or 10 return kg * 150 end, true)   -- ancien modèle (supérette) : remplacé par « masques et sacs »
-- Magasin de masques et sacs : même cabine que le magasin de vêtements (rayons Masques et Sacs, images), l'article acheté arrive dans le sac
Place.Register({ id = 'shop_masks', label = 'Magasin de masques et sacs', group = 'Commerces', icon = 'user',
    create = function(pos, name)
        local sid = DB.insert('INSERT INTO pb_shops (kind, label, x, y, z, h, sprite, color, blip, price, catalog, enabled, opts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, 1, ?)',
            { 'clothes', name, f(pos.x), f(pos.y), f(pos.z), f(pos.h), 362, 47, '[]', PB.Json({ tagline = 'Pour ne pas être reconnu', accent = '#b58cff', pay_mode = 'both', scope = 'masks_bags', npc_on = true, npc_model = 'mp_m_shopkeep_01', shop_tag = 'shop_masks' }) })
        G.PushConfig()
        return sid ~= nil, name .. ' créé. Prix des masques et des sacs : Magasins › Réglages.'
    end,
    list = function() local out = {} for _, r in ipairs(DB.q('SELECT id, label, x, y FROM pb_shops WHERE opts LIKE ?', { '%shop_masks%' }) or {}) do out[#out + 1] = { id = tostring(r.id), label = r.label, x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec('DELETE FROM pb_shops WHERE id = ? AND opts LIKE ?', { tonumber(rid) or -1, '%shop_masks%' }) G.PushConfig() return true end })
-- anciens magasins de masques / sacs posés en supérette : passés une fois en cabine « masques et sacs »
CreateThread(function()
    while not PB.IsReady do Wait(500) end
    local n = 0
    for _, r in ipairs(DB.q("SELECT id, opts FROM pb_shops WHERE kind = 'store' AND (opts LIKE '%shop_masks%' OR opts LIKE '%shop_bags%')") or {}) do
        local o = PB.FromJson(r.opts, {}) or {}
        o.scope, o.shop_tag, o.accent = 'masks_bags', 'shop_masks', '#b58cff'
        DB.exec("UPDATE pb_shops SET kind = 'clothes', price = 0, catalog = '[]', opts = ? WHERE id = ?", { PB.Json(o), r.id })
        n = n + 1
    end
    if n > 0 then G.PushConfig() end
end)

local function bankType(id, label, kind, icon)
    Place.Register({ id = id, label = label, group = 'Banque', icon = icon,
        create = function(pos, name)
            DB.exec('INSERT INTO pb_bank_points (id, kind, label, x, y, z, enabled) VALUES (?, ?, ?, ?, ?, ?, 1)', { uid(kind), kind, name, f(pos.x), f(pos.y), f(pos.z) })
            G.PushConfig() return true, name .. ' ajouté.'
        end,
        list = function() local out = {} for _, r in ipairs(DB.q('SELECT id, label, x, y FROM pb_bank_points WHERE kind = ?', { kind }) or {}) do out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y } end return out end,
        remove = function(rid) DB.exec('DELETE FROM pb_bank_points WHERE id = ? AND kind = ?', { tostring(rid), kind }) G.PushConfig() return true end })
end
bankType('bank_branch', 'Agence bancaire', 'branch', 'coins')
bankType('bank_atm', 'Distributeur (ATM)', 'atm', 'card')

Place.Register({ id = 'garage', label = 'Garage public', group = 'Garages et coffres', icon = 'engine',
    create = function(pos, name)
        local sp = ahead(pos, 4.0)
        DB.exec("INSERT INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh, biz, enabled) VALUES (?, ?, 'public', ?, ?, ?, ?, ?, ?, ?, '', 1)", { uid('gar'), name, f(pos.x), f(pos.y), f(pos.z), f(sp.x), f(sp.y), f(sp.z), f(sp.h) })
        G.PushConfig() return true, name .. ' créé. Le véhicule sort 4 m devant toi.'
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y FROM pb_garages WHERE kind = 'public'") or {}) do out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_garages WHERE id = ? AND kind = 'public'", { tostring(rid) }) G.PushConfig() return true end })

Place.Register({ id = 'stash', label = 'Coffre public', group = 'Garages et coffres', icon = 'lock',
    create = function(pos, name)
        DB.exec("INSERT INTO pb_inv_stashes (id, label, slots, weight, x, y, z, biz, min_grade, enabled) VALUES (?, ?, 50, 100000, ?, ?, ?, '', 0, 1)", { uid('stash'), name, f(pos.x), f(pos.y), f(pos.z) })
        G.PushConfig() return true, name .. ' créé (50 emplacements).'
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y FROM pb_inv_stashes WHERE biz = ''") or {}) do out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_inv_stashes WHERE id = ? AND biz = ''", { tostring(rid) }) DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. tostring(rid) }) G.PushConfig() return true end })

-- Filières illégales : on ajoute une ligne à la configuration du module Activités illégales.
local function ensureItem(name, label)
    if not DB.one('SELECT name FROM pb_inv_items WHERE name = ?', { name }) then
        DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, 100, 50, ?, 0, ?)', { name, label, 'misc', 'Marchandise illégale.' })
        if G.Inv and G.Inv.Reload then G.Inv.Reload() end
    end
end
local function cfgAppend(ns, key, row)
    local list = PB.Cfg.Get(ns, key, {}) or {}
    local out = {}
    for _, r in ipairs(list) do out[#out + 1] = r end
    out[#out + 1] = row
    PB.Cfg.Set(ns, key, out, 0, 'Carte : ' .. tostring(row.label))
    G.PushConfig()
end
local function cfgRemove(ns, key, id)
    local out = {}
    for _, r in ipairs(PB.Cfg.Get(ns, key, {}) or {}) do if tostring(r.id) ~= tostring(id) then out[#out + 1] = r end end
    PB.Cfg.Set(ns, key, out, 0, 'Carte : suppression ' .. tostring(id))
    G.PushConfig()
    return true
end
local function cfgList(ns, key, kind)
    local out = {}
    for _, r in ipairs(PB.Cfg.Get(ns, key, {}) or {}) do if not kind or r.kind == kind then out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y } end end
    return out
end
local function drugPresets() local out = {} for _, k in ipairs(G.Crime.DRUG_ORDER) do out[#out + 1] = { k, G.Crime.DRUGS[k].label } end return out end
local function drugType(kind, label, icon)
    Place.Register({ id = 'drug_' .. kind, label = label, group = 'Activités illégales', icon = icon,
        presets = drugPresets(),
        create = function(pos, name, _, preset)
            local key = G.Crime.DRUGS[preset or ''] and preset or 'weed'
            local d = G.Crime.EnsureDrug(key)
            local row = G.Crime.DrugRow(key, kind, { id = uid(kind), label = name, x = f(pos.x), y = f(pos.y), z = f(pos.z) })
            cfgAppend('crime', 'chain', row)
            local what = kind == 'harvest' and 'récolte (1 ' .. d.raw[2]:lower() .. ')' or (kind == 'process' and 'transformation (2 bruts → 1 pochon)' or 'vente et drapeau (3 pochons max par passage)')
            return true, name .. ' : ' .. what .. ' — ' .. d.label .. '.'
        end,
        list = function() return cfgList('crime', 'chain', kind) end,
        remove = function(rid) return cfgRemove('crime', 'chain', rid) end })
end
drugType('harvest', 'Point de récolte (drogue)', 'paw')
drugType('process', 'Laboratoire de transformation', 'box')
drugType('sell', 'Point de vente et drapeau (dealer)', 'coins')

Place.Register({ id = 'heist', label = 'Braquage', group = 'Activités illégales', icon = 'alert',
    create = function(pos, name)
        cfgAppend('crime', 'heists', { id = uid('heist'), label = name, x = f(pos.x), y = f(pos.y), z = f(pos.z), radius = 4, min = 800, max = 2200, time = 30, cooldown = 30, police = 0, need = '', alert = 100 })
        return true, name .. ' ajouté. Gains et délais dans Activités illégales › Braquages.'
    end,
    list = function() return cfgList('crime', 'heists') end, remove = function(rid) return cfgRemove('crime', 'heists', rid) end })
-- Vendeur du braquage le plus proche (30 m) : se placer DERRIÈRE le comptoir, face aux clients, puis Entrée
Place.Register({ id = 'heist_clerk', label = 'Braquage : position du vendeur (derrière le comptoir)', group = 'Activités illégales', icon = 'user',
    create = function(pos)
        local list = cfgList('crime', 'heists')
        local best, bd
        for _, r in ipairs(list) do
            local d = math.sqrt((pos.x - r.x) ^ 2 + (pos.y - r.y) ^ 2)
            if d < 30 and (not bd or d < bd) then best, bd = r, d end
        end
        if not best then return false, 'Aucun braquage à moins de 30 m : pose d\'abord le braquage.' end
        local all = PB.Cfg.Get('crime', 'heists', {}) or {}
        for _, r in ipairs(all) do if r.id == best.id then r.px, r.py, r.pz, r.h = f(pos.x), f(pos.y), f(pos.z), math.floor(pos.h or 0) end end
        PB.Cfg.Set('crime', 'heists', all, 0, 'Builder : position du vendeur')
        G.PushConfig()
        return true, ('Vendeur de « %s » placé ici (il regardera dans ta direction).'):format(best.label)
    end,
    list = function() return {} end, remove = function() return true end })
-- Vendeur du magasin le plus proche (30 m) : se placer derrière le comptoir, face aux clients, puis Entrée
Place.Register({ id = 'shop_clerk', label = 'Magasin : position du vendeur (derrière le comptoir)', group = 'Commerces', icon = 'user',
    create = function(pos)
        local best, bd
        for _, r in ipairs(DB.q('SELECT id, label, x, y FROM pb_shops') or {}) do
            local d = math.sqrt((pos.x - r.x) ^ 2 + (pos.y - r.y) ^ 2)
            if d < 30 and (not bd or d < bd) then best, bd = r, d end
        end
        if not best then return false, "Aucun magasin à moins de 30 m : pose d'abord le magasin." end
        DB.exec('REPLACE INTO pb_clerk_pos (shop_id, x, y, z, h) VALUES (?, ?, ?, ?, ?)', { best.id, f(pos.x), f(pos.y), f(pos.z), math.floor(pos.h or 0) })
        G.PushConfig()
        return true, ('Vendeur de « %s » placé ici (il regardera dans ta direction).'):format(best.label)
    end,
    list = function() return {} end, remove = function() return true end })
Place.Register({ id = 'launder', label = 'Point de blanchiment', group = 'Activités illégales', icon = 'coins',
    create = function(pos, name)
        cfgAppend('crime', 'launder', { id = uid('wash'), label = name, x = f(pos.x), y = f(pos.y), z = f(pos.z), rate = 70, max = 20000, time = 12 })
        return true, name .. ' ajouté.'
    end,
    list = function() return cfgList('crime', 'launder') end, remove = function(rid) return cfgRemove('crime', 'launder', rid) end })

-- Points d'entreprise et de gang (G.Points) : siège, service, patron, coffre.
local PKINDS = { hq = 'Siège (blip)', duty = 'Prise de service', boss = 'Bureau du patron' }
local function pointType(ownerKind, kind, label, icon)
    Place.Register({ id = ownerKind .. '_' .. kind, label = label, group = ownerKind == 'biz' and 'Entreprises' or 'Gangs', icon = icon, needs = ownerKind,
        create = function(pos, name, owner)
            owner = tostring(owner or '')
            if ownerKind == 'biz' and not G.Biz.Get(owner) then return false, "Choisis l'entreprise concernée." end
            if ownerKind == 'gang' and not (G.Tags.GangDefs()[owner]) then return false, 'Choisis le gang concerné.' end
            -- siège d'entreprise : icône et couleur du catalogue si l'entreprise en vient
            local cat = ownerKind == 'biz' and G.BizCat and G.BizCat.ByKey and G.BizCat.ByKey[owner]
            local sprite = kind == 'hq' and (ownerKind == 'biz' and (cat and cat.blip and cat.blip[1] or 475) or 84) or 0
            local bcolor = ownerKind == 'biz' and (cat and cat.blip and cat.blip[2] or 3) or 1
            local id = G.Points.Add({ owner_kind = ownerKind, owner = owner, kind = kind, label = name, x = pos.x, y = pos.y, z = pos.z, h = pos.h, radius = 2.0, sprite = sprite, bcolor = bcolor, vis = ownerKind == 'biz' and 'all' or 'members' })
            if kind == 'hq' and ownerKind == 'biz' then DB.exec('UPDATE pb_biz SET hx = ?, hy = ?, hz = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), owner }) end
            return id ~= nil, name .. ' ajouté.'
        end,
        list = function()
            local out = {}
            for _, r in ipairs(DB.q('SELECT id, label, owner, x, y FROM pb_points WHERE owner_kind = ? AND kind = ?', { ownerKind, kind }) or {}) do out[#out + 1] = { id = tostring(r.id), label = r.label .. ' (' .. r.owner .. ')', x = r.x, y = r.y } end
            return out
        end,
        remove = function(rid) G.Points.Remove(rid) return true end })
end
for _, k in ipairs({ 'hq', 'duty', 'boss' }) do pointType('biz', k, 'Entreprise : ' .. PKINDS[k], k == 'hq' and 'building' or (k == 'duty' and 'clock' or 'briefcase')) end
pointType('gang', 'hq', 'Gang : quartier général (blip membres)', 'users')
pointType('gang', 'boss', 'Gang : bureau du chef', 'briefcase')

Place.Register({ id = 'biz_stash', label = "Entreprise : coffre de l'équipe", group = 'Entreprises', icon = 'lock', needs = 'biz',
    create = function(pos, name, owner)
        if not G.Biz.Get(tostring(owner or '')) then return false, "Choisis l'entreprise concernée." end
        DB.exec('INSERT INTO pb_inv_stashes (id, label, slots, weight, x, y, z, biz, min_grade, enabled) VALUES (?, ?, 80, 150000, ?, ?, ?, ?, 0, 1)', { uid('bz'), name, f(pos.x), f(pos.y), f(pos.z), tostring(owner) })
        G.PushConfig() return true, name .. ' créé (réservé aux employés).'
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y, biz FROM pb_inv_stashes WHERE biz <> ''") or {}) do out[#out + 1] = { id = r.id, label = r.label .. ' (' .. r.biz .. ')', x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_inv_stashes WHERE id = ? AND biz <> ''", { tostring(rid) }) DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. tostring(rid) }) G.PushConfig() return true end })
Place.Register({ id = 'biz_garage', label = "Entreprise : entrée du garage (E : sortir / ranger)", group = 'Entreprises', icon = 'engine', needs = 'biz',
    create = function(pos, name, owner)
        if not G.Biz.Get(tostring(owner or '')) then return false, "Choisis l'entreprise concernée." end
        local sp = ahead(pos, 4.0)
        local gid = uid('bg')
        DB.exec("INSERT INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh, biz, enabled) VALUES (?, ?, 'biz', ?, ?, ?, ?, ?, ?, ?, ?, 1)", { gid, name, f(pos.x), f(pos.y), f(pos.z), f(sp.x), f(sp.y), f(sp.z), f(sp.h), tostring(owner) })
        G.PushConfig() return true, name .. ' créé. Pose maintenant la sortie des véhicules si ce n\'est pas déjà fait.', gid
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y, biz FROM pb_garages WHERE kind = 'biz'") or {}) do out[#out + 1] = { id = r.id, label = r.label .. ' (' .. r.biz .. ')', x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_garages WHERE id = ? AND kind = 'biz'", { tostring(rid) }) G.PushConfig() return true end })

Place.Register({ id = 'biz_garage_out', label = "Entreprise : sortie des véhicules (où ils apparaissent)", group = 'Entreprises', icon = 'engine', needs = 'biz',
    create = function(pos, name, owner, preset)
        owner = tostring(owner or '')
        if not G.Biz.Get(owner) then return false, "Choisis l'entreprise concernée." end
        local gid = tostring(preset or '')
        if gid == '' then
            local rows = DB.q("SELECT id FROM pb_garages WHERE kind = 'biz' AND biz = ?", { owner }) or {}
            if #rows ~= 1 then return false, #rows == 0 and "Pose d'abord l'entrée du garage de cette entreprise." or 'Cette entreprise a plusieurs garages : passe par « Configurer les points ».' end
            gid = rows[1].id
        end
        if not DB.one("SELECT id FROM pb_garages WHERE id = ? AND kind = 'biz' AND biz = ?", { gid, owner }) then return false, 'Garage introuvable.' end
        DB.exec('UPDATE pb_garages SET sx = ?, sy = ?, sz = ?, sh = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), gid })
        G.PushConfig() return true, 'Sortie des véhicules placée ici (dans le sens où tu regardes).'
    end,
    list = function() return {} end, remove = function() return true end })
Place.Register({ id = 'biz_wardrobe_shop', label = "Entreprise : magasin de vêtements gratuit (ancien vestiaire)", group = 'Entreprises', icon = 'hanger', needs = 'biz', hidden = true,
    create = function(pos, name, owner)
        local b = G.Biz.Get(tostring(owner or ''))
        if not b then return false, "Choisis l'entreprise concernée." end
        local opts = { tagline = 'Vestiaire de ' .. tostring(b.label), accent = '#b58cff', pay_mode = 'both', vestiaire = true, biz_owner = b.id }
        local sid = DB.insert('INSERT INTO pb_shops (kind, label, x, y, z, h, sprite, color, blip, price, catalog, enabled, opts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            { 'clothes', name, f(pos.x), f(pos.y), f(pos.z), f(pos.h), 73, 47, 0, 0, '[]', 1, PB.Json(opts) })
        G.PushConfig() return sid ~= nil, name .. " créé : magasin de vêtements gratuit, sans blip (accessible à toute personne qui s'en approche)."
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y FROM pb_shops WHERE kind = 'clothes' AND opts LIKE '%vestiaire%'") or {}) do out[#out + 1] = { id = tostring(r.id), label = r.label, x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_shops WHERE id = ? AND kind = 'clothes' AND opts LIKE '%vestiaire%'", { tonumber(rid) or -1 }) G.PushConfig() return true end })
-- Points de métier : accueil (toutes les entreprises), atelier (garages), cuisine / bar (restauration) ----------------------------------------
pointType('biz', 'desk', "Entreprise : accueil (E : appeler un employé)", 'bell')
pointType('biz', 'wardrobe', "Entreprise : vestiaire (tenues de l'entreprise)", 'hanger')
pointType('gang', 'wardrobe', "Gang : vestiaire (tenues du groupe)", 'hanger')
pointType('biz', 'workshop', "Entreprise : atelier / pont (réparations et améliorations)", 'engine')
pointType('biz', 'kitchen', "Entreprise : cuisine / bar (préparer les produits)", 'food')

-- Comptoir de vente : boutique de l'entreprise (argent dans sa caisse, vendeur en service ou sonnette, stock rempli par les employés)
local function art(name, label, price, hunger, thirst, stress) return { name = name, label = label, price = price, hunger = hunger or 0, thirst = thirst or 0, stress = stress or 0, category = 'Carte', image = '' } end
local CATALOGS = {
    bar = { art('beer', 'Bière', 6, 0, 20, -8), art('wine', 'Verre de vin', 10, 0, 15, -10), art('cocktail', 'Cocktail maison', 15, 0, 25, -15), art('whisky', 'Verre de whisky', 14, 0, 10, -15),
        art('tequila_shot', 'Shot de tequila', 8, 0, 8, -10), art('soda', 'Soda', 4, 0, 25, -3), art('water', "Bouteille d'eau", 3, 0, 35, 0) },
    resto = { art('meal', 'Plat du jour', 18, 70, 0, -5), art('pizza', 'Pizza', 12, 55, -3, 0), art('salad', 'Salade composée', 9, 30, 5, 0), art('fish_meal', 'Assiette de poisson', 16, 60, 0, 0),
        art('soda', 'Soda', 4, 0, 25, -3), art('water', "Bouteille d'eau", 3, 0, 35, 0), art('wine', 'Verre de vin', 10, 0, 15, -10) },
    sushi = { art('sushi', 'Plateau de sushis', 14, 45, 0, 0), art('ramen', 'Bol de ramen', 11, 50, 10, 0), art('tea', 'Thé vert', 3, 0, 25, -5), art('water', "Bouteille d'eau", 3, 0, 35, 0) },
    cafe = { art('coffee', 'Café', 4, 0, 15, -5), art('cappuccino', 'Cappuccino', 5, 0, 18, -6), art('croissant', 'Croissant', 3, 15, 0, 0), art('muffin', 'Muffin', 4, 20, 0, 0),
        art('orange_juice', "Jus d'orange", 5, 0, 35, 0), art('sandwich', 'Sandwich', 6, 35, 0, 0) },
    bakery = { art('bread', 'Pain', 3, 30, 0, 0), art('croissant', 'Croissant', 3, 15, 0, 0), art('pain_choc', 'Pain au chocolat', 3, 18, 0, 0), art('cake', 'Part de gâteau', 6, 25, 0, -5) },
    icecream = { art('icecream', 'Glace', 5, 10, 10, -5), art('milkshake', 'Milkshake', 6, 10, 20, -5) },
    wine = { art('wine', 'Bouteille de vin', 25, 0, 20, -15), art('grape', 'Raisin', 2, 3, 3, 0) },
    beer = { art('beer', 'Bière artisanale', 7, 0, 20, -8) },
    mart = { art('water', "Bouteille d'eau", 3, 0, 35, 0), art('soda', 'Soda', 4, 0, 25, -3), art('sandwich', 'Sandwich', 6, 35, 0, 0), art('chips', 'Paquet de chips', 3, 18, -4, -2),
        art('bread', 'Pain', 3, 30, 0, 0), art('coffee', 'Café', 4, 0, 15, -5) },
    hardware = { art('repair_kit', 'Kit de réparation', 450, 0, 0, 0), art('rope', 'Corde', 25, 0, 0, 0), art('fishing_rod', 'Canne à pêche', 120, 0, 0, 0), art('pickaxe', 'Pioche', 150, 0, 0, 0), art('axe', 'Hache', 140, 0, 0, 0) },
    pharmacy = { art('bandage', 'Bandage', 30, 0, 0, 0), art('medkit', 'Trousse de soins', 150, 0, 0, -10) },
    electronics = { art('phone', 'Téléphone', 300, 0, 0, 0) },
    tobacco = { art('cigarettes', 'Paquet de cigarettes', 10, 0, 0, -15) },
    florist = { art('bouquet', 'Bouquet de fleurs', 25, 0, 0, -5) },
    books = { art('book', 'Livre', 15, 0, 0, -5) },
}
-- Catalogue d'une entreprise : d'après son identifiant du catalogue, sinon sa catégorie (vide = à remplir dans Magasins)
local CATALOG_OF = { bahamas = 'bar', unicorn = 'bar', tequilala = 'bar', pub = 'bar', nightclub = 'bar', nightcover = 'bar', casino = 'bar',
    restaurant = 'resto', pizzeria = 'resto', foodtruck = 'resto', catering = 'resto', sushi = 'sushi', bean = 'cafe', cafe = 'cafe', bakery = 'bakery', icecream = 'icecream',
    vineyard = 'wine', brewery = 'beer', mart = 'mart', supermarket = 'mart', gasstation = 'mart', hardware = 'hardware', pharmacy = 'pharmacy', electronics = 'electronics',
    tobacco = 'tobacco', florist = 'florist', books = 'books' }
function Place.CatalogFor(b)
    if not b then return nil end
    local k = CATALOG_OF[b.id] or (b.category == 'resto' and 'resto') or (b.category == 'commerce' and 'mart') or nil
    return k and CATALOGS[k] or nil
end
Place.Register({ id = 'biz_shop', label = "Entreprise : comptoir de vente (boutique de l'entreprise)", group = 'Entreprises', icon = 'cart', needs = 'biz',
    create = function(pos, name, owner)
        local b = G.Biz.Get(tostring(owner or ''))
        if not b then return false, "Choisis l'entreprise concernée." end
        local cat = PB.DeepCopy(Place.CatalogFor(b) or {})
        local opts = { tagline = tostring(b.label), accent = b.color or '#7be0a4', pay_mode = 'both', max_qty = 10, biz = b.id, biz_counter = b.id, stock_on = true, stock_start = 10, stock_max = 50, wholesale = 50, npc_on = false }
        local sid = DB.insert('INSERT INTO pb_shops (kind, label, x, y, z, h, sprite, color, blip, price, catalog, enabled, opts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            { 'store', name, f(pos.x), f(pos.y), f(pos.z), f(pos.h), 52, 2, 0, 0, PB.Json(cat), 1, PB.Json(opts) })
        G.PushConfig()
        return sid ~= nil, name .. (#cat > 0 and (' créé (' .. #cat .. ' articles). ') or ' créé, catalogue vide : remplis-le dans Magasins › Modifier. ') .. "L'argent des ventes va dans la caisse de l'entreprise."
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y FROM pb_shops WHERE kind = 'store' AND opts LIKE '%biz_counter%'") or {}) do out[#out + 1] = { id = tostring(r.id), label = r.label, x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_shops WHERE id = ? AND opts LIKE '%biz_counter%'", { tonumber(rid) or -1 }) G.PushConfig() return true end })

-- Logement : porte posée à la position du staff (à vendre, 150 000 $ ; prix, loyer et intérieur se règlent ensuite dans Logements)
Place.Register({ id = 'property', label = 'Logement à vendre', group = 'Immobilier', icon = 'home',
    create = function(pos, name, owner, preset)
        if preset and tostring(preset) ~= '' then name = tostring(preset):sub(1, 48) end   -- nom tapé depuis la fiche de l'agence (Builder)
        local id = uid('prop')
        DB.exec("INSERT INTO pb_properties (id, label, kind, price, rent, x, y, z, enabled) VALUES (?, ?, 'buy', 150000, 0, ?, ?, ?, 1)", { id, name, f(pos.x), f(pos.y), f(pos.z) })
        G.PushConfig()
        return true, name .. " mis en vente (150 000 $). Prix, location et intérieur : panel › Logements."
    end,
    list = function() local out = {} for _, r in ipairs(DB.q('SELECT id, label, x, y, owner FROM pb_properties') or {}) do out[#out + 1] = { id = r.id, label = r.label .. (r.owner ~= '' and ' (occupé)' or ''), x = r.x, y = r.y } end return out end,
    remove = function(rid)
        local r = DB.one('SELECT owner FROM pb_properties WHERE id = ?', { tostring(rid) })
        if r and r.owner ~= '' then return false end
        DB.exec('DELETE FROM pb_properties WHERE id = ?', { tostring(rid) }) G.PushConfig() return true
    end })

pointType('gang', 'stash', "Gang : coffre de l'organisation (reçoit les récompenses)", 'lock')
-- tous les points d'entreprise / de gang, de toutes sortes (y compris d'anciennes versions) : pour « Supprimer le point le plus proche »
Place.Register({ id = 'any_point', label = "Point d'entreprise / de gang", group = 'Entreprises', icon = 'pin', hidden = true,
    create = function() return false, 'Utilise les points de la fiche.' end,
    list = function()
        local out = {}
        for _, r in ipairs(DB.q('SELECT id, kind, label, owner, x, y FROM pb_points') or {}) do out[#out + 1] = { id = tostring(r.id), label = (r.label ~= '' and r.label or r.kind) .. ' (' .. r.owner .. ')', x = r.x, y = r.y } end
        return out
    end,
    remove = function(rid) G.Points.Remove(tonumber(rid)) return true end })
Place.Register({ id = 'gang_garage', label = "Gang : rangement des véhicules (E : sortir / ranger)", group = 'Gangs', icon = 'engine', needs = 'gang',
    create = function(pos, name, owner)
        owner = tostring(owner or '')
        if not G.Tags.GangDefs()[owner] then return false, 'Choisis le gang concerné.' end
        local sp = ahead(pos, 4.0)
        local gid = uid('gg')
        DB.exec("INSERT INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh, biz, enabled) VALUES (?, ?, 'gang', ?, ?, ?, ?, ?, ?, ?, ?, 1)", { gid, name, f(pos.x), f(pos.y), f(pos.z), f(sp.x), f(sp.y), f(sp.z), f(sp.h), owner })
        G.PushConfig() return true, name .. ' créé. Pose maintenant la sortie des véhicules si ce n\'est pas déjà fait.', gid
    end,
    list = function() local out = {} for _, r in ipairs(DB.q("SELECT id, label, x, y, biz FROM pb_garages WHERE kind = 'gang'") or {}) do out[#out + 1] = { id = r.id, label = r.label .. ' (' .. r.biz .. ')', x = r.x, y = r.y } end return out end,
    remove = function(rid) DB.exec("DELETE FROM pb_garages WHERE id = ? AND kind = 'gang'", { tostring(rid) }) G.PushConfig() return true end })
Place.Register({ id = 'gang_garage_out', label = "Gang : sortie des véhicules (où ils apparaissent)", group = 'Gangs', icon = 'engine', needs = 'gang',
    create = function(pos, name, owner, preset)
        owner = tostring(owner or '')
        if not G.Tags.GangDefs()[owner] then return false, 'Choisis le gang concerné.' end
        local gid = tostring(preset or '')
        if gid == '' then
            local rows = DB.q("SELECT id FROM pb_garages WHERE kind = 'gang' AND biz = ?", { owner }) or {}
            if #rows ~= 1 then return false, #rows == 0 and "Pose d'abord le rangement des véhicules de ce gang." or 'Ce gang a plusieurs garages : passe par « Configurer les points ».' end
            gid = rows[1].id
        end
        if not DB.one("SELECT id FROM pb_garages WHERE id = ? AND kind = 'gang' AND biz = ?", { gid, owner }) then return false, 'Garage introuvable.' end
        DB.exec('UPDATE pb_garages SET sx = ?, sy = ?, sz = ?, sh = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), gid })
        G.PushConfig() return true, 'Sortie des véhicules placée ici (dans le sens où tu regardes).'
    end,
    list = function() return {} end, remove = function() return true end })

-- Pack de points : tous les points d'une entreprise ou d'une organisation, posés l'un après l'autre en jeu -------------------------------------
-- Les étapes dépendent du métier ; chacune correspond à une fonction qui existe vraiment (marqueur E, coffre, garage, magasin de vêtements gratuit).
local BASE_BIZ = {
    { type = 'biz_hq', name = 'Siège', hint = "Entrée de l'entreprise (blip sur la carte)." },
    { type = 'biz_duty', name = 'Prise de service', hint = 'E : se mettre en / hors service.' },
    { type = 'biz_boss', name = 'Bureau du patron', hint = 'E : ouvre la tablette de gestion.' },
    { type = 'biz_stash', name = "Coffre de l'équipe", hint = 'Coffre partagé réservé aux employés.' },
    { type = 'biz_garage', name = 'Garage', hint = "Entrée du garage : E pour sortir ou ranger un véhicule.", garage = true },
    { type = 'biz_garage_out', name = 'Sortie des véhicules', hint = 'Place-toi où les véhicules doivent apparaître, dans le bon sens.', needsGarage = true },
    { type = 'biz_wardrobe', name = 'Vestiaire', hint = "Tenues de l'entreprise par grade (le patron les enregistre sur place) et tenue civile." },
}
local EXTRA_BIZ = {
    police = { { type = 'biz_stash', name = 'Coffre des saisies', hint = 'Objets saisis lors des fouilles.' } },
    ems = { { type = 'biz_stash', name = 'Pharmacie', hint = 'Trousses, bandages et médicaments.' } },
    garage = { { type = 'biz_stash', name = 'Pièces détachées', hint = 'Kits et pièces de réparation.' } },
}
function Place.PackSteps(ownerKind, owner)
    local out = {}
    if ownerKind == 'gang' then
        out = { { type = 'gang_hq', name = 'Quartier général', hint = 'Point principal du gang (blip pour les membres).' },
            { type = 'gang_boss', name = 'Point boss', hint = 'Bureau du chef : E ouvre la tablette du gang.' },
            { type = 'gang_stash', name = 'Point coffre', hint = "Coffre de l'organisation (starter pack, territoires) : E pour l'ouvrir." },
            { type = 'gang_garage', name = 'Rangement véhicules', hint = "Entrée du garage de gang : E pour sortir ou ranger (véhicules du gang et les tiens).", garage = true },
            { type = 'gang_garage_out', name = 'Sortie du garage', hint = 'Place-toi où les véhicules doivent apparaître, dans le bon sens.', needsGarage = true },
            { type = 'gang_wardrobe', name = 'Vestiaire', hint = "Tenues du groupe (le chef les enregistre sur place) et tenue civile." } }
    else
        local b = G.Biz.Get(owner)
        for _, s in ipairs(BASE_BIZ) do out[#out + 1] = s end
        for _, s in ipairs(b and EXTRA_BIZ[b.kind] or {}) do out[#out + 1] = s end
        if b and b.category == 'food' then out[#out + 1] = { type = 'biz_stash', name = 'Stock et cuisine', hint = 'Ingrédients et plats.' } end
        -- points propres au métier
        out[#out + 1] = { type = 'biz_desk', name = 'Accueil', hint = "E : un client appelle les employés en service ; un employé ouvre la tablette." }
        if b and b.kind == 'garage' then out[#out + 1] = { type = 'biz_workshop', name = 'Atelier (pont)', hint = "Réparations et améliorations. Dès qu'un atelier est posé, l'atelier ne s'ouvre plus qu'ici." } end
        if b and (b.category == 'resto' or b.id == 'vineyard' or b.id == 'brewery') then
            out[#out + 1] = { type = 'biz_kitchen', name = 'Cuisine / bar', hint = 'Les employés en service y préparent les produits avec des ingrédients (recettes : Activités › Recettes).' }
        end
        if b and b.id == 'realestate' then out[#out + 1] = { type = 'property', name = 'Logement à vendre', add = true, ask = 'Nom du logement (ex. Appartement Alta 3B)', hint = "Ajoute un logement à vendre dont la porte est à ta position ; l'agence touche une commission à chaque vente." } end
        if b and Place.CatalogFor(b) then out[#out + 1] = { type = 'biz_shop', name = 'Comptoir de vente', hint = "Boutique de l'entreprise : argent dans la caisse, employé en service ou sonnette ; ce que les employés préparent est mis en rayon quand ils l'ouvrent." } end
    end
    return out
end
local createAt
local packs = {}   -- [src] = { ownerKind, owner, steps, i, garage }
local function packShow(src)
    local pk = packs[src]
    if not pk then TriggerClientEvent('pb:carte:pack', src, PB.Json({ done = true })) return end
    local s = pk.steps[pk.i]
    TriggerClientEvent('pb:carte:pack', src, PB.Json({ i = pk.i, n = #pk.steps, name = s.name, hint = s.hint }))
end
local function packNext(src)
    local pk = packs[src]
    if not pk then return end
    pk.i = pk.i + 1
    while pk.steps[pk.i] and pk.steps[pk.i].needsGarage and not pk.garage do pk.i = pk.i + 1 end
    if pk.i > #pk.steps then
        packs[src] = nil
        packShow(src)
        G.Notify(src, { type = 'success', title = 'Points', text = 'Tous les points sont posés.' })
        return
    end
    packShow(src)
end
-- Pack quelconque (ex. une drogue : récolte → transformation → vente) : étapes { type, name, hint, preset }
function Place.PackRun(src, steps, owner)
    if not src or src <= 0 or not P.Has(src, 'carte.place') then return false, 'Droit manquant (placer des points).' end
    packs[src] = { ownerKind = 'any', owner = tostring(owner or ''), steps = steps, i = 0 }
    packNext(src)
    return true
end
function Place.PackStart(src, ownerKind, owner)
    if not src or src <= 0 or not P.Has(src, 'carte.place') then return false, 'Droit manquant (placer des points).' end
    ownerKind = ownerKind == 'gang' and 'gang' or 'biz'
    owner = tostring(owner or '')
    if ownerKind == 'biz' and not G.Biz.Get(owner) then return false, 'Entreprise introuvable.' end
    if ownerKind == 'gang' and not (G.Tags.GangDefs()[owner]) then return false, 'Gang introuvable.' end
    packs[src] = { ownerKind = ownerKind, owner = owner, steps = Place.PackSteps(ownerKind, owner), i = 0 }
    packNext(src)
    return true
end
PB.Action('carte.pack', 'carte.place', function(ctx, p)
    local v = p.values or p
    local kind, owner = tostring(v.target or ''):match('^(%a+):(.+)$')
    if not kind then kind, owner = v.owner_kind, v.owner end
    if not ctx.src or ctx.src <= 0 then return false, 'Disponible seulement en jeu : connecte-toi au serveur.' end
    local ok, err = Place.PackStart(ctx.src, kind, owner)
    if not ok then return false, err end
    ctx.audit('config', 'carte.pack', tostring(owner), nil, { kind = kind })
    ctx.close = true
    return true
end)
RegisterNetEvent('pb:carte:pack:set', function()
    local src = source
    local pk = packs[src]
    if not pk or not P.Has(src, 'carte.place') then packs[src] = nil return end
    local s = pk.steps[pk.i]
    local t = s and Place.types[s.type]
    if not t then packs[src] = nil packShow(src) return end
    local preset = s.needsGarage and pk.garage or (s.preset or '')
    local ok, msg, gid = createAt(src, t, s.name, pk.owner, preset)
    PB.Audit.Log('config', ok and 'carte.create' or 'carte.fail', src, t.id, nil, { name = s.name, owner = pk.owner, pack = true })
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Étape ' .. pk.i .. '/' .. #pk.steps, text = tostring(msg or '') })
    if not ok then return end
    if s.garage and gid then pk.garage = gid end
    packNext(src)
end)
RegisterNetEvent('pb:carte:pack:skip', function()
    local src = source
    if packs[src] then packNext(src) end
end)
RegisterNetEvent('pb:carte:pack:stop', function()
    local src = source
    if packs[src] then packs[src] = nil packShow(src) G.Notify(src, { type = 'info', title = 'Points', text = 'Configuration interrompue : les points déjà posés restent en place.' }) end
end)
AddEventHandler('playerDropped', function() packs[source] = nil end)

-- Parcours : choisir sur la carte → téléportation → confirmer ----------------------------------------------------------------------------
local pending = {}   -- [src] = { type, name, owner, preset, back = {x,y,z}, at }

local function typeInfo(t) return { id = t.id, label = t.label, group = t.group, icon = t.icon, needs = t.needs, presets = t.presets } end
function Place.Types() local out = {} for _, id in ipairs(Place.order) do if not Place.types[id].hidden then out[#out + 1] = typeInfo(Place.types[id]) end end return out end

local function validate(p, requireName)
    local t = Place.types[tostring(p.type or '')]
    if not t then return nil, 'Type inconnu.' end
    local name = clean(p.name, 48)
    if requireName ~= false and #name < 2 then return nil, 'Donne un nom au point (2 caractères au moins).' end
    return t, name
end

function createAt(src, t, name, owner, preset)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false, 'Position illisible.' end
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return false, 'Position illisible.' end
    local pos = { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped) or 0.0 }   -- z = hauteur du joueur, comme tous les points du jeu
    local ok, a, b, c = pcall(t.create, pos, name, owner, preset, src)
    if not ok then PB.Err('carte ' .. t.id .. ' : ' .. tostring(a)) return false, 'Création impossible : ' .. tostring(a):sub(1, 120) end
    return a, b, c
end

Place.CreateAt = createAt

PB.Action('carte.start', 'carte.place', function(ctx, p)
    if not ctx.src or ctx.src <= 0 then return false, 'Disponible seulement en jeu.' end
    local t, name = validate(p)
    if not t then return false, name end
    local x, y = tonumber(p.x), tonumber(p.y)
    if not x or not y or math.abs(x) > 10000 or math.abs(y) > 10000 then return false, "Clique d'abord un endroit sur la carte." end
    if t.needs and tostring(p.owner or '') == '' then return false, t.needs == 'biz' and "Choisis l'entreprise concernée." or 'Choisis le gang concerné.' end
    local ped = GetPlayerPed(ctx.src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped) or nil
    pending[ctx.src] = { type = t.id, name = name, owner = tostring(p.owner or ''), preset = tostring(p.preset or ''), back = c and { x = c.x, y = c.y, z = c.z } or nil, at = os.time() }
    ctx.audit('config', 'carte.start', t.id, nil, { name = name, x = x, y = y })
    ctx.close = true
    TriggerClientEvent('pb:carte:go', ctx.src, PB.Json({ x = x, y = y, label = t.label, name = name }))
    return true
end)

PB.Action('carte.here', 'carte.place', function(ctx, p)
    if not ctx.src or ctx.src <= 0 then return false, 'Disponible seulement en jeu.' end
    local t, name = validate(p)
    if not t then return false, name end
    if t.needs and tostring(p.owner or '') == '' then return false, t.needs == 'biz' and "Choisis l'entreprise concernée." or 'Choisis le gang concerné.' end
    local ok, msg = createAt(ctx.src, t, name, tostring(p.owner or ''), tostring(p.preset or ''))
    if not ok then return false, msg end
    ctx.audit('config', 'carte.create', t.id, nil, { name = name, owner = p.owner })
    ctx.toast = msg
    return true
end)

PB.Action('carte.delete', 'carte.delete', function(ctx, p)
    local t = Place.types[tostring(p.type or '')]
    if not t or not t.remove then return false, 'Type inconnu.' end
    t.remove(tostring(p.id or ''))
    ctx.audit('config', 'carte.delete', t.id, nil, { id = p.id })
    ctx.toast = 'Supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce point ?', text = 'Le point disparaît du monde pour tous les joueurs.', danger = true } })

-- Confirmation en jeu (touche E) ou annulation (touche Retour arrière / commande)
RegisterNetEvent('pb:carte:confirm', function()
    local src = source
    local pd = pending[src]
    if not pd or os.time() - pd.at > 900 then pending[src] = nil return end
    if not P.Has(src, 'carte.place') then pending[src] = nil return end
    local t = Place.types[pd.type]
    if not t then pending[src] = nil return end
    pending[src] = nil
    local ok, msg = createAt(src, t, pd.name, pd.owner, pd.preset)
    PB.Audit.Log('config', ok and 'carte.create' or 'carte.fail', src, t.id, nil, { name = pd.name, owner = pd.owner, msg = msg })
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Carte', text = tostring(msg or '') })
    TriggerClientEvent('pb:carte:done', src, ok and true or false)
end)
RegisterNetEvent('pb:carte:cancel', function()
    local src = source
    local pd = pending[src]
    pending[src] = nil
    if pd and pd.back then TriggerClientEvent('pb:carte:back', src, PB.Json(pd.back)) end
    G.Notify(src, { type = 'info', title = 'Carte', text = 'Ajout annulé.' })
    TriggerClientEvent('pb:carte:done', src, false)
end)
AddEventHandler('playerDropped', function() pending[source] = nil end)

-- Pose depuis le menu staff (Builder) : sur place, sans téléportation ; E pose, Retour arrière annule
function Place.Arm(src, typeId, name, owner, preset)
    if not P.Has(src, 'carte.place') then return false, 'Droit manquant (placer des points).' end
    local t = Place.types[tostring(typeId)]
    if not t then return false, 'Type inconnu.' end
    name = clean(name, 48)
    if #name < 2 then name = t.label end
    if t.needs and tostring(owner or '') == '' then return false, t.needs == 'biz' and "Choisis l'entreprise concernée." or 'Choisis le gang concerné.' end
    pending[src] = { type = t.id, name = name, owner = tostring(owner or ''), preset = tostring(preset or ''), at = os.time() }
    TriggerClientEvent('pb:carte:arm', src, PB.Json({ label = t.label, name = name }))
    return true
end

-- Points d'autres ressources (ex. Burger Shot) : ajoutés au Builder, la ressource crée le point elle-même à la position du staff
Place.ext = {}
exports('RegisterBuilder', function(def, cb)
    if type(def) ~= 'table' or not tostring(def.id or ''):match('^[%w_]+$') or type(def.points) ~= 'table' then return false end
    local res = (GetInvokingResource and GetInvokingResource()) or def.id
    local pts = {}
    for _, pt in ipairs(def.points) do
        if type(pt) == 'table' and tostring(pt.id or ''):match('^[%w_]+$') then
            local tid = 'ext_' .. def.id .. '_' .. pt.id
            pts[#pts + 1] = { id = tid, pid = pt.id, multi = pt.multi and true or nil, label = tostring(pt.label or pt.id):sub(1, 60), ask = pt.ask and tostring(pt.ask):sub(1, 40) or nil }
            Place.Register({ id = tid, label = tostring(def.label or def.id) .. ' : ' .. tostring(pt.label or pt.id), group = 'Ressources', icon = def.icon or 'box', hidden = true,
                create = function(pos, name, owner, preset, src)
                    if not src or (GetResourceState and res ~= def.id and GetResourceState(res) ~= 'started') then return false, 'Ressource « ' .. res .. ' » arrêtée.' end
                    local ok, r = pcall(cb, src, pt.id, preset ~= '' and preset or name)
                    if not ok then return false, 'Erreur de la ressource : ' .. tostring(r):sub(1, 100) end
                    return r ~= false, r ~= false and (tostring(pt.label or pt.id) .. ' placé ici.') or 'Refusé par la ressource.'
                end })
        end
    end
    -- def.list = true : cb(src, '__list') renvoie les points déjà posés { { key, label, x, y, z } } ; cb(src, '__delete', key) : en supprime un (facultatifs)
    Place.ext[def.id] = { id = def.id, label = tostring(def.label or def.id):sub(1, 40), icon = def.icon, points = pts, res = res, cb = cb, listable = def.list == true }
    return true
end)
AddEventHandler('onResourceStop', function(res) for id, e in pairs(Place.ext) do if e.res == res then Place.ext[id] = nil end end end)

-- Module du panel ---------------------------------------------------------------------------------------------------------------------------
local GROUP_COLOR = { Commerces = '#7be0a4', Banque = '#6fd3ff', ['Garages et coffres'] = '#ffb457', ['Activités illégales'] = '#ff6b7d', Entreprises = '#b58cff', Gangs = '#f2c14e' }
PB.Module({
    id = 'carte', label = 'Carte du jeu', icon = 'map', group = 'Serveur', order = 90, perm = 'carte.place', hint = 'Poser des points sur la carte du jeu',
    caps = function()
        return PB.Capsify({
            { 'Choisir un point sur la carte, téléportation, confirmation', 'ok', "Le serveur lit ta position au moment de confirmer (E) : le point est exactement où tu te tiens." },
            { 'Téléportation exacte au sol', 'warn', "Le jeu cherche le sol sous le point cliqué ; sur un toit ou un intérieur, utilise ton noclip puis confirme au bon endroit. Jamais vérifié dans un vrai client FiveM." },
            { 'Précision de la carte', 'warn', "Image satellite calibrée sur quelques repères : ~100 m d'écart possible, d'où la confirmation en jeu." },
        })
    end,
    doc = "## Carte\n1. Choisis le **type** de point (supérette, distributeur, garage, laboratoire…).\n2. Donne un **nom** (et l'entreprise / le gang si demandé).\n3. **Clique sur la carte** : un repère apparaît.\n4. **Me téléporter là-bas** : tu arrives sur place, avance jusqu'à l'endroit exact puis **E** pour confirmer (Retour arrière pour annuler).\n\nTu peux aussi tout créer **à ta position actuelle** sans te téléporter. Les points existants sont listés dans l'onglet *Existants*.",
    view = function(ctx)
        return { tabs = {
            { id = 'make', label = 'Créer', icon = 'building', build = function()
                local copts, kinds = {}, { { 'generic', 'Autre entreprise' }, { 'police', 'Police' }, { 'ems', 'Secours' }, { 'garage', 'Garage / mécanique' } }
                for _, c in ipairs(G.BizCat and G.BizCat.Cats or {}) do copts[#copts + 1] = { c.id, c.label } end
                if #copts == 0 then copts = { { 'services', 'Services' } } end
                return { B.notice('info', "Choisis ce que tu veux ajouter, remplis les infos, puis tu es guidé en jeu : point coffre, point boss, rangement des véhicules, sortie du garage… (E pour poser ici, Retour arrière pour passer)."),
                    { type = 'form', id = 'biz.create', title = 'Ajouter une entreprise', cols = 2, fields = {
                        { k = 'label', type = 'text', label = "Nom de l'entreprise", required = true, maxlen = 48 }, { k = 'category', type = 'select', label = 'Catégorie', opts = copts },
                        { k = 'template', type = 'select', label = 'Type de métier', opts = kinds, hint = 'Police / secours / garage donnent des droits propres au métier.' },
                        { k = 'id', type = 'text', label = 'Identifiant (facultatif)', maxlen = 32, pattern = '^[%w_]*$' },
                        { k = 'points', type = 'toggle', label = 'Poser tous les points maintenant (en jeu)' } },
                        values = { label = '', category = copts[1][1], template = 'generic', id = '', points = true }, submit = { action = 'biz.create', label = 'Créer l\'entreprise' } },
                    G.Orgs and G.Orgs.CreateForm() or nil }
            end, perm = 'carte.place' },
            { id = 'add', label = 'Ajouter', icon = 'plus', build = function()
                local bizs, gangs = {}, {}
                for _, b in ipairs(G.Biz.List()) do bizs[#bizs + 1] = { b.id, b.label } end
                for gid, d in pairs(G.Tags.GangDefs()) do gangs[#gangs + 1] = { gid, d.label } end
                table.sort(gangs, function(a, b) return a[2] < b[2] end)
                local pts = {}
                for _, id in ipairs(Place.order) do
                    local t = Place.types[id]
                    for _, r in ipairs(t.list and t.list() or {}) do pts[#pts + 1] = { id = r.id, label = r.label, sub = t.label, x = r.x, y = r.y, color = GROUP_COLOR[t.group] or '#ffffff' } end
                end
                local legend = {}
                for g, c in pairs(GROUP_COLOR) do legend[#legend + 1] = { label = g, color = c } end
                table.sort(legend, function(a, b) return a.label < b.label end)
                return { { type = 'carte', types = Place.Types(), bizs = bizs, gangs = gangs, points = pts, legend = legend, colors = GROUP_COLOR } }
            end },
            { id = 'pack', label = 'Configurer tout', icon = 'map', build = function()
                local opts = {}
                for _, b in ipairs(G.Biz.List()) do opts[#opts + 1] = { 'biz:' .. b.id, 'Entreprise · ' .. b.label } end
                local gl = {}
                for gid, d in pairs(G.Tags.GangDefs()) do gl[#gl + 1] = { 'gang:' .. gid, 'Organisation · ' .. d.label } end
                table.sort(gl, function(a, b) return a[2] < b[2] end)
                for _, g in ipairs(gl) do opts[#opts + 1] = g end
                local rows = {}
                for _, kind in ipairs({ 'police', 'ems', 'garage', 'generic' }) do
                    local names = {}
                    for _, s in ipairs(BASE_BIZ) do names[#names + 1] = s.name end
                    for _, s in ipairs(EXTRA_BIZ[kind] or {}) do names[#names + 1] = s.name end
                    rows[#rows + 1] = { kind = ({ police = 'Police', ems = 'Secours', garage = 'Garage / mécanique', generic = 'Autre entreprise' })[kind], steps = table.concat(names, ' · ') }
                end
                rows[#rows + 1] = { kind = 'Organisation', steps = 'Quartier général · Point boss · Point coffre · Rangement véhicules · Sortie du garage' }
                return { B.notice('info', "Choisis une entreprise ou une organisation : tu es guidé en jeu, point par point (E pour poser ici, Retour arrière pour passer, /carte_annuler pour arrêter). Les points posés restent en place."),
                    { type = 'form', id = 'carte.pack', title = 'Poser tous les points', cols = 1, fields = { { k = 'target', type = 'select', label = 'Entreprise ou organisation', opts = opts, required = true } },
                        values = { target = opts[1] and opts[1][1] or '' }, submit = { action = 'carte.pack', label = 'Commencer (en jeu)' } },
                    B.table({ id = 'packrows', title = 'Points demandés selon le type', columns = { { k = 'kind', label = 'Type' }, { k = 'steps', label = 'Étapes' } }, rows = rows }) }
            end, perm = 'carte.place' },
            { id = 'list', label = 'Existants', icon = 'list', build = function()
                local rows = {}
                for _, id in ipairs(Place.order) do
                    local t = Place.types[id]
                    for _, r in ipairs(t.list and t.list() or {}) do
                        rows[#rows + 1] = { type = t.label, name = r.label, pos = ('%d, %d'):format(math.floor(tonumber(r.x) or 0), math.floor(tonumber(r.y) or 0)),
                            actions = ctx.has('carte.delete') and { { action = 'carte.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { type = t.id, id = r.id } } } or {} }
                    end
                end
                return { B.table({ id = 'cartelist', title = 'Points créés depuis la carte et par les modules', search = true, columns = { { k = 'type', label = 'Type' }, { k = 'name', label = 'Nom' }, { k = 'pos', label = 'Position (x, y)' } }, rows = rows, empty = 'Aucun point.' }),
                    B.notice('info', "Pour modifier un magasin, un garage ou une entreprise (catalogue, grades…), utilise leur module ; la Carte sert à les poser.") }
            end, perm = 'carte.place' },
        } }
    end,
})

PB.SelfTest.Add('carte', function(R)
    R.check(#Place.order >= 15, 'carte', 'moins de 15 types de points : ' .. #Place.order)
    R.check(#Place.PackSteps('gang', 'x') == 6 and #Place.PackSteps('biz', 'zz_inconnu') >= 7, 'carte', 'pack de points incomplet')
    for _, id in ipairs(Place.order) do
        local t = Place.types[id]
        R.check(type(t.create) == 'function' and t.label and t.group, 'carte', 'type mal défini : ' .. id)
    end
end)
