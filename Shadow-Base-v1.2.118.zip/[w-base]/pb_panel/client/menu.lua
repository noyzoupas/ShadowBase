-- Menu « RageUI » : navigation aux flèches / manette (sans souris), rendu dans l'interface NUI, exports pour d'autres scripts.
-- La logique (éléments, sous-menus, listes, curseurs) est dans client/lib/menu_core.lua ; ici on lit les touches et on parle à l'interface.
local G = PBG
local Core = PBMenuCore
local stack = Core.NewStack({ maxVisible = 10, wrap = true })
local rep = Core.NewRepeater(380, 85)
local running = false
local rootId = ''
local uiOn, uiFocus = false, false     -- affichage « UI » (souris) au lieu de « lib » (flèches)
local askBox = nil
local suspended = false   -- menu mis de côté (pose au Builder…) : la pile est gardée, rien n'est affiché

-- Mode d'affichage d'un menu : choix du joueur (si permis) > règle par menu (« id|ui ») > réglage global > mode demandé par le script
local function modeFor(def)
    local c = (G.cfg and G.cfg.menus) or {}
    local m = (type(def) == 'table' and (def.mode == 'ui' or def.mode == 'lib')) and def.mode or 'lib'
    if c.ui_mode == 'ui' or c.ui_mode == 'lib' then m = c.ui_mode end
    local id = type(def) == 'table' and tostring(def.id or '') or ''
    local best = -1
    for _, line in ipairs(c.ui_overrides or {}) do
        local pre, md = tostring(line):match('^([%w_%.%-]+)|(%a+)$')
        if pre and (md == 'ui' or md == 'lib') and (id == pre or id:sub(1, #pre + 1) == pre .. '.') and #pre > best then m = md best = #pre end
    end
    if c.ui_allow_choice ~= false then
        local v = GetResourceKvpString('pb_menu_style')
        if v == 'ui' or v == 'lib' then m = v end
    end
    return m
end

local function mcfg() return (G.cfg and G.cfg.menus) or {} end
local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen() and not G.barberOpen) end   -- le coiffeur utilise ce menu

-- choix du joueur (F5 › Mes paramètres › Sons des menus), mémorisé sur son poste :
-- « click » = clic du serveur (par défaut) · « gta » = sons de base des menus du jeu · « off » = aucun son
function G.MenuSoundMode() local v = GetResourceKvpString('pb_menu_snd') if v == 'off' or v == 'gta' then return v end return 'click' end
function G.MenuSoundOn() return G.MenuSoundMode() ~= 'off' end
local GTA_SND = { nav = 'NAV_UP_DOWN', change = 'NAV_LEFT_RIGHT', select = 'SELECT', back = 'BACK', error = 'ERROR' }
local function sound(kind)
    if mcfg().sounds == false or not kind or not G.MenuSoundOn() then return end
    local cm = stack:Current()
    if cm and cm.def and cm.def.silent then return end   -- menu qui joue ses propres sons
    -- le clic du serveur (web/sounds/click.wav) pour naviguer, valider, revenir ; l'erreur garde le son du jeu
    if G.MenuSoundMode() == 'gta' then
        PlaySoundFrontend(-1, GTA_SND[kind] or 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    elseif kind == 'error' then PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    else G.send('ui.click', {}) end
end

local function push(ev)
    if uiOn then
        local snap = stack:Full()
        if not snap then G.send('umenu.close', {}) return end
        G.send((ev == 'rmenu.open') and 'umenu.open' or 'umenu.render', { menu = snap, brand = G.cfg and G.cfg.brand, staff = rootId:sub(1, 5) == 'staff' })
        return
    end
    local snap = stack:Snapshot()
    if not snap then G.send('rmenu.close', {}) return end
    G.send(ev or 'rmenu.render', { menu = snap, staff = rootId:sub(1, 5) == 'staff' })
end

-- Accepte askText(item) avec item = { prompt, label, value, maxlen } ou askText(libellé, valeur par défaut, longueur max)
local function askText(item, default, maxlen)
    if type(item) ~= 'table' then item = { prompt = item, value = default, maxlen = maxlen } end
    -- (v1.2.58) la même fenêtre partout, plus le clavier du jeu : à côté du menu, avec la souris le temps de la saisie
    askBox = { done = false, text = nil }
    local box, mouse = askBox, not uiOn
    if mouse then G.focus(true) end
    G.send('menuask.open', { prompt = tostring(item.prompt or item.label or 'Saisie'), value = tostring(item.value or ''), maxlen = tonumber(item.maxlen) or 120 })
    local t = GetGameTimer() + 120000
    while not box.done and GetGameTimer() < t do Wait(50) end
    if not box.done then G.send('menuask.close', {}) end
    askBox = nil
    if mouse then G.focus(false) end
    return box.text
end

local function closeAll()
    suspended = false
    if not stack:IsOpen() then return end
    stack:Close()
    if uiOn then
        G.send('umenu.close', {})
        if uiFocus then uiFocus = false G.focus(false) end
        uiOn = false
    else
        G.send('rmenu.close', {})
    end
end

local BLOCK = { 172, 173, 174, 175, 189, 190, 176, 177, 199, 200, 201, 202, 24, 25, 140, 141, 142, 143, 257, 263, 264 }

local function loop()
    if running then return end
    running = true
    CreateThread(function()
        while stack:IsOpen() and not suspended do
            Wait(0)
            if busy() then closeAll() break end
            if uiOn then goto continue end
            for i = 1, #BLOCK do DisableControlAction(0, BLOCK[i], true) end
            local c = mcfg()
            local now = GetGameTimer()
            local dirty = false
            local function press(id) return IsDisabledControlPressed(0, id) end
            do
                local first, every = tonumber(c.repeat_first) or 380, tonumber(c.repeat_every) or 85
                if rep('up', press(172), now, first, every) then sound(stack:Move(-1)) dirty = true
                elseif rep('down', press(173), now, first, every) then sound(stack:Move(1)) dirty = true
                elseif rep('left', press(174) or press(189), now, first, every) then sound(stack:Change(-1)) dirty = true
                elseif rep('right', press(175) or press(190), now, first, every) then sound(stack:Change(1)) dirty = true end
            end
            if IsDisabledControlJustPressed(0, 201) then
                local snd, req = stack:Select()
                sound(snd)
                if req and req.input then
                    local text = askText(req.input)
                    sound(stack:SetInput(req.input, text))
                end
                dirty = true
            elseif IsDisabledControlJustPressed(0, 202) or IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 200) then
                sound(stack:Back())
                if not stack:IsOpen() then G.send('rmenu.close', {}) break end
                dirty = true
            end
            if dirty and stack:IsOpen() then push() end
            ::continue::
        end
        running = false
    end)
end

local function open(def)
    if type(def) ~= 'table' or busy() then return false end
    local c = mcfg()
    stack.maxVisible = tonumber(c.max_visible) or 10
    stack.wrap = c.wrap ~= false
    if stack:IsOpen() then closeAll() end
    suspended = false
    if not stack:Open(def) then return false end
    rootId = tostring(def.id or '')
    uiOn = modeFor(def) == 'ui'
    if uiOn then uiFocus = true G.focus(true) end
    push('rmenu.open')
    sound('select')
    loop()
    return true
end

-- Ordre personnalisable : l'ordre choisi par le joueur est mémorisé sur son poste (KVP), `default` vient du panel.
local function loadOrder(key)
    local v = GetResourceKvpString('pb_order_' .. key)
    if v and v ~= '' then local ok, t = pcall(json.decode, v) if ok and type(t) == 'table' then return t end end
    return nil
end
local function saveOrder(key, ids) SetResourceKvp('pb_order_' .. key, json.encode(ids)) end
local function sortedItems(key, items, default) return Core.SortItems(items, loadOrder(key) or default) end
-- Élément « Réorganiser ce menu » : getItems() renvoie les éléments (avec `id`) tels qu'ils sont proposés.
local function orderEntry(key, getItems, default)
    local function current()
        local items = sortedItems(key, getItems(), default)
        local ids, label = {}, {}
        for _, it in ipairs(items) do if it.id and not it.hidden then ids[#ids + 1] = it.id label[it.id] = it.label end end
        return ids, label
    end
    local function moveItem(id, label)
        local function mv(how, text) return { label = text, onSelect = function() local ids = current() saveOrder(key, Core.MoveId(ids, id, how)) G.Menu.Refresh() end } end
        return { id = key .. '.order.' .. id, title = label, subtitle = 'Déplacer cet élément', refreshOnReturn = true, items = {
            mv('top', 'Tout en haut'), mv('up', 'Monter'), mv('down', 'Descendre'), mv('bottom', 'Tout en bas') } }
    end
    return { type = 'submenu', label = 'Réorganiser ce menu', icon = 'sliders', description = "Choisis un élément puis déplace-le. Réglage personnel, mémorisé sur ton poste.",
        submenu = { id = key .. '.order', title = 'Réorganiser', subtitle = 'Ton ordre personnel', refreshOnReturn = true, build = function()
            local ids, label = current()
            local out = {}
            for pos, id in ipairs(ids) do out[#out + 1] = { type = 'submenu', label = label[id] or id, right = pos .. ' / ' .. #ids, submenu = moveItem(id, label[id] or id) } end
            out[#out + 1] = { type = 'button', label = "Remettre l'ordre d'origine", description = "Retrouve l'ordre choisi par le serveur.", onSelect = function() DeleteResourceKvp('pb_order_' .. key) G.Menu.Refresh() end }
            return out
        end } }
end

G.Menu = { Sorted = sortedItems, OrderEntry = orderEntry, Ask = askText, Open = open, Close = closeAll, IsOpen = function() return stack:IsOpen() and not suspended end, Refresh = function() if stack:IsOpen() and not suspended then stack:Rebuild() push() end end, Stack = stack }

-- Mettre le menu de côté (le joueur va poser un point, viser une porte…) puis le rouvrir exactement où il était : une étape en arrière
-- de l'action choisie, pas tout en haut. Sans reprise dans les 15 minutes, la pile est oubliée.
local suspendSeq = 0
function G.Menu.Suspend()
    if not stack:IsOpen() or suspended then return false end
    suspended = true
    suspendSeq = suspendSeq + 1
    local seq = suspendSeq
    if uiOn then G.send('umenu.close', {}) if uiFocus then uiFocus = false G.focus(false) end else G.send('rmenu.close', {}) end
    SetTimeout(900000, function() if suspended and suspendSeq == seq then suspended = false stack:Close() end end)
    return true
end
function G.Menu.Resume()
    if not suspended then return false end
    suspended = false
    if not stack:IsOpen() or busy() then stack:Close() return false end
    if uiOn then uiFocus = true G.focus(true) end
    stack:Rebuild()
    push('rmenu.open')
    loop()
    return true
end
G.Menu.IsSuspended = function() return suspended end

-- Rendu « UI » : la souris envoie l'indice de la ligne ; la logique reste celle de la pile (aucune règle dupliquée)
local function afterUi()
    if stack:IsOpen() then push() return end
    if uiOn then
        G.send('umenu.close', {})
        if uiFocus then uiFocus = false G.focus(false) end
        uiOn = false
    end
end
local lastPick = { i = nil, t = 0 }
G.nui['umenu.select'] = function(d)
    local now = GetGameTimer()
    if lastPick.i == d.i and now - lastPick.t < 300 then return {} end
    lastPick.i, lastPick.t = d.i, now
    if not uiOn or not stack:IsOpen() or not stack:SetSel(d.i) then return {} end
    stack:Select()
    afterUi()
    return {}
end
G.nui['umenu.hover'] = function(d)
    if not uiOn or not stack:IsOpen() then return {} end
    if stack:SetSel(d.i) then afterUi() end
    return {}
end
G.nui['umenu.change'] = function(d)
    if not uiOn or not stack:IsOpen() or not stack:SetSel(d.i) then return {} end
    stack:Change(tonumber(d.dir) == -1 and -1 or 1)
    afterUi()
    return {}
end
G.nui['umenu.input'] = function(d)
    if not uiOn or not stack:IsOpen() or not stack:SetSel(d.i) then return {} end
    local m = stack:Current()
    local it = m and m.items[math.floor(tonumber(d.i) or 0)]
    if it and it.type == 'input' and type(d.text) == 'string' then stack:SetInput(it, d.text) end
    afterUi()
    return {}
end
G.nui['umenu.move'] = function(d)
    if not uiOn or not stack:IsOpen() then return {} end
    stack:Move(tonumber(d.dir) == -1 and -1 or 1)
    afterUi()
    return {}
end
G.nui['umenu.close'] = function() if uiOn then closeAll() end return {} end
G.nui['umenu.back'] = function()
    if not uiOn or not stack:IsOpen() then return {} end
    stack:Back()
    afterUi()
    return {}
end
G.nui['umenu.asked'] = function(d)
    if askBox then askBox.text = (type(d.text) == 'string') and d.text or nil askBox.done = true end
    return {}
end

-- Le joueur change de style (si le serveur le permet) : « ui » (souris) ou « lib » (flèches)
local function switchStyle(to)
    if (G.cfg.menus or {}).ui_allow_choice == false then return false end
    SetResourceKvp('pb_menu_style', to)
    if not stack:IsOpen() then return true end
    local want = to == 'ui'
    if want == uiOn then return true end
    if uiOn then G.send('umenu.close', {}) if uiFocus then uiFocus = false G.focus(false) end else G.send('rmenu.close', {}) end
    uiOn = want
    if uiOn then uiFocus = true G.focus(true) end
    push('rmenu.open')
    return true
end
G.nui['umenu.style'] = function(d) switchStyle(d.style == 'ui' and 'ui' or 'lib') return {} end
RegisterCommand('menustyle', function()
    if (G.cfg.menus or {}).ui_allow_choice == false then G.send('notify', { type = 'warn', title = 'Menus', text = "Le serveur impose le style des menus." }) return end
    local cur = GetResourceKvpString('pb_menu_style')
    local to = (cur == 'ui' or (cur ~= 'lib' and uiOn)) and 'lib' or 'ui'
    switchStyle(to)
    G.send('notify', { type = 'info', title = 'Menus', text = to == 'ui' and 'Style : interface (souris).' or 'Style : flèches + Entrée.' })
end, false)
G.Menu.SwitchStyle = switchStyle
G.Menu.Style = function() return uiOn and 'ui' or 'lib' end

-- Menus des autres ressources : si un état d'interface est resté bloqué (magasin fermé de travers), on le remet à zéro et on réessaie,
-- au lieu de refuser sans rien dire
exports('OpenMenu', function(def)
    if open(def) then return true end
    if type(def) == 'table' and not G.creating and not (G.state and G.state.dead) and not G.barberOpen then
        G.ForceClose('menu bloqué')
        if open(def) then return true end
    end
    G.send('notify', { type = 'warn', title = 'Menu', text = "Impossible d'ouvrir ce menu pour l'instant (une autre interface est ouverte)." })
    return false
end)
exports('CloseMenu', function() closeAll() end)
exports('IsMenuOpen', function() return stack:IsOpen() end)
exports('RefreshMenu', function() G.Menu.Refresh() end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and stack:IsOpen() then closeAll() end end)

-- Ouvrir un sous-menu par-dessus le menu affiché (réponse du serveur arrivée après coup) ; sans menu ouvert, l'ouvre simplement
function G.Menu.Push(def)
    if not stack:IsOpen() or suspended then return open(def) end
    stack:Open(def)
    push()
    return true
end
-- Remplacer le menu affiché (même niveau) : retour d'une étape puis ouverture du nouveau
function G.Menu.Replace(def)
    if not stack:IsOpen() or suspended then return open(def) end
    if stack:Depth() > 1 then
        local m = table.remove(stack.menus)
        if m and m.def and m.def.onClose then pcall(m.def.onClose, m) end
    else return open(def) end
    stack:Open(def)
    push()
    return true
end

function G.Menu.Back() if stack:IsOpen() and not suspended then stack:Back() push() end end
-- Suppression sensible : deux écrans à valider. « Annuler » est en premier : Entrée appuyée deux fois par erreur ne supprime rien.
function G.Menu.ConfirmTwice(what, note, onYes)
    local function cancelRow(n) return { label = 'Annuler', icon = 'x', onSelect = function() for _ = 1, n do G.Menu.Back() end end } end
    G.Menu.Push({ id = 'confirm.one', title = 'Supprimer ?', subtitle = tostring(what), nosearch = true, items = {
        cancelRow(1),
        { label = 'Oui, continuer', icon = 'trash', description = note, onSelect = function()
            G.Menu.Push({ id = 'confirm.two', title = 'Vraiment supprimer ?', subtitle = tostring(what), nosearch = true, items = {
                cancelRow(2),
                { label = 'Oui, supprimer', icon = 'trash', description = note, onSelect = function()
                    G.Menu.Back() G.Menu.Back()
                    onYes()
                end },
            } })
        end },
    } })
end
-- Revenir au menu `def` (en refermant ceux ouverts par-dessus) et, si `newDef` est donné, le remplacer par celui-ci.
-- Retourne false si `def` n'est plus dans la pile (le joueur est sorti entre-temps).
function G.Menu.PopTo(def, newDef)
    if not stack:IsOpen() or suspended then return false end
    local at
    for i, m in ipairs(stack.menus) do if m.def == def then at = i end end
    if not at then return false end
    while #stack.menus > at do
        local m = table.remove(stack.menus)
        if m.def and m.def.onClose then pcall(m.def.onClose, m) end
    end
    if newDef then
        local m = table.remove(stack.menus)
        if m and m.def and m.def.onClose then pcall(m.def.onClose, m) end
        stack:Open(newDef)
        local cur = stack:Current()
        if cur and m and newDef.keepSel then cur.sel = math.min(m.sel or 1, math.max(1, #cur.items)) cur:fixSel(1) end
    else stack:Rebuild() end
    push()
    return true
end

-- Pages « blocs » envoyées par le serveur (tableaux, formulaires, actions, avis) transformées en éléments de menu lib :
-- une ligne avec des actions devient un sous-menu, un formulaire devient une liste de choix + « Valider ».
-- onAct(act, payload) est appelé pour chaque action ou formulaire validé (le serveur revérifie tout).
local function short(t, n) t = tostring(t or ''):gsub('%s+', ' ') if #t > n then return t:sub(1, n - 1) .. '…' end return t end
-- une action « à confirmer » (exclure, renvoyer…) devient un sous-menu Confirmer / Annuler
local function actItem(a, onAct, id)
    local label = tostring(a.label or a.act)
    if not a.confirm then return { label = label, danger = a.danger, icon = a.danger and 'x' or (a.icon or 'check'), disabled = a.disabled or nil, onSelect = function() onAct(a.act, a.payload or {}) end } end
    return { type = 'submenu', label = label, danger = a.danger, icon = a.danger and 'x' or (a.icon or 'check'), disabled = a.disabled or nil, description = 'Demande une confirmation.',
        submenu = { id = id, title = short(label, 30), subtitle = 'Confirmer ?', items = {
            { label = 'Confirmer : ' .. short(label, 30), icon = 'check', onSelect = function() onAct(a.act, a.payload or {}) end },
            { label = 'Annuler', icon = 'back', onSelect = function() G.Menu.Back() end } } } }
end
-- onPage(id, label) : lien vers une autre page (tuiles) ; sans lui, les tuiles sont ignorées
function G.Menu.FromBlocks(blocks, onAct, idPrefix, onPage)
    local out = {}
    idPrefix = idPrefix or 'blocks'
    for bi, b in ipairs(blocks or {}) do
        if b.type == 'hero' then
            for _, c in ipairs(b.chips or {}) do if c[1] then out[#out + 1] = { label = tostring(c[1]), right = tostring(c[2] or ''), disabled = true } end end
        elseif b.type == 'tiles' and onPage then
            if b.title then out[#out + 1] = { type = 'separator', label = short(b.title, 40) } end
            for _, t in ipairs(b.items or {}) do
                if t.page then out[#out + 1] = { label = tostring(t.title or t.page), icon = t.icon, right = '›', description = t.sub and tostring(t.sub) or nil, onSelect = function() onPage(t.page, t.title) end }
                elseif t.act then out[#out + 1] = actItem({ act = t.act, payload = t.payload, label = t.title, icon = t.icon }, onAct, idPrefix .. '.t' .. bi) end
            end
        elseif b.type == 'terrmap' then
            if b.title then out[#out + 1] = { type = 'separator', label = short(b.title, 40) } end
            local zs = b.zones or {}
            if #zs == 0 then out[#out + 1] = { label = 'Aucun territoire défini', disabled = true } end
            for _, z in ipairs(zs) do
                local det = (z.owner and ('Tenu par ' .. tostring(z.owner)) or 'Libre') .. (z.reward and (' · ' .. tostring(z.reward)) or '') .. (z.next and (' · ' .. tostring(z.next)) or '')
                out[#out + 1] = { label = short(z.label or z.id, 34), right = z.mine and 'À nous' or (z.owner and short(z.owner, 16) or 'Libre'), icon = z.gps and 'gps' or 'pin', description = det .. (z.gps and ' · Entrée : GPS.' or ''),
                    disabled = not z.gps or nil, onSelect = function() if z.gps then onAct('gps_zone', { id = z.id }) end end }
            end
        elseif b.type == 'perms' then
            if b.title then out[#out + 1] = { type = 'separator', label = tostring(b.title) } end
            for gi, gr in ipairs(b.grades or {}) do
                if not gr.locked then
                    local rows = {}
                    for _, it in ipairs(b.items or {}) do
                        local on = type(gr.perms) == 'table' and gr.perms[it.k] == true
                        rows[#rows + 1] = { type = 'checkbox', label = tostring(it.label or it.k), description = it.desc, checked = on, onChange = function(_, v) onAct(b.act, { grade = gr.id, perm = it.k, on = v and '1' or '0' }) end }
                    end
                    out[#out + 1] = { type = 'submenu', label = tostring(gr.label), icon = 'crown', submenu = { id = idPrefix .. '.perms.' .. bi .. '.' .. gi, title = tostring(gr.label), subtitle = 'Droits du grade', items = rows } }
                end
            end
        elseif b.type == 'notice' then
            out[#out + 1] = { label = short(b.text, 46), icon = 'info', description = tostring(b.text or ''), disabled = true }
        elseif b.type == 'cards' then
            for _, c in ipairs(b.items or {}) do out[#out + 1] = { label = tostring(c.title or ''), right = tostring(c.value or ''), description = c.sub and tostring(c.sub) or nil, disabled = true } end
        elseif b.type == 'table' then
            if b.title then out[#out + 1] = { type = 'separator', label = short(b.title, 40) } end
            local cols = b.columns or {}
            local rows = b.rows or {}
            if #rows == 0 then out[#out + 1] = { label = short(b.empty or 'Rien à afficher', 46), disabled = true, description = b.empty } end
            for ri, r in ipairs(rows) do
                local first = cols[1] and r[cols[1].k]
                local label = tostring(r.label or first or '')
                local det = {}
                for _, c in ipairs(cols) do local v = r[c.k] if v ~= nil and v ~= '' and tostring(v) ~= label then det[#det + 1] = c.label .. ' : ' .. tostring(v) end end
                local acts = {}
                for ai, a in ipairs(r.actions or {}) do acts[#acts + 1] = actItem(a, onAct, idPrefix .. '.r' .. bi .. '.' .. ri .. '.c' .. ai) end
                if #acts > 0 then
                    out[#out + 1] = { type = 'submenu', label = short(label, 40), right = r.state and tostring(r.state) or nil, description = table.concat(det, ' · '),
                        submenu = { id = idPrefix .. '.r' .. bi .. '.' .. ri, title = short(label, 30), items = acts } }
                else
                    out[#out + 1] = { label = short(label, 40), right = r.state and tostring(r.state) or (cols[2] and r[cols[2].k] and short(r[cols[2].k], 18)) or nil, description = table.concat(det, ' · '), disabled = true }
                end
            end
        elseif b.type == 'actions' then
            if b.title then out[#out + 1] = { type = 'separator', label = short(b.title, 40) } end
            for ai, a in ipairs(b.items or {}) do out[#out + 1] = actItem(a, onAct, idPrefix .. '.a' .. bi .. '.' .. ai) end
        elseif b.type == 'form' then
            local vals = {}
            local items = {}
            local okFields = true
            for _, f in ipairs(b.fields or {}) do
                if f.type == 'select' then
                    local names = {}
                    for _, o in ipairs(f.opts or {}) do names[#names + 1] = short(type(o) == 'table' and (o[2] or o[1]) or o, 34) end
                    if #names == 0 then okFields = false items[#items + 1] = { label = tostring(f.label), right = 'Aucun choix', disabled = true }
                    else
                        vals[f.k] = type(f.opts[1]) == 'table' and f.opts[1][1] or f.opts[1]
                        items[#items + 1] = { type = 'list', label = tostring(f.label), list = names, index = 1, description = '← → pour choisir.',
                            onChange = function(_, _, i) local o = f.opts[i] vals[f.k] = type(o) == 'table' and o[1] or o end }
                    end
                else
                    items[#items + 1] = { type = 'input', label = tostring(f.label), maxlen = tonumber(f.maxlen) or 40, description = 'Entrée : écrire.',
                        onSelect = function(_, text) vals[f.k] = f.type == 'number' and tonumber(text) or text end }
                end
            end
            local sub = b.submit or {}
            items[#items + 1] = { label = tostring(sub.label or 'Valider'), icon = 'check', disabled = (sub.disabled == true) or not okFields, onSelect = function() onAct(sub.act, vals) end }
            out[#out + 1] = { type = 'submenu', label = short(b.title or 'Formulaire', 40), icon = 'edit', description = b.desc and tostring(b.desc) or nil,
                submenu = { id = idPrefix .. '.f' .. bi, title = short(b.title or 'Formulaire', 30), subtitle = b.desc and short(b.desc, 40) or nil, items = items } }
        end
    end
    if #out == 0 then out[1] = { label = 'Rien à afficher', disabled = true } end
    return out
end
