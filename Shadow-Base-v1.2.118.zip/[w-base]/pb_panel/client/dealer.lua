-- Concession tenue par des joueurs (server/game/shops.lua) : le vendeur choisit le véhicule à essayer / vendre ; le client accepte l'offre.
local G = PBG
local function money(n) return G.money and G.money(n) or (tostring(n) .. ' $') end
local function vehicleItems(list, t, mode)
    local items, cats = {}, {}
    for _, v in ipairs(list or {}) do
        local c = (v.category and v.category ~= '') and v.category or 'Autres'
        if not cats[c] then cats[c] = {} items[#items + 1] = { type = 'separator', label = c } end
        items[#items + 1] = { label = v.label, right = money(v.price), icon = 'car', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:dealer:act', t, v.model, mode) end }
    end
    if #items == 0 then items[1] = { label = 'Aucun véhicule au catalogue', disabled = true } end
    return items
end
RegisterNetEvent('pb:g:dealer:menu', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local items = vehicleItems(d.list, d.t, d.mode)
    G.Menu.Open({ id = 'dealer.pick', title = d.mode == 'sell' and 'Vendre un véhicule' or 'Faire essayer', subtitle = tostring(d.shop or ''), items = items })
end)
RegisterNetEvent('pb:g:dealer:offer', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local done = false
    local function answer(ok) if done then return end done = true G.Menu.Close() TriggerServerEvent('pb:g:dealer:answer', d.token, ok) end
    G.Menu.Open({ id = 'dealer.offer', title = tostring(d.shop or 'Concession'), subtitle = 'Facture du vendeur', items = {
        { label = tostring(d.label or ''), right = money(d.price), icon = 'car', disabled = true },
        { type = 'button', label = 'Payer la facture', icon = 'check', description = 'Le véhicule est à toi : plaque à ton nom, il apparaît devant la concession.', onSelect = function() answer(true) end },
        { type = 'button', label = 'Refuser', icon = 'x', onSelect = function() answer(false) end },
    } })
end)

-- Catalogue : l'écran de la concession, le serveur vérifie qu'on est bien au point
RegisterNetEvent('pb:g:dealer:opencat', function(id) TriggerServerEvent('pb:g:shop:open', id) end)

-- Poste du vendeur : le client, puis le véhicule ou le montant
RegisterNetEvent('pb:g:dealer:desk', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local function clientsMenu(id, title, onPick)
        local items = {}
        for _, c in ipairs(d.clients or {}) do items[#items + 1] = onPick(c) end
        if #items == 0 then items[1] = { label = 'Aucun client à moins de 10 m', disabled = true } end
        return { id = id, title = title, subtitle = 'Choisis le client', items = items }
    end
    local function vehicles(id, title, mode)
        return clientsMenu(id, title, function(c)
            return { type = 'submenu', label = tostring(c.name), icon = 'user', submenu = { id = id .. '.' .. c.id, title = title, subtitle = tostring(c.name), items = vehicleItems(d.list, c.id, mode) } }
        end)
    end
    local bill = clientsMenu('dealer.desk.bill', 'Envoyer une facture', function(c)
        return { label = tostring(c.name), icon = 'user', onSelect = function()
            local amount = tonumber(G.Menu.Ask('Montant de la facture', '', 9))
            if not amount then return end
            local reason = G.Menu.Ask('Motif', '', 80)
            if not reason or reason == '' then return end
            G.Menu.Close()
            TriggerServerEvent('pb:g:dealer:bill', c.id, amount, reason)
        end }
    end)
    G.Menu.Open({ id = 'dealer.desk', title = 'Poste du vendeur', subtitle = tostring(d.shop or ''), nosearch = true, items = {
        { type = 'submenu', label = 'Vendre un véhicule', icon = 'coins', description = 'Le client reçoit la facture : il paie, le véhicule est à lui.', submenu = vehicles('dealer.desk.sell', 'Vendre un véhicule', 'sell') },
        { type = 'submenu', label = 'Faire essayer', icon = 'car', description = 'Le client part en essai à la sortie des véhicules.', submenu = vehicles('dealer.desk.test', 'Faire essayer', 'test') },
        { type = 'submenu', label = 'Envoyer une facture', icon = 'file', description = "Un montant et un motif : l'argent va dans la caisse de l'entreprise.", submenu = bill },
        { label = 'Actualiser les clients', icon = 'user', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:points:use', d.point) end },
    } })
end)

-- Builder : où les véhicules du catalogue s'affichent, ou sortent d'une location (d.ev : l'événement qui reçoit la position). ← → tourner · ↑ ↓ plus loin / plus près · E poser · Retour arrière : annuler
local placingView = false
function G.VehSpotBusy() return placingView end
RegisterNetEvent('pb:g:dealer:placeview', function(j)
    local d = G.decode(j)
    if not d or placingView then return end
    placingView = true
    CreateThread(function()
        Wait(600)   -- le temps que la liste du Builder revienne
        local hash = joaat('adder')
        RequestModel(hash)
        local t = GetGameTimer() + 4000
        while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
        if not HasModelLoaded(hash) then placingView = false return end
        if G.Menu.Suspend then G.Menu.Suspend() end
        local c = GetEntityCoords(PlayerPedId())
        local e = CreateVehicle(hash, c.x, c.y, c.z - 50.0, 0.0, false, false)
        SetModelAsNoLongerNeeded(hash)
        SetEntityAlpha(e, 170, false)
        SetEntityCollision(e, false, false)
        FreezeEntityPosition(e, true)
        G.send('prompt', { show = true, free = true, key = 'E', text = tostring(d.title or 'Où afficher les véhicules') .. " : va à l'endroit voulu  ·  ← → tourner  ·  ↑ ↓ plus loin / plus près  ·  Retour arrière : annuler" })
        local dist, turn, pos, h = 6.0, 90.0, nil, nil
        while true do
            Wait(0)
            for _, k in ipairs({ 172, 173, 174, 175, 200 }) do DisableControlAction(0, k, true) end
            if IsDisabledControlPressed(0, 174) then turn = turn + 1.5 end
            if IsDisabledControlPressed(0, 175) then turn = turn - 1.5 end
            if IsDisabledControlPressed(0, 172) then dist = math.min(25.0, dist + 0.05) end
            if IsDisabledControlPressed(0, 173) then dist = math.max(3.0, dist - 0.05) end
            local me = PlayerPedId()
            local mc, r = GetEntityCoords(me), math.rad(GetEntityHeading(me))
            local x, y = mc.x - math.sin(r) * dist, mc.y + math.cos(r) * dist
            local ok, gz = GetGroundZFor_3dCoord(x, y, mc.z + 1.0, false)
            local z = ((ok and math.abs(gz - mc.z) < 4.0) and gz or (mc.z - 1.0)) + 0.6
            local ph = (GetEntityHeading(me) + turn) % 360.0
            SetEntityCoordsNoOffset(e, x, y, z, false, false, false)
            SetEntityHeading(e, ph)
            if IsControlJustPressed(0, 38) then pos, h = vector3(x, y, z), ph break
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then break end
        end
        if DoesEntityExist(e) then DeleteEntity(e) end
        G.send('prompt', { show = false })
        if G.Menu.Resume then G.Menu.Resume() end
        placingView = false
        if pos then TriggerServerEvent(d.ev or 'pb:g:dealer:setview', d.id, pos.x, pos.y, pos.z, h)
        else G.send('notify', { type = 'warn', title = 'Builder', text = d.cancel or "Emplacement non choisi : tant qu'il manque, les véhicules s'affichent à la sortie. « Refaire l'emplacement d'exposition » permet de le poser." }) end
    end)
end)
