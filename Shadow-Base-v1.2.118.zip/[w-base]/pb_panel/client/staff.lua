-- Menu staff (F10) : le serveur envoie la liste des actions autorisées, ce fichier en fait un menu « RageUI » et exécute les effets
-- (téléportation, noclip, véhicules…) que le serveur a autorisés. Rien n'est décidé ici : une action refusée par le serveur ne produit aucun effet.
local G = PBG
local spec = nil
local dutyOn, graceUntil, godApplied = false, 0, false   -- invincibilité du staff (voir refreshGod)
local self = {}                     -- outils actifs (noclip, god, invisible, names, speed)
local spectating = false

-- le serveur ignore deux actions à moins de 250 ms : on espace les envois au lieu de les perdre (sinon une case cochée revenait en arrière)
local nextSend = 0
local function send(id, payload)
    local now = GetGameTimer()
    local at = math.max(now, nextSend)
    nextSend = at + 300
    if at == now then TriggerServerEvent('pb:g:staff:act', id, payload or {})
    else SetTimeout(at - now, function() TriggerServerEvent('pb:g:staff:act', id, payload or {}) end) end
end
local function note(t, text) G.send('notify', { type = t, title = 'Menu staff', text = text }) end
G.StaffSpec = function() return spec end
G.StaffSend = function(id, payload) send(id, payload) end   -- (v1.2.98) pour les autres fichiers du menu staff
G.StaffCat = G.StaffCat or {}           -- id de catégorie -> function(spec, send) items
G.StaffPlayerExtra = G.StaffPlayerExtra or {}   -- function(pl, spec, send) -> liste d'entrées ajoutées à la fiche d'un joueur   -- (v1.2.43) dernière liste du serveur (Builder › Ascenseurs)

local PL = {
    info = { 'Informations', "Argent, métier, ping et nombre de sanctions.", 'search' },
    history = { 'Historique complet', 'Sanctions, reports, notes, police, actions du staff et retours en arrière, sur une seule page.', 'history' },
    ['goto'] = { 'Aller sur le joueur', 'Te téléporte à côté de lui.', 'arrowr' },
    bring = { 'Ramener à moi', 'Le téléporte à toi.', 'arrowl' },
    heal = { 'Soigner / Réanimer', 'Remet la santé, la faim, la soif et le stress.', 'heart' },
    revive = { 'Réanimer', 'Relève la personne à terre.', 'heart' },
    freeze = { 'Freeze', "Bloque ou libère ses déplacements.", 'freeze' },
    spectate = { 'Observer (mini-écran)', 'Ouvre un mini-écran de ce joueur : plusieurs joueurs possibles, /ecrans pour les déplacer. Relance pour fermer.', 'eye' },
    spectate_full = { 'Observer en plein écran', 'Ta caméra suit ce joueur. Relance pour arrêter.', 'eye' },
    message = { 'Envoyer un message', 'Notification visible par lui seul.', 'chat' },
    whisper = { 'Chuchoter', 'Parle à lui seul, sans casser la scène RP.', 'chat' },
    cash = { 'Espèces', 'Donner (montant positif) ou retirer (négatif).', 'wallet' },
    bank = { 'Banque', 'Donner (montant positif) ou retirer (négatif).', 'card' },
    veh_owned = { 'Véhicules du joueur', 'Voir ses véhicules et en supprimer un définitivement.', 'engine' },
    coins = { 'Coins de la boutique', 'Donner (montant positif) ou retirer (négatif), avec un motif. Tracé.', 'coins' },
    item = { 'Donner un objet', 'Recherche par nom simplifié ou technique, puis quantité.', 'bag' },
    job = { 'Entreprise (emploi 1)', "Choisis une catégorie, l'entreprise, puis le grade.", 'building' },
    job2 = { 'Deuxième emploi', "Même chose pour son second emploi.", 'building' },
    gang = { 'Gang', 'Choisis le gang puis le grade.', 'users' },
    setrank = { 'Grade staff', 'Donne ou retire un grade du staff.', 'shield' },
    warn = { 'Avertir', "Enregistré dans son casier et affiché à l'écran.", 'alert' },
    kick = { 'Expulser (kick)', 'Le déconnecte avec le motif.', 'kickout' },
    ban = { 'Bannir', 'Ouvre la fenêtre : raison et durée.', 'banned' },
    mute = { 'Réduire au silence', "Bloque son chat. Relance pour lever la sanction.", 'chat' },
    note = { 'Ajouter une note', 'Note privée, visible par le staff seulement.', 'file' },
    notes = { 'Lire les notes', 'Les dernières notes du staff sur ce joueur.', 'file' },
    inv_view = { "Voir l'inventaire", 'Ouvre son vrai inventaire. Seul le fondateur peut prendre ses objets.', 'bag' },
    inv_clear = { "Vider l'inventaire", 'Supprime tous ses objets (irréversible).', 'x' },
    mortrp = { 'Mort RP', "À sa prochaine balle reçue, son personnage meurt pour de bon : écran MORT RP, objets donnés ces 24 h retirés, données effacées, expulsé au bout de 10 s. Relance pour annuler.", 'alert' },
    ata_give = { 'Mettre au repos', "Minutes sans arme ni course (comme après une réapparition à l'hôpital).", 'clock' },
    ata_remove = { 'Lever le repos', 'Il peut de nouveau sortir une arme et courir.', 'check' },
    rollback = { 'Retour en arrière', "Ses sauvegardes des dernières 48 h (sac et argent) : choisis l'heure et restaure.", 'undo' },
    register = { 'Register (refaire le personnage)', "Expulsé, il refait identité et apparence à la reconnexion. Argent, objets, véhicules et logements gardés.", 'refresh' },
    wipe = { 'Wipe (effacer le personnage)', "Expulsé, et tout son personnage est effacé : identité, argent, objets, véhicules, logements, emploi. Le compte reste (bans, VIP, coins).", 'trash' },
    newbie_clear = { 'Lever la protection nouveau', "Fin de ses 30 minutes de protection : armes, actions et collisions comme tout le monde.", 'check' },
    jail = { 'Envoyer en prison', 'Minutes puis motif.', 'lock' },
    unjail = { 'Libérer de prison', 'Met fin à sa peine (prison ou TIG) et le ramène à la sortie.', 'check' },
    vip_give = { 'Donner le VIP', 'Durée en jours (0 = permanent). Prolonge un VIP en cours.', 'crown' },
    vip_remove = { 'Retirer le VIP', 'Il perd ses avantages VIP tout de suite.', 'x' },
    give_vehicle = { 'Donner un véhicule', 'Ajoute un véhicule à son garage.', 'engine' },
    feed = { 'Nourrir', 'Faim et soif au maximum, stress à zéro.', 'food' },
    uncuff = { 'Démenotter / délier', "Retire les menottes de la police ou les liens d'une organisation, et arrête l'escorte.", 'key' },
    armor = { 'Donner un gilet', 'Gilet pare-balles au maximum.', 'shield' },
    weapon = { 'Donner une arme', 'Liste des armes, puis le nombre de munitions. Elle arrive dans son inventaire.', 'crosshair' },
    strip = { 'Retirer les armes', 'Lui retire toutes ses armes.', 'x' },
    slap = { 'Projeter en l\'air', 'Une petite claque pour attirer son attention.', 'bolt' },
    kill = { 'Mettre à terre', 'Le met à terre (il peut être réanimé).', 'alert' },
    leave_veh = { 'Sortir du véhicule', 'Le fait descendre de force.', 'engine' },
}

local function askAll(inputs, payload)
    for _, inp in ipairs(inputs or {}) do
        local v = G.Menu.Ask(inp.label, '', inp.maxlen or 60)
        if (v == nil or v == '') and not inp.optional then return false end
        payload[inp.k] = inp.number and tonumber(v) or v
    end
    return true
end


local function bizPicker(pl, actionId, withNone)
    local byCat, cats = {}, {}
    for _, b in ipairs(spec.bizlist or {}) do byCat[b.cat] = byCat[b.cat] or {} table.insert(byCat[b.cat], b) end
    for _, c in ipairs(spec.bizcats or {}) do
        local list = byCat[c.id]
        if list and #list > 0 then
            local sub = {}
            for _, b in ipairs(list) do
                local gs = {}
                for _, g in ipairs(b.grades or {}) do
                    gs[#gs + 1] = { label = g[2], right = 'Grade ' .. g[1], onSelect = function() send(actionId, { id = pl.id, biz = b.id, grade = g[1] }) end }
                end
                sub[#sub + 1] = { type = 'submenu', label = b.label, submenu = { id = 'staff.' .. actionId .. '.' .. pl.id .. '.' .. b.id, title = b.label, subtitle = 'Choisis le grade', items = gs } }
            end
            cats[#cats + 1] = { type = 'submenu', label = c.label, badge = tostring(#list), submenu = { id = 'staff.' .. actionId .. '.' .. pl.id .. '.c.' .. c.id, title = c.label, subtitle = 'Choisis l\'entreprise', items = sub } }
        end
    end
    if withNone ~= false then table.insert(cats, 1, { label = 'Aucun (retirer)', icon = 'x', onSelect = function() send(actionId, { id = pl.id, biz = 'none' }) end }) end
    if #cats == 0 then cats[1] = { label = 'Aucune entreprise', description = 'Crée-en dans le panel › Entreprises.', disabled = true } end
    return { id = 'staff.' .. actionId .. '.' .. pl.id, title = 'Entreprise', subtitle = pl.name, items = cats }
end
local function gangPicker(pl)
    local items = { { label = 'Aucun (quitter son gang)', icon = 'x', onSelect = function() send('gang', { id = pl.id, gang = 'none' }) end } }
    for _, g in ipairs(spec.ganglist or {}) do
        local gs = {}
        for i, name in ipairs(spec.gangGrades or {}) do gs[#gs + 1] = { label = name, right = 'Grade ' .. i, onSelect = function() send('gang', { id = pl.id, gang = g[1], grade = i }) end } end
        items[#items + 1] = { type = 'submenu', label = g[2], submenu = { id = 'staff.gang.' .. pl.id .. '.' .. g[1], title = g[2], subtitle = 'Choisis le grade', items = gs } }
    end
    if #items == 1 then items[2] = { label = 'Aucun gang défini', description = 'Crée-en dans le panel › Gangs.', disabled = true } end
    return { id = 'staff.gang.' .. pl.id, title = 'Gang', subtitle = pl.name, items = items }
end
local function rankPicker(pl)
    local items = { { label = 'Aucun grade (retirer)', icon = 'x', onSelect = function() send('setrank', { id = pl.id, grade = 'none' }) end } }
    for _, g in ipairs(spec.gradeList or {}) do items[#items + 1] = { label = g.label, right = g.name, onSelect = function() send('setrank', { id = pl.id, grade = g.name }) end } end
    return { id = 'staff.rank.' .. pl.id, title = 'Grade staff', subtitle = pl.name, items = items }
end
local function weaponPicker(pl)
    local byCat, order = {}, {}
    for _, w in ipairs(spec.weapons or {}) do
        if not byCat[w[3]] then byCat[w[3]] = {} order[#order + 1] = w[3] end
        table.insert(byCat[w[3]], { label = w[2], right = w[4] ~= '' and 'munitions' or nil, onSelect = function()
            local n = 0
            if w[4] ~= '' then
                local v = G.Menu.Ask('Munitions à donner (0 = aucune)', '', 5)
                if v == nil then return end
                n = tonumber(v) or 0
            end
            send('weapon', { id = pl.id, name = w[1], ammo = n })
        end })
    end
    local items = {}
    for _, c in ipairs(order) do items[#items + 1] = { type = 'submenu', label = c, badge = tostring(#byCat[c]), submenu = { id = 'staff.w.' .. pl.id .. '.' .. c, title = c, subtitle = pl.name, items = byCat[c] } } end
    if #items == 0 then items[1] = { label = 'Aucune arme', disabled = true } end
    return { id = 'staff.w.' .. pl.id, title = 'Donner une arme', subtitle = pl.name, items = items }
end
-- Donner un objet : recherche en direct (nom simplifié OU nom technique, accents et majuscules ignorés) + catégories.
local FOLD = { ['é'] = 'e', ['è'] = 'e', ['ê'] = 'e', ['ë'] = 'e', ['à'] = 'a', ['â'] = 'a', ['ä'] = 'a', ['î'] = 'i', ['ï'] = 'i', ['ô'] = 'o', ['ö'] = 'o', ['ù'] = 'u', ['û'] = 'u', ['ü'] = 'u', ['ç'] = 'c', ['œ'] = 'oe', ['É'] = 'e', ['È'] = 'e', ['À'] = 'a', ['Ç'] = 'c', ['\'' ] = ' ', ['’'] = ' ' }
local function fold(t) t = tostring(t or ''):lower() for k, v in pairs(FOLD) do t = t:gsub(k, v) end return (t:gsub('[_%-]', ' ')) end
G.FoldText = fold
local function itemMatches(it, words)
    local hay = fold(it[2]) .. ' ' .. fold(it[1]) .. ' ' .. fold(it[3])
    for _, w in ipairs(words) do if not hay:find(w, 1, true) then return false end end
    return true
end
local function giveItemTo(pl, it)
    local v = G.Menu.Ask(('Quantité de « %s »'):format(it[2]), '1', 4)
    if v == nil then return end
    local q = math.floor(tonumber(v) or 0)
    if q < 1 then G.send('notify', { type = 'warn', title = 'Objet', text = 'Quantité invalide.' }) return end
    send('item', { id = pl.id, item = it[1], qty = q })
end
-- (v1.2.45) sélecteur d'objets réutilisable : list = { { nom technique, nom simplifié, catégorie, description }, … }
-- o = { id, title, subtitle, onPick = function(it) } ; sert au staff (donner un objet) et au Builder (objet offert par une zone)
function G.ItemPicker(list, o)
    list = list or {}
    local function row(it) return { label = it[2], right = it[1], description = ('Nom technique : %s · %s%s'):format(it[1], it[3], ((it[4] or '') ~= '' and (' · ' .. it[4]) or '')), icon = 'bag', onSelect = function() o.onPick(it) end } end
    local query = ''
    local byCat, order = {}, {}
    for _, it in ipairs(list) do
        if not byCat[it[3]] then byCat[it[3]] = {} order[#order + 1] = it[3] end
        table.insert(byCat[it[3]], it)
    end
    table.sort(order)
    return { id = o.id, title = o.title, subtitle = o.subtitle or (#list .. ' objets'), refreshOnReturn = true, build = function()
        local items = { { type = 'input', label = 'Rechercher', value = query ~= '' and query or nil, maxlen = 40, icon = 'search',
            description = 'Entrée pour taper : une partie du nom simplifié ou du nom technique (ex. « eau » ou « water »). Vide = toutes les catégories.',
            onChange = function(_, text) query = tostring(text or ''):gsub('^%s+', ''):gsub('%s+$', '') G.Menu.Refresh() end } }
        if query ~= '' then
            local words = {}
            for w in fold(query):gmatch('%S+') do words[#words + 1] = w end
            local n = 0
            for _, it in ipairs(list) do
                if itemMatches(it, words) then
                    n = n + 1
                    if n <= 120 then items[#items + 1] = row(it) end
                end
            end
            if n == 0 then items[#items + 1] = { label = 'Aucun objet pour « ' .. query .. ' »', description = 'Essaie un autre mot, ou une partie du nom technique.', disabled = true }
            elseif n > 120 then items[#items + 1] = { label = ('%d autres résultats : précise ta recherche'):format(n - 120), disabled = true } end
            items[#items + 1] = { label = 'Effacer la recherche', icon = 'x', onSelect = function() query = '' G.Menu.Refresh() end }
            return items
        end
        items[#items + 1] = { type = 'separator', label = 'Catégories' }
        for _, c in ipairs(order) do
            local rows = {}
            for _, it in ipairs(byCat[c]) do rows[#rows + 1] = row(it) end
            items[#items + 1] = { type = 'submenu', label = c, badge = tostring(#rows), submenu = { id = o.id .. '.' .. c, title = c, subtitle = o.subtitle, items = rows } }
        end
        if #order == 0 then items[#items + 1] = { label = "Aucun objet défini (panel › Inventaire › Objets)", disabled = true } end
        return items
    end }
end
-- revient au menu `id` après un choix fait dans un sous-menu (catégorie -> objet)
function G.MenuBackTo(id)
    for _ = 1, 8 do
        local m = G.Menu.Stack and G.Menu.Stack:Current()
        if not m or m.def.id == id then return end
        G.Menu.Stack:Back()
    end
end
local function itemPicker(pl)
    return G.ItemPicker(spec.items or {}, { id = 'staff.item.' .. pl.id, title = 'Donner un objet', subtitle = pl.name, onPick = function(it) giveItemTo(pl, it) end })
end
-- (v1.2.86) Donner un véhicule : les voitures perms (avec aperçu), ou un autre modèle tapé à la main
local function carPicker(pl)
    local items = {}
    for _, c in ipairs(spec.permcars or {}) do
        if IsModelInCdimage(joaat(c[1])) then
            items[#items + 1] = { label = c[2], right = c[1], model = c[1], description = 'Voiture perm : elle va directement dans son garage.', onSelect = function()
                G.Menu.ConfirmTwice(c[2], 'Donner ce véhicule à ' .. pl.name .. ' ?', function() send('give_vehicle', { id = pl.id, model = c[1], label = c[2] }) end)
            end }
        end
    end
    if #items == 0 then items[1] = { label = 'Aucune voiture perm sur ce serveur', disabled = true, description = 'Liste dans le panel : Menu staff › Réglages › Voitures perms.' } end
    items[#items + 1] = { type = 'separator', label = 'Autre' }
    items[#items + 1] = { label = 'Autre modèle…', icon = 'edit', description = 'Tape le nom du modèle (ex. sultan).', onSelect = function()
        local m = G.Menu.Ask('Modèle du véhicule', '', 32)
        if m and m ~= '' then send('give_vehicle', { id = pl.id, model = m }) end
    end }
    return G.VehPreview.Wrap({ id = 'staff.car.' .. pl.id, title = 'Donner un véhicule', subtitle = pl.name, items = items })
end
local PICK = { item = itemPicker, give_vehicle = carPicker, job = function(pl) return bizPicker(pl, 'job') end, job2 = function(pl) return bizPicker(pl, 'job2') end, gang = gangPicker, setrank = rankPicker, weapon = weaponPicker }

-- (v1.2.56) fiche du joueur : rangée par sections, actions sensibles en rouge
local PL_SECTIONS = {
    { 'Informations', { 'info', 'history', 'notes', 'note', 'inv_view' } },
    { 'Téléportation & état', { 'goto', 'bring', 'heal', 'revive', 'freeze', 'spectate', 'spectate_full', 'feed', 'armor', 'uncuff', 'leave_veh', 'slap' } },
    { 'Communication', { 'message', 'whisper' } },
    { 'Argent & objets', { 'cash', 'bank', 'coins', 'item', 'weapon', 'give_vehicle', 'veh_owned' } },
    { 'Emploi & statut', { 'job', 'job2', 'gang', 'setrank', 'vip_give', 'vip_remove', 'ata_remove', 'newbie_clear', 'unjail' } },
    { 'Retour en arrière', { 'rollback' } },
    { 'Sanctions', { 'warn', 'mute', 'jail', 'ata_give', 'strip', 'inv_clear', 'kill', 'register', 'wipe', 'mortrp', 'kick', 'ban' } },
}
local PL_DANGER = { warn = true, mute = true, jail = true, ata_give = true, strip = true, inv_clear = true, kill = true, register = true, wipe = true, mortrp = true, kick = true, ban = true, vip_remove = true }
local function money(n)
    local s = tostring(math.floor(tonumber(n) or 0))
    local neg = s:sub(1, 1) == '-'
    if neg then s = s:sub(2) end
    s = s:reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')
    return (neg and '-' or '') .. s .. ' $'
end
-- Fenêtre « Bannir » (web/game/rmenu.js) : attend la réponse du staff
local banBox
G.nui['staffban.done'] = function(d) if banBox then banBox.done, banBox.res = true, d end return {} end
local function banDialog(pl)
    local durs, def = {}, 1
    for i, d in ipairs(spec.bans_presets or {}) do
        durs[i] = d[1]
        if tostring(d[1]):lower():find('7 j', 1, true) then def = i end
    end
    if #durs == 0 then note('warn', 'Aucune durée de bannissement configurée.') return end
    local box = { done = false }
    banBox = box
    local mouse = G.Menu.Style() ~= 'ui'   -- le menu à flèches n'a pas la souris : on la donne le temps de la fenêtre
    if mouse then G.focus(true) end
    G.send('staffban.open', { name = pl.name, durs = durs, def = def })
    local t = GetGameTimer() + 180000
    while not box.done and GetGameTimer() < t and G.Menu.IsOpen() do Wait(50) end
    if not box.done then G.send('staffban.close', {}) end
    banBox = nil
    if mouse then G.focus(false) end
    local r = box.res
    if r and r.ok and tostring(r.reason or '') ~= '' then send('ban', { id = pl.id, duration = tostring(r.duration), reason = tostring(r.reason) }) end
end

local function playerMenu(pl)
    local items, byAct = {}, {}
    for _, a in ipairs(spec.pactions or {}) do
        if not ((a.id == 'jail' and pl.jailed) or (a.id == 'unjail' and not pl.jailed) or (a.id == 'vip_remove' and not pl.vip)) then
            local meta = PL[a.id] or { a.id, '', 'star' }
            local locked = a.rank and not pl.rank
            local it = { aid = a.id, label = meta[1], description = locked and 'Ce joueur a un rang égal ou supérieur au tien.' or meta[2], icon = meta[3], disabled = locked or nil, danger = PL_DANGER[a.id] }
            if a.pickBan then
                it.right, it.onSelect = '›', function() banDialog(pl) end
            elseif a.id == 'freeze' then
                it.type, it.checked = 'checkbox', pl.frozen == true
                it.onChange = function(_, v) pl.frozen = v or nil send('freeze', { id = pl.id }) end
            elseif PICK[a.id] and not locked and (a.id ~= 'item' or (spec.items and #spec.items > 0)) then
                it.type, it.submenu = 'submenu', PICK[a.id](pl)
            else
                it.onSelect = function()
                    local p = { id = pl.id }
                    if a.id == 'register' or a.id == 'wipe' then   -- (v1.2.89) double confirmation
                        G.Menu.ConfirmTwice(pl.name, a.id == 'wipe' and 'Effacer définitivement son personnage ?' or 'Lui faire refaire son personnage ?', function() send(a.id, p) end)
                        return
                    end
                    if a.id == 'spectate' then p.mini = true end
                    if askAll(a.inputs, p) then send(a.id, p) end
                end
            end
            byAct[a.id] = it
        end
    end
    local placed = {}
    for _, sec in ipairs(PL_SECTIONS) do
        local rows = {}
        if sec[1] == 'Informations' and byAct.info then
            local function fiche() send('info', { id = pl.id }) end
            rows[1] = { label = 'Métier', icon = 'job', right = pl.job and (pl.job .. ((pl.grade or '') ~= '' and (' · ' .. pl.grade) or '')) or 'Sans emploi', description = 'Entreprise et grade. Entrée : fiche complète.', onSelect = fiche }
            local j = pl.jail
            rows[#rows + 1] = { label = 'Prison', icon = 'lock', right = j and (j.kind == 'tig' and ('TIG : ' .. j.remaining .. ' tâche(s)') or (math.ceil(j.remaining / 60) .. ' min')) or 'Non', description = j and ('Motif : ' .. j.reason) or "N'est pas en prison.", onSelect = fiche }
            rows[#rows + 1] = { label = 'Repos (ATA)', icon = 'clock', right = (pl.ata or 0) > 0 and (math.ceil(pl.ata / 60) .. ' min') or 'Non', description = (pl.ata or 0) > 0 and 'Ni arme, ni course pendant ce temps.' or "N'est pas au repos.", onSelect = fiche }
            rows[2] = { label = 'Argent / Banque', icon = 'money', right = money(pl.cash) .. ' · ' .. money(pl.bank), description = 'Espèces et compte en banque. Entrée : fiche complète.', onSelect = fiche }
        end
        for _, id in ipairs(sec[2]) do
            if byAct[id] then rows[#rows + 1] = byAct[id] placed[id] = true end
        end
        if #rows > 0 then
            items[#items + 1] = { type = 'separator', label = sec[1] }
            for _, r in ipairs(rows) do items[#items + 1] = r end
        end
    end
    local others = {}
    for _, a in ipairs(spec.pactions or {}) do if byAct[a.id] and not placed[a.id] then others[#others + 1] = byAct[a.id] end end
    if spec.gestures and #spec.gestures > 0 then
        local themes = {}
        for _, th in ipairs(spec.gestures) do
            local sub = {}
            for _, g in ipairs(th.items or {}) do
                sub[#sub + 1] = { label = g.label, description = pl.rank and g.desc or 'Ce joueur a un rang égal ou supérieur au tien.', disabled = (not pl.rank) or nil, onSelect = function()
                    local p = { id = pl.id }
                    if askAll(g.inputs, p) then send(g.id, p) end
                end }
            end
            themes[#themes + 1] = { type = 'submenu', label = th.label, icon = 'star', badge = tostring(#sub), submenu = { id = 'staff.g.' .. th.id .. '.' .. pl.id, title = th.label, subtitle = pl.name, items = sub } }
        end
        others[#others + 1] = { type = 'submenu', label = 'Gestes', icon = 'star', description = 'Vie, déplacement, apparence, animations, médias, troll, véhicule, écran.', submenu = { id = 'staff.gs.' .. pl.id, title = 'Gestes', subtitle = pl.name, items = themes } }
    end
    for _, fn in ipairs(G.StaffPlayerExtra) do   -- (v1.2.98) motifs prêts, comptes liés, surveillance…
        local ok, extra = pcall(fn, pl, spec, send)
        if ok and type(extra) == 'table' then for _, e in ipairs(extra) do others[#others + 1] = e end end
    end
    if #others > 0 then
        items[#items + 1] = { type = 'separator', label = 'Autres' }
        for _, r in ipairs(others) do items[#items + 1] = r end
    end
    return { id = 'staff.p.' .. pl.id, title = 'Actions', head = { crumb = 'Administration › Joueurs', name = pl.name, badge = 'ID ' .. tostring(pl.uid or pl.id) }, items = items }
end

-- (v1.2.43) Viseur staff : les actions les plus utilisées sur le joueur visé, puis « Toutes les actions »
local QUICK = { 'info', 'goto', 'bring', 'spectate', 'freeze', 'heal', 'revive', 'message', 'warn', 'kick', 'jail' }
local function quickMenu(pl)
    local full = playerMenu(pl)
    local byId = {}
    for _, it in ipairs(full.items) do if it.aid then byId[it.aid] = it end end
    local items = {}
    for _, id in ipairs(QUICK) do if byId[id] then items[#items + 1] = byId[id] end end
    items[#items + 1] = { type = 'separator', label = 'Plus' }
    items[#items + 1] = { type = 'submenu', label = 'Toutes les actions', icon = 'list', description = 'La fiche complète du joueur.', submenu = full }
    return { id = 'staff.aim.' .. pl.id, title = pl.name, subtitle = ('Viseur staff · #%d'):format(pl.uid or pl.id), banner = { text = 'Actions rapides' }, items = items }
end

-- Dossier d'un joueur, connecté ou non : tout ce que le serveur sait de lui, et ce qu'on peut faire
local cardData
local function can(id) return spec.can and spec.can[id] end
local function day(t) return (tonumber(t) or 0) > 0 and os.date('%d/%m/%Y', t) or 'jamais' end
local function cardItems()
    local c = cardData
    if not c then return { { label = 'Dossier indisponible', disabled = true } } end
    local function refresh() send('p_card', { license = c.license }) end
    local items = { { type = 'separator', label = 'Informations' },
        { label = 'État', icon = 'user', right = c.online and ('En ligne · ID ' .. c.online) or ('Hors ligne · vu le ' .. day(c.seen)), disabled = true },
        { label = 'ID permanent', icon = 'tag', right = c.uid and ('#' .. c.uid) or '—', description = c.license, disabled = true },
        { label = 'Espèces', icon = 'wallet', right = money(c.cash), disabled = true },
        { label = 'Banque', icon = 'card', right = money(c.bank), disabled = true },
        { label = 'Emploi', icon = 'building', right = c.job or 'Sans emploi', disabled = true },
        { label = 'Groupe', icon = 'users', right = c.gang or 'Aucun', disabled = true },
        { label = 'Prison', icon = 'lock', right = c.jail and (c.jail.kind == 'tig' and (c.jail.remaining .. ' tâche(s)') or (math.ceil(c.jail.remaining / 60) .. ' min')) or 'Non', description = c.jail and ('Motif : ' .. tostring(c.jail.reason) .. ' · par ' .. tostring(c.jail.by)) or nil, disabled = true },
        { label = 'Repos (ATA)', icon = 'clock', right = c.online and ((c.ata or 0) > 0 and (math.ceil(c.ata / 60) .. ' min') or 'Non') or 'Non (hors ligne)', description = "Le repos s'arrête à la déconnexion.", disabled = true },
        { label = 'Bannissement', icon = 'banned', right = c.ban and (c.ban.expires == 0 and 'Définitif' or ("Jusqu'au " .. day(c.ban.expires))) or 'Non', description = c.ban and ('Motif : ' .. tostring(c.ban.reason) .. ' · par ' .. tostring(c.ban.by)) or nil, disabled = true },
    }
    local function lines(title, list, icon, row)
        local sub = {}
        for _, x in ipairs(list or {}) do sub[#sub + 1] = row(x) end
        if #sub == 0 then sub[1] = { label = 'Aucun', disabled = true } end
        return { type = 'submenu', label = title, icon = icon, badge = tostring(#(list or {})), submenu = { id = 'staff.card.' .. icon, title = title, subtitle = c.name, items = sub } }
    end
    items[#items + 1] = lines('Véhicules', c.cars, 'engine', function(v) return { label = v.label, right = v.plate, disabled = true } end)
    items[#items + 1] = { label = 'Historique complet', icon = 'history', description = 'Sanctions, reports, notes, police, actions du staff et retours en arrière, du plus récent au plus ancien.', onSelect = function() send('p_timeline', { license = c.license }) end }
    items[#items + 1] = lines('Sanctions', c.sanctions, 'history', function(s) return { label = s.kind .. ' · ' .. tostring(s.reason), right = day(s.at), description = tostring(s.reason) .. ' · par ' .. tostring(s.by), disabled = true } end)
    if can('off_note') then items[#items + 1] = lines('Notes', c.notes, 'file', function(n) return { label = tostring(n.text), right = day(n.at), description = tostring(n.text) .. ' · par ' .. tostring(n.by), disabled = true } end) end
    if c.online then
        items[#items + 1] = { type = 'separator', label = 'Actions' }
        local live
        for _, pl in ipairs(spec.players or {}) do if pl.id == c.online then live = pl end end
        if live then items[#items + 1] = { type = 'submenu', label = 'Ouvrir sa fiche en direct', icon = 'arrowr', description = 'Toutes les actions sur un joueur connecté.', submenu = playerMenu(live) } end
    else
        items[#items + 1] = { type = 'separator', label = 'Actions' }
        local function act(id, label, icon, desc, inputs, extra, danger)
            if not can(id) then return end
            items[#items + 1] = { label = label, icon = icon, description = desc, danger = danger, onSelect = function()
                local p = { license = c.license }
                for k, v in pairs(extra or {}) do p[k] = v end
                if askAll(inputs, p) then send(id, p) end
            end }
        end
        act('off_note', 'Ajouter une note', 'file', 'Visible par le staff seulement.', { { k = 'text', label = 'Note privée', maxlen = 250 } })
        act('off_money', 'Espèces', 'wallet', 'Donner (positif) ou retirer (négatif). Tracé.', { { k = 'amount', label = 'Montant (négatif pour retirer)', number = true, maxlen = 9 } }, { field = 'cash' })
        act('off_money', 'Banque', 'card', 'Donner (positif) ou retirer (négatif). Tracé.', { { k = 'amount', label = 'Montant (négatif pour retirer)', number = true, maxlen = 9 } }, { field = 'bank' })
        act('off_warn', 'Avertir', 'alert', 'Enregistré dans son casier.', { { k = 'reason', label = 'Motif', maxlen = 120 } }, nil, true)
        if not c.jail then act('off_jail', 'Mettre en prison', 'lock', 'La peine commence à son retour, dans la prison du staff.', { { k = 'minutes', label = 'Minutes de prison', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } }, nil, true) end
    end
    if c.jail and can('unjail_license') then items[#items + 1] = { label = 'Libérer de prison', icon = 'check', description = 'Met fin à sa peine.', onSelect = function() send('unjail_license', { license = c.license }) refresh() end } end
    if c.ban then
        if can('unban') then items[#items + 1] = { label = 'Lever le bannissement', icon = 'check', description = 'Autorise à nouveau la connexion.', onSelect = function() send('unban', { sid = c.ban.id }) refresh() end } end
    elseif not c.online and can('ban_offline') then
        items[#items + 1] = { label = 'Bannir', icon = 'banned', danger = true, description = 'Motif et durée.', onSelect = function()
            local p = { license = c.license, who = c.license }
            if askAll({ { k = 'minutes', label = 'Durée en minutes (0 = définitif)', number = true, maxlen = 6 }, { k = 'reason', label = 'Motif', maxlen = 120 } }, p) then send('ban_offline', p) refresh() end
        end }
    end
    return items
end
RegisterNetEvent('pb:g:staff:card', function(j)
    cardData = G.decode(j)
    if not cardData then return end
    local cur = G.Menu.Stack and G.Menu.Stack:Current()
    if cur and cur.def.id == 'staff.card' then G.Menu.Refresh() return end
    G.Menu.Push({ id = 'staff.card', title = 'Dossier', head = { crumb = 'Administration › Joueurs', name = cardData.name, badge = cardData.uid and ('#' .. cardData.uid) or nil }, refreshOnReturn = true, build = cardItems })
end)
-- (v1.2.97) Historique complet d'un joueur (server/game/staffhistory.lua), avec un filtre par type
local tlData, tlFilter = nil, 'all'
local TL_CATS = { { 'all', 'Tout', 'list' }, { 'sanctions', 'Sanctions', 'banned' }, { 'reports', 'Reports', 'flag' }, { 'staff', 'Actions du staff', 'shield' }, { 'police', 'Police et justice', 'lock' }, { 'notes', 'Notes', 'file' }, { 'auto', 'Expulsions auto', 'alert' } }
local TL_ICON = { sanctions = 'banned', reports = 'flag', staff = 'shield', police = 'lock', notes = 'file', auto = 'alert' }
local function tlItems()
    local d = tlData
    if not d then return { { label = 'Historique indisponible', disabled = true } } end
    local items = { { type = 'separator', label = 'Filtre' } }
    for _, c in ipairs(TL_CATS) do
        local n = c[1] == 'all' and #(d.items or {}) or ((d.count or {})[c[1]] or 0)
        if c[1] == 'all' or n > 0 then
            items[#items + 1] = { label = c[2], icon = c[3], badge = tostring(n), right = tlFilter == c[1] and 'affiché' or nil, onSelect = function() tlFilter = c[1] G.Menu.Refresh() end }
        end
    end
    items[#items + 1] = { type = 'separator', label = 'Du plus récent au plus ancien' }
    local shown = 0
    for _, e in ipairs(d.items or {}) do
        if tlFilter == 'all' or e.cat == tlFilter then
            shown = shown + 1
            local desc = (e.text or '') .. (e.by and ((e.text and ' · ' or '') .. 'par ' .. e.by) or '')
            items[#items + 1] = { label = e.title, icon = TL_ICON[e.cat] or 'clock', right = (e.at or 0) > 0 and os.date('%d/%m/%y %H:%M', e.at) or '—', description = desc ~= '' and desc or nil, danger = e.tone == 'bad' or nil, disabled = true }
        end
    end
    if shown == 0 then items[#items + 1] = { label = 'Rien à afficher', description = 'Aucun évènement enregistré pour ce joueur.', disabled = true } end
    return items
end
RegisterNetEvent('pb:g:staff:timeline', function(j)
    tlData = G.decode(j)
    if not tlData then return end
    tlFilter = 'all'
    local cur = G.Menu.Stack and G.Menu.Stack:Current()
    if cur and cur.def.id == 'staff.timeline' then G.Menu.Refresh() return end
    G.Menu.Push({ id = 'staff.timeline', title = 'Historique', head = { crumb = 'Administration › Joueurs', name = tlData.name, badge = tlData.uid and ('#' .. tlData.uid) or nil }, build = tlItems })
end)
local findQuery, findRows = '', nil
RegisterNetEvent('pb:g:staff:find', function(j)
    local d = G.decode(j)
    if not d then return end
    findQuery, findRows = tostring(d.q or ''), d.rows or {}
    G.Menu.Refresh()
end)

local function catPlayers()
    local items = {}
    -- (v1.2.91) carte des joueurs : tous les joueurs (ou un filtre) sur la carte et la mini-carte
    if can('pmap') and G.StaffMapItems then
        items[#items + 1] = { type = 'submenu', label = 'Carte des joueurs', icon = 'gps', right = spec.pmap and spec.pmap.on and 'affichée' or nil, description = 'Tous les joueurs sur ta carte, même loin de toi : tous, le staff, une entreprise ou un gang. Rouge : staff en service, violet : gang, bleu : métier.',
            submenu = { id = 'staff.pmap', title = 'Carte des joueurs', subtitle = 'Affichage', refreshOnReturn = true, build = function() return G.StaffMapItems(spec, send) end } }
    end
    if can('p_find') then
        items[#items + 1] = { type = 'input', label = 'Rechercher un joueur', icon = 'search', value = findQuery ~= '' and findQuery or nil, maxlen = 48, description = 'En ligne ou hors ligne : prénom, nom, nom FiveM, ID permanent ou licence.',
            onChange = function(_, text)
                text = tostring(text or ''):gsub('^%s+', ''):gsub('%s+$', '')
                if text == '' then findQuery, findRows = '', nil G.Menu.Refresh() else send('p_find', { q = text }) end
            end }
    end
    if findRows then
        items[#items + 1] = { type = 'separator', label = ('Résultats (%d)'):format(#findRows) }
        for _, r in ipairs(findRows) do
            local info = { { 'État', r.online and ('En ligne · ID ' .. r.online) or 'Hors ligne' } }
            if not r.online then info[#info + 1] = { 'Vu le', os.date('%d/%m/%Y', tonumber(r.seen) or 0) } end
            info[#info + 1] = { 'Prison', r.jailed and 'Oui' or 'Non' }
            info[#info + 1] = { 'Banni', r.banned and 'Oui' or 'Non' }
            items[#items + 1] = { label = r.name, right = r.uid and ('#' .. r.uid) or nil, badge = r.banned and 'BANNI' or (r.jailed and 'PRISON') or (r.online and 'EN LIGNE') or 'HORS LIGNE', info = info, description = 'Entrée : ouvrir son dossier.', icon = 'user',
                onSelect = function() send('p_card', { license = r.license }) end }
        end
        if #findRows == 0 then items[#items + 1] = { label = 'Aucun joueur pour « ' .. findQuery .. ' »', disabled = true } end
        items[#items + 1] = { label = 'Effacer la recherche', icon = 'x', onSelect = function() findQuery, findRows = '', nil G.Menu.Refresh() end }
        return items
    end
    if #items > 0 then items[#items + 1] = { type = 'separator', label = 'Connectés' } end
    local nOnline = #items
    for _, pl in ipairs(spec.players or {}) do
        local info = { { 'Prison', pl.jail and (pl.jail.kind == 'tig' and (pl.jail.remaining .. ' tâche(s)') or (math.ceil(pl.jail.remaining / 60) .. ' min')) or 'Non' }, { 'Repos (ATA)', (pl.ata or 0) > 0 and (math.ceil(pl.ata / 60) .. ' min') or 'Non' }, { 'Emploi', pl.job or 'Sans emploi' } }
        items[#items + 1] = { info = info, label = pl.name, right = '#' .. (pl.uid or pl.id), badge = pl.staff and 'STAFF' or (pl.jailed and 'PRISON') or ((pl.ata or 0) > 0 and 'ATA') or (pl.dead and 'À TERRE' or nil), submenu = playerMenu(pl), type = 'submenu' }
    end
    if #items == nOnline then items[#items + 1] = { label = 'Personne', disabled = true } end
    return items
end

local function toggle(label, desc, icon, feature)
    return { type = 'checkbox', label = label, description = desc, icon = icon, checked = (spec.self or {})[feature] == true,
        onChange = function(_, v) send('self', { feature = feature, on = v }) end }
end
local function can(id) return spec.can and spec.can[id] end

local function catSelf()
    local out = {}
    local function sep(l) if #out > 0 and out[#out].type == 'separator' then out[#out] = nil end out[#out + 1] = { type = 'separator', label = l } end
    -- Déplacement
    sep('Déplacement')
    if can('self') then
        out[#out + 1] = toggle('Noclip', 'Vole à travers tout, invisible pour les joueurs (tu te vois en transparence, ton véhicule aussi). Molette : vitesse, Ctrl : ralenti, Maj : boost, E : monter, A : descendre.', 'bolt', 'noclip')
        out[#out + 1] = toggle('Course rapide', 'Cours plus vite.', 'bolt', 'speed')
        out[#out + 1] = toggle('Nage rapide', 'Nage plus vite.', 'bolt', 'swim')
        out[#out + 1] = toggle('Super saut', 'Saute beaucoup plus haut.', 'bolt', 'jump')
        out[#out + 1] = toggle('Endurance infinie', 'Ne te fatigue plus en courant ou nageant.', 'bolt', 'stamina')
    end
    if can('freecam') then
        out[#out + 1] = { label = 'Caméra libre', icon = 'eye', right = G.StaffFreecamOn and G.StaffFreecamOn() and 'active' or nil, description = "Détache la caméra de ton personnage (invisible, il la suit) pour filmer ou surveiller sans être vu. ZQSD, souris, Maj / Ctrl, E / A, molette, H : interface, Retour arrière : quitter.",
            onSelect = function() G.Menu.Close() send('freecam') end }
    end
    -- Protection
    sep('Protection')
    if can('self') then
        out[#out + 1] = toggle('Invincible', 'Aucun dégât.', 'shield', 'god')
        out[#out + 1] = toggle('Invisible', "Les autres ne te voient plus.", 'eye', 'invisible')
        out[#out + 1] = toggle('Balles infinies', "Munitions illimitées et pas de rechargement pour l'arme en main.", 'crosshair', 'ammo')
    end
    if can('heal_me') then out[#out + 1] = { label = 'Me soigner', description = 'Santé, faim, soif et stress au maximum.', icon = 'heart', onSelect = function() send('heal_me') end } end
    -- Affichage
    sep('Affichage')
    -- (v1.2.43) une seule option « noms » : l'ID et le nom au-dessus de la tête de chaque joueur proche
    out[#out + 1] = { type = 'checkbox', label = 'Infos staff en haut de l\'écran', icon = 'sliders', checked = GetResourceKvpString('pb_staffhud_pin') == 'on',
        description = "La barre staff (reports, joueurs, staff en service…) reste en haut de l'écran, même quand un menu ou une interface est ouvert.",
        onChange = function(_, v) SetResourceKvp('pb_staffhud_pin', v and 'on' or 'off') if G.StaffHudPush then G.StaffHudPush() end end }
    if can('self') then
        out[#out + 1] = toggle('Noms au-dessus des têtes', "L'ID, le nom et le grade de chaque joueur proche, au-dessus de sa tête. Visible par toi seul.", 'users', 'names')
        out[#out + 1] = toggle('Viseur staff', "Un viseur au centre de l'écran : le joueur visé est entouré avec son ID. Clic gauche : ses actions rapides (infos, aller vers, ramener, observer, geler…).", 'crosshair', 'aim')
        out[#out + 1] = toggle('Squelette des joueurs', "Dessine le squelette des joueurs proches, même à travers le ped et les murs (en noclip ou non).", 'users', 'skeleton')
        out[#out + 1] = toggle('Repères des joueurs', 'Points sur la carte pour les joueurs chargés près de toi.', 'gps', 'blips')
        out[#out + 1] = toggle('Afficher mes coordonnées', 'Position et cap à l\'écran.', 'gps', 'coords')
        out[#out + 1] = toggle('Mode photo', "Noclip + ton personnage invisible + toute l'interface cachée (radar, HUD, notifications) pour prendre des photos. Le menu staff reste accessible pour en sortir.", 'image', 'photo')
    end
    -- Téléportation
    sep('Téléportation')
    if can('tp_waypoint') then out[#out + 1] = { label = 'Aller au point GPS', description = "Place un point sur la carte, puis choisis ceci.", icon = 'gps', onSelect = function() send('tp_waypoint') end } end
    if can('tp_player') then out[#out + 1] = { label = 'Aller vers un ID', description = "Saisis l'ID du joueur.", icon = 'users', onSelect = function() local v = G.Menu.Ask("ID du joueur", '', 6) if tonumber(v) then send('tp_player', { uid = tonumber(v) }) end end } end
    if can('tp_coords') then out[#out + 1] = { label = 'Aller aux coordonnées', description = 'Saisis : x y z', icon = 'gps', onSelect = function() local v = G.Menu.Ask('Coordonnées : x y z', '', 40) if v and v ~= '' then send('tp_coords', { text = v }) end end } end
    if can('tp_back') then out[#out + 1] = { label = 'Retourner où j\'étais', description = 'Revient à la position avant ta dernière téléportation.', icon = 'undo', onSelect = function() send('tp_back') end } end
    if #out > 0 and out[#out].type == 'separator' then out[#out] = nil end
    return out
end

local function catVehicles()
    local sub = {}
    for _, m in ipairs(spec.spawn or {}) do sub[#sub + 1] = { label = m[1], onSelect = function() send('veh_spawn', { model = m[1] }) end } end
    sub[#sub + 1] = { label = 'Autre modèle…', description = 'Saisis le nom du modèle (ex. adder).', onSelect = function() local v = G.Menu.Ask('Modèle du véhicule', '', 32) if v and v ~= '' then send('veh_spawn', { model = v }) end end }
    return {
        { label = 'Créer un véhicule', description = 'Le véhicule apparaît autour de toi.', icon = 'engine', type = 'submenu', submenu = { id = 'staff.spawn', title = 'Véhicules', subtitle = 'Choisis un modèle', items = sub } },
        { label = 'Réparer', description = 'Répare et nettoie ton véhicule.', icon = 'key', onSelect = function() send('veh_repair') end },
        { label = 'Remettre sur les roues', icon = 'refresh', onSelect = function() send('veh_flip') end },
        { label = 'Nettoyer', description = 'Retire la saleté de ton véhicule.', icon = 'refresh', onSelect = function() send('veh_clean') end },
        { label = 'Plein de carburant', icon = 'engine', onSelect = function() send('veh_fuel') end },
        { label = 'Performances au maximum', description = 'Moteur, freins, transmission, suspension et turbo.', icon = 'bolt', onSelect = function() send('veh_max') end },
        { label = 'Déverrouiller', description = 'Ouvre ton véhicule ou le plus proche.', icon = 'lock', onSelect = function() send('veh_unlock') end },
        { label = 'Moteur : démarrer / couper', icon = 'key', onSelect = function() send('veh_engine') end },
        { label = 'Coup de boost', description = 'Accélère d\'un coup.', icon = 'bolt', onSelect = function() send('veh_boost') end },
        { label = 'Monter dans le véhicule proche', description = 'Te place dans le véhicule le plus proche (25 m).', icon = 'engine', onSelect = function() send('veh_tpin') end },
        { label = 'Supprimer mon véhicule', description = 'Supprime le véhicule dans lequel tu es (ou le plus proche).', icon = 'x', onSelect = function() send('veh_delete') end },
        { label = 'Nettoyer les véhicules vides (50 m)', description = 'Supprime les véhicules sans conducteur autour de toi.', icon = 'x', onSelect = function() send('veh_purge') end },
        can('veh_find') and { type = 'submenu', label = 'Supprimer définitivement', description = 'Retire un véhicule du compte de son propriétaire, avec son coffre.', icon = 'x', submenu = { id = 'staff.wipe', title = 'Supprimer définitivement', subtitle = 'Choisis le véhicule', items = (function()
            local l = {
                { label = 'Celui où je suis ou le plus proche', description = 'À 10 m au plus.', icon = 'engine', onSelect = function() send('veh_find') end },
                { label = 'Par plaque…', description = "Fonctionne aussi si le véhicule est au garage ou si son propriétaire n'est pas connecté.", icon = 'key', onSelect = function()
                    local v = G.Menu.Ask('Plaque du véhicule', '', 12)
                    if v and v ~= '' then send('veh_find', { plate = v }) end
                end },
                { type = 'separator', label = 'Joueurs connectés' },
            }
            for _, pl in ipairs(spec.players or {}) do l[#l + 1] = { label = pl.name, right = '#' .. (pl.uid or pl.id), onSelect = function() send('veh_owned', { id = pl.id }) end } end
            return l
        end)() } } or nil,
    }
end

-- Résultat de la recherche : chaque véhicule demande une confirmation avant la suppression
-- (v1.2.90) Retour en arrière : liste des sauvegardes d'un joueur, puis sac seul ou sac + argent
local function money2(n) return n and (tostring(math.floor(n)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') .. ' $') or '—' end
RegisterNetEvent('pb:g:staff:rollback', function(j)
    local d = G.decode(j)
    if not d then return end
    local items = {}
    for _, s in ipairs(d.list or {}) do
        local ago = s.ago < 60 and (s.ago .. ' min') or (math.floor(s.ago / 60) .. ' h ' .. (s.ago % 60) .. ' min')
        local sub = {
            { label = 'Objets dans le sac', right = tostring(s.items), disabled = true },
            { label = 'Espèces / banque', right = money2(s.cash) .. ' · ' .. money2(s.bank), disabled = true },
            { label = 'Restaurer le sac et l\'argent', icon = 'undo', description = "Remplace son sac et son argent par ceux de cette sauvegarde (l'état actuel est sauvegardé avant).", disabled = s.cash == nil or nil, onSelect = function()
                G.Menu.ConfirmTwice(d.name, 'Revenir au ' .. s.at .. ' (sac et argent) ?', function() send('rollback_do', { id = d.id, snap = s.id, money = true }) end)
            end },
            { label = 'Restaurer seulement le sac', icon = 'bag', onSelect = function()
                G.Menu.ConfirmTwice(d.name, 'Revenir au ' .. s.at .. ' (sac seulement) ?', function() send('rollback_do', { id = d.id, snap = s.id, money = false }) end)
            end },
        }
        items[#items + 1] = { type = 'submenu', label = s.at, right = 'il y a ' .. ago, icon = 'clock', description = s.reason .. ' · ' .. s.items .. ' objet(s) · ' .. money2(s.cash), submenu = { id = 'staff.rb.' .. s.id, title = s.at, subtitle = d.name, items = sub } }
    end
    if #items == 0 then items[1] = { label = 'Aucune sauvegarde ces dernières 48 h', disabled = true } end
    G.Menu.Open({ id = 'staff.rollback', title = 'Retour en arrière', subtitle = d.name, items = items })
end)
RegisterNetEvent('pb:g:staff:vehs', function(j)
    local d = G.decode(j)
    if not d or not d.rows then return end
    local items = {}
    for _, v in ipairs(d.rows) do
        items[#items + 1] = { type = 'submenu', label = v.name, right = v.plate, icon = 'engine', description = v.owner .. ' · ' .. v.state, submenu = { id = 'staff.wipe.' .. v.plate, title = 'Supprimer définitivement ?', subtitle = v.name .. ' · ' .. v.plate, items = {
            { label = 'Annuler', icon = 'refresh', onSelect = function() G.Menu.Stack:Back() end },
            { label = 'Oui, supprimer définitivement', icon = 'x', description = ('Appartient à %s. Il quitte la ville et le compte, avec le contenu de son coffre. Impossible à annuler.'):format(v.owner), onSelect = function()
                G.Menu.ConfirmTwice(v.plate, 'Dernier écran : impossible à annuler.', function()
                    send('veh_wipe', { plate = v.plate })
                    G.Menu.Back() G.Menu.Back()
                end)
            end },
        } } }
    end
    G.Menu.Open({ id = 'staff.wipe.list', title = 'Supprimer définitivement', subtitle = d.title, items = items })
end)

local function catServer()
    local out = {}
    if can('clear_peds') then out[#out + 1] = { label = 'Supprimer les piétons (60 m)', description = 'Retire les piétons non joueurs autour de toi.', icon = 'x', onSelect = function() send('clear_peds') end } end
    if can('announce') then
        local sub = {}
        local STYLES = { { 'info', 'Information' }, { 'event', 'Événement' }, { 'alert', 'Alerte' }, { 'success', 'Bonne nouvelle' } }
        local st = { i = 1, preview = false }
        local function go(text) send('announce', { text = text, style = STYLES[st.i][1], preview = st.preview or nil }) end
        if spec.announce_screen then
            sub[#sub + 1] = { type = 'list', label = 'Style du bandeau', icon = 'palette', list = { 'Information', 'Événement', 'Alerte', 'Bonne nouvelle' }, index = st.i,
                description = 'Bandeau plein écran au centre de l\'écran de tous les joueurs.', onChange = function(_, _, i) st.i = i end }
            sub[#sub + 1] = { type = 'checkbox', label = 'Aperçu sur mon écran seulement', icon = 'eye', checked = false, description = "Coché : l'annonce ne s'affiche que chez toi, pour voir le rendu.", onChange = function(_, v) st.preview = v and true or false end }
        end
        for _, a in ipairs(spec.announce or {}) do sub[#sub + 1] = { label = a[1], description = a[2], onSelect = function() go(a[2]) end } end
        sub[#sub + 1] = { label = 'Message libre…', onSelect = function() local v = G.Menu.Ask('Annonce' .. (spec.announce_screen and ' plein écran' or ' à tous les joueurs'), '', 200) if v and v ~= '' then go(v) end end }
        out[#out + 1] = { label = 'Annonce', description = spec.announce_screen and 'Bandeau plein écran à tous les joueurs (style au choix, aperçu possible).' or 'Message à tous les joueurs (chat + bandeau).', icon = 'chat', type = 'submenu', submenu = { id = 'staff.announce', title = 'Annonce', subtitle = spec.announce_screen and 'Plein écran' or 'À tous les joueurs', items = sub } }
    end
    if can('weather') then
        if spec.world_on then
            local sub = {}
            for _, w in ipairs(spec.weather or {}) do sub[#sub + 1] = { label = w, onSelect = function() send('weather', { value = w }) end } end
            out[#out + 1] = { label = 'Météo', icon = 'cloud', type = 'submenu', submenu = { id = 'staff.weather', title = 'Météo', subtitle = 'Pour tout le monde', items = sub } }
            local hs = { { label = 'Le temps reprend son cours', onSelect = function() send('hour', { value = 'cycle' }) end } }
            for h = 0, 23, 2 do hs[#hs + 1] = { label = ('Figer à %02d h'):format(h), onSelect = function() send('hour', { value = h }) end } end
            out[#out + 1] = { label = 'Heure', icon = 'clock', type = 'submenu', submenu = { id = 'staff.hour', title = 'Heure', subtitle = 'Pour tout le monde', items = hs } }
        else
            out[#out + 1] = { label = 'Météo et heure', right = 'Indisponible', description = "Le panel ne pilote pas le monde. Active-le dans Monde › Réglages.", icon = 'cloud', disabled = true }
        end
    end
    -- (v1.2.78) diffusion d'une vidéo YouTube à tous les joueurs (fondateur uniquement)
    if spec.video and can('video_play') then
        out[#out + 1] = { type = 'submenu', label = 'Diffusion vidéo', icon = 'eye', right = spec.video.on and 'En cours' or nil, description = "Fondateur : une vidéo YouTube sur l'écran de tous les joueurs, en même temps. Leur écran est bloqué ; chacun règle le son.",
            submenu = { id = 'staff.video', title = 'Diffusion vidéo', subtitle = 'Tous les joueurs connectés', refreshOnReturn = true, build = function()
                local v = spec.video or {}
                local items = { { label = 'Diffuser une vidéo YouTube', icon = 'eye', description = 'Colle le lien (youtube.com/watch?v=… ou youtu.be/…). « &t=90 » démarre à 1 min 30.', onSelect = function()
                    local url = G.Menu.Ask('Lien de la vidéo YouTube', '', 200)
                    if url and url ~= '' then G.Menu.ConfirmTwice('Diffuser à tous les joueurs', "L'écran de tout le monde sera bloqué pendant la vidéo.", function() send('video_play', { text = url }) end) end
                end } }
                if v.on then items[#items + 1] = { label = 'Arrêter la diffusion', icon = 'x', description = 'Rend la main à tous les joueurs.', onSelect = function() send('video_stop') end } end
                return items
            end } }
    end
    -- (v1.2.78) ventes par PNJ uniquement : concessions, immobilier, supérettes (bascules)
    if spec.npcsales and can('npc_sales') then
        local ns = spec.npcsales
        local function box(k, label, desc) return { type = 'checkbox', label = label, icon = 'user', checked = ns[k] == true, description = desc, onChange = function(_, v) send('npc_sales', { kind = k, on = v }) end } end
        out[#out + 1] = { type = 'submenu', label = 'Ventes par PNJ uniquement', icon = 'cart', description = 'Retire les vendeurs joueurs : on achète seul auprès d\'un PNJ. Décocher les remet.', submenu = { id = 'staff.npcsales', title = 'Ventes par PNJ', subtitle = 'Plus de vendeurs joueurs', refreshOnReturn = true, build = function()
            ns = spec.npcsales or ns
            return { box('dealer', 'Concessions', 'On achète seul à la vitrine ; les vendeurs ne vendent plus.'),
                box('realestate', 'Immobilier', "L'agence PNJ (Builder › Immobilier) montre les logements libres ; achat ou location à la porte."),
                box('store', 'Supérettes', "On paie seul, même si l'épicerie appartient à une entreprise.") }
        end } }
    end
    if can('blackout') then out[#out + 1] = { type = 'checkbox', label = 'Coupure de courant', description = 'Éteint les lumières de la ville pour tout le monde.', icon = 'bolt', checked = spec.blackout == true, onChange = function() send('blackout') end } end
    if can('heal_all') then out[#out + 1] = { label = 'Soigner tout le monde', icon = 'heart', description = 'Réanime et soigne tous les joueurs en ligne.', onSelect = function() send('heal_all') end } end
    if can('revive_all') then out[#out + 1] = { label = 'Réanimer tout le monde', icon = 'heart', description = 'Seulement les joueurs à terre.', onSelect = function() send('revive_all') end } end
    if can('ata_clear_all') then out[#out + 1] = { label = 'Lever tous les repos', icon = 'check', description = "Tout le monde peut de nouveau sortir une arme et courir.", onSelect = function() send('ata_clear_all') end } end
    if can('uncuff_all') then out[#out + 1] = { label = 'Démenotter tout le monde', icon = 'key', description = 'Libère toutes les personnes menottées ou ligotées.', onSelect = function() send('uncuff_all') end } end
    if can('restart') then
        local sub = {}
        if spec.restart then sub[#sub + 1] = { label = 'Annuler le redémarrage', description = ('Arrêt dans %d s.'):format(spec.restart.left or 0), icon = 'x', onSelect = function() send('restart_cancel') end } end
        for _, m in ipairs({ 1, 2, 5, 10, 15, 30, 60 }) do sub[#sub + 1] = { label = ('Dans %d minute%s'):format(m, m > 1 and 's' or ''), onSelect = function() send('restart', { minutes = m }) end } end
        out[#out + 1] = { label = 'Redémarrer le serveur', right = spec.restart and 'En cours' or nil, description = 'Annonce à tous les joueurs, sauvegarde, puis arrêt.', icon = 'refresh', type = 'submenu', submenu = { id = 'staff.restart', title = 'Redémarrage', subtitle = 'Avec annonce et compte à rebours', items = sub } }
    end
    if can('maintenance') then out[#out + 1] = { type = 'checkbox', label = 'Mode maintenance', description = "Seuls les membres autorisés peuvent se connecter.", icon = 'lock', checked = spec.maint == true, onChange = function() send('maintenance') end } end
    return out
end

local function ago(s) s = tonumber(s) or 0 if s < 90 then return s .. ' s' elseif s < 5400 then return math.floor(s / 60) .. ' min' else return math.floor(s / 3600) .. ' h' end end
local function catReports()
    local items = {}
    for _, r in ipairs(spec.reports or {}) do
        local sub = {
            { label = 'Aller vers lui', icon = 'gps', onSelect = function() send('report_goto', { rid = r.id }) end },
            { label = 'Prendre en charge', icon = 'check', onSelect = function() send('report_claim', { rid = r.id }) end },
            { label = 'Répondre dans le chat', icon = 'chat', description = 'Seuls le joueur et le staff en service voient le message (il répond avec /r). Ou dans le chat : /rr ' .. r.id .. ' message.', onSelect = function()
                local t = G.Menu.Ask('Message pour ' .. r.name, '', 300)
                if t and t ~= '' then send('report_chat', { rid = r.id, text = t }) end
            end },
            { label = 'Clore', icon = 'x', onSelect = function() send('report_close', { rid = r.id }) end },
        }
        items[#items + 1] = { type = 'submenu', label = r.name, right = ago(r.ago), badge = r.status == 'claimed' and (r.by ~= '' and r.by or 'PRIS') or 'NOUVEAU', description = r.text,
            submenu = { id = 'staff.r.' .. r.id, title = 'Signalement #' .. r.id, subtitle = r.name, items = sub } }
    end
    if #items == 0 then items[1] = { label = 'Aucun signalement ouvert', disabled = true } end
    return items
end

local function catSanctions()
    local items = {}
    if can('ban_offline') then
        items[#items + 1] = { label = 'Bannir un joueur hors ligne', description = 'Par sa licence (6 caractères au moins).', icon = 'shield', onSelect = function()
            local p = {}
            local inputs = { { k = 'who', label = 'Licence (ou fin de licence)', maxlen = 60 }, { k = 'minutes', label = 'Durée en minutes (0 = définitif)', number = true, maxlen = 6 }, { k = 'reason', label = 'Motif', maxlen = 120 } }
            if askAll(inputs, p) then send('ban_offline', p) end
        end }
    end
    for _, j in ipairs(spec.jailed or {}) do
        local left = j.kind == 'tig' and (tostring(j.remaining) .. ' tâche(s)') or (tostring(math.ceil((j.remaining or 0) / 60)) .. ' min')
        items[#items + 1] = { type = 'submenu', label = j.name, icon = 'lock', right = (j.kind == 'tig' and 'TIG · ' or 'Prison · ') .. left, description = (j.online and ('#' .. (G.UidOf(j.online) or j.online) .. ' · ') or 'Hors ligne · ') .. (j.reason or ''),
            submenu = { id = 'staff.j.' .. j.license, title = j.name, subtitle = 'Détenu', items = { { label = 'Libérer de prison', icon = 'check', description = 'Met fin à sa peine' .. (j.online and ' et le ramène à la sortie.' or ' (il sera libre à sa prochaine connexion).'), onSelect = function() send('unjail_license', { license = j.license }) end } } } }
    end
    for _, b in ipairs(spec.bans or {}) do
        items[#items + 1] = { type = 'submenu', label = b.name, right = (b.expires or 0) == 0 and 'Définitif' or os.date('%d/%m %H:%M', b.expires), description = b.reason,
            submenu = { id = 'staff.b.' .. b.id, title = b.name, subtitle = 'Bannissement', items = { { label = 'Lever le bannissement', icon = 'check', description = 'Autorise à nouveau la connexion.', onSelect = function() send('unban', { sid = b.id }) end } } } }
    end
    if #items == 0 then items[1] = { label = 'Aucun bannissement ni détenu', disabled = true } end
    return items
end

-- (v1.2.45) Téléportation : TP rapides (favoris du staff), lieux posés au Builder, mappings trouvés sur le serveur
local function catTeleport()
    local d = spec.tpdata or {}
    local out = {}
    local function askAdd()
        local v = G.Menu.Ask('Nom de ce lieu (ta position actuelle)', '', 48)
        if v and v ~= '' then send('tp_fav_add', { name = v }) end
    end
    local favs = {}
    for _, f in ipairs(d.favs or {}) do favs[#favs + 1] = { label = f[2], icon = 'gps', description = 'Y aller.', onSelect = function() send('tp_saved', { place = f[1] }) end } end
    out[#out + 1] = { type = 'separator', label = 'TP rapides' }
    for _, it in ipairs(favs) do out[#out + 1] = it end
    out[#out + 1] = { label = 'Ajouter ma position ici', icon = 'plus', description = 'Ajoute un TP rapide, visible par tout le staff.', onSelect = askAdd }
    if #favs > 0 then
        local rows = {}
        for _, f in ipairs(d.favs or {}) do
            rows[#rows + 1] = { type = 'submenu', label = f[2], icon = 'pin', submenu = { id = 'staff.tp.f' .. f[1], title = f[2], items = {
                { label = 'Renommer', icon = 'edit', onSelect = function() local v = G.Menu.Ask('Nouveau nom', f[2], 48) if v and v ~= '' then send('tp_rename', { place = f[1], name = v }) G.Menu.Stack:Back() end end },
                { label = 'Retirer', icon = 'trash', onSelect = function() send('tp_del', { place = f[1] }) G.Menu.Stack:Back() end } } } }
        end
        out[#out + 1] = { type = 'submenu', label = 'Gérer les TP rapides', icon = 'edit', badge = tostring(#rows), submenu = { id = 'staff.tp.favs', title = 'TP rapides', refreshOnReturn = true, items = rows } }
    end
    -- mappings
    local maps, hiddenN = {}, 0
    local manage = {}
    for _, m in ipairs(d.maps or {}) do
        if m[3] then hiddenN = hiddenN + 1 else maps[#maps + 1] = { label = m[2], icon = 'building', description = 'Y aller (au sol, au centre du mapping).', onSelect = function() send('tp_saved', { place = m[1] }) end } end
        manage[#manage + 1] = { type = 'submenu', label = m[2], icon = 'pin', right = m[3] and 'Masqué' or nil, submenu = { id = 'staff.tp.m' .. m[1], title = m[2], items = {
            { label = 'Renommer', icon = 'edit', onSelect = function() local v = G.Menu.Ask('Nouveau nom', m[2], 64) if v and v ~= '' then send('tp_rename', { place = m[1], name = v }) G.Menu.Stack:Back() end end },
            { label = m[3] and 'Afficher dans la liste' or 'Masquer de la liste', icon = 'eye', onSelect = function() send('tp_hide', { place = m[1] }) G.Menu.Stack:Back() end } } } }
    end
    if #manage > 0 then
        table.insert(maps, { type = 'separator', label = '' })
        table.insert(maps, { type = 'submenu', label = 'Renommer ou masquer', icon = 'edit', badge = tostring(#manage), submenu = { id = 'staff.tp.mapsm', title = 'Gérer les mappings', refreshOnReturn = true, items = manage } })
    end
    if #manage == 0 then maps[#maps + 1] = { label = (d.scan and d.scan.ok == false) and ('Recherche impossible : ' .. tostring(d.scan.why)) or 'Aucun mapping trouvé pour le moment', disabled = true } end
    maps[#maps + 1] = { label = 'Rechercher à nouveau', icon = 'search', description = 'Relit les fichiers de carte des ressources démarrées.', onSelect = function() send('tp_scan') end }
    out[#out + 1] = { type = 'separator', label = 'Le serveur' }
    out[#out + 1] = { type = 'submenu', label = 'Mappings', icon = 'building', badge = tostring(#(d.maps or {}) - hiddenN), description = 'Tous les mappings installés sur le serveur.', submenu = { id = 'staff.tp.maps', title = 'Mappings', refreshOnReturn = true, items = maps } }
    local groups = {}
    for _, g in ipairs(d.places or {}) do
        local rows = {}
        for _, r in ipairs(g[2]) do rows[#rows + 1] = { label = r[3], right = r[4], icon = 'gps', onSelect = function() send('tp_place', { type = r[1], place = r[2] }) end } end
        groups[#groups + 1] = { type = 'submenu', label = g[1], badge = tostring(#rows), submenu = { id = 'staff.tp.g.' .. g[1], title = g[1], items = rows } }
    end
    if #groups > 0 then out[#out + 1] = { type = 'submenu', label = 'Lieux du Builder', icon = 'pin', badge = tostring(#groups), description = 'Magasins, garages, banques, entreprises… tout ce qui est posé.', submenu = { id = 'staff.tp.places', title = 'Lieux du Builder', items = groups } } end
    -- outils déjà connus
    out[#out + 1] = { type = 'separator', label = 'Autres' }
    if can('tp_waypoint') then out[#out + 1] = { label = 'Aller au point GPS', icon = 'gps', description = 'Place un point sur la carte, puis choisis ceci.', onSelect = function() send('tp_waypoint') end } end
    if can('tp_player') then out[#out + 1] = { label = 'Aller vers un ID', icon = 'users', onSelect = function() local v = G.Menu.Ask("ID du joueur", '', 6) if v and v ~= '' then send('tp_player', { uid = v }) end end } end
    if can('tp_coords') then out[#out + 1] = { label = 'Aller aux coordonnées', icon = 'gps', description = 'x y z', onSelect = function() local v = G.Menu.Ask('Coordonnées : x y z', '', 40) if v and v ~= '' then send('tp_coords', { text = v }) end end } end
    if can('tp_back') then out[#out + 1] = { label = "Retourner où j'étais", icon = 'undo', onSelect = function() send('tp_back') end } end
    return out
end
local BUILD = { players = catPlayers, self = catSelf, teleport = catTeleport, vehicles = catVehicles, server = catServer, reports = catReports, sanctions = catSanctions,
    builder = function() return G.BuilderItems and G.BuilderItems(spec, send) or {} end,
    orgs = function() return G.StaffOrgItems and G.StaffOrgItems(spec, send) or {} end,
    props = function() return G.PropsItems and G.PropsItems() or {} end }

local function mainItems()
    local hidden = {}
    for _, id in ipairs(spec.hide or {}) do hidden[id] = true end
    if dutyOn ~= (spec.duty == true) then dutyOn = spec.duty == true end
    local items = { { type = 'separator', label = spec.grade .. (spec.duty and ' · en service' or ' · hors service') },
        { id = 'duty', type = 'checkbox', label = 'Prendre mon service', description = spec.require_duty and 'Obligatoire pour utiliser les outils.' or 'Optionnel : visible par les autres staff.', icon = 'bolt', checked = spec.duty == true,
          onChange = function(_, v) send('duty', { on = v }) end } }
    -- hors service : uniquement « Prendre mon service » (rien d'autre ne s'affiche)
    if not spec.duty then return items end
    if can('search') then
        items[#items + 1] = { id = 'search', label = 'Rechercher', icon = 'search', description = 'Un joueur (nom, prénom, ID, licence), un véhicule (plaque) ou un numéro de téléphone.', onSelect = function()
            local q = G.Menu.Ask('Nom, ID, plaque ou numéro', '', 48)
            if q and q ~= '' then send('search', { q = q }) end
        end }
    end
    if spec.dutycfg then
        local dc = spec.dutycfg
        items[#items + 1] = { type = 'submenu', label = 'Réglages du service', icon = 'sliders', description = 'Ped de service par grade et blocage des accès joueur.', submenu = { id = 'staff.dutycfg', title = 'Service', subtitle = 'Réglages', refreshOnReturn = true, build = function()
            dc = spec.dutycfg or dc   -- valeurs à jour à chaque reconstruction (pas celles de l'ouverture du menu)
            local sub = {
                { type = 'checkbox', label = 'Ped de service', description = 'En service, chaque grade prend son ped ; il retrouve son personnage en quittant.', checked = dc.ped == true, onChange = function(_, v) send('duty_cfg', { key = 'ped', on = v }) end },
                { type = 'checkbox', label = 'Bloquer les accès joueur en service', description = 'Inventaire, métier, téléphone, banque… coupés ; les outils staff restent ouverts.', checked = dc.block == true, onChange = function(_, v) send('duty_cfg', { key = 'block', on = v }) end },
            }
            for _, g in ipairs(spec.gradeList or {}) do
                sub[#sub + 1] = { label = 'Ped : ' .. g.label, right = (dc.peds or {})[g.name] or '—', description = 'Modèle du ped de service de ce grade (vide = aucun).', onSelect = function()
                    local v = G.Menu.Ask('Modèle de ped pour ' .. g.label .. ' (vide = aucun)', (dc.peds or {})[g.name] or '', 40)
                    if v ~= nil then send('duty_cfg', { key = 'grade_ped', grade = g.name, model = v }) end
                end }
            end
            return sub
        end } }
    end
    for _, c in ipairs(spec.cats or {}) do
        if not hidden[c.id] or c.id == 'panel' then
            if c.id == 'panel' then
                items[#items + 1] = { id = 'panel', label = c.label, icon = c.icon, description = 'Ouvre le panel de configuration du serveur.', onSelect = function() send('panel') end }
            elseif BUILD[c.id] or G.StaffCat[c.id] then
                local b = BUILD[c.id] or function() local ok, r = pcall(G.StaffCat[c.id], spec, send) return ok and r or { { label = 'Indisponible', disabled = true } } end
                items[#items + 1] = { id = c.id, type = 'submenu', label = c.label, icon = c.icon, badge = (c.count and c.count > 0) and tostring(c.count) or nil,
                    submenu = { id = 'staff.' .. c.id, title = c.label, subtitle = spec.grade, refreshOnReturn = true, build = b } }
            end
        end
    end
    return items
end

local def = { id = 'staff', title = 'Menu staff', refreshOnReturn = true, banner = { text = 'Menu admin' } }
def.build = function()
    if not spec.duty then return mainItems() end
    local items = G.Menu.Sorted('staff', mainItems(), spec.order)
    items[#items + 1] = G.Menu.OrderEntry('staff', mainItems, spec.order)
    return items
end

-- Ouvert de mémoire à la touche : la réponse du serveur met le menu à jour au lieu de le rouvrir
local openedFromMemory = false
RegisterNetEvent('pb:g:staff:denied', function()
    spec = nil
    if openedFromMemory then openedFromMemory = false G.Menu.Close() end
end)
RegisterNetEvent('pb:g:staff:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if not d.spec then if G.Menu.IsOpen() then G.Menu.Close() end return end
    for _, k in ipairs(d.spec.kept or {}) do d.spec[k] = spec and spec[k] end
    -- mise à jour après une action : les longues listes ne sont pas renvoyées, on garde celles de l'ouverture
    if d.ev ~= 'open' and spec then d.spec.items, d.spec.weapons = d.spec.items or spec.items, d.spec.weapons or spec.weapons end
    spec = d.spec
    if d.ev == 'open' and openedFromMemory and not spec.focus then
        openedFromMemory = false
        def.subtitle = spec.grade
        if G.Menu.IsOpen() then G.Menu.Refresh() end
    elseif d.ev == 'open' then
        openedFromMemory = false
        def.subtitle = spec.grade
        def.banner = { text = 'Menu admin' }
        local f = spec.focus
        if f and f.k == 'reports' and can('report_claim') then
            G.Menu.Open({ id = 'staff.reports', title = 'Gestion des reports', subtitle = spec.grade, refreshOnReturn = true, banner = { text = 'Menu admin' }, build = catReports })
        elseif f and f.k == 'aim' then
            for _, pl in ipairs(spec.players or {}) do if pl.id == f.id then G.Menu.Open(quickMenu(pl)) return end end
            note('warn', 'Ce joueur n\'apparaît pas dans ta liste.')
        elseif f and f.k == 'player' then
            for _, pl in ipairs(spec.players or {}) do if pl.id == f.id then G.Menu.Open(playerMenu(pl)) return end end
            G.Menu.Open(def)
        else G.Menu.Open(def) end
    elseif G.Menu.IsOpen() then
        G.Menu.Refresh()
    end
end)

RegisterNetEvent('pb:g:staff:panel', function()
    G.Menu.Close()
    Wait(100)
    ExecuteCommand(GetConvar('pb_panel_cmd', 'panel'))
end)

-- Effets autorisés par le serveur ----------------------------------------------------------------------------------------------------------
local function groundZ(x, y, z)
    for h = 1000, -100, -50 do
        local ok, gz = GetGroundZFor_3dCoord(x + 0.0, y + 0.0, h + 0.0, false)
        if ok and math.abs(gz - z) < 400 then return gz end
    end
    return z
end
local backPos = nil
-- En noclip, c'est la boucle du noclip qui déplace le personnage : elle applique le saut elle-même, sans attendre le sol
local noclipJump = nil
local function teleport(c)
    local ped = PlayerPedId()
    local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
    local from = GetEntityCoords(ent)
    if not c.back then backPos = { x = from.x, y = from.y, z = from.z } end
    RequestCollisionAtCoord(c.x + 0.0, c.y + 0.0, c.z + 0.0)
    if self.noclip then noclipJump = { x = c.x + 0.0, y = c.y + 0.0, z = c.z + 0.5 } return end
    local t = GetGameTimer() + 1500
    while not HasCollisionLoadedAroundEntity(ent) and GetGameTimer() < t do Wait(0) end
    SetEntityCoordsNoOffset(ent, c.x + 0.0, c.y + 0.0, c.z + 0.5, false, false, true)
end
-- Sol d'un point lointain : il n'est chargé qu'autour du personnage, on descend donc par paliers jusqu'à le trouver
local function findGround(ent, x, y)
    local z
    local h = 1000.0
    local t = GetGameTimer() + 6000
    FreezeEntityPosition(ent, true)
    while not z and GetGameTimer() < t do
        SetEntityCoordsNoOffset(ent, x, y, h, false, false, true)
        RequestCollisionAtCoord(x, y, h)
        Wait(25)
        local ok, gz = GetGroundZFor_3dCoord(x, y, h, false)
        if ok then z = gz else h = h - 40.0 if h < -60.0 then h = 1000.0 end end
    end
    if not self.noclip then FreezeEntityPosition(ent, false) end
    return z
end

-- Invincibilité du staff : en service, en noclip ou avec « Invincible » actif, aucun dégât (chute, balles, explosion, feu…).
-- Elle est réaffirmée en boucle (un changement de ped ou un respawn la remet à zéro) et prolongée 4 s après la sortie du noclip.
local function wantGod() return (dutyOn and G.cfg.staff and G.cfg.staff.duty_god == true) or self.god == true or self.noclip == true or GetGameTimer() < graceUntil end
local function refreshGod()
    local ped, want = PlayerPedId(), wantGod()
    if want then
        SetPlayerInvincible(PlayerId(), true) SetEntityInvincible(ped, true)
        SetEntityProofs(ped, true, true, true, true, true, true, true, true)
        godApplied = true
    elseif godApplied then
        SetPlayerInvincible(PlayerId(), false) SetEntityInvincible(ped, false)
        SetEntityProofs(ped, false, false, false, false, false, false, false, false)
        godApplied = false
    end
end
CreateThread(function()
    while true do
        Wait(250)
        refreshGod()
    end
end)

-- Pose le ped (ou le véhicule) sur le sol sous lui, sans dégât, à la sortie du noclip.
local function landOnGround(ent)
    local p = GetEntityCoords(ent)
    RequestCollisionAtCoord(p.x, p.y, p.z)
    local t = GetGameTimer() + 1500
    while not HasCollisionLoadedAroundEntity(ent) and GetGameTimer() < t do Wait(0) end
    local gz
    for _, dz in ipairs({ 2.0, 40.0, 300.0 }) do
        local ok, z = GetGroundZFor_3dCoord(p.x + 0.0, p.y + 0.0, p.z + dz, false)
        if ok and z <= p.z + dz then gz = z break end
    end
    if gz and p.z - gz > 0.8 then
        SetEntityCoordsNoOffset(ent, p.x, p.y, gz + (IsEntityAPed(ent) and 1.0 or 0.6), false, false, false)
    end
    SetEntityVelocity(ent, 0.0, 0.0, 0.0)
end

local function noclipLoop()
    CreateThread(function()
        local ped = PlayerPedId()
        local touched = {}     -- tout ce qu'on a gelé : rendu en sortie, même si on est descendu du véhicule en cours de route
        local function release(e)
            if e and e ~= 0 and DoesEntityExist(e) then SetEntityCollision(e, true, true) FreezeEntityPosition(e, false) end
        end
        local lastEnt
        -- fantôme : invisible pour les autres joueurs (réseau), visible pour soi en transparence ; pareil pour le véhicule
        local ghosted = {}
        local function ghost(e)
            if not e or e == 0 or not DoesEntityExist(e) then return end
            if not ghosted[e] then ghosted[e] = true NetworkSetEntityInvisibleToNetwork(e, true) end
            SetEntityAlpha(e, 120, false)
        end
        local function unghost(e)
            if e and e ~= 0 and DoesEntityExist(e) then ResetEntityAlpha(e) NetworkSetEntityInvisibleToNetwork(e, false) end
            ghosted[e] = nil
        end
        local base = 0.6                       -- vitesse de base ; la molette la règle de 0,1 à 5
        local function showHints()
            if G and G.send then G.send('hints', { items = { { k = 'ZQSD', t = 'Se déplacer' }, { k = 'E', t = 'Monter' }, { k = 'A · Q', t = 'Descendre' }, { k = 'SHIFT', t = 'Boost' }, { k = 'CTRL', t = 'Ralenti' }, { k = 'mouse', t = ('Vitesse %.1f'):format(base) } } }) end
        end
        showHints()
        while self.noclip do
            Wait(0)
            DisableControlAction(0, 14, true) DisableControlAction(0, 15, true) DisableControlAction(0, 16, true) DisableControlAction(0, 17, true)
            if IsDisabledControlJustPressed(0, 15) or IsDisabledControlJustPressed(0, 17) then base = math.min(5.0, base + 0.1) showHints()
            elseif IsDisabledControlJustPressed(0, 14) or IsDisabledControlJustPressed(0, 16) then base = math.max(0.1, base - 0.1) showHints() end
            ped = PlayerPedId()
            local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
            if lastEnt and lastEnt ~= ent then
                -- on est monté / descendu : l'ancienne entité est libérée tout de suite (sinon le véhicule reste figé et le ped bloqué)
                release(lastEnt)
                if lastEnt ~= ped then unghost(lastEnt) landOnGround(lastEnt) end
            end
            lastEnt = ent
            ghost(ent)
            if ent ~= ped then ghost(ped) end
            touched[ent] = true
            SetEntityCollision(ent, false, false)
            FreezeEntityPosition(ent, true)
            local rot = GetGameplayCamRot(2)
            local rz, rx = math.rad(rot.z), math.rad(rot.x)
            local fwd = { x = -math.sin(rz) * math.cos(rx), y = math.cos(rz) * math.cos(rx), z = math.sin(rx) }
            local right = { x = math.cos(rz), y = math.sin(rz) }
            local speed = IsControlPressed(0, 21) and base * 4.0 or (IsControlPressed(0, 36) and base * 0.25 or base)
            if noclipJump then
                local j = noclipJump
                noclipJump = nil
                SetEntityCoordsNoOffset(ent, j.x, j.y, j.z, true, true, true)
            end
            local p = GetEntityCoords(ent)
            local x, y, z = p.x, p.y, p.z
            if IsControlPressed(0, 32) then x, y, z = x + fwd.x * speed, y + fwd.y * speed, z + fwd.z * speed end
            if IsControlPressed(0, 33) then x, y, z = x - fwd.x * speed, y - fwd.y * speed, z - fwd.z * speed end
            if IsControlPressed(0, 34) then x, y = x - right.x * speed, y - right.y * speed end
            if IsControlPressed(0, 35) then x, y = x + right.x * speed, y + right.y * speed end
            if IsControlPressed(0, 38) then z = z + speed end
            if IsControlPressed(0, 44) then z = z - speed end
            SetEntityCoordsNoOffset(ent, x, y, z, true, true, true)
            SetEntityHeading(ent, rot.z)
        end
        if G and G.send then G.send('hints', { items = {} }) end
        local ent = IsPedInAnyVehicle(PlayerPedId(), false) and GetVehiclePedIsIn(PlayerPedId(), false) or PlayerPedId()
        graceUntil = GetGameTimer() + 4000
        refreshGod()
        for e in pairs(touched) do release(e) end
        release(PlayerPedId())
        for e in pairs(ghosted) do unghost(e) end
        if self.invisible or self.photo then SetEntityVisible(PlayerPedId(), false, false) end
        landOnGround(ent)
    end)
end

-- Squelette : traits entre les os, visibles à travers le ped et les décors (DrawLine ignore la profondeur).
local BONES = { { 31086, 39317 }, { 39317, 24818 }, { 24818, 11816 }, { 24818, 40269 }, { 24818, 45509 }, { 40269, 28252 }, { 28252, 57005 }, { 45509, 61163 }, { 61163, 18905 },
    { 11816, 58271 }, { 58271, 63931 }, { 63931, 14201 }, { 11816, 51826 }, { 51826, 36864 }, { 36864, 52301 } }
-- Trait à l'écran : même épaisseur de près comme de loin. Le trait dans le monde ne sert que si un bout sort de l'écran.
local function boneLine(a, c, r, g, b)
    local okA, ax, ay = GetScreenCoordFromWorldCoord(a.x, a.y, a.z)
    local okC, cx, cy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z)
    if okA and okC then DrawLine_2d(ax, ay, cx, cy, 0.0007, r, g, b, 255)
    elseif okA or okC then DrawLine(a.x, a.y, a.z, c.x, c.y, c.z, r, g, b, 255) end
end
local function skeletonLoop()
    CreateThread(function()
        while self.skeleton do
            Wait(0)
            local hex = tostring((G.cfg and G.cfg.brand and G.cfg.brand.color) or ''):match('^#(%x%x%x%x%x%x)$') or 'ffffff'
            local r, g, b = tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16)
            if r + g + b < 200 then r, g, b = 255, 255, 255 end   -- serveur noir : un squelette noir ne se verrait pas
            local me = PlayerPedId()
            local mp = GetEntityCoords(me)
            for _, pid in ipairs(GetActivePlayers()) do
                local ped = GetPlayerPed(pid)
                if ped ~= me and DoesEntityExist(ped) then
                    local pos = GetEntityCoords(ped)
                    if #(pos - mp) < 500.0 then
                        SetPedLodMultiplier(ped, 8.0)   -- le jeu n'anime plus les os des personnages lointains ou hors champ : c'est ce qui faisait clignoter
                        local head, pelvis = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0), GetPedBoneCoords(ped, 11816, 0.0, 0.0, 0.0)
                        if #(head - pelvis) < 0.2 then
                            -- os pas encore calculés : une silhouette simple à sa position plutôt que rien
                            boneLine(vector3(pos.x, pos.y, pos.z - 1.0), vector3(pos.x, pos.y, pos.z + 0.75), r, g, b)
                            boneLine(vector3(pos.x - 0.3, pos.y, pos.z + 0.4), vector3(pos.x + 0.3, pos.y, pos.z + 0.4), r, g, b)
                        else
                            for _, bn in ipairs(BONES) do
                                boneLine(GetPedBoneCoords(ped, bn[1], 0.0, 0.0, 0.0), GetPedBoneCoords(ped, bn[2], 0.0, 0.0, 0.0), r, g, b)
                            end
                        end
                    end
                end
            end
        end
    end)
end

local blipOf = {}
local function clearBlips() for _, b in pairs(blipOf) do if DoesBlipExist(b) then RemoveBlip(b) end end blipOf = {} end
local function coordsLoop()
    CreateThread(function()
        while self.coords do
            Wait(0)
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            SetTextScale(0.0, 0.34) SetTextFont(4) SetTextOutline() SetTextEntry('STRING')
            AddTextComponentString(('%.2f  %.2f  %.2f  ·  cap %.1f'):format(c.x, c.y, c.z, GetEntityHeading(ped)))
            DrawText(0.5, 0.012)
        end
    end)
end
local function blipsLoop()
    CreateThread(function()
        while self.blips do
            local seen = {}
            for _, pid in ipairs(GetActivePlayers()) do
                if pid ~= PlayerId() then
                    local ped = GetPlayerPed(pid)
                    if DoesEntityExist(ped) then
                        seen[pid] = true
                        if blipOf[pid] and DoesBlipExist(blipOf[pid]) and GetBlipInfoIdEntityIndex(blipOf[pid]) ~= ped then RemoveBlip(blipOf[pid]) blipOf[pid] = nil end   -- nouveau personnage (réapparition, tenue) : l'ancien repère restait figé
                        if not blipOf[pid] or not DoesBlipExist(blipOf[pid]) then
                            local b = AddBlipForEntity(ped)
                            SetBlipSprite(b, 1) SetBlipScale(b, 0.8) SetBlipColour(b, 0) SetBlipCategory(b, 7)
                            BeginTextCommandSetBlipName('STRING') AddTextComponentString(('[%d] %s'):format(GetPlayerServerId(pid), GetPlayerName(pid))) EndTextCommandSetBlipName(b)
                            blipOf[pid] = b
                        end
                    end
                end
            end
            for pid, b in pairs(blipOf) do if not seen[pid] then if DoesBlipExist(b) then RemoveBlip(b) end blipOf[pid] = nil end end
            Wait(1000)
        end
        clearBlips()
    end)
end

-- Mode photo : noclip + personnage invisible + interface cachée (le menu staff reste visible pour en sortir)
local photoNoclip = false
local function photoLoop()
    CreateThread(function()
        G.send('photo', { on = true })
        while self.photo do
            HideHudAndRadarThisFrame()
            DisplayRadar(false)
            SetEntityVisible(PlayerPedId(), false, false)
            Wait(0)
        end
        DisplayRadar(true)
        G.send('photo', { on = false })
        if not self.invisible then SetEntityVisible(PlayerPedId(), true, false) end
    end)
end

-- (v1.2.43) Balles infinies : chargeur infini + munitions illimitées pour l'arme en main, rendu à la désactivation
local function ammoLoop()
    CreateThread(function()
        local done = {}
        while self.ammo do
            local ped = PlayerPedId()
            SetPedInfiniteAmmoClip(ped, true)
            local ok, w = GetCurrentPedWeapon(ped, true)
            if ok and w and w ~= GetHashKey('WEAPON_UNARMED') then SetPedInfiniteAmmo(ped, true, w) done[w] = true end
            Wait(250)
        end
        local ped = PlayerPedId()
        SetPedInfiniteAmmoClip(ped, false)
        for w in pairs(done) do SetPedInfiniteAmmo(ped, false, w) end
    end)
end

-- (v1.2.43) Viseur staff : réticule à l'écran, le joueur le plus proche du centre (250 m, même derrière un mur) est entouré ;
-- clic gauche = actions rapides (le serveur revérifie que le viseur est actif et ouvre la fiche).
local function aimPick(me, mp)
    local best, bd
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= me and DoesEntityExist(ped) then
            local c = GetPedBoneCoords(ped, 24818, 0.0, 0.0, 0.0)   -- torse
            local dist = #(c - mp)
            if dist < 250.0 then
                local on, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z)
                if on then
                    local d = math.sqrt((sx - 0.5) ^ 2 + (sy - 0.5) ^ 2)
                    local lim = math.max(0.018, 0.06 - dist * 0.0002)   -- plus tolérant de près
                    if d < lim and (not bd or d < bd) then best, bd = { pid = pid, ped = ped, dist = dist }, d end
                end
            end
        end
    end
    return best
end
local function aimLoop()
    CreateThread(function()
        local lastSid = nil
        G.send('staff.aim', { on = true })
        while self.aim do
            Wait(0)
            local me = PlayerPedId()
            local busy = IsPauseMenuActive() or IsNuiFocused()   -- le menu du staff reste ouvert pendant qu'on vise : il ne prend pas la souris
            local t = (not busy) and aimPick(me, GetGameplayCamCoord()) or nil
            -- repère du joueur visé (plus de contour sur son personnage : ça faisait planter le jeu)
            if t and DoesEntityExist(t.ped) then G.MarkPed(t.ped) end
            local sid = t and GetPlayerServerId(t.pid) or nil
            if sid ~= lastSid then
                lastSid = sid
                G.send('staff.aim', { on = true, target = t and { id = sid, name = GetPlayerName(t.pid), dist = math.floor(t.dist + 0.5) } or nil })
            end
            if not busy then
                HideHudComponentThisFrame(14)
                DisableControlAction(0, 24, true) DisableControlAction(0, 257, true) DisableControlAction(0, 140, true) DisableControlAction(0, 141, true) DisableControlAction(0, 142, true)
                if sid and IsDisabledControlJustPressed(0, 24) then TriggerServerEvent('pb:g:staff:open', sid) end
            end
        end
        G.send('staff.aim', { on = false })
    end)
end

local function applySelf(feature, on)
    self[feature] = on or nil
    local ped = PlayerPedId()
    if feature == 'photo' then
        if on then
            photoNoclip = not self.noclip
            if photoNoclip then self.noclip = true refreshGod() noclipLoop() end
            photoLoop()
        else
            if photoNoclip then self.noclip = nil photoNoclip = false end
        end
    elseif feature == 'noclip' then if on then refreshGod() noclipLoop() end
    elseif feature == 'god' then refreshGod()
    elseif feature == 'invisible' then SetEntityVisible(ped, not on, false)
    elseif feature == 'names' then G.tagsOff = not on   -- (v1.2.43) une seule chose : les étiquettes (nom, ID, grade) au-dessus des têtes
    elseif feature == 'coords' then if on then coordsLoop() end
    elseif feature == 'blips' then if on then blipsLoop() end
    elseif feature == 'skeleton' then if on then skeletonLoop() end
    elseif feature == 'ammo' then if on then ammoLoop() end
    elseif feature == 'aim' then if on then aimLoop() end
    elseif feature == 'speed' then SetRunSprintMultiplierForPlayer(PlayerId(), on and 1.49 or 1.0) SetPedMoveRateOverride(ped, on and 1.4 or 1.0)
    elseif feature == 'swim' then SetSwimMultiplierForPlayer(PlayerId(), on and 1.49 or 1.0)
    elseif feature == 'stamina' or feature == 'jump' then
        if on then CreateThread(function()
            while self[feature] do
                if feature == 'stamina' then RestorePlayerStamina(PlayerId(), 1.0)
                elseif feature == 'jump' then SetSuperJumpThisFrame(PlayerId())
                end
                Wait(feature == 'jump' and 0 or 250)
            end
        end) end
    end
end

local function vehicleFx(d)
    local ped = PlayerPedId()
    local veh = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or 0
    if d.op == 'spawn' then
        local hash = GetHashKey(tostring(d.model))
        if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then note('error', 'Modèle de véhicule inconnu : ' .. tostring(d.model)) return end
        RequestModel(hash)
        local t = GetGameTimer() + 4000
        while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(0) end
        if not HasModelLoaded(hash) then note('error', 'Chargement du modèle impossible.') return end
        if veh ~= 0 then SetEntityAsMissionEntity(veh, true, true) DeleteVehicle(veh) end
        local c = GetEntityCoords(ped)
        local v = CreateVehicle(hash, c.x, c.y, c.z + 0.3, GetEntityHeading(ped), true, false)
        SetPedIntoVehicle(ped, v, -1)
        SetVehicleNumberPlateText(v, 'STAFF')
        SetModelAsNoLongerNeeded(hash)
    elseif d.op == 'repair' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleDirtLevel(veh, 0.0) SetVehicleEngineHealth(veh, 1000.0)
    elseif d.op == 'flip' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleOnGroundProperly(veh)
    elseif d.op == 'delete' then
        if veh == 0 then
            local c = GetEntityCoords(ped)
            veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71)
        end
        if veh ~= 0 and DoesEntityExist(veh) then SetEntityAsMissionEntity(veh, true, true) DeleteVehicle(veh) else note('warn', 'Aucun véhicule à proximité.') end
    elseif d.op == 'purge' then
        local c = GetEntityCoords(ped)
        local n = 0
        for _, v in ipairs(GetGamePool('CVehicle')) do
            if v ~= veh and #(GetEntityCoords(v) - c) < 50.0 and GetPedInVehicleSeat(v, -1) == 0 and GetVehicleNumberOfPassengers(v) == 0 then
                SetEntityAsMissionEntity(v, true, true) DeleteVehicle(v) n = n + 1
            end
        end
        note('success', n .. ' véhicule(s) vide(s) supprimé(s).')
    elseif d.op == 'clean' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleDirtLevel(veh, 0.0) WashDecalsFromVehicle(veh, 1.0)
    elseif d.op == 'fuel' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleFuelLevel(veh, 100.0)
    elseif d.op == 'max' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleModKit(veh, 0)
        for _, m in ipairs({ 11, 12, 13, 15, 16 }) do SetVehicleMod(veh, m, GetNumVehicleMods(veh, m) - 1, false) end
        ToggleVehicleMod(veh, 18, true)
    elseif d.op == 'unlock' then
        local v = veh
        if v == 0 then local c = GetEntityCoords(ped) v = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
        if v ~= 0 and DoesEntityExist(v) then SetVehicleDoorsLocked(v, 1) SetVehicleDoorsLockedForAllPlayers(v, false) else note('warn', 'Aucun véhicule à proximité.') end
    elseif d.op == 'boost' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleForwardSpeed(veh, math.min(80.0, GetEntitySpeed(veh) + 25.0))
    elseif d.op == 'tpin' then
        local c = GetEntityCoords(ped)
        local v = GetClosestVehicle(c.x, c.y, c.z, 25.0, 0, 71)
        if v ~= 0 and DoesEntityExist(v) then
            for seat = -1, GetVehicleModelNumberOfSeats(GetEntityModel(v)) - 2 do if IsVehicleSeatFree(v, seat) then SetPedIntoVehicle(ped, v, seat) return end end
            note('warn', 'Aucune place libre.')
        else note('warn', 'Aucun véhicule à moins de 25 m.') end
    elseif d.op == 'engine' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleEngineOn(veh, not GetIsVehicleEngineRunning(veh), true, true)
    end
end

RegisterNetEvent('pb:g:staff:fx', function(kind, j)
    local d = G.decode(j) or {}
    local ped = PlayerPedId()
    if kind == 'tp' and type(d.x) == 'number' then teleport(d)
    elseif kind == 'tpxy' and type(d.x) == 'number' then
        -- (v1.2.43) point sans hauteur connue : on charge la zone puis on se pose au sol
        local ped = PlayerPedId()
        local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
        local from = GetEntityCoords(ent)
        backPos = { x = from.x, y = from.y, z = from.z }
        local z = tonumber(d.z)
        if not z then
            z = findGround(ent, d.x + 0.0, d.y + 0.0)
        end
        teleport({ x = d.x, y = d.y, z = (z or 50.0), back = true })
    elseif kind == 'tpback' then
        if not backPos then note('warn', "Aucune position précédente.") return end
        local c = { x = backPos.x, y = backPos.y, z = backPos.z, back = true }
        teleport(c)
        backPos = nil
    elseif kind == 'blackout' then
        SetArtificialLightsState(d.on == true) SetArtificialLightsStateAffectsVehicles(false)
    elseif kind == 'tpwp' then
        local blip = GetFirstBlipInfoId(8)
        if not DoesBlipExist(blip) then note('warn', "Pas de point GPS sur la carte.") return end
        local c = GetBlipInfoIdCoord(blip)
        local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
        local from = GetEntityCoords(ent)
        backPos = { x = from.x, y = from.y, z = from.z }
        teleport({ x = c.x, y = c.y, z = findGround(ent, c.x + 0.0, c.y + 0.0) or groundZ(c.x, c.y, 100.0), back = true })
    elseif kind == 'heal' then
        SetEntityHealth(ped, GetEntityMaxHealth(ped)) ClearPedBloodDamage(ped) SetPedArmour(ped, 0)
    elseif kind == 'freeze' then
        local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
        FreezeEntityPosition(ent, d.on == true)
    elseif kind == 'spectate' then
        if d.on and d.target then
            CreateThread(function() G.SpectateStart(d) end)
        else
            G.SpectateStop()
        end
    elseif kind == 'self' and type(d.feature) == 'string' then applySelf(d.feature, d.on == true)
    elseif kind == 'freecam' then if G.StaffFreecam then G.StaffFreecam() end
    elseif kind == 'dutystate' then dutyOn = d.on == true refreshGod()
    elseif kind == 'follow' then
        G.send('staff.follow', { id = d.id, name = d.name })
    elseif kind == 'dutyped' then
        if d.on and type(d.model) == 'string' then
            local h = GetHashKey(d.model)
            if not IsModelInCdimage(h) or not IsModelAPed(h) then note('error', 'Ped de service inconnu : ' .. d.model) return end
            RequestModel(h)
            local t = GetGameTimer() + 4000
            while not HasModelLoaded(h) and GetGameTimer() < t do Wait(0) end
            if HasModelLoaded(h) then SetPlayerModel(PlayerId(), h) SetModelAsNoLongerNeeded(h) SetPedDefaultComponentVariation(PlayerPedId()) G.staffPed = d.model end
        else
            G.staffPed = nil
            if G.appearance and G.applyAppearance then G.applyAppearance(G.appearance, true) end
        end
    elseif kind == 'kill' then SetEntityHealth(ped, 0)
    elseif kind == 'slap' then
        if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 4160) Wait(400) end
        SetPedToRagdoll(PlayerPedId(), 1500, 1500, 0, false, false, false) ApplyForceToEntity(PlayerPedId(), 1, 0.0, 0.0, 9.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
    elseif kind == 'armor' then SetPedArmour(ped, 100)
    elseif kind == 'leaveveh' then if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16) end
    elseif kind == 'strip' then RemoveAllPedWeapons(ped, true)
    elseif kind == 'weapon' and type(d.name) == 'string' then
        local hash = GetHashKey(d.name)
        if IsWeaponValid(hash) then GiveWeaponToPed(ped, hash, math.floor(tonumber(d.ammo) or 0), false, false) else note('error', 'Arme inconnue : ' .. d.name) end
    elseif kind == 'clearpeds' then
        local c, n = GetEntityCoords(ped), 0
        for _, p in ipairs(GetGamePool('CPed')) do
            if not IsPedAPlayer(p) and #(GetEntityCoords(p) - c) < 60.0 then SetEntityAsMissionEntity(p, true, true) DeletePed(p) n = n + 1 end
        end
        note('success', n .. ' piéton(s) supprimé(s).')
    elseif kind == 'veh' then vehicleFx(d) end
end)

G.nui['staff.follow.open'] = function() TriggerServerEvent('pb:g:staff:open', 'follow') return {} end
G.nui['staff.notif.click'] = function(d) if d.k == 'reports' then TriggerServerEvent('pb:g:staff:open', 'reports') end return {} end

RegisterCommand('pb_staff', function()
    if not G.begun or G.creating or G.wardrobe then return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    if spec then openedFromMemory = G.Menu.Open(def) == true end
    TriggerServerEvent('pb:g:staff:open')
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.staff and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_staff', 'Menu staff', 'keyboard', (G.cfg.staff and G.cfg.staff.key) or 'F10')
end)
-- Raccourcis clavier staff (modifiables dans les raccourcis de FiveM). Le serveur décide : sans droit ou hors service, rien ne se passe.
local BINDS = {
    { 'noclip', 'noclip', 'Staff : noclip', 'noclip' }, { 'tpm', nil, 'Staff : téléportation au point GPS', 'tpm' }, { 'back', nil, 'Staff : retour à la position précédente', 'back' },
    { 'god', 'god', 'Staff : invincibilité', 'god' }, { 'invisible', 'invisible', 'Staff : invisibilité', 'invisible' }, { 'names', 'names', 'Staff : noms au-dessus des têtes (ID et nom)', 'names' },
    { 'heal', nil, 'Staff : me soigner', 'heal' }, { 'photo', 'photo', 'Staff : mode photo (tout invisible)', 'photo' },
    { 'aim', 'aim', 'Staff : viseur (actions rapides sur le joueur visé)', 'aim' }, { 'ammo', 'ammo', 'Staff : balles infinies', 'ammo' },
}
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.staff and GetGameTimer() < t do Wait(250) end
    local c = G.cfg.staff or {}
    local defaults = { noclip = 'F3' }   -- F4 = poste radio des joueurs
    for _, b in ipairs(BINDS) do
        local name, feature, label = b[1], b[2], b[3]
        local cmd = 'pb_staff_' .. name
        RegisterCommand(cmd, function()
            -- le noclip reste disponible menu ouvert (Builder : se déplacer sans quitter la liste des points)
            if not G.begun or G.creating or G.wardrobe or (G.Menu.IsOpen() and name ~= 'noclip') then return end
            TriggerServerEvent('pb:g:staff:bind', name, feature and not self[feature] or false)
        end, false)
        local key = c['bind_' .. name]
        if type(key) ~= 'string' then key = defaults[name] or '' end
        RegisterKeyMapping(cmd, label, 'keyboard', key)
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    if spectating then NetworkSetInSpectatorMode(false, PlayerPedId()) end
    local ped = PlayerPedId()
    dutyOn, graceUntil = false, 0
    self.noclip, self.god, self.photo = nil, nil, nil
    DisplayRadar(true)
    refreshGod()
    SetEntityVisible(ped, true, false) FreezeEntityPosition(ped, false)
end)

-- Barre staff : la dernière reçue est renvoyée à l'interface toutes les 5 s (elle ne disparaît plus si l'interface l'a perdue)
-- et peut être épinglée en haut de l'écran (Gestion personnelle › Affichage)
local hudD
function G.StaffHudPush()
    if not hudD then return end
    local pin = GetResourceKvpString('pb_staffhud_pin') == 'on'
    local d = {}
    for k, v in pairs(hudD) do d[k] = v end
    if pin and #(d.items or {}) > 0 then d.pin = true d.style = 'bar' end
    G.send('staff.hud', d)
end
RegisterNetEvent('pb:g:staff:hud', function(j)
    local d = G.decode(j)
    hudD = (type(d) == 'table' and d.items) and d or { items = {} }
    G.StaffHudPush()
end)
CreateThread(function()
    while true do
        Wait(5000)
        if hudD and #(hudD.items or {}) > 0 then G.StaffHudPush() end
    end
end)

-- Spectateur amélioré : on se rapproche invisiblement si la cible est loin, on revient à sa place à la fin ;
-- infos de la cible à l'écran ; ← → joueur suivant / précédent ; Retour arrêter.
local specState
function G.SpectateStart(d)
    local ped = PlayerPedId()
    if not specState then specState = { back = GetEntityCoords(ped), list = d.list or {} } end
    if d.list then specState.list = d.list end
    specState.target, specState.name = d.target, d.name
    local pid = GetPlayerFromServerId(d.target)
    if pid == -1 and d.pos then
        SetEntityVisible(ped, false, false) SetEntityCollision(ped, false, false) FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true)
        SetEntityCoords(ped, d.pos.x + 0.0, d.pos.y + 0.0, d.pos.z - 30.0, false, false, false, false)
        local t = GetGameTimer() + 5000
        while GetPlayerFromServerId(d.target) == -1 and GetGameTimer() < t do Wait(100) end
        pid = GetPlayerFromServerId(d.target)
    end
    if pid == -1 then note('error', 'Impossible de rejoindre ce joueur.') G.SpectateStop() return end
    SetEntityVisible(ped, false, false) SetEntityCollision(ped, false, false) FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true)
    NetworkSetInSpectatorMode(true, GetPlayerPed(pid))
    spectating = true
    if specState.loop then return end
    specState.loop = true
    CreateThread(function()
        while spectating and specState do
            Wait(0)
            if not specState then break end   -- arrêtée pendant cette image
            local tp = GetPlayerFromServerId(specState.target)
            local tped = tp ~= -1 and GetPlayerPed(tp) or 0
            -- la position du staff suit la cible (sous le sol) pour rester à portée réseau
            if tped ~= 0 then local c = GetEntityCoords(tped) SetEntityCoords(PlayerPedId(), c.x, c.y, c.z - 30.0, false, false, false, false) end
            local lines = { ('%s (#%d)'):format(tostring(specState.name or '?'), G.UidOf(specState.target) or specState.target) }
            if tped ~= 0 then
                lines[#lines + 1] = ('Vie %d · Gilet %d'):format(math.max(0, GetEntityHealth(tped) - 100), GetPedArmour(tped))
                local v = GetVehiclePedIsIn(tped, false)
                if v ~= 0 then lines[#lines + 1] = ('%s · %d km/h'):format(GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(v))), math.floor(GetEntitySpeed(v) * 3.6)) end
                local _, w = GetCurrentPedWeapon(tped, true)
                if w and w ~= joaat('WEAPON_UNARMED') then lines[#lines + 1] = 'Arme en main' end
            end
            lines[#lines + 1] = '← → joueur suivant · Retour : arrêter'
            for i, l in ipairs(lines) do
                SetTextFont(4) SetTextScale(0.38, 0.38) SetTextColour(255, 255, 255, 230) SetTextOutline()
                BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(l) EndTextCommandDisplayText(0.015, 0.30 + i * 0.028)
            end
            DisableControlAction(0, 174, true) DisableControlAction(0, 175, true) DisableControlAction(0, 177, true) DisableControlAction(0, 194, true)
            if IsDisabledControlJustPressed(0, 175) or IsDisabledControlJustPressed(0, 174) then
                local l, cur, nextId = specState.list or {}, 0, nil
                for i, id in ipairs(l) do if id == specState.target then cur = i end end
                if #l > 0 then nextId = l[((cur - 1 + (IsDisabledControlJustPressed(0, 175) and 1 or -1)) % #l) + 1] end
                if nextId and nextId ~= specState.target then TriggerServerEvent('pb:g:staff:specnext', nextId) end
            elseif IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 194) then
                G.SpectateStop()
            end
        end
    end)
end
function G.SpectateStop()
    local ped = PlayerPedId()
    NetworkSetInSpectatorMode(false, ped)
    spectating = false
    if specState then
        local b = specState.back
        specState = nil
        if b then SetEntityCoords(ped, b.x, b.y, b.z, false, false, false, false) end
    end
    SetEntityVisible(ped, true, false) SetEntityCollision(ped, true, true) FreezeEntityPosition(ped, false)
    if refreshGod then refreshGod() else SetEntityInvincible(ped, false) end
end
