-- Atelier : customisation en direct dans le véhicule, réparation et nettoyage facturés au client. Le serveur vérifie métier, service, distance et prix.
local G = PBG

local function nearestVeh()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then local c = GetEntityCoords(ped) veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    return veh ~= 0 and DoesEntityExist(veh) and veh or nil
end
local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', '') end
local function grab(veh) if NetworkHasControlOfEntity(veh) then return true end NetworkRequestControlOfEntity(veh) local t = GetGameTimer() + 1500 while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(30) end return NetworkHasControlOfEntity(veh) end

-- Applique une pièce (aussi utilisée à la sortie du garage)
function G.ApplyPart(veh, kind, mod, level)
    level = math.floor(tonumber(level) or 0)
    if kind == 'mod' then
        SetVehicleModKit(veh, 0)
        SetVehicleMod(veh, mod, level - 1, false)
    elseif kind == 'toggle' then SetVehicleModKit(veh, 0) ToggleVehicleMod(veh, mod, level > 0)
    elseif kind == 'tint' then SetVehicleModKit(veh, 0) SetVehicleWindowTint(veh, level)
    elseif kind == 'plate' then SetVehicleNumberPlateTextIndex(veh, level)
    elseif kind == 'paint' then local _, c2 = GetVehicleColours(veh) SetVehicleColours(veh, level, c2) end
end
function G.ApplyMods(veh, mods)
    local parts = (G.cfg.mech and G.cfg.mech.parts) or {}
    for _, p in ipairs(parts) do
        local lv = mods and mods[p.key]
        if lv then G.ApplyPart(veh, p.kind, p.mod, lv) end
    end
end

-- Customisation (atelier) ---------------------------------------------------------------------------------------------------------------------------------
-- Le mécanicien est DANS le véhicule. Chaque option survolée s'affiche sur la voiture (le client voit le rendu) ; Entrée l'ajoute au devis.
-- En quittant une liste, la voiture revient à l'état du devis. « Valider le devis » envoie les changements au serveur, qui fixe les prix.
local CLASSIC = { { 0, 'Noir' }, { 1, 'Graphite' }, { 2, 'Noir acier' }, { 3, 'Argent foncé' }, { 4, 'Argent' }, { 5, 'Argent bleuté' }, { 6, 'Gris acier' }, { 7, 'Argent ombré' },
    { 8, 'Argent pierre' }, { 9, 'Argent minuit' }, { 10, 'Gris canon' }, { 11, 'Anthracite' }, { 27, 'Rouge' }, { 28, 'Rouge Turin' }, { 29, 'Rouge formule' }, { 30, 'Rouge flamme' },
    { 31, 'Rouge grenat' }, { 32, 'Rouge désert' }, { 33, 'Rouge cabernet' }, { 34, 'Rouge bonbon' }, { 35, 'Rouge aurore' }, { 36, 'Orange' }, { 37, 'Or classique' }, { 38, 'Orange vif' },
    { 49, 'Vert foncé' }, { 50, 'Vert course' }, { 51, 'Vert mer' }, { 52, 'Vert olive' }, { 53, 'Vert vif' }, { 54, 'Vert essence' }, { 61, 'Bleu nuit' }, { 62, 'Bleu foncé' },
    { 63, 'Bleu saxe' }, { 64, 'Bleu' }, { 65, 'Bleu marine' }, { 66, 'Bleu port' }, { 67, 'Bleu diamant' }, { 68, 'Bleu surf' }, { 69, 'Bleu nautique' }, { 70, 'Bleu électrique' },
    { 71, 'Violet' }, { 72, 'Violet spinnaker' }, { 73, 'Bleu ultra' }, { 74, 'Bleu clair' }, { 88, 'Jaune' }, { 89, 'Jaune course' }, { 90, 'Bronze' }, { 91, 'Jaune pâle' },
    { 92, 'Vert citron' }, { 94, 'Brun' }, { 96, 'Chocolat' }, { 97, 'Érable' }, { 98, 'Selle' }, { 99, 'Paille' }, { 100, 'Mousse' }, { 101, 'Bison' }, { 102, 'Bois' },
    { 103, 'Hêtre' }, { 104, 'Sienne' }, { 105, 'Sable' }, { 106, 'Beige' }, { 107, 'Crème' }, { 111, 'Blanc' }, { 112, 'Blanc givré' }, { 135, 'Rose vif' }, { 136, 'Rose saumon' },
    { 137, 'Rose' }, { 138, 'Orange brûlé' }, { 141, 'Bleu nuit profond' }, { 142, 'Violet nuit' }, { 143, 'Rouge vin' }, { 145, 'Violet clair' }, { 150, 'Rouge lave' } }
local MATTE = { { 12, 'Noir mat' }, { 13, 'Gris mat' }, { 14, 'Gris clair mat' }, { 39, 'Rouge mat' }, { 40, 'Rouge foncé mat' }, { 41, 'Orange mat' }, { 42, 'Jaune mat' },
    { 55, 'Vert lime mat' }, { 82, 'Bleu foncé mat' }, { 83, 'Bleu mat' }, { 84, 'Bleu nuit mat' }, { 128, 'Vert mat' }, { 131, 'Blanc mat' }, { 148, 'Violet mat' },
    { 149, 'Violet foncé mat' }, { 151, 'Vert forêt mat' }, { 152, 'Olive mat' }, { 153, 'Terre mat' }, { 154, 'Désert mat' }, { 155, 'Feuillage mat' } }
local METAL = { { 117, 'Acier brossé' }, { 118, 'Acier noir brossé' }, { 119, 'Aluminium brossé' }, { 158, 'Or pur' }, { 159, 'Or brossé' }, { 120, 'Chrome' } }
local RGB = { { 'Blanc pur', 255, 255, 255 }, { 'Noir profond', 8, 8, 8 }, { 'Rouge vif', 220, 20, 30 }, { 'Bordeaux', 110, 10, 30 }, { 'Orange', 255, 120, 0 }, { 'Jaune', 255, 210, 0 },
    { 'Vert lime', 120, 255, 30 }, { 'Vert émeraude', 0, 150, 90 }, { 'Turquoise', 0, 200, 200 }, { 'Bleu ciel', 80, 170, 255 }, { 'Bleu roi', 20, 60, 220 }, { 'Bleu nuit', 10, 20, 70 },
    { 'Violet', 130, 40, 220 }, { 'Rose', 255, 80, 170 }, { 'Or', 212, 175, 55 }, { 'Gris béton', 120, 120, 125 } }
local WHEELS = { { 0, 'Sport' }, { 1, 'Muscle' }, { 2, 'Lowrider' }, { 3, 'SUV' }, { 4, 'Tout-terrain' }, { 5, 'Tuner' }, { 7, 'Haut de gamme' }, { 8, "Benny's originales" }, { 9, "Benny's bespoke" },
    { 10, 'Ouvertes' }, { 11, 'Rue' }, { 12, 'Circuit' }, { 6, 'Moto' } }
local BODY = { { 0, 'Aileron' }, { 1, 'Pare-chocs avant' }, { 2, 'Pare-chocs arrière' }, { 3, 'Bas de caisse' }, { 4, 'Échappement' }, { 5, 'Arceau / châssis' }, { 6, 'Calandre' },
    { 7, 'Capot' }, { 8, 'Ailes' }, { 9, 'Ailes droites' }, { 10, 'Toit' } }
local EXTRA = { { 25, 'Support de plaque' }, { 26, 'Plaques personnalisées' }, { 27, 'Garnitures' }, { 28, 'Ornements' }, { 29, 'Tableau de bord' }, { 30, 'Compteurs' },
    { 31, 'Haut-parleurs de porte' }, { 32, 'Sièges' }, { 33, 'Volant' }, { 34, 'Levier de vitesse' }, { 35, 'Plaques' }, { 36, 'Haut-parleurs' }, { 37, 'Coffre' },
    { 38, 'Hydraulique' }, { 39, 'Bloc moteur' }, { 40, 'Filtre à air' }, { 41, 'Jambes de force' }, { 42, 'Passages de roue' }, { 43, 'Antennes' }, { 44, 'Garnitures extérieures' },
    { 45, 'Réservoir' }, { 46, 'Vitres' } }
local PERF = { { 11, 'Moteur' }, { 12, 'Freins' }, { 13, 'Transmission' }, { 15, 'Suspension' }, { 16, 'Blindage' } }
local XENON = { { -1, "Blanc d'origine" }, { 0, 'Blanc' }, { 1, 'Bleu' }, { 2, 'Bleu électrique' }, { 3, 'Vert menthe' }, { 4, 'Vert lime' }, { 5, 'Jaune' }, { 6, 'Or' },
    { 7, 'Orange' }, { 8, 'Rouge' }, { 9, 'Rose poney' }, { 10, 'Rose vif' }, { 11, 'Violet' }, { 12, 'Lumière noire' } }
local TINT = { { 0, 'Aucune' }, { 4, 'Légère' }, { 5, 'Fumée' }, { 3, 'Fumée claire' }, { 1, 'Noir intégral' }, { 2, 'Noir foncé' }, { 6, 'Verte' } }
local PLATES = { { 0, 'Bleu sur blanc 1' }, { 3, 'Bleu sur blanc 2' }, { 4, 'Bleu sur blanc 3' }, { 1, 'Jaune sur noir' }, { 2, 'Jaune sur bleu' }, { 5, 'Yankton' } }

local function isBike(veh) return IsThisModelABike ~= nil and IsThisModelABike(GetEntityModel(veh)) == true end
G.IsBike = isBike
-- Lecture et application d'un état complet (mêmes clés que le devis)
local function readState(veh)
    local s = { mods = {} }
    local c1, c2 = GetVehicleColours(veh)
    local pearl, wcol = GetVehicleExtraColours(veh)
    s.col1, s.col2, s.pearl, s.wheelcol = { c1 }, { c2 }, pearl, wcol
    s.int = GetVehicleInteriorColour and GetVehicleInteriorColour(veh) or 0
    s.dash = GetVehicleDashboardColour and GetVehicleDashboardColour(veh) or 0
    if GetIsVehiclePrimaryColourCustom(veh) then local r, g, b = GetVehicleCustomPrimaryColour(veh) s.rgb1 = { r, g, b } end
    if GetIsVehicleSecondaryColourCustom(veh) then local r, g, b = GetVehicleCustomSecondaryColour(veh) s.rgb2 = { r, g, b } end
    SetVehicleModKit(veh, 0)
    s.wheel = { GetVehicleWheelType(veh), GetVehicleMod(veh, 23), GetVehicleModVariation(veh, 23) }
    for t = 0, 48 do if t ~= 23 and t ~= 18 and t ~= 22 and t ~= 20 and not (t == 24 and isBike(veh)) then s.mods[tostring(t)] = GetVehicleMod(veh, t) end end
    s.turbo, s.xenon, s.smoke = IsToggleModOn(veh, 18), IsToggleModOn(veh, 22), IsToggleModOn(veh, 20)
    s.xcol = GetVehicleXenonLightsColor and GetVehicleXenonLightsColor(veh) or -1
    s.neon = { IsVehicleNeonLightEnabled(veh, 0), IsVehicleNeonLightEnabled(veh, 1), IsVehicleNeonLightEnabled(veh, 2), IsVehicleNeonLightEnabled(veh, 3) }
    local nr, ng, nb = GetVehicleNeonLightsColour(veh) s.ncol = { nr, ng, nb }
    local sr, sg, sb = GetVehicleTyreSmokeColor(veh) s.scol = { sr, sg, sb }
    s.tint, s.plate = GetVehicleWindowTint(veh), GetVehicleNumberPlateTextIndex(veh)
    s.horn, s.livery = GetVehicleMod(veh, 14), GetVehicleLivery(veh)
    -- options propres au modèle (surtout les véhicules addon : kits, feux, accessoires) : seulement celles qui existent
    s.extras = {}
    for n = 1, 14 do if DoesExtraExist(veh, n) then s.extras[tostring(n)] = IsVehicleExtraTurnedOn(veh, n) == true end end
    return s
end
-- Une teinte libre « retirée » s'écrit false (ou { -1, -1, -1 } venant de l'atelier)
local function freeColour(v) return type(v) == 'table' and tonumber(v[1]) and tonumber(v[1]) >= 0 and v or nil end
-- Applique un état (complet ou partiel). Chaque réglage n'est posé que s'il diffère de ce que le véhicule a déjà : moins de scintillement,
-- et jamais d'indice hors limites (un véhicule addon n'a pas forcément les mêmes pièces que le modèle d'origine).
function G.ApplyCustom(veh, s)
    if not veh or veh == 0 or type(s) ~= 'table' or not DoesEntityExist(veh) then return end
    SetVehicleModKit(veh, 0)
    local bike = isBike(veh)
    local c1, c2 = GetVehicleColours(veh)
    if s.col1 or s.col2 then SetVehicleColours(veh, s.col1 and s.col1[1] or c1, s.col2 and s.col2[1] or c2) end
    local r1, r2 = freeColour(s.rgb1), freeColour(s.rgb2)
    if r1 then SetVehicleCustomPrimaryColour(veh, r1[1], r1[2], r1[3]) elseif s.rgb1 ~= nil or s.col1 then ClearVehicleCustomPrimaryColour(veh) end
    if r2 then SetVehicleCustomSecondaryColour(veh, r2[1], r2[2], r2[3]) elseif s.rgb2 ~= nil or s.col2 then ClearVehicleCustomSecondaryColour(veh) end
    local pearl, wcol = GetVehicleExtraColours(veh)
    if s.pearl or s.wheelcol then SetVehicleExtraColours(veh, s.pearl or pearl, s.wheelcol or wcol) end
    if s.int and SetVehicleInteriorColour then SetVehicleInteriorColour(veh, s.int) end
    if s.dash and SetVehicleDashboardColour then SetVehicleDashboardColour(veh, s.dash) end
    -- jantes : le type change d'abord, puis le modèle ; une moto a aussi une roue arrière (pièce 24) identique
    if type(s.wheel) == 'table' then
        local wt = math.floor(tonumber(s.wheel[1]) or 0)
        local idx, var = math.floor(tonumber(s.wheel[2]) or -1), s.wheel[3] == true
        local typeChanged = GetVehicleWheelType(veh) ~= wt
        if typeChanged then SetVehicleWheelType(veh, wt) end
        for _, slot in ipairs(bike and { 23, 24 } or { 23 }) do
            if typeChanged or GetVehicleMod(veh, slot) ~= idx or GetVehicleModVariation(veh, slot) ~= var then
                if idx < 0 then RemoveVehicleMod(veh, slot)
                elseif idx < (GetNumVehicleMods(veh, slot) or 0) then SetVehicleMod(veh, slot, idx, var) end
            end
        end
    end
    for k, v in pairs(s.mods or {}) do
        local t = tonumber(k)
        if t and t ~= 23 and not (t == 24 and bike) and type(v) == 'number' and GetVehicleMod(veh, t) ~= v then
            if v < 0 then RemoveVehicleMod(veh, t)
            elseif v < (GetNumVehicleMods(veh, t) or 0) then SetVehicleMod(veh, t, v, false) end
        end
    end
    if s.turbo ~= nil then ToggleVehicleMod(veh, 18, s.turbo == true) end
    if s.xenon ~= nil then ToggleVehicleMod(veh, 22, s.xenon == true) end
    if s.xcol and SetVehicleXenonLightsColor then SetVehicleXenonLightsColor(veh, s.xcol) end
    if s.neon then for i = 0, 3 do SetVehicleNeonLightEnabled(veh, i, s.neon[i + 1] == true) end end
    if s.ncol then SetVehicleNeonLightsColour(veh, s.ncol[1], s.ncol[2], s.ncol[3]) end
    if s.smoke ~= nil then ToggleVehicleMod(veh, 20, s.smoke == true) end
    if s.scol then SetVehicleTyreSmokeColor(veh, s.scol[1], s.scol[2], s.scol[3]) end
    if s.tint then SetVehicleWindowTint(veh, s.tint) end
    if s.plate then SetVehicleNumberPlateTextIndex(veh, s.plate) end
    -- (v1.2.78) klaxon : le choix de l'atelier est dans mods[14] ; l'ancien « s.horn » (klaxon d'origine) passait après et
    -- le remettait : tous les klaxons sonnaient pareil, et le klaxon acheté n'était jamais gardé
    local horn = s.mods and tonumber(s.mods['14'] or s.mods[14]) or tonumber(s.horn)
    if horn and GetVehicleMod(veh, 14) ~= horn then if horn < 0 then RemoveVehicleMod(veh, 14) elseif horn < (GetNumVehicleMods(veh, 14) or 0) then SetVehicleMod(veh, 14, horn, false) end end
    if s.livery and s.livery >= 0 and s.livery < (GetVehicleLiveryCount(veh) or 0) then SetVehicleLivery(veh, s.livery) end
    if type(s.extras) == 'table' then
        for k, on in pairs(s.extras) do
            local n = tonumber(k)
            if n and n >= 1 and n <= 14 and DoesExtraExist(veh, n) and (IsVehicleExtraTurnedOn(veh, n) == true) ~= (on == true) then SetVehicleExtra(veh, n, on ~= true) end
        end
    end
end

local shop   -- { veh, base, cart = { [k] = { v, label, txt } }, prices }
local function merged()
    local st = {}
    for k, v in pairs(shop.base) do if k ~= 'mods' then st[k] = v end end
    st.mods, st.extras = {}, {}
    for k, v in pairs(shop.base.mods) do st.mods[k] = v end
    for k, v in pairs(shop.base.extras or {}) do st.extras[k] = v end
    for k, e in pairs(shop.cart) do
        local mt, xt = k:match('^mod:(%d+)$'), k:match('^xt:(%d+)$')
        if mt then st.mods[mt] = e.v elseif xt then st.extras[xt] = e.v else st[k] = e.v end
    end
    return st
end
local function restore() if shop and DoesEntityExist(shop.veh) then G.ApplyCustom(shop.veh, merged()) end end
local function preview(k, v)
    if not shop or not DoesEntityExist(shop.veh) then return end
    local st = merged()
    local mt, xt = k:match('^mod:(%d+)$'), k:match('^xt:(%d+)$')
    if mt then st.mods[mt] = v elseif xt then st.extras[xt] = v else st[k] = v end
    G.ApplyCustom(shop.veh, st)
end
local function money(n) return PB.Money(n) end
local function cartCount() local n = 0 for _ in pairs(shop.cart) do n = n + 1 end return n end
local function pick(k, v, label, txt) shop.cart[k] = { v = v, label = label, txt = txt } G.send('notify', { type = 'success', title = 'Devis', text = (txt or label) .. ' ajouté au devis.' }) end
-- une liste d'options : survol = aperçu sur la voiture, Entrée = au devis, sortie = retour à l'état du devis
local function optList(id, title, k, opts, priceKey, partLabel)
    local items = {}
    for _, o in ipairs(opts) do
        local cur = shop.cart[k]
        items[#items + 1] = { label = o.label, right = (cur and json.encode(cur.v) == json.encode(o.v)) and 'Au devis' or (shop.prices[priceKey] and money(shop.prices[priceKey]) or nil), val = o.v,
            onSelect = function() pick(k, o.v, partLabel or title, (partLabel or title) .. ' : ' .. o.label) end }
    end
    return { id = 'mech.' .. id, title = title, subtitle = 'Survole pour voir · Entrée : au devis', items = items,
        onHover = function(it) if it and it.val ~= nil then preview(k, it.val) end end,
        onOpen = function(m) local it = m.items and m.items[m.sel or 1] if it and it.val ~= nil then preview(k, it.val) end end,
        onClose = function() restore() end }
end
local function colorMenu(id, title, k)
    local function list(src) local o = {} for _, c in ipairs(src) do o[#o + 1] = { label = c[2], v = { c[1] } } end return o end
    local items = {
        { type = 'submenu', label = 'Classique et métallisé', submenu = optList(id .. '.c', title .. ' · classique', k, list(CLASSIC), 'color', title) },
        { type = 'submenu', label = 'Mat', submenu = optList(id .. '.m', title .. ' · mat', k, list(MATTE), 'color', title) },
        { type = 'submenu', label = 'Métal et chrome', submenu = optList(id .. '.x', title .. ' · métal', k, list(METAL), 'color', title) },
    }
    local rk = k == 'col1' and 'rgb1' or 'rgb2'
    local rl = {}
    for _, c in ipairs(RGB) do rl[#rl + 1] = { label = c[1], v = { c[2], c[3], c[4] } } end
    items[#items + 1] = { type = 'submenu', label = 'Teinte personnalisée', description = 'Couleur libre, plus vive que la palette du jeu.', submenu = optList(id .. '.r', title .. ' · teinte libre', rk, rl, 'rgb', title .. ' (teinte libre)') }
    return { id = 'mech.' .. id, title = title, items = items }
end
local function modList(t, label)
    SetVehicleModKit(shop.veh, 0)
    local n = GetNumVehicleMods(shop.veh, t) or 0
    if n <= 0 then return nil end
    local opts = { { label = "D'origine", v = -1 } }
    for i = 0, n - 1 do
        local txt = GetModTextLabel(shop.veh, t, i)
        local name = txt and txt ~= '' and GetLabelText(txt) or nil
        if not name or name == 'NULL' then name = label .. ' ' .. (i + 1) end
        opts[#opts + 1] = { label = name, v = i }
    end
    return optList('mod' .. t, label, 'mod:' .. t, opts, nil, label)
end
local function wheelsMenu()
    local items = {}
    for _, w in ipairs(WHEELS) do
        items[#items + 1] = { type = 'submenu', label = w[2], submenu = { id = 'mech.w' .. w[1], title = 'Jantes · ' .. w[2], subtitle = 'Survole pour voir · Entrée : au devis', build = function()
            local veh = shop.veh
            SetVehicleModKit(veh, 0)
            SetVehicleWheelType(veh, w[1])
            local n = GetNumVehicleMods(veh, 23) or 0
            local list = {}
            for i = 0, n - 1 do
                local txt = GetModTextLabel(veh, 23, i)
                local name = txt and txt ~= '' and GetLabelText(txt) or nil
                if not name or name == 'NULL' then name = 'Jante ' .. (i + 1) end
                list[#list + 1] = { label = name, right = money(shop.prices.wheel or 0), val = { w[1], i, false },
                    onSelect = function() pick('wheel', { w[1], i, false }, 'Jantes', 'Jantes : ' .. name) end }
            end
            if #list == 0 then list[1] = { label = 'Aucune jante de ce type pour ce véhicule', disabled = true } end
            return list
        end, onHover = function(it) if it and it.val then preview('wheel', it.val) end end, onClose = function() restore() end } }
    end
    local wl = {}
    for _, c in ipairs(CLASSIC) do wl[#wl + 1] = { label = c[2], v = c[1] } end
    for _, c in ipairs(METAL) do wl[#wl + 1] = { label = c[2], v = c[1] } end
    items[#items + 1] = { type = 'submenu', label = 'Couleur des jantes', submenu = optList('wcol', 'Couleur des jantes', 'wheelcol', wl, 'wheelcol') }
    items[#items + 1] = { type = 'submenu', label = 'Pneus', submenu = optList('tyre', 'Pneus', 'wheel', { { label = 'Pneus de série', v = { shop.base.wheel[1], shop.base.wheel[2], false } }, { label = 'Pneus personnalisés', v = { shop.base.wheel[1], shop.base.wheel[2], true } } }, 'wheel', 'Pneus') }
    local sm = {}
    for _, c in ipairs(RGB) do sm[#sm + 1] = { label = c[1], v = { c[2], c[3], c[4] } } end
    items[#items + 1] = { type = 'submenu', label = 'Fumée des pneus', submenu = { id = 'mech.smoke', title = 'Fumée des pneus', items = {
        { type = 'submenu', label = 'Activer / retirer', submenu = optList('smk', 'Fumée des pneus', 'smoke', { { label = 'Retirer', v = false }, { label = 'Installer', v = true } }, 'smoke') },
        { type = 'submenu', label = 'Couleur', submenu = optList('scol', 'Couleur de la fumée', 'scol', sm, 'scol') } } } }
    return { id = 'mech.wheels', title = 'Jantes et pneus', items = items }
end

-- Atelier v2 (v1.2.42) : écran plein cadre, voiture au centre (caméra autour du véhicule), pièces par onglets.
-- ←/→ change le réglage d'une pièce : il s'applique tout de suite sur la voiture (le client le voit) ; tout ce qui diffère de l'état
-- d'arrivée part au panier. « Valider le devis » envoie la liste au serveur, qui recalcule les prix (même logique qu'avant).
local SW = {   -- teinte approximative des couleurs du jeu pour les pastilles
    [0] = '#0d0d0f', [1] = '#26282c', [2] = '#33373d', [3] = '#5a5e64', [4] = '#9ea2a6', [5] = '#a7b3bf', [6] = '#6b7178', [7] = '#8b8f94', [8] = '#7d7a72', [9] = '#5f6670', [10] = '#4a4f55', [11] = '#2e3033',
    [27] = '#c0131d', [28] = '#b2121a', [29] = '#d4171a', [30] = '#d63a1b', [31] = '#7d1322', [32] = '#8e2a21', [33] = '#5c1426', [34] = '#c21c4a', [35] = '#e2524b', [36] = '#f06a12', [37] = '#c99a2b', [38] = '#ff7a12',
    [49] = '#123d22', [50] = '#1a5b2e', [51] = '#2f8f6f', [52] = '#4f5a2a', [53] = '#3fbf3a', [54] = '#1c6e5c', [61] = '#0f1c3a', [62] = '#182a5c', [63] = '#2b4f9a', [64] = '#1f4fbf', [65] = '#1c2e66', [66] = '#2a4d7a',
    [67] = '#4f8fd4', [68] = '#3a8fc9', [69] = '#2a5f9a', [70] = '#0b6cf0', [71] = '#4b2a8a', [72] = '#3a2a6a', [73] = '#1f3aa0', [74] = '#6fb3e6', [88] = '#f2c20f', [89] = '#ffd21a', [90] = '#9c6b2f', [91] = '#e8dc8a',
    [92] = '#8fd41a', [94] = '#4a3020', [96] = '#2e1d14', [97] = '#7a4a26', [98] = '#8a5a34', [99] = '#b89a62', [100] = '#5d6a3a', [101] = '#5a3d2a', [102] = '#6e4a2c', [103] = '#a07850', [104] = '#8a4a26',
    [105] = '#c9b08a', [106] = '#d8c8a2', [107] = '#efe5cc', [111] = '#f2f2f2', [112] = '#e4e8ec', [135] = '#ff3d8b', [136] = '#ff8a7a', [137] = '#f29ac0', [138] = '#d4561a', [141] = '#0a1230', [142] = '#2a1440',
    [143] = '#4a0f1a', [145] = '#8a5ad4', [150] = '#a3121a', [12] = '#121212', [13] = '#3a3a3a', [14] = '#8a8a8a', [39] = '#a5161e', [40] = '#5e0f14', [41] = '#c4560f', [42] = '#d4a90f', [55] = '#6fbf1a',
    [82] = '#1a2a5a', [83] = '#2a4a9a', [84] = '#141c33', [128] = '#3a5a2a', [131] = '#e6e6e6', [148] = '#5a2a8a', [149] = '#2a143f', [151] = '#24341f', [152] = '#4a4f2f', [153] = '#5a4a32', [154] = '#a08a5a',
    [155] = '#3d4a2c', [117] = '#b8bcc0', [118] = '#3a3c3f', [119] = '#d6d9dc', [158] = '#d4af37', [159] = '#c2a35a', [120] = '#e9edf1',
}
local function hex(r, g, b) return ('#%02x%02x%02x'):format(r, g, b) end
local ui, cam, doorsOpen = nil, nil, false

-- caméra : vue 3/4 avant, plus près des roues ou de l'habitacle selon l'onglet
local CAMS = { performances = { 0.0, 1.25, 0.45, 2.0 }, exterieur = { -1.0, 1.0, 0.55, 2.3 }, interieur = { -0.25, 0.15, 0.62, 0.9 }, peinture = { -1.0, 0.85, 0.5, 2.5 }, roues = { -1.15, 0.55, 0.15, 1.5 }, extras = { 1.0, -1.0, 0.5, 2.4 } }
local function camTo(tab)
    if not ui or not DoesEntityExist(ui.veh) then return end
    local p = CAMS[tab] or CAMS.exterieur
    local mn, mx = GetModelDimensions(GetEntityModel(ui.veh))
    local sx, sy, sz = mx.x - mn.x, mx.y - mn.y, mx.z - mn.z
    local off = vector3(p[1] * sx * p[4], p[2] * sy * p[4] * 0.62, sz * p[3] + 0.4)
    local pos = GetOffsetFromEntityInWorldCoords(ui.veh, off.x, off.y, off.z)
    local look = GetOffsetFromEntityInWorldCoords(ui.veh, 0.0, tab == 'interieur' and 0.2 or 0.0, tab == 'roues' and -0.15 or 0.25)
    local nc = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', pos.x, pos.y, pos.z, 0.0, 0.0, 0.0, 50.0, false, 0)
    PointCamAtCoord(nc, look.x, look.y, look.z)
    -- orbite à la souris : on repart de cette vue (angle autour du point visé, hauteur, distance)
    local rel = pos - look
    local dist = #rel
    ui.orbit = { look = look, dist = dist, yaw = math.atan(rel.y, rel.x), pitch = math.asin(math.max(-1.0, math.min(1.0, rel.z / math.max(dist, 0.01)))), maxd = math.max(4.0, (sx + sy) * 1.6) }
    if cam and DoesCamExist(cam) then SetCamActiveWithInterp(nc, cam, 650, 1, 1) Wait(10) local old = cam SetTimeout(700, function() if DoesCamExist(old) then DestroyCam(old, false) end end)
    else SetCamActive(nc, true) RenderScriptCams(true, true, 500, true, true) end
    cam = nc
end
local function camOff() if cam then RenderScriptCams(false, true, 500, true, true) if DoesCamExist(cam) then DestroyCam(cam, false) end cam = nil end end

-- lecture des statistiques (0-100) : d'origine et après les pièces de performance
local function stats(veh, st)
    local spd = math.min(100, math.floor((GetVehicleEstimatedMaxSpeed(veh) or 40) * 1.4))
    local acc = math.min(100, math.floor((GetVehicleAcceleration(veh) or 0.3) * 160))
    local brk = math.min(100, math.floor((GetVehicleMaxBraking(veh) or 0.8) * 70))
    local grp = math.min(100, math.floor((GetVehicleMaxTraction(veh) or 2.2) * 26))
    return { speed = spd, accel = acc, brake = brk, grip = grp }
end

local function opt(label, v, sw) return { label = label, v = v, sw = sw } end
local function curIndex(opts, v) local ev = json.encode(v) for i, o in ipairs(opts) do if json.encode(o.v) == ev then return i end end return nil end
local function piece(k, label, opts, base, price, style, extra)
    local bi = curIndex(opts, base)
    if not bi then   -- réglage actuel absent de la liste (couleur libre, pièce rare…) : il devient la première option « Actuel »
        local sw = (style == 'swatch' and type(base) == 'table' and #base == 3 and base[1] >= 0) and hex(base[1], base[2], base[3]) or (style == 'swatch' and type(base) == 'table' and SW[base[1]]) or (style == 'swatch' and SW[base]) or nil
        table.insert(opts, 1, opt('Actuel', base, sw))
        bi = 1
    end
    local p = { k = k, label = label, opts = opts, base = bi, price = price, style = style }
    for kk, vv in pairs(extra or {}) do p[kk] = vv end
    p.sel = p.base
    return p
end
local function modPiece(t, label, price, style)
    SetVehicleModKit(ui.veh, 0)
    local n = GetNumVehicleMods(ui.veh, t) or 0
    if n <= 0 then return nil end
    local opts = { opt(style == 'level' and 'Aucun' or "D'origine", -1) }
    for i = 0, n - 1 do
        local name
        if style == 'level' then name = 'Niveau ' .. (i + 1)
        else
            local txt = GetModTextLabel(ui.veh, t, i)
            name = txt and txt ~= '' and GetLabelText(txt) or nil
            if not name or name == 'NULL' then name = label .. ' ' .. (i + 1) end
        end
        opts[#opts + 1] = opt(name, i)
    end
    return piece('mod:' .. t, label, opts, ui.base.mods[tostring(t)] or -1, price, style, { perf = style == 'level' and t or nil })
end
local function colorOpts(list) local o = {} for _, c in ipairs(list) do o[#o + 1] = opt(c[2], { c[1] }, SW[c[1]] or '#888') end return o end
local function colorOpts1(list) local o = {} for _, c in ipairs(list) do o[#o + 1] = opt(c[2], c[1], SW[c[1]] or '#888') end return o end
local function rgbOpts() local o = {} for _, c in ipairs(RGB) do o[#o + 1] = opt(c[1], { c[2], c[3], c[4] }, hex(c[2], c[3], c[4])) end return o end
local function wheelOpts(wtype)
    local veh = ui.veh
    SetVehicleModKit(veh, 0)
    local keep = GetVehicleWheelType(veh)
    SetVehicleWheelType(veh, wtype)
    local n = GetNumVehicleMods(veh, 23) or 0
    local o = { opt("D'origine", { wtype, -1, false }) }
    for i = 0, n - 1 do
        local txt = GetModTextLabel(veh, 23, i)
        local name = txt and txt ~= '' and GetLabelText(txt) or nil
        if not name or name == 'NULL' then name = 'Jante ' .. (i + 1) end
        o[#o + 1] = opt(name, { wtype, i, false })
    end
    SetVehicleWheelType(veh, keep)
    return o
end

local function buildTabs(prices, perfPrice)
    local P = function(k) return math.floor(tonumber(prices[k]) or 0) end
    local b = ui.base
    local tabs = {}
    -- Performances
    local perf = {}
    for _, p in ipairs(PERF) do local m = modPiece(p[1], p[2], perfPrice[tostring(p[1])] or 0, 'level') if m then m.perLevel = true perf[#perf + 1] = m end end
    perf[#perf + 1] = piece('turbo', 'Turbo', { opt('Sans', false), opt('Installé', true) }, b.turbo == true, P('turbo'), 'toggle')
    tabs[#tabs + 1] = { id = 'performances', label = 'Performances', pieces = perf }
    -- Extérieur
    local ext = {}
    for _, x in ipairs(BODY) do local m = modPiece(x[1], x[2], P('body')) if m then ext[#ext + 1] = m end end
    local lv = GetVehicleLiveryCount(ui.veh)
    if lv and lv > 0 then local o = {} for i = 0, lv - 1 do o[#o + 1] = opt('Livrée ' .. (i + 1), i) end ext[#ext + 1] = piece('livery', 'Livrée', o, b.livery, P('livery')) end
    local m48 = modPiece(48, 'Livrée (kit)', P('livery')) if m48 then ext[#ext + 1] = m48 end
    local tl = {} for _, t in ipairs(TINT) do tl[#tl + 1] = opt(t[2], t[1]) end
    ext[#ext + 1] = piece('tint', 'Vitres teintées', tl, b.tint, P('tint'))
    local pl = {} for _, p in ipairs(PLATES) do pl[#pl + 1] = opt(p[2], p[1]) end
    ext[#ext + 1] = piece('plate', 'Plaque', pl, b.plate, P('plate'))
    tabs[#tabs + 1] = { id = 'exterieur', label = 'Extérieur', pieces = ext }
    -- Intérieur
    local int = {}
    int[#int + 1] = piece('int', 'Couleur intérieure', colorOpts1(CLASSIC), b.int, P('interior'), 'swatch')
    int[#int + 1] = piece('dash', 'Tableau de bord', colorOpts1(CLASSIC), b.dash, P('interior'), 'swatch')
    for _, x in ipairs(EXTRA) do if x[1] >= 27 and x[1] <= 37 then local m = modPiece(x[1], x[2], P('extra')) if m then int[#int + 1] = m end end end
    tabs[#tabs + 1] = { id = 'interieur', label = 'Intérieur', pieces = int }
    -- Peinture
    local all = {} for _, l in ipairs({ CLASSIC, MATTE, METAL }) do for _, c in ipairs(l) do all[#all + 1] = c end end
    local paint = {
        piece('col1', 'Couleur principale', colorOpts(all), b.col1, P('color'), 'swatch'),
        piece('col2', 'Couleur secondaire', colorOpts(all), b.col2, P('color'), 'swatch'),
        piece('pearl', 'Nacré', colorOpts1(CLASSIC), b.pearl, P('pearl'), 'swatch'),
        piece('rgb1', 'Teinte libre (principale)', (function() local o = rgbOpts() table.insert(o, 1, opt('Aucune', { -1, -1, -1 })) return o end)(), b.rgb1 or { -1, -1, -1 }, P('rgb'), 'swatch'),
        piece('rgb2', 'Teinte libre (secondaire)', (function() local o = rgbOpts() table.insert(o, 1, opt('Aucune', { -1, -1, -1 })) return o end)(), b.rgb2 or { -1, -1, -1 }, P('rgb'), 'swatch'),
    }
    tabs[#tabs + 1] = { id = 'peinture', label = 'Peinture', pieces = paint }
    -- Roues
    local wt, bike = {}, isBike(ui.veh)
    for _, w in ipairs(WHEELS) do if (w[1] == 6) == bike then wt[#wt + 1] = opt(w[2], w[1]) end end
    local wb = b.wheel or { 0, -1, false }
    local roues = {
        piece('wtype', 'Type de jantes', wt, wb[1], 0, nil, { local_ = true }),
        piece('wheel', 'Jantes', wheelOpts(wb[1]), { wb[1], wb[2], false }, P('wheel')),
        piece('wheelcol', 'Couleur des jantes', colorOpts1(CLASSIC), b.wheelcol, P('wheelcol'), 'swatch'),
        piece('tyre', 'Pneus', { opt('De série', false), opt('Personnalisés', true) }, wb[3] == true, P('wheel'), 'toggle', { local_ = true }),
        piece('smoke', 'Fumée des pneus', { opt('Sans', false), opt('Installée', true) }, b.smoke == true, P('smoke'), 'toggle'),
        piece('scol', 'Couleur de la fumée', rgbOpts(), b.scol, P('scol'), 'swatch'),
    }
    tabs[#tabs + 1] = { id = 'roues', label = 'Roues', pieces = roues }
    -- Extras
    local xl = {} for _, x in ipairs(XENON) do xl[#xl + 1] = opt(x[2], x[1]) end
    local extras = {
        piece('xenon', 'Phares xénon', { opt("D'origine", false), opt('Xénon', true) }, b.xenon == true, P('xenon'), 'toggle'),
        piece('xcol', 'Couleur des xénons', xl, b.xcol, P('xcol')),
        piece('neon', 'Néons', { opt('Aucun', { false, false, false, false }), opt('Tout autour', { true, true, true, true }), opt('Côtés', { true, true, false, false }), opt('Avant et arrière', { false, false, true, true }) }, b.neon, P('neon')),
        piece('ncol', 'Couleur des néons', rgbOpts(), b.ncol, P('ncol'), 'swatch'),
    }
    local horn = modPiece(14, 'Klaxon', P('horn')) if horn then horn.horn = true extras[#extras + 1] = horn end
    for _, x in ipairs(EXTRA) do if x[1] < 27 or x[1] > 37 then local m = modPiece(x[1], x[2], P('extra')) if m then extras[#extras + 1] = m end end end
    for n = 1, 14 do
        if DoesExtraExist(ui.veh, n) then
            extras[#extras + 1] = piece('xt:' .. n, 'Option du modèle ' .. n, { opt('Retirée', false), opt('Montée', true) }, b.extras and b.extras[tostring(n)] == true, P('extra'), 'toggle')
        end
    end
    tabs[#tabs + 1] = { id = 'extras', label = 'Extras', pieces = extras }
    return tabs
end

-- état « sélection » -> état complet à appliquer (base + tout ce qui a changé)
local function selState()
    local st = merged()
    for _, t in ipairs(ui.tabs) do for _, p in ipairs(t.pieces) do
        if p.sel ~= p.base and not p.local_ then
            local v = p.opts[p.sel].v
            local mt, xt = p.k:match('^mod:(%d+)$'), p.k:match('^xt:(%d+)$')
            if mt then st.mods[mt] = v elseif xt then st.extras[xt] = v else st[p.k] = v end
        end
    end end
    -- jantes : type et pneus combinés dans « wheel »
    local wtype, wheel, tyre
    for _, t in ipairs(ui.tabs) do for _, p in ipairs(t.pieces) do
        if p.k == 'wtype' then wtype = p.opts[p.sel].v elseif p.k == 'wheel' then wheel = p elseif p.k == 'tyre' then tyre = p.opts[p.sel].v end
    end end
    if wheel then
        local v = wheel.opts[wheel.sel].v
        st.wheel = { v[1] or wtype, v[2], tyre == true }
    end
    -- « Aucune » teinte libre : on la retire vraiment (false), au lieu d'envoyer { -1, -1, -1 } que le serveur refusait
    if type(st.rgb1) == 'table' and st.rgb1[1] == -1 then st.rgb1 = false end
    if type(st.rgb2) == 'table' and st.rgb2[1] == -1 then st.rgb2 = false end
    return st
end
local function changes()
    local list = {}
    local base = ui.base
    local st = selState()
    for _, t in ipairs(ui.tabs) do for _, p in ipairs(t.pieces) do
        if not p.local_ and p.k ~= 'wheel' and p.sel ~= p.base then
            local v = p.opts[p.sel].v
            if (p.k == 'rgb1' or p.k == 'rgb2') and type(v) == 'table' and v[1] == -1 then v = false end
            list[#list + 1] = { k = p.k, v = v, label = p.label }
        end
    end end
    if json.encode(st.wheel) ~= json.encode(base.wheel) then list[#list + 1] = { k = 'wheel', v = st.wheel, label = 'Jantes' } end
    return list
end
local function findPiece(k) for _, t in ipairs(ui.tabs) do for _, p in ipairs(t.pieces) do if p.k == k then return p end end end end

G.nui['mech.set'] = function(d)
    if not ui then return {} end
    local p = findPiece(tostring(d.k or ''))
    local i = math.floor(tonumber(d.i) or 0)
    if not p or i < 1 or i > #p.opts then return {} end
    p.sel = i
    local reply = {}
    if p.k == 'wtype' then   -- nouveau type de jantes : nouvelle liste de modèles
        local w = findPiece('wheel')
        if w then
            local bw = ui.base.wheel or { 0, -1, false }
            w.opts = wheelOpts(p.opts[i].v)
            w.base = (bw[1] == p.opts[i].v) and (curIndex(w.opts, { bw[1], bw[2], false }) or 1) or 0
            w.sel = w.base > 0 and w.base or 1
            reply.wheel = w
        end
    end
    if DoesEntityExist(ui.veh) then G.ApplyCustom(ui.veh, selState()) end
    if p.horn then SetTimeout(150, function() if ui and DoesEntityExist(ui.veh) then StartVehicleHorn(ui.veh, 1100, joaat('HELDDOWN'), false) end end) end   -- d'origine compris
    if p.k == 'xenon' or p.k == 'xcol' then SetVehicleLights(ui.veh, 2) SetTimeout(2500, function() if ui and DoesEntityExist(ui.veh) then SetVehicleLights(ui.veh, 0) end end) end
    return reply
end
-- Rotation de la caméra : glisser avec le clic (gauche-droite = tourner, haut-bas = hauteur), molette = zoom
G.nui['mech.orbit'] = function(d)
    local o = ui and ui.orbit
    if not o or not cam or not DoesCamExist(cam) then return {} end
    local dx, dy, dz = tonumber(d.dx) or 0, tonumber(d.dy) or 0, tonumber(d.zoom) or 0
    o.yaw = o.yaw - math.max(-400, math.min(400, dx)) * 0.0065
    o.pitch = math.max(-0.05, math.min(1.25, o.pitch + math.max(-400, math.min(400, dy)) * 0.0045))
    if dz ~= 0 then o.dist = math.max(1.2, math.min(o.maxd, o.dist * (dz > 0 and 1.1 or 0.9))) end
    local cp = math.cos(o.pitch)
    local x, y, z = o.look.x + o.dist * cp * math.cos(o.yaw), o.look.y + o.dist * cp * math.sin(o.yaw), o.look.z + o.dist * math.sin(o.pitch)
    local ok, gz = GetGroundZFor_3dCoord(x, y, z + 1.0, false)
    if ok and z < gz + 0.25 then z = gz + 0.25 end   -- jamais sous le sol
    SetCamCoord(cam, x, y, z)
    PointCamAtCoord(cam, o.look.x, o.look.y, o.look.z)
    return {}
end
G.nui['mech.tab'] = function(d) if ui then CreateThread(function() camTo(tostring(d.id or '')) end) end return {} end
G.nui['mech.doors'] = function()
    if not ui or not DoesEntityExist(ui.veh) then return {} end
    doorsOpen = not doorsOpen
    for i = 0, 5 do if doorsOpen then SetVehicleDoorOpen(ui.veh, i, false, false) else SetVehicleDoorShut(ui.veh, i, false) end end
    return { open = doorsOpen }
end
local function closeUi(keep)
    if not ui then return end
    local u = ui
    ui = nil
    G.focus(false)
    G.send('mech.close', {})
    camOff()
    if DoesEntityExist(u.veh) then
        for i = 0, 5 do SetVehicleDoorShut(u.veh, i, false) end
        if not keep then restore() end
    end
    doorsOpen = false
end
G.nui['mech.cancel'] = function() if shop then shop.cart = {} end closeUi(false) return {} end
G.nui['mech.quote'] = function()
    if not ui then return {} end
    local list = changes()
    if #list == 0 then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucune modification au panier.' }) return {} end
    -- le devis devient la sélection courante (la voiture garde l'aperçu jusqu'au paiement ou au refus du client)
    shop.cart = {}
    for _, c in ipairs(list) do shop.cart[c.k] = { v = c.v, label = c.label, txt = c.label } end
    shop.orig = shop.orig or shop.base   -- état d'avant le devis : c'est lui qu'on remet si la facture est refusée
    TriggerServerEvent('pb:g:mech:quote', NetworkGetNetworkIdFromEntity(ui.veh), list)
    closeUi(true)
    return {}
end

local function openShop(d)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Monte dans le véhicule du client pour le customiser.' }) return end
    if not NetworkHasControlOfEntity(veh) then NetworkRequestControlOfEntity(veh) end
    local prev = shop
    shop = { veh = veh, base = readState(veh), cart = {}, prices = d.prices or {}, orig = (prev and prev.veh == veh) and prev.orig or nil }
    ui = { veh = veh, base = shop.base }
    ui.tabs = buildTabs(d.prices or {}, d.perf or {})
    G.ApplyCustom(veh, shop.base)
    local s0 = stats(veh, shop.base)
    G.focus(true)
    G.send('mech.open', { biz = d.biz or 'Atelier', plate = plateOf(veh), label = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(veh))), tabs = ui.tabs, stats = s0 })
    CreateThread(function() camTo('performances') end)
    CreateThread(function()   -- le mécanicien reste au volant, sans conduire, pendant l'atelier
        while ui do
            DisableAllControlActions(0)
            EnableControlAction(0, 249, true)   -- push-to-talk
            HideHudAndRadarThisFrame()
            Wait(0)
        end
    end)
end
G.onForceClose(function() closeUi(false) end)

RegisterNetEvent('pb:g:mech:ui', function(j) local d = G.decode(j) if d then openShop(d) end end)
-- (v1.2.78) custom validée : le menu « Envoyer la facture » s'ouvre tout seul (avant, il fallait passer par F6)
RegisterNetEvent('pb:g:mech:quoted', function()
    CreateThread(function()
        local t = GetGameTimer() + 3000
        while (ui or IsNuiFocused()) and GetGameTimer() < t do Wait(100) end   -- l'atelier se ferme d'abord
        Wait(250)
        if G.Menu.IsOpen() then G.Menu.Close() Wait(100) end
        ExecuteCommand('pb_mech_bill')
    end)
end)
-- facture refusée : la voiture revient comme avant ; payée : le devis devient l'état de base
RegisterNetEvent('pb:g:mech:revert', function(netId)
    if not shop then return end
    local veh = shop.veh
    local back = shop.orig or shop.base
    if DoesEntityExist(veh) then if not NetworkHasControlOfEntity(veh) then NetworkRequestControlOfEntity(veh) Wait(200) end G.ApplyCustom(veh, back) end
    shop.base, shop.orig, shop.cart = back, nil, {}
end)
RegisterNetEvent('pb:g:mech:keep', function() if shop then shop.base = merged() shop.cart = {} shop.orig = nil end end)

-- Réparer / nettoyer (menu F6) : véhicule le plus proche, animation, le serveur vérifie la durée
local function closestVeh(r)
    local ped = PlayerPedId()
    local v = GetVehiclePedIsIn(ped, false)
    if v ~= 0 then return v end
    local c = GetEntityCoords(ped)
    v = GetClosestVehicle(c.x, c.y, c.z, r or 5.0, 0, 71)
    return v ~= 0 and v or nil
end
RegisterCommand('pb_mech_repair', function() local v = closestVeh() if not v then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun véhicule à côté.' }) return end TriggerServerEvent('pb:g:mech:start', 'repair', NetworkGetNetworkIdFromEntity(v)) end, false)
RegisterCommand('pb_mech_clean', function() local v = closestVeh() if not v then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun véhicule à côté.' }) return end TriggerServerEvent('pb:g:mech:start', 'clean', NetworkGetNetworkIdFromEntity(v)) end, false)
RegisterNetEvent('pb:g:mech:work', function(j)
    local d = G.decode(j)
    if not d then return end
    CreateThread(function()
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then TaskLeaveAnyVehicle(ped, 0, 0) Wait(1500) end
        local start = GetEntityCoords(ped)
        TaskStartScenarioInPlace(ped, d.kind == 'clean' and 'WORLD_HUMAN_MAID_CLEAN' or 'PROP_HUMAN_BUM_BIN', 0, true)
        G.send('crime.progress', { label = d.kind == 'clean' and 'Nettoyage du véhicule' or 'Réparation du véhicule', secs = d.secs })
        local t = GetGameTimer() + d.secs * 1000
        while GetGameTimer() < t do
            Wait(250)
            if #(GetEntityCoords(ped) - start) > 3.0 or IsEntityDead(ped) then ClearPedTasks(ped) G.send('crime.progress', { cancel = true }) G.send('notify', { type = 'warn', title = 'Atelier', text = 'Travail interrompu.' }) return end
        end
        ClearPedTasks(ped)
        TriggerServerEvent('pb:g:mech:done')
    end)
end)
-- Facture : choix du client parmi les joueurs proches
RegisterCommand('pb_mech_bill', function()
    local me = GetEntityCoords(PlayerPedId())
    local items = {}
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= PlayerPedId() and #(GetEntityCoords(ped) - me) < 8.0 then
            local sid = GetPlayerServerId(pid)
            local inside = GetVehiclePedIsIn(ped, false) ~= 0 and GetVehiclePedIsIn(ped, false) == GetVehiclePedIsIn(PlayerPedId(), false)
            items[#items + 1] = { label = 'Client à ' .. math.floor(#(GetEntityCoords(ped) - me) + 0.5) .. ' m' .. (inside and ' (dans le véhicule)' or ''), icon = 'user', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:mech:bill', sid) end }
        end
    end
    if #items == 0 then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun client à côté de toi : F6 › Envoyer la facture quand il sera là.' }) return end
    G.Menu.Open({ id = 'mech.bill', title = 'Envoyer la facture', subtitle = 'Choisis le client', items = items })
end, false)
-- Le client reçoit la facture : payer ou refuser
RegisterNetEvent('pb:g:mech:offer', function(j)
    local d = G.decode(j)
    if not d then return end
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    local items = {}
    for _, it in ipairs(d.items or {}) do items[#items + 1] = { label = it.label, right = money(it.price), disabled = true } end
    items[#items + 1] = { type = 'separator', label = 'Total : ' .. money(d.amount) }
    items[#items + 1] = { label = 'Payer ' .. money(d.amount), icon = 'check', description = 'Banque d\'abord, sinon espèces.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:mech:answer', d.id, true) end }
    items[#items + 1] = { label = 'Refuser', icon = 'x', description = 'La customisation est retirée du véhicule.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:mech:answer', d.id, false) end }
    G.Menu.Open({ id = 'mech.offer', title = tostring(d.biz or 'Garage'), subtitle = 'Facture de ' .. tostring(d.from or ''), banner = { text = 'Facture' }, items = items })
end)


RegisterNetEvent('pb:g:mech:do', function(j)
    local d = G.decode(j)
    if not d then return end
    local veh = NetworkGetEntityFromNetworkId(d.netId or 0)
    if not veh or veh == 0 or not DoesEntityExist(veh) then veh = nearestVeh() end
    if not veh or not grab(veh) then G.send('notify', { type = 'error', title = 'Atelier', text = 'Impossible de travailler sur ce véhicule.' }) return end
    if d.kind == 'clean' then SetVehicleDirtLevel(veh, 0.0) WashDecalsFromVehicle(veh, 1.0)
    elseif d.kind == 'repair' then
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    else G.ApplyPart(veh, d.kind, d.mod, d.level) end
end)
