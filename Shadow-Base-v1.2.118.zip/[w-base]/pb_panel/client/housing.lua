-- Logements : blips, marqueur et invite (E) devant la porte, menu, ouverture du coffre, entrée / sortie sur ordre du serveur.
local G = PBG
local isOpen = false
local points, blips = {}, {}
local inside = nil   -- { id } quand le joueur est dans un intérieur configuré

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if not isOpen then return end
    isOpen = false
    TriggerServerEvent('pb:g:housing:close')
    G.focus(false)
    G.send('housing.close', {})
end

RegisterNetEvent('pb:g:housing:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then TriggerServerEvent('pb:g:housing:close') return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('housing.' .. tostring(d.ev), d)
end)
G.nui['housing.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:housing:page', tostring(d.page or 'home')) end return {} end
G.nui['housing.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:housing:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end return {} end
G.nui['housing.close'] = function() close() return {} end

-- Le coffre s'ouvre dans la fenêtre d'inventaire
RegisterNetEvent('pb:g:housing:stash', function(owner)
    close()
    Wait(150)
    TriggerServerEvent('pb:g:inv:open', tostring(owner))
end)

-- Meubles de l'intérieur : objets locaux, recréés à chaque entrée et à chaque changement
local furn, placing = {}, nil
local function clearFurniture() for _, f in ipairs(furn) do if DoesEntityExist(f.obj) then DeleteEntity(f.obj) end end furn = {} end
local function loadModel(m) local h = joaat(m) if not IsModelInCdimage(h) then return nil end RequestModel(h) local t = GetGameTimer() + 3000 while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end return HasModelLoaded(h) and h or nil end
local function spawnFurniture(list)
    clearFurniture()
    for _, f in ipairs(list or {}) do
        local h = loadModel(f.m)
        if h then
            local o = CreateObject(h, f.x + 0.0, f.y + 0.0, f.z + 0.0, false, false, false)
            SetEntityHeading(o, f.h + 0.0) FreezeEntityPosition(o, true)
            SetModelAsNoLongerNeeded(h)
            furn[#furn + 1] = { id = f.id, obj = o, m = f.m }
        end
    end
end
RegisterNetEvent('pb:g:housing:furn', function(j) if inside then spawnFurniture(G.decode(j)) end end)

-- Pose d'un meuble : fantôme devant soi ; ← → tourner, ↑ ↓ distance, Page haut / bas hauteur, Entrée valider, Retour annuler
local function place(model, label)
    local h = loadModel(model)
    if not h then G.send('notify', { type = 'error', title = 'Meubles', text = label .. ' : modèle indisponible dans cette version du jeu.' }) return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local ghost = CreateObject(h, c.x, c.y, c.z, false, false, false)
    SetEntityAlpha(ghost, 170, false) SetEntityCollision(ghost, false, false) FreezeEntityPosition(ghost, true)
    local dist, rot, dz = 1.8, GetEntityHeading(ped) + 180.0, 0.0
    placing = true
    G.send('prompt', { show = true, key = '↵', text = label .. ' : ← → tourner · ↑ ↓ distance · PgHaut / PgBas hauteur · Retour : annuler' })
    while placing do
        Wait(0)
        for _, k in ipairs({ 172, 173, 174, 175, 10, 11, 201, 202, 177, 194 }) do DisableControlAction(0, k, true) end
        if IsDisabledControlPressed(0, 174) then rot = rot + 2.0 end
        if IsDisabledControlPressed(0, 175) then rot = rot - 2.0 end
        if IsDisabledControlPressed(0, 172) then dist = math.min(4.0, dist + 0.02) end
        if IsDisabledControlPressed(0, 173) then dist = math.max(0.6, dist - 0.02) end
        if IsDisabledControlPressed(0, 10) then dz = math.min(2.5, dz + 0.01) end
        if IsDisabledControlPressed(0, 11) then dz = math.max(-1.5, dz - 0.01) end
        local p = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, dist, -1.0 + dz)
        SetEntityCoordsNoOffset(ghost, p.x, p.y, p.z, false, false, false)
        SetEntityHeading(ghost, rot)
        if IsDisabledControlJustPressed(0, 201) then
            TriggerServerEvent('pb:g:housing:furnadd', model, p.x, p.y, p.z, rot % 360.0)
            placing = false
        elseif IsDisabledControlJustPressed(0, 202) or IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 194) then placing = false end
    end
    DeleteEntity(ghost)
    SetModelAsNoLongerNeeded(h)
    G.send('prompt', { show = false })
end
RegisterNetEvent('pb:g:housing:furncat', function(j)
    local list = G.decode(j) or {}
    local items = {}
    for _, f in ipairs(list) do items[#items + 1] = { label = f.label, icon = f.aquarium and 'drop' or 'home', right = f.qty and ('×' .. f.qty) or nil, onSelect = function() G.Menu.Close() CreateThread(function() place(f.m or f.model, f.label) end) end } end
    G.Menu.Open({ id = 'housing.furn', title = 'Meubles', subtitle = inside and inside.label or 'Logement', items = items })
end)
local function nearestFurniture(maxd)
    local c = GetEntityCoords(PlayerPedId())
    local best, bd
    for _, f in ipairs(furn) do if DoesEntityExist(f.obj) then local d = #(GetEntityCoords(f.obj) - c) if d < maxd and (not bd or d < bd) then best, bd = f, d end end end
    return best
end
RegisterNetEvent('pb:g:housing:aquarium', function(j)
    local d = G.decode(j) or {}
    local items = { { type = 'separator', label = ('Dans l\'aquarium (%d / 12)'):format(#(d.fish or {})) } }
    for _, f in ipairs(d.fish or {}) do items[#items + 1] = { label = f.label, icon = 'drop', right = 'Reprendre', onSelect = function() TriggerServerEvent('pb:g:housing:aquarium', 'take', f.id) end } end
    if #(d.fish or {}) == 0 then items[#items + 1] = { label = 'Aucun poisson pour le moment', disabled = true } end
    items[#items + 1] = { type = 'separator', label = 'Tes poissons' }
    for _, f in ipairs(d.mine or {}) do items[#items + 1] = { label = f.label, right = '×' .. f.qty, description = "Le mettre dans l'aquarium.", onSelect = function() TriggerServerEvent('pb:g:housing:aquarium', 'put', f.item) end } end
    if #(d.mine or {}) == 0 then items[#items + 1] = { label = 'Aucun poisson dans ton sac', disabled = true } end
    G.Menu.Close()
    G.Menu.Open({ id = 'housing.aquarium', title = 'Aquarium', subtitle = inside and inside.label or '', items = items })
end)
local function insideMenu()
    local items = {
        { label = 'Sortir', icon = 'gps', onSelect = function()
            G.Menu.Close()
            local id = inside.id
            TriggerServerEvent('pb:g:housing:exit', id)
            SetTimeout(2500, function() if inside and inside.id == id then TriggerServerEvent('pb:g:housing:exit', id) end end)
        end },
        { label = 'Poser un meuble', icon = 'plus', description = 'Un meuble de ton sac (Magasin de meubles).', onSelect = function() TriggerServerEvent('pb:g:housing:furncat') end },
        { label = 'Retirer le meuble le plus proche', icon = 'x', description = 'Il revient dans ton sac.', onSelect = function()
            local f = nearestFurniture(3.0)
            if not f then G.send('notify', { type = 'warn', title = 'Meubles', text = 'Aucun meuble à moins de 3 m.' }) return end
            G.Menu.Close() TriggerServerEvent('pb:g:housing:furndel', f.id)
        end },
    }
    for _, f in ipairs(furn) do
        if f.m == 'prop_aquarium_01' then items[#items + 1] = { label = 'Aquarium', icon = 'drop', onSelect = function() TriggerServerEvent('pb:g:housing:aquarium', 'view') end } break end
    end
    G.Menu.Open({ id = 'housing.inside', title = inside.label or 'Logement', subtitle = 'Chez toi', items = items })
end

RegisterNetEvent('pb:g:housing:teleport', function(j)
    local d = G.decode(j)
    if not d then return end
    local ped = PlayerPedId()
    DoScreenFadeOut(400)
    while not IsScreenFadedOut() do Wait(20) end
    close()
    RequestCollisionAtCoord(d.x + 0.0, d.y + 0.0, d.z + 0.0)
    SetEntityCoords(ped, d.x + 0.0, d.y + 0.0, d.z + 0.0, false, false, false, false)
    if d.h then SetEntityHeading(ped, d.h + 0.0) end
    local t = GetGameTimer()
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 4000 do Wait(20) end
    inside = d.exit and nil or { id = d.id, label = d.label, door = vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0) }
    if d.exit then clearFurniture() else spawnFurniture(d.furn) end
    DoScreenFadeIn(400)
end)

-- Carte : vert = libre (à vendre / à louer), rouge = occupé, rose = chez toi (ou un logement dont tu as la clé)
local mine, showBlips = {}, false
local function shortLabel(p)
    local l = tostring(p.label or 'Logement')
    if p.free then return l end
    -- « Maison à vendre » une fois achetée : on retire la mention (texte exact, sans motif : les accents sont sur 2 octets)
    for _, w in ipairs({ ' (à vendre)', ' - à vendre', ' · à vendre', ' à vendre', ' (à louer)', ' - à louer', ' · à louer', ' à louer', 'À vendre', 'À louer' }) do
        local i = l:find(w, 1, true)
        if i then l = l:sub(1, i - 1) .. l:sub(i + #w) end
    end
    l = l:gsub('^%s+', ''):gsub('%s+$', '')
    return l ~= '' and l or 'Logement'
end
G.HousingLabel = shortLabel
local function drawBlips()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not showBlips then return end
    for _, p in ipairs(points) do
        local own = mine[tostring(p.id)] == true
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(b, 40) SetBlipColour(b, own and 8 or (p.free and 2 or 1)) SetBlipScale(b, own and 0.85 or 0.7) SetBlipAsShortRange(b, not own)
        local name = own and ('Chez moi : ' .. shortLabel(p)) or (p.free and (shortLabel(p) .. (p.kind == 'rent' and ' · à louer' or ' · à vendre')) or (shortLabel(p) .. ' · occupé'))
        if p.free and tostring(p.label):lower():find('à vendre', 1, true) then name = shortLabel(p) end
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(name) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end
RegisterNetEvent('pb:g:housing:mine', function(j)
    local t = G.decode(j)
    mine = {}
    for _, id in ipairs(type(t) == 'table' and t or {}) do mine[tostring(id)] = true end
    drawBlips()
end)
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    points = c.housing_points or {}
    showBlips = (c.housing and c.housing.blips) and true or false
    drawBlips()
end

CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or busy() or isOpen then hide() Wait(700)
        elseif inside then
            -- à l'intérieur : E à la porte (là où on est arrivé) pour sortir, meubles, aquarium (le serveur vérifie les droits)
            local c = GetEntityCoords(PlayerPedId())
            local d = inside.door and #(c - inside.door) or 0.0
            if d > 80.0 then
                -- on n'est plus dans le logement (téléporté, réapparu…) : on oublie l'intérieur, l'invite disparaît
                inside = nil clearFurniture() hide()
            elseif placing or G.Menu.IsOpen() then hide() Wait(200)
            elseif d <= 2.0 then
                G.Point(inside.door.x, inside.door.y, inside.door.z - 0.95, 223, 226, 231, 1.0)
                if not shown or key ~= 'out' then shown, key = true, 'out' G.send('prompt', { show = true, key = 'E', text = tostring(inside.label) .. ' : sortir, meubles, aquarium' }) end
                if IsControlJustPressed(0, 38) then hide() insideMenu() end
                Wait(0)
            else
                hide()
                if d <= 12.0 then G.Point(inside.door.x, inside.door.y, inside.door.z - 0.95, 223, 226, 231, 1.0) Wait(0) else Wait(300) end
            end
        elseif #points == 0 then hide() Wait(1000)
        else
            local hc = G.cfg.housing or {}
            local c = GetEntityCoords(PlayerPedId())
            -- portes proches recalculées toutes les 0,5 s (pas toute la liste à chaque image)
            local now = GetGameTimer()
            if now >= (G._hsScan or 0) then
                G._hsScan = now + 500
                G._hsCand = {}
                for _, p in ipairs(points) do if #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) < 30.0 then G._hsCand[#G._hsCand + 1] = p end end
            end
            local best, bd = nil, 1e9
            for _, p in ipairs(G._hsCand or {}) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd = p, d end end
            if best and bd <= 12.0 and not IsPedInAnyVehicle(PlayerPedId(), false) then
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
                if bd <= (hc.use_distance or 2.5) then
                    if not shown or key ~= best.id then shown, key = true, best.id G.send('prompt', { show = true, key = 'E', text = shortLabel(best) }) end
                    if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:housing:open', best.id) end
                else hide() end
                Wait(0)
            else hide() Wait(500) end
        end
    end
end)

CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)

-- Agence immobilière : mettre un logement en annonce à sa position, avec une gamme à prix fixe (intérieur posé automatiquement)
RegisterNetEvent('pb:g:realtor:menu', function(j)
    local tiers = G.decode(j)
    if type(tiers) ~= 'table' or #tiers == 0 then return end
    local st = { tier = 1, kind = 1, name = '' }
    local function money(n) return G.money and G.money(n) or (tostring(n) .. ' $') end
    local function labels() local t = {} for i, x in ipairs(tiers) do t[i] = x.label .. ' · ' .. money(x.price) .. ' / ' .. money(x.rent) end return t end
    G.Menu.Open({ id = 'realtor.list', title = 'Agence immobilière', subtitle = 'Nouvelle annonce', items = {
        { type = 'list', label = 'Gamme', icon = 'home', list = labels(), index = 1, description = "Prix de vente / loyer fixés par le serveur. L'intérieur de la gamme est posé automatiquement.", onChange = function(_, _, i) st.tier = i end },
        { type = 'list', label = 'Annonce', icon = 'tag', list = { 'À vendre', 'À louer' }, index = 1, onChange = function(_, _, i) st.kind = i end },
        { type = 'input', label = 'Nom du logement', icon = 'brush', prompt = 'Nom du logement (ex. Maison de Vinewood)', maxlen = 48, onChange = function(_, v) st.name = tostring(v or '') end },
        { type = 'button', label = 'Mettre en annonce ici', icon = 'check', description = 'La porte du logement est à ta position.', onSelect = function()
            if #st.name < 3 then G.send('notify', { type = 'warn', title = 'Agence immobilière', text = 'Donne un nom au logement (3 caractères au moins).' }) return end
            G.Menu.Close()
            TriggerServerEvent('pb:g:realtor:list', st.kind == 1 and 'buy' or 'rent', tiers[st.tier].id, st.name)
        end },
    } })
end)

-- Remise des clés : l'agent choisit la durée de la location ; le client accepte ou refuse l'offre
RegisterNetEvent('pb:g:realtor:days', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local function money(n) return G.money and G.money(n) or (tostring(n) .. ' $') end
    local DAYS = { 1, 3, 7, 14, 30 }
    local list = {}
    for i, n in ipairs(DAYS) do list[i] = ('%d jour%s · %s'):format(n, n > 1 and 's' or '', money(math.ceil((tonumber(d.rent) or 0) * n / math.max(1, tonumber(d.period) or 7)))) end
    local st = 3
    G.Menu.Open({ id = 'realtor.keys', title = 'Remettre les clés', subtitle = tostring(d.label or ''), items = {
        { type = 'list', label = 'Durée de la location', icon = 'clock', list = list, index = 3, onChange = function(_, _, i) st = i end },
        { type = 'button', label = 'Proposer au client', icon = 'key', description = 'Il accepte et paie depuis son compte bancaire.', onSelect = function()
            G.Menu.Close()
            TriggerServerEvent('pb:g:realtor:days', d.t, d.id, DAYS[st])
        end },
        { type = 'button', label = 'Annuler', icon = 'x', onSelect = function() G.Menu.Close() end },
    } })
end)
RegisterNetEvent('pb:g:realtor:offer', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local function money(n) return G.money and G.money(n) or (tostring(n) .. ' $') end
    local what = d.rent and ('Location de « %s » pour %d jour(s)'):format(tostring(d.label), tonumber(d.days) or 0) or ('Achat de « %s »'):format(tostring(d.label))
    local answered = false
    local function answer(ok) if answered then return end answered = true G.Menu.Close() TriggerServerEvent('pb:g:realtor:answer', d.token, ok) end
    G.Menu.Open({ id = 'realtor.offer', title = 'Agence immobilière', subtitle = tostring(d.agent or ''), items = {
        { label = what, icon = 'home', disabled = true },
        { label = 'Prix', right = money(d.price), icon = 'card', disabled = true },
        { type = 'button', label = 'Accepter et payer', icon = 'check', description = 'Payé depuis ton compte bancaire ; tu reçois les clés.', onSelect = function() answer(true) end },
        { type = 'button', label = 'Refuser', icon = 'x', onSelect = function() answer(false) end },
    } })
end)
