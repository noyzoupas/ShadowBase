/* Magasin de vêtements : accueil en cartes, catalogue par rayon, variantes au centre, panier à droite, tenues enregistrées et tenues de la communauté.
   Envois : creator.preview / creator.textures / creator.rotate / creator.zoom, wardrobe.pay, wardrobe.list, wardrobe.save, wardrobe.del, wardrobe.pub, wardrobe.unpub. Le serveur vérifie et encaisse. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const add = (el, ...k) => el.append(...k.filter((x) => x != null));   // append(null) écrirait « null »
const money = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
const CATS = [
  ['Chapeau', 'tag', [['Chapeau', 'p', 0]]], ["Accessoires d'oreille", 'star', [['Oreilles', 'p', 2]]], ['Lunettes', 'eye', [['Lunettes', 'p', 1]]],
  ['Haut', 'hanger', [['Haut', 'c', 11], ['Sous-Haut', 'c', 8], ['Bras', 'c', 3], ['Decals', 'c', 10]]], ['Accessoires', 'star', [['Accessoires', 'c', 7]]], ['Sac', 'bag', [['Sac', 'c', 5]]],
  ['Montre', 'clock', [['Montre', 'p', 6]]], ['Bracelet', 'star', [['Bracelet', 'p', 7]]], ['Bas', 'user', [['Bas', 'c', 4]]], ['Chaussures', 'paw', [['Chaussures', 'c', 6]]], ['Masque', 'face', [['Masque', 'c', 1]]],
];
const SCOPES = { masks: ['Masque'], hats: ['Chapeau'], tops: ['Haut'], bottoms: ['Bas'], shoes: ['Chaussures'], accessories: ['Accessoires', "Accessoires d'oreille", 'Lunettes', 'Montre', 'Bracelet'] };
// masques et sacs : magasin à part (seulement l'achat, l'article arrive dans le sac du joueur)
const GEAR = [['Masques', 'face', [['Masque', 'c', 1]]], ['Sacs', 'bag', [['Sac', 'c', 5]]]];
const BARE = { male: { 11: 15, 8: 15, 3: 15, 4: 61, 6: 34 }, female: { 11: 15, 8: 14, 3: 15, 4: 15, 6: 35 } };
const PAGE = 60;

G.wardrobeDa = function (d, opt) {
  opt = opt || {};
  const shop = d.shop || {}, piece = Number(shop.piece) || 0, flat = Number(shop.price) || 0;
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const norm = (a) => { a = a ? clone(a) : { comps: [], props: [] }; a.comps = a.comps || []; a.props = a.props || []; for (let i = 0; i < 12; i++) if (!a.comps[i]) a.comps[i] = { d: 0, t: 0 }; return a; };
  const base = norm(d.appearance);
  let app = norm(d.appearance);
  const gear = shop.gear || null;
  const cats = gear ? GEAR : (shop.scope && SCOPES[shop.scope]) ? CATS.filter((c) => SCOPES[shop.scope].indexOf(c[0]) >= 0) : CATS.filter((c) => c[0] !== 'Masque' && c[0] !== 'Sac');
  const st = { view: gear ? 'cat' : 'home', cat: 0, sub: 0, q: '', tex: 1, shown: PAGE, method: (d.cash || 0) > 0 ? 'cash' : 'bank', cash: d.cash, bank: d.bank, mine: [], shared: [], sharedOn: true, max: 10, picked: null, boughtShared: null };

  const fit = () => el.style.setProperty('--k', String(Math.min(window.innerWidth / 1920, window.innerHeight / 1080)));
  const acc = (shop.color && /^#[0-9a-f]{6}$/i.test(shop.color)) ? shop.color : '#d9262e';   // vêtements : rouge, indépendant de la couleur du serveur
  const left = h('div', { class: 'wd-main' }), vars = h('div', { class: 'wd-vars hidden' }), cart = h('aside', { class: 'wd-cart hidden' }), drag = h('div', { class: 'wd-drag' });
  const dim = h('div', { class: 'wd-dim' });
  let dimOn = true;
  const hints = h('div', { class: 'wd-hints' }, h('span', null, h('kbd', null, 'Clic'), 'Glisser pour tourner'), h('span', null, h('kbd', null, 'Molette'), 'Molette pour zoomer'),
    h('span', { class: 'wd-fl', onclick: () => { dimOn = !dimOn; dim.classList.toggle('off', !dimOn); flt.classList.toggle('off', !dimOn); } }, 'Fond', (function () { const x = h('i', { class: 'wd-sw' }, h('u')); return x; })()), h('span', null, h('kbd', null, 'ÉCHAP'), 'Quitter'));
  const flt = hints.querySelector('.wd-sw');
  const el = h('div', { class: 'wd', style: { '--wd': acc, '--wd-rgb': G.hexToRgb(acc) } }, dim, drag, h('div', { class: 'wd-left' }, h('header', { class: 'wd-brand' }, h('b', null, String(shop.label || 'Vêtements').toUpperCase()), h('button', { 'aria-label': 'Fermer', onclick: opt.onCancel }, ico('close'))), left), vars, hints, cart);
  fit(); window.addEventListener('resize', fit);

  // ---------- personnage ----------
  let down = null, timer = null;
  drag.addEventListener('mousedown', (e) => { down = e.clientX; });
  const mv = (e) => { if (down === null) return; const dx = e.clientX - down; if (Math.abs(dx) >= 3) { if (!opt.static) G.post('creator.rotate', { delta: dx * 0.45 }); down = e.clientX; } };
  const up = () => { down = null; };
  document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
  drag.addEventListener('wheel', (e) => { if (!opt.static) G.post('creator.zoom', { d: e.deltaY > 0 ? 1 : -1 }); });
  const send = () => { if (opt.static) return; clearTimeout(timer); timer = setTimeout(() => G.post('creator.preview', { appearance: app }).then((r) => { if (r && r.comps) d.limits = r; }), 60); };

  const lim = () => d.limits || { comps: Array(12).fill(60), props: { 0: 60, 1: 30, 2: 20, 6: 20, 7: 20 } };
  const prop = (a, id) => { let p = a.props.find((x) => x.id === id); if (!p) { p = { id, d: -1, t: 0 }; a.props.push(p); } return p; };
  const cur = () => cats[st.cat][2][st.sub];
  const state = () => { const [, k, id] = cur(); return k === 'c' ? app.comps[id] : prop(app, id); };
  const count = () => { const [, k, id] = cur(); return Math.max(1, k === 'c' ? (lim().comps[id] || 1) : (lim().props[id] || 1)); };
  const img = (k, id, dr, t) => {
    if (!shop.img || dr < 0) return null;
    const src = String(shop.img).replace(/\{sex\}/g, shop.sex || 'male').replace(/\{type\}/g, k === 'c' ? 'clothing' : 'prop').replace(/\{k\}/g, k).replace(/\{id\}/g, id).replace(/\{d\}/g, dr).replace(/\{t\}/g, t || 0);
    return h('img', { src, alt: '', loading: 'lazy', draggable: false, onerror: (e) => e.target.remove() });
  };
  // pièces différentes de ce que le joueur porte en entrant
  function changed() {
    const out = [];
    CATS.forEach((c) => c[2].forEach(([label, k, id]) => {
      const a = k === 'c' ? app.comps[id] : prop(app, id), b = k === 'c' ? base.comps[id] : (base.props.find((x) => x.id === id) || { d: -1, t: 0 });
      if (a && b && (a.d !== b.d || a.t !== b.t) && a.d >= 0) out.push({ label, cat: c[0], k, id, d: a.d, t: a.t });
    }));
    return out;
  }
  const total = (list) => (!list.length ? 0 : piece > 0 ? piece * list.length : flat);
  const pieceTxt = () => (piece > 0 ? money(piece) : flat > 0 ? '' : 'Gratuit');
  // masques et sacs : le prix de l'article
  const gearPrice = (i) => { if (cur()[2] !== 5) return money(gear.mask_price || 0); const b = (gear.bags || []).find((x) => x.d === i); return b ? money(b.price) : ''; };
  function loadTex() {
    const [, k, id] = cur(), s = state();
    if (opt.static) { st.tex = 4; drawVars(); return; }
    if (k === 'p' && s.d < 0) { st.tex = 1; drawVars(); return; }
    const ask = st.texAsk = (st.texAsk || 0) + 1;
    G.post('creator.textures', { kind: k === 'c' ? 'comp' : 'prop', id, drawable: s.d }).then((r) => { if (ask !== st.texAsk) return; st.tex = (r && r.n) || 1; s.t = Math.min(s.t, st.tex - 1); drawVars(); });
  }
  const gearBags = () => (gear && gear.bags) || [];
  const pay = (shared) => { if (opt.onSubmit) opt.onSubmit(app, st.method, shared || null); };

  // ---------- panier ----------
  function payBlock(sum, label, shared) {
    const opts = [['cash', 'Espèces', st.cash, 'coins'], ['bank', 'Carte bancaire', st.bank, 'card']];
    return [h('div', { class: 'wd-pay' }, opts.map(([k, l, v, ic]) => h('button', { class: k === st.method ? 'on' : '', onclick: () => { st.method = k; drawCart(); } }, h('span', { class: 'wd-pi' }, ico(ic)), h('b', null, l), h('em', { class: (Number(v) || 0) < sum ? 'low' : '' }, money(v)), k === st.method ? ico('check') : h('u')))),
      h('div', { class: 'wd-tot' }, h('small', null, 'Total'), h('b', null, money(sum))), h('button', { class: 'wd-buy', disabled: (Number(st.method === 'cash' ? st.cash : st.bank) || 0) < sum || (!sum && !shared && !changed().length) || null, onclick: () => pay(shared) }, label)];
  }
  function drawCart() {
    G.clear(cart);
    const v = st.view;
    if (v === 'home' || v === 'create') { cart.classList.add('hidden'); return; }
    cart.classList.remove('hidden');
    if (gear) {
      const s = state(), [, k, id] = cur(), isBag = id === 5;
      const bag = isBag ? gearBags().find((b) => b.d === s.d) : null;
      const can = isBag ? !!bag : s.d > 0, cost = (isBag ? (bag && bag.price) : gear.mask_price) || 0;
      const name = isBag ? (bag ? String(bag.label) : 'Choisis un sac') : (s.d > 0 ? 'Masque, modèle ' + s.d : 'Choisis un masque');
      add(cart, h('div', { class: 'wd-ch' }, ico('bag'), h('b', null, 'Achat')),
        h('div', { class: 'wd-line' }, h('span', { class: 'wd-th' }, can ? img(k, id, s.d, s.t) : null), h('div', null, h('small', null, cats[st.cat][0]), h('b', null, name))),
        h('p', { class: 'wd-pn' }, "L'article arrive dans ton sac : équipe-le depuis l'inventaire."),
        h('div', { class: 'wd-tot' }, h('small', null, 'Prix'), h('b', null, can ? money(cost) : '—')),
        h('button', { class: 'wd-buy', disabled: !can || (Number(st.cash) || 0) + (Number(st.bank) || 0) < cost, onclick: () => { if (opt.onBuy) opt.onBuy({ kind: isBag ? 'bag' : 'mask', d: s.d, t: s.t }); } }, 'Acheter'));
      return;
    }
    if ((v === 'mine' || v === 'shared') && st.picked) {
      const o = st.picked, pc = (o.data.comps || []).filter(Boolean).length;
      const list = (changed());
      add(cart, h('div', { class: 'wd-ch' }, ico('hanger'), h('b', null, 'Tenue')),
        h('div', { class: 'wd-line' }, h('span', { class: 'wd-th' }, img('c', 11, (o.data.comps[11] || {}).d || 0, 0)), h('div', null, h('small', null, v === 'mine' ? 'Vos tenues' : 'Communauté'), h('b', null, String(o.label)), o.author ? h('small', null, 'Par ' + String(o.author)) : h('small', null, pc + ' pièces')), h('em', null, money(total(list)))),
        h('button', { class: 'wd-link', onclick: () => { st.picked = null; app = norm(base); send(); draw(); } }, "Retirer l'essai"), ...payBlock(total(list), 'Acheter la tenue', v === 'shared' ? o.id : null));
      return;
    }
    const list = changed(), sum = total(list);
    const s = v === 'cat' ? cur() : null;
    const head = [h('div', { class: 'wd-ch' }, ico('bag'), h('b', null, 'Panier'))];
    if (s) { const stt = state(); head.push(h('div', { class: 'wd-line' }, h('span', { class: 'wd-th' }, img(s[1], s[2], stt.d, stt.t)), h('div', null, h('small', null, cats[st.cat][0]), h('b', null, stt.d < 0 ? 'Aucun' : 'Modèle n° ' + stt.d)), h('em', null, pieceTxt()))); }
    if (list.length) head.push(h('div', { class: 'wd-sum' }, h('b', null, list.length + (list.length > 1 ? ' pièces' : ' pièce')), h('em', null, money(sum))));
    head.push(h('small', { class: 'wd-art' }, 'Articles'), h('p', { class: 'wd-pn' }, list.length ? list.map((x) => x.label).join(' · ') : 'Essayez des vêtements : tout ce qui change est acheté ensemble.'));
    add(cart, ...head, ...payBlock(sum, 'Payer'));
  }

  // ---------- variantes ----------
  function drawVars() {
    G.clear(vars);
    if (st.view !== 'cat') { vars.classList.add('hidden'); drawCart(); return; }
    const s = state(), [, k, id] = cur();
    if (s.d < 0 || st.tex < 2) { vars.classList.add('hidden'); drawCart(); return; }
    vars.classList.remove('hidden');
    vars.appendChild(h('div', { class: 'wd-vh' }, h('b', null, 'Variations'), h('span', null, cur()[0] + ' · Modèle n° ' + s.d), h('em', null, (s.t + 1) + ' / ' + st.tex)));
    const grid = h('div', { class: 'wd-vg' });
    for (let t = 0; t < st.tex; t++) grid.appendChild(h('button', { class: t === s.t ? 'on' : '', onclick: () => { s.t = t; send(); drawVars(); } }, img(k, id, s.d, t), h('i', null, String(t + 1))));
    vars.appendChild(grid);
    drawCart();
  }

  // ---------- pages ----------
  function title(t, n) { const c = h('div', { class: 'wd-ttl' }); if (st.view !== 'home' && st.view !== 'cat') c.appendChild(h('button', { class: 'wd-home', onclick: () => go('home') }, ico('back'), 'Accueil')); add(c, h('b', null, t), n ? h('small', null, n) : null); return c; }
  function go(v) { st.view = v; st.picked = null; if (v === 'mine' || v === 'shared') { if (!opt.static) G.post('wardrobe.list', {}); } if (v === 'home') { app = norm(app); } draw(); }
  const thumbs = (ids) => h('div', { class: 'wd-hth' }, ids.map((x, i) => h('span', { class: i === 1 ? 'mid' : '' }, x)));
  function pageHome() {
    const card = (titleT, sub, tag, btn, fn, a, b, ic) => h('div', { class: 'wd-hc', onclick: fn }, thumbs([a, ico(ic), b]), h('div', { class: 'wd-hb' }, h('b', null, titleT), h('small', null, sub), h('div', { class: 'wd-hf' }, tag ? h('span', { class: 'wd-tag' }, tag) : h('i'), h('button', null, btn))));
    const row = (t, s, lab, fn, ic, right) => h('div', { class: 'wd-hr', onclick: fn }, h('span', { class: 'wd-hri' }, ico(ic)), h('div', null, h('b', null, t), h('small', null, s)), right, h('button', null, lab));
    const mk = (k, id, dr) => img(k, id, dr, 0) || ico('hanger');
    return [h('div', { class: 'wd-ttl' }, h('b', null, 'Bienvenue chez ' + String(shop.label || ''))), h('div', { class: 'wd-scroll' },
      h('h4', null, 'Magasin de vêtements'), h('div', { class: 'wd-h2' }, card('Magasin', 'Hauts, bas, chaussures et accessoires', cats.length + ' catégories', 'Parcourir', () => { st.cat = cats.findIndex((c) => c[0] === 'Haut'); if (st.cat < 0) st.cat = 0; st.sub = 0; st.shown = PAGE; go('cat'); loadTex(); }, mk('c', 11, 1), mk('c', 11, 8), 'bag'),
        card('Créer une tenue', 'Composez une tenue pièce par pièce', null, 'Composer', () => go('create'), mk('c', 11, 3), mk('c', 11, 7), 'sparkle')),
      h('h4', null, 'Garde-robe'), h('div', { class: 'wd-h2' }, card('Vos tenues', 'Vos tenues sauvegardées, en un clic', st.max + ' tenues max.', 'Ouvrir', () => go('mine'), mk('c', 11, 4), mk('c', 11, 6), 'hanger'),
        st.sharedOn ? card('Communauté', 'Les tenues des autres joueurs', null, 'Découvrir', () => go('shared'), mk('c', 11, 2), mk('c', 11, 9), 'users') : null))];
  }
  function pageCreate() {
    const row = (ic, t, s, fn) => h('button', { class: 'wd-cr', onclick: fn }, h('span', null, ico(ic)), h('div', null, h('b', null, t), h('small', null, s)));
    const bare = BARE[shop.sex === 'female' ? 'female' : 'male'];
    return [title('Créer une tenue'), row('plus', 'Créer une nouvelle tenue', 'Tous les vêtements sont retirés : composez la tenue pièce par pièce.', () => { Object.keys(bare).forEach((i) => { app.comps[i] = { d: bare[i], t: 0 }; }); app.props.forEach((p) => { p.d = -1; }); send(); st.cat = Math.max(0, cats.findIndex((c) => c[0] === 'Haut')); st.sub = 0; go('cat'); loadTex(); }),
      row('hanger', "Créer une tenue basée sur l'actuelle", 'Les vêtements que vous portez sont repris.', () => { app = norm(base); send(); st.cat = Math.max(0, cats.findIndex((c) => c[0] === 'Haut')); st.sub = 0; go('cat'); loadTex(); }),
      row('sparkle', 'Modifier une tenue sauvegardée', 'Ouvrez « Vos tenues » puis choisissez « Modifier » sur la tenue voulue.', () => go('mine'))];
  }
  function pageCat() {
    const c = cats[st.cat], s = state(), [, k, id] = cur(), n = count();
    // modèles sans photo masqués : le paquet de photos dit lesquels existent vraiment. Sans paquet pour ce rayon (bras…), tout reste affiché.
    const photoKey = (shop.sex || 'male') + '_' + k + id;
    st.photos = st.photos || {};
    if (shop.hidenp && st.photos[photoKey] === undefined) {
      st.photos[photoKey] = false;
      G.clothPack(photoKey).then((pk) => { st.photos[photoKey] = pk && Object.keys(pk).length ? pk : false; if (st.photos[photoKey] && st.view === 'cat') draw(); });
    }
    const photos = shop.hidenp ? st.photos[photoKey] : false;
    // restent visibles : le 0 et les numéros « rien porté » (invisibles, donc jamais photographiés), et la pièce portée
    const bareD = k === 'c' ? BARE[shop.sex === 'female' ? 'female' : 'male'][id] : undefined;
    // après le dernier numéro photographié : vêtements ajoutés au serveur (packs), jamais photographiés mais bien réels
    const lastPhoto = photos ? Math.max(...Object.keys(photos).map(Number)) : -1;
    const hasPhoto = (i) => !photos || i === 0 || i === bareD || i === s.d || photos[i] != null || i > lastPhoto;
    let total = 0;
    for (let i = gear ? 1 : 0; i < n; i++) if (hasPhoto(i)) total++;
    const rail = h('nav', { class: 'wd-rail' }, gear ? h('button', { class: 'wd-ri', onclick: () => { if (opt.onCancel) opt.onCancel(); } }, ico('back'), 'Quitter') : h('button', { class: 'wd-ri', onclick: () => go('home') }, ico('back'), 'Accueil'), h('small', null, 'Catalogue'),
      cats.map((x, i) => h('button', { class: 'wd-ri' + (i === st.cat ? ' on' : ''), onclick: () => { st.cat = i; st.sub = 0; st.shown = PAGE; draw(); loadTex(); } }, ico(x[1]), x[0])));
    const tabs = c[2].length > 1 ? h('div', { class: 'wd-tabs' }, c[2].map((x, i) => h('button', { class: i === st.sub ? 'on' : '', onclick: () => { st.sub = i; st.shown = PAGE; draw(); loadTex(); } }, x[0]))) : null;
    const grid = h('div', { class: 'wd-grid' });
    const soldD = gear && id === 5 ? gearBags().map((b) => b.d).filter((x, j, a) => a.indexOf(x) === j) : null;
    const choose = (i) => { s.d = i; s.t = 0; send(); Array.from(grid.children).forEach((b) => b.classList.toggle('on', Number(b.dataset.d) === i)); loadTex(); };
    const tile = (i) => h('button', { class: 'wd-t' + (s.d === i ? ' on' : ''), 'data-d': i, onclick: () => choose(i) }, h('i', null, i < 0 ? '—' : String(i)), h('u'), h('span', { class: 'wd-ti' }, i < 0 ? null : img(k, id, i, 0)), h('div', { class: 'wd-tb' }, h('b', null, i < 0 ? 'Aucun' : 'Modèle ' + i), h('em', null, (gear ? gearPrice(i) : pieceTxt()))));
    const fill = () => {
      G.clear(grid);
      const q = st.q;
      if (k === 'p' && !q) grid.appendChild(tile(-1));
      let shown = 0;
      if (soldD) { soldD.forEach((i) => { if (!q || String(i).indexOf(q) === 0) grid.appendChild(tile(i)); }); return; }
      for (let i = gear ? 1 : 0; i < n && shown < st.shown; i++) { if (!hasPhoto(i) || (q && String(i).indexOf(q) !== 0)) continue; grid.appendChild(tile(i)); shown++; }
    };
    fill();
    const list = h('div', { class: 'wd-scroll', onscroll: (e) => { const t = e.target; if (t.scrollTop + t.clientHeight > t.scrollHeight - 300 && st.shown < total) { st.shown += PAGE; const y = t.scrollTop; fill(); t.scrollTop = y; } } }, grid);
    const search = h('div', { class: 'wd-find' }, ico('calc'), h('input', { type: 'text', maxlength: 5, value: st.q, placeholder: 'Numéro du modèle', oninput: (e) => { st.q = e.target.value.replace(/\D/g, ''); fill(); } }));
    return [h('div', { class: 'wd-cat' }, rail, h('div', { class: 'wd-cc' }, h('div', { class: 'wd-ttl' }, h('b', null, c[0]), h('small', null, (soldD ? soldD.length : total) + ' modèles')), tabs, search, list))];
  }
  const outfitCard = (o, kids) => {
    const dd = o.data || {};
    const comps = dd.comps || [], pr = (dd.props || []).find((x) => x && x.id === 0);
    const cell = (k, id, dr) => h('span', null, img(k, id, dr, 0));
    return h('div', { class: 'wd-oc' + (st.picked && st.picked.id === o.id ? ' on' : ''), onclick: () => { st.picked = o; app.comps = clone(dd.comps || app.comps); app.props = clone(dd.props || []); app = norm(app); send(); draw(); } },
      h('div', { class: 'wd-oi' }, cell('c', 11, (comps[11] || {}).d || 0), cell('c', 4, (comps[4] || {}).d || 0), cell('c', 6, (comps[6] || {}).d || 0), pr && pr.d >= 0 ? cell('p', 0, pr.d) : h('span')),
      h('div', { class: 'wd-ob' }, h('div', { class: 'wd-obt' }, h('b', null, String(o.label))), kids));
  };
  function pageMine() {
    const btn = (t, fn) => h('button', { onclick: (e) => { e.stopPropagation(); fn(); } }, t);
    const grid = h('div', { class: 'wd-og' }, st.mine.map((o) => outfitCard(o, h('div', { class: 'wd-oa' },
      btn('Modifier', () => { app.comps = clone(o.data.comps); app.props = clone(o.data.props || []); app = norm(app); send(); st.cat = Math.max(0, cats.findIndex((c) => c[0] === 'Haut')); st.sub = 0; go('cat'); loadTex(); }),
      st.sharedOn ? btn('Publier', () => G.post('wardrobe.pub', { id: o.id })) : null, btn('Supprimer', () => G.post('wardrobe.del', { id: o.id }))))));
    return [title('Vos tenues', st.mine.length + ' / ' + st.max), h('div', { class: 'wd-ba' }, h('button', { onclick: () => G.post('wardrobe.save', { label: '' }) }, 'Enregistrer ce que je porte'), h('span', null, st.mine.length + ' / ' + st.max + ' tenues')),
      h('div', { class: 'wd-scroll' }, st.mine.length ? grid : h('p', { class: 'wd-none' }, "Vous n'avez pas encore de tenue enregistrée."))];
  }
  function pageShared() {
    const grid = h('div', { class: 'wd-og' }, st.shared.map((o) => outfitCard(o, h('div', null, h('small', null, 'Par ' + String(o.author) + ' · ' + (Number(o.buys) || 0) + ' achats'), o.mine ? h('div', { class: 'wd-oa' }, h('button', { onclick: (e) => { e.stopPropagation(); G.post('wardrobe.unpub', { id: o.id }); } }, 'Retirer')) : null))));
    return [title('Tenues de la communauté', st.shared.length + ' tenues'), h('p', { class: 'wd-pn' }, 'Tenues publiées par les autres joueurs. Choisissez une tenue pour l\'essayer.'), h('div', { class: 'wd-scroll' }, st.shared.length ? grid : h('p', { class: 'wd-none' }, 'Aucune tenue publiée pour le moment.'))];
  }
  function draw() {
    G.clear(left);
    const p = { home: pageHome, create: pageCreate, cat: pageCat, mine: pageMine, shared: pageShared }[st.view]();
    p.forEach((x) => x && left.appendChild(x));
    drawVars();
  }
  draw();
  if (gear) loadTex();
  else if (!opt.static) G.post('wardrobe.list', {});
  return { el, app: () => app, setMoney: (m) => { if (!m) return; st.cash = m.cash; st.bank = m.bank; drawCart(); }, setData: (x) => { st.mine = x.mine || []; st.shared = x.shared || []; st.sharedOn = x.shared_on !== false; st.max = x.max || 10; draw(); },
    destroy() { window.removeEventListener('resize', fit); document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); } };
};
})();
