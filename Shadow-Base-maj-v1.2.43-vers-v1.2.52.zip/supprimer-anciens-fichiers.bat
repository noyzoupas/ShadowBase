@echo off
chcp 65001 >nul
cd /d "%~dp0"
del /f /q "[w-base]\animation_menu\html\img\emotes\guardarmy.svg" 2>nul
echo Anciens fichiers supprimes.
pause