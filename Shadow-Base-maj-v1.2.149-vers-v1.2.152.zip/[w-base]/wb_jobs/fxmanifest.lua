fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_jobs'
description "Shadow Base — petits jobs des entreprises : livraisons, taxi, dépannage, patrouilles, secours, chantiers, reportages, transport, service sur place. Extension de pb_panel."
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

shared_script 'shared.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'

shared_script '@wb_shield/shield.lua'
