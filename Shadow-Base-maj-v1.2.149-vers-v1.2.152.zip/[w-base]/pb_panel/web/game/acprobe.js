/* Sonde anticheat : une instruction « debugger » chronométrée. Sans outils de développement ouverts, elle ne fait rien (quelques µs) ;
   avec, le navigateur s'arrête dessus. 8 mesures lentes de suite = outils ouverts (un à-coup isolé ne compte jamais). Le jeu décide ensuite (staff exempté). */
(function () {
'use strict';
const G = window.PBGame;
if (!G || !G.post) return;
let slow = 0;
setInterval(function () {
  const t = performance.now();
  debugger;
  const d = performance.now() - t;
  slow = d > 100 ? slow + 1 : 0;
  if (slow >= 8) { slow = 0; G.post('ac.devtools', { n: 8 }); }
}, 2000);
})();
