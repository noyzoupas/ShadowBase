fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_peche'
description "Shadow Base — pêche : raretés de poissons et de leurres, cannes, ferrage, marché aux prix variables, records. Extension de pb_panel."
author 'Shadow Base'
version '1.1.0'

dependency 'pb_panel'

shared_script 'shared.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'

shared_script '@wb_shield/shield.lua'
