fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_activites'
description 'Shadow Base — activités ouvertes à tous : pêche, mine, bûcheron, ferme, vignes, vergers, cueillette, récupération ; transformation, revente, établis de craft. Extension de pb_panel.'
author 'Shadow Base'
version '1.1.1'

dependency 'pb_panel'

shared_script 'templates.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'

shared_script '@wb_shield/shield.lua'
