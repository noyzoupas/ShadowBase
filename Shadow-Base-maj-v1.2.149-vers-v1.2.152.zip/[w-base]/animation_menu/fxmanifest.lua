fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'animation_menu'
description 'Menu des animations (emotes) - UI NUI'
version '1.0.0'

ui_page 'html/index.html'

shared_script 'config.lua'
client_script 'client.lua'

files {
  'html/index.html',
  'html/globals.css',
  'html/style.css',
  'html/script.js',
  'html/img/*.png',
  'html/img/mask/*.png',
  'html/img/emotes/*.svg',
  'html/fonts/*',
}

-- (v1.2.82) Escrow Cfx.re : fichiers laissés lisibles et modifiables par le propriétaire du serveur (le reste du Lua est chiffré)
escrow_ignore {
    'config.lua',
}

shared_script '@wb_shield/shield.lua'
