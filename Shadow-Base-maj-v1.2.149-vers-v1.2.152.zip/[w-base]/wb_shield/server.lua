-- wb_shield (serveur) : secret de session par joueur, jetons à usage unique, évènements « armés » par apprentissage, limite de débit, installation.
--   convar wb_shield_mode   = block (défaut : refuse les évènements ARMÉS sans jeton valide) | log (signale seulement)
--   convar wb_shield_rate   = appels max par joueur, évènement et 10 s (défaut 60 ; au-delà : signalé, refusé en mode block)
--   convar wb_shield_ignore = évènements exclus, séparés par des virgules
--   convar wb_shield_arm    = jetons valides nécessaires pour armer un évènement (défaut 30)
-- Un évènement est ARMÉ quand il a été vu avec au moins `wb_shield_arm` jetons valides et sans jeton chez 3 joueurs différents au plus.
-- Tant qu'il n'est pas armé, un appel sans jeton est seulement compté : un script non protégé, un cas oublié ou un bug ne peut donc jamais faire sanctionner un joueur.
local secrets, names, nameList, seen, rates, memo, lastFlag, toks, lcount = {}, {}, {}, {}, {}, {}, {}, {}, {}
local stats = { ok = 0, bad = 0, flood = 0, notoken = 0 }
local ev = {}            -- nom -> { v = jetons valides, u = appels sans jeton, up = { licences } }
local dirty = false
local localEv = {}
exports('Local', function(name) if type(name) == 'string' then localEv[name] = true end end)

local function mode() return GetConvar('wb_shield_mode', 'block') == 'log' and 'log' or 'block' end
local function rateMax() return tonumber(GetConvar('wb_shield_rate', '60')) or 60 end
local function armNeed() return tonumber(GetConvar('wb_shield_arm', '30')) or 30 end

local function mix(s)
    local h = 0xcbf29ce484222325
    for i = 1, #s do h = (h ~ s:byte(i)) * 0x100000001b3 end
    h = h ~ (h >> 29); h = h * 0xbf58476d1ce4e5b9; h = h ~ (h >> 32)
    return string.format('%x', h)
end
local function newSecret()
    local t = {}
    for i = 1, 4 do t[i] = string.format('%08x', math.random(0, 0x7fffffff)) end
    return table.concat(t)
end
local function ensure(src)
    if not secrets[src] then secrets[src] = newSecret() seen[src] = { set = {}, order = {} } toks[src] = {} end
    return secrets[src]
end
local function licenseOf(src)
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if id:sub(1, 8) == 'license:' then return id end end
    return 'src:' .. tostring(src)
end
local function stat(name) ev[name] = ev[name] or { v = 0, u = 0, up = {} } return ev[name] end
local function armed(name)
    local e = ev[name]
    if not e then return false end
    local n = 0
    for _ in pairs(e.up) do n = n + 1 end
    return e.v >= armNeed() and n <= 2
end

-- persistance de l'apprentissage -----------------------------------------------------------------------------------------------------
local function load()
    local raw = LoadResourceFile(GetCurrentResourceName(), 'learned.json')
    local ok, t = pcall(function() return raw and json.decode(raw) end)
    if ok and type(t) == 'table' then
        for k, v in pairs(t) do
            if type(k) == 'string' and type(v) == 'table' then
                local up = {}
                for _, l in ipairs(type(v.up) == 'table' and v.up or {}) do up[tostring(l)] = true end
                ev[k] = { v = tonumber(v.v) or 0, u = tonumber(v.u) or 0, up = up }
            end
        end
    end
end
local function save()
    if not dirty then return end
    dirty = false
    local out = {}
    for k, e in pairs(ev) do
        local up = {}
        for l in pairs(e.up) do up[#up + 1] = l if #up >= 5 then break end end
        out[k] = { v = e.v, u = e.u, up = up }
    end
    SaveResourceFile(GetCurrentResourceName(), 'learned.json', json.encode(out), -1)
end
load()
CreateThread(function() while true do Wait(300000) pcall(save) end end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then pcall(save) end end)

local function report(src, kind, detail)
    local k = src .. kind .. detail
    if (lastFlag[k] or 0) > os.time() - 60 then return end            -- une alerte par minute et par cause
    lastFlag[k] = os.time()
    print(('[wb_shield] %s #%d — %s'):format(kind, src, detail))
    pcall(function() exports.pb_panel:AntiCheatFlag(src, kind, detail) end)
end

AddEventHandler('playerJoining', function() ensure(source) end)
AddEventHandler('playerDropped', function() local s = source secrets[s], seen[s], rates[s], memo[s], toks[s] = nil, nil, nil, nil, nil end)

local function limited(src, key, win, max)
    local r = rates[src] or {}
    rates[src] = r
    r[key] = r[key] or { t0 = os.time(), n = 0 }
    if os.time() - r[key].t0 >= win then r[key] = { t0 = os.time(), n = 0 } end
    r[key].n = r[key].n + 1
    return r[key].n > max, r[key].n
end

RegisterNetEvent('wb_shield:hello', function()
    local src = source
    if limited(src, 'hello', 60, 30) then return end
    TriggerClientEvent('wb_shield:init', src, ensure(src), nameList)
end)

-- le client annonce « le prochain <évènement> porte ce jeton »
RegisterNetEvent('wb_shield:tok', function(name, token)
    local src = source
    local sec, tk = secrets[src], toks[src]
    if not sec or type(name) ~= 'string' or type(token) ~= 'string' or #name > 120 or #token > 40 then return end
    if limited(src, 'tok', 10, 400) then return end
    local rnd, sig = token:match('^(%d+):(%x+)$')
    if not rnd or sig ~= mix(sec .. '|' .. name .. '|' .. rnd) then
        stats.bad = stats.bad + 1
        if armed(name) then report(src, 'event_token', ('%s : jeton faux'):format(name)) end
        return
    end
    local sv = seen[src]
    if sv.set[token] then
        stats.bad = stats.bad + 1
        if armed(name) then report(src, 'event_token', ('%s : jeton rejoué'):format(name)) end
        return
    end
    sv.set[token] = true
    sv.order[#sv.order + 1] = token
    if #sv.order > 2000 then sv.set[table.remove(sv.order, 1)] = nil end
    local q = tk[name] or {}
    tk[name] = q
    q[#q + 1] = os.time()
    if #q > 64 then table.remove(q, 1) end
end)

exports('Declare', function(list)
    local fresh = {}
    for _, n in ipairs(type(list) == 'table' and list or {}) do
        lcount[n] = (lcount[n] or 0) + 1
        if not names[n] then names[n] = true nameList[#nameList + 1] = n fresh[#fresh + 1] = n end
    end
    if #fresh > 0 then TriggerClientEvent('wb_shield:add', -1, fresh) end
end)

-- Vrai : laisser passer. Faux : refuser. 'retry' : pas de jeton pour l'instant, redemander dans 300 ms.
exports('Check', function(src, name, res, second)
    local sec = secrets[src]
    if not sec or localEv[name] then return true end                        -- joueur pas encore connu, ou évènement aussi déclenché en local
    local m = memo[src]
    if m and m.name == name and m.left > 0 and os.clock() - m.t < 0.05 then m.left = m.left - 1 return m.ok end   -- autres écouteurs du même évènement
    local ok = true
    -- débit
    local over, n = limited(src, 'e:' .. name, 10, rateMax())
    if over then
        stats.flood = stats.flood + 1
        report(src, 'event_flood', ('%s appelé %d fois en 10 s (ressource %s)'):format(name, n, tostring(res)))
        if mode() == 'block' and n > rateMax() * 5 then ok = false end        -- refus seulement très au-dessus du seuil de signalement
    end
    if ok then
        local q = toks[src] and toks[src][name]
        local got = false
        while q and #q > 0 do
            local at = table.remove(q, 1)
            if os.time() - at <= 60 then got = true break end              -- jeton périmé : on l'ignore
        end
        local e = stat(name)
        if got then
            e.v = e.v + 1
            stats.ok = stats.ok + 1
            dirty = true
        elseif not second then
            memo[src] = nil
            return 'retry'
        else
            e.u = e.u + 1
            e.up[licenseOf(src)] = true
            stats.notoken = stats.notoken + 1
            dirty = true
            if armed(name) then
                report(src, 'event_token', ('%s appelé sans jeton (ressource %s)'):format(name, tostring(res)))
                if mode() == 'block' then ok = false end
            end
        end
    end
    memo[src] = { name = name, t = os.clock(), ok = ok, left = math.max(0, (lcount[name] or 1) - 1) }
    return ok
end)
exports('Stats', function()
    local n, a = 0, 0
    for k in pairs(names) do n = n + 1 if armed(k) then a = a + 1 end end
    if armed('@weapon') then a = a + 1 end
    if armed('@vehicle') then a = a + 1 end
    return { mode = mode(), events = n, armed = a, ok = stats.ok, bad = stats.bad, flood = stats.flood, notoken = stats.notoken }
end)


-- Permis : armes et véhicules ----------------------------------------------------------------------------------------------------------------
-- Les ressources qui chargent shield.lua annoncent chaque arme donnée (GiveWeaponToPed) et chaque véhicule réseau créé (CreateVehicle).
-- Un menu de triche appelle les natives directement : rien n'est annoncé. Comme pour les évènements, ces règles ne sanctionnent qu'une fois ARMÉES
-- (assez d'annonces légitimes vues, et peu de joueurs « inexpliqués ») : une ressource tierce qui donne des armes ou des véhicules désarme la règle d'elle-même.
local WEAPON_OK = { [0] = true, [-1] = true, [-1569615261] = true, [-72657034] = true }   -- aucune, poings, parachute
local allowW, vperm = {}, {}                                                              -- src -> { [hash] = true } ; src -> { horodatages }
local function permitStat(k) return stat(k) end

RegisterNetEvent('wb_shield:permit', function(kind, value, token)
    local src = source
    local sec = secrets[src]
    if not sec or type(kind) ~= 'string' or type(value) ~= 'number' or type(token) ~= 'string' or #token > 40 then return end
    if kind ~= 'weapon' and kind ~= 'vehicle' then return end
    if limited(src, 'permit', 10, 300) then return end
    local rnd, sig = token:match('^(%d+):(%x+)$')
    value = math.floor(value)
    if not rnd or sig ~= mix(sec .. '|permit|' .. kind .. '|' .. value .. '|' .. rnd) or seen[src].set['p' .. token] then return end
    seen[src].set['p' .. token] = true
    if kind == 'weapon' then
        allowW[src] = allowW[src] or {}
        allowW[src][value] = true
        permitStat('@weapon').v = permitStat('@weapon').v + 1
    else
        vperm[src] = vperm[src] or {}
        vperm[src][#vperm[src] + 1] = os.time()
        if #vperm[src] > 20 then table.remove(vperm[src], 1) end
        permitStat('@vehicle').v = permitStat('@vehicle').v + 1
    end
    dirty = true
end)
AddEventHandler('playerDropped', function() local s = source allowW[s], vperm[s] = nil, nil end)
RegisterNetEvent('wb_shield:strip', function() end)   -- réservé

-- armes en main non annoncées (lues par le serveur)
local strikes, since = {}, {}
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            for src in pairs(secrets) do
                since[src] = since[src] or os.time()
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 and os.time() - since[src] > 30 then
                    local w = GetSelectedPedWeapon(ped)
                    if w and not WEAPON_OK[w] and not (allowW[src] and allowW[src][w]) and GetVehiclePedIsIn(ped, false) == 0 and GetEntityHealth(ped) > 0 then
                        strikes[src] = (strikes[src] or 0) + 1
                        if strikes[src] >= 3 then
                            strikes[src] = 0
                            local e = permitStat('@weapon')
                            e.u = e.u + 1
                            e.up[licenseOf(src)] = true
                            dirty = true
                            if armed('@weapon') then report(src, 'weapon_unlisted', ('arme en main non annoncée : %d'):format(w)) end
                        end
                    else strikes[src] = 0 end
                end
            end
        end)
    end
end)
AddEventHandler('playerDropped', function() local s = source strikes[s], since[s] = nil, nil end)

-- véhicules créés par un joueur sans annonce
AddEventHandler('entityCreated', function(ent)
    local ok = pcall(function()
        if not ent or ent == 0 or GetEntityType(ent) ~= 2 then return end
        SetTimeout(2500, function()
            pcall(function()
                if not DoesEntityExist(ent) then return end
                local owner = NetworkGetEntityOwner(ent)
                if not owner or owner <= 0 or not secrets[owner] then return end
                if GetEntityPopulationType and GetEntityPopulationType(ent) ~= 7 then return end         -- trafic et stationnés : pas de joueur derrière
                local sc = GetEntityScript and GetEntityScript(ent)
                if type(sc) == 'string' and sc ~= '' and GetResourceState(sc) ~= 'missing' then return end   -- créé par une ressource connue du serveur
                local q = vperm[owner]
                if q then
                    while #q > 0 do if os.time() - table.remove(q, 1) <= 20 then return end end         -- une annonce récente l'explique
                end
                local e = permitStat('@vehicle')
                e.u = e.u + 1
                e.up[licenseOf(owner)] = true
                dirty = true
                if armed('@vehicle') then
                    pcall(DeleteEntity, ent)
                    report(owner, 'vehicle_unlisted', 'véhicule créé sans annonce (supprimé)')
                end
            end)
        end)
    end)
end)

-- Console du serveur ----------------------------------------------------------------------------------------------------------------------
local LINE = "shared_script '@wb_shield/shield.lua'"
local NEVER = { wb_shield = true, oxmysql = true, chat = true, spawnmanager = true, sessionmanager = true, mapmanager = true, hardcap = true, baseevents = true, ['rconlog'] = true, webpack = true, yarn = true, monitor = true, wframework = true }
local function eligible(res)
    if NEVER[res] or res:find('^cfx') or res:find('^fivem') then return false end
    local f = LoadResourceFile(res, 'fxmanifest.lua')
    if not f then return false end
    if f:find('wb_shield/shield.lua', 1, true) then return false, 'déjà' end
    if LoadResourceFile(res, '.fxap') then return false, 'protégée (escrow)' end
    if not (f:find('client_script') or f:find('server_script')) then return false end
    return true, f
end
local function cmd(name, fn) RegisterCommand(name, function(src, args) if src ~= 0 then return end fn(args) end, true) end

cmd('shield_status', function()
    local s = exports.wb_shield:Stats()
    print(('[wb_shield] mode %s — %d évènements vus, %d armés — %d jetons valides, %d faux/rejoués, %d sans jeton, %d en rafale'):format(s.mode, s.events, s.armed, s.ok, s.bad, s.notoken, s.flood))
end)
cmd('shield_events', function()
    local list = {}
    for k, e in pairs(ev) do
        local n = 0 for _ in pairs(e.up) do n = n + 1 end
        list[#list + 1] = { k = k, v = e.v, u = e.u, n = n, a = armed(k) }
    end
    table.sort(list, function(a, b) if a.a ~= b.a then return not a.a end return a.u > b.u end)
    print('[wb_shield] évènements NON armés d\'abord (jetons valides / appels sans jeton / joueurs sans jeton) :')
    for i = 1, math.min(#list, 40) do print(('  %s %s : %d / %d / %d'):format(list[i].a and '[armé]' or '[    ]', list[i].k, list[i].v, list[i].u, list[i].n)) end
end)
cmd('shield_install', function(a)
    local target, dry = a[1], a[2] == 'dry' or a[1] == 'dry'
    if not target or target == 'dry' then print('[wb_shield] usage : shield_install <ressource|all> [dry]') return end
    local n = 0
    for i = 0, GetNumResources() - 1 do
        local res = GetResourceByFindIndex(i)
        if res and (target == 'all' or target == res) then
            local ok, f = eligible(res)
            if ok then
                n = n + 1
                if dry then print('[wb_shield] (simulation) ' .. res)
                else
                    SaveResourceFile(res, 'fxmanifest.lua.wbshield.bak', f, -1)
                    SaveResourceFile(res, 'fxmanifest.lua', f .. '\n\n' .. LINE .. '\n', -1)
                    print('[wb_shield] ajouté à ' .. res .. ' (sauvegarde : fxmanifest.lua.wbshield.bak)')
                end
            elseif f and target == res then print('[wb_shield] ' .. res .. ' : ' .. tostring(f)) end
        end
    end
    print(('[wb_shield] %d ressource(s)%s. Redémarre-les (ou le serveur) pour appliquer.'):format(n, dry and ' (simulation)' or ' modifiée(s)'))
end)
cmd('shield_remove', function(a)
    local target = a[1]
    if not target then print('[wb_shield] usage : shield_remove <ressource|all>') return end
    local n = 0
    for i = 0, GetNumResources() - 1 do
        local res = GetResourceByFindIndex(i)
        if res and (target == 'all' or target == res) then
            local f = LoadResourceFile(res, 'fxmanifest.lua')
            if f and f:find('wb_shield/shield.lua', 1, true) then
                SaveResourceFile(res, 'fxmanifest.lua', (f:gsub("\n*shared_script '@wb_shield/shield%.lua'\n*", '\n')), -1)
                n = n + 1
                print('[wb_shield] retiré de ' .. res)
            end
        end
    end
    print(('[wb_shield] %d ressource(s) nettoyée(s).'):format(n))
end)
