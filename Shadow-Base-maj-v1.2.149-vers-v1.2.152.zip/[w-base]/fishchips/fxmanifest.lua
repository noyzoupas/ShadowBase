fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'fishchips'
description 'Fish & Chips : bornes de commande, cuisine, vente sur place (sans livraison) — pour Shadow Base (pb_panel)'
version '1.0.0'

dependency 'pb_panel'

ui_page 'html/index.html'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files {
  'html/index.html',
  'html/style.css',
  'html/app.js',
}

-- (v1.2.82) Escrow Cfx.re : fichiers laissés lisibles et modifiables par le propriétaire du serveur (le reste du Lua est chiffré)
escrow_ignore {
    'config.lua',
}

shared_script '@wb_shield/shield.lua'
