/* HUD : quatre styles (ring, spotlight, minimal, classic). hudView(cfg) renvoie { main, veh, top, update(live, state) } ; utilisé en jeu et dans l'aperçu du panel. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const NEEDS = [ // clé du réglage, icône, valeur
  ['health', 'heart', 'hp', 'c_health'], ['armor', 'shield', 'armor', 'c_armor'], ['hunger', 'food', 'hunger', 'c_hunger'],
  ['thirst', 'drop', 'thirst', 'c_thirst'], ['stress', 'stress', 'stress', 'c_stress'], ['stamina', 'bolt', 'stamina', 'c_stamina'],
];
const pad = (n) => (n < 10 ? '0' : '') + n;
const dir = (hd) => ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'][Math.round(((hd % 360) + 360) % 360 / 45) % 8];


// ---------- compteur : cadran à 270° ----------
// Arc de vitesse (dégradé aux couleurs de la base) + graduations qui s'allument, arc de régime avec zone rouge, rapport, carburant en segments.
const NS = 'http://www.w3.org/2000/svg';
let gsdUid = 0;
const sv = (tag, attrs, kids) => { const e = document.createElementNS(NS, tag); Object.keys(attrs || {}).forEach((k) => e.setAttribute(k, attrs[k])); (kids || []).forEach((c) => e.appendChild(c)); return e; };
const CX = 150, CY = 150, A0 = 135, SWEEP = 270;
const pt = (r, deg) => { const a = deg * Math.PI / 180; return [CX + r * Math.cos(a), CY + r * Math.sin(a)]; };
const arcPath = (r) => { const p1 = pt(r, A0), p2 = pt(r, A0 + SWEEP); return 'M' + p1[0].toFixed(2) + ' ' + p1[1].toFixed(2) + 'A' + r + ' ' + r + ' 0 1 1 ' + p2[0].toFixed(2) + ' ' + p2[1].toFixed(2); };
const LABEL_STEPS = { 20: 4, 25: 5, 30: 6, 40: 4, 50: 5, 100: 5 };   // pas des chiffres → nombre de graduations entre deux chiffres
function niceStep(max) { const c = [20, 25, 30, 40, 50, 100]; for (let i = 0; i < c.length; i++) if (max / c[i] <= 8) return c[i]; return 100; }

function buildSpeedo(cfg, css) {
  const mph = cfg.units === 'mph';
  const custom = Number(cfg.speed_max) > 0;
  const max = custom ? Math.max(60, Math.min(500, Number(cfg.speed_max))) : (mph ? 180 : 280);
  const lab = custom ? niceStep(max) : (mph ? 30 : 40), minor = lab / LABEL_STEPS[lab];
  const styleName = cfg.speedo_style === 'disc' ? 'disc' : cfg.speedo_style === 'floating' ? 'floating' : 'digits';
  const gid = 'gsd' + (++gsdUid);
  const ticks = [], labels = [];
  const gT = sv('g'), gL = sv('g');
  for (let v = 0; v <= max + 0.001; v += minor) {
    const isMajor = Math.abs(v / lab - Math.round(v / lab)) < 0.001, isMid = !isMajor && lab % 2 === 0 && Math.abs(v / (lab / 2) - Math.round(v / (lab / 2))) < 0.001;
    const a = A0 + SWEEP * (v / max), len = isMajor ? 12 : isMid ? 8 : 5, p1 = pt(142, a), p2 = pt(142 - len, a);
    const l = sv('line', { x1: p1[0].toFixed(2), y1: p1[1].toFixed(2), x2: p2[0].toFixed(2), y2: p2[1].toFixed(2), class: 'gsd-tk' + (isMajor ? ' maj' : '') });
    gT.appendChild(l); ticks.push({ el: l, v, on: false });
    if (isMajor) {
      const q = pt(121, a), t = sv('text', { x: q[0].toFixed(1), y: q[1].toFixed(1), class: 'gsd-lb' }); t.textContent = String(Math.round(v));
      gL.appendChild(t); labels.push({ el: t, v, on: false });
    }
  }
  const fil = sv('path', { d: arcPath(104), pathLength: 100, class: 'gsd-fil', stroke: 'url(#' + gid + ')' });
  fil.style.strokeDasharray = '100'; fil.style.strokeDashoffset = '100'; fil.style.opacity = '0';
  const tip = sv('circle', { cx: CX + 104, cy: CY, r: 4.6, class: 'gsd-tip' });
  const rf = sv('path', { d: arcPath(88), pathLength: 100, class: 'gsd-rf' });
  rf.style.strokeDasharray = '100'; rf.style.strokeDashoffset = '100';
  const rz = sv('path', { d: arcPath(88), pathLength: 100, class: 'gsd-rz' }); rz.style.strokeDasharray = '15 85'; rz.style.strokeDashoffset = '-85';
  const svg = sv('svg', { viewBox: '0 0 300 300', class: 'gsd-svg' }, [
    sv('defs', {}, [sv('linearGradient', { id: gid, x1: '0.1', y1: '0.9', x2: '0.9', y2: '0.1' }, [sv('stop', { offset: '0', style: 'stop-color:var(--acc2,#aab0bb)' }), sv('stop', { offset: '1', style: 'stop-color:var(--acc)' })])]),
    gT, gL, sv('path', { d: arcPath(104), pathLength: 100, class: 'gsd-trk' }), fil, tip,
    sv('path', { d: arcPath(88), pathLength: 100, class: 'gsd-rt' }), rz, rf,
  ]);
  const gear = h('div', { class: 'gsd-gear' }, 'N'), num = h('b', { class: 'gsd-n' }, '0'), unit = h('em', { class: 'gsd-u' }, mph ? 'mph' : 'km/h'), odoEl = h('span', { class: 'gsd-odo hidden-o' }, '');
  const pips = []; for (let i = 0; i < 10; i++) pips.push(h('i'));
  const eng = h('span', { class: 'gsd-eng' }, ico('engine')), range = h('span', { class: 'gsd-rg' }, '');
  const showFuel = cfg.show_fuel !== false;
  const bottom = h('div', { class: 'gsd-b' }, showFuel ? h('div', { class: 'gsd-f' }, h('span', { class: 'gsd-fi' }, ico('fuel')), h('div', { class: 'gsd-pips' }, pips), eng) : eng, showFuel ? range : null);
  const el = h('div', { class: 'gv gsd gsd-' + styleName, style: Object.assign({ left: (cfg.veh_x != null ? cfg.veh_x : 89) + '%', top: (cfg.veh_y != null ? cfg.veh_y : 82) + '%', '--sc': cfg.veh_scale || 1 }, css) },
    h('div', { class: 'gsd-bg' }), svg, h('div', { class: 'gsd-c' }, gear, num, unit, odoEl), bottom);
  const low = cfg.low_threshold != null ? cfg.low_threshold : 20, showRpm = cfg.show_rpm !== false;
  if (!showRpm) { rf.style.display = 'none'; rz.style.display = 'none'; svg.querySelector('.gsd-rt').style.display = 'none'; }
  function light(list, sp) { for (let i = 0; i < list.length; i++) { const on = list[i].v <= sp + 0.001 && sp > 0; if (on !== list[i].on) { list[i].on = on; list[i].el.classList.toggle('on', on); } } }
  function update(v) {
    v = v || {};
    const sp = Math.max(0, Number(v.speed) || 0), f = Math.min(1, sp / max);
    fil.style.strokeDashoffset = (100 - f * 100).toFixed(2); fil.style.opacity = f < 0.004 ? '0' : '1';
    tip.style.transform = 'rotate(' + (A0 + SWEEP * f).toFixed(2) + 'deg)'; tip.style.opacity = f < 0.004 ? '0' : '1';
    num.textContent = String(Math.round(sp));
    light(ticks, sp); light(labels, sp);
    gear.textContent = v.gear === 0 ? 'R' : (sp < 1 && (v.gear == null || v.gear <= 1) ? 'N' : String(v.gear == null ? 'N' : v.gear));
    if (v.odo != null && cfg.show_odo !== false) {
      const t = Number(v.odo).toFixed(1).split('.'), whole = t[0].replace(/\B(?=(\d{3})+(?!\d))/g, '\u202f');
      odoEl.textContent = whole + ',' + t[1] + (mph ? ' mi' : ' km'); odoEl.classList.remove('hidden-o');
    } else odoEl.classList.add('hidden-o');
    const r = Math.max(0, Math.min(100, Number(v.rpm) || 0));
    rf.style.strokeDashoffset = (100 - r).toFixed(2); rf.classList.toggle('red', r >= 85);
    const fuel = Math.max(0, Math.min(100, Number(v.fuel) || 0)), lit = Math.ceil(fuel / 10);
    for (let i = 0; i < pips.length; i++) pips[i].classList.toggle('on', i < lit);
    const fm = (n) => (n < 10 ? n.toFixed(1) : String(Math.round(n)));
    range.textContent = v.range != null ? fm(Number(v.range)) + (v.rangemax != null ? '/' + fm(Number(v.rangemax)) : '') + (mph ? ' mi' : ' km') : '';
    el.classList.toggle('lowf', fuel <= low); el.classList.toggle('off', v.on === false); el.classList.toggle('hot', f > 0.85);
    eng.classList.toggle('bad', (v.engine != null && v.engine < 30) || v.on === false);
  }
  return { el, update };
}

// ---------- HUD « photo » : colonne en bas à gauche, tout en gris ; le mode de voix passe au vert quand on parle ----------
function photoHud(cfg) {
  const css = { '--acc': cfg.c_accent || '#dfe2e7' };
  const zone = h('b', null, ''), street = h('span', null, ''), time = h('span', null, '12:00'), vmode = h('span', { class: 'pv-pill' }, 'Normal');
  const cash = h('span', null, '0 $'), bank = h('span', null, '0 $'), dir2 = h('span', null, 'N 0°'), dirty = h('span', null, '');
  const main = h('div', { class: 'gh gh-photo', style: Object.assign({ left: (cfg.photo_x != null ? cfg.photo_x : 16.4) + '%', bottom: (cfg.photo_y != null ? cfg.photo_y : 2.4) + '%' }, css) },
    h('div', { class: 'pv-r' }, h('span', { class: 'pv-i pin' }, ico('pin')), h('div', { class: 'pv-2' }, zone, street)),
    h('div', { class: 'pv-r' }, h('span', { class: 'pv-i' }, ico('clock')), time),
    h('div', { class: 'pv-r' }, vmode, h('span', { class: 'pv-i' }, ico('coins')), cash),
    h('div', { class: 'pv-r' }, h('span', { class: 'pv-i' }, ico('card')), bank, h('span', { class: 'pv-i' }, ico('pin')), dir2),
    h('div', { class: 'pv-r pv-dirty hidden' }, h('span', { class: 'pv-i' }, ico('coins')), dirty));
  // Besoins (au-dessus de la colonne) : pastilles rondes faim / soif / micro, barres vie / armure
  const low = cfg.low_threshold != null ? cfg.low_threshold : 20;
  const needs = h('div', { class: 'pv-needs' });
  const pills = h('div', { class: 'pv-pills' });
  const pill = (key, icon, color) => {
    const fill = h('i', { class: 'pv-pf' });
    const el = h('span', { class: 'pv-p', style: { '--pc': color } }, fill, ico(icon));
    pills.appendChild(el);
    return { el, fill };
  };
  const pHunger = cfg.show_hunger !== false ? pill('hunger', 'food', cfg.c_hunger || '#e23b4e') : null;
  const pThirst = cfg.show_thirst !== false ? pill('thirst', 'drop', cfg.c_thirst || '#e23b4e') : null;
  const pStress = cfg.show_stress === true ? pill('stress', 'stress', cfg.c_stress || '#b58cff') : null;
  const pMic = cfg.show_voice !== false ? pill('voice', 'mic', '#6b6f78') : null;
  const bar = (icon, color) => {
    const fill = h('i');
    const row = h('div', { class: 'pv-b' }, h('span', { class: 'pv-bi' }, ico(icon)), h('div', { class: 'pv-bt', style: { '--bc': color } }, fill));
    needs.appendChild(row);
    return { row, fill };
  };
  if (pills.children.length) needs.appendChild(pills);
  const bHealth = cfg.show_health !== false ? bar('heart', cfg.c_health_bar || '#f2f3f5') : null;
  const bArmor = cfg.show_armor !== false ? bar('shield', cfg.c_armor || '#6fb4ff') : null;
  if (needs.children.length) main.insertBefore(needs, main.firstChild);
  const pct = (v) => Math.max(0, Math.min(100, Number(v) || 0));
  const setPill = (p, v, hideFull) => {
    if (!p) return;
    v = pct(v);
    p.fill.style.height = v + '%';
    p.el.classList.toggle('low', v <= low);
    p.el.classList.toggle('hidden', !!(hideFull && v >= 100));
  };
  const speedo = buildSpeedo(cfg, css), veh = speedo.el; veh.classList.add('hidden');
  const top = h('div', { class: 'hidden' });
  function update(live, state) {
    live = live || {}; state = state || {};
    if (live.visible === false) { main.classList.add('hidden'); veh.classList.add('hidden'); return; }
    main.classList.remove('hidden');
    setPill(pHunger, state.hunger, cfg.hide_full); setPill(pThirst, state.thirst, cfg.hide_full); setPill(pStress, state.stress, false);
    if (pMic) { pMic.fill.style.height = '100%'; pMic.el.classList.toggle('talk', !!live.talking); }
    if (bHealth) { const v = pct(live.hp); bHealth.fill.style.width = v + '%'; bHealth.row.classList.toggle('low', v <= low); }
    if (bArmor) { const v = pct(live.armor); bArmor.fill.style.width = v + '%'; bArmor.row.classList.toggle('hidden', v <= 0); }
    zone.textContent = live.zone || ''; street.textContent = live.street || '';
    time.textContent = pad(live.hour || 0) + ':' + pad(live.minute || 0);
    cash.textContent = G.money(state.cash); bank.textContent = G.money(state.bank);
    dir2.textContent = dir(live.heading || 0) + ' ' + Math.round(live.heading || 0) + '°';
    vmode.textContent = live.radio ? 'Radio' : (live.vmode || 'Normal');
    vmode.classList.toggle('on', !!live.talking);
    if (state.dirty > 0) { dirty.textContent = G.money(state.dirty) + ' sale'; dirty.parentNode.classList.remove('hidden'); } else dirty.parentNode.classList.add('hidden');
    if (live.veh && cfg.show_vehicle !== false) { veh.classList.remove('hidden'); speedo.update(live.veh); } else veh.classList.add('hidden');
  }
  return { main, top, veh, bar: null, update };
}

// ---------- HUD « Shadow » : collé à la mini-carte (rue dans la carte, vie dessous, argent / voix / faim / soif à droite),
// heure, date et serveur en haut à droite. La position de la mini-carte vient du jeu (live.mm), quelle que soit la résolution. ----------
let srvInfo = { online: null, max: null };
G.on('hud.srv', (d) => { srvInfo = d || srvInfo; });
const MM0 = { l: 0.015, t: 0.775, w: 0.141, h: 0.176 };
function shadowHud(cfg) {
  const low = cfg.low_threshold != null ? cfg.low_threshold : 20;
  const main = h('div', { class: 'gh gh-sh' });
  // dans la carte : lieu en haut à gauche, direction en haut à droite
  const zone = h('b', null, ''), street = h('span', null, ''), cmp = h('em', { class: 'sh-n' }, 'N');
  const map = h('div', { class: 'sh-map' }, h('div', { class: 'sh-loc' }, h('i', { class: 'sh-pin' }, ico('pin')), h('div', null, zone, street)), cmp);
  const hpFill = h('i'), arFill = h('i'), arRow = h('div', { class: 'sh-bar ar hidden' }, arFill);
  const bars = h('div', { class: 'sh-bars' }, h('div', { class: 'sh-bar hp' }, hpFill), arRow);
  // à droite de la carte : argent en haut, voix / faim / soif en bas
  const cash = h('b', null, '0 $'), bank = h('b', null, '0 $'), dirty = h('b', null, ''), dirtyRow = h('div', { class: 'sh-r dirty hidden' }, h('i', null, ico('coins')), dirty);
  const voice = h('b', null, 'Normal'), voiceRow = h('div', { class: 'sh-r voice' }, h('i', null, ico('mic')), voice);
  const hun = h('b', null, '100%'), thi = h('b', null, '100%');
  const hunRow = h('div', { class: 'sh-r need' }, h('i', null, ico('food')), hun), thiRow = h('div', { class: 'sh-r need' }, h('i', null, ico('drop')), thi);
  const side = h('div', { class: 'sh-side' },
    h('div', { class: 'sh-top' }, h('div', { class: 'sh-r' }, h('i', null, ico('wallet')), cash), h('div', { class: 'sh-r' }, h('i', null, ico('card')), bank), dirtyRow),
    h('div', { class: 'sh-bot' }, cfg.show_voice !== false ? voiceRow : null, cfg.show_hunger !== false ? hunRow : null, cfg.show_thirst !== false ? thiRow : null));
  main.appendChild(map); main.appendChild(bars); main.appendChild(side);
  // en haut à droite : serveur, heure, date, identifiant et joueurs
  const b = (G.cfg && G.cfg.brand) || {};
  const logo = b.logo ? h('img', { class: 'sh-logo', src: b.logo, alt: '' }) : h('b', { class: 'sh-name' }, String(b.name || 'SHADOW').toUpperCase().slice(0, 18));
  const clock = h('b', { class: 'sh-time' }, '00:00'), date = h('span', { class: 'sh-date' }, ''), info = h('span', { class: 'sh-info' }, '');
  const top = h('div', { class: 'gh-shtop' }, h('div', { class: 'sh-head' }, logo, h('div', { class: 'sh-clock' }, clock, date)), info);
  const speedo = buildSpeedo(cfg, { '--acc': cfg.c_accent || '#dfe2e7' });
  const veh = speedo.el; veh.classList.add('hidden');
  const pct = (v) => Math.max(0, Math.min(100, Math.round(Number(v) || 0)));
  let lastMm = '';
  function place(mm) {
    mm = mm || MM0;
    const k = mm.l + ':' + mm.t + ':' + mm.w + ':' + mm.h;
    if (k === lastMm) return;
    lastMm = k;
    const P = (v) => (v * 100).toFixed(3) + '%';
    Object.assign(map.style, { left: P(mm.l), top: P(mm.t), width: P(mm.w), height: P(mm.h) });
    Object.assign(bars.style, { left: P(mm.l), top: 'calc(' + P(mm.t + mm.h) + ' + 4px)', width: P(mm.w) });
    Object.assign(side.style, { left: 'calc(' + P(mm.l + mm.w) + ' + 10px)', top: P(mm.t), height: P(mm.h) });
  }
  place(MM0);
  function update(live, state) {
    live = live || {}; state = state || {};
    if (live.visible === false) { main.classList.add('hidden'); top.classList.add('hidden'); veh.classList.add('hidden'); return; }
    main.classList.remove('hidden'); top.classList.remove('hidden');
    place(live.mm);
    zone.textContent = live.zone || ''; street.textContent = live.street || '';
    cmp.textContent = dir(live.heading || 0);
    const hp = pct(live.hp), ar = pct(live.armor);
    hpFill.style.width = hp + '%'; bars.classList.toggle('low', hp <= low);
    arFill.style.width = ar + '%'; arRow.classList.toggle('hidden', ar <= 0);
    cash.textContent = G.money(state.cash); bank.textContent = G.money(state.bank);
    if (state.dirty > 0) { dirty.textContent = G.money(state.dirty) + ' sale'; dirtyRow.classList.remove('hidden'); } else dirtyRow.classList.add('hidden');
    voice.textContent = live.radio ? 'Radio' : (live.talking ? 'Parler' : (live.vmode || 'Normal'));
    voiceRow.classList.toggle('on', !!live.talking);
    const hu = pct(state.hunger), th = pct(state.thirst);
    hun.textContent = hu + '%'; thi.textContent = th + '%';
    hunRow.classList.toggle('low', hu <= low); thiRow.classList.toggle('low', th <= low);
    hunRow.classList.toggle('hidden', !!(cfg.hide_full && hu >= 100)); thiRow.classList.toggle('hidden', !!(cfg.hide_full && th >= 100));
    clock.textContent = pad(live.hour || 0) + ':' + pad(live.minute || 0);
    const d = new Date();
    date.textContent = pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear();
    const parts = [];
    if (live.id != null) parts.push('ID ' + live.id);
    if (srvInfo && srvInfo.online != null) parts.push(srvInfo.online + (srvInfo.max ? '/' + srvInfo.max : '') + ' en ligne');
    info.textContent = parts.join('  ·  ');
    if (live.veh && cfg.show_vehicle !== false) { veh.classList.remove('hidden'); speedo.update(live.veh); } else veh.classList.add('hidden');
  }
  return { main, top, veh, bar: null, update };
}

function hudView(cfg) {
  cfg = cfg || {};
  if ((cfg.style || 'ring') === 'shadow') return shadowHud(cfg);
  if ((cfg.style || 'ring') === 'photo') return photoHud(cfg);
  const style = cfg.style || 'ring';
  const ring = style === 'ring';
  const statusOn = cfg.status_on === true;       // vie, faim, soif, argent, heure, boussole… : coupés par défaut, seul le compteur reste
  const VEH_KEYS = { show_vehicle: 1, show_fuel: 1, show_rpm: 1 };
  const on = (k) => (VEH_KEYS[k] ? cfg[k] !== false : statusOn && cfg[k] !== false);
  const css = {
    '--acc': cfg.c_accent || '#dfe2e7', '--acc-rgb': G.hexToRgb(cfg.c_accent || '#dfe2e7'),
  };
  const parts = {};
  const main = h('div', { class: 'gh gh-' + style, style: Object.assign({ left: ring ? (cfg.ring_x != null ? cfg.ring_x : 19.6) + '%' : (cfg.pos_x != null ? cfg.pos_x : 14) + '%', top: ring ? (cfg.ring_y != null ? cfg.ring_y : 97.5) + '%' : (cfg.pos_y != null ? cfg.pos_y : 90) + '%', opacity: cfg.opacity != null ? cfg.opacity : 1, '--sc': cfg.scale || 1 }, css) });
  const rows = h('div', { class: 'gh-rows' });
  NEEDS.forEach(([name, icon, key, colorKey]) => {
    const show = name === 'stress' ? (statusOn && cfg.show_stress === true) : name === 'armor' ? on('show_armor') : name === 'stamina' ? on('show_stamina') : on('show_' + name);
    if (!show) return;
    const color = cfg[colorKey] || '#fff';
    let el, fill, val;
    if (ring && (name === 'health' || name === 'armor')) { parts[name] = { bar: true, key }; return; }   // en « anneaux », vie et armure sont dans la barre sous la mini-carte
    if (style === 'minimal' || ring) {
      const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 44 44');
      const bg = document.createElementNS(NS, 'circle'); bg.setAttribute('cx', 22); bg.setAttribute('cy', 22); bg.setAttribute('r', 19); bg.setAttribute('class', 'trk');
      fill = document.createElementNS(NS, 'circle'); fill.setAttribute('cx', 22); fill.setAttribute('cy', 22); fill.setAttribute('r', 19); fill.setAttribute('class', 'fil'); fill.setAttribute('stroke', color);
      fill.setAttribute('stroke-dasharray', '119.4'); fill.setAttribute('stroke-dashoffset', '0');
      svg.appendChild(bg); svg.appendChild(fill);
      el = h('div', { class: 'gn gn-' + name }, svg, h('span', { class: 'ic', style: { color } }, ico(icon)));
    } else {
      fill = h('i', { style: { background: color } }); val = h('b', null, '100');
      el = h('div', { class: 'gn gn-' + name }, h('span', { class: 'ic', style: { color } }, ico(icon)), h('div', { class: 'bar' }, fill), style === 'spotlight' ? val : null);
    }
    parts[name] = { el, fill, val, key, min: style === 'minimal' || ring };
    rows.appendChild(el);
  });
  main.appendChild(rows);
  if (ring && statusOn) {
    const bar = h('div', { class: 'gh-mbar', style: Object.assign({ left: (cfg.bar_x != null ? cfg.bar_x : 8.6) + '%', top: (cfg.bar_y != null ? cfg.bar_y : 97.6) + '%', width: (cfg.bar_w != null ? cfg.bar_w : 14) + '%', opacity: cfg.opacity != null ? cfg.opacity : 1 }, css) });
    if (on('show_health')) { parts.health.fill = h('i', { style: { background: cfg.c_health || '#ff6b7d' } }); bar.appendChild(h('div', { class: 'mb hp' }, parts.health.fill)); }
    if (on('show_armor')) { parts.armor.fill = h('i', { style: { background: cfg.c_armor || '#6fb4ff' } }); parts.armor.row = h('div', { class: 'mb ar hidden' }, parts.armor.fill); bar.appendChild(parts.armor.row); }
    parts.mbar = bar;
  }
  // heure, argent, micro
  const chips = h('div', { class: 'gh-chips' });
  if (on('show_voice')) { parts.mic = h('span', { class: 'chip mic' }, ico('mic')); chips.appendChild(parts.mic); }
  if (on('show_clock')) { parts.clock = h('span', { class: 'chip' }, ico('clock'), h('b', null, '12:00')); chips.appendChild(parts.clock); }
  if (on('show_money')) { parts.cash = h('b', null, '$0'); parts.bank = h('b', null, '$0'); chips.appendChild(h('span', { class: 'chip' }, ico('coins'), parts.cash, h('em', null, '·'), parts.bank)); }
  if (chips.children.length) main.appendChild(chips);

  // rue + boussole (haut centre)
  const top = h('div', { class: 'gh-top gh-' + style, style: css });
  if (on('show_compass')) { parts.dir = h('b', null, 'N'); parts.deg = h('em', null, '0°'); top.appendChild(h('div', { class: 'cmp' }, parts.dir, parts.deg)); }
  if (on('show_street')) { parts.street = h('b', null, ''); parts.zone = h('em', null, ''); top.appendChild(h('div', { class: 'st' }, ico('pin'), h('div', null, parts.street, parts.zone))); }

  // véhicule : cadran W (voir buildSpeedo)
  const speedo = buildSpeedo(cfg, css);
  const veh = speedo.el;
  veh.classList.add('hidden');
  if (!statusOn) { main.classList.add('hidden'); top.classList.add('hidden'); }

  const low = cfg.low_threshold != null ? cfg.low_threshold : 20;
  function setNeed(name, v) {
    const p = parts[name]; if (!p) return;
    v = Math.max(0, Math.min(100, v == null ? 0 : v));
    if (p.bar) {
      if (!p.fill) return;
      p.fill.style.width = v + '%';
      if (name === 'armor') p.row.classList.toggle('hidden', v <= 0); else p.fill.parentNode.classList.toggle('low', v <= low);
      return;
    }
    if (p.min) p.fill.setAttribute('stroke-dashoffset', (119.4 * (1 - v / 100)).toFixed(1));
    else p.fill.style.width = v + '%';
    if (p.val) p.val.textContent = Math.round(v);
    p.el.classList.toggle('low', v <= low && name !== 'stress' && name !== 'stamina' && name !== 'armor');
    p.el.classList.toggle('hi', name === 'stress' && v >= 100 - low);
    if (name === 'armor') p.el.classList.toggle('hidden', v <= 0);
    if ((name === 'hunger' || name === 'thirst') && cfg.hide_full) p.el.classList.toggle('hidden', v >= 100);
  }
  function update(live, state) {
    live = live || {}; state = state || {};
    if (live.visible === false) { main.classList.add('hidden'); top.classList.add('hidden'); veh.classList.add('hidden'); if (parts.mbar) parts.mbar.classList.add('hidden'); return; }
    if (statusOn) { main.classList.remove('hidden'); top.classList.remove('hidden'); if (parts.mbar) parts.mbar.classList.remove('hidden'); }
    setNeed('health', live.hp); setNeed('armor', live.armor); setNeed('hunger', state.hunger); setNeed('thirst', state.thirst); setNeed('stress', state.stress);
    if (parts.stamina) setNeed('stamina', live.oxygen != null ? live.oxygen : live.stamina);
    if (parts.stamina) parts.stamina.el.classList.toggle('oxy', live.oxygen != null);
    if (parts.mic) parts.mic.classList.toggle('on', !!live.talking);
    if (parts.clock) parts.clock.lastChild.textContent = pad(live.hour || 0) + ':' + pad(live.minute || 0);
    if (parts.cash) { parts.cash.textContent = G.money(state.cash); parts.bank.textContent = G.money(state.bank); }
    if (parts.dir) { parts.dir.textContent = dir(live.heading || 0); parts.deg.textContent = Math.round(live.heading || 0) + '°'; }
    if (parts.street) { parts.street.textContent = live.street || ''; parts.zone.textContent = live.zone || ''; }
    if (live.veh && on('show_vehicle')) {
      veh.classList.remove('hidden'); speedo.update(live.veh);
    } else veh.classList.add('hidden');
  }
  return { main, top, veh, bar: parts.mbar || null, update };
}
G.hudView = hudView;

// HUD en jeu : un seul rendu, reconstruit quand la configuration change, mis à jour par les messages du client.
let cur = null, lastLive = { visible: false };
const gameRoot = () => { let r = document.getElementById('g-hud'); if (!r) { r = h('div', { id: 'g-hud' }); G.root.appendChild(r); } return r; };
function rebuild() {
  const r = G.clear(gameRoot());
  cur = hudView(G.cfg.hud);
  r.appendChild(cur.main); r.appendChild(cur.top); r.appendChild(cur.veh); if (cur.bar) r.appendChild(cur.bar);
  cur.update(lastLive, G.state);
}
G.on('cfg', rebuild);
G.on('hud', (live) => { lastLive = live; if (!cur) rebuild(); else cur.update(live, G.state); });
G.on('state', () => { if (cur) cur.update(lastLive, G.state); });

// Aperçu dans le panel : données d'exemple, réglages du formulaire appliqués avant l'enregistrement.
G.preview.hud = function (box, cfg) {
  G.clear(box);
  cfg = cfg || {};
  const mph = cfg.units === 'mph', statusOn = cfg.status_on === true || cfg.style === 'shadow';
  const v = hudView(Object.assign({}, cfg, { pos_x: 22, pos_y: 80, veh_x: statusOn ? 80 : 50, veh_y: 52, veh_scale: 0.95, opacity: 1, ring_x: 24, ring_y: 90, bar_x: 3, bar_y: 94, bar_w: 20 }));
  const stage = h('div', { class: 'gstage tall' }, statusOn ? [v.top, v.main, v.bar] : null, v.veh);
  box.appendChild(stage);
  const base = { visible: true, hp: 82, armor: 40, stamina: 64, talking: true, hour: 21, minute: 37, street: 'Vinewood Boulevard', zone: 'Vinewood', heading: 128 };
  const st = { hunger: 74, thirst: cfg.low_threshold > 15 ? 12 : 45, stress: 38, cash: 4250, bank: 18900 };
  const frame = (t) => {   // démonstration : le compteur monte et descend, change de rapport, passe en zone rouge
    const f = (1 - Math.cos(t)) / 2, top = mph ? 150 : 240, speed = Math.round(f * top), per = mph ? 28 : 45;
    const gearNo = Math.min(6, 1 + Math.floor(speed / per)), part = (speed % per) / per;
    return Object.assign({}, base, { veh: { speed, fuel: 62, range: mph ? 7.7 : 12.4, rangemax: mph ? 12.4 : 20, gear: speed < 1 ? 1 : gearNo, rpm: Math.round(22 + part * 70 + (speed > top * 0.9 ? 8 : 0)), engine: 88, on: true, odo: mph ? 29957.3 : 48213.7 } });
  };
  v.update(frame(Math.PI * 0.62), st);
  let t = Math.PI * 0.62;
  const iv = setInterval(() => { if (!box.isConnected) { clearInterval(iv); return; } t += 0.05; v.update(frame(t), st); }, 90);
};
})();
