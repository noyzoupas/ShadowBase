-- Tablette citoyen / entreprise : ouverture, navigation, réparation du garage. Toutes les données et vérifications viennent du serveur.
local G = PBG
local isOpen = false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

-- Tablette en main tant qu'une tablette est ouverte (entreprise, organisation, police…) : objet + animation, retirés à la fermeture
local tab, tabUsers = nil, 0
local TAB_DICT, TAB_ANIM = 'amb@code_human_in_bus_passenger_idles@female@tablet@base', 'base'
function G.TabletAnim(on)
    tabUsers = math.max(0, tabUsers + (on and 1 or -1))
    local ped = PlayerPedId()
    if tabUsers > 0 and not tab then
        if IsPedInAnyVehicle(ped, false) or IsEntityDead(ped) then return end
        local model = joaat('prop_cs_tablet')
        RequestModel(model)
        local t = GetGameTimer() + 1500
        while not HasModelLoaded(model) and GetGameTimer() < t do Wait(10) end
        RequestAnimDict(TAB_DICT)
        while not HasAnimDictLoaded(TAB_DICT) and GetGameTimer() < t do Wait(10) end
        if tabUsers == 0 or not HasModelLoaded(model) then return end
        local c = GetEntityCoords(ped)
        tab = CreateObject(model, c.x, c.y, c.z + 0.2, true, true, false)
        SetModelAsNoLongerNeeded(model)
        AttachEntityToEntity(tab, ped, GetPedBoneIndex(ped, 60309), 0.03, 0.002, -0.0, 10.0, 160.0, 0.0, true, false, false, false, 2, true)
        if HasAnimDictLoaded(TAB_DICT) then TaskPlayAnim(ped, TAB_DICT, TAB_ANIM, 3.0, 3.0, -1, 49, 0, false, false, false) end
        CreateThread(function()
            while tab and tabUsers > 0 do
                Wait(400)
                local p = PlayerPedId()
                if HasAnimDictLoaded(TAB_DICT) and not IsEntityPlayingAnim(p, TAB_DICT, TAB_ANIM, 3) and not IsPedInAnyVehicle(p, false) then TaskPlayAnim(p, TAB_DICT, TAB_ANIM, 3.0, 3.0, -1, 49, 0, false, false, false) end
            end
        end)
    elseif tabUsers == 0 and tab then
        if DoesEntityExist(tab) then DetachEntity(tab, true, true) DeleteEntity(tab) end
        tab = nil
        StopAnimTask(ped, TAB_DICT, TAB_ANIM, 1.0)
    end
end
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and tab and DoesEntityExist(tab) then DeleteEntity(tab) end end)

local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.TabletAnim(false)
    G.send('tablet.close', {})
end

local function open()
    if isOpen or busy() or not G.begun then return end
    TriggerServerEvent('pb:g:biz:open')
end

RegisterNetEvent('pb:g:biz:open', function() open() end)   -- ouverture demandée par un point (bureau du patron / siège)

RegisterNetEvent('pb:g:biz:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then return end
        isOpen = true
        G.focus(true)
        CreateThread(function() G.TabletAnim(true) end)
    elseif not isOpen then return end
    G.send('tablet.' .. tostring(d.ev), d)
end)

RegisterNetEvent('pb:g:biz:job', function(j) G.job = G.decode(j) end)

G.nui['tablet.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:biz:page', tostring(d.page or 'home')) end return {} end
G.nui['tablet.act'] = function(d)
    if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:biz:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end
    return {}
end
G.nui['tablet.close'] = function() close() return {} end

-- Réparation demandée par le serveur (le mécanicien a le droit « repair » et est en service)
RegisterNetEvent('pb:g:biz:repair', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    if veh == 0 or not DoesEntityExist(veh) then G.send('notify', { type = 'error', text = 'Aucun véhicule à proximité.' }) return end
    SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    G.send('notify', { type = 'success', text = 'Véhicule réparé.' })
end)

RegisterCommand('pb_tablet', open, false)
RegisterCommand('tablette', open, false)

-- La tablette s'ouvre au siège / bureau de l'entreprise (point du Builder) ou par /tablette ; F6 ouvre le menu de l'entreprise (client/quick.lua).
-- Une touche n'est posée que si le serveur en a choisi une autre que F6.
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.biz and GetGameTimer() < t do Wait(250) end
    local k = G.cfg.biz and G.cfg.biz.tablet_key
    if type(k) == 'string' and k ~= '' and k:upper() ~= 'F6' and k:upper() ~= ((G.cfg.quick and G.cfg.quick.key) or 'F6'):upper() then RegisterKeyMapping('pb_tablet', 'Ouvrir la tablette', 'keyboard', k) end
end)

CreateThread(function()
    while true do
        Wait(500)
        if isOpen and busy() then close() end
    end
end)
G.onForceClose(function() close() end)
