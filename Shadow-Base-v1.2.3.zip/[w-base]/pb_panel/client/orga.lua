-- Tablette des organisations (au QG, ou /orga au QG) et menu F7 de l'organisation. Tout vient du serveur.
local G = PBG
local isOpen = false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end
local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    if G.TabletAnim then G.TabletAnim(false) end
    G.send('orga.close', {})
end
local function open()
    if isOpen or busy() or not G.begun then return end
    TriggerServerEvent('pb:g:orga:open')
end

RegisterNetEvent('pb:g:orga:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then return end
        isOpen = true
        G.focus(true)
        if G.TabletAnim then CreateThread(function() G.TabletAnim(true) end) end
    elseif not isOpen then return end
    G.send('orga.' .. tostring(d.ev), d)
end)
RegisterNetEvent('pb:g:orga:shut', function() if isOpen then close() end end)
RegisterNetEvent('pb:g:orga:gps', function(j)
    local d = G.decode(j)
    if d and tonumber(d.x) and tonumber(d.y) then SetNewWaypoint(d.x + 0.0, d.y + 0.0) end
end)
G.nui['orga.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:orga:page', tostring(d.page or 'home')) end return {} end
G.nui['orga.act'] = function(d)
    if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:orga:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end
    return {}
end
G.nui['orga.close'] = function() close() return {} end
RegisterCommand('pb_orga', open, false)
RegisterCommand('orga', open, false)
-- Menu de mon organisation (F7) : ligoter, escorter, fouiller, GPS du QG, coffre, caisse… La tablette, elle, s'ouvre au QG.
local gspec
local function gsend(id, payload) TriggerServerEvent('pb:g:gang:act', id, payload or {}) end
local function gangItems()
    local out = { { type = 'separator', label = tostring(gspec.gang) .. (gspec.grade ~= '' and (' · ' .. gspec.grade) or '') } }
    for _, e in ipairs(gspec.entries) do
        if e.type == 'separator' then out[#out + 1] = { type = 'separator', label = e.label }
        elseif e.type == 'info' then
            local list = {}
            for _, m in ipairs(e.items or {}) do list[#list + 1] = { label = m.label, right = m.right, disabled = true } end
            if #list == 0 then list[1] = { label = 'Personne', disabled = true } end
            out[#out + 1] = { type = 'submenu', label = e.label, icon = e.icon, right = e.right, submenu = { id = 'gang.' .. e.id, title = e.label, items = list } }
        elseif e.needs == 'target' then
            local list = {}
            for _, n in ipairs(gspec.near or {}) do if e.only ~= 'tied' or n.tied then list[#list + 1] = n end end
            out[#out + 1] = { type = 'submenu', label = e.label, icon = e.icon, description = e.desc, submenu = function()
                return G.PickMenu('gang.' .. e.id .. '.who', e.label, list, function(id) gsend(e.id, { id = id }) end, e.only == 'tied' and 'Personnes ligotées à côté de toi' or nil)
            end }
        else
            out[#out + 1] = { type = 'button', label = e.label, icon = e.icon, description = e.desc, disabled = e.disabled, onSelect = function()
                local p = {}
                for _, inp in ipairs(e.inputs or {}) do
                    local v = G.Menu.Ask(inp.label, '', inp.maxlen or 20)
                    if v == nil or v == '' then return end
                    p[inp.k] = inp.number and tonumber(v) or v
                end
                gsend(e.id, p)
            end }
        end
    end
    return out
end
local gdef = { id = 'gang', title = 'Organisation', refreshOnReturn = true, build = function() return gangItems() end }
RegisterNetEvent('pb:g:gang:ui', function(j)
    local d = G.decode(j)
    if not d or not d.spec then return end
    gspec = d.spec
    gdef.subtitle = gspec.boss and 'Chef' or 'Membre'
    gdef.banner = { text = tostring(gspec.gang) }
    local mine = G.Menu.IsOpen() and G.Menu.Stack.menus[1] and G.Menu.Stack.menus[1].def == gdef
    if d.ev == 'open' then G.Menu.Open(gdef) elseif mine then G.Menu.Refresh() end
end)
RegisterNetEvent('pb:g:gang:tablet', function() G.Menu.Close() TriggerServerEvent('pb:g:orga:open') end)
RegisterCommand('pb_gang', function()
    if not G.begun or G.creating or G.wardrobe or G.state.dead then return end
    if isOpen then close() return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    TriggerServerEvent('pb:g:gang:open')
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.tablets and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_gang', 'Menu de mon organisation', 'keyboard', (G.cfg.tablets and G.cfg.tablets.orga_key) or 'F7')
end)
CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
