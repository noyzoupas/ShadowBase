-- Blanchiment : contact (PNJ) à chaque point de blanchiment ; E ouvre son menu (mise, commission, durée, avancement).
local G = PBG

local function fmt(n) local s = tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') return s .. ' $' end
local points = {}
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local cr, l = c.crime or {}, c.launder or {}
    points = (cr.enabled == false or l.enabled == false) and {} or (cr.launder or {})
    local npcs = {}
    for _, s in ipairs(points) do npcs[#npcs + 1] = { id = s.id, model = tostring(l.ped or 'g_m_m_armboss_01'), x = s.x, y = s.y, z = s.z, h = s.h or 0.0, scenario = 'WORLD_HUMAN_SMOKING' } end
    G.Npcs('launder', npcs)
end

RegisterNetEvent('pb:g:wash:menu', function(j)
    local d = G.decode(j)
    if not d then return end
    local items = {}
    if d.job then
        local jb = d.job
        items[#items + 1] = { type = 'separator', label = 'Blanchiment en cours · ' .. jb.pct .. ' %' }
        items[#items + 1] = { label = 'Argent confié', right = fmt(jb.dirty), icon = 'coins', description = 'Commission du contact : ' .. jb.cut .. ' %.' }
        items[#items + 1] = { label = 'Déjà reçu (propre)', right = fmt(jb.paid) .. ' / ' .. fmt(jb.clean), icon = 'check', description = "L'argent propre arrive au fur et à mesure, même si tu pars." }
        items[#items + 1] = { label = 'Temps restant', right = jb.left > 3600 and (('%d h %02d'):format(math.floor(jb.left / 3600), math.floor((jb.left % 3600) / 60))) or (math.max(1, math.floor(jb.left / 60)) .. ' min'), icon = 'clock',
            description = 'Une notification te prévient à la fin. Les VIP voient l\'avancement de partout avec /blanchiment.' }
        items[#items + 1] = { label = 'Un seul blanchiment à la fois', disabled = true, icon = 'lock' }
    else
        items[#items + 1] = { type = 'separator', label = ('Argent sale sur toi : %s'):format(fmt(d.have)) }
        if #(d.offers or {}) == 0 then
            items[#items + 1] = { label = ('Il faut au moins %s d\'argent sale'):format(fmt(d.min)), disabled = true, icon = 'coins' }
        else
            local labels = {}
            for i, o in ipairs(d.offers) do labels[i] = fmt(o.amount) end
            local sel = 1
            local function desc(o) return ('Commission %d %% · tu récupères %s propres · durée %s. Plus la mise est grosse, plus la commission baisse.'):format(o.cut, fmt(o.clean), o.dur) end
            local mise = { type = 'list', label = 'Mise', icon = 'coins', list = labels, index = 1, description = desc(d.offers[1]) }
            mise.onChange = function(it, _, i) sel = i it.description = desc(d.offers[i]) G.Menu.Refresh() end
            items[#items + 1] = mise
            for _, o in ipairs(d.offers) do items[#items + 1] = { label = fmt(o.amount), right = o.cut .. ' % · ' .. o.dur, disabled = true } end
            items[#items + 1] = { type = 'button', label = 'Confier l\'argent au contact', icon = 'check', description = "L'argent sale part tout de suite ; l'argent propre revient petit à petit.", onSelect = function()
                local o = d.offers[sel]
                G.Menu.Close()
                TriggerServerEvent('pb:g:wash:start', d.id, o.amount)
            end }
        end
    end
    G.Menu.Open({ id = 'wash', title = tostring(d.label or 'Blanchiment'), subtitle = 'Le contact', items = items })
end)

CreateThread(function()
    local shown
    while true do
        local best, bd = nil, 1e9
        if #points > 0 and G.begun and not G.state.dead then
            local c = GetEntityCoords(PlayerPedId())
            for _, s in ipairs(points) do local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) if d < bd then best, bd = s, d end end
        end
        if best and bd <= 12.0 then
            G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
            if bd <= 2.5 and not G.Menu.IsOpen() and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt', { show = true, key = 'E', text = 'Parler au contact' }) end
                if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:wash:open', best.id) end
            elseif shown then shown = nil G.send('prompt', { show = false }) end
            Wait(0)
        else
            if shown then shown = nil G.send('prompt', { show = false }) end
            Wait(700)
        end
    end
end)
TriggerEvent('chat:addSuggestion', '/blanchiment', "Avancement de ton blanchiment (de partout pour les VIP)")
