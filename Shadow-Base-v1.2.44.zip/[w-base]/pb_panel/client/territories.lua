-- Territoires : invite E dans une zone, couleur de la zone sur la carte, ré-utilise la barre de progression des activités.
local G = PBG
local zones, owners, me, blips = {}, {}, nil, {}
local polys = {}   -- contours dessinés au Builder : { [id] = { {x, y}, … } }
local active = false
-- point dans un polygone (contour de la zone) ; sinon cercle
local function inPoly(x, y, poly)
    local inside, j = false, #poly
    for i = 1, #poly do
        local xi, yi, xj, yj = poly[i][1], poly[i][2], poly[j][1], poly[j][2]
        if ((yi > y) ~= (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1e-9) + xi) then inside = not inside end
        j = i
    end
    return inside
end
G.InPoly = inPoly
local function inZoneXY(z, x, y)
    local p = polys[z.id]
    if p and #p >= 3 then return inPoly(x, y, p) end
    local dx, dy = x - (z.x + 0.0), y - (z.y + 0.0)
    return math.sqrt(dx * dx + dy * dy) <= (tonumber(z.radius) or 30) + 0.0
end
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local t = c.territories or {}
    polys = type(t.polys) == 'table' and t.polys or {}
    zones = t.enabled == false and {} or (t.zones or {})
    G.terrBlips = t.show_blips ~= false
    G.redrawTerr()
end
-- Couleurs de blip du jeu (approximations RGB) : la carte du jeu ne sait afficher que cette palette, on prend la plus proche de la couleur du gang.
local PALETTE = {
    { 1, 224, 50, 50 }, { 2, 114, 204, 114 }, { 3, 93, 182, 229 }, { 5, 238, 198, 80 }, { 7, 156, 110, 175 }, { 8, 255, 123, 196 }, { 17, 234, 143, 53 },
    { 25, 59, 150, 60 }, { 29, 37, 102, 159 }, { 38, 36, 98, 165 }, { 40, 77, 77, 77 }, { 4, 240, 240, 240 }, { 39, 170, 170, 170 }, { 43, 140, 230, 200 }, { 46, 238, 220, 120 }, { 49, 155, 40, 40 }, { 54, 20, 120, 120 },
}
function G.blipColourFor(hex)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 4 end
    r, g, b = tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
    local best, bd = 4, 1e9
    for _, p in ipairs(PALETTE) do
        local d = (p[2] - r) ^ 2 + (p[3] - g) ^ 2 + (p[4] - b) ^ 2
        if d < bd then best, bd = p[1], d end
    end
    return best
end
function G.redrawTerr()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not G.terrBlips then return end
    if not me or me == '' then return end   -- territoires visibles seulement par les membres d'un groupe illégal
    for _, z in ipairs(zones) do
        local o = owners[z.id]
        local colour = o and G.blipColourFor(o.color) or 4
        local b = AddBlipForRadius(z.x + 0.0, z.y + 0.0, z.z + 0.0, (tonumber(z.radius) or 30) + 0.0)
        SetBlipColour(b, colour) SetBlipAlpha(b, o and 110 or 40)
        blips[#blips + 1] = b
        -- petit repère au centre avec le nom de la zone et du gang qui la tient (visible sur la carte du jeu)
        local c = AddBlipForCoord(z.x + 0.0, z.y + 0.0, z.z + 0.0)
        SetBlipSprite(c, 84) SetBlipColour(c, colour) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(z.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
        blips[#blips + 1] = c
    end
end
RegisterNetEvent('pb:g:terr:owners', function(j) local d = G.decode(j) if d then owners = d.owners or {} me = d.me G.redrawTerr() end end)
RegisterNetEvent('pb:g:terr:wait', function() active = true end)
-- fin de la barre : on confirme au serveur (la barre elle-même est celle des activités)
RegisterNetEvent('pb:g:crime:go', function(j)
    local d = G.decode(j)
    if not active or not d then return end
    CreateThread(function()
        local secs = tonumber(d.time) or 30
        local t0, ok = GetGameTimer(), true
        while GetGameTimer() - t0 < secs * 1000 do
            Wait(200)
            local p = PlayerPedId()
            local pc = GetEntityCoords(p)
            local z = nil
            for _, x in ipairs(zones) do if 'Capture : ' .. tostring(x.label) == tostring(d.label) then z = x end end
            local out = z and polys[z.id] and not inPoly(pc.x, pc.y, polys[z.id]) or (not (z and polys[z.id]) and #(pc - vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)) > (tonumber(d.radius) or 30) + 3.0)
            if IsEntityDead(p) or out then ok = false break end
        end
        active = false
        TriggerServerEvent('pb:g:terr:end', ok)
    end)
end)
-- cercle très fin autour de chaque zone proche (couleur du gang qui la tient, gris si libre)
CreateThread(function()
    while true do
        if not G.begun or #zones == 0 then Wait(1000) else
            local c = GetEntityCoords(PlayerPedId())
            local any = false
            for _, z in ipairs(zones) do
                local zx, zy, zz = z.x + 0.0, z.y + 0.0, z.z + 0.0
                local rr = (tonumber(z.radius) or 30) + 0.0
                if #(c - vector3(zx, zy, zz)) < rr + 120.0 then
                    any = true
                    local o = owners[z.id]
                    local r, g, b = 200, 204, 212
                    local hex = o and (o.color or '')
                    if type(hex) == 'string' then local rr2, gg, bb = hex:match('^#(%x%x)(%x%x)(%x%x)$') if rr2 then r, g, b = tonumber(rr2, 16), tonumber(gg, 16), tonumber(bb, 16) end end
                    local p = polys[z.id]
                    if p and #p >= 3 then
                        -- contour dessiné : un trait au sol entre chaque coin (hauteur du sol calculée une fois par coin)
                        p.gz = p.gz or {}
                        for i = 1, #p do
                            local a, bb = p[i], p[i % #p + 1]
                            if not p.gz[i] then p.gz[i] = G.Ground(a[1] + 0.0, a[2] + 0.0, c.z) + 0.15 end
                            local j = i % #p + 1
                            if not p.gz[j] then p.gz[j] = G.Ground(bb[1] + 0.0, bb[2] + 0.0, c.z) + 0.15 end
                            DrawLine(a[1] + 0.0, a[2] + 0.0, p.gz[i], bb[1] + 0.0, bb[2] + 0.0, p.gz[j], r, g, b, 200)
                            DrawLine(a[1] + 0.0, a[2] + 0.0, p.gz[i] + 1.2, bb[1] + 0.0, bb[2] + 0.0, p.gz[j] + 1.2, r, g, b, 90)
                        end
                    else
                        G.Zone(zx, zy, zz - 0.95, r, g, b, rr)
                    end
                end
            end
            Wait(any and 0 or 500)
        end
    end
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #zones == 0 or not me or active or G.Menu.IsOpen() then hide() Wait(700)
        else
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if inZoneXY(z, c.x, c.y) then hit = z break end end
            local o = hit and owners[hit.id]
            if hit and (not o or o.gang ~= me) then
                if shown ~= hit.id then shown = hit.id G.send('prompt', { show = true, key = 'E', text = 'Prendre : ' .. hit.label }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:terr:start', hit.id) end
                Wait(0)
            else hide() Wait(400) end
        end
    end
end)

-- Entrée dans un territoire : carte « Vous entrez en territoire / Sous le contrôle de … » au-dessus de la mini-carte (une fois par entrée)
CreateThread(function()
    local inside
    while true do
        Wait(700)
        if G.begun and #zones > 0 then
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if inZoneXY(z, c.x, c.y) then hit = z break end end
            local id = hit and hit.id or nil
            if id ~= inside then
                inside = id
                if hit then
                    local o = owners[hit.id]
                    G.send('zone.enter', { zone = hit.label, gang = o and o.label or nil, color = o and o.color or nil })
                end
            end
        else Wait(1000) end
    end
end)

RegisterNetEvent('pb:g:zone:banner', function(j) local d = G.decode(j) if d then G.send('zone.banner', d) end end)

-- Builder › Créer › Territoire de gang : on marche jusqu'à chaque coin et on appuie sur Entrée ; la zone se dessine au fur et à mesure.
-- Retour arrière : retirer le dernier coin · E : terminer (3 coins minimum) · X : annuler. Ensuite : nom et objet offert toutes les 5 h.
local drawing = false
function G.TerrDraw(send, rewards)
    if drawing then return end
    drawing = true
    G.Menu.Suspend()
    local pts = {}
    local function help()
        G.send('prompt', { show = true, free = true, key = '↵', text = ('Coin %d : Entrée pour l\'ajouter ici  ·  Retour arrière : retirer  ·  E : terminer (3 coins min.)  ·  X : annuler'):format(#pts + 1) })
    end
    help()
    CreateThread(function()
        local finished = false
        while drawing do
            Wait(0)
            DisableControlAction(0, 200, true) DisableControlAction(0, 199, true)
            local c = GetEntityCoords(PlayerPedId())
            -- traits déjà posés, puis le trait vers le joueur (et le retour au premier coin)
            for i = 1, #pts - 1 do DrawLine(pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z, 255, 255, 255, 230) end
            for _, q in ipairs(pts) do DrawMarker(28, q.x, q.y, q.z, 0, 0, 0, 0, 0, 0, 0.35, 0.35, 0.35, 255, 255, 255, 200, false, false, 2, false, nil, nil, false) end
            local gz = c.z - 0.9
            if #pts > 0 then
                local l = pts[#pts]
                DrawLine(l.x, l.y, l.z, c.x, c.y, gz, 255, 255, 255, 140)
                if #pts >= 2 then DrawLine(c.x, c.y, gz, pts[1].x, pts[1].y, pts[1].z, 255, 255, 255, 70) end
            end
            if IsDisabledControlJustPressed(0, 191) or IsControlJustPressed(0, 191) then
                pts[#pts + 1] = { x = c.x, y = c.y, z = gz }
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if #pts >= 40 then finished = true drawing = false end
                help()
            elseif IsDisabledControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                if #pts > 0 then table.remove(pts) help() end
            elseif IsControlJustPressed(0, 38) then
                if #pts >= 3 then finished = true drawing = false
                else G.send('notify', { type = 'warn', title = 'Territoire', text = 'Pose au moins 3 coins.' }) end
            elseif IsControlJustPressed(0, 73) then
                drawing = false
            end
        end
        G.send('prompt', { show = false })
        if not finished then G.Menu.Resume() return end
        -- fin du tracé : nom de la zone et objet offert au groupe qui la tient (toutes les 5 h)
        local st = { name = '', item = 1 }
        local list, keys = { 'Aucun objet' }, { '' }
        for _, r in ipairs(rewards or {}) do list[#list + 1] = r[2] keys[#keys + 1] = r[1] end
        G.Menu.Resume()
        G.Menu.Open({ id = 'b.terr.new', title = 'Nouveau territoire', subtitle = #pts .. ' coins', items = {
            { type = 'input', label = 'Nom de la zone', icon = 'pen', prompt = 'Nom de la zone (ex. Grove Street)', maxlen = 40, onChange = function(_, v) st.name = tostring(v or '') end },
            { type = 'list', label = 'Objet offert toutes les 5 h', icon = 'box', list = list, index = 1, description = "Déposé dans le coffre du groupe qui tient la zone.", onChange = function(_, _, i) st.item = i end },
            { type = 'button', label = 'Créer la zone', icon = 'check', onSelect = function()
                if #st.name < 2 then G.send('notify', { type = 'warn', title = 'Territoire', text = 'Donne un nom à la zone.' }) return end
                local poly = {}
                for _, q in ipairs(pts) do poly[#poly + 1] = { x = q.x, y = q.y, z = q.z } end
                G.Menu.Close()
                send('b_terr', { label = st.name, poly = poly, item = keys[st.item] or '' })
            end },
            { type = 'button', label = 'Annuler', icon = 'x', onSelect = function() G.Menu.Close() end },
        } })
    end)
end
