-- Menu personnel (F5) : cartes (interface) ou menu RageUI, au choix du serveur et, si permis, du joueur (mémorisé sur son poste).
local G = PBG
local data, isOpen = nil, false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end
local function pref()
    local c = G.cfg.personal or {}
    local m = c.mode == 'lib' and 'lib' or 'cards'
    if c.allow_choice ~= false then
        local v = GetResourceKvpString('pb_me_mode')
        if v == 'lib' or v == 'cards' then m = v end
    end
    return m
end

local function closeCards()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.send('me.close', {})
end

local function run(e)
    if type(e) ~= 'table' or e.disabled then return end
    local cmd = e.cmd
    if type(cmd) ~= 'string' or not cmd:match('^[%w_:%-]+$') then return end
    if G.Menu.IsOpen() then G.Menu.Close() end
    closeCards()
    Wait(50)
    ExecuteCommand(cmd)
end

local function findEntry(id, cmd)
    for _, e in ipairs(data and data.entries or {}) do
        if e.id == id and (id ~= 'cmd' or e.cmd == cmd) then return e end
    end
end

-- Taille du HUD (réglage personnel) : 80 % à 160 %, mémorisée sur le poste du joueur
local SIZES = { 80, 90, 100, 110, 120, 130, 140, 150, 160 }
local function hudSize() local v = tonumber(GetResourceKvpString('pb_hud_ps') or '') return (v and v >= 70 and v <= 170) and v or 100 end
local function setHudSize(v)
    v = math.max(70, math.min(170, math.floor(tonumber(v) or 100)))
    SetResourceKvp('pb_hud_ps', tostring(v))
    G.send('hud.pscale', { v = v / 100 })
end
G.HudSize = hudSize
CreateThread(function()
    local t = GetGameTimer() + 20000
    while not G.cfg.hud and GetGameTimer() < t do Wait(500) end
    G.send('hud.pscale', { v = hudSize() / 100 })
end)
G.nui['me.hudsize'] = function(d) setHudSize(d.v) return { v = hudSize() } end
-- sons des menus (clic du serveur dans la lib et les interfaces) : coupables par chaque joueur
local function setMenuSound(on)
    SetResourceKvp('pb_menu_snd', on and 'on' or 'off')
    G.send('ui.sound', { on = on })
end
CreateThread(function() Wait(3000) G.send('ui.sound', { on = GetResourceKvpString('pb_menu_snd') ~= 'off' }) end)
G.nui['me.sound'] = function(d) setMenuSound(d.on ~= false) return { on = d.on ~= false } end

local libDef
local function libMenu()
    local items = { { type = 'separator', label = data.name } }
    local nCmd = 0
    for _, e in ipairs(data.entries) do
        local desc = (e.desc or '') .. ((e.sub and e.sub ~= '') and ('\n' .. e.sub) or '')
        if e.id == 'cmd' then nCmd = nCmd + 1 end
        local it = { id = e.id == 'cmd' and ('cmd' .. nCmd) or e.id, type = 'button', label = e.label, icon = e.icon, right = e.value, badge = e.badge, description = desc, disabled = e.disabled }
        if e.list then
            local sub = {}
            for _, x in ipairs(e.list) do
                if x.veh then   -- véhicule : fiche (emplacement, poids, coffre en lecture seule)
                    sub[#sub + 1] = { type = 'submenu', label = x.label, right = x.kind, badge = x.state, description = x.where, submenu = { id = 'me.veh.' .. x.veh, title = x.label, subtitle = x.veh, items = {
                        { type = 'button', label = 'Voir le coffre', icon = 'box', right = 'Lecture seule', description = "Ouvre l'inventaire : ton sac et le coffre du véhicule. Tu regardes seulement, rien ne peut être pris.",
                            onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:me:trunk', x.veh) end },
                        { type = 'button', label = 'Mettre le GPS', icon = 'pin', right = x.state, description = x.where, onSelect = function() TriggerServerEvent('pb:g:me:gps', x.gps) end },
                    } } }
                else
                    sub[#sub + 1] = { type = 'button', label = x.label, right = x.plate or x.kind, badge = x.state, description = x.gps and 'Entrée : mettre le GPS.' or x.cmd and 'Entrée : ouvrir.' or nil, onSelect = x.gps and function() TriggerServerEvent('pb:g:me:gps', x.gps) end or x.cmd and function() run({ cmd = x.cmd }) end or nil }
                end
            end
            if #sub == 0 then sub[1] = { type = 'button', label = 'Rien à afficher', disabled = true } end
            it.type, it.submenu = 'submenu', { id = 'me.' .. e.id, title = e.label, subtitle = 'Information', items = sub }
        elseif e.id == 'settings' then
            local cur = pref()
            local list, idx = {}, 3
            for i, s in ipairs(SIZES) do list[i] = s .. ' %' if s == hudSize() then idx = i end end
            local size = { type = 'list', label = 'Taille du HUD', icon = 'sliders', list = list, index = idx, description = "Grossit ou réduit le HUD (argent, besoins, compteur, heure…). ← → pour changer, réglage mémorisé sur ton poste.",
                onChange = function(_, _, i) setHudSize(SIZES[i]) end }
            local snd = { type = 'checkbox', label = 'Sons des menus', icon = 'music', checked = GetResourceKvpString('pb_menu_snd') ~= 'off',
                description = "Le petit clic quand tu navigues dans les menus et les interfaces. Décoche pour le couper (réglage mémorisé sur ton poste).",
                onChange = function(_, v) setMenuSound(v) end }
            -- (v1.2.43) noms et badges au-dessus des têtes (visibles par le staff) : le réglage vit ici, plus dans le menu staff
            local tags = { type = 'checkbox', label = 'Noms au-dessus des têtes', icon = 'users', checked = GetResourceKvpString('pb_tags_off') ~= 'on',
                description = "Les étiquettes affichées au-dessus des joueurs (nom, ID, grade staff). Décoche pour les masquer sur ton écran.",
                onChange = function(_, v) SetResourceKvp('pb_tags_off', v and 'off' or 'on') G.tagsOff = not v end }
            it.type, it.submenu = 'submenu', { id = 'me.settings', title = 'Mes paramètres', subtitle = "Affichage et sons", items = { size, snd, tags, { type = 'separator', label = 'Menu F5' },
                { type = 'button', label = 'Grandes cartes', right = cur == 'cards' and 'Actif' or nil, description = "Interface avec images (souris).", onSelect = function() SetResourceKvp('pb_me_mode', 'cards') G.Menu.Close() isOpen = true G.focus(true) G.send('me.open', { data = data, mode = 'cards', brand = G.cfg.brand, hudsize = hudSize() }) end },
                { type = 'button', label = 'Menu RageUI', right = cur == 'lib' and 'Actif' or nil, description = 'Flèches + Entrée.', onSelect = function() SetResourceKvp('pb_me_mode', 'lib') G.Menu.Close() G.Menu.Open(libDef()) end } } }
            if data.allow_choice == false then for k = 5, #it.submenu.items do it.submenu.items[k].disabled = true end end
        else
            it.onSelect = function() run(e) end
        end
        items[#items + 1] = it
    end
    return items
end
function libDef()
    local d = { id = 'me', title = data.title, subtitle = data.subtitle, refreshOnReturn = true }
    d.build = function()
        local items = G.Menu.Sorted('me', libMenu(), data.order)
        return items
    end
    return d
end

local function show()
    if pref() == 'lib' then G.Menu.Open(libDef())
    else
        isOpen = true
        G.focus(true)
        G.send('me.open', { data = data, mode = 'cards', brand = G.cfg.brand, hudsize = hudSize() })
    end
end

RegisterNetEvent('pb:g:me:ui', function(j)
    local d = G.decode(j)
    if not d or d.ev ~= 'open' or type(d.data) ~= 'table' then return end
    if isOpen or busy() then return end
    data = d.data
    show()
end)

G.nui['me.act'] = function(d)
    if not isOpen or type(d.id) ~= 'string' then return {} end
    run(findEntry(d.id, d.cmd))
    return {}
end
-- raccourci d'une ligne de liste (ex. « Animal de compagnie » dans Mon VIP) : seulement une commande envoyée par le serveur
G.nui['me.cmd'] = function(d)
    if not isOpen or type(d.cmd) ~= 'string' then return {} end
    for _, e in ipairs(data and data.entries or {}) do
        for _, x in ipairs(e.list or {}) do if x.cmd == d.cmd then run({ cmd = x.cmd }) return {} end end
    end
    return {}
end
G.nui['me.mode'] = function(d)
    if not isOpen or (data and data.allow_choice == false) then return {} end
    if d.mode == 'lib' or d.mode == 'cards' then
        SetResourceKvp('pb_me_mode', d.mode)
        if d.mode == 'lib' then closeCards() G.Menu.Open(libDef()) end
    end
    return {}
end
G.nui['me.close'] = function() closeCards() return {} end
-- F5 › Mes véhicules : coffre en lecture seule dans l'inventaire (le menu F5 se ferme d'abord)
G.nui['me.trunk'] = function(d)
    if isOpen and type(d.plate) == 'string' and #d.plate <= 12 then closeCards() TriggerServerEvent('pb:g:me:trunk', d.plate) end
    return {}
end
G.nui['me.gps'] = function(d)
    if isOpen and type(d.ref) == 'string' and #d.ref <= 48 then TriggerServerEvent('pb:g:me:gps', d.ref) end
    return {}
end
RegisterNetEvent('pb:g:me:gps', function(j)
    local d = G.decode(j)
    if not d or not tonumber(d.x) then return end
    SetNewWaypoint(tonumber(d.x) + 0.0, tonumber(d.y) + 0.0)
end)

RegisterCommand('pb_me', function()
    if not G.begun or busy() then return end
    if isOpen then closeCards() return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    TriggerServerEvent('pb:g:me:open')
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.personal and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_me', 'Menu personnel', 'keyboard', (G.cfg.personal and G.cfg.personal.key) or 'F5')
end)
CreateThread(function() while true do Wait(500) if isOpen and busy() then closeCards() end end end)
G.onForceClose(function() closeCards() end)
