-- Laboratoire de drogue : la transformation n'est plus une simple attente. Trois étapes jouées au clavier :
-- 1. Dosage : appuie sur E quand le curseur passe dans la zone blanche (3 fois) ;
-- 2. Cuisson : garde l'aiguille dans la bonne température avec Q / D (ou ← →) ;
-- 3. Conditionnement : tape la suite de flèches affichée.
-- La qualité (0 à 1) part au serveur, qui décide de la quantité produite (ratée, normale ou meilleure) et revérifie tout.
local G = PBG

local function txt(s, x, y, scale, center, a)
    SetTextFont(4) SetTextScale(0.0, scale or 0.4) SetTextColour(255, 255, 255, a or 235) SetTextOutline()
    if center then SetTextCentre(true) end
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(s) EndTextCommandDisplayText(x, y)
end
local function panel(title, step, help)
    DrawRect(0.5, 0.78, 0.32, 0.17, 10, 10, 12, 205)
    DrawRect(0.5, 0.6955, 0.32, 0.003, 255, 255, 255, 120)
    txt(title, 0.345, 0.70, 0.42)
    txt(('Étape %d / 3'):format(step), 0.655, 0.70, 0.34, false, 160)
    SetTextRightJustify(false)
    txt(help, 0.5, 0.835, 0.32, true, 170)
end
local function block() DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 44, true) DisableControlAction(0, 140, true) end

-- 1. Dosage : 3 essais, chacun vaut 1 s'il tombe dans la zone, 0,5 près du bord, 0 sinon
local function dosing()
    local score, tries = 0, 0
    local pos, dir, speed = 0.0, 1, 0.9
    local zone = math.random() * 0.6 + 0.2
    local last = GetGameTimer()
    while tries < 3 do
        Wait(0) block()
        local now = GetGameTimer()
        pos = pos + dir * speed * (now - last) / 1000
        last = now
        if pos > 1 then pos, dir = 1, -1 elseif pos < 0 then pos, dir = 0, 1 end
        panel('Dosage des produits', 1, ('E : verser quand le curseur est dans la zone blanche  (%d / 3)'):format(tries))
        local x0, w = 0.37, 0.26
        DrawRect(x0 + w / 2, 0.775, w, 0.018, 255, 255, 255, 40)
        DrawRect(x0 + zone * w, 0.775, w * 0.12, 0.018, 255, 255, 255, 170)
        DrawRect(x0 + pos * w, 0.775, 0.003, 0.034, 255, 214, 80, 255)
        if IsControlJustPressed(0, 38) then
            local d = math.abs(pos - zone)
            score = score + (d < 0.06 and 1 or (d < 0.11 and 0.5 or 0))
            tries = tries + 1
            PlaySoundFrontend(-1, d < 0.06 and 'SELECT' or 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
            zone = math.random() * 0.6 + 0.2
            speed = speed + 0.25
        end
    end
    return score / 3
end

-- 2. Cuisson : la température dérive ; Q / D (← →) pour la ramener ; score = part du temps passé dans la bonne plage
local function cooking(secs)
    local temp, drift, inside, total = 0.5, 0, 0, 0
    local stop = GetGameTimer() + secs * 1000
    local last = GetGameTimer()
    while GetGameTimer() < stop do
        Wait(0) block()
        local now = GetGameTimer()
        local dt = (now - last) / 1000
        last = now
        if math.random() < 0.03 then drift = (math.random() - 0.5) * 0.9 end
        temp = temp + drift * dt
        if IsControlPressed(0, 34) or IsControlPressed(0, 174) then temp = temp - 0.55 * dt end
        if IsControlPressed(0, 35) or IsControlPressed(0, 175) then temp = temp + 0.55 * dt end
        temp = math.max(0, math.min(1, temp))
        total = total + dt
        local ok = temp > 0.4 and temp < 0.6
        if ok then inside = inside + dt end
        panel('Cuisson', 2, ('Q / D (ou ← →) : garde l\'aiguille dans la zone  ·  %d s'):format(math.ceil((stop - now) / 1000)))
        local x0, w = 0.37, 0.26
        DrawRect(x0 + w / 2, 0.775, w, 0.018, 255, 255, 255, 40)
        DrawRect(x0 + 0.5 * w, 0.775, w * 0.2, 0.018, 120, 220, 140, 150)
        DrawRect(x0 + temp * w, 0.775, 0.003, 0.034, ok and 255 or 255, ok and 255 or 90, ok and 255 or 90, 255)
    end
    return total > 0 and inside / total or 0
end

-- 3. Conditionnement : suite de 5 flèches ; une erreur coûte des points
local ARROWS = { { 172, '↑' }, { 173, '↓' }, { 174, '←' }, { 175, '→' } }
local function packing()
    local seq = {}
    for i = 1, 5 do seq[i] = ARROWS[math.random(1, 4)] end
    local i, errors = 1, 0
    local stop = GetGameTimer() + 12000
    while i <= #seq and GetGameTimer() < stop do
        Wait(0) block()
        for k = 172, 175 do DisableControlAction(0, k, true) end
        local shown = {}
        for k, a in ipairs(seq) do shown[#shown + 1] = (k < i and '~c~' or (k == i and '~y~' or '~s~')) .. a[2] end
        panel('Mise en sachets', 3, 'Tape la suite de flèches')
        txt(table.concat(shown, '   '), 0.5, 0.757, 0.7, true)
        for _, a in ipairs(ARROWS) do
            if IsDisabledControlJustPressed(0, a[1]) then
                if a[1] == seq[i][1] then i = i + 1 PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                else errors = errors + 1 PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
            end
        end
    end
    local done = (i - 1) / #seq
    return math.max(0, done - errors * 0.15)
end

-- Joue les 3 étapes (au moins `secs` secondes au total) ; renvoie la qualité de 0 à 1 et si le joueur est resté sur place
function G.LabGame(secs, at, radius)
    local ped = PlayerPedId()
    TaskStartScenarioInPlace(ped, 'PROP_HUMAN_BBQ', 0, true)
    local t0 = GetGameTimer()
    local q1 = dosing()
    local q2 = cooking(math.max(8, math.min(30, (secs or 20) * 0.5)))
    local q3 = packing()
    local rest = (secs or 20) * 1000 - (GetGameTimer() - t0)
    if rest > 0 then
        local stop = GetGameTimer() + rest
        while GetGameTimer() < stop do Wait(0) panel('Séchage', 3, ('Encore %d s…'):format(math.ceil((stop - GetGameTimer()) / 1000))) end
    end
    ClearPedTasks(ped)
    local here = not at or #(GetEntityCoords(PlayerPedId()) - at) <= (radius or 6.0)
    return math.max(0, math.min(1, q1 * 0.3 + q2 * 0.4 + q3 * 0.3)), here and not IsEntityDead(PlayerPedId())
end
