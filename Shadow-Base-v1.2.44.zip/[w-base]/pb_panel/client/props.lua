-- Props permanents : fait apparaître (localement) les objets posés par le staff à moins de 150 m, et le mode de pose du menu F10.
-- Le serveur garde la liste et revérifie chaque pose ; ici on ne fait que dessiner et proposer.
local G = PBG
local list, spawned = {}, {}   -- id -> entité

local function remove(id) local e = spawned[id] if e and DoesEntityExist(e) then DeleteEntity(e) end spawned[id] = nil end
RegisterNetEvent('pb:g:props:all', function(j)
    local l = G.decode(j) or {}
    local keep = {}
    for _, p in ipairs(l) do keep[p.id] = p end
    for id in pairs(spawned) do
        local o, n = list[id], keep[id]
        if not n or not o or o.m ~= n.m or o.x ~= n.x or o.y ~= n.y or o.z ~= n.z or o.h ~= n.h then remove(id) end
    end
    list = keep
end)

CreateThread(function()
    while true do
        Wait(1500)
        local me = GetEntityCoords(PlayerPedId())
        for id, p in pairs(list) do
            local near = #(me - vector3(p.x, p.y, p.z)) < 150.0
            if near and not (spawned[id] and DoesEntityExist(spawned[id])) then
                local h = joaat(p.m)
                if IsModelInCdimage(h) then
                    RequestModel(h)
                    local t = GetGameTimer() + 3000
                    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
                    if HasModelLoaded(h) and list[id] == p then
                        local e = CreateObjectNoOffset(h, p.x, p.y, p.z, false, false, false)
                        SetEntityRotation(e, p.p or 0.0, p.r or 0.0, p.h or 0.0, 2, true)
                        FreezeEntityPosition(e, true)
                        SetEntityCollision(e, p.c ~= 0, p.c ~= 0)
                        SetEntityInvincible(e, true)
                        SetModelAsNoLongerNeeded(h)
                        spawned[id] = e
                    end
                else spawned[id] = 0 end   -- modèle absent sur cette version du jeu : on n'insiste pas
            elseif not near and spawned[id] then remove(id) end
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then for id in pairs(spawned) do remove(id) end end end)

-- Mode de pose : aperçu transparent là où vise la caméra ; ← → tourner, ↑ ↓ hauteur, E poser, Retour arrière annuler
local placing = false
local function rotToDir(r) local x, z = math.rad(r.x), math.rad(r.z) return vector3(-math.sin(z) * math.abs(math.cos(x)), math.cos(z) * math.abs(math.cos(x)), math.sin(x)) end
local function aimPoint(ignore)
    local from = GetGameplayCamCoord()
    local to = from + rotToDir(GetGameplayCamRot(2)) * 25.0
    local ray = StartShapeTestRay(from.x, from.y, from.z, to.x, to.y, to.z, 1 + 16, ignore or PlayerPedId(), 0)
    local _, hit, pos = GetShapeTestResult(ray)
    if hit == 1 then return pos end
    return to
end
function G.PropPlace(model, label)
    if placing then return end
    if G.PropPreviewStop then G.PropPreviewStop() end   -- (v1.2.43) l'aperçu est défini plus bas : l'appel direct plantait et empêchait toute pose
    local h = joaat(model)
    if not IsModelInCdimage(h) then G.send('notify', { type = 'error', title = 'Props', text = ('Modèle « %s » introuvable dans le jeu.'):format(model) }) return end
    placing = true
    if G.Menu.Suspend then G.Menu.Suspend() end
    CreateThread(function()
        RequestModel(h)
        local t = GetGameTimer() + 4000
        while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
        if not HasModelLoaded(h) then placing = false if G.Menu.Resume then G.Menu.Resume() end return end
        local ped = PlayerPedId()
        local c = GetEntityCoords(ped)
        local e = CreateObjectNoOffset(h, c.x, c.y, c.z, false, false, false)
        SetModelAsNoLongerNeeded(h)
        SetEntityAlpha(e, 160, false)
        SetEntityCollision(e, false, false)
        FreezeEntityPosition(e, true)
        local heading, lift = GetEntityHeading(ped), 0.0
        G.send('prompt', { show = true, free = true, key = 'E', text = ('Poser « %s »  ·  ← → tourner  ·  ↑ ↓ hauteur  ·  Retour arrière : annuler'):format(label or model) })
        local done = false
        while not done do
            Wait(0)
            DisableControlAction(0, 172, true) DisableControlAction(0, 173, true) DisableControlAction(0, 174, true) DisableControlAction(0, 175, true)
            DisableControlAction(0, 200, true) DisableControlAction(0, 24, true) DisableControlAction(0, 25, true)
            if IsDisabledControlPressed(0, 174) then heading = heading + 1.5 end
            if IsDisabledControlPressed(0, 175) then heading = heading - 1.5 end
            if IsDisabledControlPressed(0, 172) then lift = math.min(5.0, lift + 0.01) end
            if IsDisabledControlPressed(0, 173) then lift = math.max(-2.0, lift - 0.01) end
            local p = aimPoint(e)
            SetEntityCoordsNoOffset(e, p.x, p.y, p.z + lift, false, false, false)
            SetEntityHeading(e, heading % 360.0)
            SetEntityDrawOutline(e, true)
            SetEntityDrawOutlineColor(255, 255, 255, 255)
            if IsControlJustPressed(0, 38) then
                local pos = GetEntityCoords(e)
                TriggerServerEvent('pb:g:props:place', { model = model, label = label or '', x = pos.x, y = pos.y, z = pos.z, h = heading % 360.0 })
                done = true
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then done = true end
        end
        SetEntityDrawOutline(e, false)
        DeleteEntity(e)
        G.send('prompt', { show = false })
        placing = false
        if G.Menu.Resume then G.Menu.Resume() end
    end)
end

-- Catalogue intégré, trié par thème (les modèles ajoutés dans le panel arrivent dans « Ajoutés par le serveur »)
local CATALOG = {
    { 'Barrières et signalisation', 'shield', {
        { 'prop_barrier_work05', 'Barrière de chantier' }, { 'prop_barrier_work06a', 'Barrière de chantier (longue)' }, { 'prop_mp_barrier_02b', 'Barrière de police' },
        { 'prop_mp_barrier_01', 'Barrière de sécurité' }, { 'prop_barier_conc_05a', 'Muret béton' }, { 'prop_mp_arrow_barrier_01', 'Panneau flèche' },
        { 'prop_roadcone02a', 'Cône' }, { 'prop_mp_cone_02', 'Cône (grand)' }, { 'prop_consign_01a', 'Panneau travaux' } } },
    { 'Mobilier', 'home', {
        { 'prop_table_03', 'Table' }, { 'prop_chair_01a', 'Chaise' }, { 'prop_bench_01a', 'Banc' }, { 'prop_off_chair_01', 'Chaise de bureau' },
        { 'prop_couch_01', 'Canapé' }, { 'prop_patio_lounger1', 'Transat' }, { 'prop_table_para_comb_04', 'Table avec parasol' }, { 'prop_parasol_04b', 'Parasol' } } },
    { 'Événements', 'star', {
        { 'prop_tent_01', 'Tente' }, { 'prop_gazebo_02', 'Barnum' }, { 'prop_bbq_1', 'Barbecue' }, { 'prop_beach_fire', 'Feu de camp' },
        { 'prop_speaker_06', 'Enceinte' }, { 'prop_flag_france', 'Drapeau France' }, { 'prop_flag_us', 'Drapeau USA' }, { 'prop_portaloo_01a', 'Toilettes mobiles' } } },
    { 'Éclairage et énergie', 'bolt', {
        { 'prop_worklight_03b', 'Projecteur' }, { 'prop_worklight_04b', 'Projecteur sur pied' }, { 'prop_streetlight_01', 'Lampadaire' }, { 'prop_generator_03b', 'Groupe électrogène' } } },
    { 'Chantier et stockage', 'box', {
        { 'prop_boxpile_07d', 'Pile de cartons' }, { 'prop_pallet_02a', 'Palette' }, { 'prop_cementbags01', 'Sacs de ciment' }, { 'prop_toolchest_05', 'Servante à outils' },
        { 'prop_container_01a', 'Conteneur' }, { 'prop_dumpster_01a', 'Benne' }, { 'prop_portacabin01', 'Algeco' } } },
    { 'Divers', 'tag', {
        { 'prop_fire_exting_1a', 'Extincteur' }, { 'prop_bin_05a', 'Poubelle' }, { 'prop_atm_01', 'Distributeur (décor)' }, { 'prop_vend_soda_01', 'Distributeur de boissons' },
        { 'prop_vend_snak_01', 'Distributeur de snacks' }, { 'prop_pot_plant_01a', 'Plante en pot' } } },
}

-- Aperçu au survol : un fantôme du modèle tourne devant toi tant que la liste est ouverte
local pv = { model = nil, ent = nil, run = false }
local function previewStop()
    pv.model = nil
    if pv.ent and DoesEntityExist(pv.ent) then DeleteEntity(pv.ent) end
    pv.ent = nil
end
local function previewSet(model)
    if pv.model == model then return end
    previewStop()
    if not model then return end
    local h = joaat(model)
    if not IsModelInCdimage(h) then return end
    pv.model = model
    if pv.run then return end
    pv.run = true
    CreateThread(function()
        local spin, cur = 0.0, nil
        while pv.model and G.Menu.IsOpen() and not placing do
            if cur ~= pv.model then
                cur = pv.model
                if pv.ent and DoesEntityExist(pv.ent) then DeleteEntity(pv.ent) end
                pv.ent = nil
                local h = joaat(cur)
                RequestModel(h)
                local t = GetGameTimer() + 3000
                while not HasModelLoaded(h) and GetGameTimer() < t and pv.model == cur do Wait(10) end
                if HasModelLoaded(h) and pv.model == cur then
                    local c = GetEntityCoords(PlayerPedId())
                    pv.ent = CreateObjectNoOffset(h, c.x, c.y, c.z - 50.0, false, false, false)
                    SetEntityAlpha(pv.ent, 190, false)
                    SetEntityCollision(pv.ent, false, false)
                    FreezeEntityPosition(pv.ent, true)
                    SetModelAsNoLongerNeeded(h)
                end
            end
            local e = pv.ent
            if e and DoesEntityExist(e) then
                local mn, mx = GetModelDimensions(GetEntityModel(e))
                local size = math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z)
                local ped = PlayerPedId()
                local dist = math.min(14.0, 1.6 + size * 1.1)
                local p = GetOffsetFromEntityInWorldCoords(ped, 0.0, dist, 0.0)
                local ok, gz = GetGroundZFor_3dCoord(p.x, p.y, p.z + 2.0, false)
                SetEntityCoordsNoOffset(e, p.x, p.y, (ok and gz or (p.z - 1.0)) - mn.z, false, false, false)
                spin = (spin + 0.6) % 360.0
                SetEntityHeading(e, spin)
                SetEntityDrawOutline(e, true)
                SetEntityDrawOutlineColor(255, 255, 255, 200)
            end
            Wait(0)
        end
        pv.run = false
        previewStop()
    end)
end
G.PropPreviewStop = previewStop

-- Menu staff F10 › Props permanents
local presets = {}
RegisterNetEvent('pb:g:props:presets', function(j) presets = G.decode(j) or {} if G.Menu.IsOpen() then G.Menu.Refresh() end end)
local hl
local function highlight(id)
    if hl and spawned[hl] and spawned[hl] ~= 0 and DoesEntityExist(spawned[hl]) then SetEntityDrawOutline(spawned[hl], false) end
    hl = id
    local e = id and spawned[id]
    if e and e ~= 0 and DoesEntityExist(e) then SetEntityDrawOutline(e, true) SetEntityDrawOutlineColor(255, 200, 80, 255) end
end
function G.PropsItems()
    if #presets == 0 then TriggerServerEvent('pb:g:props:presets') end
    local function pickItem(m, l) return { label = l, right = m, pm = m, description = 'Aperçu devant toi au survol. Entrée : le placer (E pour poser).', onSelect = function() previewStop() G.PropPlace(m, l) end } end
    local function pickMenu(id, title, items)
        return { id = id, title = title, subtitle = 'Survole pour prévisualiser', items = items,
            onHover = function(it) previewSet(it and it.pm or nil) end,
            onOpen = function(m) local it = m.items[m.sel or 1] previewSet(it and it.pm or nil) end,
            onClose = function() previewStop() end }
    end
    local known, pick = {}, {}
    for _, cat in ipairs(CATALOG) do
        local items = {}
        for _, p in ipairs(cat[3]) do
            known[p[1]] = true
            if IsModelInCdimage(joaat(p[1])) then items[#items + 1] = pickItem(p[1], p[2]) end
        end
        table.sort(items, function(a, b) return a.label < b.label end)
        if #items > 0 then pick[#pick + 1] = { type = 'submenu', label = cat[1], icon = cat[2], right = tostring(#items), submenu = pickMenu('staff.props.c.' .. #pick, cat[1], items) } end
    end
    local extra = {}
    for _, p in ipairs(presets) do if not known[p.m] then extra[#extra + 1] = pickItem(p.m, p.l) end end
    if #extra > 0 then
        table.sort(extra, function(a, b) return a.label < b.label end)
        pick[#pick + 1] = { type = 'submenu', label = 'Ajoutés par le serveur', icon = 'list', right = tostring(#extra), description = 'Modèles ajoutés dans le panel (Props › Modèles proposés).', submenu = pickMenu('staff.props.c.srv', 'Ajoutés par le serveur', extra) }
    end
    pick[#pick + 1] = { type = 'separator', label = 'Autre' }
    pick[#pick + 1] = { label = 'Autre modèle…', icon = 'edit', description = 'Tape le nom technique du modèle (ex. prop_barrier_work05).', onSelect = function()
        local m = G.Menu.Ask('Nom du modèle', '', 64)
        if m and m:match('^[%w_]+$') then G.PropPlace(m:lower(), m:lower()) end
    end }
    local me = GetEntityCoords(PlayerPedId())
    local near = {}
    for id, p in pairs(list) do
        local d = #(me - vector3(p.x, p.y, p.z))
        if d < 60.0 then near[#near + 1] = { id = id, p = p, d = d } end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    local nearItems = {}
    for _, n in ipairs(near) do
        nearItems[#nearItems + 1] = { label = (n.p.l ~= '' and n.p.l) or n.p.m, right = math.floor(n.d + 0.5) .. ' m', pid = n.id, description = 'Entouré à l\'écran. Entrée : le retirer.',
            onSelect = function() highlight(nil) TriggerServerEvent('pb:g:props:remove', n.id) G.Menu.Stack:Back() G.Menu.Refresh() end }
    end
    if #nearItems == 0 then nearItems[1] = { label = 'Aucun prop à moins de 60 m', disabled = true } end
    return {
        { type = 'submenu', label = 'Poser un prop', icon = 'plus', description = 'Catalogue trié par thème, aperçu au survol, puis E pour poser. Il reste après un redémarrage.', submenu = { id = 'staff.props.pick', title = 'Poser un prop', items = pick } },
        { type = 'submenu', label = 'Props proches', icon = 'box', right = tostring(#near), description = 'Le prop survolé est entouré.', submenu = { id = 'staff.props.near', title = 'Props proches', items = nearItems,
            onHover = function(it) highlight(it and it.pid or nil) end, onOpen = function(m) local it = m.items[m.sel or 1] highlight(it and it.pid or nil) end, onClose = function() highlight(nil) end } },
    }
end
