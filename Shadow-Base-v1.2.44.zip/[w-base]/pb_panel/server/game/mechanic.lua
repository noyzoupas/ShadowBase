-- Atelier de mécanicien : réparation complète et améliorations (moteur, freins, transmission, suspension, blindage, turbo, xénon, teinte, plaque, peinture).
-- Il faut être mécanicien (droit « repair » d'une entreprise de type garage) et en service. Les pièces sont payées par la caisse de l'entreprise :
-- le garage facture ensuite son client avec les factures de la tablette. Les améliorations des véhicules achetés en ville sont conservées.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local M = {}
G.Mech = M

P.Register('mech.edit', "Modifier l'atelier et les pièces", 'mech', true)

local PARTS = {
    { key = 'engine', label = 'Moteur', kind = 'mod', mod = 11, max = 4, price = 1500 },
    { key = 'brakes', label = 'Freins', kind = 'mod', mod = 12, max = 3, price = 900 },
    { key = 'trans', label = 'Transmission', kind = 'mod', mod = 13, max = 3, price = 1100 },
    { key = 'susp', label = 'Suspension', kind = 'mod', mod = 15, max = 4, price = 700 },
    { key = 'armor', label = 'Blindage', kind = 'mod', mod = 16, max = 5, price = 1200 },
    { key = 'turbo', label = 'Turbo', kind = 'toggle', mod = 18, max = 1, price = 4000 },
    { key = 'xenon', label = 'Phares xénon', kind = 'toggle', mod = 22, max = 1, price = 800 },
    { key = 'tint', label = 'Vitres teintées', kind = 'tint', mod = 0, max = 6, price = 250 },
    { key = 'plate', label = 'Style de plaque', kind = 'plate', mod = 0, max = 5, price = 300 },
    { key = 'paint', label = 'Peinture (couleur 0 à 160)', kind = 'paint', mod = 0, max = 160, price = 600 },
}
PB.Cfg.Define('mech', { enabled = true, require_duty = true, max_dist = 6, repair_cost = 150, parts = PARTS })
local function cfg(k, d) return PB.Cfg.Get('mech', k, d) end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

function M.Part(key) for _, p in ipairs(cfg('parts', {}) or {}) do if p.key == key then return p end end end
-- prix d'un niveau : proportionnel au niveau, sauf la peinture (forfait)
function M.Price(part, level)
    level = math.floor(tonumber(level) or 0)
    if level <= 0 then return 0 end
    if part.kind == 'paint' then return math.floor(part.price) end
    return math.floor(part.price * level)
end

-- le mécanicien : contexte d'entreprise valide, droit de réparer, en service
local function mechanic(src)
    if not cfg('enabled', true) then return nil, "L'atelier est désactivé." end
    local c = G.Biz and G.Biz.Ctx(src)
    if not c then return nil, "Tu n'as pas d'entreprise." end
    if not G.Biz.Allowed(c, 'repair') then return nil, "Ton métier ne permet pas de réparer." end
    if cfg('require_duty', true) ~= false and not c.duty then return nil, 'Prends ton service.' end
    local p = G.Get(src)
    if not p or PB.ToBool(p.row.dead) or (G.IsCuffed and G.IsCuffed(src)) then return nil, 'Indisponible.' end
    return c
end
local function acct(c) return 'biz:' .. c.biz.id end

-- Atelier posé au Builder (point « atelier / pont ») : dès qu'une entreprise en a un, on ne répare et n'améliore plus qu'à côté (15 m)
local function atWorkshop(src, c)
    if not (G.Points and G.Points.Of) then return true end
    local list = {}
    for _, p in ipairs(G.Points.Of('biz', c.biz.id)) do if p.kind == 'workshop' then list[#list + 1] = p end end
    if #list == 0 then return true end
    local pc = GetEntityCoords(GetPlayerPed(src))
    for _, p in ipairs(list) do if #(pc - vector3(p.x, p.y, p.z)) <= 15.0 then return true end end
    return false
end
function M.Open(src)
    local c, err = mechanic(src)
    if not c then G.Notify(src, { type = 'warn', title = 'Atelier', text = err }) return end
    if not atWorkshop(src, c) then G.Notify(src, { type = 'warn', title = 'Atelier', text = "Amène le véhicule à l'atelier de ton garage." }) return end
    TriggerClientEvent('pb:g:mech:ui', src, PB.Json({ parts = cfg('parts', {}), repair = tonumber(cfg('repair_cost', 150)) or 0, balance = G.Eco and G.Eco.Balance(acct(c)) or 0, biz = c.biz.label }))
end
RegisterNetEvent('pb:g:mech:open', function()
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not throttle(src, 500) then return end
    M.Open(src)
end)

-- (l'ancien « pb:g:mech:apply » est retiré : tout passe par le devis « pb:g:mech:quote », validé par le client)

local settings = Form.Cfg({ ns = 'mech', id = 'settings', title = 'Atelier', perm = 'mech.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Atelier actif', default = true }, { k = 'require_duty', type = 'toggle', label = 'Mécanicien en service obligatoire', default = true },
    { k = 'max_dist', type = 'number', label = 'Distance au véhicule (m)', default = 6, min = 2, max = 20 },   -- (v1.2.43) « coût payé par la caisse » retiré : plus utilisé (la réparation est facturée au client, onglet Atelier facturé)
} })
local partsForm = Form.Cfg({ ns = 'mech', id = 'parts', title = 'Pièces et améliorations', perm = 'mech.edit', fields = {
    { k = 'parts', type = 'rows', label = 'Pièces', default = PARTS, wide = true, maxitems = 30, unique = 'key',
      hint = "Type : mod (pièce numérotée), toggle (activée ou non), tint (vitres), plate (plaque), paint (couleur). « Mod » = numéro de la pièce du jeu (11 moteur, 12 freins, 13 transmission, 15 suspension, 16 blindage, 18 turbo, 22 xénon). Prix : par niveau, sauf la peinture (forfait).",
      cols = { { k = 'key', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 16, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true }, { k = 'mod', label = 'Mod', type = 'number', min = 0, max = 60 },
        { k = 'max', label = 'Niveaux', type = 'number', min = 1, max = 200 }, { k = 'price', label = 'Prix', type = 'number', min = 0, max = 10000000 } } } } })

PB.Module({
    id = 'mech', label = 'Atelier mécanicien', icon = 'engine', group = 'Serveur', order = 143, perm = 'mech.edit', hint = 'Réparation et tuning',
    caps = function()
        return PB.Capsify({
            { 'Réparation et nettoyage facturés', 'ok', "F6 (en service) : réparer, nettoyer, gestes du métier, puis envoyer la facture au client ; il paie, la caisse encaisse." },
            { 'Customisation en direct, dans le véhicule', 'ok', "Peinture (classique, métallisé, mat, métal, chrome, nacré, teinte libre), jantes, carrosserie, Benny's, performances, xénons, néons, fumée, vitres, plaque, klaxon, livrée : chaque option s'affiche sur la voiture, le client valide en payant." },
            { 'Améliorations conservées', 'ok', "Enregistrées avec le véhicule acheté en ville ; un joueur ne peut pas les modifier lui-même." },
        })
    end,
    doc = "## Atelier\nUn mécanicien en service va à l'**atelier du garage** (point posé au Builder), monte dans le véhicule et choisit une pièce puis un niveau. La caisse de l'entreprise paie les pièces ; le garage facture son client.\n\nLes améliorations sont conservées avec le véhicule.",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'mech', title = "Menu de l'atelier (exemple)", cfg = PB.Cfg.All('menus') } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() local out = {} if M.BillingForm then out[1] = M.BillingForm(ctx) end if M.KitsForm then out[#out + 1] = M.KitsForm(ctx) end out[#out + 1] = settings(ctx) return out end },
            { id = 'parts', label = 'Pièces', icon = 'engine', build = function() return { partsForm(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('atelier', function(R)
    for _, p in ipairs(cfg('parts', {}) or {}) do R.check(p.kind == 'mod' or p.kind == 'toggle' or p.kind == 'tint' or p.kind == 'plate' or p.kind == 'paint', 'pièce « ' .. tostring(p.key) .. '»', 'type inconnu : ' .. tostring(p.kind)) end
end)
