-- Territoires de gangs : zones à prendre. Un gang prend une zone en restant dedans pendant la durée de capture ; le serveur vérifie tout.
-- Les gangs viennent du module Gamertags (natifs ou lus depuis une autre ressource). Revenus versés aux membres connectés du gang propriétaire.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Tr = {}
G.Territories = Tr

P.Register('territories.edit', 'Modifier les territoires de gangs', 'territories', true)
PB.Migrate('078_territories', 'Territoires de gangs', {
    [[CREATE TABLE IF NOT EXISTS pb_territories (zone VARCHAR(32) NOT NULL PRIMARY KEY, gang VARCHAR(32) NOT NULL DEFAULT '', since INT NOT NULL DEFAULT 0, lastcap INT NOT NULL DEFAULT 0)]],
})
PB.Migrate('097_terr_influence', 'Territoires : influence des gangs', {
    [[CREATE TABLE IF NOT EXISTS pb_terr_influence (zone VARCHAR(32) NOT NULL, gang VARCHAR(32) NOT NULL, points INT NOT NULL DEFAULT 0, day INT NOT NULL DEFAULT 0, today INT NOT NULL DEFAULT 0, PRIMARY KEY (zone, gang))]],
})
PB.Migrate('196_terr_reward', 'Territoires : récompenses périodiques', {
    [[CREATE TABLE IF NOT EXISTS pb_terr_reward (zone VARCHAR(32) NOT NULL PRIMARY KEY, last INT NOT NULL DEFAULT 0)]],
})
local ZONES = {
    { id = 'grove', label = 'Grove Street', x = 114.0, y = -1944.0, z = 20.8, radius = 40, income = 400, time = 90, cooldown = 60, min = 1 },
    { id = 'vespucci', label = 'Canaux de Vespucci', x = -1157.0, y = -1520.0, z = 4.4, radius = 40, income = 300, time = 90, cooldown = 60, min = 1 },
    { id = 'mirror_park', label = 'Mirror Park', x = 1090.0, y = -645.0, z = 56.5, radius = 45, income = 300, time = 90, cooldown = 60, min = 1, reward_item = 'armor', reward_qty = 1, reward_hours = 10 },
}
-- polys : contour dessiné au Builder pour une zone ({ [id] = { {x, y}, … } }) ; reward_items : objets proposés à la création
PB.Cfg.Define('territories', { enabled = true, income_min = 30, show_blips = true, zones = ZONES, polys = {},
    reward_items = { 'armor', 'lockpick', 'bandage', 'medkit', 'rope', 'repairkit', 'black_money', 'ammo_pistol', 'ammo_smg', 'ammo_rifle', 'weed_pouch', 'coke_pouch' }, reward_hours_default = 5 })
local function cfg(k, d) return PB.Cfg.Get('territories', k, d) end
local function nowS() return os.time() end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function zone(id) for _, z in ipairs(cfg('zones', {}) or {}) do if z.id == id then return z end end end
function Tr.Zone(id) return zone(id) end
function Tr.Owner(id) local r = DB.one('SELECT gang, since, lastcap FROM pb_territories WHERE zone = ?', { id }) return r and r.gang ~= '' and r.gang or nil, r end
function Tr.Owners()
    local out = {}
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local gid = Tr.Owner(z.id)
        local d = gid and G.Tags and G.Tags.GangDefs()[gid]
        out[z.id] = gid and { gang = gid, label = d and d.label or gid, color = d and d.color or '#dfe2e7' } or false
    end
    return out
end
-- Influence : points gagnés par un gang dans une zone (graffitis non effacés, par exemple). Elle raccourcit la capture de cette zone par ce gang.
function Tr.Influence(zoneId, gangId)
    local r = DB.one('SELECT points FROM pb_terr_influence WHERE zone = ? AND gang = ?', { tostring(zoneId), tostring(gangId) })
    return r and tonumber(r.points) or 0
end
-- `cap` limite ce qu'un gang peut gagner dans une zone en une journée ; renvoie les points réellement ajoutés
function Tr.AddInfluence(zoneId, gangId, n, cap)
    n = math.floor(tonumber(n) or 0)
    if n <= 0 or not zone(zoneId) then return 0 end
    local day = math.floor(nowS() / 86400)
    local r = DB.one('SELECT points, day, today FROM pb_terr_influence WHERE zone = ? AND gang = ?', { zoneId, gangId })
    local today = (r and tonumber(r.day) == day) and tonumber(r.today) or 0
    if cap and cap > 0 then n = math.min(n, math.max(0, cap - today)) end
    if n <= 0 then return 0 end
    DB.exec('REPLACE INTO pb_terr_influence (zone, gang, points, day, today) VALUES (?, ?, ?, ?, ?)', { zoneId, gangId, (r and tonumber(r.points) or 0) + n, day, today + n })
    return n
end
function Tr.InfluenceRows()
    return DB.q('SELECT zone, gang, points FROM pb_terr_influence WHERE points > 0 ORDER BY points DESC LIMIT 100') or {}
end
-- point dans un polygone (contour dessiné au Builder), sinon le cercle de la zone
local function inPoly(x, y, poly)
    local inside, j = false, #poly
    for i = 1, #poly do
        local xi, yi, xj, yj = poly[i][1], poly[i][2], poly[j][1], poly[j][2]
        if ((yi > y) ~= (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1e-9) + xi) then inside = not inside end
        j = i
    end
    return inside
end
Tr.InPoly = inPoly
local function polyOf(z) local p = (cfg('polys', {}) or {})[z.id] return type(p) == 'table' and #p >= 3 and p or nil end
local function inZone(src, z, extra)
    local poly = polyOf(z)
    if poly then
        local ped = GetPlayerPed(src)
        if not ped or ped == 0 then return false end
        local c = GetEntityCoords(ped)
        if inPoly(c.x, c.y, poly) then return true end
        return (extra or 0) > 0 and G.DistTo(src, z.x, z.y, z.z) <= (tonumber(z.radius) or 30) * 0.5   -- petite marge au bord
    end
    return G.DistTo(src, z.x, z.y, z.z) <= (tonumber(z.radius) or 30) + (extra or 0)
end
local function gangsInZone(z)
    local out = {}
    for src in pairs(G.Players()) do
        local g = gangOf(src)
        if g and usable(src) and inZone(src, z) then out[g.id] = (out[g.id] or 0) + 1 end
    end
    return out
end

local sessions, last = {}, {}
AddEventHandler('playerDropped', function() sessions[source] = nil last[source] = nil end)
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end

function Tr.Push(src)
    local gs = src and { [src] = true } or G.Players()
    local owners = PB.Json(Tr.Owners())
    for s in pairs(gs) do
        local g = gangOf(s)
        TriggerClientEvent('pb:g:terr:owners', s, PB.Json({ owners = Tr.Owners(), me = g and g.id or nil }))
    end
end
table.insert(G.beginHooks, function(src) Tr.Push(src) end)

function Tr.Start(src, id)
    if not cfg('enabled', true) then return false, 'Territoires désactivés.' end
    if sessions[src] then return false, 'Capture déjà en cours.' end
    local z = zone(id)
    if not z then return false, 'Zone inconnue.' end
    local g = gangOf(src)
    if not g then return false, "Tu n'appartiens à aucun gang." end
    if not inZone(src, z) then return false, 'Tu es hors de la zone.' end
    local owner, row = Tr.Owner(z.id)
    if owner == g.id then return false, 'Ton gang tient déjà cette zone.' end
    local lastcap = row and tonumber(row.lastcap) or 0
    if lastcap + (tonumber(z.cooldown) or 60) * 60 > nowS() then return false, ('Zone protégée encore %d min.'):format(math.ceil((lastcap + z.cooldown * 60 - nowS()) / 60)) end
    local here = gangsInZone(z)
    if (here[g.id] or 0) < (tonumber(z.min) or 1) then return false, ('Il faut au moins %d membre(s) de ton gang dans la zone.'):format(z.min) end
    local base = math.max(5, tonumber(z.time) or 60)
    local bonus = math.min(0.4, Tr.Influence(z.id, g.id) / 250)       -- 100 points = -40 % (maximum)
    sessions[src] = { zone = z.id, gang = g.id, t = nowS(), dur = math.max(5, math.floor(base * (1 - bonus) + 0.5)) }
    return true, nil, { label = 'Capture : ' .. z.label, time = sessions[src].dur, x = z.x, y = z.y, z = z.z, radius = (tonumber(z.radius) or 30) }
end
function Tr.Finish(src)
    local se = sessions[src]
    sessions[src] = nil
    if not se then return false, nil end
    local z = zone(se.zone)
    local g = gangOf(src)
    if not z or not g or g.id ~= se.gang then return false, 'Capture annulée.' end
    if nowS() - se.t < se.dur - 1 then return false, 'Tu es parti trop vite.' end
    if not inZone(src, z, 3) then return false, 'Tu as quitté la zone.' end
    local owner = Tr.Owner(z.id)
    local here = gangsInZone(z)
    if owner and (here[owner] or 0) > 0 then return false, 'Contesté : un membre du gang rival défend la zone.' end
    DB.exec('REPLACE INTO pb_territories (zone, gang, since, lastcap) VALUES (?, ?, ?, ?)', { z.id, g.id, nowS(), nowS() })
    DB.exec('REPLACE INTO pb_terr_reward (zone, last) VALUES (?, ?)', { z.id, nowS() })
    PB.Audit.Log('serveur', 'territory.capture', src, z.id, owner, g.id, nil)
    TriggerEvent('pb_panel:territoryTaken', src, z.id, g.id)
    Tr.Push()
    local gd = g.color and g or (G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[g.id]) or g   -- couleur du gang pour la bannière
    TriggerClientEvent('pb:g:zone:banner', -1, PB.Json({ title = 'Zone capturée', sub = g.label, zone = z.label, color = gd.color or '#e5384f' }))
    return true, ('%s est à toi.'):format(z.label)
end
function Tr.Release(id) DB.exec('DELETE FROM pb_territories WHERE zone = ?', { tostring(id) }) Tr.Push() end

-- Objets proposés au Builder pour la récompense (seulement ceux qui existent dans l'inventaire)
function Tr.RewardChoices()
    local out = {}
    for _, n in ipairs(cfg('reward_items', {}) or {}) do
        local d = G.Inv and G.Inv.Def and G.Inv.Def(tostring(n))
        if d then out[#out + 1] = { tostring(n), d.label or tostring(n) } end
    end
    return out
end
-- Création d'une zone dessinée au Builder : coins posés un par un (3 à 40), objet offert toutes les 5 h au groupe qui la tient
function Tr.CreateDrawn(src, label, poly, item)
    label = tostring(label or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    if #label < 2 then return false, 'Donne un nom à la zone.' end
    if type(poly) ~= 'table' or #poly < 3 or #poly > 40 then return false, 'Il faut entre 3 et 40 coins.' end
    local pts, sx, sy, sz = {}, 0, 0, 0
    for _, p in ipairs(poly) do
        local x, y, z = tonumber(type(p) == 'table' and (p.x or p[1]) or nil), tonumber(type(p) == 'table' and (p.y or p[2]) or nil), tonumber(type(p) == 'table' and (p.z or p[3]) or 0)
        if not x or not y or math.abs(x) > 10000 or math.abs(y) > 10000 then return false, 'Coin invalide.' end
        if G.DistTo(src, x, y, z or 0) > 1500 then return false, 'Un coin est trop loin de toi.' end
        pts[#pts + 1] = { math.floor(x * 10 + 0.5) / 10, math.floor(y * 10 + 0.5) / 10 }
        sx, sy, sz = sx + x, sy + y, sz + (z or 0)
    end
    local cx, cy, cz = sx / #pts, sy / #pts, sz / #pts
    local r = 0
    for _, p in ipairs(pts) do r = math.max(r, math.sqrt((p[1] - cx) ^ 2 + (p[2] - cy) ^ 2)) end
    if r < 8 then return false, 'Zone trop petite.' end
    item = tostring(item or '')
    if item ~= '' then
        local ok = false
        for _, c in ipairs(Tr.RewardChoices()) do if c[1] == item then ok = true end end
        if not ok then return false, 'Objet de récompense inconnu.' end
    end
    local zones = {}
    for _, z in ipairs(cfg('zones', {}) or {}) do zones[#zones + 1] = z end
    local base = label:lower():gsub('[^%w]+', '_'):gsub('^_+', ''):gsub('_+$', ''):sub(1, 18)
    if base == '' then base = 'zone' end
    local id, n = base, 1
    local function taken(x) for _, z in ipairs(zones) do if z.id == x then return true end end return false end
    while taken(id) do n = n + 1 id = base .. '_' .. n end
    zones[#zones + 1] = { id = id, label = label, x = math.floor(cx * 10) / 10, y = math.floor(cy * 10) / 10, z = math.floor(cz * 10) / 10, radius = math.floor(r + 0.5),
        income = 300, time = 90, cooldown = 60, min = 1, reward_item = item, reward_qty = 1, reward_hours = tonumber(cfg('reward_hours_default', 5)) or 5 }
    local polys = {}
    for k, v in pairs(cfg('polys', {}) or {}) do polys[k] = v end
    polys[id] = pts
    PB.Cfg.Set('territories', 'polys', polys, src, 'Builder : zone ' .. label)
    PB.Cfg.Set('territories', 'zones', zones, src, 'Builder : zone ' .. label)
    PB.Audit.Log('config', 'territory.create', src, id, nil, { corners = #pts, item = item })
    G.PushConfig()
    Tr.Push()
    local d = item ~= '' and G.Inv.Def(item)
    return true, ('Zone « %s » créée (%d coins)%s.'):format(label, #pts, d and (' : ' .. d.label .. ' toutes les 5 h au groupe qui la tient') or '')
end
function Tr.Delete(id)
    local zones, found = {}, false
    for _, z in ipairs(cfg('zones', {}) or {}) do if z.id ~= id then zones[#zones + 1] = z else found = true end end
    if not found then return false end
    local polys = {}
    for k, v in pairs(cfg('polys', {}) or {}) do if k ~= id then polys[k] = v end end
    PB.Cfg.Set('territories', 'zones', zones, 0, 'Zone supprimée')
    PB.Cfg.Set('territories', 'polys', polys, 0, 'Zone supprimée')
    DB.exec('DELETE FROM pb_territories WHERE zone = ?', { id })
    G.PushConfig()
    Tr.Push()
    return true
end

RegisterNetEvent('pb:g:terr:start', function(id)
    local src = source
    if not usable(src) or not throttle(src, 800) then return end
    local ok, msg, info = Tr.Start(src, tostring(id))
    if not ok then G.Notify(src, { type = 'error', title = 'Territoire', text = msg }) return end
    TriggerClientEvent('pb:g:terr:wait', src, PB.Json({ id = tostring(id) }))
    if type(info) == 'table' then info.kind = 'terr' end
    TriggerClientEvent('pb:g:crime:go', src, PB.Json(info))      -- même barre de progression que les activités
end)
RegisterNetEvent('pb:g:terr:end', function(done)
    local src = source
    if not G.Get(src) then return end
    if done ~= true then sessions[src] = nil return end
    local ok, msg = Tr.Finish(src)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Territoire', text = msg }) end
end)

-- Revenus : à intervalle fixe, la somme de la zone est partagée entre les membres connectés du gang propriétaire
function Tr.PayOut()
    local n = 0
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local owner = Tr.Owner(z.id)
        if owner and (tonumber(z.income) or 0) > 0 then
            local members = {}
            for s in pairs(G.Players()) do local g = gangOf(s) if g and g.id == owner and usable(s) then members[#members + 1] = s end end
            if #members > 0 then
                local inc = G.Eco and G.Eco.Income and G.Eco.Income(z.income, 'illegal') or z.income   -- onglet Économie
                local share = math.floor(inc / #members)
                for _, s in ipairs(members) do if share > 0 then G.AddMoney(s, 'cash', share, 'Revenus du territoire ' .. z.label) G.Notify(s, { type = 'success', title = z.label, text = ('+%s de revenus de territoire.'):format(PB.Money(share)) }) n = n + share end end
            end
        end
    end
    return n
end
-- Récompenses : un objet déposé dans le coffre de l'organisation propriétaire, toutes les N heures (une seule remise même si le serveur a été éteint longtemps)
function Tr.RewardOf(z)
    local item = tostring(z.reward_item or '')
    if item == '' then return nil end
    return { item = item, qty = math.max(1, math.min(50, math.floor(tonumber(z.reward_qty) or 1))), hours = math.max(1, math.min(168, tonumber(z.reward_hours) or 10)) }
end
function Tr.RewardLast(z, row)
    local r = DB.scalar('SELECT last FROM pb_terr_reward WHERE zone = ?', { z.id })
    return tonumber(r) or (row and tonumber(row.since)) or nowS()
end
function Tr.NextReward(z)
    local rw = Tr.RewardOf(z); if not rw then return nil end
    local owner, row = Tr.Owner(z.id); if not owner then return nil end
    return math.max(0, Tr.RewardLast(z, row) + rw.hours * 3600 - nowS())
end
function Tr.RewardTick()
    local given = 0
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local rw = Tr.RewardOf(z)
        local owner, row = Tr.Owner(z.id)
        if rw and owner and Tr.RewardLast(z, row) + rw.hours * 3600 <= nowS() then
            local o = 'o:' .. owner
            if G.Inv and G.Inv.Def(rw.item) and select(1, G.Inv.CanCarry(o, rw.item, rw.qty)) and G.Inv.Add(o, rw.item, rw.qty) then
                DB.exec('REPLACE INTO pb_terr_reward (zone, last) VALUES (?, ?)', { z.id, nowS() })
                PB.Audit.Log('serveur', 'territory.reward', 0, z.id, owner, rw.item, rw.qty)
                if G.Inv.PushOwners then G.Inv.PushOwners(o) end
                for s in pairs(G.Players()) do
                    local g = gangOf(s)
                    if g and g.id == owner then G.Notify(s, { type = 'success', title = z.label, text = ('%d× %s livré(s) dans le coffre de l\'organisation.'):format(rw.qty, (G.Inv.Def(rw.item) or {}).label or rw.item) }) end
                end
                given = given + 1
            end
        end
    end
    return given
end
CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        if cfg('enabled', true) then Tr.RewardTick() end
    end
end)
CreateThread(function()
    while true do
        Wait(math.max(5, tonumber(cfg('income_min', 30)) or 30) * 60000)
        if cfg('enabled', true) then Tr.PayOut() end
    end
end)
PB.Cfg.OnChange('territories', function() Tr.Push() end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------------
local settings = Form.Cfg({ ns = 'territories', id = 'settings', title = 'Territoires', perm = 'territories.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Territoires actifs', default = true },
    { k = 'income_min', type = 'number', label = 'Intervalle des revenus (minutes)', default = 30, min = 5, max = 1440 },
    { k = 'show_blips', type = 'toggle', label = 'Zones visibles sur la carte (couleur du gang propriétaire)', default = true },
} })
local zonesForm = Form.Cfg({ ns = 'territories', id = 'zones', title = 'Zones', perm = 'territories.edit', fields = {
    { k = 'zones', type = 'rows', label = 'Zones à prendre', default = ZONES, wide = true, maxitems = 40, unique = 'id',
      hint = "Revenu = somme versée à chaque intervalle, partagée entre les membres connectés du gang propriétaire. Durée = secondes à rester dans la zone. Protection = minutes pendant lesquelles on ne peut pas la reprendre. Membres = nombre minimal de ton gang dans la zone.",
      cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false },
        { k = 'radius', label = 'Rayon', type = 'number', min = 5, max = 300 }, { k = 'income', label = 'Revenu', type = 'number', min = 0, max = 1000000 }, { k = 'time', label = 'Durée (s)', type = 'number', min = 5, max = 1800 },
        { k = 'cooldown', label = 'Protection (min)', type = 'number', min = 0, max = 10080 }, { k = 'min', label = 'Membres', type = 'number', min = 1, max = 30 }, { k = 'reward_item', label = 'Objet offert', pattern = '^[%w_]*$', maxlen = 32, lower = true }, { k = 'reward_qty', label = 'Quantité', type = 'number', min = 1, max = 50 }, { k = 'reward_hours', label = 'Toutes les (h)', type = 'number', min = 1, max = 168 } } } } })
PB.Module({
    id = 'territories', label = 'Zones de gangs', icon = 'flag', group = 'Serveur', order = 146, perm = 'territories.edit', hint = 'Zones de gangs, revenus',
    caps = function() return PB.Capsify({
        { 'Prise de zone', 'ok', 'Le gang reste dans la zone pendant la durée ; refusé si un membre du gang propriétaire la défend ou si elle est protégée.' },
        { 'Revenus', 'ok', 'Versés aux membres connectés du gang propriétaire, partagés à parts égales.' },
        { 'Gangs', 'ok', 'Gangs natifs (Gamertags) ou lus depuis une autre ressource (voir Gamertags › Source des gangs).' },
        { 'Guerre de gangs avec points de contrôle multiples', 'off', 'Une seule zone circulaire à la fois ; pas de score ni de saisons.' },
    }) end,
    doc = "## Territoires\nChaque zone a un rayon, un revenu et une durée de capture. Un joueur de gang appuie sur **E** dans la zone et reste sur place ; si un membre du gang propriétaire est encore dans la zone, la capture échoue.",
    view = function(ctx) return { tabs = {
        { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
        { id = 'zones', label = 'Zones', icon = 'map', build = function() return { zonesForm(ctx) } end },
        { id = 'owners', label = 'Propriétaires', icon = 'users', build = function()
            local rows = {}
            for _, z in ipairs(cfg('zones', {}) or {}) do
                local gid, r = Tr.Owner(z.id)
                rows[#rows + 1] = { id = z.id, zone = z.label, gang = gid or '—', since = r and r.since or 0, actions = (gid and ctx.has('territories.edit')) and { { action = 'territories.release', label = 'Libérer', payload = { id = z.id }, confirm = 'Libérer cette zone ?' } } or nil }
            end
            return { B.table({ id = 'own', title = 'Qui tient quoi', columns = { { k = 'zone', label = 'Zone' }, { k = 'gang', label = 'Gang', type = 'badge' }, { k = 'since', label = 'Depuis', type = 'date' } }, rows = rows, empty = 'Aucune zone.' }) }
        end },
        { id = 'influence', label = 'Influence', icon = 'flag', build = function()
            local rows = {}
            for _, r in ipairs(Tr.InfluenceRows()) do local z = zone(r.zone) rows[#rows + 1] = { zone = z and z.label or r.zone, gang = r.gang, points = r.points } end
            return { B.notice('info', "L'influence vient des graffitis d'organisation non effacés. 100 points raccourcissent de 40 % la capture de la zone par ce gang."),
                B.table({ id = 'infl', title = 'Influence par zone', columns = { { k = 'zone', label = 'Zone' }, { k = 'gang', label = 'Gang', type = 'badge' }, { k = 'points', label = 'Points' } }, rows = rows }) }
        end },
        { id = 'map', label = 'Carte', icon = 'map', build = function()
            local pts = {}
            for _, z in ipairs(cfg('zones', {}) or {}) do
                local gid = Tr.Owner(z.id)
                local d = gid and G.Tags and G.Tags.GangDefs()[gid]
                pts[#pts + 1] = { id = z.id, x = z.x, y = z.y, r = tonumber(z.radius) or 30, color = d and d.color or '#dfe2e7', label = z.label, sub = gid and (d and d.label or gid) or 'libre' }
            end
            return { { type = 'map', id = 'zmap', title = 'Zones de gangs', points = pts } }
        end },
        { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'crime', title = 'Barre de capture (exemple)', cfg = PB.Cfg.All('menus') } } end },
    } } end,
})
PB.Action('territories.release', 'territories.edit', function(ctx, p) Tr.Release(p.id) ctx.audit('serveur', 'territory.release', tostring(p.id or '')) ctx.toast = 'Zone libérée.' return true end)
PB.SelfTest.Add('territoires', function(R)
    local seen = {}
    for _, z in ipairs(cfg('zones', {}) or {}) do R.check(not seen[z.id], 'zone « ' .. tostring(z.id) .. ' »', 'identifiant en double') seen[z.id] = true end
    R.check(G.Tags ~= nil, 'gangs disponibles', 'le module Gamertags manque')
end)
