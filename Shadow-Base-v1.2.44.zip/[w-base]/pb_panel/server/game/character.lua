-- Créateur de personnage et écran de mort. Règles, textes, apparition et couleurs se règlent depuis le panel ; le serveur valide tout ce que le client envoie.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('character.reset', 'Faire refaire le créateur à un joueur', 'character', true)
P.Register('death.ems_alert', 'Recevoir les appels de secours (joueurs à terre)', 'death')

PB.Migrate('042_game_creator_v2', 'Créateur : histoire et point de départ', {
    "ALTER TABLE pb_players ADD COLUMN bio VARCHAR(400) NOT NULL DEFAULT ''",
    "ALTER TABLE pb_players ADD COLUMN spawn_id VARCHAR(32) NOT NULL DEFAULT ''",
})

PB.Migrate('300_player_last_pos', 'Reconnexion à la dernière position', {
    "ALTER TABLE pb_players ADD COLUMN last_pos VARCHAR(96) NOT NULL DEFAULT ''",
})

PB.Migrate('162_player_tagcolor', 'Gamertag : couleur du nom choisie à la création', {
    "ALTER TABLE pb_players ADD COLUMN tagcolor VARCHAR(7) NOT NULL DEFAULT ''",
})

local DEFAULT_SPAWNS = {
    { id = 'aeroport', label = 'Aéroport de Los Santos', desc = "Tu arrives en avion : ville immense, transports et premiers boulots à proximité.", x = -1042.0, y = -2745.0, z = 21.4, h = 327.0, enabled = true },
    { id = 'legion', label = 'Legion Square', desc = 'Le centre-ville : commerces, administrations, beaucoup de monde.', x = 195.0, y = -934.0, z = 30.7, h = 142.0, enabled = true },
    { id = 'vespucci', label = 'Plage de Vespucci', desc = 'Ambiance balnéaire, skateurs, bars et ruelles.', x = -1388.0, y = -1196.0, z = 4.5, h = 20.0, enabled = true },
    { id = 'mirror', label = 'Mirror Park', desc = 'Quartier résidentiel calme, parc et cafés.', x = 1078.0, y = -686.0, z = 57.5, h = 90.0, enabled = true },
    { id = 'sandy', label = 'Sandy Shores', desc = 'Le désert du comté de Blaine : plus calme, plus rude.', x = 1695.0, y = 3590.0, z = 35.5, h = 210.0, enabled = true },
    { id = 'paleto', label = 'Paleto Bay', desc = 'Petite ville du nord, bord de mer et forêts.', x = -278.0, y = 6228.0, z = 31.5, h = 45.0, enabled = true },
}
PB.Cfg.Define('character', { spawn = { x = -269.4, y = -955.3, z = 31.2, h = 205.0 }, spawn_points = DEFAULT_SPAWNS })
PB.Cfg.Define('death', { respawn_pos = { x = 298.6, y = -584.4, z = 43.3, h = 72.0 }, pvp = true, headshot_kill = true })

-- Créateur --------------------------------------------------------------------------------------------------------------------------
local creatorForm = Form.Cfg({
    ns = 'character', id = 'rules', title = 'Créateur de personnage', perm = 'character.edit', cols = 2,
    desc = "S'ouvre à la première connexion tant que le personnage n'est pas créé. Un seul personnage par licence Rockstar.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Créateur actif', default = true, hint = 'Désactivé : les joueurs gardent le modèle du jeu et ne choisissent pas leur identité.' },
        { k = 'title', type = 'text', label = 'Titre', default = 'Crée ton personnage', maxlen = 48 },
        { k = 'welcome', type = 'area', label = "Texte d'accueil", default = 'Choisis ton identité et ton apparence. Tu pourras changer de vêtements dans les magasins.', maxlen = 240, wide = true },
        { k = 'c_accent', type = 'color', label = 'Couleur', default = '#dfe2e7' },
        { k = 'allow_male', type = 'toggle', label = 'Homme autorisé', default = true },
        { k = 'allow_female', type = 'toggle', label = 'Femme autorisée', default = true },
        { k = 'name_min', type = 'number', label = 'Longueur minimale des noms', default = 2, min = 1, max = 20 },
        { k = 'name_max', type = 'number', label = 'Longueur maximale des noms', default = 20, min = 3, max = 32 },
        { k = 'age_min', type = 'number', label = 'Âge minimal', default = 18, min = 12, max = 99 },
        { k = 'age_max', type = 'number', label = 'Âge maximal', default = 80, min = 18, max = 120 },
        { k = 'height_min', type = 'number', label = 'Taille minimale (cm)', default = 150, min = 100, max = 250 },
        { k = 'height_max', type = 'number', label = 'Taille maximale (cm)', default = 205, min = 120, max = 250 },
        { k = 'nationalities', type = 'tags', label = 'Nationalités proposées', default = { 'Française', 'Américaine', 'Britannique', 'Espagnole', 'Italienne', 'Allemande', 'Marocaine', 'Algérienne', 'Autre' }, hint = 'Laisse vide pour un champ libre.', maxitems = 40 },
        { k = 'show_clothes', type = 'toggle', label = 'Étape « Vêtements »', default = true },
        { k = 'allow_random', type = 'toggle', label = 'Boutons « Aléatoire »', default = true },
        { k = 'ask_bio', type = 'toggle', label = "Demander une courte histoire du personnage", default = true },
        { k = 'bio_max', type = 'number', label = "Longueur maximale de l'histoire", default = 240, min = 40, max = 400 },
        { k = 'spawn_last', type = 'toggle', label = 'Reconnexion à la dernière position', default = true, hint = "Le joueur réapparaît là où il s'est déconnecté (position relevée par le serveur, aussi toutes les 2 minutes). Désactivé : il réapparaît au point de départ." },
        { k = 'allow_spawn_choice', type = 'toggle', label = 'Le joueur choisit son point de départ', default = true, hint = "Les points se gèrent dans l'onglet « Points de départ ». Désactivé : tout le monde apparaît à la position ci-dessous." },
        { k = 'rules_required', type = 'toggle', label = 'Faire accepter le règlement avant de valider', default = false },
        { k = 'rules_text', type = 'area', label = 'Règlement affiché à la validation', default = 'Je jouerai mon personnage de façon réaliste et je respecterai les règles du serveur.', maxlen = 400, wide = true },
        { k = 'start_cash', type = 'number', label = 'Espèces de départ', default = 500, min = 0, max = 10000000 },
        { k = 'start_bank', type = 'number', label = 'Banque de départ', default = 2500, min = 0, max = 10000000 },
        { k = 'spawn', type = 'coords', label = 'Apparition après la création', default = { x = -269.4, y = -955.3, z = 31.2, h = 205.0 }, wide = true, hint = 'Clique sur « Ma position » en te plaçant à l\'endroit voulu en jeu.' },
    },
})

local function nationalitiesFor() return PB.Cfg.Get('character', 'nationalities', {}) end

local function modelFor(sex) return sex == 'f' and 'mp_f_freemode_01' or 'mp_m_freemode_01' end

local function isInt(v, a, b) return type(v) == 'number' and v == math.floor(v) and v >= a and v <= b end
local function isNum(v, a, b) return type(v) == 'number' and v == v and v >= a and v <= b end

-- Valide une apparence envoyée par le client : structure fixe, bornes larges (les limites réelles des vêtements dépendent des ressources du client).
function G.ValidAppearance(a, sex)
    if type(a) ~= 'table' then return nil, 'Apparence invalide.' end
    local o = { model = modelFor(sex) }
    local h = a.head
    if type(h) ~= 'table' or not isInt(h.mother, 0, 45) or not isInt(h.father, 0, 45) or not isNum(h.shape, 0, 1) or not isNum(h.skin, 0, 1) then return nil, 'Hérédité invalide.' end
    o.head = { mother = h.mother, father = h.father, shape = h.shape, skin = h.skin }
    if type(a.face) ~= 'table' or #a.face ~= 20 then return nil, 'Traits du visage invalides.' end
    o.face = {}
    for i = 1, 20 do if not isNum(a.face[i], -1, 1) then return nil, 'Traits du visage invalides.' end o.face[i] = a.face[i] end
    local hr = a.hair
    if type(hr) ~= 'table' or not isInt(hr.style, 0, 255) or not isInt(hr.color, 0, 63) or not isInt(hr.highlight, 0, 63) then return nil, 'Cheveux invalides.' end
    o.hair = { style = hr.style, color = hr.color, highlight = hr.highlight }
    if not isInt(a.eye, 0, 31) then return nil, 'Couleur des yeux invalide.' end
    o.eye = a.eye
    if type(a.ov) ~= 'table' or #a.ov ~= 13 then return nil, 'Détails du visage invalides.' end
    o.ov = {}
    for i = 1, 13 do
        local v = a.ov[i]
        if type(v) ~= 'table' or not isInt(v.s, 0, 255) or not isNum(v.o, 0, 1) or not isInt(v.c, 0, 63) then return nil, 'Détails du visage invalides.' end
        o.ov[i] = { s = v.s, o = v.o, c = v.c }
    end
    if type(a.comps) ~= 'table' or #a.comps ~= 12 then return nil, 'Vêtements invalides.' end
    o.comps = {}
    for i = 1, 12 do
        local v = a.comps[i]
        if type(v) ~= 'table' or not isInt(v.d, 0, 1999) or not isInt(v.t, 0, 99) then return nil, 'Vêtements invalides.' end
        o.comps[i] = { d = v.d, t = v.t }
    end
    o.props = {}
    local okId = { [0] = true, [1] = true, [2] = true, [6] = true, [7] = true }
    if type(a.props) ~= 'table' or #a.props > 5 then return nil, 'Accessoires invalides.' end
    for _, v in ipairs(a.props) do
        if type(v) ~= 'table' or not isInt(v.id, 0, 7) or not okId[v.id] or not isInt(v.d, -1, 1999) or not isInt(v.t, 0, 99) then return nil, 'Accessoires invalides.' end
        o.props[#o.props + 1] = { id = v.id, d = v.d, t = v.t }
    end
    -- tatouages : { { c = collection, o = motif } } (hachages GTA, 60 au plus), facultatif
    o.tattoos = {}
    if a.tattoos ~= nil then
        if type(a.tattoos) ~= 'table' or #a.tattoos > 60 then return nil, 'Tatouages invalides.' end
        local seen = {}
        for _, v in ipairs(a.tattoos) do
            if type(v) ~= 'table' or not isInt(v.c, -2147483648, 4294967295) or not isInt(v.o, -2147483648, 4294967295) then return nil, 'Tatouages invalides.' end
            local k = v.c .. ':' .. v.o
            if not seen[k] then seen[k] = true o.tattoos[#o.tattoos + 1] = { c = v.c, o = v.o } end
        end
    end
    return o
end

local function validName(s, cfg)
    if type(s) ~= 'string' then return nil end
    s = PB.Trim(s)
    local chars = 0
    for _ in s:gmatch('[%z\1-\127\194-\244][\128-\191]*') do chars = chars + 1 end
    if chars < cfg.name_min or chars > cfg.name_max then return nil end
    -- lettres (accents compris), espaces, tiret et apostrophe
    local good = pcall(function()
        for _, cp in utf8.codes(s) do
            local ok = (cp >= 65 and cp <= 90) or (cp >= 97 and cp <= 122) or cp == 32 or cp == 45 or cp == 39 or (cp >= 0xC0 and cp <= 0x24F and cp ~= 0xD7 and cp ~= 0xF7)
            if not ok then error('x') end
        end
    end)
    if not good then return nil end
    return s
end

local function validDob(s, cfg)
    local y, m, d = tostring(s or ''):match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    y, m, d = tonumber(y), tonumber(m), tonumber(d)
    if not y or m < 1 or m > 12 or d < 1 or d > 31 then return nil end
    local now = os.date('*t')
    local age = now.year - y - (((now.month < m) or (now.month == m and now.day < d)) and 1 or 0)
    if age < cfg.age_min or age > cfg.age_max then return nil, ('Âge autorisé : %d à %d ans.'):format(cfg.age_min, cfg.age_max) end
    return ('%04d-%02d-%02d'):format(y, m, d)
end

-- Points de départ -----------------------------------------------------------------------------------------------------------------
local function slug(label) local x = tostring(label):lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', '') return x:sub(1, 24) end

function G.CleanSpawns(rows)
    if type(rows) ~= 'table' then return nil, 'Liste invalide.' end
    if #rows > 24 then return nil, 'Au plus 24 points de départ.' end
    local out, seen = {}, {}
    for _, r in ipairs(rows) do
        if type(r) == 'table' then
            local label = PB.Trim(PB.Sanitize(tostring(r.label or ''), 40))
            if label == '' then return nil, 'Chaque point doit avoir un nom.' end
            local id = tostring(r.id or ''):match('^[%w_]+$') and tostring(r.id):sub(1, 32) or slug(label)
            if id == '' then id = 'point' end
            local base, n = id, 1
            while seen[id] do n = n + 1 id = base .. n end
            seen[id] = true
            local x, y, z, h = tonumber(r.x), tonumber(r.y), tonumber(r.z), tonumber(r.h) or 0
            if not x or not y or not z or x ~= x or y ~= y or z ~= z or math.abs(x) > 10000 or math.abs(y) > 10000 or math.abs(z) > 3000 then return nil, 'Coordonnées invalides pour « ' .. label .. ' ».' end
            if x == 0 and y == 0 then return nil, '« ' .. label .. ' » est en 0, 0 : place le point avec « Ajouter ma position ».' end
            out[#out + 1] = { id = id, label = label, desc = PB.Trim(PB.Sanitize(tostring(r.desc or ''), 140)), x = PB.Round(x, 2), y = PB.Round(y, 2), z = PB.Round(z, 2), h = PB.Round(h % 360, 2), enabled = PB.ToBool(r.enabled ~= false and r.enabled ~= 'false' and r.enabled ~= 0) }
        end
    end
    return out
end

local function enabledSpawns()
    local out = {}
    for _, p in ipairs(PB.Cfg.Get('character', 'spawn_points', {})) do if p.enabled ~= false then out[#out + 1] = p end end
    return out
end

local lastCreate = {}
RegisterNetEvent('pb:g:create', function(data)
    local src = source
    local p = G.Get(src)
    if not p then return end
    local now = GetGameTimer and GetGameTimer() or os.time() * 1000
    if lastCreate[src] and now - lastCreate[src] < 1500 then return end
    lastCreate[src] = now
    local function refuse(msg) TriggerClientEvent('pb:g:createError', src, msg) end
    local cfg = PB.Cfg.All('character')
    if not cfg.enabled then return refuse('Le créateur est désactivé.') end
    if PB.ToBool(p.row.created) then return refuse('Ton personnage existe déjà.') end
    if type(data) ~= 'table' then return refuse('Données invalides.') end
    local sex = data.sex == 'f' and 'f' or 'm'
    if (sex == 'm' and not cfg.allow_male) or (sex == 'f' and not cfg.allow_female) then return refuse('Ce sexe n\'est pas autorisé.') end
    local first, last = validName(data.firstname, cfg), validName(data.lastname, cfg)
    if not first or not last then return refuse(('Prénom et nom : %d à %d lettres (accents, espace, tiret et apostrophe autorisés).'):format(cfg.name_min, cfg.name_max)) end
    local dob, derr = validDob(data.dob, cfg)
    if not dob then return refuse(derr or 'Date de naissance invalide (AAAA-MM-JJ).') end
    local height = tonumber(data.height)
    if not height or height < cfg.height_min or height > cfg.height_max then return refuse(('Taille : %d à %d cm.'):format(cfg.height_min, cfg.height_max)) end
    local nat = PB.Sanitize(tostring(data.nationality or ''), 32)
    local list = cfg.nationalities or {}
    if #list > 0 and not PB.Contains(list, nat) then return refuse('Nationalité inconnue.') end
    local app, aerr = G.ValidAppearance(data.appearance, sex)
    if not app then return refuse(aerr) end
    if cfg.rules_required and data.accept ~= true then return refuse('Tu dois accepter le règlement pour continuer.') end
    local bio = ''
    if cfg.ask_bio and data.bio ~= nil then bio = PB.Trim(PB.Sanitize(tostring(data.bio), cfg.bio_max or 240)) end
    local spawn, spawnId = cfg.spawn, ''
    if cfg.allow_spawn_choice then
        local pts = enabledSpawns()
        if #pts > 0 then
            local found
            for _, pt in ipairs(pts) do if pt.id == tostring(data.spawn_id or '') then found = pt end end
            if not found then
                if data.spawn_id ~= nil and tostring(data.spawn_id) ~= '' then return refuse('Point de départ inconnu.') end
                found = pts[1]
            end
            spawn, spawnId = { x = found.x, y = found.y, z = found.z, h = found.h }, found.id
        end
    end
    local tagc = ''   -- la couleur du nom dépend du grade staff, plus du joueur
    local json = PB.Json(app)
    if #json > 8000 then return refuse('Apparence trop volumineuse.') end
    local r = p.row
    r.firstname, r.lastname, r.dob, r.sex, r.height, r.nationality = first, last, dob, sex, math.floor(height), nat
    r.appearance, r.created, r.bio, r.spawn_id, r.tagcolor = json, 1, bio, spawnId, tagc
    r.cash, r.bank = r.cash + (cfg.start_cash or 0), r.bank + (cfg.start_bank or 0)
    DB.exec('UPDATE pb_players SET firstname = ?, lastname = ?, dob = ?, sex = ?, height = ?, nationality = ?, appearance = ?, created = 1, cash = ?, bank = ?, bio = ?, spawn_id = ?, tagcolor = ? WHERE license = ?',
        { first, last, dob, sex, r.height, nat, json, r.cash, r.bank, bio, spawnId, tagc, p.license })
    G.PushState(src)
    TriggerClientEvent('pb:g:created', src, PB.Json({ spawn = spawn, appearance = app, sex = sex }))
    if G.ShowWelcome then SetTimeout(2500, function() G.ShowWelcome(src) end) end   -- le règlement s'affiche après la création du personnage
    TriggerEvent('pb_panel:characterCreated', src, { firstname = first, lastname = last, dob = dob, sex = sex })
    G.Notify(src, { type = 'success', title = 'Bienvenue ' .. first, text = 'Ton personnage a été créé.' })
end)

-- Sauvegarde d'apparence (vêtements achetés, barbier…) : toujours validée, jamais appliquée sur la seule parole du client.
function G.SaveAppearance(src, app)
    local p = G.Get(src)
    if not p then return false, 'Joueur inconnu.' end
    local v, err = G.ValidAppearance(app, p.row.sex)
    if not v then return false, err end
    local json = PB.Json(v)
    if #json > 8000 then return false, 'Apparence trop volumineuse.' end
    p.row.appearance = json
    DB.exec('UPDATE pb_players SET appearance = ? WHERE license = ?', { json, p.license })
    return true
end
exports('SaveAppearance', function(src, app) return G.SaveAppearance(src, app) end)

PB.Action('character.reset', 'character.reset', function(ctx, p)
    local lic = tostring(p.license or '')
    local row = DB.one('SELECT license, firstname, lastname FROM pb_players WHERE license = ?', { lic })
    if not row then return false, 'Joueur introuvable.' end
    DB.exec('UPDATE pb_players SET created = 0 WHERE license = ?', { lic })
    for _, pl in pairs(G.Players()) do if pl.license == lic then pl.row.created = 0 end end
    ctx.audit('config', 'personnage.reset', lic, nil, { name = row.firstname .. ' ' .. row.lastname })
    ctx.toast = 'Le créateur se rouvrira à sa prochaine connexion (identité et apparence conservées jusque-là).'
    return true
end, { critical = true, confirm = { title = 'Refaire le créateur ?', text = "Le joueur recréera son identité et son apparence à sa prochaine connexion. Son argent est conservé.", danger = true } })

PB.Action('character.spawns.save', 'character.edit', function(ctx, p)
    local rows = (p.values or {}).points or {}
    local clean, err = G.CleanSpawns(rows)
    if not clean then return false, err end
    local before = PB.Cfg.Get('character', 'spawn_points', {})
    local ok, e = PB.Cfg.Set('character', 'spawn_points', clean, ctx.actor, 'Points de départ')
    if ok == false then return false, e end
    ctx.audit('config', 'character.spawns', 'spawn_points', before, clean)
    ctx.toast = #clean .. ' point(s) de départ enregistré(s) et envoyé(s) aux joueurs.'
    return true
end)

PB.Action('character.spawns.add', 'character.edit', function(ctx, p)
    local v = p.values or {}
    if not ctx.src or ctx.src == 0 then return false, 'Cette action se lance depuis le jeu : place-toi à l\'endroit voulu.' end
    local c = GetEntityCoords(GetPlayerPed(ctx.src))
    if not c or (c.x == 0 and c.y == 0) then return false, 'Position introuvable : tu dois être en jeu.' end
    local list = PB.DeepCopy(PB.Cfg.Get('character', 'spawn_points', {}))
    list[#list + 1] = { label = tostring(v.label or ''), desc = tostring(v.desc or ''), x = c.x, y = c.y, z = c.z, h = GetEntityHeading and GetEntityHeading(GetPlayerPed(ctx.src)) or 0, enabled = true }
    local clean, err = G.CleanSpawns(list)
    if not clean then return false, err end
    PB.Cfg.Set('character', 'spawn_points', clean, ctx.actor, 'Point de départ ajouté')
    ctx.audit('config', 'character.spawns.add', tostring(v.label), nil, clean[#clean])
    ctx.toast = 'Point ajouté à ta position actuelle.'
    return true
end)

-- Écran de mort ------------------------------------------------------------------------------------------------------------------------
local deathForm = Form.Cfg({
    ns = 'death', id = 'rules', title = 'Écran de mort', perm = 'death.edit', cols = 2,
    desc = "Le joueur à terre attend, peut appeler les secours, puis réapparaît à l'hôpital une fois le délai écoulé.",
    fields = {
        { k = 'enabled', type = 'toggle', label = "Écran de mort actif", default = true, hint = 'Désactivé : le jeu gère la mort comme d\'habitude.' },
        { k = 'pvp', type = 'toggle', label = 'Combat entre joueurs', default = true, hint = 'Les joueurs peuvent se blesser et se tuer.' },
        { k = 'headshot_kill', type = 'toggle', label = 'Balle dans la tête mortelle', default = true, hint = 'Une balle dans la tête met à terre immédiatement (pas les armes de mêlée).' },
        { k = 'title', type = 'text', label = 'Titre', default = 'Tu es inconscient', maxlen = 40 },
        { k = 'subtitle', type = 'text', label = 'Sous-titre', default = 'Attends les secours ou réapparais à l\'hôpital.', maxlen = 120 },
        { k = 'c_accent', type = 'color', label = 'Couleur', default = '#ff6b7d' },
        { k = 'respawn_delay', type = 'number', label = 'Délai avant de pouvoir réapparaître (secondes)', default = 120, min = 10, max = 1800 },
        { k = 'allow_ems', type = 'toggle', label = 'Bouton « Appeler les secours »', default = true },
        { k = 'ems_cooldown', type = 'number', label = 'Délai entre deux appels (secondes)', default = 60, min = 10, max = 600 },
        { k = 'respawn_cost', type = 'number', label = 'Frais de réapparition', default = 250, min = 0, max = 1000000 },
        { k = 'respawn_free_broke', type = 'toggle', label = "Gratuit si le joueur n'a pas assez", default = true },
        { k = 'lose_cash_pct', type = 'number', label = 'Espèces perdues à la réapparition (%)', default = 0, min = 0, max = 100 },
        { k = 'lose_items', type = 'select', label = "Objets perdus à la réapparition à l'hôpital", opts = { { 'none', 'Aucun' }, { 'weapons', 'Armes et munitions' }, { 'all', 'Armes et objets' } }, default = 'all', hint = 'Les VIP gardent tout (VIP › Avantages). Ne sont jamais perdus : vêtements, objets liés (armes premium, armes VIP) et la liste ci-dessous.' },
        { k = 'lose_keep', type = 'list', label = 'Objets toujours gardés', default = { 'phone', 'radio', 'card_id', 'card_bank', 'carkey', 'key', 'id_card', 'driver_license' }, maxitems = 40, maxlen = 40, wide = true },
        { k = 'revive_health', type = 'number', label = 'Vie après une réanimation (%)', default = 50, min = 10, max = 100 },
        { k = 'respawn_health', type = 'number', label = "Vie après réapparition à l'hôpital (%)", default = 100, min = 10, max = 100 },
        { k = 'respawn_needs', type = 'number', label = 'Faim et soif après réapparition (%)', default = 50, min = 0, max = 100 },
        { k = 'respawn_pos', type = 'coords', label = "Point de réapparition (hôpital)", default = { x = 298.6, y = -584.4, z = 43.3, h = 72.0 }, wide = true },
    },
})

local deadAt, lastEms = {}, {}

RegisterNetEvent('pb:g:died', function(killer, weapon)
    local src = source
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) then return end
    if not PB.Cfg.Get('death', 'enabled', true) then return end
    deadAt[src] = os.time()
    G.SetDead(src, true)
    TriggerEvent('pb_panel:playerDied', src)
    -- journal des morts (kills.lua) : le tueur annoncé par la victime est vérifié côté serveur (connecté, assez proche)
    TriggerEvent('pb_panel:killReport', src, math.floor(tonumber(killer) or 0), math.floor(tonumber(weapon) or 0))
end)

table.insert(G.beginHooks, function(src, p) if PB.ToBool(p.row.dead) then deadAt[src] = os.time() end end)

RegisterNetEvent('pb:g:respawn', function()
    local src = source
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.dead) then return end
    local cfg = PB.Cfg.All('death')
    local since = os.time() - (deadAt[src] or 0)
    if since + 2 < cfg.respawn_delay then G.Notify(src, { type = 'warn', text = 'Tu dois encore attendre avant de réapparaître.' }) return end
    local cost = math.floor(cfg.respawn_cost or 0)
    if cost > 0 and G.Vip and G.Vip.Discount then cost = G.Vip.Discount(src, 'ems', cost) end   -- VIP : soins de l'hôpital réduits
    if cost > 0 then
        local acc = G.Pay(src, cost, 'cash')
        -- sans argent : facture de l'hôpital (Cohérence de la ville) ; sinon soins gratuits ou refus selon le réglage
        local billed = not acc and G.Coherence and G.Coherence.HospitalCharge(src, cost, false)
        if not acc and not billed and not cfg.respawn_free_broke then G.Notify(src, { type = 'error', text = "Tu n'as pas assez d'argent pour les frais de réapparition." }) return end
        if acc then
            G.Notify(src, { type = 'info', text = ('Frais de soins : %s'):format(PB.Money(cost)) })
            if G.Coherence then G.Coherence.HospitalCharge(src, cost, true) end
        elseif billed then G.Notify(src, { type = 'warn', text = ("Tu n'avais pas assez d'argent : l'hôpital t'envoie une facture de %s."):format(PB.Money(cost)) }) end
    end
    if (cfg.lose_cash_pct or 0) > 0 then
        local lose = math.floor((p.row.cash or 0) * cfg.lose_cash_pct / 100)
        if lose > 0 then G.RemoveMoney(src, 'cash', lose) end
    end
    -- objets perdus (les VIP gardent tout si l'avantage est actif)
    local mode = cfg.lose_items or 'all'
    if mode ~= 'none' and G.Inv and G.Inv.WipeOnDeath then
        local vipKeep = G.Vip and G.Vip.Is(src) and PB.Cfg.Get('vip', 'keep_items', true) ~= false
        if vipKeep then G.Notify(src, { type = 'info', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = 'Avantage VIP : tu gardes tes armes et tes objets.' })
        else
            local n = G.Inv.WipeOnDeath(src, mode, cfg.lose_keep or {})
            if n > 0 then G.Notify(src, { type = 'warn', text = mode == 'weapons' and 'Tes armes et munitions ont été perdues.' or 'Tu as perdu tes armes et tes objets.' }) end
        end
    end
    local needs = cfg.respawn_needs or 50
    p.row.hunger, p.row.thirst = math.max(p.row.hunger, needs), math.max(p.row.thirst, needs)
    deadAt[src] = nil
    G.SetDead(src, false)
    TriggerClientEvent('pb:g:respawnAt', src, PB.Json({ pos = cfg.respawn_pos, health = cfg.respawn_health }))
    TriggerEvent('pb_panel:playerRespawned', src)
end)

-- Alerte des secours : les secouristes en service (entreprise de type secours) et les joueurs qui ont le droit « recevoir les appels ».
-- auto = true : alerte automatique (un passant a appelé), sans message d'attente au joueur s'il a déjà appelé
function G.EmsAlert(src, auto, x, y, z)
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.dead) then return false end
    local cfg = PB.Cfg.All('death')
    if not cfg.allow_ems then return false end
    local now = os.time()
    if lastEms[src] and now - lastEms[src] < cfg.ems_cooldown then if not auto then G.Notify(src, { type = 'warn', text = 'Tu as déjà appelé les secours, patiente un peu.' }) end return false end
    lastEms[src] = now
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped) or nil
    local pos = c and { x = c.x, y = c.y, z = c.z } or { x = tonumber(x) or 0, y = tonumber(y) or 0, z = tonumber(z) or 0 }
    pos.id = src   -- un seul repère par joueur à terre chez les secouristes (un nouvel appel remplace l'ancien)
    local sent = 0
    local who = (p.row.firstname .. ' ' .. p.row.lastname):gsub('^%s+', '')
    for target in pairs(G.Players()) do
        local bc = target ~= src and G.Biz and G.Biz.Ctx(target)
        if target ~= src and (P.Has(target, 'death.ems_alert') or (bc and bc.duty and bc.biz.kind == 'ems')) then
            G.Notify(target, { type = 'warn', title = auto and 'Appel d\'un passant' or 'Appel de secours', text = (who ~= '' and who or 'Un joueur') .. ' est à terre.', duration = 9000 })
            TriggerClientEvent('pb:g:emsBlip', target, PB.Json(pos))
            sent = sent + 1
        end
    end
    TriggerEvent('pb_panel:emsCalled', src, { x = pos.x, y = pos.y, z = pos.z })
    G.Notify(src, { type = sent > 0 and 'success' or 'info', text = sent > 0 and (auto and 'Un passant a prévenu les secours.' or 'Les secours ont été prévenus.') or "Aucun secouriste n'est en service pour le moment." })
    return sent > 0
end
RegisterNetEvent('pb:g:ems', function(x, y, z) G.EmsAlert(source, false, x, y, z) end)

AddEventHandler('playerDropped', function() local s = source deadAt[s] = nil lastEms[s] = nil lastCreate[s] = nil end)

exports('GetDeadPlayers', function()
    local out = {}
    for src, p in pairs(G.Players()) do if PB.ToBool(p.row.dead) then out[#out + 1] = src end end
    return out
end)

-- Modules du panel -----------------------------------------------------------------------------------------------------------------------------
local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end

PB.Module({
    id = 'character', label = 'Créateur de personnage', icon = 'user', group = 'Serveur', order = 135, perm = 'character.view', hint = 'Identité, apparence, apparition',
    caps = function()
        local others = {}
        for _, r in ipairs({ 'esx_identity', 'esx_skin', 'skinchanger', 'qb-multicharacter', 'qb-clothing', 'illenium-appearance', 'fivem-appearance', 'qbx_core' }) do if GetResourceState(r) == 'started' then others[#others + 1] = r end end
        return PB.Capsify({
            { 'Identité (prénom, nom, naissance, taille, nationalité)', 'ok', 'Validée par le serveur et enregistrée dans pb_players.' },
            { 'Apparence : hérédité, visage, cheveux, détails, vêtements', 'ok', 'Freemode (mp_m / mp_f). Les modèles de ped personnalisés ne sont pas pris en charge.' },
            { 'Un seul personnage par licence', 'partial', 'Pas de sélection de personnages multiples.' },
            { 'Autre script de personnage actif', #others == 0 and 'ok' or 'partial', #others == 0 and 'Aucun conflit détecté.' or ('Détecté : ' .. table.concat(others, ', ') .. '. Deux créateurs en même temps se disputent le joueur : n\'en garde qu\'un.') },
            { 'Données ESX / QBCore', 'off', 'Ne remplit pas les tables users (ESX) ou players (QBCore). À utiliser sans ces scripts de personnage.' },
        })
    end,
    doc = "## Créateur de personnage\nÀ la première connexion le joueur passe par : identité, visage, cheveux et détails, vêtements, validation. Tout est vérifié côté serveur (âge, taille, noms, valeurs d'apparence).\n\n- **Apparition** : se règle avec « Ma position » depuis le panel.\n- **Refaire le créateur** : onglet Joueurs.\n- **Pour tes scripts** : `exports.pb_panel:GetIdentity(source)`, `exports.pb_panel:SaveAppearance(source, apparence)`.",
    view = function(ctx)
        return { tabs = {
            tab('rules', 'Règles et textes', 'sliders', function() return { creatorForm(ctx), { type = 'gpreview', kind = 'creator', title = 'Aperçu en direct', form = 'character.rules', cfg = PB.Cfg.All('character') } } end),
            tab('spawns', 'Points de départ', 'pin', function()
                local list = PB.Cfg.Get('character', 'spawn_points', {})
                local sub = ctx.has('character.edit')
                local blocks = { B.notice('info', "Ce sont les endroits parmi lesquels le joueur choisit où commencer, sur une carte de la ville. Place-toi en jeu puis ajoute ta position, ou modifie les coordonnées dans le tableau.") }
                blocks[#blocks + 1] = { type = 'form', id = 'spawns.form', title = 'Points proposés au joueur', cols = 1, fields = {
                    { k = 'points', type = 'rows', label = 'Points de départ', wide = true, cols = {
                        { k = 'label', label = 'Nom' }, { k = 'desc', label = 'Description' }, { k = 'x', label = 'X', type = 'number' }, { k = 'y', label = 'Y', type = 'number' }, { k = 'z', label = 'Z', type = 'number' },
                        { k = 'h', label = 'Cap', type = 'number' }, { k = 'enabled', label = 'Actif', type = 'toggle' } } } },
                    values = { points = list }, submit = sub and { action = 'character.spawns.save', label = 'Enregistrer les points' } or nil }
                if sub then
                    blocks[#blocks + 1] = { type = 'form', id = 'spawns.add', title = 'Ajouter ma position', cols = 2, fields = {
                        { k = 'label', type = 'text', label = 'Nom du point', required = true, maxlen = 40 }, { k = 'desc', type = 'text', label = 'Description', maxlen = 140 } },
                        values = { label = '', desc = '' }, submit = { action = 'character.spawns.add', label = 'Ajouter ici' } }
                end
                blocks[#blocks + 1] = { type = 'gpreview', kind = 'spawnmap', title = 'Carte vue par le joueur', cfg = { spawn_points = list, c_accent = PB.Cfg.Get('character', 'c_accent', '#dfe2e7') } }
                return blocks
            end),
            tab('players', 'Joueurs', 'users', function(_, params)
                local q = PB.Trim(tostring(params.q or '')):lower()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT license, firstname, lastname, dob, sex, height, created, cash, bank, last_seen FROM pb_players ORDER BY last_seen DESC LIMIT 300') or {}) do
                    local name = (r.firstname .. ' ' .. r.lastname)
                    if q == '' or name:lower():find(q, 1, true) or r.license:find(q, 1, true) then
                        rows[#rows + 1] = { id = r.license, name = name ~= ' ' and name or '—', dob = r.dob, sex = r.sex == 'f' and 'F' or 'H', height = r.height, state = PB.ToBool(r.created) and { text = 'Créé', tone = 'ok' } or { text = 'À créer', tone = 'warn' },
                            cash = r.cash, bank = r.bank, lic = r.license,
                            actions = ctx.has('character.reset') and { { action = 'character.reset', label = 'Refaire le créateur', icon = 'undo', danger = true, payload = { license = r.license } } } or {} }
                    end
                end
                return { B.table({ id = 'chars', title = 'Personnages', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'dob', label = 'Naissance' }, { k = 'sex', label = 'Sexe' }, { k = 'height', label = 'Taille', type = 'num' },
                    { k = 'state', label = 'Statut', type = 'badge' }, { k = 'cash', label = 'Espèces', type = 'num' }, { k = 'bank', label = 'Banque', type = 'num' }, { k = 'lic', label = 'Licence', type = 'mono' } }, rows = rows, empty = 'Aucun personnage pour le moment.' }) }
            end),
        } }
    end,
})

PB.Module({
    id = 'death', label = 'Écran de mort', icon = 'heart', group = 'Serveur', order = 136, perm = 'death.view', hint = 'Délai, secours, hôpital, frais',
    caps = function()
        local others = {}
        for _, r in ipairs({ 'esx_ambulancejob', 'qb-ambulancejob', 'wasabi_ambulance', 'ox_death' }) do if GetResourceState(r) == 'started' then others[#others + 1] = r end end
        return PB.Capsify({
            { 'Écran de mort, délai, réapparition, frais', 'ok', 'Chronomètre vérifié par le serveur.' },
            { "Appel des secours", 'ok', "Prévient les joueurs qui ont la permission « death.ems_alert » (crée un grade « secours » dans Grades et permissions) et place un point sur leur carte." },
            { 'Réanimation par un secouriste', 'partial', "Pas d'action de soin incluse : ton script de métier appelle exports.pb_panel:Revive(joueur)." },
            { 'Autre script de mort / ambulance actif', #others == 0 and 'ok' or 'partial', #others == 0 and 'Aucun conflit détecté.' or ('Détecté : ' .. table.concat(others, ', ') .. '. Un seul système de mort doit tourner.') },
        })
    end,
    doc = "## Écran de mort\nLe joueur à terre voit un chronomètre. Il peut appeler les secours, puis réapparaître à l'hôpital quand le délai est écoulé (frais et pertes réglables).\n\n- **Secouristes** : donne la permission `death.ems_alert` à leur grade pour qu'ils reçoivent l'alerte et le point sur la carte.\n- **Réanimer** : `exports.pb_panel:Revive(source)` depuis ton script de métier ; `exports.pb_panel:IsDead(source)` et `exports.pb_panel:GetDeadPlayers()` pour les lister.\n- Événements serveur : `pb_panel:playerDied`, `pb_panel:playerRespawned`, `pb_panel:emsCalled`.",
    view = function(ctx)
        return { tabs = { tab('rules', 'Règles et textes', 'sliders', function() return { deathForm(ctx), { type = 'gpreview', kind = 'death', title = 'Aperçu en direct', form = 'death.rules', cfg = PB.Cfg.All('death') } } end) } }
    end,
})

PB.SelfTest.Add('character', function(R)
    local a = { head = { mother = 21, father = 0, shape = 0.5, skin = 0.5 }, face = {}, hair = { style = 4, color = 2, highlight = 5 }, eye = 3, ov = {}, comps = {}, props = { { id = 0, d = -1, t = 0 } } }
    for i = 1, 20 do a.face[i] = 0.0 end
    for i = 1, 13 do a.ov[i] = { s = 255, o = 1.0, c = 0 } end
    for i = 1, 12 do a.comps[i] = { d = 0, t = 0 } end
    local ok, clean = pcall(G.ValidAppearance, a, 'm')
    R.check(ok and clean, 'personnage', "une apparence par défaut valide est refusée", clean)
    local bad = pcall(G.ValidAppearance, { head = 'x' }, 'm')
    R.check(bad, 'personnage', "une apparence malformée fait planter la validation au lieu d'être refusée")
end)
