/* Magasins : supérette, concession, invite d'interaction. Le vestiaire est dans creator.js. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

// invite « E » (même boîte pour l'invite principale et celles du véhicule proche : une ligne chacune)
let mainPrompt = null, vehLines = [];
function drawPrompt() {
  let p = document.getElementById('g-prompt');
  if (!p) { p = h('div', { id: 'g-prompt' }); G.root.appendChild(p); }
  G.clear(p);
  const lines = (mainPrompt ? [mainPrompt] : []).concat(vehLines);
  if (!lines.length) { p.classList.add('hidden'); return; }
  p.classList.remove('hidden');
  lines.forEach((l) => {
    const txt = String(l.text || ''), low = txt.charAt(0).toLowerCase() + txt.slice(1);
    p.appendChild(h('div', { class: 'gp-l' }, h('span', null, 'Appuyez sur '), h('kbd', null, String(l.key || 'E')), h('span', null, ' pour ' + low + '.')));
  });
  fitPrompt(p);
}
// L'invite reste toujours entière à l'écran : recalée si elle déborde d'un bord, retour à la ligne si elle est plus large que l'écran
function fitPrompt(p) {
  p.style.left = ''; p.style.top = ''; p.style.removeProperty('max-width');
  p.querySelectorAll('.gp-l').forEach((l) => { l.style.whiteSpace = ''; });
  const M = 8, vw = window.innerWidth, vh = window.innerHeight;
  let r = p.getBoundingClientRect();
  if (r.width > vw - 2 * M) {
    p.style.setProperty('max-width', (vw - 2 * M) + 'px', 'important');   // la feuille de style impose « none !important »
    p.querySelectorAll('.gp-l').forEach((l) => { l.style.whiteSpace = 'normal'; });
    r = p.getBoundingClientRect();
  }
  let dx = 0, dy = 0;
  if (r.left < M) dx = M - r.left; else if (r.right > vw - M) dx = (vw - M) - r.right;
  if (r.top < M) dy = M - r.top; else if (r.bottom > vh - M) dy = (vh - M) - r.bottom;
  if (dx) p.style.left = 'calc(var(--pp-x, 50%) + ' + Math.round(dx) + 'px)';
  if (dy) p.style.top = 'calc(var(--pp-y, 82%) + ' + Math.round(dy) + 'px)';
}
window.addEventListener('resize', () => { const p = document.getElementById('g-prompt'); if (p && !p.classList.contains('hidden')) fitPrompt(p); });
G.on('prompt', (d) => { mainPrompt = d && d.show ? { key: d.key, text: d.text } : null; drawPrompt(); });
G.on('vprompt', (d) => { vehLines = (d && d.lines) || []; drawPrompt(); });

let cur = null;
G.on('shop.open', (d) => {
  const r = document.getElementById('g-shop') || (function () { const e = h('div', { id: 'g-shop' }); G.root.appendChild(e); return e; })();
  if (d.refresh && cur && cur.update && cur.state.data.id === d.id) { cur.update(d); return; }
  G.clear(r); r.classList.remove('hidden');
  cur = G.shopFlowView(d, { onClose: () => G.post('shop.close', {}), onTest: (it) => G.post('shop.test', { name: it.name }), onRestock: (it, q) => G.post('shop.restock', { name: it.name, qty: q }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'shop');
  G.uiStack.push({ id: 'shop', onEscape: () => { if (!(cur && cur.escape && cur.escape())) G.post('shop.close', {}); } });
});
G.on('shop.money', (m) => { if (cur) cur.setMoney(m); });
G.on('shop.order', (o) => { if (cur) cur.onOrder(o); else if (o && o.assigned) assignedPopup(o); });
G.on('shop.targets', (d) => { if (cur && cur.setTargets) cur.setTargets(d.list); });

// Panier attribué par un vendeur : le client confirme avec Y ou refuse avec N (le serveur revérifie tout au paiement)
let ap = null, apKey = null;
function closeAssigned() { if (ap) { ap.remove(); ap = null; } if (apKey) { document.removeEventListener('keydown', apKey, true); apKey = null; } G.post('shop.assignedDone', {}); }
function assignedPopup(o) {
  if (ap) { ap.remove(); ap = null; }
  if (o.state === 'cancelled') { closeAssigned(); return; }
  const pay = () => G.post('shop.opay', { id: o.id }), no = () => { G.post('shop.ocancel', { id: o.id }); closeAssigned(); };
  if (o.state === 'paid') {
    ap = h('div', { class: 'sf-ap' }, h('div', { class: 'sf-apd' }, h('b', null, 'Merci !'), h('p', null, 'Tes articles sont dans ton sac.')));
    G.root.appendChild(ap); setTimeout(closeAssigned, 1800); return;
  }
  ap = h('div', { class: 'sf-ap' }, h('div', { class: 'sf-apd', role: 'dialog' },
    h('small', null, (o.label || 'Magasin')), h('b', null, (o.by || 'Un vendeur') + ' te propose un panier'),
    h('div', { class: 'sf-apl' }, (o.lines || []).map((l) => h('div', null, h('span', null, l.qty + ' × ' + l.label), h('em', null, G.money(l.price * l.qty))))),
    h('div', { class: 'sf-apt' }, h('span', null, 'Total'), h('b', null, G.money(o.total))),
    h('div', { class: 'sf-apb' }, h('button', { type: 'button', class: 'sf-bt green', onclick: pay }, 'Payer (Y)'), h('button', { type: 'button', class: 'sf-bt red', onclick: no }, 'Refuser (N)'))));
  G.root.appendChild(ap);
  if (apKey) document.removeEventListener('keydown', apKey, true);
  apKey = (e) => { const k = (e.key || '').toLowerCase(); if (k === 'y') { e.preventDefault(); pay(); } else if (k === 'n') { e.preventDefault(); no(); } };
  document.addEventListener('keydown', apKey, true);
}
G.on('shop.orders', (d) => { if (cur) cur.onOrders(d.list); });
G.on('shop.ticket', (t) => { if (cur) cur.onTicket(t); });
G.on('shop.catdata', (d) => { if (cur) cur.onCat(d); });
G.on('shop.close', () => { const r = document.getElementById('g-shop'); if (r) { G.clear(r); r.classList.add('hidden'); } cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'shop'); });

G.preview.shop = function (box, cfg, blk) {
  G.clear(box);
  const kind = (blk && blk.shopKind) || 'store';
  const it = (name, label, price, category, extra) => Object.assign({ name, label, price, category }, extra || {});
  const STORE = [it('water', 'Eau', 3, 'Boissons', { thirst: 35, image: 'img/items/water.svg' }), it('soda', 'Soda', 5, 'Boissons', { thirst: 25, image: 'img/items/soda.svg' }), it('burger', 'Burger', 12, 'Snacks', { hunger: 50, image: 'img/items/burger.svg' }),
    it('sandwich', 'Sandwich', 8, 'Snacks', { hunger: 35, image: 'img/items/sandwich.svg' }), it('chips', 'Chips', 4, 'Snacks', { hunger: 18, image: 'img/items/chips.svg' }), it('coffee', 'Café', 4, 'Boissons', { thirst: 15, stress: -5, image: 'img/items/coffee.svg' })];
  const GUNS = [it('weapon_pistol', 'Pistolet', 2500, 'Armes de poing', { type: 'weapon', dmg: 35, range: 40, rate: 55, mag: 40, image: 'img/items/_pistol.svg', desc: 'Pistolet semi-automatique fiable.' }), it('weapon_knife', 'Couteau', 150, 'Armes blanches', { type: 'weapon', dmg: 20, range: 5, rate: 60, mag: 0, image: 'img/items/_knife.svg' }),
    it('ammo_pistol', 'Munitions 9 mm', 90, 'Munitions', { type: 'ammo', stock: 40, image: 'img/items/_ammo.svg' })];
  let data;
  if (kind === 'dealer') {
    const V = [{ model: 'blista', label: 'Blista', price: 14000, category: 'Compactes' }, { model: 'sultan', label: 'Sultan', price: 38000, category: 'Berlines' }, { model: 'bati', label: 'Bati 801', price: 21000, category: 'Motos' }, { model: 'adder', label: 'Adder', price: 1000000, category: 'Supercars' }];
    data = { kind, id: 0, label: 'Concession', flow: 'seller', drive_sec: 60, cash: 4200, bank: 9800, vehicles: V, cats: [{ id: 'Compactes', count: 1 }, { id: 'Berlines', count: 1 }, { id: 'Motos', count: 1 }, { id: 'Supercars', count: 1 }] };
  } else if (kind === 'weapons' || kind === 'armory') data = { kind: 'weapons', id: 0, label: 'Armurerie', tagline: "Permis de port d'arme obligatoire", flow: 'seller', test_sec: 20, max_qty: 5, cash: 3200, bank: 9100, items: GUNS };
  else if (kind === 'stock') data = { kind: 'store', id: 0, label: 'Épicerie du port', tagline: 'Tenue par un vendeur — vue employé', flow: 'seller', clerk: true, restock: true, cash: 120, bank: 2400, items: STORE.map((x, i) => Object.assign({}, x, { stock: [14, 3, 0, 9, 6, 11][i] })),
    orders: [{ id: 7, who: 'Mia Costa', state: 'sent', total: 28, items: '2 × Burger, 1 × Eau' }, { id: 6, who: 'Léo Marin', state: 'paid', total: 12, items: '1 × Burger', can_refund: true }] };
  else data = { kind: 'store', id: 0, label: 'Supérette', tagline: 'Ouvert 24 h/24', flow: 'direct', cash: 120, bank: 2400, items: STORE };
  box.appendChild(G.fitStage(h('div', { class: 'sh-stage', style: { width: '1240px' } }, G.shopFlowView(data, { onRestock() {} }).el), 1240, 640));
};
G.preview.weapons = function (box, cfg) { G.preview.shop(box, cfg, { shopKind: 'armory' }); };
})();
