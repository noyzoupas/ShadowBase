-- Interfaces en jeu (noyau client) : configuration reçue du serveur, HUD, notifications, besoins.
-- Les valeurs de configuration viennent du panel ; rien n'est décidé ici sur les droits ou l'argent (le serveur fait foi).

PBG = PBG or { cfg = {}, state = { hunger = 100, thirst = 100, stress = 0, cash = 0, bank = 0, dead = false }, begun = false, nui = {}, locked = 0 }

-- Points d'interaction (banque, garage, boutique…) : un petit point lumineux à hauteur de poitrine, plus de flèche.
-- z = hauteur du sol. Le point le plus proche dessiné sert d'ancre à l'étiquette « [E] TEXTE » (voir plus bas).
local anchor   -- { x, y, z, d, at } : point d'interaction le plus proche dessiné à l'instant
local promptOn, promptAt = false, nil
-- petite touche « E » (carré rouge, lettre blanche) à l'écran au-dessus du point ; masquée quand l'étiquette complète y est affichée
local function keyBadge(x, y, z, d)
    if promptOn and anchor and math.abs(anchor.x - x) < 0.01 and math.abs(anchor.y - y) < 0.01 and d < 8.0 then return end
    local ok, sx, sy = GetScreenCoordFromWorldCoord(x, y, z)
    if not ok then return end
    local k = math.max(0.55, 1.0 - d / 30.0)
    local a = math.floor(math.max(90, 235 - d * 9))
    local hgt = 0.026 * k
    local w = hgt / GetAspectRatio(false)
    DrawRect(sx, sy, w, hgt, 196, 47, 74, a)
    SetTextFont(4) SetTextScale(0.0, 0.36 * k) SetTextColour(255, 255, 255, a) SetTextCentre(true) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName('E') EndTextCommandDisplayText(sx, sy - hgt * 0.47)
end
local function dot(x, y, z, big)
    local t = GetGameTimer() / 1000.0
    local s = (big and 0.085 or 0.06) + 0.008 * math.sin(t * 3.0)
    DrawMarker(28, x, y, z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)   -- halo
    DrawMarker(28, x, y, z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
function PBG.Point(x, y, z, r, g, b, size)
    local pz = z + 1.0
    local me = GetEntityCoords(PlayerPedId())
    local dx, dy, dz = me.x - x, me.y - y, me.z - pz
    local d = math.sqrt(dx * dx + dy * dy + dz * dz)
    keyBadge(x, y, pz, d)
    local now = GetGameTimer()
    if not anchor or now - anchor.at > 60 or d <= anchor.d then anchor = { x = x, y = y, z = pz, d = d, at = now } end
end
-- Au-dessus d'une entité sélectionnable (menu ALT) : même point, plus gros quand elle est survolée.
function PBG.Arrow(x, y, z, big, r, g, b) dot(x, y, z + 0.1, big) end

-- Étiquette d'interaction ancrée dans le monde : l'interface la place sur le point le plus proche (ou sur les coordonnées données
-- par l'appelant : G.send('prompt', { show, key, text, at = { x, y, z } })). Sans point proche, elle s'affiche en bas au centre.
function PBG.PromptAnchor(at) promptAt = at end
CreateThread(function()
    local lx, ly, free
    while true do
        if promptOn then
            local a = promptAt
            if a == nil then a = anchor and GetGameTimer() - anchor.at < 300 and anchor.d < 8.0 and anchor or nil end
            local ok, sx, sy = false, 0, 0
            if a then ok, sx, sy = GetScreenCoordFromWorldCoord(a.x + 0.0, a.y + 0.0, a.z + 0.28) end
            if ok then
                if free ~= false or math.abs(sx - lx) > 0.0012 or math.abs(sy - ly) > 0.0012 then
                    lx, ly, free = sx, sy, false
                    SendNUIMessage({ type = 'g', ev = 'prompt.pos', data = { x = sx, y = sy } })
                end
            elseif free ~= true then
                free = true
                SendNUIMessage({ type = 'g', ev = 'prompt.pos', data = { free = true } })
            end
            Wait(0)
        else
            lx, ly, free = 0, 0, nil
            Wait(150)
        end
    end
end)
-- PNJ fixes (vendeurs, banquiers, gardiens de garage…) : apparaissent quand le joueur approche, toujours posés sur le sol
-- (le z des points peut être la hauteur du joueur ou celle du sol), se tournent vers le joueur tout proche.
-- PBG.Npcs(groupe, { { id, model, x, y, z, h, scenario }, … }) remplace la liste d'un groupe.
local npcSets, npcPeds = {}, {}
function PBG.Npcs(group, list)
    local set = {}
    for _, n in ipairs(list or {}) do if n.model and n.model ~= '' then set[group .. ':' .. tostring(n.id)] = n end end
    npcSets[group] = set
end
local function npcGround(x, y, z)
    local ok, gz = GetGroundZFor_3dCoord(x, y, z + 1.0, false)
    if ok and math.abs(gz - z) < 3.0 then return gz end
    return z - 1.0
end
PBG.Ground = npcGround
CreateThread(function()
    while true do
        Wait(1000)
        local me = PlayerPedId()
        local c = GetEntityCoords(me)
        local want = {}
        if PBG.begun then
            for _, set in pairs(npcSets) do
                for k, n in pairs(set) do if #(c - vector3(n.x + 0.0, n.y + 0.0, n.z + 0.0)) < 60.0 then want[k] = n end end
            end
        end
        for k, p in pairs(npcPeds) do if not want[k] or want[k].model ~= p.model then if DoesEntityExist(p.ped) then DeleteEntity(p.ped) end npcPeds[k] = nil end end
        for k, n in pairs(want) do
            local p = npcPeds[k]
            if not p or not DoesEntityExist(p.ped) then
                local m = GetHashKey(tostring(n.model))
                if IsModelInCdimage(m) and IsModelValid(m) then
                    RequestModel(m)
                    local t = GetGameTimer() + 3000
                    while not HasModelLoaded(m) and GetGameTimer() < t do Wait(50) end
                    if HasModelLoaded(m) then
                        local x, y = n.x + 0.0, n.y + 0.0
                        RequestCollisionAtCoord(x, y, n.z + 0.0)
                        local ped = CreatePed(4, m, x, y, npcGround(x, y, n.z + 0.0), (tonumber(n.h) or 0.0) + 0.0, false, false)
                        SetEntityInvincible(ped, true) SetBlockingOfNonTemporaryEvents(ped, true) SetPedFleeAttributes(ped, 0, false)
                        SetPedCanRagdoll(ped, false) SetPedDiesWhenInjured(ped, false) FreezeEntityPosition(ped, true)
                        if n.ghost then SetEntityCollision(ped, false, false) end   -- garage : les véhicules passent sans le heurter
                        if n.anim and n.anim[1] and DoesAnimDictExist(n.anim[1]) then
                            RequestAnimDict(n.anim[1])
                            local ta = GetGameTimer() + 2000
                            while not HasAnimDictLoaded(n.anim[1]) and GetGameTimer() < ta do Wait(20) end
                            if HasAnimDictLoaded(n.anim[1]) then TaskPlayAnim(ped, n.anim[1], n.anim[2], 2.0, 2.0, -1, 1, 0, false, false, false) end
                        elseif n.scenario and n.scenario ~= '' then TaskStartScenarioInPlace(ped, tostring(n.scenario), 0, true) end
                        SetModelAsNoLongerNeeded(m)
                        npcPeds[k] = { ped = ped, model = n.model, noturn = n.noturn, anim = n.anim }
                    end
                end
            elseif not p.noturn and not PBG.busyPeds[p.ped] and #(c - GetEntityCoords(p.ped)) < 4.0 then
                local pc = GetEntityCoords(p.ped)
                SetEntityHeading(p.ped, GetHeadingFromVector_2d(c.x - pc.x, c.y - pc.y))
            end
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then for _, p in pairs(npcPeds) do if DoesEntityExist(p.ped) then DeleteEntity(p.ped) end end end end)
-- PNJ occupé par une scène (braquage…) : on ne le tourne plus vers le joueur tant qu'il l'est
PBG.busyPeds = PBG.busyPeds or {}
function PBG.SetBusy(ped, on) if ped then PBG.busyPeds[ped] = on and true or nil end end
-- PNJ posé (pour lui faire faire un geste) : nil s'il n'est pas apparu (joueur trop loin)
function PBG.NpcPed(group, id) local p = npcPeds[group .. ':' .. tostring(id)] return p and DoesEntityExist(p.ped) and p.ped or nil, p end
-- Zone (rayon) : cercle très fin au sol (un seul trait de 1 pixel, aucun remplissage).
function PBG.Zone(x, y, z, r, g, b, radius)
    local R = (tonumber(radius) or 2.0) + 0.0
    local n = math.max(40, math.min(120, math.floor(R * 2.4)))
    local step = (math.pi * 2.0) / n
    local px, py = x + R, y
    local zz = z + 0.08
    for i = 1, n do
        local a = i * step
        local cx, cy = x + R * math.cos(a), y + R * math.sin(a)
        DrawLine(px, py, zz, cx, cy, zz, r, g, b, 210)
        px, py = cx, cy
    end
end
local G = PBG

local function decode(s)
    if type(s) ~= 'string' or s == '' then return nil end
    local ok, v = pcall(json.decode, s)
    return ok and v or nil
end
G.decode = decode

function G.send(ev, data)
    if ev == 'prompt' then
        promptOn = type(data) == 'table' and data.show == true
        local at = promptOn and type(data.at) == 'table' and tonumber(data.at.x) and data.at or nil
        promptAt = at and { x = at.x + 0.0, y = at.y + 0.0, z = (tonumber(at.z) or 0) + 0.0 } or nil
        if promptOn and data.free then promptAt = false end   -- invite libre (placement au Builder…) : en bas au centre
    end
    SendNUIMessage({ type = 'g', ev = ev, data = data })
end

-- Focus souris / clavier : plusieurs interfaces peuvent le demander, on rend le focus quand la dernière se ferme.
function G.focus(on)
    G.locked = math.max(0, G.locked + (on and 1 or -1))
    SetNuiFocus(G.locked > 0, G.locked > 0)
end

-- Garde-fou : si le jeu pense qu'une interface est ouverte alors que l'écran n'en montre aucune (fermeture ratée, double appui,
-- erreur d'un script), on remet tout à zéro au lieu de laisser les interactions bloquées pour toute la session.
G.resets = {}
function G.onForceClose(fn) G.resets[#G.resets + 1] = fn end
function G.ForceClose(reason)
    for _, fn in ipairs(G.resets) do pcall(fn) end
    G.locked = 0
    G.wardrobe = false
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    print(('[pb_panel] interfaces remises à zéro (%s)'):format(tostring(reason or 'watchdog')))
end
G.nuiOpen = nil
G.nui['ui.state'] = function(d) G.nuiOpen = d and d.open and true or false return {} end
RegisterCommand('pb_uireset', function() G.ForceClose('commande') G.send('notify', { type = 'success', text = 'Interfaces remises à zéro.' }) end, false)
CreateThread(function()
    local idle = 0
    while true do
        Wait(1500)
        local stuck = G.locked > 0 or G.wardrobe or (G.shopIsOpen and G.shopIsOpen())
        if stuck and not G.creating and not G.barberOpen then   -- coiffeur / tatoueur : menu du jeu, pas d'interface : ne pas les fermer
            G.nuiOpen = nil
            G.send('ui.probe', {})
            Wait(400)
            if G.nuiOpen == false then idle = idle + 1 else idle = 0 end
            G.nuiOpen = nil
            if idle >= 3 then idle = 0 G.ForceClose('watchdog') end
        else
            idle = 0
        end
    end
end)

RegisterNUICallback('g', function(d, cb)
    if type(d) == 'table' and type(d.ev) == 'string' and G.nui[d.ev] then
        local ok, res = pcall(G.nui[d.ev], d.data or {})
        cb(ok and res or {})
    else
        cb({})
    end
end)

-- Configuration et état -----------------------------------------------------------------------------------------------------------
RegisterNetEvent('pb:g:cfg', function(j)
    local c = decode(j)
    if not c then return end
    G.cfg = c
    G.send('cfg', c)
    if G.onCfg then G.onCfg(c) end
end)

-- Configuration de jeu reçue du serveur (couleurs, réglages) : lue par les ressources compagnons, ex. animation_menu
exports('GetClientConfig', function() return G.cfg end)

RegisterNetEvent('pb:g:state', function(j)
    local s = decode(j)
    if not s then return end
    G.state = s
    G.send('state', s)
end)

RegisterNetEvent('pb:g:notify', function(j)
    local n = decode(j)
    if n then G.send('notify', n) end
end)

RegisterNetEvent('pb:g:info', function(j)
    local n = decode(j)
    if n then G.send('infopanel', n) end
end)

-- Coma : on tombe, l'écran d'inconscience s'ouvre avec la raison (voir G.startDeath)
RegisterNetEvent('pb:g:coma', function(why)
    local ped = PlayerPedId()
    if IsEntityDead(ped) or G.state.dead or G.dead then return end
    G.comaWhy = why == 'thirst' and 'thirst' or 'hunger'
    SetEntityHealth(ped, 0)
end)

RegisterNetEvent('pb:g:starve', function(dmg)
    local ped = PlayerPedId()
    dmg = tonumber(dmg) or 0
    if dmg <= 0 or IsEntityDead(ped) or G.state.dead then return end
    SetEntityHealth(ped, math.max(0, GetEntityHealth(ped) - math.floor(dmg)))
end)

-- Notifications : uniquement celles de Shadow Base (aucun événement ESX / QBCore n'est repris).
exports('Notify', function(n) if type(n) == 'table' then G.send('notify', n) else G.send('notify', { type = 'info', text = tostring(n) }) end end)

-- HUD ---------------------------------------------------------------------------------------------------------------------------------
local last, lastSlow = '', 0
local street, zone = '', ''

local function clamp(v, a, b) if v < a then return a elseif v > b then return b end return v end

local GEARS = { [0] = 'R' }

-- Kilométrage réel : distance parcourue mesurée ici (conducteur), envoyée par paquets, stockée par plaque côté serveur.
local odo = { plate = nil, base = nil, own = false, pend = 0.0, pos = nil, flushed = 0 }
local function odoFlush()
    if odo.plate and odo.pend >= 25.0 then
        TriggerServerEvent('pb:g:odo:add', odo.plate, math.floor(odo.pend))
        if odo.own and odo.base then odo.base = odo.base + math.floor(odo.pend) end
        odo.pend = odo.pend - math.floor(odo.pend)
    end
    odo.flushed = GetGameTimer()
end
RegisterNetEvent('pb:g:odo', function(j)
    local d = type(j) == 'string' and json.decode(j) or j
    if type(d) == 'table' and d.plate == odo.plate then odo.base = tonumber(d.m) or 0 odo.own = d.own and true or false end
end)
local function odoTick(ped, veh, c)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
        local plate = (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', ''):upper()
        if plate ~= odo.plate then
            odoFlush()
            odo.plate, odo.base, odo.own, odo.pend, odo.pos = plate, nil, false, 0.0, nil
            if plate ~= '' then TriggerServerEvent('pb:g:odo:get', plate) end
        end
        if odo.pos then
            local d = #(c - odo.pos)
            if d < 60.0 then odo.pend = odo.pend + d end     -- on ignore les téléportations
        end
        odo.pos = c
        if GetGameTimer() - odo.flushed > 30000 then odoFlush() end
        if odo.base then return (odo.base + odo.pend) / 1000.0 end
        return nil
    elseif odo.plate then
        odoFlush(); odo.plate, odo.base, odo.pos, odo.pend = nil, nil, nil, 0.0
    end
    return nil
end

CreateThread(function()
    while true do
        local h = G.cfg.hud
        if not h or h.enabled == false or not G.begun or G.hidden then
            if last ~= 'off' then last = 'off' G.send('hud', { visible = false }) end
            Wait(500)
        else
            local ped = PlayerPedId()
            local id = PlayerId()
            local inVeh = IsPedInAnyVehicle(ped, false)
            local veh = inVeh and GetVehiclePedIsIn(ped, false) or 0
            local maxHp = GetEntityMaxHealth(ped) - 100
            local hp = maxHp > 0 and clamp(math.floor((GetEntityHealth(ped) - 100) / maxHp * 100 + 0.5), 0, 100) or 0
            local t = {
                visible = not (h.hide_pause and IsPauseMenuActive()),
                hp = hp, armor = clamp(GetPedArmour(ped), 0, 100),
                stamina = clamp(math.floor(100 - GetPlayerSprintStaminaRemaining(id)), 0, 100),
                oxygen = IsPedSwimmingUnderWater(ped) and clamp(math.floor(GetPlayerUnderwaterTimeRemaining(id) * 10), 0, 100) or nil,
                talking = NetworkIsPlayerTalking(id) and true or false,
                radio = (LocalPlayer.state.radioChannel or 0) > 0 and NetworkIsPlayerTalking(id) or false,
                vmode = (LocalPlayer.state.proximity and ({ 'Chuchote', 'Normal', 'Crie' })[LocalPlayer.state.proximity.index or 2]) or nil,
                hour = GetClockHours(), minute = GetClockMinutes(),
            }
            local now = GetGameTimer()
            if now - lastSlow > 1000 then
                lastSlow = now
                local c = GetEntityCoords(ped)
                local s1 = GetStreetNameAtCoord(c.x, c.y, c.z)
                street = GetStreetNameFromHashKey(s1)
                zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
            end
            t.street, t.zone = street, zone
            -- cadre de la mini-carte (fractions de l'écran) : le HUD « Shadow » s'aligne dessus quelle que soit la résolution
            if now - (G.mmAt or 0) > 2000 then
                G.mmAt = now
                local safe = GetSafeZoneSize()
                local ar = GetAspectRatio(false)
                local w = 1.0 / (4.0 * ar)
                local hgt = 1.0 / 5.674
                local left = 0.05 * (math.abs(safe - 1.0) * 10)
                local bottom = 1.0 - 0.05 * (math.abs(safe - 1.0) * 10)
                local r4 = function(v) return math.floor(v * 10000 + 0.5) / 10000 end
                G.mm = { l = r4(left), t = r4(bottom - hgt), w = r4(w), h = r4(hgt) }
                G.myId = GetPlayerServerId(PlayerId())
            end
            t.mm, t.id = G.mm, G.myId
            t.heading = math.floor((360.0 - GetGameplayCamRot(0).z) % 360.0 / 3) * 3   -- au degré près, la boussole renvoyait le HUD sans arrêt
            local odoKm = (G.cfg.odo == nil or G.cfg.odo.enabled ~= false) and odoTick(ped, veh, GetEntityCoords(ped)) or nil
            if inVeh then
                local kmh = GetEntitySpeed(veh) * 3.6
                local liters = GetVehicleFuelLevel(veh) or 0.0
                local tank = (GetVehicleHandlingFloat and GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')) or 0.0
                if h.tank_l and tonumber(h.tank_l) and tonumber(h.tank_l) > 0 then tank = tonumber(h.tank_l) end
                if not tank or tank < 1.0 then tank = 65.0 end
                local per100 = math.max(1.0, tonumber(G.fuelAvg) or tonumber(h.l_per_100) or 9.0)
                local rangeKm, maxKm = liters / (per100 / 100.0), tank / (per100 / 100.0)
                local uk = h.units == 'mph' and 0.621371 or 1.0
                local _, lowOn, highOn = GetVehicleLightsState(veh)
                if GetPedInVehicleSeat(veh, -1) == ped and now - (G.trunkAsk or 0) > 6000 then
                    G.trunkAsk = now
                    TriggerServerEvent('pb:g:veh:trunkw', NetworkGetNetworkIdFromEntity(veh), GetVehicleClass(veh))
                end
                t.veh = { speed = math.floor(h.units == 'mph' and kmh * 0.621371 or kmh), fuel = clamp(math.floor(liters / tank * 100.0 + 0.5), 0, 100),
                    liters = math.floor(liters * 100 + 0.5) / 100, tank = math.floor(tank * 10 + 0.5) / 10, low = lowOn == 1 or nil, high = highOn == 1 or nil,
                    kg = G.trunkW and G.trunkW.w or nil, kgmax = G.trunkW and G.trunkW.max or nil,
                    range = math.floor(rangeKm * uk * 10 + 0.5) / 10, rangemax = math.floor(maxKm * uk * 10 + 0.5) / 10,
                    gear = GetVehicleCurrentGear(veh), rpm = clamp(math.floor(GetVehicleCurrentRpm(veh) * 100), 0, 100), odo = odoKm and (math.floor(odoKm * 10 * (h.units == 'mph' and 0.621371 or 1) + 0.5) / 10) or nil, engine = clamp(math.floor(GetVehicleEngineHealth(veh) / 10), 0, 100), on = GetIsVehicleEngineRunning(veh) and true or false }
            end
            -- mini-carte
            local mm = h.minimap or 'always'
            DisplayRadar(mm == 'always' or (mm == 'vehicle' and inVeh))
            -- on n'envoie que ce qui a changé
            local key = json.encode(t)
            if key ~= last then last = key G.send('hud', t) end
            Wait(inVeh and 120 or 400)
        end
    end
end)

-- Boucle unique « à chaque image » : HUD natif masqué + tâches des autres fichiers (G.frameHooks : molette d'armes, Échap…).
-- Un seul thread au lieu d'un par fonction ; il s'endort quand aucune tâche n'est active. Une tâche renvoie true si elle a agi.
G.frameHooks = G.frameHooks or {}
CreateThread(function()
    local hooks = G.frameHooks
    while true do
        local active = false
        local h = G.cfg.hud
        if h and h.enabled ~= false and G.begun then
            HideHudComponentThisFrame(3) HideHudComponentThisFrame(4)
            if h.show_street ~= false then HideHudComponentThisFrame(6) HideHudComponentThisFrame(7) HideHudComponentThisFrame(8) HideHudComponentThisFrame(9) end
            active = true
        end
        for i = 1, #hooks do if hooks[i]() then active = true end end
        Wait(active and 0 or 250)
    end
end)

-- nombre de joueurs en ligne (HUD Shadow)
RegisterNetEvent('pb:g:hud:srv', function(j) local d = G.decode(j) if d then G.send('hud.srv', d) end end)

-- poids du coffre du véhicule conduit (compteur)
RegisterNetEvent('pb:g:veh:trunkw', function(j) local d = G.decode(j) G.trunkW = d and { w = tonumber(d.w) or 0, max = tonumber(d.max) or 0 } or nil end)
RegisterNetEvent('pb:g:hud:me', function(j) local d = G.decode(j) if d then G.send('hud.me', d) end end)
