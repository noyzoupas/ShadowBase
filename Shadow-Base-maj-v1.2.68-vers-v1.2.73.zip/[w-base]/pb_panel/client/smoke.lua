-- Fumer : choix de ce qu'on met dedans, objet en main, bouffées (G), fumée vue par les joueurs proches, effets à l'écran. Le serveur compte et retire les objets.
local G = PBG

local DEVICE = {
    cigarette = { model = 'prop_cs_ciggy_01', fx = 0.28, dict = 'mp_player_int_uppersmoke', anim = 'mp_player_int_smoke', title = 'Rouler la cigarette' },
    joint = { model = 'p_cs_joint_02', fx = 0.32, dict = 'mp_player_int_uppersmoke', anim = 'mp_player_int_smoke' },
    vape = { model = 'ba_prop_battle_vape_01', fx = 0.6, dict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', title = 'Charger la vapoteuse' },
}

-- Effets : filtre de l'écran, tremblement, démarche, vitesse de course, endurance
local EFFECT = {
    nature = { secs = 8, shake = 0.0 },
    weed = { secs = 30, tc = 'spectator5', str = 0.55, shake = 0.15, blur = true },
    coke = { secs = 25, tc = 'drug_drive_blend01', str = 0.5, run = 1.12, stamina = true },
    meth = { secs = 25, tc = 'DRUG_gas_huffin', str = 0.45, shake = 0.3, run = 1.08, stamina = true },
    ecstasy = { secs = 30, fxscreen = 'DrugsMichaelAliensFight', shake = 0.1, stamina = true },
    heroin = { secs = 30, tc = 'Drug_deadman', str = 0.6, shake = 0.55, blur = true, clip = 'move_m@drunk@slightlydrunk' },
}
local MAX_MS = 240000
local cur = { key = nil, untilAt = 0, puffs = 0 }
local clipLoaded

local function clearEffect()
    if not cur.key then return end
    local e = EFFECT[cur.key]
    if e.tc then ClearTimecycleModifier() end
    if e.fxscreen then AnimpostfxStop(e.fxscreen) end
    if (e.shake or 0) > 0 then StopGameplayCamShaking(true) end
    if e.blur then SetPedMotionBlur(PlayerPedId(), false) end
    if e.clip then ResetPedMovementClipset(PlayerPedId(), 0.5) end
    if e.run then SetRunSprintMultiplierForPlayer(PlayerId(), 1.0) end
    cur.key, cur.puffs = nil, 0
end
local function applyEffect(key)
    local e = EFFECT[key]
    if not e then return end
    local now = GetGameTimer()
    if cur.key ~= key then
        clearEffect()
        cur.key, cur.puffs, cur.untilAt = key, 0, now
        if e.tc then SetTimecycleModifier(e.tc) end
        if e.fxscreen then AnimpostfxPlay(e.fxscreen, 0, true) end
        if e.clip then
            RequestAnimSet(e.clip)
            local t = now + 1500
            while not HasAnimSetLoaded(e.clip) and GetGameTimer() < t do Wait(10) end
            SetPedMovementClipset(PlayerPedId(), e.clip, 1.0)
            clipLoaded = e.clip
        end
        if e.run then SetRunSprintMultiplierForPlayer(PlayerId(), e.run + 0.0) end
    end
    cur.puffs = cur.puffs + 1
    cur.untilAt = math.min(now + MAX_MS, math.max(cur.untilAt, now) + e.secs * 1000)
    local k = math.min(1.0, 0.5 + cur.puffs * 0.1)   -- plus on tire, plus c'est fort
    if e.tc then SetTimecycleModifierStrength((e.str or 0.5) * k) end
    if e.blur then SetPedMotionBlur(PlayerPedId(), true) end
    if (e.shake or 0) > 0 then ShakeGameplayCam('DRUNK_SHAKE', e.shake * k) end
end
RegisterNetEvent('pb:g:smoke:effect', function(key) applyEffect(tostring(key)) end)
CreateThread(function()
    while true do
        Wait(1000)
        if cur.key then
            local e, now = EFFECT[cur.key], GetGameTimer()
            if now >= cur.untilAt or IsEntityDead(PlayerPedId()) then clearEffect()
            else
                if e.stamina then RestorePlayerStamina(PlayerId(), 1.0) end
                -- le filtre s'efface dans les 8 dernières secondes
                local left = cur.untilAt - now
                if e.tc and left < 8000 then SetTimecycleModifierStrength((e.str or 0.5) * left / 8000) end
            end
        end
    end
end)

-- Fumée, chez tous les joueurs proches
local function loadFx()
    RequestNamedPtfxAsset('core')
    local t = GetGameTimer() + 1500
    while not HasNamedPtfxAssetLoaded('core') and GetGameTimer() < t do Wait(10) end
    return HasNamedPtfxAssetLoaded('core')
end
RegisterNetEvent('pb:g:smoke:fx', function(id, device)
    local pl = GetPlayerFromServerId(tonumber(id) or -1)
    if pl == -1 then return end
    local d = DEVICE[tostring(device)]
    if not d then return end
    CreateThread(function()
        Wait(1300)   -- le temps de porter à la bouche
        local ped = GetPlayerPed(pl)
        if not DoesEntityExist(ped) or not loadFx() then return end
        UseParticleFxAssetNextCall('core')
        local h = StartParticleFxLoopedOnEntityBone('exp_grd_bzgas_smoke', ped, 0.0, 0.08, 0.02, 0.0, 0.0, 0.0, GetPedBoneIndex(ped, 31086), d.fx + 0.0, false, false, false)
        Wait(d.fx > 0.5 and 2200 or 1400)
        if h then StopParticleFxLooped(h, false) end
    end)
end)

local function loadDict(dict)
    if not DoesAnimDictExist(dict) then return false end
    RequestAnimDict(dict)
    local t = GetGameTimer() + 2000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(10) end
    return HasAnimDictLoaded(dict)
end

-- Objet en main, tant qu'on fume
local smoking, stopRequested = false, false
local function run(d)
    local dev = DEVICE[d.device]
    if not dev or smoking then return end
    smoking, stopRequested = true, false
    local left = tonumber(d.left) or 1
    CreateThread(function()
        local ped = PlayerPedId()
        local obj
        local m = joaat(dev.model)
        if IsModelInCdimage(m) then
            RequestModel(m)
            local t = GetGameTimer() + 2000
            while not HasModelLoaded(m) and GetGameTimer() < t do Wait(10) end
            if HasModelLoaded(m) then
                local c = GetEntityCoords(ped)
                obj = CreateObject(m, c.x, c.y, c.z, true, true, false)
                SetEntityCollision(obj, false, false)
                AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422), 0.02, 0.0, -0.02, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
                SetModelAsNoLongerNeeded(m)
            end
        end
        local shown
        local function prompt() local txt = ('Tirer (%d restantes)  ·  X : ranger'):format(left) if shown ~= txt then shown = txt G.send('prompt', { show = true, free = true, key = 'G', text = txt }) end end
        local nextAt = 0
        while smoking and not stopRequested do
            Wait(0)
            prompt()
            DisableControlAction(0, 47, true)
            ped = PlayerPedId()
            local now = GetGameTimer()
            if IsEntityDead(ped) or IsPedCuffed(ped) then stopRequested = true
            elseif IsDisabledControlJustPressed(0, 47) and now >= nextAt and left > 0 then
                nextAt = now + 2500
                left = left - 1
                if loadDict(dev.dict) then TaskPlayAnim(ped, dev.dict, dev.anim, 8.0, -8.0, 2400, 49, 0, false, false, false) end
                TriggerServerEvent('pb:g:smoke:puff')
            elseif IsControlJustPressed(0, 73) then
                stopRequested = true
                TriggerServerEvent('pb:g:smoke:stopped')
            end
        end
        G.send('prompt', { show = false })
        ClearPedSecondaryTask(PlayerPedId())
        if obj and DoesEntityExist(obj) then DeleteEntity(obj) end
        smoking = false
    end)
end
RegisterNetEvent('pb:g:smoke:start', function(j) local d = G.decode(j) if d then run(d) end end)
RegisterNetEvent('pb:g:smoke:stop', function(msg)
    stopRequested = true
    if msg then G.send('notify', { type = 'info', title = 'Fumer', text = tostring(msg) }) end
end)

-- Ce qu'on met dedans
RegisterNetEvent('pb:g:smoke:menu', function(j)
    local d = G.decode(j)
    local dev = d and DEVICE[d.device]
    if not dev then return end
    local function load(item) G.Menu.Close() TriggerServerEvent('pb:g:smoke:load', d.device, item) end
    local items = { { label = 'Nature', icon = 'check', description = d.device == 'vape' and 'Sans drogue. Un peu moins de stress.' or 'Du tabac, rien de plus. Un peu moins de stress.', onSelect = function() load('') end } }
    if #(d.options or {}) > 0 then items[#items + 1] = { type = 'separator', label = 'Mettre dedans (1 sera utilisé)' } end
    for _, o in ipairs(d.options or {}) do
        items[#items + 1] = { label = tostring(o.label), right = '× ' .. tostring(o.n), icon = 'plus', description = o.desc and tostring(o.desc) or nil, onSelect = function() load(o.item) end }
    end
    G.Menu.Open({ id = 'smoke.load', title = dev.title or tostring(d.label), subtitle = tostring(d.label), nosearch = true, items = items })
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then clearEffect() end end)
