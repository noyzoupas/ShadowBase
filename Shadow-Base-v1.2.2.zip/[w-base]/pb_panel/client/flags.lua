-- Drapeaux de vente : mât (objet du jeu) + tissu dessiné, cercle au sol, invite pour le chef ; l'état de la zone s'affiche sur le côté de l'écran.
-- Neutre = drapeau blanc en bas du mât ; tenu = drapeau à la couleur du gang (avec emblème) tout en haut ; prise en cours = il monte et se colore.
-- Le serveur décide de tout : ici on dessine et on demande « E ».
local G = PBG
local spots, me, boss, rad, enabled = {}, nil, false, 25.0, true
local model, POLE = '', 6.0
local objs = {}
local prog = {}
local recvAt = 0
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local f = c.flags or {}
    enabled = f.enabled ~= false and f.show ~= false
    rad = (tonumber(f.radius) or 25) + 0.0
    model = type(f.pole_model) == 'string' and f.pole_model or model
    POLE = (tonumber(f.pole_height) or 6) + 0.0
end
local function rgb(hex)
    if type(hex) ~= 'string' then return 223, 226, 231 end
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 223, 226, 231 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
-- Points de vente / drapeaux sur la carte : seulement pour les membres d'un groupe illégal
local flagBlips = {}
local function drawFlagBlips()
    for _, b in ipairs(flagBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    flagBlips = {}
    if not enabled or not me or me == '' then return end
    for _, s in ipairs(spots) do
        local o = s.owner
        local col = o and G.blipColourFor and G.blipColourFor(o.color) or 4
        local a = AddBlipForRadius(s.x + 0.0, s.y + 0.0, s.z + 0.0, rad)
        SetBlipColour(a, col) SetBlipAlpha(a, o and 110 or 50)
        flagBlips[#flagBlips + 1] = a
        local c = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(c, 38) SetBlipColour(c, col) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Drapeau · ' .. tostring(s.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
        flagBlips[#flagBlips + 1] = c
    end
end
local lastSig = ''
RegisterNetEvent('pb:g:flag:state', function(j)
    local d = G.decode(j)
    if not d then return end
    spots, me, boss = d.spots or {}, d.me, d.boss == true
    recvAt = GetGameTimer()   -- le temps restant du propriétaire se décompte ici (le serveur ne renvoie plus l'état chaque seconde)
    local sig = tostring(me)
    for _, s in ipairs(spots) do sig = sig .. '|' .. s.id .. ':' .. tostring(s.owner and s.owner.gang or '') end
    if sig ~= lastSig then lastSig = sig drawFlagBlips() end
    if d.cfg then
        if d.cfg.radius then rad = (tonumber(d.cfg.radius) or 25) + 0.0 end
        if d.cfg.model ~= nil then model = tostring(d.cfg.model) end
        if d.cfg.height then POLE = (tonumber(d.cfg.height) or 6) + 0.0 end
    end
end)

-- Tissu : vrai drapeau rectangulaire (1,9 × 1,15 m) qui flotte dans le sens du vent du jeu : 18 bandes, plis éclairés / ombrés,
-- ourlets plus sombres en haut et en bas, emblème (anneau clair) au centre ; dessiné des deux côtés (le jeu n'en affiche qu'un).
local CLOTH_H = 1.15
local FW, FH, SEG, HEM = 1.9, 1.15, 18, 0.07
local wind = { x = 1.0, y = 0.0 }
local function sh(c, k) return math.max(0, math.min(255, math.floor(c * k + 0.5))) end
local function poly2(a, b, c, r, g, bl, al)
    DrawPoly(a[1], a[2], a[3], b[1], b[2], b[3], c[1], c[2], c[3], r, g, bl, al)
    DrawPoly(c[1], c[2], c[3], b[1], b[2], b[3], a[1], a[2], a[3], r, g, bl, al)
end
local function quad2(p1, p2, p3, p4, r, g, b, al) poly2(p1, p2, p3, r, g, b, al) poly2(p1, p3, p4, r, g, b, al) end
local function cloth(x, y, z, r, g, b, t, emblem)
    local dx, dy = wind.x, wind.y
    local nx, ny = -dy, dx
    -- point du tissu : u = 0 au mât … 1 au bout ; v = 0 en bas … 1 en haut ; off = petit décalage (emblème au-dessus du tissu)
    local function at(u, v, off)
        local w = math.sin(t * 2.6 - u * 6.0) * (0.05 + 0.2 * u) + (off or 0)
        local droop = -0.12 * u * u
        return { x + dx * FW * u + nx * w, y + dy * FW * u + ny * w, z + droop + FH * v * (1.0 - 0.04 * u) }
    end
    local function light(u) return 0.72 + 0.28 * (0.5 + 0.5 * math.cos(t * 2.6 - u * 6.0)) end
    local hv = HEM / FH
    for i = 1, SEG do
        local u0, u1 = (i - 1) / SEG, i / SEG
        local k = (light(u0) + light(u1)) * 0.5
        quad2(at(u0, hv), at(u1, hv), at(u1, 1 - hv), at(u0, 1 - hv), sh(r, k), sh(g, k), sh(b, k), 245)
        local kh = k * 0.62
        quad2(at(u0, 0), at(u1, 0), at(u1, hv), at(u0, hv), sh(r, kh), sh(g, kh), sh(b, kh), 250)
        quad2(at(u0, 1 - hv), at(u1, 1 - hv), at(u1, 1), at(u0, 1), sh(r, kh), sh(g, kh), sh(b, kh), 250)
    end
    if emblem then
        local N, cu, cv, ru, rv = 16, 0.5, 0.5, 0.15, 0.25
        for side = -1, 1, 2 do
            local function disc(scale, off, cr, cg, cb)
                local c = at(cu, cv, off * side)
                for j = 0, N - 1 do
                    local a0, a1 = j / N * math.pi * 2, (j + 1) / N * math.pi * 2
                    poly2(c, at(cu + math.cos(a0) * ru * scale, cv + math.sin(a0) * rv * scale, off * side), at(cu + math.cos(a1) * ru * scale, cv + math.sin(a1) * rv * scale, off * side), cr, cg, cb, 245)
                end
            end
            disc(1.0, 0.012, 242, 242, 238)                          -- anneau clair
            disc(0.55, 0.016, sh(r, 0.9), sh(g, 0.9), sh(b, 0.9))     -- centre à la couleur du gang
        end
    end
end
-- vent du jeu, lissé (le drapeau ne saute pas d'une direction à l'autre)
CreateThread(function()
    while true do
        local ok, wd = pcall(GetWindDirection)
        if ok and wd and (wd.x ~= 0 or wd.y ~= 0) then
            local l = math.sqrt(wd.x * wd.x + wd.y * wd.y)
            local tx, ty = wd.x / l, wd.y / l
            for _ = 1, 20 do
                wind.x, wind.y = wind.x + (tx - wind.x) * 0.1, wind.y + (ty - wind.y) * 0.1
                local m = math.sqrt(wind.x * wind.x + wind.y * wind.y)
                if m > 0 then wind.x, wind.y = wind.x / m, wind.y / m end
                Wait(100)
            end
        else Wait(2000) end
    end
end)
-- mât : objet du jeu posé au sol, créé à l'approche, supprimé en s'éloignant (ou si le modèle est inconnu : mât dessiné)
local function pole(s, near)
    local o = objs[s.id]
    if not near or model == '' then
        if o and o.e and DoesEntityExist(o.e) then DeleteEntity(o.e) end
        objs[s.id] = nil
        return false
    end
    if o then return o.e ~= nil and DoesEntityExist(o.e) end
    objs[s.id] = { e = nil, bad = false }
    CreateThread(function()
        local h = GetHashKey(model)
        if not IsModelInCdimage(h) then objs[s.id].bad = true return end
        RequestModel(h)
        local t = GetGameTimer()
        while not HasModelLoaded(h) and GetGameTimer() - t < 3000 do Wait(50) end
        if not HasModelLoaded(h) then objs[s.id].bad = true return end
        local e = CreateObject(h, s.x + 0.0, s.y + 0.0, s.z - 0.95, false, false, false)
        SetEntityAsMissionEntity(e, true, true)
        PlaceObjectOnGroundProperly(e)
        FreezeEntityPosition(e, true)
        SetModelAsNoLongerNeeded(h)
        if objs[s.id] then objs[s.id].e = e else DeleteEntity(e) end
    end)
    return false
end
local function fmt(sec) sec = math.max(0, math.floor(sec)) return ('%d h %02d'):format(sec // 3600, sec % 3600 // 60) end
local hudKey = ''

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    local t0 = GetGameTimer()
    while true do
        if not G.begun or not enabled or #spots == 0 then hide() if hudKey ~= '' then hudKey = '' G.send('flag.hud', { show = false }) end Wait(800)
        else
            local c = GetEntityCoords(PlayerPedId())
            local near, nd
            local anyNear = false
            for _, s in ipairs(spots) do
                local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0))
                if d < 90.0 then
                    anyNear = true
                    local x, y, z = s.x + 0.0, s.y + 0.0, s.z - 0.95
                    local r, g, b = 236, 236, 232      -- neutre : drapeau blanc en bas du mât
                    local height, emblem = 0.15, false
                    if s.owner then r, g, b = rgb(s.owner.color) height, emblem = POLE - CLOTH_H - 0.1, true
                    elseif s.ready and s.ready.color then r, g, b = rgb(s.ready.color) height, emblem = POLE - CLOTH_H - 0.1, true
                    elseif s.by and (tonumber(s.prog) or 0) > 0 then
                        local k = math.min(1.0, (tonumber(s.prog) or 0) / 100.0)
                        local cr, cg, cb = rgb(s.by.color)
                        r, g, b = math.floor(236 + (cr - 236) * k), math.floor(236 + (cg - 236) * k), math.floor(232 + (cb - 232) * k)
                        height, emblem = 0.15 + (POLE - CLOTH_H - 0.25) * k, k > 0.5
                    end
                    -- cercle au sol (couleur du drapeau) + mât
                    PBG.Zone(x, y, z, r, g, b, rad)
                    local hasObj = pole(s, d < 70.0)
                    if not hasObj and not (objs[s.id] and not objs[s.id].bad and model ~= '') then
                        DrawLine(x, y, z, x, y, z + POLE, 28, 28, 30, 255)
                    end
                    cloth(x + 0.05, y, z + height, r, g, b, (GetGameTimer() - t0) / 1000.0, emblem)
                    if not nd or d < nd then near, nd = s, d end
                end
            end
            for _, s in ipairs(spots) do if objs[s.id] and #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) >= 90.0 then pole(s, false) end end
            -- état de la zone sur le côté de l'écran (comme « Zone capturée ») tant qu'on est dans le cercle
            local hud
            if near and nd <= rad then
                local s = near
                if s.owner then
                    local left = math.max(0, math.floor((tonumber(s.owner.left) or 0) - (GetGameTimer() - recvAt) / 1000))
                    hud = { title = 'Zone contrôlée', sub = tostring(s.owner.label), info = tostring(s.label) .. ' · encore ' .. fmt(left), color = s.owner.color }
                elseif s.ready then
                    hud = { title = 'Drapeau prêt', sub = tostring(s.ready.label or ''), info = 'Le chef doit venir le récupérer', color = s.ready.color }
                elseif s.by and (tonumber(s.prog) or 0) > 0 then
                    hud = { title = 'Capture en cours', sub = tostring(s.by.label), info = tostring(s.prog) .. ' %', prog = tonumber(s.prog), color = s.by.color }
                else
                    hud = { title = 'Zone neutre', sub = tostring(s.label), info = 'Aucun groupe ne tient ce point de vente', color = '#e8e8e4' }
                end
            end
            local key = hud and (hud.title .. hud.sub .. hud.info) or ''
            if key ~= hudKey then hudKey = key G.send('flag.hud', hud or { show = false }) end
            -- invite : le chef du gang dont le drapeau est prêt, dans le cercle
            if near and nd <= rad and near.ready and near.ready.gang == me and boss and not G.Menu.IsOpen() then
                if shown ~= near.id then shown = near.id G.send('prompt', { show = true, key = 'E', text = 'Récupérer le drapeau' }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:flag:claim', near.id) end
            else hide() end
            Wait(anyNear and 0 or 500)   -- aucun drapeau à moins de 90 m : inutile de repasser à chaque image
            if not near then Wait(500) end
        end
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    for _, o in pairs(objs) do if o.e and DoesEntityExist(o.e) then DeleteEntity(o.e) end end
end)
