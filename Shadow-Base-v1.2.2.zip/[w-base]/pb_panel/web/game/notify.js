/* Notifications : position, style, durée et couleurs réglés depuis le panel. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const ICON = { info: 'info', success: 'check', warn: 'alert', error: 'alert' };
const TYPES = { success: 'success', ok: 'success', warn: 'warn', warning: 'warn', error: 'error', danger: 'error', info: 'info', inform: 'info' };

function toastEl(cfg, n) {
  const type = TYPES[n.type] || 'info';
  const col = cfg['c_' + type] || { info: '#7cc8ff', success: '#5ee09a', warn: '#ffc65c', error: '#ff7a8c' }[type];
  const dur = Math.max(1000, Number(n.duration) || Number(cfg.duration) || 5000);
  const announce = n.kind === 'announce';
  // Notification sobre : le texte et une barre simple en dessous (aucun logo, aucune icône, aucun halo)
  const style = { '--tc': col, '--tc-rgb': G.hexToRgb(col), '--dur': dur + 'ms' };
  const el = h('div', { class: 'tn tn-card tn-plain' + (announce ? ' tn-ann' : ''), style },
    h('div', { class: 'tn-b' }, n.title ? h('b', null, String(n.title).slice(0, 60)) : null, h('span', null, String(n.text || '').slice(0, 300))), h('i', { class: 'tn-p' }));
  if (n.click === 'reports') { el.setAttribute('data-click', 'reports'); el.addEventListener('click', () => G.post('staff.notif.click', { k: 'reports' })); }
  return { el, dur };
}

G.toastEl = toastEl;
let box = null;
function container() {
  if (!box) { box = h('div', { id: 'g-notify' }); G.root.appendChild(box); }
  const nc = G.cfg.notify || {};
  box.className = 'gp-' + (nc.position || 'map');
  box.style.bottom = (nc.position || 'map') === 'map' ? Math.max(5, Math.min(60, Number(nc.lift) || 24)) + 'vh' : '';
  return box;
}
G.on('cfg', () => { if (box) container(); });
G.on('notify', (n) => {
  const cfg = G.cfg.notify || {}, c = container(), max = Math.max(1, Math.min(8, cfg.max || 4));
  const { el, dur } = toastEl(cfg, n || {});
  const bottom = (cfg.position || 'map').indexOf('bottom') === 0;
  if (bottom) c.insertBefore(el, c.firstChild); else c.appendChild(el);
  while (c.children.length > max) (bottom ? c.lastChild : c.firstChild).remove();
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, dur);
});

// Bandeau « Zone capturée » : milieu droit de l'écran, petit, qui s'efface seul
G.on('zone.banner', (d) => {
  let el = document.getElementById('g-zone');
  if (!el) { el = h('div', { id: 'g-zone' }); G.root.appendChild(el); }
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color || '') ? d.color : '#e5384f';
  G.clear(el); el.style.setProperty('--zc', col); el.classList.remove('out');
  el.appendChild(h('b', null, String(d.title || 'Zone capturée').slice(0, 40))); el.appendChild(h('span', null, String(d.sub || '').slice(0, 60)));
  clearTimeout(el.__t); el.__t = setTimeout(() => { el.classList.add('out'); }, 7000);
});

// Point de vente (drapeau) : état de la zone sur le côté de l'écran, même style que « Zone capturée », tant qu'on est dans le cercle
G.on('flag.hud', (d) => {
  let el = document.getElementById('g-flagzone');
  if (!d || d.show === false || !d.title) { if (el) el.classList.add('out'); return; }
  if (!el) { el = h('div', { id: 'g-flagzone', class: 'out' }); G.root.appendChild(el); }
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color || '') ? d.color : '#e5384f';
  G.clear(el); el.style.setProperty('--zc', col);
  el.appendChild(h('b', null, String(d.title).slice(0, 40)));
  if (d.sub) el.appendChild(h('span', null, String(d.sub).slice(0, 60)));
  if (d.prog != null) el.appendChild(h('i', { class: 'fz-bar' }, h('em', { style: { width: Math.max(0, Math.min(100, Number(d.prog) || 0)) + '%' } })));
  if (d.info) el.appendChild(h('small', null, String(d.info).slice(0, 80)));
  requestAnimationFrame(() => el.classList.remove('out'));
});

// Entrée dans un territoire : carte au-dessus de la mini-carte (badge du gang, nom de la zone, gang qui la contrôle), dégradé à la couleur du gang
G.on('zone.enter', (d) => {
  const old = document.getElementById('g-terr');
  if (old) old.remove();
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color || '') ? d.color : '#9aa0aa';
  const gang = String(d.gang || '').slice(0, 32);
  const initials = gang ? gang.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() : '—';
  const el = h('div', { id: 'g-terr', class: gang ? '' : 'free' });
  el.style.setProperty('--tc', col);
  el.appendChild(h('div', { class: 'gt-top' },
    h('div', { class: 'gt-badge' }, initials),
    h('div', { class: 'gt-head' }, h('b', null, String(d.zone || 'Territoire').slice(0, 40)), h('span', null, 'Vous entrez en territoire'))));
  el.appendChild(h('div', { class: 'gt-foot' }, gang ? 'Sous le contrôle de ' : 'Territoire libre', gang ? h('em', null, gang) : null));
  G.root.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  setTimeout(() => { el.classList.remove('in'); el.classList.add('out'); setTimeout(() => el.remove(), 450); }, 6500);
});

G.preview.notify = function (box, cfg) {
  G.clear(box);
  const stage = h('div', { class: 'gstage' }), c = h('div', { class: 'gp-' + (cfg.position || 'map'), style: { position: 'absolute', inset: '14px' } });
  [['success', 'Achat réussi', 'Tu as payé 120 $ en espèces.'], ['announce', 'Annonce', 'Redémarrage du serveur dans 10 minutes.'], ['warn', 'Attention', 'Ta soif est très basse.'], ['error', 'Impossible', "Tu n'as pas assez d'argent."]]
    .slice(0, Math.max(1, Math.min(4, cfg.max || 4))).forEach((s) => { const t = toastEl(cfg, { type: s[0] === 'announce' ? 'info' : s[0], kind: s[0] === 'announce' ? 'announce' : undefined, title: s[1], text: s[2], duration: 1e6 }); t.el.classList.add('static'); c.appendChild(t.el); });
  stage.appendChild(c); box.appendChild(stage);
};
})();
