-- Nouveautés : journal des mises à jour affiché dans le panel (carte sur l'accueil + module « Nouveautés »).
-- Chaque lot ajoute une entrée à PB.Changelog (voir la liste plus bas). Le « lu / non lu » est mémorisé par administrateur (licence).
-- Pour ajouter une nouveauté : PB.News.Add({ id = 'lot37', date = 'AAAA-MM-JJ', title = '…', items = { { tag = 'Nouveau', text = '…', module = 'id-du-module' } } }).

local B, P, DB = PB.B, PB.Perm, PB.DB
local N = {}
PB.News = N

PB.Migrate('192_news_seen', 'Nouveautés : dernier lot lu par administrateur', {
    [[CREATE TABLE IF NOT EXISTS pb_news_seen (license VARCHAR(64) NOT NULL PRIMARY KEY, seq INT NOT NULL DEFAULT 0)]],
})

N.list = {}   -- du plus ancien au plus récent ; seq = position
function N.Add(e)
    if type(e) ~= 'table' or not e.id then return end
    for _, x in ipairs(N.list) do if x.id == e.id then return end end
    local items = {}
    for _, it in ipairs(e.items or {}) do
        items[#items + 1] = { tag = tostring(it.tag or 'Nouveau'):sub(1, 16), text = tostring(it.text or ''):sub(1, 240), module = it.module and tostring(it.module) or nil }
    end
    N.list[#N.list + 1] = { id = tostring(e.id), seq = #N.list + 1, date = tostring(e.date or ''), title = tostring(e.title or e.id):sub(1, 160), items = items }
end

local function seenOf(license)
    local r = license and DB.one('SELECT seq FROM pb_news_seen WHERE license = ?', { license })
    return r and tonumber(r.seq) or 0
end
-- Entrées pour un administrateur : { unseen, entries (les plus récentes d'abord) }
function N.For(license, limit)
    local seen, out, unseen = seenOf(license), {}, 0
    for i = #N.list, 1, -1 do
        local e = N.list[i]
        local isNew = e.seq > seen
        if isNew then unseen = unseen + 1 end
        if #out < (limit or 50) then out[#out + 1] = { id = e.id, date = e.date, title = e.title, items = e.items, new = isNew } end
    end
    return unseen, out
end
function N.MarkRead(license)
    if not license or #N.list == 0 then return end
    DB.exec('REPLACE INTO pb_news_seen (license, seq) VALUES (?, ?)', { license, N.list[#N.list].seq })
end

-- Journal des lots ----------------------------------------------------------------------------------------------------------------------
N.Add({ id = 'lot34', date = '2026-10-17', title = 'Patch notes 34 : téléphone, inventaire, boutiques', items = {
    { tag = 'Amélioré', text = "Boutiques, inventaire, notifications et HUD repensés.", module = 'shops' },
} })
N.Add({ id = 'lot35', date = '2026-10-17', title = 'Patch notes 35 : entreprises, gangs, carte', items = {
    { tag = 'Nouveau', text = "130 entreprises et gangs prêts à installer, rangés en 10 catégories.", module = 'biz' },
    { tag = 'Nouveau', text = "Module « Carte du jeu » : clique sur la carte, tu es téléporté, E pour poser un point.", module = 'carte' },
    { tag = 'Nouveau', text = "Menu staff : emploi, second emploi, gang, grade, armes dans l'inventaire, redémarrage planifié.", module = 'staff' },
    { tag = 'Corrigé', text = "Boutiques bloquées, noclip en véhicule, boutons grisés, éditeur d'automatisations." },
} })
N.Add({ id = 'lot36', date = '2026-10-17', title = 'Patch notes 36 : coffres, concession, tablettes', items = {
    { tag = 'Nouveau', text = "Coffre de véhicule (touche K) et touches capot, moteur, ceinture, vitres.", module = 'vehtrunk' },
    { tag = 'Nouveau', text = "Concession : 45 véhicules par défaut et nouvelle fiche (vitesse, places, coffre).", module = 'shops' },
    { tag = 'Nouveau', text = "Tablettes entreprise et gang complétées : équipe, annonces, journal, stats, paie, caisse commune, territoires…", module = 'orga' },
    { tag = 'Changé', text = "Noms au-dessus des têtes réservés au staff, couleur par grade.", module = 'tags' },
    { tag = 'Changé', text = "Créateur de personnage redessiné ; tablette transparente.", module = 'character' },
} })
N.Add({ id = 'fix37', date = '2026-10-17', title = 'Gros correctif de présentation', items = {
    { tag = 'Corrigé', text = "Commandes « restreintes » : la restriction ne s'appliquait jamais (faille corrigée).", module = 'commands' },
    { tag = 'Corrigé', text = "Second emploi : il est maintenant payé à chaque paie (pourcentage réglable).", module = 'biz' },
    { tag = 'Corrigé', text = "Points « bureau du patron / siège » : la tablette s'ouvre enfin." },
    { tag = 'Corrigé', text = "Garage : une page avec une note faisait planter l'écran." },
    { tag = 'Amélioré', text = "290 actions du panel et 119 événements du jeu testés avec des données absurdes : plus aucun plantage." },
} })

-- Actions -------------------------------------------------------------------------------------------------------------------------------
PB.Action('news.read', nil, function(ctx) N.MarkRead(ctx.license) return true, { unseen = 0 } end, { read = true })

-- Module --------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'whatsnew', label = 'Nouveautés', icon = 'sparkle', group = 'Pilotage', order = 5, perm = 'whatsnew.view', hint = 'Ce qui change à chaque mise à jour',
    doc = "## Nouveautés\nChaque mise à jour de Shadow Base ajoute une entrée ici, avec un lien direct vers le module concerné. Une pastille signale ce que tu n'as pas encore lu ; « Tout marquer comme lu » l'efface pour ton compte.",
    view = function(ctx)
        return { tabs = { { id = 'all', label = 'Mises à jour', icon = 'sparkle', build = function()
            local unseen, entries = N.For(ctx.license, 50)
            local blocks = {}
            if unseen > 0 then blocks[#blocks + 1] = B.actions({ { action = 'news.read', label = 'Tout marquer comme lu (' .. unseen .. ')', icon = 'check', primary = true } }) end
            for _, e in ipairs(entries) do
                local rows = {}
                for _, it in ipairs(e.items) do
                    local row = { tag = it.tag, text = it.text }
                    if it.module then row.actions = { { nav = it.module, label = 'Ouvrir', icon = 'arrow' } } end
                    rows[#rows + 1] = row
                end
                blocks[#blocks + 1] = B.table({ id = 'news_' .. e.id, title = (e.new and 'NOUVEAU · ' or '') .. e.title .. (e.date ~= '' and ('  (' .. e.date .. ')') or ''), columns = { { k = 'tag', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' } }, rows = rows })
            end
            if #blocks == 0 then blocks[1] = B.notice('info', 'Aucune nouveauté pour le moment.') end
            return blocks
        end } } }
    end,
})

N.Add({ id = 'lot39', date = '2026-10-17', title = 'Patch notes 39 : images, tablettes, placement, nettoyage', items = {
    { tag = 'Corrigé', text = "Images d'objets de l'inventaire et tablette des organisations (mise en page)." },
    { tag = 'Changé', text = "Tablette entreprise : uniquement les outils du métier (police : appels, détenus, amendes, dossiers).", module = 'biz' },
    { tag = 'Nouveau', text = "Placement à l'écran : déplace le vrai HUD, le chat, les menus et l'invite.", module = 'placement' },
    { tag = 'Changé', text = "Onglets en double supprimés (Services, Argent, Documentation, Garages).", module = 'general' },
} })

PB.SelfTest.Add('nouveautés', function(R)
    R.check(#N.list >= 3, 'journal', 'aucune entrée')
    local seen = {}
    for _, e in ipairs(N.list) do
        R.check(not seen[e.id], 'journal', 'identifiant en double : ' .. e.id)
        seen[e.id] = true
        R.check(#e.items > 0, 'journal', 'entrée vide : ' .. e.id)
    end
end)

N.Add({ id = 'patch40', date = '2026-10-18', title = 'Patch notes 40 : inventaire, territoires, points, identité', items = {
    { tag = 'Corrigé', text = "Inventaire : glisser-déposer, vrais filtres, armes jamais consommées (touches 1 à 5)." },
    { tag = 'Nouveau', text = "Tablette illégale : carte des territoires ; Mirror Park donne un gilet toutes les 10 h dans le coffre de l'organisation." },
    { tag = 'Nouveau', text = "Carte : « Configurer tout » pose tous les points d'une entreprise ou d'un gang d'une traite.", module = 'carte' },
    { tag = 'Changé', text = "Supérette : interface d'origine avec panier. Notifications : déplacement corrigé." },
    { tag = 'Nouveau', text = "Logo W et bannières Shadow Base (offres, Halloween, patch notes)." },
    { tag = 'Nouveau', text = "Menus : bannière animée Shadow Base (réglable dans Menus > Apparence).", module = 'menus' },
} })

N.Add({ id = 'patch41', date = '2026-10-18', title = 'Patch notes 41 : aides, infos, ALT, bannière, chuchoter', items = {
    { tag = 'Nouveau', text = "Barre d'aide en bas de l'écran : noclip (molette = vitesse, Ctrl, Maj) et cabine de vêtements." },
    { tag = 'Changé', text = "Les infos d'un joueur, l'argent, les papiers et la plaque s'affichent dans une fiche à côté du menu, plus en notification." },
    { tag = 'Nouveau', text = "Menu ALT en cascade, épuré (nouvelle version par défaut).", module = 'interface' },
    { tag = 'Nouveau', text = "Bannière des menus : le W se dessine, le texte suit le menu ouvert (Menu admin, Menu police…).", module = 'menus' },
    { tag = 'Nouveau', text = "Menu staff : Chuchoter, message que seul le joueur reçoit (voix privée en option).", module = 'staff' },
    { tag = 'Changé', text = "Le W de Shadow Base est le logo par défaut du panel.", module = 'general' },
} })
N.Add({ id = 'patch42', date = '2026-10-18', title = 'Patch notes 42 : organisations, starter pack, véhicules de gang', items = {
    { tag = 'Nouveau', text = "Carte du jeu › Entreprise / organisation : tu remplis les infos, puis tu es guidé en jeu pour poser le point coffre, le point boss, le rangement des véhicules et la sortie du garage.", module = 'carte' },
    { tag = 'Nouveau', text = "Module Organisations : création d'un gang avec ses grades, liste (membres, véhicules, caisse), réglages.", module = 'orgs' },
    { tag = 'Nouveau', text = "Starter pack à la création : objets dans le coffre, argent dans la caisse et trois véhicules de départ (tout est réglable).", module = 'orgs' },
    { tag = 'Nouveau', text = "Garage de gang : tu y retrouves tes véhicules et ceux de l'organisation ; les membres ont la clé des véhicules du gang.", module = 'garage' },
    { tag = 'Nouveau', text = "Donner un de tes véhicules à l'organisation, le reprendre, et le chef peut attribuer un véhicule du gang à un membre.", module = 'garage' },
    { tag = 'Nouveau', text = "Panel : ajouter un véhicule neuf à une organisation ou en attribuer un existant (par plaque).", module = 'orgs' },
    { tag = 'Changé', text = "Un garage de gang n'apparaît (carte, marqueur, touche E) que pour les membres de ce gang.", module = 'garage' },
} })


N.Add({ id = 'patch43', date = '2026-10-20', title = 'Patch notes 43 : extensions, staff, PNJ, correctif images', items = {
    { tag = 'Nouveau', text = 'Extensions : une autre ressource se branche sur Shadow Base (pages, réglages, actions, permissions). Module Extensions.', module = 'extensions' },
    { tag = 'Nouveau', text = 'Menu staff : « Libérer de prison » et liste des détenus dans Gestion des sanctions.' },
    { tag = 'Nouveau', text = 'Monde : supprimer les PNJ et les PNJ police (activés par défaut).', module = 'world' },
    { tag = 'Correctif', text = "Envoyer une image depuis le PC (bannière, logo) ne déconnecte plus." },
} })
N.Add({ id = 'patch44', date = '2026-10-20', title = 'Patch notes 44 : activités, blips, inventaire, territoires, HUD', items = {
    { tag = 'Nouveau', text = 'Activités ouvertes à tous (pêche, mine, bois, agriculture, cueillette, décharge, craft), posées au Builder.', module = 'wb_activites' },
    { tag = 'Nouveau', text = 'Blips : coffres en dégradé aux couleurs du serveur, QG de gang, vraie icône Burger Shot.' },
    { tag = 'Nouveau', text = "Message en entrant dans un territoire ; HUD faim / soif / micro et barres vie / armure." },
    { tag = 'Correctif', text = "Fond de l'inventaire : le jeu se voit derrière (plus noir opaque)." },
} })
N.Add({ id = 'patch45', date = '2026-10-20', title = 'Patch notes 45 : portes, menu boss, builder, GPS, animations', items = {
    { tag = 'Nouveau', text = 'Portes verrouillables par groupes (F10 › Builder › Portes ou /portes).', module = 'wb_portes' },
    { tag = 'Nouveau', text = 'Gestion des entreprises et organisations seulement au point boss.' },
    { tag = 'Nouveau', text = 'Builder : supprimer un point ou tous les points ; GPS dans le F5 ; animations manger et boire.' },
    { tag = 'Correctif', text = 'Burger Shot : menus qui clignotaient, client PNJ mal placé ; menu F2 retiré (tout est dans ALT).' },
} })
N.Add({ id = 'patch46', date = '2026-10-20', title = 'Patch notes 46 : points de métier pour toutes les entreprises', items = {
    { tag = 'Nouveau', text = 'Builder : accueil, atelier (garages), cuisine / bar et comptoir de vente selon le métier.', module = 'carte' },
} })
N.Add({ id = 'patch47', date = '2026-10-20', title = 'Patch notes 47 : agence immobilière, mises à jour', items = {
    { tag = 'Nouveau', text = 'Agence immobilière : annonces, intérieurs, visites et commission (menu ALT des agents).' },
    { tag = 'Nouveau', text = 'Module Mises à jour : nouvelles versions signées, patch notes et téléchargement gratuit.', module = 'updates' },
} })

N.Add({ id = 'patch48', date = '2026-10-21', title = 'Patch notes 48 : écran de chargement', items = {
    { tag = 'Nouveau', text = 'Écran de chargement : logo, barre de progression et bandeau de messages qui défile (ressource wb_loading).' },
} })
N.Add({ id = 'patch49', date = '2026-10-21', title = 'Patch notes 49 : la base devient Shadow Base', items = {
    { tag = 'Nouveau', text = 'Nouveau nom et nouveau logo : Shadow Base.', module = 'general' },
} })
N.Add({ id = 'patch50', date = '2026-10-21', title = 'Patch notes 50 : corrections, journal des expulsions, vestiaires, braquages', items = {
    { tag = 'Nouveau', text = "Journal des expulsions et bans : raison précise, origine et référence pour chaque kick.", module = 'kicks' },
    { tag = 'Correctif', text = "Anticheat : plus d'éjections pendant un restart ou un lag.", module = 'general' },
    { tag = 'Correctif', text = "Staff affiché hors ligne, touches des menus, onglets vides, suppression des anciens points.", module = 'general' },
    { tag = 'Nouveau', text = "Vrais vestiaires d'entreprise et de gang, vendeurs derrière le comptoir et braquages animés.", module = 'general' },
} })
N.Add({ id = 'patch51', date = '2026-10-21', title = 'Patch notes 51 : petits jobs, vraie pêche, vendeurs derrière le comptoir', items = {
    { tag = 'Nouveau', text = "Petits jobs pour chaque entreprise (touche O) : livraisons, taxi, dépannage, patrouille, secours, chantiers…", module = 'general' },
    { tag = 'Nouveau', text = "Pêche : raretés de poissons et de leurres, cannes, ferrage, marché aux prix variables, records.", module = 'general' },
    { tag = 'Correctif', text = "Vendeurs placés derrière le comptoir dans toutes les supérettes, magasins comme braquages.", module = 'shops' },
    { tag = 'Correctif', text = "Menotté : plus d'animations ; saisies au casier ; annonces visibles dans le chat ; couleur des gangs.", module = 'general' },
} })
N.Add({ id = 'patch52', date = '2026-10-21', title = 'Patch notes 52 : coiffeur / barbier, bandeau de démarrage', items = {
    { tag = 'Nouveau', text = "Coiffeur / barbier : coupe, couleurs, barbe, sourcils, maquillage, aperçu en direct. Builder › Commerces.", module = 'shops' },
    { tag = 'Nouveau', text = "Au démarrage, la console affiche la version, le numéro du dernier patch notes et l'état de la licence.", module = 'general' },
} })
N.Add({ id = 'patch53', date = '2026-10-21', title = 'Patch notes 53 : moins de métiers, Builder plus rapide, Auto Exotic, packs', items = {
    { tag = 'Amélioré', text = "Catalogue court : 14 entreprises utiles (dont Auto Exotic) ; les inutilisées sont retirées.", module = 'biz' },
    { tag = 'Amélioré', text = "Builder : Entrée pose le point tout de suite ; icône du siège au choix ; patron choisi parmi les joueurs connectés.", module = 'carte' },
    { tag = 'Nouveau', text = "3 packs de départ pour les organisations, donnés à la création.", module = 'orgs' },
    { tag = 'Correctif', text = "Points accueil / atelier / cuisine et points du Burger Shot : posés, affichés et supprimables.", module = 'carte' },
    { tag = 'Amélioré', text = "Inventaire : cases moins vertes, fond plus transparent.", module = 'inv' },
} })
N.Add({ id = 'patch54', date = '2026-10-21', title = 'Patch notes 54 : grosse optimisation, noms et ID réservés au staff', items = {
    { tag = 'Amélioré', text = "Noms, grades et ID visibles par le staff seulement (étiquettes, menu ALT, inventaire).", module = 'tags' },
    { tag = 'Amélioré', text = "Optimisation client et serveur : boucles allégées, moins d'envois réseau.", module = 'monitor' },
    { tag = 'Correctif', text = "Blips des entreprises : couleur, taille et portée rétablies.", module = 'carte' },
} })
N.Add({ id = 'patch55', date = '2026-10-22', title = 'Patch notes 55 : VIP, tatoueur, chasse, braquages, logements, animaux', items = {
    { tag = 'Nouveau', text = "VIP (menu staff, /vip, panel) : multi-personnages, animaux de compagnie, meubles, canne et leurres VIP, bonus de revente.", module = 'vip' },
    { tag = 'Nouveau', text = "Salon de tatouage, chasse, braquages (cambriolages, receleur, distributeurs, GoFast, fourgons blindés).", module = 'shops' },
    { tag = 'Nouveau', text = "Logements : impôt foncier, colocation, sonnette, intérieurs instanciés, meubles et aquarium.", module = 'housing' },
    { tag = 'Amélioré', text = "Builder (fantôme, Ctrl+Z), inventaire (tri, recherche, coffre), vestiaires, spectateur, événements programmés.", module = 'events' },
    { tag = 'Amélioré', text = "Optimisation : panel chargé à la demande, images allégées, purge des journaux, index.", module = 'monitor' },
} })
N.Add({ id = 'patch56', date = '2026-10-22', title = "Patch notes 56 : atelier d'armes, portes en ALT, menu ALT admin, VIP dans F5", items = {
    { tag = 'Nouveau', text = "Atelier d'armes clandestin (wb_armes) : ateliers cachés, pièces, plans, niveau d'armurier, finition, mini-jeu, marché noir.", module = 'extensions' },
    { tag = 'Nouveau', text = "Portes en ALT pour le staff : porte surlignée, choix des entreprises et gangs qui gardent l'accès, avec recherche.", module = 'ctx' },
    { tag = 'Nouveau', text = "Menu ALT staff : DV, pneus crevés, faire descendre, occupants avec ID, donner un véhicule, mute chat et micro, TP.", module = 'ctx' },
    { tag = 'Amélioré', text = "Carte « Mon VIP » dans le menu F5 : statut, date de fin, avantages.", module = 'personal' },
    { tag = 'Corrigé', text = "Invites E des extensions (pêche, chasse…) bloquées, envoi d'images depuis le PC bloqué, invite E hors de l'écran.", module = 'general' },
} })
N.Add({ id = 'patch57', date = '2026-10-22', title = 'Patch notes 57 : entreprises sur mesure et toutes les icônes de la carte', items = {
    { tag = 'Nouveau', text = "Entreprises sur mesure : nom libre, fonctionnement de n'importe quel type (mécano, café, bar, taxi…), créées au Builder ou dans le panel.", module = 'biz' },
    { tag = 'Nouveau', text = "Sélecteur des 965 icônes de GTA avec aperçu, recherche et couleur, pour le siège des entreprises.", module = 'biz' },
    { tag = 'Amélioré', text = "Type de fonctionnement et icône modifiables après coup ; les petits jobs suivent le type choisi.", module = 'biz' },
} })
N.Add({ id = 'patch58', date = '2026-10-22', title = 'Patch notes 58 : appels vocaux au téléphone', items = {
    { tag = 'Nouveau', text = "Appels vocaux (pma-voice) : application Appels avec clavier, appels récents et manqués ; bouton Appeler sur les contacts et les conversations.", module = 'phone' },
    { tag = 'Nouveau', text = "Appeler un service de l'annuaire : tous les employés en service sonnent, le premier qui décroche prend l'appel.", module = 'phone' },
    { tag = 'Nouveau', text = "Bandeau d'appel en haut de l'écran, sonnerie, téléphone à l'oreille ; /decrocher et /raccrocher.", module = 'phone' },
    { tag = 'Sécurité', text = "Canaux d'appel tirés au hasard et surveillés : un joueur qui tente d'écouter l'appel d'un autre est retiré et journalisé.", module = 'phone' },
} })
N.Add({ id = 'patch59', date = '2026-10-22', title = 'Patch notes 59 : radio F4, tickets Discord, anti-duplication, chronologie', items = {
    { tag = 'Nouveau', text = "Poste radio sur F4 : fréquence au pavé ou aux flèches, volume retenu, raccourcis vers les canaux de ton métier ; parler avec Verr. Maj.", module = 'radio' },
    { tag = 'Nouveau', text = "Tickets : /ticket (catégorie, conversation, suivi), /report devient un ticket ; le staff répond dans le panel ou directement sur Discord.", module = 'tickets' },
    { tag = 'Nouveau', text = "Anti-duplication : alerte quand un joueur gagne trop d'argent ou reçoit trop d'objets en 1 h (staff en service + Discord).", module = 'vigil' },
    { tag = 'Nouveau', text = "Chronologie d'un joueur : connexions, argent, objets, sanctions, tickets, expulsions et journal sur une seule ligne du temps.", module = 'vigil' },
    { tag = 'Nouveau', text = "Téléphone : partager sa position par message (bouton « Y aller ») et haut-parleur pendant un appel.", module = 'phone' },
    { tag = 'Corrigé', text = "Champs du panel refusés à tort (« format invalide ») : une touche comme F4 pour le noclip, les identifiants, les listes « nom|valeur ».", module = 'general' },
    { tag = 'Changé', text = "F4 n'est plus le raccourci staff « téléportation au point GPS » (à reprendre dans Staff › Raccourcis si besoin).", module = 'staff' },
} })
N.Add({ id = 'patch60', date = '2026-10-22', title = 'Patch notes 60 : bar et discothèque, télévisions, 911, conférences, coma', items = {
    { tag = 'Nouveau', text = "Bar, discothèque, café : le barman prépare au bar (ingrédients payés par la caisse) puis sert un client avec ALT ; le client accepte et paie.", module = 'biz' },
    { tag = 'Nouveau', text = "Télévisions : ALT sur un écran, puis un lien YouTube ou Vimeo ; tout le monde autour voit et entend la même vidéo.", module = 'tv' },
    { tag = 'Nouveau', text = "Téléphone : SOS 911 (police et secours sonnent et reçoivent ta position), conférence à plusieurs, numéros bloqués, groupes de discussion.", module = 'phone' },
    { tag = 'Nouveau', text = "Faim ou soif à 0 : coma (réanimation par les secours possible), avec un avertissement sous 10 %.", module = 'hud' },
    { tag = 'Nouveau', text = "Builder : dupliquer un point, déplacer tous les points d'un coup, « y aller » avec vérification du sol ; panel › Points posés (carte et problèmes).", module = 'pointsmap' },
    { tag = 'Amélioré', text = "Garage et téléphone : carburant, moteur et carrosserie de chaque véhicule, et bouton Localiser.", module = 'garage' },
    { tag = 'Amélioré', text = "Menu F10 : recherche unique (joueur, ID, plaque, numéro). Économie : gains par heure et par activité.", module = 'staff' },
} })
N.Add({ id = 'patch61', date = '2026-10-22', title = 'Patch notes 61 : points et étiquettes, garage avec aperçu, noclip fantôme', items = {
    { tag = 'Changé', text = "Plus de flèches : un petit point lumineux marque chaque endroit où interagir, et l'étiquette « [E] GARAGE » s'affiche dessus, dans le monde.", module = 'hud' },
    { tag = 'Nouveau', text = "Garage en menu : en descendant sur un véhicule, il apparaît en transparence à la sortie, avec une caméra.", module = 'garage' },
    { tag = 'Corrigé', text = "Fourrière : la récupération marche même sans point de sortie ou si le véhicule est resté en ville ; tu es mis au volant.", module = 'garage' },
    { tag = 'Amélioré', text = "Noclip : invisible pour tous les joueurs, tu te vois en transparence (ton véhicule aussi).", module = 'staff' },
} })
N.Add({ id = 'patch62', date = '2026-10-22', title = 'Patch notes 62 : atelier mécano facturé, customisation en direct, menu Shadow retravaillé', items = {
    { tag = 'Nouveau', text = "Customisation dans le véhicule : peintures (classique, mat, métal, chrome, nacré, teinte libre), jantes, carrosserie, Benny's, performances, xénons, néons, fumée, vitres, plaque, klaxon, livrée — chaque option s'affiche sur la voiture.", module = 'mech' },
    { tag = 'Nouveau', text = "Devis puis facture au client : il paie (la caisse de l'entreprise encaisse) ou refuse (la custom est retirée). Réparer et nettoyer depuis F5 › Mon entreprise, facturés pareil.", module = 'mech' },
    { tag = 'Nouveau', text = "Mécano en service : ouvre et conduit les véhicules des clients. Tenue de service (ex. Benny's) enfilée à la prise de service, vêtements rendus à la fin.", module = 'mech' },
    { tag = 'Changé', text = "Menu Shadow retravaillé (fond, bannière, lignes et icônes de la maquette).", module = 'menus' },
    { tag = 'Corrigé', text = "Inventaire : titres en français qui ne débordent plus, plus de cadenas « Premium » dans les coffres. Portes : beaucoup plus de portes détectées en ALT (portails, grilles, portes de garage, doubles portes).", module = 'inv' },
} })
N.Add({ id = 'patch63', date = '2026-10-23', title = 'Patch notes 63 : casino et repères de la carte', items = {
    { tag = 'Nouveau', text = "Casino au Builder (Casino › Caisse / Jeu) : machine à sous, roulette, blackjack, roue de la fortune, dés, plus haut / plus bas, tickets à gratter, avec de vraies animations. Tous les tirages sont faits par le serveur.", module = 'casino' },
    { tag = 'Nouveau', text = "Jetons de casino dans l'inventaire (achetés et revendus à la caisse), loterie hebdomadaire avec cagnotte, casino de l'État ou d'une entreprise, statistiques et redistribution affichées.", module = 'casino' },
    { tag = 'Nouveau', text = "Repères : les doublons sont masqués automatiquement, les repères fantômes supprimés ; « /blips reset » ou Points posés › Repères des joueurs pour tout redessiner.", module = 'pointsmap' },
    { tag = 'Corrigé', text = "Repères qui restaient sur la carte : joueur observé par le staff, animal de compagnie, alertes 911 et secours empilées.", module = 'pointsmap' },
} })
N.Add({ id = 'patch64', date = '2026-10-23', title = 'Patch notes 64 : la ville réagit (impayés, mandats, fourrière, secours)', items = {
    { tag = 'Nouveau', text = "Factures et amendes impayées : majoration, puis saisie sur le compte (même hors ligne), puis mandat visible dans la tablette de la police.", module = 'coherence' },
    { tag = 'Nouveau', text = "Véhicule abandonné ou disparu : envoyé en fourrière, SMS au propriétaire. Messages automatiques au téléphone (Trésor public, Fourrière, Hôpital…).", module = 'coherence' },
    { tag = 'Nouveau', text = "Joueur à terre : les secouristes en service sont alertés tout seuls ; les frais d'hôpital vont à la caisse des secours, facture si le joueur n'a pas l'argent.", module = 'coherence' },
    { tag = 'Amélioré', text = "Chronologie du joueur : factures, amendes, majorations, saisies, mandats, fourrières, comas, prison, réanimations.", module = 'vigil' },
    { tag = 'Corrigé', text = "Employés restés « en service » après une déconnexion ; page Paie qui affichait toujours « payée par l'État ». Patron prévenu quand la caisse ne couvre plus la paie.", module = 'coherence' },
} })
N.Add({ id = 'patch65', date = '2026-10-23', title = 'Patch notes 65 : taxi, dépanneuse, annonces, véhicules de service, logements', items = {
    { tag = 'Nouveau', text = "Taxi : app Taxi du téléphone (commander, accepter), taximètre mesuré par le serveur, paiement automatique ou facture.", module = 'taxi' },
    { tag = 'Nouveau', text = "Dépanneuse : un mécano en service avec un plateau charge un véhicule (ALT), le décharge ou le dépose à la fourrière contre une prime pour sa caisse.", module = 'garage' },
    { tag = 'Nouveau', text = "Véhicules de service d'entreprise (clé seulement en service) et clés prêtées pour 1 à 24 h.", module = 'garage' },
    { tag = 'Nouveau', text = "Téléphone : app Annonces (vente, achat, emploi, logement…) avec Écrire / Appeler l'auteur.", module = 'phone' },
    { tag = 'Nouveau', text = "Logements : loyer prélevé même hors ligne, expulsion après les impayés tolérés, affaires mises à la consigne, dette transmise à l'agence.", module = 'housing' },
    { tag = 'Amélioré', text = "Économie › Tableau de bord ; historique récent à côté du spectateur staff ; plus d'annonces de redémarrage en double.", module = 'economy' },
} })
N.Add({ id = 'patch66', date = '2026-10-23', title = 'Patch notes 66 : Builder rangé, garages terrestres, aériens et navals', items = {
    { tag = 'Amélioré', text = "Builder (F10 › Builder) : tout est rangé en 7 sections (Entreprises, Illégal, Commerces et services, Garages et véhicules, Immobilier et coffres, Activités, Autres) avec une recherche, au lieu d'une longue liste.", module = 'carte' },
    { tag = 'Nouveau', text = "Garages créés en jeu : on pose l'entrée, la sortie du véhicule et le PNJ, étape par étape ; garage, hangar d'avions, port, et une fourrière pour chacun.", module = 'garage' },
    { tag = 'Nouveau', text = "Garages séparés par type : un avion ne se range que dans un hangar, un bateau que dans un port ; icône de carte selon le type, PNJ au comptoir.", module = 'garage' },
    { tag = 'Corrigé', text = "Le groupe Casino n'apparaissait pas dans le Builder ; nom du jeu repris du préréglage choisi.", module = 'casino' },
} })
N.Add({ id = 'patch67', date = '2026-10-23', title = 'Patch notes 67 : ville vivante (ouvert / fermé, contrats, plaques, Discord, journaux)', items = {
    { tag = 'Nouveau', text = "Entreprises ouvertes ou fermées : repère vert ou rouge sur la carte selon les employés en service, et annuaire du téléphone en direct (ouverts d'abord).", module = 'biz' },
    { tag = 'Nouveau', text = "Contrats de vente entre joueurs (app Contrats) : véhicule ou logement, signature à côté, paiement sécurisé et taxe de mutation.", module = 'economy' },
    { tag = 'Nouveau', text = "Plaques personnalisées (payantes, au garage) et fausses plaques pour les illégaux : la police ne retrouve plus le véhicule, retrait en ALT.", module = 'garage' },
    { tag = 'Nouveau', text = "Journal des morts (qui, par qui, arme, distance, position) et sauvegardes d'inventaire avec restauration à une date donnée.", module = 'kills' },
    { tag = 'Nouveau', text = "Discord ↔ personnage : rôles VIP, métier et groupe donnés et retirés tout seuls, pseudo du personnage, Discord obligatoire en option.", module = 'discordlink' },
} })
N.Add({ id = 'patch68', date = '2026-10-23', title = 'Patch notes 68 : largages, chasses au trésor, guerres de territoire', items = {
    { tag = 'Nouveau', text = "Largage : une zone est annoncée, une caisse tombe, le premier qui l'ouvre gagne argent et objets. Chasse au trésor : la zone se resserre toutes les 3 minutes, il faut creuser au bon endroit.", module = 'worldev' },
    { tag = 'Nouveau', text = "Lancement automatique (toutes les X minutes s'il y a assez de joueurs), planifié dans Événements, ou à la main depuis le panel.", module = 'worldev' },
    { tag = 'Nouveau', text = "Guerres de territoire planifiées (jour et heure) : points de présence dans la zone et d'éliminations de rivaux, tableau des scores à l'écran, la zone et la récompense au vainqueur, historique.", module = 'wars' },
} })
N.Add({ id = 'patch69', date = '2026-10-23', title = 'Patch notes 69 : grande chasse aux bugs', items = {
    { tag = 'Corrigé', text = "Duplication d'objets quand deux joueurs vident le même coffre en même temps ; aquarium et consigne qui pouvaient donner deux fois.", module = 'inv' },
    { tag = 'Corrigé', text = "Caisses (organisation, entreprise, casino, bar, atelier, missions) qui pouvaient payer deux fois ou passer dans le rouge sur un double clic.", module = 'economy' },
    { tag = 'Corrigé', text = "Garage : on ne range plus une voiture laissée ailleurs (doublon). Fourrière et atelier : la plaque est lue par le serveur, plus de saisie ou de tuning à distance.", module = 'garage' },
    { tag = 'Corrigé', text = "Location remboursée même véhicule détruit ; magasin qui encaissait sans donner l'objet ; remboursement accepté alors que le client n'avait plus les articles ; achat de logement payé sans être attribué en cas d'erreur.", module = 'shops' },
    { tag = 'Corrigé', text = "Se déconnecter menotté ne libère plus (toujours menotté à la reconnexion, police prévenue) ; virements à soi-même refusés.", module = 'biz' },
    { tag = 'Corrigé', text = "Braquages : un distributeur payé deux fois, GoFast livré avec n'importe quel véhicule. Fabrication (armes, activités) qui donnait l'objet même si les pièces manquaient.", module = 'extensions' },
    { tag = 'Corrigé', text = "Discord : synchronisations étalées (plus de limite de débit), pseudo envoyé seulement s'il change.", module = 'discordlink' },
} })
N.Add({ id = 'patch70', date = '2026-10-23', title = 'Patch notes 70 : poker entre joueurs, historique du casino', items = {
    { tag = 'Nouveau', text = "Poker Texas Hold'em entre joueurs (Builder › Casino › Jeu › Poker) : 2 à 6 places, cave en jetons, blindes, relances, tapis et pots secondaires, temps de parole, commission du casino dès le flop.", module = 'casino' },
    { tag = 'Nouveau', text = "Casino › Mes parties : bilans du jour, de la semaine et depuis toujours, jeu préféré, plus gros gain, dernières parties. Panel › Casino › Joueurs : classement des gagnants et perdants.", module = 'casino' },
} })
N.Add({ id = 'patch71', date = '2026-10-23', title = "Patch notes 71 : hélipad, où est ma voiture, meubles à vendre, tenue de service", items = {
    { tag = 'Nouveau', text = "Hélipad d'entreprise (Builder › entreprise › Hélipad) et catalogue de véhicules de service achetés avec la caisse : hélicoptères à l'hélipad, voitures au garage, bateaux au port ; revente à 50 %.", module = 'garage' },
    { tag = 'Nouveau', text = "Téléphone › Garage : où est chaque véhicule (en direct, dernière position connue, garage, fourrière la plus proche), itinéraire et repère sur la carte ; véhicules de service et clés prêtées listés aussi.", module = 'garage' },
    { tag = 'Nouveau', text = "Meubles en objets : Magasin de meubles au Builder, on pose ses meubles chez soi et ils reviennent dans le sac quand on les retire. App Contrats : vente d'objets entre joueurs (meubles et autres), paiement sécurisé.", module = 'housing' },
    { tag = 'Amélioré', text = "Tenue de service : la dernière tenue enfilée au vestiaire devient sa tenue de service ; chacun peut désactiver la tenue automatique.", module = 'biz' },
    { tag = 'Corrigé', text = "Licence : la limite de joueurs et le blocage sans licence ne s'appliquaient pas (erreur dans la connexion).", module = 'general' },
} })
N.Add({ id = 'patch72', date = '2026-10-23', title = 'Patch notes 72 : nouveau menu ALT, drapeaux de vente, tournois de poker, badge', items = {
    { tag = 'Amélioré', text = "Menu ALT refait : petite boîte bleu nuit, texte seul, barre bleue sur la ligne survolée, les catégories s'ouvrent dedans et « Retour » remonte. Les anciens styles restent au choix dans le panel.", module = 'ctx' },
    { tag = 'Amélioré', text = "Drapeaux de vente redessinés (vrai drapeau rectangulaire qui flotte dans le vent, emblème, blanc quand la zone est neutre). Plus de texte au-dessus du drapeau : l'état de la zone s'affiche sur le côté de l'écran.", module = 'flags' },
    { tag = 'Nouveau', text = "Poker : tournois (droit d'entrée, jetons de tournoi, blindes qui doublent, cagnotte partagée entre les premiers, classement dans le panel) et tables privées avec mot de passe.", module = 'casino' },
    { tag = 'Nouveau', text = "Croupiers du casino aux tables (blackjack, roulette, dés, plus haut / plus bas, poker) avec un geste à chaque donne.", module = 'casino' },
    { tag = 'Nouveau', text = "Badge d'employé : ALT › Métier › Montrer mon badge (entreprise, grade, matricule, en service ou non).", module = 'biz' },
} })
N.Add({ id = 'patch73', date = '2026-10-23', title = 'Patch notes 73 : menu ALT comme la référence, corrections', items = {
    { tag = 'Amélioré', text = "Menu ALT : large boîte bleu ardoise translucide, texte blanc bien espacé, pastille bleu cyan sur la ligne choisie, sans surlignage.", module = 'ctx' },
    { tag = 'Corrigé', text = "À la déconnexion, le joueur disparaissait avant que les autres scripts ne le lisent : le service n'était pas toujours remis à zéro et la déconnexion n'apparaissait pas dans la chronologie.", module = 'coherence' },
    { tag = 'Corrigé', text = "Points d'entreprise et sacs au sol : demandes limitées (un client modifié pouvait surcharger la base de données).", module = 'inv' },
} })
N.Add({ id = 'patch74', date = '2026-10-23', title = "Patch notes 74 : fusion 1.2.2, inventaire d'origine conservé, corrections", items = {
    { tag = 'Amélioré', text = "Tout le travail des patchs 63 à 73 est intégré (casino, poker, taxi, contrats, guerres de territoire, largages, Builder rangé…), sauf le nouvel inventaire : l'inventaire d'origine est gardé (couleur du serveur, décor assombri, flou). Les protections anti-duplication de l'inventaire sont bien reprises.", module = 'inv' },
    { tag = 'Corrigé', text = "Un serveur passé par la 1.2.2 retrouve automatiquement l'apparence d'origine de l'inventaire (une seule fois, réglable ensuite dans le panel).", module = 'inv' },
    { tag = 'Corrigé', text = "Loterie du casino : le prochain tirage pouvait être décalé d'une heure au changement d'heure été / hiver.", module = 'casino' },
    { tag = 'Corrigé', text = "Téléphone : les apps (Contrats, Annonces…) plantaient au démarrage du serveur ; Économie › Contrats ne s'ouvrait pas dans le panel.", module = 'phone' },
} })
