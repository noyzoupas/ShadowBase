# pb_panel — panneau de configuration du serveur FiveM

Un panneau translucide, ouvert en jeu (F10 ou `/panel`), qui **configure** ton serveur : il écrit dans le `server.cfg`, la base de données, les fichiers de configuration des ressources et pousse les changements vers tes scripts. Il ne remplace ni ton menu admin, ni ton framework : il s'y branche.

Thème « Spotlight » (verre sombre mauve, Poppins), quatre autres thèmes, logo du serveur en grand débordant en haut de chaque module, recherche globale (Ctrl+K), favoris, notifications.

## Installation

1. Copie le dossier `pb_panel` dans `resources/`.
2. Dépendance : `oxmysql` (obligatoire). Le framework (ESX, QBCore, Qbox) et l'inventaire (ox, qb, esx) sont détectés automatiquement ; sans eux le panel fonctionne, les modules concernés l'indiquent.
3. Dans le `server.cfg`, après `oxmysql` :
   ```
   ensure pb_panel
   ```
4. Dans `config.lua`, renseigne **au moins** ta licence propriétaire :
   ```lua
   Config.Owners = { 'license:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' }
   ```
   (ou, depuis la console serveur : `pb_grant <id> owner`).
5. Redémarre, connecte-toi, appuie sur **F10**. Les tables se créent seules (migrations versionnées).

Réglages de `config.lua` : touche/commande d'ouverture, framework, inventaire, chemin du serveur (si `server.cfg` n'est pas trouvé), superviseur (`txadmin` / `autre` / `aucun`, nécessaire aux redémarrages programmés), pont vers la librairie admin.

## Librairie admin (un seul système de grades)

Le panel **ne crée pas de menu admin, de noclip, de spectate ni de téléportation** : ta librairie les fournit déjà. Il n'y a **qu'un seul système de grades** : celui du panel, synchronisé avec ta librairie.

- `Config.AdminLib.mode = 'ace'` : chaque grade devient un groupe ACE `group.pb_<grade>` avec ses permissions et ses héritages ; le groupe d'un joueur est posé en principal. Convient aux librairies qui lisent l'ACE.
- `mode = 'export'` : le panel appelle les exports de ta librairie (`listGrades`, `saveGrade`, `deleteGrade`, `setPlayerGrade`, `listPermissions`, `setLayout`). Tous sont facultatifs ; un export non renseigné est affiché comme **non pris en charge** dans l'onglet *Compatibilité*, jamais simulé.
- Position du menu staff : glisser-déposer dans *Interface › Menu de la librairie admin*. La valeur est transmise via l'export `setLayout` s'il existe, sinon ta librairie la lit avec `exports.pb_panel:GetStaffMenuLayout()` (`{x, y, scale, opacity}` en pourcentages).
- Règle de décision des permissions : la plus précise l'emporte, à précision égale le refus gagne, une exception individuelle passe avant le grade. On ne modifie que des grades de niveau inférieur au sien et on n'accorde que des permissions qu'on possède.

## Modules

Chaque module a un onglet **Compatibilité** qui dit ce qui est réellement pris en charge sur ton serveur (pris en charge / partiel / indisponible) et un onglet **Aide**.

| Module | Ce qu'il fait |
|---|---|
| Configuration | identité (nom, slogan, couleurs, logo), `server.cfg` (formulaires + édition brute avec diff), slots, réseau, maintenance, messages, ressources à démarrer, validation, historique |
| Grades et permissions | grades, héritage, grille de permissions, équipe, exceptions par membre, permissions effectives, comparaison, synchronisation librairie admin |
| Commandes | commandes du panel, accès (ACE), usage, blocage de commandes du chat |
| Ressources | start/stop/restart/ensure, fichiers (édition avec diff et restauration), valeurs de configuration (`Config.*`), recherche, erreurs de scripts |
| Métiers / Gangs | liste, éditeur (grades, salaires), effectifs, paie, import/export (ESX : base ; QBCore/Qbox : fichiers partagés) |
| Objets | objets, images (PNG pour ox), boutiques, coffres, réglages |
| Véhicules | catalogue, véhicules joueurs, garages |
| Économie | salaires, amendes, taxes, supervision de la masse monétaire |
| Services | police / EMS / mécanos / entreprises, via détection du script |
| Cartographie | blips, marqueurs, zones, import/export, plan simplifié |
| Monde | météo, heure, densité, blackout |
| Base de données | vue d'ensemble, tables, migrations, requêtes lentes, recherche, console SQL (PIN pour l'écriture), dump/restauration |
| Journaux | audit (avant/après), connexions, erreurs, export CSV, purge |
| Sauvegardes | configuration / fichiers / base, planification, envoi distant, restauration avec somme de contrôle |
| Discord | salons, webhooks (secrets), rôles, bot |
| Sécurité | sessions, PIN, limites, secrets, événements, propriétaires |
| Monitoring | courbes joueurs/latence, alertes, détection d'arrêt brutal, redémarrage planifié, rapport de diagnostic |
| Automatisation | tâches à liste d'actions fermée, droits vérifiés à la création, historique |
| Interface | apparence (thème, verre, flou, arrondis, densité, texte, position du panneau), préférences personnelles, raccourcis, menu staff |

## Interfaces en jeu (lot 1) — mode autonome

Tout est dans la ressource `pb_panel` (aucun framework requis ; données dans `pb_players`, `pb_vehicles`, `pb_shops`) :

| Module du panel | Ce qu'il fournit en jeu |
|---|---|
| HUD | vie, armure, faim, soif, stress, endurance, micro, heure, argent, rue, boussole, compteur et carburant ; 3 styles ; position par glisser-déposer |
| Créateur de personnage | identité, hérédité, visage, cheveux, détails, vêtements ; validé par le serveur |
| Écran de mort | délai, secours, réapparition payante, perte d'argent |
| Magasins | supérettes, magasins de vêtements, concessions (catalogues modifiables) |
| Notifs, chat, menu | notifications, chat local/`/me`/`/do`/`/ooc`/`/annonce`, menu d'interaction |

Exports utiles : `AddStatus`, `GetStatus`, `AddMoney`, `RemoveMoney`, `GetMoney`, `GetIdentity`, `IsDead`, `Revive`, `Notify`, `ChatSend`, `SaveAppearance`, `GetOwnedVehicles`, `GetDeadPlayers`.

### Lot 2 — économie, entreprises, parcours serveur

| Module du panel | Ce qu'il fournit |
|---|---|
| Économie | 7 presets (équilibrée, pauvre, réaliste, RP ouvrier, hardcore, sandbox, riche) + presets personnalisés, simulateur (heures pour une voiture), retour arrière, comptes et journal ; prix, TVA, amendes, paie, impôt, intérêts, argent de départ |
| Entreprises | police, EMS, garage, générique : grades, droits, salaires, caisse, factures, amendes, dossiers, réanimation, réparation ; **tablette citoyen / patron** en jeu (touche réglable ou `/tablette`) |
| Parcours serveur | liste blanche + priorités, file d'attente en direct, écran de règlement versionné (lecture minimale vérifiée par le serveur), sessions et temps de jeu, annonces de redémarrage |
| Personnage (créateur v2) | 9 étapes, choix du point d'arrivée sur une carte, biographie, règles configurables |

Exports ajoutés : `GetJob`, `SetJob`, `IsOnDuty`, `GetBusinessBalance`, `AddBusinessMoney`, `IsWhitelisted`, `GetPlaytime`, `GetBalance`, `EcoPrice`.

### Lot 3 — inventaire, banque, véhicules, logements, téléphone, police, missions

| Module du panel | Ce qu'il fournit en jeu |
|---|---|
| Inventaire | emplacements et poids, objets configurables, utilisation (nourriture, soins…), raccourcis, jeter / donner à proximité, coffres publics ou d'entreprise |
| Banque | agences et distributeurs, dépôt / retrait / virement par IBAN, plafonds journaliers, frais, historique |
| Garages et véhicules | garages publics et d'entreprise, fourrière payante, clés partagées (doubles), verrouillage (touche réglable), dégâts et carburant conservés |
| Logements | achat ou location (loyers automatiques), accès partagés, porte verrouillable, coffre du logement, intérieur facultatif ; impayé = accès suspendu, jamais de suppression |
| Téléphone | numéro unique, contacts, messages texte, annuaire des services (les employés en service sont prévenus), signalement et modération (le staff ne lit que les messages signalés) |
| Entreprises (police) | page « Terrain » : menottes, fouille de l'inventaire d'une personne menottée, saisie d'un véhicule vers la fourrière |
| Métiers civils | missions à étapes (livraison, collecte, coursier) contrôlées par le serveur (ordre, distance, temps de trajet, délai, plafond horaire), payées par le serveur ou par la caisse d'une entreprise |

Gangs et organisations : crée une entreprise de type « Entreprise » (grades, caisse, recrutement, factures depuis la tablette).

Exports ajoutés : `AddItem`, `RemoveItem`, `GetItemCount`, `HasItem`, `CanCarryItem`, `HasKeys`, `ImpoundVehicle`, `GetVehicleState`, `HasHousingAccess`, `GetProperties`, `GetPhoneNumber`, `IsCuffed`. Évènements : `pb_panel:propertyBought`, `pb_panel:cuffed`, `pb_panel:searched`, `pb_panel:seized`, `pb_panel:missionDone`, `pb_panel:impounded`, `pb_panel:impoundRecovered`.

**Limites** :
- Les scripts client n'ont pas pu être exécutés dans un vrai GTA (testés : serveur simulé et interfaces dans Chromium). Fais un essai sur un serveur de test.
- Ne lance pas deux HUD / créateurs / chats / inventaires en même temps (arrête esx_hud, qb-hud, ox_inventory, la ressource `chat`…).
- Les données sont celles du panel (`pb_players`, `pb_vehicles`, `pb_inv`…), pas celles d'ESX / QBCore : les véhicules ou objets déjà présents dans ces frameworks ne sont pas importés.
- Les coordonnées par défaut (agences, distributeurs, garages, fourrière, logements, missions) sont des lieux connus de Los Santos, **à vérifier en jeu** ; aucun intérieur de logement n'est fourni.
- Les distributeurs sont détectés côté client (les frais et plafonds limitent l'abus) ; la détection exacte d'un véhicule disparu (fourrière) demande OneSync, sinon un délai s'applique.
- Pas d'appels vocaux (il faut un script voix), pas de prison ni de transport de personne menottée, pas de métiers de récolte / craft, pas de stock pour les magasins.
- Le serveur ne peut pas se redémarrer seul : les redémarrages passent par txAdmin ou ton hébergeur.

## Auto-test : `/testall`

En jeu (grade avec la permission `selftest.run`) ou `testall` dans la console : construit chaque module et onglet, vérifie les boutons, les formulaires, les tables SQL et les tests propres à chaque module. Ne modifie rien. Rapport dans la console et dans le module **Auto-test**. Un nouveau module ajoute ses vérifications avec `PB.SelfTest.Add('nom', function(R, ctx) R.check(cond, 'où', 'message') end)`.

## Sécurité

Tous les droits sont vérifiés **côté serveur** (jeton de session, limite de débit, permission par action). Les actions sensibles demandent une confirmation, et un PIN si tu en as défini un ; elles sont écrites dans le journal d'audit avec l'état avant/après et peuvent souvent être annulées (*Historique*). Les secrets (clés, webhooks, jetons) ne sont jamais renvoyés à l'interface. Les éléments d'interface sans action valide ou sans droit sont retirés par le serveur : il n'y a pas de bouton factice.

## Limites connues

- **Aperçus et éditeurs de HUD, de créateur de personnage et d'écran de mort : non inclus.** Ils ne figuraient pas dans ta liste d'options ; le module Interface indique « Interfaces en jeu » comme *non pris en charge*.
- Le navigateur intégré de FiveM ne peut pas enregistrer de fichier : les exports s'ouvrent dans une fenêtre à **copier**.
- Les modifications de scripts tiers ne sont proposées que pour les scripts reconnus (détection ESX/QBCore/Qbox, ox/qb inventory) ; un réglage non reconnu est listé comme tel, pas modifié.
- Le plan de la carte est un schéma de points, pas les tuiles du jeu.
- Les sauvegardes sont stockées dans le dossier du serveur ; si le disque est plein, elles échouent et l'indiquent. Les envois distants passent par HTTP(S) avec les limites de taille de FiveM.
- Beaucoup de réglages (`server.cfg`, ports, slots) demandent un **redémarrage** : le panel l'indique.
- Le panel a été testé avec un simulateur FiveM (Lua 5.4 + SQLite) et Chromium pour l'interface, **pas sur un serveur FiveM réel** : fais un premier essai sur un serveur de test, avec une sauvegarde.

## Développement

`python3 tests/test_modules.py all` (serveur, ~980 vérifications), `python3 tests/test_game.py hud character shops uikit selftest eco biz flow inv bank garage housing phone police civil` (interfaces en jeu) et `/testall` en jeu et `python3 tests/test_ui.py` (interface, Chromium via Playwright). Le simulateur est `tests/fxsim.py`.

## Patch notes 4 — Menus RageUI, F2, F5, tablette, tableau de bord

**Menu « RageUI » (module Menus).** Bannière (logo texte ou image), titre + compteur, ligne de progression, sous-titre, éléments (bouton, liste, case, curseur, saisie, séparateur, sous-menu), description. Navigation aux flèches / manette + Entrée + Retour, sans souris : le joueur peut continuer à bouger. Apparence 100 % réglable dans le panel (couleurs, bannière, largeur, arrondi, position, textes, pastilles). Pour tes scripts : `exports.pb_panel:OpenMenu(def)`, `CloseMenu()`, `IsMenuOpen()`, `RefreshMenu()` (exemple dans l'onglet Développeur du module).

**F2 — actions rapides des entreprises.** Menu construit par le serveur selon métier / grade / service (police : menotter, libérer, fouiller, amende, fourrière ; secours : réanimer ; garage : réparer ; tous : service, facturer, tablette). Chaque entrée appelle l'action de la tablette : droits, service, distance et montants sont revérifiés. Liste fermée d'actions : le client ne peut rien lancer d'autre. Entrées personnalisées `libellé|description|commande`.

**F5 — menu personnel, deux affichages.** Grandes cartes avec images GTA (`web/img/cards/*.jpg`, 640×400, remplaçables) teintées par la couleur de la carte ou du serveur, ou menu RageUI. Le serveur choisit le mode par défaut ; le joueur peut choisir le sien (mémorisé sur son poste) si tu l'autorises. La touche de la tablette passe de F5 à **F6** par défaut.

**Tablettes (tablette, banque, garage, logement, téléphone).** Habillage sombre : barre haute avec statuts, carte d'identité, navigation avec compteurs, bloc « Accès rapides », carte utilisateur avec bouton de fermeture, accent = couleur du serveur ou de l'entreprise.

**Accueil du panel.** Tableau de bord : fiche du serveur, 4 indicateurs avec courbes, fréquentation, liste « À faire », joueurs en ligne, dernières actions. Chaque section n'apparaît que si le rôle a le droit de la voir.

Limites : pas de GPS pour retrouver un véhicule ou un logement ; les cartes F5 affichent l'état, pas la position. Les images GTA fournies sont des visuels de tiers : à toi de vérifier que tu as le droit de les utiliser sur ton serveur.

## Patch notes 5 — Téléphone en bas à droite, changements en direct, correctifs

- **Téléphone** : s'affiche en bas à droite de l'écran (format portrait, barre d'onglets en bas) sans masquer le jeu.
- **Changements sans redémarrage** : prix des magasins, catalogues, affichage (HUD, menus, notifications…), points, entreprises, etc. s'appliquent immédiatement. Un magasin **déjà ouvert** par un joueur se met à jour tout seul (nouveaux prix, ou fermeture si le magasin est supprimé). Les achats utilisent toujours le prix du serveur.
- Le formulaire « Liste serveur » (nom, tags…) est appliqué en direct via les convars ; la liste publique FiveM se met à jour à la prochaine annonce.
- **Ce qui exige encore un redémarrage (limites FiveM)** : slots/réseau/clés dans `server.cfg`, formulaires de langue, réglages internes d'`ox_inventory`, et les touches par défaut (FiveM mémorise les touches de chaque joueur ; ils peuvent les changer dans Paramètres › Touches).
- **Correctifs** : tables par joueur nettoyées à la déconnexion (entreprises), mise à jour d'un magasin ouvert, doublon dans la pile d'interface. Nouveau test `fuzz` : ~700 appels aberrants sur tous les évènements réseau du jeu, sans erreur ni argent incohérent.

## Patch notes 6 — Shadow Base : nouvelle identité

- Nom par défaut **Shadow Base**, couleur de base **gris blanc** (principale `#dfe2e7`, secondaire `#aab0bb`) ; modifiables dans Configuration › Identité.
- Panel redessiné : verre graphite, filets fins, accent argent, onglets soulignés, boutons argent à texte sombre (le texte s'adapte à la couleur choisie), barre active dans le menu, bandeau avec wordmark sobre.
- Thèmes : W (gris blanc, par défaut), Mauve (ancien style), Aurore, Braise, Forêt, Monochrome.

## Patch notes 7 — Panel uniforme, police de la tablette

- Rail gauche pleine hauteur (logo, navigation, profil en bas) et en-tête intégré (titre du module, recherche, notifications, fermeture) sur une seule surface de verre.
- Police **Barlow Condensed** (celle de la tablette) partout : titres en capitales espacées, boutons, onglets, formulaires. Fichiers dans `web/fonts/`.

## Patch notes 8 — Rail façon tablette
- Navigation espacée avec titres de catégories, entrée active en pilule argent, carte profil en bas ; onglets et boutons du panel sur le même modèle de pilules arrondies. Police Poppins (celle de la tablette).

## Patch notes 9 — Menu staff (F10), ordre des menus, F5

- **Menu staff en jeu (F10)**, format RageUI, construit par le serveur selon les permissions du grade (groupe `staff` dans Grades et permissions). Le staff passe d'abord **en service** (obligatoire par défaut, réglable).
  - **Joueurs en ligne** : infos, historique, aller vers / ramener, soigner, geler, observer, message, argent (espèces / banque), objet, entreprise, avertir, expulser, bannir (durées réglables).
  - **Mes outils** : noclip, invincible, invisible, noms au-dessus des têtes, course rapide, se soigner, aller au GPS / aux coordonnées / vers un ID.
  - **Véhicules** : créer (liste + modèle libre), réparer, remettre sur les roues, supprimer, nettoyer les véhicules vides.
  - **Serveur** : annonces rapides, météo, heure, soigner tout le monde, maintenance.
  - **Signalements** : les joueurs écrivent `/report message` ; le staff les voit, va vers eux, prend en charge, clôt.
  - **Sanctions** : lever un bannissement. Les bans s'appliquent à la connexion (licence et autres identifiants connus) avec le motif et la date de fin.
  - **Ouvrir le panel de configuration** : visible pour le propriétaire (et tout grade ayant `panel.open`).
- **Sécurité** : permission + service + hiérarchie (jamais d'action forcée sur un rang égal ou supérieur) + plafonds + journal à chaque action ; le client n'exécute que ce que le serveur autorise.
- **Touche F10** : le panel n'a plus de touche par défaut (il s'ouvre depuis le menu staff ou avec `/panel`).
- **Réorganiser les menus** : chaque joueur peut changer l'ordre des entrées de son menu (F10 et F5 en mode RageUI) avec « Réorganiser ce menu » ; le propriétaire fixe l'ordre par défaut dans le panel (Menu staff / Menu personnel › « Ordre »). Ex. : mettre `inventory` en dernier.
- **Menu F5** : le propriétaire choisit « grandes cartes » ou « RageUI », et décide si chaque joueur peut changer lui-même.
- Menus : couleurs par défaut passées au gris blanc ; correctif de la saisie texte du menu (libellé et longueur ignorés dans F2).
- Tests : `python3 tests/test_game.py staff menuorder`.

## Patch notes 10 — Menus en « UI » ou en « lib »

Tous les menus de la bibliothèque (F2, F5, F10…) existent maintenant en deux rendus identiques : **lib** (flèches, style RageUI) et **UI** (grandes cartes, souris + clavier).
Réglages dans le panel (Menus) : `ui_mode` (auto/lib/ui), `ui_allow_choice` (le joueur peut choisir), `ui_overrides` (`id|ui`, préfixe le plus long gagne). Commande joueur : `/menustyle`.
Le « Réorganiser ce menu » n'existe plus que dans le menu staff (F10) ; le F5 suit l'ordre défini par le propriétaire.

## Patch notes 11 — Gamertags et menu staff étendu

**Gamertags** (module « Gamertags » du panel, `server/game/tags.lua`, `client/tags.lua`, `web/game/tags.js`) : nom RP, ID, entreprise + grade, rang staff (couleur du grade, seulement en service par défaut), état « inconscient » et micro actif. Trois styles (pastille, carte, minimal), distance, nombre maximum d'étiquettes, rangs à masquer, visibilité « tout le monde » ou « staff seulement » (les autres ne reçoivent rien). Limite : l'étiquette disparaît derrière un mur (pas de vision à travers les obstacles).

**Menu staff (F10)** — nouveautés : réduire au silence (durée, motif ; relancer lève), notes privées, voir/vider l'inventaire, donner un véhicule (au garage du joueur), bannir hors ligne par licence, retour à la position d'avant la téléportation, coordonnées à l'écran, repères des joueurs sur la carte (joueurs chargés seulement), coupure de courant, `/sc` (chat staff). Nouveaux droits : `staff.mute`, `staff.notes` (donnés au modérateur / support une seule fois), `staff.inventory`, `staff.givecar` (sensibles, non donnés par défaut). Tout est vérifié côté serveur, hiérarchie respectée, journalisé.

Le « Réorganiser ce menu » n'existe plus que dans le menu staff.

## Patch notes 12 — Justice

`server/game/justice.lua`, `client/justice.lua`, `web/game/justice.js`. Panel : module « Justice et urgences » (réglages, détenus, appels, journal).
- **Prison** : minutes (1 à `max_jail`), téléportation, minuteur en ligne seulement, retour forcé hors du périmètre, peine conservée à la déconnexion, sortie à la porte. **TIG** : chantiers `x|y|z|nom`, une tâche vérifiée par le serveur (distance + délai).
- **Casier** : amendes, arrestations, saisies, notes, prison, TIG, libérations (tablette › Justice, ou F2 › Casier judiciaire). Police seulement.
- **Appels** : `/911`, `/112`, `/appel <service> <message>`, `/annuler`. Page « Appels » de la tablette : répondre, GPS, clore, et pour le répartiteur (droit `dispatch`) envoyer une unité précise. Clôture automatique après `call_ttl` minutes.
- Nouveaux droits d'entreprise : `jail`, `dispatch`. Staff : action « Prison / libérer » (droit sensible `staff.jail`).
- Limites : pas de procès ni d'avocats ; pas d'escorte à pied.

## Patch notes 13 — Menus plats, HUD épuré, compteur, gamertags, staff en service

- **Menus (lib et mode « UI »)** : même habillage plat que la capture (bannière avec logo, barre « titre · sous-titre · 1/8 », lignes séparées, ligne sélectionnée plus sombre, case à droite). Le mode « UI » ajoute la souris (survol, clic, flèches, retour/fermer). **Transparence** : *Menus › Apparence › opacité du fond* (de 10 à 100 %). Style « Classique » toujours disponible.
- **HUD** : nouveau style par défaut « Anneaux » — anneaux ronds (faim, soif, endurance, stress) à droite de la mini-carte et fine barre vie/armure dessous. Positions réglables dans l'onglet *Position*. Les 3 anciens styles restent.
- **Compteur** : refait, plat et sans néon. Vitesse, rapport, barre de carburant et **autonomie estimée en km** (carburant restant ÷ consommation moyenne). Réglages : *réservoir* (0 = valeur du véhicule) et *consommation L/100 km*. C'est une estimation : le jeu ne calcule pas de consommation réelle.
- **Gamertags** : style « Épuré » par défaut (texte seul) : gang en haut, nom + ID, entreprise · grade dessous, rang staff au-dessus. Gangs et membres : *Gamertags › Gangs* ou `exports.pb_panel:SetPlayerGang(src, 'ballas')`. Les gangs d'un framework externe ne sont pas lus.
- **Staff en service** : mini-tableau de 3 à 4 chiffres (reports ouverts, pris par moi, joueurs en ligne, sanctions 24 h), position et contenu réglables dans *Menu staff › Réglages*. Menu staff renommé : « Gestion des joueurs (N) », « Gestion des reports (N) », « Prendre mon service »…

## Patch notes 14 — Images depuis le PC, panel scindé, boutique de A à Z, interfaces « boutique »

- **Images depuis ton PC** (png, jpg, webp, gif) : champs « image » dans *Identité* (logo, bannière du serveur), *Menus* (bannière, logo), écran d'accueil, tablette et boutiques. L'image est réduite dans le navigateur puis stockée en base (max 900 Ko, 200 images) ; les joueurs la reçoivent à la demande. Aucun lien externe.
- **Panel scindé** : onglets en liste à gauche, contenu à droite ; les listes de type « maître/détail » (boutiques) comme sur la photo.
- **Boutique de A à Z** (*Boutiques*) : nom, bannière, logo, couleur, horaires, métier et grade requis, remise, mode de paiement, quantité maximale, vendeur (PNJ), catégories et articles.
- **Interfaces « boutique »** : supérette, concession, **vestiaire** et **garage** utilisent la même coque (titre en haut à gauche, rail d'icônes, recherche + liste, fiche à droite, bouton d'action en bas). Vestiaire : catégories, grille de modèles, variantes, caméra, bouton *Payer*.
- Limites : le vendeur PNJ est défini dans la boutique mais son apparition dépend du client ; pas de stock ni de vendeur joueur.

## Patch notes 15 — Menu ALT (menu contextuel)

`server/game/ctxmenu.lua`, `client/ctxmenu.lua`, `web/game/ctxmenu.js`. Panel : module « Menu ALT ».
- **Utilisation** : maintenir **ALT** (touche réglable) → la souris apparaît, un point s'affiche sur soi et sur les personnes visibles à portée ; un clic ouvre un petit menu à côté de la personne : catégories à gauche, options en volet à droite, formulaire intégré pour les montants et motifs.
- **Sur soi** : inventaire, téléphone, tablette, menu personnel, argent, animations, actions du métier, prise de service.
- **Sur les autres** : montrer ses papiers, donner de l'argent (plafond réglable), signaler ; avec un métier : facturer, menotter, libérer, fouiller, réanimer, casier.
- **Staff** : catégorie en plus (informations, historique, aller vers, ramener, soigner, geler, observer, inventaire, note, message, avertir, silence, expulser ; sur soi : menu staff, service, soin, repère, réparation), argent/ping/état de la personne. Visible selon les permissions et le service.
- **Panel** : activer/désactiver chaque entrée (soi, autres, staff), distances, touche, entrées personnalisées `libellé|description|commande|self ou other`. Couleurs, transparence et arrondi reprennent ceux des *Menus*.
- **Sécurité** : le client n'envoie que « cette entrée, cette cible » ; le serveur recompose la liste à chaque clic (distance, métier, permissions, service) et refuse le reste. Dons d'argent journalisés.
- Limites : (les véhicules et objets ont été ajoutés au Lot 18) ; points visibles à l'écran seulement sauf réglage « à travers les murs » ; un bouton d'une entrée personnalisée lance une commande, il ne crée pas de nouvelle action.

## Patch notes 16 — Véhicules : carburant, dégâts, clés, atelier
- **Carburant** (module *Carburant*) : consommation réelle selon la vitesse et le régime, moteur qui cale à sec, pompes dans des stations (liste modifiable), prix et paiement vérifiés par le serveur. Le niveau lui-même est géré par le client (un client truqué peut tricher sur le niveau, pas sur le prix ni le paiement).
- **Dégâts persistants** : moteur, carrosserie, réservoir, pneus, portes et améliorations sont enregistrés avec le véhicule et rappliqués à la sortie du garage ; un véhicule détruit part à la fourrière.
- **Clés** : doubles de clés donnés ou repris, vérifiés à chaque verrouillage, moteur ou coffre.
- **Atelier** (module *Mécanicien*) : une entreprise de type garage, un employé en service, des pièces (moteur, freins, turbo, peinture, réparation…) payées par la caisse de l'entreprise.

## Patch notes 17 — Armes, activités illégales, territoires
- **Armes et permis** (module *Armes*) : armes et munitions sont des objets du sac, équipés par le serveur ; un permis (délivré par la police via F2 ou le menu ALT, ou depuis le panel) est exigé. Une armurerie est créée par défaut : c'est un magasin ordinaire avec l'option « permis exigé ». Les armes données par un autre script ne sont pas contrôlées.
- **Activités illégales** (module *Activités illégales*) : trois listes de points modifiables — filières (récolte → transformation → vente, drogues ou autre), braquages (gain tiré au sort, délai, policiers minimum, objet requis, alerte police) et blanchiment (taux). Les gains arrivent en *argent sale* (objet `black_money`). Le joueur reste sur place pendant une barre de progression ; le serveur contrôle le départ, la durée, la distance et les objets.
- **Territoires** (module *Territoires*) : zones prises par un gang en restant dedans ; refus si un membre du gang propriétaire la défend ou si elle est protégée ; revenus partagés entre les membres connectés du gang propriétaire.

## Patch notes 18 — Boutiques à stock, ALT élargi, gangs externes
- **Stock** (module *Magasins*, groupe « Stock et vendeur joueur ») : stock de départ et maximum par article, réapprovisionnement automatique (si la boutique n'a pas de propriétaire) ou par un employé.
- **Vendeur joueur** : une boutique peut appartenir à une entreprise : ses ventes (hors TVA) vont dans sa caisse, le magasin peut être fermé sans employé en service, et le réapprovisionnement est payé par la caisse (coût = % du prix).
- **PNJ vendeur** : le personnage défini dans la boutique apparaît à moins de 60 m (invulnérable, immobile, avec son attitude) et disparaît ensuite.
- **Menu ALT** : en plus des personnes, les **véhicules** (verrouiller, moteur, coffre, plaque ; propriétaire et fourrière pour la police en service) et des **objets du décor** réglables (distributeur, etc.).
- **Gangs externes** (module *Gamertags*) : source `native`, `qbcore` (PlayerData.gang.name) ou export d'une autre ressource ; utilisée par les gamertags, les territoires et le menu ALT.
- **À travers les murs** : réglage pour les gamertags (non / staff / tous) et pour le menu ALT (désactivé par défaut).

### Ce qui n'a pas pu être vérifié
Tout est testé dans un simulateur (serveur + interface), jamais dans un vrai FiveM. Non vérifiés en conditions réelles : l'apparition du PNJ, le rendu des points à l'écran, le comportement avec un vrai QBCore, les noms de modèles/armes de ton build.

## Scripts en doublon (ESX et autres)
Module *Scripts en doublon* (`server/game/conflicts.lua`). pb_panel est autonome : il n'a besoin que d'**oxmysql** (ESX n'est pas obligatoire). Si tu gardes ESX comme base, ce module détecte les scripts ESX qui font doublon (personnage, HUD, inventaire, garages, boutiques, métiers…) et les **arrête automatiquement** au démarrage et dès qu'ils démarrent. `es_extended`, `oxmysql` et `pb_panel` ne sont jamais touchés ; une liste « à garder » et une liste « à ajouter » sont réglables dans le panel.
- Un arrêt est temporaire : retire leurs lignes `ensure` de server.cfg (l'onglet *Détectés* affiche les lignes exactes).
- Ordre conseillé : `ensure oxmysql`, `ensure es_extended`, `ensure pb_panel`.
- Les scripts ESX tiers liront l'argent et le métier d'ESX, pas ceux de pb_panel : il n'y a pas de synchronisation.

## Pack de base (contenu de départ)

Au **premier lancement** (base vide), pb_panel installe tout seul de quoi jouer tout de suite. Rien n'est jamais écrasé : ce qui existe déjà (même identifiant ou même nom) reste tel quel. Le panel **Pack de base** (groupe Serveur) permet de le relancer sans risque.

| Élément | Contenu |
|---|---|
| Entreprises | Police de Los Santos, Shérif de Blaine, Secours, Garage Los Santos Customs, Taxi, Burger Shot, Bean Machine, Bahama Mamas (grades et salaires inclus) |
| Gangs | Ballas, Families, Vagos, Lost MC, Marabunta, Triades |
| Magasins | 10 supérettes (nourriture, boissons, bandages), 6 magasins de vêtements, quincaillerie (crochet, kit de réparation, corde, téléphone), concession Premium Deluxe (12 véhicules), l'armurerie existante |
| Garages | 3 publics de plus (Sandy, Paleto, Vespucci) et 3 garages d'entreprise (police, secours, mécano), en plus des 3 d'origine |
| Banque | 10 distributeurs en plus des 6 agences |
| Carburant | 6 stations en plus |
| Activités | Filière de recyclage légale (casse → fonderie → ferrailleur), 3 braquages en plus, laverie, objets ferraille et lingot de cuivre |
| Territoires | 4 zones en plus |

**À savoir** : les coordonnées sont des points de la carte standard, donnés de mémoire, et les noms de modèles (véhicules, vendeur) sont ceux du jeu mais non testés sur un vrai serveur. Vérifie chaque point en jeu et corrige avec « Ma position ». Pour désactiver l'installation automatique : réglage du module, ou `set pb_starter "off"` dans `server.cfg`. Le `/testall` signale un pack non installé.

## Barre staff en service

Quand tu prends ton service staff, une **barre apparaît en haut de l'écran** avec les chiffres utiles, mis à jour toutes les 4 secondes (et tout de suite quand un nouveau report arrive). Elle disparaît quand tu quittes le service.

Infos disponibles (panel › Menu staff › Réglages › « Infos affichées », dans l'ordre que tu veux, 8 au plus) : `reports` (en attente), `mine` (pris par moi), `online` (joueurs), `staff` (en service / connectés), `dead` (joueurs à terre), `police` et `ems` (en service), `queue` (file d'attente), `sanctions` (24 h). Les infos de reports et de sanctions ne s'affichent que si ton grade a le droit correspondant. Les chiffres sont calculés par le serveur ; seuls les staff en service les reçoivent.

Réglages : affichage en **barre** ou en **encart sur le côté**, distance du haut, désactivation complète. Sur un petit écran (moins de 1150 px), les libellés se cachent et il reste les icônes et les chiffres.

## Nom de la base et thèmes de fête

**Le nom de la base** se règle à un seul endroit : Configuration › Vue d'ensemble › Identité du serveur. Il change tout de suite, sans redémarrer ni rouvrir le panel, sur : le logo et le bandeau du panel, l'accueil, toutes les fenêtres de jeu à coque commune (magasins, concession, vestiaire, banque, garage, logements, téléphone), la tablette, le menu radial, l'écran de bienvenue et les messages Discord (si le nom d'affichage Discord est « Panel » ou vide). Un nom long réduit le logo texte et passe à la ligne au lieu de dépasser. Le nom affiché dans la liste FiveM (`sv_projectName`, `sv_hostname`) reste un réglage séparé, dans l'onglet « Liste du serveur », car il demande un redémarrage.

**Thèmes de fête** : Configuration › onglet « Fêtes ».
- **Halloween** : verre violet, accent orange et violet, brume orange, toile d'araignée, chauves-souris qui traversent.
- **Noël** : verre vert sapin, accent rouge et vert, guirlande lumineuse, neige qui tombe, congère en bas.
- **Mode** : aucune, **automatique selon la date** (Halloween du 15 octobre au 1er novembre, Noël du 1er décembre au 2 janvier, changement à minuit sans rien toucher), ou forcé.
- **Appliquer aux interfaces des joueurs** : couleurs et décor dans les fenêtres de jeu et la tablette.
- **Décor animé** : désactivable ; coupé aussi pour les joueurs qui ont désactivé les animations.
- Les couleurs de la fête remplacent temporairement celles de l'identité ; les tiennes reviennent à la fin. Un membre du staff qui a choisi son propre thème dans « Mes préférences » garde le sien.
- Les deux thèmes sont aussi choisissables à la main (Interface › thème par défaut, ou Mes préférences).

Limites : le décor est du CSS (aucune image à envoyer). Les fenêtres de jeu qui n'utilisent pas la coque commune (HUD, notifications, chat) gardent leur apparence.

## Compteur de vitesse W et HUD de statut

- Nouveau compteur à cadran 270° : arc de vitesse en dégradé aux couleurs de la base, graduations qui s'allument, chiffres, rapport engagé, arc de régime moteur avec zone rouge, carburant en segments, autonomie et voyant moteur. Styles « Cadran avec fond » ou « Flottant ».
- Réglages (Panel › HUD › Apparence) : style, vitesse max du cadran (0 = auto), arc de régime, unités km/h ou mph, carburant. Position et taille dans l'onglet Position.
- Le **HUD de statut** (vie, armure, faim, soif, argent, heure, boussole, micro, rue) est **masqué par défaut** : seul le compteur s'affiche. Pour le réactiver, coche « Afficher le HUD de statut ». Les besoins (faim, soif) continuent de descendre en arrière-plan ; coupe-les dans l'onglet Besoins si tu ne les utilises pas.
- Limite : rendu validé dans un navigateur de test, pas dans un vrai FiveM (le régime vient de `GetVehicleCurrentRpm`).

### Kilométrage réel

- Le compteur affiche un **vrai kilométrage** (sous la vitesse) : la distance réellement parcourue, mesurée côté client (conducteur uniquement, téléportations ignorées) et envoyée au serveur par paquets toutes les 30 s et à la descente.
- Le serveur sauvegarde par plaque (table `pb_vehicle_odo`), plafonne chaque envoi à 100 m/s depuis le précédent, et **ne retient que les véhicules possédés** (achetés via la base). Sur un véhicule non possédé, le compteur compte seulement le trajet en cours.
- Option « Kilométrage réel du véhicule » dans Panel › HUD › Apparence ; unités km ou miles selon le réglage.
- Limite : pas de lecture/remise à zéro depuis le panel pour l'instant, et non testé dans un vrai FiveM.

### Compteur « chiffres seuls » (défaut)

Le style par défaut n'affiche plus de cadran ni d'arc : seulement la **vitesse en gros chiffres**, l'unité et le **kilométrage**. Les anciens styles « Cadran avec fond » et « Flottant » restent disponibles dans Panel › HUD › Apparence › Style du compteur.

## Armurerie en cartes (boutique d'armes)

Nouveau type de magasin **« Armurerie »** (Panel › Magasins › Nouveau › Type), avec une interface en cartes : rayons à gauche, grille de cartes avec image, prix, statistiques (dégâts, portée, cadence, chargeur), boutons **Acheter** et **Tester**.

Tout se règle depuis le panel, par armurerie :
- **Catalogue** : armes, munitions et accessoires (type, identifiant, nom, rayon, prix, image `https://…` ou envoyée depuis le PC, description, munition utilisée, boîtes offertes avec l'arme, statistiques, essai oui/non). Un catalogue complet de départ est fourni.
- **Emplacement, carte, vendeur (PNJ), horaires, accès par entreprise et grade, permis de port d'arme, moyens de paiement, remise, quantité max, stock et réapprovisionnement, entreprise propriétaire** — comme les autres magasins.
- **Essai** : durée (0 = pas de bouton Tester) et munitions de test. L'arme est mise en main, la boutique se ferme le temps de tirer (touche X pour terminer), puis se rouvre. Rien n'entre dans le sac.
- Les armes vendues sont ajoutées **automatiquement** au catalogue du module Armes et au sac (équipables, permis exigé selon le réglage « Armes et permis »). Les munitions utilisent l'objet indiqué.

Sécurité : prix, distance, permis, stock et paiement sont vérifiés par le serveur ; l'essai n'est accordé que pour une arme du catalogue de la boutique ouverte. L'armurerie par défaut non modifiée est convertie automatiquement. `/testall` vérifie les catalogues (objets du sac, noms `weapon_…`) et prévient si aucun permis n'est exigé.

Limites : noms de jeu des armes saisis de mémoire (à vérifier en jeu), pas d'accessoires montés sur l'arme (silencieux, viseurs : vendus comme objets seulement), rendu validé dans un navigateur de test et non dans un vrai FiveM.

## Correctifs : « Access denied for command add_ace » et liste blanche

- **add_ace / remove_ace refusés** : FiveM n'autorise pas une ressource à gérer les ACE sans droit explicite. Shadow Base teste ce droit une seule fois : sans lui, elle n'envoie plus aucune commande (fini les centaines de lignes d'erreur) et affiche un seul avertissement. Pour activer la synchronisation ACE, ajoute dans `server.cfg` les quatre lignes `add_ace resource.pb_panel command.add_ace allow` (et `remove_ace`, `add_principal`, `remove_principal`) — voir `server.cfg.example`. Les permissions du panel sont internes : il fonctionne avec ou sans ces lignes.
- **« Tu n'es pas sur la liste blanche »** : la liste blanche est maintenant **ignorée tant qu'elle est vide** (une liste vide enfermait tout le monde dehors). Le refus affiche **ta licence** pour que le staff puisse t'ajouter. Dépannage : `set pb_whitelist off` dans `server.cfg`, ou `pb_whitelist off` / `on` / `status` dans la console du serveur. `/testall` signale une liste blanche active mais vide.
- Si le message que tu vois n'est pas « Tu n'es pas sur la liste blanche. Candidate sur notre Discord. » (ou ton texte personnalisé), il vient d'une **autre ressource** de ton serveur (ESX/QB whitelist, etc.).

### Boutique d'armes : mise en page de référence

L'armurerie reprend exactement la mise en page de la boutique de référence : barre du haut (avatar, nom du joueur, espèces, banque, **FERMER ESC**), menu à gauche avec l'onglet actif en violet (Accueil, rayons avec icônes), grille de 4 cartes (nom, prix avec pastille, grande image, **Acheter** / **Tester**). Les statistiques apparaissent au survol. Sans image fournie, une silhouette est dessinée automatiquement (pistolet, revolver, SMG, fusil à pompe, carabine, couteau, batte, pied-de-biche, machette, munitions, accessoire). La couleur d'accent se règle dans « 3 · Apparence de l'interface » (violet par défaut).

### Liste blanche : si tu es encore bloqué

La liste blanche est **désactivée par défaut**. Si tu es refusé :
1. **Lis la console du serveur** : à chaque connexion, quand la liste blanche est activée, une ligne indique ta licence, si la liste est active, si tu y es, si tu es reconnu comme équipe/propriétaire, et la décision.
2. **Coupe-la de force** (au choix) : `Config.DisableWhitelist = true` dans `config.lua` · `set pb_whitelist off` dans `server.cfg` · `pb_whitelist off` dans la console du serveur. Redémarre la ressource.
3. Sont **toujours acceptés** : les propriétaires (`Config.Owners`, ACE `pb_panel.owner`), tous les membres de l'équipe quel que soit leur grade, et les admins ayant l'ACE `command`.
4. Si le message affiché n'est pas celui de Shadow Base (« Tu n'es pas sur la liste blanche. Candidate sur notre Discord. » ou ton texte personnalisé dans Parcours › Connexion), il vient **d'une autre ressource** de ton serveur : cherche « whitelist » dans tes ressources (`grep -ri whitelist resources/`) et arrête-la.

### « You are not whitelisted on this server » (en anglais)

Ce message **ne vient pas de Shadow Base** (les refus de Shadow Base sont en français et affichent ta licence). C'est une autre ressource de ton serveur. Pour la trouver : Windows (PowerShell, dans le dossier du serveur) `Get-ChildItem -Recurse resources | Select-String "not whitelisted" -List` ; Linux `grep -ril "not whitelisted" resources/`. Arrête-la (retire son `ensure` du `server.cfg`) ou ajoute ta licence dans sa propre liste.

**Voir ta licence** : à chaque connexion, la console du serveur affiche `[pb_panel] connexion de <nom> · license:xxxx`. Elle est aussi dans txAdmin › Players › (ton joueur) › Identifiers, et dans l'historique des joueurs de txAdmin.

## Écran de chargement, création puis règlement

Ordre d'arrivée : **écran de chargement → création du personnage → carte de bienvenue/règlement**.

- Le client attend la fin réelle du chargement (`GetIsLoadingScreenActive`, fondu écran, bascule joueur) avant d'annoncer `pb:clientReady`, puis 3 s de marge. Secours : après 60 s, l'écran de chargement est fermé de force.
- Le créateur n'apparaît donc plus pendant le chargement.
- Le règlement s'affiche **après** la création (2,5 s après validation), ou quelques instants après l'entrée pour un joueur déjà créé qui doit relire une nouvelle version du règlement.
- La bienvenue est une simple carte centrée, sans cadre ni contour. Le joueur est figé et invincible tant qu'elle est ouverte.
- L'acceptation reste validée côté serveur (lecture minimale) et enregistrée ; le refus déconnecte.
- Limite : non testé dans un vrai FiveM ; le comportement de `GetIsLoadingScreenActive` avec un écran de chargement personnalisé n'est pas vérifié (d'où le secours à 60 s).

### Si tu as arrêté des ressources ESX (spawnmanager, multicharacter, écran de chargement)

Ces ressources sont celles qui ferment normalement l'écran de chargement et font apparaître le joueur. Si elles sont arrêtées, personne ne le fait et on reste bloqué dessus. Shadow Base prend maintenant le relais : si au bout de 15 s le chargement est toujours actif, l'écran noir, ou le joueur pas apparu, il ferme le chargement (`ShutdownLoadingScreen` + `Nui`), fait apparaître le joueur (modèle freemode, place du Legion Square), refait le fondu, puis lance le créateur. Nom de ressource à surveiller aussi : une ressource d'écran de chargement avec `loadscreen_manual_shutdown 'yes'` attend qu'on la ferme, ce que Shadow Base fait désormais. Non testé dans un vrai FiveM.

## Patch notes 19 : corrections d'affichage et de jeu

- **Notifications** : elles prenaient le style de la tablette (même classe CSS `gt`), d'où le « téléphone noir ». Les toasts utilisent maintenant `tn-*`.
- **Coins carrés** : tous les `backdrop-filter` (flou d'arrière-plan) ont été retirés, CEF/FiveM les dessine avec des coins carrés. Les fonds sont simplement translucides.
- **Menu staff / lib** : le fondu d'ouverture n'est plus rejoué à chaque rafraîchissement (il faisait « disparaître puis réapparaître » le menu à chaque changement de catégorie).
- **Position du menu staff** : le réglage Interface > « Menu de la librairie admin » (x, y, taille, opacité) est maintenant transmis au jeu et appliqué au menu staff. Sans réglage enregistré, la position du panel Menus reste utilisée.
- **Écran de mort** refait : plein écran sans cadre, anneau de chronomètre, touches **E** (secours), **G** (maintenu, réapparaître) et **H** (staff).
- **Revive staff** : un staff (permissions `staff.menu` + `staff.heal`) à terre peut se réanimer avec **H** sur l'écran de mort, même hors service (sinon il ne pourrait pas rouvrir son menu). Contrôlé côté serveur, journalisé.
- **Gamertag perso** : « Afficher ma propre étiquette » est activé par défaut (une seule fois, ton choix ensuite est conservé).
- **Menu F5** : les cartes n'étaient pas cliquables (le conteneur héritait de `pointer-events:none`).
- **Panel** : plein écran (largeur 100 %, sans arrondi) et réellement transparent (verre à 0,3 ; fonds des cartes proportionnels). Réglable dans Interface. Migration unique des anciens réglages.
- **Tablettes** : fond transparent, plus d'onglets latéraux : on arrive sur des **cartes de catégories** avec leurs sous-catégories, bouton « Menu » en haut pour y revenir. Le téléphone garde sa barre du bas.
- Limites : non testé dans un vrai FiveM ; la touche H (contrôle 74) peut être prise par un autre script.

### Menu ALT (correctif)

- Les points cliquables étaient recréés ~30 fois par seconde, ce qui annulait le survol et le clic (« comme si je passais dessus 40 fois »). Ils sont maintenant réutilisés : seule leur position change. Zone de clic agrandie.
- Menu refait avec des coins bien arrondis (carte 20 px, lignes 13 px, sous-menu arrondi).

## Patch notes 20 — Panel en cartes, F5 détaillé, points stylés, inventaire refait
- Panel : l'accueil est une grille de grandes cartes par catégorie (sous-catégories visibles), un clic ouvre la page de la catégorie (cartes des modules), bouton « ← retour » dans le bandeau ; plein écran translucide en jeu.
- Menu F5 : un clic sur une carte ouvre une page de détail (plus d'infos en bas). Tablettes : bandeaux d'état supprimés.
- Menu staff étendu (kill, slap, armure, nourrir, strip, armes, nettoyage peds, options véhicule, options perso).
- Points au sol : marqueurs personnalisés (`PBG.Point` / `PBG.Zone`). Créateur : grille de cheveux. Boutiques : option `scope` (masques, vêtements…). Inventaire réécrit, transparent. Menu Alt : cibles cliquables directes.
- Limites : non testé dans un vrai FiveM ; types de marqueurs/natives écrits de mémoire ; la touche H (revive staff) peut entrer en conflit avec un autre script.

## Patch notes 21 — Panel en 3 onglets, carte du jeu, drapeaux de territoire, joueurs
- **Panel** : 3 onglets (Accueil, Configuration, Outils), sélection sans couleur, grand logo. *Outils* = raccourcis (Joueurs, Territoires, Activités illégales, Monitoring, Journaux), recherche, notifications, favoris.
- **Carte du jeu** : l'image satellite est dans `web/img/map.jpg`. Tous les blocs `type = 'map'` l'utilisent (zoom molette, déplacement, légende). Calibrage sur quelques repères : position à ~100 m près (constantes `MAPCAL` dans `web/app.js`). Cartes ajoutées : Territoires, Zones de gangs, Activités illégales, Joueurs, Cartographie.
- **Territoires (drapeaux)** — `server/game/flags.lua`, `client/flags.lua` : chaque point de vente (filière de type « vente ») a un cercle et un drapeau. Neutre = noir en bas du mât. Un seul gang dans le cercle, au moins 5 membres (réglable), 60 s : le chef récupère le drapeau (E) → le point est à lui 5 h et ses ventes y sont x2. Un rival dans le cercle annule la prise ; le gang propriétaire est prévenu quand on l'attaque. Tout est validé par le serveur et journalisé.
- **Chef de gang** : désigné dans Territoires › Chefs (ou export `SetGangBoss`), sinon le membre le plus ancien du gang.
- **Joueurs** — `server/game/players.lua` : liste en ligne, carte des positions, relever / expulser (droit `players.moderate`, journalisé).
- L'ancien module « Territoires » (zones à revenus) devient « Zones de gangs » ; il reste indépendant.
- Limites : drapeau dessiné avec les natives de tracé (mât, tissu, cercle), pas un objet du jeu ; non testé dans un vrai FiveM ; position sur la carte approximative.

## Patch notes 22 — Vitrines à cartes (boutique, concession, garage) et cartes partout
- Nouvelle vitrine `web/game/market.js` : plein écran, fond transparent, cartes avec image, prix, effets/statistiques, quantité et bouton. Utilisée par la supérette, la concession et le garage (onglets en haut pour Véhicules / Clés). L'armurerie garde sa mise en page mais prend la même peau transparente et neutre.
- Images : celles de l'article (champ « Image » du catalogue) ; sans image, illustration neutre. Véhicules : photo depuis `docs.fivem.net/vehicles/<modèle>.webp` (réglage Magasins › « Photos des véhicules », nécessite Internet côté joueur), repli sur l'illustration si absente.
- Onglet « Carte » ajouté à Magasins, Garages, Logements et Banque (carte du jeu du Lot 21).
- Limites : non testé dans un vrai FiveM ; les photos de véhicules dépendent d'un site externe.

## Patch notes 23 — Boutiques en cartes, panier, vendeur, sonnette, concession GTA
- **Interface** (`web/game/shopflow.js`, utilisée par supérette, armurerie et concession) : catégories en cartes → produits en cartes avec image → clic = fenêtre de confirmation (quantité, « Ajouter au panier ») → panier. **Chaque produit a toujours une image** : celle du catalogue, sinon une illustration fournie (`web/img/items/*.svg`, choisie d'après le nom : eau, burger, pistolet…), pour les véhicules la photo du modèle puis une image neutre.
- **Paiement par vendeur** : le bouton *Payer* est bloqué ; le client clique *Envoyer au vendeur*. Le vendeur (employé en service de l'entreprise liée au magasin) voit l'onglet **Caisse** : *Encaisser* (le client peut alors payer), *Refuser*, *Rembourser* (30 minutes, repris dans la caisse de l'entreprise, stock remis, véhicule repris), *Donner un ticket*. Après paiement le client voit son ticket.
- **Sans vendeur** : le bouton *Sonner* apparaît ; après `bell_secs` (120 s par défaut, réglable par magasin) le bouton *Payer* se débloque et le client règle seul. Si un vendeur est en service, la sonnette ne débloque rien.
- **Réglage « Paiement par vendeur »** (par magasin) : *Automatique* (vendeur seulement si une entreprise est liée — sinon paiement direct immédiat), *Toujours*, *Jamais*. L'achat direct historique reste valable en mode direct et est refusé sinon.
- **Concession** : tous les véhicules du jeu (≈640, `server/game/vehcat.lua`) rangés en catégories (option « Proposer tout le catalogue GTA », + bateaux/avions/hélicos/vélos, pourcentage de prix). Les lignes du catalogue du panel remplacent un modèle (nom, prix, image). Chaque véhicule : **Visionner** (caméra 360°, flèches, Retour), **Essayer** (durée réglable, véhicule local retiré à la fin ou si on s'éloigne trop) ou **Demander l'achat** (même circuit vendeur / sonnette).
- Sécurité : prix, stock, quantités (1 à 20 lignes), distance, droits du vendeur, double paiement, prix modifié entre l'envoi et le paiement — tout est contrôlé par le serveur ; remboursements et paiements sont journalisés. Un vendeur ne traite pas sa propre commande.
- Tests : `python3 tests/test_game.py shop2` (137 contrôles), tests d'interface mis à jour, contrôle `/testall` « boutiques: images et catalogue GTA ».
- Limites : non testé dans un vrai FiveM ; liste et noms des véhicules écrits de mémoire (un modèle absent de ta version est refusé à l'apparition) ; photos de véhicules depuis docs.fivem.net (Internet requis, sinon image neutre) ; le ticket est un reçu affiché (pas un objet du sac) ; le magasin de vêtements garde son paiement direct ; l'ancienne interface d'armurerie en liste est supprimée.

## Patch notes 24 — Gamertag « badge », couleur du nom, catalogues élargis
- **Gamertag de base = style « badge »** (comme tes captures) : badge blanc du gang (sinon entreprise, sinon rang) ; ligne `[ID] Nom Prénom | pseudo FiveM ★` ; petite barre de santé dessous. Le texte est de la couleur choisie par le joueur et **devient bleu quand il parle**. Les anciens styles restent disponibles ; une installation existante passe au badge une seule fois (ensuite ton choix dans le panel est conservé).
- **Panel › Gamertags › Réglages** : style, couleur par défaut, couleur « il parle », choix de couleur à la création (oui/non), pseudo FiveM, préfixe (`[{id}]`, variables `{id}` `{job}` `{gang}`), barre de santé, étoile (staff en service).
- **Création du personnage** : choix de la couleur du nom (10 pastilles + sélecteur libre), aperçu en direct ; enregistrée côté serveur (colonne `tagcolor`, format `#RRGGBB` validé).
- **Armes** : catalogue par défaut de l'armurerie passé à ~75 armes + 7 types de munitions (pistolets, fusils d'assaut, mitraillettes, snipers, pompes, armes lourdes, explosifs, armes blanches), chacune avec son illustration. Bouton « Ajouter toutes les armes du jeu manquantes » pour une armurerie existante. Limite du catalogue portée à 150.
- **Véhicules** : 658 modèles, classe « Militaires » ajoutée (visible avec « bateaux, avions… »).
- Limites : le sens de « U 5 | T 34 » de ta capture m'est inconnu : par défaut le préfixe affiche l'ID, à adapter dans le champ préfixe ; la barre est la santé (l'autre sens possible : voix) ; noms d'armes et de véhicules écrits de mémoire d'après tes grilles — tout modèle absent de ta version du jeu est ignoré ; non testé dans un vrai FiveM.

## Patch notes 25 — Images dans le jeu
Les images (cartes, produits, armes, véhicules) sont maintenant déclarées **une par une** dans `fxmanifest.lua` (`files`), comme `map.jpg` qui s'affichait déjà, au lieu de globs de sous-dossiers. Un auto-test `/testall` vérifie qu'aucun glob image ne revient et que chaque fichier existe. Après mise à jour : `restart pb_panel` (ou `refresh` puis `ensure`), puis vider le cache NUI (F8 → `nui_devtools` si besoin). Non testé dans un vrai client FiveM.

## Patch notes 26 — Nettoyage des ressources arrêtées
Au **premier démarrage**, le panel liste (console + panel › Pilotage › **Nettoyage**) les ressources à l'état *arrêtée*. **Rien n'est modifié sans ton accord** : bouton « Désactiver » / « Tout désactiver » (avec confirmation, permission `cleanup.apply`) ou console `pb_cleanup apply`. Autres commandes console : `pb_cleanup list | skip | restore <nom>`.
- « Supprimer » = **désactiver** : le `fxmanifest.lua` du dossier est renommé en `fxmanifest.lua.pb-off` (la ressource disparaît du serveur, rien n'est effacé, **Restaurer** la remet). Lua ne sait ni lister ni effacer un dossier : pour libérer la place, supprime le dossier à la main.
- Jamais proposées : le panel, `oxmysql`, les ressources système (`[cfx-default]`, chat, spawnmanager…), celles non arrêtées, celles dont dépend une ressource active, celles marquées « Garder ».
- Chaque action est journalisée. `/testall` vérifie que le renommage de fichiers est possible sur le serveur. Non testé sur un vrai serveur FiveM (testé avec de vrais dossiers temporaires dans la simulation).

## Patch notes 27 — Retours de test (boutique, interface, HUD, organisations)

- **Boutique de vêtements** : le vendeur se choisit parmi 3 cartes avec tête (vendeur, vendeuse, costume) ; l'ancien « modèle vendeur invalide » est converti.
- **Opacité** : réglage « Interface › Opacité » à niveaux prédéfinis, appliqué au panel et à tous les écrans plein cadre du jeu (inventaire, tablette, banque, garage, logement, menu).
- **Notifications** : simples — texte + barre de temps, sans cadre.
- **Invite « Appuyez sur E »** en haut à gauche ; **textes 3D au-dessus de la tête** automatiques à chaque action (onglet Interface › 3D) ; **menu Alt** restylé (curseur main, entité survolée semi-transparente).
- **Inventaire** refait d'après la photo (catégories en pastilles) ; **bannière de zone** au milieu à droite ; **HUD photo** (gris, vert quand on parle).
- **Territoires** : drapeau sans tissu (mât dessiné), cercles de zone très fins.
- **Organisations natives** (`server/adapters/framework.lua`, tables `pb_org_*`, migration 170) : métiers légaux et gangs illégaux fonctionnent sans framework, et les gangs sous ESX (qui n'en a pas). Plus d'erreur « ESX n'a pas de ressource gangs » ; les compatibilités n'affichent plus de ligne rouge. Les gangs créés alimentent l'étiquette au-dessus de la tête.
- **Fiche joueur** (Joueurs › Fiche joueur) : `players.setrank` (tous les grades staff), `players.setjob`, `players.setgang`, avec le droit `players.sheet`, journalisés.
- Tests : `python3 tests/test_game.py orgs` (43), plus les suites existantes.
- Limites : rien n'a été vérifié dans un vrai client FiveM (textes 3D, alpha d'entité, cercles DrawLine, détection radio pma-voice non testés en jeu). Le « violet de l'historique » n'a pas été reproduit : seul le thème Halloween en était la source possible (passé en orange).

## Patch notes 28 — Drapeau, flèches, inventaire avec personnage, dons par glisser-déposer

- **Drapeau** : plus de mât blanc ni de prop ; seul le drapeau est dessiné (noir en bas, il monte pendant la capture et prend la couleur de l'organisation), tenu par un fil de mât très fin et sombre.
- **Flèche flottante** (`PBG.Arrow`) : pendant ALT, une flèche monte et descend au-dessus de chaque cible (personne, véhicule, objet), plus grande sur celle qu'on survole. Réglage « Flèche flottante sur les cibles » dans Menu ALT. Les points d'interaction gardent leur flèche animée.
- **Inventaire avec ton personnage** : à l'ouverture, une caméra de face montre ton vrai personnage au milieu (fond légèrement transparent). Un objet « Vêtement » (Inventaire › Objets : emplacement, modèle, texture) s'enfile avec « Enfiler » et se voit tout de suite sur le personnage ; « Retirer » le remet comme avant. L'état est serveur (table `pb_inv_worn`, migration 171) et se réapplique à la connexion.
- **Gens à proximité** à droite : fais glisser un objet sur une personne pour le lui donner (mêmes contrôles serveur que le don existant : distance, poids, journal). La liste se met à jour toute seule.
- Limites : non vérifié dans un vrai client FiveM. La caméra, l'application des vêtements et le retour à l'apparence d'origine (valeurs de base conservées par session) ne sont testés qu'en simulation ; les numéros de modèle de vêtements dépendent de tes packs.

## Patch notes 28 (suite) — Mât en objet, flèche d'interaction

- Le mât redevient un objet du jeu **sans drapeau intégré** (`prop_pole_01a` par défaut, réglable dans Territoires › Drapeaux ; si le modèle est introuvable, un fil sombre le remplace). Le drapeau reste comme au début : noir tout en bas, il monte et prend la couleur de l'organisation.
- La flèche n'est plus dans le menu ALT : elle marque les **points d'interaction** (coffre, banque, garage, boutique…). Grande flèche qui monte et descend + anneau discret ; on s'approche, on voit la flèche, E pour interagir.
- Limite : le nom du modèle de mât n'a pas pu être vérifié sans le jeu ; s'il affiche un drapeau ou rien, change-le dans le panel.

## Patch notes 29 — Service staff, gestes, hors ligne, photos, radio, menu ALT

- **Ped de service par grade** et **blocage des accès joueur en service** : deux réglages indépendants (`staff.duty_ped_on` / `duty_peds`, `staff.duty_block`), modifiables dans le menu staff (Réglages du service) ou dans le panel. Le blocage coupe inventaire, métier, téléphone, banque, garage, logement, boutiques ; les outils staff restent ouverts.
- **Squelette** dessiné à travers le ped (noclip ou non).
- **Reports** : prendre un report téléporte sur le joueur en noclip, le joueur voit « Modérateur Jean Dupont a pris votre demande », une pastille « Suivi » sous la barre staff ouvre la fiche (Alt + clic), la notification d'un nouveau report s'ouvre à l'Alt, un joueur en prison ne peut plus signaler. La liste des joueurs affiche le nom RP.
- **Menu ALT** : portée 15 m ; Escorter / Lâcher et Mettre dans le véhicule (police en service ou staff) sur une personne menottée ; Sortir la personne menottée, Retourner le véhicule, Crocheter (crochet en poche) sur un véhicule ; Animations en direct sur soi ; Réanimer et Mettre en prison pour le staff.
- **Radio réservée** (`server/game/radio.lua`, panel **Serveur › Radio**) : plages `Libellé|de|à|qui` (ex. `Police|1|10|police`) contrôlées via `addChannelCheck` de **pma-voice** (seul système pris en charge). Désactivée par défaut. Export `CanUseRadio(source, canal)`.
- **Gestes** (`server/game/gestures.lua`, `client/gestures.lua`) : plus de 60 gestes rangés en 8 thèmes (vie, déplacement, apparence, animations, médias, troll, véhicule, écran). Menu staff › joueur › Gestes, et panel **Joueurs › Gestes**. Droits `staff.gestures` (modérateurs par défaut), `staff.troll` (troll, ped, médias plein écran) et `staff.screen` ; le rang du joueur est vérifié, durées plafonnées (120 s par défaut), cadence limitée, chaque geste est journalisé. Les médias (image/son/vidéo) n'acceptent que des adresses `https://` d'hôtes autorisés (Joueurs › Gestes › Hôtes de médias) : désactivés tant que la liste est vide.
- **Vue d'écran** : capture ou direct (images toutes les 2,5 s, 90 s maximum), nécessite **screenshot-basic** ; sans lui, message d'indisponibilité. Seules des images `data:image/jpeg` de moins de 900 Ko sont acceptées. Option pour prévenir le joueur. Le direct s'affiche en jeu ; le panel (Joueurs › Écran) affiche la dernière capture.
- **Joueurs hors ligne** (Joueurs › Hors ligne › Fiche) : identité, argent, grade staff, sanctions ; actions `players.off.setrank`, `.money`, `.warn`, `.ban` (droits `players.sheet`, `staff.money`, `staff.warn`, `staff.ban`, rang vérifié, journalisées).
- **Photos** (`server/game/photos.lua`) : portrait du personnage (capture du visage via screenshot-basic, réduite à 112 px dans l'interface, validée côté serveur), sinon photo Discord (adresse du CDN officiel, nécessite le jeton du bot). Affichées dans la liste des joueurs du panel, la liste hors ligne, la fiche et l'en-tête du menu ALT.
- Tests : `python3 tests/test_game.py lot29c` (radio, 69) et `lot29d` (gestes, écran, photos, hors ligne, 147), `lot29a`, `lot29b`, plus l'interface (`tests/test_ui.py`).
- Limites : rien n'a été vérifié dans un vrai client FiveM. Les noms d'animations, de sons et de modificateurs d'écran sont des valeurs courantes du jeu, non essayées en jeu. La radio dépend de `addChannelCheck` (pma-voice récent). La vue d'écran et le portrait dépendent de screenshot-basic ; la photo Discord, du jeton du bot. Le menu Alt+clic sur la pastille de suivi n'a pas pu être testé avec une vraie souris.

### Lot 29 (refonte d'après tes captures) — inventaire, menu Alt, HUD

- **Inventaire** refait : plein écran sans voile ; onglets (Aucun, Consommables, Armes, Vêtements, Divers) ; « Inventaire » puis « Sac » en grilles de 5 colonnes avec poids et barre fine ; fiche de l'objet (quantité, poids unitaire, poids total) sous les grilles ; vêtements portés autour du personnage ; raccourcis N°1 à N°10 (croix rouge si vide) ; « Joueurs à proximité » à droite. En jeu, le ped de chaque joueur proche est **copié** et aligné à droite, face à la caméra ; on glisse un objet sur lui pour le donner (grisé et refusé s'il est trop loin). Réglage `near_show` (10 m) dans Inventaire. Sans copie possible, des pastilles avec photo remplacent les peds.
- **Menu Alt** refait : boîte bleu marine, liste de textes, barre bleue à gauche de la ligne visée, « Retour » en dernière ligne, saisie intégrée dans la boîte. La main (curseur) est celle de la capture.
- **HUD** : colonne placée juste à droite de la mini-carte (16,4 % depuis la gauche).
- Limites : disposition vérifiée uniquement sur des rendus Chromium (1920×1080 et 1280×720), pas dans FiveM. Les copies de peds (`ClonePed`), leur placement par rapport à la caméra et leur projection à l'écran n'ont pas pu être essayés. Les cases rouges rayées de la capture (emplacements verrouillés) ne sont pas reproduites. Le logo du serveur en haut n'est pas ajouté.

### Lot 29 (suite) — copies de peds plus soignées
Les joueurs proches apparaissent en fondu (légèrement décalés), regardent la caméra, reçoivent une lumière douce, et la caméra de l'inventaire applique un léger flou d'arrière-plan. Si un joueur n'est pas encore chargé chez toi, la copie est retentée une fois après 1,5 s. Non testé dans un vrai client : `ClonePed`, `TaskLookAtCoord`, le flou (`SetCamDof*`) et la lumière peuvent demander des réglages.

### Lot 29 (suite) — une image pour chaque objet
Chaque objet de l'inventaire affiche une image dans sa case et dans sa fiche : celle choisie dans le panel (Inventaire > Objets > « Image » : `img/items/nom.svg` ou une adresse `https://…`), sinon l'illustration fournie selon son nom (eau, burger, armes…) ou son type (soin, outil, document, vêtement, divers). Si l'image ne charge pas, l'icône du type la remplace. Adresses vérifiées (https seulement, sans caractères spéciaux). Les illustrations fournies sont des dessins simples, pas des photos : pour de vraies photos, indique leur adresse https dans le champ « Image ».

### Lot 29 (suite) — images ox_inventory, menu Alt épuré, notifications au-dessus de la mini-carte
- **Images d'objets** : les images d'ox_inventory (196 PNG, objets, armes `WEAPON_*`, munitions `ammo-*`) sont dans `web/img/ox/`. Elles sont trouvées par le nom de l'objet (avec quelques équivalences : `soda`→sprunk, `medkit`→medikit, `id_card`→card_id…), sinon le dessin fourni selon le type. Une image choisie dans le panel (Inventaire > Objets > Image) a toujours priorité. Elles servent aussi aux magasins. **Licence** : ces fichiers viennent de https://github.com/overextended/ox_inventory (GPL-3.0 ou ultérieure) ; `LICENSE.txt`, `NOTICE.md` et `CREDITS.txt` sont joints dans le même dossier, à conserver si tu redistribues la ressource.
- **Menu Alt** : refait en carte sombre épurée (en-tête nom et sous-titre, pastille d'icône par ligne, flèche pour les sous-menus, « Retour » séparé en bas, saisie arrondie et bouton « Valider »). Sans flou d'arrière-plan (coins carrés dans FiveM).
- **Notifications** : nouvelle position par défaut « Bas gauche, au-dessus de la mini-carte » (réglage `Hauteur`, 24 % par défaut, à ajuster selon ta mini-carte). Si ta configuration avait déjà enregistré une autre position, elle est conservée : change-la dans Interface > Notifications.
- Limites : rendu vérifié uniquement dans Chromium, pas dans FiveM ; la hauteur des notifications est une estimation de l'emplacement de la mini-carte.

### Lot 30 — plus de « ressource introuvable » sans ESX
Sans ESX, QBCore ni ox_inventory, les écrans du panel qui réclamaient leurs fichiers ou leurs tables (« Ressource introuvable ou non démarrée », « Aucun framework détecté », « Aucun inventaire détecté », « Table owned_vehicles introuvable »…) utilisent maintenant les systèmes intégrés de Shadow Base :
- **Économie > Argent et salaires** : salaires, impôts, prix, banque, argent de départ (les mêmes réglages que le module « Économie (presets) », effet immédiat). **Masse monétaire** : lue dans les comptes des joueurs de Shadow Base.
- **Véhicules** : catalogue de Shadow Base (prix, noms, catégories, ajouts, retraits ; table `pb_veh_catalog`, utilisé par les concessions), véhicules des joueurs (`pb_vehicles`), garages (renvoi vers « Garages et véhicules »).
- **Objets** : objets de Shadow Base (poids, pile, type, effets, image), création, modification, suppression ; boutiques, coffres et réglages renvoient vers les modules de Shadow Base.
- **Services** (police, EMS, mécaniciens) : entreprises de Shadow Base du même type ; **Entreprises** : caisses de Shadow Base. **Configuration > Langue** : indication claire (Shadow Base est en français).
Avec ESX / QBCore / ox_inventory installés, rien ne change : ces écrans éditent toujours leurs fichiers ou leurs tables. Limites : vérifié en simulation uniquement ; les objets et véhicules de Shadow Base ne sont pas partagés avec un autre script d'inventaire ou de concession.

## Patch notes 31 — Licence

Shadow Base ne démarre qu'avec une licence signée (Ed25519, vérifiée en Lua pur).
- **Licence** : `WB1.<charge utile>.<signature>`. Placée dans `license.key` (racine de la ressource) ou `set wbase_license "WB1…"` dans server.cfg. Panel : module **Licence** (statut, activation).
- **Empreinte** : dérivée de `sv_licenseKey` (ou d'un `install.id` généré) ; une licence peut être liée à un serveur (`fp`) ou valable partout (`*`). Console : `wbase_licence`.
- **Sans licence valide / expirée / falsifiée / révoquée** : bandeau en console, `StopResource`, base de données coupée, connexions refusées. Limite de joueurs (`max`) et expiration (`exp`) respectées.
- **Révocation** : `Config.License.revocation_url` (HTTPS) → fichier signé `{at, ids, sig}` vérifié toutes les `check_hours` heures.
- **Outil de délivrance** (`wbase-licence/wlicense.py`, **à ne jamais distribuer** : contient la clé privée) : `init`, `embed`, `issue`, `list`, `revoke`, `revocation`, `verify`. Seule la clé publique est dans `server/core/license_pub.lua`.
- **Limite honnête** : du Lua lisible peut être modifié par qui possède les fichiers. La licence décourage le partage et permet de révoquer ; pour une vraie protection, utilise en plus l'escrow Cfx.re. Non testé dans un vrai client FiveM.

## Patch notes 31 (suite) — Uniquement Shadow Framework

Shadow Base ne fonctionne plus qu'avec **wframework** (ressource compagnon fournie à côté : `wframework/`).
- **server.cfg** : `ensure oxmysql` → `ensure wframework` → `ensure pb_panel`. Retire toutes les lignes ESX / QBCore / Qbox / ox_inventory et leurs scripts.
- **Garde-fou** (`server/core/exclusive.lua`, non désactivable) : `es_extended`, `qb-core`, `qbx_core`, `ox_inventory`, les inventaires externes et tout `esx_*`, `qb-*`, `qbx_*`, `es_*` sont **arrêtés** au démarrage, à leur lancement tardif et toutes les 30 s, avec un message en console. `oxmysql`, `wframework` et tes autres scripts ne sont pas touchés. Le panel (Général › Validation) signale ceux qui tournent encore.
- **Retiré** : tous les adaptateurs ESX / QBCore / Qbox (métiers en base ESX, `shared/jobs.lua` QB), ox_inventory (fichiers, boutiques, coffres, images, convars), `Config.Framework` et `Config.Inventory`, la reprise des notifications `esx:showNotification` / `QBCore:Notify`, la source de gangs « QBCore ». Les modules Métiers, Gangs, Véhicules, Économie, Services, Objets lisent et écrivent uniquement les tables de Shadow Base (`pb_org_*`, `pb_inv_items`, catalogue de véhicules…).
- **wframework** : fournit le nom, `IsReady`, et `import.lua` (`shared_script '@wframework/import.lua'`) qui expose `WF.GetMoney / AddMoney / GetJob / SetJob / AddItem / HasItem / Notify…` au-dessus des exports de Shadow Base. Il ne crée aucune table.
- **Limites** : les scripts écrits pour ESX / QBCore ne marchent pas (ils doivent utiliser `WF` ou les exports de `pb_panel`). Rien n'a été vérifié dans un vrai client FiveM : l'arrêt de ressources, l'ordre de démarrage et `import.lua` sont testés en simulation uniquement.

## Patch notes 31 (suite 2) — Panel verrouillé sans licence + panneau de licences
- **Sans licence valide**, la ressource ne s'arrête plus : elle passe en **mode verrouillé**. Base de données coupée ; seuls les propriétaires (`Config.Owners` / ACE `pb_panel.owner`) peuvent se connecter, et le panel n'affiche que le module **Licence** (toutes les autres actions et vues sont refusées côté serveur). Les autres joueurs sont refusés à la connexion.
- **Activation** : coller la licence dans Licence › Activer. Elle est vérifiée, écrite dans `license.key`, puis la ressource redémarre toute seule pour charger tous les modules. Sans accès au jeu : mettre la licence dans `license.key` ou `set wbase_license` puis `restart pb_panel`.
- **Panneau de licences (vendeur)** : `wbase-licence/panel.py` (page locale 127.0.0.1) pour créer, copier, révoquer et exporter `revoked.json`. À garder chez toi.
- Limite : si un propriétaire n'est pas défini dans `Config.Owners`, personne ne peut activer depuis le jeu ; utiliser `license.key`.

## Patch notes 32 — Modèles de métiers et de gangs

Dans **Métiers** et **Gangs**, l'onglet **Modèles** crée en un clic un groupe complet (identifiant, nom, type, grades, salaires, patron) :

- Métiers : Police, Sheriff, EMS (`ambulance`), Pompiers, Mécanicien, Taxi, Concessionnaire, Agent immobilier, Journaliste, Banquier, Barman, Justice, Chômeur.
- Gangs : Ballas, Families, Vagos, Lost MC, Mafia, Cartel, Yakuza, Triades.
- « Créer tous les modèles manquants » installe le pack d'un coup ; un groupe qui existe déjà n'est **jamais écrasé** (il passe en « Déjà créé » avec un bouton Modifier).
- Les salaires sont des valeurs de départ : ajuste-les dans l'éditeur. Les modèles sont définis dans `server/modules/presets.lua` (modifiable).
- Permission : `jobs.edit` / `gangs.edit`. Chaque création est journalisée (`jobs.modele` / `gangs.modele`).
- Limite : le lien entre un type (`leo`, `ems`…) et un comportement dépend des scripts qui lisent ce type ; Shadow Base ne fournit pas lui-même les scripts de service (armurerie police, etc.).

## Patch notes 32 (suite) — Staff : invincible en service, atterrissage après le noclip

- **En service staff, tu ne peux plus mourir** : aucun dégât (chute, balles, explosion, feu, noyade, collision). L'état est renvoyé au client à chaque prise/fin de service et réaffirmé toutes les 250 ms (un changement de ped de service ou un respawn ne l'annule plus). Hors service, tout redevient normal. L'outil « Invincible » du menu reste utilisable hors service.
- **Sortie du noclip (comme txAdmin)** : le ped (ou le véhicule) est posé sur le sol juste en dessous, vitesse remise à zéro, **sans dégât**, et reste protégé 4 s de plus.
- Limite : non vérifié dans un vrai client FiveM. Un ped déjà mort avant la prise de service n'est pas ressuscité (utilise « Me soigner »).

## Patch notes 32 (suite 2) — Raccourcis clavier du staff

Des touches pour les outils les plus utilisés, **réglables par chaque staff** dans *Paramètres FiveM › Raccourcis clavier › FiveM* (entrées « Staff : … ») :

| Raccourci | Défaut | Commande |
|---|---|---|
| Noclip (activer / couper) | `F3` | `pb_staff_noclip` |
| Téléportation au point GPS (tpm) | `F4` | `pb_staff_tpm` |
| Retour à la position précédente | — | `pb_staff_back` |
| Invincibilité | — | `pb_staff_god` |
| Invisibilité | — | `pb_staff_invisible` |
| Noms au-dessus des têtes | — | `pb_staff_names` |
| Me soigner | — | `pb_staff_heal` |

- Les touches par défaut se changent dans le panel (Menu staff › « Raccourci : … », vide = aucune touche). Un joueur qui a déjà réglé sa touche dans FiveM garde la sienne.
- **Sécurité** : la touche n'envoie que le nom du raccourci ; le serveur vérifie le droit `staff.menu` + l'outil concerné et le mode « en service » comme pour le menu. Sans droit, rien ne se passe (aucun message). Chaque usage passe par les mêmes actions que le menu (journalisées comme lui).
- Limite : non vérifié dans un vrai client FiveM ; les touches déjà enregistrées par un joueur avant la mise à jour ne reprennent pas les nouveaux défauts.

## Patch notes 33 — Inventaire, notifications, boutiques, HUD, téléphone, placement, anticheat

**Inventaire** : 5 emplacements d'armes (touches 1 à 5), plus aucune croix ; à l'ouverture la caméra cadre ton propre ped (plus de ped géant au milieu). Limite : la caméra est réglée par estimation, non vérifiée dans un vrai client FiveM.

**Notifications** : à gauche, le logo du serveur ; les annonces (`PB.Announce`, mode « écran ») s'affichent en carte avec la **bannière du serveur** en fond. Réglages : Notifs › « Logo du serveur » et « Annonce en carte » (désactivée, l'ancien fil d'actualité revient).

**Boutiques (nourriture, supérette…)** : une icône sur chaque catégorie et chaque carte, panier refait (lignes avec vignette, boutons − / + / Retirer / Payer / Vider larges).

**HUD véhicule** : l'autonomie s'affiche `restant/max km` (ex. `1.3/15 km`). Elle est calculée avec la **consommation moyenne réelle** du véhicule (lissée), pas une valeur fixe. Le script d'essence (consommation, panne sèche, pompes, stations) existait déjà et alimente ce calcul.

**Placement des interfaces** — Interface › « Placement des interfaces » : l'écran 1920×1080 avec les **vrais éléments** (compteur qui bouge, HUD, tableau staff, notifications, menu personnel). Clique, glisse, règle la taille, enregistre. Le serveur valide chaque valeur (bornes, droits `hud.edit` / `staff.edit` / `uikit.edit` / `menus.edit`) et journalise (`interface.place`). Notifications : 7 emplacements fixes. Limite : positions vérifiées en aperçu, pas dans un vrai client.

**Téléphone** — un vrai téléphone (écran d'accueil, pastilles, fonds d'écran) avec 10 applications : Messages (bulles, signalement), Contacts, Annuaire des services, **Banque** (solde, virement par numéro avec les mêmes limites et frais que la banque, opérations), **Factures** (payer les factures et amendes des entreprises), **Garage** (tes véhicules, « Localiser » pose le repère GPS), **GPS** (lieux réglables dans le panel), Notes (40 max), Calculatrice, Réglages (fond, ne pas déranger, sons). Le serveur vérifie toutes les actions ; un staff peut masquer des applications et définir les lieux du GPS (Téléphone › Réglages). Limites : pas d'appels vocaux (il faut un script voix) ; l'animation + l'objet téléphone en main sont **non testés** dans un vrai client (option « Animation » à couper en cas de souci).

**Anticheat de base** — Système › Anticheat. Protection **simple et côté serveur** :
- arrêt de tes scripts par un joueur (signalé par le client, **confirmé par le serveur**) + pouls toutes les 15 s : plus de réponse = sanction ;
- ressources protégées arrêtées côté serveur (console / txAdmin) : alerte + **redémarrage automatique** (option : refuser stop/restart en rcon) ;
- explosions, feux et particules en rafale, armes et modèles interdits (refusés avant d'apparaître), armes données à un autre joueur, tâches annulées sur un autre joueur ;
- évènements pièges (jamais appelés par un script légitime) ;
- invincibilité et déplacement impossible (par défaut « Journaliser » : risque de faux positifs).
Chaque détection : *Désactivé / Journaliser / Expulser / Bannir*. Les joueurs avec `anticheat.bypass` ne sont jamais sanctionnés. Tout est dans le journal Sécurité et notifié au staff. Les téléportations du serveur se déclarent avec `exports.pb_panel:AntiCheatGrace(src, 10)`.
**Limites honnêtes** : un anticheat en Lua ne voit pas ce qui s'exécute dans le jeu du joueur (menus injectés, exécuteurs) ; un cheat sachant imiter le pouls passe. La console du serveur garde la main : on ne peut pas empêcher un `stop` depuis la console, on le répare et on le journalise. Vérifié par simulation uniquement : teste chaque mode avec un compte de test avant « Bannir ».

Autre : l'envoi des gros messages du panel coupe maintenant sur une frontière de caractère (plus d'erreur d'accent coupé).

## Patch notes 34 — Accueil, tablettes, inventaire, boutiques, braquage, territoires, menu ALT, menu Échap, graffitis

**Écran d'accueil** — Flux › Accueil : style « grand » (logo, titre avec mots en couleur, paragraphe, règles, boutons) ou « carte » ; flou du jeu en fond ; titre, mots mis en valeur, texte et image de fond réglables.

**Tablette des organisations (F7, `/orga`)** — Organisations : sept tuiles en mosaïque (Crypto, Gestion, Leaderboard, Crews, Grades, Laboratoires, Contrats), recherche, compteurs d'XP. Crypto au cours mobile, grades et exclusion réservés au chef, XP issue des braquages, ventes et captures. Les images des tuiles viennent de ton PC (panel). La tablette entreprise (légale) a le même habillage.

**Inventaire** — onglets d'icônes avec poids `x / y kg`, grille de 5 colonnes, raccourcis 1 à 5, colonnes de vêtements à gauche et d'accessoires à droite du ped, pagination ; sans logo central ni barre staff.

**Boutiques** — fiche produit avec prix vert et bouton « Ajouter », panier à droite, boutons « Attribuer au joueur le plus proche » (vendeur), « Acheter pour moi », « Vider ». Un sélecteur flotte au-dessus de la tête du joueur qui recevra les objets et paiera (il accepte avec Y, refuse avec N). Sans vendeur : même menu, sans « Attribuer ».

**Braquage** — viser le vendeur (ped du commerce, ou ped de remplacement) 0,7 s lance le braquage, **à l'arme à feu comme à l'arme blanche** ; le serveur relit l'arme et refuse les mains nues (réglable). Le vendeur lève les mains pendant l'action.

**Territoires** — chaque zone est colorée sur la carte du jeu à la couleur du gang propriétaire (approximation de la palette de blips) ; **influence** par zone et par gang : 100 points raccourcissent la capture de 40 % (Zones de gangs › Influence).

**Menu ALT (contextuel)** — catégories avec **sous-menu à côté**, qui ne sort jamais de l'écran. Trois versions au choix dans Interface › **Versions des interfaces** : *Verre*, *Context menu V2* (deux colonnes, touches 1 à 9, retour arrière) et *Épurée* (couleurs du serveur). Gestes sur un joueur : **Porter**, **Se faire porter**, **Checker** (il accepte avec Y, refuse avec N), poignée de main, câlin, **Copier son ID**. Sur soi : **Se rendre**, à genoux, mains sur la tête, saluts, poses, sport, danses… (plus de 35 gestes), Copier mon ID, Faire un tag. Portage : X pour lâcher ; le serveur arrête tout si l'un des deux s'éloigne, meurt ou part.

**Menu Échap** — Échap ouvre ce menu (la touche P garde le menu de pause du jeu ; `/menu` aussi). Accueil avec annonces (réglables), **Personnage** (fiche filmée par la caméra du jeu : toi ou l'un de tes véhicules, glisser pour tourner), **Parcours** (emplois et organisations successifs avec durées), **Carte** (carte du jeu avec tes lieux et ton GPS, ou survol 3D jusqu'à un lieu ; lieux enregistrés à ta position, lieux communs réglables), **Réglages du jeu** (vue à pied et en véhicule, caméra cinématique, station de radio, volumes radio et appels avec pma-voice, filtre, ombres, distance d'affichage, liste des touches). Les réglages sont gardés sur le PC du joueur.

**Graffitis (tags)** — Graffitis : bibliothèque de 16 images envoyées depuis ton PC (un tag réservé à un gang = logo de groupe), tags en texte stylisé (4 styles, 10 couleurs). Commande `/tag` (ou ALT sur soi) : choix, taille, puis **aperçu transparent** sur le mur visé (molette = taille, Q / E = rotation, clic gauche = poser, clic droit = annuler). `/tagerase` efface le tag le plus proche (durée vérifiée par le serveur). Chaque tag d'organisation non effacé rapporte de l'**influence** chaque jour dans le territoire où il se trouve.

**Limites honnêtes** — rien de ce lot n'a été vérifié dans un vrai client FiveM : tests en simulation et dans un navigateur. Les zones de territoire sont des cercles (pas des polygones) et la carte du jeu n'accepte que sa palette de couleurs. Le choix d'un fichier directement sur le PC n'est pas possible depuis l'interface du jeu : les images des tags passent par le panel (bibliothèque). Les tags sont dessinés par le jeu à partir d'une page interne (DUI) projetée sur le mur : rendu et performances à vérifier sur ton serveur. Le studio du personnage est la caméra du jeu sur place (pas d'intérieur fermé). Les clips d'animation et filtres utilisent des noms du jeu non vérifiés ici ; les volumes de voix demandent pma-voice. Les emplacements « chemise » et « gants » de l'inventaire sont approximatifs.

## Patch notes 35 — Catalogue d'entreprises, Carte, menu staff, correctifs d'interface

**Entreprises (130 modèles, 10 catégories)** — Services publics, Santé, Automobile, Restauration et bars, Commerce, Services et immobilier, Médias, Loisirs, Transport et travaux, Couvertures et façades. Tout le catalogue est installé au premier lancement (sans jamais écraser une entreprise existante) ; chaque entreprise a grades, salaires croissants, droits par grade (police, secours, garage) et, quand une position réelle est connue, un siège avec blip. Entreprises › *Nouvelle entreprise* : cartes par catégorie, installation d'un modèle, d'une catégorie ou de tout le catalogue, et création sur mesure (catégorie + type de métier). *Modifier* permet de changer la catégorie. `/setjob [id] [nom ou fragment] [grade]` retrouve « police » même si l'entreprise s'appelle « Police de Los Santos ».

**Deuxième emploi** — `/setjob2`, `/jobswap` (le joueur passe de l'un à l'autre), exports `GetJob2`, `SetJob2`, `SwapJobs`.

**Points d'entreprise et de gang** — siège, prise de service, bureau du patron avec blip (visibilité : tous / membres / staff / aucun). Le staff **en service** voit tous les points. Interaction « E » revalidée côté serveur (distance et appartenance).

**Menu staff** — joueur › *Entreprise (emploi 1)*, *Deuxième emploi* (catégorie → entreprise → grade), *Gang* (gang → grade ; le dernier grade fait le chef), *Grade staff* (liste des grades), *Donner une arme* (liste par catégorie, munitions demandées, l'arme et des boîtes de munitions arrivent **dans l'inventaire**). Serveur › *Redémarrer le serveur* (1 à 60 min, annonces, annulation) avec le droit `staff.restart`. L'en-tête du menu reste **en haut** et se place dans l'éditeur de placement avec le vrai menu en aperçu.

**Carte du jeu** (module du panel) — 18 types de points (supérette, vêtements, armurerie, concession, agence, ATM, garage, coffre, récolte / laboratoire / vente de drogue, braquage, blanchiment, points d'entreprise et de gang, coffre et garage d'entreprise). On choisit le type, on clique sur la carte, **Me téléporter là-bas**, on se place et **E** confirme (Retour arrière annule) ; ou **Créer à ma position**. La position est toujours lue côté serveur. Onglet *Existants* pour supprimer. Les formulaires de modification restent dans leurs modules.

**Créateur de personnage** — la carte de choix du départ utilise la vraie carte du jeu (`img/map.jpg`).

**Inventaire** — ton personnage vivant au centre comme une maquette : distance de caméra réglable (6,5 m par défaut), rotation lente, socle lumineux (Inventaire › Réglages). Images : PNG ox_inventory + SVG de repli, tous les fichiers sont déclarés dans le manifeste.

**Panel** — les boutons ne sont plus jamais grisés pour toujours : un refus les rend **rouges** avec la raison (info-bulle + message au clic) ; l'éditeur d'automatisation envoie et relit correctement les réglages de l'action (faux « message obligatoire » corrigé).

**Interface en jeu** — notifications sobres (texte + barre simple, sans logo), barre staff réduite dans le coin haut droit, menu pause de GTA rétabli (`/menu` pour celui du panel), étoiles de recherche supprimées (Monde › *Police de GTA*), noclip dans un véhicule : le véhicule est relâché à la sortie.

**Interactions qui cessent de répondre** — cause exacte non démontrée hors du jeu : un compteur de focus ou un drapeau d'interface resté bloqué. Un **garde-fou** vérifie toutes les 1,5 s que l'écran montre bien une interface quand le jeu pense en avoir une ouverte ; sinon tout est remis à zéro. Commande manuelle `/pb_uireset`.

**Limites honnêtes** — rien n'a été vérifié dans un vrai client FiveM. Positions et sprites de blip du catalogue viennent de ma mémoire (modifiables) ; la carte est précise à ~100 m ; la téléportation cherche le sol, pas les intérieurs ; le ped d'inventaire est le vrai ped filmé (réduit par la distance), pas une vue du menu pause.

## Patch notes 36

- **Tablettes entreprise / gang** : même format que le menu F5 (en-tête avec argent, grille de cartes illustrées).
- **Coffre de véhicule** (`server/game/vehtrunk.lua`, `client/vehtrunk.lua`) : à pied, derrière le véhicule, touche **K** ; le serveur revérifie distance, clé (véhicule possédé) et verrouillage. Capacité par classe GTA réglable (panel › Coffres de véhicules). Touches : coffre K, capot J, moteur Y, ceinture B, vitres U (réglables dans le panel et dans les raccourcis FiveM). Sans ceinture, un choc violent éjecte le conducteur. Le menu contextuel « Coffre » ouvre aussi le coffre.
- **Concession** : 45 véhicules par défaut (le catalogue GTA complet est activé par défaut pour les concessions qui n'ont pas de réglage explicite). Nouvelle fiche véhicule : vitesse, accélération, freinage, adhérence, places, coffre (emplacements et kg). Les valeurs viennent du jeu quand le client peut les lire, sinon ce sont des estimations par catégorie.
- **Noms au-dessus des têtes** : réservés au staff (en service par défaut), couleur = couleur du grade. Le choix de couleur a disparu du créateur. Réglable : Gamertags › « staff seulement ».
- **Créateur de personnage** : nouvelle mise en page (étapes en haut, colonne pleine hauteur à gauche).
- Limites : rien de tout cela n'a été vérifié dans un vrai client FiveM ; les bones/portes de coffre, les natives de stats et l'éjection sans ceinture dépendent du modèle de véhicule.

### Lot 36 (suite) : tablettes complétées
- **Entreprise** : 7 nouvelles pages — Équipe, Annonces (le patron publie, les connectés sont notifiés), Journal, Statistiques (7 jours, meilleurs employés), Paie (masse salariale par grade, patron), Règlement (grades, salaires, droits), Lieux (GPS vers les points posés dans « Carte du jeu »). Droits : Journal/Statistiques = droit « caisse », Paie = patron.
- **Gang** : 5 nouvelles tuiles — Territoires (GPS), Effectif (membres hors ligne compris), Messages du chef, Caisse commune (tout membre verse, le chef retire), Activité (XP, classement).
- Toutes les actions sont revalidées côté serveur et journalisées quand elles touchent à l'argent ou aux annonces. Images de tuiles réglables dans le panel.

### Nouveautés dans le panel
`server/modules/whatsnew.lua` : journal des mises à jour. Une carte « Nouveautés » apparaît sur l'accueil du panel (pastille des non-lus, « Tout marquer comme lu », bouton « Ouvrir » vers le module concerné) et le module **Nouveautés** garde l'historique. Le lu/non lu est mémorisé par administrateur. Pour ajouter une entrée : `PB.News.Add({ id, date, title, items = { { tag, text, module } } })`.

### Correctif de présentation (audit complet)
Audit automatique : événements client/serveur recoupés (aucun orphelin sauf un, corrigé), appels NUI, manifeste, fichiers images, réglages jamais lus, variables inconnues (client et serveur), 290 actions du panel et 119 événements joueur lancés avec des données absurdes, 89 messages d'interface avec des charges vides ou mal formées.
Corrigé : commandes « restreintes » jamais restreintes ; second emploi jamais payé (`job2_pct`) ; tablette non ouverte par les points « patron/siège » ; garage planté par une note ; requêtes mal formées faisant planter ~80 formulaires du panel ; menus contextuel/interaction/garage plantés sur données incomplètes.
Limite : le code client Lua (natives FiveM) n'est vérifié que par analyse statique et lecture, jamais dans un vrai client.

## Patch notes 39 — Images d'inventaire, tablettes, placement à l'écran, nettoyage des onglets
- **Images d'objets** : les 199 PNG (`web/img/ox/`, ox_inventory, GPL-3.0, voir CREDITS.txt) doivent être présents dans la ressource ; alias étendus (menottes, taser, matraque, joint…) et 3 SVG maison (café, chips, sandwich).
- **Tablette des organisations** : le style `#g-orga` manquait, d'où l'affichage cassé ; corrigé.
- **Tablette entreprise** : les pages perso (finances, factures, annuaire, profil) n'y apparaissent plus ; la police a accueil, appels, détenus, amendes, dossiers, dispatch. Le serveur refuse aussi ces pages côté entreprise.
- **Placement à l'écran** (module `placement`) : un éditeur unique avec les vrais éléments (HUD, menus, chat, invite, barre de progression, notifications) à déplacer ; onglet de remise à zéro. Les rectangles « HUD » ont disparu.
- **Onglets supprimés** : module Services (doublon d'Entreprises), Économie/Argent (même bloc que « Économie »), Interface/Documentation, Véhicules/Garages, Orga/Tablette entreprise (déplacé dans Entreprises > Tablette et images).
- Limite : rien n'a été vérifié dans un vrai client FiveM.

## Patch notes 40 — Inventaire, territoires, packs de points, logo et bannières, optimisation
- **Inventaire** : glisser-déposer au pointeur (cases, cases vides, coffre, carte d'un joueur pour donner) ; les filtres masquent vraiment les objets (dont « Utilisables ») ; les armes n'ont plus de bouton Utiliser, elles s'équipent avec les touches 1 à 5 et ne sont jamais consommées.
- **Tablette illégale** : même teinte unie que la tablette entreprise (`#dfe2e7`).
- **Notifications (placement)** : la pile suit le curseur, 7 repères d'ancrage, position appliquée au relâchement (le bug venait du redessin pendant le glissement).
- **Territoires** : onglet carte dans la tablette illégale (propriétaire, récompense, prochaine livraison, GPS). Récompense par zone (`reward_item/qty/hours`) livrée dans le coffre de l'organisation (`o:<gang>`) ; Mirror Park = gilet pare-balles toutes les 10 h (une seule livraison, sans rattrapage). Coffre ouvrable depuis la tablette ou près d'un point « coffre » du gang.
- **Packs de points** (carte > « Configurer tout ») : une entreprise ou un gang se configure d'une traite (siège, service, patron, coffre, garage entrée/sortie, vestiaire, + points propres au métier). Créer une entreprise lance le pack (case « points » décochable).
- **Supérette** : retour à l'interface d'origine (catégories, produits, fenêtre, bouton Panier) avec le panier ; la disposition « photo » reste une option (`layout = 'photo'`).
- **Identité** : logo W et bannières originales (titre serif, grand W ton sur ton, lame de verre ; Shadow Base, offre, Halloween, patch notes ; formats 1920×1080 et 1920×480) dans `web/img/brand/`, générateur dans `tools/brand/make2.py`.
- **Optimisation** (mesurée seulement par lecture/analyse, pas de profilage en jeu) : boucle de pause (250 ms au lieu de chaque image quand aucun réglage ne l'exige), repères du monde (liste proche recalculée 2×/s), graffitis (repos quand rien autour).
- Vocabulaire : « patch notes » remplace « lot ».
- Limite : rien n'a été vérifié dans un vrai client FiveM.
- **Bannière animée des menus** : nouveau mode « Shadow Base animée » (réglage Menus > Apparence > Bannière), activé par défaut : lueur qui dérive, reflet qui traverse le W, filet lumineux ; uniquement `transform`/`opacity` (pas de filtre), désactivé si l'animation réduite est demandée. Les modes « Logo texte » et « Image » restent disponibles ; si tu avais choisi une image, ton réglage est conservé.

## Patch notes 41 — Aides à l'écran, infos à côté des menus, ALT en cascade, bannière animée, chuchoter
- **Barre d'aide** (`web/game/hints.js`) : touches + explications en bas de l'écran (`G.send('hints', { items = { { k = 'CTRL', t = 'Ralenti' }, { k = 'mouse', t = 'Vitesse 0.5' } } })`, liste vide pour masquer). Utilisée par le **noclip** (molette = vitesse de 0,1 à 5 ; Ctrl ralentit ×0,25 ; Maj ×4 ; E monter, A descendre) et par la **cabine de vêtements** (caméra, rotation, numéro, quitter).
- **Fiche d'infos à côté du menu** (`G.Info(src, { title, rows })`, `web/game/infopanel.js`) : remplace la notification pour les infos du joueur (staff), l'historique des sanctions, « Mon argent », les papiers montrés, la plaque et le fichier véhicule. Elle se pose à droite du menu ouvert (ou en haut à droite), texte jamais interprété, disparaît seule.
- **Menu ALT « cascade »** : nouvelle version par défaut (Interface > Versions) — colonnes sobres côte à côte, sans titre ni cadre, icône + texte. Les versions Verre, V2 et Épurée restent choisissables.
- **Bannière des menus** : le W se dessine (tracé du contour du logo) puis le nom du menu apparaît ; rien d'autre. Le texte suit le menu ouvert (« Menu admin », « Menu police »…, sinon « Menu » + titre) ; violet par défaut, ambre pendant Halloween. Seule la bannière bouge, la liste ne bouge pas.
- **Chuchoter** (menu staff, menu ALT > Staff, droit `staff.whisper`) : le staff écrit à un seul joueur (message discret, journalisé). Option « voix privée » (`whisper_voice`, appel pma-voice entre les deux) : non vérifiée dans un vrai client.
- **Logo du panel** : le W de Shadow Base par défaut (remplaçable dans Général).
- Limite : rien de tout cela n'a été vérifié dans un vrai client FiveM.

## Patch notes 42 — Organisations illégales, starter pack et véhicules de gang

**Assistant de création** (Carte du jeu › *Entreprise / organisation*, ou module *Organisations* › *Créer*) : tu renseignes nom, couleur, identifiant, chef (facultatif) puis tu es guidé en jeu, étape par étape (E pour poser ici, Retour arrière pour passer, `/carte_annuler` pour arrêter) :
1. Quartier général (blip des membres) · 2. **Point boss** (tablette du gang) · 3. **Point coffre** · 4. **Rangement véhicules** (entrée du garage de gang) · 5. **Sortie du garage** (où les véhicules apparaissent). Les entreprises ont leur propre parcours (siège, service, patron, coffre, garage, sortie, vestiaire…).

**Starter pack** (réglable dans *Organisations › Réglages*) : à la création, les objets listés (`objet:quantité`) vont dans le coffre `o:<id>`, l'argent de départ dans la caisse, et les véhicules de départ (`modèle|nom`) sont ajoutés au garage du gang. Donné une fois ; « Redonner le pack » dans la liste l'ajoute de nouveau (confirmation). Un objet inconnu est ignoré et signalé, jamais bloquant.

**Véhicules de gang** : colonne `pb_vehicles.gang`. Les membres ont la clé (`HasKeys`), sortent et rangent dans le garage du gang (grade minimum réglable). Menu du garage de gang, onglet *Organisation* : donner un de ses véhicules (rangé) à l'organisation, le reprendre (donateur seulement), et le **chef** attribue un véhicule du gang à un membre proche. Maximum par organisation réglable. Les véhicules d'organisation n'apparaissent plus dans la liste personnelle ni dans le compte du maximum personnel. Fourrière : seul le chef récupère un véhicule de gang. Chaque don, reprise et attribution est journalisé.

**Panel** : *Organisations › Véhicules* ajoute un véhicule neuf ou attribue un véhicule existant par plaque (les doubles de clés sont retirés) ; *Retirer* le rend à son ancien propriétaire. Le garage de gang est aussi créable à la main (*Garages et véhicules* › type « Garage de gang », identifiant du gang).

**Limites honnêtes** : testé par simulation serveur et navigateur sans jeu, jamais dans un vrai client FiveM. Pas de suppression d'organisation depuis ce module (onglet *Gangs*, les véhicules et le coffre restent en base). Le garage de gang est caché côté client aux non-membres, mais c'est le serveur qui décide de l'accès. Les véhicules dehors dans le monde doivent être rangés avant un don.

## Patch notes 43 — Extensions, métiers de récolte, correctifs

**Extensions (API).** Une autre ressource peut maintenant se brancher sur Shadow Base sans toucher à pb_panel : pages du panel, réglages (stockés, historisés, annulables), actions, permissions, tables SQL. Fichier `server/core/ext.lua` (exemple en tête) et `client/ext.lua`. Exports serveur : `ExtRegister`, `ExtPerm`, `ExtSettings`, `ExtModule`, `ExtAction`, `ExtMigrate`, `ExtReady`, `CfgGet`, `CfgAll`, `CfgSet`, `NotifyPlayer`, `Pay`, `DistTo`, `CanAct`, `GetLicense`, `ItemInfo` ; évènement `pb_panel:cfgChanged` (ns, clé). Exports client : `Prompt`, `HidePrompt`, `Progress`, `CancelProgress`, `Marker`, `IsFree`. Une extension ne peut écrire que dans ses propres espaces (nom de sa ressource) ; quand elle s'arrête, ses pages et actions sont retirées. Nouveau module **Extensions** (liste des extensions branchées).

**Métiers de récolte** : première extension, ressource `wb_metiers` (voir son README).

**Menu staff** : « Libérer de prison » sur la fiche d'un détenu (badge PRISON dans la liste), liste des détenus (connectés ou non) dans Gestion des sanctions.

**Monde** : « Supprimer les PNJ » et « Supprimer les PNJ police » (activés par défaut), appliqués même si le panel ne pilote pas la météo ; les curseurs de densité aussi.

**Correctif** : envoyer une image depuis le PC (bannière, logo) déconnectait le joueur (`Reliable network event size overflow: pb:upChunk`) : les gros transferts passent par des évènements latents.

## Patch notes 44 — Activités, blips, Burger Shot, inventaire, territoires, HUD

- **Activités** (ressource `wb_activites`, remplace `wb_metiers`) : ouvertes à tous, sans métier. Pêche, mine, bûcheron, agriculture (blé, vignes, vergers), cueillette, récupération (décharge), transformations, grossiste et établis de craft. Butin aléatoire (ex. pêche : poisson, saumon, crabe, vieille chaussure, bouteille à la mer), outil tenu en main (pioche, hache). **Points posés en jeu** : menu staff F10 › Builder › Activités, puis Entrée sur place. Correctif : la distance est mesurée au sol et les grandes zones ont un cercle au sol (avant : seulement le blip, l'invite n'apparaissait jamais).
- **Blips** : coffres (publics, de gang, d'entreprise pour ses employés) = `radar_nhp_chest` (587) en dégradé animé aux couleurs du serveur ; QG des gangs = `radar_bat_cargo` (615).
- **Burger Shot** : vraie icône `radar_burger_shot` (98) ; ses points (bornes, postes, comptoir, adresses) se posent depuis la fiche de l'entreprise dans le Builder (Entreprises › Restauration › Burger Shot), plus dans « Ressources ».
- **Inventaire** : le fond n'est plus noir opaque ; le jeu se voit derrière, cases sombres translucides, silhouette claire (images `img/inv/bg*.webp` refaites ; originaux opaques dans `_archive`).
- **Territoires** : en entrant dans une zone, une carte apparaît au-dessus de la mini-carte (badge du gang, nom de la zone, « Sous le contrôle de … » à la couleur du gang, ou « Territoire libre »).
- **HUD « photo »** : pastilles faim / soif / micro et barres vie / armure au-dessus de la colonne (réglages Vie, Armure, Faim, Soif, Stress du module HUD).

## Patch notes 45 — Portes, menu boss, builder, GPS, animations, Burger Shot

- **Portes verrouillables** (ressource `wb_portes`) : n'importe quelle porte du jeu, rangée dans un groupe. Accès cochés par entreprise, par gang ou « tout le monde » ; le staff en service ouvre toujours. Gestion en jeu : F10 › Builder › Portes, ou `/portes` (viser une porte + E pour l'ajouter ou la retirer). Les joueurs autorisés ouvrent / verrouillent avec E.
- **Menu boss** : la gestion (employés, grades et salaires, caisse, paie, journal, statistiques ; pour les organisations : gestion, grades, caisse) ne s'ouvre plus depuis la tablette n'importe où, seulement au **bureau du patron / point boss** posé au Builder. Sans point boss posé, rien ne change. Réglage : Tablettes › « Gestion seulement au point boss ».
- **Builder** : sur un point déjà posé, « Supprimer ce point » (son icône disparaît) ; « Supprimer tous les points » d'une entreprise, d'un gang ou d'une drogue (confirmation OUI).
- **Menu F2 retiré** (réactivable : Actions rapides › « Menu F2 »). Toutes ses actions restent dans le menu ALT ; la police y escorte et met dans un véhicule.
- **GPS** (F5) : clic sur un véhicule (position réelle s'il est dehors, sinon son garage ou la fourrière) ou un logement : repère sur la carte.
- **Animations** : manger et boire avec l'objet en main (burger, frites, canette, café, bouteille…). Kit de réparation utilisable : répare le véhicule le plus proche (8 s, animation de mécanicien).
- **Burger Shot** : l'écran de cuisine et le suivi de commande ne clignotent plus (ils se reconstruisaient chaque seconde) ; le client PNJ apparaît sur le trottoir le plus proche de l'adresse (plus sur les toits ni au milieu de la route) et la remise fonctionne jusqu'à 30 m de l'adresse. Les adresses par défaut sont approximatives : repose-les au Builder (Burger Shot › Adresse de livraison) après `/bsplace clear addresses`.
- Correctif : le « kit de réparation » des activités faisait doublon avec `repair_kit` et disparaissait sans effet.

## Patch notes 46 — Points de métier pour toutes les entreprises

Dans le Builder (F10 › Builder › Entreprises › catégorie › entreprise), chaque entreprise du catalogue (≈ 130 : police, EMS, garages, Bahama Mamas, Vanilla Unicorn, Bean Machine, boulangerie, agence immobilière, taxis, BTP…) a, en plus du siège, du service, du bureau du patron, du coffre, du garage et du vestiaire :
- **Accueil** (toutes) : un client appuie sur E, les employés en service sont prévenus (notification + repère clignotant 60 s) ; un employé y ouvre la tablette.
- **Atelier / pont** (garages, carrosserie, pneus, dépannage, casse) : réparations et améliorations ; dès qu'un atelier est posé, l'atelier ne s'ouvre plus qu'à côté (15 m).
- **Cuisine / bar** (restauration, bars, cafés, boulangerie, vignoble, brasserie) : les employés en service y préparent les produits à partir des récoltes des activités (cocktails, bières, pizzas, plats, sushis, viennoiseries, vin…). Recettes : Activités › Recettes (établi `tag:bar`, `tag:resto`, `tag:cafe`, `tag:bakery`, `tag:sushi`, `tag:wine`, `tag:beer`, ou `biz:<entreprise>`).
- **Comptoir de vente** (restauration, bars, commerces) : boutique de l'entreprise, catalogue adapté au métier, argent dans sa caisse, vendeur en service ou sonnette. Quand un employé en service l'ouvre, ce qu'il a préparé est mis en rayon automatiquement.
- **Agence immobilière** : « Logement à vendre » (porte à ta position) ; l'agence touche une commission (5 %, réglable dans Logements) sur chaque vente et chaque première location. Les logements se posent aussi pour tout le monde dans Builder › Immobilier.

## Patch notes 47 — Agence immobilière, mises à jour gratuites

- **Agence immobilière** (entreprise `realestate`, réglable dans Logements) : ses agents en service ont dans le menu ALT (Métier) : « Mettre en vente ici », « Mettre en location ici » (la porte est à leur position), « Définir l'intérieur ici », « Changer le prix », « Retirer de la vente », et sur un client « Faire visiter » (accès de 15 minutes à un logement libre). L'agence touche une commission sur chaque vente et chaque première location (5 %, réglable) ; nombre d'annonces limité (40 par défaut).
- **Mises à jour** : Shadow Base vérifie toutes les 6 heures si une nouvelle version est publiée (fichier `latest.json` signé avec la clé de licence : une fausse mise à jour est refusée). Nouveau module **Mises à jour** (version installée, dernière version, patch notes, lien de téléchargement) et commande console `wbase_update`. Rien ne s'installe tout seul.
- **Publication gratuite** : outil `W-Base/outils/publier.py` (zip sans secrets, empreinte SHA-256, signature, site des patch notes) à déposer sur GitHub (Releases + Pages, gratuit).

## Patch notes 48 — Écran de chargement

- Nouvelle ressource `wb_loading` (lancée par `ensure [w-base]`) : logo du serveur au centre (lueur qui respire), barre de progression du vrai chargement, bandeau de messages qui défile en bas. Messages, couleurs et vitesse se changent en haut de `wb_loading/index.html` ; le logo est `wb_loading/logo.png`.

## Patch notes 49 — Nouveau nom : Shadow Base

- La base s'appelle désormais **Shadow Base** : panel, menus, messages de la console, écran de chargement, patch notes. Un serveur qui avait gardé le nom par défaut passe tout seul à « Shadow Base » (Configuration › Identité pour le changer).
- Nouveau logo partout (panel, bannière animée des menus, cartes) ; l'animation « le logo se dessine » suit le nouveau logo.
- Rien à refaire côté licences et réglages : les noms techniques (ressources `pb_panel`, `wframework`, `wb_*`, `wbase_license`, licences `WB1…`) ne changent pas.

## Patch notes 50 — Corrections en série, journal des expulsions, vrais vestiaires, braquages animés

- **Journal des expulsions et bans** (nouveau module « Expulsions et bans ») : chaque kick, ban, connexion refusée et départ est enregistré avec sa raison précise, son origine (anticheat, staff, licence, file d'attente, maintenance…), le détail technique, le ping et la position. Le joueur voit une **référence #** à donner au staff. Salon Discord dédié possible (`logs_kicks`).
- **Anticheat : plus d'éjections sans raison.** Délai de battement relevé (90 s), marge à la connexion (3 min), un `restart` de ressource via txAdmin n'éjecte plus tout le monde, un jeton périmé ou une réponse en retard est redemandé au lieu de sanctionner.
- **Staff « hors ligne » alors qu'il est connecté** : corrigé (licence `license2:` et majuscules reconnues).
- **Touches des menus** : changer une touche par défaut dans la config s'applique désormais à tous les joueurs (à leur prochaine connexion).
- **Onglets vides du panel** (grades, comparaison) et **préréglages d'économie « inconnus »** : corrigés (accents mal gérés sous Windows).
- **Builder : suppression des points** : la liste « Tous les points posés » montre aussi les points créés avant les patchs (coffres, comptoirs, garages…), chacun avec GPS et « Supprimer ce point », plus « Tout supprimer ».
- **Vrais vestiaires** d'entreprise et de gang : le patron enregistre les tenues portées (avec grade minimum, homme/femme), les membres les enfilent, « Tenue civile » remet leurs vêtements. Le vestiaire est aussi proposé dans le pack de points des gangs.
- **Braquages** : nouveau point Builder « Braquage : position du vendeur » pour le placer **derrière le comptoir**. Le vendeur lève les mains, crie, remplit un sac à la caisse puis se recroqueville ; le braqueur le tient en joue. Banque et bijouterie : ramassage des billets / vitrines cassées avec sac.

## Patch notes 51 — Vendeurs derrière le comptoir, petits jobs pour chaque entreprise, vraie pêche, grand ménage

- **Vendeurs derrière le comptoir, partout** : dans les 19 supérettes de GTA (24/7, LTD, Rob's Liquor), le vendeur du magasin et celui du braquage se placent tout seuls derrière la caisse, face aux clients. Pour un magasin ou un intérieur personnalisé : Builder › Commerces › « Magasin : position du vendeur » (et toujours « Braquage : position du vendeur »).
- **Petits jobs pour chaque entreprise** (nouvelle ressource `wb_jobs`) : en service, touche **O** (ou /jobs). 12 types de missions adaptés au métier : livraisons, repas en scooter, courses de taxi, dépannages, patrouilles, appels de secours, chantiers, poubelles, reportages, transport, convoyage de voitures, service sur place. Véhicule de service fourni, PNJ (clients, passagers, blessés, automobilistes en panne), paie à chaque étape + bonus pour la caisse de l'entreprise. Réglages : Extensions › Petits jobs.
- **Vraie pêche** (nouvelle ressource `wb_peche`) : pêche partout face à l'eau ou en bateau, 27 espèces en 5 raretés selon l'eau (mer, large, lac, rivière), 5 appâts et leurres de rareté croissante, 3 cannes, ferrage avec E dans la zone verte, trouvailles (coffre englouti, leurre doré), records du serveur. **Marché aux poissons vivant** : chaque vente fait baisser le cours de l'espèce, qui remonte avec le temps, et une « pêche du jour » est mieux payée. Points à poser : Builder › Pêche.
- **Grand ménage** :
  - joueur menotté : il ne peut plus lancer d'animations, de gestes ni de graffitis ;
  - saisie d'un véhicule depuis le menu ALT : enfin inscrite au casier ;
  - annonces en mode « chat » et commandes personnalisées : elles s'affichent maintenant dans le chat de la base (elles partaient vers le chat FiveM, absent) ;
  - capture de territoire : la bannière prend bien la couleur du gang ;
  - police et secours créés depuis le catalogue : le sergent / l'infirmier est répartiteur, comme dans les modèles de base ;
  - canne à pêche utilisable depuis l'inventaire ;
  - server.cfg : langue fr-FR et icône du serveur avec le logo Shadow Base (au lieu du logo ESX).
- **Tests** : toutes les suites repassent au vert (4 691 + 2 357 vérifications, 0 échec), plus des tests pour les petits jobs et la pêche.

## Patch notes 52 — Coiffeur / barbier, bandeau de démarrage

- **Coiffeur / barbier** (nouveau type de magasin) : coupe, couleur et reflets, barbe, sourcils, poils du torse, maquillage des yeux, blush, rouge à lèvres, avec style, densité et teinte. Aperçu en direct sur le personnage, caméra sur le visage, « Tourner la tête » pour voir le profil. Le serveur ne modifie que les cheveux et ces détails (le reste du visage ne bouge pas), vérifie chaque valeur et encaisse le prix du passage (40 $ par défaut, modifiable dans Magasins).
  - Builder › Commerces : « Coiffeur / barbier » (un salon où tu es) ou « Coiffeurs : les 7 salons de GTA d'un coup » (Herr Kutz, Beach Combover, O'Sheas…, blip ciseaux).
  - Le salon peut être rattaché à l'entreprise « Coiffeur et barbier » comme les autres magasins (encaissement dans sa caisse).
- **Bandeau au démarrage du serveur** : la console affiche la version installée, le **numéro et la date du dernier patch notes**, et l'**état de la licence** (valide : client, identifiant, expiration, fichier ou server.cfg ; verrouillée : raison et empreinte du serveur).
- **Nouveautés du panel** : les patch notes 49 à 51 étaient dans le désordre (la 49 passait pour la plus récente) et les titres longs étaient coupés en plein mot. Corrigé.

## Patch notes 53 — Moins de métiers, Builder plus rapide, Auto Exotic, packs d'organisation

- **Moins de métiers** : le catalogue propose seulement 14 entreprises utiles (LSPD, EMS, justice, LS Customs, **Auto Exotic**, taxi, concession, Burger Shot, Bean Machine, Bahama Mamas, Vanilla Unicorn, agence immobilière, Weazel News, livraison). Au premier démarrage, les entreprises inutilisées (sans employé, sans point posé, caisse vide) sont retirées ; celles qui servent restent. Entreprises › Réglages › « Catalogue complet » réaffiche les 120 modèles.
- **Auto Exotic** : nouveau garage mécanique (mêmes droits que LS Customs : réparer, facturer), posable au Builder.
- **Builder plus rapide** : place-toi au bon endroit, choisis le point dans la liste, **Entrée : il est posé**. La liste revient tout de suite pour le point suivant (plus de deuxième Entrée).
- **Icône sur la carte à la création** : le siège d'une entreprise (ex. Burger Shot) ou le QG d'un groupe se pose avec son icône et sa couleur, au choix (liste ou numéro de blip). Modifiable ensuite depuis le point.
- **Choisir le patron** à la fin de la pose des points : parmi les joueurs connectés (grade le plus haut). Pour un groupe : le chef.
- **Packs de départ des organisations** : 3 packs prêts (Rue, Standard, Gros calibre) choisis à la création au Builder et donnés tout de suite (caisse, coffre, véhicules au garage). Contenu modifiable dans Organisations › Réglages.
- **Correctifs Builder** :
  - les points « Accueil », « Atelier » et « Cuisine / bar » étaient enregistrés comme un second siège (et restaient « Aucune position ») ; ceux déjà posés sont réparés ;
  - les points du Burger Shot (bornes, comptoir, postes, tableau, adresses) s'affichent maintenant comme posés et **se suppriment** depuis le Builder.
- **Inventaire** : intérieur des cases beaucoup moins vert, fond plus transparent.

## Patch notes 54 — Grosse optimisation, confidentialité des noms et des ID

- **Noms, grades et ID réservés au staff** : les joueurs ne reçoivent plus aucune étiquette au-dessus des têtes (le réglage passe sur « staff seulement », appliqué une fois automatiquement). Menu ALT : la personne visée s'appelle « Une personne », sans ID (le staff voit le nom et l'ID). Inventaire : les joueurs proches s'affichent « Personne à 2 m », triés du plus proche au plus loin (le staff voit nom et ID).
- **Optimisation client** :
  - points d'entreprise et magasins : la liste proche est recalculée toutes les 0,5 s au lieu de parcourir tous les points à chaque image ;
  - drapeaux de territoire : plus rien à chaque image quand aucun drapeau n'est à moins de 90 m ;
  - braquage : le vendeur n'est plus cherché parmi tous les PNJ à chaque image (cache d'une seconde) ;
  - densité des PNJ intégrée à la boucle unique « à chaque image » (un thread permanent de moins) ;
  - HUD : la boussole n'envoie plus l'interface à chaque degré ; coffres animés recoloriés moins souvent ;
  - activités, pêche et portes : plus d'appels à pb_panel à chaque image (marqueur et « libre ? » en local).
- **Optimisation serveur** : les drapeaux de territoire ne renvoient plus leur état à tous les joueurs chaque seconde (le compte à rebours est fait par le client) ; les étiquettes ne sont plus calculées pour les joueurs qui n'en ont pas, ni du tout quand aucun staff n'est connecté.
- **Correctif** : les blips des entreprises avaient perdu leur couleur, leur taille et leur portée courte (erreur du patch 53). Rétabli.

## Patch notes 55 — VIP, tatoueur, chasse, braquages, logements, animaux, inventaire, staff, optimisation

- **VIP** : donné ou retiré depuis le menu staff (F10 › Joueurs › un joueur › Donner / Retirer le VIP, durée en jours, 0 = permanent), avec **/vip <id> [jours]** et **/unvip <id>** (console aussi), ou dans le panel (module VIP). Le VIP est lié au compte.
- **Multi-personnages (VIP)** : 3 personnages par compte, choix à la connexion. Chaque personnage a son inventaire, son argent, son métier, ses véhicules et ses logements.
- **Animaux de compagnie (VIP)** : nouvelle ressource `wb_animaux`. Animalerie au Builder, chiens et chat, **/animal** (appeler, assis, couché, suivre, renommer).
- **Salon de tatouage** : tatouages classés par zone du corps, aperçu en direct, prix par nouveau tatouage (retirer est gratuit). Builder › Commerces › Salon de tatouage.
- **Pêche** : canne et leurre VIP, bonus de revente VIP, canne visible en main, **filet de pêche** depuis un bateau, **concours de la semaine** (plus gros poisson, prix versé en banque, /concours).
- **Chasse** : nouvelle ressource `wb_chasse`. Zones au Builder, 7 animaux de rareté différente (le puma et la panthère attaquent), appeaux (dont un VIP), dépeçage au couteau, marché aux prix variables, bonus VIP.
- **Braquages et trafics** : nouvelle ressource `wb_braquages`.
  - Cambriolages (crochet, fouilles, voisin qui appelle la police).
  - Receleur caché.
  - Distributeurs à la perceuse.
  - **GoFast**, avec des départs cachés à trouver en RP, une course chronométrée et la police qui suit la voiture.
  - Fourgons blindés (charge thermique, sacs d'argent).
- **Logements** :
  - impôt foncier automatique sur les logements achetés ;
  - vraie colocation : clés partagées, porte, coffre commun, loyer payable par les colocataires ;
  - sonnette, avec **/ouvrir** pour faire entrer la personne ;
  - intérieurs instanciés (chacun chez soi) ;
  - intérieurs prédéfinis (studio, appartement, luxe, villa) et **meubles posables** pour les VIP ;
  - **aquarium** pour exposer tes poissons.
- **Builder** : un fantôme montre où le point sera posé, et **Ctrl+Z** annule le dernier point posé ou déplacé.
- **Inventaire** :
  - les objets ramassés vont dans le sac, plus dans les raccourcis 1 à 5 ;
  - tri automatique, recherche, poids par catégorie ;
  - bouton « Coffre » qui ouvre le coffre du véhicule proche à côté du sac.
- **Vestiaires** : gilet et badge enregistrés par grade, ajoutés automatiquement à chaque tenue.
- **Restaurants** : ce qui est préparé en cuisine part directement en rayon au comptoir de l'entreprise (ticket de caisse par article à l'encaissement).
- **Staff** :
  - spectateur amélioré : rejoint les joueurs éloignés, affiche leurs infos, ← → pour changer de joueur, retour à ta place à la fin ;
  - **enregistrement d'écran** de 30 s, revisionnable (nécessite screenshot-basic).
- **Événements** (nouveau module) : annonces, météo et bonus de paie programmés, une fois ou en répétition.
- **Optimisation** :
  - le panel d'administration n'est chargé qu'à sa première ouverture ;
  - images de l'interface allégées (7,5 Mo → 3,4 Mo) ;
  - portes des logements recalculées toutes les 0,5 s au lieu de chaque image ;
  - purge automatique de tous les journaux et nouveaux index sur la base.

## Patch notes 56 — Atelier d'armes, portes en ALT, menu ALT admin, VIP dans F5, corrections

- **Mon VIP dans le menu F5** : statut (actif ou non), date de fin, liste des avantages. « Animal de compagnie » ouvre directement **/animal**. La carte peut être masquée dans le panel (Menu personnel › Carte VIP).
- **Atelier d'armes clandestin** (nouvelle ressource `wb_armes`) :
  - ateliers **cachés**, sans icône sur la carte : l'invite E n'apparaît qu'à côté de l'établi ;
  - accès possible réservé à des gangs ou des entreprises ;
  - fabrication en chaîne : ferraille, pièces d'acier, ressorts, canons, culasses, carcasses, crosses, puis les armes. Aussi les munitions et le démontage d'armes ;
  - **plans** à acheter pour chaque famille d'armes ;
  - **niveau d'armurier** de 1 à 10 par personnage ;
  - finition artisanale, correcte ou excellente, avec un **mini-jeu d'assemblage** ;
  - ratés possibles, alerte police, marché noir (ferraille, poudre, plans).

  Pose : F10 › Builder › Atelier d'armes.
- **Portes en ALT (staff)** : en maintenant ALT, les portes autour de toi s'entourent en jaune. Clique sur une porte pour choisir qui garde l'accès (tout le monde, entreprises, gangs), avec un filtre et une **recherche**, puis valide. Les deux battants d'une double porte sont pris ensemble. Sur une porte déjà verrouillable : ouvrir ou fermer, changer les accès, la rendre normale.
- **Menu ALT, réservé au staff** :
  - sur un véhicule :
    - les occupants (nom et ID) s'affichent directement ;
    - supprimer le véhicule (DV), crever les pneus, faire descendre les occupants ;
    - réparer, déverrouiller, geler ;
  - sur un joueur :
    - TP sur lui ou TP à moi ;
    - faire descendre du véhicule, donner un véhicule (ajouté à son garage), gifler ;
    - **muter** : chat **et micro**, relancer démute.
- **Corrections** :
  - **invites E des extensions qui ne s'affichaient plus** (magasin de pêche, chasse, braquages…) après avoir ouvert certains magasins. C'est la cause des « le shop pêche ne s'ouvre pas » ;
  - un menu qui ne s'ouvre pas affiche maintenant pourquoi, au lieu de ne rien faire ;
  - l'invite « E pour interagir » ne sort plus de l'écran, même placée tout en haut ou sur un bord ; les textes courts restent à l'endroit choisi ;
  - **envoi d'un logo ou d'une bannière depuis le PC** qui restait bloqué sur « Envoi… ». Les morceaux arrivant dans le désordre sont maintenant acceptés, un envoi raté ne bloque plus le suivant, et la taille s'affiche pendant l'envoi.
- **Optimisation** : la recherche de portes en ALT ne tourne que pour le staff et seulement toutes les 0,5 s ; journal de l'atelier purgé automatiquement.

## Patch notes 57 — Entreprises sur mesure et toutes les icônes de la carte

- **Entreprises sur mesure** : crée autant d'entreprises que tu veux, avec le nom de ton choix (ex. « Benny's Motorworks », « Le Petit Café », « Garage du Port »). Tu choisis comment elle fonctionne parmi **tous les types du catalogue** (mécano, carrosserie, dépannage, café, restaurant, bar, boîte de nuit, taxi, supérette, armurerie, coiffeur…). Elle garde tout ce que fait ce type :
  - un mécano a son atelier, le droit de réparer et les dépannages ;
  - un café, un restaurant ou un bar a sa cuisine et son comptoir, avec la bonne carte (un café vend des cafés, pas le plat du jour) ;
  - un taxi a ses courses ;
  - et ainsi de suite.

  Grades, salaires et droits sont générés automatiquement.
  - **En jeu** : F10 › Builder › Entreprises › **Créer une entreprise sur mesure** (nom, type, icône), puis pose de ses points. Les entreprises sur mesure sont listées en haut du menu Entreprises.
  - **Dans le panel** : Entreprises › Catalogue › « Créer une entreprise sur mesure ».
- **Toutes les icônes de la carte** : un sélecteur affiche les **965 icônes de GTA** avec leur image. Les plus utiles (garage, bar, police…) sont en premier, avec recherche par nom ou par numéro, et choix de la couleur. Il est disponible :
  - à la création d'une entreprise ;
  - sur le siège d'une entreprise au Builder (« Voir toutes les icônes du jeu ») ;
  - dans le panel (Entreprises › Modifier).
- **Modifier une entreprise** : son type de fonctionnement et son icône se changent après coup, et le siège déjà posé prend la nouvelle icône.
- Les petits jobs (wb_jobs) suivent le type choisi : un garage renommé propose toujours les dépannages.

## Patch notes 58 — Appels vocaux au téléphone

- **Appels vocaux** (par pma-voice, déjà installé) : nouvelle application **Appels** sur le téléphone (F1).
  - **Clavier** pour composer un numéro, **appels récents** (durée, refusés, manqués) et **contacts** à appeler d'un clic ;
  - bouton **Appeler** sur chaque contact et dans chaque conversation ;
  - pastille rouge sur l'application quand tu as manqué un appel.
- **Appel entrant** :
  - un **bandeau** s'affiche en haut de l'écran, même téléphone fermé, avec une sonnerie ;
  - ouvre ton téléphone (F1) pour **décrocher** ou **refuser**, ou tape **/decrocher** et **/raccrocher** ;
  - pendant l'appel, le personnage porte le téléphone à l'oreille (à pied comme en voiture) et le bandeau affiche la durée.
- **Appeler un service** (police, EMS, mécano…) depuis l'Annuaire : **tous les employés en service sonnent**, le premier qui décroche prend l'appel.
- **Cas gérés** : ligne occupée, correspondant injoignable ou en « ne pas déranger », pas de réponse au bout de 30 s, joueur à terre ou déconnecté (l'appel se coupe), téléphone suspendu par le staff.
- **Sécurité** : chaque appel a un canal vocal tiré au hasard. Le serveur vérifie toutes les 3 s que personne n'écoute un appel qui n'est pas le sien : un tricheur est retiré du canal et c'est noté dans les journaux (anticheat).
- **Réglages** (panel › Téléphone › Réglages) : activer les appels, appels aux services, durée de la sonnerie, durée maximale d'un appel (30 min par défaut), nombre d'appels par minute. L'auto-test prévient si pma-voice ne tourne pas.

## Patch notes 59 — Radio F4, tickets reliés à Discord, anti-duplication, chronologie des joueurs

- **Poste radio sur F4** :
  - écran de talkie-walkie : fréquence tapée au pavé (puis OK) ou changée avec ◀ ▶, bouton marche / arrêt, volume (retenu d'une connexion à l'autre) ;
  - boutons rapides vers les canaux de ton métier (ex. « Police 1–10 ») ;
  - on parle en maintenant **Verr. Maj** (pma-voice utilisait ALT, déjà pris par le menu d'interaction : réglé dans `server.cfg`).
  - **Sécurité** : le serveur vérifie chaque fréquence (nombre entier, plages réservées, métier en service, objet « Radio » si exigé). Toutes les 3 s, un joueur entré de force sur une fréquence réservée, à terre ou qui a perdu son métier en est retiré, et la triche est notée dans les journaux.
  - Réglages : panel › Radio (touche, objet obligatoire, coupure à terre, fréquence maximale) et onglet **Aperçu**.
- **Tickets** :
  - **/ticket** ouvre une fenêtre de suivi : catégorie (aide, bug, plainte, remboursement, autre), conversation avec le staff, état, possibilité de clore soi-même ;
  - **/report** crée aussi un ticket ;
  - le joueur est prévenu à chaque réponse ;
  - le staff répond dans le **panel › Tickets** (ouverts / clos, conversation, clore, rouvrir) et garde le menu F10 pour prendre en charge et aller voir le joueur.
  - **Discord** : chaque ticket, réponse et clôture part sur Discord. Avec le bot du panel et l'identifiant du canal (Tickets › Réglages), **une réponse au message du ticket sur Discord revient en jeu**, et « !fermer » le clôt. Sans bot : webhook « Tickets des joueurs », envoi seulement.
- **Anti-duplication** (panel › Anti-duplication) :
  - alerte quand un joueur gagne plus de 150 000 $ en 1 h, ou reçoit plus de 250 objets identiques en 1 h (seuils réglables) ;
  - les objets sortis d'un coffre ou donnés par un autre joueur ne comptent pas, seuls les objets créés comptent ;
  - le staff en service est prévenu et l'alerte part sur Discord (canal « Alertes anti-duplication »), avec les principales sources de l'argent ;
  - pas de sanction automatique : une alerte peut venir d'un gros braquage réussi. On la classe « vue » ou « fausse alerte ».
- **Chronologie d'un joueur** (Anti-duplication › Chronologie, recherche par nom ou licence) : connexions et déconnexions, mouvements d'argent avec leur motif, objets reçus, sanctions, tickets, expulsions et journal du panel, du plus récent au plus ancien.
- **Téléphone** :
  - bouton **📍 position** dans une conversation : ta position (lue par le serveur) part en message, le destinataire appuie sur **Y aller** ;
  - **haut-parleur** pendant un appel : les personnes à moins de 3 m entendent l'appel (et peuvent y parler, comme un vrai haut-parleur).
- **Corrigé** : de nombreux champs du panel étaient refusés à tort (« format invalide »), par exemple **F4 comme raccourci du noclip**, les identifiants ou les listes « nom|valeur ». À l'inverse, certaines listes acceptaient n'importe quoi. Les formats sont maintenant lus exactement comme le serveur les vérifie.
- **Changé** : F4 n'est plus la touche par défaut du raccourci staff « téléportation au point GPS » (elle sert à la radio). Remets une touche dans Staff › Raccourcis si tu t'en servais.

## Patch notes 60 — Bar et discothèque, télévisions, 911, conférences, coma

- **Bar, discothèque, café, restaurant : le barman sert les clients** :
  - au point « cuisine / bar » (E), le barman en service choisit un produit de la carte et une quantité. La préparation prend quelques secondes (animation) et les **ingrédients sont payés par la caisse** de l'entreprise (30 % du prix, réglable). Les recettes à ingrédients restent accessibles depuis le même menu ;
  - puis **ALT sur un client › Servir** : il choisit le produit et la quantité, le client voit la commande et son prix, **accepte (il paie, espèces puis banque) ou refuse**. La caisse de l'entreprise encaisse ;
  - **Discothèque**, **Pub** et **Café** sont maintenant proposés dans F10 › Builder › Entreprises. Le « Club » s'appelle désormais « Discothèque ».
  - Réglages : Entreprises › Réglages › Service au bar.
- **Télévisions** :
  - **ALT sur une télé** (ou un écran de cinéma, un grand écran) › **Diffuser une vidéo**, puis colle un lien **YouTube** ou **Vimeo** ;
  - tous les joueurs autour voient la **même vidéo au même moment**, et le son monte en s'approchant ;
  - chacun règle son propre volume ;
  - **Arrêter** coupe l'écran. Le staff voit et coupe toutes les diffusions (panel › Télévisions). Seuls les sites autorisés passent : un lien quelconque serait chargé chez tout le monde.
- **Téléphone** :
  - **SOS 911** sur le clavier : tous les policiers et secouristes en service sonnent, et **ta position s'affiche sur leur carte** (point clignotant et itinéraire) ;
  - **conférence** : pendant un appel, « Ajouter » fait sonner un autre numéro, jusqu'à 5 personnes. Celui qui raccroche s'en va seul ;
  - **bloquer un numéro** (Contacts) : il ne peut plus t'écrire ni t'appeler. Liste des numéros bloqués avec « Débloquer » ;
  - **groupes de discussion** (Messages › icône groupe) : un nom, des numéros, les membres sont prévenus à chaque message. On peut quitter un groupe.
- **Coma de faim et de soif** : à 0, le personnage tombe dans le coma, avec l'écran d'inconscience (« Tu t'es évanoui de faim »). Un secouriste peut le réanimer (la faim et la soif remontent à 15 %), sinon il réapparaît à l'hôpital. Un avertissement s'affiche sous 10 %. Désactivable dans HUD › Besoins.
- **Builder** (F10 › Builder › une entreprise ou un groupe › un point posé) :
  - **Y aller et vérifier le sol** : téléportation, puis le jeu dit si le point est sous le sol, dans le vide ou en l'air ;
  - **Dupliquer ici** : copie le point à ta position (un coffre copié est vide) ;
  - **Tout déplacer : ce point vient ici** : tous les points suivent avec le même décalage, pratique pour changer de bâtiment.
- **Panel › Points posés** : carte de tous les points du serveur, liste des **problèmes** (position vide, hors carte, sous le niveau de la mer, doublon, très loin du siège) et bouton **Tester en jeu**.
- **Garage** (et application Garage du téléphone) : carburant, moteur et carrosserie de chaque véhicule (en direct s'il est sorti), et **Localiser sur la carte**.
- **Menu F10 › Rechercher** : un seul champ pour trouver un joueur (nom RP, nom FiveM, ID, licence), un véhicule (plaque) ou un numéro de téléphone.
- **Économie › Gains par activité** : argent versé par heure et **par joueur et par heure** pour chaque activité (pêche, chasse, petits jobs, braquages, salaires, bar…), sur 24 h et 7 jours. Les transferts entre joueurs sont affichés à part.

## Patch notes 61 — Points et étiquettes d'interaction, garage avec aperçu, noclip fantôme

- **Plus de flèches ni de texte en haut à gauche** :
  - chaque endroit où l'on peut interagir est marqué par un **petit point lumineux** à hauteur de poitrine ;
  - en s'approchant, une étiquette compacte **[E] GARAGE**, **[E] CUSTOMISER**… s'affiche **sur le point, dans le monde**, comme sur les serveurs de référence ;
  - partout : banques, garages, magasins, logements, points d'entreprise, TIG, carburant, drapeaux, drogues, braquages, et toutes les extensions (pêche, chasse, activités, animaux, atelier d'armes, braquages, portes, petits jobs, Burger Shot) ;
  - les placements au Builder gardent une invite en bas de l'écran (rien à quoi s'accrocher).
- **Garage en menu, avec aperçu** :
  - à l'ouverture, la liste des véhicules s'affiche dans le menu (même style que le menu staff) ;
  - **en descendant sur un véhicule, il apparaît en transparence à la sortie du garage**, avec ses couleurs, et une caméra le montre. L'aperçu n'est visible que par toi ;
  - Entrée sur un véhicule : Sortir, Récupérer ou Localiser. Clés et Organisation ouvrent la fenêtre complète.
- **Fourrière corrigée** :
  - une fourrière sans point de sortie faisait apparaître le véhicule nulle part : il sort maintenant à côté du point ;
  - un véhicule abandonné en ville est retiré du monde au moment de la récupération ;
  - **tu es mis directement au volant**, même si la sortie est un peu loin.
- **Noclip fantôme** : en noclip, **personne ne te voit**. Toi, tu te vois en **transparence**, et ton véhicule aussi si tu noclip en voiture. Tout redevient normal à la sortie (sauf si « Invisible » est activé).

## Patch notes 62 — Atelier mécano facturé, customisation en direct, menu Shadow retravaillé

- **Customisation chez le mécano** (point « atelier » au Builder, ou F2 › Atelier) :
  - le mécanicien en service doit être **dans le véhicule** du client ;
  - **chaque option survolée s'affiche directement sur la voiture** : le client voit le rendu et dit si ça lui va. Entrée l'ajoute au **devis**, et en quittant une liste la voiture revient à l'état du devis ;
  - **peinture** : principale et secondaire en classique / métallisé (≈ 75 teintes), mat, métal brossé, or et chrome, **teinte libre** (16 couleurs vives), nacré, intérieur, tableau de bord ;
  - **jantes** : tous les types (sport, muscle, lowrider, SUV, tout-terrain, tuner, haut de gamme, Benny's, rue, circuit…) avec tous leurs modèles, couleur des jantes, pneus personnalisés, fumée des pneus et sa couleur ;
  - **carrosserie** : aileron, pare-chocs, bas de caisse, échappement, arceau, calandre, capot, ailes, toit, livrées. Seules les pièces qui existent pour le modèle sont proposées ;
  - **Benny's** : sièges, volant, tableau de bord, compteurs, hydraulique, bloc moteur… ;
  - **performances** : moteur, freins, transmission, suspension, blindage, turbo ;
  - **éclairage** : xénons et leur couleur, néons (tout autour, côtés, avant / arrière) et leur couleur. Aussi : vitres teintées, style de plaque, klaxon ;
  - **Valider le devis** : le serveur calcule le prix lui-même (grille réglable dans le panel › Atelier mécanicien).
- **Facture au client** : F5 › Mon entreprise › **Envoyer la facture**, puis on choisit le client à côté.
  - Le client voit le détail et **paie** : l'argent va dans la **caisse de l'entreprise** et la customisation est **enregistrée avec son véhicule**.
  - S'il **refuse**, la customisation est retirée de la voiture.
  - Une facture payée plus tard depuis la tablette ou le téléphone compte aussi.
- **F5 › Mon entreprise (mécano en service)** : **Réparer** et **Nettoyer** le véhicule le plus proche (animation, durée vérifiée), puis **Envoyer la facture**. Prix réglables (réparation 500 $, nettoyage 100 $ par défaut).
- **Le mécano en service conduit les véhicules des clients** : il peut les ouvrir et les démarrer sans leur clé.
- **Tenue de service automatique** : à la prise de service, la tenue enregistrée au vestiaire de l'entreprise est enfilée (la combinaison Benny's pour le garage, l'uniforme pour la police…). À la fin du service, le joueur retrouve ses vêtements. Si aucune tenue n'est enregistrée, le patron est invité à la créer au vestiaire.
- **Menu Shadow retravaillé** : fond, bannière, traits, lignes, puces et icônes repris de la maquette (version reçue dans le zip), avec le défilement des longues listes conservé.
- **Inventaire** : titres « Sac à dos » et « Équipement » en français (les anciens étaient des images en anglais dont le sous-titre débordait sur la jauge de poids) ; les cases au-delà de la capacité d'un coffre n'affichent plus de cadenas « Premium ».
- **Portes (ALT staff)** : beaucoup plus de portes détectées (portes épaisses, doubles portes, grilles, portails, portes de garage), jusqu'à 16 autour de toi dans un rayon de 12 m ; une porte déjà enregistrée est toujours reconnue, quelle que soit sa forme.

## Patch notes 63 — Casino et repères de la carte
- **Nouveau** : Casino au Builder (Casino › Caisse / Jeu) : machine à sous, roulette, blackjack, roue de la fortune, dés, plus haut / plus bas, tickets à gratter, avec de vraies animations. Tous les tirages sont faits par le serveur.
- **Nouveau** : Jetons de casino dans l'inventaire (achetés et revendus à la caisse), loterie hebdomadaire avec cagnotte, casino de l'État ou d'une entreprise, statistiques et redistribution affichées.
- **Nouveau** : Repères : les doublons sont masqués automatiquement, les repères fantômes supprimés ; « /blips reset » ou Points posés › Repères des joueurs pour tout redessiner.
- **Corrigé** : Repères qui restaient sur la carte : joueur observé par le staff, animal de compagnie, alertes 911 et secours empilées.

## Patch notes 64 — La ville réagit (impayés, mandats, fourrière, secours)
- **Nouveau** : Factures et amendes impayées : majoration, puis saisie sur le compte (même hors ligne), puis mandat visible dans la tablette de la police.
- **Nouveau** : Véhicule abandonné ou disparu : envoyé en fourrière, SMS au propriétaire. Messages automatiques au téléphone (Trésor public, Fourrière, Hôpital…).
- **Nouveau** : Joueur à terre : les secouristes en service sont alertés tout seuls ; les frais d'hôpital vont à la caisse des secours, facture si le joueur n'a pas l'argent.
- **Amélioré** : Chronologie du joueur : factures, amendes, majorations, saisies, mandats, fourrières, comas, prison, réanimations.
- **Corrigé** : Employés restés « en service » après une déconnexion ; page Paie qui affichait toujours « payée par l'État ». Patron prévenu quand la caisse ne couvre plus la paie.

## Patch notes 65 — Taxi, dépanneuse, annonces, véhicules de service, logements
- **Nouveau** : Taxi : app Taxi du téléphone (commander, accepter), taximètre mesuré par le serveur, paiement automatique ou facture.
- **Nouveau** : Dépanneuse : un mécano en service avec un plateau charge un véhicule (ALT), le décharge ou le dépose à la fourrière contre une prime pour sa caisse.
- **Nouveau** : Véhicules de service d'entreprise (clé seulement en service) et clés prêtées pour 1 à 24 h.
- **Nouveau** : Téléphone : app Annonces (vente, achat, emploi, logement…) avec Écrire / Appeler l'auteur.
- **Nouveau** : Logements : loyer prélevé même hors ligne, expulsion après les impayés tolérés, affaires mises à la consigne, dette transmise à l'agence.
- **Amélioré** : Économie › Tableau de bord ; historique récent à côté du spectateur staff ; plus d'annonces de redémarrage en double.

## Patch notes 66 — Builder rangé, garages terrestres, aériens et navals
- **Amélioré** : Builder (F10 › Builder) : tout est rangé en 7 sections (Entreprises, Illégal, Commerces et services, Garages et véhicules, Immobilier et coffres, Activités, Autres) avec une recherche, au lieu d'une longue liste.
- **Nouveau** : Garages créés en jeu : on pose l'entrée, la sortie du véhicule et le PNJ, étape par étape ; garage, hangar d'avions, port, et une fourrière pour chacun.
- **Nouveau** : Garages séparés par type : un avion ne se range que dans un hangar, un bateau que dans un port ; icône de carte selon le type, PNJ au comptoir.
- **Corrigé** : Le groupe Casino n'apparaissait pas dans le Builder ; nom du jeu repris du préréglage choisi.

## Patch notes 67 — Ville vivante (ouvert / fermé, contrats, plaques, Discord, journaux)
- **Nouveau** : Entreprises ouvertes ou fermées : repère vert ou rouge sur la carte selon les employés en service, et annuaire du téléphone en direct (ouverts d'abord).
- **Nouveau** : Contrats de vente entre joueurs (app Contrats) : véhicule ou logement, signature à côté, paiement sécurisé et taxe de mutation.
- **Nouveau** : Plaques personnalisées (payantes, au garage) et fausses plaques pour les illégaux : la police ne retrouve plus le véhicule, retrait en ALT.
- **Nouveau** : Journal des morts (qui, par qui, arme, distance, position) et sauvegardes d'inventaire avec restauration à une date donnée.
- **Nouveau** : Discord ↔ personnage : rôles VIP, métier et groupe donnés et retirés tout seuls, pseudo du personnage, Discord obligatoire en option.

## Patch notes 68 — Largages, chasses au trésor, guerres de territoire
- **Nouveau** : Largage : une zone est annoncée, une caisse tombe, le premier qui l'ouvre gagne argent et objets. Chasse au trésor : la zone se resserre toutes les 3 minutes, il faut creuser au bon endroit.
- **Nouveau** : Lancement automatique (toutes les X minutes s'il y a assez de joueurs), planifié dans Événements, ou à la main depuis le panel.
- **Nouveau** : Guerres de territoire planifiées (jour et heure) : points de présence dans la zone et d'éliminations de rivaux, tableau des scores à l'écran, la zone et la récompense au vainqueur, historique.

## Patch notes 69 — Grande chasse aux bugs
- **Corrigé** : Duplication d'objets quand deux joueurs vident le même coffre en même temps ; aquarium et consigne qui pouvaient donner deux fois.
- **Corrigé** : Caisses (organisation, entreprise, casino, bar, atelier, missions) qui pouvaient payer deux fois ou passer dans le rouge sur un double clic.
- **Corrigé** : Garage : on ne range plus une voiture laissée ailleurs (doublon). Fourrière et atelier : la plaque est lue par le serveur, plus de saisie ou de tuning à distance.
- **Corrigé** : Location remboursée même véhicule détruit ; magasin qui encaissait sans donner l'objet ; remboursement accepté alors que le client n'avait plus les articles ; achat de logement payé sans être attribué en cas d'erreur.
- **Corrigé** : Se déconnecter menotté ne libère plus (toujours menotté à la reconnexion, police prévenue) ; virements à soi-même refusés.
- **Corrigé** : Braquages : un distributeur payé deux fois, GoFast livré avec n'importe quel véhicule. Fabrication (armes, activités) qui donnait l'objet même si les pièces manquaient.
- **Corrigé** : Discord : synchronisations étalées (plus de limite de débit), pseudo envoyé seulement s'il change.

## Patch notes 70 — Poker entre joueurs, historique du casino
- **Nouveau** : Poker Texas Hold'em entre joueurs (Builder › Casino › Jeu › Poker) : 2 à 6 places, cave en jetons, blindes, relances, tapis et pots secondaires, temps de parole, commission du casino dès le flop.
- **Nouveau** : Casino › Mes parties : bilans du jour, de la semaine et depuis toujours, jeu préféré, plus gros gain, dernières parties. Panel › Casino › Joueurs : classement des gagnants et perdants.

## Patch notes 71 — Hélipad, où est ma voiture, meubles à vendre, tenue de service
- **Nouveau** : Hélipad d'entreprise (Builder › entreprise › Hélipad) et catalogue de véhicules de service achetés avec la caisse : hélicoptères à l'hélipad, voitures au garage, bateaux au port ; revente à 50 %.
- **Nouveau** : Téléphone › Garage : où est chaque véhicule (en direct, dernière position connue, garage, fourrière la plus proche), itinéraire et repère sur la carte ; véhicules de service et clés prêtées listés aussi.
- **Nouveau** : Meubles en objets : Magasin de meubles au Builder, on pose ses meubles chez soi et ils reviennent dans le sac quand on les retire. App Contrats : vente d'objets entre joueurs (meubles et autres), paiement sécurisé.
- **Amélioré** : Tenue de service : la dernière tenue enfilée au vestiaire devient sa tenue de service ; chacun peut désactiver la tenue automatique.
- **Corrigé** : Licence : la limite de joueurs et le blocage sans licence ne s'appliquaient pas (erreur dans la connexion).

## Patch notes 72 — Nouveau menu ALT, drapeaux de vente, tournois de poker, badge
- **Amélioré** : Menu ALT refait : petite boîte bleu nuit, texte seul, barre bleue sur la ligne survolée, les catégories s'ouvrent dedans et « Retour » remonte. Les anciens styles restent au choix dans le panel.
- **Amélioré** : Drapeaux de vente redessinés (vrai drapeau rectangulaire qui flotte dans le vent, emblème, blanc quand la zone est neutre). Plus de texte au-dessus du drapeau : l'état de la zone s'affiche sur le côté de l'écran.
- **Nouveau** : Poker : tournois (droit d'entrée, jetons de tournoi, blindes qui doublent, cagnotte partagée entre les premiers, classement dans le panel) et tables privées avec mot de passe.
- **Nouveau** : Croupiers du casino aux tables (blackjack, roulette, dés, plus haut / plus bas, poker) avec un geste à chaque donne.
- **Nouveau** : Badge d'employé : ALT › Métier › Montrer mon badge (entreprise, grade, matricule, en service ou non).

## Patch notes 73 — Menu ALT comme la référence, corrections
- **Amélioré** : Menu ALT : large boîte bleu ardoise translucide, texte blanc bien espacé, pastille bleu cyan sur la ligne choisie, sans surlignage.
- **Corrigé** : À la déconnexion, le joueur disparaissait avant que les autres scripts ne le lisent : le service n'était pas toujours remis à zéro et la déconnexion n'apparaissait pas dans la chronologie.
- **Corrigé** : Points d'entreprise et sacs au sol : demandes limitées (un client modifié pouvait surcharger la base de données).

## Patch notes 74 — Fusion 1.2.2, inventaire d'origine conservé, corrections
- **Amélioré** : Tout le travail des patchs 63 à 73 est intégré (casino, poker, taxi, contrats, guerres de territoire, largages, Builder rangé…), sauf le nouvel inventaire : l'inventaire d'origine est gardé (couleur du serveur, décor assombri, flou). Les protections anti-duplication de l'inventaire sont bien reprises.
- **Corrigé** : Un serveur passé par la 1.2.2 retrouve automatiquement l'apparence d'origine de l'inventaire (une seule fois, réglable ensuite dans le panel).
- **Corrigé** : Loterie du casino : le prochain tirage pouvait être décalé d'une heure au changement d'heure été / hiver.
- **Corrigé** : Téléphone : les apps (Contrats, Annonces…) plantaient au démarrage du serveur ; Économie › Contrats ne s'ouvrait pas dans le panel.
