-- Interfaces (panel › Interfaces) : écrans de chargement, salle du créateur, regroupement des repères sur la carte, tenues de la communauté.
local G, DB = PB.G, PB.DB
local ns = 'uida'
local DEFAULT_BLIPS = { '52=Magasin: Supérette', '73=Magasin de vêtements', '110=Armurerie: Ammu-Nation', '71=Salon de coiffure', '75=Salon de tatouage', '108=Établissement bancaire: Banque', '277=Banque: Distributeur de billets',
    '357=Garages: Parking', '50=Garages: Parking', '361=Station-service', '326=Concessionnaire', '225=Concessionnaire: Voitures', '60=Service public: Police', '61=Service public: Hôpital', '72=Mécanicien', '446=Mécanicien', '40=Immobilier: Habitation', '93=Boîte de nuit' }
PB.Cfg.Define(ns, { ls_title = 'Bienvenue sur {serveur}', ls_text = 'Le jeu se prépare. La durée dépend de votre connexion et de votre machine : ne fermez pas le jeu.', ls_color = '', ls_logo = '', ls_bg = {}, ls_discord = '', ls_shop = '', ls_music = {}, ls_music_title = 'Ambiance', ls_music_sub = '',
    boot_kick = 'Préparation de votre session', boot_title = 'Bonjour {nom}…', boot_text = 'Votre personnage arrive en ville. Le chargement ne prend que quelques instants : ne fermez pas le jeu.',
    room = { x = 402.92, y = -996.72, z = -100.0, h = 180.0 }, blips_on = true, blips = DEFAULT_BLIPS, outfits_shared = true, outfits_shared_max = 1, bank_color = '#27a04f', wd_color = '#d9262e', wd_piece = 0 })
local function cfg(k, d) return PB.Cfg.Get(ns, k, d) end

-- l'écran de chargement n'a pas accès à la configuration : elle lui est passée à la connexion
function G.LoadscreenData()
    local name = PB.Cfg.Get('general', 'server_name', '')
    if name == '' then name = (tostring(GetConvar('sv_projectName', '')):gsub('%^%d', ''):gsub('|.*$', ''):gsub('^%s+', ''):gsub('%s+$', '')) end
    local color = cfg('ls_color', '')
    if color == '' then color = PB.Cfg.Get('general', 'color_primary', '') end
    return { wb = { serveur = name, titre = cfg('ls_title', ''), texte = cfg('ls_text', ''), couleur = color, logo = cfg('ls_logo', ''), fonds = cfg('ls_bg', {}), discord = cfg('ls_discord', ''), boutique = cfg('ls_shop', ''),
        musiques = cfg('ls_music', {}), ambiance = cfg('ls_music_title', 'Ambiance'), radio = cfg('ls_music_sub', '') } }
end

-- quitter depuis l'écran de choix du personnage
RegisterNetEvent('pb:g:charquit', function()
    DropPlayer(source, 'À bientôt !')
end)

-- Tenues (vestiaire) ---------------------------------------------------------------------------------------------------------------------
PB.Migrate('533_outfit_shared', 'Vestiaire : tenues publiées par les joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_outfit_shared (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, author VARCHAR(64) NOT NULL, label VARCHAR(32) NOT NULL, sex VARCHAR(1) NOT NULL, data LONGTEXT NOT NULL, buys INT NOT NULL DEFAULT 0, at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_sex (sex, buys), KEY k_lic (license))]],
})
local function sexOf(p) local s = p.row.sex return (s == 'f' or s == 'female' or s == 1) and 'f' or 'm' end
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)
local function send(src)
    local p = G.Get(src)
    if not p then return end
    local mine, shared = {}, {}
    for _, r in ipairs(DB.q('SELECT id, label, data FROM pb_saved_outfits WHERE license = ? AND sex = ? ORDER BY id', { p.license, sexOf(p) }) or {}) do
        mine[#mine + 1] = { id = r.id, label = r.label, data = PB.FromJson(r.data, nil) }
    end
    if cfg('outfits_shared', true) then
        for _, r in ipairs(DB.q('SELECT id, label, author, buys, data, license FROM pb_outfit_shared WHERE sex = ? ORDER BY buys DESC, id DESC LIMIT 60', { sexOf(p) }) or {}) do
            shared[#shared + 1] = { id = r.id, label = r.label, author = r.author, buys = r.buys, data = PB.FromJson(r.data, nil), mine = r.license == p.license or nil }
        end
    end
    TriggerClientEvent('pb:g:wd:data', src, PB.Json({ mine = mine, shared = shared, shared_on = cfg('outfits_shared', true), max = G.Vip and G.Vip.OutfitsMax and G.Vip.OutfitsMax(p.license) or 10 }))
end
RegisterNetEvent('pb:g:wd:list', function() local src = source if throttle(src, 300) then send(src) end end)
-- enregistrer ce que le joueur porte (mêmes règles et même sac que « Mes tenues »)
RegisterNetEvent('pb:g:wd:save', function(label)
    local src = source
    if not throttle(src, 800) or not G.Tenues then return end
    local ok, msg = G.Tenues.Save(src, tostring(label or ''))
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Tenues', text = msg })
    send(src)
end)
RegisterNetEvent('pb:g:wd:delete', function(id)
    local src = source
    if not throttle(src, 500) or not G.Tenues or not G.Tenues.Delete then return end
    local ok, msg = G.Tenues.Delete(src, tonumber(id) or -1)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Tenues', text = msg }) end
    send(src)
end)
-- publier une de ses tenues dans le vestiaire de la communauté
RegisterNetEvent('pb:g:wd:publish', function(id)
    local src = source
    if not throttle(src, 800) or not cfg('outfits_shared', true) then return end
    local p = G.Get(src)
    if not p then return end
    local row = DB.one('SELECT * FROM pb_saved_outfits WHERE id = ? AND license = ?', { tonumber(id) or -1, p.license })
    if not row then return end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_outfit_shared WHERE license = ?', { p.license })
    local mx = tonumber(cfg('outfits_shared_max', 1)) or 1
    if n and tonumber(n.n) >= mx then G.Notify(src, { type = 'warn', title = 'Communauté', text = ('Tu as déjà %d tenue(s) publiée(s) : limite atteinte.'):format(tonumber(n.n)) }) return end
    local author = ((p.row.firstname or '') .. ' ' .. (p.row.lastname or '')):sub(1, 64)
    DB.exec('INSERT INTO pb_outfit_shared (license, author, label, sex, data, at) VALUES (?, ?, ?, ?, ?, ?)', { p.license, author, row.label, row.sex, row.data, os.time() })
    G.Notify(src, { type = 'success', title = 'Communauté', text = ('« %s » est publiée.'):format(row.label) })
    send(src)
end)
RegisterNetEvent('pb:g:wd:unpublish', function(id)
    local src = source
    local p = G.Get(src)
    if not p or not throttle(src, 500) then return end
    DB.exec('DELETE FROM pb_outfit_shared WHERE id = ? AND license = ?', { tonumber(id) or -1, p.license })
    send(src)
end)
-- compté quand une tenue publiée est achetée (appelé par shops.lua après le paiement)
function G.OutfitBought(id) if tonumber(id) then DB.exec('UPDATE pb_outfit_shared SET buys = buys + 1 WHERE id = ?', { tonumber(id) }) end end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
local RES = '^[%w%-%._~:/%%%?=&+ ]+$'
local form = PB.Form.Cfg({ ns = ns, id = 'settings', title = 'Interfaces', perm = 'general.edit', cols = 2, desc = "Écrans de chargement, salle du créateur et repères de la carte. La couleur des interfaces se règle dans Inventaire › Couleur d'accent.", fields = {
    { k = 'ls_bg', type = 'list', label = 'Images des écrans de chargement (chargement, connexion, arrivée)', default = {}, maxitems = 12, maxlen = 200, pattern = RES, wide = true, hint = 'Une par ligne : une adresse https://… ou un fichier déposé dans wb_loading/fond/ (ex. fond/ville.jpg). Plusieurs images défilent en fondu ; elles sont floues puis se précisent. Vide : fond uni et illustration du serveur. Le rendu ci-dessus se met à jour à l\'enregistrement.' },
    { k = 'ls_music', type = 'list', label = 'Musiques', default = {}, maxitems = 20, maxlen = 200, pattern = RES, wide = true, hint = "Fichiers audio : déposés dans wb_loading/musique/ (ex. musique/theme.mp3) ou adresse https:// directe. Vide : pas de lecteur. Jouées au chargement, au choix du personnage et au créateur." },
    { k = 'ls_music_title', type = 'text', label = 'Lecteur : titre', default = 'Ambiance', maxlen = 32 },
    { k = 'ls_music_sub', type = 'text', label = 'Lecteur : sous-titre', default = '', maxlen = 40, hint = 'Vide : le nom du fichier.' },
    { k = 'boot_kick', type = 'text', label = 'Avant la ville : surtitre', default = 'Préparation de votre session', maxlen = 60 },
    { k = 'boot_title', type = 'text', label = 'Avant la ville : titre', default = 'Bonjour {nom}…', maxlen = 60, hint = '{nom} = prénom du personnage.' },
    { k = 'boot_text', type = 'area', label = 'Avant la ville : texte', default = 'Votre personnage arrive en ville. Le chargement ne prend que quelques instants : ne fermez pas le jeu.', maxlen = 300, wide = true },
    { k = 'room', type = 'coords', label = 'Salle du créateur (choix homme/femme)', wide = true, hint = "Par défaut la salle d'identité de GTA Online. Sol et orientation : le personnage y fait face à la caméra." },
    { k = 'bank_color', type = 'color', label = 'Couleur de la banque', default = '#27a04f' },
    { k = 'wd_color', type = 'color', label = 'Couleur des magasins de vêtements', default = '#d9262e' },
    { k = 'wd_piece', type = 'number', label = 'Prix par pièce de vêtement', default = 0, min = 0, max = 1000000, hint = "0 : le prix du magasin, quel que soit le nombre de pièces changées." },
    { k = 'blips_on', type = 'toggle', label = 'Regrouper les repères de la carte', default = true, wide = true, hint = 'Les repères de même icône portent le même nom : la légende de la carte les range sur une seule ligne « ‹ 1/20 › ».' },
    { k = 'blips', type = 'list', label = 'Noms des groupes', default = DEFAULT_BLIPS, maxitems = 80, maxlen = 64, pattern = '^%d+=.+$', wide = true, hint = 'Une ligne par icône : numéro=Catégorie: Nom. Une icône absente garde son propre nom.' },
    { k = 'outfits_shared', type = 'toggle', label = 'Vestiaire : tenues de la communauté', default = true },
    { k = 'outfits_shared_max', type = 'number', label = 'Tenues publiées par joueur', default = 1, min = 1, max = 20 },
} })
PB.Module({
    id = 'uida', label = 'Interfaces', icon = 'sliders', group = 'Serveur', order = 18, perm = 'general.edit', hint = 'Écrans de chargement, créateur, repères groupés',
    caps = function() return PB.Capsify({
        { 'Écran de chargement et écran avant la ville', 'ok', 'Fond, textes, couleur, liens et musique se règlent ici.' },
        { 'Repères groupés', 'ok', 'Par icône ; les noms se règlent ici.' },
        { 'Vérifié dans un vrai client FiveM', 'off', 'Non : testé en simulation et dans un navigateur.' } }) end,
    doc = "## Interfaces\nRègle les écrans de chargement, la salle du créateur et le regroupement des repères.\n\nLes images peuvent être déposées dans `wb_loading/fond/`.",
    view = function(ctx)
        return { tabs = { { id = 'settings', label = 'Réglages', icon = 'sliders', build = function()
            return { { type = 'loadprev', title = 'Rendu des écrans de chargement', images = cfg('ls_bg', {}), name = PB.Cfg.Get('general', 'server_name', ''), hello = cfg('boot_title', ''):gsub('{nom}', 'Prénom') }, form(ctx) }
        end } } }
    end,
})
