@echo off
chcp 65001 >nul
cd /d "%~dp0"
del /f /q "[w-base]\pb_panel\client\drugslab.lua" 2>nul
echo Anciens fichiers supprimes.
pause