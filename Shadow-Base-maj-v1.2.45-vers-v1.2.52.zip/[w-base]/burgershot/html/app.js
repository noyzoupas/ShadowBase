// Burger Shot — interface : borne de commande, écran de cuisine, mini-jeux, suivi, note.
let BRAND = "Burger Shot";   // nom du restaurant (config de la ressource)
const RES = typeof GetParentResourceName === "function" ? GetParentResourceName() : null;
const post = (name, data = {}) => {
  if (!RES) { (window.__posts = window.__posts || []).push([name, data]); return; }
  fetch(`https://${RES}/${name}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).catch(() => {});
};
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => `${Math.round(Number(n) || 0).toLocaleString("fr-FR")} $`;
const show = (id, on) => $(id).classList.toggle("hidden", !on);
const isShown = (id) => !$(id).classList.contains("hidden");
if (!RES) document.body.classList.add("preview");

// Image du jeu, sinon émoji
function pic(item, cls = "pic") {
  const img = item.img ? `<img src="${esc(item.img)}" data-emo="${esc(item.emoji || "🍔")}" alt="">` : `<span class="emo">${esc(item.emoji || "🍔")}</span>`;
  return `<div class="${cls}">${img}</div>`;
}
function fixImages(root) {
  root.querySelectorAll("img[data-emo]").forEach((img) => {
    img.addEventListener("error", () => { const s = document.createElement("span"); s.className = "emo"; s.textContent = img.dataset.emo; img.replaceWith(s); }, { once: true });
  });
}

// =====================================================================================================================================
// Borne de commande
// =====================================================================================================================================
let K = null, cart = [], cat = "menus", mode = "counter", pay = "cash", busy = false, doneTimer = null;
const byId = (id) => K.items.find((i) => i.id === id);

function openKiosk(data) {
  K = data; cart = []; mode = "counter"; pay = "cash"; busy = false;
  if (data && data.brand) BRAND = String(data.brand);
  cat = (data.categories[0] || {}).id || "menus";
  $("k-hello").textContent = `Bonjour ${data.name || ""} 👋 Qu’est-ce qui te ferait plaisir ?`;
  const st = $("k-status");
  st.className = "chip" + (data.staff > 0 ? " ok" : "");
  st.textContent = data.staff > 0 ? `Ouvert · ${data.staff} équipier${data.staff > 1 ? "s" : ""}` : data.auto ? "Cuisine automatique · retrait au comptoir" : "Fermé";
  $("k-fee").textContent = data.fee > 0 ? `+${money(data.fee)}` : "offerte";
  $("k-cash").textContent = money(data.cash);
  $("k-bank").textContent = money(data.bank);
  show("k-closed", !data.open); show("k-done", false); show("k-choice", false);
  $("k-err").textContent = "";
  renderCats(); renderGrid(); renderCart();
  show("kiosk", true);
}
function closeKiosk() { clearTimeout(doneTimer); show("kiosk", false); K = null; post("close"); }

function renderCats() {
  $("k-cats").innerHTML = K.categories.filter((c) => K.items.some((i) => i.cat === c.id))
    .map((c) => `<button data-cat="${esc(c.id)}" class="${c.id === cat ? "on" : ""}"><span>${esc(c.emoji)}</span>${esc(c.label)}</button>`).join("");
}
function renderGrid() {
  const c = K.categories.find((x) => x.id === cat);
  const items = K.items.filter((i) => i.cat === cat);
  $("k-grid").innerHTML = `<h2>${esc(c ? c.label : "")}</h2>` + items.map((i) => `
    <button class="card" data-add="${esc(i.id)}">
      ${i.cat === "menus" && i.price >= 20 ? '<span class="badge">BEST-SELLER</span>' : ""}
      ${pic(i)}
      <h4>${esc(i.label)}</h4>
      <p>${esc(i.contents ? i.contents.join(" + ") + " + boisson" : i.desc)}</p>
      <div class="row"><span class="kcal">${i.kcal ? i.kcal + " kcal" : ""}</span><span class="price">${money(i.price)}</span><span class="add">+</span></div>
    </button>`).join("");
  fixImages($("k-grid"));
}
function subtotal() { return cart.reduce((s, l) => s + byId(l.id).price * l.qty, 0); }
function total() { return subtotal() + (mode === "delivery" ? K.fee : 0); }
function units() { return cart.reduce((s, l) => s + l.qty * (byId(l.id).contents ? byId(l.id).contents.length + 1 : 1), 0); }

function renderCart() {
  const lines = $("k-lines");
  if (!cart.length) lines.innerHTML = `<div class="empty"><span>🛒</span>Choisis tes produits<br>à gauche</div>`;
  else lines.innerHTML = cart.map((l, n) => {
    const it = byId(l.id);
    const ch = l.choice ? (it.choice.find((c) => c.id === l.choice) || {}).label : "";
    return `<div class="line"><span class="e">${esc(it.emoji)}</span><div><b>${esc(it.label)}</b><small>${ch ? "avec " + esc(ch) + " · " : ""}${money(it.price * l.qty)}</small></div>
      <div class="qty"><button data-dec="${n}">−</button>${l.qty}<button data-inc="${n}">+</button></div></div>`;
  }).join("");
  document.querySelectorAll("#k-mode button").forEach((b) => {
    b.classList.toggle("on", b.dataset.mode === mode);
    b.disabled = b.dataset.mode === "delivery" && K.staff === 0;
    if (b.dataset.mode === "delivery") b.style.display = K.nodelivery ? "none" : "";   // restaurant sans livraison
  });
  document.querySelectorAll("#k-pay button").forEach((b) => b.classList.toggle("on", b.dataset.pay === pay));
  const t = total(), funds = pay === "bank" ? K.bank : K.cash;
  $("k-total").textContent = money(t);
  const btn = $("k-paybtn");
  btn.disabled = busy || !cart.length || t > funds;
  btn.textContent = busy ? "Paiement…" : cart.length ? `Payer ${money(t)}` : "Payer";
  $("k-err").textContent = cart.length && t > funds ? (pay === "bank" ? "Solde bancaire insuffisant." : "Pas assez d’espèces sur toi.") : "";
}
function addToCart(id, choice) {
  const i = cart.findIndex((l) => l.id === id && l.choice === choice);
  if (units() >= 20) { $("k-err").textContent = "20 articles maximum par commande."; return; }
  if (i >= 0) cart[i].qty = Math.min(10, cart[i].qty + 1); else cart.push({ id, qty: 1, choice });
  const card = document.querySelector(`[data-add="${CSS.escape(id)}"]`);
  if (card) { card.classList.remove("bump"); void card.offsetWidth; card.classList.add("bump"); }
  renderCart();
}
function askChoice(item) {
  const box = $("k-choice");
  box.innerHTML = `<div class="box"><h3>${esc(item.label)}</h3><p class="muted">Choisis ta boisson</p>
    <div class="opts">${item.choice.map((c) => `<button data-choose="${esc(c.id)}"><span>${esc(c.emoji)}</span>${esc(c.label)}</button>`).join("")}</div>
    <button class="link" data-choose="">Annuler</button></div>`;
  box.dataset.item = item.id;
  show("k-choice", true);
}
function showDone(o) {
  const lines = (o.lines || []).map((l) => `<li><span>${l.qty} × ${esc(l.label)}${l.choice ? " (" + esc(l.choice) + ")" : ""}</span></li>`).join("");
  const msg = o.state === "auto"
    ? "Notre cuisine automatique prépare ta commande. Elle t’attendra au comptoir."
    : o.mode === "delivery"
      ? "Un livreur va te l’apporter où que tu sois. Suis-le en bas à droite de ton écran."
      : "Un équipier la prépare et te l’apporte. Reste dans le coin !";
  $("k-done").innerHTML = `<div class="ticket"><div class="lbl">Ta commande</div><div class="num">#${o.id}</div><ul>${lines}</ul>
    <div class="tot"><span>Payé</span><span>${money(o.total)}</span></div></div><h2>Merci !</h2><p>${msg}</p><button class="pay" data-close>Fermer</button>`;
  show("k-done", true);
  doneTimer = setTimeout(() => { if (isShown("kiosk")) closeKiosk(); }, 12000);
}

$("kiosk").addEventListener("click", (e) => {
  const t = e.target.closest("button");
  if (!t) return;
  if (t.hasAttribute("data-close")) return closeKiosk();
  if (t.dataset.cat) { cat = t.dataset.cat; renderCats(); renderGrid(); return; }
  if (t.dataset.add) { const it = byId(t.dataset.add); return it.choice && it.choice.length ? askChoice(it) : addToCart(it.id); }
  if (t.dataset.choose !== undefined) { const id = $("k-choice").dataset.item; show("k-choice", false); if (t.dataset.choose) addToCart(id, t.dataset.choose); return; }
  if (t.dataset.inc) { const l = cart[+t.dataset.inc]; if (units() < 20) l.qty = Math.min(10, l.qty + 1); return renderCart(); }
  if (t.dataset.dec) { const n = +t.dataset.dec; cart[n].qty--; if (cart[n].qty <= 0) cart.splice(n, 1); return renderCart(); }
  if (t.dataset.mode && !t.disabled) { mode = t.dataset.mode; return renderCart(); }
  if (t.dataset.pay) { pay = t.dataset.pay; return renderCart(); }
  if (t.id === "k-paybtn" && !t.disabled) {
    busy = true; renderCart();
    post("order", { lines: cart.map((l) => ({ id: l.id, qty: l.qty, choice: l.choice })), mode, pay });
  }
});

// =====================================================================================================================================
// Écran de cuisine
// =====================================================================================================================================
let Q = [], me = null, manager = false, qAt = Date.now(), clockTimer = null;
const sure = {}, taking = {};   // confirmations d'annulation et prises en cours (gardées entre deux rafraîchissements)
const STATE_COL = { paid: "new", cooking: "cook", cooked: "cook", ready: "ready", counter: "ready", auto: "ready" };
const STATE_TXT = { paid: "", cooking: "en préparation", cooked: "à emballer", ready: "en main", counter: "au comptoir", auto: "cuisine auto" };

function openKds(data, list) {
  const s = data.stats || {};
  $("kds-stats").innerHTML = `<span class="stat">Mes commandes<b>${s.orders || 0}</b></span><span class="stat">Gagné ce service<b>${money(s.earned || 0)}</b></span>` +
    (data.balance != null ? `<span class="stat">Caisse<b>${money(data.balance)}</b></span>` : "");
  renderQueue(list || Q, me, manager);
  show("kds", true);
  clearInterval(clockTimer);
  clockTimer = setInterval(() => { tickClock(); tickQueue(); }, 1000);   // chaque seconde : seulement les chronos (reconstruire les tickets les faisait clignoter)
  tickClock();
}
function tickClock() { const d = new Date(); $("kds-clock").textContent = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }); }
function closeKds() { clearInterval(clockTimer); show("kds", false); post("close"); }
function age(o) { const a = o.age + Math.floor((Date.now() - qAt) / 1000); return a; }
function mmss(s) { s = Math.max(0, s); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; }

function ticket(o) {
  const a = age(o);
  const cls = ["tk", a > 360 ? "late" : a > 180 ? "warn" : "", (o.cookId === me || o.carrierId === me) ? "mine" : ""].join(" ");
  const modeTag = o.npc ? `<span class="mode npc">PNJ · ${esc(o.address || "livraison")}</span>` : o.mode === "delivery" ? '<span class="mode del">Livraison</span>' : '<span class="mode">Sur place</span>';
  const who = o.cook ? `Cuisine : ${esc(o.cook)}` : o.carrier ? `En main : ${esc(o.carrier)}` : STATE_TXT[o.state] || "en attente";
  const steps = (o.stations || []).map((s) => `<span class="step ${s.done ? "done" : ""}">${s.done ? "✓ " : ""}${esc(s.label)} ×${s.need}</span>`).join("");
  let actions = "";
  if (o.state === "paid") actions += taking[o.id] > Date.now() ? `<button class="btn" disabled>…</button>` : `<button class="btn" data-take="${o.id}">Prendre en charge</button>`;
  if (manager && o.state !== "auto") actions += sure[o.id] > Date.now() ? `<button class="btn ghost" data-cancel="${o.id}" data-sure="1">Confirmer l’annulation ?</button>` : `<button class="btn ghost" data-cancel="${o.id}">Annuler · rembourser</button>`;
  return `<div class="${cls}" data-oid="${o.id}"><div class="tk-top"><span class="tk-num">#${o.id}</span><div class="tk-who">${esc(o.name)}<small>${who}</small></div>${modeTag}<span class="tk-age">${mmss(a)}</span></div>
    <ul>${(o.items || []).map((i) => `<li><b>${i.qty}×</b>${esc(i.emoji)} ${esc(i.label)}</li>`).join("")}</ul>
    ${steps ? `<div class="steps">${steps}</div>` : ""}${actions ? `<div class="tk-actions">${actions}</div>` : ""}</div>`;
}
// Met à jour l'âge et la couleur des tickets déjà affichés, sans les recréer
function tickQueue() {
  Q.forEach((o) => {
    const el = document.querySelector(`#kds .tk[data-oid="${o.id}"]`);
    if (!el) return;
    const a = age(o);
    const t = el.querySelector(".tk-age"); if (t) t.textContent = mmss(a);
    el.classList.toggle("late", a > 360); el.classList.toggle("warn", a > 180 && a <= 360);
  });
}
function renderQueue(list, meId, isManager, tickOnly) {
  if (!tickOnly) { Q = list || []; me = meId ?? me; manager = !!isManager; qAt = Date.now(); }
  const cols = { new: [], cook: [], ready: [] };
  Q.forEach((o) => { const c = STATE_COL[o.state]; if (c) cols[c].push(o); });
  const fill = (id, arr, empty) => { $(id).innerHTML = arr.length ? arr.map(ticket).join("") : `<div class="none">${empty}</div>`; };
  fill("col-new", cols.new, "Aucune commande en attente 👌");
  fill("col-cook", cols.cook, "Rien sur le feu");
  fill("col-ready", cols.ready, "—");
  $("c-new").textContent = cols.new.length; $("c-cook").textContent = cols.cook.length; $("c-ready").textContent = cols.ready.length;
}
$("kds").addEventListener("click", (e) => {
  const t = e.target.closest("button");
  if (!t) return;
  if (t.hasAttribute("data-close")) return closeKds();
  if (t.dataset.take) { taking[t.dataset.take] = Date.now() + 3000; post("take", { id: +t.dataset.take }); renderQueue(Q, me, manager, true); }
  if (t.dataset.cancel) {
    if (t.dataset.sure) { delete sure[t.dataset.cancel]; post("cancel", { id: +t.dataset.cancel }); }
    else sure[t.dataset.cancel] = Date.now() + 5000;
    renderQueue(Q, me, manager, true);
  }
});

// =====================================================================================================================================
// Mini-jeux des postes
// =====================================================================================================================================
let G = null;
const HELP = {
  flip: "Retourne le steak quand le curseur est dans la zone verte. Trop tard, il brûle !",
  fry: "Maintiens ESPACE pour plonger le panier, relâche dans la zone dorée.",
  fill: "Maintiens ESPACE pour remplir le gobelet, relâche entre les pointillés.",
  timing: "Appuie sur ESPACE quand le curseur passe dans la zone verte.",
  combo: "Reproduis la suite de flèches avant la fin du temps.",
};
function startGame(g) {
  if (G) { G.running = false; cancelAnimationFrame(G.raf); }
  const rounds = Math.max(1, Math.min(3, g.count || 1));
  G = { ...g, rounds, round: 0, scores: [], diff: g.difficulty || 1, running: false };
  $("g-title").textContent = `${g.label} — ${g.verb} ×${g.count}`;
  $("g-help").textContent = HELP[g.game] || "";
  $("g-feedback").textContent = ""; $("g-feedback").className = "g-feedback";
  $("g-stage").innerHTML = `<div class="patty">${{ flip: "🥩", fry: "🍟", fill: "🥤", timing: "🍦", combo: "🍔" }[g.game] || "🍔"}</div>`;
  dots();
  show("game", true);
  const cur = G;
  setTimeout(() => { if (G === cur) nextRound(); }, 500);
}
function dots() {
  $("g-rounds").innerHTML = Array.from({ length: G.rounds }, (_, i) => {
    const s = G.scores[i];
    return `<i class="${s == null ? (i === G.round ? "cur" : "") : s >= 75 ? "ok" : s >= 40 ? "mid" : "bad"}"></i>`;
  }).join("");
}
function feedback(s) {
  const f = $("g-feedback");
  f.className = "g-feedback " + (s >= 75 ? "ok" : s >= 40 ? "mid" : "bad");
  f.textContent = s >= 90 ? "PARFAIT !" : s >= 75 ? "Très bien" : s >= 40 ? "Correct" : "Raté…";
}
function endRound(score) {
  if (!G || !G.running) return;
  G.running = false;
  cancelAnimationFrame(G.raf);
  score = Math.max(0, Math.min(100, Math.round(score)));
  G.scores.push(score); feedback(score); G.round++; dots();
  const cur = G;   // les minuteurs ne touchent que la partie qui les a lancés
  if (G.round >= G.rounds) {
    const avg = G.scores.reduce((a, b) => a + b, 0) / G.scores.length;
    setTimeout(() => { if (G !== cur) return; show("game", false); post("gameDone", { score: Math.round(avg) }); G = null; }, 1100);
  } else setTimeout(() => { if (G === cur) nextRound(); }, 900);
}
function zoneScore(pos, c, w) {
  const d = Math.abs(pos - c);
  return d <= w / 2 ? 100 - (d / (w / 2)) * 25 : Math.max(0, 75 - (d - w / 2) * 5);
}
function nextRound() {
  if (!G) return;
  dots();
  $("g-feedback").textContent = "";
  const st = $("g-stage"), diff = G.diff;
  G.running = true; G.hold = false;
  const t0 = performance.now();
  if (G.game === "flip" || G.game === "timing") {
    const w = Math.max(8, (G.game === "flip" ? 18 : 16) / diff - G.round * 2), c = 45 + Math.random() * 35;
    st.innerHTML = `${G.game === "flip" ? '<div class="patty" id="g-patty">🥩</div>' : ""}<div class="bar ${G.game === "timing" ? "plain" : ""}" style="margin-top:14px"><div class="zone" style="left:${c - w / 2}%;width:${w}%"></div><div class="cursor" id="g-cur"></div></div>`;
    G.zone = { c, w };
    const dur = (G.game === "flip" ? 2600 : 1500) / diff;
    const loop = (t) => {
      if (!G || !G.running) return;
      let p = (t - t0) / dur;
      if (G.game === "timing") p = Math.abs(((p % 2) + 2) % 2 - 1);   // aller-retour
      G.pos = Math.min(100, p * 100);
      $("g-cur").style.left = G.pos + "%";
      if (G.game === "flip" && G.pos >= 100) return endRound(0);       // brûlé
      if (G.game === "timing" && t - t0 > dur * 6) return endRound(0);
      G.raf = requestAnimationFrame(loop);
    };
    G.raf = requestAnimationFrame(loop);
    G.press = () => { if (G.game === "flip") $("g-patty").classList.add("flip"); endRound(zoneScore(G.pos, c, w)); };
  } else if (G.game === "fry" || G.game === "fill") {
    const fill = G.game === "fill";
    const w = Math.max(8, 14 / diff), c = fill ? 72 + Math.random() * 12 : 60 + Math.random() * 20;
    st.innerHTML = fill
      ? `<div class="fillbar"><div class="band" style="bottom:${c - w / 2}%;height:${w}%"></div><div class="liquid ${Math.random() < 0.5 ? "cola" : ""}" id="g-liq" style="height:0%"></div></div>`
      : `<div style="width:100%"><div class="patty">🍟</div><div class="bar" style="margin-top:14px"><div class="zone gold" style="left:${c - w / 2}%;width:${w}%"></div><div class="cursor" id="g-cur"></div></div></div>`;
    G.pos = 0;
    let last = t0;
    const speed = (fill ? 42 : 36) * diff;   // % par seconde quand on maintient
    const loop = (t) => {
      if (!G || !G.running) return;
      const dt = (t - last) / 1000; last = t;
      if (G.hold) G.pos += speed * dt;
      if (fill) $("g-liq").style.height = Math.min(100, G.pos) + "%"; else $("g-cur").style.left = Math.min(100, G.pos) + "%";
      if (G.pos >= 100) return endRound(0);                               // débordé / brûlé
      if (t - t0 > 9000) return endRound(G.pos > 0 ? zoneScore(G.pos, c, w) : 0);
      G.raf = requestAnimationFrame(loop);
    };
    G.raf = requestAnimationFrame(loop);
    G.down = () => { G.hold = true; };
    G.up = () => { if (G.hold && G.pos > 0) endRound(zoneScore(G.pos, c, w)); G.hold = false; };
  } else if (G.game === "combo") {
    const keys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"], sym = { ArrowUp: "↑", ArrowDown: "↓", ArrowLeft: "←", ArrowRight: "→" };
    const n = Math.min(7, 4 + G.round), seq = Array.from({ length: n }, () => keys[Math.floor(Math.random() * 4)]);
    const limit = (2200 + n * 450) / diff;
    st.innerHTML = `<div style="width:100%;display:grid;place-items:center;gap:18px"><div class="combo">${seq.map((k, i) => `<kbd id="g-k${i}" class="${i === 0 ? "cur" : ""}">${sym[k]}</kbd>`).join("")}</div><div class="bar plain" style="height:10px;width:80%"><div class="timer" id="g-tm" style="width:100%"></div></div></div>`;
    G.seq = seq; G.idx = 0; G.miss = 0;
    const loop = (t) => {
      if (!G || !G.running) return;
      const left = 1 - (t - t0) / limit;
      $("g-tm").style.width = Math.max(0, left * 100) + "%";
      if (left <= 0) return endRound(Math.max(0, (G.idx / n) * 70 - G.miss * 15));
      G.raf = requestAnimationFrame(loop);
    };
    G.raf = requestAnimationFrame(loop);
    G.key = (k) => {
      if (!keys.includes(k)) return;
      const el = $("g-k" + G.idx);
      if (k === G.seq[G.idx]) {
        el.className = "ok"; G.idx++;
        if (G.idx >= n) { const timeLeft = 1 - (performance.now() - t0) / limit; return endRound(100 - G.miss * 18 - (1 - timeLeft) * 15); }
        $("g-k" + G.idx).classList.add("cur");
      } else { G.miss++; el.classList.remove("bad"); void el.offsetWidth; el.classList.add("bad"); }
    };
  }
}
function cancelGame() { if (!G) return; G.running = false; cancelAnimationFrame(G.raf); G = null; show("game", false); post("close"); }

// =====================================================================================================================================
// Note et pourboire
// =====================================================================================================================================
let R = null;
function openRate(d) {
  R = { id: d.id, stars: 5, tip: 0 };
  $("r-who").textContent = `Commande remise par ${d.who}.`;
  renderRate();
  show("rate", true);
}
function renderRate() {
  $("r-stars").innerHTML = [1, 2, 3, 4, 5].map((n) => `<button data-star="${n}" class="${n <= R.stars ? "on" : ""}">⭐</button>`).join("");
  $("r-tips").innerHTML = [0, 5, 10, 20].map((n) => `<button data-tip="${n}" class="${n === R.tip ? "on" : ""}">${n ? money(n) : "Non merci"}</button>`).join("");
}
$("rate").addEventListener("click", (e) => {
  const t = e.target.closest("button");
  if (!t || !R) return;
  if (t.hasAttribute("data-close")) { show("rate", false); R = null; return post("close"); }
  if (t.dataset.star) { R.stars = +t.dataset.star; return renderRate(); }
  if (t.dataset.tip) { R.tip = +t.dataset.tip; return renderRate(); }
  if (t.id === "r-send") { post("rate", { id: R.id, stars: R.stars, tip: R.tip }); show("rate", false); R = null; }
});

// =====================================================================================================================================
// Suivi client et équipier
// =====================================================================================================================================
let T = null, courierDist = null;
function renderTrack() {
  const o = T;
  if (!o) return show("track", false);
  const step = { paid: 1, cooking: 1, cooked: 1, auto: 1, ready: 2, counter: 3 }[o.state] ?? 1;
  const done = (i) => i < step || (o.state === "counter" && i <= 2);
  let msg = "En attente d’un équipier…";
  if (o.state === "cooking" || o.state === "cooked") msg = `👨‍🍳 ${esc(o.cook || "Un équipier")} prépare ta commande.`;
  if (o.state === "auto") { const left = Math.max(0, (o.eta ?? 0) - Math.floor((Date.now() - (o.at || Date.now())) / 1000)); msg = left > 0 ? `🤖 Cuisine automatique · prête dans ${left} s` : "🤖 Presque prête…"; }
  if (o.state === "ready") msg = o.mode === "delivery" ? `🛵 ${esc(o.carrier || "Ton livreur")} arrive${courierDist != null ? ` · ${courierDist} m` : ""}` : `🛍️ ${esc(o.carrier || "Un équipier")} t’apporte ta commande.`;
  if (o.state === "counter") msg = "✅ Prête au comptoir : va la récupérer (E).";
  const labels = ["Payée", "En cuisine", "Prête", "Remise"];
  $("track").innerHTML = `<div class="tt"><span class="n">#${o.id}</span><div>${esc(BRAND)}<small>${o.mode === "delivery" ? "Livraison" : "Sur place / à emporter"} · ${money(o.total)}</small></div><span>🍔</span></div>
    <div class="prog">${labels.map((_, i) => `<i class="${done(i) ? "done" : i === step ? "cur" : ""}"></i>`).join("")}</div>
    <div class="prog-l">${labels.map((l) => `<span>${l}</span>`).join("")}</div><div class="msg">${msg}</div>`;
  show("track", true);
}
// compte à rebours de la cuisine automatique : seul le texte change (reconstruire relançait l'animation de la barre)
setInterval(() => {
  if (!T || T.state !== "auto") return;
  const m = document.querySelector("#track .msg");
  if (!m) return renderTrack();
  const left = Math.max(0, (T.eta ?? 0) - Math.floor((Date.now() - (T.at || Date.now())) / 1000));
  m.textContent = left > 0 ? `🤖 Cuisine automatique · prête dans ${left} s` : "🤖 Presque prête…";
}, 1000);
let W = { order: null, carry: null };
function renderWork() {
  const { order, carry } = W;
  if (carry) {
    $("work").innerHTML = `<h5>Commande #${carry.id} en main</h5><p>${carry.npc ? `Livre-la à ${esc(carry.name)} — ${esc(carry.address ? carry.address.label : "")} (GPS).` : `Remets-la à ${esc(carry.name)} (E à côté de lui) ou pose-la au comptoir.`}</p>`;
    return show("work", true);
  }
  if (!order) return show("work", false);
  const next = (order.stations || []).find((s) => !s.done);
  $("work").innerHTML = `<h5>Commande #${order.id}</h5><p>${esc(order.name)} · ${order.mode === "delivery" ? "livraison" : "sur place"}</p>
    <ul>${(order.stations || []).map((s) => `<li class="${s.done ? "done" : s === next ? "next" : ""}"><span>${esc(s.label)} ×${s.need}</span><span>${s.done ? "✓" : "…"}</span></li>`).join("")}
    <li class="${next ? "" : "next"}"><span>Emballer (Montage)</span><span>${next ? "" : "→"}</span></li></ul>`;
  show("work", true);
}

// =====================================================================================================================================
// Messages du jeu et clavier
// =====================================================================================================================================
window.addEventListener("message", (e) => {
  const d = e.data || {};
  switch (d.action) {
    case "kiosk": openKiosk(d.data); break;
    case "orderResult":
      busy = false;
      if (!K) break;
      if (d.result && d.result.ok) showDone(d.result.order); else { renderCart(); $("k-err").textContent = (d.result && d.result.msg) || "Commande refusée."; }
      break;
    case "track": T = d.order || null; if (T) T.at = Date.now(); if (!T || T.state !== "ready") courierDist = null; renderTrack(); break;
    case "courier": courierDist = d.dist; renderTrack(); break;
    case "kds": openKds(d.data || {}, d.list); break;
    case "queue": renderQueue(d.list, d.me, d.manager); break;
    case "work": W = { order: d.order || null, carry: d.carry || null }; renderWork(); break;
    case "game": startGame(d.game); break;
    case "rate": openRate(d); break;
  }
});
document.addEventListener("keydown", (e) => {
  if (G) {
    if (e.key === "Escape") return cancelGame();
    if (e.code === "Space") { e.preventDefault(); if (e.repeat) return; if (G.running) { if (G.down) G.down(); else if (G.press) G.press(); } }
    if (G && G.running && G.key) { e.preventDefault(); G.key(e.key); }
    return;
  }
  if (e.key !== "Escape") return;
  if (isShown("kiosk") && !busy) { if (isShown("k-choice")) show("k-choice", false); else closeKiosk(); }
  else if (isShown("kds")) closeKds();
  else if (isShown("rate")) { show("rate", false); R = null; post("close"); }
});
document.addEventListener("keyup", (e) => { if (G && G.running && e.code === "Space" && G.up) G.up(); });
