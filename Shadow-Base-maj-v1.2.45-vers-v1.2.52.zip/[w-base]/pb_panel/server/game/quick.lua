-- Menu de mon entreprise (touche F6) : un menu « lib » construit par le serveur selon le métier, le grade et le service du joueur.
-- Aucune logique d'action ici : chaque entrée appelle l'action de l'entreprise (Biz.Act), qui revérifie droits, service, distance et montants.
-- Les pages de gestion (ex-tablette) sont ajoutées en bas : le client les ouvre en sous-menus (client/pagesmenu.lua).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Biz = G.Biz
local Q = {}
G.Quick = Q

P.Register('quick.edit', 'Modifier le menu entreprise (F6)', 'quick', true)
PB.Cfg.Define('quick', { enabled = true, f2_menu = true, key = 'F6', fines_shown = 12, invoice_presets = { 'Prestation|250', 'Intervention|500', 'Dépannage|800' }, extra = {}, show_tablet = false, nearby_dist = 8, f6_v1 = false })
local function cfg(k, d) return PB.Cfg.Get('quick', k, d) end

-- Seules ces actions de l'entreprise peuvent être lancées depuis le menu F6
local ALLOWED = { duty = true, invoice = true, fine = true, cuff = true, uncuff = true, escort = true, put_veh = true, search = true, seize = true, revive = true, repair = true, jail = true, tig = true, casier = true }
Q.ALLOWED = ALLOWED
Q.Common, Q.Handlers = {}, {}   -- entrées et actions ajoutées par d'autres fichiers (bizmenu.lua), toutes métiers confondus
Q.Handlers.fleet = function(src, c, p)
    if not c or not c.boss then return false, 'Réservé au patron.' end
    return G.Garage.FleetAct(src, 'biz', c.biz.id, p.plate, p.act == 'recall' and 'recall' or 'gps')
end

local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

-- Spécification pure (sans fonction) du menu : le client la transforme en éléments
function Q.Spec(src)
    if not cfg('enabled', true) then return nil, 'Les actions rapides sont désactivées.' end
    local c = Biz.Ctx(src)
    if not c then return nil, "Tu n'as pas d'entreprise." end
    local near = {}
    for _, n in ipairs(Biz.Nearby(src, cfg('nearby_dist', 8))) do near[#near + 1] = { id = n.id, name = n.name } end
    local e = {}
    local function add(x) e[#e + 1] = x end
    add({ id = 'duty', type = 'duty', label = c.duty and 'Quitter mon service' or 'Prendre mon service', desc = c.duty and 'Tu repasses hors service (tes vêtements reviennent).' or 'Tu passes en service (tenue de travail si elle est enregistrée au vestiaire).', icon = c.duty and 'x' or 'bolt', on = c.duty })
    if c.duty then
        -- taxi : courses, compteur et facture, tout depuis ce menu (le téléphone ne sert plus qu'au client pour commander)
        local Tx = G.Taxi
        if Tx and Tx.IsDriver(src) then
            local calls = Tx.CallList(src)
            add({ id = 'taxi_calls', type = 'list', label = 'Courses en attente', desc = 'Choisis une course : le client est mis sur ton GPS.', icon = 'gps', items = calls, right = tostring(#calls) })
            if Tx.meters[src] then add({ id = 'taxi_stop', label = 'Terminer la course', desc = 'Arrête le compteur. Ensuite : « Envoyer la facture » au client.', icon = 'check' })
            else add({ id = 'taxi_start', label = 'Démarrer le compteur', desc = 'Le client doit être à bord, toi au volant.', icon = 'car' }) end
            local b = Tx.bills[src]
            if b then add({ id = 'taxi_bill', needs = 'target', near = b.riders, label = ('Envoyer la facture (%s $)'):format(b.fare), desc = 'Choisis le client : il reçoit la facture et la paie.', icon = 'card' }) end
        end
        -- bar, café, restaurant : servir un client
        if G.Bar and G.Bar.CanServe and G.Bar.CanServe(src) then add({ id = 'bar_serve', needs = 'target', label = 'Servir un client', desc = 'Choisis le client puis le produit préparé ; il paie s\'il accepte.', icon = 'food' }) end
        if Biz.Allowed(c, 'cuff') then
            add({ id = 'cuff', needs = 'target', label = 'Menotter', desc = 'Menotte la personne ciblée, tout près de toi.', icon = 'lock' })
            add({ id = 'uncuff', needs = 'target', label = 'Libérer', desc = 'Retire les menottes de la personne ciblée.', icon = 'key' })
            add({ id = 'escort', needs = 'target', label = 'Escorter / lâcher', desc = 'La personne menottée te suit ; relance pour la lâcher.', icon = 'hand' })
            add({ id = 'put_veh', needs = 'target', label = 'Mettre dans le véhicule', desc = "Assied la personne menottée à l'arrière du véhicule le plus proche.", icon = 'car' })
        end
        if Biz.Allowed(c, 'search') then add({ id = 'search', needs = 'target', label = 'Fouiller', desc = 'Fouille une personne menottée.', icon = 'search' }) end
        if Biz.Allowed(c, 'fine') then
            local items = {}
            for _, f in ipairs(DB.q('SELECT code, label, amount FROM pb_fines ORDER BY category, label LIMIT ?', { cfg('fines_shown', 12) }) or {}) do items[#items + 1] = { code = f.code, label = f.label, amount = f.amount } end
            add({ id = 'fine', needs = 'target', label = 'Amende', desc = "Choisis l'infraction du catalogue, puis valide.", icon = 'tag', pick = items })
        end
        if Biz.Allowed(c, 'seize') then add({ id = 'seize', label = 'Mise en fourrière', desc = 'Saisit le véhicule le plus proche (motif demandé).', icon = 'key', inputs = { { k = 'reason', label = 'Motif', maxlen = 70 } } }) end
        if Biz.Allowed(c, 'jail') then
            add({ id = 'jail', needs = 'target', label = 'Prison', desc = 'Condamne une personne menottée : durée en minutes, puis motif.', icon = 'lock', inputs = { { k = 'amount', label = 'Minutes', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } } })
            add({ id = 'tig', needs = 'target', label = "Travaux d'intérêt général", desc = 'Nombre de tâches à effectuer, puis motif.', icon = 'hand', inputs = { { k = 'amount', label = 'Tâches', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } } })
        end
        if c.biz.kind == 'police' and (Biz.Allowed(c, 'records') or Biz.Allowed(c, 'jail')) then add({ id = 'casier', needs = 'target', label = 'Casier judiciaire', desc = "Affiche les dernières lignes du casier de la personne ciblée.", icon = 'book' }) end
        if c.biz.kind == 'police' and Biz.Allowed(c, 'records') and G.Weapons then
            add({ id = 'permit', needs = 'target', label = "Délivrer un permis d'arme", desc = "Donne le permis de port d'arme à la personne ciblée.", icon = 'id' })
            add({ id = 'permit_revoke', needs = 'target', label = "Retirer le permis d'arme", desc = "Retire le permis de la personne ciblée.", icon = 'x' })
        end
        if Biz.Allowed(c, 'revive') then add({ id = 'revive', needs = 'target', label = 'Réanimer', desc = "Réanime une personne inconsciente à côté de toi.", icon = 'heart' }) end
        if Biz.Allowed(c, 'repair') then
            -- mécano : gestes simples (avec animation), customisation dans le véhicule du client, puis facture
            add({ id = 'mech_repair', kind = 'client', label = 'Réparer le véhicule', desc = 'Le véhicule le plus proche : moteur, carrosserie, pneus. Ajouté à la facture.', icon = 'engine' })
            add({ id = 'mech_clean', kind = 'client', label = 'Nettoyer le véhicule', desc = 'Lavage du véhicule le plus proche. Ajouté à la facture.', icon = 'drop' })
            -- la customisation ne se fait qu'au garage (point « atelier »), pas depuis ce menu
            add({ id = 'mech_bill', needs = 'target', label = 'Envoyer la facture', desc = 'Ce que tu as fait (réparation, nettoyage, devis validé) : choisis le client.', icon = 'card' })
        end
        if Biz.Allowed(c, 'invoice') then
            local presets = {}
            -- factures pré-remplies : celles du secteur (garage, santé, restauration…) puis celles du panel
            local lines, seen = {}, {}
            for _, src2 in ipairs({ (G.JobPacks and G.JobPacks.Presets(c)) or {}, cfg('invoice_presets', {}) or {} }) do
                for _, l in ipairs(src2) do if not seen[l] and #lines < 8 then seen[l] = true lines[#lines + 1] = l end end
            end
            for _, line in ipairs(lines) do
                local l, a = tostring(line):match('^(.-)|(%d+)$')
                if l and l ~= '' then presets[#presets + 1] = { label = clean(l, 40), amount = tonumber(a) } end
            end
            add({ id = 'invoice', needs = 'target', label = 'Facturer', desc = 'Envoie une facture à la personne ciblée.', icon = 'card', pick = presets, inputs = { { k = 'amount', label = 'Montant', number = true, maxlen = 7 }, { k = 'reason', label = 'Motif', maxlen = 60 } } })
        end
    end
    -- actions communes à toutes les entreprises (annonce, ouverture, renfort, collègues, soins…) : server/game/bizmenu.lua
    for _, fn in ipairs(Q.Common) do fn(src, c, add) end
    for _, line in ipairs(cfg('extra', {}) or {}) do
        local l, d, cmd = tostring(line):match('^(.-)|(.-)|([%w_:%-]+)$')
        if l and l ~= '' then add({ id = 'cmd', label = clean(l, 40), desc = clean(d, 120), icon = 'link', cmd = cmd }) end
    end
    -- toutes les pages de gestion (ex-tablette) : tableau de bord, équipe, factures, dossiers, caisse… selon le grade
    local mine, work = {}, {}
    for _, n in ipairs(Biz.Frame(src).nav or {}) do
        local x = { id = 'page:' .. n.id, type = 'page', page = n.id, label = n.id == 'home' and 'Tableau de bord' or n.label, icon = n.icon }
        if n.group == 'Mon espace' then mine[#mine + 1] = x else work[#work + 1] = x end
    end
    add({ type = 'separator', label = "Gestion de l'entreprise" })
    -- (v1.2.42) flotte : où sont les véhicules de service, qui les a sortis, rappel au garage (patron)
    if c.boss and G.Garage and G.Garage.Fleet then
        local fleet = G.Garage.Fleet('biz', c.biz.id)
        if #fleet > 0 then
            local out = 0 for _, f in ipairs(fleet) do if f.state == 'out' then out = out + 1 end end
            add({ id = 'fleet', type = 'fleet', label = 'Véhicules de service', icon = 'car', right = out .. ' / ' .. #fleet .. ' sortis', items = fleet, desc = 'Où ils sont, qui les a sortis ; rappelle au garage ceux qui sont abandonnés.' })
        end
    end
    local hqOnly = PB.Cfg.Get('tablets', 'hq_only', true) ~= false
    if hqOnly then
        add({ id = 'tab_info', type = 'info', label = "Tablette de l'entreprise", right = 'Au siège', icon = 'briefcase', desc = "Tableau de bord, équipe, factures, caisse… : à la tablette du siège (E sur le point de l'entreprise)." })
    else for _, x in ipairs(work) do add(x) end end
    if not hqOnly and c.boss and not Biz.AtBoss(src, c) then
        add({ id = 'boss_info', type = 'info', label = 'Gestion du patron', right = 'Au bureau', icon = 'lock', desc = 'Employés, grades, salaires et caisse : au bureau du patron (point posé au Builder).' })
    end
    -- ses propres pages : finances (virement), factures à payer, annuaire, profil
    if #mine > 0 then
        add({ type = 'separator', label = 'Mon espace' })
        for _, x in ipairs(mine) do add(x) end
    end
    return { biz = c.biz.label, kind = c.biz.kind, grade = c.grade.label, duty = c.duty, color = c.biz.color, near = near, entries = e }
end

local function has(spec, id) for _, x in ipairs(spec.entries) do if x.id == id then return x end end end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end

RegisterNetEvent('pb:g:quick:open', function()
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    local spec, err = Q.Spec(src)
    -- sans entreprise : F6 ouvre l'espace citoyen (finances, factures, entreprises, profil)
    if not spec and cfg('enabled', true) and not Biz.Ctx(src) then TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'open', frame = Biz.Frame(src) })) return end
    if not spec then G.Notify(src, { type = 'warn', title = 'Actions rapides', text = err }) return end
    TriggerClientEvent('pb:g:quick:ui', src, PB.Json({ ev = 'open', spec = spec }))
end)

function Q.Do(src, id, payload)
    id = tostring(id or '')
    local spec, err = Q.Spec(src)
    if not spec then return false, err end
    if Q.Handlers[id] then
        if not has(spec, id) then return false, 'Action indisponible.' end
        return Q.Handlers[id](src, Biz.Ctx(src), type(payload) == 'table' and payload or {})
    end
    local p0 = type(payload) == 'table' and payload or {}
    local Tx = G.Taxi
    if id == 'taxi_accept' then if not has(spec, 'taxi_calls') then return false, 'Action indisponible.' end return Tx.Accept(src, p0.call) end
    if id == 'taxi_start' then if not has(spec, 'taxi_start') then return false, 'Action indisponible.' end return Tx.Start(src) end
    if id == 'taxi_stop' then if not has(spec, 'taxi_stop') then return false, 'Action indisponible.' end return Tx.Stop(src) end
    if id == 'taxi_bill' then if not has(spec, 'taxi_bill') then return false, 'Action indisponible.' end return Tx.Bill(src, tonumber(p0.id)) end
    if id == 'bar_serve' then
        if not has(spec, 'bar_serve') then return false, 'Action indisponible.' end
        local tid = tonumber(p0.id)
        if not tid or tid == src or not G.Get(tid) or G.DistBetween(src, tid) > cfg('nearby_dist', 8) + 2 then return false, 'Choisis un client à côté de toi.' end
        return G.Bar.ServeMenu(src, tid)
    end
    if id == 'mech_bill' then
        if not has(spec, 'mech_bill') then return false, 'Action indisponible.' end
        return G.Mech.Bill(src, tonumber(p0.id))
    end
    if id == 'cmd' then
        local cmd = type(payload) == 'table' and tostring(payload.cmd or '') or ''
        for _, x in ipairs(spec.entries) do if x.id == 'cmd' and x.cmd == cmd then TriggerClientEvent('pb:g:quick:cmd', src, cmd) return true end end
        return false, 'Action indisponible.'
    end
    if id == 'permit' or id == 'permit_revoke' then
        if not has(spec, id) then return false, 'Action indisponible.' end
        local tid = type(payload) == 'table' and tonumber(payload.id) or nil
        if not tid or tid == src or G.DistBetween(src, tid) > PB.Cfg.Get('ctx', 'act_dist', 3.5) + 1.5 then return false, 'Choisis une personne proche.' end
        local c = Biz.Ctx(src)
        local ok, msg = (id == 'permit' and G.Weapons.Grant or G.Weapons.Revoke)(src, tid, c and c.biz.label or nil)
        return ok, msg
    end
    if not ALLOWED[id] or not has(spec, id) then return false, 'Action indisponible.' end
    local p = type(payload) == 'table' and payload or {}
    local clean_p = { id = tonumber(p.id), on = p.on == true, code = p.code and clean(p.code, 40) or nil, amount = tonumber(p.amount), reason = clean(p.reason, 120) }
    if id == 'duty' then clean_p.on = p.on == true end
    local ok, msg = Biz.Act(src, id, clean_p, 'quick')
    if id == 'duty' and ok and G.Taxi and not clean_p.on then G.Taxi.OffDuty(src) end
    return ok, msg
end

RegisterNetEvent('pb:g:quick:act', function(id, payload)
    local src = source
    if not usable(src) or not throttle(src, 300) then return end
    local ok, msg = Q.Do(src, id, payload)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Actions rapides', text = tostring(msg) }) end
    local spec = Q.Spec(src)
    TriggerClientEvent('pb:g:quick:ui', src, PB.Json({ ev = 'update', spec = spec, ok = ok and true or false }))
end)

PB.OnReady(function()
    -- (v1.2.45) plus de menu sur F2 : il faisait doublon avec F6 (même menu entreprise) et F7
    if PB.Cfg.Get('quick', 'f6_v2', false) ~= true then
        if tostring(PB.Cfg.Get('quick', 'key', 'F6')):upper() == 'F2' then PB.Cfg.Set('quick', 'key', 'F6', nil, 'Plus de menu sur F2') end
        PB.Cfg.Set('quick', 'f6_v2', true, nil, 'Migration')
    end
    if PB.Cfg.Get('quick', 'f6_v1', false) ~= true then
        if PB.Cfg.Get('quick', 'key', 'F6') == 'F2' then PB.Cfg.Set('quick', 'key', 'F6', nil, 'Menu entreprise sur F6') end
        PB.Cfg.Set('quick', 'f2_menu', true, nil, 'Menu entreprise sur F6')
        PB.Cfg.Set('quick', 'show_tablet', false, nil, 'Menu entreprise sur F6')
        PB.Cfg.Set('quick', 'f6_v1', true, nil, 'Migration')
    end
end)

local settings = Form.Cfg({ ns = 'quick', id = 'settings', title = 'Menu de mon entreprise (F6)', perm = 'quick.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Actions rapides actives', default = true, hint = 'Ce sont aussi les actions du métier du menu ALT : laisse activé.' },
    { k = 'f2_menu', type = 'toggle', label = 'Touche dédiée au menu entreprise', default = true, hint = 'Les mêmes actions restent aussi dans le menu ALT.' }, { k = 'key', type = 'text', label = "Touche d'ouverture (par défaut)", default = 'F6', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
    { k = 'nearby_dist', type = 'number', label = 'Distance de la liste des cibles (m)', default = 8, min = 2, max = 30 }, { k = 'fines_shown', type = 'number', label = "Infractions proposées (amende)", default = 12, min = 3, max = 30 },
    { k = 'invoice_presets', type = 'list', label = 'Factures rapides (libellé|montant, un par ligne)', default = { 'Prestation|250', 'Intervention|500', 'Dépannage|800' }, maxitems = 10, maxlen = 60, pattern = '^[^|]+|%d+$', wide = true },
    { k = 'extra', type = 'list', label = 'Entrées personnalisées (libellé|description|commande, un par ligne)', default = {}, maxitems = 10, maxlen = 200, pattern = '^[^|]+|[^|]*|[%w_:%-]+$', wide = true, hint = "La commande est exécutée côté joueur (ex. un /emote de ton serveur). Pas d'espace dans la commande." },
} })

PB.Module({
    id = 'quick', label = 'Menu entreprise (F6)', icon = 'bolt', group = 'Serveur', order = 140, perm = 'quick.edit', hint = 'Menu F6 des entreprises',
    caps = function()
        return PB.Capsify({
            { 'Menu F6 selon le métier (toutes les entreprises)', 'ok', "Les entrées dépendent du métier, du grade et du service." },
            { 'Cible : joueurs proches', 'ok', 'Liste actualisée à chaque ouverture ; le serveur revérifie la distance.' },
            { 'Toute la gestion dans le menu (plus de tablette)', 'ok', 'Tableau de bord, équipe, factures, dossiers, caisse, annonces, statistiques… en sous-menus, selon le grade. Mêmes règles qu\'avant.' },
            { 'Actions hors liste', 'off', "Le menu ne peut lancer que les actions prévues : pas d'action arbitraire envoyée par le client." },
        })
    end,
    doc = "## Menu de mon entreprise\nLe joueur appuie sur **F6** (réglable). Il voit seulement ce que son métier, son grade et son service lui permettent : prise de service, facture, menottes, réparation, taxi, service au bar…\n\nPour une action sur quelqu'un (facture, menottes, fouille…), il choisit la **personne** dans la liste : celle survolée est **entourée et marquée d'une flèche** pour être sûr de viser la bonne. Le serveur revérifie tout.\n\nEn bas du menu, **Gestion de l'entreprise** : toutes les pages de l'ancienne tablette (tableau de bord, équipe, factures, dossiers, annonces, statistiques…) en sous-menus. Employés, grades, salaires et caisse restent réservés au **bureau du patron**. Sans entreprise, F6 ouvre l'espace citoyen (finances, factures, profil).",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'quick', title = "Menu F6 d'un officier (exemple)", cfg = PB.Cfg.All('menus') } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx), G.BizMenuForm and G.BizMenuForm(ctx) or { type = 'notice', text = '' }, G.JobPacksForm and G.JobPacksForm(ctx) or nil, G.EmsForm and G.EmsForm(ctx) or nil } end },
        } }
    end,
})

PB.SelfTest.Add('menu entreprise F6', function(R)
    for id in pairs(ALLOWED) do R.check(Biz.ACT[id] ~= nil, 'action « ' .. id .. ' »', "l'action n'existe plus côté entreprise") end
end)
