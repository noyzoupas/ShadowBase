-- Notifications, chat et menu d'interaction : réglages dans le panel, exécution ici (chat) et dans client/ui.lua.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G = PB.G

P.Register('chat.announce', 'Envoyer une annonce serveur (/annonce)', 'game', true)
P.Register('chat.moderate', 'Voir et vider le chat', 'game')

PB.Cfg.Define('notify', {})
PB.Cfg.Define('chat', {})
PB.Cfg.Define('interact', {})
local POS = { { 'map', 'Bas gauche, au-dessus de la mini-carte' }, { 'top-right', 'Haut droite' }, { 'top-left', 'Haut gauche' }, { 'top-center', 'Haut centre' }, { 'bottom-right', 'Bas droite' }, { 'bottom-left', 'Bas gauche' }, { 'bottom-center', 'Bas centre' } }

local notify = Form.Cfg({
    ns = 'notify', id = 'look', title = 'Notifications', perm = 'uikit.edit', cols = 2,
    desc = "Les notifications du serveur, du panel et des scripts utilisant exports.pb_panel:Notify. L'aperçu montre vos réglages avant l'enregistrement.",
    fields = {
        { k = 'position', type = 'select', label = 'Position', opts = POS, default = 'map' },
        { k = 'lift', type = 'number', label = 'Hauteur au-dessus du bas de l\'écran (%, position mini-carte)', default = 24, min = 5, max = 60, step = 1, hint = 'Monte ou descend les notifications si la mini-carte est plus grande ou plus petite chez toi.' },
        { k = 'duration', type = 'number', label = 'Durée (ms)', default = 5000, min = 1500, max = 20000, step = 100 },
        { k = 'max', type = 'number', label = 'Affichées en même temps', default = 4, min = 1, max = 8 },
        { k = 'announce_card', type = 'toggle', label = 'Annonces : carte avec la bannière du serveur', default = true, hint = "Les annonces du staff et du serveur s'affichent sur la bannière du serveur (sans bannière : fond sombre avec le logo)." },
        { k = 'c_info', type = 'color', label = 'Couleur : information', default = '#7cc8ff' },
        { k = 'c_success', type = 'color', label = 'Couleur : succès', default = '#5ee09a' },
        { k = 'c_warn', type = 'color', label = 'Couleur : attention', default = '#ffc65c' },
        { k = 'c_error', type = 'color', label = 'Couleur : erreur', default = '#ff7a8c' },
    },
})

local chat = Form.Cfg({
    ns = 'chat', id = 'rules', title = 'Chat du serveur', perm = 'uikit.edit', cols = 2,
    desc = "Le serveur applique les limites (portée, cadence, longueur) : le client ne peut pas les contourner.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Activer le chat du panel', default = true, hint = "Désactivé : aucun message ne passe par ce chat." },
        { k = 'key', type = 'text', label = 'Touche par défaut', default = 'T', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans Paramètres > Raccourcis.' },
        { k = 'radius', type = 'number', label = 'Portée du chat local (m)', default = 25, min = 3, max = 200 },
        { k = 'max_len', type = 'number', label = 'Longueur maximale', default = 220, min = 20, max = 400 },
        { k = 'cooldown', type = 'number', label = 'Délai entre deux messages (ms)', default = 900, min = 0, max = 10000, step = 50 },
        { k = 'show_time', type = 'toggle', label = "Afficher l'heure", default = false },
        { k = 'fade', type = 'number', label = 'Disparition des messages (s, 0 = reste)', default = 12, min = 0, max = 120 },
        { k = 'c_say', type = 'color', label = 'Local', default = '#ffffff' },
        { k = 'c_me', type = 'color', label = '/me', default = '#d9a3ff' },
        { k = 'c_do', type = 'color', label = '/do', default = '#7cc8ff' },
        { k = 'c_ooc', type = 'color', label = '/ooc', default = '#9aa3b2' },
        { k = 'c_announce', type = 'color', label = 'Annonce', default = '#ffc65c' },
        { k = 'filter', type = 'list', label = 'Mots interdits', default = {}, maxitems = 100, maxlen = 32, hint = 'Un mot par ligne. Remplacés par des étoiles.' },
    },
})

local ENTRIES = {
    { 'id', "Montrer ma carte d'identité", 'id' }, { 'handsup', 'Lever les mains', 'hand' }, { 'crossarms', 'Croiser les bras', 'user' },
    { 'sit', "S'asseoir", 'user' }, { 'salute', 'Salut', 'user' }, { 'facepalm', 'Facepalm', 'user' }, { 'dance', 'Danser', 'music' },
    { 'cancel', "Arrêter l'animation", 'x' }, { 'engine', 'Moteur on/off (véhicule)', 'car' }, { 'lights', 'Phares (véhicule)', 'car' },
    { 'doors', 'Verrouiller les portes (véhicule)', 'lock' }, { 'ems', 'Appeler les secours', 'heart' },
}
local ENTRY_OPTS = {}
for _, e in ipairs(ENTRIES) do ENTRY_OPTS[#ENTRY_OPTS + 1] = { e[1], e[2] } end

local interact = Form.Cfg({
    ns = 'interact', id = 'menu', title = "Menu d'interaction", perm = 'uikit.edit', cols = 2,
    desc = "Menu radial ouvert par une touche. Les actions sont choisies dans une liste fermée : rien n'est exécuté en dehors de celle-ci.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Activer le menu', default = true },
        { k = 'key', type = 'text', label = 'Touche par défaut', default = 'F2', maxlen = 12, pattern = '^[%w_]+$' },
        { k = 'style', type = 'select', label = 'Style', opts = { { 'radial', 'Radial (cercle)' }, { 'list', 'Liste' } }, default = 'radial' },
        { k = 'c_accent', type = 'color', label = 'Couleur', default = '#dfe2e7' },
        { k = 'entries', type = 'multi', label = 'Actions proposées', opts = ENTRY_OPTS, default = { 'id', 'handsup', 'crossarms', 'sit', 'cancel', 'engine', 'ems' }, maxitems = 10, wide = true, hint = '10 actions au maximum.' },
    },
})

-- Config côté client : libellés et icônes des entrées
local oldCC = G.ClientConfig
function G.ClientConfig()
    local c = oldCC()
    local lab = {}
    for _, e in ipairs(ENTRIES) do lab[e[1]] = { label = e[2], icon = e[3] } end
    c.interact_entries = lab
    return c
end

-- Chat ------------------------------------------------------------------------------------------------------------------------------
local lastMsg = {}
local history = {}   -- derniers messages, pour la modération
local function nameOf(src)
    local i = G.Identity and G.Identity(src)
    if i and i.created and i.firstname and i.firstname ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 40) end
    return (GetPlayerName and GetPlayerName(src)) or ('Joueur ' .. src)
end

local function filterWords(text, words)
    for _, w in ipairs(words or {}) do
        if #w >= 2 then
            local pat = w:lower():gsub('[%^%$%(%)%%%.%[%]%*%+%-%?]', '%%%0')
            local out, low, pos = {}, text:lower(), 1
            while true do
                local a, b = low:find(pat, pos)
                if not a then out[#out + 1] = text:sub(pos) break end
                out[#out + 1] = text:sub(pos, a - 1) .. ('*'):rep(b - a + 1)
                pos = b + 1
            end
            text = table.concat(out)
        end
    end
    return text
end

local function near(src, radius)
    local list = {}
    local me = GetEntityCoords(GetPlayerPed(src))
    for _, id in ipairs(GetPlayers()) do
        id = tonumber(id)
        local c = GetEntityCoords(GetPlayerPed(id))
        local dx, dy, dz = c.x - me.x, c.y - me.y, c.z - me.z
        if id == src or (dx * dx + dy * dy + dz * dz) <= radius * radius then list[#list + 1] = id end
    end
    return list
end

function G.ChatSend(src, kind, text)
    local cfg = PB.Cfg.All('chat')
    if not cfg.enabled then return false, 'Le chat est désactivé.' end
    if type(text) ~= 'string' then return false, 'Message invalide.' end
    text = PB.Trim(PB.Sanitize(text, cfg.max_len))
    if text == '' then return false, 'Message vide.' end
    local now = GetGameTimer and GetGameTimer() or os.time() * 1000
    if lastMsg[src] and now - lastMsg[src] < cfg.cooldown then return false, 'Doucement : attends un instant.' end
    lastMsg[src] = now
    if kind == 'announce' and not P.Has(src, 'chat.announce') then return false, "Tu n'as pas le droit d'envoyer une annonce." end
    if kind ~= 'say' and kind ~= 'me' and kind ~= 'do' and kind ~= 'ooc' and kind ~= 'announce' then return false, 'Commande inconnue.' end
    text = filterWords(text, cfg.filter)
    local dest
    if kind == 'ooc' or kind == 'announce' then dest = {} for _, id in ipairs(GetPlayers()) do dest[#dest + 1] = tonumber(id) end
    else dest = near(src, cfg.radius) end
    local msg = PB.Json({ kind = kind, name = kind == 'announce' and 'Annonce' or nameOf(src), text = text, at = os.date('%H:%M'), id = src })
    for _, id in ipairs(dest) do TriggerClientEvent('pb:g:chat', id, msg) end
    history[#history + 1] = { at = os.time(), src = src, name = nameOf(src), kind = kind, text = text }
    if #history > 200 then table.remove(history, 1) end
    return true
end

-- Message système dans le chat de la base (annonces, commandes du serveur). Le chat par défaut de FiveM n'est pas installé.
function G.ChatSystem(target, name, text)
    local msg = PB.Json({ kind = 'announce', name = tostring(name or 'Serveur'), text = PB.Sanitize(tostring(text or ''), 400), at = os.date('%H:%M'), id = 0 })
    TriggerClientEvent('pb:g:chat', target or -1, msg)
    TriggerClientEvent('chat:addMessage', target or -1, { color = { 155, 140, 255 }, multiline = true, args = { tostring(name or 'Serveur'), tostring(text or '') } })
end

-- Commandes du serveur proposées dans le chat
local HIDE_RES = { monitor = true, sessionmanager = true, txAdmin = true, ['webadmin'] = true }
-- Commandes de chat de la base (G.ChatCmds) : avec aide et paramètres, seulement celles que ce joueur peut utiliser
local function chatCmds(src)
    local out, seen = {}, {}
    if G.ChatCmds then for _, c in ipairs(G.ChatCmds.For(src)) do seen[c.name] = true out[#out + 1] = c end end
    local hidden = G.ChatCmds and G.ChatCmds.Staff or {}
    for _, c in ipairs(GetRegisteredCommands() or {}) do
        local n = c.name
        if type(n) == 'string' and not seen[n] and not hidden[n] and n:match('^[%w_%-]+$') and #n <= 40 and not HIDE_RES[c.resource or ''] and not n:match('^pb_') and not n:match('^txa') and not n:match('__') then
            out[#out + 1] = { name = n, help = '' }   -- une commande réservée reste refusée par FiveM à ceux qui n'ont pas le droit
        end
    end
    return out
end
G.ChatCmdList = chatCmds
table.insert(G.beginHooks, function(src) TriggerClientEvent('pb:g:chatCmds', src, PB.Json(chatCmds(src))) end)
AddEventHandler('onResourceStart', function()
    SetTimeout(2000, function() for s in pairs(G.Players()) do TriggerClientEvent('pb:g:chatCmds', s, PB.Json(chatCmds(s))) end end)
end)

RegisterNetEvent('pb:g:chatSend', function(kind, text)
    local src = source
    local ok, err = G.ChatSend(src, tostring(kind), text)
    if not ok and err then G.Notify(src, { type = 'warn', text = err }) end
end)
AddEventHandler('playerDropped', function() lastMsg[source] = nil end)

-- Menu d'interaction : seules les actions serveur de la liste fermée passent ici.
RegisterNetEvent('pb:g:interact', function(entry)
    local src = source
    local cfg = PB.Cfg.All('interact')
    if true or not cfg.enabled or type(entry) ~= 'string' then return end   -- v1.2.37 : menu d'interaction F2 retiré
    local allowed = false
    for _, e in ipairs(cfg.entries or {}) do if e == entry then allowed = true end end
    if not allowed then return end
    if entry == 'id' then
        local i = G.Identity(src)
        if not i or not i.created then G.Notify(src, { type = 'warn', text = "Ton personnage n'est pas encore créé." }) return end
        local msg = PB.Json({ kind = 'me', name = nameOf(src), text = ("montre sa carte d'identité : %s %s, né(e) le %s, %s."):format(i.firstname, i.lastname, tostring(i.dob or '?'), tostring(i.nationality or '?')), at = os.date('%H:%M'), id = src })
        for _, id in ipairs(near(src, 5)) do TriggerClientEvent('pb:g:chat', id, msg) end
    end
end)

PB.Action('chat.clear', 'chat.moderate', function(ctx)
    history = {}
    TriggerClientEvent('pb:g:chatClear', -1)
    ctx.audit('config', 'chat.clear', 'chat', nil, nil)
    ctx.toast = 'Chat vidé pour tous les joueurs.'
    return true
end, { critical = true, confirm = 'Vider le chat de tous les joueurs ?' })

PB.Action('chat.announce', 'chat.announce', function(ctx, p)
    local ok, err = G.ChatSend(ctx.src, 'announce', tostring((p.values or p).text or ''))
    if not ok then return false, err end
    ctx.audit('config', 'chat.announce', 'chat', nil, { text = tostring((p.values or p).text):sub(1, 120) })
    ctx.toast = 'Annonce envoyée.'
    return true
end)

exports('ChatSend', function(src, kind, text) return G.ChatSend(src, kind, text) end)

P.Register('uikit.edit', 'Modifier notifications, chat et menu d\'interaction', 'game')
P.Register('uikit.view', 'Voir les interfaces en jeu', 'game')

PB.Module({
    id = 'uikit', label = 'Notifs, chat, menu', icon = 'message', group = 'Serveur', order = 138, perm = 'uikit.view', hint = 'Notifications, chat, menu d\'interaction',
    caps = function()
        return PB.Capsify({
            { 'Notifications', 'ok', 'Position, style, durée, couleurs .' },
            { 'Chat local, /me, /do, /ooc, annonces', 'ok', 'Portée, cadence et filtre appliqués par le serveur.' },
            { 'Autre chat', GetResourceState('chat') == 'started' and 'partial' or 'ok', "Le chat par défaut de FiveM (resource « chat ») reste actif et se superpose : arrête-le si tu utilises celui-ci." },
            { 'Commandes personnalisées dans le chat', 'off', "Seules /me, /do, /ooc et /annonce sont gérées. Les commandes d'autres scripts passent par la console F8." },
            { "Menu d'interaction", 'ok', 'Actions choisies dans une liste fermée (animations, véhicule, identité, secours).' },
            { 'Actions sur un autre joueur ou un objet (fouiller, menotter, cibler)', 'off', "Non fournies dans ce lot : le menu n'agit que sur le joueur lui-même." },
        })
    end,
    doc = "## Notifications, chat et menu d'interaction\n- **Notifier depuis un script** : `exports.pb_panel:Notify({ type = 'success', title = 'Titre', text = 'Message' })` côté client, ou `exports.pb_panel:Notify` / `TriggerClientEvent('pb:g:notify', src, json)` via l'API serveur.\n- **Chat** : `/me`, `/do`, `/ooc`, `/annonce` (droit requis). Le serveur applique portée et délai.\n- **Menu** : touche réglable par chaque joueur dans les paramètres de touches de FiveM.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('notify', 'Notifications', 'bell', function()
                return { notify(ctx), { type = 'gpreview', kind = 'notify', title = 'Aperçu en direct', form = 'notify.look', cfg = PB.Cfg.All('notify') } }
            end),
            tab('me3d', 'Texte 3D', 'message', function()
                return { G.Me3DForm and G.Me3DForm(ctx) or B.notice('warn', 'Module indisponible.') }
            end),
            tab('chat', 'Chat', 'message', function()
                local blocks = { chat(ctx), { type = 'gpreview', kind = 'chat', title = 'Aperçu en direct', form = 'chat.rules', cfg = PB.Cfg.All('chat') } }
                if ctx.has('chat.announce') then
                    blocks[#blocks + 1] = { type = 'form', id = 'chat.announce.form', title = 'Annonce serveur', fields = {
                        { k = 'text', type = 'text', label = 'Message', required = true, maxlen = 400 } }, values = { text = '' },
                        submit = { action = 'chat.announce', label = 'Envoyer à tous' } }
                end
                if ctx.has('chat.moderate') then
                    blocks[#blocks + 1] = B.actions({ { action = 'chat.clear', label = 'Vider le chat', icon = 'trash', danger = true } }, 'Modération')
                end
                return blocks
            end),
        } }
    end,
})

PB.SelfTest.Add('chat', function(R)
    R.check(filterWords('abc zut def', { 'zut' }) == 'abc *** def', 'chat', 'le filtre de mots ne masque pas correctement')
    R.check(filterWords('rien', { '(((' }) == 'rien', 'chat', 'un mot interdit contenant des caractères spéciaux fait échouer le filtre')
end)

-- (v1.2.45) notifications au-dessus de la mini-carte (une fois pour toutes ; réglable ensuite dans Interface › Notifications)
PB.OnReady(function()
    if PB.Cfg.Get('notify', 'pos_v145', false) ~= true then
        PB.Cfg.Set('notify', 'position', 'map', nil, 'Notifications au-dessus de la mini-carte')
        PB.Cfg.Set('notify', 'pos_v145', true, nil, 'Migration')
    end
end)
