/* Mort RP : écran noir « MORT RP », puis le serveur déconnecte le joueur au bout de 10 s. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
G.on('mortrp', (d) => {
  let secs = Math.max(1, Number(d.secs) || 10);
  const left = h('b', null, String(secs));
  const el = h('div', { id: 'g-mortrp' },
    h('div', { class: 'mr-in' }, h('h1', null, 'MORT RP'),
      h('p', null, (d.name ? String(d.name).trim() + ' : ' : '') + 'ton personnage est mort définitivement.'),
      h('small', null, 'Déconnexion dans ', left, ' s. Reconnecte-toi pour créer un nouveau personnage.')));
  G.root.appendChild(el);
  const t = setInterval(() => { secs = Math.max(0, secs - 1); left.textContent = String(secs); if (!secs) clearInterval(t); }, 1000);
});
})();
