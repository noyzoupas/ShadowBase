/* Territoires en guerre (batailles de zone et guerres planifiées) : texte propre en haut de l'écran (zone + temps restant, sans cadre)
   et points de chaque gang en bas à droite. Le texte « Territoire · nom » hors guerre est dessiné par le client Lua (natives du jeu). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const safeCol = (c) => (/^#[0-9a-fA-F]{6}$/.test(c || '') ? c : '#e5384f');
const fmt = (s) => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

function buildText(d) {
  const clock = h('span', { class: 'wt-clock' });
  const el = h('div', { id: 'g-wartxt' },
    h('b', null, 'ZONE EN GUERRE  ·  ' + String(d.zone || '').slice(0, 40) + '  ·  ', clock),
    h('span', { class: 'wt-sub' }, 'Tirs autorisés  ·  pas de secours  ·  tiens les points de contrôle'));
  return { el, clock };
}
function buildScore(rows, target) {
  const sc = h('div', { id: 'g-tscore' });
  const max = Math.max(1, Number(target) || 0, ...rows.map((r) => Number(r.pts) || 0));
  rows.slice(0, 8).forEach((r) => {
    const fill = h('i', { style: { width: Math.min(100, (Number(r.pts) || 0) / max * 100) + '%', background: safeCol(r.color) } });
    sc.appendChild(h('div', { class: 'ts-row' }, h('span', null, String(r.label || r.id || '').slice(0, 24) + ' (' + (Number(r.pts) || 0) + ')'), h('div', { class: 'ts-bar' }, fill)));
  });
  return sc;
}
// une seule guerre affichée à la fois : la dernière source qui parle (bataille ou guerre planifiée) l'emporte, chacune peut la retirer
let txt = null, sc = null, owner = null, tick = null, endAt = 0;
function hide(src) {
  if (src && owner && src !== owner) return;
  clearInterval(tick); tick = null;
  if (txt) { txt.el.remove(); txt = null; }
  if (sc) { sc.remove(); sc = null; }
  owner = null;
  scoreHeight();
}
// les munitions (web/game.css #g-ammo) montent de la hauteur du bloc des points
function scoreHeight() { document.documentElement.style.setProperty('--tscore-h', sc ? (sc.offsetHeight + 10) + 'px' : '0px'); }
function show(src, d) {
  if (!d || !d.on) { hide(src); return; }
  const first = !txt;
  if (txt) txt.el.remove();
  if (sc) { sc.remove(); sc = null; }
  clearInterval(tick);
  txt = buildText(d); owner = src;
  if (!first) txt.el.classList.add('still');
  endAt = Date.now() + (Number(d.left) || 0) * 1000;
  const upd = () => { if (txt) txt.clock.textContent = fmt((endAt - Date.now()) / 1000); };
  upd(); tick = setInterval(upd, 500);
  G.root.appendChild(txt.el);
  const rows = d.rows || [];
  if (rows.length) { sc = buildScore(rows, d.target); G.root.appendChild(sc); }
  scoreHeight();
}
G.warBar = show;
G.on('terr.war', (d) => show('terr', d));

// Aperçu du panel : hors guerre (texte en bas), puis en guerre (texte en haut + points en bas à droite)
G.preview.territory = function (box) {
  G.clear(box);
  const wrap = h('div', { style: { display: 'grid', gap: '14px', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))' } });
  const peace = h('div', { class: 'gstage pv-terr' });
  peace.appendChild(h('div', { class: 'pv-txt' }, h('b', null, 'TERRITOIRE  ·  Grove Street'), h('span', { style: 'color:#a64dff' }, 'Territoire de Ballas  ·  tirs interdits')));
  peace.appendChild(h('div', { class: 'pv-cap' }, 'Hors guerre : texte en bas de l\'écran'));
  const war = h('div', { class: 'gstage pv-terr' });
  const t = buildText({ zone: 'Grove Street' });
  t.clock.textContent = '10:40';
  war.appendChild(t.el);
  war.appendChild(buildScore([{ label: 'Ballas', color: '#a64dff', pts: 62 }, { label: 'Families', color: '#2fbf4a', pts: 41 }, { label: 'Vagos', color: '#f2c200', pts: 17 }], 100));
  war.appendChild(h('div', { class: 'pv-cap' }, 'En guerre : texte en haut, points en bas à droite'));
  wrap.appendChild(peace); wrap.appendChild(war);
  box.appendChild(wrap);
};
})();
