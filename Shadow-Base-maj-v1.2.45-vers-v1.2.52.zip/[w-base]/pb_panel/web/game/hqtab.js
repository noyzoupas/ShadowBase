/* Tablette de l'entreprise / de l'organisation, au siège ou au QG : même fenêtre que la banque (web/game/daview.js).
   Le serveur envoie les mêmes pages que les menus (server/game/biz.lua, server/game/orga.lua) ; ici on adapte leur en-tête. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let cur = null, kind = null, raw = null;
const host = () => document.getElementById('g-hqtab') || (function () { const e = h('div', { id: 'g-hqtab', class: 'hidden' }); G.root.appendChild(e); return e; })();

// en-tête de la fenêtre : nom de l'entreprise / de l'organisation, grade, pages
function frameOf(k, f) {
  f = f || {};
  if (k === 'orga') {
    const nav = [{ id: 'home', label: 'Accueil', icon: 'home', group: 'Organisation' }]
      .concat((f.tiles || []).map((t) => ({ id: t.page || t.id, label: t.title, icon: t.icon, group: 'Organisation' })));
    return { brand: f.subtitle || 'Organisation', name: f.name || '', nav };
  }
  const b = f.biz;
  const nav = (f.nav || []).map((n) => ({ id: n.id, label: n.id === 'home' ? 'Tableau de bord' : n.label, icon: n.icon, group: n.group }));
  return { brand: b ? b.label : (f.subtitle || 'Espace citoyen'), name: b ? (String(b.grade || '') + (b.duty ? ' · En service' : ' · Hors service')) : (f.name || ''), nav, cash: f.cash, bank: f.bank };
}
// accueil de l'organisation : le serveur n'envoie rien (le menu avait des raccourcis) ; la tablette montre l'XP.
// Les pages sont seulement dans la barre de gauche (pas de tuiles en double).
function pageOf(k, p, f) {
  if (!p || k !== 'orga' || p.page !== 'home' || (p.blocks || []).length) return p;
  f = f || {};
  const chips = (f.xp || []).map((x) => [x.icon === 'users' ? 'XP du groupe' : 'Mon XP', String(x.value || '') + (x.rank ? ' · ' + x.rank : '')]);
  return { page: 'home', title: 'Accueil', blocks: [
    { type: 'hero', eyebrow: 'Tablette du QG', title: f.subtitle || 'Organisation', sub: f.name || '', chips },
    { type: 'notice', text: 'Choisis une page dans la barre de gauche.' }] };
}
function update(d) {
  if (!cur) return;
  if (d.frame) raw = d.frame;
  cur.set({ frame: d.frame ? frameOf(kind, d.frame) : undefined, page: d.page ? pageOf(kind, d.page, raw) : undefined, err: d.err });
}
G.on('hqtab.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  kind = d.kind === 'orga' ? 'orga' : 'biz'; raw = d.frame || {};
  const first = (d.focus && d.focus.page) || d.page;   // point du bureau du patron : la page de gestion directement
  cur = G.daView({ frame: frameOf(kind, raw), page: pageOf(kind, first, raw),
    onClose: () => G.post('hqtab.close', {}), onPage: (p) => G.post('hqtab.page', { page: p }), onAct: (n, pl, p) => G.post('hqtab.act', { name: n, payload: pl, page: p }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'hqtab'); G.uiStack.push({ id: 'hqtab', onEscape: () => G.post('hqtab.close', {}) });
});
G.on('hqtab.page', (d) => update(d));
G.on('hqtab.result', (d) => { update(d); if (cur) cur.say(d.ok, d.msg); });
G.on('hqtab.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; kind = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'hqtab'); });

// Aperçu du panel : la tablette d'une organisation, page Territoires
G.preview.hqtab = function (box) {
  G.clear(box);
  const f = { subtitle: 'Ballas', name: 'Loan46', xp: [{ icon: 'star', value: '1 240 XP' }, { icon: 'users', value: '18 600 XP', rank: '#2' }],
    tiles: [{ id: 'gestion', title: 'Gestion', icon: 'sliders' }, { id: 'territories', title: 'Territoires', icon: 'pin' }, { id: 'roster', title: 'Effectif', icon: 'user' }, { id: 'orgvault', title: 'Caisse', icon: 'wallet' }] };
  const page = { page: 'territories', title: 'Territoires', blocks: [
    { type: 'cards', items: [{ title: 'Territoires tenus', value: '1', icon: 'pin' }, { title: 'Zones du serveur', value: '3', icon: 'map' }] },
    { type: 'terrmap', title: 'Carte des territoires', zones: [
      { label: 'Grove Street', x: 114, y: -1944, r: 120, owner: 'Ballas', color: '#a64dff', mine: true },
      { label: 'Mirror Park', x: 1090, y: -645, r: 140 },
      { label: 'Canaux de Vespucci', x: -1157, y: -1520, r: 130, owner: 'Families', color: '#2fbf4a' }] }] };
  box.appendChild(G.fitStage(G.daView({ frame: frameOf('orga', f), page, onPage: () => {}, onAct: () => {} }).el));
};
})();
