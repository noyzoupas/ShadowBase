/* Panneau de la carte du jeu (à gauche) : liste des lieux par catégorie (recherche, ‹ 2/5 › pour passer d'un lieu à l'autre, cible = GPS),
   œil pour masquer les repères, zones de territoires. La carte et ses repères restent ceux du jeu.
   Les lieux viennent du jeu (repères posés par les scripts). Les textes sont insérés avec textContent ; les icônes ci-dessous sont des constantes. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const NS = 'http://www.w3.org/2000/svg';

// Même calibrage que la carte du panel (précision de l'ordre de 100 m)
const CAL = { ax: -5206.4, bx: 11493.2, ay: 8271.8, by: 12556 };
const uv = (x, y) => [(x - CAL.ax) / CAL.bx, (CAL.ay - y) / CAL.by];

// ---- Icônes des lieux : dessinées en 24×24, en couleur. Pour mettre les tiennes : déposer img/blips/<clé>.png (voir KEYS), elles passent avant. ----
const T = (c, t, sz) => '<text x="12" y="' + (sz > 14 ? 18.5 : 17) + '" text-anchor="middle" font-family="Poppins,Arial,sans-serif" font-weight="800" font-size="' + (sz || 18) + '" fill="' + c + '">' + t + '</text>';
const ICONS = {
  loan: '<circle cx="12" cy="9" r="5.5" fill="#2f8bff" stroke="#bfe0ff" stroke-width="1.6"/><path d="M8.5 13l-2 8 5.5-3 5.5 3-2-8z" fill="#cfe6ff"/>',
  resale: '<path d="M12 2.5l9 4.2v8.2l-9 6.6-9-6.6V6.7z" fill="#e9922f"/><path d="M12 6l5.2 2.4v4.8L12 17l-5.2-3.8V8.4z" fill="#2b1a08"/><path d="M12 8.6l2.6 1.2v2.4L12 14l-2.6-1.8V9.8z" fill="#f4b95f"/>',
  hook: '<path d="M13 3v10a4 4 0 11-8 0" fill="none" stroke="#c9ccd2" stroke-width="2.4" stroke-linecap="round"/><path d="M4 11l1.2 2.6L7.6 11.6" fill="none" stroke="#c9ccd2" stroke-width="2" stroke-linecap="round"/><circle cx="13" cy="3.2" r="1.6" fill="#c9ccd2"/>',
  hunt: '<path d="M12 2.5l8.5 4v6.5c0 4.2-3.6 6.9-8.5 8.5C7.1 19.900 3.500 17.200 3.500 13V6.500z" fill="#2f8a3d"/><circle cx="12" cy="11.500" r="4.200" fill="none" stroke="#d8f5d5" stroke-width="1.700"/><path d="M12 5.800v11.400M6.300 11.500h11.400" stroke="#d8f5d5" stroke-width="1.500"/>',
  gun: '<rect x="2" y="6" width="19.500" height="5.200" rx="1.400" fill="#e23a34"/><path d="M6.500 11h5.600l-1.300 9H7.300z" fill="#e23a34"/><path d="M12.300 11.200v3.200h3.600" fill="none" stroke="#e23a34" stroke-width="1.700" stroke-linecap="round"/><rect x="15" y="7.400" width="4" height="1.200" rx=".6" fill="#7d1612"/>',
  bone: '<g transform="rotate(-38 12 12)" fill="#f1f1f1"><rect x="5.500" y="10.300" width="13" height="3.400" rx="1.200"/><circle cx="5" cy="9.600" r="2.500"/><circle cx="5" cy="14.400" r="2.500"/><circle cx="19" cy="9.600" r="2.500"/><circle cx="19" cy="14.400" r="2.500"/></g>',
  arcade: '<rect x="4" y="5" width="16" height="10.500" rx="1.600" fill="#f1f3f5"/><rect x="5.800" y="6.800" width="12.400" height="6.900" rx=".8" fill="#14161a"/><path d="M2.500 17h19l-1.500 2.500h-16z" fill="#f1f3f5"/>',
  dollar: '<circle cx="12" cy="12" r="9" fill="#173d20"/>' + T('#43d15c', '$', 17),
  scissors: '<circle cx="7" cy="17" r="3" fill="none" stroke="#f28a1d" stroke-width="2.200"/><circle cx="17" cy="17" r="3" fill="none" stroke="#f28a1d" stroke-width="2.200"/><path d="M9 14.500L17.500 3.500M15 14.500L6.500 3.500" stroke="#f28a1d" stroke-width="2.200" stroke-linecap="round"/>',
  bowling: '<rect x="2.500" y="2.500" width="19" height="19" rx="3" fill="#1b6fd1"/>' + T('#d8eaff', 'B', 15),
  fist: '<path d="M3 14.500c2-3 4-4 6.500-3.200l2-2.800 2.800 1.800L10.800 14l7 3.600c1.800 1 3.200-.4 3.200-.4l-1 3.800H9z" fill="#f1b21e"/>',
  wood: '<rect x="3" y="4" width="18" height="16" rx="2" fill="#6b4a2c"/><rect x="5.500" y="6.500" width="13" height="11" rx="1" fill="#8a6038"/><circle cx="12" cy="12" r="3.200" fill="none" stroke="#b78a58" stroke-width="1.400"/><circle cx="12" cy="12" r="1" fill="#b78a58"/>',
  works: '<path d="M6 3.500v17M18 3.500v17M3.500 7.500h17M3.500 13.500h17" stroke="#f0a226" stroke-width="2.600" stroke-linecap="square"/>',
  school: '<circle cx="12" cy="12" r="9.500" fill="#7a56c9"/><path d="M12 5.500l5.500 12h-2.500l-1-2.600h-4l-1 2.600H6.500zM11 12.800h2L12 10z" fill="#efe6ff"/>',
  globe: '<circle cx="12" cy="12" r="9" fill="#1c6a3a"/><path d="M3 12h18M12 3c3 2.400 3 15.600 0 18M12 3c-3 2.400-3 15.600 0 18M5 7.500h14M5 16.500h14" fill="none" stroke="#7fe0a0" stroke-width="1.300"/>',
  tow: '<path d="M2.500 16.500V10l3-3h7v5h3.500l3 2.500v2z" fill="#e8b21e"/><circle cx="7" cy="17" r="2.300" fill="#2a2a2a" stroke="#e8b21e" stroke-width="1"/><circle cx="17" cy="17" r="2.300" fill="#2a2a2a" stroke="#e8b21e" stroke-width="1"/>',
  spray: '<rect x="8" y="9" width="8" height="12" rx="1.600" fill="#9b6a3d"/><rect x="9.500" y="5.500" width="5" height="3.500" fill="#d6c3a5"/><path d="M5 4.500h2M4 7.500h2M5 10.500h2" stroke="#d6c3a5" stroke-width="1.400" stroke-linecap="round"/>',
  garage: '<rect x="3" y="3.500" width="18" height="17" rx="2.600" fill="#1d63c4"/><path d="M6.500 8h11M6.500 11.500h11M6.500 15h11" stroke="#cfe3ff" stroke-width="1.800" stroke-linecap="round"/>',
  wrench: '<path d="M14.800 3.500a5 5 0 00-4.600 6.800L3.500 17a2.200 2.200 0 103.100 3.100l6.700-6.700a5 5 0 006.800-4.600l-3.200 3.200-2.800-.6-.6-2.800z" fill="#b8bec9"/>',
  heart: '<path d="M12 20.500C5 15.500 3 12 3 8.800A4.600 4.600 0 0112 7a4.600 4.600 0 019 1.800c0 3.200-2 6.700-9 11.700z" fill="#e8434f"/><path d="M12 9v6M9 12h6" stroke="#fff" stroke-width="1.800" stroke-linecap="round"/>',
  shield: '<path d="M12 2.500l8 3v6.500c0 4.600-3.300 7.800-8 9.500-4.700-1.700-8-4.900-8-9.500V5.500z" fill="#2a5bd1"/><path d="M12 7l1.500 3 3.300.4-2.400 2.300.6 3.300-3-1.600-3 1.600.6-3.300-2.400-2.300 3.300-.4z" fill="#e8f0ff"/>',
  cart: '<path d="M3 4h2.600l2.200 10.500h10.200L20 7H7" fill="none" stroke="#6fd0e8" stroke-width="2.100" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9.500" cy="19" r="1.700" fill="#6fd0e8"/><circle cx="17" cy="19" r="1.700" fill="#6fd0e8"/>',
  fuel: '<rect x="4" y="3.500" width="10" height="17" rx="1.800" fill="#e6612e"/><rect x="6" y="6" width="6" height="4" rx=".6" fill="#2a1208"/><path d="M14 8.500h2.500a2 2 0 012 2V16a1.300 1.300 0 002.600 0V9l-2.500-2.200" fill="none" stroke="#e6612e" stroke-width="1.800" stroke-linecap="round"/>',
  house: '<path d="M3 11.500L12 3.500l9 8h-2.500V20h-4.500v-5.500h-4V20H5.500v-8.500z" fill="#4aa3ff"/>',
  shirt: '<path d="M8.500 3.500L3 6.500l2 4 2-1V20.500h10V9.500l2 1 2-4-5.500-3c-.5 1.500-1.800 2.300-3.500 2.300S9 5 8.500 3.500z" fill="#e8e8ee"/>',
  cocktail: '<path d="M4.500 4.500h15L12 13.500zM12 13.500V20M8 20.500h8" fill="#e9528c" stroke="#e9528c" stroke-width="1.800" stroke-linejoin="round" stroke-linecap="round"/><circle cx="17" cy="4.500" r="2" fill="#7ad65a"/>',
  burger: '<path d="M4 11a8 7 0 0116 0z" fill="#e8a23a"/><rect x="3.500" y="12" width="17" height="2.400" rx="1.200" fill="#58a83c"/><rect x="3.500" y="14.800" width="17" height="2" rx="1" fill="#7a3b1c"/><path d="M4 17.500h16a4 3 0 01-4 3H8a4 3 0 01-4-3z" fill="#e8a23a"/>',
  coffee: '<path d="M4.500 8.500h12v6a5 5 0 01-5 5h-2a5 5 0 01-5-5z" fill="#d9a36b"/><path d="M16.500 10h1.800a2.600 2.600 0 010 5.200h-2" fill="none" stroke="#d9a36b" stroke-width="1.800"/><path d="M8 3.500c-1 1 1 2 0 3M12 3.500c-1 1 1 2 0 3" stroke="#d9a36b" stroke-width="1.300" fill="none" stroke-linecap="round"/>',
  taxi: '<rect x="3" y="9" width="18" height="8" rx="2.600" fill="#f2c12e"/><rect x="9.500" y="5" width="5" height="3.200" rx=".8" fill="#f2c12e"/><circle cx="7.500" cy="17.500" r="2" fill="#262626"/><circle cx="16.500" cy="17.500" r="2" fill="#262626"/>',
  tattoo: '<path d="M4 20l3-.5L18.500 8 16 5.500 4.500 17z" fill="#d7d9de"/><path d="M16.800 4.700l1.400-1.400a1.600 1.600 0 012.300 2.300L19.200 7z" fill="#e9528c"/>',
  dice: '<rect x="3.500" y="3.500" width="17" height="17" rx="3.600" fill="#ece8dc"/><circle cx="8.500" cy="8.500" r="1.600" fill="#c9302c"/><circle cx="15.500" cy="8.500" r="1.600" fill="#c9302c"/><circle cx="12" cy="12" r="1.600" fill="#c9302c"/><circle cx="8.500" cy="15.500" r="1.600" fill="#c9302c"/><circle cx="15.500" cy="15.500" r="1.600" fill="#c9302c"/>',
  car: '<path d="M3 14.500l1.700-5A2.500 2.500 0 017 7.800h10a2.500 2.500 0 012.300 1.700l1.700 5v3.200h-2.500V19h-2.500v-1.300h-9V19H5.500v-1.300H3z" fill="#9aa3b2"/><circle cx="7.300" cy="14.200" r="1.400" fill="#1a1d22"/><circle cx="16.700" cy="14.200" r="1.400" fill="#1a1d22"/>',
  plane: '<path d="M21 3L2.500 10.500l6 2.500 2.500 6 3-6.200z" fill="#7fb8ff"/>',
  boat: '<path d="M3 15h18l-3 4.500H6zM11 4v9M11 4l6 7h-6" fill="#69c5d9" stroke="#69c5d9" stroke-width="1.300" stroke-linejoin="round"/>',
  tools: '<rect x="3" y="9" width="18" height="11" rx="2" fill="#c85a2a"/><path d="M8.500 9V6.500a1.500 1.500 0 011.500-1.500h4a1.500 1.500 0 011.500 1.500V9" fill="none" stroke="#c85a2a" stroke-width="1.800"/><rect x="10.500" y="12.500" width="3" height="3" fill="#2a1208"/>',
  leaf: '<path d="M5 19c0-9 5-14 15-14 0 10-5 15-14 15z" fill="#4fbf4a"/><path d="M5 19c3-5 6-7.500 9.500-9" stroke="#0e3a12" stroke-width="1.400" fill="none"/>',
  mask: '<path d="M3.500 6.500c3-1.700 6-2 8.500-2s5.500.3 8.500 2c0 6-2 11.500-8.500 13-6.500-1.500-8.500-7-8.500-13z" fill="#e8e8ee"/><ellipse cx="8.500" cy="10" rx="2.200" ry="1.300" fill="#111"/><ellipse cx="15.500" cy="10" rx="2.200" ry="1.300" fill="#111"/>',
  star: '<path d="M12 3l2.700 5.600 6.100.8-4.500 4.200 1.200 6L12 16.600 6.500 19.600l1.200-6L3.200 9.400l6.100-.8z" fill="#f3c12e"/>',
  pin: '<path d="M12 21.500s-6.800-6-6.800-11.200a6.800 6.800 0 0113.600 0C18.800 15.500 12 21.500 12 21.500z" fill="currentColor"/><circle cx="12" cy="10" r="2.600" fill="#0e1014"/>',
};
const KEYS = Object.keys(ICONS);
// mots du nom du lieu -> icône (accents ignorés)
const BY_NAME = [
  ['loan', 'loan'], ['revente', 'resale'], ['peche', 'hook'], ['chasse', 'hunt'], ['ammu', 'gun'], ['armurerie', 'gun'], ['arme', 'gun'], ['animalerie', 'bone'], ['arcade', 'arcade'],
  ['banque', 'dollar'], ['atm', 'dollar'], ['distributeur', 'dollar'], ['fleeca', 'dollar'], ['barbier', 'scissors'], ['coiffeur', 'scissors'], ['bowling', 'bowling'], ['bras de fer', 'fist'], ['bucheron', 'wood'],
  ['chantier', 'works'], ['ecole', 'school'], ['interim', 'globe'], ['fourriere', 'tow'], ['depann', 'tow'], ['full custom', 'spray'], ['peinture', 'spray'], ['graffiti', 'spray'], ['garage', 'garage'],
  ['atelier', 'wrench'], ['mecan', 'wrench'], ['hopital', 'heart'], ['pharmac', 'heart'], ['ems', 'heart'], ['police', 'shield'], ['commissariat', 'shield'], ['gendarm', 'shield'], ['superette', 'cart'], ['magasin', 'cart'],
  ['epicerie', 'cart'], ['supermarche', 'cart'], ['station', 'fuel'], ['essence', 'fuel'], ['logement', 'house'], ['maison', 'house'], ['appartement', 'house'], ['agence', 'house'], ['vetement', 'shirt'], ['binco', 'shirt'],
  ['bar', 'cocktail'], ['club', 'cocktail'], ['unicorn', 'cocktail'], ['burger', 'burger'], ['restaurant', 'burger'], ['pizza', 'burger'], ['cafe', 'coffee'], ['taxi', 'taxi'], ['tatou', 'tattoo'], ['casino', 'dice'],
  ['concession', 'car'], ['location', 'car'], ['aeroport', 'plane'], ['port', 'boat'], ['bateau', 'boat'], ['outil', 'tools'], ['quincaillerie', 'tools'], ['culture', 'leaf'], ['recolte', 'leaf'], ['weed', 'leaf'],
  ['braquage', 'mask'], ['coffre', 'mask'],
];
// sprites du jeu connus -> icône (si le nom ne dit rien)
const BY_SPRITE = { 110: 'gun', 108: 'dollar', 277: 'dollar', 71: 'scissors', 73: 'shirt', 61: 'heart', 60: 'shield', 357: 'garage', 361: 'fuel', 40: 'house', 52: 'cart', 93: 'cocktail', 75: 'tattoo', 446: 'wrench', 225: 'car', 198: 'taxi', 90: 'plane', 427: 'boat', 590: 'dice', 679: 'dice', 59: 'cart', 77: 'burger', 106: 'coffee', 68: 'hook', 76: 'hunt' };
// couleurs des repères du jeu (approximation)
const COLS = { 0: '#e6e6e6', 1: '#e03232', 2: '#72cc72', 3: '#5db6e5', 4: '#f0f0f0', 5: '#eec650', 6: '#e03232', 7: '#9c6eaf', 8: '#ff7bc4', 9: '#f0b270', 17: '#ea8f35', 25: '#3b963c', 29: '#25669f', 38: '#2462a5', 40: '#4d4d4d', 43: '#8ce6c8', 46: '#eedc78', 49: '#9b2828' };
const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
function iconKey(name, sprite) {
  const n = norm(name);
  for (const [w, k] of BY_NAME) if (n.indexOf(w) >= 0) return k;
  return BY_SPRITE[sprite] || 'pin';
}
function svgIcon(key, color, size) {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'at-ic');
  if (size) { s.setAttribute('width', size); s.setAttribute('height', size); }
  if (color) s.style.color = color;
  s.innerHTML = ICONS[key] || ICONS.pin;   // constantes ci-dessus, jamais du texte du serveur
  return s;
}
// icône : l'icône native du jeu (image de la documentation FiveM, comme dans le Builder) ; ton PNG img/blips/<sprite>.png passe avant ; sinon le dessin
const bad = {};
function glyph(key, color, size, sprite) {
  const native = sprite != null && sprite > 0 && window.PBBlipPick && window.PBBlipPick.url && window.PBBlipPick.url(sprite);
  // icône native du jeu quand le sprite est connu (pas de dessin de remplacement : on attend l'image), sinon dessin
  const box = h('span', { class: 'at-g' }, native ? null : svgIcon(key, color, size));
  const urls = [];
  if (sprite != null && sprite > 0) {
    urls.push('img/blips/' + sprite + '.png');
    const u = window.PBBlipPick && window.PBBlipPick.url && window.PBBlipPick.url(sprite);
    if (u) urls.push(u);
  }
  urls.push('img/blips/' + key + '.png');
  const next = (i) => {
    while (i < urls.length && bad[urls[i]]) i++;
    if (i >= urls.length) { if (native && !box.firstChild) box.appendChild(svgIcon(key, color, size)); return; }
    const im = new Image();
    im.onload = () => {
      box.textContent = '';
      if (color && /^#/.test(color) && urls[i] === native) {   // image native (blanche) : teinte à la couleur du repère
        const m = h('span', { class: 'at-ic at-tint' });
        m.style.backgroundColor = color; m.style.webkitMaskImage = m.style.maskImage = 'url("' + urls[i] + '")';
        box.appendChild(m);
      } else { im.className = 'at-ic at-img'; box.appendChild(im); }
    };
    im.onerror = () => { bad[urls[i]] = true; next(i + 1); };
    im.src = urls[i];
  };
  next(0);
  return box;
}

const I = {
  search: 'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-4.500-4.500', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 100 6 3 3 0 000-6z',
  eyeoff: 'M3 3l18 18M10.600 6.100A9.500 9.500 0 0112 5c6 0 10 7 10 7a17 17 0 01-3.200 4M6.600 6.700C3.700 8.500 2 12 2 12s4 7 10 7c1.600 0 3-.4 4.200-1M9.900 9.900a3 3 0 004.200 4.200',
  gear: 'M12 9a3 3 0 100 6 3 3 0 000-6zM19.400 13.500a7.600 7.600 0 000-3l2-1.600-2-3.400-2.400 1a7.500 7.500 0 00-2.600-1.500L14 2.500h-4l-.4 2.500A7.500 7.500 0 007 6.500l-2.400-1-2 3.400 2 1.600a7.600 7.600 0 000 3l-2 1.600 2 3.400 2.400-1a7.500 7.500 0 002.600 1.500l.4 2.500h4l.4-2.500a7.500 7.500 0 002.600-1.500l2.400 1 2-3.400z',
  target: 'M12 3v4M12 17v4M3 12h4M17 12h4M12 8a4 4 0 100 8 4 4 0 000-8z', left: 'M15 5l-7 7 7 7', right: 'M9 5l7 7-7 7', x: 'M5 5l14 14M19 5L5 19',
  gps: 'M12 21s-7-6-7-11a7 7 0 0114 0c0 5-7 11-7 11zM12 7.500a2.500 2.500 0 100 5 2.500 2.500 0 000-5z',
};
function ui(name, cls) {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'at-u' + (cls ? ' ' + cls : ''));
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', I[name]); s.appendChild(p); return s;
}
const btn = (cls, kids, fn, title) => h('button', { type: 'button', class: cls, title: title || null, onclick: (e) => { e.stopPropagation(); fn(e); } }, kids);

const MAPS = [['Satellite', 'sat'], ['Sombre', 'dark'], ['Clair', 'light']];
let host = null, S = null;
const root = () => host || (host = (function () { const e = h('div', { id: 'g-atlas', class: 'hidden' }); G.root.appendChild(e); return e; })());
const fmtD = (m) => m >= 1000 ? (m / 1000).toFixed(1).replace('.', ',') + ' km' : Math.round(m / 10) * 10 + ' m';

function build(d, prev) {
  const post = prev ? () => {} : G.post;
  const me = d.me || { x: 0, y: 0, h: 0 };
  // catégories : un nom = une catégorie
  const cats = new Map();
  (d.points || []).forEach((p) => {
    const name = String(p.n || '').trim() || ('Lieu ' + p.s);
    const k = norm(name);
    let c = cats.get(k);
    if (!c) { const key = iconKey(name, p.s); c = { k, name, key, sprite: p.s, color: COLS[p.c] || '#e6e6e6', pts: [], idx: 0 }; cats.set(k, c); }
    c.pts.push({ x: p.x, y: p.y, dist: Math.hypot(p.x - me.x, p.y - me.y) });
  });
  const list = Array.from(cats.values());
  list.forEach((c) => c.pts.sort((a, b) => a.dist - b.dist));
  // les points créés au Builder (Loan, reventes, pêche, chasse…) en tête dans cet ordre, puis tout le reste par ordre alphabétique
  const PIN = ['peche', 'chasse'];
  const pinOf = (c) => { const n = norm(c.name); for (let i = 0; i < PIN.length; i++) if (n.indexOf(PIN[i]) === 0) return i; return 99; };
  list.sort((a, b) => (pinOf(a) - pinOf(b)) || a.name.localeCompare(b.name, 'fr', { sensitivity: 'base' }));

  // La carte est celle du jeu (avec ses repères d'origine) : ce panneau la pilote — repères du lieu choisi qui clignotent, GPS, masquer, zones.
  const state = { sel: null, hide: false, zones: true, q: '' };
  const meName = String((d.me && d.me.name) || '').slice(0, 40);
  const q = h('input', { type: 'text', class: 'at-q', placeholder: 'Rechercher un lieu', maxlength: '40' });
  q.addEventListener('keydown', (e) => e.stopPropagation());
  q.addEventListener('input', () => { state.q = q.value; paintList(); });
  const eyeBtn = btn('at-sq', [ui('eye')], () => { state.hide = !state.hide; G.clear(eyeBtn); eyeBtn.appendChild(ui(state.hide ? 'eyeoff' : 'eye')); post('atlas.hide', { on: state.hide }); }, 'Afficher / masquer les repères');
  const styleBtns = [];
  const paintStyles = (cur) => styleBtns.forEach((b, i) => b.classList.toggle('on', i === cur));
  const names = ['Carte du jeu (d\u2019origine)'].concat(d.styles || []);
  names.forEach((nm, i) => { const b = btn('at-mi', [ui('gps'), nm], () => { menu.classList.add('hidden'); paintStyles(i); post('atlas.style', { i }); }); styleBtns.push(b); });
  const menu = h('div', { class: 'at-menu hidden' }, h('small', { class: 'at-ms' }, 'Type de carte'), styleBtns,
    h('i', { class: 'at-sep' }),
    btn('at-mi', [ui('gps'), 'Effacer le GPS'], () => { menu.classList.add('hidden'); post('atlas.gpsoff'); }),
    btn('at-mi', [ui('eye'), 'Tout afficher'], () => { menu.classList.add('hidden'); state.hide = false; G.clear(eyeBtn); eyeBtn.appendChild(ui('eye')); post('atlas.hide', { on: false }); }));
  paintStyles(Number(d.style) || 0);
  const gpsBtn = h('span', { class: 'at-tw' }, btn('at-type', [ui('gear'), h('span', null, 'Type de carte')], () => menu.classList.toggle('hidden'), 'Options de la carte'), menu);
  const box = h('div', { class: 'at-list' });
  function select(c, i) {
    state.sel = c; c.idx = Math.max(0, Math.min(c.pts.length - 1, i == null ? c.idx : i));
    post('atlas.select', { k: c.k, i: c.idx, x: c.pts[c.idx].x, y: c.pts[c.idx].y, name: c.name });
    paintList();
  }
  function paintList() {
    G.clear(box);
    const qq = norm(state.q);
    let n = 0;
    list.forEach((c) => {
      if (qq && norm(c.name).indexOf(qq) < 0) return;
      n++;
      const many = c.pts.length > 1, on = state.sel === c;
      const row = h('div', { class: 'at-r' + (on ? ' on' : ''), onclick: () => select(c, c.idx) },
        glyph(c.key, c.color, 26, c.sprite), h('b', null, c.name),
        on ? btn('at-loc', [ui('target')], () => select(c, c.idx), 'Poser le GPS sur ce lieu') : null,
        many ? h('span', { class: 'at-cy' }, btn('at-ar', [ui('left')], () => select(c, (c.idx - 1 + c.pts.length) % c.pts.length)), h('em', null, (c.idx + 1) + '/' + c.pts.length), btn('at-ar', [ui('right')], () => select(c, (c.idx + 1) % c.pts.length))) : null);
      box.appendChild(row);
    });
    // première ligne : le joueur lui-même (son nom FiveM) ; un clic fait clignoter sa position sur la carte
    if (meName && (!qq || norm(meName).indexOf(qq) >= 0)) {
      const on = state.sel === 'me';
      box.insertBefore(h('div', { class: 'at-r at-self' + (on ? ' on' : ''), onclick: () => { state.sel = 'me'; post('atlas.me', {}); paintList(); } },
        h('i', { class: 'at-mei' }), h('b', null, meName)), box.firstChild);
      n++;
    }
    if (!n) box.appendChild(h('div', { class: 'at-empty' }, list.length ? 'Aucun lieu ne correspond.' : 'Aucun lieu sur la carte pour le moment.'));
  }
  const zIc = h('span', { class: 'at-zi' }, ui('eye'));
  const zoneRow = h('div', { class: 'at-zrow on', onclick: () => { state.zones = !state.zones; G.clear(zIc); zIc.appendChild(ui(state.zones ? 'eye' : 'eyeoff')); zoneRow.classList.toggle('on', state.zones); post('atlas.zones', { on: state.zones }); } });
  zoneRow.append(zIc, h('b', null, 'Territoires'));
  const zones = (d.zones || []).length ? h('div', { class: 'at-zbox' }, h('small', null, 'Zones'), zoneRow) : null;
  const side = h('aside', { class: 'at-side' },
    h('header', { class: 'at-hd' }, h('div', null, h('small', null, G.brandName ? G.brandName() : ''), h('h2', null, 'Carte')), gpsBtn),
    h('div', { class: 'at-sr' }, h('label', { class: 'at-sb' }, ui('search'), q), eyeBtn),
    box, zones);
  // la souris ne va au panneau que lorsqu'elle le survole : ailleurs, elle sert à la carte du jeu
  side.addEventListener('mouseleave', () => post('atlas.leave'));
  const el = h('div', { class: 'at-root at-only' }, side);
  const rect = () => { const r = side.getBoundingClientRect(); post('atlas.rect', { r: (r.right + 6) / Math.max(1, window.innerWidth) }); };
  requestAnimationFrame(() => { paintList(); rect(); });
  window.addEventListener('resize', rect);
  return { el, setMe() {} };
}

let cur = null;
G.on('atlas.open', (d) => {
  const r = root(); r.classList.add('atl'); G.clear(r); r.classList.remove('hidden');
  cur = build(d); r.appendChild(cur.el);
  G.uiStack = G.uiStack || [];
  G.uiStack = G.uiStack.filter((u) => u.id !== 'atlas'); G.uiStack.push({ id: 'atlas', onEscape: () => G.post('atlas.close') });
});
G.on('atlas.me', (d) => { if (cur) cur.setMe(d.me, d.wp); });
G.on('atlas.close', () => {
  const r = root(); G.clear(r); r.classList.add('hidden'); cur = null; S = null;
  G.uiStack = (G.uiStack || []).filter((u) => u.id !== 'atlas');
});
G.atlasKeys = KEYS;
// Aperçu du panel : la barre à gauche d'une carte, avec des lieux d'exemple
G.preview.atlas = function (box) {
  G.clear(box);
  const names = [['Points de revente: Vente de drogue', 0, 5, 8], ['Pêche: Quai de Roxwood', 68, 5, 7], ['Chasse: Zone de Chasse Roxwood', 141, 5, 5], ['Ammunation', 110, 9, 9], ['Animalerie', 0, 5, 1], ['Arcade house', 740, 5, 1], ['Banque', 108, 8, 8], ['Barbier', 71, 8, 7], ['Bowling', 97, 3, 1], ['Bras de Fer', 0, 5, 4], ['Garage', 357, 3, 19]];
  const pts = [];
  names.forEach((n, i) => { for (let k = 0; k < n[3]; k++) pts.push({ x: -800 + i * 110 + k * 30, y: -2500 + i * 300 + k * 80, s: n[1], c: n[2], n: n[0] }); });
  const stage = h('div', { class: 'atl at-stage' });
  const v = build({ points: pts, me: { x: 0, y: -1500, h: 0, name: 'Loan46' }, zones: [{ x: 0, y: 0, r: 100, label: 'Zone', color: '#3fa34d' }] }, true);
  stage.appendChild(v.el); box.appendChild(stage);
};
})();
