/* Guerre de territoire planifiée : même bandeau en haut de l'écran que les batailles de zone (web/game/territory.js). */
(function () {
'use strict';
const G = window.PBGame;
G.on('war.board', (d) => { if (G.warBar) G.warBar('war', d); });
G.preview.war = function (box) { G.clear(box); const s = G.h('div', { class: 'gstage pv-terr' }); box.appendChild(s); const prev = G.root; G.root = s;
  G.warBar('war', { on: true, zone: 'Mirror Park', left: 1260, rows: [{ id: 'ballas', label: 'Ballas', color: '#a64dff', pts: 86 }, { id: 'fam', label: 'Families', color: '#2fbf4a', pts: 61 }, { id: 'vagos', label: 'Vagos', color: '#f2c200', pts: 23 }] });
  G.root = prev; };
})();
