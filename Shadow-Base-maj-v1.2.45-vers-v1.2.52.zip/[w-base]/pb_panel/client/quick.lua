-- Menu de mon entreprise (F6) : le serveur envoie la liste des entrées autorisées, ce fichier en fait un menu lib. Rien n'est décidé ici.
-- Une action sur quelqu'un ouvre « Choisir la personne » : la personne survolée est entourée à l'écran (client/pick.lua).
local G = PBG
local spec = nil

local function notify(t, text) G.send('notify', { type = t, title = spec and spec.biz or 'Entreprise', text = text }) end
local function send(id, payload) TriggerServerEvent('pb:g:quick:act', id, payload or {}) end

local function askInputs(e, payload)
    for _, inp in ipairs(e.inputs or {}) do
        local v = G.Menu.Ask(inp.label, payload[inp.k] and tostring(payload[inp.k]) or '', inp.maxlen or 60)
        if v == nil or v == '' then return false end
        payload[inp.k] = inp.number and tonumber(v) or v
    end
    return true
end

-- personnes proposées : celles envoyées par l'entrée (ex. clients de la course), sinon les joueurs proches connus du serveur
local function people(e) return e.near or spec.near or {} end

-- gestes du mécano lancés sur place (animation, véhicule le plus proche) : commandes du client, revérifiées par le serveur
local CLIENT = { mech_repair = 'pb_mech_repair', mech_clean = 'pb_mech_clean' }

-- (v1.2.42) flotte (entreprise ou organisation) : un sous-menu par véhicule (où, qui) avec « GPS » et « Rappeler au garage »
function G.FleetItem(e, sendFn, prefix)
    local items = {}
    for _, f in ipairs(e.items or {}) do
        local right = f.state == 'out' and (f.busy and 'En route' or 'Abandonné ?') or f.where
        local desc = f.state == 'out' and ((f.who and ('Sorti par ' .. f.who) or 'Sorti') .. (f.live and '' or ' · introuvable en ville')) or f.where
        local acts = {}
        if f.state == 'out' and f.live then acts[#acts + 1] = { label = 'GPS : le retrouver', icon = 'gps', onSelect = function() sendFn(e.id, { plate = f.plate, act = 'gps' }) end } end
        if f.state == 'out' and f.recall then acts[#acts + 1] = { label = 'Rappeler au garage', icon = 'undo', description = "Personne n'est à bord : le véhicule disparaît de la ville et revient au garage.", onSelect = function() sendFn(e.id, { plate = f.plate, act = 'recall' }) end } end
        if #acts == 0 then acts[1] = { label = f.state == 'out' and "Quelqu'un est au volant" or 'Au garage', disabled = true } end
        items[#items + 1] = { type = 'submenu', label = tostring(f.label) .. ' · ' .. tostring(f.plate), right = right, description = desc, submenu = { id = (prefix or 'fleet') .. '.' .. f.plate, title = tostring(f.label), subtitle = tostring(f.plate), items = acts } }
    end
    if #items == 0 then items[1] = { label = 'Aucun véhicule', disabled = true } end
    return { type = 'submenu', label = e.label, icon = e.icon, right = e.right, description = e.desc, submenu = { id = prefix or 'fleet', title = e.label, items = items } }
end

local function entryItem(e)
    if e.type == 'separator' then return { type = 'separator', label = e.label } end
    if e.type == 'page' then return G.PagesMenu.Item('biz', e) end   -- page de gestion (équipe, caisse, factures…) : client/pagesmenu.lua
    if e.type == 'fleet' then return G.FleetItem(e, send, 'quick.fleet') end
    if e.type == 'choices' then   -- liste de choix : chacun envoie l'action avec son propre contenu (ex. mission → GPS)
        local list = {}
        for _, it in ipairs(e.items or {}) do list[#list + 1] = { label = it.label, right = it.right, onSelect = function() send(e.id, it.payload or {}) end } end
        if #list == 0 then list[1] = { label = 'Rien pour le moment', disabled = true } end
        return { type = 'submenu', label = e.label, icon = e.icon, right = e.right, description = e.desc, submenu = { id = 'quick.' .. e.id, title = e.label, items = list } }
    end
    if e.type == 'info' then
        if not e.items then return { label = e.label, icon = e.icon, right = e.right, description = e.desc, disabled = true } end
        local list = {}
        for _, m in ipairs(e.items) do list[#list + 1] = { label = m.label, right = m.right, disabled = true } end
        if #list == 0 then list[1] = { label = 'Personne pour le moment', disabled = true } end
        return { type = 'submenu', label = e.label, icon = e.icon, right = e.right, description = e.desc, submenu = { id = 'quick.' .. e.id, title = e.label, items = list } }
    end
    if e.type == 'duty' then
        return { type = 'button', label = e.label, description = e.desc, icon = e.icon, right = e.on and 'En service' or 'Hors service', onSelect = function() send('duty', { on = not e.on }) end }
    end
    if e.type == 'list' then
        local items = {}
        for _, c in ipairs(e.items or {}) do
            items[#items + 1] = { label = c.label, right = c.mine and 'Acceptée' or c.right, description = 'Entrée : accepter la course (le client est mis sur ton GPS).', onSelect = function() send('taxi_accept', { call = c.id }) end }
        end
        if #items == 0 then items[1] = { label = 'Aucune course pour le moment', disabled = true } end
        return { type = 'submenu', label = e.label, description = e.desc, icon = e.icon, right = e.right, submenu = { id = 'quick.' .. e.id, title = e.label, items = items } }
    end
    if e.kind == 'client' and CLIENT[e.id] then
        return { type = 'button', label = e.label, description = e.desc, icon = e.icon, onSelect = function() G.Menu.Close() ExecuteCommand(CLIENT[e.id]) end }
    end
    -- action sur une personne : on la choisit d'abord (surbrillance), puis montant / motif si besoin
    if e.needs == 'target' then
        local function done(id, extra)
            local p = extra or {}
            p.id = id
            if e.id == 'cmd' then p.cmd = e.cmd end
            if not askInputs(e, p) then return end
            send(e.id, p)
        end
        if e.pick and #e.pick > 0 then
            -- amende / facture : d'abord le motif (catalogue), ensuite la personne
            local items = {}
            for _, pk in ipairs(e.pick) do
                items[#items + 1] = { type = 'submenu', label = pk.label, right = pk.amount and PB.Money(pk.amount) or nil, submenu = function()
                    return G.PickMenu('quick.' .. e.id .. '.who', e.label, people(e), function(id)
                        local p = { id = id, code = pk.code, amount = pk.amount, reason = pk.label }
                        if e.id == 'invoice' then
                            p.code = nil
                            local r = G.Menu.Ask('Motif', pk.label, 60)
                            if r == nil or r == '' then return end
                            p.reason = r
                        end
                        send(e.id, p)
                    end)
                end }
            end
            if e.id == 'invoice' then
                items[#items + 1] = { type = 'submenu', label = 'Montant libre…', description = 'Choisis la personne, puis le montant et le motif.', submenu = function() return G.PickMenu('quick.invoice.who', e.label, people(e), function(id) done(id) end) end }
            end
            return { type = 'submenu', label = e.label, description = e.desc, icon = e.icon, submenu = { id = 'quick.' .. e.id, title = e.label, subtitle = 'Choisis puis la personne', items = items } }
        end
        return { type = 'submenu', label = e.label, description = e.desc, icon = e.icon, submenu = function() return G.PickMenu('quick.' .. e.id .. '.who', e.label, people(e), function(id) done(id) end) end }
    end
    return { type = 'button', label = e.label, description = e.desc, icon = e.icon, onSelect = function()
        local p = {}
        if e.id == 'cmd' then p.cmd = e.cmd end
        if not askInputs(e, p) then return end
        send(e.id, p)
    end }
end

local function items()
    local out = { { type = 'separator', label = spec.biz .. ' · ' .. spec.grade } }
    for _, e in ipairs(spec.entries) do out[#out + 1] = entryItem(e) end
    return out
end

local def = { id = 'quick', title = 'Mon entreprise', refreshOnReturn = true, build = function() return items() end }

RegisterNetEvent('pb:g:quick:ui', function(j)
    local d = G.decode(j)
    local mine = G.Menu.IsOpen() and G.Menu.Stack.menus[1] and G.Menu.Stack.menus[1].def == def
    if not d or not d.spec then if d and d.ev == 'update' and mine then G.Menu.Close() end return end
    spec = d.spec
    def.subtitle = (spec.duty and 'En service' or 'Hors service')
    def.banner = { text = tostring(spec.biz or 'Entreprise') }
    if d.ev == 'open' then
        G.Menu.Open(def)
    elseif mine then
        G.Menu.Refresh()
    end
end)
RegisterNetEvent('pb:g:quick:cmd', function(cmd) G.Menu.Close() if type(cmd) == 'string' and cmd:match('^[%w_:%-]+$') then ExecuteCommand(cmd) end end)

-- une seule action par appui : si deux raccourcis sont posés sur la même touche (ancienne touche mémorisée par FiveM + nouvelle),
-- le second appel n'ouvre pas puis referme le menu aussitôt
local lastToggle = 0
local function toggle()
    local t = GetGameTimer()
    if t - lastToggle < 400 then return end
    lastToggle = t
    if G.cfg.quick and G.cfg.quick.f2_menu == false then return end
    if not G.begun or G.creating or G.wardrobe or G.state.dead then return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    TriggerServerEvent('pb:g:quick:open')
end
-- (v1.2.45) la commande s'appelait pb_quick : chez les joueurs venus quand elle était sur F2, FiveM gardait « pb_quick = F2 »
-- (un 2e menu entreprise sur F2). Nouveau nom : l'ancienne touche ne mène plus nulle part.
RegisterCommand('pb_entreprise', toggle, false)
RegisterCommand('entreprise', toggle, false)
-- ancienne touche « F6 = tablette » mémorisée par FiveM chez les joueurs déjà venus : elle ouvre le menu de l'entreprise
RegisterCommand('pb_tablet__F6', toggle, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.quick and GetGameTimer() < t do Wait(250) end
    local k = tostring((G.cfg.quick and G.cfg.quick.key) or 'F6')
    if k:upper() == 'F2' then k = 'F6' end   -- jamais sur F2 (doublon de F6 / F7)
    if not (G.cfg.quick and G.cfg.quick.f2_menu == false) then RegisterKeyMapping('pb_entreprise', 'Menu de mon entreprise', 'keyboard', k) end
end)
