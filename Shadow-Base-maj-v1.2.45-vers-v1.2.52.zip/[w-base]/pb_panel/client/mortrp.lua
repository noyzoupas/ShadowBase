-- Mort RP (server/game/mortrp.lua) : quand le staff l'active, la prochaine balle reçue tue le personnage pour de bon.
local G = PBG
local armed = false
RegisterNetEvent('pb:g:mortrp:arm', function(on) armed = on == true end)
-- dégâts reçus : seulement les armes à balles (type de dégâts 3)
AddEventHandler('gameEventTriggered', function(name, args)
    if not armed or name ~= 'CEventNetworkEntityDamage' then return end
    local ped = PlayerPedId()
    if args[1] ~= ped then return end
    local weapon = args[7]
    if weapon and GetWeaponDamageType(weapon) == 3 then
        armed = false
        SetEntityHealth(ped, 0)
        TriggerServerEvent('pb:g:mortrp:hit')
    end
end)
RegisterNetEvent('pb:g:mortrp:screen', function(j)
    local d = G.decode(j) or {}
    G.send('mortrp', d)
end)
