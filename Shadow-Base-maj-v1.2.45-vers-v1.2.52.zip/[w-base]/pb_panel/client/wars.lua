-- Guerre de territoire : zone clignotante sur la carte (pour tous) + tableau des scores et compte à rebours à l'écran,
-- seulement tant qu'on est dans la zone en guerre (valeurs envoyées par le serveur).
local G = PBG
local blip
local board, recv, shown = nil, 0, false
local function inside(d)
    local r = G.terrInZone and G.terrInZone(d.zid)
    if r ~= nil then return r end   -- contour dessiné au Builder (ou cercle de la zone)
    local c = GetEntityCoords(PlayerPedId())
    return #(vector2(c.x, c.y) - vector2(d.x + 0.0, d.y + 0.0)) <= (d.r or 30) + 15.0
end
local function sync()
    local want = board ~= nil and inside(board)
    if want then
        local d = {}
        for k, v in pairs(board) do d[k] = v end
        d.left = math.max(0, (tonumber(board.left) or 0) - (GetGameTimer() - recv) / 1000)
        G.send('war.board', d)
    elseif shown then G.send('war.board', { on = false }) end
    shown = want
end
RegisterNetEvent('pb:g:war', function(j)
    local d = G.decode(j) or {}
    if blip and DoesBlipExist(blip) then RemoveBlip(blip) end
    blip = nil
    local was = board and board.zid
    if d.on then
        if not (G.terrInZone and G.terrInZone(d.zid) ~= nil) then
            blip = AddBlipForRadius(d.x + 0.0, d.y + 0.0, 0.0, (d.r or 30) + 15.0)
            SetBlipColour(blip, 1) SetBlipAlpha(blip, 110) SetBlipFlashes(blip, true)
        end
        board, recv = d, GetGameTimer()
    else board = nil end
    G.plannedWar = board   -- client/territories.lua : tirs libres dans la zone pendant la guerre, zone rouge sur la carte
    if (board and board.zid) ~= was and G.redrawTerr then G.redrawTerr() end
    if G.terrRefresh then G.terrRefresh() end
    if board and inside(board) or shown then sync() end
end)
CreateThread(function()
    while true do
        Wait(700)
        if board then
            local want = inside(board)
            if want ~= shown then sync() end
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and blip and DoesBlipExist(blip) then RemoveBlip(blip) end end)
