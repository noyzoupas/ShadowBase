-- Blanchiment : contact (PNJ) à chaque point de blanchiment ; E ouvre son menu (mise, commission, durée, avancement).
local G = PBG

local points = {}
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local cr, l = c.crime or {}, c.launder or {}
    points = (cr.enabled == false or l.enabled == false) and {} or (cr.launder or {})
    local npcs = {}
    for _, s in ipairs(points) do npcs[#npcs + 1] = { id = s.id, model = tostring(l.ped or 'g_m_m_armboss_01'), x = s.x, y = s.y, z = s.z, h = s.h or 0.0, scenario = 'WORLD_HUMAN_SMOKING' } end
    G.Npcs('launder', npcs)
end

-- (v1.2.45) fenêtre du contact (web/game/wash.js, même style que la banque) à la place du menu lib
local isOpen = false
local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.send('wash.close', {})
end
RegisterNetEvent('pb:g:wash:menu', function(j)
    local d = G.decode(j)
    if not d or G.creating or G.wardrobe or G.state.dead then return end
    if G.Menu.IsOpen() then G.Menu.Close() end
    isOpen = true
    G.focus(true)
    G.send('wash.open', d)
end)
G.nui['wash.start'] = function(d)
    if isOpen and d and d.id and tonumber(d.amount) then close() TriggerServerEvent('pb:g:wash:start', d.id, tonumber(d.amount)) end
    return {}
end
G.nui['wash.collect'] = function(d) if isOpen and d and d.id then close() TriggerServerEvent('pb:g:wash:collect', d.id) end return {} end
G.nui['wash.close'] = function() close() return {} end
G.onForceClose(function() close() end)

CreateThread(function()
    local shown
    while true do
        local best, bd = nil, 1e9
        if #points > 0 and G.begun and not G.state.dead then
            local c = GetEntityCoords(PlayerPedId())
            for _, s in ipairs(points) do local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) if d < bd then best, bd = s, d end end
        end
        if best and bd <= 12.0 then
            G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
            if bd <= 2.5 and not G.Menu.IsOpen() and not isOpen and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt', { show = true, key = 'E', text = 'Parler au contact' }) end
                if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:wash:open', best.id) end
            elseif shown then shown = nil G.send('prompt', { show = false }) end
            Wait(0)
        else
            if shown then shown = nil G.send('prompt', { show = false }) end
            Wait(700)
        end
    end
end)
TriggerEvent('chat:addSuggestion', '/blanchiment', "Avancement de ton blanchiment (de partout pour les VIP)")
