-- Concession tenue par des joueurs (server/game/shops.lua) : le vendeur choisit le véhicule à essayer / vendre ; le client accepte l'offre.
local G = PBG
local function money(n) return G.money and G.money(n) or (tostring(n) .. ' $') end
RegisterNetEvent('pb:g:dealer:menu', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local items, cats = {}, {}
    for _, v in ipairs(d.list or {}) do
        local c = (v.category and v.category ~= '') and v.category or 'Autres'
        if not cats[c] then cats[c] = {} items[#items + 1] = { type = 'separator', label = c } end
        items[#items + 1] = { label = v.label, right = money(v.price), icon = 'car', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:dealer:act', d.t, v.model, d.mode) end }
    end
    if #items == 0 then items[1] = { label = 'Aucun véhicule au catalogue', disabled = true } end
    G.Menu.Open({ id = 'dealer.pick', title = d.mode == 'sell' and 'Vendre un véhicule' or 'Faire essayer', subtitle = tostring(d.shop or ''), items = items })
end)
RegisterNetEvent('pb:g:dealer:offer', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    local done = false
    local function answer(ok) if done then return end done = true G.Menu.Close() TriggerServerEvent('pb:g:dealer:answer', d.token, ok) end
    G.Menu.Open({ id = 'dealer.offer', title = tostring(d.shop or 'Concession'), subtitle = 'Offre du vendeur', items = {
        { label = tostring(d.label or ''), right = money(d.price), icon = 'car', disabled = true },
        { type = 'button', label = 'Accepter et payer', icon = 'check', description = 'Le véhicule est à toi : plaque à ton nom, il apparaît devant la concession.', onSelect = function() answer(true) end },
        { type = 'button', label = 'Refuser', icon = 'x', onSelect = function() answer(false) end },
    } })
end)
