-- Menu Échap : ouverture à la place du menu de pause, fiche du personnage filmée (toi ou un véhicule), survol 3D, GPS et réglages du jeu.
-- Le serveur fournit les données ; ici on ne fait que de l'affichage, de la caméra et des réglages propres à ce joueur (gardés sur son PC).
local G = PBG
local isOpen, studio, fly, blips = false, nil, nil, {}

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) or G.locked > 0 or (G.Menu and G.Menu.IsOpen and G.Menu.IsOpen()) end

-- Réglages ---------------------------------------------------------------------------------------------------------------------------------
local DEF = { foot_view = 'keep', veh_view = 'keep', no_cinematic = false, radio_start = 'keep', filter = 'none', filter_str = 60, lod = 100, shadows = 'normal', radio_vol = 100, call_vol = 100 }
local S = {}
local function loadSet()
    local raw = GetResourceKvpString and GetResourceKvpString('pb_pause_set') or nil
    local t = raw and G.decode(raw) or nil
    S = {}
    for k, v in pairs(DEF) do S[k] = (type(t) == 'table' and t[k] ~= nil and type(t[k]) == type(v)) and t[k] or v end
end
local function saveSet() SetResourceKvp('pb_pause_set', json.encode(S)) end
local FILTERS = { none = false, cinema = 'cinema', warm = 'NG_filmic01', cool = 'NG_filmic08', vivid = 'NG_filmic15' }
local RADIOS = { off = 'OFF', rock = 'RADIO_01_CLASS_ROCK', pop = 'RADIO_02_POP', hiphop = 'RADIO_03_HIPHOP_NEW', punk = 'RADIO_04_PUNK', talk = 'RADIO_05_TALK_01', chill = 'RADIO_06_COUNTRY' }
local FOOT = { near = 0, mid = 1, far = 2, first = 4 }
local VEH = { far = 0, mid = 1, near = 2, first = 4 }
local function applyFilter()
    local m = FILTERS[S.filter]
    if m then SetTimecycleModifier(m) SetTimecycleModifierStrength(math.max(0.0, math.min(1.0, (tonumber(S.filter_str) or 60) / 100))) else ClearTimecycleModifier() end
end
local function applyShadows()
    pcall(function()
        if S.shadows == 'reduced' then CascadeShadowsSetCascadeBoundsScale(0.4) CascadeShadowsEnableEntityTracker(false)
        elseif S.shadows == 'sharp' then CascadeShadowsSetCascadeBoundsScale(1.0) CascadeShadowsEnableEntityTracker(true)
        else CascadeShadowsSetCascadeBoundsScale(1.0) CascadeShadowsEnableEntityTracker(false) end
    end)
end
local function applyVoice()
    pcall(function() exports['pma-voice']:setRadioVolume(math.max(0, math.min(100, S.radio_vol)) / 100.0) end)
    pcall(function() exports['pma-voice']:setCallVolume(math.max(0, math.min(100, S.call_vol)) / 100.0) end)
end
local function applyFoot() local m = FOOT[S.foot_view] if m then SetFollowPedCamViewMode(m) end end
local function applyAll() applyFilter() applyShadows() applyVoice() applyFoot() end

CreateThread(function()
    loadSet()
    Wait(4000)
    applyAll()
    local lastVeh = 0
    while true do
        -- par image seulement si un réglage l'exige ; sinon un coup d'œil toutes les 250 ms suffit (entrée dans un véhicule)
        Wait((S.no_cinematic or S.lod ~= 100) and 0 or 250)
        if S.no_cinematic then DisableControlAction(0, 80, true) end
        if S.lod ~= 100 then OverrideLodscaleThisFrame(math.max(0.5, math.min(2.0, S.lod / 100.0))) end
        -- à l'entrée dans un véhicule : vue et station de radio choisies
        local veh = GetVehiclePedIsIn(PlayerPedId(), false)
        if veh ~= lastVeh then
            lastVeh = veh
            if veh ~= 0 then
                local vm = VEH[S.veh_view]
                if vm then SetFollowVehicleCamViewMode(vm) end
                local st = RADIOS[S.radio_start]
                if st and GetPedInVehicleSeat(veh, -1) == PlayerPedId() then SetVehRadioStation(veh, st) end
            end
        end
    end
end)

-- Studio : caméra devant le personnage, ou devant une copie locale d'un véhicule (personne d'autre ne la voit) --------------------
local function stopStudio()
    if not studio then return end
    if studio.cam then RenderScriptCams(false, true, 400, true, false) DestroyCam(studio.cam, false) end
    if studio.veh and DoesEntityExist(studio.veh) then DeleteEntity(studio.veh) end
    studio = nil
end
local function placeCam()
    if not studio then return end
    local r, a = studio.radius, math.rad(studio.angle)
    local t = studio.target
    SetCamCoord(studio.cam, t.x + math.sin(a) * r, t.y + math.cos(a) * r, t.z + studio.up)
    PointCamAtCoord(studio.cam, t.x, t.y, t.z + studio.look)
end
local function startStudio(mode, model)
    stopStudio()
    local ped = PlayerPedId()
    local t, radius, up, look, veh
    if mode == 'veh' and type(model) == 'string' and model:match('^[%w_]+$') then
        local hash = GetHashKey(model)
        if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then G.send('notify', { type = 'warn', text = 'Modèle introuvable.' }) return end
        RequestModel(hash)
        local tm = GetGameTimer() + 4000
        while not HasModelLoaded(hash) and GetGameTimer() < tm do Wait(10) end
        if not HasModelLoaded(hash) then return end
        local fwd = GetEntityForwardVector(ped)
        local c = GetEntityCoords(ped)
        local x, y, z = c.x + fwd.x * 9.0, c.y + fwd.y * 9.0, c.z
        veh = CreateVehicle(hash, x, y, z, GetEntityHeading(ped) + 90.0, false, false)
        if not veh or veh == 0 then return end
        SetEntityCollision(veh, false, false) SetEntityInvincible(veh, true) FreezeEntityPosition(veh, true)
        SetVehicleOnGroundProperly(veh) SetVehicleDoorsLocked(veh, 2) SetModelAsNoLongerNeeded(hash)
        t = GetEntityCoords(veh)
        local mn, mx = GetModelDimensions(hash)
        radius, up, look = math.max(5.5, (mx.y - mn.y) * 1.5), 1.4, 0.4
    else
        t = GetPedBoneCoords(ped, 0x796E, 0.0, 0.0, 0.0)   -- tête
        radius, up, look = 2.3, 0.1, -0.35
        t = vector3(t.x, t.y, t.z - 0.1)
    end
    local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamFov(cam, 38.0)
    studio = { cam = cam, target = t, radius = radius, up = up, look = look, veh = veh, angle = mode == 'veh' and 200.0 or (GetEntityHeading(ped) * -1.0 + 0.0) }
    if mode ~= 'veh' then
        local f = GetEntityForwardVector(ped)
        studio.angle = math.deg(math.atan(f.x, f.y))
    end
    placeCam()
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 500, true, false)
end

-- Survol 3D : la caméra monte au-dessus du joueur puis rejoint le lieu choisi --------------------------------------------------------
local function stopFly()
    if not fly then return end
    RenderScriptCams(false, true, 700, true, false)
    if fly.cam then DestroyCam(fly.cam, false) end
    if fly.cam2 then DestroyCam(fly.cam2, false) end
    fly = nil
end
local function startFly(x, y, z)
    stopFly()
    local c = GetEntityCoords(PlayerPedId())
    local cam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', c.x, c.y, c.z + 60.0, -60.0, 0.0, 0.0, 60.0, false, 2)
    local cam2 = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', x, y - 90.0, (z or 30.0) + 140.0, -55.0, 0.0, 0.0, 60.0, false, 2)
    SetCamActive(cam, true)
    RenderScriptCams(true, false, 0, true, false)
    SetCamActiveWithInterp(cam2, cam, 5500, 1, 1)
    fly = { cam = cam, cam2 = cam2 }
    SetFocusPosAndVel(x, y, (z or 30.0) + 100.0, 0.0, 0.0, 0.0)
    CreateThread(function()
        local mine = fly
        Wait(5800)
        while fly == mine and fly do
            Wait(0)
            local r = GetCamRot(cam2, 2)
            SetCamRot(cam2, r.x, r.y, r.z + 0.04, 2)
        end
        ClearFocus()
    end)
end

-- Repères des lieux enregistrés sur la carte du jeu -----------------------------------------------------------------------------------------
local function setBlips(places)
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    for _, p in ipairs(places or {}) do
        local x, y = tonumber(p.x), tonumber(p.y)
        if x and y then
            local b = AddBlipForCoord(x + 0.0, y + 0.0, (tonumber(p.z) or 0.0) + 0.0)
            SetBlipSprite(b, p.shared and 162 or 126) SetBlipScale(b, 0.75) SetBlipColour(b, p.shared and 3 or 5) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label or 'Lieu')) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        end
    end
end

-- Ouverture / fermeture -----------------------------------------------------------------------------------------------------------------------
local function close()
    if not isOpen then return end
    isOpen = false
    stopStudio() stopFly()
    G.send('pause.close', {})
    G.focus(false)
    TriggerScreenblurFadeOut(300)
end
local function open()
    if isOpen or busy() or not G.begun or IsPauseMenuActive() then return end
    TriggerServerEvent('pb:g:pause:open')
end
RegisterNetEvent('pb:g:pause:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then return end
        isOpen = true
        G.focus(true)
        TriggerScreenblurFadeIn(300)
        if d.data then setBlips(d.data.places) end
        d.settings = S
        G.send('pause.open', d)
        return
    elseif not isOpen and d.ev ~= 'places' then return end
    if d.ev == 'places' then setBlips(d.places) end
    G.send('pause.' .. tostring(d.ev), d)
end)
RegisterNetEvent('pb:g:pause:gps', function(j)
    local d = G.decode(j)
    if d and tonumber(d.x) and tonumber(d.y) then
        SetNewWaypoint(d.x + 0.0, d.y + 0.0)
        G.send('notify', { type = 'success', text = 'GPS réglé sur : ' .. tostring(d.label or 'lieu') })
    end
end)

G.nui['pause.close'] = function() close() return {} end
G.nui['pause.tab'] = function(d)
    if d.tab ~= 'character' then stopStudio() end
    if d.tab ~= 'map' then stopFly() end
    return {}
end
G.nui['pause.studio'] = function(d)
    if not isOpen then return {} end
    if d.stop then stopStudio() else startStudio(d.mode == 'veh' and 'veh' or 'ped', d.model) end
    return {}
end
G.nui['pause.rot'] = function(d)
    if studio then studio.angle = studio.angle + math.max(-40, math.min(40, tonumber(d.dx) or 0)) * 0.6 placeCam() end
    return {}
end
G.nui['pause.fly'] = function(d)
    if not isOpen then return {} end
    if d.stop then stopFly() else startFly(tonumber(d.x) or 0.0, tonumber(d.y) or 0.0, tonumber(d.z) or 30.0) end
    return {}
end
G.nui['pause.gps'] = function(d) if isOpen and type(d.id) == 'string' then TriggerServerEvent('pb:g:pause:gps', d.id) end return {} end
G.nui['pause.gpsoff'] = function() SetWaypointOff() return {} end
G.nui['pause.shop'] = function() if isOpen then close() SetTimeout(250, function() ExecuteCommand('pb_shop') end) end return {} end
G.nui['pause.placeadd'] = function(d) if isOpen then TriggerServerEvent('pb:g:pause:place:add', tostring(d.label or '')) end return {} end
G.nui['pause.placedel'] = function(d) if isOpen and type(d.id) == 'string' then TriggerServerEvent('pb:g:pause:place:del', d.id) end return {} end
-- case « Paramètres » : le menu de GTA (paramètres du jeu)
G.nui['pause.gtamenu'] = function()
    close()
    SetTimeout(250, function() pcall(function() ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), false, -1) end) end)
    return {}
end
G.nui['pause.map2d'] = function()
    if G.AtlasOpen then close() SetTimeout(250, function() G.AtlasOpen() end) return {} end   -- carte du jeu + panneau de lieux à gauche
    close()
    CreateThread(function()
        Wait(350)
        pcall(function() ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), false, -1) end)
        Wait(300)
        pcall(function() PauseMenuceptionGoDeeper(0) end)
    end)
    return {}
end
G.nui['pause.set'] = function(d)
    if type(d.k) ~= 'string' or DEF[d.k] == nil or type(d.v) ~= type(DEF[d.k]) then return {} end
    local v = d.v
    if type(v) == 'number' then v = math.floor(math.max(0, math.min(200, v))) end
    if type(v) == 'string' and not v:match('^[%w_]+$') then return {} end
    S[d.k] = v
    saveSet()
    if d.k == 'filter' or d.k == 'filter_str' then applyFilter()
    elseif d.k == 'shadows' then applyShadows()
    elseif d.k == 'radio_vol' or d.k == 'call_vol' then applyVoice()
    elseif d.k == 'foot_view' then applyFoot() end
    return {}
end
G.nui['pause.setreset'] = function()
    for k, v in pairs(DEF) do S[k] = v end
    saveSet() applyAll()
    G.send('pause.settings', { settings = S })
    return {}
end

-- Échap : ouvre ce menu à la place de celui du jeu (la touche P garde le menu de pause du jeu)
RegisterCommand('menu', open, false)
G.frameHooks = G.frameHooks or {}
G.frameHooks[#G.frameHooks + 1] = function()
    local c = G.cfg.pause
    if not (c and c.enabled ~= false and c.replace_esc == true and G.begun) then return false end
    if busy() or IsPauseMenuActive() or G.qmapOpen then return false end   -- carte rapide ouverte : Échap y ouvre la carte plein écran
    DisableControlAction(0, 200, true)
    if IsDisabledControlJustReleased(0, 200) then open() end
    return true
end
-- touche P (carte du menu pause de GTA) : la carte du serveur à la place (réglage map_on_p, actif par défaut), même si Échap garde le menu du jeu
G.frameHooks[#G.frameHooks + 1] = function()
    local c = G.cfg.pause
    if not (c and c.map_on_p ~= false and G.begun and G.AtlasOpen) then return false end
    if busy() or IsPauseMenuActive() or G.qmapOpen then return false end
    DisableControlAction(0, 199, true)
    if IsDisabledControlJustReleased(0, 199) then G.AtlasOpen() end
    return true
end
CreateThread(function() while true do Wait(500) if isOpen and (G.state.dead or G.creating) then close() end end end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then stopStudio() stopFly() ClearTimecycleModifier() for _, b in ipairs(blips) do RemoveBlip(b) end end end)
G.onForceClose(function() close() end)
