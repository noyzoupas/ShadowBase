-- Tablette de l'entreprise / de l'organisation : s'ouvre au point du siège / QG (server/game/points.lua), même fenêtre que la banque
-- (web/game/hqtab.js). Les pages et les actions passent par les mêmes évènements que les menus (pb:g:biz:*, pb:g:orga:*) ;
-- client/pagesmenu.lua envoie ici tout ce qui concerne la tablette tant qu'elle est ouverte. Elle se ferme si on s'éloigne du point.
local G = PBG
local T = { kind = nil, at = nil }
G.HqTab = T
local EV = { biz = 'pb:g:biz', orga = 'pb:g:orga' }

function T.IsOpen(kind) return T.kind ~= nil and (kind == nil or T.kind == kind) end
function T.Close()
    if not T.kind then return end
    T.kind, T.at = nil, nil
    G.focus(false)
    G.send('hqtab.close', {})
end
function T.Open(kind, d)
    if G.creating or G.wardrobe or (G.state and G.state.dead) then return end
    if G.Menu.IsOpen() then G.Menu.Close() end
    T.kind, T.at = kind, GetEntityCoords(PlayerPedId())
    G.focus(true)
    d.kind = kind
    G.send('hqtab.open', d)
end
function T.Ui(d) if T.kind and (d.ev == 'page' or d.ev == 'result') then G.send('hqtab.' .. d.ev, d) end end

G.nui['hqtab.page'] = function(d) if T.kind then TriggerServerEvent(EV[T.kind] .. ':page', tostring(d.page or 'home')) end return {} end
G.nui['hqtab.act'] = function(d)
    if T.kind and type(d.name) == 'string' then TriggerServerEvent(EV[T.kind] .. ':act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end
    return {}
end
G.nui['hqtab.close'] = function() T.Close() return {} end

-- on s'éloigne du point (ou on meurt) : la tablette se ferme
CreateThread(function()
    while true do
        Wait(600)
        if T.kind then
            local c = GetEntityCoords(PlayerPedId())
            if (G.state and G.state.dead) or (T.at and #(c - T.at) > 8.0) then T.Close() end
        end
    end
end)
G.onForceClose(function() if T.kind then T.Close() end end)
