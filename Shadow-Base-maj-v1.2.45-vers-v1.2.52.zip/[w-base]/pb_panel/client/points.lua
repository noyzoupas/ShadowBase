-- Points d'entreprises et de gangs : blips sur la carte (selon ce que le serveur autorise) + marqueur et « E » pour les membres.
local G = PBG
local pts, blips = {}, {}
local LABEL = { hq = 'Bureau', duty = 'Prise de service', boss = 'Gestion', stash = 'Coffre', wardrobe = 'Vestiaire', garage = 'Garage', desk = 'Accueil', workshop = 'Atelier', kitchen = 'Préparer' }

-- Un client sonne à l'accueil : repère clignotant pendant 60 s sur la carte des employés en service
RegisterNetEvent('pb:g:points:ping', function(j)
    local d = G.decode(j)
    if not d or not tonumber(d.x) then return end
    local b = AddBlipForCoord(d.x + 0.0, d.y + 0.0, 0.0)
    SetBlipSprite(b, 280) SetBlipColour(b, 5) SetBlipScale(b, 0.9) SetBlipFlashes(b, true)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Client : ' .. tostring(d.label or 'accueil')) EndTextCommandSetBlipName(b)
    SetTimeout(60000, function() if DoesBlipExist(b) then RemoveBlip(b) end end)
end)

-- Icônes : coffre = radar_nhp_chest (587) en dégradé animé aux couleurs du serveur ; QG de gang = radar_bat_cargo (615)
local CHEST, GANG_HQ = 587, 615
-- icônes des points de mon entreprise / organisation (repères roses) : sprites déjà utilisés ailleurs dans le panel
local MINE_SPRITE = { stash = CHEST, garage = 357, wardrobe = 73, workshop = 446, kitchen = 93 }
local pointChests = {}     -- coffres de gang / d'entreprise (points) ; les coffres de l'inventaire sont dans stashBlips
local stashBlips = {}
local function addChest(x, y, z, label)
    local b = AddBlipForCoord(x + 0.0, y + 0.0, z + 0.0)
    SetBlipSprite(b, CHEST) SetBlipScale(b, 0.7) SetBlipAsShortRange(b, true)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(label ~= '' and label or 'Coffre')) EndTextCommandSetBlipName(b)
    return b
end
local function rgb(hex, d) hex = tostring(hex or d):gsub('#', '') return tonumber(hex:sub(1, 2), 16) or 223, tonumber(hex:sub(3, 4), 16) or 226, tonumber(hex:sub(5, 6), 16) or 231 end
-- couleur personnalisée 0xRRGGBBAA (acceptée par SetBlipColour en plus des couleurs numérotées du jeu)
CreateThread(function()
    local t = 0
    while true do
        if #pointChests + #stashBlips > 0 then
            local brand = G.cfg and G.cfg.brand or {}
            local r1, g1, b1 = rgb(brand.color, '#dfe2e7')
            local r2, g2, b2 = rgb(brand.color2, '#8e95a1')
            t = t + 0.08
            local k = (math.sin(t) + 1) / 2
            local r, g, b = math.floor(r1 + (r2 - r1) * k), math.floor(g1 + (g2 - g1) * k), math.floor(b1 + (b2 - b1) * k)
            local col = (r << 24) | (g << 16) | (b << 8) | 0xFF
            for _, list in ipairs({ pointChests, stashBlips }) do for _, bl in ipairs(list) do if DoesBlipExist(bl) then SetBlipColour(bl, col) end end end
            Wait(160)   -- dégradé lent : inutile de recolorier plus souvent
        else Wait(1000) end
    end
end)

-- Coffres de l'inventaire (publics pour tous, d'entreprise pour ses employés)
local stashList, stashJob = {}, nil
local function rebuildStashes()
    for _, b in ipairs(stashBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    stashBlips = {}
    local job = G.job and G.job.biz or nil
    stashJob = job
    for _, s in ipairs(stashList) do
        if not s.biz or s.biz == job then stashBlips[#stashBlips + 1] = addChest(s.x, s.y, s.z, s.label) end
    end
end
function G.SetStashBlips(list) stashList = list or {} rebuildStashes() end
CreateThread(function() while true do Wait(5000) if (G.job and G.job.biz or nil) ~= stashJob then rebuildStashes() end end end)

-- Siège des entreprises : vert si au moins un employé est en service, rouge sinon (réglage « open_blips »)
local openMap, openOn, bizBlips = {}, true, {}
local function applyOpen()
    for b, d in pairs(bizBlips) do
        if DoesBlipExist(b) then
            if openOn then
                local open = openMap[d.owner] == true
                SetBlipColour(b, open and 2 or 1)   -- vert ouvert, rouge fermé ; le nom reste celui de l'entreprise
            else
                SetBlipColour(b, d.bc or 0)
                BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(d.label) EndTextCommandSetBlipName(b)
            end
        else bizBlips[b] = nil end
    end
end
RegisterNetEvent('pb:g:bizopen', function(j)
    local d = G.decode(j)
    if not d then return end
    openMap, openOn = d.open or {}, d.on ~= false
    G.bizOpen = openMap
    applyOpen()
end)
local function rebuild()
    bizBlips = {}
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    pointChests = {}
    for _, p in ipairs(pts) do
        if p.kind == 'area' then   -- zone d'un groupe illégal (visible de tous) : cercle à sa couleur + nom
            local col = G.blipColourFor and G.blipColourFor(p.col) or 1
            local a = AddBlipForRadius(p.x + 0.0, p.y + 0.0, p.z + 0.0, (tonumber(p.r) or 90) + 0.0)
            SetBlipColour(a, col) SetBlipAlpha(a, 80)
            blips[#blips + 1] = a
            local c = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(c, 437) SetBlipColour(c, col) SetBlipScale(c, 0.65) SetBlipAsShortRange(c, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label)) EndTextCommandSetBlipName(c)
            blips[#blips + 1] = c
        elseif p.mine then
            -- (v1.2.45) point de mon entreprise / organisation : repère rose, visible de ses membres seulement (siège, tablette, coffre, garage…)
            local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, MINE_SPRITE[p.kind] or ((p.kind == 'hq' and (p.bsp or 0) > 0) and p.bsp) or 1)
            SetBlipColour(b, 8) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.nm or (p.label ~= '' and p.label) or 'Point')) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        elseif p.kind == 'stash' and (p.use or (p.sp or 0) > 0) then
            local b = addChest(p.x, p.y, p.z, p.label)
            blips[#blips + 1] = b
            pointChests[#pointChests + 1] = b
        elseif (p.sp or 0) > 0 then
            local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, (p.og and p.kind == 'hq' and (p.sp == 84 or p.sp == GANG_HQ)) and GANG_HQ or p.sp)   -- QG de gang : 615 par défaut, sinon l'icône choisie au Builder
            SetBlipColour(b, p.bc or 0) SetBlipScale(b, (p.sc or 0.8) + 0.0) SetBlipAsShortRange(b, true)
            local name = tostring(p.nm or (p.label ~= '' and p.label) or 'Point')
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(name) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
            if p.ob then bizBlips[b] = { owner = p.ob, label = name, bc = p.bc or 0 } end
        end
    end
    applyOpen()
end

RegisterNetEvent('pb:g:points', function(j)
    pts = G.decode(j) or {}
    rebuild()
end)

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    local cand, nextScan = {}, 0   -- points utilisables à moins de 40 m, recalculés toutes les 0,5 s (pas toute la liste à chaque image)
    while true do
        local sleep = 800
        if #pts > 0 and (G.locked or 0) == 0 then
            local c = GetEntityCoords(PlayerPedId())
            local now = GetGameTimer()
            if now >= nextScan then
                nextScan = now + 500
                cand = {}
                for _, p in ipairs(pts) do
                    if p.use and (p.kind ~= 'stash' or p.og) and p.kind ~= 'garage' and #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) < 40.0 then cand[#cand + 1] = p end
                end
            end
            if #cand == 0 then sleep = 500 end
            local near
            for _, p in ipairs(cand) do
                do
                    local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0))
                    if d < 25.0 then
                        sleep = 0
                        G.Point(p.x + 0.0, p.y + 0.0, p.z - 0.95, 255, 255, 255, 1.0)
                        if d < (p.r or 2.0) and (not near or d < near.d) then near = { p = p, d = d } end
                    end
                end
            end
            if near and not (G.Menu and G.Menu.IsOpen and G.Menu.IsOpen()) then
                if shown ~= near.p.id then shown = near.p.id G.send('prompt', { show = true, key = 'E', text = LABEL[near.p.kind] or 'Utiliser' }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:points:use', near.p.id) end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

