-- Repos après une réapparition (server/game/ata.lua) : arme rangée, pas de tir, pas de course ni de saut, temps restant affiché.
local G = PBG
local endAt = 0
RegisterNetEvent('pb:g:ata', function(j)
    local d = G.decode(j) or {}
    local left = tonumber(d.left) or 0
    endAt = left > 0 and (GetGameTimer() + left * 1000) or 0
    if left > 0 then SetCurrentPedWeapon(PlayerPedId(), GetHashKey('WEAPON_UNARMED'), true) end
end)
local function txt(s, y, scale, a)
    SetTextFont(4) SetTextScale(0.0, scale) SetTextColour(255, 255, 255, a or 230) SetTextCentre(true) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(s) EndTextCommandDisplayText(0.5, y)
end
CreateThread(function()
    while true do
        local left = endAt > 0 and math.floor((endAt - GetGameTimer()) / 1000) or 0
        if left > 0 and G.begun and not (G.state and G.state.dead) then
            Wait(0)
            local ped = PlayerPedId()
            DisablePlayerFiring(PlayerId(), true)
            for _, c in ipairs({ 24, 25, 37, 45, 47, 58, 140, 141, 142, 143, 257, 263, 264, 21, 22 }) do DisableControlAction(0, c, true) end
            if GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_UNARMED') then SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true) end
            txt(('REPOS  ·  %d:%02d  ·  ni arme, ni course'):format(math.floor(left / 60), left % 60), 0.94, 0.36, 210)
        else
            if endAt > 0 and left <= 0 then endAt = 0 G.send('notify', { type = 'success', title = 'Repos', text = 'Tu es remis : armes et course à nouveau possibles.' }) end
            Wait(500)
        end
    end
end)
