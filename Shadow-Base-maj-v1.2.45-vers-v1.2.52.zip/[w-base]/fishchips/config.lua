Config = {}

Config.Business = 'fishchips'          -- identifiant de l'entreprise dans Shadow Base (catalogue : Restauration)
-- (v1.2.45) modèle réutilisable : copie le dossier, change ces lignes et la carte, et tu as un autre restaurant identique (sans livraison si tu veux)
Config.Name = 'Fish & Chips'           -- nom affiché (bornes, cuisine, notifications)
Config.EventPrefix = 'fc'             -- préfixe des évènements : différent pour chaque copie
Config.ItemPrefix = 'fc_'             -- préfixe des objets de l'inventaire : différent pour chaque copie
Config.BuilderId = 'fishchips'       -- identifiant au Builder du menu staff
Config.PlaceCommand = 'fcplace'       -- commande de placement des points
Config.Delivery = false                -- false : pas de livraison (ni à la borne, ni commandes de PNJ)
Config.ImageBase = 'https://cfx-nui-pb_panel/web/img/'   -- images de Shadow Base (servies par pb_panel)

--[[
  Carte. Les prix se règlent aussi dans le panel (Serveur > Burger Shot).
  stations : postes de cuisine nécessaires (grill, fryer, drinks, dessert, assembly)
  hunger / thirst / stress : effets quand on consomme l'objet (inventaire Shadow Base, objet « bs_<id> »)
]]
Config.Categories = {
  { id = 'menus', label = 'Menus', emoji = '🍱' },
  { id = 'burgers', label = 'Poissons', emoji = '🐟' },
  { id = 'sides', label = 'Accompagnements', emoji = '🍟' },
  { id = 'drinks', label = 'Boissons', emoji = '🥤' },
  { id = 'desserts', label = 'Desserts', emoji = '🍩' },
}

Config.Items = {
  fishchips   = { cat = 'burgers', label = 'Fish & Chips', price = 13, kcal = 840, emoji = '🐟', img = 'items/_food.svg', stations = { 'fryer', 'assembly' }, hunger = 65, thirst = -5, desc = 'Filet de cabillaud en pâte à bière, frites épaisses, citron.' },
  fishburger  = { cat = 'burgers', label = 'Burger de poisson', price = 10, kcal = 620, emoji = '🍔', img = 'ox/burger.png', stations = { 'fryer', 'assembly' }, hunger = 48, thirst = -4, desc = 'Poisson pané, sauce tartare, salade.' },
  fishfillet  = { cat = 'burgers', label = 'Filet pané', price = 8, kcal = 420, emoji = '🐟', img = 'items/_food.svg', stations = { 'fryer' }, hunger = 35, thirst = -3, desc = 'Filet de poisson pané, croustillant.' },
  chips       = { cat = 'sides', label = 'Cornet de frites', price = 4, kcal = 380, emoji = '🍟', img = 'ox/fries.png', stations = { 'fryer' }, hunger = 22, thirst = -5, desc = 'Frites épaisses à l’anglaise, sel et vinaigre.' },
  peas        = { cat = 'sides', label = 'Purée de petits pois', price = 3, kcal = 150, emoji = '🟢', img = 'items/_snack.svg', stations = { 'assembly' }, hunger = 15, desc = 'Mushy peas, comme à Londres.' },
  rings       = { cat = 'sides', label = 'Calamars frits', price = 6, kcal = 330, emoji = '🦑', img = 'items/_snack.svg', stations = { 'fryer' }, hunger = 22, thirst = -3, desc = 'Anneaux de calamar, sauce tartare.' },
  tea         = { cat = 'drinks', label = 'Thé', price = 3, kcal = 5, emoji = '🍵', img = 'items/coffee.svg', stations = { 'drinks' }, thirst = 25, stress = -5, desc = 'Thé noir, un nuage de lait.' },
  ecola       = { cat = 'drinks', label = 'eCola', price = 3, kcal = 160, emoji = '🥤', img = 'items/soda.svg', stations = { 'drinks' }, thirst = 35, desc = 'Le cola original de Los Santos.' },
  water       = { cat = 'drinks', label = 'Eau minérale', price = 2, kcal = 0, emoji = '💧', img = 'ox/water.png', stations = { 'drinks' }, thirst = 40, desc = 'Fraîche et plate.' },
  pudding     = { cat = 'desserts', label = 'Sticky toffee pudding', price = 5, kcal = 450, emoji = '🍮', img = 'items/_snack.svg', stations = { 'dessert' }, hunger = 18, stress = -5, desc = 'Gâteau aux dattes, sauce caramel.' },
}

-- Menus : contenu fixe + une boisson au choix
Config.Menus = {
  menu_fish   = { label = 'Menu Fish & Chips', price = 17, emoji = '🍱', img = 'items/_food.svg', contents = { 'fishchips', 'peas' }, choice = { 'tea', 'ecola', 'water' }, desc = 'Fish & Chips + petits pois + boisson.' },
  menu_burger = { label = 'Menu Burger de poisson', price = 14, emoji = '🍔', img = 'ox/burger.png', contents = { 'fishburger', 'chips' }, choice = { 'tea', 'ecola', 'water' }, desc = 'Burger de poisson + frites + boisson.' },
}

-- Postes de cuisine : mini-jeu, animation et accessoire
Config.Stations = {
  grill    = { label = 'Grill', game = 'flip', verb = 'Cuire', scenario = 'PROP_HUMAN_BBQ' },
  fryer    = { label = 'Friteuse', game = 'fry', verb = 'Frire', anim = { 'mini@repair', 'fixing_a_ped' } },
  drinks   = { label = 'Fontaine à boissons', game = 'fill', verb = 'Servir', anim = { 'mini@repair', 'fixing_a_ped' } },
  dessert  = { label = 'Desserts', game = 'timing', verb = 'Garnir', anim = { 'mini@repair', 'fixing_a_ped' } },
  assembly = { label = 'Montage', game = 'combo', verb = 'Monter', anim = { 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', 'machinic_loop_mechandplayer' } },
}
Config.StationOrder = { 'grill', 'fryer', 'drinks', 'dessert', 'assembly' }

Config.MaxUnits = 20             -- articles maximum par commande
Config.KioskDistance = 3.0
Config.StationDistance = 2.5
Config.HandDistance = 3.0
Config.BagProp = 'prop_paper_bag_small'
Config.DeliveryVehicles = { 'faggio', 'faggio2' }
Config.NpcModels = { 'a_m_y_hipster_01', 'a_f_y_hipster_02', 'a_m_m_business_01', 'a_f_y_business_02', 'a_m_y_skater_01', 'a_f_m_tourist_01', 'a_m_y_vinewood_01', 'a_f_y_genhot_01' }

--[[
  Points par défaut, autour du Burger Shot de Del Perro (siège Shadow Base -1192, -884).
  À placer précisément en jeu avec /bsplace (sauvegardé dans data/points.json), surtout avec un intérieur (MLO).
]]
Config.DefaultPoints = { kiosks = {}, addresses = {} }   -- à poser en jeu : F10 › Builder › Fish & Chips (ou /fcplace)
