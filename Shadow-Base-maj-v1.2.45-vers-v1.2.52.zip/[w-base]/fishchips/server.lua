-- Burger Shot : commandes, paiement, cuisine, remise et livraison. Le serveur décide de tout (prix, distances, droits, argent) ;
local EVP = Config.EventPrefix or 'bs'                      -- préfixe des évènements (une copie = un autre préfixe)
local NAME = Config.Name or 'Burger Shot'                   -- nom affiché du restaurant
-- le client n'envoie que des intentions. S'appuie sur Shadow Base (pb_panel) : métier, service, inventaire, argent et caisse d'entreprise.

local PB = exports.pb_panel
local BIZ = Config.Business
local Orders, Seq = {}, 100
local Points = {}
local lastAct = {}             -- anti-spam : src -> ms
local pendingRefund = {}       -- license -> { { account, amount, label } }
local games = {}               -- src -> { oid, station, token, at }
local stats = {}               -- src -> { orders, earned }

-- Réglages (panel Shadow Base > Burger Shot) --------------------------------------------------------------------------------------------
local DEF = { enabled = true, auto_kitchen = true, auto_prep_secs = 60, commission = 15, delivery_fee = 25, delivery_share = 100, npc_orders = true, npc_every = 4, npc_max = 3,
  price_pct = 100, prices = {}, disabled = {}, order_timeout = 25, difficulty = 'normal', manager_grade = 1 }
local function S()
  local ok, c = pcall(function() return PB:GetBurgerShotSettings() end)
  local out = {}
  for k, v in pairs(DEF) do out[k] = (ok and type(c) == 'table' and c[k] ~= nil) and c[k] or v end
  return out
end

local function now() return os.time() end
local function ms() return GetGameTimer() end
-- anti-spam par joueur et par action (ouvrir la carte puis commander aussitôt reste possible)
local function throttle(src, key, gap)
  key = src .. ':' .. key
  local t = ms()
  if lastAct[key] and t - lastAct[key] < (gap or 400) then return false end
  lastAct[key] = t
  return true
end
local function notify(src, kind, text, title) pcall(function() PB:Notify(src, { type = kind, title = title or (NAME), text = text }) end) end
local function license(src) return GetPlayerIdentifierByType(src, 'license') end
local function nameOf(src)
  local ok, id = pcall(function() return PB:GetIdentity(src) end)
  if ok and type(id) == 'table' and (id.firstname or '') ~= '' then return (id.firstname .. ' ' .. (id.lastname or '')):sub(1, 40) end
  return GetPlayerName(src) or ('Client ' .. src)
end
local function coords(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function near(src, p, d)
  local c = coords(src)
  if not c or type(p) ~= 'table' then return false end
  return #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) <= (d or 3.0) + 1.0   -- marge réseau
end
local function onDuty(src) local ok, r = pcall(function() return PB:IsOnDuty(src, BIZ) end) return ok and r == true end
local function job(src) local ok, j = pcall(function() return PB:GetJob(src) end) return ok and type(j) == 'table' and j.biz == BIZ and j or nil end
local function isManager(src) local j = job(src) return j ~= nil and (j.boss or (tonumber(j.grade) or 0) >= (tonumber(S().manager_grade) or 1)) end
local function staffOnDuty()
  local out = {}
  for _, id in ipairs(GetPlayers()) do id = tonumber(id) if onDuty(id) then out[#out + 1] = id end end
  return out
end
local function bizMoney(delta, reason) if delta ~= 0 then pcall(function() PB:AddBusinessMoney(BIZ, math.floor(delta), reason) end) end end
local function payBank(src, amount, reason) if amount > 0 then pcall(function() PB:AddMoney(src, 'bank', math.floor(amount), reason) end) end end

-- Points (placés en jeu avec /bsplace) ---------------------------------------------------------------------------------------------
local function savePoints() SaveResourceFile(GetCurrentResourceName(), 'data/points.json', json.encode(Points), -1) end
local function loadPoints()
  local raw = LoadResourceFile(GetCurrentResourceName(), 'data/points.json')
  local ok, t = pcall(json.decode, raw or '')
  Points = (ok and type(t) == 'table') and t or json.decode(json.encode(Config.DefaultPoints))
  for k, v in pairs(Config.DefaultPoints) do if Points[k] == nil then Points[k] = v end end
end

-- Carte et prix -----------------------------------------------------------------------------------------------------------------
local function priceOverrides(s)
  local o = {}
  for _, line in ipairs(s.prices or {}) do local id, p = tostring(line):match('^([%w_]+)|(%d+)$') if id then o[id] = tonumber(p) end end
  return o
end
local function disabledSet(s) local d = {} for _, id in ipairs(s.disabled or {}) do d[tostring(id)] = true end return d end
local function def(id) return Config.Items[id] or Config.Menus[id] end
local function priceOf(id, s, o)
  local d = def(id)
  if not d then return nil end
  local base = o[id] or d.price
  return math.max(1, math.floor(base * (tonumber(s.price_pct) or 100) / 100 + 0.5))
end
local function catalog(s)
  local o, off, list = priceOverrides(s), disabledSet(s), {}
  local function add(id, d, isMenu)
    if off[id] then return end
    local contents
    if isMenu then contents = {} for _, c in ipairs(d.contents) do contents[#contents + 1] = Config.Items[c].label end end
    local choice
    if d.choice then choice = {} for _, c in ipairs(d.choice) do if not off[c] then choice[#choice + 1] = { id = c, label = Config.Items[c].label, emoji = Config.Items[c].emoji } end end end
    -- photos détourées (png) sur la borne ; les icônes de Shadow Base (svg sur tuile sombre) laissent la place à l'émoji
    local img = d.img and d.img:match('%.png$') and (Config.ImageBase .. d.img) or nil
    list[#list + 1] = { id = id, cat = isMenu and 'menus' or d.cat, label = d.label, price = priceOf(id, s, o), kcal = d.kcal, emoji = d.emoji, img = img,
      desc = d.desc, contents = contents, choice = choice }
  end
  for id, d in pairs(Config.Menus) do add(id, d, true) end
  for id, d in pairs(Config.Items) do add(id, d, false) end
  table.sort(list, function(a, b) if a.cat ~= b.cat then return a.cat < b.cat end return a.price < b.price end)
  return list
end

-- Commandes ----------------------------------------------------------------------------------------------------------------------
--[[ o = { id, src, license, name, npc, lines, units = { item = qty }, stations = { station = { need, done, score } }, subtotal, fee, total, pay, mode,
         state = paid|cooking|cooked|ready|counter|auto|done|cancelled, cook, carrier, packer, created, readyAt, address, quality } ]]
local function expand(lines, s)
  local o, off = priceOverrides(s), disabledSet(s)
  local units, subtotal, count, clean = {}, 0, 0, {}
  for _, l in ipairs(type(lines) == 'table' and lines or {}) do
    local id, qty = tostring(l.id or ''), math.floor(tonumber(l.qty) or 0)
    local d = def(id)
    if not d or off[id] or qty < 1 or qty > 10 then return nil, 'Article indisponible.' end
    local menu = Config.Menus[id]
    local parts = {}
    if menu then
      for _, c in ipairs(menu.contents) do parts[#parts + 1] = c end
      local ch = tostring(l.choice or menu.choice[1])
      local okc = false
      for _, c in ipairs(menu.choice) do if c == ch and not off[c] then okc = true end end
      if not okc then return nil, 'Boisson du menu indisponible.' end
      parts[#parts + 1] = ch
    else parts[1] = id end
    for _, p in ipairs(parts) do units[p] = (units[p] or 0) + qty count = count + qty end
    subtotal = subtotal + priceOf(id, s, o) * qty
    clean[#clean + 1] = { id = id, qty = qty, label = d.label, choice = menu and Config.Items[parts[#parts]].label or nil }
  end
  if count == 0 then return nil, 'Ton panier est vide.' end
  if count > Config.MaxUnits then return nil, ('%d articles maximum par commande.'):format(Config.MaxUnits) end
  return { units = units, subtotal = subtotal, lines = clean, count = count }
end
local function stationsFor(units)
  local st = {}
  for item, qty in pairs(units) do
    for _, s in ipairs(Config.Items[item].stations) do st[s] = st[s] or { need = 0, done = false, score = 0 } st[s].need = st[s].need + qty end
  end
  return st
end

local function publicOrder(o, forStaff)
  local st = {}
  for _, k in ipairs(Config.StationOrder) do local s = o.stations[k] if s then st[#st + 1] = { id = k, label = Config.Stations[k].label, need = s.need, done = s.done } end end
  local items = {}
  for item, qty in pairs(o.units) do items[#items + 1] = { label = Config.Items[item].label, emoji = Config.Items[item].emoji, qty = qty } end
  table.sort(items, function(a, b) return a.label < b.label end)
  return { id = o.id, name = o.name, npc = o.npc or nil, mode = o.mode, state = o.state, lines = o.lines, items = items, stations = st, total = o.total, age = now() - o.created,
    cook = o.cook and nameOf(o.cook) or nil, carrier = o.carrier and nameOf(o.carrier) or nil, mine = nil, address = o.address and o.address.label or nil,
    eta = o.readyAt and math.max(0, o.readyAt - now()) or nil, quality = o.quality, cookId = forStaff and o.cook or nil, carrierId = forStaff and o.carrier or nil }
end

local pushPending = false
local function pushStaff()
  if pushPending then return end
  pushPending = true
  SetTimeout(250, function()
    pushPending = false
    local list = {}
    for _, o in pairs(Orders) do if o.state ~= 'done' and o.state ~= 'cancelled' then list[#list + 1] = publicOrder(o, true) end end
    table.sort(list, function(a, b) return a.id < b.id end)
    local cooking, ready = {}, {}
    for _, o in ipairs(list) do if o.state == 'ready' or o.state == 'counter' then ready[#ready + 1] = o.id elseif not o.npc then cooking[#cooking + 1] = o.id end end
    for _, id in ipairs(staffOnDuty()) do TriggerClientEvent((EVP .. ':queue'), id, list, id, isManager(id)) end
    TriggerClientEvent((EVP .. ':board'), -1, cooking, ready)
  end)
end
local function pushCustomer(o)
  if o.npc or not o.src or not GetPlayerName(o.src) then return end
  TriggerClientEvent((EVP .. ':mine'), o.src, publicOrder(o, false))
end
local function changed(o) pushStaff() pushCustomer(o) end

local function refund(o, why)
  if o.state == 'done' or o.state == 'cancelled' then return end
  o.state = 'cancelled'
  if not o.npc then
    bizMoney(-o.total, ('Remboursement commande #%d'):format(o.id))
    if o.src and GetPlayerName(o.src) and license(o.src) == o.license then
      pcall(function() PB:AddMoney(o.src, o.pay, o.total, ((NAME .. ' : remboursement #%d')):format(o.id)) end)
      notify(o.src, 'warn', ('Commande #%d annulée (%s) : %d $ remboursés.'):format(o.id, why, o.total))
      TriggerClientEvent((EVP .. ':mine'), o.src, nil)
    else
      pendingRefund[o.license] = pendingRefund[o.license] or {}
      table.insert(pendingRefund[o.license], { account = o.pay, amount = o.total, label = ((NAME .. ' : remboursement #%d')):format(o.id) })
    end
  end
  if o.carrier then TriggerClientEvent((EVP .. ':carry'), o.carrier, nil) end
  Orders[o.id] = nil
  pushStaff()
end

local function complete(o, by)
  if o.state == 'done' then return end
  local s = S()
  o.state = 'done'
  -- articles remis au client (ce qui ne rentre pas dans le sac est signalé)
  if not o.npc then
    local missing = 0
    for item, qty in pairs(o.units) do
      local ok = false
      pcall(function() ok = PB:AddItem(o.src, (Config.ItemPrefix or 'bs_') .. item, qty) end)
      if not ok then missing = missing + qty end
    end
    if missing > 0 then notify(o.src, 'warn', ('Ton sac est plein : %d article(s) n’ont pas pu être rangés.'):format(missing)) end
  else
    bizMoney(o.total, ('Livraison #%d (%s)'):format(o.id, o.address and o.address.label or 'client'))
  end
  -- primes : l'équipier qui remet la commande touche la commission, le livreur les frais de livraison
  local worker = by or o.packer
  if worker and GetPlayerName(worker) then
    local bonus = math.floor(o.subtotal * (tonumber(s.commission) or 0) / 100)
    local fee = (o.mode == 'delivery') and math.floor(o.fee * (tonumber(s.delivery_share) or 100) / 100) or 0
    if bonus + fee > 0 then
      bizMoney(-(bonus + fee), ('Prime commande #%d'):format(o.id))
      payBank(worker, bonus + fee, ((NAME .. ' : prime commande #%d')):format(o.id))
    end
    stats[worker] = stats[worker] or { orders = 0, earned = 0 }
    stats[worker].orders, stats[worker].earned = stats[worker].orders + 1, stats[worker].earned + bonus + fee
    notify(worker, 'success', ('Commande #%d remise%s. Prime : %d $.'):format(o.id, o.npc and (' à ' .. (o.address and o.address.label or 'un client')) or '', bonus + fee))
  end
  if not o.npc then
    TriggerClientEvent((EVP .. ':mine'), o.src, nil)
    TriggerClientEvent((EVP .. ':rate'), o.src, o.id, worker and nameOf(worker) or (NAME), o.quality or 80)
    o.rateBy, o.rateUntil = worker, now() + 90
  end
  if o.carrier then TriggerClientEvent((EVP .. ':carry'), o.carrier, nil) end
  o.carrier = nil
  -- on garde la commande 90 s pour le pourboire puis on l'oublie
  SetTimeout(95000, function() if Orders[o.id] == o then Orders[o.id] = nil end end)
  pushStaff()
end

local function newOrder(t)
  Seq = Seq + 1
  if Seq > 999 then Seq = 101 end
  t.id, t.created = Seq, now()
  t.stations = stationsFor(t.units)
  Orders[t.id] = t
  return t
end

-- Borne : carte et commande ------------------------------------------------------------------------------------------------------
local function nearKiosk(src) for _, k in ipairs(Points.kiosks or {}) do if near(src, k, Config.KioskDistance) then return true end end return false end
local function isOpen(s) return s.enabled ~= false and (#staffOnDuty() > 0 or s.auto_kitchen ~= false) end

RegisterNetEvent((EVP .. ':catalog'), function()
  local src = source
  if not throttle(src, 'catalog', 300) then return end
  local s = S()
  local cash, bank = 0, 0
  pcall(function() cash, bank = PB:GetMoney(src, 'cash'), PB:GetMoney(src, 'bank') end)
  TriggerClientEvent((EVP .. ':catalog'), src, { items = catalog(s), categories = Config.Categories, open = isOpen(s), staff = #staffOnDuty(), auto = s.auto_kitchen ~= false,
    fee = tonumber(s.delivery_fee) or 0, cash = cash, bank = bank, name = nameOf(src), brand = NAME, nodelivery = Config.Delivery == false })
end)

RegisterNetEvent((EVP .. ':order'), function(data)
  local src = source
  if not throttle(src, 'order', 1500) then return end
  local function fail(msg) TriggerClientEvent((EVP .. ':orderResult'), src, { ok = false, msg = msg }) end
  if type(data) ~= 'table' then return fail('Commande invalide.') end
  if not nearKiosk(src) then return fail('Approche-toi de la borne.') end
  local s = S()
  if not isOpen(s) then return fail(('Le ' .. NAME .. ' est fermé : aucun équipier en service.')) end
  local lic = license(src)
  for _, o in pairs(Orders) do if o.license == lic and o.state ~= 'done' and o.state ~= 'cancelled' then return fail(('Tu as déjà une commande en cours (#%d).'):format(o.id)) end end
  local e, err = expand(data.lines, s)
  if not e then return fail(err) end
  local mode = (data.mode == 'delivery' and Config.Delivery ~= false) and 'delivery' or 'counter'   -- sans livraison : toujours sur place
  local staff = #staffOnDuty()
  if mode == 'delivery' and staff == 0 then return fail('Livraison impossible sans équipier en service.') end
  local pay = data.pay == 'bank' and 'bank' or 'cash'
  local fee = mode == 'delivery' and math.floor(tonumber(s.delivery_fee) or 0) or 0
  local total = e.subtotal + fee
  local paid = false
  pcall(function() paid = PB:RemoveMoney(src, pay, total, (NAME .. ' : commande')) end)
  if not paid then return fail(pay == 'bank' and 'Paiement refusé : solde bancaire insuffisant.' or 'Pas assez d’espèces sur toi.') end
  bizMoney(total, ('Ventes ' .. NAME))
  local o = newOrder({ src = src, license = lic, name = nameOf(src), units = e.units, lines = e.lines, subtotal = e.subtotal, fee = fee, total = total, pay = pay, mode = mode, state = 'paid' })
  if staff == 0 then
    o.state = 'auto'
    o.readyAt = now() + math.floor(tonumber(s.auto_prep_secs) or 60) + e.count * 4
    o.quality = 75
  else
    for _, id in ipairs(staffOnDuty()) do
      TriggerClientEvent((EVP .. ':ding'), id, o.id, o.name, mode)
    end
  end
  TriggerClientEvent((EVP .. ':orderResult'), src, { ok = true, order = publicOrder(o, false) })
  changed(o)
end)

-- Cuisine : écran, prise en charge, postes, emballage ----------------------------------------------------------------------------------
local function staffGuard(src) if not onDuty(src) then notify(src, 'error', ('Tu dois être en service au ' .. NAME .. '.')) return false end return true end
local function assigned(src) for _, o in pairs(Orders) do if o.cook == src and (o.state == 'cooking' or o.state == 'cooked') then return o end end end

RegisterNetEvent((EVP .. ':kds'), function()
  local src = source
  if not throttle(src, 'kds', 300) or not staffGuard(src) then return end
  local st = stats[src] or { orders = 0, earned = 0 }
  local bal = 0
  pcall(function() bal = PB:GetBusinessBalance(BIZ) end)
  TriggerClientEvent((EVP .. ':kdsOpen'), src, { stats = st, balance = isManager(src) and bal or nil })
  pushStaff()
end)

RegisterNetEvent((EVP .. ':take'), function(oid)
  local src = source
  if not throttle(src, 'take') or not staffGuard(src) then return end
  local o = Orders[math.floor(tonumber(oid) or 0)]
  if not o or o.state ~= 'paid' then notify(src, 'warn', 'Cette commande est déjà prise.') return end
  local cur = assigned(src)
  if cur then notify(src, 'warn', ('Termine d’abord la commande #%d.'):format(cur.id)) return end
  o.cook, o.state, o.startedAt = src, 'cooking', now()
  notify(src, 'info', ('Commande #%d pour toi. Passe aux postes indiqués.'):format(o.id))
  if not o.npc then notify(o.src, 'info', ('Ta commande #%d est en cuisine (%s).'):format(o.id, nameOf(src))) end
  TriggerClientEvent((EVP .. ':work'), src, publicOrder(o, true))
  changed(o)
end)

local DIFF = { easy = 0.75, normal = 1.0, hard = 1.3 }
RegisterNetEvent((EVP .. ':station'), function(station)
  local src = source
  if not throttle(src, 'station') or not staffGuard(src) then return end
  station = tostring(station)
  local cfg = Config.Stations[station]
  if not cfg or not near(src, Points[station], Config.StationDistance) then return end
  local o = assigned(src)
  if not o then notify(src, 'warn', 'Prends une commande sur l’écran de cuisine.') return end
  local st = o.stations[station]
  if not st or st.done then
    if station == 'assembly' then
      -- tout est prêt : emballage
      for _, x in pairs(o.stations) do if not x.done then notify(src, 'warn', 'Il reste des postes à faire avant d’emballer.') return end end
      local sum, n = 0, 0
      for _, x in pairs(o.stations) do sum, n = sum + x.score, n + 1 end
      o.quality = n > 0 and math.floor(sum / n) or 80
      o.state, o.packer, o.carrier, o.readyAt = 'ready', src, src, now()
      TriggerClientEvent((EVP .. ':carry'), src, { id = o.id, npc = o.npc and true or false, mode = o.mode, name = o.name, address = o.address, customer = (not o.npc) and o.src or nil })
      if not o.npc then notify(o.src, 'success', ('Commande #%d prête ! %s te l’apporte.'):format(o.id, nameOf(src))) end
      changed(o)
      return
    end
    notify(src, 'info', ('Rien à faire ici pour la commande #%d.'):format(o.id))
    return
  end
  local token = tostring(math.random(100000, 999999))
  games[src] = { oid = o.id, station = station, token = token, at = ms() }
  TriggerClientEvent((EVP .. ':game'), src, { oid = o.id, station = station, label = cfg.label, verb = cfg.verb, game = cfg.game, count = st.need, difficulty = DIFF[S().difficulty] or 1.0, token = token })
end)

RegisterNetEvent((EVP .. ':gameDone'), function(token, score)
  local src = source
  local g = games[src]
  if not g or g.token ~= tostring(token) then return end   -- un mauvais jeton n'annule pas la partie en cours
  games[src] = nil
  local o = Orders[g.oid]
  if not o or o.cook ~= src then return end
  if ms() - g.at < 2500 then notify(src, 'error', 'Trop rapide pour être honnête.') return end   -- un mini-jeu dure plusieurs secondes
  if not near(src, Points[g.station], Config.StationDistance) then return end
  score = math.max(0, math.min(100, math.floor(tonumber(score) or 0)))
  local st = o.stations[g.station]
  if score < 35 then notify(src, 'warn', ('%s raté (%d %%) : recommence.'):format(Config.Stations[g.station].label, score)) return end
  st.done, st.score = true, score
  local left = 0
  for _, x in pairs(o.stations) do if not x.done then left = left + 1 end end
  o.state = left == 0 and 'cooked' or 'cooking'
  notify(src, 'success', left == 0 and ('Tout est prêt : emballe la commande #%d au poste Montage.'):format(o.id)
    or ('%s : %d %%. Encore %d poste(s).'):format(Config.Stations[g.station].label, score, left))
  TriggerClientEvent((EVP .. ':work'), src, publicOrder(o, true))
  changed(o)
end)

-- Remise : en main propre, au comptoir, ou au PNJ ------------------------------------------------------------------------------------
local function carried(src, oid) local o = Orders[math.floor(tonumber(oid) or 0)] if o and o.carrier == src and o.state == 'ready' then return o end end

RegisterNetEvent((EVP .. ':handover'), function(oid)
  local src = source
  if not throttle(src, 'handover', 800) then return end
  local o = carried(src, oid)
  if not o or o.npc then return end
  if not GetPlayerName(o.src) then notify(src, 'warn', 'Le client n’est plus en ville : pose la commande au comptoir.') return end
  local a, b = coords(src), coords(o.src)
  if not a or not b or #(a - b) > Config.HandDistance + 1.5 then notify(src, 'warn', 'Rapproche-toi du client.') return end
  TriggerClientEvent((EVP .. ':giveAnim'), src) TriggerClientEvent((EVP .. ':giveAnim'), o.src)
  complete(o, src)
end)

RegisterNetEvent((EVP .. ':handnpc'), function(oid)
  local src = source
  if not throttle(src, 'handnpc', 800) then return end
  local o = carried(src, oid)
  if not o or not o.npc then return end
  -- le PNJ est posé sur le trottoir le plus proche de l'adresse : on accepte la remise dans un rayon de 30 m autour d'elle
  if not near(src, o.address, 30.0) then notify(src, 'error', "Tu es trop loin de l'adresse de livraison.") return end
  complete(o, src)
end)

RegisterNetEvent((EVP .. ':counter'), function(oid)
  local src = source
  if not throttle(src, 'counter') or not near(src, Points.counter, 2.5) then return end
  local o = carried(src, oid)
  if not o or o.npc then return end
  o.state, o.carrier = 'counter', nil
  TriggerClientEvent((EVP .. ':carry'), src, nil)
  notify(o.src, 'success', ('Commande #%d posée au comptoir : viens la récupérer.'):format(o.id))
  changed(o)
end)

RegisterNetEvent((EVP .. ':pickup'), function()
  local src = source
  if not throttle(src, 'pickup') or not near(src, Points.counter, 2.5) then return end
  local lic = license(src)
  for _, o in pairs(Orders) do
    if o.license == lic and (o.state == 'counter') then complete(o, o.packer) return end
  end
  -- un équipier reprend une commande posée pour la livrer en main propre
  if onDuty(src) then
    for _, o in pairs(Orders) do
      if o.state == 'counter' and not o.carrier then
        o.state, o.carrier = 'ready', src
        TriggerClientEvent((EVP .. ':carry'), src, { id = o.id, mode = o.mode, name = o.name, customer = o.src })
        changed(o) return
      end
    end
  end
end)

RegisterNetEvent((EVP .. ':cancel'), function(oid)
  local src = source
  if not throttle(src, 'cancel') or not staffGuard(src) then return end
  if not isManager(src) then notify(src, 'error', 'Réservé aux managers.') return end
  local o = Orders[math.floor(tonumber(oid) or 0)]
  if o then refund(o, 'annulée par ' .. nameOf(src)) end
end)

RegisterNetEvent((EVP .. ':rate'), function(oid, stars, tip)
  local src = source
  if not throttle(src, 'rate', 1000) then return end
  local o = Orders[math.floor(tonumber(oid) or 0)]
  if not o or o.state ~= 'done' or o.license ~= license(src) or not o.rateUntil or now() > o.rateUntil then return end
  o.rateUntil = nil
  stars = math.max(1, math.min(5, math.floor(tonumber(stars) or 5)))
  tip = math.max(0, math.min(500, math.floor(tonumber(tip) or 0)))
  local w = o.rateBy
  if w and GetPlayerName(w) then
    if tip > 0 then
      local ok = false
      pcall(function() ok = PB:RemoveMoney(src, 'bank', tip, (NAME .. ' : pourboire')) end)
      if ok then payBank(w, tip, (NAME .. ' : pourboire')) stats[w] = stats[w] or { orders = 0, earned = 0 } stats[w].earned = stats[w].earned + tip end
      notify(src, ok and 'success' or 'warn', ok and ('Pourboire de %d $ envoyé. Merci !'):format(tip) or 'Pourboire refusé : solde insuffisant.')
      if ok then notify(w, 'success', ('%s te laisse %d $ de pourboire et %d étoile(s).'):format(o.name, tip, stars)) end
    else
      notify(w, 'info', ('%s te donne %d étoile(s).'):format(o.name, stars))
    end
  end
end)

-- Scooter de livraison -----------------------------------------------------------------------------------------------------------
RegisterNetEvent((EVP .. ':vehicle'), function()
  local src = source
  if not throttle(src, 'vehicle', 2000) or not staffGuard(src) or not near(src, Points.garage, 4.0) then return end
  TriggerClientEvent((EVP .. ':vehicleOk'), src, Config.DeliveryVehicles[math.random(#Config.DeliveryVehicles)])
end)

-- Placement des points (staff) ------------------------------------------------------------------------------------------------------
local SINGLE = { counter = true, kds = true, grill = true, fryer = true, drinks = true, dessert = true, assembly = true, garage = true, board = true }
local function canPlace(src)
  local ok, r = pcall(function() return PB:HasPermission(src, 'burgershot.edit') end)
  return (ok and r) or IsPlayerAceAllowed(src, 'command')
end
-- Place un point à la position du joueur (commande /bsplace ou Builder du menu staff Shadow Base)
local function placePoint(src, what, extra)
  local c, h = coords(src), GetEntityHeading(GetPlayerPed(src))
  local p = c and { x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, h = math.floor(h) } or nil
  if what == 'kiosk' and p then Points.kiosks = Points.kiosks or {} table.insert(Points.kiosks, p) notify(src, 'success', ('Borne n°%d ajoutée.'):format(#Points.kiosks))
  elseif what == 'address' and p then p.label = extra ~= '' and extra:sub(1, 40) or 'Adresse' Points.addresses = Points.addresses or {} table.insert(Points.addresses, p) notify(src, 'success', 'Adresse de livraison ajoutée : ' .. p.label)
  elseif SINGLE[what] and p then Points[what] = p notify(src, 'success', 'Point « ' .. what .. ' » placé ici.')
  elseif what == 'clear' and (extra == 'kiosks' or extra == 'addresses') then Points[extra] = {} notify(src, 'success', 'Liste « ' .. extra .. ' » vidée.')
  elseif what == 'reset' then Points = json.decode(json.encode(Config.DefaultPoints)) notify(src, 'success', 'Points remis par défaut.')
  else
    notify(src, 'info', 'Usage : /bsplace kiosk | counter | kds | grill | fryer | drinks | dessert | assembly | garage | board | address <nom> | clear kiosks|addresses | reset')
    return false
  end
  savePoints()
  TriggerClientEvent((EVP .. ':points'), -1, Points)
  return true
end

-- Builder : liste des points posés (clé = nom du point, ou « kiosks:2 » / « addresses:5 » pour les listes) et suppression
local LABELS = { counter = 'Comptoir', kds = 'Écran de cuisine', grill = 'Poste : grill', fryer = 'Poste : friteuse', drinks = 'Poste : boissons', dessert = 'Poste : desserts',
  assembly = 'Poste : montage', garage = 'Sortie des scooters', board = 'Tableau des numéros' }
function listPoints()
  local out = {}
  for k, label in pairs(LABELS) do local p = Points[k] if type(p) == 'table' and p.x then out[#out + 1] = { key = k, label = label, x = p.x, y = p.y, z = p.z } end end
  table.sort(out, function(a, b) return a.label < b.label end)
  for i, p in ipairs(Points.kiosks or {}) do out[#out + 1] = { key = 'kiosks:' .. i, label = 'Borne n°' .. i, x = p.x, y = p.y, z = p.z } end
  for i, p in ipairs(Points.addresses or {}) do out[#out + 1] = { key = 'addresses:' .. i, label = 'Adresse : ' .. tostring(p.label or i), x = p.x, y = p.y, z = p.z } end
  return out
end
function deletePoint(src, key)
  local list, i = key:match('^(%a+):(%d+)$')
  if list == 'kiosks' or list == 'addresses' then
    i = tonumber(i)
    if not (Points[list] and Points[list][i]) then return false end
    table.remove(Points[list], i)
  elseif LABELS[key] then
    if not Points[key] then return false end
    Points[key] = nil
  else return false end
  savePoints()
  TriggerClientEvent((EVP .. ':points'), -1, Points)
  return true
end

RegisterCommand(Config.PlaceCommand or 'bsplace', function(src, args)
  if src == 0 then return end
  if not canPlace(src) then notify(src, 'error', "Tu n'as pas le droit de placer les points du Burger Shot (droit « burgershot.edit » du panel).") return end
  placePoint(src, tostring(args[1] or ''), table.concat(args, ' ', 2))
end, false)

-- Builder du menu staff Shadow Base : les points du Burger Shot s'y placent avec E (Shadow Base vérifie le droit du staff)
local BUILDER = {
  id = Config.BuilderId or 'burgershot', label = (NAME), icon = 'food', list = true,   -- le Builder affiche et supprime les points posés
  points = {
    { id = 'kiosk', label = 'Borne de commande', multi = true }, { id = 'counter', label = 'Comptoir (retrait des commandes)' }, { id = 'kds', label = 'Écran de cuisine' },
    { id = 'grill', label = 'Poste : grill' }, { id = 'fryer', label = 'Poste : friteuse' }, { id = 'drinks', label = 'Poste : boissons' }, { id = 'dessert', label = 'Poste : desserts' },
    { id = 'assembly', label = 'Poste : montage' }, { id = 'garage', label = 'Sortie des scooters (ton orientation compte)' }, { id = 'board', label = 'Tableau des numéros (en hauteur)' },
    { id = 'address', label = 'Adresse de livraison (PNJ)', multi = true, ask = 'Nom du lieu' },
  },
}
local function registerBuilder()
  pcall(function()
    exports.pb_panel:RegisterBuilder(BUILDER, function(src, what, extra)
      if what == '__list' then return listPoints() end
      if not canPlace(src) then return false end
      if what == '__delete' then return deletePoint(src, tostring(extra or '')) end
      return placePoint(src, tostring(what), tostring(extra or ''))
    end)
  end)
end
AddEventHandler('onResourceStart', function(r) if r == 'pb_panel' then SetTimeout(1500, registerBuilder) end end)
CreateThread(function() Wait(2000) registerBuilder() end)

-- Service : Shadow Base prévient à chaque prise / fin de service et changement de métier
AddEventHandler('pb_panel:duty', function(src, biz, on)
  if biz ~= BIZ then return end
  TriggerClientEvent((EVP .. ':duty'), src, on and true or false)
  if not on then   -- fin de service : ses commandes repassent à l'équipe
    for _, o in pairs(Orders) do
      if o.cook == src and (o.state == 'cooking' or o.state == 'cooked') then o.cook = nil o.state = 'paid' end
      if o.carrier == src then o.carrier = nil o.state = 'counter' TriggerClientEvent((EVP .. ':carry'), src, nil) end
    end
    TriggerClientEvent((EVP .. ':work'), src, nil)
  end
  pushStaff()
end)
AddEventHandler('pb_panel:jobChanged', function(src) SetTimeout(500, function() TriggerClientEvent((EVP .. ':duty'), src, onDuty(src)) pushStaff() end) end)

RegisterNetEvent((EVP .. ':hello'), function()
  local src = source
  TriggerClientEvent((EVP .. ':points'), src, Points)
  TriggerClientEvent((EVP .. ':duty'), src, onDuty(src))
  -- commande en cours retrouvée après reconnexion (même licence)
  local lic = license(src)
  for _, o in pairs(Orders) do if o.license == lic and o.state ~= 'done' and o.state ~= 'cancelled' then o.src = src pushCustomer(o) end end
  if onDuty(src) then pushStaff() end
  -- remboursements en attente (client déconnecté au moment du remboursement)
  local list = pendingRefund[lic]
  if list then
    pendingRefund[lic] = nil
    SetTimeout(8000, function()
      for _, r in ipairs(list) do pcall(function() PB:AddMoney(src, r.account, r.amount, r.label) end) end
      notify(src, 'info', ('Remboursement ' .. NAME .. ' crédité.'))
    end)
  end
end)

-- Boucle : cuisine automatique, délais, suivi de livraison, commandes de PNJ ---------------------------------------------------------
local lastNpc = 0
CreateThread(function()
  while true do
    Wait(3000)
    local s, t = S(), now()
    for _, o in pairs(Orders) do
      if o.state == 'auto' and t >= (o.readyAt or t) then
        o.state = 'counter'
        notify(o.src, 'success', ('Commande #%d prête au comptoir !'):format(o.id))
        changed(o)
      elseif o.state ~= 'done' and o.state ~= 'cancelled' and t - o.created > (tonumber(s.order_timeout) or 25) * 60 then
        refund(o, 'délai dépassé')
      elseif o.state == 'ready' and o.carrier then
        if not GetPlayerName(o.carrier) or not onDuty(o.carrier) then
          o.carrier = nil o.state = 'counter'   -- livreur parti : la commande attend au comptoir
          changed(o)
        elseif not o.npc and GetPlayerName(o.src) then
          local c, k = coords(o.src), coords(o.carrier)
          if c then TriggerClientEvent((EVP .. ':target'), o.carrier, o.id, c.x, c.y, c.z) end
          if k then TriggerClientEvent((EVP .. ':courier'), o.src, o.id, k.x, k.y, k.z) end
        end
      end
    end
    -- commandes de PNJ : seulement s'il y a des équipiers en service
    if Config.Delivery ~= false and s.npc_orders ~= false and t - lastNpc >= (tonumber(s.npc_every) or 4) * 60 then   -- commandes de PNJ à livrer
      local staff, pending = #staffOnDuty(), 0
      for _, o in pairs(Orders) do if o.npc and o.state ~= 'done' and o.state ~= 'cancelled' then pending = pending + 1 end end
      local addr = Points.addresses or {}
      if staff > 0 and pending < (tonumber(s.npc_max) or 3) and #addr > 0 then
        lastNpc = t
        local o, off = priceOverrides(s), disabledSet(s)
        local ids = {}
        for id in pairs(Config.Menus) do if not off[id] then ids[#ids + 1] = id end end
        for id in pairs(Config.Items) do if not off[id] then ids[#ids + 1] = id end end
        local lines = {}
        for _ = 1, math.random(1, 3) do
          local id = ids[math.random(#ids)]
          local m = Config.Menus[id]
          lines[#lines + 1] = { id = id, qty = 1, choice = m and m.choice[math.random(#m.choice)] or nil }
        end
        local e = expand(lines, s)
        if e then
          local a = addr[math.random(#addr)]
          local fee = math.floor(tonumber(s.delivery_fee) or 0)
          local names = { 'M. Rodriguez', 'Mme Chen', 'Kevin', 'Tracey', 'Lamar', 'Mme Patterson', 'Dr. Friedlander', 'Jimmy', 'Amanda', 'Denise' }
          local n = newOrder({ npc = true, name = names[math.random(#names)], units = e.units, lines = e.lines, subtotal = e.subtotal, fee = fee, total = e.subtotal + fee, pay = 'cash', mode = 'delivery', state = 'paid', address = a })
          for _, id in ipairs(staffOnDuty()) do TriggerClientEvent((EVP .. ':ding'), id, n.id, n.name .. ' — ' .. (a.label or 'livraison'), 'delivery') end
          pushStaff()
        end
      end
    end
  end
end)

-- Déconnexions et arrêt ----------------------------------------------------------------------------------------------------------
AddEventHandler('playerDropped', function()
  local src = source
  games[src] = nil
  for k in pairs(lastAct) do if k:match('^' .. src .. ':') then lastAct[k] = nil end end
  for _, o in pairs(Orders) do
    if o.cook == src and (o.state == 'cooking' or o.state == 'cooked') then o.cook = nil o.state = 'paid' changed(o) end   -- reprise par un autre équipier
    if o.carrier == src then o.carrier = nil o.state = 'counter' changed(o) end
  end
end)

AddEventHandler('onResourceStop', function(res)
  if res ~= GetCurrentResourceName() then return end
  for _, o in pairs(Orders) do refund(o, ('redémarrage du ' .. NAME)) end
end)

-- Démarrage : entreprise, objets de la carte, points ------------------------------------------------------------------------------
CreateThread(function()
  loadPoints()
  local t = GetGameTimer() + 30000
  while GetResourceState('pb_panel') ~= 'started' and GetGameTimer() < t do Wait(500) end
  Wait(3000)
  local okB = false
  pcall(function() okB = PB:EnsureBusiness(BIZ) end)
  if not okB then print('^3[fishchips]^7 Entreprise « ' .. BIZ .. ' » introuvable dans Shadow Base : crée-la dans le panel (Entreprises).') end
  local n = 0
  for id, d in pairs(Config.Items) do
    local kind = (d.thirst or 0) > (d.hunger or 0) and 'drink' or 'food'
    local ok = false
    pcall(function() ok = PB:EnsureItem({ name = (Config.ItemPrefix or 'bs_') .. id, label = d.label, weight = kind == 'drink' and 330 or 250, stack = 10, kind = kind,
      hunger = d.hunger or 0, thirst = d.thirst or 0, stress = d.stress or 0, usable = true, description = (NAME .. ' — ') .. (d.desc or ''), image = d.img and ('img/' .. d.img) or '' }) end)
    if ok then n = n + 1 end
  end
  print(('^2[fishchips]^7 Prêt : %d articles, %d bornes. Placement : /bsplace'):format(n, #(Points.kiosks or {})))
  TriggerClientEvent((EVP .. ':points'), -1, Points)
end)
