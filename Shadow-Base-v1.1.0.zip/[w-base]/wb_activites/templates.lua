-- Catalogue des activités : modèles posés en jeu depuis le Builder du menu staff (F10 › Builder › Activités).
-- Chaque modèle devient un point quand le staff appuie sur Entrée à l'endroit voulu. Tout reste modifiable ensuite dans le panel (Activités › Points).
--   kind   : harvest (récolte), process (transformation), sell (grossiste), bench (établi de craft)
--   loot   : « objet:poids,objet:poids » — tirage au sort pondéré à chaque récolte (remplace item_out)
--   anim   : scénario GTA (WORLD_HUMAN_…, PROP_HUMAN_…) ou « dictionnaire|animation »
--   prop   : objet tenu en main pendant l'action (vide = aucun)
--   sprite / color : icône sur la carte (0 = aucune) — liste : docs.fivem.net/docs/game-references/blips
--   (356 quai, 618 lingot, 501 caisse, 846 tracteur, 141 chasse, 527 casse, 500 argent, 643 atelier)
ACT_TEMPLATES = {
    -- Pêche
    { id = 'peche', group = 'Pêche', kind = 'harvest', label = 'Zone de pêche', radius = 10, tool = 'fishing_rod', loot = 'fish:62,salmon:22,crab:10,old_boot:5,message_bottle:1', qty_out = 1, time = 12, anim = 'WORLD_HUMAN_STAND_FISHING', prop = '', sprite = 356, color = 3 },
    { id = 'poissonnerie', group = 'Pêche', kind = 'process', label = 'Poissonnerie', radius = 3, item_in = 'fish', qty_in = 2, item_out = 'fish_fillet', qty_out = 1, time = 8, anim = 'PROP_HUMAN_BBQ', sprite = 356, color = 47 },
    -- Mine
    { id = 'mine', group = 'Mine', kind = 'harvest', label = 'Filon', radius = 12, tool = 'pickaxe', loot = 'stone:45,iron_ore:35,copper_ore:15,gold_nugget:4,diamond_raw:1', qty_out = 1, time = 9, anim = 'melee@large_wpn@streamed_core|ground_attack_on_spot', prop = 'prop_tool_pickaxe', sprite = 618, color = 5 },
    { id = 'fonderie', group = 'Mine', kind = 'process', label = 'Fonderie (fer)', radius = 3, item_in = 'iron_ore', qty_in = 3, item_out = 'iron_ingot', qty_out = 1, time = 10, anim = 'WORLD_HUMAN_WELDING', sprite = 618, color = 47 },
    { id = 'fonderie_cuivre', group = 'Mine', kind = 'process', label = 'Fonderie (cuivre)', radius = 3, item_in = 'copper_ore', qty_in = 3, item_out = 'copper_ingot', qty_out = 1, time = 10, anim = 'WORLD_HUMAN_WELDING', sprite = 618, color = 47 },
    { id = 'concasseur', group = 'Mine', kind = 'process', label = 'Concasseur (pierre → sable)', radius = 3, item_in = 'stone', qty_in = 4, item_out = 'sand', qty_out = 2, time = 8, anim = 'PROP_HUMAN_PARKING_METER', sprite = 618, color = 47 },
    { id = 'verrerie', group = 'Mine', kind = 'process', label = 'Verrerie (sable → verre)', radius = 3, item_in = 'sand', qty_in = 3, item_out = 'glass', qty_out = 1, time = 10, anim = 'WORLD_HUMAN_WELDING', sprite = 618, color = 47 },
    -- Bûcheron
    { id = 'bois', group = 'Bûcheron', kind = 'harvest', label = 'Coupe de bois', radius = 12, tool = 'axe', loot = 'wood_log:85,resin:15', qty_out = 1, time = 9, anim = 'melee@large_wpn@streamed_core|ground_attack_on_spot', prop = 'w_me_hatchet', sprite = 501, color = 25 },
    { id = 'scierie', group = 'Bûcheron', kind = 'process', label = 'Scierie', radius = 3, item_in = 'wood_log', qty_in = 1, item_out = 'plank', qty_out = 2, time = 8, anim = 'WORLD_HUMAN_HAMMERING', sprite = 501, color = 47 },
    -- Agriculture
    { id = 'ble', group = 'Agriculture', kind = 'harvest', label = 'Champ de blé', radius = 15, tool = '', loot = 'wheat:100', qty_out = 2, time = 7, anim = 'WORLD_HUMAN_GARDENER_PLANT', prop = '', sprite = 846, color = 46 },
    { id = 'moulin', group = 'Agriculture', kind = 'process', label = 'Moulin', radius = 3, item_in = 'wheat', qty_in = 4, item_out = 'flour', qty_out = 1, time = 8, anim = 'PROP_HUMAN_BUM_BIN', sprite = 846, color = 47 },
    { id = 'vigne', group = 'Agriculture', kind = 'harvest', label = 'Vignes', radius = 15, tool = '', loot = 'grape:100', qty_out = 2, time = 7, anim = 'WORLD_HUMAN_GARDENER_PLANT', prop = '', sprite = 846, color = 27 },
    { id = 'pressoir', group = 'Agriculture', kind = 'process', label = 'Pressoir (vin)', radius = 3, item_in = 'grape', qty_in = 5, item_out = 'wine', qty_out = 1, time = 10, anim = 'PROP_HUMAN_PARKING_METER', sprite = 846, color = 47 },
    { id = 'verger', group = 'Agriculture', kind = 'harvest', label = 'Verger d\'orangers', radius = 15, tool = '', loot = 'orange:100', qty_out = 2, time = 7, anim = 'amb@prop_human_movie_bulb@base|base', prop = '', sprite = 846, color = 47 },
    { id = 'presse', group = 'Agriculture', kind = 'process', label = 'Presse-agrumes (jus)', radius = 3, item_in = 'orange', qty_in = 3, item_out = 'orange_juice', qty_out = 1, time = 8, anim = 'PROP_HUMAN_PARKING_METER', sprite = 846, color = 47 },
    -- Cueillette
    { id = 'cueillette', group = 'Cueillette', kind = 'harvest', label = 'Cueillette en forêt', radius = 20, tool = '', loot = 'mushroom:45,berries:45,truffle:10', qty_out = 1, time = 6, anim = 'WORLD_HUMAN_GARDENER_PLANT', prop = '', sprite = 141, color = 2 },
    -- Récupération
    { id = 'decharge', group = 'Récupération', kind = 'harvest', label = 'Décharge', radius = 12, tool = '', loot = 'scrap_metal:45,plastic:30,glass_shard:20,old_phone:5', qty_out = 1, time = 8, anim = 'PROP_HUMAN_BUM_BIN', prop = '', sprite = 527, color = 21 },
    { id = 'recyclerie', group = 'Récupération', kind = 'process', label = 'Recyclerie (ferraille → fer)', radius = 3, item_in = 'scrap_metal', qty_in = 4, item_out = 'iron_ingot', qty_out = 1, time = 10, anim = 'WORLD_HUMAN_WELDING', sprite = 527, color = 47 },
    -- Commerce et craft
    { id = 'grossiste', group = 'Commerce', kind = 'sell', label = 'Grossiste', radius = 3, sprite = 500, color = 2 },
    { id = 'atelier', group = 'Commerce', kind = 'bench', label = 'Établi', radius = 2, sprite = 643, color = 0 },
}

-- Objets créés au premier démarrage (modifiables ensuite dans Inventaire › Objets)
ACT_ITEMS = {
    { name = 'fishing_rod', label = 'Canne à pêche', weight = 1200, stack = 1, kind = 'tool', usable = false, description = 'Pour pêcher.' },
    { name = 'pickaxe', label = 'Pioche', weight = 2500, stack = 1, kind = 'tool', usable = false, description = 'Pour miner.' },
    { name = 'axe', label = 'Hache', weight = 2000, stack = 1, kind = 'tool', usable = false, description = 'Pour couper du bois.' },
    { name = 'fish', label = 'Poisson', weight = 600, stack = 50, kind = 'misc', usable = false },
    { name = 'salmon', label = 'Saumon', weight = 900, stack = 30, kind = 'misc', usable = false, description = 'Prise de choix.' },
    { name = 'crab', label = 'Crabe', weight = 500, stack = 30, kind = 'misc', usable = false },
    { name = 'old_boot', label = 'Vieille chaussure', weight = 400, stack = 10, kind = 'misc', usable = false, description = 'Ça arrive aux meilleurs.' },
    { name = 'message_bottle', label = 'Bouteille à la mer', weight = 300, stack = 5, kind = 'misc', usable = false, description = 'Un message illisible… et précieux pour un collectionneur.' },
    { name = 'fish_fillet', label = 'Filet de poisson', weight = 300, stack = 50, kind = 'misc', usable = false },
    { name = 'stone', label = 'Pierre', weight = 1500, stack = 50, kind = 'misc', usable = false },
    { name = 'iron_ore', label = 'Minerai de fer', weight = 1500, stack = 50, kind = 'misc', usable = false },
    { name = 'copper_ore', label = 'Minerai de cuivre', weight = 1500, stack = 50, kind = 'misc', usable = false },
    { name = 'gold_nugget', label = 'Pépite d\'or', weight = 100, stack = 50, kind = 'misc', usable = false },
    { name = 'diamond_raw', label = 'Diamant brut', weight = 50, stack = 20, kind = 'misc', usable = false, description = 'Très rare.' },
    { name = 'iron_ingot', label = 'Lingot de fer', weight = 1000, stack = 50, kind = 'misc', usable = false },
    { name = 'copper_ingot', label = 'Lingot de cuivre', weight = 1000, stack = 50, kind = 'misc', usable = false },
    { name = 'sand', label = 'Sable', weight = 800, stack = 50, kind = 'misc', usable = false },
    { name = 'glass', label = 'Plaque de verre', weight = 900, stack = 30, kind = 'misc', usable = false },
    { name = 'wood_log', label = 'Bûche', weight = 2000, stack = 20, kind = 'misc', usable = false },
    { name = 'resin', label = 'Résine', weight = 200, stack = 50, kind = 'misc', usable = false },
    { name = 'plank', label = 'Planche', weight = 800, stack = 50, kind = 'misc', usable = false },
    { name = 'wheat', label = 'Blé', weight = 300, stack = 100, kind = 'misc', usable = false },
    { name = 'flour', label = 'Farine', weight = 500, stack = 50, kind = 'misc', usable = false },
    { name = 'grape', label = 'Raisin', weight = 250, stack = 100, kind = 'misc', usable = false },
    { name = 'wine', label = 'Bouteille de vin', weight = 900, stack = 20, kind = 'drink', usable = true, thirst = 20, stress = -15, description = 'Cuvée maison.' },
    { name = 'orange', label = 'Orange', weight = 200, stack = 100, kind = 'food', usable = true, hunger = 5, thirst = 5 },
    { name = 'orange_juice', label = 'Jus d\'orange', weight = 400, stack = 20, kind = 'drink', usable = true, thirst = 35 },
    { name = 'mushroom', label = 'Champignon', weight = 100, stack = 50, kind = 'food', usable = true, hunger = 5 },
    { name = 'berries', label = 'Baies sauvages', weight = 100, stack = 50, kind = 'food', usable = true, hunger = 5, thirst = 3 },
    { name = 'truffle', label = 'Truffe', weight = 100, stack = 20, kind = 'misc', usable = false, description = 'Les restaurants se l\'arrachent.' },
    { name = 'scrap_metal', label = 'Ferraille', weight = 1200, stack = 50, kind = 'misc', usable = false },
    { name = 'plastic', label = 'Plastique', weight = 300, stack = 100, kind = 'misc', usable = false },
    { name = 'glass_shard', label = 'Débris de verre', weight = 300, stack = 50, kind = 'misc', usable = false },
    { name = 'old_phone', label = 'Vieux téléphone', weight = 300, stack = 10, kind = 'misc', usable = false, description = 'Des composants à récupérer.' },
    { name = 'bread', label = 'Pain', weight = 300, stack = 20, kind = 'food', usable = true, hunger = 30, description = 'Fait maison.' },
    { name = 'lockpick', label = 'Crochet', weight = 150, stack = 10, kind = 'tool', usable = false, description = 'Utile pour… certaines portes.' },
    { name = 'bandage', label = 'Bandage', weight = 100, stack = 20, kind = 'medic', usable = true, health = 20 },
    -- produits préparés dans les cuisines / bars des entreprises (et vendus à leur comptoir)
    { name = 'cocktail', label = 'Cocktail maison', weight = 400, stack = 20, kind = 'drink', usable = true, thirst = 25, stress = -15 },
    { name = 'beer', label = 'Bière', weight = 500, stack = 20, kind = 'drink', usable = true, thirst = 20, stress = -8 },
    { name = 'pizza', label = 'Pizza', weight = 600, stack = 10, kind = 'food', usable = true, hunger = 55, thirst = -3 },
    { name = 'fish_meal', label = 'Assiette de poisson', weight = 500, stack = 10, kind = 'food', usable = true, hunger = 60 },
    { name = 'meal', label = 'Plat du jour', weight = 600, stack = 10, kind = 'food', usable = true, hunger = 70, stress = -5 },
    { name = 'salad', label = 'Salade composée', weight = 350, stack = 10, kind = 'food', usable = true, hunger = 30, thirst = 5 },
    { name = 'sushi', label = 'Plateau de sushis', weight = 400, stack = 10, kind = 'food', usable = true, hunger = 45 },
    { name = 'croissant', label = 'Croissant', weight = 100, stack = 20, kind = 'food', usable = true, hunger = 15 },
    { name = 'pain_choc', label = 'Pain au chocolat', weight = 100, stack = 20, kind = 'food', usable = true, hunger = 18 },
    { name = 'cake', label = 'Part de gâteau', weight = 200, stack = 20, kind = 'food', usable = true, hunger = 25, stress = -5 },
}

ACT_MARKET = {
    { item = 'fish', price = 8 }, { item = 'salmon', price = 25 }, { item = 'crab', price = 18 }, { item = 'old_boot', price = 1 }, { item = 'message_bottle', price = 400 },
    { item = 'fish_fillet', price = 30 }, { item = 'stone', price = 2 }, { item = 'iron_ore', price = 10 }, { item = 'copper_ore', price = 14 }, { item = 'gold_nugget', price = 120 },
    { item = 'diamond_raw', price = 1500 }, { item = 'iron_ingot', price = 45 }, { item = 'copper_ingot', price = 60 }, { item = 'glass', price = 40 }, { item = 'wood_log', price = 12 },
    { item = 'resin', price = 15 }, { item = 'plank', price = 15 }, { item = 'wheat', price = 3 }, { item = 'flour', price = 25 }, { item = 'grape', price = 3 }, { item = 'wine', price = 60 },
    { item = 'orange', price = 3 }, { item = 'orange_juice', price = 28 }, { item = 'mushroom', price = 6 }, { item = 'berries', price = 4 }, { item = 'truffle', price = 180 },
    { item = 'scrap_metal', price = 6 }, { item = 'plastic', price = 2 }, { item = 'glass_shard', price = 2 }, { item = 'old_phone', price = 35 },
}

ACT_RECIPES = {
    { id = 'repair_kit', bench = '', label = 'Kit de réparation', ingredients = 'iron_ingot:2,plank:2', item_out = 'repair_kit', qty_out = 1, time = 12 },
    { id = 'fishing_rod', bench = '', label = 'Canne à pêche', ingredients = 'plank:2,iron_ingot:1', item_out = 'fishing_rod', qty_out = 1, time = 10 },
    { id = 'pickaxe', bench = '', label = 'Pioche', ingredients = 'iron_ingot:2,plank:1', item_out = 'pickaxe', qty_out = 1, time = 10 },
    { id = 'axe', bench = '', label = 'Hache', ingredients = 'iron_ingot:1,plank:2', item_out = 'axe', qty_out = 1, time = 10 },
    { id = 'bread', bench = '', label = 'Pain', ingredients = 'flour:2', item_out = 'bread', qty_out = 1, time = 6 },
    { id = 'lockpick', bench = '', label = 'Crochet', ingredients = 'iron_ingot:1,copper_ingot:1', item_out = 'lockpick', qty_out = 2, time = 10 },
    { id = 'bandage', bench = '', label = 'Bandage', ingredients = 'plastic:2,resin:1', item_out = 'bandage', qty_out = 2, time = 6 },
    -- cuisines / bars des entreprises (établi « tag:… ») : ingrédients issus des activités
    { id = 'k_cocktail', bench = 'tag:bar', label = 'Cocktail maison', ingredients = 'orange_juice:1,wine:1', item_out = 'cocktail', qty_out = 2, time = 6 },
    { id = 'k_beer_bar', bench = 'tag:bar', label = 'Bière pression', ingredients = 'wheat:4', item_out = 'beer', qty_out = 2, time = 6 },
    { id = 'k_pizza', bench = 'tag:resto', label = 'Pizza', ingredients = 'flour:2,mushroom:2', item_out = 'pizza', qty_out = 2, time = 10 },
    { id = 'k_fish', bench = 'tag:resto', label = 'Assiette de poisson', ingredients = 'fish_fillet:2', item_out = 'fish_meal', qty_out = 2, time = 8 },
    { id = 'k_meal', bench = 'tag:resto', label = 'Plat du jour truffé', ingredients = 'fish_fillet:1,flour:1,truffle:1', item_out = 'meal', qty_out = 3, time = 12 },
    { id = 'k_salad', bench = 'tag:resto', label = 'Salade composée', ingredients = 'mushroom:1,berries:2', item_out = 'salad', qty_out = 2, time = 6 },
    { id = 'k_sushi', bench = 'tag:sushi', label = 'Plateau de sushis', ingredients = 'fish_fillet:2,wheat:1', item_out = 'sushi', qty_out = 2, time = 10 },
    { id = 'k_juice', bench = 'tag:cafe', label = "Jus d'orange pressé", ingredients = 'orange:3', item_out = 'orange_juice', qty_out = 1, time = 5 },
    { id = 'k_croissant_cafe', bench = 'tag:cafe', label = 'Croissant', ingredients = 'flour:1', item_out = 'croissant', qty_out = 2, time = 6 },
    { id = 'k_bread', bench = 'tag:bakery', label = 'Pain', ingredients = 'flour:2', item_out = 'bread', qty_out = 2, time = 6 },
    { id = 'k_croissant', bench = 'tag:bakery', label = 'Croissant', ingredients = 'flour:1', item_out = 'croissant', qty_out = 2, time = 6 },
    { id = 'k_painchoc', bench = 'tag:bakery', label = 'Pain au chocolat', ingredients = 'flour:1', item_out = 'pain_choc', qty_out = 2, time = 6 },
    { id = 'k_cake', bench = 'tag:bakery', label = 'Part de gâteau', ingredients = 'flour:2,berries:2', item_out = 'cake', qty_out = 3, time = 10 },
    { id = 'k_wine', bench = 'tag:wine', label = 'Bouteille de vin', ingredients = 'grape:5', item_out = 'wine', qty_out = 1, time = 10 },
    { id = 'k_beer', bench = 'tag:beer', label = 'Bière artisanale', ingredients = 'wheat:4', item_out = 'beer', qty_out = 2, time = 8 },
}
