-- Anticheat (client) : répond au « pouls » du serveur et signale l'arrêt d'une ressource protégée.
-- Il ne détecte rien tout seul : le serveur décide. Un cheat injecté pourrait imiter le pouls (voir la liste des limites dans le panel).
local sec, protected = nil, {}

local function hash(s)
    local h = 5381
    for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
    return h
end

RegisterNetEvent('pb:ac:hello', function(secret, list)
    sec = tostring(secret or '')
    protected = {}
    for _, r in ipairs(type(list) == 'table' and list or {}) do protected[tostring(r)] = true end
end)

RegisterNetEvent('pb:ac:ping', function(seq, nonce)
    if not sec then return end
    TriggerServerEvent('pb:ac:pong', seq, hash(tostring(nonce) .. sec))
end)

AddEventHandler('onClientResourceStop', function(res)
    if sec and protected[res] then TriggerServerEvent('pb:ac:cstop', res) end
end)

-- Filet de sécurité : une ressource protégée qui n'est plus « started » côté client alors qu'on a la liste.
CreateThread(function()
    local told = {}
    while true do
        Wait(5000)
        if sec then
            for r in pairs(protected) do
                local st = GetResourceState(r)
                if st ~= 'started' and st ~= 'starting' and st ~= 'missing' and not told[r] then told[r] = true TriggerServerEvent('pb:ac:cstop', r)
                elseif st == 'started' then told[r] = nil end
            end
        end
    end
end)
