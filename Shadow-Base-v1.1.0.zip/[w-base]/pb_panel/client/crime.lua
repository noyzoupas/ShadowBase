-- Activités illégales : marqueurs, invite E, barre de progression ; le serveur valide le départ et la fin.
local G = PBG
local spots, active = {}, false
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local cr = c.crime or {}
    spots = {}
    if cr.enabled == false then return end
    local function add(kind, list) for _, s in ipairs(list or {}) do spots[#spots + 1] = { kind = kind, id = s.id, label = s.label, x = s.x + 0.0, y = s.y + 0.0, z = s.z + 0.0, r = tonumber(s.radius) or 3.0 } end end
    add('chain', cr.chain) for _, s in ipairs(cr.heists or {}) do spots[#spots + 1] = { kind = 'heist', id = s.id, label = s.label, x = s.x + 0.0, y = s.y + 0.0, z = s.z + 0.0, r = tonumber(s.radius) or 3.0, ped = s.ped, h = s.h } end add('launder', cr.launder)
    G.crimeCfg = cr
end

-- Filière : le geste remplace la barre de progression (récolte : se penche ; transformation : prépare ; vente : échange), joué en boucle pendant l'action
local GESTURE = {
    harvest = { 'pickup_object', 'pickup_low' },
    process = { 'mp_arresting', 'a_uncuff' },
    sell = { 'mp_common', 'givetake1_a' },
}
local function playGesture(kind, secs)
    local g = GESTURE[kind]
    if not g then return false end
    RequestAnimDict(g[1])
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded(g[1]) and GetGameTimer() < t do Wait(10) end
    if not HasAnimDictLoaded(g[1]) then return false end
    CreateThread(function()
        local stop = GetGameTimer() + secs * 1000
        while active and GetGameTimer() < stop do
            TaskPlayAnim(PlayerPedId(), g[1], g[2], 8.0, -8.0, -1, 0, 0, false, false, false)
            local len = math.max(600, math.floor((GetAnimDuration(g[1], g[2]) or 1.0) * 1000))
            Wait(math.min(len, math.max(200, stop - GetGameTimer())))
        end
        RemoveAnimDict(g[1])
    end)
    return true
end

RegisterNetEvent('pb:g:crime:go', function(j)
    local d = G.decode(j)
    if not d then return end
    active = true
    local ped = PlayerPedId()
    local secs = tonumber(d.time) or 5
    local gesture = d.anim and GESTURE[d.anim] ~= nil
    if not gesture then G.send('crime.progress', { label = d.label, secs = secs }) end
    local clerk = G.heistClerk
    G.heistClerk = nil
    if clerk and DoesEntityExist(clerk) then FreezeEntityPosition(clerk, false) TaskHandsUp(clerk, secs * 1000, ped, -1, false) end
    if gesture then playGesture(d.anim, secs)
    elseif not clerk then TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_STAND_IMPATIENT', 0, true) end
    CreateThread(function()
        local t0, ok = GetGameTimer(), true
        while GetGameTimer() - t0 < secs * 1000 do
            Wait(100)
            local p = PlayerPedId()
            local c = GetEntityCoords(p)
            if IsEntityDead(p) or #(c - vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)) > (tonumber(d.radius) or 4.5) then ok = false break end
        end
        active = false
        ClearPedTasks(PlayerPedId())
        if clerk and DoesEntityExist(clerk) then ClearPedTasks(clerk) FreezeEntityPosition(clerk, true) end
        if not gesture then G.send('crime.progress', { cancel = true }) end
        if not ok then G.send('notify', { type = 'warn', title = 'Activité', text = 'Interrompu.' }) end
        TriggerServerEvent('pb:g:crime:end', ok)
    end)
end)

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #spots == 0 or active or G.Menu.IsOpen() then hide() Wait(500)
        else
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(spots) do if s.kind ~= 'heist' then local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end end
            local cr = G.crimeCfg or {}
            if best and bd < 25.0 and cr.show_markers ~= false then G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 255, 255, 255, 1.0) end
            if best and bd <= math.max(best.r, tonumber(cr.use_dist) or 2.5) and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt', { show = true, key = 'E', text = best.label }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:crime:start', best.kind, best.id) end
                Wait(0)
            else hide() Wait(bd and bd < 40 and 150 or 700) end
        end
    end
end)

-- Braquage : on vise le vendeur (arme à feu ou arme blanche) pendant un instant. Le vendeur est le ped du jeu déjà présent au comptoir ;
-- s'il n'y en a pas, on en pose un. Le serveur relit la distance, l'arme en main, les policiers en service et le délai.
local clerks = {}        -- id du point -> ped posé par nous
local MELEE = 2685387236
local function clerkAt(s)
    local ped = clerks[s.id]
    if ped and DoesEntityExist(ped) and not IsEntityDead(ped) then return ped end
    local me = PlayerPedId()
    local best, bd
    local pool = GetGamePool and GetGamePool('CPed') or {}
    for _, p in ipairs(pool) do
        if p ~= me and not IsPedAPlayer(p) and not IsPedDeadOrDying(p, true) and not IsPedInAnyVehicle(p, false) then
            local d = #(GetEntityCoords(p) - vector3(s.x, s.y, s.z))
            if d < 4.5 and (not bd or d < bd) then best, bd = p, d end
        end
    end
    return best
end
local function spawnClerk(s)
    local model = joaat(s.ped ~= nil and s.ped ~= '' and s.ped or 'mp_m_shopkeep_01')
    RequestModel(model)
    local t = GetGameTimer() + 3000
    while not HasModelLoaded(model) and GetGameTimer() < t do Wait(50) end
    if not HasModelLoaded(model) then return end
    local ped = CreatePed(4, model, s.x, s.y, G.Ground(s.x, s.y, s.z), (tonumber(s.h) or 0.0) + 0.0, false, false)
    SetEntityInvincible(ped, false) SetBlockingOfNonTemporaryEvents(ped, true) SetPedFleeAttributes(ped, 0, false) FreezeEntityPosition(ped, true)
    SetModelAsNoLongerNeeded(model)
    clerks[s.id] = ped
end
CreateThread(function()
    local hold, shown = 0, nil
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        local sleep = 700
        if G.begun and not active and not G.Menu.IsOpen() then
            local me = PlayerPedId()
            local c = GetEntityCoords(me)
            for _, s in ipairs(spots) do
                if s.kind == 'heist' then
                    local d = #(c - vector3(s.x, s.y, s.z))
                    if d < 45.0 then
                        sleep = 250
                        if not clerkAt(s) and not clerks[s.id] and d < 30.0 then spawnClerk(s) end
                    end
                    if d < s.r + 4.0 and GetVehiclePedIsIn(me, false) == 0 then
                        sleep = 0
                        local ped = clerkAt(s)
                        local _, w = GetCurrentPedWeapon(me, true)
                        local armed = w and w ~= joaat('WEAPON_UNARMED')
                        if ped then
                            if shown ~= s.id then shown = s.id G.send('prompt', { show = true, key = 'RMB', text = armed and ('Vise le vendeur pour braquer : ' .. s.label) or 'Sors une arme (même blanche) et vise le vendeur' }) end
                            local aiming = false
                            if armed then
                                if GetWeapontypeGroup(w) == MELEE then
                                    local dd = #(GetEntityCoords(ped) - c)
                                    local fwd = GetEntityForwardVector(me)
                                    local to = GetEntityCoords(ped) - c
                                    local len = #to
                                    aiming = IsControlPressed(0, 25) and dd < 3.5 and len > 0.01 and ((fwd.x * to.x + fwd.y * to.y) / len) > 0.6
                                else
                                    aiming = IsPlayerFreeAimingAtEntity(PlayerId(), ped)
                                end
                            end
                            if aiming then
                                hold = hold + (GetFrameTime and GetFrameTime() or 0.016)
                                if hold >= 0.7 then
                                    hold = 0 hide()
                                    G.heistClerk = ped
                                    TriggerServerEvent('pb:g:crime:start', 'heist', s.id)
                                    Wait(1500)
                                end
                            else hold = 0 end
                        else hide() end
                    elseif shown == s.id then hide() hold = 0 end
                end
            end
        else hide() end
        Wait(sleep)
    end
end)
-- le vendeur lève les mains pendant le braquage
