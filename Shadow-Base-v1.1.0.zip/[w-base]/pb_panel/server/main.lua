-- Démarrage du panel : détection de l'environnement, commandes console, exports pour les autres scripts.

PB.DetectEnv()

SetConvarReplicated('pb_panel_key', tostring(Config.OpenKey or ''))
SetConvarReplicated('pb_panel_cmd', tostring(Config.OpenCommand or 'panel'))

PB.Info = { resource = GetCurrentResourceName(), version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '1.0.0', startedAt = os.time() }

-- Commandes console (jamais utilisables par un joueur) ---------------------------------------------------------------------
local function consoleOnly(src)
    if src ~= 0 then return false end
    return true
end

RegisterCommand('pb_grant', function(src, args)
    if not consoleOnly(src) then return end
    local target, grade = args[1], args[2]
    if not target or not grade then print('Usage : pb_grant <id joueur | license:xxxx> <grade>') return end
    local license, name = target, ''
    if tonumber(target) then
        license = PB.Perm.GetLicense(tonumber(target))
        name = GetPlayerName(tonumber(target)) or ''
        if not license then print('Joueur introuvable.') return end
    end
    local ok, err = PB.Perm.SetStaff(0, license, name, grade)
    print(ok and ('Grade « ' .. grade .. ' » attribué à ' .. license) or ('Refusé : ' .. tostring(err)))
end, true)

RegisterCommand('pb_revoke', function(src, args)
    if not consoleOnly(src) then return end
    local target = args[1]
    if not target then print('Usage : pb_revoke <id joueur | license:xxxx>') return end
    local license = tonumber(target) and PB.Perm.GetLicense(tonumber(target)) or target
    local ok, err = PB.Perm.SetStaff(0, license, '', nil)
    print(ok and 'Grade retiré.' or ('Refusé : ' .. tostring(err)))
end, true)

RegisterCommand('pb_grades', function(src)
    if not consoleOnly(src) then return end
    for _, g in ipairs(PB.Perm.Grades()) do print(('%-14s niveau %-4d %d membre(s)'):format(g.name, g.level, g.members)) end
end, true)

RegisterCommand('pb_sync', function(src)
    if not consoleOnly(src) then return end
    PB.Perm.SyncAll()
    print('Grades synchronisés avec la librairie admin (mode ' .. (Config.AdminLib.mode or 'ace') .. ').')
end, true)

RegisterCommand('pb_status', function(src)
    if not consoleOnly(src) then return end
    print(('pb_panel %s — framework : %s — inventaire : %s — base : %s'):format(PB.Info.version, 'wframework', tostring(PB.Inv.Detect()), PB.IsReady and 'prête' or 'en attente'))
end, true)

-- Exports pour les autres scripts : alimenter le journal du panel -------------------------------------------------------------
-- exports.pb_panel:Log('sanction', 'ban', 'NomAdmin', 'NomJoueur', nil, nil, { raison = '...' })
exports('Log', function(cat, action, actor, target, before, after, data)
    if type(cat) ~= 'string' or type(action) ~= 'string' then return false end
    PB.Audit.Log(cat:sub(1, 24), action, tostring(actor or 'script'), target, before, after, data)
    return true
end)

exports('Notify', function(level, title, text) PB.Notify(level, tostring(title), tostring(text or '')) return true end)

AddEventHandler('pb_panel:ready', function()
    if #(Config.Owners or {}) == 0 and #PB.Perm.Staff() == 0 then
        print('^3[pb_panel]^7 Aucun propriétaire défini. Ajoute ta licence dans config.lua (Config.Owners) ou tape dans la console : pb_grant <ton id en jeu> owner')
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then PB.Cfg.Set('monitor', 'panel_stopped_at', os.time(), 'système', nil, true) end
end)
