-- Module 3 : Commandes (inventaire, commandes du panel, restriction par grade, blocage, historique d'usage).
-- Limite assumée : FiveM ne permet pas de désenregistrer une commande d'une autre ressource. Le panel peut la
-- restreindre (ACE) ou la bloquer dans le chat ; il ne peut pas la supprimer.

local B, Form, P, F, DB = PB.B, PB.Form, PB.Perm, PB.Files, PB.DB

P.Register('commands.edit', 'Créer et modifier les commandes du panel', 'commands')
P.Register('commands.access', 'Restreindre une commande à un grade (ACE)', 'commands', true)

PB.Migrate('020_commands', 'Commandes du panel', {
    [[CREATE TABLE IF NOT EXISTS pb_commands (
        name VARCHAR(48) NOT NULL, kind VARCHAR(16) NOT NULL DEFAULT 'message', text VARCHAR(400) NOT NULL DEFAULT '',
        description VARCHAR(160) NOT NULL DEFAULT '', cooldown INT NOT NULL DEFAULT 0, enabled TINYINT(1) NOT NULL DEFAULT 1,
        restricted TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (name))]],
    [[CREATE TABLE IF NOT EXISTS pb_cmd_usage (
        name VARCHAR(48) NOT NULL, uses INT NOT NULL DEFAULT 0, last_by VARCHAR(96) NOT NULL DEFAULT '', last_at INT NOT NULL DEFAULT 0, PRIMARY KEY (name))]],
})

local NAME_PAT = '^[%a][%w_%-]+$'
local registered, lastUse = {}, {}

local function count(name, who)
    DB.exec('INSERT INTO pb_cmd_usage (name, uses, last_by, last_at) VALUES (?, 1, ?, ?) ON DUPLICATE KEY UPDATE uses = uses + 1, last_by = VALUES(last_by), last_at = VALUES(last_at)',
        { name, tostring(who or ''):sub(1, 96), os.time() })
end

-- Enregistre (une seule fois) le gestionnaire d'une commande du panel ; il relit la base à chaque appel.
local function register(name)
    if registered[name] then return end
    registered[name] = true
    local c0 = DB.one('SELECT restricted FROM pb_commands WHERE name = ?', { name })
    RegisterCommand(name, function(src)
        local c = DB.one('SELECT * FROM pb_commands WHERE name = ?', { name })
        if not c or not PB.ToBool(c.enabled) then return end
        local now = os.time()
        local k = name .. ':' .. tostring(src)
        if (c.cooldown or 0) > 0 and lastUse[k] and now - lastUse[k] < c.cooldown then
            if src > 0 then TriggerClientEvent('pb:announce', src, 'Patiente encore ' .. (c.cooldown - (now - lastUse[k])) .. ' s.') end
            return
        end
        lastUse[k] = now
        if c.kind == 'broadcast' then PB.Announce(c.text, 'both')
        elseif src > 0 then TriggerClientEvent('chat:addMessage', src, { color = { 155, 140, 255 }, args = { name, c.text } }) TriggerClientEvent('pb:announce', src, c.text)
        else PB.Log('/' .. name .. ' : ' .. c.text) end
        count(name, src > 0 and (GetPlayerName(src) or src) or 'console')
    end, PB.ToBool(c0 and c0.restricted))
end

PB.OnReady(function()
    for _, c in ipairs(DB.q('SELECT name, restricted FROM pb_commands') or {}) do register(c.name) end
end)

-- Commandes tapées dans le chat : blocage et statistiques (nécessite le chat par défaut).
local blockedCfg = Form.Cfg({
    ns = 'commands', id = 'block', title = 'Blocage dans le chat', perm = 'commands.edit', cols = 1,
    desc = "Les commandes listées sont annulées quand un joueur les tape dans le chat. Les commandes lancées depuis la console ou une touche ne sont pas concernées.",
    fields = {
        { k = 'blocked', type = 'tags', label = 'Commandes bloquées (sans « / »)', default = {}, hint = 'Ex. : kill, suicide' },
        { k = 'count_chat', type = 'toggle', label = 'Compter les commandes tapées dans le chat', default = true },
    },
})

AddEventHandler('chatMessage', function(src, _, msg)
    if type(msg) ~= 'string' or msg:sub(1, 1) ~= '/' then return end
    local name = msg:match('^/([%w_%-%.]+)')
    if not name then return end
    name = name:lower()
    local blocked = PB.Cfg.Get('commands', 'blocked', {})
    for _, b in ipairs(type(blocked) == 'table' and blocked or {}) do
        if tostring(b):lower() == name then CancelEvent() TriggerClientEvent('pb:announce', src, 'Cette commande est désactivée.') return end
    end
    if PB.Cfg.Get('commands', 'count_chat', true) then count(name, GetPlayerName(src) or src) end
end)

-- Actions ---------------------------------------------------------------------------------------------------------------------------------------
PB.Action('commands.save', 'commands.edit', function(ctx, p)
    local v = p.values or {}
    local name = tostring(v.name or ''):lower()
    if not name:match(NAME_PAT) or #name < 2 or #name > 32 then return false, 'Nom invalide : lettres, chiffres, - et _ (2 à 32 caractères).' end
    local text = PB.Sanitize(tostring(v.text or ''), 400)
    if text == '' then return false, 'Le texte est obligatoire.' end
    if p.mode ~= 'edit' then
        if DB.one('SELECT name FROM pb_commands WHERE name = ?', { name }) then return false, 'Une commande du panel porte déjà ce nom.' end
        for _, c in ipairs(GetRegisteredCommands() or {}) do
            if c.name == name then return false, 'Cette commande existe déjà (' .. tostring(c.resource) .. ').' end
        end
    end
    local kind = v.kind == 'broadcast' and 'broadcast' or 'message'
    local before = DB.one('SELECT * FROM pb_commands WHERE name = ?', { name })
    DB.upsert('pb_commands', { name = name, kind = kind, text = text, description = PB.Sanitize(tostring(v.description or ''), 160),
        cooldown = PB.Clamp(PB.ToInt(v.cooldown, 0), 0, 3600), enabled = PB.ToBool(v.enabled) and 1 or 0,
        restricted = PB.ToBool(v.restricted) and 1 or 0 }, { 'name' })
    register(name)
    ctx.audit('config', before and 'commande.modifier' or 'commande.creer', name, before, { kind = kind, text = text })
    ctx.toast = before and 'Commande enregistrée.' or 'Commande /' .. name .. ' créée et active.'
    if before and PB.ToBool(before.restricted) ~= PB.ToBool(v.restricted) then ctx.toast = ctx.toast .. ' Le mode « restreinte » s\'applique au prochain redémarrage.' end
    return true
end)

PB.Action('commands.delete', 'commands.edit', function(ctx, p)
    local name = tostring(p.name or '')
    local before = DB.one('SELECT * FROM pb_commands WHERE name = ?', { name })
    if not before then return false, 'Commande introuvable.' end
    DB.exec('DELETE FROM pb_commands WHERE name = ?', { name })
    ctx.audit('config', 'commande.supprimer', name, before)
    ctx.toast = '/' .. name .. ' supprimée : elle ne répond plus (elle disparaît de la liste au prochain redémarrage).'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette commande ?', text = 'Elle cesse de répondre immédiatement.' } })

PB.Action('commands.usage.reset', 'commands.edit', function(ctx)
    DB.exec('DELETE FROM pb_cmd_usage')
    ctx.audit('config', 'commande.stats.reset', 'pb_cmd_usage')
    ctx.toast = 'Statistiques remises à zéro.'
    return true
end, { critical = true, confirm = { title = 'Remettre les statistiques à zéro ?', text = "Le compteur d'usage de toutes les commandes est effacé." } })

local ACE_PAT = '^[%w_%.%-]+$'
PB.Action('commands.access.set', 'commands.access', function(ctx, p)
    local v = p.values or {}
    local cmd, grade = tostring(v.command or ''):lower(), tostring(v.grade or '')
    if not cmd:match(ACE_PAT) then return false, 'Nom de commande invalide.' end
    if not P.Grade(grade) then return false, 'Grade introuvable.' end
    if P.Level(ctx.src) <= (P.Grade(grade).level or 0) and not P.IsOwner(ctx.src) then return false, 'Tu ne peux pas accorder une commande à un grade égal ou supérieur au tien.' end
    local allow = v.allow == 'deny' and 'deny' or 'allow'
    local line = ('add_ace group.pb_%s command.%s %s'):format(grade, cmd, allow)
    local ok, err = F.CfgApply({ { op = 'append', line = line } }, ctx.actor, 'Accès commande : ' .. line)
    if not ok then return false, err end
    P.AceExec(line)
    ctx.audit('permission', 'commande.acces', cmd, nil, { grade = grade, rule = allow })
    ctx.toast = 'Règle ajoutée au server.cfg et appliquée. Pense à marquer la commande comme restreinte si son script ne l\'est pas.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Ajouter cette règle d\'accès ?', text = 'Elle est écrite dans le server.cfg et appliquée immédiatement.' } })

-- Vue -----------------------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'commands', label = 'Commandes', icon = 'terminal', group = 'Pilotage', order = 30, perm = 'commands.view', hint = 'Inventaire, accès, commandes du panel',
    caps = function()
        return PB.Capsify({
            { 'Lister les commandes enregistrées', 'ok', 'Via GetRegisteredCommands.' },
            { 'Créer des commandes (message, annonce)', 'ok', 'Enregistrées par le panel, avec délai entre deux usages.' },
            { 'Restreindre une commande à un grade', F.ServerCfgPath() and 'ok' or 'off', F.ServerCfgPath() and 'Règle ACE écrite dans le server.cfg.' or 'server.cfg introuvable.' },
            { 'Bloquer une commande', 'partial', 'Uniquement quand elle est tapée dans le chat.' },
            { 'Supprimer une commande d\'une autre ressource', 'off', 'Impossible avec FiveM : restreins-la ou bloque-la.' },
            { 'Alias / exécution de commandes arbitraires', 'off', 'Volontairement absent : ce serait une porte d\'escalade de privilèges.' },
        })
    end,
    doc = "## Commandes\nListe toutes les commandes du serveur et en crée de simples (message, annonce). Les restrictions utilisent le système ACE, donc les mêmes grades que le reste du panel.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('list', 'Inventaire', 'list', function()
                local usage = {}
                for _, u in ipairs(DB.q('SELECT * FROM pb_cmd_usage') or {}) do usage[u.name] = u end
                local mine = {}
                for _, c in ipairs(DB.q('SELECT name FROM pb_commands') or {}) do mine[c.name] = true end
                local rows, per = {}, {}
                for _, c in ipairs(GetRegisteredCommands() or {}) do
                    local u = usage[c.name]
                    rows[#rows + 1] = { name = '/' .. c.name, res = c.resource or '?', origin = mine[c.name] and { text = 'Panel', tone = 'ok' } or 'Ressource',
                        uses = u and u.uses or 0, last = u and u.last_by or '' }
                    per[c.resource or '?'] = (per[c.resource or '?'] or 0) + 1
                end
                table.sort(rows, function(a, b) return a.name < b.name end)
                return {
                    B.stats({ { label = 'Commandes', value = #rows, icon = 'terminal' }, { label = 'Ressources', value = PB.Count(per), icon = 'box' }, { label = 'Commandes du panel', value = PB.Count(mine), icon = 'sliders' } }),
                    B.table({ id = 'cmds', search = true, columns = { { k = 'name', label = 'Commande', type = 'mono' }, { k = 'res', label = 'Ressource' }, { k = 'origin', label = 'Origine', type = 'badge' }, { k = 'uses', label = 'Usages', type = 'num' }, { k = 'last', label = 'Dernier usage' } }, rows = rows, empty = 'Aucune commande enregistrée.' }),
                }
            end),
            tab('custom', 'Commandes du panel', 'plus', function()
                local list = DB.q('SELECT * FROM pb_commands ORDER BY name') or {}
                local rows = {}
                for _, c in ipairs(list) do
                    rows[#rows + 1] = { name = '/' .. c.name, kind = c.kind == 'broadcast' and 'Annonce à tous' or 'Message au joueur', text = c.text, cd = c.cooldown, on = PB.ToBool(c.enabled),
                        actions = { { action = 'commands.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { name = c.name } } } }
                end
                return {
                    B.table({ id = 'mine', title = 'Commandes créées', columns = { { k = 'name', label = 'Commande', type = 'mono' }, { k = 'kind', label = 'Type' }, { k = 'text', label = 'Texte' }, { k = 'cd', label = 'Délai (s)', type = 'num' }, { k = 'on', label = 'Active', type = 'bool' } }, rows = rows, empty = 'Aucune commande créée.' }),
                    { type = 'form', id = 'cmd.new', title = 'Créer une commande', cols = 2, fields = {
                        { k = 'name', type = 'text', label = 'Nom (sans « / »)', required = true, maxlen = 32, pattern = '^[%a][%w_%-]+$' },
                        { k = 'kind', type = 'select', label = 'Type', options = { { 'message', 'Message au joueur' }, { 'broadcast', 'Annonce à tous' } } },
                        { k = 'text', type = 'text', label = 'Texte', required = true, maxlen = 400 },
                        { k = 'description', type = 'text', label = 'Description', maxlen = 160 },
                        { k = 'cooldown', type = 'number', label = 'Délai entre deux usages (s)', min = 0, max = 3600 },
                        { k = 'enabled', type = 'toggle', label = 'Active' },
                        { k = 'restricted', type = 'toggle', label = 'Restreinte (ACE obligatoire)', hint = 'Demande une règle d\'accès dans l\'onglet Accès.' },
                    }, values = { kind = 'message', cooldown = 0, enabled = true, restricted = false }, submit = { action = 'commands.save', label = 'Créer', payload = { mode = 'create' } } },
                }
            end, 'commands.edit'),
            tab('access', 'Accès', 'lock', function()
                local opts, gopts = {}, {}
                for _, c in ipairs(GetRegisteredCommands() or {}) do opts[#opts + 1] = { c.name, '/' .. c.name } end
                table.sort(opts, function(a, b) return a[1] < b[1] end)
                for _, g in ipairs(P.Grades()) do gopts[#gopts + 1] = { g.name, g.label } end
                return {
                    B.notice('info', "Une commande déclarée « restreinte » par son script n'est utilisable que par les groupes qui ont la règle ACE correspondante. Ce formulaire ajoute cette règle pour un grade du panel.", 'Comment ça marche'),
                    { type = 'form', id = 'cmd.access', title = 'Accorder ou refuser une commande à un grade', cols = 3, fields = {
                        { k = 'command', type = 'select', label = 'Commande', options = opts, required = true },
                        { k = 'grade', type = 'select', label = 'Grade', options = gopts, required = true },
                        { k = 'allow', type = 'select', label = 'Règle', options = { { 'allow', 'Autoriser' }, { 'deny', 'Refuser' } } },
                    }, values = { allow = 'allow' }, submit = { action = 'commands.access.set', label = 'Appliquer' } },
                }
            end, 'commands.access'),
            tab('block', 'Blocage', 'ban', function() return { blockedCfg(ctx) } end),
            tab('usage', 'Statistiques', 'chart', function()
                local rows = {}
                for _, u in ipairs(DB.q('SELECT * FROM pb_cmd_usage ORDER BY uses DESC LIMIT 100') or {}) do
                    rows[#rows + 1] = { name = '/' .. u.name, uses = u.uses, by = u.last_by, at = u.last_at }
                end
                return {
                    B.table({ id = 'usage', columns = { { k = 'name', label = 'Commande', type = 'mono' }, { k = 'uses', label = 'Usages', type = 'num' }, { k = 'by', label = 'Dernier joueur' }, { k = 'at', label = 'Dernière fois', type = 'date' } }, rows = rows, empty = "Aucun usage enregistré pour l'instant." }),
                    B.actions({ { action = 'commands.usage.reset', label = 'Remettre à zéro', icon = 'trash', danger = true } }),
                }
            end),
        } }
    end,
})
