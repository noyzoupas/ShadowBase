-- Auto-test : /testall (en jeu pour les grades autorisés, ou « testall » dans la console).
-- Construit chaque module et chaque onglet, vérifie les boutons (action existante), les formulaires (valeurs valides), les tables SQL
-- et les tests propres à chaque module (PB.SelfTest.Add). Il ne modifie rien : aucun bouton n'est « cliqué », aucune donnée n'est écrite.
-- Chaque nouveau module ajoute ses vérifications avec PB.SelfTest.Add('nom', function(R) ... end).

PB.SelfTest = PB.SelfTest or { custom = {}, last = nil }
local ST = PB.SelfTest
PB.Perm.Register('selftest.run', "Lancer l'auto-test du panel (/testall)", 'system')

-- R.ok(label) / R.fail(label, détail) / R.warn(label, détail)
function ST.Add(name, fn) ST.custom[#ST.custom + 1] = { name = name, fn = fn } end

local function walk(node, fn, path)
    if type(node) ~= 'table' then return end
    fn(node, path)
    for k, v in pairs(node) do if type(v) == 'table' then walk(v, fn, path) end end
end

local function make()
    local R = { items = {}, passed = 0, failed = 0, warned = 0, t0 = os.time() }
    R.ok = function() R.passed = R.passed + 1 end
    R.fail = function(where, label, detail) R.failed = R.failed + 1 R.items[#R.items + 1] = { level = 'fail', where = where, label = label, detail = tostring(detail or '') } end
    R.warn = function(where, label, detail) R.warned = R.warned + 1 R.items[#R.items + 1] = { level = 'warn', where = where, label = label, detail = tostring(detail or '') } end
    R.check = function(cond, where, label, detail) if cond then R.ok() else R.fail(where, label, detail) end end
    return R
end

local function checkBlocks(R, where, blocks)
    walk(blocks, function(n)
        if type(n.action) == 'string' then
            R.check(PB.ActionExists(n.action), where, 'bouton sans action : « ' .. n.action .. ' »', (n.label or n.title or ''))
        end
        if n.submit and type(n.submit) == 'table' and type(n.submit.action) == 'string' then
            R.check(PB.ActionExists(n.submit.action), where, 'formulaire sans action : « ' .. n.submit.action .. ' »', n.id)
        end
        if n.save and type(n.save) == 'table' and type(n.save.action) == 'string' then
            R.check(PB.ActionExists(n.save.action), where, 'bouton Enregistrer sans action : « ' .. n.save.action .. ' »', n.id)
        end
        if n.type == 'form' then
            R.check(type(n.fields) == 'table' and type(n.values) == 'table', where, 'formulaire incomplet', n.id)
            local function chk(list)
                for _, f in ipairs(list or {}) do
                    if f.type == 'group' then
                        R.check(f.label and type(f.fields) == 'table', where, 'groupe incomplet', n.id .. '/' .. tostring(f.label))
                        chk(f.fields)
                    elseif f.type == 'info' then R.check(f.label or f.text, where, 'champ incomplet', n.id .. '/info')
                    else R.check(f.k and f.type and f.label, where, 'champ incomplet', n.id .. '/' .. tostring(f.k)) end
                end
            end
            chk(n.fields)
            -- les valeurs actuelles doivent passer leur propre validation (sinon l'enregistrement échouerait sans que l'admin ait rien changé)
            if type(n.fields) == 'table' and type(n.values) == 'table' and n.submit and n.submit.action and tostring(n.submit.action):match('^cfg%.') then
                local ok, clean, err = pcall(PB.Validate, n.fields, n.values)
                if not ok then R.fail(where, 'validation en erreur', n.id .. ' : ' .. tostring(clean))
                elseif not clean then R.fail(where, 'valeurs actuelles invalides', n.id .. ' : ' .. tostring(err)) else R.ok() end
            end
        elseif n.type == 'table' then
            R.check(type(n.columns) == 'table' and type(n.rows) == 'table', where, 'table incomplète', n.id)
        elseif n.type == 'gpreview' then
            R.check(type(n.kind) == 'string', where, 'aperçu sans type', n.id)
        end
    end)
end

local function testModules(R, ctx)
    for _, m in ipairs(PB.Modules.list) do
        local where = 'module ' .. m.id
        R.check(type(m.view) == 'function', where, 'pas de fonction view')
        local ok, view = pcall(m.view, ctx, { all = true })
        if not ok then R.fail(where, 'la vue plante', view)
        else
            R.ok()
            R.check(type(view) == 'table' and type(view.tabs) == 'table' and #view.tabs > 0, where, 'aucun onglet')
            for _, t in ipairs((view and view.tabs) or {}) do
                local w = where .. '/' .. tostring(t.id)
                local blocks = t.blocks
                if t.build then
                    local okb, b = pcall(t.build, ctx, { all = true, tab = t.id })
                    if okb then blocks = b else R.fail(w, "l'onglet plante", b) blocks = nil end
                end
                if blocks then R.ok() checkBlocks(R, w, blocks) end
            end
        end
        if m.caps then
            local okc, caps = pcall(m.caps)
            R.check(okc, where, 'la table de compatibilité plante', caps)
        end
    end
end

local function testActions(R)
    -- toute action dont la permission est une chaîne doit désigner une permission déclarée dans le catalogue
    local known = {}
    for _, p in ipairs(PB.Perm.Catalog()) do known[p.perm] = true end
    for name, a in pairs(PB.ActionList()) do
        if type(a.perm) == 'string' then R.check(known[a.perm], 'action ' .. name, 'permission non déclarée : ' .. a.perm) end
    end
end

local function testGame(R)
    local G = PB.G
    if not G then return end
    local ok, js = pcall(function() return PB.Json(G.ClientConfig()) end)
    R.check(ok and type(js) == 'string' and #js > 2, 'jeu', 'la configuration client ne se sérialise pas', js)
    for _, t in ipairs({ 'pb_players', 'pb_vehicles', 'pb_shops' }) do
        local okq, e = pcall(PB.DB.one, 'SELECT 1 AS x FROM ' .. t .. ' LIMIT 1')
        R.check(okq, 'base de données', 'table manquante ou illisible : ' .. t, e)
    end
    local okc = pcall(function() return G.ShopList() end)
    R.check(okc, 'jeu', 'la liste des magasins plante')
end

function ST.Run(src)
    local R = make()
    local ctx = PB.MakeCtx(src)
    -- en console (src 0) il n'y a pas de grade : on teste comme un propriétaire
    if src == 0 then ctx.has = function() return true end end
    local okm, e = pcall(testModules, R, ctx)
    if not okm then R.fail('auto-test', 'erreur interne pendant les modules', e) end
    pcall(testActions, R)
    local okg, eg = pcall(testGame, R)
    if not okg then R.fail('jeu', 'erreur interne', eg) end
    for _, c in ipairs(ST.custom) do
        local okc, err = pcall(c.fn, R, ctx)
        if not okc then R.fail('test ' .. c.name, 'le test plante', err) end
    end
    R.secs = os.time() - R.t0
    local out = { at = os.time(), passed = R.passed, failed = R.failed, warned = R.warned, secs = R.secs, items = R.items, modules = #PB.Modules.list }
    ST.last = out
    return out
end

local function printReport(r)
    print(('^5[pb_panel] /testall^7 : %d vérifications OK, ^%d%d échec(s)^7, %d avertissement(s) — %d modules'):format(r.passed, r.failed > 0 and 1 or 2, r.failed, r.warned, r.modules))
    for _, it in ipairs(r.items) do
        print(('  %s [%s] %s%s'):format(it.level == 'fail' and '^1✗^7' or '^3!^7', it.where, it.label, it.detail ~= '' and (' — ' .. it.detail) or ''))
    end
end

RegisterCommand('testall', function(src)
    if src ~= 0 and not PB.Perm.Has(src, 'selftest.run') then return end
    local r = ST.Run(src)
    printReport(r)
    if src ~= 0 then
        local msg = ('Auto-test : %d OK, %d échec(s), %d avertissement(s).'):format(r.passed, r.failed, r.warned)
        if PB.G and PB.G.Notify then PB.G.Notify(src, { type = r.failed > 0 and 'error' or 'success', title = '/testall', text = msg .. (r.failed > 0 and ' Détails dans la console du serveur et dans le panel > Auto-test.' or ''), duration = 9000 }) end
        TriggerClientEvent('chat:addMessage', src, { args = { 'testall', msg } })
    end
end, false)

PB.Action('selftest.run', 'selftest.run', function(ctx)
    local r = ST.Run(ctx.src)
    printReport(r)
    ctx.audit('config', 'selftest.run', 'panel', nil, { passed = r.passed, failed = r.failed })
    ctx.toast = ('%d OK, %d échec(s), %d avertissement(s).'):format(r.passed, r.failed, r.warned)
    return true
end, { read = true })

PB.Module({
    id = 'selftest', label = 'Auto-test', icon = 'check', group = 'Système', order = 215, perm = 'selftest.run', hint = '/testall : vérifie tous les modules',
    doc = "## Auto-test\nLa commande **/testall** (en jeu, ou `testall` dans la console) construit chaque module et chaque onglet, vérifie que chaque bouton a une action, que chaque formulaire accepte ses propres valeurs, que les tables SQL existent, puis lance les tests propres à chaque module.\n\nElle **ne clique pas** sur les boutons et n'écrit rien : c'est un contrôle sans risque, à relancer après chaque mise à jour.",
    view = function(ctx)
        return { tabs = { { id = 'run', label = 'Résultats', icon = 'check', build = function()
            local r = ST.last
            local blocks = { PB.B.actions({ { action = 'selftest.run', label = "Lancer l'auto-test", icon = 'play' } }) }
            if not r then blocks[#blocks + 1] = PB.B.notice('info', "Aucun test lancé depuis le démarrage. Clique sur le bouton, ou tape /testall en jeu.") return blocks end
            blocks[#blocks + 1] = PB.B.stats({ { label = 'Vérifications OK', value = r.passed, icon = 'check' }, { label = 'Échecs', value = r.failed, icon = 'alert' }, { label = 'Avertissements', value = r.warned, icon = 'info' }, { label = 'Modules testés', value = r.modules, icon = 'grid' } })
            local rows = {}
            for _, it in ipairs(r.items) do rows[#rows + 1] = { level = it.level == 'fail' and 'Échec' or 'Avertissement', where = it.where, label = it.label, detail = it.detail } end
            blocks[#blocks + 1] = PB.B.table({ id = 'selftest', columns = { { k = 'level', label = 'Niveau' }, { k = 'where', label = 'Où', type = 'mono' }, { k = 'label', label = 'Problème' }, { k = 'detail', label = 'Détail' } }, rows = rows,
                empty = 'Aucun problème détecté.' })
            return blocks
        end } } }
    end,
})
