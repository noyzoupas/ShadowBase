-- Noyau des interfaces et scripts en jeu : joueurs (identité, apparence, statuts, argent), configuration envoyée aux clients, exports.
-- Autonome : tables propres (pb_players, pb_vehicles), aucun framework requis. Si ESX / QBCore est installé, ne lance pas deux systèmes de personnages en même temps.

PB.G = PB.G or {}
local G = PB.G
local DB, P = PB.DB, PB.Perm

PB.Migrate('040_game_players', 'Joueurs (identité, apparence, statuts, argent)', {
    [[CREATE TABLE IF NOT EXISTS pb_players (
        license VARCHAR(64) NOT NULL, firstname VARCHAR(32) NOT NULL DEFAULT '', lastname VARCHAR(32) NOT NULL DEFAULT '',
        dob VARCHAR(10) NOT NULL DEFAULT '', sex VARCHAR(1) NOT NULL DEFAULT 'm', height INT NOT NULL DEFAULT 175, nationality VARCHAR(32) NOT NULL DEFAULT '',
        appearance MEDIUMTEXT NULL, hunger DOUBLE NOT NULL DEFAULT 100, thirst DOUBLE NOT NULL DEFAULT 100, stress DOUBLE NOT NULL DEFAULT 0,
        cash BIGINT NOT NULL DEFAULT 0, bank BIGINT NOT NULL DEFAULT 0, dead TINYINT(1) NOT NULL DEFAULT 0, created TINYINT(1) NOT NULL DEFAULT 0,
        last_seen INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_vehicles (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, plate VARCHAR(8) NOT NULL, model VARCHAR(48) NOT NULL, label VARCHAR(64) NOT NULL DEFAULT '',
        bought_at INT NOT NULL DEFAULT 0, price BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (id), UNIQUE KEY uq_plate (plate))]],
})

P.Register('game.view', 'Voir les interfaces en jeu', 'game')

G.beginHooks = {}
local NS = { 'hud', 'death', 'character', 'notify', 'chat', 'interact', 'biz', 'flow', 'inv', 'bank', 'garage', 'housing', 'phone', 'civil', 'menus', 'quick', 'personal', 'staff', 'tags', 'justice', 'ctx', 'fuel', 'mech', 'crime', 'weapons', 'territories', 'flags', 'me3d', 'tablets', 'pause', 'graffiti', 'trunk', 'place', 'animmenu', 'rental' }
local players = {}        -- src -> { license, row, dirty }
local STATUS = { hunger = true, thirst = true, stress = true }

local function row(license)
    local r = DB.one('SELECT * FROM pb_players WHERE license = ?', { license })
    if r then return r end
    DB.exec('INSERT INTO pb_players (license, last_seen) VALUES (?, ?)', { license, os.time() })
    return DB.one('SELECT * FROM pb_players WHERE license = ?', { license })
end

-- Configuration envoyée aux clients ------------------------------------------------------------------------------------------------
function G.ClientConfig()
    local c = {}
    for _, ns in ipairs(NS) do c[ns] = PB.Cfg.All(ns) or {} end
    c.staffmenu = PB.Cfg.Get('interface', 'staffmenu')
    c.gta_police = PB.Cfg.Get('world', 'police_wanted', false) == true   -- serveur GTA RP : par défaut aucune étoile ni police du jeu
    c.ui = { glass = PB.Cfg.Get('interface', 'glass_level', 'solid') }
    c.shops = G.ShopList and G.ShopList() or {}
    c.shops_settings = PB.Cfg.All('shops')
    c.stashes = G.StashList and G.StashList() or {}
    c.bank_points = G.BankPoints and G.BankPoints() or {}
    c.garage_points = G.GaragePoints and G.GaragePoints() or {}
    c.housing_points = G.HousingPoints and G.HousingPoints() or {}
    c.civil_points = G.CivilPoints and G.CivilPoints() or {}
    local season = PB.Season and PB.Season.Info()
    local fest = season and season.game and season or nil   -- fête active ET appliquée au jeu
    c.brand = { name = PB.Cfg.Get('general', 'server_name', ''), color = fest and fest.color or PB.Cfg.Get('general', 'color_primary', '#dfe2e7'), color2 = fest and fest.color2 or PB.Cfg.Get('general', 'color_secondary', '#8e95a1'), logo = PB.Cfg.Get('general', 'server_logo', ''), banner = PB.Cfg.Get('general', 'server_banner', ''),
        season = fest and { id = fest.id, decor = fest.decor } or nil }
    return c
end

local pushPending = false
function G.PushConfig(target)
    if target then TriggerClientEvent('pb:g:cfg', target, PB.Json(G.ClientConfig())) return end
    if pushPending then return end
    pushPending = true
    SetTimeout(300, function() pushPending = false TriggerClientEvent('pb:g:cfg', -1, PB.Json(G.ClientConfig())) end)
end
for _, ns in ipairs(NS) do PB.Cfg.OnChange(ns, function() G.PushConfig() end) end
PB.Cfg.OnChange('shops', function() G.PushConfig() end)
PB.Cfg.OnChange('interface', function(k) if k == 'staffmenu' or k == 'glass_level' then G.PushConfig() end end)
PB.Cfg.OnChange('general', function() G.PushConfig() end)
PB.Cfg.OnChange('world', function(k) if k == 'police_wanted' then G.PushConfig() end end)
-- Mode automatique : la fête change à minuit sans que personne ne touche à rien
local lastFest = PB.Season and PB.Season.Current() or nil
CreateThread(function()
    while true do
        Wait(600000)
        local cur = PB.Season and PB.Season.Current() or nil
        if cur ~= lastFest then lastFest = cur G.PushConfig() if PB.PushBrand then PB.PushBrand() end end
    end
end)

-- Joueurs -----------------------------------------------------------------------------------------------------------------------------
function G.Get(src) return players[tonumber(src) or -1] end

local function snapshot(p)
    local r = p.row
    return { hunger = math.floor(r.hunger + 0.5), thirst = math.floor(r.thirst + 0.5), stress = math.floor(r.stress + 0.5), cash = r.cash, bank = r.bank, dead = PB.ToBool(r.dead) }
end

function G.PushState(src)
    local p = players[src]
    if p then TriggerClientEvent('pb:g:state', src, PB.Json(snapshot(p))) end
end

local function save(p)
    if not p or not p.dirty then return end
    local r = p.row
    DB.exec('UPDATE pb_players SET hunger = ?, thirst = ?, stress = ?, cash = ?, bank = ?, dead = ?, last_pos = ?, last_seen = ? WHERE license = ?',
        { r.hunger, r.thirst, r.stress, r.cash, r.bank, PB.ToBool(r.dead) and 1 or 0, r.last_pos or '', os.time(), p.license })
    p.dirty = false
end

-- Dernière position (reconnexion à l'endroit de la déconnexion) : lue par le serveur (OneSync), jamais envoyée par le client.
-- Pas de relevé en prison ni dans une instance (intérieur, création) : on garde la position précédente.
local function capturePos(src, p)
    if not p or not PB.ToBool(p.row.created) then return end
    pcall(function()
        if G.IsJailed and G.IsJailed(src) then return end
        if GetPlayerRoutingBucket and (tonumber(GetPlayerRoutingBucket(src)) or 0) ~= 0 then return end
        local ped = GetPlayerPed(src)
        if not ped or ped == 0 then return end
        local c = GetEntityCoords(ped)
        if not c or (math.abs(c.x) < 1.0 and math.abs(c.y) < 1.0) or c.z < -50.0 or c.z > 2000.0 then return end
        local h = GetEntityHeading and GetEntityHeading(ped) or 0.0
        local pos = ('{"x":%.2f,"y":%.2f,"z":%.2f,"h":%.1f}'):format(c.x, c.y, c.z, tonumber(h) or 0.0)
        if pos ~= p.row.last_pos then p.row.last_pos = pos p.dirty = true end
    end)
end

function G.SaveAll() for src, p in pairs(players) do capturePos(src, p) save(p) end end
-- relevé régulier : la position reste à jour même si le serveur s'arrête brutalement
CreateThread(function() while true do Wait(120000) for src, p in pairs(players) do capturePos(src, p) save(p) end end end)

function G.Identity(src)
    local p = players[src]
    if not p then return nil end
    local r = p.row
    return { firstname = r.firstname, lastname = r.lastname, dob = r.dob, sex = r.sex, height = r.height, nationality = r.nationality, created = PB.ToBool(r.created) }
end

function G.Appearance(src)
    local p = players[src]
    return p and PB.FromJson(p.row.appearance, nil) or nil
end

function G.Begin(src)
    local license = P.GetLicense(src)
    if not license then DropPlayer(src, 'Identifiant Rockstar introuvable.') return end
    local p = { license = license, row = row(license), dirty = false }
    players[src] = p
    if p.row.created == 0 and not PB.Cfg.Get('character', 'enabled', true) then
        p.row.created = 1
        DB.exec('UPDATE pb_players SET created = 1 WHERE license = ?', { license })
    end
    G.PushConfig(src)
    G.PushState(src)
    for _, fn in ipairs(G.beginHooks) do pcall(fn, src, p) end
    -- reconnexion à la dernière position (réglage Personnage > « Reconnexion à la dernière position ») ; en prison, la justice place déjà le joueur
    local pos
    if PB.Cfg.Get('character', 'spawn_last', true) ~= false and PB.ToBool(p.row.created) and not (G.IsJailed and G.IsJailed(src)) then
        local t = PB.FromJson(p.row.last_pos or '', nil)
        if type(t) == 'table' and tonumber(t.x) and tonumber(t.y) and tonumber(t.z) then
            pos = { x = tonumber(t.x), y = tonumber(t.y), z = tonumber(t.z), h = tonumber(t.h) or 0 }
            if G.AC and G.AC.Grace then G.AC.Grace(src, 20) end
        end
    end
    TriggerClientEvent('pb:g:begin', src, PB.Json({ created = PB.ToBool(p.row.created), dead = PB.ToBool(p.row.dead), appearance = PB.FromJson(p.row.appearance, nil), sex = p.row.sex, identity = G.Identity(src), pos = pos }))
end
RegisterNetEvent('pb:clientReady', function() G.Begin(source) end)

AddEventHandler('playerDropped', function()
    local src = source
    capturePos(src, players[src])
    save(players[src])
    players[src] = nil
end)

-- Statuts (faim, soif, stress) et argent : le serveur fait foi, le client ne fait qu'afficher --------------------------------------------------------------
function G.AddStatus(src, name, delta)
    local p = players[tonumber(src) or -1]
    if not p or not STATUS[name] then return false end
    delta = tonumber(delta)
    if not delta or delta ~= delta then return false end
    p.row[name] = PB.Clamp(p.row[name] + delta, 0, 100)
    p.dirty = true
    G.PushState(tonumber(src))
    return true
end

function G.GetStatus(src, name)
    local p = players[tonumber(src) or -1]
    return p and STATUS[name] and p.row[name] or nil
end

function G.GetMoney(src, account)
    local p = players[tonumber(src) or -1]
    if not p or (account ~= 'cash' and account ~= 'bank') then return nil end
    return p.row[account]
end

function G.AddMoney(src, account, amount, reason)
    local p = players[tonumber(src) or -1]
    amount = math.floor(tonumber(amount) or 0)
    if not p or (account ~= 'cash' and account ~= 'bank') or amount <= 0 then return false end
    p.row[account] = p.row[account] + amount
    p.dirty = true
    G.PushState(tonumber(src))
    return true
end

function G.RemoveMoney(src, account, amount, reason)
    local p = players[tonumber(src) or -1]
    amount = math.floor(tonumber(amount) or 0)
    if not p or (account ~= 'cash' and account ~= 'bank') or amount <= 0 then return false end
    if p.row[account] < amount then return false end
    p.row[account] = p.row[account] - amount
    p.dirty = true
    G.PushState(tonumber(src))
    return true
end

-- Paiement : espèces d'abord ou banque d'abord selon le réglage du magasin ; renvoie le compte débité.
function G.Pay(src, amount, prefer)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return 'cash' end
    local order = prefer == 'bank' and { 'bank', 'cash' } or { 'cash', 'bank' }
    for _, acc in ipairs(order) do
        if (G.GetMoney(src, acc) or 0) >= amount then
            G.RemoveMoney(src, acc, amount)
            return acc
        end
    end
    return nil
end

function G.SetDead(src, dead)
    local p = players[tonumber(src) or -1]
    if not p then return false end
    p.row.dead = dead and 1 or 0
    p.dirty = true
    save(p)
    G.PushState(tonumber(src))
    return true
end

function G.Revive(src)
    src = tonumber(src)
    if not players[src] then return false end
    if PB.AC then PB.AC.Grace(src, 15) end
    G.SetDead(src, false)
    TriggerClientEvent('pb:g:revive', src)
    return true
end

-- Fiche d'informations affichée à côté du menu (au lieu d'une notification) : G.Info(src, { title = 'Informations', rows = { { 'Nom', 'Camille' }, … } })
function G.Info(src, n)
    if type(n) ~= 'table' or type(n.rows) ~= 'table' then return end
    local rows = {}
    for i = 1, math.min(#n.rows, 16) do
        local r = n.rows[i]
        if type(r) == 'table' then rows[#rows + 1] = { tostring(r[1] or ''):sub(1, 40), tostring(r[2] == nil and '' or r[2]):sub(1, 90) } end
    end
    TriggerClientEvent('pb:g:info', src, PB.Json({ title = tostring(n.title or 'Informations'):sub(1, 40), rows = rows, secs = math.max(4, math.min(60, tonumber(n.secs) or 14)) }))
end

function G.Notify(src, n)
    if type(n) ~= 'table' then return end
    TriggerClientEvent('pb:g:notify', src, PB.Json({ type = n.type or 'info', title = n.title, text = tostring(n.text or ''):sub(1, 400), duration = n.duration, click = (n.click == 'reports') and 'reports' or nil, kind = (n.kind == 'announce') and 'announce' or nil }))
end

-- Boucle de statuts : toutes les 10 s, un seul message par joueur et seulement si une valeur affichée change.
CreateThread(function()
    local tick = 0
    while true do
        Wait(10000)
        tick = tick + 1
        local hungerRate = PB.Cfg.Get('hud', 'hunger_rate', 1.0)    -- points perdus par minute
        local thirstRate = PB.Cfg.Get('hud', 'thirst_rate', 1.4)
        local stressDecay = PB.Cfg.Get('hud', 'stress_decay', 0.5)
        local enabled = PB.Cfg.Get('hud', 'needs_enabled', true)
        for src, p in pairs(players) do
            local r = p.row
            if enabled and r.created ~= 0 and not PB.ToBool(r.dead) then
                local before = snapshot(p)
                r.hunger = PB.Clamp(r.hunger - hungerRate / 6, 0, 100)
                r.thirst = PB.Clamp(r.thirst - thirstRate / 6, 0, 100)
                r.stress = PB.Clamp(r.stress - stressDecay / 6, 0, 100)
                p.dirty = true
                local after = snapshot(p)
                if after.hunger ~= before.hunger or after.thirst ~= before.thirst or after.stress ~= before.stress then G.PushState(src) end
                if r.hunger <= 0 or r.thirst <= 0 then TriggerClientEvent('pb:g:starve', src, PB.Cfg.Get('hud', 'starve_damage', 2)) end
            end
            if tick % 6 == 0 then save(p) end
        end
    end
end)

-- Exports pour tes autres scripts (nourriture, boissons, boutiques, métiers…) ------------------------------------------------------------
exports('AddStatus', function(src, name, delta) return G.AddStatus(src, name, delta) end)
exports('GetStatus', function(src, name) return G.GetStatus(src, name) end)
exports('AddMoney', function(src, account, amount, reason) return G.AddMoney(src, account, amount, reason) end)
exports('RemoveMoney', function(src, account, amount, reason) return G.RemoveMoney(src, account, amount, reason) end)
exports('GetMoney', function(src, account) return G.GetMoney(src, account) end)
exports('GetIdentity', function(src) return G.Identity(src) end)
exports('IsDead', function(src) local p = players[tonumber(src) or -1] return p and PB.ToBool(p.row.dead) or false end)
exports('Revive', function(src) return G.Revive(src) end)
exports('Notify', function(src, n) return G.Notify(src, n) end)

-- Restauration d'un statut quand un script de nourriture appelle l'événement ESX / QB classique n'est volontairement pas faite :
-- utilise exports.pb_panel:AddStatus(src, 'hunger', 25).

function G.Players() return players end
