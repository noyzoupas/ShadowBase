-- Activités illégales : filières (récolte, transformation, vente — drogues ou autre), braquages et blanchiment.
-- Tout est une liste de points réglable dans le panel. Le serveur démarre l'action (distance, objets, policiers en service, délai), le joueur
-- reste sur place pendant la durée, puis le serveur revérifie (temps écoulé, distance) avant de donner le résultat.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local C = {}
G.Crime = C

P.Register('crime.edit', 'Modifier les activités illégales (filières, braquages, blanchiment)', 'crime', true)

local CHAIN = {
    { id = 'weed_field', kind = 'harvest', label = 'Champ de cannabis', x = 2224.4, y = 5577.2, z = 53.8, radius = 6, item_in = '', qty_in = 0, item_out = 'weed', qty_out = 3, price = 0, time = 8, alert = 0 },
    { id = 'weed_lab', kind = 'process', label = 'Labo de séchage', x = 1391.3, y = 3605.9, z = 38.9, radius = 3, item_in = 'weed', qty_in = 3, item_out = 'joint', qty_out = 5, price = 0, time = 10, alert = 0 },
    { id = 'weed_dealer', kind = 'sell', label = 'Revendeur de rue', x = 115.4, y = -1949.8, z = 20.8, radius = 3, item_in = 'joint', qty_in = 1, item_out = '', qty_out = 0, price = 45, time = 6, alert = 25 },
}
local HEISTS = {
    { id = 'store_rob', label = 'Braquage de supérette', x = 24.5, y = -1346.7, z = 29.5, radius = 4, min = 800, max = 2200, time = 30, cooldown = 30, police = 0, need = '', alert = 100, ped = 'mp_m_shopkeep_01', h = 271.0 },
    { id = 'jewel', label = 'Bijouterie', x = -622.2, y = -230.9, z = 38.1, radius = 4, min = 6000, max = 14000, time = 60, cooldown = 90, police = 0, need = 'lockpick', alert = 100 },
}
local LAUNDER = { { id = 'wash', label = 'Laverie du port', x = 1123.6, y = -3194.0, z = -40.4, rate = 70, max = 20000, time = 12 } }
PB.Cfg.Define('crime', { enabled = true, need_weapon = true, black_money = true, dirty_item = 'black_money', use_dist = 2.5, max_sell = 3, raw_mult = 0.4, show_markers = true, show_blips = false, chain = CHAIN, heists = HEISTS, launder = LAUNDER })
local function cfg(k, d) return PB.Cfg.Get('crime', k, d) end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function owner(src) local p = G.Get(src) return p and ('p:' .. p.license) end
local Inv = function() return G.Inv end

-- objets de filière par défaut (créés une fois, modifiables dans Inventaire › Objets)
PB.Migrate('077_crime_items', 'Activités illégales : objets', function()
    for _, d in ipairs({ { 'weed', 'Cannabis brut', 80, 50, 'misc' }, { 'joint', 'Joint', 10, 100, 'misc' } }) do
        DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable) VALUES (?, ?, ?, ?, ?, 0)', d)
    end
end)

-- Drogues prêtes à l'emploi (Builder du menu staff) : produit brut récolté, pochon transformé, prix d'un pochon.
-- Tout pèse lourd exprès : sans sac à dos, on ne transporte pas grand-chose.
C.DRUGS = {
    weed = { label = 'Cannabis', raw = { 'weed', 'Cannabis brut', 1500 }, pouch = { 'weed_pouch', 'Pochon de cannabis', 1000 }, price = 120 },
    coke = { label = 'Cocaïne', raw = { 'coca_leaf', 'Feuilles de coca', 1500 }, pouch = { 'coke_pouch', 'Pochon de cocaïne', 1000 }, price = 260 },
    meth = { label = 'Méthamphétamine', raw = { 'meth_raw', 'Produits chimiques', 1500 }, pouch = { 'meth_pouch', 'Pochon de méthamphétamine', 1000 }, price = 220 },
    heroin = { label = 'Héroïne', raw = { 'poppy', 'Opium brut', 1500 }, pouch = { 'heroin_pouch', "Pochon d'héroïne", 1000 }, price = 200 },
    ecstasy = { label = 'Ecstasy', raw = { 'mdma_raw', 'Cristaux de MDMA', 1500 }, pouch = { 'ecstasy_pouch', "Sachet d'ecstasy", 1000 }, price = 160 },
}
C.DRUG_ORDER = { 'weed', 'coke', 'meth', 'heroin', 'ecstasy' }
-- Crée les objets d'une drogue (un objet déjà créé garde ses réglages, sauf l'ancien poids par défaut, trop léger)
function C.EnsureDrug(key)
    local d = C.DRUGS[key]
    if not d then return nil end
    for _, it in ipairs({ d.raw, d.pouch }) do
        DB.exec("INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, 50, 'misc', 0, ?)", { it[1], it[2], it[3], 'Marchandise illégale (' .. d.label .. ').' })
        DB.exec('UPDATE pb_inv_items SET weight = ? WHERE name = ? AND weight <= 100', { it[3], it[1] })
    end
    if G.Inv and G.Inv.Reload then G.Inv.Reload() end
    return d
end
-- Lignes de filière d'une drogue : récolte (1 brut), transformation (2 bruts → 1 pochon), vente (pochons, ou bruts à prix réduit). 2 secondes chacune.
function C.DrugRow(key, kind, base)
    local d = C.DRUGS[key]
    local row = { id = base.id, kind = kind, label = base.label, x = base.x, y = base.y, z = base.z, drug = key, radius = kind == 'harvest' and 8 or 3,
        item_in = '', qty_in = 0, item_out = '', qty_out = 0, price = 0, raw = '', time = 2, alert = 0 }
    if kind == 'harvest' then row.item_out, row.qty_out = d.raw[1], 1
    elseif kind == 'process' then row.item_in, row.qty_in, row.item_out, row.qty_out = d.raw[1], 2, d.pouch[1], 1
    else row.item_in, row.qty_in, row.price, row.raw, row.alert = d.pouch[1], 1, d.price, d.raw[1], 15 end
    return row
end

local function find(list, id) for _, s in ipairs(list or {}) do if s.id == id then return s end end end
function C.Spot(kind, id)
    if kind == 'chain' then return find(cfg('chain', {}), id) elseif kind == 'heist' then return find(cfg('heists', {}), id) elseif kind == 'launder' then return find(cfg('launder', {}), id) end
end

-- policiers en service
local function copsOnline() return (G.Justice and G.Justice.CountUnits and G.Justice.CountUnits('police')) or 0 end
local function isCop(src) local c = G.Biz and G.Biz.Ctx(src) return c and c.biz.kind == 'police' and c.duty end

local sessions, cd, last = {}, {}, {}
AddEventHandler('playerDropped', function() sessions[source] = nil last[source] = nil end)
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
local function nowS() return os.time() end

local function notify(src, kind, text) G.Notify(src, { type = kind, title = 'Activité', text = text }) end
local function reward(src, amount, why)
    amount = math.floor(amount)
    if amount <= 0 then return end
    if cfg('black_money', true) and Inv() and Inv().Def(cfg('dirty_item', 'black_money')) then
        local ow = owner(src)
        if Inv().CanCarry(ow, cfg('dirty_item', 'black_money'), amount) then Inv().Add(ow, cfg('dirty_item', 'black_money'), amount) return 'dirty' end
    end
    G.AddMoney(src, 'cash', amount, why)
    return 'cash'
end
local function alert(spot, text)
    if G.Justice and G.Justice.Alert then G.Justice.Alert('police', text, spot.x, spot.y, spot.z) end
end

-- Démarrage -------------------------------------------------------------------------------------------------------------------------
function C.Start(src, kind, id)
    if not cfg('enabled', true) then return false, 'Désactivé.' end
    if sessions[src] then return false, 'Tu es déjà occupé.' end
    local s = C.Spot(kind, id)
    if not s then return false, 'Point inconnu.' end
    if G.DistTo(src, s.x, s.y, s.z) > math.max(tonumber(s.radius) or 3, tonumber(cfg('use_dist', 2.5)) or 2.5) + 3 then return false, 'Tu es trop loin.' end
    local ow = owner(src)
    local dur = math.max(1, tonumber(s.time) or 5)
    if kind == 'heist' then
        if isCop(src) then return false, 'Un policier en service ne peut pas faire ça.' end
        if cfg('need_weapon', true) then
            -- le serveur relit l'arme en main : une arme blanche suffit, les poings non
            local okw, w = pcall(function() return GetSelectedPedWeapon and GetSelectedPedWeapon(GetPlayerPed(src)) or nil end)
            if okw and w ~= nil and (w == 0 or w == 2725352035 or w == -1569615261) then return false, "Sors une arme (une arme blanche suffit) et vise le vendeur." end
        end
        if (cd[s.id] or 0) > nowS() then return false, ('Rien à voler pour l\'instant (encore %d min).'):format(math.ceil((cd[s.id] - nowS()) / 60)) end
        if copsOnline() < (tonumber(s.police) or 0) then return false, 'Pas assez de policiers en service pour tenter ça.' end
        if (s.need or '') ~= '' then
            if not Inv() or Inv().Count(ow, s.need) < 1 then return false, ('Il te faut : %s.'):format((Inv() and Inv().Def(s.need) and Inv().Def(s.need).label) or s.need) end
            Inv().Remove(ow, s.need, 1)
        end
        cd[s.id] = nowS() + (tonumber(s.cooldown) or 30) * 60
        if math.random(100) <= (tonumber(s.alert) or 100) then alert(s, 'Braquage en cours : ' .. s.label) end
    elseif kind == 'chain' then
        if s.kind == 'harvest' then
            if not Inv() or not Inv().CanCarry(ow, s.item_out, s.qty_out) then return false, 'Tu ne peux pas porter plus.' end
        else
            local hasRaw = s.kind == 'sell' and (s.raw or '') ~= '' and Inv() and Inv().Count(ow, s.raw) > 0
            if not hasRaw and (not Inv() or Inv().Count(ow, s.item_in) < math.max(1, tonumber(s.qty_in) or 1)) then return false, ('Il te faut %d × %s.'):format(s.qty_in, (Inv() and Inv().Def(s.item_in) and Inv().Def(s.item_in).label) or s.item_in) end
        end
        if s.kind == 'sell' and isCop(src) then return false, 'Un policier en service ne peut pas faire ça.' end
    elseif kind == 'launder' then
        if not Inv() or Inv().Count(ow, cfg('dirty_item', 'black_money')) < 1 then return false, "Tu n'as pas d'argent sale." end
    end
    sessions[src] = { kind = kind, id = s.id, t = nowS(), dur = dur }
    -- filière : pas de barre, le personnage fait le geste (récolte penché, transformation, échange) le temps de l'action
    return true, nil, { label = s.label, time = dur, x = s.x, y = s.y, z = s.z, radius = (tonumber(s.radius) or 3) + 1.5, anim = kind == 'chain' and s.kind or nil }
end

-- Fin : le temps doit être écoulé et le joueur encore sur place
function C.Finish(src)
    local se = sessions[src]
    sessions[src] = nil
    if not se then return false, nil end
    local s = C.Spot(se.kind, se.id)
    if not s then return false, 'Point inconnu.' end
    if nowS() - se.t < se.dur - 1 then return false, 'Tu es parti trop vite.' end
    if G.DistTo(src, s.x, s.y, s.z) > (tonumber(s.radius) or 3) + 5 then return false, 'Tu t\'es éloigné.' end
    local ow = owner(src)
    if se.kind == 'heist' then
        local lo, hi = math.floor(tonumber(s.min) or 0), math.floor(tonumber(s.max) or 0)
        if hi < lo then hi = lo end
        local amount = math.random(lo, hi)
        local how = reward(src, amount, s.label)
        TriggerEvent('pb_panel:heistDone', src, s.id, amount)
        return true, ('%s : %s %s.'):format(s.label, money(amount), how == 'dirty' and "d'argent sale" or 'en liquide'), amount
    elseif se.kind == 'chain' then
        if s.kind == 'harvest' then
            if not Inv().CanCarry(ow, s.item_out, s.qty_out) then return false, 'Tu ne peux pas porter plus.' end
            Inv().Add(ow, s.item_out, s.qty_out)
            return true, ('+%d × %s'):format(s.qty_out, (Inv().Def(s.item_out) and Inv().Def(s.item_out).label) or s.item_out)
        elseif s.kind == 'process' then
            if Inv().Count(ow, s.item_in) < s.qty_in then return false, "Il te manque des ingrédients." end
            if not Inv().CanCarry(ow, s.item_out, s.qty_out) then return false, 'Tu ne peux pas porter plus.' end
            Inv().Remove(ow, s.item_in, s.qty_in)
            Inv().Add(ow, s.item_out, s.qty_out)
            return true, ('%d × %s → %d × %s'):format(s.qty_in, (Inv().Def(s.item_in) and Inv().Def(s.item_in).label) or s.item_in, s.qty_out, (Inv().Def(s.item_out) and Inv().Def(s.item_out).label) or s.item_out)
        elseif s.kind == 'sell' then
            -- au plus « max_sell » (3) par passage ; sans pochon, le produit brut se vend à prix réduit (x0,4)
            local maxN = math.max(1, tonumber(cfg('max_sell', 3)) or 3)
            local item, rate = s.item_in, 1
            if Inv().Count(ow, item) < 1 and (s.raw or '') ~= '' and Inv().Count(ow, s.raw) > 0 then item, rate = s.raw, tonumber(cfg('raw_mult', 0.4)) or 0.4 end
            local n = math.min(Inv().Count(ow, item), maxN)
            if n < 1 then return false, 'Tu n\'as plus rien à vendre.' end
            Inv().Remove(ow, item, n)
            local mult = (G.Flags and G.Flags.Mult and G.Flags.Mult(s.id, src)) or 1
            local total = math.floor(n * (tonumber(s.price) or 0) * rate * mult)
            local how = reward(src, total, s.label)
            if math.random(100) <= (tonumber(s.alert) or 0) then alert(s, 'Trafic suspect signalé : ' .. s.label) end
            TriggerEvent('pb_panel:drugSold', src, s.id, n, total)
            local label = (Inv().Def(item) and Inv().Def(item).label) or item
            return true, ('%d × %s vendu(s) : %s %s%s%s.'):format(n, label, money(total), how == 'dirty' and "d'argent sale" or 'en liquide',
                rate < 1 and (' (produit brut : x' .. tostring(rate) .. ')') or '', mult > 1 and (' (x' .. tostring(mult) .. ' : ton gang tient le drapeau)') or '')
        end
    elseif se.kind == 'launder' then
        local item = cfg('dirty_item', 'black_money')
        local n = math.min(Inv().Count(ow, item), math.floor(tonumber(s.max) or 20000))
        if n < 1 then return false, "Tu n'as pas d'argent sale." end
        Inv().Remove(ow, item, n)
        local clean = math.floor(n * (tonumber(s.rate) or 70) / 100)
        G.AddMoney(src, 'cash', clean, 'Blanchiment')
        PB.Audit.Log('economie', 'crime.launder', src, s.id, nil, nil, { dirty = n, clean = clean })
        return true, ('%s blanchis : %s récupérés.'):format(money(n), money(clean))
    end
    return false, 'Action inconnue.'
end

RegisterNetEvent('pb:g:crime:start', function(kind, id)
    local src = source
    if not usable(src) or not throttle(src, 700) then return end
    local ok, msg, info = C.Start(src, tostring(kind), tostring(id))
    if not ok then notify(src, 'error', msg) return end
    TriggerClientEvent('pb:g:crime:go', src, PB.Json(info))
end)
RegisterNetEvent('pb:g:crime:end', function(done)
    local src = source
    if not G.Get(src) then return end
    if done ~= true then sessions[src] = nil return end
    local ok, msg = C.Finish(src)
    if msg then notify(src, ok and 'success' or 'error', msg) end
end)
function C.Cancel(src) sessions[src] = nil end
function C.Cooldowns() local out = {} for id, t in pairs(cd) do if t > nowS() then out[id] = t - nowS() end end return out end
function C.ResetCooldown(id) cd[id] = nil end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
local settings = Form.Cfg({ ns = 'crime', id = 'settings', title = 'Activités illégales', perm = 'crime.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Activités illégales actives', default = true },
    { k = 'need_weapon', type = 'toggle', label = 'Braquage : exiger une arme en main (arme blanche acceptée)', default = true },
    { k = 'black_money', type = 'toggle', label = "Gains en argent sale (à blanchir)", default = true, hint = "Désactivé : les gains arrivent directement en espèces." },
    { k = 'dirty_item', type = 'text', label = "Objet « argent sale »", default = 'black_money', maxlen = 32, pattern = '^[%w_]+$' },
    { k = 'use_dist', type = 'number', label = "Distance d'interaction (m)", default = 2.5, min = 1, max = 10, int = false },
    { k = 'max_sell', type = 'number', label = 'Quantité maximale vendue par passage', default = 3, min = 1, max = 500 },
    { k = 'raw_mult', type = 'number', label = 'Vente du produit brut (non transformé) : multiplicateur du prix', default = 0.4, min = 0, max = 1, step = 0.05, int = false, hint = '0,4 = le brut se vend 40 % du prix d’un pochon.' },
    { k = 'show_markers', type = 'toggle', label = 'Marqueur au sol près des points', default = true }, { k = 'show_blips', type = 'toggle', label = 'Icônes sur la carte (déconseillé)', default = false },
} })
local XYZ = { { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } }
local function cols(list) local out = {} for _, c in ipairs(list) do out[#out + 1] = c end return out end
local function join(a, b) local out = cols(a) for _, c in ipairs(b) do out[#out + 1] = c end return out end
local chainForm = Form.Cfg({ ns = 'crime', id = 'chain', title = 'Filières (récolte → transformation → vente)', perm = 'crime.edit', fields = {
    { k = 'chain', type = 'rows', label = 'Points de filière', default = CHAIN, wide = true, maxitems = 60, unique = 'id',
      hint = "Type : harvest (récolte : donne « sortie »), process (transforme « entrée » en « sortie »), sell (vend « entrée » au prix indiqué, par unité). Durée en secondes, alerte = % de chances de prévenir la police.",
      cols = join({ { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 } }, join(XYZ, {
        { k = 'radius', label = 'Rayon', type = 'number', min = 1, max = 50, int = false }, { k = 'item_in', label = 'Objet entrée', pattern = '^[%w_]*$', maxlen = 32, lower = true }, { k = 'qty_in', label = 'Qté entrée', type = 'number', min = 0, max = 500 },
        { k = 'item_out', label = 'Objet sortie', pattern = '^[%w_]*$', maxlen = 32, lower = true }, { k = 'qty_out', label = 'Qté sortie', type = 'number', min = 0, max = 500 }, { k = 'price', label = 'Prix unité', type = 'number', min = 0, max = 1000000 },
        { k = 'time', label = 'Durée (s)', type = 'number', min = 1, max = 600 }, { k = 'alert', label = 'Alerte %', type = 'number', min = 0, max = 100 },
        { k = 'raw', label = 'Vente : produit brut accepté (prix réduit)', pattern = '^[%w_]*$', maxlen = 32, lower = true } })) } } })
local heistForm = Form.Cfg({ ns = 'crime', id = 'heists', title = 'Braquages', perm = 'crime.edit', fields = {
    { k = 'heists', type = 'rows', label = 'Braquages', default = HEISTS, wide = true, maxitems = 40, unique = 'id',
      hint = "Le gain est tiré entre min et max. Policiers = nombre minimal en service. Objet requis (vide = aucun) : un exemplaire est consommé au départ. Délai en minutes avant qu'on puisse recommencer.",
      cols = join({ { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 } }, join(XYZ, {
        { k = 'radius', label = 'Rayon', type = 'number', min = 1, max = 50, int = false }, { k = 'min', label = 'Gain min', type = 'number', min = 0, max = 10000000 }, { k = 'max', label = 'Gain max', type = 'number', min = 0, max = 10000000 },
        { k = 'time', label = 'Durée (s)', type = 'number', min = 5, max = 900 }, { k = 'cooldown', label = 'Délai (min)', type = 'number', min = 1, max = 1440 }, { k = 'police', label = 'Policiers', type = 'number', min = 0, max = 50 },
        { k = 'need', label = 'Objet requis', pattern = '^[%w_]*$', maxlen = 32, lower = true }, { k = 'alert', label = 'Alerte %', type = 'number', min = 0, max = 100 },
        { k = 'ped', label = 'Vendeur (modèle ; vide = ped du jeu)', pattern = '^[%w_]*$', maxlen = 40 }, { k = 'h', label = 'Cap du vendeur', type = 'number', min = 0, max = 360, int = false } })) } } })
local launderForm = Form.Cfg({ ns = 'crime', id = 'launder', title = 'Blanchiment', perm = 'crime.edit', fields = {
    { k = 'launder', type = 'rows', label = "Points de blanchiment", default = LAUNDER, wide = true, maxitems = 20, unique = 'id',
      hint = "Taux = part de l'argent sale rendue en espèces propres ; maximum par passage.",
      cols = join({ { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 } }, join(XYZ, {
        { k = 'rate', label = 'Taux %', type = 'number', min = 1, max = 100 }, { k = 'max', label = 'Maximum', type = 'number', min = 1, max = 10000000 }, { k = 'time', label = 'Durée (s)', type = 'number', min = 1, max = 300 } })) } } })

PB.Module({
    id = 'crime', label = 'Activités illégales', icon = 'skull', group = 'Serveur', order = 145, perm = 'crime.edit', hint = 'Filières, braquages, blanchiment',
    caps = function()
        return PB.Capsify({
            { 'Filières (drogues ou autre)', 'ok', 'Récolte, transformation et vente : tu définis les points, les objets, les quantités et les prix.' },
            { 'Braquages', 'ok', "Gain tiré au sort, délai avant de recommencer, policiers en service minimum, objet requis, alerte à la police." },
            { 'Argent sale et blanchiment', 'ok', "Les gains arrivent en argent sale ; des points de blanchiment le convertissent avec un taux." },
            { 'Territoires de gangs', 'ok', "Voir le module Territoires : un gang prend et garde des zones." },
            { 'Police qui voit les trafiquants en direct', 'off', "La police reçoit une alerte (appel) avec la position, pas un suivi en temps réel." },
        })
    end,
    doc = "## Activités illégales\nTrois listes de points : **Filières** (récolte → transformation → vente), **Braquages** et **Blanchiment**.\n\nLe joueur s'approche, appuie sur **E**, reste sur place pendant la durée (barre de progression), puis reçoit le résultat. Le serveur vérifie la distance au départ et à la fin, les objets, les policiers en service et le délai.\n\nLes objets doivent exister dans **Inventaire › Objets** (le cannabis et les joints sont créés au premier démarrage).",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'crime', title = 'Ce que voit le joueur (exemple)', cfg = PB.Cfg.All('menus') } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
            { id = 'chain', label = 'Filières', icon = 'route', build = function() return { chainForm(ctx) } end },
            { id = 'heists', label = 'Braquages', icon = 'alert', build = function()
                local rows = {}
                for id, left in pairs(C.Cooldowns()) do rows[#rows + 1] = { id = id, left = ('%d min'):format(math.ceil(left / 60)), actions = ctx.has('crime.edit') and { { action = 'crime.reset', label = 'Réinitialiser', payload = { id = id } } } or nil } end
                return { heistForm(ctx), B.table({ id = 'cds', title = 'Braquages en attente', columns = { { k = 'id', label = 'Point' }, { k = 'left', label = 'Disponible dans' } }, rows = rows, empty = 'Aucun braquage récent.' }) }
            end },
            { id = 'launder', label = 'Blanchiment', icon = 'coins', build = function() return { launderForm(ctx) } end },
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                local KIND = { harvest = '#7bd88f', process = '#f2c14e', sell = '#ff7a7a' }
                for _, s in ipairs(cfg('chain', {}) or {}) do pts[#pts + 1] = { id = s.id, x = s.x, y = s.y, color = KIND[s.kind] or '#ffffff', label = s.label, sub = s.kind } end
                for _, s in ipairs(cfg('heists', {}) or {}) do pts[#pts + 1] = { id = s.id, x = s.x, y = s.y, color = '#b48cff', label = s.label, sub = 'braquage' } end
                for _, s in ipairs(cfg('launder', {}) or {}) do pts[#pts + 1] = { id = s.id, x = s.x, y = s.y, color = '#6fd3ff', label = s.label, sub = 'blanchiment' } end
                return { { type = 'map', id = 'cmap', title = 'Points illégaux', points = pts, legend = { { color = '#7bd88f', label = 'Récolte' }, { color = '#f2c14e', label = 'Transformation' }, { color = '#ff7a7a', label = 'Vente' }, { color = '#b48cff', label = 'Braquage' }, { color = '#6fd3ff', label = 'Blanchiment' } } } }
            end },
        } }
    end,
})
PB.Action('crime.reset', 'crime.edit', function(ctx, p) C.ResetCooldown(tostring(p.id or '')) ctx.audit('serveur', 'crime.reset', tostring(p.id or '')) ctx.toast = 'Braquage réinitialisé.' return true end)

PB.SelfTest.Add('activités illégales', function(R)
    local function item(name, where) if (name or '') ~= '' then R.check(G.Inv and G.Inv.Def(name) ~= nil, where .. ' « ' .. name .. ' »', "l'objet n'existe pas (Inventaire › Objets)") end end
    for _, s in ipairs(cfg('chain', {}) or {}) do R.check(s.kind == 'harvest' or s.kind == 'process' or s.kind == 'sell', 'filière « ' .. tostring(s.id) .. ' »', 'type inconnu : ' .. tostring(s.kind)) item(s.item_in, 'objet entrée') item(s.item_out, 'objet sortie') end
    for _, s in ipairs(cfg('heists', {}) or {}) do R.check((tonumber(s.max) or 0) >= (tonumber(s.min) or 0), 'braquage « ' .. tostring(s.id) .. ' »', 'le gain maximum est inférieur au minimum') item(s.need, 'objet requis') end
    item(cfg('dirty_item', 'black_money'), 'argent sale')
end)
