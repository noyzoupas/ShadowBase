/* Menu ALT : points cliquables sur les personnes (positions écran envoyées par le jeu) et petit menu à côté de la personne choisie.
   Le jeu n'envoie que des identifiants ; le serveur compose la liste des entrées. Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

let keyH = null, layer = null, spotsEl = null, menuEl = null, spec = null, anchor = { x: 0, y: 0 }, spotMap = {};
const root = () => layer || (layer = (function () { const e = h('div', { id: 'g-ctx', class: 'hidden' }); G.root.appendChild(e); return e; })());

function themeVars(t) {
  const th = G.rmenu.themeOf(t);
  return { '--ac': th.accent, '--acr': G.hexToRgb(th.accent), '--bg': th.bg, '--bgr': G.hexToRgb(th.bg), '--tx': th.text, '--mu': th.muted, '--op': String(th.opacity / 100), '--rd': Math.min(14, th.radius) + 'px', '--bl': th.blur + 'px', '--fs': String(th.font_scale / 100) };
}

// menu : { target:{...}, cats:[{id,label,icon,entries:[{id,label,desc,icon,danger,inputs,disabled,why}]}] }
const STYLES = ['cascade', 'glass', 'v2', 'clean'];
G.ctxStyles = STYLES;
// Quatre présentations : « cascade » (épurée en cascade, par défaut), « glass » (Verre : liste + sous-menu à côté), « v2 » (deux colonnes, touches 1-9), « clean » (épurée, couleurs du serveur).
function menuView(sp, o) {
  o = o || {};
  sp = sp || {};
  const cats = sp.cats || [];
  const tg = sp.target || {};
  const style = STYLES.indexOf(o.style) >= 0 ? o.style : 'cascade';
  const v2 = style === 'v2';
  const box = h('div', { class: 'sx-menu sx-' + style, style: themeVars(o.theme) });
  let cur = null, form = null, subEl = null, colR = null, colL = null;
  const row = (label, cls, fn, opt) => {
    opt = opt || {};
    const b = h('button', { type: 'button', class: 'sx-i' + (cls ? ' ' + cls : ''), onclick: fn },
      opt.key ? h('kbd', { class: 'sx-k' }, String(opt.key)) : null,
      h('span', { class: 'sx-ic' }, ico(opt.icon || 'chevron')),
      h('span', { class: 'sx-tx' }, h('b', null, label), opt.why ? h('small', null, opt.why) : null),
      opt.more ? h('span', { class: 'sx-go' }, ico('chevron')) : null);
    if (opt.hover) b.addEventListener('mouseenter', opt.hover);
    return b;
  };
  const head = (title, sub) => h('div', { class: 'sx-h' }, h('b', null, title), sub ? h('small', null, sub) : null);
  const none = () => h('div', { class: 'sx-none' }, 'Aucune action disponible.');

  function entryList(c, keyed) {
    const list = h('div', { class: 'sx-l' });
    c.entries.forEach((e, i) => list.appendChild(row(e.label, (e.danger ? 'bad' : '') + (e.disabled ? ' off' : ''), () => pickEntry(e), { icon: e.icon, why: e.disabled && e.why ? e.why : null, more: !e.disabled && (e.inputs || []).length > 0, key: keyed && i < 9 ? i + 1 : null })));
    return list;
  }
  function formView(e) {
    const vals = {};
    const fm = h('div', { class: 'sx-f' });
    (e.inputs || []).forEach((f, i) => {
      const inp = h('input', { type: f.number ? 'number' : 'text', maxlength: String(f.maxlen || 60), placeholder: f.label, class: 'sx-in' });
      inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') go(); else if (ev.key === 'Escape') { form = null; render(); } });
      vals[f.k] = [inp, f]; if (i === 0 && !o.static) setTimeout(() => inp.focus(), 20);
      fm.appendChild(inp);
    });
    const go = () => {
      const p = {};
      Object.keys(vals).forEach((k) => { const [inp, f] = vals[k]; p[k] = f.number ? (inp.value === '' ? null : Number(inp.value)) : inp.value; });
      o.onAct && o.onAct(e.id, p);
    };
    fm.appendChild(h('button', { type: 'button', class: 'sx-ok', onclick: go }, 'Valider'));
    return h('div', { class: 'sx-fw' }, head(e.label, tg.name), fm, row('Retour', 'back', () => { form = null; render(); }, { icon: 'undo' }));
  }
  function pickEntry(e) {
    if (e.disabled) return;
    if ((e.inputs || []).length) { form = e; render(); } else o.onAct && o.onAct(e.id, {});
  }
  // Place le sous-menu à côté de la ligne choisie : à droite, sinon à gauche, sinon par-dessus ; toujours entièrement dans l'écran.
  function layoutSub(rowBtn) {
    if (!subEl || !subEl.isConnected) return;
    subEl.classList.remove('left', 'over');
    subEl.style.top = '0px'; subEl.style.left = ''; subEl.style.right = '';
    const bx = box.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
    const sw = subEl.offsetWidth || 250, sh = Math.min(subEl.offsetHeight || 200, vh - 16);
    if (bx.right + 6 + sw > vw - 8) {
      if (bx.left - 6 - sw >= 8) subEl.classList.add('left'); else subEl.classList.add('over');
    }
    let t = (rowBtn && rowBtn.isConnected ? rowBtn.getBoundingClientRect().top : bx.top) - bx.top;
    t = Math.min(t, vh - 8 - sh - bx.top); t = Math.max(t, 8 - bx.top);
    subEl.style.top = t + 'px';
  }
  function openCat(c, rowBtn) {
    cur = c; form = null;
    if (v2) { render(); return; }
    box.querySelectorAll('.sx-cats .sx-i').forEach((b) => b.classList.toggle('on', b.__c === c));
    if (subEl) subEl.remove();
    subEl = h('div', { class: 'sx-sub' }, head(c.label, tg.name), entryList(c, false));
    box.appendChild(subEl); layoutSub(rowBtn);
  }
  function catRow(c, i) {
    const b = row(c.label, cur === c ? 'on' : '', () => openCat(c, b), { icon: c.icon, more: true, key: v2 && !cur && i < 9 ? i + 1 : null, hover: v2 || o.static ? null : () => { if (cur !== c) openCat(c, b); } });
    b.__c = c; return b;
  }
  // Après un changement de contenu, la boîte remonte si elle dépasse en bas de l'écran.
  function clampBox() {
    if (o.static || !box.isConnected) return;
    const r = box.getBoundingClientRect(), vh = window.innerHeight;
    let dy = Math.min(0, vh - 8 - r.bottom);
    if (r.top + dy < 8) dy = 8 - r.top;
    if (dy) box.style.top = ((parseFloat(box.style.top) || 0) + dy) + 'px';
  }
  function render() {
    G.clear(box); subEl = null;
    box.classList.remove('in'); void box.offsetWidth; box.classList.add('in');
    if (!cats.length) { box.appendChild(none()); return; }
    if (v2) {
      if (!cur && cats.length === 1) cur = cats[0];
      colL = h('div', { class: 'sx-c1' }, head(tg.name || 'Interactions', tg.sub), h('div', { class: 'sx-l sx-cats' }, ...cats.map(catRow)));
      colR = h('div', { class: 'sx-c2' });
      if (form) colR.appendChild(formView(form));
      else if (cur) { colR.appendChild(head(cur.label, 'Touches 1 à 9 · Retour arrière = catégories')); colR.appendChild(entryList(cur, true)); }
      else colR.appendChild(h('div', { class: 'sx-none' }, 'Choisis une catégorie (touche 1 à 9).'));
      box.appendChild(colL); box.appendChild(colR);
      clampBox();
      return;
    }
    if (cats.length === 1) {       // une seule catégorie : les entrées sont directement dans la boîte
      const c = cats[0];
      if (form) { box.appendChild(formView(form)); return; }
      box.appendChild(head(tg.name || c.label, tg.sub));
      box.appendChild(entryList(c, false));
      return;
    }
    box.appendChild(head(tg.name || 'Interactions', tg.sub));
    box.appendChild(h('div', { class: 'sx-l sx-cats' }, ...cats.map(catRow)));
    if (cur) {
      if (form) { subEl = h('div', { class: 'sx-sub' }, formView(form)); box.appendChild(subEl); layoutSub(box.querySelector('.sx-cats .sx-i.on')); }
      else openCat(cur, box.querySelector('.sx-cats .sx-i.on'));
    }
  }
  // Touches 1-9 (version 2) et Retour arrière ; renvoie true si la touche a été utilisée.
  box.__keys = (ev) => {
    if (!v2 || form || (ev.target && /^(INPUT|TEXTAREA)$/.test(ev.target.tagName))) return false;
    if (ev.key === 'Backspace' && cur && cats.length > 1) { cur = null; render(); return true; }
    const n = /^[1-9]$/.test(ev.key) ? Number(ev.key) : 0;
    if (!n) return false;
    if (!cur) { if (cats[n - 1]) { openCat(cats[n - 1]); return true; } return false; }
    const e = cur.entries[n - 1];
    if (e) { pickEntry(e); return true; }
    return false;
  };
  box.__layout = () => layoutSub(box.querySelector('.sx-cats .sx-i.on'));
  box.__first = () => {};
  render();
  return box;
}
G.ctxMenuView = menuView;

function place(el, x, y) {
  const vw = window.innerWidth, vh = window.innerHeight;
  el.style.left = '0px'; el.style.top = '0px';
  const w = el.offsetWidth || 272, hh = Math.min(el.offsetHeight || 160, vh - 20);
  let lx = x + 24; if (lx + w > vw - 10) { lx = Math.max(10, x - 24 - w); el.classList.add('flip'); } else el.classList.remove('flip');
  lx = Math.max(10, Math.min(lx, vw - w - 10));
  let ty = Math.max(10, Math.min(y + 10, vh - hh - 10));
  el.style.left = lx + 'px'; el.style.top = ty + 'px';
  if (el.__layout) el.__layout();
}

function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } if (keyH) { document.removeEventListener('keydown', keyH, true); keyH = null; } spec = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'ctx'); }
// Les points sont réutilisés d'une image à l'autre (seule la position change) : recréer les boutons ~30 fois par seconde
// annulait le survol et le clic en permanence.
function drawSpots(list) {
  const r = root();
  if (!spotsEl) { spotsEl = h('div', { class: 'cx-spots' }); r.appendChild(spotsEl); }
  const seen = {};
  (list || []).forEach((s) => {
    const key = (s.k || 'p') + s.i;
    seen[key] = true;
    let b = spotMap[key];
    if (!b) {
      b = h('button', { type: 'button', class: 'cx-hit' + (s.me ? ' me' : '') + (s.k === 'v' ? ' veh' : s.k === 'o' ? ' obj' : ''), 'aria-label': s.me ? 'Moi' : s.k === 'v' ? 'Véhicule' : s.k === 'o' ? 'Objet' : 'Personne ' + s.i },
        h('span', { class: 'cx-hl' }, s.me ? 'Moi' : s.k === 'v' ? 'Véhicule' : s.k === 'o' ? 'Objet' : '#' + s.i));
      b.addEventListener('click', () => {
        const rc = b.getBoundingClientRect(); anchor = { x: rc.left + rc.width / 2, y: rc.top + rc.height / 2 };
        G.post('ctx.pick', { i: b.__s.i, k: b.__s.k || 'p' });
      });
      b.addEventListener('mouseenter', () => G.post('ctx.hover', { i: b.__s.i, k: b.__s.k || 'p' }));
      b.addEventListener('mouseleave', () => G.post('ctx.hover', {}));
      spotMap[key] = b; spotsEl.appendChild(b);
    }
    b.__s = s;
    // zone cliquable = rectangle autour de la cible (taille minimale si le jeu n'a pas pu la mesurer)
    const w = Math.max(0.045, Number(s.w) || 0.07), hh = Math.max(0.09, Number(s.h) || 0.18);
    b.style.left = (s.x * 100) + '%'; b.style.top = (s.y * 100) + '%'; b.style.width = (w * 100) + '%'; b.style.height = (hh * 100) + '%';
  });
  Object.keys(spotMap).forEach((k) => { if (!seen[k]) { spotMap[k].remove(); delete spotMap[k]; } });
}
function clearSpots() { if (spotsEl) G.clear(spotsEl); spotMap = {}; G.post('ctx.hover', {}); }
G.on('ctx.spots', (d) => { const r = root(); if (menuEl) return; r.classList.remove('hidden'); r.classList.add('hold'); G.root.classList.add('alt-hold'); drawSpots(d.p || []); });
G.on('ctx.hide', () => { G.root.classList.remove('alt-hold'); if (menuEl) return; const r = root(); r.classList.add('hidden'); r.classList.remove('hold'); clearSpots(); });
G.on('ctx.open', (d) => {
  const r = root(); r.classList.remove('hidden');
  closeMenu(); spec = d.spec;
  menuEl = menuView(spec, { theme: G.cfg && G.cfg.menus, style: (G.cfg && G.cfg.ctx && G.cfg.ctx.style) || 'cascade', onAct: (id, p) => G.post('ctx.act', { t: spec.target.id, id, payload: p || {} }), onClose: () => G.post('ctx.close', {}) });
  r.appendChild(menuEl); place(menuEl, anchor.x, anchor.y); menuEl.__first();
  keyH = (ev) => { if (menuEl && menuEl.__keys && menuEl.__keys(ev)) { ev.preventDefault(); ev.stopPropagation(); } };
  document.addEventListener('keydown', keyH, true);
  G.uiStack.push({ id: 'ctx', onEscape: () => G.post('ctx.close', {}) });
});
G.on('ctx.close', () => { G.root.classList.remove('alt-hold'); closeMenu(); const r = root(); r.classList.add('hidden'); r.classList.remove('hold'); clearSpots(); });
document.addEventListener('mousedown', (e) => { if (menuEl && !menuEl.contains(e.target)) G.post('ctx.close', {}); }, true);


// Demande de geste à deux : Y accepte, N refuse (la réponse est lue par le jeu, la fenêtre ne fait qu'afficher)
let invEl = null, invT = 0;
function dropInvite() { clearTimeout(invT); if (invEl) { invEl.remove(); invEl = null; } }
G.on('ctx.invite', (d) => {
  dropInvite();
  if (d.stop) return;
  invEl = h('div', { id: 'g-ctxinv' },
    h('div', { class: 'ci-t' }, h('b', null, String(d.name || '').slice(0, 40)), h('span', null, String(d.text || '').slice(0, 80))),
    h('div', { class: 'ci-k' }, h('span', null, h('kbd', null, 'Y'), 'Accepter'), h('span', null, h('kbd', null, 'N'), 'Refuser')));
  G.root.appendChild(invEl);
  invT = setTimeout(dropInvite, Math.max(5, Math.min(60, Number(d.secs) || 15)) * 1000 + 500);
});
G.on('ctx.copy', (d) => {
  const t = String(d.text || '').slice(0, 24);
  const fallback = () => { const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); };
  try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).catch(fallback); else fallback(); } catch (e) { fallback(); }
});

const DEMO = { target: { id: 12, name: 'Camille Durand', sub: 'Police · Officier', gang: 'Ballas', gc: '#a56bff', lines: ['Espèces $640 · Banque $18 250', 'Ping 34 ms'] }, cats: [
  { id: 'people', label: 'Interactions', icon: 'users', entries: [{ id: 'show_id', label: 'Montrer mes papiers', icon: 'id' }, { id: 'give_cash', label: "Donner de l'argent", icon: 'coins', inputs: [{ k: 'amount', label: 'Montant', number: true }] }, { id: 'report', label: 'Signaler cette personne', icon: 'alert', inputs: [{ k: 'reason', label: 'Motif' }] }] },
  { id: 'job', label: 'Métier', icon: 'briefcase', entries: [{ id: 'cuff', label: 'Menotter', icon: 'lock' }, { id: 'search', label: 'Fouiller', icon: 'search', disabled: true, why: 'Trop loin.' }, { id: 'invoice', label: 'Facturer', icon: 'card' }] },
  { id: 'staff', label: 'Staff', icon: 'shield', entries: [{ id: 's_info', label: 'Informations', icon: 'info' }, { id: 's_goto', label: 'Aller vers elle', icon: 'gps' }, { id: 's_warn', label: 'Avertir', icon: 'alert', danger: true }] }] };
const DEMO_V = { target: { id: 77, name: 'Sultan', sub: 'PB 1111', vehicle: true, lines: ['Dehors'] }, cats: [{ id: 'vehicle', label: 'Véhicule', icon: 'car', entries: [
  { id: 'v_lock', label: 'Verrouiller / déverrouiller', icon: 'lock' }, { id: 'v_engine', label: 'Moteur : démarrer / couper', icon: 'bolt' }, { id: 'v_trunk', label: 'Coffre : ouvrir / fermer', icon: 'bag' }, { id: 'v_plate', label: 'Lire la plaque', icon: 'id' },
  { id: 'v_owner', label: 'Propriétaire (fichier)', icon: 'search' }, { id: 'v_impound', label: 'Mettre en fourrière', icon: 'x', danger: true, inputs: [{ k: 'reason', label: 'Motif' }] }] }] };
const DEMO_O = { target: { id: 1, name: 'Distributeur', object: true }, cats: [{ id: 'object', label: 'Distributeur', icon: 'card', entries: [{ id: 'o_use', label: 'Utiliser', icon: 'card' }] }] };
G.preview.ctx = function (box, cfg, blk) {
  G.clear(box);
  const demo = (blk && blk.demo) || 'person';
  const sp = demo === 'vehicle' ? DEMO_V : demo === 'object' ? DEMO_O : DEMO;
  const m = menuView(sp, { theme: cfg, style: (blk && blk.style) || 'cascade', static: true, onAct() {} });
  m.style.position = 'absolute'; m.style.left = '108px'; m.style.top = '70px';
  const who = demo === 'vehicle' ? 'Sultan · PB 1111' : demo === 'object' ? 'Distributeur' : 'Camille Durand';
  const stage = h('div', { class: 'cx-stage' }, h('div', { class: 'cx-person' }, h('b', null, who), h('button', { type: 'button', class: 'cx-hit' + (demo === 'vehicle' ? ' veh' : demo === 'object' ? ' obj' : ''), style: { left: '0', top: '0', position: 'relative', transform: 'none', width: demo === 'vehicle' ? '150px' : '84px', height: demo === 'vehicle' ? '70px' : '190px' } }, h('span', { class: 'cx-hl' }, who))), m);
  box.appendChild(stage); m.__first();
};
})();
