/* Panel — interface. DOM construit avec h() : aucune donnée serveur n'est jamais insérée via innerHTML. */
(function () {
'use strict';
const IN_GAME = typeof GetParentResourceName === 'function';
const RES = IN_GAME ? GetParentResourceName() : 'pb_panel';
const CHUNK = 30000, UP_LIMIT = 45000;

/* ---------- utilitaires ---------- */
const $ = (s, r) => (r || document).querySelector(s);
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') { for (const sk in v) { if (sk.indexOf('--') === 0) el.style.setProperty(sk, v[sk]); else el.style[sk] = v[sk]; } }
    else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'readOnly' || k === 'selected') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  add(el, kids);
  return el;
}
function add(el, kids) {
  for (const k of kids) {
    if (k == null || k === false) continue;
    if (Array.isArray(k)) add(el, k);
    else el.appendChild(k.nodeType ? k : document.createTextNode(String(k)));
  }
}
const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
const isArr = Array.isArray;
// Les formats des champs sont écrits en motifs Lua (vérifiés aussi par le serveur) : %w, %d, %-, | littéral…
// On les traduit en expression JavaScript, sinon « ^[%w_]*$ » refusait « F4 » (lu comme « seulement %, w ou _ »).
const LUA_CL = { a: 'A-Za-z', d: '0-9', l: 'a-z', u: 'A-Z', w: 'A-Za-z0-9', x: '0-9A-Fa-f', s: '\\s', p: '!-\\/:-@\\[-`{-~', c: '\\x00-\\x1f' };
const luaRx = {};
function luaPattern(p) {
  if (luaRx[p]) return luaRx[p];
  let out = '', inSet = false, setStart = 0;
  for (let i = 0; i < p.length; i++) {
    const c = p[i];
    if (c === '%' && i + 1 < p.length) {
      const n = p[++i], lo = n.toLowerCase();
      if (LUA_CL[lo]) out += inSet ? LUA_CL[lo] : (n === lo ? '[' : '[^') + LUA_CL[lo] + ']';
      else out += /[A-Za-z0-9]/.test(n) ? n : '\\' + n;
      continue;
    }
    if (inSet) {
      if (c === ']' && i > setStart) inSet = false;
      out += (c === '\\' || c === '[') ? '\\' + c : c;
      continue;
    }
    if (c === '[') { inSet = true; setStart = p[i + 1] === '^' ? i + 2 : i + 1; out += c; continue; }
    if (c === '-') { out += '*?'; continue; }
    out += /[|{}\/\\]/.test(c) ? '\\' + c : c;
  }
  return (luaRx[p] = new RegExp(out));
}
window.PBLuaPattern = luaPattern;
const esc = (s) => String(s == null ? '' : s);
const clone = (o) => (o === undefined ? undefined : JSON.parse(JSON.stringify(o)));
const optList = (f) => (f.opts || f.options || []).map((o) => (isArr(o) ? { v: o[0], l: o[1], i: o[2] } : (o && typeof o === 'object') ? { v: o.value != null ? o.value : o.v, l: o.label != null ? o.label : o.l } : { v: o, l: o }));
const hue = (s) => { let x = 0; for (let i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) % 360; return x; };

const ICONS = {
  upload: 'M12 16V4m-5 5 5-5 5 5M5 20h14', image: 'M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M8.5 9.5h.01',
  trash: 'M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14', edit: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4', download: 'M12 4v11m-5-4 5 5 5-5M5 20h14',
  box: 'M3 8l9-5 9 5v8l-9 5-9-5zM3 8l9 5 9-5M12 13v8', shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z', users: 'M9 11a3 3 0 100-6 3 3 0 000 6zM3 20c0-3 2.5-5 6-5s6 2 6 5M16 5a3 3 0 010 6M18 15c2 .5 3 2.5 3 5',
  undo: 'M9 14 4 9l5-5M4 9h10a6 6 0 010 12h-3', diff: 'M12 3v9M7.5 7.5h9M7.5 18h9', coins: 'M8 8a6 3 0 1012 0 6 3 0 10-12 0zM8 8v5c0 1.7 2.7 3 6 3s6-1.3 6-3V8M4 12v4c0 1.5 2 2.7 5 3',
  clock: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2', check: 'M5 12l5 5L20 7', activity: 'M3 12h4l3-8 4 16 3-8h4', sync: 'M20 11a8 8 0 00-14-4L4 9m0-5v5h5M4 13a8 8 0 0014 4l2-2m0 5v-5h-5',
  power: 'M12 3v9M6.5 6.5a8 8 0 1011 0', 'hard-drive': 'M3 14h18v5H3zM3 14l3-9h12l3 9M7 17h.01', alert: 'M12 4l9 16H3zM12 10v4M12 17h.01', wrench: 'M14 7a4 4 0 005 5l-9 9-3-3 9-9a4 4 0 00-2-2zM15 6l3-3',
  terminal: 'M4 5h16v14H4zM8 10l3 2-3 2M13 15h3', stop: 'M6 6h12v12H6z', sliders: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4', send: 'M21 3 3 11l7 3 3 7zM10 14l11-11',
  plus: 'M12 5v14M5 12h14', play: 'M7 4l13 8-13 8z', package: 'M3 8l9-5 9 5v8l-9 5-9-5zM12 3v18M7.5 5.5l9 5', map: 'M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2zM9 4v14M15 6v14',
  list: 'M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01', layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5', info: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v6M12 7.5h.01',
  folder: 'M3 6h6l2 2h10v11H3z', database: 'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6',
  cpu: 'M7 7h10v10H7zM9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4', cloud: 'M7 18a4 4 0 010-8 5 5 0 019.5-1A4.5 4.5 0 0117 18z', car: 'M5 16V11l2-5h10l2 5v5M3 16h18M7.5 19a1 1 0 100-2 1 1 0 000 2zM16.5 19a1 1 0 100-2 1 1 0 000 2z',
  building: 'M5 21V4h9v17M14 9h5v12M8 8h3M8 12h3M8 16h3M3 21h18', archive: 'M3 5h18v4H3zM5 9v11h14V9M10 13h4', zap: 'M13 3 5 14h6l-1 7 8-11h-6z', x: 'M6 6l12 12M18 6 6 18',
  up: 'M12 19V5M6 11l6-6 6 6', down: 'M12 5v14M6 13l6 6 6-6', table: 'M3 5h18v14H3zM3 10h18M9 5v14', scroll: 'M7 4h11a2 2 0 012 2v12M7 4a2 2 0 00-2 2v12a2 2 0 002 2h11M9 9h6M9 13h6',
  save: 'M5 4h12l3 3v13H5zM8 4v5h8V4M8 20v-6h8v6', palette: 'M12 3a9 9 0 100 18c1.5 0 2-1 1.5-2-.6-1.3.2-2.5 1.5-2.5H17a4 4 0 004-4c0-5-4-9.5-9-9.5z', message: 'M4 5h16v11H9l-5 4z',
  lock: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3', heart: 'M12 20s-8-5-8-11a4.5 4.5 0 018-2.5A4.5 4.5 0 0120 9c0 6-8 11-8 11z', door: 'M6 21V4h9l3 2v15M3 21h18M12 12h.01', briefcase: 'M3 8h18v12H3zM9 8V5h6v3M3 13h18',
  ban: 'M12 21a9 9 0 100-18 9 9 0 000 18zM5.6 5.6l12.8 12.8', book: 'M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM5 17a3 3 0 013-3h11', chart: 'M4 20V4M4 20h16M8 16v-5M13 16V8M18 16v-3', code: 'M9 8l-5 4 5 4M15 8l5 4-5 4M13 6l-2 12',
  scale: 'M12 4v16M6 20h12M5 8h14M5 8l-2.5 6a3 3 0 005 0zM19 8l-2.5 6a3 3 0 005 0z', flame: 'M12 3c1 3 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z', building: 'M5 21V5a1 1 0 011-1h8a1 1 0 011 1v16M15 11h3a1 1 0 011 1v9M3 21h18M9 8h2M9 12h2M9 16h2', gem: 'M6 4h12l3 5-9 11L3 9zM3 9h18M9 4l-2 5 5 11 5-11-2-5', skull: 'M12 3a8 8 0 00-5 14v3h10v-3a8 8 0 00-5-14zM9 12h.01M15 12h.01M10 17v3M14 17v3', sparkle: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z', star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z', crown: 'M3 8l4 4 5-7 5 7 4-4-2 11H5z', file: 'M6 3h8l4 4v14H6zM14 3v4h4M9 13h6M9 17h6', gavel: 'M14 4l6 6-3 3-6-6zM11 7 4 14l3 3 7-7M3 21h9', globe: 'M12 21a9 9 0 100-18 9 9 0 000 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  hash: 'M5 9h14M5 15h14M10 4 8 20M16 4l-2 16', history: 'M3 12a9 9 0 109-9 9 9 0 00-7 3.5M3 4v4h4M12 8v5l3 2', key: 'M14 10a4 4 0 11-3 4l-7 7v-3H7v-2h2l2-2M15.5 8.5h.01', keyboard: 'M3 6h18v12H3zM7 10h.01M11 10h.01M15 10h.01M7 14h10',
  language: 'M4 5h9M8 3v2M6 5c1 4 4 7 7 8M12 5c-1 4-4 7-8 9M14 21l4-10 4 10M15.5 18h5', link: 'M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3A4 4 0 0011 18.7l1-1',
  megaphone: 'M3 10v4h4l9 5V5L7 10zM19 9a4 4 0 010 6', move: 'M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3', percent: 'M19 5 5 19M7 9a2 2 0 100-4 2 2 0 000 4zM17 19a2 2 0 100-4 2 2 0 000 4z',
  shop: 'M4 9l1.5-5h13L20 9M4 9v11h16V9M4 9a3 3 0 006 0 3 3 0 006 0 3 3 0 004 0M10 20v-5h4v5', user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 3.5-6 8-6s8 2 8 6', warehouse: 'M3 21V9l9-5 9 5v12M7 21v-7h10v7M7 17h10', wifi: 'M2 9a15 15 0 0120 0M5 12.5a10 10 0 0114 0M8.5 16a5 5 0 017 0M12 19.5h.01',
  route: 'M6 19a2 2 0 100-4 2 2 0 000 4zM18 9a2 2 0 100-4 2 2 0 000 4zM8 17h6a3 3 0 000-6h-4a3 3 0 010-6h6', face: 'M12 21a8 8 0 100-16 8 8 0 000 16zM9 10v1.5M15 10v1.5M9 15c1.7 1.6 4.3 1.6 6 0', bolt: 'M13 3 5 14h6l-1 7 8-11h-6z', grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z', engine: 'M4 9h3l2-2h6v3h3v6h-3v2H9l-2-2H4zM2 12h2M20 12h2', card: 'M3 6h18v12H3zM3 10h18',
  search: 'M11 18a7 7 0 100-14 7 7 0 000 14zM20 20l-4-4', bell: 'M6 16V11a6 6 0 0112 0v5l2 2H4zM10 21h4', home: 'M3 11l9-8 9 8M5 10v10h14V10', star: 'M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.3l1-6.2L3 9.7l6.2-.9z',
  copy: 'M8 8h12v12H8zM4 16V4h12', menu: 'M4 6h16M4 12h16M4 18h16', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z', pin: 'M12 21s-6-6-6-11a6 6 0 0112 0c0 5-6 11-6 11zM12 12a2 2 0 100-4 2 2 0 000 4z',
};
// (v1.2.43) icônes utilisées par les modules du panel mais absentes (elles s'affichaient comme un « i »)
Object.assign(ICONS, {'arrow': 'M5 12h14M13 6l6 6-6 6', 'bag': 'M6 8h12l1 12H5zM9 8V6a3 3 0 016 0v2', 'bed': 'M3 18V7M3 14h18v4M21 14v-2a3 3 0 00-3-3h-8v5M7 11.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z', 'brush': 'M18.5 3.5l2 2-8.5 8.5-3-3zM8.5 11.5c-2.4 0-4 1.6-4 4 0 2-.8 3.2-1.5 4 3.5.5 8.5-.5 8.5-5', 'cart': 'M3 4h3l2 11h10l2-8H7M10 20h.01M17 20h.01', 'chat': 'M4 5h16v11H9l-5 4z', 'close': 'M6 6l12 12M18 6 6 18', 'crosshair': 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 3v5M12 16v5M3 12h5M16 12h5', 'cube': 'M12 3l8 4.5v9L12 21l-8-4.5v-9zM4 7.5l8 4.5 8-4.5M12 12v9', 'dice': 'M5 4h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V5a1 1 0 011-1zM8.5 8.5h.01M15.5 8.5h.01M12 12h.01M8.5 15.5h.01M15.5 15.5h.01', 'drop': 'M12 3s6 6.5 6 11a6 6 0 01-12 0c0-4.5 6-11 6-11z', 'fire': 'M12 3c1 4 5.5 5.5 5.5 10.5a5.5 5.5 0 01-11 0c0-3 2-4.5 2-7.5 2 1 3.5 3 3.5 5.5', 'flag': 'M5 21V4M5 4h11l-2 4 2 4H5', 'food': 'M7 3v8a2 2 0 002 2v8M7 3v6M11 3v6M9 3v10M17 3c-2 2-3 5-3 8h3v10', 'fuel': 'M5 21V5a2 2 0 012-2h6a2 2 0 012 2v16M5 21h10M15 9h2a2 2 0 012 2v6a1.5 1.5 0 003 0V9l-3-3', 'gift': 'M4 11h16v9H4zM3 8h18v3H3zM12 8v12M12 8c-2-4-6-3-5 0M12 8c2-4 6-3 5 0', 'gps': 'M12 21s-6-6-6-11a6 6 0 0112 0c0 5-6 11-6 11zM12 12a2 2 0 100-4 2 2 0 000 4z', 'hand': 'M8 11V5a1.5 1.5 0 013 0v5M11 10V4a1.5 1.5 0 013 0v6M14 10V6a1.5 1.5 0 013 0v8c0 4-2 7-6 7-3 0-5-2-6-5l-1-4a1.5 1.5 0 013-1', 'hanger': 'M12 8a2 2 0 10-2-2M12 8v2L3 17h18z', 'help': 'M12 21a9 9 0 100-18 9 9 0 000 18zM9.5 9.5a2.5 2.5 0 114 2c-1 .7-1.5 1.2-1.5 2.5M12 17h.01', 'id': 'M3 5h18v14H3zM7 10a2 2 0 104 0 2 2 0 00-4 0zM6 16c.5-2 5.5-2 6 0M14 10h4M14 14h4', 'mic': 'M12 3a3 3 0 013 3v6a3 3 0 01-6 0V6a3 3 0 013-3zM6 11a6 6 0 0012 0M12 17v4', 'music': 'M9 18V6l10-2v12M9 18a3 3 0 11-6 0 3 3 0 016 0zM19 16a3 3 0 11-6 0 3 3 0 016 0z', 'note': 'M6 3h12v18H6zM9 8h6M9 12h6M9 16h3', 'phone': 'M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2', 'puzzle': 'M10 4a2 2 0 014 0v2h4v4h-2a2 2 0 000 4h2v4h-4v-2a2 2 0 00-4 0v2H6v-4h2a2 2 0 000-4H6V6h4z', 'refresh': 'M4 12a8 8 0 0114-5l2-2v6h-6l2.3-2.3A5.5 5.5 0 006 12M20 12a8 8 0 01-14 5l-2 2v-6h6l-2.3 2.3A5.5 5.5 0 0018 12', 'scissors': 'M6 8a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM6 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM8 6.5 20 17M8 17.5 20 7', 'siren': 'M6 18v-6a6 6 0 0112 0v6M4 18h16M12 3v2M3.5 6.5 5 8M20.5 6.5 19 8', 'tag': 'M3 12V4h8l10 10-8 8zM7.5 8h.01', 'tool': 'M14.5 5.5a4 4 0 00-5 5L4 16l4 4 5.5-5.5a4 4 0 005-5l-2.5 2.5-2.5-.5-.5-2.5z', 'truck': 'M3 6h11v10H3zM14 10h4l3 3v3h-7M7 19a2 2 0 100-4 2 2 0 000 4M17 19a2 2 0 100-4 2 2 0 000 4', 'wallet': 'M4 7h14a2 2 0 012 2v9a2 2 0 01-2 2H6a2 2 0 01-2-2zM4 7l12-3v3M16 13h2', 'wheel': 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 8.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7zM12 3v5.5M12 15.5V21M3 12h5.5M15.5 12H21'});
function ico(name, cls) {
  const NS = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'i' + (cls ? ' ' + cls : ''));
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', ICONS[name] || ICONS.info); s.appendChild(p);
  return s;
}

/* ---------- textes de l'interface (FR / EN) ---------- */
const TXT = {
  fr: { search: 'Rechercher un réglage…', home: 'Accueil', save: 'Enregistrer', cancel: 'Annuler', confirm: 'Confirmer', close: 'Fermer', copy: 'Copier', copied: 'Copié.', loading: 'Chargement…',
    hello: 'Bonjour', pick: 'Choisis un module pour commencer.', favs: 'Favoris', history: 'Historique', revert: 'Restaurer', noRes: 'Aucun résultat.', pin: 'PIN de sécurité',
    pinHelp: 'Cette action est protégée par ton PIN.', expired: 'Session expirée', expiredT: 'Rouvre le panel pour continuer.', revoked: 'Accès retiré', revokedT: 'Tes droits ont changé : le panel a été fermé.',
    denied: 'Accès refusé', deniedT: "Tu n'as pas la permission d'ouvrir le panel.", conn: 'Connexion perdue.', empty: 'Rien à afficher.', page: 'Page', of: 'sur', addRow: 'Ajouter une ligne', mypos: 'Ma position',
    restart: 'Redémarrage requis', notifs: 'Notifications', none: 'Aucune notification.', copyHint: 'Le navigateur intégré ne peut pas enregistrer de fichier : copie le contenu ci-dessous.', run: 'Exécuter', allow: 'Autorisé', deny: 'Refusé', inh: 'Hérité', set: 'défini', rules: 'Motifs personnalisés', addRule: 'Ajouter un motif', before: 'Avant', after: 'Après', pos: 'Position', scale: 'Taille', opac: 'Opacité', reset: 'Réinitialiser', prefsT: 'Apparence personnelle' },
  en: { search: 'Search a setting…', home: 'Home', save: 'Save', cancel: 'Cancel', confirm: 'Confirm', close: 'Close', copy: 'Copy', copied: 'Copied.', loading: 'Loading…',
    hello: 'Hello', pick: 'Pick a module to get started.', favs: 'Favourites', history: 'History', revert: 'Restore', noRes: 'No results.', pin: 'Security PIN',
    pinHelp: 'This action is protected by your PIN.', expired: 'Session expired', expiredT: 'Reopen the panel to continue.', revoked: 'Access removed', revokedT: 'Your rights changed: the panel was closed.',
    denied: 'Access denied', deniedT: 'You are not allowed to open the panel.', conn: 'Connection lost.', empty: 'Nothing to show.', page: 'Page', of: 'of', addRow: 'Add a row', mypos: 'My position',
    restart: 'Restart required', notifs: 'Notifications', none: 'No notifications.', copyHint: 'The in-game browser cannot save files: copy the content below.', run: 'Run', allow: 'Allowed', deny: 'Denied', inh: 'Inherited', set: 'set', rules: 'Custom patterns', addRule: 'Add a pattern', before: 'Before', after: 'After', pos: 'Position', scale: 'Size', opac: 'Opacity', reset: 'Reset', prefsT: 'Personal appearance' },
};
const t = (k) => (TXT[S.lang] || TXT.fr)[k] || TXT.fr[k] || k;

/* ---------- état ---------- */
const S = { token: null, boot: null, lang: 'fr', mod: null, view: null, tab: null, params: {}, busy: false, fav: [], pending: {}, seq: 1, notifs: [], unread: 0, prefs: {}, dirty: false };
const root = $('#root');

/* ---------- transport ---------- */
const chunks = {};
function post(name, body) {
  if (window.__pbTransport) return window.__pbTransport(name, body);
  return fetch('https://' + RES + '/' + name, { method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify(body) }).catch(() => {});
}
function call(name, payload, opts) {
  return new Promise((resolve) => {
    const id = 'r' + (S.seq++);
    const timer = setTimeout(() => { if (S.pending[id]) { delete S.pending[id]; resolve({ ok: false, err: t('conn') }); } }, (opts && opts.timeout) || 45000);
    S.pending[id] = (r) => { clearTimeout(timer); resolve(r); };
    const json = JSON.stringify(payload == null ? {} : payload);
    if (json.length <= UP_LIMIT) post('call', { token: S.token, id, name, json });
    else {
      const n = Math.ceil(json.length / CHUNK);
      for (let i = 1; i <= n; i++) post('upChunk', { token: S.token, id, name, i, n, part: json.slice((i - 1) * CHUNK, i * CHUNK) });
    }
  });
}
function onMsg(kind, id, json) {
  let data; try { data = JSON.parse(json); } catch (e) { return; }
  if (kind === 'opened') return openSession(data);
  if (kind === 'res') { const f = S.pending[id]; if (f) { delete S.pending[id]; f(data); } return; }
  if (kind === 'push') return onPush(data);
  if (kind === 'revoked') return overlay(t('revoked'), t('revokedT'));
  if (kind === 'denied') return overlay(t('denied'), (data && data.reason) || t('deniedT'), true);
}
window.addEventListener('message', (e) => {
  const d = e.data || {};
  if (d.type === 'msg') onMsg(d.kind, d.id, d.json);
  else if (d.type === 'closed') hidePanel();
});
window.__pbMsg = onMsg;
if (window.PBGame) window.PBGame.assetFetcher = (id) => {
  if (!S.token) return window.PBGame.post('asset.want', { id });
  call('asset.get', { id }).then((r) => { if (r.ok && r.data) window.__pbGameMsg('asset', { id, uri: r.data.uri }); });
};

function closePanel() { post('close', {}); hidePanel(); }
function hidePanel() { root.classList.add('hidden'); clear(root); S.token = null; for (const k in S.pending) { S.pending[k]({ ok: false, expired: true }); delete S.pending[k]; } }
document.addEventListener('keydown', (e) => {
  if (root.classList.contains('hidden')) return;
  if (e.key === 'Escape') { const ms = document.querySelectorAll('.modal-bg'); const m = ms[ms.length - 1]; if (m && S.token) m.remove(); else if (S.drawer) toggleDrawer(false); else closePanel(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); const i = $('#gsearch'); if (i) i.focus(); }
});

/* ---------- toasts, modales ---------- */
function toast(text, ok) {
  if (!text) return;
  const el = h('div', { class: 'toast ' + (ok === false ? 'err' : 'ok') }, ico(ok === false ? 'alert' : 'check'), h('span', null, text));
  const box = $('#toasts'); while (box.children.length >= 3) box.firstChild.remove();
  box.appendChild(el); setTimeout(() => el.remove(), 4200 + Math.min(text.length * 25, 4000));
}
function modal(title, body, buttons, wide) {
  const bg = h('div', { class: 'modal-bg', onmousedown: (e) => { if (e.target === bg) bg.remove(); } },
    h('div', { class: 'modal' + (wide ? ' wide' : ''), role: 'dialog' }, h('h2', null, title), h('div', { class: 'mb' }, body), h('div', { class: 'mf' }, buttons || [h('button', { class: 'pl', onclick: () => bg.remove() }, t('close'))])));
  document.body.appendChild(bg);
  return bg;
}
function overlay(title, text, hard) {
  clear(root); root.classList.remove('hidden');
  root.appendChild(h('div', { class: 'modal-bg' }, h('div', { class: 'modal' }, h('h2', null, title), h('div', { class: 'mb' }, text), h('div', { class: 'mf' }, h('button', { class: 'pl pri', onclick: closePanel }, t('close'))))));
  S.token = hard ? null : S.token;
}

/* ---------- exécution d'une action (confirmation, PIN, retours) ---------- */
async function run(action, payload, o) {
  o = o || {};
  payload = Object.assign({}, payload || {});
  let res = await call(action, payload);
  while (res && res.confirm) {
    const c = res.confirm;
    const pinIn = c.pin ? h('input', { type: 'password', inputmode: 'numeric', maxlength: 8, class: 'cinp', autocomplete: 'off' }) : null;
    const go = await new Promise((resolve) => {
      const bg = modal(c.title || t('confirm'), [h('p', null, c.text || ''), pinIn ? h('div', { class: 'pin' }, h('label', { class: 'cd' }, t('pinHelp')), pinIn) : null],
        [h('button', { class: 'pl', onclick: () => { bg.remove(); resolve(false); } }, t('cancel')),
         h('button', { class: 'pl ' + (c.danger ? 'danger' : 'pri'), onclick: () => { bg.remove(); resolve(true); } }, t('confirm'))]);
      if (pinIn) setTimeout(() => pinIn.focus(), 30);
    });
    if (!go) return { ok: false, cancelled: true };
    payload._confirm = true; if (pinIn) payload._pin = pinIn.value;
    res = await call(action, payload);
  }
  if (!res) return { ok: false };
  if (res.expired) { overlay(t('expired'), t('expiredT')); return res; }
  if (res.pinError) { toast(typeof res.pinError === 'string' ? res.pinError : 'PIN incorrect.', false); return res; }
  if (res.ok === false) { toast(res.err || 'Action impossible.', false); return res; }
  if (res.toast && !o.quiet) toast(res.toast, true);
  const d = res.data;
  if (action === 'audit.detail' && d) { showAudit(d); return res; }
  if (d && typeof d === 'object') {
    if (d.download) showDownload(d.download);
    if (d.diff) showDiff(d.diff, d.title);
    if (d.open) { await openModule(S.mod, { tab: d.open.tab, params: d.open.params }); return res; }
  }
  if (res.close) { closePanel(); return res; }
  if (res.refresh !== false && !o.noRefresh && (o.refresh || res.refresh)) await reload();
  return res;
}
function showDownload(d) {
  const ta = h('textarea', { readOnly: true, spellcheck: 'false' }, d.text || '');
  ta.value = d.text || '';
  const bg = modal(d.name || 'Export', [h('p', { class: 'cd' }, t('copyHint')), ta], [
    h('button', { class: 'pl', onclick: () => bg.remove() }, t('close')),
    h('button', { class: 'pl pri', onclick: () => { ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} toast(ok ? t('copied') : 'Ctrl+C', ok); } }, ico('copy'), t('copy'))], true);
  setTimeout(() => ta.select(), 50);
}
function diffBlock(lines) {
  const box = h('div', { class: 'diff' });
  for (const l of lines || []) {
    if (typeof l === 'string') box.appendChild(h('div', null, l));
    else { const k = l.t || l.type || l.op || ' '; box.appendChild(h('div', { class: k === '+' || k === 'add' ? 'p' : (k === '-' || k === 'del' ? 'm' : (k === '…' || k === 'gap' ? 'e' : '')) }, (k === 'add' ? '+ ' : k === 'del' ? '- ' : k.length === 1 ? k + ' ' : '  ') + esc(l.text != null ? l.text : l.l))); }
  }
  return box;
}
function showDiff(diff, title) { modal(title || 'Différences', isArr(diff) ? diffBlock(diff) : h('pre', null, JSON.stringify(diff, null, 2)), null, true); }
function prettyVal(v) { if (v == null) return '—'; if (typeof v === 'string') return v; return JSON.stringify(v, null, 1); }

function showAudit(d) {
  modal('#' + d.id + ' · ' + d.action, [
    h('div', { class: 'kv' }, [['Catégorie', d.cat], ['Acteur', d.actor], ['Cible', d.target], ['Date', new Date((d.at || 0) * 1000).toLocaleString()]].map((p) => [h('span', null, p[0]), h('span', null, esc(p[1]))]).flat()),
    h('h4', null, t('before')), h('pre', { class: 'diff' }, prettyVal(d.before)), h('h4', null, t('after')), h('pre', { class: 'diff' }, prettyVal(d.after)), d.data ? h('pre', { class: 'diff' }, prettyVal(d.data)) : null], null, true);
}
async function showHistory(h0) {
  const r = await call('cfg.history', { ns: h0.ns, k: h0.k });
  if (!r.ok) return toast(r.err || 'Erreur', false);
  const rows = r.data || [];
  const tb = h('table', null, h('thead', null, h('tr', null, ['Date', 'Clé', 'Avant', 'Après', 'Par', ''].map((x) => h('th', null, x)))),
    h('tbody', null, rows.map((e) => h('tr', null, h('td', null, new Date((e.at || 0) * 1000).toLocaleString()), h('td', { class: 'mono' }, esc(e.key)), h('td', { class: 'mono' }, prettyVal(e.before).slice(0, 80)), h('td', { class: 'mono' }, prettyVal(e.after).slice(0, 80)), h('td', null, esc(e.actor)),
      h('td', { class: 'act' }, e.reverted ? h('span', { class: 'chip off' }, '↺') : h('button', { class: 'pl sm', onclick: async () => { const x = await run('cfg.revert', { id: e.id }, { refresh: true }); if (x.ok) { bg.remove(); } } }, ico('undo'), t('revert')))))));
  const bg = modal(t('history'), rows.length ? h('div', { class: 'tbl-wrap' }, tb) : h('div', { class: 'empty' }, t('empty')), null, true);
}

/* ---------- session, préférences, apparence ---------- */
function openSession(d) {
  S.token = d.token; S.boot = d.boot; S.prefs = isArr(d.boot.prefs) || !d.boot.prefs ? {} : d.boot.prefs;
  S.fav = isArr(S.prefs.favorites) ? S.prefs.favorites.slice() : [];
  S.lang = S.prefs.lang || (d.boot.interface && d.boot.interface.lang) || 'fr';
  if (S.lang !== 'en') S.lang = 'fr';
  root.classList.remove('hidden');
  applyLook();
  buildShell();
  const last = S.prefs.lastModule;
  if (last && S.boot.nav.some((m) => m.id === last)) openModule(last); else showHome();
}
function applyLook() {
  const I = (S.boot && S.boot.interface) || {}, P = S.prefs || {}, br = (S.boot && S.boot.brand) || {};
  const st = root.style;
  const fest = br.season || null;   // fête active côté serveur : { id, theme, decor }
  const theme = P.theme || (fest && fest.theme) || I.theme || 'elyx';
  root.setAttribute('data-theme', theme);
  // décor de fête : sur le thème de fête choisi (par le serveur ou à la main), sauf animations coupées
  const decorOn = (theme === 'halloween' || theme === 'noel') && (fest ? fest.decor !== false : true) && I.animations !== false;
  root.setAttribute('data-fest', decorOn ? theme : '');
  root.setAttribute('data-density', P.density || I.density || 'comfort');
  root.setAttribute('data-anim', I.animations === false ? 'off' : 'on');
  const num = (v, d, a, b) => { v = Number(v); return isFinite(v) ? Math.min(b, Math.max(a, v)) : d; };
  st.setProperty('--a', String(P.opacity != null ? num(P.opacity, 30, 0, 100) / 100 * 0.9 + 0.05 : ({ clear: 0.30, soft: 0.50, solid: 0.72, full: 0.92 })[I.glass_level] || (I.glass != null && !I.glass_level ? num(I.glass, 0.3, 0.05, 0.95) : 0.72)));
  st.setProperty('--blur', (P.blur != null ? num(P.blur, 18, 0, 40) : num(I.blur, 18, 0, 40)) + 'px');
  st.setProperty('--r', num(I.radius, 22, 0, 32) + 'px');
  st.setProperty('--fs', String(num(I.font_scale, 1, 0.85, 1.3)));
  st.setProperty('--panel-x', String(num(I.panel_x, 50, 20, 80)));
  st.setProperty('--panel-w', String(num(I.panel_w, 100, 50, 100)));
  root.setAttribute('data-full', num(I.panel_w, 100, 50, 100) >= 99 ? '1' : '');
  const hex = (c) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : null);
  if (!P.theme && hex(br.color)) { st.setProperty('--acc', br.color); st.setProperty('--acc2', hex(br.color2) || br.color); }
  else { st.removeProperty('--acc'); st.removeProperty('--acc2'); }
  if (hex(P.accent)) st.setProperty('--acc', P.accent);
  { const a = (hex(P.accent) || (!P.theme && hex(br.color)) || ''); if (a) { const n = parseInt(a.slice(1), 16), L = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; st.setProperty('--onacc', L > 0.58 ? '#12141a' : '#ffffff'); } else st.removeProperty('--onacc'); }
  root.classList.toggle('nobig', I.big_logo === false);
  if (hex(br.color)) st.setProperty('--logo1', br.color); if (hex(br.color2)) st.setProperty('--logo2', br.color2);
}
let prefTimer = null;
function savePrefs(patch) {
  Object.assign(S.prefs, patch); clearTimeout(prefTimer);
  prefTimer = setTimeout(() => call('ui.prefs.set', { values: patch }), 400);
}

/* ---------- logo ---------- */
function logo(small) {
  const b = S.boot.brand || {};
  if (b.logoUrl) return h('div', { class: 'logo-big' + (small ? ' sm' : '') }, h('img', { src: b.logoUrl, alt: b.name || '' }));
  const name = String(b.name || 'Serveur'), sp = name.indexOf(' '), cut = sp > 0 ? sp : Math.max(1, Math.ceil(name.length / 2));
  return h('div', { class: 'logo-big' + (small ? ' sm' : '') + (name.length > 18 ? ' xl' : name.length > 12 ? ' long' : '') }, h('b', null, name.slice(0, cut), h('i', null, name.slice(cut))), b.tagline && !small ? h('small', null, b.tagline) : null);
}

/* ---------- structure générale ---------- */
const R = {}; // références DOM
function buildShell() {
  clear(root);
  const U = S.boot.user;
  R.search = h('input', { id: 'gsearch', placeholder: t('search'), autocomplete: 'off', oninput: onSearch, onkeydown: onSearchKey });
  R.res = h('div', { class: 'res hidden' });
  R.dot = h('span', { class: 'dot hidden' }, '0');
  R.side = h('nav', { class: 'side' + (S.prefs.sidebar === false ? ' min' : '') });
  R.banner = h('div', { class: 'banner' });
  R.tabs = h('div', { class: 'ptabs' });
  R.content = h('div', { class: 'content' });
  R.me = h('div', { class: 'me' });
  R.main = h('section', { class: 'main' },
    h('header', { class: 'top' },
      R.banner,
      h('div', { class: 'tools-top' },
        h('div', { class: 'sbar' }, ico('search'), R.search, h('kbd', null, 'Ctrl K'), R.res),
        h('button', { class: 'circ', title: t('notifs'), onclick: () => toggleDrawer() }, ico('bell'), R.dot),
        h('button', { class: 'circ', title: t('close'), onclick: closePanel }, ico('x')))),
    (R.split = h('div', { class: 'split single' }, R.tabs, R.content)));
  const initials = (U.name || '?').split(/\s+/).map((x) => x[0]).join('').slice(0, 2).toUpperCase();
  R.me.appendChild(h('div', { class: 'av' }, initials));
  R.me.appendChild(h('div', { class: 'me-t' }, h('b', null, esc(U.name)), h('small', null, esc(U.gradeLabel || U.grade || ''))));
  root.appendChild(h('div', { class: 'frame' },
    h('aside', { class: 'rail' },
      h('div', { class: 'brand-big', onclick: showHome }, logo(false)),
      R.side, R.me),
    R.main, h('div', { class: 'fest' })));
  buildSide();
  loadNotifs();
}
function buildSide() {
  clear(R.side);
  const tab = S.mod ? 'config' : (S.tab || 'home');
  const T = [['home', 'home', t('home')], ['config', 'settings', 'Configuration'], ['tools', 'star', 'Outils']];
  T.forEach((x) => R.side.appendChild(h('button', { class: 'ni' + (tab === x[0] ? ' on' : ''), 'data-tab': x[0], onclick: () => (x[0] === 'home' ? showHome() : x[0] === 'config' ? showConfig() : showTools()), title: x[2] }, ico(x[1]), h('span', null, x[2]))));
}

/* ---------- accueil ---------- */
function spark(vals, color) {
  const NS = 'http://www.w3.org/2000/svg', W = 120, H = 34;
  const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); svg.setAttribute('preserveAspectRatio', 'none'); svg.setAttribute('class', 'dh-sp');
  const v = (vals || []).slice(-24); if (v.length < 2) return svg;
  const mx = Math.max.apply(null, v), mn = Math.min.apply(null, v), span = Math.max(1, mx - mn);
  const pts = v.map((y, i) => [i * W / (v.length - 1), H - 4 - (H - 10) * (y - mn) / span]);
  const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = document.createElementNS(NS, 'path'); area.setAttribute('d', line + ' L' + W + ' ' + H + ' L0 ' + H + ' Z'); area.setAttribute('fill', color); area.setAttribute('opacity', '.16'); svg.appendChild(area);
  const ln = document.createElementNS(NS, 'path'); ln.setAttribute('d', line); ln.setAttribute('fill', 'none'); ln.setAttribute('stroke', color); ln.setAttribute('stroke-width', '2'); ln.setAttribute('stroke-linejoin', 'round'); svg.appendChild(ln);
  return svg;
}
function dashboard(d) {
  const sv = d.server || {}, res = d.res || {};
  const wrap = h('div', { class: 'dh' });
  const dt = new Date();
  const when = dt.toLocaleDateString(S.lang === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) + ', ' + dt.toLocaleTimeString(S.lang === 'en' ? 'en-GB' : 'fr-FR', { hour: '2-digit', minute: '2-digit' });
  const open = (m) => () => { if (S.boot.nav.some((x) => x.id === m)) openModule(m); };
  const stop = (res.stopped || []).length;
  wrap.appendChild(h('div', { class: 'hello' }, h('h1', null, t('hello') + ', ', h('span', null, esc(S.boot.user.name))),
    h('p', null, when.charAt(0).toUpperCase() + when.slice(1) + (stop ? ' · ' + stop + (stop > 1 ? ' ressources arrêtées' : ' ressource arrêtée') : ' · tout fonctionne'))));
  // fiche du serveur
  const stat = (l, v, sub, tone) => h('div', { class: 'dh-st' }, h('small', null, l), h('b', null, v), h('em', { class: tone || '' }, sub || ''));
  wrap.appendChild(h('section', { class: 'dh-srv' },
    h('div', { class: 'dh-sh' }, h('h2', null, esc(sv.name || '')), h('span', { class: 'dh-ok' }, h('i'), 'En ligne'), h('span', { class: 'dh-tag' }, 'v' + (S.boot.version || '1'))),
    h('div', { class: 'dh-sg' },
      stat('Panel actif depuis', sv.upText || '—', 'Depuis le dernier démarrage'),
      stat('Ressources', (res.started || 0) + ' sur ' + (res.total || 0), stop ? (res.stopped.slice(0, 2).join(', ') + (stop > 2 ? '…' : '') + ' arrêtée' + (stop > 1 ? 's' : '')) : 'Toutes démarrées', stop ? 'warn' : 'ok'),
      stat('Mémoire du panel', (d.lua_mb != null ? d.lua_mb : '—') + ' Mo', 'Mémoire Lua utilisée'),
      stat('Latence moyenne', d.ping != null ? d.ping + ' ms' : '—', d.ping != null && d.ping > 120 ? 'À surveiller' : 'Stable', d.ping != null && d.ping > 120 ? 'warn' : '')),
    h('div', { class: 'dh-sa' }, h('button', { class: 'dh-b pri', onclick: open('monitor') }, ico('activity'), 'Monitoring'), h('button', { class: 'dh-b', onclick: open('resources') }, ico('box'), 'Ressources'), h('button', { class: 'dh-b', onclick: open('logs') }, ico('book'), 'Journaux'))));
  // nouveautés (journal des mises à jour)
  if (d.news && d.news.entries && d.news.entries.length) {
    const nw = d.news, box = h('section', { class: 'dh-card dh-news' });
    const draw = () => {
      clear(box);
      box.appendChild(h('div', { class: 'dh-ch' }, h('h3', null, 'Nouveautés'), nw.unseen > 0 ? h('span', { class: 'dh-pill ok' }, nw.unseen + ' nouveau' + (nw.unseen > 1 ? 'x' : '')) : h('span', { class: 'dh-pill' }, 'À jour'),
        nw.unseen > 0 ? h('button', { class: 'dh-b', onclick: async () => { const r = await call('news.read', {}); if (r && r.ok) { nw.unseen = 0; nw.entries.forEach((e) => { e.new = false; }); draw(); } } }, ico('check'), 'Tout marquer comme lu') : h('button', { class: 'dh-b', onclick: open('whatsnew') }, 'Historique')));
      nw.entries.forEach((e) => box.appendChild(h('div', { class: 'dh-nw' + (e.new ? ' new' : '') }, h('b', null, e.title), h('small', null, e.date || ''),
        h('ul', null, e.items.slice(0, 5).map((it) => h('li', null, h('span', { class: 'dh-tg' }, it.tag), ' ', it.text, it.module ? h('button', { class: 'dh-go', onclick: open(it.module) }, 'Ouvrir') : null))))));
    };
    draw();
    wrap.appendChild(box);
  }
  // indicateurs
  const ch = d.chart || {};
  const kpi = (icon, l, v, sub, vals, color, tone) => h('div', { class: 'dh-k' }, h('div', { class: 'dh-kh' }, h('span', { class: 'dh-ki' }, ico(icon)), h('small', null, l)), h('div', { class: 'dh-kv' }, h('b', null, v), sub[0] ? h('i', null, sub[0]) : null), h('em', { class: tone || '' }, sub[1] || ''), vals ? spark(vals, color) : null);
  wrap.appendChild(h('div', { class: 'dh-kpis' },
    kpi('users', 'Joueurs en ligne', String(sv.online || 0), ['/ ' + (sv.max || 0), sv.online ? 'Connectés maintenant' : 'Personne pour le moment'], ch.players, '#7cc8ff'),
    kpi('chart', 'Pic récent', String(d.peak != null ? d.peak : '—'), ['', 'Sur la période suivie'], ch.players, '#dfe2e7'),
    kpi('globe', 'Latence', d.ping != null ? d.ping + ' ms' : '—', ['', 'Moyenne des joueurs'], ch.ping, '#ffc65c', d.ping > 120 ? 'warn' : 'ok'),
    kpi('box', 'Ressources', String(res.started || 0), ['/ ' + (res.total || 0), stop ? stop + ' arrêtée' + (stop > 1 ? 's' : '') : 'Toutes démarrées'], null, '#5ee09a', stop ? 'warn' : 'ok')));
  // courbe + à faire
  const left = h('div', { class: 'dh-col' }), right = h('div', { class: 'dh-col' });
  if (ch.players && ch.players.length > 1) left.appendChild(blkChart({ id: 'dash', title: 'Fréquentation', labels: ch.labels, series: [{ name: 'Joueurs', values: ch.players }] }));
  else left.appendChild(card('Fréquentation', null, h('p', { class: 'dh-mute' }, 'La courbe apparaît après quelques minutes de suivi (une mesure par minute).')));
  const todo = d.todo || [], left2 = todo.filter((x) => !x.done).length;
  right.appendChild(h('section', { class: 'dh-card' }, h('div', { class: 'dh-ch' }, h('h3', null, 'À faire'), h('span', { class: 'dh-pill' }, (todo.length - left2) + ' sur ' + todo.length)),
    h('div', { class: 'dh-td' }, todo.map((x) => h('button', { class: 'dh-t' + (x.done ? ' done' : ''), onclick: open(x.module) }, h('span', { class: 'dh-ck' }, x.done ? ico('check') : null), h('span', { class: 'dh-tt' }, h('b', null, x.title), h('small', null, x.sub)))))));
  wrap.appendChild(h('div', { class: 'dh-two' }, left, right));
  // en ligne + dernières actions
  const row2 = h('div', { class: 'dh-two eq' });
  if (d.players) row2.appendChild(h('section', { class: 'dh-card' }, h('div', { class: 'dh-ch' }, h('h3', null, 'En ligne maintenant'), h('span', { class: 'dh-pill ok' }, String(sv.online || 0))),
    d.players.length ? h('div', { class: 'dh-pl' }, d.players.map((p) => h('div', { class: 'dh-p' }, h('span', { class: 'dh-av' }, esc(String(p.name).charAt(0).toUpperCase())), h('span', { class: 'dh-pn' }, h('b', null, esc(p.name)), h('small', null, 'id ' + p.id + ' · ' + esc(p.job))), h('em', null, p.ping + ' ms')))) : h('p', { class: 'dh-mute' }, 'Aucun joueur connecté.')));
  if (d.feed) row2.appendChild(h('section', { class: 'dh-card' }, h('div', { class: 'dh-ch' }, h('h3', null, 'Dernières actions'), h('button', { class: 'dh-lk', onclick: open('logs') }, 'Tout le journal')),
    d.feed.length ? h('div', { class: 'dh-fd' }, d.feed.map((f) => h('div', { class: 'dh-f' }, h('span', { class: 'dh-fi' }, ico('history')), h('span', { class: 'dh-ft' }, h('b', null, esc(f.who || 'Système')), ' ', esc(f.what), f.target ? h('small', null, esc(f.target)) : null), h('em', null, f.ago)))) : h('p', { class: 'dh-mute' }, 'Rien pour le moment.')));
  if (row2.children.length) wrap.appendChild(row2);
  return wrap;
}
function showHome() {
  S.tab = 'home'; S.mod = null; S.view = null; buildSide();
  clear(R.banner); clear(R.tabs); clear(R.content); R.split.classList.add('single');
  R.banner.appendChild(h('div', { class: 'bn-t' }, h('small', null, esc((S.boot.brand && S.boot.brand.name) || 'Shadow Base')), h('b', null, t('home'))));
  R.banner.appendChild(h('div', { class: 'bn-r' }, h('span', { class: 'chip' }, (S.boot.framework || 'none').toUpperCase()), h('span', { class: 'chip' }, 'v' + (S.boot.version || '1'))));
  const nav = S.boot.nav;
  const dashBox = h('div', { class: 'dh-box' });
  R.content.appendChild(dashBox);
  dashBox.appendChild(h('div', { class: 'hello' }, h('h1', null, t('hello') + ', ', h('span', null, esc(S.boot.user.name))), h('p', null, t('pick'))));
  call('ui.dashboard', {}).then((r) => { if (S.mod || !dashBox.isConnected) return; if (r && r.ok && r.data) { clear(dashBox); dashBox.appendChild(dashboard(r.data)); } });
  const tile = (m) => h('button', { class: 'tl', style: { '--h': hue(m.id) }, onclick: () => openModule(m.id) },
    h('span', { class: 'ti' }, ico(m.icon)), h('b', null, m.label), h('small', null, esc(m.hint || '')),
    h('span', { class: 'fav' + (S.fav.indexOf(m.id) >= 0 ? ' on' : ''), title: t('favs'), onclick: (e) => { e.stopPropagation(); toggleFav(m.id); showHome(); } }, ico('star')));
}
function resetView(title) {
  S.mod = null; S.view = null; buildSide();
  clear(R.banner); clear(R.tabs); clear(R.content); R.split.classList.add('single');
  R.banner.appendChild(h('div', { class: 'bn-t' }, h('small', null, esc((S.boot.brand && S.boot.brand.name) || 'Shadow Base')), h('b', null, title)));
}
function showConfig() {
  S.tab = 'config'; resetView('Configuration');
  const nav = S.boot.nav;
  const gl = (S.boot.groups || []).filter((g) => nav.some((m) => m.group === g));
  R.content.appendChild(h('div', { class: 'gcards' }, gl.map((g) => {
    const ms = nav.filter((m) => m.group === g);
    return h('button', { class: 'gcard', onclick: () => showGroup(g) },
      h('span', { class: 'gc-i' }, ico(ms[0].icon)), h('b', null, esc(g)),
      h('small', null, ms.slice(0, 4).map((m) => esc(m.label)).join(', ') + (ms.length > 4 ? '…' : '')),
      h('span', { class: 'gc-n' }, ms.length + ' ' + (ms.length > 1 ? 'sections' : 'section')));
  })));
}
function showTools() {
  S.tab = 'tools'; resetView('Outils');
  const nav = S.boot.nav, byId = (id) => nav.find((m) => m.id === id);
  const tile = (m) => h('button', { class: 'tl', onclick: () => openModule(m.id) }, h('span', { class: 'ti' }, ico(m.icon)), h('b', null, m.label), h('small', null, esc(m.hint || '')),
    h('span', { class: 'fav' + (S.fav.indexOf(m.id) >= 0 ? ' on' : ''), title: t('favs'), onclick: (e) => { e.stopPropagation(); toggleFav(m.id); showTools(); } }, ico('star')));
  const act = (ic, l, sub, fn) => h('button', { class: 'tl', onclick: fn }, h('span', { class: 'ti' }, ico(ic)), h('b', null, l), h('small', null, sub));
  R.content.appendChild(h('h3', { class: 'cd' }, 'Raccourcis'));
  R.content.appendChild(h('div', { class: 'tiles big' },
    act('search', 'Recherche', 'Trouver un module, un joueur, un réglage', () => R.search.focus()),
    act('bell', 'Notifications', 'Alertes et activité récente', () => toggleDrawer(true)),
    ...['players', 'flags', 'crime', 'monitor', 'logs'].filter((id) => byId(id)).map((id) => tile(byId(id))),
    (S.prefs.lastModule && byId(S.prefs.lastModule)) ? act('clock', 'Reprendre', byId(S.prefs.lastModule).label, () => openModule(S.prefs.lastModule)) : null));
  R.content.appendChild(h('h3', { class: 'cd' }, t('favs')));
  const favs = nav.filter((m) => S.fav.indexOf(m.id) >= 0);
  R.content.appendChild(favs.length ? h('div', { class: 'tiles big' }, favs.map(tile)) : h('div', { class: 'empty' }, 'Aucun favori : clique sur l’étoile d’une carte pour l’épingler ici.'));
}
function showGroup(g) {
  S.tab = 'config'; S.mod = null; S.view = null; buildSide();
  clear(R.banner); clear(R.tabs); clear(R.content); R.split.classList.add('single');
  R.banner.appendChild(h('div', { class: 'bn-t' }, h('small', null, esc((S.boot.brand && S.boot.brand.name) || 'Shadow Base')), h('b', null, esc(g))));
  R.banner.appendChild(h('button', { class: 'chip gback', onclick: showConfig }, '← Configuration'));
  const nav = S.boot.nav.filter((m) => m.group === g);
  R.content.appendChild(h('div', { class: 'tiles big' }, nav.map((m) => h('button', { class: 'tl', style: { '--h': hue(m.id) }, onclick: () => { S.back = g; openModule(m.id); } },
    h('span', { class: 'ti' }, ico(m.icon)), h('b', null, m.label), h('small', null, esc(m.hint || ''))))));
}
function toggleFav(id) { const i = S.fav.indexOf(id); if (i >= 0) S.fav.splice(i, 1); else S.fav.push(id); savePrefs({ favorites: S.fav }); buildSide(); }

/* ---------- recherche globale ---------- */
let searchTimer = null, hits = [], hitIdx = 0;
function onSearch() {
  clearTimeout(searchTimer);
  const q = R.search.value.trim();
  if (q.length < 2) { R.res.classList.add('hidden'); return; }
  searchTimer = setTimeout(async () => {
    const r = await call('ui.search', { q });
    if (R.search.value.trim() !== q) return;
    hits = (r.ok && r.data) || []; hitIdx = 0; renderHits();
  }, 220);
}
function renderHits() {
  clear(R.res); R.res.classList.remove('hidden');
  if (!hits.length) return R.res.appendChild(h('div', { class: 'empty' }, t('noRes')));
  hits.forEach((x, i) => R.res.appendChild(h('button', { class: 'hit' + (i === hitIdx ? ' on' : ''), onmousedown: (e) => { e.preventDefault(); pickHit(x); } },
    h('div', null, h('div', null, esc(x.label)), h('small', null, esc(x.hint || ''))), h('span', { class: 'k' }, esc(x.kind)))));
}
function pickHit(x) { R.res.classList.add('hidden'); R.search.value = ''; openModule(x.module, { tab: x.tab, focus: x.field }); }
function onSearchKey(e) {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); hitIdx = (hitIdx + (e.key === 'ArrowDown' ? 1 : hits.length - 1)) % Math.max(1, hits.length); renderHits(); }
  else if (e.key === 'Enter' && hits[hitIdx]) pickHit(hits[hitIdx]);
  else if (e.key === 'Escape') { R.res.classList.add('hidden'); e.stopPropagation(); }
}
document.addEventListener('click', (e) => { if (R.res && !e.target.closest('.sbar')) R.res.classList.add('hidden'); if (S.drawer && !e.target.closest('.drawer') && !e.target.closest('.circ')) toggleDrawer(false); });

/* ---------- notifications ---------- */
async function loadNotifs() { const r = await call('ui.notifs', {}); if (r.ok) { S.notifs = r.data || []; S.unread = Math.min(S.notifs.length, 9); updDot(); } }
function updDot() { if (!R.dot) return; R.dot.textContent = S.unread; R.dot.classList.toggle('hidden', !S.unread); }
function onPush(d) {
  if (d.type === 'notify' && d.entry) { S.notifs.unshift(d.entry); S.unread++; updDot(); if (d.entry.level === 'warn' || d.entry.level === 'error' || d.entry.level === 'critical') toast(d.entry.title + (d.entry.text ? ' — ' + d.entry.text : ''), d.entry.level === 'warn'); if (S.drawer) toggleDrawer(true); }
  if (d.type === 'brand') { call('ui.boot', {}).then((r) => { if (!r.ok) return; S.boot = r.data; S.prefs = (isArr(S.boot.prefs) ? {} : S.boot.prefs) || S.prefs; applyLook(); const m = S.mod, tb = S.tab, keep = m && S.boot.nav.some((x) => x.id === m); buildShell(); if (keep) openModule(m, { tab: tb, params: S.params }); else showHome(); }); }
  if (d.type === 'perms') { call('ui.boot', {}).then((r) => { if (r.ok) { S.boot = r.data; S.prefs = (isArr(S.boot.prefs) ? {} : S.boot.prefs) || S.prefs; applyLook(); buildSide(); if (S.mod && !S.boot.nav.some((m) => m.id === S.mod)) showHome(); } }); }
}
function toggleDrawer(on) {
  if (S.drawerEl) { S.drawerEl.remove(); S.drawerEl = null; }
  S.drawer = on === undefined ? !S.drawer : on;
  if (!S.drawer) return;
  S.unread = 0; updDot();
  S.drawerEl = h('div', { class: 'drawer' }, S.notifs.length ? S.notifs.slice(0, 40).map((n) => h('div', { class: 'nf' }, h('span', { class: 'chip ' + (n.level === 'error' || n.level === 'critical' ? 'bad' : n.level === 'warn' ? 'warn' : 'info') }, esc(n.level)), h('div', null, h('b', null, esc(n.title)), h('small', null, esc(n.text)), h('small', null, new Date((n.at || 0) * 1000).toLocaleTimeString())))) : h('div', { class: 'empty' }, t('none')));
  root.querySelector('.frame').appendChild(S.drawerEl);
}

/* ---------- modules, onglets ---------- */
async function openModule(id, o) {
  o = o || {};
  if (!S.boot.nav.some((m) => m.id === id)) return showHome();
  S.mod = id; S.focus = o.focus || null;
  S.params = Object.assign({}, o.params || {});
  if (o.tab) S.params.tab = o.tab; else delete S.params.tab;
  buildSide(); savePrefs({ lastModule: id });
  await load(true);
}
async function reload() { await load(false); }
async function load(scrollTop) {
  const my = ++S.seq, keep = R.content.scrollTop;
  clear(R.content); R.content.appendChild(h('div', { class: 'loading' }, h('div', { class: 'spin' })));
  const r = await call('ui.view', { module: S.mod, params: S.params });
  if (!S.token) return;
  if (r.expired) return overlay(t('expired'), t('expiredT'));
  if (!r.ok) { clear(R.content); drawBanner(null); R.content.appendChild(blkNotice({ level: 'error', text: r.err || 'Erreur' })); return; }
  S.view = r.data; S.tab = S.view.active || (S.view.tabs[0] && S.view.tabs[0].id);
  drawBanner(S.view); drawTabs(); drawContent();
  R.content.scrollTop = scrollTop ? 0 : keep;
  if (S.focus) { const el = R.content.querySelector('[data-k="' + CSS.escape(S.focus) + '"]'); if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('err'); setTimeout(() => el.classList.remove('err'), 1600); } S.focus = null; }
}
function drawBanner(v) {
  clear(R.banner);
  R.banner.appendChild(h('div', { class: 'bn-t' }, h('small', null, esc((S.boot.brand && S.boot.brand.name) || 'Shadow Base')), h('b', null, v ? esc(v.title) : '')));
  const right = h('div', { class: 'bn-r' });
  if (v && v.compat) right.appendChild(h('button', { class: 'chip ' + (v.compat === 'ok' ? 'ok' : v.compat === 'off' ? 'err' : 'warn'), title: 'Compatibilité', onclick: () => switchTab('_compat') },
    ico(v.compat === 'ok' ? 'check' : 'alert'), v.compat === 'ok' ? 'Compatible' : v.compat === 'off' ? 'Non pris en charge' : 'Partiel'));
  if (v) right.appendChild(h('button', { class: 'circ', title: t('favs'), onclick: () => { toggleFav(S.mod); drawBanner(S.view); } }, ico('star')));
  if (S.boot.nav.some((m) => m.id === S.mod)) { const mm = S.boot.nav.find((m) => m.id === S.mod); R.banner.appendChild(h('button', { class: 'chip gback', onclick: () => (mm && mm.group ? showGroup(mm.group) : showConfig()) }, '← ' + (mm && mm.group ? esc(mm.group) : t('home')))); }
  R.banner.appendChild(right);
}
function drawTabs() {
  clear(R.tabs);
  R.split.classList.toggle('single', (S.view.tabs || []).length < 2);
  (S.view.tabs || []).forEach((tb) => R.tabs.appendChild(h('button', { class: 'ptab' + (tb.id === S.tab ? ' on' : ''), onclick: () => switchTab(tb.id) }, tb.icon ? ico(tb.icon) : null, esc(tb.label))));
}
function switchTab(id) { S.params = { tab: id }; return reload(); }
function navTo(nav) { S.params = Object.assign({}, nav.params || {}); S.params.tab = nav.tab || S.tab; return reload(); }
function drawContent() {
  clear(R.content);
  if (S.pvHandler) { document.removeEventListener('pbform', S.pvHandler); S.pvHandler = null; }
  const tb = (S.view.tabs || []).find((x) => x.id === S.tab);
  if (!tb) return;
  S.formState = {};
  renderBlocks(tb.blocks || [], R.content);
}
function renderBlocks(blocks, into) { (blocks || []).forEach((b) => { if (!b) return; const el = block(b); if (el) into.appendChild(el); }); }

/* ---------- blocs ---------- */
function block(b) {
  const fn = BLOCKS[b.type];
  if (!fn) return blkNotice({ level: 'off', title: 'Bloc non pris en charge', text: 'Type « ' + esc(b.type) + ' » inconnu de cette version de l\'interface.' });
  try { return fn(b); } catch (e) { return blkNotice({ level: 'error', text: 'Erreur d\'affichage : ' + e.message }); }
}
const card = (title, desc, kids, tools) => h('div', { class: 'card' }, title ? h('h3', { class: 'ch' }, esc(title), tools ? h('span', { class: 'sp' }, tools) : null) : null, desc ? h('p', { class: 'cd' }, esc(desc)) : null, kids);
function blkNotice(b) {
  const ic = { warn: 'alert', error: 'alert', ok: 'check', off: 'lock', info: 'info' }[b.level] || 'info';
  return h('div', { class: 'notice ' + (b.level || 'info') }, ico(ic), h('div', null, b.title ? h('b', null, esc(b.title)) : null, h('span', null, esc(b.text))));
}
function triggerAction(a, extra) {
  if (a.nav) return navTo(a.nav);
  if (!a.action) return;
  return run(a.action, Object.assign({}, a.payload || {}, extra || {}), { refresh: true, show: a.show });
}
function btn(a, cls) {
  const el = h('button', { class: 'pl ' + (a.danger ? 'danger ' : '') + (a.disabled ? 'blocked ' : '') + (cls || ''), title: a.disabled ? (a.reason || 'Action indisponible pour le moment.') : null, onclick: (e) => {
    e.stopPropagation();
    if (a.disabled) { toast(a.reason || a.hint || 'Action indisponible pour le moment.', false); return; }
    if (el.dataset.busy === '1') return;
    el.dataset.busy = '1'; el.classList.add('busy');
    const p = triggerAction(a);
    Promise.resolve(p).then((r) => { if (r && r.ok === false) { el.classList.add('blocked'); setTimeout(() => el.classList.remove('blocked'), 2200); } }, () => {}).finally(() => { el.dataset.busy = ''; el.classList.remove('busy'); });
    showResult(a, p);
  } }, a.icon ? ico(a.icon) : null, esc(a.label));
  return el;
}
async function showResult(a, p) { const r = await p; if (a && a.show && r && r.ok) displayShow(a.show, r.data); }
function displayShow(kind, data) {
  if (!data) return;
  const resEl = R.content.querySelector('[data-result]');
  const tbl = data.table || (data.rows && { columns: Object.keys(data.rows[0] || {}).map((k) => ({ k, label: k })), rows: data.rows });
  if (kind === 'result' && resEl) { fillResult(resEl, data); return; }
  if (tbl) modal('Résultat', tableRaw(tbl), null, true);
  else if (data.rows) modal('Résultat', h('pre', null, JSON.stringify(data.rows, null, 2)), null, true);
}
function tableRaw(tb) {
  const cols = (tb.columns || []).map((c) => (typeof c === 'string' ? { k: c, label: c } : c));
  const rows = tb.rows || [];
  const cell = (r, c, i) => { const v = isArr(r) ? r[i] : r[c.k]; return h('td', { class: 'mono' }, v == null ? 'NULL' : typeof v === 'object' ? JSON.stringify(v) : String(v)); };
  return h('div', null, h('div', { class: 'tbl-wrap' }, h('table', null, h('thead', null, h('tr', null, cols.map((c) => h('th', null, esc(c.label || c.k))))), h('tbody', null, rows.map((r) => h('tr', null, cols.map((c, i) => cell(r, c, i))))))),
    tb.total != null ? h('div', { class: 'pager' }, tb.total + ' ligne(s)') : null);
}
function fillResult(el, data) { clear(el); if (data.table) el.appendChild(tableRaw(data.table)); else if (data.rows) el.appendChild(tableRaw({ rows: data.rows, columns: Object.keys(data.rows[0] || {}) })); if (data.msg) el.appendChild(h('p', { class: 'cd' }, data.msg)); }

/* ---------- cartes à dégradé (presets, tablettes, statistiques) ---------- */
function blkCards(b) {
  const rgb = (hex) => { const m = /^#([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return '223,226,231'; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255].join(','); };
  const grid = h('div', { class: 'cards' + (b.big ? ' big' : '') }, (b.items || []).map((c) => {
    const tone = /^#[0-9a-f]{6}$/i.test(c.tone || '') ? c.tone : '#dfe2e7';
    return h('div', { class: 'cardx' + (c.active ? ' on' : ''), style: { '--tone': tone, '--tone-rgb': rgb(tone) } },
      h('div', { class: 'kx-h' }, c.icon ? h('span', { class: 'kx-i' }, ico(c.icon)) : null, h('div', { class: 'kx-t' }, h('b', null, esc(c.title)), c.sub ? h('small', null, esc(c.sub)) : null), c.badge ? h('span', { class: 'kx-b' }, esc(c.badge)) : null),
      c.value != null ? h('div', { class: 'kx-v' }, esc(c.value)) : null,
      c.text ? h('p', null, esc(c.text)) : null,
      c.bar != null ? h('div', { class: 'kx-bar' }, h('i', { style: { width: Math.max(0, Math.min(100, c.bar)) + '%' } })) : null,
      c.stats ? h('div', { class: 'kx-s' }, c.stats.map((s) => h('div', null, h('small', null, esc(s.label)), h('b', null, esc(s.value))))) : null,
      c.action ? h('div', { class: 'kx-a' }, btn(c.action, c.active ? '' : 'pri')) : null);
  }));
  return b.title ? card(b.title, b.desc, grid) : grid;
}

const BLOCKS = {
  cards: blkCards,
  notice: blkNotice,
  stats: (b) => h('div', { class: 'stats' }, (b.items || []).map((s) => h('div', { class: 'stat' }, h('small', null, s.icon ? ico(s.icon) : null, esc(s.label)), h('b', { title: esc(s.value) }, esc(s.value)), s.sub ? h('small', null, esc(s.sub)) : null))),
  kv: (b) => card(b.title, null, h('div', { class: 'kv' }, (b.items || []).map((p) => [h('span', null, esc(p.label)), h('span', null, esc(p.value))]).flat())),
  actions: (b) => card(b.title, null, h('div', { class: 'tools', style: { marginBottom: 0 } }, (b.items || []).map((a) => btn(a, a.primary ? 'pri' : '')))),
  columns: (b) => h('div', { class: 'cols', style: { gridTemplateColumns: /^[0-9a-z\s.%()]+$/.test(b.widths || '') && b.widths ? b.widths : 'repeat(' + (b.cols || []).length + ',minmax(0,1fr))' } }, (b.cols || []).map((c) => { const d = h('div', { class: 'cols-c', style: { display: 'flex', flexDirection: 'column', gap: '16px', minWidth: 0 } }); renderBlocks(c, d); return d; })),
  doc: (b) => card(b.title, null, h('div', { class: 'doc' }, md(b.text || ''))),
  caps: (b) => card(null, null, (b.items || []).map((c) => h('div', { class: 'caprow' }, h('span', { class: 'chip ' + ({ ok: 'ok', partial: 'warn', off: 'err' }[c.status] || 'off') }, { ok: 'Pris en charge', partial: 'Partiel', off: 'Indisponible' }[c.status] || esc(c.status)), h('div', null, h('b', null, esc(c.feature)), c.reason ? h('small', null, esc(c.reason)) : null)))),
  image: (b) => card(b.title, null, h('div', { class: 'imgblk' }, typeof b.src === 'string' && SAFE_IMG.test(b.src) && b.src.length < 950000 ? h('img', { src: b.src, alt: '' }) : h('div', { class: 'empty' }, 'Image indisponible.'), b.caption ? h('p', { class: 'cd' }, esc(b.caption)) : null)),
  result: (b) => card(b.title, null, h('div', { 'data-result': '1' }, h('div', { class: 'empty' }, '—'))),
  picker: (b) => {
    const sel = h('select', { class: 'cinp', onchange: () => {
      const ids = []; const tb = S.view.tabs.find((x) => x.id === S.tab);
      (function scan(n) { if (isArr(n)) n.forEach(scan); else if (n && typeof n === 'object') { if (n.type === 'picker') ids.push(n.id); Object.keys(n).forEach((k) => { if (typeof n[k] === 'object') scan(n[k]); }); } })(tb.blocks);
      const i = ids.indexOf(b.id); ids.slice(i + 1).forEach((x) => delete S.params[x]);
      S.params[b.id] = sel.value; reload();
    } }, optList(b).map((o) => h('option', { value: o.v, selected: String(o.v) === String(b.value) }, esc(o.l))));
    sel.value = b.value == null ? '' : b.value;
    return h('div', { class: 'card' }, h('div', { class: 'pk' }, h('label', null, esc(b.label)), h('div', { class: 'f', style: { flex: 1, maxWidth: '520px' } }, sel)));
  },
  mlist: blkMList, gpreview: blkGPreview, table: blkTable, form: blkForm, permgrid: blkPerm, editor: blkEditor, chart: blkChart, map: blkMap, carte: blkCarte, prefs: blkPrefs, positioner: blkPositioner, layout: blkLayout,
};

/* mini Markdown (titres, listes, **gras**, `code`) — texte uniquement */
function inline(s) {
  const out = []; const re = /(\*\*[^*]+\*\*|`[^`]+`)/g; let last = 0, m;
  while ((m = re.exec(s))) { if (m.index > last) out.push(s.slice(last, m.index)); const x = m[0]; out.push(x[0] === '`' ? h('code', null, x.slice(1, -1)) : h('b', null, x.slice(2, -2))); last = m.index + x.length; }
  if (last < s.length) out.push(s.slice(last)); return out;
}
function md(text) {
  const out = []; let ul = null;
  String(text).split('\n').forEach((ln) => {
    const m = ln.match(/^(#{1,4})\s+(.*)/), li = ln.match(/^\s*[-*]\s+(.*)/);
    if (li) { if (!ul) { ul = h('ul'); out.push(ul); } ul.appendChild(h('li', null, inline(li[1]))); return; }
    ul = null;
    if (m) out.push(h('h' + Math.min(4, m[1].length + 1), null, inline(m[2])));
    else if (ln.trim()) out.push(h('p', null, inline(ln)));
  });
  return out;
}

/* ---------- tableau ---------- */
const SAFE_IMG = /^(data:image\/(jpeg|png);base64,[A-Za-z0-9+\/=]+|https:\/\/cdn\.discordapp\.com\/avatars\/\d+\/[\w]+\.png\?size=\d+)$/;
function cellNode(c, v) {
  if (c.type === 'avatar') {
    const o = v && typeof v === 'object' ? v : { text: v };
    const src = typeof o.src === 'string' && SAFE_IMG.test(o.src) && o.src.length < 120000 ? o.src : '';
    return h('span', { class: 'av' }, src ? h('img', { src, alt: '', class: 'avimg' }) : h('i', { class: 'avimg ph' }), esc(o.text == null ? '' : o.text));
  }
  if (v && typeof v === 'object' && !isArr(v)) return h('span', { class: 'chip ' + (v.tone || '') }, esc(v.text));
  if (c.type === 'badge') return v ? h('span', { class: 'chip' }, esc(v)) : '';
  if (c.type === 'bool') return h('span', { class: 'chip ' + (v ? 'ok' : 'off') }, v ? 'Oui' : 'Non');
  if (c.type === 'color') return v ? h('span', { class: 'sw', style: { background: /^#[0-9a-f]{3,8}$/i.test(v) ? v : 'transparent' } }) : '';
  if (c.type === 'date') return v ? new Date((typeof v === 'number' && v < 1e12 ? v * 1000 : v)).toLocaleString() : '';
  if (c.type === 'num') return v == null ? '' : (typeof v === 'number' ? v.toLocaleString() : esc(v));
  return v == null ? '' : esc(v);
}
function blkTable(b) {
  const cols = b.columns || []; let rows = (b.rows || []).slice(); let q = ''; let sort = null;
  const body = h('tbody'), head = h('tr'), pager = h('div', { class: 'pager' });
  const tools = h('div', { class: 'tools' });
  function draw() {
    clear(body);
    let list = rows;
    if (q) { const x = q.toLowerCase(); list = list.filter((r) => cols.some((c) => { const v = r[c.k]; return String(v && typeof v === 'object' ? v.text : v == null ? '' : v).toLowerCase().indexOf(x) >= 0; })); }
    if (sort) { const c = sort.c; list = list.slice().sort((a, z) => { let x = a[c.k], y = z[c.k]; if (x && x.text !== undefined) x = x.text; if (y && y.text !== undefined) y = y.text; return (x > y ? 1 : x < y ? -1 : 0) * sort.d; }); }
    if (!list.length) body.appendChild(h('tr', null, h('td', { colspan: cols.length + 1, class: 'empty' }, esc(b.empty || t('empty')))));
    list.forEach((r) => body.appendChild(h('tr', null, cols.map((c) => h('td', { class: c.type === 'num' ? 'num' : c.type === 'mono' ? 'mono' : '' }, cellNode(c, r[c.k]))),
      h('td', { class: 'act' }, (r.actions || []).map((a) => btn(Object.assign({}, a, { payload: Object.assign({ id: r.id }, a.payload || {}) }), 'sm'))))));
  }
  cols.forEach((c) => head.appendChild(h('th', { class: (c.type === 'num' ? 'num ' : '') + 'sortable', onclick: () => { sort = { c, d: sort && sort.c === c ? -sort.d : 1 }; draw(); } }, esc(c.label))));
  head.appendChild(h('th'));
  if (b.search) tools.appendChild(h('label', { class: 'tsearch' }, ico('search'), h('input', { type: 'text', placeholder: 'Filtrer…', oninput: (e) => { q = e.target.value; draw(); } })));
  (b.toolbar || []).forEach((a) => tools.appendChild(btn(a, 'pri')));
  draw();
  const pg = b.page;
  if (pg && pg.total > pg.per) {
    const last = Math.ceil(pg.total / pg.per), go = (n) => { const ex = {}; Object.keys(pg).forEach((k) => { if (['n', 'per', 'total', 'tab'].indexOf(k) < 0) ex[k] = pg[k]; }); S.params = Object.assign({}, S.params, ex, { page: n }); S.params.tab = pg.tab || S.tab; reload(); };
    pager.appendChild(h('button', { class: 'pl sm', disabled: pg.n <= 1, onclick: () => go(pg.n - 1) }, '‹'));
    pager.appendChild(h('span', null, t('page') + ' ' + pg.n + ' ' + t('of') + ' ' + last + ' · ' + pg.total));
    pager.appendChild(h('button', { class: 'pl sm', disabled: pg.n >= last, onclick: () => go(pg.n + 1) }, '›'));
  }
  return card(b.title, b.desc, [tools.childNodes.length ? tools : null, h('div', { class: 'tbl-wrap' }, h('table', null, h('thead', null, head), body)), pg ? pager : null]);
}

/* ---------- formulaires ---------- */
function blkForm(b) {
  const vals = clone(b.values || {}) || {};
  const readOnly = !b.submit;
  const grid = h('div', { class: 'form-grid', style: { gridTemplateColumns: 'repeat(' + Math.max(1, Math.min(4, b.cols || 2)) + ',minmax(0,1fr))' } });
  const getters = [];
  const err = (el, on) => el.classList.toggle('err', !!on);
  function mount(fields, into, v, gk) {
    (fields || []).forEach((f) => {
      if (f.type === 'group') { const g = h('div', { class: 'group f wide' }, f.label ? h('legend', null, esc(f.label)) : null); const gv = f.k ? ((v[f.k] && typeof v[f.k] === 'object' && !isArr(v[f.k])) ? v[f.k] : (v[f.k] = {})) : v; mount(f.fields, g, gv, f.k || gk); into.appendChild(g); return; }
      if (f.type === 'info') { into.appendChild(h('div', { class: 'f wide' }, h('div', { class: 'hint' }, esc(f.label || f.hint)))); return; }
      const mk = FIELDS[f.type] || FIELDS.text;
      const dis = readOnly || f.readonly || f.disabled;
      const w = mk(f, v, dis);
      const wrap = h('div', { class: 'f' + (f.wide || ['area', 'tags', 'list', 'rows', 'multi', 'icon', 'image', 'asset', 'coords'].indexOf(f.type) >= 0 ? ' wide' : ''), 'data-k': f.k || '' },
        f.type === 'toggle' ? null : h('label', null, esc(f.label), f.required ? h('em', null, '*') : null, f.type === 'secret' && f.set ? h('span', { class: 'chip ok' }, t('set')) : null),
        w.el, f.hint ? h('div', { class: 'hint' }, esc(f.hint)) : null);
      if (f.type === 'toggle') { wrap.insertBefore(h('label', null, esc(f.label)), w.el); }
      into.appendChild(wrap);
      getters.push({ f, wrap, get: w.get, gk });
    });
  }
  mount(b.fields, grid, vals);
  const out = h('div', { class: 'form-out' });
  const fire = () => document.dispatchEvent(new CustomEvent('pbform', { detail: { id: b.id, values: collect().v } }));
  ['input', 'change'].forEach((ev) => grid.addEventListener(ev, fire)); grid.addEventListener('click', () => setTimeout(fire, 0));
  function collect() {
    const v = {}; let bad = null;
    getters.forEach((g) => {
      const val = g.get(); err(g.wrap, false);
      const f = g.f;
      if (f.k == null) return;
      if (!f.readonly && f.required && (val === '' || val == null || (isArr(val) && !val.length))) { err(g.wrap, true); bad = bad || (f.label + ' : obligatoire.'); }
      if (typeof val === 'string' && val !== '' && f.pattern) { try { if (!luaPattern(f.pattern).test(val)) { err(g.wrap, true); bad = bad || (f.label + ' : format invalide.'); } } catch (e) {} }
      if (typeof val === 'number' && ((f.min != null && val < f.min) || (f.max != null && val > f.max))) { err(g.wrap, true); bad = bad || (f.label + ' : valeur hors limites.'); }
      if (g.gk) { if (!v[g.gk] || typeof v[g.gk] !== 'object') v[g.gk] = {}; v[g.gk][f.k] = val; } else v[f.k] = val;
    });
    return { v, bad };
  }
  const sub = b.submit;
  const foot = h('div', { class: 'fsub' });
  if (sub) {
    foot.appendChild(h('button', { class: 'pl ' + (sub.danger ? 'danger' : 'pri'), onclick: async (ev) => {
      const btnEl = ev.currentTarget;
      const { v, bad } = collect();
      if (bad) { btnEl.classList.add('blocked'); setTimeout(() => btnEl.classList.remove('blocked'), 2200); return toast(bad, false); }
      if (sub.nav && !sub.action) { S.params = Object.assign({}, S.params, sub.as === 'params' ? v : {}, { tab: sub.nav.tab || S.tab }, sub.nav.params || {}); delete S.params.page; return reload(); }
      if (btnEl.dataset.busy === '1') return;
      btnEl.dataset.busy = '1'; btnEl.classList.add('busy');
      let r;
      try { r = await run(sub.action, Object.assign({}, sub.payload || {}, { values: v }), { refresh: !sub.show, noRefresh: !!sub.show }); }
      finally { btnEl.dataset.busy = ''; btnEl.classList.remove('busy'); }
      if (r && r.ok === false) { btnEl.classList.add('blocked'); setTimeout(() => btnEl.classList.remove('blocked'), 2200); }
      if (r && r.ok && sub.show) displayShow(sub.show, r.data);
    } }, ico(sub.danger ? 'trash' : 'save'), esc(sub.label || t('save'))));
  }
  (b.extra || []).forEach((x) => {
    foot.appendChild(h('button', { class: 'pl', onclick: async (ev) => {
      const btnEl = ev.currentTarget;
      const { v, bad } = collect();
      if (bad) return toast(bad, false);
      if (btnEl.dataset.busy === '1') return;
      btnEl.dataset.busy = '1'; btnEl.classList.add('busy');
      try { await run(x.action, Object.assign({}, x.payload || {}, { values: v }), { noRefresh: true }); } finally { btnEl.dataset.busy = ''; btnEl.classList.remove('busy'); }
    } }, ico(x.icon || 'eye'), esc(x.label || '')));
  });
  const info = h('div', { class: 'info' });
  if (b.restart) info.appendChild(h('span', { class: 'chip warn', title: b.restart }, ico('power'), t('restart')));
  if (b.source) info.appendChild(h('span', { class: 'chip' }, esc(b.source)));
  if (b.history) info.appendChild(h('button', { class: 'pl sm', onclick: () => showHistory(b.history) }, ico('clock'), t('history')));
  foot.appendChild(info);
  return card(b.title, b.desc, [b.restart ? blkNotice({ level: 'warn', text: b.restart }) : null, grid, foot, out]);
}

const FIELDS = {
  text: (f, v, dis) => { const i = h('input', { type: 'text', value: v[f.k] == null ? '' : v[f.k], maxlength: f.maxlen, placeholder: f.placeholder, disabled: dis, autocomplete: 'off' }); return { el: i, get: () => i.value }; },
  area: (f, v, dis) => { const i = h('textarea', { maxlength: f.maxlen, disabled: dis, rows: f.rows || 4 }); i.value = v[f.k] == null ? '' : v[f.k]; return { el: i, get: () => i.value }; },
  number: (f, v, dis) => {
    const i = h('input', { type: 'number', min: f.min, max: f.max, step: f.step || (f.int === false ? 'any' : 1), disabled: dis }); i.value = v[f.k] == null ? '' : v[f.k];
    if (f.picker !== 'blip' || !window.PBBlipPick) return { el: i, get: () => (i.value === '' ? '' : Number(i.value)) };
    // icône de la carte : aperçu + sélecteur de toutes les icônes du jeu (la couleur remplit le champ voisin)
    const img = h('img', { class: 'bp-prev', alt: '' }), nm = h('span', { class: 'bp-prevn' });
    const show = () => { const n = Number(i.value); const u = n >= 0 && window.PBBlipList ? window.PBBlipList.img(n) : ''; img.src = u || ''; img.style.visibility = u ? '' : 'hidden'; nm.textContent = n >= 0 && window.PBBlipList ? window.PBBlipList.name(n) : 'Icône du type'; };
    i.addEventListener('input', show);
    const colorInput = () => { const form = i.closest('.f') && i.closest('.f').parentElement; return f.pickerColor && form ? form.querySelector('[data-k="' + f.pickerColor + '"] input') : null; };
    const btn = h('button', { type: 'button', class: 'pl sm', disabled: dis, onclick: () => {
      const ci = colorInput();
      window.PBBlipPick({ sprite: Number(i.value) >= 0 ? Number(i.value) : 475, color: ci && ci.value !== '' && Number(ci.value) >= 0 ? Number(ci.value) : 3, title: f.label }, (r) => {
        if (!r) return;
        i.value = r.sprite; show();
        if (ci) ci.value = r.color;
        i.dispatchEvent(new Event('input', { bubbles: true }));
      });
    } }, ico('map'), 'Choisir parmi toutes les icônes');
    show();
    return { el: h('div', { class: 'bp-field' }, i, img, nm, btn), get: () => (i.value === '' ? '' : Number(i.value)) };
  },
  range: (f, v, dis) => {
    const cur = v[f.k] == null ? (f.default != null ? f.default : f.min || 0) : v[f.k];
    const o = h('output', null, String(cur)), i = h('input', { type: 'range', min: f.min != null ? f.min : 0, max: f.max != null ? f.max : 100, step: f.step || 1, disabled: dis, oninput: () => { o.textContent = i.value; } }); i.value = cur;
    return { el: h('div', { class: 'rng' }, i, o), get: () => Number(i.value) };
  },
  toggle: (f, v, dis) => {
    let on = !!v[f.k]; const sw = h('span', { class: 'sw-tg' + (on ? ' on' : '') });
    const bt = h('button', { type: 'button', class: 'tgl', role: 'switch', disabled: dis, 'aria-checked': on, onclick: () => { on = !on; sw.classList.toggle('on', on); bt.setAttribute('aria-checked', on); } }, sw, h('span', null, f.sub || ''));
    return { el: bt, get: () => on };
  },
  select: (f, v, dis) => {
    const os = optList(f), i = h('select', { disabled: dis }, os.map((o) => h('option', { value: o.v }, esc(o.l))));
    const cur = v[f.k] == null ? '' : v[f.k]; if (!os.some((o) => String(o.v) === String(cur))) i.appendChild(h('option', { value: cur }, esc(cur === '' ? '—' : cur)));
    i.value = cur; return { el: i, get: () => { const o = os.find((x) => String(x.v) === i.value); return o ? o.v : i.value; } };
  },
  cards: (f, v, dis) => {
    const os = optList(f); let cur = v[f.k] == null || v[f.k] === '' ? (f.default != null ? f.default : (os[0] && os[0].v)) : v[f.k];
    const box = h('div', { class: 'pcards' });
    const draw = () => { box.innerHTML = ''; os.forEach((o) => box.appendChild(h('button', { type: 'button', class: 'pcard' + (String(o.v) === String(cur) ? ' on' : ''), disabled: dis, onclick: () => { cur = o.v; draw(); } }, o.i ? h('img', { src: o.i, alt: '' }) : null, h('span', null, esc(o.l))))); };
    draw(); return { el: box, get: () => cur };
  },
  multi: (f, v, dis) => {
    const sel = new Set((isArr(v[f.k]) ? v[f.k] : []).map(String)), box = h('div', { class: 'chips' });
    optList(f).forEach((o) => { const c = h('button', { type: 'button', class: 'cb' + (sel.has(String(o.v)) ? ' on' : ''), disabled: dis, onclick: () => { const k = String(o.v); if (sel.has(k)) sel.delete(k); else sel.add(k); c.classList.toggle('on', sel.has(k)); } }, esc(o.l)); box.appendChild(c); });
    return { el: box, get: () => optList(f).filter((o) => sel.has(String(o.v))).map((o) => o.v) };
  },
  tags: (f, v, dis) => {
    let list = isArr(v[f.k]) ? v[f.k].slice() : []; const box = h('div', { class: 'tagbox' }), inp = h('input', { type: 'text', disabled: dis, placeholder: f.placeholder || 'Entrée pour ajouter' });
    function draw() { Array.from(box.querySelectorAll('.tg')).forEach((x) => x.remove()); list.forEach((x, i) => box.insertBefore(h('span', { class: 'tg' }, esc(x), dis ? null : h('button', { type: 'button', onclick: () => { list.splice(i, 1); draw(); } }, '×')), inp)); }
    inp.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ',') && inp.value.trim()) { e.preventDefault(); inp.value.split(',').forEach((x) => { x = x.trim(); if (x && list.indexOf(x) < 0) list.push(x); }); inp.value = ''; draw(); } });
    box.appendChild(inp); draw(); return { el: box, get: () => { if (inp.value.trim()) { list.push(inp.value.trim()); inp.value = ''; draw(); } return list.slice(); } };
  },
  list: (f, v, dis) => { const i = h('textarea', { disabled: dis, rows: 4, placeholder: 'Une valeur par ligne' }); i.value = (isArr(v[f.k]) ? v[f.k] : []).join('\n'); return { el: i, get: () => i.value.split('\n').map((x) => x.trim()).filter(Boolean) }; },
  color: (f, v, dis) => {
    const cur = /^#[0-9a-f]{6}$/i.test(v[f.k] || '') ? v[f.k] : '#dfe2e7';
    const c = h('input', { type: 'color', value: cur, disabled: dis }), t2 = h('input', { type: 'text', value: v[f.k] || cur, maxlength: 9, disabled: dis, style: { maxWidth: '130px' } });
    c.addEventListener('input', () => { t2.value = c.value; }); t2.addEventListener('input', () => { if (/^#[0-9a-f]{6}$/i.test(t2.value)) c.value = t2.value; });
    return { el: h('div', { class: 'colr' }, c, t2), get: () => t2.value };
  },
  time: (f, v, dis) => { const i = h('input', { type: 'time', value: v[f.k] || '', disabled: dis }); return { el: i, get: () => i.value }; },
  secret: (f, v, dis) => { const i = h('input', { type: 'password', autocomplete: 'new-password', placeholder: f.set ? '•••••• (laisser vide pour ne pas changer)' : (f.placeholder || ''), disabled: dis }); return { el: i, get: () => i.value }; },
  image: (f, v, dis) => {
    let data = ''; const prev = h('img', { class: 'hidden' }), file = h('input', { type: 'file', accept: 'image/*', disabled: dis, class: 'cinp' });
    file.addEventListener('change', () => { const fl = file.files[0]; if (!fl) return; if (fl.size > (f.maxkb || 700) * 1024) { toast('Image trop lourde (max ' + (f.maxkb || 700) + ' Ko).', false); file.value = ''; return; } const rd = new FileReader(); rd.onload = () => { data = rd.result; prev.src = data; prev.classList.remove('hidden'); }; rd.readAsDataURL(fl); });
    return { el: h('div', { class: 'imgf' }, file, prev, f.set ? h('span', { class: 'chip ok' }, t('set')) : null), get: () => data };
  },
  asset: (f, v, dis) => {
    let cur = typeof v[f.k] === 'string' ? v[f.k] : '';
    const maxW = f.maxw || 1024, maxH = f.maxh || 512;
    const prev = h('div', { class: 'asp' }), file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', disabled: dis, class: 'hidden' });
    const stat = h('small', { class: 'asp-s' });
    const draw = () => {
      clear(prev);
      const G = window.PBGame;
      if (!cur) { prev.appendChild(h('span', { class: 'asp-e' }, 'Aucune image')); stat.textContent = ''; return; }
      const id = (/^asset:([a-z0-9]+)$/.exec(cur) || [])[1];
      const uri = id && G && G.assets[id];
      if (uri) prev.appendChild(h('img', { src: uri, alt: '' })); else { prev.appendChild(h('span', { class: 'asp-e' }, 'Chargement…')); if (id && G) G.wantAsset(id); }
    };
    if (window.PBGame && !window.PBGame.__aspBound) { window.PBGame.__aspBound = true; window.PBGame.on('asset', () => document.dispatchEvent(new CustomEvent('pbasset'))); }
    const redraw = () => { if (!prev.isConnected) { document.removeEventListener('pbasset', redraw); return; } draw(); };
    document.addEventListener('pbasset', redraw);
    draw();
    function shrink(img, type) {
      let w = img.naturalWidth, hh = img.naturalHeight; const k = Math.min(1, maxW / w, maxH / hh); w = Math.max(1, Math.round(w * k)); hh = Math.max(1, Math.round(hh * k));
      const cv = document.createElement('canvas'); cv.width = w; cv.height = hh; cv.getContext('2d').drawImage(img, 0, 0, w, hh);
      const keepAlpha = type === 'image/png' || type === 'image/webp';
      for (const q of [0.88, 0.78, 0.66, 0.5]) {
        const uri = keepAlpha && q === 0.88 ? cv.toDataURL('image/png') : cv.toDataURL('image/jpeg', q);
        if (uri.length * 0.75 < 800 * 1024) return uri;
      }
      return null;
    }
    file.addEventListener('change', () => {
      const fl = file.files[0]; file.value = ''; if (!fl) return;
      if (!/^image\/(png|jpeg|webp)$/.test(fl.type)) { toast('Format accepté : PNG, JPEG ou WebP.', false); return; }
      if (fl.size > 15 * 1024 * 1024) { toast('Fichier trop volumineux (15 Mo maximum).', false); return; }
      stat.textContent = 'Préparation…';
      const url = URL.createObjectURL(fl), img = new Image();
      img.onload = async () => {
        URL.revokeObjectURL(url);
        const uri = shrink(img, fl.type);
        if (!uri) { stat.textContent = ''; toast("Impossible de réduire l'image sous 800 Ko : choisis-en une plus simple.", false); return; }
        const m = /^data:(image\/[a-z]+);base64,(.+)$/.exec(uri);
        stat.textContent = 'Envoi… (' + Math.round(m[2].length * 0.75 / 1024) + ' Ko, quelques secondes)';
        const r = await call('asset.upload', { name: fl.name, mime: m[1], data: m[2] }, { timeout: 90000 });
        if (!r.ok) { stat.textContent = ''; toast(r.err || 'Envoi impossible.', false); return; }
        const id = r.data.id.slice(6);
        if (window.PBGame) window.PBGame.assets[id] = uri;
        cur = r.data.id; stat.textContent = 'Envoyée — pense à enregistrer.'; draw();
      };
      img.onerror = () => { URL.revokeObjectURL(url); stat.textContent = ''; toast("Cette image n'a pas pu être lue.", false); };
      img.src = url;
    });
    const pick = h('button', { type: 'button', class: 'pl sm', disabled: dis, onclick: () => file.click() }, ico('upload'), 'Choisir une image sur mon PC');
    const del = h('button', { type: 'button', class: 'pl sm danger', disabled: dis, onclick: () => { cur = ''; stat.textContent = 'Retirée — pense à enregistrer.'; draw(); } }, ico('trash'), 'Retirer');
    return { el: h('div', { class: 'asf' }, prev, h('div', { class: 'asf-b' }, pick, del, stat), file), get: () => cur };
  },
  icon: (f, v, dis) => {
    let cur = v[f.k] || ''; const box = h('div', { class: 'icons' });
    optList(f).forEach((o) => { const bt = h('button', { type: 'button', class: 'icb' + (o.v === cur ? ' on' : ''), title: o.l, disabled: dis, onclick: () => { cur = o.v; Array.from(box.children).forEach((x) => x.classList.remove('on')); bt.classList.add('on'); } }, ico(String(o.v))); box.appendChild(bt); });
    return { el: box, get: () => cur };
  },
  coords: (f, v, dis) => {
    const c = v[f.k] || {}, mk = (k) => h('input', { type: 'number', step: 'any', placeholder: k === 'h' ? 'cap' : k, value: c[k] == null ? '' : c[k], disabled: dis, 'aria-label': k }), x = mk('x'), y = mk('y'), z = mk('z'), hd = mk('h');
    const bt = h('button', { type: 'button', class: 'pl sm', disabled: dis, onclick: async () => { const r = await call('map.mypos', {}); if (r.ok && r.data && r.data.coords) { const p = r.data.coords; x.value = (+p.x).toFixed(2); y.value = (+p.y).toFixed(2); z.value = (+p.z).toFixed(2); hd.value = (+(p.h || 0)).toFixed(1); } else toast(r.err || 'Position indisponible.', false); } }, ico('pin'), t('mypos'));
    return { el: h('div', { class: 'coords' }, x, y, z, hd, bt), get: () => ({ x: Number(x.value || 0), y: Number(y.value || 0), z: Number(z.value || 0), h: Number(hd.value || 0) }) };
  },
  rows: (f, v, dis) => {
    let rows = clone(isArr(v[f.k]) ? v[f.k] : []) || []; const body = h('tbody');
    const cols = f.cols || [];
    const mkc = (col, r) => {
      if (col.type === 'select') { const i = h('select', { class: 'cinp', disabled: dis, onchange: () => { r[col.k] = i.value; } }, (col.opts || []).map((o) => h('option', { value: o[0], selected: String(r[col.k] == null ? (col.opts[0] || [])[0] : r[col.k]) === o[0] }, esc(o[1])))); if (r[col.k] == null) r[col.k] = (col.opts[0] || [])[0]; return i; }
      if (col.type === 'toggle') { const i = h('input', { type: 'checkbox', checked: !!r[col.k], disabled: dis, onchange: () => { r[col.k] = i.checked; } }); return i; }
      const i = h('input', { class: 'cinp', type: col.type === 'number' ? 'number' : 'text', min: col.min, max: col.max, disabled: dis, value: r[col.k] == null ? '' : r[col.k], oninput: () => { r[col.k] = col.type === 'number' ? (i.value === '' ? '' : Number(i.value)) : i.value; } }); return i;
    };
    function draw() { clear(body); rows.forEach((r, ix) => body.appendChild(h('tr', null, cols.map((c) => h('td', null, mkc(c, r))), h('td', null, dis ? null : h('button', { type: 'button', class: 'pl sm danger', onclick: () => { rows.splice(ix, 1); draw(); } }, ico('trash')))))); }
    draw();
    const add = h('button', { type: 'button', class: 'pl sm', style: { marginTop: '10px' }, disabled: dis, onclick: () => { const r = {}; cols.forEach((c) => { r[c.k] = c.type === 'number' ? (rows.length ? (Number(rows[rows.length - 1][c.k]) || 0) + (c.k === 'grade' ? 1 : 0) : 0) : c.type === 'toggle' ? false : ''; }); rows.push(r); draw(); } }, ico('plus'), t('addRow'));
    return { el: h('div', null, h('div', { class: 'rows-ed' }, h('table', null, h('thead', null, h('tr', null, cols.map((c) => h('th', null, esc(c.label || c.k))), h('th'))), body)), add), get: () => clone(rows) };
  },
};

/* ---------- aperçu des interfaces en jeu (rendu par web/game/*.js avec les réglages du formulaire non enregistrés) ---------- */
/* liste maître (à gauche d'un éditeur) : éléments cliquables, recherche, bouton « nouveau » */
function blkMList(b) {
  const box = h('div', { class: 'ml' });
  const list = h('div', { class: 'ml-l' });
  const draw = (q) => {
    clear(list);
    const items = (b.items || []).filter((it) => !q || String(it.label).toLowerCase().indexOf(q) >= 0 || String(it.sub || '').toLowerCase().indexOf(q) >= 0);
    items.forEach((it) => list.appendChild(h('button', { class: 'ml-i' + (it.active ? ' on' : '') + (it.off ? ' off' : ''), onclick: () => { if (it.nav) { S.params = Object.assign({}, it.nav.params || {}); S.params.tab = it.nav.tab || S.tab; reload(); } } },
      h('span', { class: 'ml-ic' }, ico(it.icon || 'shop')), h('span', { class: 'ml-t' }, h('b', null, esc(it.label)), h('small', null, esc(it.sub || ''))), it.badge ? h('span', { class: 'chip ' + (it.tone || '') }, esc(it.badge)) : null)));
    if (!items.length) list.appendChild(h('div', { class: 'empty' }, esc(b.empty || 'Rien à afficher.')));
  };
  const head = h('div', { class: 'ml-h' }, h('b', null, esc(b.title || '')),
    b.toolbar ? h('button', { class: 'pl sm pri', onclick: () => { S.params = Object.assign({}, b.toolbar.nav.params || {}); S.params.tab = b.toolbar.nav.tab || S.tab; reload(); } }, ico('plus'), esc(b.toolbar.label)) : null);
  box.appendChild(head);
  if (b.search !== false && (b.items || []).length > 6) box.appendChild(h('input', { class: 'ml-s', placeholder: 'Rechercher…', oninput: (e) => draw(e.target.value.trim().toLowerCase()) }));
  box.appendChild(list); draw('');
  return box;
}
function blkGPreview(b) {
  const box = h('div'); const GP = window.PBGame;
  const draw = (cfg) => { try { if (GP && GP.preview[b.kind]) GP.preview[b.kind](box, cfg, b); else box.appendChild(h('div', { class: 'empty' }, 'Aperçu indisponible.')); } catch (e) { clear(box); box.appendChild(h('div', { class: 'empty' }, 'Aperçu : ' + e.message)); } };
  draw(b.cfg || {});
  if (S.pvHandler) document.removeEventListener('pbform', S.pvHandler);
  if (b.form) { S.pvHandler = (e) => { if (e.detail.id === b.form) draw(Object.assign({}, b.cfg || {}, e.detail.values)); }; document.addEventListener('pbform', S.pvHandler); }
  return card(b.title || 'Aperçu', b.desc, box);
}

/* ---------- grille de permissions ---------- */
function blkPerm(b) {
  const state = {}; const extra = (b.rules || []).map((r) => ({ pat: r.pat, allow: !!r.allow }));
  (b.groups || []).forEach((g) => g.perms.forEach((p) => { state[p.perm] = p.own === 'allow' ? true : p.own === 'deny' ? false : undefined; }));
  const filter = h('input', { type: 'text', class: 'cinp', placeholder: t('search'), style: { maxWidth: '280px' }, oninput: () => { const q = filter.value.toLowerCase(); wrap.querySelectorAll('.pr').forEach((r) => r.classList.toggle('hidden', q && r.getAttribute('data-s').indexOf(q) < 0)); } });
  const wrap = h('div');
  const dis = !b.submit;
  (b.groups || []).forEach((g, gi) => {
    const det = h('details', { class: 'pg-g', open: gi === 0 || (b.groups || []).length <= 6 }, h('summary', null, esc(g.label), h('small', null, g.perms.length + '')));
    g.perms.forEach((p) => {
      const seg = h('div', { class: 'seg' }), eff = h('span', { class: 'chip ' + (p.eff ? 'ok' : 'off'), title: esc((p.rule || '') + (p.from ? ' — ' + p.from : '')) }, p.eff ? t('allow') : t('deny'));
      const btns = [[undefined, t('inh'), 'inh'], [true, '✓', 'al'], [false, '✕', 'de']].map((o) => h('button', { type: 'button', disabled: dis, title: o[0] === undefined ? t('inh') : o[0] ? t('allow') : t('deny'), class: state[p.perm] === o[0] ? 'on ' + o[2] : '', onclick: () => { state[p.perm] = o[0]; btns.forEach((x, i) => x.className = [undefined, true, false][i] === o[0] ? 'on ' + ['inh', 'al', 'de'][i] : ''); } }, o[1]));
      btns.forEach((x) => seg.appendChild(x));
      det.appendChild(h('div', { class: 'pr', 'data-s': (p.label + ' ' + p.perm).toLowerCase() }, h('div', { class: 'pn' }, h('b', null, esc(p.label), p.danger ? h('span', { class: 'chip bad', style: { marginLeft: '8px' } }, '!') : null), h('small', null, esc(p.perm))), eff, seg));
    });
    wrap.appendChild(det);
  });
  const exBox = h('div');
  function drawEx() {
    clear(exBox);
    extra.forEach((r, i) => exBox.appendChild(h('div', { class: 'pr' }, h('input', { class: 'cinp', type: 'text', value: r.pat, disabled: dis, placeholder: 'ex. jobs.* ou *.view', oninput: (e) => { r.pat = e.target.value.trim(); } }),
      h('div', { class: 'seg' }, h('button', { type: 'button', class: r.allow ? 'on al' : '', disabled: dis, onclick: () => { r.allow = true; drawEx(); } }, '✓'), h('button', { type: 'button', class: !r.allow ? 'on de' : '', disabled: dis, onclick: () => { r.allow = false; drawEx(); } }, '✕')),
      dis ? null : h('button', { type: 'button', class: 'pl sm danger', onclick: () => { extra.splice(i, 1); drawEx(); } }, ico('x')))));
  }
  drawEx();
  const foot = h('div', { class: 'fsub' });
  if (!dis) {
    foot.appendChild(h('button', { type: 'button', class: 'pl sm', onclick: () => { extra.push({ pat: '', allow: true }); drawEx(); } }, ico('plus'), t('addRule')));
    foot.appendChild(h('button', { class: 'pl pri', style: { marginLeft: 'auto' }, onclick: () => {
      const rules = {}; Object.keys(state).forEach((k) => { if (state[k] !== undefined) rules[k] = state[k]; });
      for (const r of extra) { if (!r.pat) continue; if (!/^[a-z0-9_.*-]+$/i.test(r.pat)) return toast('Motif invalide : ' + r.pat, false); rules[r.pat] = r.allow; }
      run(b.submit.action, Object.assign({}, b.submit.payload || {}, { rules }), { refresh: true });
    } }, ico('save'), esc(b.submit.label || t('save'))));
  }
  return card(b.title, b.help, [h('div', { class: 'pg-top' }, filter), wrap, extra.length || !dis ? h('h4', { class: 'cd', style: { margin: '16px 0 6px' } }, t('rules')) : null, exBox, foot]);
}

/* ---------- éditeur ---------- */
function blkEditor(b) {
  const ta = h('textarea', { class: 'ed', spellcheck: 'false', readOnly: !!b.readonly || !b.save, wrap: 'off' }); ta.value = b.content || '';
  ta.addEventListener('keydown', (e) => { if (e.key === 'Tab') { e.preventDefault(); const s = ta.selectionStart; ta.value = ta.value.slice(0, s) + '    ' + ta.value.slice(ta.selectionEnd); ta.selectionStart = ta.selectionEnd = s + 4; } });
  const foot = h('div', { class: 'fsub' }, b.save && !b.readonly ? h('button', { class: 'pl pri', onclick: () => run(b.save.action, Object.assign({}, b.save.payload || {}, { content: ta.value }), { refresh: true }) }, ico('save'), esc(b.save.label || t('save'))) : null,
    h('button', { class: 'pl', onclick: () => { ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} toast(ok ? t('copied') : 'Ctrl+C', ok); } }, ico('copy'), t('copy')),
    h('span', { class: 'chip off' }, b.language || 'txt'));
  return card(b.title, b.desc, [ta, foot]);
}

/* ---------- graphique ---------- */
function blkChart(b) {
  const labels = b.labels || [], sers = (b.series || []).filter((x) => (x.values || []).length);
  const NS = 'http://www.w3.org/2000/svg', el = (n, a) => { const e = document.createElementNS(NS, n); Object.keys(a || {}).forEach((k) => e.setAttribute(k, a[k])); return e; };
  const box = h('div', { class: 'chart' }); const tip = h('div', { class: 'tip hidden' });
  const legend = sers.length > 1 ? h('div', { class: 'ch-lg' }) : null;
  const css = getComputedStyle(document.documentElement);
  const COL = [(css.getPropertyValue('--acc') || '').trim() || '#dfe2e7', '#7cc8ff', '#ffc65c', '#5ee09a'];
  const nice = (m) => { if (m <= 5) return 5; const p = Math.pow(10, Math.floor(Math.log10(m))), f = m / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };
  const uid = 'cg' + String(b.id || Math.random()).replace(/[^a-z0-9]/gi, '');
  function smooth(pts) {
    if (pts.length < 3) return pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    let d = 'M' + pts[0][0].toFixed(1) + ' ' + pts[0][1].toFixed(1);
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2, k = 0.18;
      d += ' C' + (p1[0] + (p2[0] - p0[0]) * k).toFixed(1) + ' ' + (p1[1] + (p2[1] - p0[1]) * k).toFixed(1) + ',' + (p2[0] - (p3[0] - p1[0]) * k).toFixed(1) + ' ' + (p2[1] - (p3[1] - p1[1]) * k).toFixed(1) + ',' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
    }
    return d;
  }
  function draw() {
    const W = Math.max(260, box.clientWidth || 600), H = 220, L = 38, R = 12, T = 12, B = 26;
    box.querySelectorAll('svg').forEach((n) => n.remove());
    const svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H });
    const all = sers.flatMap((x) => x.values || []); const mx = nice(Math.max(1, ...all) * 1.05), n = Math.max(...sers.map((x) => x.values.length));
    const X = (i) => L + (W - L - R) * (n > 1 ? i / (n - 1) : 0.5), Y = (v) => T + (H - T - B) * (1 - v / mx);
    const defs = el('defs'); svg.appendChild(defs);
    for (let i = 0; i <= 4; i++) {
      const v = mx * (1 - i / 4), y = Y(v);
      svg.appendChild(el('line', { x1: L, x2: W - R, y1: y, y2: y, stroke: 'rgba(255,255,255,' + (i === 4 ? '.16' : '.07') + ')', 'stroke-dasharray': i === 4 ? '' : '3 5' }));
      const tx = el('text', { x: L - 8, y: y + 3.5, fill: 'rgba(255,255,255,.5)', 'font-size': 10.5, 'text-anchor': 'end' }); tx.textContent = Math.round(v); svg.appendChild(tx);
    }
    const step = Math.max(1, Math.ceil(n / Math.max(2, Math.floor((W - L - R) / 70))));
    for (let i = 0; i < labels.length; i += step) { const tx = el('text', { x: X(i), y: H - 7, fill: 'rgba(255,255,255,.5)', 'font-size': 10.5, 'text-anchor': i === 0 ? 'start' : 'middle' }); tx.textContent = labels[i]; svg.appendChild(tx); }
    sers.forEach((sr, si) => {
      const col = COL[si % COL.length], pts = sr.values.map((v, i) => [X(i), Y(v)]);
      const gr = el('linearGradient', { id: uid + si, x1: 0, y1: 0, x2: 0, y2: 1 }); gr.appendChild(el('stop', { offset: '0', 'stop-color': col, 'stop-opacity': si ? '.12' : '.32' })); gr.appendChild(el('stop', { offset: '1', 'stop-color': col, 'stop-opacity': '0' })); defs.appendChild(gr);
      const d = smooth(pts);
      if (pts.length > 1) svg.appendChild(el('path', { d: d + ' L' + pts[pts.length - 1][0].toFixed(1) + ' ' + Y(0) + ' L' + pts[0][0].toFixed(1) + ' ' + Y(0) + ' Z', fill: 'url(#' + uid + si + ')' }));
      svg.appendChild(el('path', { d, fill: 'none', stroke: col, 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
      const last = pts[pts.length - 1]; svg.appendChild(el('circle', { cx: last[0], cy: last[1], r: 3.5, fill: col })); svg.appendChild(el('circle', { cx: last[0], cy: last[1], r: 7, fill: col, opacity: '.18' }));
    });
    const cross = el('line', { y1: T, y2: H - B, stroke: 'rgba(255,255,255,.28)', opacity: 0 }); svg.appendChild(cross);
    const dots = sers.map((_, si) => { const c = el('circle', { r: 4, fill: '#fff', stroke: COL[si % COL.length], 'stroke-width': 2, opacity: 0 }); svg.appendChild(c); return c; });
    const hit = el('rect', { x: L, y: T, width: W - L - R, height: H - T - B, fill: 'transparent' }); svg.appendChild(hit);
    hit.addEventListener('mousemove', (e) => {
      const r = svg.getBoundingClientRect(), px = (e.clientX - r.left) * (W / r.width);
      const i = Math.max(0, Math.min(n - 1, Math.round((px - L) / ((W - L - R) / Math.max(1, n - 1)))));
      cross.setAttribute('x1', X(i)); cross.setAttribute('x2', X(i)); cross.setAttribute('opacity', 1);
      dots.forEach((c, si) => { const v = sers[si].values[i]; if (v == null) { c.setAttribute('opacity', 0); return; } c.setAttribute('cx', X(i)); c.setAttribute('cy', Y(v)); c.setAttribute('opacity', 1); });
      clear(tip); tip.appendChild(h('b', null, esc(labels[i] || ''))); sers.forEach((sr, si) => { if (sr.values[i] != null) tip.appendChild(h('span', null, h('i', { style: { background: COL[si % COL.length] } }), esc((sr.name || '') + (sr.name ? ' : ' : '') + sr.values[i]))); });
      tip.classList.remove('hidden'); const tw = tip.offsetWidth; tip.style.left = Math.max(4, Math.min(box.clientWidth - tw - 4, X(i) * (r.width / W) - tw / 2)) + 'px'; tip.style.top = '4px';
    });
    hit.addEventListener('mouseleave', () => { cross.setAttribute('opacity', 0); dots.forEach((c) => c.setAttribute('opacity', 0)); tip.classList.add('hidden'); });
    box.insertBefore(svg, tip);
  }
  box.appendChild(tip);
  if (legend) sers.forEach((sr, si) => legend.appendChild(h('span', null, h('i', { style: { background: COL[si % COL.length] } }), esc(sr.name || ''))));
  let t0 = 0; const redraw = () => { if (box.isConnected) draw(); };
  requestAnimationFrame(() => { redraw(); setTimeout(redraw, 120); });
  window.addEventListener('resize', () => { clearTimeout(t0); t0 = setTimeout(redraw, 100); });
  return card(b.title, null, legend ? [legend, box] : box);
}

/* ---------- plan ---------- */
/* Carte du jeu : image satellite + points (m) calibrés sur quelques repères — précision de l'ordre de 100 m, suffisante pour situer un point. */
const MAPCAL = { ax: -5206.4, bx: 11493.2, ay: 8271.8, by: 12556 };      // x = u*bx + ax ; y = ay - v*by
const mapUV = (x, y) => [(x - MAPCAL.ax) / MAPCAL.bx, (MAPCAL.ay - y) / MAPCAL.by];
function blkMap(b) {
  const pts = b.points || [];
  const view = { s: 1, x: 0, y: 0 };
  let style = 'sat'; try { style = localStorage.getItem('pb_map_style') === 'plan' ? 'plan' : 'sat'; } catch (e) { /* rien */ }
  const wrap = h('div', { class: 'gmap' }), inn = h('div', { class: 'gm-in' }), img = h('img', { src: style === 'plan' ? 'img/map-plan.jpg' : 'img/map.jpg', alt: '', draggable: 'false' });
  // satellite (noms des lieux) ou plan des routes : même cadrage, même calibrage
  const seg = h('div', { class: 'map-seg' });
  const drawSeg = () => { seg.innerHTML = ''; [['sat', 'Satellite'], ['plan', 'Plan']].forEach(([k, l]) => seg.appendChild(h('button', { type: 'button', class: style === k ? 'on' : '', onclick: (e) => { e.stopPropagation(); style = k; try { localStorage.setItem('pb_map_style', k); } catch (er) { /* rien */ } img.src = k === 'plan' ? 'img/map-plan.jpg' : 'img/map.jpg'; drawSeg(); } }, l))); };
  drawSeg();
  wrap.appendChild(seg);
  inn.appendChild(img);
  const tip = h('div', { class: 'gm-tip hidden' });
  pts.forEach((p) => {
    const uv = mapUV(Number(p.x) || 0, Number(p.y) || 0), col = /^#[0-9a-f]{3,8}$/i.test(p.color || '') ? p.color : '#ffffff';
    if (p.r) inn.appendChild(h('i', { class: 'gm-c', style: { left: uv[0] * 100 + '%', top: uv[1] * 100 + '%', width: (2 * p.r / MAPCAL.bx * 100) + '%', height: (2 * p.r / MAPCAL.bx * 100) + '%', borderColor: col, background: col + '33' } }));
    const d = h('b', { class: 'gm-p' + (p.on === false ? ' off' : ''), style: { left: uv[0] * 100 + '%', top: uv[1] * 100 + '%', background: col } });
    const info = (p.label || '') + (p.sub ? ' · ' + p.sub : '');
    d.addEventListener('mouseenter', () => { tip.textContent = info; tip.classList.remove('hidden'); });
    d.addEventListener('mouseleave', () => tip.classList.add('hidden'));
    d.addEventListener('click', (e) => { e.stopPropagation(); if (b.open) { const pr = {}; pr[b.open.key || 'id'] = p.id; navTo({ tab: b.open.tab, params: pr }); } });
    inn.appendChild(d);
  });
  function apply() {
    const r = wrap.getBoundingClientRect(), W = r.width || 1, H = r.height || 1;
    view.s = Math.min(8, Math.max(1, view.s));
    view.x = Math.min(0, Math.max(W - W * view.s, view.x)); view.y = Math.min(0, Math.max(H - H * view.s, view.y));
    inn.style.transform = 'translate(' + view.x + 'px,' + view.y + 'px) scale(' + view.s + ')';
    inn.style.setProperty('--inv', String(1 / view.s));
  }
  wrap.addEventListener('wheel', (e) => {
    e.preventDefault();
    const r = wrap.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, k = e.deltaY < 0 ? 1.25 : 0.8, ns = Math.min(8, Math.max(1, view.s * k)), f = ns / view.s;
    view.x = mx - (mx - view.x) * f; view.y = my - (my - view.y) * f; view.s = ns; apply();
  }, { passive: false });
  let drag = null;
  let startPt = null, mark = null;
  wrap.addEventListener('pointerdown', (e) => { if (e.target.closest && e.target.closest('.gm-ctl')) return; startPt = { x: e.clientX, y: e.clientY }; drag = { x: e.clientX - view.x, y: e.clientY - view.y }; wrap.setPointerCapture(e.pointerId); wrap.classList.add('grab'); });
  wrap.addEventListener('pointermove', (e) => { if (!drag) return; view.x = e.clientX - drag.x; view.y = e.clientY - drag.y; apply(); });
  wrap.addEventListener('pointerup', (e) => {
    const was = drag; drag = null; wrap.classList.remove('grab');
    if (was && b.pick && startPt && Math.hypot(e.clientX - startPt.x, e.clientY - startPt.y) < 5) {
      const r = inn.getBoundingClientRect(), u = (e.clientX - r.left) / r.width, v = (e.clientY - r.top) / r.height;
      if (u >= 0 && u <= 1 && v >= 0 && v <= 1) {
        if (!mark) { mark = h('b', { class: 'gm-pick' }); inn.appendChild(mark); }
        mark.style.left = u * 100 + '%'; mark.style.top = v * 100 + '%';
        b.pick(Math.round(u * MAPCAL.bx + MAPCAL.ax), Math.round(MAPCAL.ay - v * MAPCAL.by));
      }
    }
  });
  const zoom = (k) => { const r = wrap.getBoundingClientRect(), mx = r.width / 2, my = r.height / 2, ns = Math.min(8, Math.max(1, view.s * k)), f = ns / view.s; view.x = mx - (mx - view.x) * f; view.y = my - (my - view.y) * f; view.s = ns; apply(); };
  wrap.appendChild(inn); wrap.appendChild(tip);
  wrap.appendChild(h('div', { class: 'gm-ctl' }, h('button', { onclick: () => zoom(1.4) }, '+'), h('button', { onclick: () => zoom(0.7) }, '−'), h('button', { onclick: () => { view.s = 1; view.x = 0; view.y = 0; apply(); } }, '⟲')));
  setTimeout(apply, 0);
  const leg = (b.legend || []).map((l) => h('span', { class: 'gm-lg' }, h('i', { style: { background: l.color } }), l.label));
  return card(b.title, b.desc, [wrap, h('div', { class: 'gm-foot' }, h('span', { class: 'cd' }, pts.length + ' point(s) · molette pour zoomer, glisser pour déplacer · position à ~100 m près'), h('span', { class: 'gm-legend' }, leg))]);
}


/* ---------- carte : choisir le type, cliquer, se téléporter, confirmer ---------- */
function blkCarte(b) {
  const st = { type: (b.types[0] || {}).id, x: null, y: null, name: '', owner: '', preset: '' };
  const typeBox = h('div', { class: 'ct-types' }), formBox = h('div', { class: 'ct-form' }), posOut = h('div', { class: 'ct-pos cd' }, 'Clique sur la carte pour placer le repère.');
  const cur = () => b.types.find((t) => t.id === st.type);
  function drawTypes() {
    clear(typeBox);
    const groups = {}; const order = [];
    b.types.forEach((t) => { if (!groups[t.group]) { groups[t.group] = []; order.push(t.group); } groups[t.group].push(t); });
    order.forEach((g) => {
      typeBox.appendChild(h('div', { class: 'ct-g' }, h('i', { style: { background: (b.colors || {})[g] || '#fff' } }), g));
      groups[g].forEach((t) => typeBox.appendChild(h('button', { type: 'button', class: 'ct-t' + (t.id === st.type ? ' on' : ''), onclick: () => { st.type = t.id; st.owner = ''; st.preset = ''; drawTypes(); drawForm(); } }, ico(t.icon || 'pin'), esc(t.label))));
    });
  }
  function selectOf(opts, val, cb, ph) {
    const s = h('select', { onchange: () => cb(s.value) }, [h('option', { value: '' }, ph || '—')].concat(opts.map((o) => h('option', { value: o[0] }, esc(o[1])))));
    s.value = val || ''; return s;
  }
  function drawForm() {
    clear(formBox);
    const t = cur(); if (!t) return;
    formBox.appendChild(h('div', { class: 'f' }, h('label', null, 'Nom du point', h('em', null, '*')), h('input', { type: 'text', maxlength: 48, value: st.name, placeholder: t.label, oninput: (e) => { st.name = e.target.value; } })));
    if (t.needs === 'biz') formBox.appendChild(h('div', { class: 'f' }, h('label', null, 'Entreprise', h('em', null, '*')), selectOf(b.bizs || [], st.owner, (v) => { st.owner = v; }, 'Choisir une entreprise')));
    if (t.needs === 'gang') formBox.appendChild(h('div', { class: 'f' }, h('label', null, 'Gang', h('em', null, '*')), selectOf(b.gangs || [], st.owner, (v) => { st.owner = v; }, 'Choisir un gang')));
    if (t.presets) { st.preset = st.preset || t.presets[0][0]; const s = h('select', { onchange: () => { st.preset = s.value; } }, t.presets.map((o) => h('option', { value: o[0] }, esc(o[1])))); s.value = st.preset; formBox.appendChild(h('div', { class: 'f' }, h('label', null, 'Produit'), s)); }
  }
  function payload() { return { type: st.type, x: st.x, y: st.y, name: st.name.trim() || (cur() || {}).label || '', owner: st.owner, preset: st.preset }; }
  function why() {
    const t = cur();
    if (!t) return 'Choisis un type de point.';
    if ((st.name.trim() || '').length < 2 && !t.label) return 'Donne un nom au point.';
    if (t.needs === 'biz' && !st.owner) return "Choisis l'entreprise concernée.";
    if (t.needs === 'gang' && !st.owner) return 'Choisis le gang concerné.';
    return null;
  }
  const mk = (label, icon, action, needPos) => {
    const bt = h('button', { type: 'button', class: 'pl pri' }, ico(icon), esc(label));
    bt.addEventListener('click', async () => {
      const w = why() || (needPos && st.x == null ? "Clique d'abord un endroit sur la carte." : null);
      if (w) { bt.classList.add('blocked'); setTimeout(() => bt.classList.remove('blocked'), 2200); return toast(w, false); }
      if (bt.dataset.busy === '1') return; bt.dataset.busy = '1'; bt.classList.add('busy');
      try { const r = await run(action, payload(), { noRefresh: false }); if (r && r.ok === false) { bt.classList.add('blocked'); setTimeout(() => bt.classList.remove('blocked'), 2200); } else if (r && r.ok && action === 'carte.here') { st.name = ''; drawForm(); } }
      finally { bt.dataset.busy = ''; bt.classList.remove('busy'); }
    });
    return bt;
  };
  const map = blkMap({ title: 'Carte du jeu', points: b.points || [], legend: b.legend || [], pick: (x, y) => { st.x = x; st.y = y; posOut.textContent = 'Repère : x ' + x + ' · y ' + y + ' (précision ~100 m)'; } });
  drawTypes(); drawForm();
  const side = h('div', { class: 'ct-side' }, card('1 · Quoi ajouter ?', null, typeBox), card('2 · Détails', null, [formBox, posOut,
    h('div', { class: 'fsub ct-act' }, mk('Me téléporter là-bas', 'gps', 'carte.start', true), mk('Créer à ma position', 'pin', 'carte.here', false))]));
  return h('div', { class: 'ct-wrap' }, side, h('div', { class: 'ct-map' }, map, h('div', { class: 'hint ct-hint' }, "3 · Clique sur la carte, téléporte-toi, place-toi exactement puis appuie sur E en jeu pour confirmer (Retour arrière annule).")));
}

/* ---------- préférences personnelles ---------- */
function blkPrefs(b) {
  const P = S.prefs, I = S.boot.interface || {};
  const row = (label, el) => h('div', { class: 'f' }, h('label', null, label), el);
  const themes = [['elyx', 'W (gris blanc)'], ['mauve', 'Mauve'], ['aurora', 'Aurora'], ['ember', 'Ember'], ['forest', 'Forest'], ['mono', 'Mono'], ['halloween', 'Halloween'], ['noel', 'Noël']];
  const sel = (k, opts, cur, cb) => { const s = h('select', { onchange: () => cb(s.value) }, opts.map((o) => h('option', { value: o[0] }, o[1]))); s.value = cur; return s; };
  const rng = (min, max, cur, cb) => { const o = h('output', null, String(cur)), i = h('input', { type: 'range', min, max, value: cur, oninput: () => { o.textContent = i.value; cb(Number(i.value)); } }); return h('div', { class: 'rng' }, i, o); };
  const upd = (patch) => { savePrefs(patch); applyLook(); };
  return card(b.title || t('prefsT'), b.desc, h('div', { class: 'form-grid', style: { gridTemplateColumns: 'repeat(2,minmax(0,1fr))' } },
    row('Thème', sel('theme', themes, P.theme || I.theme || 'elyx', (v) => upd({ theme: v }))),
    row('Densité', sel('density', [['compact', 'Compacte'], ['comfort', 'Confortable'], ['large', 'Large']], P.density || I.density || 'comfort', (v) => upd({ density: v }))),
    row('Langue', sel('lang', [['fr', 'Français'], ['en', 'English']], S.lang, (v) => { S.lang = v; savePrefs({ lang: v }); buildShell(); reload(); })),
    row('Couleur d\'accent', (() => { const c = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(P.accent || '') ? P.accent : '#dfe2e7', oninput: () => upd({ accent: c.value }) }); return h('div', { class: 'colr' }, c); })()),
    row('Opacité du verre', rng(0, 100, P.opacity != null ? P.opacity : 55, (v) => upd({ opacity: v }))),
    row('Flou', rng(0, 40, P.blur != null ? P.blur : 18, (v) => upd({ blur: v })))));
}

/* ---------- positionnement du menu staff ---------- */
function blkPositioner(b) {
  const v = Object.assign({ x: 50, y: 50, scale: 1, opacity: 1 }, b.value || {});
  const scr = h('div', { class: 'screen' }), mn = h('div', { class: 'mn', tabindex: 0 }, b.label || 'Menu staff');
  function place() { mn.style.left = v.x + '%'; mn.style.top = v.y + '%'; mn.style.width = (120 * v.scale) + 'px'; mn.style.height = (150 * v.scale) + 'px'; mn.style.opacity = v.opacity; mn.title = Math.round(v.x) + ' % · ' + Math.round(v.y) + ' %'; }
  place(); scr.appendChild(mn);
  let drag = false;
  mn.addEventListener('pointerdown', (e) => { drag = true; mn.setPointerCapture(e.pointerId); });
  mn.addEventListener('pointerup', () => { drag = false; });
  mn.addEventListener('pointermove', (e) => { if (!drag) return; const r = scr.getBoundingClientRect(); v.x = Math.min(100, Math.max(0, (e.clientX - r.left) / r.width * 100)); v.y = Math.min(100, Math.max(0, (e.clientY - r.top) / r.height * 100)); place(); readout.textContent = Math.round(v.x) + ' % / ' + Math.round(v.y) + ' %'; });
  mn.addEventListener('keydown', (e) => { const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key]; if (d) { e.preventDefault(); v.x = Math.min(100, Math.max(0, v.x + d[0])); v.y = Math.min(100, Math.max(0, v.y + d[1])); place(); readout.textContent = Math.round(v.x) + ' % / ' + Math.round(v.y) + ' %'; } });
  const readout = h('span', { class: 'chip' }, Math.round(v.x) + ' % / ' + Math.round(v.y) + ' %');
  const rg = (min, max, step, k) => { const o = h('output', null, String(v[k])), i = h('input', { type: 'range', min, max, step, value: v[k], oninput: () => { v[k] = Number(i.value); o.textContent = i.value; place(); } }); return h('div', { class: 'rng' }, i, o); };
  return card(b.title, 'Glisse le rectangle avec la souris (ou les flèches du clavier) à l\'endroit voulu sur l\'écran.', [scr,
    h('div', { class: 'form-grid', style: { gridTemplateColumns: 'repeat(2,minmax(0,1fr))', marginTop: '14px', maxWidth: '640px' } }, h('div', { class: 'f' }, h('label', null, t('scale')), rg(0.6, 1.6, 0.05, 'scale')), b.noOpacity ? null : h('div', { class: 'f' }, h('label', null, t('opac')), rg(0.3, 1, 0.05, 'opacity'))),
    h('div', { class: 'fsub' }, b.save ? h('button', { class: 'pl pri', onclick: () => run(b.save.action, Object.assign({}, b.save.payload || {}, { values: { x: +v.x.toFixed(2), y: +v.y.toFixed(2), scale: v.scale, opacity: v.opacity } }), { refresh: true }) }, ico('save'), esc(b.save.label || t('save'))) : null, readout)]);
}

/* ---------- éditeur de placement (vrais éléments, voir web/game/layout.js) ---------- */
function blkLayout(b) {
  const GP = window.PBGame;
  if (!GP || !GP.layoutEditor) return card(b.title, b.desc, h('div', { class: 'empty' }, 'Éditeur indisponible.'));
  const ed = GP.layoutEditor(b, { save: async (groups) => { const r = await run(b.save.action, { groups }); return !!(r && r.ok !== false); } });
  return card(b.title, b.desc, ed);
}

/* ---------- démarrage ---------- */
window.__pb = { S, run, call, h, block };
document.body.classList.toggle('dev', !IN_GAME);
})();
