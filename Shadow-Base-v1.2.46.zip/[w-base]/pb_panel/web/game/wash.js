/* Blanchiment : fenêtre du contact (même style que la banque, web/game/daview.js) à la place du menu lib.
   Argent sale sur soi, offres du contact (commission, argent propre récupéré, durée), ou l'avancement du blanchiment en cours. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let cur = null;
const host = () => document.getElementById('g-wash') || (function () { const e = h('div', { id: 'g-wash', class: 'hidden' }); G.root.appendChild(e); return e; })();
const fmt = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
const dur = (s) => { s = Math.max(0, Number(s) || 0); return s > 3600 ? Math.floor(s / 3600) + ' h ' + String(Math.floor((s % 3600) / 60)).padStart(2, '0') : Math.max(1, Math.floor(s / 60)) + ' min'; };

function pageOf(d) {
  if (d.job) {
    const j = d.job, due = Math.max(0, (Number(j.clean) || 0) - (Number(j.paid) || 0));
    const here = String(j.spot) === String(d.id);
    return { page: 'home', title: j.done ? 'Blanchiment terminé' : 'Blanchiment en cours', blocks: [
      { type: 'washring', pct: j.done ? 100 : j.pct, left: j.left, total: j.total, dirty: j.dirty, clean: due, cut: j.cut, done: !!j.done },
      j.done && here ? { type: 'actions', items: [{ act: 'collect', label: 'Récupérer ' + fmt(due), icon: 'coins', primary: true }] }
        : j.done ? { type: 'notice', kind: 'warn', text: 'Ton argent t\u2019attend chez ' + (j.spotLabel || 'ton autre contact') + '.' }
        : { type: 'notice', text: 'L\u2019argent propre reste chez le contact : reviens le chercher à la fin (une notification te prévient). Les VIP suivent l\u2019avancement de partout avec /blanchiment.' }] };
  }
  const offers = d.offers || [];
  const blocks = [{ type: 'hero', eyebrow: 'Le contact', title: 'Argent sale sur toi : ' + fmt(d.have), sub: 'Choisis ta mise : plus elle est grosse, plus la commission baisse.' }];
  if (!offers.length) blocks.push({ type: 'notice', kind: 'warn', text: 'Il faut au moins ' + fmt(d.min) + ' d’argent sale pour parler affaires.' });
  else blocks.push({ type: 'tiles', title: 'Confier une somme', items: offers.map((o) => ({ title: fmt(o.amount), sub: 'Commission ' + o.cut + ' % · ' + fmt(o.clean) + ' propres · ' + o.dur, icon: 'coins', act: 'start', payload: { amount: o.amount } })) },
    { type: 'notice', text: 'L’argent sale part tout de suite ; l’argent propre t’attend ici à la fin (une notification te prévient).' });
  return { page: 'home', title: 'Blanchiment', blocks };
}
G.on('wash.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  const frame = { brand: String(d.label || 'Blanchiment'), name: 'Le contact', nav: [{ id: 'home', label: 'Blanchiment', icon: 'coins', group: 'Contact' }] };
  cur = G.daView({ frame, page: pageOf(d), onClose: () => G.post('wash.close', {}), onPage: () => {},
    onAct: (n, pl) => { if (n === 'start') G.post('wash.start', { id: d.id, amount: pl.amount }); else if (n === 'collect') G.post('wash.collect', { id: d.id }); } });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'wash'); G.uiStack.push({ id: 'wash', onEscape: () => G.post('wash.close', {}) });
});
G.on('wash.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'wash'); });

G.preview.wash = function (box) {
  G.clear(box);
  const d = { label: 'Laverie de Strawberry', have: 48250, min: 1000, offers: [{ amount: 5000, cut: 30, clean: 3500, dur: '10 min' }, { amount: 20000, cut: 25, clean: 15000, dur: '30 min' }, { amount: 45000, cut: 20, clean: 36000, dur: '1 h' }] };
  box.appendChild(G.fitStage(G.daView({ frame: { brand: d.label, name: 'Le contact', nav: [{ id: 'home', label: 'Blanchiment', icon: 'coins', group: 'Contact' }] }, page: pageOf(d), onPage: () => {}, onAct: () => {} }).el));
};
})();
