-- Actions de métier dans le menu F6 : chaque métier a ses gestes à lui, cohérents avec ce qu'il fait en ville.
-- Mécano / dépanneur : diagnostic, moteur, carrosserie, pneus, remettre sur ses roues, ouvrir un véhicule verrouillé, plateau, fourrière, carburant.
-- Secours : bilan du patient ; pompiers : éteindre les feux. Police : contrôle d'identité, contrôle de plaque. Armurerie : permis d'arme.
-- Médias : flash info. Station-service : plein. Station de lavage : lavage. Transport et travaux : missions de l'entreprise (GPS).
-- Sécurité d'un club (droit « security », ex. agent de sécurité du Galaxy) : palpation, contrôle à l'entrée, bracelet, interdiction d'entrée,
-- expulsion, renfort, liste de la soirée.
-- Factures pré-remplies selon le secteur (garage, santé, restauration…).
-- Déroulé d'une action sur un véhicule : le client désigne le véhicule le plus proche, le serveur le retrouve (plaque lue par lui),
-- lance l'animation, vérifie à la fin la durée et la distance, puis applique l'effet et ajoute le prix à la facture du garage.

local G, DB = PB.G, PB.DB
local Q, Biz = G.Quick, G.Biz
local JP = { jobs = {}, last = {} }
G.JobPacks = JP

PB.Cfg.Define('jobpacks', { enabled = true, veh_dist = 7, prices = { engine = 300, body = 300, tyres = 150, flip = 80, unlock = 120, tow = 350, refuel = 0, wash = 0 },
    secs = { engine = 9, body = 9, tyres = 6, flip = 4, unlock = 10, impound = 8, refuel = 6, wash = 8, extinguish = 6 }, flash_cooldown = 120, flash_maxlen = 200,
    presets = {
        auto = { 'Réparation|500', 'Remorquage|350', 'Pneus|150', 'Nettoyage|100' }, sante = { 'Consultation|150', 'Soins|300', 'Transport en ambulance|500' },
        resto = { 'Menu|25', 'Boisson|8', 'Commande de groupe|150' }, commerce = { 'Achat|50', 'Commande spéciale|250' }, services = { 'Prestation|250', 'Frais de dossier|500' },
        medias = { 'Annonce publicitaire|300', 'Reportage|800' }, club = { 'Entrée|50', 'Entrée VIP (carré)|150', 'Cocktail|25', 'Bouteille|400', 'Table réservée|600' }, loisirs = { 'Entrée|50', 'Séance|100' }, industrie = { 'Livraison|200', 'Chantier|1000' },
        public = { 'Frais administratifs|100', 'Document officiel|250' }, facade = { 'Prestation|250' } } })
local function cfg(k, d) return PB.Cfg.Get('jobpacks', k, d) end
local function tbl(k, sub, d) local t = cfg(k, {}) or {} local v = tonumber(t[sub]) return v or d end
local function now() return os.time() end
local function display(src) return Biz.Display and Biz.Display(src) or ('#' .. tostring(src)) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):gsub('%s+', ' '):gsub('^ ', ''):sub(1, n)) end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function modelKey(c) return G.BizCat and G.BizCat.ModelKey and G.BizCat.ModelKey(c.biz) or c.biz.id end

-- Qui a quoi --------------------------------------------------------------------------------------------------------------------------------
local TOWING = { towing = true, mecano = true, scrapyard = true }
local function is(c, what)
    local k, kind, cat = modelKey(c), c.biz.kind, c.biz.category
    if what == 'mech' then return Biz.Allowed(c, 'repair') end
    if what == 'tow' then return Biz.Allowed(c, 'repair') and (TOWING[k] == true or kind == 'garage') end
    if what == 'ems' then return kind == 'ems' end
    if what == 'fire' then return k == 'fire' end
    if what == 'police' then return kind == 'police' end
    if what == 'gun' then return k == 'gunshop' end
    if what == 'media' then return cat == 'medias' or k == 'weazel' or k == 'radio' or k == 'newspaper' end
    if what == 'gas' then return k == 'gasstation' or (Biz.Allowed(c, 'repair') and TOWING[k] == true) end
    if what == 'wash' then return k == 'carwash' end
    if what == 'missions' then return cat == 'industrie' end
    if what == 'security' then return Biz.Allowed(c, 'security') end
    return false
end
JP.Is = is

-- Actions -----------------------------------------------------------------------------------------------------------------------------------
-- veh = sur le véhicule le plus proche ; secs = animation (durée vérifiée) ; fx = effet appliqué par le client du joueur ; price = ajouté à la facture
local A = {
    { id = 'job_vdiag', who = 'mech', veh = true, quiet = true, fx = 'diag', label = 'Diagnostic du véhicule', icon = 'search', desc = 'État du moteur, de la carrosserie, du réservoir, des pneus et du carburant.' },
    { id = 'job_engine', who = 'mech', veh = true, secs = 'engine', fx = 'engine', price = 'engine', label = 'Réparer le moteur', icon = 'engine', anim = 'PROP_HUMAN_BUM_BIN', desc = 'Moteur et réservoir remis à neuf. Ajouté à la facture.' },
    { id = 'job_body', who = 'mech', veh = true, secs = 'body', fx = 'body', price = 'body', label = 'Réparer la carrosserie', icon = 'wrench', anim = 'WORLD_HUMAN_WELDING', desc = 'Tôle, vitres et portières. Ajouté à la facture.' },
    { id = 'job_tyres', who = 'mech', veh = true, secs = 'tyres', fx = 'tyres', price = 'tyres', label = 'Changer les pneus', icon = 'wheel', anim = 'CODE_HUMAN_MEDIC_KNEEL', desc = 'Remplace les pneus crevés. Ajouté à la facture.' },
    { id = 'job_flip', who = 'mech', veh = true, secs = 'flip', fx = 'flip', price = 'flip', label = 'Remettre sur ses roues', icon = 'refresh', anim = 'PROP_HUMAN_BUM_BIN', desc = 'Un véhicule retourné ou couché sur le côté. Ajouté à la facture.' },
    { id = 'job_unlock', who = 'mech', veh = true, secs = 'unlock', fx = 'unlock', price = 'unlock', label = 'Ouvrir un véhicule verrouillé', icon = 'key', anim = 'PROP_HUMAN_PARKING_METER', desc = 'Client qui a perdu ses clés. Inscrit dans les dossiers de l\'entreprise.' },
    { id = 'job_refuel', who = 'gas', veh = true, secs = 'refuel', fx = 'refuel', price = 'refuel', label = 'Faire le plein', icon = 'drop', anim = 'PROP_HUMAN_PARKING_METER', desc = 'Remplit le réservoir du véhicule le plus proche.' },
    { id = 'job_wash', who = 'wash', veh = true, secs = 'wash', fx = 'wash', price = 'wash', label = 'Laver le véhicule', icon = 'drop', anim = 'WORLD_HUMAN_MAID_CLEAN', desc = 'Lavage complet du véhicule le plus proche.' },
    { id = 'job_tow_load', who = 'tow', quiet = true, fx = 'tow_load', label = 'Charger sur le plateau', icon = 'truck', desc = 'Ta dépanneuse à plateau (Flatbed) à côté, le véhicule à charger juste derrière.' },
    { id = 'job_tow_unload', who = 'tow', quiet = true, fx = 'tow_unload', label = 'Décharger le plateau', icon = 'truck', desc = 'Dépose le véhicule chargé derrière la dépanneuse.' },
    { id = 'job_impound', who = 'tow', veh = true, secs = 'impound', price = 'tow', label = 'Envoyer à la fourrière', icon = 'lock', anim = 'WORLD_HUMAN_CLIPBOARD', inputs = { { k = 'reason', label = 'Motif (stationnement gênant, épave…)', maxlen = 70 } },
        desc = 'Véhicule abandonné ou gênant : il part à la fourrière, son propriétaire est prévenu. Inscrit dans les dossiers.' },
    { id = 'job_pdiag', who = 'ems', target = true, label = 'Bilan du patient', icon = 'heart', desc = 'Conscience et état de santé de la personne choisie.' },
    { id = 'job_extinguish', who = 'fire', quiet = true, secs = 'extinguish', fx = 'extinguish', label = 'Éteindre les feux autour', icon = 'fire', anim = 'WORLD_HUMAN_STAND_FIRE', desc = 'Éteint les feux dans un rayon de 20 m.' },
    { id = 'job_idcheck', who = 'police', target = true, label = "Contrôle d'identité", icon = 'id', desc = "Nom, naissance, nationalité, permis d'arme et antécédents de la personne choisie." },
    { id = 'job_plate', who = 'police', veh = true, label = 'Contrôler la plaque', icon = 'search', desc = 'Propriétaire et situation du véhicule le plus proche (fourrière, non enregistré).' },
    { id = 'job_permit', who = 'gun', target = true, label = "Vérifier le permis d'arme", icon = 'id', desc = "Avant une vente : la personne choisie a-t-elle un permis de port d'arme ?" },
    { id = 'job_frisk', who = 'security', target = true, label = 'Palpation de sécurité', icon = 'hand', desc = "À l'entrée : la personne choisie porte-t-elle une arme ? Tu ne prends rien, tu refuses l'entrée si besoin." },
    { id = 'job_door', who = 'security', target = true, label = "Contrôle à l'entrée", icon = 'id', desc = 'Nom, âge (majeur ou non), bracelet et interdiction d\'entrée de la personne choisie.' },
    { id = 'job_band', who = 'security', target = true, label = 'Poser un bracelet', icon = 'star', desc = 'Bracelet de la soirée (entrée payée ou carré VIP), valable 6 heures.', inputs = { { k = 'kind', label = 'Bracelet (entrée, vip, staff…)', maxlen = 16 } } },
    { id = 'job_ban', who = 'security', target = true, label = "Interdire l'entrée", icon = 'lock', desc = "La personne est inscrite sur la liste des interdits du club (motif gardé dans les dossiers).", inputs = { { k = 'reason', label = 'Motif (bagarre, arme, comportement…)', maxlen = 80 } } },
    { id = 'job_unban', who = 'security', target = true, label = "Lever l'interdiction", icon = 'check', desc = 'Retire la personne choisie de la liste des interdits.' },
    { id = 'job_expel', who = 'security', target = true, label = 'Expulser du club', icon = 'close', desc = "La personne choisie est priée de sortir : elle reçoit l'ordre et le point de sortie sur son GPS." },
    { id = 'job_backup', who = 'security', label = 'Demander du renfort', icon = 'siren', desc = 'Alerte tous les collègues en service, avec ta position sur leur GPS.' },
    { id = 'job_guests', who = 'security', label = 'Liste de la soirée', icon = 'list', desc = 'Bracelets posés et personnes interdites.' },
    { id = 'job_flash', who = 'media', label = 'Flash info', icon = 'chat', desc = 'Une annonce spéciale de ton média, en grand, chez tous les joueurs.', inputs = { { k = 'text', label = 'Flash info (toute la ville)', maxlen = 200 } } },
}
local BY = {}
for _, a in ipairs(A) do BY[a.id] = a end
JP.Actions = A

local function missions(c)
    local out = {}
    for _, j in ipairs(DB.q("SELECT id, label, pay, x, y FROM pb_civil_jobs WHERE enabled = 1 AND (biz = ? OR biz = '') ORDER BY label LIMIT 12", { c.biz.id }) or {}) do
        out[#out + 1] = { label = j.label, right = (tonumber(j.pay) or 0) > 0 and money(j.pay) or nil, payload = { mission = j.id } }
    end
    return out
end

table.insert(Q.Common, 1, function(src, c, add)
    if cfg('enabled', true) == false or not c.duty then return end
    local first = true
    for _, a in ipairs(A) do
        if is(c, a.who) then
            if first then add({ type = 'separator', label = 'Gestes du métier' }) first = false end
            local price = a.price and tbl('prices', a.price, 0) or 0
            add({ id = a.id, label = a.label, icon = a.icon, desc = a.desc, right = price > 0 and money(price) or nil, needs = a.target and 'target' or nil, inputs = a.inputs })
        end
    end
    if is(c, 'missions') then
        local list = missions(c)
        if #list > 0 then
            if first then add({ type = 'separator', label = 'Gestes du métier' }) end
            add({ id = 'job_missions', type = 'choices', label = "Missions de l'entreprise", icon = 'gps', right = tostring(#list), items = list, desc = 'GPS vers le départ de la mission choisie.' })
        end
    end
end)

-- Factures pré-remplies selon le secteur
local CLUBS = { galaxy = true, nightclub = true, bahamas = true, unicorn = true, tequilala = true }
function JP.Presets(c)
    local all = cfg('presets', {}) or {}
    local list = (CLUBS[modelKey(c) or ''] and all.club) or all[c.biz.category or ''] or (c.biz.kind == 'garage' and all.auto) or (c.biz.kind == 'ems' and all.sante)
    return type(list) == 'table' and #list > 0 and list or nil
end

-- Exécution ---------------------------------------------------------------------------------------------------------------------------------
local function fxTo(src, kind, data) data = data or {} data.kind = kind TriggerClientEvent('pb:g:job:fx', src, PB.Json(data)) end
local function finish(src, c, a, d)
    if a.id == 'job_impound' then
        if d.plate == '' then return false, 'Plaque illisible.' end
        local plate = G.Garage and G.Garage.Real and G.Garage.Real(d.plate) or d.plate
        local v = G.Garage and G.Garage.Vehicle(plate)
        if not v then return false, 'Véhicule non enregistré en ville : impossible de le mettre en fourrière.' end
        if v.state == 'impound' then return false, 'Ce véhicule est déjà en fourrière.' end
        local ok, err = G.Garage.Impound(plate, d.reason)
        if not ok then return false, err end
        Biz.Record(c, v.license, '', 'seize', ('Fourrière %s : %s'):format(plate, d.reason), 0)
        for id, pl in pairs(G.Players()) do if pl.license == v.license then G.Notify(id, { type = 'warn', title = c.biz.label, text = ('Ton véhicule %s a été emmené à la fourrière : %s.'):format(plate, d.reason) }) end end
        PB.Audit.Log('serveur', 'job.impound', src, plate, nil, nil, { reason = d.reason, biz = c.biz.id })
    end
    if a.fx then fxTo(src, a.fx, { netId = d.netId }) end
    if a.id == 'job_unlock' then
        local v = d.plate ~= '' and G.Garage and G.Garage.Vehicle((G.Garage.Real and G.Garage.Real(d.plate)) or d.plate)
        Biz.Record(c, v and v.license or '', d.plate, 'repair', ('Véhicule %s ouvert (clés perdues)'):format(d.plate), 0)
        -- le propriétaire est toujours prévenu : ouvrir la voiture de quelqu'un d'autre ne passe pas inaperçu
        if v then for id, pl in pairs(G.Players()) do if pl.license == v.license and id ~= src then G.Notify(id, { type = 'warn', title = c.biz.label, text = ('Ton véhicule %s vient d\'être ouvert par %s.'):format(d.plate, display(src)) }) end end end
        PB.Audit.Log('serveur', 'job.unlock', src, d.plate, nil, nil, { biz = c.biz.id })
    end
    local price = a.price and tbl('prices', a.price, 0) or 0
    if price > 0 and G.Mech and G.Mech.AddItem and Biz.Allowed(c, 'repair') then
        local total = G.Mech.AddItem(src, a.label .. (d.plate ~= '' and (' (' .. d.plate .. ')') or ''), price, { plate = d.plate, netId = d.netId })
        return true, ('%s : %s ajouté à la facture (total %s). « Envoyer la facture » au client.'):format(a.label, money(price), money(total))
    end
    if a.quiet then return true, nil end   -- le résultat s'affiche déjà chez le joueur (diagnostic, plateau, feux)
    return true, a.label .. ' : fait.'
end

-- début : sans durée, on finit tout de suite ; sinon animation côté client et rendez-vous à « pb:g:job:done »
local function begin(src, c, a, d)
    local secs = a.secs and tbl('secs', a.secs, 6) or 0
    if secs <= 0 then return finish(src, c, a, d) end
    d.at, d.secs, d.biz = now(), secs, c.biz.id
    JP.jobs[src] = { a = a, d = d }
    TriggerClientEvent('pb:g:job:work', src, PB.Json({ id = a.id, label = a.label, secs = secs, anim = a.anim, netId = d.netId }))
    return true, nil
end

local function vehicleOf(src, netId)
    local ent, plate = G.VehNear(src, netId, tonumber(cfg('veh_dist', 7)) or 7)
    if not ent then
        if G.ServerSees() then return nil, plate end
        return { netId = math.floor(tonumber(netId) or 0), plate = '' }   -- sans OneSync : le serveur ne voit pas les véhicules
    end
    return { netId = math.floor(tonumber(netId) or 0), plate = plate }
end

local function handler(a)
    return function(src, c, p)
        if not c or not c.duty or not is(c, a.who) then return false, 'Action réservée à ce métier, en service.' end
        if a.veh then
            if not p.netId then TriggerClientEvent('pb:g:job:veh', src, a.id, PB.Json(p)) return true, nil end   -- le client désigne le véhicule
            local d, err = vehicleOf(src, p.netId)
            if not d then return false, err end
            if a.id == 'job_plate' then
                if d.plate == '' then return false, 'Plaque illisible (approche-toi).' end
                local plate = G.Garage and G.Garage.Real and G.Garage.Real(d.plate) or d.plate
                local v = G.Garage and G.Garage.Vehicle(plate)
                if not v then return true, ('Plaque %s : véhicule NON ENREGISTRÉ (volé, loué ou sans papiers).'):format(d.plate) end
                local o = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { v.license })
                local who = (v.biz or '') ~= '' and ('entreprise ' .. v.biz) or (v.gang or '') ~= '' and 'une organisation' or (o and ((o.firstname or '') .. ' ' .. (o.lastname or ''))) or 'inconnu'
                Biz.Record(c, v.license, who, 'note', ('Contrôle de la plaque %s'):format(plate), 0)
                return true, ('Plaque %s · %s · propriétaire : %s%s'):format(plate, v.label ~= '' and v.label or v.model, who, v.state == 'impound' and ' · EN FOURRIÈRE' or '')
            end
            if a.id == 'job_impound' then
                d.reason = clean(p.reason, 70)
                if #d.reason < 3 then return false, 'Indique le motif.' end
            end
            return begin(src, c, a, d)
        end
        if a.target then
            local tp, err, tid = Biz.Target(src, p.id)
            if not tp then return false, err end
            local name = display(tid)
            if a.id == 'job_pdiag' then
                local ped = GetPlayerPed(tid)
                local hp = ped and ped ~= 0 and GetEntityHealth(ped) or 0
                local pct = math.max(0, math.min(100, math.floor((hp - 100) + 0.5)))
                local dead = PB.ToBool(tp.row.dead)
                if not G.ServerSees() then return true, dead and (name .. ' : INCONSCIENT — à réanimer.') or (name .. ' : conscient.') end
                Biz.Record(c, tp.license, name, 'care', dead and 'Bilan : inconscient' or ('Bilan : santé %d %%'):format(pct), 0)
                return true, dead and (name .. ' : INCONSCIENT — à réanimer.') or (('%s : conscient · santé %d %%%s'):format(name, pct, pct < 50 and ' — à soigner' or ''))
            end
            if a.id == 'job_idcheck' then
                local i = G.Identity(tid) or {}
                local recs = DB.one("SELECT COUNT(*) AS n FROM pb_biz_records WHERE license = ? AND kind IN ('fine','jail','seize','cuff')", { tp.license })
                local permit = G.Weapons and G.Weapons.HasPermit and G.Weapons.HasPermit(tid)
                Biz.Record(c, tp.license, name, 'note', "Contrôle d'identité", 0)
                return true, ('%s · né(e) le %s · %s · %s · permis d\'arme : %s · antécédents : %d'):format(name, tostring(i.dob or '?'), i.sex == 'f' and 'femme' or 'homme',
                    tostring(i.nationality or '?'), permit and 'oui' or 'non', tonumber(recs and recs.n) or 0)
            end
            if a.who == 'security' then return JP.Security(src, c, a, p, tp, tid, name) end
            if a.id == 'job_permit' then
                local permit = G.Weapons and G.Weapons.HasPermit and G.Weapons.HasPermit(tid)
                return permit and true or false, permit and (name .. " a un permis de port d'arme : vente autorisée.") or (name .. " n'a PAS de permis de port d'arme.")
            end
        end
        if a.id == 'job_backup' or a.id == 'job_guests' then return JP.Security(src, c, a, p) end
        if a.id == 'job_flash' then
            local text = clean(p.text, tonumber(cfg('flash_maxlen', 200)) or 200)
            if #text < 5 then return false, 'Écris ton flash info.' end
            local k = 'flash:' .. c.biz.id
            local left = (JP.last[k] or 0) + (tonumber(cfg('flash_cooldown', 120)) or 120) - now()
            if left > 0 then return false, ('Un flash vient de passer : encore %d s.'):format(left) end
            JP.last[k] = now()
            for s in pairs(G.Players()) do G.Notify(s, { type = 'info', kind = 'announce', title = 'FLASH INFO · ' .. c.biz.label, text = text, duration = 15000 }) end
            PB.Audit.Log('serveur', 'job.flash', src, c.biz.id, nil, nil, { text = text })
            return true, 'Flash info diffusé.'
        end
        return begin(src, c, a, {})
    end
end
-- Sécurité d'un club --------------------------------------------------------------------------------------------------------------------------
JP.bands = {}   -- biz -> licence -> { kind, untilT, name }
local BAND_SECS = 6 * 3600
local function ageOf(dob)
    local y, m, d = tostring(dob or ''):match('^(%d%d%d%d)-(%d%d)-(%d%d)$')
    if not y then return nil end
    local t = os.date('*t')
    local a = t.year - tonumber(y)
    if t.month < tonumber(m) or (t.month == tonumber(m) and t.day < tonumber(d)) then a = a - 1 end
    return a
end
local function banOf(bizId, lic) return DB.one("SELECT text, by_name, at FROM pb_biz_records WHERE biz_id = ? AND license = ? AND kind = 'ban' ORDER BY id DESC LIMIT 1", { bizId, lic }) end
local function bandOf(bizId, lic)
    local b = JP.bands[bizId] and JP.bands[bizId][lic]
    if b and b.untilT > now() then return b end
    if b then JP.bands[bizId][lic] = nil end
end
function JP.Security(src, c, a, p, tp, tid, name)
    local id = a.id
    if id == 'job_frisk' then
        local o = G.Inv and G.Inv.PlayerOwner(tid)
        local found = {}
        for _, s in pairs(o and G.Inv.Contents(o) or {}) do
            local d = G.Inv.Def(s.item)
            if (d and d.kind == 'weapon') or tostring(s.item):sub(1, 7) == 'weapon_' then found[#found + 1] = (d and d.label or s.item) .. (s.qty > 1 and (' x' .. s.qty) or '') end
        end
        G.Notify(tid, { type = 'info', title = c.biz.label, text = display(src) .. ' procède à une palpation de sécurité.' })
        Biz.Record(c, tp.license, name, 'note', #found > 0 and ('Palpation : armé (%s)'):format(table.concat(found, ', ')) or 'Palpation : rien à signaler', 0)
        if #found > 0 then return true, ('%s est ARMÉ : %s. Entrée refusée tant que l\'arme n\'est pas laissée dehors.'):format(name, table.concat(found, ', ')) end
        return true, name .. ' : rien à signaler, aucune arme.'
    elseif id == 'job_door' then
        local i = G.Identity(tid) or {}
        local age = ageOf(i.dob)
        local ban, band = banOf(c.biz.id, tp.license), bandOf(c.biz.id, tp.license)
        return true, ('%s · %s · %s%s'):format(name, age and (age .. ' ans' .. (age < 18 and ' — MINEUR, entrée interdite' or ' — majeur')) or 'âge inconnu',
            band and ('bracelet ' .. band.kind:upper()) or 'sans bracelet', ban and (' · INTERDIT : ' .. tostring(ban.text):gsub('^Interdit d\'entrée : ', '')) or '')
    elseif id == 'job_band' then
        if banOf(c.biz.id, tp.license) then return false, name .. " est interdit d'entrée : lève d'abord l'interdiction." end
        local kind = clean(p.kind, 16):lower()
        if kind == '' then kind = 'entrée' end
        JP.bands[c.biz.id] = JP.bands[c.biz.id] or {}
        JP.bands[c.biz.id][tp.license] = { kind = kind, untilT = now() + BAND_SECS, name = name }
        G.Notify(tid, { type = 'success', title = c.biz.label, text = ('Bracelet %s posé : bonne soirée !'):format(kind:upper()) })
        return true, ('Bracelet %s posé à %s (6 h).'):format(kind:upper(), name)
    elseif id == 'job_ban' then
        local reason = clean(p.reason, 80)
        if #reason < 3 then return false, 'Indique le motif.' end
        if banOf(c.biz.id, tp.license) then return false, name .. ' est déjà interdit.' end
        Biz.Record(c, tp.license, name, 'ban', "Interdit d'entrée : " .. reason, 0)
        if JP.bands[c.biz.id] then JP.bands[c.biz.id][tp.license] = nil end
        G.Notify(tid, { type = 'warn', title = c.biz.label, text = ("Tu es interdit d'entrée : %s."):format(reason) })
        PB.Audit.Log('serveur', 'job.club_ban', src, name, nil, nil, { biz = c.biz.id, reason = reason })
        return true, name .. " est interdit d'entrée."
    elseif id == 'job_unban' then
        local n = tonumber(DB.exec("DELETE FROM pb_biz_records WHERE biz_id = ? AND license = ? AND kind = 'ban'", { c.biz.id, tp.license })) or 0
        if n == 0 then return false, name .. " n'est pas interdit." end
        G.Notify(tid, { type = 'info', title = c.biz.label, text = 'Ton interdiction d\'entrée est levée.' })
        return true, name .. ' peut de nouveau entrer.'
    elseif id == 'job_expel' then
        if JP.bands[c.biz.id] then JP.bands[c.biz.id][tp.license] = nil end
        local door = G.Points and G.Points.Of and G.Points.Of('biz', c.biz.id) or {}
        local exit
        for _, r in ipairs(door) do if r.kind == 'hq' or r.kind == 'duty' then exit = r break end end
        G.Notify(tid, { type = 'warn', kind = 'announce', title = c.biz.label .. ' · SÉCURITÉ', text = display(src) .. ' te demande de quitter le club immédiatement.', duration = 10000 })
        if exit then TriggerClientEvent('pb:g:orga:gps', tid, PB.Json({ x = exit.x, y = exit.y, label = 'Sortie' })) end
        Biz.Record(c, tp.license, name, 'note', 'Expulsé du club', 0)
        return true, name .. ' a reçu l\'ordre de sortir.'
    elseif id == 'job_backup' then
        local ped = GetPlayerPed(src)
        local pos = ped and ped ~= 0 and GetEntityCoords(ped)
        local n = 0
        for sid in pairs(G.Players()) do
            local cc = sid ~= src and Biz.Ctx(sid)
            if cc and cc.biz.id == c.biz.id and cc.duty then
                n = n + 1
                G.Notify(sid, { type = 'warn', kind = 'announce', title = c.biz.label .. ' · RENFORT', text = display(src) .. ' demande du renfort.', duration = 12000 })
                if pos then TriggerClientEvent('pb:g:orga:gps', sid, PB.Json({ x = pos.x, y = pos.y, label = 'Renfort sécurité' })) end
            end
        end
        return true, n > 0 and (('Renfort demandé : %d collègue%s prévenu%s.'):format(n, n > 1 and 's' or '', n > 1 and 's' or '')) or 'Aucun collègue en service.'
    elseif id == 'job_guests' then
        local bands, out = JP.bands[c.biz.id] or {}, {}
        for lic, b in pairs(bands) do if b.untilT > now() then out[#out + 1] = b.name .. ' (' .. b.kind .. ')' else bands[lic] = nil end end
        local bans = DB.q("SELECT name FROM pb_biz_records WHERE biz_id = ? AND kind = 'ban' ORDER BY id DESC LIMIT 15", { c.biz.id }) or {}
        local bn = {}
        for _, r in ipairs(bans) do bn[#bn + 1] = r.name end
        return true, ('Bracelets (%d) : %s · Interdits (%d) : %s'):format(#out, #out > 0 and table.concat(out, ', ') or 'aucun', #bn, #bn > 0 and table.concat(bn, ', ') or 'aucun')
    end
    return false, 'Action inconnue.'
end

for _, a in ipairs(A) do Q.Handlers[a.id] = handler(a) end

Q.Handlers.job_missions = function(src, c, p)
    if not c or not c.duty or not is(c, 'missions') then return false, 'Réservé à ce métier, en service.' end
    local j = DB.one("SELECT label, x, y FROM pb_civil_jobs WHERE id = ? AND enabled = 1 AND (biz = ? OR biz = '')", { tostring(p.mission or ''), c.biz.id })
    if not j then return false, 'Mission inconnue.' end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = j.x, y = j.y, label = j.label }))
    return true, ('« %s » : départ sur ton GPS.'):format(j.label)
end

-- le client désigne le véhicule : on repasse par le menu F6 (mêmes vérifications)
RegisterNetEvent('pb:g:job:vehicle', function(id, netId, extra)
    local src = source
    local a = BY[tostring(id)]
    if not a or not a.veh then return end
    local p = type(extra) == 'table' and extra or {}
    p.netId = math.floor(tonumber(netId) or 0)
    local ok, msg = Q.Do(src, a.id, p)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = a.label, text = tostring(msg), duration = 9000 }) end
end)
RegisterNetEvent('pb:g:job:done', function()
    local src = source
    local j = JP.jobs[src]
    JP.jobs[src] = nil
    if not j then return end
    local a, d = j.a, j.d
    local c = Biz.Ctx(src)
    if not c or c.biz.id ~= d.biz or not c.duty or not is(c, a.who) then return end
    if now() - d.at < d.secs - 1 then G.Notify(src, { type = 'error', title = a.label, text = 'Travail bâclé : recommence.' }) return end
    if d.netId and d.netId ~= 0 and G.ServerSees() then
        local ent = G.VehNear(src, d.netId, (tonumber(cfg('veh_dist', 7)) or 7) + 2)
        if not ent then G.Notify(src, { type = 'error', title = a.label, text = "Tu t'es éloigné du véhicule." }) return end
    end
    local ok, msg = finish(src, c, a, d)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = a.label, text = tostring(msg), duration = 9000 }) end
end)
AddEventHandler('playerDropped', function() JP.jobs[source] = nil end)

G.JobPacksForm = PB.Form.Cfg({ ns = 'jobpacks', id = 'settings', title = 'Menu F6 : gestes de chaque métier', perm = 'quick.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Gestes de métier dans le menu F6', default = true, hint = 'Mécano, dépanneur, secours, pompiers, police, armurerie, médias, station-service, lavage, transport, sécurité des clubs (Galaxy).' },
    { k = 'veh_dist', type = 'number', label = 'Distance maximale du véhicule (m)', default = 7, min = 3, max = 15 },
    { k = 'flash_cooldown', type = 'number', label = 'Délai entre deux flash info d\'un média (s)', default = 120, min = 30, max = 3600 },
} })

PB.SelfTest.Add('gestes de métier F6', function(R)
    R.check(Q and Q.Common ~= nil, 'menu F6', 'quick.lua doit être chargé avant')
    R.check(G.Mech and G.Mech.AddItem ~= nil, 'facture du garage', 'mechshop.lua doit exposer AddItem')
end)
