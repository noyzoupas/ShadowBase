-- Inventaire intégré : objets, poids, emplacements, coffres, objets au sol, utilisation, don. Autonome (tables pb_inv*).
-- Le serveur fait foi : propriétaire du conteneur, distance, poids, quantités. Le client ne fait qu'afficher et demander.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('inv.edit', 'Créer et modifier objets, coffres et réglages de l\'inventaire', 'inv', true)
P.Register('inv.give', "Donner ou retirer des objets à un joueur depuis le panel", 'inv', true)

local INV_SQL = {
    [[CREATE TABLE IF NOT EXISTS pb_inv_items (
        name VARCHAR(40) NOT NULL, label VARCHAR(48) NOT NULL, weight INT NOT NULL DEFAULT 100, stack INT NOT NULL DEFAULT 20, kind VARCHAR(12) NOT NULL DEFAULT 'misc',
        hunger INT NOT NULL DEFAULT 0, thirst INT NOT NULL DEFAULT 0, stress INT NOT NULL DEFAULT 0, health INT NOT NULL DEFAULT 0, usable TINYINT(1) NOT NULL DEFAULT 0,
        description VARCHAR(160) NOT NULL DEFAULT '', PRIMARY KEY (name))]],
    [[CREATE TABLE IF NOT EXISTS pb_inv (owner VARCHAR(80) NOT NULL, slot INT NOT NULL, item VARCHAR(40) NOT NULL, qty INT NOT NULL, PRIMARY KEY (owner, slot))]],
    [[CREATE TABLE IF NOT EXISTS pb_inv_stashes (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, slots INT NOT NULL DEFAULT 40, weight INT NOT NULL DEFAULT 200000, x DOUBLE NOT NULL DEFAULT 0, y DOUBLE NOT NULL DEFAULT 0, z DOUBLE NOT NULL DEFAULT 0,
        biz VARCHAR(32) NOT NULL DEFAULT '', min_grade INT NOT NULL DEFAULT 0, enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
}
PB.Cfg.Define('inv', { slots = 50, max_weight = 30000, hotbar = 5, key = 'I', no_weapon_wheel = true, tab_opens = true, drop_ttl = 20, drop_dist = 2.5, give_dist = 3.5, near_show = 10, stash_dist = 2.5, max_drops = 120, allow_drop = true, allow_give = true, ped_view = true, ped_dist = 6.5, ped_sway = true, ped_platform = true, style = 'e4', ped_mode = 'menu', ped_dist_e4 = 5, ped_dim = 12, blur = false, color_mode = 'server', color = '#00f895', promo = 'Pour débloquer plus de slot dans votre inventaire,\nachetez le *Premium*. Il est vendu dans la boutique\nserveur *24h/24 et 7j/7.*' })

local Inv = {}
G.Inv = Inv
local function cfg(k, d) return PB.Cfg.Get('inv', k, d) end

local DEFAULT_ITEMS = {
    { 'water', "Bouteille d'eau", 500, 10, 'drink', 0, 35, 0, 0, 1, "Étanche la soif." }, { 'soda', 'Soda', 350, 10, 'drink', 0, 25, -3, 0, 1, '' }, { 'coffee', 'Café', 250, 10, 'drink', 0, 15, -5, 0, 1, '' },
    { 'sandwich', 'Sandwich', 250, 10, 'food', 35, 0, 0, 0, 1, '' }, { 'burger', 'Burger', 350, 10, 'food', 50, -5, -4, 0, 1, '' }, { 'chips', 'Paquet de chips', 120, 10, 'food', 18, -4, -2, 0, 1, '' },
    { 'bandage', 'Bandage', 150, 10, 'medical', 0, 0, 0, 25, 1, 'Soigne légèrement.' }, { 'medkit', 'Trousse de soins', 900, 3, 'medical', 0, 0, -10, 60, 1, 'Soigne nettement.' },
    { 'phone', 'Téléphone', 200, 1, 'tool', 0, 0, 0, 0, 0, '' }, { 'id_card', "Carte d'identité", 20, 1, 'doc', 0, 0, 0, 0, 0, '' }, { 'lockpick', 'Crochet', 100, 5, 'tool', 0, 0, 0, 0, 0, '' },
    { 'repair_kit', 'Kit de réparation', 2500, 3, 'tool', 0, 0, 0, 0, 0, '' }, { 'rope', 'Corde', 400, 5, 'misc', 0, 0, 0, 0, 0, '' }, { 'cash_bag', "Sac d'argent", 1500, 1, 'misc', 0, 0, 0, 0, 0, '' },
}
PB.Migrate('046_game_inventory', 'Inventaire : objets, contenus, coffres', function()
    for _, sql in ipairs(INV_SQL) do DB.exec(PB.Table(sql)) end
    for _, d in ipairs(DEFAULT_ITEMS) do
        DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', d)
    end
end)

PB.Migrate('195_inv_armor', 'Inventaire : gilet pare-balles', function()
    DB.exec("INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description) VALUES ('armor', 'Gilet pare-balles', 3000, 5, 'tool', 0, 0, 0, 0, 1, 'Ajoute 50 points de protection.')")
end)

-- 15 armes + 10 munitions d'un pack addon ne tiennent pas dans 30 emplacements : on élargit une fois.
PB.Migrate('197_inv_slots', 'Inventaire : 50 emplacements du sac', function()
    if tonumber(PB.Cfg.Get('inv', 'slots', 50)) == 30 then
        PB.Cfg.Set('inv', 'slots', 50, nil, 'Emplacements élargis pour les armes addon')
    end
end)

PB.Migrate('171_inv_cloth', 'Inventaire : vêtements portés', {
    "ALTER TABLE pb_inv_items ADD COLUMN cloth VARCHAR(40) NOT NULL DEFAULT ''",
    [[CREATE TABLE IF NOT EXISTS pb_inv_worn (license VARCHAR(64) NOT NULL, slot VARCHAR(12) NOT NULL, item VARCHAR(40) NOT NULL, PRIMARY KEY (license, slot))]],
})
PB.Migrate('173_inv_image', "Inventaire : image par objet", { "ALTER TABLE pb_inv_items ADD COLUMN image VARCHAR(200) NOT NULL DEFAULT ''" })
-- Image d'un objet : celle choisie dans le panel (img/items/… ou https://…), sinon l'illustration fournie selon le nom ou le type.
local KIND_IMG = { food = '_food', drink = '_drink', medical = '_medic', tool = '_tool', doc = '_doc', clothes = '_clothes', misc = '_item' }
function Inv.ValidImage(v)
    v = tostring(v or '')
    if v == '' then return true end
    if #v > 200 or v:find('[%s"\'<>\\]') then return false end
    return v:match('^img/[%w]+/[%w_%-]+%.%a%a%a%a?$') ~= nil or v:match('^https://[%w%.%-]+/[%w%._%-%%/]+$') ~= nil
end
-- Images d'ox_inventory (web/img/ox, GPL-3.0, voir CREDITS.txt) : trouvées par le nom de l'objet, de l'arme ou de la munition.
local OX = { ['WEAPON_ACIDPACKAGE'] = true, ['WEAPON_ADVANCEDRIFLE'] = true, ['WEAPON_APPISTOL'] = true, ['WEAPON_ASSAULTRIFLE'] = true, ['WEAPON_ASSAULTRIFLE_MK2'] = true, ['WEAPON_ASSAULTSHOTGUN'] = true, ['WEAPON_ASSAULTSMG'] = true, ['WEAPON_AUTOSHOTGUN'] = true, ['WEAPON_BALL'] = true, ['WEAPON_BAT'] = true, ['WEAPON_BATTLEAXE'] = true, ['WEAPON_BOTTLE'] = true, ['WEAPON_BREAD'] = true, ['WEAPON_BRIEFCASE'] = true, ['WEAPON_BRIEFCASE_02'] = true, ['WEAPON_BULLPUPRIFLE'] = true, ['WEAPON_BULLPUPRIFLE_MK2'] = true, ['WEAPON_BULLPUPSHOTGUN'] = true, ['WEAPON_BZGAS'] = true, ['WEAPON_CANDYCANE'] = true, ['WEAPON_CARBINERIFLE'] = true, ['WEAPON_CARBINERIFLE_MK2'] = true, ['WEAPON_CERAMICPISTOL'] = true, ['WEAPON_COMBATMG'] = true, ['WEAPON_COMBATMG_MK2'] = true, ['WEAPON_COMBATPDW'] = true, ['WEAPON_COMBATPISTOL'] = true, ['WEAPON_COMBATSHOTGUN'] = true, ['WEAPON_COMPACTLAUNCHER'] = true, ['WEAPON_COMPACTRIFLE'] = true, ['WEAPON_CROWBAR'] = true, ['WEAPON_DAGGER'] = true, ['WEAPON_DBSHOTGUN'] = true, ['WEAPON_DIGISCANNER'] = true, ['WEAPON_DOUBLEACTION'] = true, ['WEAPON_EMPLAUNCHER'] = true, ['WEAPON_FERTILIZERCAN'] = true, ['WEAPON_FIREEXTINGUISHER'] = true, ['WEAPON_FIREWORK'] = true, ['WEAPON_FLARE'] = true, ['WEAPON_FLAREGUN'] = true, ['WEAPON_FLASHLIGHT'] = true, ['WEAPON_GADGETPISTOL'] = true, ['WEAPON_GARBAGEBAG'] = true, ['WEAPON_GAS'] = true, ['WEAPON_GOLFCLUB'] = true, ['WEAPON_GRENADE'] = true, ['WEAPON_GRENADELAUNCHER'] = true, ['WEAPON_GRENADELAUNCHER_SMOKE'] = true, ['WEAPON_GUSENBERG'] = true, ['WEAPON_HAMMER'] = true, ['WEAPON_HANDCUFFS'] = true, ['WEAPON_HATCHET'] = true, ['WEAPON_HAZARDCAN'] = true, ['WEAPON_HEAVYPISTOL'] = true, ['WEAPON_HEAVYRIFLE'] = true, ['WEAPON_HEAVYSHOTGUN'] = true, ['WEAPON_HEAVYSNIPER'] = true, ['WEAPON_HEAVYSNIPER_MK2'] = true, ['WEAPON_HOMINGLAUNCHER'] = true, ['WEAPON_KNIFE'] = true, ['WEAPON_KNUCKLE'] = true, ['WEAPON_MACHETE'] = true, ['WEAPON_MACHINEPISTOL'] = true, ['WEAPON_MARKSMANPISTOL'] = true, ['WEAPON_MARKSMANRIFLE'] = true, ['WEAPON_MARKSMANRIFLE_MK2'] = true, ['WEAPON_METALDETECTOR'] = true, ['WEAPON_MG'] = true, ['WEAPON_MICROSMG'] = true, ['WEAPON_MILITARYRIFLE'] = true, ['WEAPON_MINIGUN'] = true, ['WEAPON_MINISMG'] = true, ['WEAPON_MOLOTOV'] = true, ['WEAPON_MUSKET'] = true, ['WEAPON_NAVYREVOLVER'] = true, ['WEAPON_NIGHTSTICK'] = true, ['WEAPON_PETROLCAN'] = true, ['WEAPON_PIPEBOMB'] = true, ['WEAPON_PISTOL'] = true, ['WEAPON_PISTOL50'] = true, ['WEAPON_PISTOLXM3'] = true, ['WEAPON_PISTOL_MK2'] = true, ['WEAPON_POOLCUE'] = true, ['WEAPON_PRECISIONRIFLE'] = true, ['WEAPON_PROXMINE'] = true, ['WEAPON_PUMPSHOTGUN'] = true, ['WEAPON_PUMPSHOTGUN_MK2'] = true, ['WEAPON_RAILGUN'] = true, ['WEAPON_RAILGUNXM3'] = true, ['WEAPON_RAYCARBINE'] = true, ['WEAPON_RAYMINIGUN'] = true, ['WEAPON_RAYPISTOL'] = true, ['WEAPON_REVOLVER'] = true, ['WEAPON_REVOLVER_MK2'] = true, ['WEAPON_RPG'] = true, ['WEAPON_SAWNOFFSHOTGUN'] = true, ['WEAPON_SMG'] = true, ['WEAPON_SMG_MK2'] = true, ['WEAPON_SMOKEGRENADE'] = true, ['WEAPON_SNIPERRIFLE'] = true, ['WEAPON_SNOWBALL'] = true, ['WEAPON_SNSPISTOL'] = true, ['WEAPON_SNSPISTOL_MK2'] = true, ['WEAPON_SPECIALCARBINE'] = true, ['WEAPON_SPECIALCARBINE_MK2'] = true, ['WEAPON_STICKYBOMB'] = true, ['WEAPON_STONE_HATCHET'] = true, ['WEAPON_STUNGUN'] = true, ['WEAPON_SWITCHBLADE'] = true, ['WEAPON_TECPISTOL'] = true, ['WEAPON_VINTAGEPISTOL'] = true, ['WEAPON_WRENCH'] = true, ['advancedkit'] = true, ['ammo-22'] = true, ['ammo-38'] = true, ['ammo-44'] = true, ['ammo-45'] = true, ['ammo-50'] = true, ['ammo-9'] = true, ['ammo-beanbag'] = true, ['ammo-emp'] = true, ['ammo-firework'] = true, ['ammo-flare'] = true, ['ammo-grenade'] = true, ['ammo-heavysniper'] = true, ['ammo-laser'] = true, ['ammo-musket'] = true, ['ammo-railgun'] = true, ['ammo-rifle'] = true, ['ammo-rifle2'] = true, ['ammo-rocket'] = true, ['ammo-shotgun'] = true, ['ammo-sniper'] = true, ['armour'] = true, ['at_barrel'] = true, ['at_clip_drum'] = true, ['at_clip_extended'] = true, ['at_clip_extended2'] = true, ['at_flashlight'] = true, ['at_grip'] = true, ['at_muzzle_bell'] = true, ['at_muzzle_fat'] = true, ['at_muzzle_flat'] = true, ['at_muzzle_heavy'] = true, ['at_muzzle_slanted'] = true, ['at_muzzle_split'] = true, ['at_muzzle_squared'] = true, ['at_muzzle_tactical'] = true, ['at_scope_advanced'] = true, ['at_scope_holo'] = true, ['at_scope_large'] = true, ['at_scope_medium'] = true, ['at_scope_nv'] = true, ['at_scope_small'] = true, ['at_scope_thermal'] = true, ['at_suppressor'] = true, ['bandage'] = true, ['black_money'] = true, ['burger'] = true, ['burger_chicken'] = true, ['card_bank'] = true, ['card_id'] = true, ['carkey'] = true, ['cigarette'] = true, ['cigarettes_redwood'] = true, ['cocaine'] = true, ['donut'] = true, ['fries'] = true, ['garbage'] = true, ['key'] = true, ['lockpick'] = true, ['medikit'] = true, ['meth'] = true, ['money'] = true, ['mustard'] = true, ['oldkey'] = true, ['panties'] = true, ['paperbag'] = true, ['parachute'] = true, ['phone'] = true, ['pizza_ham'] = true, ['pizza_ham_box'] = true, ['pizza_ham_slice'] = true, ['radio'] = true, ['scrapmetal'] = true, ['sprunk'] = true, ['trash'] = true, ['trash_bread'] = true, ['trash_burger'] = true, ['trash_can'] = true, ['trash_chips'] = true, ['usb_black'] = true, ['water'] = true, ['weed'] = true, ['ziptie'] = true }
local OX_ALIAS = { soda = 'sprunk', medkit = 'medikit', id_card = 'card_id', repair_kit = 'advancedkit', rope = 'ziptie', cash_bag = 'paperbag', cash = 'money', dirty_money = 'black_money',
    chips = 'fries', sandwich = 'burger_chicken', bank_card = 'card_bank', car_key = 'carkey', cigar = 'cigarette', pizza = 'pizza_ham', zip_tie = 'ziptie', armor = 'armour', vest = 'armour', walkie = 'radio', joint = 'weed', weed_bag = 'weed', coke = 'cocaine', meth_bag = 'meth', bread = 'trash_bread', donuts = 'donut', fries_box = 'fries', mustard_bottle = 'mustard', usb = 'usb_black', scrap = 'scrapmetal', parachute_bag = 'parachute', cuffs = 'WEAPON_HANDCUFFS', handcuffs = 'WEAPON_HANDCUFFS', tazer = 'WEAPON_STUNGUN', baton = 'WEAPON_NIGHTSTICK', flashlight = 'WEAPON_FLASHLIGHT', extinguisher = 'WEAPON_FIREEXTINGUISHER' }
local OX_SVG = { coffee = true, chips = true, sandwich = true }
function G.OxImage(name)
    name = tostring(name or ''):lower()
    if name == '' then return nil end
    local w = name:match('^weapon_([%w_]+)$')
    if w and OX['WEAPON_' .. w:upper()] then return 'img/ox/WEAPON_' .. w:upper() .. '.png' end
    local a = name:match('^ammo[_%-]([%w_]+)$')
    if a then
        local pick = ({ pistol = '9', smg = '9', rifle = 'rifle', shotgun = 'shotgun', sniper = 'sniper', rocket = 'rocket', flare = 'flare', musket = 'musket', mg = 'rifle2' })[a] or a
        if OX['ammo-' .. pick] then return 'img/ox/ammo-' .. pick .. '.png' end
        return 'img/ox/ammo-9.png'
    end
    local n = OX_ALIAS[name] or name
    if OX[n] then return 'img/ox/' .. n .. '.png' end
    if OX_SVG[name] then return 'img/items/' .. name .. '.svg' end
    return nil
end
local clothPack = {}
local parseCloth   -- définie plus bas (emplacements d'habillage)
-- photo d'un vêtement : paquet web/img/clothes/{sexe}_{c|p}{id}.json (homme par défaut, sinon femme) ; nil si le modèle n'y est pas
local function packHas(key, d)
    if clothPack[key] == nil then
        clothPack[key] = false
        local raw = LoadResourceFile and LoadResourceFile(GetCurrentResourceName(), 'web/img/clothes/' .. key .. '.json')
        if raw and raw ~= '' then
            local set = {}
            for k in raw:gmatch('"(%d+)":"data:') do set[tonumber(k)] = true end   -- seulement les numéros, pas les images
            clothPack[key] = set
        end
    end
    return clothPack[key] and clothPack[key][d] or false
end
function Inv.ClothImage(kind, idx, drawable)
    for _, sex in ipairs({ 'male', 'female' }) do
        local key = sex .. '_' .. kind .. idx
        if packHas(key, tonumber(drawable)) then return ('img/clothes/%s_%d.webp'):format(key, drawable) end
    end
    return nil
end
function Inv.Image(d)
    if not d then return 'img/items/_item.svg' end
    if d.image and d.image ~= '' and Inv.ValidImage(d.image) then return d.image end
    local ox = G.OxImage(d.name)
    if ox then return ox end
    -- vêtement (masque, sac, chapeau…) : sa photo dans web/img/clothes si elle existe
    local cl = d.cloth and d.cloth ~= '' and parseCloth(d.cloth)
    if cl then local ci = Inv.ClothImage(cl.kind, cl.idx, cl.drawable) if ci then return ci end end
    local n = tostring(d.name or ''):lower()
    -- images dessinées pour Shadow Base (server/game/itemimages.lua, web/img/items) : poissons, meubles, butin, pièces d'armes…
    if G.ItemSvg and G.ItemSvg[n] then return 'img/items/' .. n .. '.svg' end
    -- Burger Shot (bs_*) : boisson ou plat
    if n:find('^bs_') then
        if d.kind == 'drink' then return 'img/items/soda_bs.svg' end
        if n:find('frite') or n:find('fries') then return 'img/ox/fries.png' end
        return 'img/ox/burger.png'
    end
    local sh = G.ItemImage
    if sh then
        if n:find('^weapon_') then return sh('weapons', { name = n, type = 'weapon' }) end
        if n:find('^ammo') then return sh('weapons', { name = n, type = 'ammo' }) end
    end
    return 'img/items/' .. (KIND_IMG[d.kind] or '_item') .. '.svg'
end
-- Emplacements d'habillage : nom -> { type (c = composant, p = accessoire), indice du jeu, valeur « rien » }
local CLOTH_SLOTS = { hat = { 'p', 0, -1 }, glasses = { 'p', 1, -1 }, ears = { 'p', 2, -1 }, watch = { 'p', 6, -1 }, bracelet = { 'p', 7, -1 },
    mask = { 'c', 1, 0 }, top = { 'c', 11, 15 }, legs = { 'c', 4, 21 }, shoes = { 'c', 6, 34 }, bag = { 'c', 5, 0 }, vest = { 'c', 9, 0 }, chain = { 'c', 7, 0 }, shirt = { 'c', 8, 15 }, gloves = { 'c', 3, 15 } }
local CLOTH_OPTS = { { '', 'Pas un vêtement' }, { 'top', 'Haut / veste' }, { 'shirt', 'T-shirt (dessous)' }, { 'gloves', 'Gants' }, { 'legs', 'Pantalon' }, { 'shoes', 'Chaussures' }, { 'hat', 'Chapeau' }, { 'glasses', 'Lunettes' }, { 'mask', 'Masque' },
    { 'chain', 'Collier' }, { 'ears', 'Oreilles' }, { 'bag', 'Sac' }, { 'vest', 'Gilet' }, { 'bracelet', 'Bracelet' }, { 'watch', 'Montre' } }
function parseCloth(str)
    local slot, d, t = tostring(str or ''):match('^(%a+):(%d+):(%d+)$')
    if not slot or not CLOTH_SLOTS[slot] then return nil end
    return { slot = slot, kind = CLOTH_SLOTS[slot][1], idx = CLOTH_SLOTS[slot][2], none = CLOTH_SLOTS[slot][3], drawable = tonumber(d), texture = tonumber(t) }
end

-- Définitions ----------------------------------------------------------------------------------------------------------------------------
local defs, defsAt = {}, 0
local function loadDefs()
    defs = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_inv_items') or {}) do r.usable = PB.ToBool(r.usable) defs[r.name] = r end
    defsAt = os.time()
end
function Inv.Def(name) if not defs[name] then loadDefs() end return defs[name] end
function Inv.Reload() loadDefs() end
function Inv.Defs() if next(defs) == nil then loadDefs() end return defs end

-- Crée la définition d'un objet vendu par un magasin s'il n'existe pas encore
function Inv.Ensure(item)
    if not item or not tostring(item.name or ''):match('^[%w_]+$') then return false end
    if Inv.Def(item.name) then return true end
    DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, usable) VALUES (?, ?, 200, 10, ?, ?, ?, ?, ?)',
        { item.name, tostring(item.label or item.name):sub(1, 48), (item.hunger or 0) ~= 0 and 'food' or ((item.thirst or 0) ~= 0 and 'drink' or 'misc'), item.hunger or 0, item.thirst or 0, item.stress or 0,
          ((item.hunger or 0) ~= 0 or (item.thirst or 0) ~= 0 or (item.stress or 0) ~= 0) and 1 or 0 })
    loadDefs()
    return Inv.Def(item.name) ~= nil
end

-- Pour les ressources compagnons : crée un objet complet s'il n'existe pas (les réglages faits ensuite dans le panel sont conservés).
-- def = { name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description, image }
local function ensureItem(def)
    if type(def) ~= 'table' or not tostring(def.name or ''):match('^[%w_]+$') or #tostring(def.name) > 40 then return false end
    local img = tostring(def.image or '')
    if img ~= '' and not img:match('^img/[%a]+/[%w_%-]+%.%a%a%a%a?$') and not img:match('^https://[%w%.%-]+/[%w%./_%-]+$') then img = '' end
    local cur = Inv.Def(def.name)
    if cur then
        -- objet déjà créé (autre addon / ancienne installation) : on complète au moins l'image manquante
        if img ~= '' and tostring(cur.image or '') == '' then
            DB.exec('UPDATE pb_inv_items SET image = ? WHERE name = ?', { img, def.name })
            loadDefs()
        end
        return true
    end
    local num = function(v, lo, hi, d) v = math.floor(tonumber(v) or d) return math.max(lo, math.min(hi, v)) end
    local kind = tostring(def.kind or 'misc'):match('^%a+$') or 'misc'
    DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { def.name, tostring(def.label or def.name):sub(1, 48), num(def.weight, 0, 100000, 200), num(def.stack, 1, 1000, 10), kind:sub(1, 12),
          num(def.hunger, -100, 100, 0), num(def.thirst, -100, 100, 0), num(def.stress, -100, 100, 0), num(def.health, -200, 200, 0), def.usable == false and 0 or 1,
          tostring(def.description or ''):sub(1, 160), img })
    loadDefs()
    return Inv.Def(def.name) ~= nil
end
Inv.EnsureItem = ensureItem
exports('EnsureItem', ensureItem)

-- Conteneurs ----------------------------------------------------------------------------------------------------------------------------
local drops, dropSeq = {}, 0     -- 'd:N' -> { id, x, y, z, at }
local function playerOwner(src) local p = G.Get(src) return p and ('p:' .. p.license) or nil end
Inv.PlayerOwner = playerOwner

function Inv.Stash(id) return DB.one('SELECT * FROM pb_inv_stashes WHERE id = ?', { tostring(id) }) end

-- { slots, weight } de capacité selon le type de conteneur
function Inv.Capacity(owner)
    local kind, id = tostring(owner):match('^(%a+):(.+)$')
    if kind == 'p' then return cfg('slots', 50), cfg('max_weight', 30000) + (Inv.BagBonusFor and Inv.BagBonusFor(id) or 0) + (G.Vip and G.Vip.InvBonus and G.Vip.InvBonus(id) or 0) end
    if kind == 's' then local s = Inv.Stash(id) return s and s.slots or 0, s and s.weight or 0 end
    if kind == 'd' then return 20, 1000000 end
    if kind == 'v' then local c = Inv.TrunkCap and Inv.TrunkCap(id) if c then return c[1], c[2] end return 12, 60000 end
    if kind == 'h' then return 60, 300000 end
    if kind == 'o' then return cfg('org_slots', 60), cfg('org_weight', 400000) end
    return 0, 0
end

function Inv.Contents(owner)
    local out = {}
    for _, r in ipairs(DB.q('SELECT slot, item, qty FROM pb_inv WHERE owner = ? ORDER BY slot', { owner }) or {}) do out[r.slot] = { item = r.item, qty = r.qty } end
    return out
end

function Inv.Weight(owner)
    local w = 0
    for _, s in pairs(Inv.Contents(owner)) do local d = Inv.Def(s.item) w = w + (d and d.weight or 0) * s.qty end
    return w
end
function Inv.Count(owner, item) local n = 0 for _, s in pairs(Inv.Contents(owner)) do if s.item == item then n = n + s.qty end end return n end

-- Peut-on ajouter qty objets (poids et emplacements) ?
function Inv.CanCarry(owner, item, qty, contents)
    qty = math.floor(tonumber(qty) or 0)
    local d = Inv.Def(item)
    if not d or qty < 1 then return false, 'Objet inconnu.' end
    local slots, maxw = Inv.Capacity(owner)
    if slots <= 0 then return false, 'Conteneur introuvable.' end
    contents = contents or Inv.Contents(owner)
    local w = 0
    for _, s in pairs(contents) do local sd = Inv.Def(s.item) w = w + (sd and sd.weight or 0) * s.qty end
    if w + d.weight * qty > maxw then return false, 'Trop lourd.' end
    local room = 0
    local free = 0
    for i = 1, slots do
        local s = contents[i]
        if not s then free = free + 1 elseif s.item == item then room = room + math.max(0, d.stack - s.qty) end
    end
    if room + free * d.stack < qty then return false, "Plus de place." end
    return true
end

-- Retire qty d'un emplacement seulement s'il contient encore cet objet en quantité suffisante (deux joueurs sur le même coffre :
-- un seul retrait réussit, l'autre est refusé au lieu de dupliquer l'objet)
local function takeExact(owner, slot, item, qty)
    local n = tonumber(DB.exec('UPDATE pb_inv SET qty = qty - ? WHERE owner = ? AND slot = ? AND item = ? AND qty >= ?', { qty, owner, slot, item, qty })) or 0
    if n < 1 then return false end
    DB.exec('DELETE FROM pb_inv WHERE owner = ? AND slot = ? AND qty <= 0', { owner, slot })
    return true
end
Inv.TakeExact = takeExact

function Inv.Add(owner, item, qty)
    qty = math.floor(tonumber(qty) or 0)
    local ok, why = Inv.CanCarry(owner, item, qty)
    if not ok then return false, why end
    local d = Inv.Def(item)
    local slots = Inv.Capacity(owner)
    local c = Inv.Contents(owner)
    for i = 1, slots do
        if qty <= 0 then break end
        local s = c[i]
        if s and s.item == item and s.qty < d.stack then
            local add = math.min(qty, d.stack - s.qty)
            DB.exec('UPDATE pb_inv SET qty = qty + ? WHERE owner = ? AND slot = ?', { add, owner, i })
            qty = qty - add
        end
    end
    -- sac d'un joueur : les nouvelles piles vont dans le sac, pas dans la barre de raccourcis (cases 1 à N) qui ne sert qu'en dernier recours
    local hot = tostring(owner):sub(1, 2) == 'p:' and math.max(0, math.min(slots, math.floor(tonumber(cfg('hotbar', 5)) or 5))) or 0
    local order = {}
    for i = hot + 1, slots do order[#order + 1] = i end
    for i = 1, hot do order[#order + 1] = i end
    for _, i in ipairs(order) do
        if qty <= 0 then break end
        if not c[i] then
            local add = math.min(qty, d.stack)
            DB.exec('INSERT INTO pb_inv (owner, slot, item, qty) VALUES (?, ?, ?, ?)', { owner, i, item, add })
            c[i] = { item = item, qty = add }
            qty = qty - add
        end
    end
    return true
end

function Inv.Remove(owner, item, qty)
    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 or Inv.Count(owner, item) < qty then return false end
    local c = Inv.Contents(owner)
    local order = {}
    for slot, s in pairs(c) do if s.item == item then order[#order + 1] = slot end end
    table.sort(order, function(a, b) return c[a].qty < c[b].qty end)   -- on vide d'abord les petites piles
    local want = qty
    for _, slot in ipairs(order) do
        if qty <= 0 then break end
        local take = math.min(qty, c[slot].qty)
        if not takeExact(owner, slot, item, take) then
            -- quelqu'un a pris le même objet en même temps : on remet ce qui a déjà été retiré et on refuse
            if want - qty > 0 then Inv.Add(owner, item, want - qty) end
            return false
        end
        qty = qty - take
    end
    return true
end

-- Accès -----------------------------------------------------------------------------------------------------------------------------
local function distTo(src, x, y, z)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return 0 end
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return 0 end
    local dx, dy, dz = c.x - x, c.y - y, c.z - z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end
G.DistTo = distTo
function G.DistBetween(a, b)
    local pa, pb = GetPlayerPed(a), GetPlayerPed(b)
    if not pa or pa == 0 or not pb or pb == 0 then return 0 end
    local ca, cb = GetEntityCoords(pa), GetEntityCoords(pb)
    if not ca or not cb or (ca.x == 0 and ca.y == 0) or (cb.x == 0 and cb.y == 0) then return 0 end
    return math.sqrt((ca.x - cb.x) ^ 2 + (ca.y - cb.y) ^ 2 + (ca.z - cb.z) ^ 2)
end

-- Le joueur a-t-il le droit d'ouvrir et de modifier ce conteneur ?
function Inv.Access(src, owner)
    local mine = playerOwner(src)
    if not mine then return false end
    if owner == mine then return true end
    local kind, id = tostring(owner):match('^(%a+):(.+)$')
    if kind == 's' then
        local s = Inv.Stash(id)
        if not s or not PB.ToBool(s.enabled) then return false end
        if distTo(src, s.x, s.y, s.z) > cfg('stash_dist', 2.5) + 3 then return false end
        if s.biz ~= '' then
            local c = G.Biz and G.Biz.Ctx(src)
            if not c or c.biz.id ~= s.biz or (not c.boss and c.grade.grade < s.min_grade) then return false end
        end
        return true
    elseif kind == 'd' then
        local d = drops[owner]
        return d ~= nil and distTo(src, d.x, d.y, d.z) <= cfg('drop_dist', 2.5) + 3
    elseif Inv.ExtraAccess then
        return Inv.ExtraAccess(src, kind, id) and true or false
    end
    return false
end

-- Visionneuses : pour rafraîchir ceux qui regardent le même conteneur
local viewers = {}   -- src -> { owner, other }

local function nearPlayers(src)
    local out = {}
    local give, show = cfg('give_dist', 3.5), math.max(cfg('give_dist', 3.5), cfg('near_show', 10))
    local staffView = PB.Perm.Has(src, 'staff.menu')   -- un joueur ne voit ni le nom ni l'ID des inconnus autour de lui
    for id, p in pairs(G.Players()) do
        if id ~= src and PB.ToBool(p.row.created) then
            local d = G.DistBetween(src, id)
            if d <= show then
                local i = G.Identity(id)
                local name = staffView and ((((i and i.firstname or '') .. ' ' .. (i and i.lastname or '')):gsub('^%s+', '')) .. ' ' .. G.Tag(id)) or ('Personne à %d m'):format(math.floor(d + 0.5))
                out[#out + 1] = { id = id, name = name, d = d, far = d > give or nil, photo = G.Photos and G.Photos.Of(id) or nil }
            end
        end
    end
    table.sort(out, function(a, b) return a.d < b.d end)   -- le plus proche d'abord
    for _, o in ipairs(out) do o.d = nil end
    if #out > 8 then for i = #out, 9, -1 do out[i] = nil end end
    return out
end

local usables = {}
local function isWeaponItem(name, d)
    return (G.Weapons and G.Weapons.ByItem and G.Weapons.ByItem(name) ~= nil) or tostring(name):lower():find('^weapon_') ~= nil or (d and d.kind == 'weapon') or false
end
Inv.IsWeaponItem = isWeaponItem

local function view(owner, label)
    local slots, maxw = Inv.Capacity(owner)
    local list = {}
    for slot, s in pairs(Inv.Contents(owner)) do
        local d = Inv.Def(s.item) or { label = s.item, weight = 0, kind = 'misc', stack = 1 }
        list[#list + 1] = { slot = slot, item = s.item, qty = s.qty, label = d.label, weight = d.weight, kind = d.kind, image = Inv.Image(d.name and d or { name = s.item, kind = d.kind }), weapon = isWeaponItem(s.item, d) or nil, usable = (not isWeaponItem(s.item, d)) and (d.usable or (d.cloth or '') ~= '' or usables[s.item] ~= nil) and true or false, stack = d.stack, desc = d.description, cloth = (d.cloth or '') ~= '' and (d.cloth:match('^(%a+):')) or nil }
    end
    return { owner = owner, label = label, slots = slots, maxw = maxw, weight = Inv.Weight(owner), items = list }
end

local function push(src)
    local v = viewers[src]
    if not v then return end
    local data = { me = view(v.owner, 'Sac à dos'), near = nearPlayers(src), worn = Inv.Worn and Inv.Worn(src) or {}, wornImg = Inv.WornImg and Inv.WornImg(src) or {} }
    if v.ro then data.ro = true end
    if v.other then
        if v.ro or Inv.Access(src, v.other) then   -- lecture seule : déjà vérifié à l'ouverture (Inv.OpenView)
            local lab = v.otherLabel or 'Coffre'
            data.other = view(v.other, lab)
        else viewers[src].other = nil end
    end
    TriggerClientEvent('pb:g:inv:sync', src, PB.Json(data))
end
Inv.Push = push
-- Joueurs proches : mis à jour tant que l'inventaire est ouvert (seulement si la liste change)
CreateThread(function()
    local last = {}
    while true do
        Wait(1500)
        for src in pairs(viewers) do
            local n = nearPlayers(src)
            local ids = {}
            for _, x in ipairs(n) do ids[#ids + 1] = x.id end
            table.sort(ids)
            local sig = table.concat(ids, ',')
            if last[src] == nil then last[src] = sig elseif last[src] ~= sig then last[src] = sig push(src) end
        end
        for src in pairs(last) do if not viewers[src] then last[src] = nil end end
    end
end)
local function pushOwners(...)
    local set = {}
    for _, o in ipairs({ ... }) do set[o] = true end
    for s, v in pairs(viewers) do if set[v.owner] or (v.other and set[v.other]) then push(s) end end
end
Inv.PushOwners = pushOwners

local function usableNow(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end

function Inv.OpenFor(src, stash)
    if G.DutyGate and G.DutyGate(src) then return end
    if not usableNow(src) or not throttle(src, 300) then return end
    local owner = playerOwner(src)
    viewers[src] = { owner = owner }
    if stash and tostring(stash) ~= '' then
        local o = tostring(stash)
        if o:sub(1, 2) == 's:' or o:sub(1, 2) == 'd:' or o:sub(1, 2) == 'h:' or o:sub(1, 2) == 'v:' or o:sub(1, 2) == 'o:' or (o:sub(1, 2) == 'p:' and o ~= owner) then
            if Inv.Access(src, o) then
                viewers[src].other = o
                local s = o:sub(1, 2) == 's:' and Inv.Stash(o:sub(3))
                viewers[src].otherLabel = s and s.label or (o:sub(1, 2) == 'd:' and 'Au sol' or (o:sub(1, 2) == 'h:' and 'Coffre du logement' or (o:sub(1, 2) == 'o:' and "Coffre de l'organisation" or (o:sub(1, 2) == 'p:' and 'Fouille' or 'Coffre'))))
            end
        end
    end
    push(src)
    TriggerClientEvent('pb:g:inv:opened', src)
end
RegisterNetEvent('pb:g:inv:open', function(stash) Inv.OpenFor(source, stash) end)
-- Inventaire en lecture seule (ex. coffre d'un de ses véhicules depuis F5) : le sac et le conteneur s'affichent, rien ne bouge
-- (ni déplacer, ni utiliser, ni donner, ni jeter, ni trier) tant que cette vue est ouverte. L'appelant vérifie le droit de regarder.
function Inv.OpenView(src, other, label)
    if not usableNow(src) or not throttle(src, 300) then return false end
    viewers[src] = { owner = playerOwner(src), other = tostring(other), otherLabel = tostring(label or 'Coffre'):sub(1, 48), ro = true }
    push(src)
    TriggerClientEvent('pb:g:inv:opened', src)
    return true
end
local function readOnly(src)
    local v = viewers[src]
    if v and v.ro then G.Notify(src, { type = 'warn', title = 'Lecture seule', text = 'Tu regardes seulement : rien ne peut être pris ni déplacé.' }) push(src) return true end
    return false
end
Inv.ReadOnly = readOnly
RegisterNetEvent('pb:g:inv:close', function() viewers[source] = nil end)

-- Tri automatique du sac (hors barre de raccourcis) : piles fusionnées, rangées par catégorie puis par nom
local SORT_KIND = { weapon = 1, food = 2, drink = 3, medical = 4, tool = 5, doc = 6, clothes = 7, clothing = 7, misc = 8 }
RegisterNetEvent('pb:g:inv:sort', function()
    local src = source
    if not usableNow(src) or not throttle(src, 1500) or readOnly(src) then return end
    local owner = playerOwner(src)
    if not owner then return end
    local slots = Inv.Capacity(owner)
    local hot = math.max(0, math.min(slots, math.floor(tonumber(cfg('hotbar', 5)) or 5)))
    local totals, defs = {}, {}
    for slot, s in pairs(Inv.Contents(owner)) do
        if slot > hot then totals[s.item] = (totals[s.item] or 0) + s.qty defs[s.item] = Inv.Def(s.item) or { label = s.item, kind = 'misc', stack = 1 } end
    end
    local names = {}
    for item in pairs(totals) do names[#names + 1] = item end
    table.sort(names, function(a, b)
        local ka, kb = SORT_KIND[defs[a].kind] or 9, SORT_KIND[defs[b].kind] or 9
        if ka ~= kb then return ka < kb end
        return tostring(defs[a].label) < tostring(defs[b].label)
    end)
    local rows, slot = {}, hot + 1
    for _, item in ipairs(names) do
        local left, stack = totals[item], math.max(1, tonumber(defs[item].stack) or 1)
        while left > 0 do
            local q = math.min(left, stack)
            rows[#rows + 1] = { slot, item, q }
            slot, left = slot + 1, left - q
        end
    end
    if slot - 1 > slots then return end   -- (ne devrait pas arriver : le tri ne prend jamais plus de place)
    DB.exec('DELETE FROM pb_inv WHERE owner = ? AND slot > ?', { owner, hot })
    for _, r in ipairs(rows) do DB.exec('INSERT INTO pb_inv (owner, slot, item, qty) VALUES (?, ?, ?, ?)', { owner, r[1], r[2], r[3] }) end
    push(src)
end)
AddEventHandler('playerDropped', function() viewers[source] = nil last[tostring(source)] = nil end)

-- Déplacer : (owner, slot) -> (owner, slot) ; fusionne les piles identiques, échange à l'intérieur d'un même conteneur
-- objets liés au joueur (armes permanentes de la boutique) : ils ne quittent jamais son sac (ni don, ni dépôt, ni fouille, ni sol)
local bound = {}
function Inv.Bind(item) bound[tostring(item)] = true end
function Inv.IsBound(item) return bound[tostring(item)] == true end
local BOUND_MSG = 'Objet lié à son propriétaire : il reste dans son sac.'

function Inv.Move(src, fromO, fromS, toO, toS, qty)
    fromS, toS = math.floor(tonumber(fromS) or 0), math.floor(tonumber(toS) or 0)
    if type(fromO) ~= 'string' or type(toO) ~= 'string' then return false, 'Conteneur invalide.' end
    if viewers[src] and viewers[src].ro then return false, 'Lecture seule : rien ne peut être pris ni déplacé.' end
    if not Inv.Access(src, fromO) or not Inv.Access(src, toO) then return false, 'Accès refusé.' end
    local v = viewers[src]
    if not v or (fromO ~= v.owner and fromO ~= v.other) or (toO ~= v.owner and toO ~= v.other) then return false, "Ce conteneur n'est pas ouvert." end
    local fs, ts = Inv.Capacity(fromO), Inv.Capacity(toO)
    if fromS < 1 or fromS > fs or toS < 1 or toS > ts then return false, 'Emplacement invalide.' end
    local from = Inv.Contents(fromO)[fromS]
    if not from then return false, 'Emplacement vide.' end
    qty = math.floor(tonumber(qty) or from.qty)
    if qty < 1 or qty > from.qty then qty = from.qty end
    local d = Inv.Def(from.item)
    if not d then return false, 'Objet inconnu.' end
    if fromO ~= toO and bound[from.item] then return false, BOUND_MSG end
    local toC = Inv.Contents(toO)
    local dest = toC[toS]
    if fromO == toO then
        if fromS == toS then return true end
        if not dest then
            if qty == from.qty then DB.exec('UPDATE pb_inv SET slot = ? WHERE owner = ? AND slot = ?', { toS, fromO, fromS })
            else
                if not takeExact(fromO, fromS, from.item, qty) then return false, "L'objet n'est plus là." end
                DB.exec('INSERT INTO pb_inv (owner, slot, item, qty) VALUES (?, ?, ?, ?)', { toO, toS, from.item, qty })
            end
        elseif dest.item == from.item then
            local add = math.min(qty, d.stack - dest.qty)
            if add < 1 then return false, 'La pile est pleine.' end
            if not takeExact(fromO, fromS, from.item, add) then return false, "L'objet n'est plus là." end
            DB.exec('UPDATE pb_inv SET qty = qty + ? WHERE owner = ? AND slot = ?', { add, toO, toS })
        else
            if qty ~= from.qty then return false, 'Échange : déplace toute la pile.' end
            DB.exec('UPDATE pb_inv SET slot = 0 WHERE owner = ? AND slot = ?', { fromO, fromS })
            DB.exec('UPDATE pb_inv SET slot = ? WHERE owner = ? AND slot = ?', { fromS, toO, toS })
            DB.exec('UPDATE pb_inv SET slot = ? WHERE owner = ? AND slot = 0', { toS, fromO })
        end
    else
        -- entre deux conteneurs : poids de destination, pile compatible
        local maxw = select(2, Inv.Capacity(toO))
        local w = 0
        for _, s in pairs(toC) do local sd = Inv.Def(s.item) w = w + (sd and sd.weight or 0) * s.qty end
        if w + d.weight * qty > maxw then return false, 'Trop lourd.' end
        if dest and dest.item ~= from.item then return false, "Choisis un emplacement vide ou la même pile." end
        if dest then
            local add = math.min(qty, d.stack - dest.qty)
            if add < 1 then return false, 'La pile est pleine.' end
            qty = add
        else
            qty = math.min(qty, d.stack)
        end
        if not takeExact(fromO, fromS, from.item, qty) then pushOwners(fromO, toO) return false, "L'objet n'est plus là." end
        if dest then DB.exec('UPDATE pb_inv SET qty = qty + ? WHERE owner = ? AND slot = ?', { qty, toO, toS })
        else DB.exec('INSERT INTO pb_inv (owner, slot, item, qty) VALUES (?, ?, ?, ?)', { toO, toS, from.item, qty }) end
        TriggerEvent('pb_panel:itemMoved', src, from.item, qty, fromO, toO)
    end
    pushOwners(fromO, toO)
    return true
end
RegisterNetEvent('pb:g:inv:move', function(fo, fs, to, ts, qty)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usableNow(src) or not throttle(src, 120) then return end
    local ok, err = Inv.Move(src, fo, fs, to, ts, qty)
    if not ok then G.Notify(src, { type = 'error', text = err }) push(src) end
    if ok and Inv.DropTouched then Inv.DropTouched(tostring(fo)) end   -- sac au sol vidé : il disparaît tout de suite
end)

-- Utiliser -------------------------------------------------------------------------------------------------------------------------------
function Inv.RegisterUsable(name, fn) usables[tostring(name)] = fn end
-- (v1.2.42) objets à préfixe (ex. « tenue_12 ») : un seul gestionnaire pour toute une famille d'objets
local usablePrefix = {}
function Inv.RegisterUsablePrefix(prefix, fn) usablePrefix[#usablePrefix + 1] = { tostring(prefix), fn } end
local function prefixUsable(item) for _, u in ipairs(usablePrefix) do if tostring(item):sub(1, #u[1]) == u[1] then return u[2] end end end
function Inv.HasUse(name) return usables[tostring(name)] ~= nil or prefixUsable(name) ~= nil end
exports('RegisterUsable', function(name, fn) Inv.RegisterUsable(name, fn) end)

function Inv.Use(src, slot)
    local owner = playerOwner(src)
    local s = owner and Inv.Contents(owner)[math.floor(tonumber(slot) or 0)]
    if not s then return false, 'Emplacement vide.' end
    local d = Inv.Def(s.item)
    if not d then return false, 'Objet inconnu.' end
    local cl = parseCloth(d.cloth)
    if cl then return Inv.Wear(src, s.item, cl) end
    if Inv.IsOver and Inv.IsOver(src) then return false, 'Tu portes trop lourd : allège-toi ou équipe un sac.' end
    local custom = usables[s.item] or prefixUsable(s.item)
    -- arme hors du catalogue du module Armes (pack d'armes, objet weapon_*) : équipée quand même, jamais consommée
    if isWeaponItem(s.item, d) and not custom then
        if G.Weapons and G.Weapons.UseGeneric then return G.Weapons.UseGeneric(src, s.item, d) end
        return false, "Cette arme ne peut pas être équipée."
    end
    if not d.usable and not custom then return false, 'Cet objet ne s\'utilise pas.' end
    if custom then
        local ok, res, msg, keep = pcall(custom, src, s.item, d)
        if not ok then return false, "L'objet n'a pas pu être utilisé." end
        if res == false then return false, msg or "Impossible pour l'instant." end
        if keep == true then TriggerEvent('pb_panel:itemUsed', src, s.item) return true, msg or (d.label .. ' utilisé.') end   -- l'objet reste dans le sac (arme, outil)
    end
    for _, k in ipairs({ 'hunger', 'thirst', 'stress' }) do if d[k] ~= 0 then G.AddStatus(src, k, d[k]) end end
    if d.health ~= 0 then TriggerClientEvent('pb:g:inv:heal', src, d.health) end
    -- animation : manger / boire avec l'objet en main (client/inventory.lua)
    local anim = (d.kind == 'drink' or (d.thirst or 0) > (d.hunger or 0)) and 'drink' or ((d.kind == 'food' or (d.hunger or 0) > 0) and 'eat' or nil)
    if anim then TriggerClientEvent('pb:g:inv:consume', src, anim, s.item) end
    Inv.Remove(owner, s.item, 1)
    TriggerEvent('pb_panel:itemUsed', src, s.item)
    return true, d.label .. ' utilisé.'
end

-- Kit de réparation : répare le véhicule le plus proche (6 m). Rien n'est consommé s'il n'y a pas de véhicule.
PB.Migrate('212_fishing_rod_usable', "Inventaire : la canne à pêche s'utilise (pêche partout)", { "UPDATE pb_inv_items SET usable = 1 WHERE name IN ('fishing_rod', 'canne_pro', 'canne_carbone')" })
PB.Migrate('198_repair_kit_usable', "Inventaire : le kit de réparation s'utilise", { "UPDATE pb_inv_items SET usable = 1, description = 'Répare le véhicule le plus proche.' WHERE name = 'repair_kit'" })
Inv.RegisterUsable('repair_kit', function(src)
    local ped = GetPlayerPed(src)
    local c = ped ~= 0 and GetEntityCoords(ped)
    if not c then return false end
    if GetVehiclePedIsIn(ped, false) ~= 0 then return false, 'Descends du véhicule pour le réparer.' end
    local best, bd
    for _, v in ipairs(GetAllVehicles()) do
        local d = #(GetEntityCoords(v) - c)
        if d < 6.0 and (not bd or d < bd) then best, bd = v, d end
    end
    if not best then return false, 'Aucun véhicule à côté de toi.' end
    TriggerClientEvent('pb:g:inv:repairkit', src, NetworkGetNetworkIdFromEntity(best))
    return true, 'Réparation en cours…'
end)

Inv.RegisterUsable('armor', function(src, item, d)
    TriggerClientEvent('pb:g:inv:armor', src, 50)
    return true
end)

-- Vêtements : enfiler / retirer (même objet = retirer). Le serveur garde l'état, le client ne fait qu'appliquer.
local worn = {}   -- src -> { slot = item }
local function wornView(src) local w = worn[src] or {} local out = {} for slot, item in pairs(w) do local d = Inv.Def(item) out[slot] = d and d.label or item end return out end
local function sendWorn(src, only)
    local list = {}
    for slot, item in pairs(worn[src] or {}) do
        local d = Inv.Def(item); local cl = d and parseCloth(d.cloth)
        if cl and (not only or only == slot) then list[#list + 1] = { slot = slot, kind = cl.kind, idx = cl.idx, drawable = cl.drawable, texture = cl.texture, on = true } end
    end
    TriggerClientEvent('pb:g:inv:wear', src, PB.Json({ list = list, all = only == nil }))
end
function Inv.Wear(src, item, cl)
    local p = G.Get(src)
    if not p then return false, 'Joueur introuvable.' end
    worn[src] = worn[src] or {}
    if worn[src][cl.slot] == item then
        worn[src][cl.slot] = nil
        DB.exec('DELETE FROM pb_inv_worn WHERE license = ? AND slot = ?', { p.license, cl.slot })
        TriggerClientEvent('pb:g:inv:wear', src, PB.Json({ list = { { slot = cl.slot, kind = cl.kind, idx = cl.idx, none = cl.none, on = false } } }))
        return true, 'Vêtement retiré.'
    end
    worn[src][cl.slot] = item
    DB.exec('REPLACE INTO pb_inv_worn (license, slot, item) VALUES (?, ?, ?)', { p.license, cl.slot, item })
    sendWorn(src, cl.slot)
    TriggerEvent('pb_panel:itemUsed', src, item)
    return true, 'Vêtement enfilé.'
end
function Inv.Worn(src) return wornView(src) end
-- Retirer ce qui est porté dans une case (sac, masque…), même si l'objet n'est plus dans le sac du joueur
function Inv.Unwear(src, slot)
    slot = tostring(slot or '')
    local cs = CLOTH_SLOTS[slot]
    if not cs or not (worn[src] and worn[src][slot]) then return false, 'Rien à retirer ici.' end
    local p = G.Get(src)
    worn[src][slot] = nil
    if p then DB.exec('DELETE FROM pb_inv_worn WHERE license = ? AND slot = ?', { p.license, slot }) end
    TriggerClientEvent('pb:g:inv:wear', src, PB.Json({ list = { { slot = slot, kind = cs[1], idx = cs[2], none = cs[3], on = false } } }))
    return true, 'Vêtement retiré.'
end
-- (v1.2.45) un vêtement porté dont l'objet a quitté le sac (rangé dans un coffre, donné, jeté) est retiré tout seul :
-- avant, un sac à dos restait porté pour toujours et plus rien ne permettait de l'enlever
function Inv.CheckWorn(src)
    local owner = playerOwner(src)
    if not owner or not worn[src] then return end
    for slot, item in pairs(worn[src]) do
        if Inv.Count(owner, item) < 1 then Inv.Unwear(src, slot) end
    end
end
RegisterNetEvent('pb:g:inv:unwear', function(slot)
    local src = source
    if not usableNow(src) or not throttle(src, 400) then return end
    local ok, msg = Inv.Unwear(src, slot)
    G.Notify(src, { type = ok and 'success' or 'error', text = msg })
    if Inv.LoadCheck then Inv.LoadCheck(playerOwner(src)) end
    pushOwners(playerOwner(src))
end)
-- (v1.2.42) tenue complète changée (sac de vêtements) : plus aucune pièce de l'inventaire n'est portée
function Inv.ResetWorn(src)
    local p = G.Get(src)
    worn[src] = {}
    if p then DB.exec('DELETE FROM pb_inv_worn WHERE license = ?', { p.license }) end
end
-- Images des vêtements portés (cases « Équipements » de l'inventaire E4)
function Inv.WornImg(src)
    local out = {}
    for slot, item in pairs(worn[src] or {}) do local d = Inv.Def(item) out[slot] = Inv.Image(d and d.name and d or { name = item, kind = 'clothes' }) end
    return out
end
table.insert(G.beginHooks, function(src, p)
    worn[src] = {}
    for _, r in ipairs(DB.q('SELECT slot, item FROM pb_inv_worn WHERE license = ?', { p.license }) or {}) do
        local d = Inv.Def(r.item)
        if d and parseCloth(d.cloth) and CLOTH_SLOTS[r.slot] then worn[src][r.slot] = r.item end
    end
    SetTimeout(4000, function() if worn[src] and next(worn[src]) then sendWorn(src) end end)
end)
AddEventHandler('playerDropped', function() worn[source] = nil end)
RegisterNetEvent('pb:g:inv:use', function(slot)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usableNow(src) or not throttle(src, 600) or readOnly(src) then return end
    local ok, msg = Inv.Use(src, slot)
    G.Notify(src, { type = ok and 'success' or 'error', text = msg })
    pushOwners(playerOwner(src))
end)

-- Donner et jeter ---------------------------------------------------------------------------------------------------------------------------
function Inv.Give(src, targetId, slot, qty)
    if not cfg('allow_give', true) then return false, 'Les dons sont désactivés.' end
    targetId = tonumber(targetId)
    if not targetId or targetId == src then return false, 'Choisis un joueur proche.' end
    local tp = G.Get(targetId)
    if not tp or not PB.ToBool(tp.row.created) then return false, "Ce joueur n'est pas disponible." end
    if G.DistBetween(src, targetId) > cfg('give_dist', 3.5) + 1.5 then return false, 'Ce joueur est trop loin.' end
    local mine, theirs = playerOwner(src), playerOwner(targetId)
    local s = Inv.Contents(mine)[math.floor(tonumber(slot) or 0)]
    if not s then return false, 'Emplacement vide.' end
    if bound[s.item] then return false, BOUND_MSG end
    qty = math.floor(tonumber(qty) or s.qty)
    if qty < 1 or qty > s.qty then qty = s.qty end
    local ok, why = Inv.CanCarry(theirs, s.item, qty)
    if not ok then return false, 'Il ne peut pas le porter (' .. tostring(why):lower():gsub('%.$', '') .. ').' end
    Inv.Remove(mine, s.item, qty)
    Inv.Add(theirs, s.item, qty)
    local d = Inv.Def(s.item)
    G.Notify(targetId, { type = 'info', title = 'Objet reçu', text = ('%d × %s'):format(qty, d and d.label or s.item) })
    TriggerEvent('pb_panel:itemGiven', src, targetId, s.item, qty)
    pushOwners(mine, theirs)
    return true, ('%d × %s donné(s).'):format(qty, d and d.label or s.item)
end
RegisterNetEvent('pb:g:inv:give', function(target, slot, qty)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usableNow(src) or not throttle(src, 400) or readOnly(src) then return end
    local ok, msg = Inv.Give(src, target, slot, qty)
    G.Notify(src, { type = ok and 'success' or 'error', text = msg })
end)

local function dropList()
    local out = {}
    for owner, d in pairs(drops) do out[#out + 1] = { id = owner, x = d.x, y = d.y, z = d.z } end
    return out
end
local function pushDrops() TriggerClientEvent('pb:g:inv:drops', -1, PB.Json(dropList())) end

local function pruneDrops()
    local t, changed = os.time(), false
    local ttl = cfg('drop_ttl', 20) * 60
    for owner, d in pairs(drops) do
        local empty = next(Inv.Contents(owner)) == nil
        if empty or t - d.at > ttl then
            DB.exec('DELETE FROM pb_inv WHERE owner = ?', { owner })
            drops[owner] = nil changed = true
        end
    end
    if changed then pushDrops() end
end
CreateThread(function() Wait(math.random(0, 60000)) while true do Wait(60000) pruneDrops() end end)
function Inv.DropTouched(owner)
    if not drops[owner] or next(Inv.Contents(owner)) ~= nil then return end
    DB.exec('DELETE FROM pb_inv WHERE owner = ?', { owner })
    drops[owner] = nil
    pushDrops()
    for s, v in pairs(viewers) do if v.other == owner then viewers[s].other = nil push(s) end end
end
CreateThread(function() while not PB.IsReady do Wait(500) end DB.exec("DELETE FROM pb_inv WHERE owner LIKE 'd:%'") end)   -- les objets au sol ne survivent pas à un redémarrage

function Inv.Drop(src, slot, qty)
    if not cfg('allow_drop', true) then return false, 'Jeter des objets est désactivé.' end
    local mine = playerOwner(src)
    local s = Inv.Contents(mine)[math.floor(tonumber(slot) or 0)]
    if not s then return false, 'Emplacement vide.' end
    if bound[s.item] then return false, BOUND_MSG end
    qty = math.floor(tonumber(qty) or s.qty)
    if qty < 1 or qty > s.qty then qty = s.qty end
    local x, y, z = 0.0, 0.0, 0.0
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then local c = GetEntityCoords(ped) if c then x, y, z = c.x, c.y, c.z - 0.9 end end
    -- on réutilise un tas proche plutôt que d'en créer des dizaines
    local owner
    for o, d in pairs(drops) do if (d.x - x) ^ 2 + (d.y - y) ^ 2 + (d.z - z) ^ 2 < 2.25 and Inv.CanCarry(o, s.item, qty) then owner = o end end
    if not owner then
        local n = 0 for _ in pairs(drops) do n = n + 1 end
        if n >= cfg('max_drops', 120) then return false, 'Trop d\'objets au sol dans la ville : réessaie plus tard.' end
        dropSeq = dropSeq + 1
        owner = 'd:' .. dropSeq
        drops[owner] = { x = x, y = y, z = z, at = os.time() }
    end
    local ok, why = Inv.CanCarry(owner, s.item, qty)
    if not ok then return false, 'Impossible de jeter ici : ' .. tostring(why) end
    Inv.Remove(mine, s.item, qty)
    Inv.Add(owner, s.item, qty)
    drops[owner].at = os.time()
    pushDrops()
    TriggerEvent('pb_panel:itemDropped', src, s.item, qty)
    pushOwners(mine)
    return true, 'Objet jeté.'
end
RegisterNetEvent('pb:g:inv:drop', function(slot, qty)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usableNow(src) or not throttle(src, 400) or readOnly(src) then return end
    local ok, msg = Inv.Drop(src, slot, qty)
    if not ok then G.Notify(src, { type = 'error', text = msg }) end
end)
RegisterNetEvent('pb:g:inv:needDrops', function() local src = source if throttle('d' .. src, 1000) then TriggerClientEvent('pb:g:inv:drops', src, PB.Json(dropList())) end end)
function Inv.DropOwners() return drops end
function Inv.DropCount() local n = 0 for _ in pairs(drops) do n = n + 1 end return n end
Inv.__prune = pruneDrops
Inv.__drops = drops

-- Liste des coffres envoyée aux clients (position seulement)
function G.StashList()
    local out = {}
    for _, s in ipairs(DB.q('SELECT id, label, x, y, z, enabled, biz FROM pb_inv_stashes') or {}) do
        if PB.ToBool(s.enabled) and (s.x ~= 0 or s.y ~= 0) then out[#out + 1] = { id = 's:' .. s.id, label = s.label, x = s.x, y = s.y, z = s.z, biz = s.biz ~= '' and s.biz or nil } end
    end
    return out
end

-- Exports ----------------------------------------------------------------------------------------------------------------------------------
exports('AddItem', function(src, name, qty) local o = playerOwner(tonumber(src)) if not o then return false end local ok = Inv.Add(o, tostring(name), qty) if ok then pushOwners(o) end return ok end)
exports('RemoveItem', function(src, name, qty) local o = playerOwner(tonumber(src)) if not o then return false end local ok = Inv.Remove(o, tostring(name), qty) if ok then pushOwners(o) end return ok end)
exports('GetItemCount', function(src, name) local o = playerOwner(tonumber(src)) return o and Inv.Count(o, tostring(name)) or 0 end)
exports('HasItem', function(src, name, qty) local o = playerOwner(tonumber(src)) return o ~= nil and Inv.Count(o, tostring(name)) >= (tonumber(qty) or 1) end)
exports('CanCarryItem', function(src, name, qty) local o = playerOwner(tonumber(src)) if not o then return false end return Inv.CanCarry(o, tostring(name), qty) end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------------
local KINDS = { { 'food', 'Nourriture' }, { 'drink', 'Boisson' }, { 'medical', 'Soin' }, { 'tool', 'Outil' }, { 'doc', 'Document' }, { 'clothes', 'Vêtement' }, { 'misc', 'Divers' } }

PB.Action('inv.item.save', 'inv.edit', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'name', type = 'text', label = 'Identifiant', required = true, maxlen = 40, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
        { k = 'weight', type = 'number', label = 'Poids (g)', min = 0, max = 1000000 }, { k = 'stack', type = 'number', label = 'Pile maximale', min = 1, max = 1000 },
        { k = 'kind', type = 'select', label = 'Type', opts = KINDS }, { k = 'hunger', type = 'number', label = 'Faim', min = -100, max = 100 }, { k = 'thirst', type = 'number', label = 'Soif', min = -100, max = 100 },
        { k = 'stress', type = 'number', label = 'Stress', min = -100, max = 100 }, { k = 'health', type = 'number', label = 'Vie', min = -100, max = 100 }, { k = 'usable', type = 'toggle', label = 'Utilisable' },
        { k = 'description', type = 'text', label = 'Description', maxlen = 160 }, { k = 'image', type = 'text', label = 'Image (vide = illustration fournie ; img/items/… ou https://…)', maxlen = 200 },
        { k = 'cloth_slot', type = 'select', label = 'Emplacement', opts = CLOTH_OPTS }, { k = 'cloth_draw', type = 'number', label = 'Modèle', min = 0, max = 999 }, { k = 'cloth_tex', type = 'number', label = 'Texture', min = 0, max = 99 },
    }, { cloth_slot = v.cloth_slot or '', cloth_draw = v.cloth_draw or 0, cloth_tex = v.cloth_tex or 0, name = v.name, label = v.label, weight = v.weight or 100, stack = v.stack or 20, kind = v.kind or 'misc', hunger = v.hunger or 0, thirst = v.thirst or 0, stress = v.stress or 0, health = v.health or 0, usable = v.usable, description = v.description or '', image = v.image or '' })
    if not c then return false, err end
    c.cloth = c.cloth_slot ~= '' and ('%s:%d:%d'):format(c.cloth_slot, c.cloth_draw, c.cloth_tex) or ''
    if c.cloth ~= '' then c.kind = 'clothes' end
    if not Inv.ValidImage(c.image) then return false, 'Image invalide : img/items/nom.svg ou une adresse https://.' end
    local before = Inv.Def(c.name)
    if before and before.stack > c.stack then
        local over = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE item = ? AND qty > ?', { c.name, c.stack })
        if over and over.n > 0 then return false, ('%d pile(s) existante(s) dépassent cette taille : agrandis la pile ou vide-les.'):format(over.n) end
    end
    DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description, cloth, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), weight = VALUES(weight), stack = VALUES(stack), kind = VALUES(kind), hunger = VALUES(hunger), thirst = VALUES(thirst), stress = VALUES(stress), health = VALUES(health), usable = VALUES(usable), description = VALUES(description), cloth = VALUES(cloth), image = VALUES(image)',
        { c.name, c.label, c.weight, c.stack, c.kind, c.hunger, c.thirst, c.stress, c.health, c.usable and 1 or 0, c.description, c.cloth, c.image })
    loadDefs()
    ctx.audit('config', before and 'inv.item.edit' or 'inv.item.create', c.name, before, c)
    ctx.toast = 'Objet enregistré.'
    return true
end)

PB.Action('inv.item.delete', 'inv.edit', function(ctx, p)
    local name = tostring(p.item or '')
    local d = Inv.Def(name)
    if not d then return false, 'Objet introuvable.' end
    local n = DB.one('SELECT COALESCE(SUM(qty), 0) AS n FROM pb_inv WHERE item = ?', { name })
    DB.exec('DELETE FROM pb_inv WHERE item = ?', { name })
    DB.exec('DELETE FROM pb_inv_items WHERE name = ?', { name })
    loadDefs()
    ctx.audit('config', 'inv.item.delete', name, d, { removed = n and n.n or 0 })
    ctx.toast = ('Objet supprimé (%d exemplaire(s) retiré(s) des inventaires).'):format(n and n.n or 0)
    return true
end, { critical = true, confirm = { title = 'Supprimer cet objet ?', text = 'Il disparaît aussi de tous les inventaires et coffres.', danger = true } })

PB.Action('inv.stash.save', 'inv.edit', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
        { k = 'slots', type = 'number', label = 'Emplacements', min = 1, max = 200 }, { k = 'weight', type = 'number', label = 'Poids maximal (g)', min = 1000, max = 5000000 },
        { k = 'coords', type = 'coords', label = 'Position' }, { k = 'biz', type = 'text', label = 'Entreprise', maxlen = 32, pattern = '^[%w_]*$' }, { k = 'min_grade', type = 'number', label = 'Grade minimal', min = 0, max = 50 }, { k = 'enabled', type = 'toggle', label = 'Actif' },
    }, { id = v.id, label = v.label, slots = v.slots or 40, weight = v.weight or 200000, coords = v.coords or { x = 0, y = 0, z = 0, h = 0 }, biz = v.biz or '', min_grade = v.min_grade or 0, enabled = v.enabled ~= false })
    if not c then return false, err end
    if c.biz ~= '' and not (G.Biz and G.Biz.Get(c.biz)) then return false, 'Cette entreprise n\'existe pas.' end
    local before = Inv.Stash(c.id)
    if before then
        local used = DB.one('SELECT COALESCE(MAX(slot), 0) AS m FROM pb_inv WHERE owner = ?', { 's:' .. c.id })
        if used and used.m > c.slots then return false, ('Des objets occupent l\'emplacement %d : vide-les avant de réduire le coffre.'):format(used.m) end
    end
    DB.exec('INSERT INTO pb_inv_stashes (id, label, slots, weight, x, y, z, biz, min_grade, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), slots = VALUES(slots), weight = VALUES(weight), x = VALUES(x), y = VALUES(y), z = VALUES(z), biz = VALUES(biz), min_grade = VALUES(min_grade), enabled = VALUES(enabled)',
        { c.id, c.label, c.slots, c.weight, c.coords.x, c.coords.y, c.coords.z, c.biz, c.min_grade, c.enabled and 1 or 0 })
    ctx.audit('config', before and 'inv.stash.edit' or 'inv.stash.create', c.id, before, c)
    G.PushConfig()
    ctx.toast = 'Coffre enregistré.'
    return true
end)

PB.Action('inv.stash.delete', 'inv.edit', function(ctx, p)
    local s = Inv.Stash(p.id)
    if not s then return false, 'Introuvable.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { 's:' .. s.id })
    DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. s.id }) DB.exec('DELETE FROM pb_inv_stashes WHERE id = ?', { s.id })
    ctx.audit('config', 'inv.stash.delete', s.id, s, { items = n and n.n or 0 })
    G.PushConfig()
    ctx.toast = 'Coffre supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce coffre ?', text = 'Son contenu est perdu.', danger = true } })

PB.Action('inv.give', 'inv.give', function(ctx, p)
    local v = p.values or {}
    local id = tonumber(v.player)
    local o = id and playerOwner(id)
    if not o then return false, "Ce joueur n'est pas connecté avec un personnage." end
    local name, qty = tostring(v.item or ''), math.floor(tonumber(v.qty) or 0)
    if not Inv.Def(name) then return false, 'Objet inconnu.' end
    if qty < 1 or qty > 1000 then return false, 'Quantité : 1 à 1000.' end
    local ok, why = Inv.Add(o, name, qty)
    if not ok then return false, "Impossible : " .. tostring(why) end
    ctx.audit('serveur', 'inv.give', G.Get(id).license, nil, { item = name, qty = qty })
    G.Notify(id, { type = 'info', title = 'Objet reçu', text = ('%d × %s'):format(qty, Inv.Def(name).label) })
    pushOwners(o)
    ctx.toast = 'Objet donné.'
    return true
end)

PB.Action('inv.take', 'inv.give', function(ctx, p)
    local v = p.values or {}
    local id = tonumber(v.player)
    local o = id and playerOwner(id)
    if not o then return false, "Ce joueur n'est pas connecté avec un personnage." end
    local name, qty = tostring(v.item or ''), math.floor(tonumber(v.qty) or 0)
    if not Inv.Def(name) then return false, 'Objet inconnu.' end
    if not Inv.Remove(o, name, qty) then return false, "Il n'en a pas autant." end
    ctx.audit('serveur', 'inv.take', G.Get(id).license, nil, { item = name, qty = qty })
    pushOwners(o)
    ctx.toast = 'Objet retiré.'
    return true
end, { critical = true, confirm = { title = 'Retirer cet objet ?', text = 'Il disparaît définitivement de son sac.' } })

local settings = Form.Cfg({ ns = 'inv', id = 'settings', title = "Réglages de l'inventaire", perm = 'inv.edit', cols = 2, fields = {
    { k = 'style', type = 'select', label = "Apparence de l'inventaire", default = 'e4', opts = { { 'e4', 'Shadow Studio V2 (sac, personnage au centre, coffre à droite)' } } },
    { k = 'ped_mode', type = 'select', label = 'Personnage au centre (maquette E4)', default = 'menu', opts = {
        { 'menu', 'Mon personnage seul au centre, décor flouté (recommandé)' }, { 'camera', 'Caméra sur mon personnage, dans le décor' }, { 'off', 'Silhouette de la maquette' } } },
    { k = 'ped_dim', type = 'number', label = 'Assombrissement du décor derrière l\'inventaire (%)', default = 12, min = 0, max = 100, hint = 'Même teinte partout, y compris autour du personnage (mode menu pause). Le personnage reste clair.' },
    { k = 'blur', type = 'toggle', label = 'Flouter le jeu derrière l\'inventaire (maquette E4)', default = false, hint = 'Effet verre dépoli derrière les cases ; ton personnage reste net. En mode caméra, le flou vient de la profondeur de champ.' },
    { k = 'ped_dist_e4', type = 'number', label = 'Distance de la caméra (maquette E4, mode caméra) : plus grand = personnage plus petit', default = 5, min = 3, max = 12, step = 0.5, int = false },
    { k = 'color_mode', type = 'select', label = 'Couleur (maquette E4)', default = 'server', opts = {
        { 'server', 'Couleur du serveur (Identité)' }, { 'menus', "Couleur d'accent des menus" }, { 'custom', 'Couleur personnalisée' }, { 'original', 'Vert néon d’origine' } } },
    { k = 'color', type = 'color', label = 'Couleur personnalisée', default = '#00f895', hint = 'Utilisée seulement avec « Couleur personnalisée ».' },
    { k = 'promo', type = 'area', rows = 3, label = 'Encadré en bas du sac (maquette E4)', default = 'Pour débloquer plus de slot dans votre inventaire,\nachetez le *Premium*. Il est vendu dans la boutique\nserveur *24h/24 et 7j/7.*', maxlen = 300,
      hint = 'Entre *étoiles* : mot en couleur. Vide : pas de texte.' },
    { k = 'slots', type = 'number', label = 'Emplacements du sac', default = 50, min = 5, max = 200 }, { k = 'max_weight', type = 'number', label = 'Poids maximal du sac (g)', default = 30000, min = 1000, max = 1000000 },
    { k = 'key', type = 'text', label = "Touche d'ouverture (par défaut)", default = 'I', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
    { k = 'hotbar', type = 'number', label = 'Raccourcis rapides (touches 1 à N, 5 au maximum)', default = 5, min = 0, max = 5 },
    { k = 'no_weapon_wheel', type = 'toggle', label = "Supprimer la molette d'armes (Tab et molette de la souris)", default = true, hint = "Les armes se prennent depuis l'inventaire ou les raccourcis 1 à 5." },
    { k = 'tab_opens', type = 'toggle', label = "Tab ouvre et ferme l'inventaire", default = true, hint = "Avec la molette supprimée. La touche d'ouverture ci-dessus marche toujours." },
    { k = 'ped_view', type = 'toggle', label = 'Afficher mon personnage au centre (vivant, comme une maquette)', default = true },
    { k = 'ped_dist', type = 'number', label = 'Distance de la caméra (m) : plus grand = personnage plus petit', default = 6.5, min = 3, max = 12, step = 0.5, int = false },
    { k = 'ped_sway', type = 'toggle', label = 'Le personnage tourne lentement sur lui-même', default = true },
    { k = 'ped_platform', type = 'toggle', label = 'Socle lumineux sous le personnage', default = true },
    { k = 'stash_dist', type = 'number', label = 'Distance pour ouvrir un coffre (m)', default = 2.5, min = 1, max = 10 }, { k = 'give_dist', type = 'number', label = 'Distance pour donner (m)', default = 3.5, min = 1, max = 10 }, { k = 'near_show', type = 'number', label = 'Joueurs affichés à droite jusqu\'à (m)', default = 10, min = 3, max = 30 },
    { k = 'drop_dist', type = 'number', label = 'Distance pour ramasser (m)', default = 2.5, min = 1, max = 10 }, { k = 'drop_ttl', type = 'number', label = 'Durée des objets au sol (min)', default = 20, min = 1, max = 240 },
    { k = 'max_drops', type = 'number', label = 'Tas au sol maximum dans la ville', default = 120, min = 10, max = 1000 },
    { k = 'bags', type = 'list', label = 'Sacs à dos : objet|kg en plus quand il est porté', default = { 'bag_small|10', 'bag_medium|20', 'bag_large|30', 'bag_xl|40', 'bag_tactical|50' }, maxlen = 48,
      hint = 'Le poids en plus ne compte que si le sac est équipé (case Sac). Sans sac et trop chargé, le joueur avance au pas et ne peut plus agir.' },
    { k = 'allow_drop', type = 'toggle', label = 'Autoriser à jeter', default = true }, { k = 'allow_give', type = 'toggle', label = 'Autoriser à donner', default = true },
} })

PB.Module({
    id = 'inv', label = 'Inventaire', icon = 'package', group = 'Serveur', order = 130, perm = 'inv.view', hint = 'Objets, poids, coffres, sol',
    caps = function()
        return PB.Capsify({
            { 'Sac à dos avec poids et emplacements', 'ok', 'Glisser-déposer, utilisation, don à un joueur proche, objets au sol.' },
            { 'Coffres (fixes, réservés à une entreprise)', 'ok', 'Placés depuis le panel, distance vérifiée par le serveur.' },
            { "Achats des supérettes dans l'inventaire", 'ok', "Mode « inventaire intégré » dans Magasins > Réglages (par défaut quand aucun autre inventaire n'est détecté)." },
            { 'Raccourcis rapides (touches 1 à 5)', 'ok', 'Utilisent l\'objet de l\'emplacement correspondant.' },
            { 'Armes avec munitions, états d\'usure, numéros de série', 'off', 'Non prévu : les armes ne sont pas des objets de cet inventaire.' },
            { 'Ox / QB inventory en même temps', 'off', "Ne lance pas deux inventaires : désactive l'autre ou garde-le pour le reste du serveur." },
        })
    end,
    doc = "## Inventaire\nChaque joueur a un sac (emplacements + poids). Les objets se créent dans **Objets**; les coffres dans **Coffres**.\n\n- Pour tes scripts : `exports.pb_panel:AddItem(src, 'water', 2)`, `RemoveItem`, `HasItem`, `GetItemCount`, `CanCarryItem`, `RegisterUsable('lockpick', function(src) ... end)`.\n- Événements : `pb_panel:itemUsed`, `itemGiven`, `itemDropped`, `itemMoved`.\n- Les objets au sol disparaissent après la durée réglée et au redémarrage.",
    view = function(ctx)
        return { tabs = {
            { id = 'items', label = 'Objets', icon = 'package', build = function(_, params)
                local rows = {}
                for _, d in pairs(Inv.Defs()) do rows[#rows + 1] = d end
                table.sort(rows, function(a, b) return a.label < b.label end)
                local list = {}
                for _, d in ipairs(rows) do
                    local n = DB.one('SELECT COALESCE(SUM(qty), 0) AS n FROM pb_inv WHERE item = ?', { d.name })
                    list[#list + 1] = { label = d.label, name = d.name, kind = d.kind, weight = d.weight, stack = d.stack, effects = ((d.hunger ~= 0 and ('faim ' .. d.hunger .. ' ') or '') .. (d.thirst ~= 0 and ('soif ' .. d.thirst .. ' ') or '') .. (d.stress ~= 0 and ('stress ' .. d.stress .. ' ') or '') .. (d.health ~= 0 and ('vie ' .. d.health) or '')), total = n and n.n or 0,
                        actions = ctx.has('inv.edit') and { { action = 'inv.item.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { item = d.name } } } or {} }
                end
                local blocks = { B.table({ id = 'it', title = 'Objets (' .. #list .. ')', search = true, columns = { { k = 'label', label = 'Nom' }, { k = 'name', label = 'Identifiant', type = 'mono' }, { k = 'kind', label = 'Type' }, { k = 'weight', label = 'Poids (g)', type = 'num' },
                    { k = 'stack', label = 'Pile', type = 'num' }, { k = 'effects', label = 'Effets' }, { k = 'total', label = 'En circulation', type = 'num' } }, rows = list }) }
                if ctx.has('inv.edit') then
                    local opts = { { '', '— nouvel objet —' } }
                    for _, d in ipairs(rows) do opts[#opts + 1] = { d.name, d.label } end
                    local cur = Inv.Def(tostring(params and params.item or ''))
                    blocks[#blocks + 1] = { type = 'picker', id = 'item', label = 'Modifier un objet', options = opts, value = cur and cur.name or '' }
                    blocks[#blocks + 1] = { type = 'form', id = 'inv.item', title = cur and ('Modifier « ' .. cur.label .. ' »') or 'Nouvel objet', cols = 2, fields = {
                        { k = 'name', type = 'text', label = 'Identifiant', required = true, maxlen = 40, pattern = '^[%w_]+$', readonly = cur ~= nil }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
                        { k = 'weight', type = 'number', label = 'Poids (g)', min = 0, max = 1000000 }, { k = 'stack', type = 'number', label = 'Pile maximale', min = 1, max = 1000 }, { k = 'kind', type = 'select', label = 'Type', opts = KINDS },
                        { k = 'usable', type = 'toggle', label = 'Utilisable' }, { k = 'hunger', type = 'number', label = 'Faim', min = -100, max = 100 }, { k = 'thirst', type = 'number', label = 'Soif', min = -100, max = 100 },
                        { k = 'stress', type = 'number', label = 'Stress', min = -100, max = 100 }, { k = 'health', type = 'number', label = 'Vie', min = -100, max = 100 }, { k = 'description', type = 'text', label = 'Description', maxlen = 160, wide = true },
                        { k = 'cloth_slot', type = 'select', label = 'Vêtement : emplacement', opts = CLOTH_OPTS, hint = 'Choisis un emplacement pour que l’objet s’enfile (Utiliser) et se voie sur le personnage.' }, { k = 'cloth_draw', type = 'number', label = 'Vêtement : modèle', min = 0, max = 999 }, { k = 'cloth_tex', type = 'number', label = 'Vêtement : texture', min = 0, max = 99 } },
                        values = cur and { cloth_slot = (parseCloth(cur.cloth) or {}).slot or '', cloth_draw = (parseCloth(cur.cloth) or {}).drawable or 0, cloth_tex = (parseCloth(cur.cloth) or {}).texture or 0, name = cur.name, label = cur.label, weight = cur.weight, stack = cur.stack, kind = cur.kind, usable = cur.usable, hunger = cur.hunger, thirst = cur.thirst, stress = cur.stress, health = cur.health, description = cur.description }
                            or { cloth_slot = '', cloth_draw = 0, cloth_tex = 0, name = '', label = '', weight = 100, stack = 20, kind = 'misc', usable = false, hunger = 0, thirst = 0, stress = 0, health = 0, description = '' },
                        submit = { action = 'inv.item.save', label = 'Enregistrer' } }
                end
                return blocks
            end },
            { id = 'stashes', label = 'Coffres', icon = 'lock', build = function()
                local list, items = {}, {}
                for _, s in ipairs(DB.q('SELECT * FROM pb_inv_stashes ORDER BY label') or {}) do
                    local n = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { 's:' .. s.id })
                    list[#list + 1] = { label = s.label, id = s.id, slots = s.slots, weight = s.weight, biz = s.biz ~= '' and s.biz or 'Public', used = n and n.n or 0,
                        actions = ctx.has('inv.edit') and { { action = 'inv.stash.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = s.id } } } or {} }
                end
                local blocks = { B.table({ id = 'st', title = 'Coffres (' .. #list .. ')', columns = { { k = 'label', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'slots', label = 'Empl.', type = 'num' }, { k = 'weight', label = 'Poids max (g)', type = 'num' }, { k = 'biz', label = 'Accès' }, { k = 'used', label = 'Emplacements pris', type = 'num' } }, rows = list, empty = "Aucun coffre : crée le premier ci-dessous." }) }
                if ctx.has('inv.edit') then blocks[#blocks + 1] = { type = 'form', id = 'inv.stash', title = 'Créer ou modifier un coffre', desc = 'Même identifiant = modification. Laisse « Entreprise » vide pour un coffre public.', cols = 2, fields = {
                    { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'slots', type = 'number', label = 'Emplacements', min = 1, max = 200 },
                    { k = 'weight', type = 'number', label = 'Poids maximal (g)', min = 1000, max = 5000000 }, { k = 'coords', type = 'coords', label = 'Position', wide = true }, { k = 'biz', type = 'text', label = 'Entreprise (identifiant, facultatif)', maxlen = 32 },
                    { k = 'min_grade', type = 'number', label = 'Grade minimal', min = 0, max = 50 }, { k = 'enabled', type = 'toggle', label = 'Actif' } },
                    values = { id = '', label = '', slots = 40, weight = 200000, coords = { x = 0, y = 0, z = 0, h = 0 }, biz = '', min_grade = 0, enabled = true }, submit = { action = 'inv.stash.save', label = 'Enregistrer' } } end
                return blocks
            end },
            { id = 'players', label = 'Joueurs', icon = 'users', perm = 'inv.give', build = function()
                local opts, rows = {}, {}
                for id, p in pairs(G.Players()) do
                    if PB.ToBool(p.row.created) then
                        local i = G.Identity(id)
                        local name = ((i.firstname or '') .. ' ' .. (i.lastname or '')) .. ' (' .. id .. ')'
                        opts[#opts + 1] = { tostring(id), name }
                        local w = Inv.Weight('p:' .. p.license)
                        rows[#rows + 1] = { name = name, weight = w, max = cfg('max_weight', 30000), items = #(DB.q('SELECT slot FROM pb_inv WHERE owner = ?', { 'p:' .. p.license }) or {}) }
                    end
                end
                local iopts = {}
                for _, d in pairs(Inv.Defs()) do iopts[#iopts + 1] = { d.name, tostring(d.label) .. '  ·  ' .. d.name } end   -- nom simplifié · nom technique
                table.sort(iopts, function(a, b) return a[2]:lower() < b[2]:lower() end)
                local function f(title, act, label) return { type = 'form', id = 'inv.' .. act, title = title, cols = 3, fields = { { k = 'player', type = 'select', label = 'Joueur', opts = opts }, { k = 'item', type = 'select', label = 'Objet', opts = iopts }, { k = 'qty', type = 'number', label = 'Quantité', min = 1, max = 1000 } },
                    values = { player = opts[1] and opts[1][1] or '', item = iopts[1] and iopts[1][1] or '', qty = 1 }, submit = { action = 'inv.' .. act, label = label, disabled = #opts == 0 } } end
                return { B.table({ id = 'pl', title = 'Sacs des joueurs en ligne', columns = { { k = 'name', label = 'Joueur' }, { k = 'items', label = 'Emplacements', type = 'num' }, { k = 'weight', label = 'Poids (g)', type = 'num' }, { k = 'max', label = 'Max (g)', type = 'num' } }, rows = rows, empty = 'Personne en ligne.' }),
                    f('Donner un objet', 'give', 'Donner'), f('Retirer un objet', 'take', 'Retirer') }
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'inventory', title = "Inventaire vu par le joueur", cfg = {} } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'inv.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('inventaire', function(R)
    local n = 0
    for _, d in pairs(Inv.Defs()) do
        n = n + 1
        R.check(d.weight >= 0 and d.stack >= 1, 'objet ' .. d.name, 'poids ou pile invalide')
    end
    R.check(n > 0, 'objets', 'aucun objet défini')
    for _, s in ipairs(DB.q('SELECT * FROM pb_inv_stashes') or {}) do
        R.check(s.slots >= 1 and s.weight >= 1, 'coffre ' .. s.id, 'capacité invalide')
        if s.biz ~= '' then R.check(G.Biz == nil or G.Biz.Get(s.biz) ~= nil, 'coffre ' .. s.id, "l'entreprise « " .. s.biz .. " » n'existe pas") end
    end
    local bad = DB.one('SELECT COUNT(*) AS n FROM pb_inv i LEFT JOIN pb_inv_items d ON d.name = i.item WHERE d.name IS NULL AND i.owner NOT LIKE ?', { 'd:%' })
    R.check(not bad or bad.n == 0, 'contenus', 'des objets référencent une définition supprimée')
end)


-- Sacs à dos et surpoids -------------------------------------------------------------------------------------------------------------------
-- Un sac porté (case « Sac ») ajoute du poids au sac du joueur. Trop chargé : il avance au pas et ne peut plus agir (le client applique).
local function bagKg()
    local t = {}
    for _, line in ipairs(cfg('bags', {}) or {}) do local n, kg = tostring(line):match('^([%w_]+)|(%d+)$') if n then t[n] = tonumber(kg) end end
    return t
end
Inv.BagKg = bagKg
local function srcOfLicense(lic) for src, p in pairs(G.Players()) do if p.license == lic then return src end end end
function Inv.BagBonusFor(lic)
    local src = srcOfLicense(lic)
    local item = src and worn[src] and worn[src].bag
    return item and math.floor((bagKg()[item] or 0) * 1000) or 0
end
-- Réapparition à l'hôpital (Écran de mort › Objets perdus) : le sac est vidé, sauf les objets liés, les vêtements et la liste à garder.
-- mode = 'weapons' (armes et munitions seulement) ou 'all'. Renvoie le nombre d'objets perdus.
function Inv.WipeOnDeath(src, mode, keepList)
    local o = playerOwner(src)
    if not o or (mode ~= 'weapons' and mode ~= 'all') then return 0 end
    local keep = {}
    for _, k in ipairs(keepList or {}) do keep[tostring(k):lower()] = true end
    local lost = 0
    for slot, s in pairs(Inv.Contents(o)) do
        local d = Inv.Def(s.item)
        local kind = d and d.kind or 'misc'
        local weapon = kind == 'weapon' or kind == 'ammo' or tostring(s.item):sub(1, 7) == 'weapon_'
        local drop = not bound[s.item] and not keep[s.item] and kind ~= 'clothes' and (mode == 'all' or weapon)
        if drop then DB.exec('DELETE FROM pb_inv WHERE owner = ? AND slot = ?', { o, slot }) lost = lost + s.qty end
    end
    if lost > 0 then push(src) end
    return lost
end
local overState = {}   -- src -> true si trop chargé
function Inv.IsOver(src) return overState[src] == true end
function Inv.LoadCheck(owner)
    if type(owner) ~= 'string' or owner:sub(1, 2) ~= 'p:' then return end
    local src = srcOfLicense(owner:sub(3))
    if not src then return end
    local _, cap = Inv.Capacity(owner)
    local w = Inv.Weight(owner)
    local over = w > cap
    if (overState[src] == true) ~= over then
        overState[src] = over or nil
        TriggerClientEvent('pb:g:inv:load', src, over)
        if over then G.Notify(src, { type = 'warn', title = 'Trop chargé', text = ('%.1f / %.1f kg : tu avances au pas et ne peux plus agir. Équipe un sac ou allège-toi.'):format(w / 1000, cap / 1000) }) end
    end
end
AddEventHandler('playerDropped', function() overState[source] = nil end)
table.insert(G.beginHooks, function(src) SetTimeout(5000, function() if G.Get(src) then Inv.LoadCheck(playerOwner(src)) end end) end)
do  -- le poids se revérifie après chaque changement du sac d'un joueur
    local add, rem, mov, wear = Inv.Add, Inv.Remove, Inv.Move, Inv.Wear
    Inv.Add = function(owner, ...) local a, b = add(owner, ...) Inv.LoadCheck(owner) return a, b end
    local function wornCheckOwner(owner)   -- l'objet porté a quitté le sac : on le retire
        local lic = tostring(owner or ''):match('^p:(.+)$')
        if not lic then return end
        for s in pairs(G.Players()) do local p = G.Get(s) if p and p.license == lic then Inv.CheckWorn(s) end end
    end
    Inv.Remove = function(owner, ...) local a, b = rem(owner, ...) wornCheckOwner(owner) Inv.LoadCheck(owner) return a, b end
    Inv.Move = function(src, fo, fs, to, ...) local a, b = mov(src, fo, fs, to, ...) wornCheckOwner(fo) Inv.LoadCheck(fo) Inv.LoadCheck(to) return a, b end
    Inv.Wear = function(src, ...) local a, b = wear(src, ...) Inv.LoadCheck(playerOwner(src)) if Inv.Push then Inv.Push(src) end return a, b end
end

-- Objets « vêtement » prêts à l'emploi (sacs, masques) : créés une fois, modifiables ensuite dans le panel
function Inv.EnsureCloth(def)
    if Inv.Def(def.name) then return true end
    DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description, cloth, image) VALUES (?, ?, ?, 1, ?, 1, ?, ?, ?)',
        { def.name, def.label, def.weight or 500, 'clothes', def.description or '', def.cloth, def.image or '' })
    loadDefs()
    return Inv.Def(def.name) ~= nil
end
Inv.BAGS = {
    { name = 'bag_small', label = 'Petit sac (+10 kg)', cloth = 'bag:44:0', weight = 600 },
    { name = 'bag_medium', label = 'Sac moyen (+20 kg)', cloth = 'bag:45:0', weight = 900 },
    { name = 'bag_large', label = 'Grand sac (+30 kg)', cloth = 'bag:40:0', weight = 1200 },
    { name = 'bag_xl', label = 'Très grand sac (+40 kg)', cloth = 'bag:41:0', weight = 1500 },
    { name = 'bag_tactical', label = 'Sac tactique (+50 kg)', cloth = 'bag:82:0', weight = 1800 },
}
Inv.MASKS = {}
for i, d in ipairs({ 1, 2, 3, 4, 5, 6, 14, 16, 26, 28, 35, 51, 52, 54, 57, 95 }) do
    Inv.MASKS[#Inv.MASKS + 1] = { name = 'mask_' .. d, label = 'Masque modèle ' .. i, cloth = 'mask:' .. d .. ':0', weight = 200 }
end
CreateThread(function()
    while not PB.IsReady do Wait(500) end
    for _, b in ipairs(Inv.BAGS) do b.description = 'Équipe-le (case Sac) pour porter plus.' Inv.EnsureCloth(b) end
    for _, m in ipairs(Inv.MASKS) do Inv.EnsureCloth(m) end
end)

-- 1.2.3 : retour à l'apparence d'origine de l'inventaire (couleur du serveur, décor assombri, flou), une seule fois,
-- pour les serveurs passés par la 1.2.2 qui l'avait rendu neutre et transparent. Réglable ensuite dans le panel.
PB.OnReady(function()
    -- v1.2.37 : un seul inventaire (Shadow Studio V2)
    if tostring(PB.Cfg.Get('inv', 'style', 'e4')) ~= 'e4' then PB.Cfg.Set('inv', 'style', 'e4', nil, 'Inventaire : Shadow Studio V2') end
    if PB.Cfg.Get('inv', 'look_restore_v1', false) ~= true then
        if PB.Cfg.Get('inv', 'color_mode', 'server') == 'neutral' then PB.Cfg.Set('inv', 'color_mode', 'server', nil, "Inventaire : apparence d'origine") end
        if PB.Cfg.Get('inv', 'glass_v1', false) == true then
            PB.Cfg.Set('inv', 'ped_dim', 88, nil, "Inventaire : apparence d'origine")
            PB.Cfg.Set('inv', 'blur', true, nil, "Inventaire : apparence d'origine")
        end
        PB.Cfg.Set('inv', 'look_restore_v1', true, nil, 'Migration')
    end
    -- (v1.2.43) inventaire transparent pour de vrai : le voile noir (88 %) et le flou étaient dessinés par le JEU derrière l'interface,
    -- donc le CSS transparent ne changeait rien. Une seule fois ; réglable ensuite dans le panel (Inventaire).
    if PB.Cfg.Get('inv', 'look_clear_v2', false) ~= true then
        PB.Cfg.Set('inv', 'ped_dim', 12, nil, 'Inventaire transparent')
        PB.Cfg.Set('inv', 'blur', false, nil, 'Inventaire transparent')
        PB.Cfg.Set('inv', 'look_clear_v2', true, nil, 'Migration')
    end
end)

-- (v1.2.40) Tenues achetées en magasin de vêtements : chaque pièce changée devient un objet « vêtement » dans le sac, déjà enfilé,
-- avec la photo du magasin (homme ou femme selon le personnage). Re-cliquer dessus dans l'inventaire l'enlève / la remet.
local OUTFIT_COMPS = { [1] = 'mask', [4] = 'legs', [6] = 'shoes', [7] = 'chain', [8] = 'shirt', [9] = 'vest', [11] = 'top' }
local OUTFIT_PROPS = { [0] = 'hat', [1] = 'glasses', [2] = 'ears', [6] = 'watch', [7] = 'bracelet' }
local SLOT_NAME = { mask = 'Masque', legs = 'Pantalon', shoes = 'Chaussures', chain = 'Collier', shirt = 'Sous-haut', vest = 'Gilet', top = 'Haut', hat = 'Chapeau', glasses = 'Lunettes', ears = 'Boucles d\'oreilles', watch = 'Montre', bracelet = 'Bracelet' }
local function compOf(app, id) local c = app and app.comps and app.comps[id + 1] return c and (tonumber(c.d) or 0) or 0, c and (tonumber(c.t) or 0) or 0 end
local function propOf(app, id)
    for _, pr in ipairs(app and app.props or {}) do if tonumber(pr.id) == id then return tonumber(pr.d) or -1, tonumber(pr.t) or 0 end end
    return -1, 0
end
function Inv.GiveOutfit(src, old, new, sex)
    local p, owner = G.Get(src), playerOwner(src)
    if not p or not owner or type(new) ~= 'table' then return 0 end
    local female = sex == 'f' or sex == 'female'   -- même règle que le modèle du personnage (character.lua)
    local sx = female and 'female' or 'male'
    local changed = {}
    for id, slot in pairs(OUTFIT_COMPS) do
        local d, t = compOf(new, id) local od, ot = compOf(old, id)
        if (d ~= od or t ~= ot) and d ~= CLOTH_SLOTS[slot][3] then changed[#changed + 1] = { slot = slot, k = 'c', id = id, d = d, t = t } end
    end
    for id, slot in pairs(OUTFIT_PROPS) do
        local d, t = propOf(new, id) local od, ot = propOf(old, id)
        if (d ~= od or t ~= ot) and d >= 0 then changed[#changed + 1] = { slot = slot, k = 'p', id = id, d = d, t = t } end
    end
    local given, full = 0, false
    worn[src] = worn[src] or {}
    for _, c in ipairs(changed) do
        local item = ('cl_%s_%s_%d_%d'):format(female and 'f' or 'm', c.slot, c.d, c.t)
        local img = ('img/clothes/%s_%s%d_%d.webp'):format(sx, c.k, c.id, c.d)
        Inv.EnsureCloth({ name = item, label = ('%s n°%d%s'):format(SLOT_NAME[c.slot], c.d + 1, c.t > 0 and (' · variante ' .. (c.t + 1)) or ''), weight = 300,
            cloth = ('%s:%d:%d'):format(c.slot, c.d, c.t), image = img, description = 'Acheté en magasin de vêtements. Utilise-le pour l\'enlever ou le remettre.' })
        local have = Inv.Count(owner, item) > 0
        if not have then
            local can = true
            if Inv.CanCarry then can = Inv.CanCarry(owner, item, 1) end
            if can and Inv.Add(owner, item, 1) then have = true given = given + 1 else full = true end
        end
        if have then
            worn[src][c.slot] = item
            DB.exec('REPLACE INTO pb_inv_worn (license, slot, item) VALUES (?, ?, ?)', { p.license, c.slot, item })
        end
    end
    if full then G.Notify(src, { type = 'warn', title = 'Inventaire', text = "Sac plein : certaines pièces sont portées mais pas rangées dans l'inventaire." }) end
    if Inv.Push then pcall(Inv.Push, src) end
    return given
end

-- (v1.2.42) Gilets pare-balles : des vêtements (case Gilet) avec une résistance. Enfilé, le gilet donne son blindage ;
-- retiré, le blindage restant est gardé ; à 0 il est détruit. Tant qu'il tient, une balle dans la tête ne tue pas d'un coup.
PB.Migrate('396_vest_hp', 'Gilets pare-balles : résistance restante', {
    [[CREATE TABLE IF NOT EXISTS pb_vest_hp (license VARCHAR(64) NOT NULL PRIMARY KEY, item VARCHAR(40) NOT NULL, hp INT NOT NULL DEFAULT 0)]],
})
Inv.VESTS = {
    { name = 'gilet_leger', label = 'Gilet pare-balles léger', cloth = 'vest:1:0', weight = 2500, armor = 50 },
    { name = 'gilet_lourd', label = 'Gilet pare-balles lourd', cloth = 'vest:16:0', weight = 4500, armor = 100 },
}
local VEST = {}
for _, v in ipairs(Inv.VESTS) do VEST[v.name] = v end
local function vestOf(src) local it = worn[src] and worn[src].vest return it and VEST[it] and it or nil end
local vestOn = {}   -- src -> objet du gilet enfilé (côté client)
local function vestUpdate(src)
    local p = G.Get(src)
    if not p then return end
    local item = vestOf(src)
    if item then
        local r = DB.one('SELECT item, hp FROM pb_vest_hp WHERE license = ?', { p.license })
        local hp = (r and r.item == item) and tonumber(r.hp) or VEST[item].armor
        if not r or r.item ~= item then DB.exec('REPLACE INTO pb_vest_hp (license, item, hp) VALUES (?, ?, ?)', { p.license, item, hp }) end
        vestOn[src] = item
        TriggerClientEvent('pb:g:inv:vest', src, PB.Json({ on = true, hp = hp, max = VEST[item].armor, label = VEST[item].label }))
    elseif vestOn[src] then
        vestOn[src] = nil
        TriggerClientEvent('pb:g:inv:vest', src, PB.Json({ on = false }))
    end
end
Inv.VestUpdate = vestUpdate
local prevWear = Inv.Wear
Inv.Wear = function(src, item, cl)
    local a, b = prevWear(src, item, cl)
    if cl and cl.slot == 'vest' then vestUpdate(src) end
    return a, b
end
local prevReset = Inv.ResetWorn
Inv.ResetWorn = function(src) prevReset(src) vestUpdate(src) end
-- le client renvoie le blindage restant (toutes les quelques secondes et en retirant le gilet)
RegisterNetEvent('pb:g:inv:vesthp', function(hp)
    local src = source
    local p = G.Get(src)
    local item = vestOn[src]
    if not p or not item then return end
    hp = math.floor(tonumber(hp) or 0)
    local r = DB.one('SELECT hp FROM pb_vest_hp WHERE license = ? AND item = ?', { p.license, item })
    if not r then return end
    hp = math.max(0, math.min(hp, tonumber(r.hp) or 0))   -- jamais plus que ce qu'il restait (pas de recharge envoyée par le client)
    if hp > 0 then DB.exec('UPDATE pb_vest_hp SET hp = ? WHERE license = ?', { hp, p.license }) return end
    -- gilet détruit : retiré et enlevé du sac
    DB.exec('DELETE FROM pb_vest_hp WHERE license = ?', { p.license })
    if worn[src] then worn[src].vest = nil end
    DB.exec('DELETE FROM pb_inv_worn WHERE license = ? AND slot = ?', { p.license, 'vest' })
    TriggerClientEvent('pb:g:inv:wear', src, PB.Json({ list = { { slot = 'vest', kind = 'c', idx = 9, none = 0, on = false } } }))
    Inv.Remove('p:' .. p.license, item, 1)
    vestOn[src] = nil
    TriggerClientEvent('pb:g:inv:vest', src, PB.Json({ on = false, broken = true }))
    G.Notify(src, { type = 'warn', title = 'Gilet pare-balles', text = 'Ton gilet est détruit.' })
    if Inv.Push then pcall(Inv.Push, src) end
end)
table.insert(G.beginHooks, function(src) SetTimeout(4500, function() vestUpdate(src) end) end)
AddEventHandler('playerDropped', function() vestOn[source] = nil end)
CreateThread(function()
    while not PB.IsReady do Wait(500) end
    for _, v in ipairs(Inv.VESTS) do Inv.EnsureCloth({ name = v.name, label = v.label, cloth = v.cloth, weight = v.weight,
        description = ('Blindage %d. Équipe-le (case Gilet) ; il protège d\'une balle dans la tête tant qu\'il tient.'):format(v.armor) }) end
end)
