-- Menu staff (touche F10) : sanctions, téléportations, soins, argent, véhicules, monde, signalements.
-- Le serveur décide de tout : chaque action vérifie la permission, le mode service, la hiérarchie (on ne touche pas à un rang égal ou supérieur),
-- puis écrit dans les logs. Le client ne fait qu'exécuter ce que le serveur a autorisé (déplacement, effets visuels, vol).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local S = {}
G.Staff = S

PB.Migrate('060_staff', 'Menu staff : sanctions et signalements', {
    [[CREATE TABLE IF NOT EXISTS pb_sanctions (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', kind VARCHAR(8) NOT NULL, reason VARCHAR(200) NOT NULL DEFAULT '',
        by_name VARCHAR(64) NOT NULL DEFAULT '', by_license VARCHAR(64) NOT NULL DEFAULT '', created INT NOT NULL, expires INT NOT NULL DEFAULT 0,
        revoked TINYINT(1) NOT NULL DEFAULT 0, revoked_by VARCHAR(64) NOT NULL DEFAULT '', ids TEXT NULL, PRIMARY KEY (id), KEY k_lic (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_reports (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', text VARCHAR(300) NOT NULL, status VARCHAR(8) NOT NULL DEFAULT 'open',
        claimed_by VARCHAR(64) NOT NULL DEFAULT '', created INT NOT NULL, closed_at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_st (status))]],
})
PB.Migrate('061_staff_notes', 'Menu staff : notes privées sur les joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_staff_notes (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', text VARCHAR(300) NOT NULL,
        by_name VARCHAR(64) NOT NULL DEFAULT '', created INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license))]],
})

for _, x in ipairs({
    { 'staff.menu', 'Ouvrir le menu staff (F10)', false }, { 'staff.players', 'Voir les infos et sanctions des joueurs', false },
    { 'staff.teleport', 'Se téléporter / téléporter un joueur', false }, { 'staff.heal', 'Soigner et réanimer', false }, { 'staff.freeze', 'Geler un joueur', false },
    { 'staff.spectate', 'Observer un joueur', false }, { 'staff.money', "Donner ou retirer de l'argent", true }, { 'staff.items', 'Donner des objets', true },
    { 'staff.job', "Changer l'entreprise d'un joueur", true }, { 'staff.vehicle', 'Véhicules (créer, réparer, supprimer)', false },
    { 'staff.warn', 'Avertir et écrire à un joueur', false }, { 'staff.kick', 'Expulser un joueur', true }, { 'staff.ban', 'Bannir un joueur', true },
    { 'staff.unban', 'Lever un bannissement', true }, { 'staff.world', "Météo et heure", false }, { 'staff.announce', 'Annonces à tous les joueurs', false },
    { 'staff.self', 'Outils personnels (noclip, invisibilité, invincibilité…)', false }, { 'staff.reports', 'Gérer les signalements', false },
    { 'staff.maintenance', 'Activer la maintenance depuis le menu', true },
    { 'staff.mute', 'Réduire un joueur au silence (chat)', false }, { 'staff.whisper', 'Chuchoter à un joueur (lui seul entend)', false }, { 'staff.notes', 'Notes privées sur les joueurs', false },
    { 'staff.inventory', "Voir ou vider l'inventaire d'un joueur", true }, { 'staff.restart', 'Redémarrer le serveur (avec annonce) depuis le menu', true }, { 'staff.givecar', 'Donner un véhicule à un joueur', true },
}) do P.Register(x[1], x[2], 'staff', x[3]) end

P.Register('staff.undo', "Annuler une action d'un membre du staff (journal)", 'staff', true)
P.Register('staff.journal', "Voir le journal des actions du staff", 'staff', false)
PB.Migrate('139_staff_journal', 'Menu staff : journal des actions et annulation', {
    [[CREATE TABLE IF NOT EXISTS pb_staff_journal (
        id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, actor_license VARCHAR(64) NOT NULL DEFAULT '', actor_name VARCHAR(64) NOT NULL DEFAULT '', action VARCHAR(32) NOT NULL,
        target_license VARCHAR(64) NOT NULL DEFAULT '', target_name VARCHAR(80) NOT NULL DEFAULT '', detail VARCHAR(300) NOT NULL DEFAULT '', undo TEXT NULL,
        undone INT NOT NULL DEFAULT 0, undone_by VARCHAR(64) NOT NULL DEFAULT '', PRIMARY KEY (id), KEY k_at (at), KEY k_actor (actor_license))]],
})
PB.Cfg.Define('staff', {
    whisper_voice = false, duty_god = false,
    enabled = true, key = 'F10', bind_noclip = 'F3', bind_tpm = '', bind_back = '', bind_god = '', bind_invisible = '', bind_names = '', bind_heal = '', require_duty = true, duty_ped_on = false, duty_peds = {}, duty_block = false, reports_on = true, report_cooldown = 60, money_max = 1000000, item_max = 500,
    order = {}, hide = {}, hud_on = true, hud_items = { 'online', 'staff', 'reports', 'bda' }, bda_channel = '', bda_label = 'Joueurs en BDA', hud_style = 'bar', hud_x = 1.2, hud_y = 30, hud_top = 0.8,
    ban_presets = { '1 heure|60', '1 jour|1440', '3 jours|4320', '7 jours|10080', '30 jours|43200', 'Définitif|0' },
    announce_presets = { 'Redémarrage dans 10 minutes|Le serveur redémarre dans 10 minutes. Pensez à ranger vos véhicules.', 'Rappel du règlement|Merci de respecter le règlement du serveur.', 'Événement|Un événement commence bientôt, rendez-vous en ville.' },
    spawn_presets = { 'adder', 'sultan', 'panto', 'blista', 'police', 'ambulance', 'bmx' },
})
local function cfg(k, d) return PB.Cfg.Get('staff', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n or 120)) end
local function now() return os.time() end

local CATS = {
    { id = 'players', label = 'Gestion des joueurs', icon = 'users', perm = 'staff.players' },
    { id = 'self', label = 'Gestion personnelle', icon = 'bolt', perm = 'staff.self' },
    { id = 'vehicles', label = 'Gestion des véhicules', icon = 'engine', perm = 'staff.vehicle' },
    { id = 'server', label = 'Gestion du serveur', icon = 'globe', perm = 'staff.world' },
    { id = 'reports', label = 'Gestion des reports', icon = 'help', perm = 'staff.reports' },
    { id = 'sanctions', label = 'Gestion des sanctions', icon = 'shield', perm = 'staff.unban' },
    { id = 'builder', label = 'Builder (créer et placer)', icon = 'map', perm = 'carte.place' },
    { id = 'props', label = 'Props permanents', icon = 'box', perm = 'staff.props' },
    { id = 'panel', label = 'Options supplémentaires', icon = 'sliders', perm = 'panel.open' },
}
S.CATS = CATS

local duty, selfState = {}, {}
function S.SelfOn(src, f) return selfState[src] ~= nil and selfState[src][f] ~= nil and selfState[src][f] ~= false end
function S.OnDuty(src) return duty[tonumber(src) or -1] == true end
-- Service : accès joueur coupés (réglage « Bloquer les accès joueur en service ») — indépendant du ped de service.
function S.Locked(src) return duty[tonumber(src) or -1] == true and PB.Cfg.Get('staff', 'duty_block', false) == true end
function G.DutyGate(src)
    if S.Locked(src) then
        G.Notify(src, { type = 'warn', title = 'En service', text = "Accès joueur désactivé pendant le service staff (inventaire, métier, téléphone, banque…). Quitte le service pour les utiliser." })
        return true
    end
    return false
end
-- Ped de service : un modèle par grade (lignes « grade|modèle »), indépendant du blocage.
function S.DutyPeds()
    local out = {}
    for _, line in ipairs(PB.Cfg.Get('staff', 'duty_peds', {}) or {}) do
        local g, m = tostring(line):match('^([%w_%-]+)|([%w_]+)$')
        if g then out[g] = m end
    end
    return out
end
function S.DutyPedOf(src)
    if PB.Cfg.Get('staff', 'duty_ped_on', false) ~= true then return nil end
    local grade = P.GetGrade(src)
    return grade and S.DutyPeds()[grade] or nil
end
local function reg(src) return G.Get(src) end
local function rpName(src)
    local id = G.Identity(src)
    local n = id and ((id.firstname or '') .. ' ' .. (id.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') or ''
    if n == '' then n = GetPlayerName(src) or ('Joueur ' .. tostring(src)) end
    return n
end
local function level(src) return P.Level(src) end
local function outranks(src, t) return src ~= t and level(src) > level(t) end
S.Outranks, S.RpName = outranks, rpName

local function audit(src, action, target, data) PB.Audit.Log('staff', action, src, target and tostring(target) or '', nil, nil, data) end
local function notify(src, kind, text) G.Notify(src, { type = kind, title = 'Menu staff', text = text }) end

-- Sanctions ----------------------------------------------------------------------------------------------------------------------------
local function identsOf(src)
    local t = {}
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if not id:match('^ip:') then t[#t + 1] = id end end
    return t
end
local function fmtDate(ts) return os.date('%d/%m/%Y %H:%M', ts) end

function S.BanOf(src)
    local ids = identsOf(src)
    local t = now()
    for _, id in ipairs(ids) do
        local r = DB.one("SELECT id, reason, expires, by_name FROM pb_sanctions WHERE kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) AND (license = ? OR ids LIKE ?) ORDER BY id DESC LIMIT 1", { t, id, '%"' .. id .. '"%' })
        if r then return r end
    end
    return nil
end
local function banText(r)
    local fin = (tonumber(r.expires) or 0) == 0 and 'définitif' or ('jusqu\'au ' .. fmtDate(r.expires))
    return ('Tu es banni (%s). Motif : %s.'):format(fin, r.reason ~= '' and r.reason or 'non précisé')
end

local function addSanction(kind, license, name, reason, actorSrc, minutes, ids)
    local a = PB.Actor(actorSrc)
    return DB.insert('INSERT INTO pb_sanctions (license, name, kind, reason, by_name, by_license, created, expires, ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { license, clean(name, 64), kind, clean(reason, 200), a.name:sub(1, 64), a.license:sub(1, 64), now(), (minutes and minutes > 0) and (now() + minutes * 60) or 0, PB.Json(ids or {}) })
end

S.BanText = banText
S.AddSanction = addSanction
-- Le parcours serveur (flow.lua) appelle S.BanOf en premier : un seul des deux « deferrals.done » compte, il faut donc que le refus passe avant l'admission.
AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    local r = S.BanOf(src)
    if not r then return end
    deferrals.defer()
    Wait(0)
    deferrals.done(banText(r))
end)
AddEventHandler('playerJoining', function()
    local src = source
    local r = S.BanOf(src)
    if r then PB.Drop(src, 'ban', 'ban', 'Banni : ' .. tostring(r.reason or ''), ('Ban n°%s actif détecté à l\'arrivée en jeu.'):format(tostring(r.id or '?')), nil, banText(r)) end
end)

-- Informations sur les joueurs ---------------------------------------------------------------------------------------------------------
local function playerList()
    local out = {}
    for src, p in pairs(G.Players()) do
        out[#out + 1] = { id = src, uid = G.UidOf(src), name = rpName(src), ping = (GetPlayerPing and GetPlayerPing(src)) or 0, staff = level(src) > 0 or nil, dead = PB.ToBool(p.row.dead) or nil,
            jailed = (G.Justice and G.Justice.State and G.Justice.State(src)) and true or nil, vip = (G.Vip and G.Vip.Is(src)) or nil }
    end
    table.sort(out, function(a, b) return (a.uid or a.id) < (b.uid or b.id) end)
    return out
end
-- (v1.2.43) montants au format du serveur (« 4 120 $ », avant « $4120 »)
local function fmtMoney(n) return PB.Money(n) end
function S.InfoRows(t)
    local p = G.Get(t)
    if not p then return nil end
    local job = G.Biz and G.Biz.Job and G.Biz.Job(t)
    local n = DB.one("SELECT COUNT(*) AS n FROM pb_sanctions WHERE license = ? AND kind IN ('warn','kick','ban')", { p.license })
    local lic = tostring(p.license):gsub('^license:', '')
    return {
        { 'Nom RP', rpName(t) }, { 'Nom FiveM', (GetPlayerName and GetPlayerName(t)) or G.Tag(t) }, { 'ID permanent', G.Tag(t) }, { 'ID de connexion', tostring(t) },
        { 'Emploi', job and job.label or 'Sans emploi' }, { 'Grade', job and (job.gradeLabel or '') ~= '' and tostring(job.gradeLabel) or '—' },
        { 'Argent', fmtMoney(p.row.cash) }, { 'Banque', fmtMoney(p.row.bank) },
        { 'Ping', tostring((GetPlayerPing and GetPlayerPing(t)) or 0) .. ' ms' }, { 'Sanctions', tostring(n and n.n or 0) }, { 'Licence', '…' .. lic:sub(-8) },
    }
end
function S.Info(src, t)
    local p = G.Get(t)
    if not p then return nil end
    local job = G.Biz and G.Biz.Job and G.Biz.Job(t)
    local n = DB.one("SELECT COUNT(*) AS n FROM pb_sanctions WHERE license = ? AND kind IN ('warn','kick','ban')", { p.license })
    local lic = tostring(p.license):gsub('^license:', '')
    return ('%s (%s) · espèces %s · banque %s · %s · ping %s ms · %s sanction(s) · licence …%s'):format(rpName(t), G.Tag(t), PB.Money(p.row.cash), PB.Money(p.row.bank),
        job and (job.label .. ' ' .. tostring(job.gradeLabel or '')) or 'sans emploi', tostring((GetPlayerPing and GetPlayerPing(t)) or 0), tostring(n and n.n or 0), lic:sub(-8))
end

-- Actions -----------------------------------------------------------------------------------------------------------------------------
local ACT = {}
S.ACT = ACT
local function fx(t, kind, data) TriggerClientEvent('pb:g:staff:fx', t, kind, PB.Json(data or {})) end
local function coordsOf(t)
    local ped = GetPlayerPed(t)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return nil end
    return { x = c.x, y = c.y, z = c.z }
end
local function amountOf(v, max)
    local n = math.floor(tonumber(v) or 0)
    if n == 0 or math.abs(n) > max then return nil end
    return n
end
local function def(id, perm, o) o.perm = perm ACT[id] = o end
S.Def = def
S.SpecExtra = {}

-- cibles (joueur choisi)
def('info', 'staff.players', { target = true, run = function(src, t)
    local rows = S.InfoRows(t)
    if not rows then return false, 'Joueur introuvable.' end
    G.Info(src, { title = 'Informations', rows = rows, secs = 20 })
    return true
end })
-- Recherche unique : joueur (nom, prénom, ID permanent, licence), véhicule (plaque), numéro de téléphone
def('search', 'staff.players', { run = function(src, _, p)
    local q = tostring(p.q or ''):gsub('[%c%%_]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, 48)
    if #q < 2 then return false, 'Tape au moins 2 caractères.' end
    local rows, seen = {}, {}
    local function add(k, v) if #rows < 16 then rows[#rows + 1] = { k, v } end end
    -- ID permanent : joueur en ligne, sinon le compte hors ligne (et ses personnages)
    local uid = tonumber(q:match('^#?(%d+)$') or '')
    local id = uid and G.SrcOfUid(uid)
    if id then add('Joueur #' .. uid, rpName(id) .. ' · ' .. (GetPlayerName(id) or '')) seen[G.Get(id).license] = true
    elseif uid and G.Uid then
        local lic = G.Uid.LicenseOf(uid)
        if lic then
            for _, r in ipairs(DB.q("SELECT license, firstname, lastname, last_seen FROM pb_players WHERE license = ? OR license LIKE ? ORDER BY license LIMIT 5", { lic, lic .. '#%' }) or {}) do
                seen[r.license] = true
                add('Hors ligne #' .. uid, (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) .. ' · vu le ' .. os.date('%d/%m', tonumber(r.last_seen) or 0) .. ' · ' .. r.license)
            end
        end
    end
    -- joueurs connectés : nom FiveM ou nom RP
    local ql = q:lower()
    for s, pl in pairs(G.Players()) do
        if not seen[pl.license] and (tostring(GetPlayerName(s) or ''):lower():find(ql, 1, true) or rpName(s):lower():find(ql, 1, true)) then
            seen[pl.license] = true
            add('En ligne ' .. G.Tag(s), rpName(s) .. ' · ' .. (GetPlayerName(s) or ''))
        end
    end
    local like = '%' .. q .. '%'
    for _, r in ipairs(DB.q("SELECT license, firstname, lastname, cash, bank, last_seen FROM pb_players WHERE firstname LIKE ? OR lastname LIKE ? OR license LIKE ? OR (firstname LIKE ? AND lastname LIKE ?) ORDER BY last_seen DESC LIMIT 8",
        { like, like, like, '%' .. (q:match('^(%S+)') or '') .. '%', '%' .. (q:match('(%S+)$') or '') .. '%' }) or {}) do
        if not seen[r.license] then
            seen[r.license] = true
            local online
            for s, pl in pairs(G.Players()) do if pl.license == r.license then online = s end end
            add('Personnage', ((r.firstname or '') .. ' ' .. (r.lastname or '')) .. (online and (' · en ligne ' .. G.Tag(online)) or (' · vu le ' .. os.date('%d/%m', tonumber(r.last_seen) or 0))) .. ' · $' .. tostring(r.cash) .. ' / $' .. tostring(r.bank))
        end
    end
    for _, v in ipairs(DB.q('SELECT v.plate, v.label, v.model, p.firstname, p.lastname FROM pb_vehicles v LEFT JOIN pb_players p ON p.license = v.license WHERE v.plate LIKE ? LIMIT 6', { '%' .. q:upper() .. '%' }) or {}) do
        add('Véhicule ' .. v.plate, (v.label ~= '' and v.label or v.model) .. ' · à ' .. (((v.firstname or '') .. ' ' .. (v.lastname or '')):gsub('^%s+', '') ~= '' and ((v.firstname or '') .. ' ' .. (v.lastname or '')) or 'personne'))
    end
    if q:match('^%d%d%d%-?%d%d%d%d$') then
        local num = q:match('^%d%d%d%-') and q or (q:sub(1, 3) .. '-' .. q:sub(4))
        local r = DB.one('SELECT n.number, p.firstname, p.lastname FROM pb_phone_numbers n LEFT JOIN pb_players p ON p.license = n.license WHERE n.number = ?', { num })
        if r then add('Téléphone ' .. r.number, ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) end
    end
    if #rows == 0 then return false, 'Aucun résultat pour « ' .. q .. ' ».' end
    G.Info(src, { title = 'Recherche : ' .. q, rows = rows, secs = 30 })
    return true
end })
def('goto', 'staff.teleport', { target = true, run = function(src, t)
    local c = coordsOf(t) if not c then return false, 'Position du joueur illisible.' end
    fx(src, 'tp', c) return true, 'Téléporté près de ' .. rpName(t) .. '.'
end })
def('bring', 'staff.teleport', { target = true, rank = true, run = function(src, t)
    local c = coordsOf(src) if not c then return false, 'Ta position est illisible.' end
    fx(t, 'tp', c) notify(t, 'info', 'Un membre du staff te téléporte.') return true, rpName(t) .. ' a été amené.'
end })
def('heal', 'staff.heal', { target = true, run = function(src, t)
    G.Revive(t) G.AddStatus(t, 'hunger', 100) G.AddStatus(t, 'thirst', 100) G.AddStatus(t, 'stress', -100)
    fx(t, 'heal') notify(t, 'success', 'Un membre du staff t\'a soigné.') return true, rpName(t) .. ' est soigné.'
end })
def('revive', 'staff.heal', { target = true, run = function(src, t) G.Revive(t) fx(t, 'heal') notify(t, 'success', 'Un membre du staff t\'a réanimé.') return true, rpName(t) .. ' est réanimé.' end })
def('freeze', 'staff.freeze', { target = true, rank = true, run = function(src, t)
    selfState[t] = selfState[t] or {}
    local on = not selfState[t].frozen
    selfState[t].frozen = on or nil
    fx(t, 'freeze', { on = on }) return true, rpName(t) .. (on and ' est gelé.' or ' est libéré.')
end })
-- Observation : ce que le joueur observé a fait ces 15 dernières minutes (argent, objets, factures, sanctions…), à côté du menu
local function recentOf(src, t)
    local p = G.Get(t)
    if not p or not (G.Vigil and G.Vigil.Timeline) then return end
    local since, rows = os.time() - 900, {}
    local ok, list = pcall(G.Vigil.Timeline, p.license, 40)
    for _, e in ipairs(ok and list or {}) do
        if (e.at or 0) >= since and #rows < 14 then rows[#rows + 1] = { os.date('%H:%M', e.at), tostring(e.text or ''):sub(1, 90) } end
    end
    if #rows == 0 then rows[1] = { '15 min', 'Rien de notable' } end
    G.Info(src, { title = 'Récemment · ' .. rpName(t), rows = rows, secs = 40 })
end
def('spectate', 'staff.spectate', { target = true, run = function(src, t)
    if t == src then return false, 'Choisis un autre joueur.' end
    selfState[src] = selfState[src] or {}
    local on = selfState[src].spectate ~= t
    selfState[src].spectate = on and t or nil
    local list = {}
    for id in pairs(G.Players()) do if id ~= src then list[#list + 1] = id end end
    table.sort(list)
    fx(src, 'spectate', { on = on, target = t, pos = on and coordsOf(t) or nil, name = rpName(t), list = list })
    if on then recentOf(src, t) end
    return true, on and ('Tu observes ' .. rpName(t) .. '. ← → : joueur suivant / précédent · Retour : arrêter.') or 'Observation terminée.'
end })
-- spectateur : passer au joueur suivant / précédent sans repasser par le menu
RegisterNetEvent('pb:g:staff:specnext', function(t)
    local src = source
    t = tonumber(t)
    if not P.Has(src, 'staff.spectate') or not t or t == src or not G.Get(t) then return end
    selfState[src] = selfState[src] or {}
    selfState[src].spectate = t
    fx(src, 'spectate', { on = true, target = t, pos = coordsOf(t), name = rpName(t), switch = true })
    recentOf(src, t)
end)
def('message', 'staff.warn', { target = true, inputs = { { k = 'reason', label = 'Message', maxlen = 150 } }, run = function(src, t, p)
    local m = clean(p.reason, 150) if m == '' then return false, 'Message vide.' end
    G.Notify(t, { type = 'warn', title = 'Message du staff', text = m, duration = 12000 }) return true, 'Message envoyé.'
end })
-- Chuchoter : le staff parle à UN joueur, personne d'autre n'est dérangé (scènes RP préservées).
-- Texte : message discret, visible par lui seul. Voix : appel privé pma-voice entre le staff et le joueur, seulement si cette ressource tourne
-- et si « whisper_voice » est actif (non vérifié dans un vrai client). Relancer l'action sur le même joueur coupe la voix.
local whisperCall = {}      -- src staff -> { t = joueur, ch = canal }
local function voiceCall(a, ch)
    if GetResourceState and GetResourceState('pma-voice') == 'started' then
        local ok = pcall(function() exports['pma-voice']:setPlayerCall(a, ch) end)
        return ok
    end
    return false
end
local function endWhisper(src)
    local w = whisperCall[src]
    if not w then return false end
    whisperCall[src] = nil
    voiceCall(src, 0) voiceCall(w.t, 0)
    return true
end
AddEventHandler('playerDropped', function() local s = source if s then endWhisper(s) for a, w in pairs(whisperCall) do if w.t == s then endWhisper(a) end end end end)
def('whisper', 'staff.whisper', { target = true, log = true, inputs = { { k = 'text', label = 'Message chuchoté (vide = voix seulement)', maxlen = 200 } }, run = function(src, t, p)
    if t == src then return false, 'Choisis un autre joueur.' end
    local m = clean(p.text, 200)
    local voice = cfg('whisper_voice', false) == true
    local w = whisperCall[src]
    if w and w.t == t and m == '' then endWhisper(src) return true, 'Voix privée coupée.' end
    if m == '' and not voice then return false, 'Message vide.' end
    if m ~= '' then G.Notify(t, { type = 'info', title = 'Chuchotement', text = m, duration = 9000 }) end
    local msg = m ~= '' and ('Chuchoté à %s.'):format(rpName(t)) or ''
    if voice then
        endWhisper(src)
        local ch = 9000 + src
        if voiceCall(src, ch) and voiceCall(t, ch) then
            whisperCall[src] = { t = t, ch = ch }
            msg = msg .. ' Voix privée active : relance l\'action sans texte pour la couper.'
        else msg = msg .. ' (voix indisponible : pma-voice absent)' end
    end
    return true, msg ~= '' and msg or 'Fait.'
end })
def('cash', 'staff.money', { target = true, inputs = { { k = 'amount', label = 'Montant (négatif pour retirer)', number = true, maxlen = 9 } }, run = function(src, t, p)
    local n = amountOf(p.amount, cfg('money_max', 1000000)) if not n then return false, 'Montant invalide (0 ou trop grand).' end
    if n > 0 then G.AddMoney(t, 'cash', n) else if not G.RemoveMoney(t, 'cash', -n) then return false, 'Pas assez d\'espèces.' end end
    return true, ('%s espèces : %+d $.'):format(rpName(t), n)
end, log = true })
def('bank', 'staff.money', { target = true, inputs = { { k = 'amount', label = 'Montant (négatif pour retirer)', number = true, maxlen = 9 } }, run = function(src, t, p)
    local n = amountOf(p.amount, cfg('money_max', 1000000)) if not n then return false, 'Montant invalide (0 ou trop grand).' end
    if n > 0 then G.AddMoney(t, 'bank', n) else if not G.RemoveMoney(t, 'bank', -n) then return false, 'Pas assez en banque.' end end
    return true, ('%s banque : %+d $.'):format(rpName(t), n)
end, log = true })
def('item', 'staff.items', { target = true, inputs = { { k = 'item', label = "Nom de l'objet (ex. water)", maxlen = 32 }, { k = 'qty', label = 'Quantité', number = true, maxlen = 4 } }, run = function(src, t, p)
    local name, qty = tostring(p.item or ''), math.floor(tonumber(p.qty) or 0)
    if not name:match('^[%w_]+$') or #name > 32 then return false, "Nom d'objet invalide." end
    if qty < 1 or qty > cfg('item_max', 500) then return false, 'Quantité invalide.' end
    if not PB.Inv.Give(t, name, qty) then return false, "L'inventaire a refusé l'objet (inconnu ou plein)." end
    notify(t, 'success', ('Le staff t\'a donné %d × %s.'):format(qty, name)) return true, 'Objet donné.'
end, log = true })
local function bizPick(p)
    local q = tostring(p.biz or '')
    if q == '' or q == 'none' then return nil end
    return G.BizCat and G.BizCat.Resolve(q) or G.Biz.Get(q)
end
def('job', 'staff.job', { target = true, run = function(src, t, p)
    local q = tostring(p.biz or '')
    if q == '' or q == 'none' then
        local ok, why = G.Biz.SetJob(t, nil)
        if not ok then return false, why end
        return true, rpName(t) .. ' est sans emploi.'
    end
    local b = bizPick(p)
    if not b then return false, 'Aucune entreprise « ' .. q:sub(1, 32) .. ' ».' end
    local ok, why = G.Biz.SetJob(t, b.id, math.floor(tonumber(p.grade) or 0))
    if not ok then return false, why end
    return true, ('%s : %s.'):format(rpName(t), b.label)
end, log = true })
def('job2', 'staff.job', { target = true, run = function(src, t, p)
    local q = tostring(p.biz or '')
    if q == '' or q == 'none' then
        local ok, why = G.BizCat.SetJob2(t, nil)
        if not ok then return false, why end
        return true, 'Second emploi retiré.'
    end
    local b = bizPick(p)
    if not b then return false, 'Aucune entreprise « ' .. q:sub(1, 32) .. ' ».' end
    local ok, why = G.BizCat.SetJob2(t, b.id, math.floor(tonumber(p.grade) or 0))
    if not ok then return false, why end
    notify(t, 'info', 'Second emploi : ' .. b.label .. '. Change d\'emploi dans F5 › Mon entreprise.')
    return true, ('%s : second emploi %s.'):format(rpName(t), b.label)
end, log = true })
def('gang', 'staff.job', { target = true, run = function(src, t, p)
    local q = tostring(p.gang or '')
    if q == '' or q == 'none' then
        local ok, why = G.Tags.SetGang(t, nil)
        if not ok then return false, why end
        return true, rpName(t) .. ' quitte son gang.'
    end
    local defs = G.Tags.GangDefs()
    local id = defs[q] and q
    if not id then for gid, d in pairs(defs) do if tostring(d.label):lower() == q:lower() then id = gid end end end
    if not id then return false, 'Gang inconnu.' end
    local ok, why = G.Tags.SetGang(t, id)
    if not ok then return false, why end
    local names = G.Orga and G.Orga.GradeNames and G.Orga.GradeNames(id) or { 'Recrue', 'Membre', 'Lieutenant', 'Chef' }
    local gr = math.max(1, math.min(#names, math.floor(tonumber(p.grade) or 1)))
    local pl = G.Get(t)
    if gr >= #names then
        if G.Flags and G.Flags.SetBoss then G.Flags.SetBoss(id, t) end
    else
        DB.exec('REPLACE INTO pb_orga_grade (license, grade) VALUES (?, ?)', { pl.license, gr })
    end
    return true, ('%s : %s (%s).'):format(rpName(t), defs[id].label, names[gr])
end, log = true })
def('setrank', 'grades.assign', { target = true, rank = true, run = function(src, t, p)
    local pl = G.Get(t)
    local grade = tostring(p.grade or '')
    if grade == '' or grade == 'none' then grade = nil end
    if grade and not P.Grade(grade) then return false, 'Grade staff inconnu.' end
    local ok, e = P.SetStaff(src, pl.license, GetPlayerName and GetPlayerName(t) or G.Tag(t), grade)
    if not ok then return false, e end
    return true, grade and ('Grade staff : ' .. (P.Grade(grade).label or grade) .. '.') or 'Grade staff retiré.'
end, log = true })
def('warn', 'staff.warn', { target = true, rank = true, inputs = { { k = 'reason', label = 'Motif', maxlen = 120 } }, run = function(src, t, p)
    local r = clean(p.reason, 120) if r == '' then return false, 'Motif obligatoire.' end
    local pl = G.Get(t)
    addSanction('warn', pl.license, rpName(t), r, src, 0, identsOf(t))
    G.Notify(t, { type = 'warn', title = 'Avertissement', text = r, duration = 15000 }) return true, 'Avertissement enregistré.'
end, log = true })
def('kick', 'staff.kick', { target = true, rank = true, inputs = { { k = 'reason', label = 'Motif', maxlen = 120 } }, run = function(src, t, p)
    local r = clean(p.reason, 120) if r == '' then return false, 'Motif obligatoire.' end
    local pl = G.Get(t)
    addSanction('kick', pl.license, rpName(t), r, src, 0, identsOf(t))
    PB.Drop(t, 'kick', 'staff', 'Expulsé : ' .. r, 'Expulsion par le menu staff (F10).', PB.Actor(src).name) return true, 'Joueur expulsé.'
end, log = true })
def('ban', 'staff.ban', { target = true, rank = true, inputs = { { k = 'reason', label = 'Motif', maxlen = 120 } }, pickBan = true, run = function(src, t, p)
    local r = clean(p.reason, 120) if r == '' then return false, 'Motif obligatoire.' end
    local minutes
    for _, line in ipairs(cfg('ban_presets', {}) or {}) do
        local l, m = tostring(line):match('^(.-)|(%d+)$')
        if l == p.duration then minutes = tonumber(m) end
    end
    if minutes == nil then return false, 'Durée inconnue.' end
    local pl = G.Get(t)
    local id = addSanction('ban', pl.license, rpName(t), r, src, minutes, identsOf(t))
    local row = DB.one('SELECT reason, expires FROM pb_sanctions WHERE id = ?', { id })
    PB.Drop(t, 'ban', 'staff', 'Banni : ' .. r, ('Ban par le menu staff (F10), durée « %s ».'):format(tostring(p.duration)), PB.Actor(src).name, banText(row or { reason = r, expires = 0 })) return true, 'Joueur banni.'
end, log = true })
def('history', 'staff.players', { target = true, run = function(src, t)
    local pl = G.Get(t)
    local rows = DB.q('SELECT kind, reason, created FROM pb_sanctions WHERE license = ? ORDER BY id DESC LIMIT 4', { pl.license }) or {}
    if #rows == 0 then G.Info(src, { title = 'Historique · ' .. rpName(t), rows = { { 'Sanctions', 'Aucune' } } }) return true end
    local out = {}
    for _, r in ipairs(rows) do out[#out + 1] = { os.date('%d/%m', r.created) .. ' · ' .. tostring(r.kind), tostring(r.reason) } end
    G.Info(src, { title = 'Historique · ' .. rpName(t), rows = out, secs = 20 })
    return true
end })

-- soi-même
local SELF = { noclip = true, god = true, invisible = true, names = true, speed = true, coords = true, blips = true, skeleton = true, stamina = true, jump = true, swim = true, photo = true, ammo = true, aim = true }
def('self', 'staff.self', { run = function(src, _, p)
    local f = tostring(p.feature or '')
    if not SELF[f] then return false, 'Outil inconnu.' end
    selfState[src] = selfState[src] or {}
    local on = p.on == true
    selfState[src][f] = on or nil
    fx(src, 'self', { feature = f, on = on })
    return true
end, quiet = true })
def('heal_me', 'staff.heal', { run = function(src) G.Revive(src) G.AddStatus(src, 'hunger', 100) G.AddStatus(src, 'thirst', 100) G.AddStatus(src, 'stress', -100) fx(src, 'heal') return true, 'Tu es soigné.' end })
def('tp_waypoint', 'staff.teleport', { run = function(src) fx(src, 'tpwp') return true end, quiet = true })
def('tp_coords', 'staff.teleport', { inputs = { { k = 'text', label = 'Coordonnées : x y z', maxlen = 40 } }, run = function(src, _, p)
    local x, y, z = tostring(p.text or ''):match('^%s*(-?[%d%.]+)[%s,;]+(-?[%d%.]+)[%s,;]+(-?[%d%.]+)%s*$')
    x, y, z = tonumber(x), tonumber(y), tonumber(z)
    if not x or math.abs(x) > 10000 or math.abs(y) > 10000 or math.abs(z) > 3000 then return false, 'Format attendu : x y z (ex. 215.5 -810.2 30.7).' end
    fx(src, 'tp', { x = x, y = y, z = z }) return true
end, quiet = true })
def('tp_player', 'staff.teleport', { inputs = { { k = 'uid', label = 'ID du joueur', number = true, maxlen = 6 } }, run = function(src, _, p)
    local t = tonumber(p.id) if not t or not G.Get(t) then return false, 'Joueur introuvable.' end
    local c = coordsOf(t) if not c then return false, 'Position illisible.' end
    fx(src, 'tp', c) return true
end, quiet = true })

-- véhicules
def('veh_spawn', 'staff.vehicle', { inputs = { { k = 'model', label = 'Modèle (ex. adder)', maxlen = 32 } }, run = function(src, _, p)
    local m = tostring(p.model or ''):lower()
    if not m:match('^[%w_]+$') or #m < 3 or #m > 32 then return false, 'Modèle invalide.' end
    fx(src, 'veh', { op = 'spawn', model = m }) return true, 'Véhicule demandé : ' .. m .. '.'
end, log = true })
for _, op in ipairs({ 'repair', 'flip', 'delete', 'purge', 'clean', 'fuel', 'max', 'unlock', 'boost', 'tpin', 'engine' }) do
    def('veh_' .. op, 'staff.vehicle', { run = function(src) fx(src, 'veh', { op = op }) return true end, quiet = true, log = op == 'purge' })
end

-- Actions sur un joueur (en plus de celles du dessus) : tout est validé ici, le client n'exécute que l'effet.
def('kill', 'staff.freeze', { target = true, rank = true, run = function(src, t) fx(t, 'kill') return true, rpName(t) .. ' est mis à terre.' end })
def('slap', 'staff.freeze', { target = true, rank = true, run = function(src, t) fx(t, 'slap') return true, rpName(t) .. ' est projeté en l\'air.' end })
def('armor', 'staff.heal', { target = true, run = function(src, t) fx(t, 'armor') notify(t, 'info', 'Un membre du staff t\'a donné un gilet.') return true, 'Gilet donné à ' .. rpName(t) .. '.' end })
def('feed', 'staff.heal', { target = true, run = function(src, t) G.AddStatus(t, 'hunger', 100) G.AddStatus(t, 'thirst', 100) G.AddStatus(t, 'stress', -100) return true, rpName(t) .. ' est rassasié.' end })
-- Démenotter / délier : libère une personne menottée (police) ou ligotée (organisation), et arrête l'escorte
def('uncuff', 'staff.freeze', { target = true, run = function(src, t)
    if not (G.IsCuffed and G.IsCuffed(t)) then return false, rpName(t) .. " n'est ni menotté ni ligoté." end
    if G.Police and G.Police.SetCuffed then G.Police.SetCuffed(t, false) end
    if G.Police and G.Police.StopEscort then pcall(G.Police.StopEscort, t) end
    notify(t, 'info', "Un membre du staff t'a libéré.")
    return true, rpName(t) .. ' est libéré (menottes / liens retirés).'
end, log = true })
def('leave_veh', 'staff.freeze', { target = true, rank = true, run = function(src, t) fx(t, 'leaveveh') return true, rpName(t) .. ' est sorti de son véhicule.' end })
def('strip', 'staff.inventory', { target = true, rank = true, run = function(src, t) fx(t, 'strip') return true, 'Armes retirées à ' .. rpName(t) .. '.' end })
function S.WeaponList()
    local out, seen = {}, {}
    for _, w in ipairs(G.DefaultArmory or {}) do if w.type == 'weapon' and not seen[w.name] then seen[w.name] = true out[#out + 1] = { w.name, w.label, w.category or 'Armes', w.ammo_item or '' } end end
    for _, w in ipairs(G.Weapons and G.Weapons.Catalog() or {}) do if not seen[w.item] then seen[w.item] = true out[#out + 1] = { w.item, w.label, 'Armes', w.ammo_item or '' } end end
    return out
end
-- Liste des objets pour le sélecteur du menu staff : { nom technique, nom simplifié, catégorie, description }
local KIND_FR = { drink = 'Boissons', food = 'Nourriture', medical = 'Soins', tool = 'Outils', doc = 'Papiers', misc = 'Divers', weapon = 'Armes', ammo = 'Munitions',
    cloth = 'Vêtements', drug = 'Drogues', material = 'Matériaux', key = 'Clés', phone = 'Téléphone' }
function S.ItemList()
    local out = {}
    for name, d in pairs(G.Inv and G.Inv.Defs and G.Inv.Defs() or {}) do
        local label = tostring(d.label or '')
        if label == '' then label = name end
        local kind = tostring(d.kind or 'misc')
        out[#out + 1] = { name, label:sub(1, 48), KIND_FR[kind] or (kind:sub(1, 1):upper() .. kind:sub(2)), tostring(d.description or ''):sub(1, 80) }
    end
    table.sort(out, function(a, b) return a[2]:lower() < b[2]:lower() end)
    if #out > 1500 then for i = #out, 1501, -1 do out[i] = nil end end
    return out
end
def('weapon', 'staff.items', { target = true, run = function(src, t, p)
    local w = tostring(p.name or ''):lower()
    local entry
    for _, e in ipairs(S.WeaponList()) do if e[1] == w then entry = e end end
    if not entry then return false, 'Arme inconnue : choisis-la dans la liste.' end
    local ammo = math.floor(tonumber(p.ammo) or 0)
    if ammo < 0 or ammo > 1000 then return false, 'Munitions : 0 à 1000.' end
    -- l\'arme et ses munitions doivent exister dans le sac, puis l\'arme y est ajoutée (elle s\'équipe depuis l\'inventaire)
    if G.SyncArmory then
        local def = { { type = 'weapon', name = entry[1], label = entry[2], ammo_item = entry[4] } }
        if entry[4] ~= '' then def[#def + 1] = { type = 'ammo', name = entry[4], label = entry[4] } end
        pcall(G.SyncArmory, def)
    end
    if not PB.Inv.Give(t, entry[1], 1) then return false, "L'inventaire du joueur a refusé l'arme (plein ou trop lourd)." end
    local boxes = 0
    if ammo > 0 and entry[4] ~= '' then
        boxes = math.ceil(ammo / math.max(1, tonumber(PB.Cfg.Get('weapons', 'ammo_per_box', 12)) or 12))
        PB.Inv.Give(t, entry[4], boxes)
    end
    notify(t, 'success', ('Le staff t\'a donné : %s%s. Ouvre ton sac pour l\'équiper.'):format(entry[2], boxes > 0 and (' + ' .. boxes .. ' boîte(s) de munitions') or ''))
    return true, ('%s a reçu %s%s.'):format(rpName(t), entry[2], boxes > 0 and (' et ' .. boxes .. ' boîte(s) de munitions (' .. ammo .. ' balles)') or '')
end, log = true })
def('restart', 'staff.restart', { inputs = { { k = 'minutes', label = 'Redémarrer dans combien de minutes ? (1 à 60)', number = true, maxlen = 2 } }, run = function(src, _, p)
    local m = math.floor(tonumber(p.minutes) or 0)
    if m < 1 or m > 60 then return false, 'Durée : 1 à 60 minutes.' end
    if not PB.Restart then return false, 'Module de redémarrage indisponible.' end
    local ok, why = PB.Restart.Start(m * 60, rpName(src))
    if ok == false then return false, why or 'Impossible de lancer le redémarrage.' end
    return true, ('Redémarrage dans %d min annoncé aux joueurs.'):format(m)
end, log = true })
def('restart_cancel', 'staff.restart', { run = function(src)
    if not PB.Restart or not PB.Restart.State() then return false, 'Aucun redémarrage en cours.' end
    PB.Restart.Cancel(rpName(src))
    return true, 'Redémarrage annulé.'
end, log = true })
def('clear_peds', 'staff.world', { run = function(src) fx(src, 'clearpeds') return true end, quiet = true })

-- monde
def('weather', 'staff.world', { run = function(src, _, p)
    if not PB.Cfg.Get('world', 'enabled', false) then return false, "Le panel ne pilote pas le monde : active-le dans Monde › Réglages." end
    if not PB.World.SetWeather(tostring(p.value or ''), src) then return false, 'Météo inconnue.' end
    return true, 'Météo : ' .. tostring(p.value) .. '.'
end, log = true })
def('hour', 'staff.world', { run = function(src, _, p)
    if not PB.Cfg.Get('world', 'enabled', false) then return false, "Le panel ne pilote pas le monde : active-le dans Monde › Réglages." end
    local h = p.value ~= 'cycle' and tonumber(p.value) or nil
    if not PB.World.SetHour(h, src) then return false, 'Heure invalide.' end
    return true, h and ('Heure figée à ' .. h .. ' h.') or 'Le temps reprend son cours.'
end, log = true })
def('announce', 'staff.announce', { inputs = { { k = 'text', label = 'Annonce', maxlen = 200 } }, run = function(src, _, p)
    local text = clean(p.text, 200) if text == '' then return false, 'Annonce vide.' end
    -- fondateurs (droit « announce.send ») : bandeau plein écran avec style ; sinon, chat + notification comme avant
    if P.Has(src, 'announce.send') and PB.G.Announce then
        local ok, err = PB.G.Announce.Send({ text = text, style = p.style, chat = p.preview ~= true and PB.Cfg.Get('announce', 'chat_too', true) ~= false, sound = PB.Cfg.Get('announce', 'sound', true) ~= false,
            author = GetPlayerName(src) or 'Staff', target = p.preview == true and src or -1, preview = p.preview == true })
        if not ok then return false, err end
        return true, p.preview == true and 'Aperçu affiché sur ton écran.' or 'Annonce envoyée à tous les joueurs.'
    end
    if p.preview == true then return false, 'Aperçu réservé aux fondateurs.' end
    PB.Announce(text, 'both') return true, 'Annonce envoyée.'
end, log = true })
def('heal_all', 'staff.heal', { run = function(src)
    local n = 0
    for t in pairs(G.Players()) do G.Revive(t) G.AddStatus(t, 'hunger', 100) G.AddStatus(t, 'thirst', 100) fx(t, 'heal') n = n + 1 end
    return true, n .. ' joueur(s) soigné(s).'
end, log = true })
def('maintenance', 'staff.maintenance', { run = function(src)
    local on = not PB.Cfg.Get('general', 'maintenance_on', false)
    PB.Cfg.Set('general', 'maintenance_on', on, src, 'Menu staff')
    return true, on and 'Maintenance activée.' or 'Maintenance désactivée.'
end, log = true })


-- Options supplémentaires (Lot 11) ---------------------------------------------------------------------------------------------------------
local muted = {}   -- license -> fin (os.time), 0 = jusqu'à la reconnexion du serveur
function S.IsMuted(src)
    local p = G.Get(src)
    if not p then return false end
    local e = muted[p.license]
    if not e then return false end
    if e ~= 0 and e <= now() then muted[p.license] = nil return false end
    return true
end
local oldChat = G.ChatSend
function G.ChatSend(src, kind, text)
    if S.IsMuted(src) then return false, 'Tu as été réduit au silence par le staff.' end
    return oldChat(src, kind, text)
end

-- micro : coupé par la voix native (Mumble) tant que dure le silence ; vérifié chaque minute pour le rendre à l'échéance
local function voiceMute(t, on) if MumbleSetPlayerMuted then pcall(MumbleSetPlayerMuted, t, on) end end
CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        for id, pl in pairs(G.Players()) do
            local e = muted[pl.license]
            if e and e ~= 0 and e <= now() then muted[pl.license] = nil voiceMute(id, false) notify(id, 'info', 'Ton silence est terminé.')
            elseif e then voiceMute(id, true) end   -- reconnecté pendant son silence
        end
    end
end)
def('mute', 'staff.mute', { target = true, rank = true, inputs = { { k = 'minutes', label = 'Durée en minutes (0 = jusqu\'à la levée)', number = true, maxlen = 4 }, { k = 'reason', label = 'Motif', maxlen = 120 } }, run = function(src, t, p)
    local pl = G.Get(t)
    if S.IsMuted(t) then muted[pl.license] = nil voiceMute(t, false) notify(t, 'info', 'Tu peux de nouveau parler et écrire dans le chat.') return true, rpName(t) .. ' est démuté.' end
    local r = clean(p.reason, 120) if r == '' then return false, 'Motif obligatoire.' end
    local m = math.floor(tonumber(p.minutes) or -1)
    if m < 0 or m > 10080 then return false, 'Durée invalide (0 à 10080 minutes).' end
    muted[pl.license] = m > 0 and (now() + m * 60) or 0
    voiceMute(t, true)
    addSanction('mute', pl.license, rpName(t), r, src, m, {})
    notify(t, 'warn', 'Tu es muté (chat et micro) : ' .. r) return true, rpName(t) .. ' est muté (chat et micro).'
end, log = true })
def('note', 'staff.notes', { target = true, inputs = { { k = 'text', label = 'Note privée (visible par le staff)', maxlen = 250 } }, run = function(src, t, p)
    local text = clean(p.text, 250) if text == '' then return false, 'Note vide.' end
    local pl = G.Get(t)
    DB.insert('INSERT INTO pb_staff_notes (license, name, text, by_name, created) VALUES (?, ?, ?, ?, ?)', { pl.license, clean(rpName(t), 64), text, PB.Actor(src).name:sub(1, 64), now() })
    return true, 'Note enregistrée.'
end, log = true })
def('notes', 'staff.notes', { target = true, run = function(src, t)
    local pl = G.Get(t)
    local rows = DB.q('SELECT text, by_name, created FROM pb_staff_notes WHERE license = ? ORDER BY id DESC LIMIT 3', { pl.license }) or {}
    if #rows == 0 then return true, rpName(t) .. ' : aucune note.' end
    local out = {}
    for _, r in ipairs(rows) do out[#out + 1] = ('%s %s : %s'):format(os.date('%d/%m', r.created), r.by_name, r.text) end
    return true, rpName(t) .. ' · ' .. table.concat(out, ' | ')
end })
def('inv_view', 'staff.inventory', { target = true, run = function(src, t)
    local pl = G.Get(t)
    local items, n = {}, 0
    for _, s in pairs(G.Inv.Contents('p:' .. pl.license)) do n = n + 1 if #items < 8 then items[#items + 1] = ('%d× %s'):format(s.qty, s.item) end end
    if n == 0 then return true, rpName(t) .. " : l'inventaire est vide." end
    return true, rpName(t) .. ' · ' .. table.concat(items, ', ') .. (n > #items and (' … (+' .. (n - #items) .. ')') or '')
end, log = true })
def('inv_clear', 'staff.inventory', { target = true, rank = true, run = function(src, t)
    local pl = G.Get(t)
    DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 'p:' .. pl.license })
    notify(t, 'warn', "Ton inventaire a été vidé par le staff.") return true, "Inventaire de " .. rpName(t) .. ' vidé.'
end, log = true })
local function newPlate()
    local pre = tostring(PB.Cfg.Get('shops', 'plate_prefix', 'PB') or 'PB'):upper():gsub('[^A-Z0-9]', ''):sub(1, 3)
    for _ = 1, 40 do
        local pl = pre .. tostring(math.random(10 ^ (7 - #pre - 1), 10 ^ (7 - #pre) - 1))
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { pl }) then return pl end
    end
end
def('give_vehicle', 'staff.givecar', { target = true, inputs = { { k = 'model', label = 'Modèle (ex. sultan)', maxlen = 32 } }, run = function(src, t, p)
    local m = tostring(p.model or ''):lower()
    if not m:match('^[%w_]+$') or #m < 3 or #m > 32 then return false, 'Modèle invalide.' end
    local plate = newPlate() if not plate then return false, 'Aucune plaque disponible.' end
    local pl = G.Get(t)
    DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price) VALUES (?, ?, ?, ?, ?, ?)', { pl.license, plate, m, m:sub(1, 1):upper() .. m:sub(2), now(), 0 })
    notify(t, 'success', ('Le staff t\'a donné un véhicule : %s (plaque %s). Il est au garage.'):format(m, plate))
    return true, ('%s a reçu %s (plaque %s).'):format(rpName(t), m, plate)
end, log = true })
def('ban_offline', 'staff.ban', { inputs = { { k = 'who', label = 'Licence (ou fin de licence, 6 caractères au moins)', maxlen = 60 }, { k = 'minutes', label = 'Durée en minutes (0 = définitif)', number = true, maxlen = 6 }, { k = 'reason', label = 'Motif', maxlen = 120 } }, run = function(src, _, p)
    local who = tostring(p.who or ''):gsub('^license:', ''):gsub('[^A-Za-z0-9]', '')
    if #who < 6 then return false, 'Saisis au moins 6 caractères de la licence.' end
    local r = clean(p.reason, 120) if r == '' then return false, 'Motif obligatoire.' end
    local m = math.floor(tonumber(p.minutes) or -1)
    if m < 0 or m > 525600 then return false, 'Durée invalide.' end
    local rows = DB.q('SELECT license, firstname, lastname FROM pb_players WHERE license LIKE ? LIMIT 3', { '%' .. who .. '%' }) or {}
    if #rows == 0 then return false, 'Aucun joueur connu avec cette licence.' end
    if #rows > 1 then return false, 'Plusieurs joueurs correspondent : précise la licence.' end
    local row = rows[1]
    local g = P.GradeOf(row.license)
    if g and level(src) < 1000 then return false, "Ce joueur fait partie du staff : seul le propriétaire peut le bannir." end
    local name = ((row.firstname or '') .. ' ' .. (row.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    if name == '' then name = 'Inconnu' end
    addSanction('ban', row.license, name, r, src, m, { row.license })
    for t, pl in pairs(G.Players()) do if pl.license == row.license then PB.Drop(t, 'ban', 'staff', 'Banni : ' .. r, 'Ban hors ligne (par licence) appliqué au joueur connecté.', PB.Actor(src).name) end end
    return true, name .. ' est banni.'
end, log = true })
def('jail', 'staff.jail', { target = true, rank = true, inputs = { { k = 'minutes', label = 'Minutes de prison', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } }, run = function(src, t, p)
    if not G.Justice then return false, 'La justice est indisponible.' end
    local pl = G.Get(t)
    if G.Justice.State(t) then return false, rpName(t) .. ' purge déjà une peine : utilise « Libérer de prison ».' end
    return G.Justice.Sentence(PB.Actor(src).name, t, 'ajal', p.minutes, p.reason)   -- prison du staff (Builder › Prison du staff)
end, log = true })
-- Libérer : pas de contrôle de rang (libérer ne nuit à personne) ; marche aussi pour les TIG.
def('unjail', 'staff.jail', { target = true, run = function(src, t)
    if not G.Justice then return false, 'La justice est indisponible.' end
    if not G.Justice.State(t) then return false, rpName(t) .. " n'est pas en prison." end
    return G.Justice.Release(t, PB.Actor(src).name, 'Libéré(e) par le staff.')
end, log = true })
-- Libérer depuis la liste des détenus (connectés ou non), par licence.
def('unjail_license', 'staff.jail', { run = function(src, _, p)
    if not G.Justice or not G.Justice.ReleaseLicense then return false, 'La justice est indisponible.' end
    local lic = tostring(p.license or '')
    if not lic:match('^license:%x+$') then return false, 'Détenu introuvable.' end
    return G.Justice.ReleaseLicense(lic, PB.Actor(src).name)
end, log = true })
def('tp_back', 'staff.teleport', { run = function(src) fx(src, 'tpback') return true end, quiet = true })
local world = { blackout = false }
def('blackout', 'staff.world', { run = function(src)
    world.blackout = not world.blackout
    fx(-1, 'blackout', { on = world.blackout })
    return true, world.blackout and 'Coupure de courant activée.' or 'Courant rétabli.'
end, log = true })
table.insert(G.beginHooks, function(src) if world.blackout then fx(src, 'blackout', { on = true }) end end)
RegisterCommand('sc', function(src, args)
    if src == 0 or not P.Has(src, 'staff.menu') then return end
    local text = clean(table.concat(args or {}, ' '), 200)
    if text == '' then notify(src, 'info', 'Écris : /sc ton message (visible par le staff en service).') return end
    for s in pairs(G.Players()) do
        if P.Has(s, 'staff.menu') and (S.OnDuty(s) or s == src) then G.Notify(s, { type = 'info', title = 'Chat staff · ' .. rpName(src), text = text, duration = 9000 }) end
    end
end, false)

-- sanctions et signalements
def('unban', 'staff.unban', { run = function(src, _, p)
    local id = math.floor(tonumber(p.sid) or 0)
    local r = DB.one("SELECT id, name FROM pb_sanctions WHERE id = ? AND kind = 'ban' AND revoked = 0", { id })
    if not r then return false, 'Bannissement introuvable.' end
    DB.exec('UPDATE pb_sanctions SET revoked = 1, revoked_by = ? WHERE id = ?', { PB.Actor(src).name:sub(1, 64), id })
    return true, r.name .. ' est débanni.'
end, log = true })
local function reporterOf(license)
    for t, pl in pairs(G.Players()) do if pl.license == license then return t end end
end
local function gradeLabel(src) local _, g = P.GetGrade(src) return g and g.label or 'Staff' end
-- Se rend auprès du joueur d'un report : téléportation, noclip automatique et suivi (pastille à l'écran).
local function followReport(src, t)
    local c = coordsOf(t)
    if not c then return false, 'Position du joueur illisible.' end
    fx(src, 'tp', c)
    selfState[src] = selfState[src] or {}
    if P.Has(src, 'staff.self') and not selfState[src].noclip then selfState[src].noclip = true fx(src, 'self', { feature = 'noclip', on = true }) end
    selfState[src].follow = t
    fx(src, 'follow', { id = t, name = rpName(t) })
    return true
end
def('report_claim', 'staff.reports', { run = function(src, _, p)
    local id = math.floor(tonumber(p.rid) or 0)
    local r = DB.one("SELECT id, status, license FROM pb_reports WHERE id = ?", { id })
    if not r or r.status == 'closed' then return false, 'Signalement introuvable.' end
    if r.status == 'claimed' and r.claimed_by and r.claimed_by ~= '' and r.claimed_by ~= PB.Actor(src).name:sub(1, 64) and not p.force then return false, 'Déjà pris par ' .. r.claimed_by .. '.' end
    DB.exec("UPDATE pb_reports SET status = 'claimed', claimed_by = ? WHERE id = ?", { PB.Actor(src).name:sub(1, 64), id })
    local t = reporterOf(r.license)
    if not t then return true, "Signalement pris en charge (le joueur n'est plus connecté)." end
    -- le joueur voit le grade et le nom RP du membre du staff
    G.Notify(t, { type = 'success', title = 'Signalement', text = ('%s %s a pris votre demande.'):format(gradeLabel(src), rpName(src)), duration = 9000 })
    local ok, why = followReport(src, t)
    if not ok then return true, 'Signalement pris en charge. ' .. why end
    return true, 'Signalement pris en charge : tu es près de ' .. rpName(t) .. ' (noclip activé).'
end })
def('report_close', 'staff.reports', { run = function(src, _, p)
    local id = math.floor(tonumber(p.rid) or 0)
    local r = DB.one("SELECT id FROM pb_reports WHERE id = ? AND status <> 'closed'", { id })
    if not r then return false, 'Signalement introuvable.' end
    DB.exec("UPDATE pb_reports SET status = 'closed', closed_at = ?, claimed_by = ? WHERE id = ?", { now(), PB.Actor(src).name:sub(1, 64), id })
    if selfState[src] and selfState[src].follow then selfState[src].follow = nil fx(src, 'follow', {}) end
    return true, 'Signalement clos.'
end })
def('report_goto', 'staff.reports', { run = function(src, _, p)
    local r = DB.one('SELECT license FROM pb_reports WHERE id = ?', { math.floor(tonumber(p.rid) or 0) })
    if not r then return false, 'Signalement introuvable.' end
    local t = reporterOf(r.license)
    if not t then return false, "Le joueur n'est plus connecté." end
    local ok, why = followReport(src, t)
    if not ok then return false, why end
    return true, 'Tu es près de ' .. rpName(t) .. ' (noclip activé).'
end })
def('follow_stop', 'staff.reports', { noduty = true, run = function(src)
    if selfState[src] then selfState[src].follow = nil end
    fx(src, 'follow', {})
    return true
end, quiet = true })
def('panel', 'panel.open', { run = function(src) TriggerClientEvent('pb:g:staff:panel', src) return true end, quiet = true, noduty = true })
def('duty', 'staff.menu', { noduty = true, run = function(src, _, p)
    local on = p.on == true
    duty[src] = on or nil
    fx(src, 'dutystate', { on = on })
    if not on then
        for f in pairs(selfState[src] or {}) do if f ~= 'frozen' and f ~= 'spectate' then fx(src, 'self', { feature = f, on = false }) end end
        if selfState[src] and selfState[src].spectate then fx(src, 'spectate', { on = false }) end
        selfState[src] = nil
        fx(src, 'follow', {})
    end
    local model = S.DutyPedOf(src)
    if on and model then fx(src, 'dutyped', { on = true, model = model }) elseif not on then fx(src, 'dutyped', { on = false }) end
    if S.PushHud then S.PushHud(src, true) end
    return true, on and 'Tu es en service staff.' or 'Tu quittes le service staff.'
end, log = true })

-- Réglages du service depuis le menu en jeu (mêmes réglages que le panel) : ped de service, blocage des accès, ped par grade.
def('duty_cfg', 'staff.edit', { noduty = true, run = function(src, _, p)
    local k = tostring(p.key or '')
    if k == 'ped' or k == 'block' then
        local key = k == 'ped' and 'duty_ped_on' or 'duty_block'
        PB.Cfg.Set('staff', key, p.on == true, src, 'Menu staff')
        return true, (k == 'ped' and 'Ped de service ' or 'Blocage des accès en service ') .. (p.on == true and 'activé.' or 'désactivé.')
    elseif k == 'grade_ped' then
        local g, m = tostring(p.grade or ''), tostring(p.model or '')
        if not P.Grade(g) then return false, 'Grade inconnu.' end
        if m ~= '' and (not m:match('^[%w_]+$') or #m > 40) then return false, 'Modèle de ped invalide.' end
        local list = {}
        for _, line in ipairs(PB.Cfg.Get('staff', 'duty_peds', {}) or {}) do if tostring(line):match('^([%w_%-]+)|') ~= g then list[#list + 1] = line end end
        if m ~= '' then list[#list + 1] = g .. '|' .. m end
        PB.Cfg.Set('staff', 'duty_peds', list, src, 'Menu staff')
        return true, m ~= '' and ('Ped de service du grade ' .. g .. ' : ' .. m .. '.') or ('Ped de service du grade ' .. g .. ' retiré.')
    end
    return false, 'Réglage inconnu.'
end, log = true })

-- Mini-tableau de bord affiché en service : 3 à 4 chiffres utiles, calculés par le serveur --------------------------------------------------
local hudLast = {}
local HUD_KNOWN = { reports = true, mine = true, online = true, staff = true, dead = true, police = true, ems = true, queue = true, sanctions = true, bda = true }

-- « Joueurs en BDA » : joueurs connectés dont le compte Discord est dans le salon vocal d'attente du support.
-- Discord ne donne pas la liste d'un salon vocal sans connexion permanente : on demande au bot, joueur par joueur (une fois par minute),
-- dans quel salon vocal il se trouve. Il faut le jeton du bot et l'identifiant du serveur Discord (module Discord).
local bdaIn, bdaCount, bdaOk = {}, 0, false
local function discordOf(src) for _, id in ipairs(GetPlayerIdentifiers and GetPlayerIdentifiers(src) or {}) do if tostring(id):sub(1, 8) == 'discord:' then return tostring(id):sub(9) end end end
function S.BdaCount() return bdaOk and bdaCount or nil end
CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        local ch = tostring(cfg('bda_channel', '') or '')
        local gid = PB.Cfg.Get('discord', 'guild_id', '')
        local hud = false
        for _, id in ipairs(cfg('hud_items', {}) or {}) do if id == 'bda' then hud = true end end
        if hud and ch:match('^%d+$') and tostring(gid):match('^%d+$') and PB.Discord and PB.Discord.BotToken and PB.Discord.BotToken() then
            bdaOk = true
            for src in pairs(G.Players()) do
                local dc = discordOf(src)
                if dc and dc:match('^%d+$') then
                    PB.Discord.Api('GET', ('/guilds/%s/voice-states/%s'):format(gid, dc), nil, function(status, text)
                        local v = status == 200 and PB.FromJson(text, nil) or nil
                        bdaIn[src] = (type(v) == 'table' and tostring(v.channel_id or '') == ch) or nil
                    end)
                    Wait(400)   -- étalé : pas de limite de débit de Discord
                else bdaIn[src] = nil end
            end
            local n = 0
            for src in pairs(bdaIn) do if G.Players()[src] then n = n + 1 else bdaIn[src] = nil end end
            bdaCount = n
        else bdaOk = false end
    end
end)
AddEventHandler('playerDropped', function() bdaIn[source] = nil end)
-- /bdatest (staff) : vérifie tout de suite le réglage BDA avec le compte Discord de celui qui tape la commande
RegisterCommand('bdatest', function(src)
    src = tonumber(src)
    if not src or src == 0 or not P.Has(src, 'staff.menu') then return end
    local function say(kind, text) G.Notify(src, { type = kind, title = 'Test BDA', text = text, duration = 12000 }) end
    local ch = tostring(cfg('bda_channel', '') or '')
    local gid = tostring(PB.Cfg.Get('discord', 'guild_id', '') or '')
    if not (PB.Discord and PB.Discord.BotToken and PB.Discord.BotToken()) then say('error', 'Jeton du bot Discord absent (panel › Discord).') return end
    if not gid:match('^%d+$') then say('error', 'Identifiant du serveur Discord absent (panel › Discord).') return end
    if not ch:match('^%d+$') then say('error', 'Identifiant du salon vocal BDA absent (panel › Staff).') return end
    local dc = discordOf(src)
    if not dc then say('error', "FiveM ne connaît pas ton compte Discord : ouvre l'application Discord puis relance FiveM.") return end
    PB.Discord.Api('GET', ('/guilds/%s/voice-states/%s'):format(gid, dc), nil, function(status, text)
        local v = status == 200 and PB.FromJson(text, nil) or nil
        if status == 200 and type(v) == 'table' then
            local inBda = tostring(v.channel_id or '') == ch
            if inBda then bdaIn[src] = true end
            say(inBda and 'success' or 'warn', inBda and 'Ça marche : tu es dans le salon BDA, tu seras compté.' or ('Discord te voit dans un autre salon vocal (%s), pas dans le salon BDA.'):format(tostring(v.channel_id)))
        elseif status == 404 then say('warn', "Discord répond que tu n'es dans aucun salon vocal du serveur. Rejoins le salon BDA puis refais /bdatest.")
        elseif status == 401 or status == 403 then say('error', ('Discord refuse le bot (%d) : jeton invalide ou bot absent du serveur.'):format(status))
        else say('error', ('Discord a répondu %s.'):format(tostring(status))) end
    end)
end, false)
function S.HudData(src)
    if not cfg('hud_on', true) or not S.OnDuty(src) or not P.Has(src, 'staff.menu') then return nil end
    local out = {}
    local function one(id)
        if id == 'reports' and P.Has(src, 'staff.reports') then
            local n = DB.one("SELECT COUNT(*) AS n FROM pb_reports WHERE status <> 'closed'")
            return { id = id, label = 'Reports en attente', value = n and n.n or 0, icon = 'alert', warn = (n and n.n or 0) > 0 }
        elseif id == 'mine' and P.Has(src, 'staff.reports') then
            local n = DB.one("SELECT COUNT(*) AS n FROM pb_reports WHERE status = 'claimed' AND claimed_by = ?", { PB.Actor(src).name:sub(1, 64) })
            return { id = id, label = 'Pris par moi', value = n and n.n or 0, icon = 'check' }
        elseif id == 'online' then
            local n = 0
            for _ in pairs(G.Players()) do n = n + 1 end
            return { id = id, label = 'Joueurs en ligne', value = n, icon = 'users' }
        elseif id == 'staff' then
            local on, all = 0, 0
            for s in pairs(G.Players()) do if P.Has(s, 'staff.menu') then all = all + 1 if S.OnDuty(s) then on = on + 1 end end end
            return { id = id, label = 'Staff en service', value = on, icon = 'shield' }
        elseif id == 'dead' then
            local n = 0
            for _, p in pairs(G.Players()) do if p.row and PB.ToBool(p.row.dead) then n = n + 1 end end
            return { id = id, label = 'Joueurs à terre', value = n, icon = 'skull', warn = n > 0 }
        elseif (id == 'police' or id == 'ems') and G.Justice and G.Justice.CountUnits then
            return { id = id, label = id == 'police' and 'Police en service' or 'Secours en service', value = G.Justice.CountUnits(id) or 0, icon = id == 'police' and 'shield' or 'heart' }
        elseif id == 'bda' then
            local n = S.BdaCount()
            return { id = id, label = tostring(cfg('bda_label', 'Joueurs en BDA')):sub(1, 30), value = n == nil and '—' or n, icon = 'mic', warn = (n or 0) > 0 }
        elseif id == 'queue' and G.Flow and G.Flow.queue then
            return { id = id, label = "File d'attente", value = #G.Flow.queue, icon = 'clock', warn = #G.Flow.queue > 0 }
        elseif id == 'sanctions' and P.Has(src, 'staff.players') then
            local n = DB.one("SELECT COUNT(*) AS n FROM pb_sanctions WHERE created > ? AND kind IN ('warn','kick','ban','mute','jail')", { now() - 86400 })
            return { id = id, label = 'Sanctions (24 h)', value = n and n.n or 0, icon = 'shield' }
        end
    end
    local seen = {}
    for _, id in ipairs(cfg('hud_items', {}) or {}) do
        if HUD_KNOWN[id] and not seen[id] and #out < 8 then seen[id] = true local it = one(id) if it then out[#out + 1] = it end end
    end
    local style = cfg('hud_style', 'bar') == 'box' and 'box' or 'bar'
    return { items = out, style = style, x = tonumber(cfg('hud_x', 1.2)) or 1.2, y = tonumber(cfg('hud_y', 30)) or 30, top = tonumber(cfg('hud_top', 0.8)) or 0.8 }
end
function S.PushHud(src, force)
    local d = S.HudData(src)
    local j = d and PB.Json(d) or ''
    if force or hudLast[src] ~= j then
        hudLast[src] = j
        TriggerClientEvent('pb:g:staff:hud', src, d and j or '[]')
    end
end
AddEventHandler('playerDropped', function() hudLast[source] = nil end)
CreateThread(function()
    while true do
        Wait(4000)
        for src in pairs(duty) do pcall(S.PushHud, src) end
    end
end)

-- Construction de la description du menu (données pures envoyées au client) ---------------------------------------------------------------
local function parsePresets(key, sep)
    local out = {}
    for _, line in ipairs(cfg(key, {}) or {}) do
        local a, b = tostring(line):match('^(.-)|(.+)$')
        if a and a ~= '' then out[#out + 1] = { clean(a, 60), clean(b, 200) } end
    end
    return out
end

-- lance plusieurs lectures de la base en même temps et attend qu'elles soient toutes finies
local function parallel(fns)
    local list = {}
    for i = 1, 4 do if fns[i] then list[#list + 1] = fns[i] end end
    if #list == 0 then return end
    if #list == 1 then list[1]() return end
    local left, p = #list, promise.new()
    for _, fn in ipairs(list) do
        CreateThread(function()
            pcall(fn)
            left = left - 1
            if left == 0 then p:resolve(true) end
        end)
    end
    Citizen.Await(p)
end

function S.Spec(src)
    if not cfg('enabled', true) then return nil, 'Le menu staff est désactivé.' end
    if not P.Has(src, 'staff.menu') then return nil, "Tu n'as pas accès au menu staff." end
    local grade, g = P.GetGrade(src)
    local on = S.OnDuty(src)
    local needDuty = cfg('require_duty', true) ~= false
    local active = on or not needDuty
    local spec = { grade = g and g.label or 'Staff', color = g and g.color or '#dfe2e7', duty = on, require_duty = needDuty, locked = not active, cats = {},
        order = cfg('order', {}) or {}, hide = cfg('hide', {}) or {}, self = selfState[src] or {}, myid = src }
    -- base de données : reports et bans lus en même temps (et non l'un après l'autre) pour ouvrir le menu vite
    local wantReps = active and P.Has(src, 'staff.reports')
    local wantBans = active and P.Has(src, 'staff.unban')
    local repRows, banRows = nil, nil
    parallel({
        wantReps and function() repRows = DB.q("SELECT id, name, text, status, claimed_by, created, (SELECT COUNT(*) FROM pb_reports WHERE status <> 'closed') AS total FROM pb_reports WHERE status <> 'closed' ORDER BY vip DESC, id DESC LIMIT 12") end or nil,
        wantBans and function() banRows = DB.q("SELECT id, name, reason, expires FROM pb_sanctions WHERE kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) ORDER BY id DESC LIMIT 12", { now() }) end or nil,
    })
    local repTotal = repRows and repRows[1] and tonumber(repRows[1].total) or 0
    for _, c in ipairs(CATS) do
        local show = P.Has(src, c.perm)
        if c.id == 'panel' then show = P.Has(src, 'panel.open') elseif c.id == 'sanctions' then show = active and (P.Has(src, 'staff.unban') or P.Has(src, 'staff.jail')) elseif c.id == 'builder' then show = P.Has(src, 'carte.place') elseif not active then show = false end
        if show then
            local e = { id = c.id, label = c.label, icon = c.icon }
            if c.id == 'reports' then
                e.count = repTotal
                e.label = c.label .. ' (' .. e.count .. ')'
            elseif c.id == 'players' then
                local n = 0
                for _ in pairs(G.Players()) do n = n + 1 end
                e.label = c.label .. ' (' .. n .. ')'
            end
            spec.cats[#spec.cats + 1] = e
        end
    end
    spec.dutycfg = P.Has(src, 'staff.edit') and { ped = cfg('duty_ped_on', false), block = cfg('duty_block', false), peds = S.DutyPeds() } or nil
    spec.follow = selfState[src] and selfState[src].follow or nil
    if spec.dutycfg then spec.gradeList = {} for _, g in ipairs(P.Grades()) do if g.name ~= 'owner' or true then spec.gradeList[#spec.gradeList + 1] = { name = g.name, label = g.label } end end end
    spec.can = {}
    for id, a in pairs(ACT) do spec.can[id] = P.Has(src, a.perm) or nil end
    if active then
        if P.Has(src, 'staff.players') then
            spec.players = playerList()
            for _, pl in ipairs(spec.players) do pl.rank = outranks(src, pl.id) or nil end
            spec.pactions = {}
            for _, id in ipairs({ 'info', 'history', 'notes', 'note', 'goto', 'bring', 'heal', 'revive', 'freeze', 'spectate', 'message', 'whisper', 'cash', 'bank', 'item', 'inv_view', 'inv_clear', 'give_vehicle', 'jail', 'unjail', 'vip_give', 'vip_remove', 'job', 'job2', 'gang', 'setrank', 'mute', 'warn', 'kick', 'ban', 'feed', 'armor', 'weapon', 'strip', 'slap', 'kill', 'leave_veh', 'uncuff', 'ata_give', 'ata_remove', 'mortrp' }) do
                local a = ACT[id]
                if a and P.Has(src, a.perm) then spec.pactions[#spec.pactions + 1] = { id = id, rank = a.rank or nil, inputs = a.inputs, pickBan = a.pickBan or nil } end
            end
        end
            spec.gestures = G.Gestures and G.Gestures.Menu(src) or nil
        if P.Has(src, 'staff.job') then
            spec.bizlist = G.BizCat and G.BizCat.Menu() or {}
            spec.bizcats = G.BizCat and G.BizCat.Cats or {}
            local gl = {}
            for gid, d in pairs(G.Tags and G.Tags.GangDefs and G.Tags.GangDefs() or {}) do gl[#gl + 1] = { gid, d.label } end
            table.sort(gl, function(a, b) return a[2] < b[2] end)
            spec.ganglist = gl
            spec.gangGrades = G.Orga and G.Orga.GradeNames and G.Orga.GradeNames() or { 'Recrue', 'Membre', 'Lieutenant', 'Chef' }
        end
        if P.Has(src, 'grades.assign') then spec.gradeList = {} for _, g in ipairs(P.Grades()) do spec.gradeList[#spec.gradeList + 1] = { name = g.name, label = g.label } end end
        if P.Has(src, 'staff.items') then spec.weapons = S.WeaponList() spec.items = S.ItemList() end
        if P.Has(src, 'staff.restart') then spec.restart = PB.Restart and PB.Restart.State() or false end
        local bans = {}
        if P.Has(src, 'staff.unban') then
            for _, r in ipairs(banRows or {}) do
                bans[#bans + 1] = { id = r.id, name = r.name, reason = r.reason, expires = r.expires }
            end
        end
        spec.bans = bans
        -- détenus (prison et TIG), connectés ou non : libérables depuis « Gestion des sanctions »
        local jailedList = {}
        if P.Has(src, 'staff.jail') then
            for _, r in ipairs(DB.q('SELECT license, kind, remaining, reason, name FROM pb_jail ORDER BY since DESC LIMIT 20') or {}) do
                local online = false
                for t, pl in pairs(G.Players()) do if pl.license == r.license then online = t break end end
                local st = online and G.Justice and G.Justice.State and G.Justice.State(online)
                jailedList[#jailedList + 1] = { license = r.license, name = (r.name ~= '' and r.name) or 'Inconnu', kind = r.kind, reason = r.reason,
                    remaining = tonumber(st and st.remaining or r.remaining) or 0, online = online or nil }
            end
        end
        spec.jailed = jailedList
        local reps = {}
        if P.Has(src, 'staff.reports') then
            for _, r in ipairs(repRows or {}) do
                reps[#reps + 1] = { id = r.id, name = r.name, text = r.text, status = r.status, by = r.claimed_by, ago = math.max(0, now() - r.created) }
            end
        end
        spec.reports = reps
        spec.spawn = parsePresets('spawn_presets')
        spec.announce = parsePresets('announce_presets')
        spec.announce_screen = P.Has(src, 'announce.send')
        spec.bans_presets = parsePresets('ban_presets')
        spec.weather = PB.World and PB.World.Weathers or {}
        spec.world_on = PB.Cfg.Get('world', 'enabled', false)
        spec.maint = PB.Cfg.Get('general', 'maintenance_on', false)
        spec.blackout = world.blackout
    end
    for _, fn in ipairs(S.SpecExtra) do pcall(fn, src, spec) end   -- ajouts d'autres fichiers (Builder…)
    return spec
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or now() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function()
    local src = source
    last[src], duty[src], selfState[src] = nil, nil, nil
    for s, st in pairs(selfState) do
        if st.spectate == src then st.spectate = nil end
        if st.follow == src then st.follow = nil fx(s, 'follow', {}) end
    end
end)

RegisterNetEvent('pb:g:staff:open', function(focus)
    local src = source
    if not reg(src) or not P.Has(src, 'staff.menu') or not throttle(src, 400) then return end   -- silencieux pour les joueurs sans droit
    local spec, err = S.Spec(src)
    if not spec then notify(src, 'warn', err) return end
    -- ouverture directe sur les reports ou sur la fiche du joueur suivi (liste blanche, jamais le texte du client)
    if focus == 'reports' then spec.focus = { k = 'reports' }
    elseif focus == 'follow' and selfState[src] and selfState[src].follow and G.Get(selfState[src].follow) then spec.focus = { k = 'player', id = selfState[src].follow }
    -- (v1.2.43) viseur staff : clic sur un joueur visé -> actions rapides sur lui (seulement si le viseur est actif)
    elseif type(focus) == 'number' and selfState[src] and selfState[src].aim and G.Get(math.floor(focus)) and math.floor(focus) ~= src then spec.focus = { k = 'aim', id = math.floor(focus) } end
    TriggerClientEvent('pb:g:staff:ui', src, PB.Json({ ev = 'open', spec = spec }))
end)

function S.ActInfo(id) local a = ACT[id] if not a then return nil end return { perm = a.perm, noduty = a.noduty, rank = a.rank, target = a.target } end

-- Journal des actions du staff + bouton « Annuler » ------------------------------------------------------------------------------------
-- Chaque action réussie est notée (qui, quoi, sur qui). Les actions réversibles gardent de quoi les défaire : argent, objets, gel, silence,
-- téléportation, bannissement, prison. Une action ne s'annule qu'une fois et pendant 24 h.
local JLABEL = { cash = 'Argent (espèces)', bank = 'Argent (banque)', item = 'Objet donné', ['goto'] = 'Téléportation vers un joueur', bring = 'Joueur amené', freeze = 'Gel', mute = 'Silence',
    ban = 'Bannissement', kick = 'Expulsion', warn = 'Avertissement', jail = 'Prison', unjail = 'Libération', tp_coords = 'Téléportation (coordonnées)', tp_player = 'Téléportation (joueur)',
    heal = 'Soin', revive = 'Réanimation', kill = 'Mis à terre', slap = 'Projeté', strip = 'Armes retirées', inv_clear = 'Inventaire vidé', give_vehicle = 'Véhicule donné', job = "Changement d'entreprise",
    job2 = 'Second emploi', gang = 'Changement de groupe', weapon = 'Arme donnée', veh_spawn = 'Véhicule créé', announce = 'Annonce', restart = 'Redémarrage programmé', unban = 'Débannissement', ban_offline = 'Bannissement (hors ligne)',
    setrank = 'Changement de grade', message = 'Message privé', whisper = 'Chuchotement' }
local JSKIP = { info = true, search = true, history = true, notes = true, inv_view = true, spectate = true, panel = true, duty = true, duty_cfg = true, report_claim = true, report_close = true, report_goto = true, follow_stop = true, ['self'] = true }
S.JournalLabel = function(id) return JLABEL[id] or id end
local function srcOfLicense(lic) for t, pl in pairs(G.Players()) do if pl.license == lic then return t end end end
local function journalAdd(src, id, t, p, pre)
    if JSKIP[id] then return end
    local a = PB.Actor(src)
    local tl = t and G.Get(t) and G.Get(t).license or ''
    local undo
    if id == 'cash' or id == 'bank' then
        local n = amountOf(p.amount, cfg('money_max', 1000000))
        if n and tl ~= '' then undo = { k = 'money', acct = id == 'cash' and 'cash' or 'bank', n = n, lic = tl } end
    elseif id == 'item' then
        local q = math.floor(tonumber(p.qty) or 0)
        if q >= 1 and tl ~= '' then undo = { k = 'item', name = tostring(p.item or ''), qty = q, lic = tl } end
    elseif pre and pre.c then
        local lic = G.Get(pre.who) and G.Get(pre.who).license
        if lic then undo = { k = 'tp', c = pre.c, lic = lic } end
    elseif id == 'freeze' and tl ~= '' then undo = { k = 'freeze', lic = tl }
    elseif id == 'mute' and tl ~= '' and S.IsMuted(t) then undo = { k = 'mute', lic = tl }
    elseif id == 'ban' and tl ~= '' then
        local r = DB.one("SELECT id FROM pb_sanctions WHERE license = ? AND kind = 'ban' AND revoked = 0 ORDER BY id DESC LIMIT 1", { tl })
        if r then undo = { k = 'unban', sid = r.id } end
    elseif id == 'jail' and tl ~= '' then undo = { k = 'unjail', lic = tl }
    end
    local detail = {}
    if p.amount then detail[#detail + 1] = tostring(p.amount) .. ' $' end
    if p.item then detail[#detail + 1] = tostring(p.qty or 1) .. ' × ' .. clean(p.item, 32) end
    if p.reason and p.reason ~= '' then detail[#detail + 1] = clean(p.reason, 100) end
    if p.minutes then detail[#detail + 1] = tostring(p.minutes) .. ' min' end
    if p.duration then detail[#detail + 1] = clean(p.duration, 30) end
    if p.model then detail[#detail + 1] = clean(p.model, 32) end
    if p.text then detail[#detail + 1] = clean(p.text, 100) end
    DB.insert('INSERT INTO pb_staff_journal (at, actor_license, actor_name, action, target_license, target_name, detail, undo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        { now(), a.license:sub(1, 64), a.name:sub(1, 64), id, tl, t and clean(rpName(t), 80) or '', table.concat(detail, ' · '):sub(1, 300), undo and PB.Json(undo) or nil })
end
function S.Journal(n, actor)
    if actor and actor ~= '' then return DB.q('SELECT * FROM pb_staff_journal WHERE actor_license = ? ORDER BY id DESC LIMIT ?', { actor, n or 200 }) or {} end
    return DB.q('SELECT * FROM pb_staff_journal ORDER BY id DESC LIMIT ?', { n or 200 }) or {}
end
function S.Undo(src, jid)
    if not P.Has(src, 'staff.undo') then return false, "Tu n'as pas le droit d'annuler les actions du staff." end
    local r = DB.one('SELECT * FROM pb_staff_journal WHERE id = ?', { math.floor(tonumber(jid) or 0) })
    if not r then return false, 'Entrée introuvable.' end
    if (tonumber(r.undone) or 0) > 0 then return false, 'Déjà annulée.' end
    local u = r.undo and PB.FromJson(r.undo, nil)
    if type(u) ~= 'table' then return false, 'Cette action ne peut pas être annulée.' end
    if now() - (tonumber(r.at) or 0) > 86400 then return false, "Trop ancien : on n'annule que dans les 24 h." end
    local me = PB.Actor(src)
    local t = u.lic and srcOfLicense(u.lic)
    local ok, msg
    if u.k == 'money' then
        if not t then return false, 'Le joueur est hors ligne : annulation impossible pour le moment.' end
        if u.n > 0 then ok = G.RemoveMoney(t, u.acct, u.n) msg = ok and 'Argent repris.' or "Le joueur n'a plus cette somme."
        else G.AddMoney(t, u.acct, -u.n) ok, msg = true, 'Argent rendu.' end
    elseif u.k == 'item' then
        if not t then return false, 'Le joueur est hors ligne : annulation impossible pour le moment.' end
        ok = PB.Inv.Remove(t, u.name, u.qty) msg = ok and 'Objet repris.' or "Le joueur n'a plus cet objet en quantité suffisante."
    elseif u.k == 'tp' then
        if not t then return false, 'Le joueur est hors ligne.' end
        fx(t, 'tp', u.c) ok, msg = true, 'Retour à la position précédente.'
    elseif u.k == 'freeze' then
        if not t then return false, 'Le joueur est hors ligne.' end
        selfState[t] = selfState[t] or {}
        local on = not selfState[t].frozen
        selfState[t].frozen = on or nil
        fx(t, 'freeze', { on = on })
        ok, msg = true, on and 'Joueur gelé de nouveau.' or 'Joueur dégelé.'
    elseif u.k == 'mute' then
        muted[u.lic] = nil
        if t then voiceMute(t, false) notify(t, 'info', 'Tu peux de nouveau parler et écrire dans le chat.') end
        ok, msg = true, 'Silence levé.'
    elseif u.k == 'unban' then
        DB.exec('UPDATE pb_sanctions SET revoked = 1, revoked_by = ? WHERE id = ?', { me.name:sub(1, 64), u.sid })
        ok, msg = true, 'Bannissement levé.'
    elseif u.k == 'unjail' then
        if not G.Justice then return false, 'La justice est indisponible.' end
        if t then ok, msg = G.Justice.Release(t, me.name, 'Annulé par le staff.') else ok, msg = G.Justice.ReleaseLicense(u.lic, me.name) end
    else return false, 'Cette action ne peut pas être annulée.' end
    if not ok then return false, msg or 'Impossible.' end
    DB.exec('UPDATE pb_staff_journal SET undone = ?, undone_by = ? WHERE id = ?', { now(), me.name:sub(1, 64), r.id })
    audit(src, 'undo', r.target_name, { action = r.action, par = r.actor_name })
    return true, msg
end
PB.OnReady(function() pcall(function() DB.exec('DELETE FROM pb_staff_journal WHERE at < ?', { now() - 90 * 86400 }) end) end)

function S.Do(src, id, payload)
    id = tostring(id or '')
    local a = ACT[id]
    if not a then return false, 'Action inconnue.' end
    if PB.AC then PB.AC.Grace(src, 15) if type(payload) == 'table' and tonumber(payload.target) then PB.AC.Grace(payload.target, 15) end end
    if not P.Has(src, 'staff.menu') or not P.Has(src, a.perm) then return false, "Tu n'as pas la permission pour cette action." end
    if not a.noduty and cfg('require_duty', true) ~= false and not S.OnDuty(src) then return false, 'Passe en service staff avant.' end
    local p = type(payload) == 'table' and payload or {}
    -- ID tapé par un humain (commande, champ « ID du joueur ») = ID permanent ; les listes du menu envoient déjà le joueur choisi
    if p.uid ~= nil then p.id = G.SrcOfUid(p.uid) or -1 end
    local t
    if a.target then
        t = tonumber(p.id)
        if not t or not G.Get(t) then return false, 'Joueur introuvable ou pas encore connecté.' end
        if a.rank and not outranks(src, t) then return false, 'Ce joueur a un rang égal ou supérieur au tien.' end
    end
    local pre
    if id == 'bring' then pre = { who = t, c = coordsOf(t) }
    elseif id == 'goto' or id == 'tp_coords' or id == 'tp_player' or id == 'tp_waypoint' then pre = { who = src, c = coordsOf(src) } end
    local ok, msg = a.run(src, t, p)
    if ok then pcall(journalAdd, src, id, t, p, pre) end
    if ok and (a.log or not a.quiet) then
        audit(src, id, t and (rpName(t) .. ' ' .. G.Tag(t)) or '', { reason = p.reason, amount = p.amount, item = p.item, qty = p.qty, model = p.model, text = p.text, duration = p.duration, minutes = p.minutes, who = p.who })
    end
    return ok and true or false, msg
end

-- Écran de mort : un staff à terre peut se réanimer (même hors service : sinon il ne pourrait jamais rouvrir son menu).
local function canSelfRevive(src)
    local p = G.Get(src)
    return p ~= nil and PB.ToBool(p.row.dead) and P.Has(src, 'staff.menu') and P.Has(src, 'staff.heal')
end
RegisterNetEvent('pb:g:staff:canrevive', function()
    local src = source
    if not reg(src) or not throttle(src, 500) then return end
    TriggerClientEvent('pb:g:staff:canrevive', src, canSelfRevive(src))
end)
RegisterNetEvent('pb:g:staff:selfrevive', function()
    local src = source
    if not reg(src) or not throttle(src, 1500) then return end
    if not canSelfRevive(src) then return end
    local a = ACT.heal_me
    local ok, msg = a.run(src, nil, {})
    if ok then audit(src, 'heal_me', rpName(src) .. ' ' .. G.Tag(src), { text = 'depuis_ecran_de_mort' }) end
    if msg then notify(src, ok and 'success' or 'error', tostring(msg)) end
end)

RegisterNetEvent('pb:g:staff:act', function(id, payload)
    local src = source
    if not reg(src) or not throttle(src, 250) then return end
    local ok, msg = S.Do(src, id, payload)
    if msg then notify(src, ok and 'success' or 'error', tostring(msg)) end
    local spec = S.Spec(src)
    TriggerClientEvent('pb:g:staff:ui', src, PB.Json({ ev = 'update', spec = spec, ok = ok and true or false }))
end)

-- Raccourcis clavier (noclip, tpm…) : le client envoie seulement le nom du raccourci ; le serveur vérifie le droit et le service
-- exactement comme pour le menu, puis applique la même action (silencieux pour un joueur sans droit).
local BIND = {
    noclip = { 'self', 'noclip' }, god = { 'self', 'god' }, invisible = { 'self', 'invisible' }, names = { 'self', 'names' },
    photo = { 'self', 'photo' }, aim = { 'self', 'aim' }, ammo = { 'self', 'ammo' },
    tpm = { 'tp_waypoint' }, back = { 'tp_back' }, heal = { 'heal_me' },
}
S.BIND = BIND
RegisterNetEvent('pb:g:staff:bind', function(name, on)
    local src = source
    if not reg(src) or not P.Has(src, 'staff.menu') or not throttle(src, 300) then return end
    local b = BIND[tostring(name)]
    if not b then return end
    local payload = b[2] and { feature = b[2], on = on == true } or {}
    local ok, msg = S.Do(src, b[1], payload)
    if msg then notify(src, ok and 'success' or 'error', tostring(msg)) end
end)

-- Signalements des joueurs : /report <message> --------------------------------------------------------------------------------------------
local lastReport = {}
RegisterCommand('report', function(src, args)
    if src == 0 or not G.Get(src) then return end
    if not cfg('reports_on', true) then G.Notify(src, { type = 'warn', title = 'Signalement', text = 'Les signalements sont désactivés.' }) return end
    if G.Justice and G.Justice.State and G.Justice.State(src) then G.Notify(src, { type = 'warn', title = 'Signalement', text = 'Tu es en prison : tu ne peux pas faire de signalement.' }) return end
    local text = clean(table.concat(args or {}, ' '), 280)
    if #text < 5 then G.Notify(src, { type = 'warn', title = 'Signalement', text = 'Décris ton problème : /report ton message.' }) return end
    local t = now()
    if lastReport[src] and t - lastReport[src] < cfg('report_cooldown', 60) then G.Notify(src, { type = 'warn', title = 'Signalement', text = 'Attends un peu avant un nouveau signalement.' }) return end
    local open = DB.one("SELECT COUNT(*) AS n FROM pb_reports WHERE license = ? AND status <> 'closed'", { G.Get(src).license })
    if open and open.n >= 3 then G.Notify(src, { type = 'warn', title = 'Signalement', text = 'Tu as déjà 3 signalements ouverts.' }) return end
    lastReport[src] = t
    local rid = DB.insert('INSERT INTO pb_reports (license, name, text, status, created) VALUES (?, ?, ?, ?, ?)', { G.Get(src).license, rpName(src), text, 'open', t })
    local vip = G.Tickets and G.Tickets.MarkVip and rid and G.Tickets.MarkVip(src, rid)   -- VIP : prioritaire
    if G.Tickets and rid then pcall(G.Tickets.Created, rid) end   -- conversation, Discord
    G.Notify(src, { type = 'success', title = 'Signalement', text = "Ton message a été transmis à l'équipe (ticket #" .. tostring(rid or '?') .. ', suivi avec /ticket).' })
    for s in pairs(G.Players()) do
        if S.OnDuty(s) and P.Has(s, 'staff.reports') then G.Notify(s, { type = 'warn', title = (vip and '★ VIP · ' or '') .. 'Nouveau signalement', text = rpName(src) .. ' (' .. G.Tag(src) .. ') : ' .. text .. ' — Alt + clic pour l\'ouvrir.', click = 'reports', duration = 12000 }) pcall(S.PushHud, s) end
    end
end, false)
AddEventHandler('playerDropped', function() lastReport[source] = nil end)

exports('IsStaffOnDuty', function(src) return S.OnDuty(src) end)

-- Panel : réglages, sanctions, signalements ---------------------------------------------------------------------------------------------
P.Register('staff.edit', 'Modifier les réglages du menu staff', 'staff', true)
local settings = Form.Cfg({ ns = 'staff', id = 'settings', title = 'Menu staff', perm = 'staff.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Menu staff actif', default = true },
    { k = 'key', type = 'text', label = "Touche d'ouverture (par défaut)", default = 'F10', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
    { k = 'bind_noclip', type = 'text', label = 'Raccourci : noclip', default = 'F3', maxlen = 12, pattern = '^[%w_]*$', hint = 'Touche par défaut, que chaque staff peut changer dans les raccourcis de FiveM. Vide = aucune touche.' },
    { k = 'bind_tpm', type = 'text', label = 'Raccourci : téléportation au point GPS (tpm)', default = '', maxlen = 12, pattern = '^[%w_]*$' },
    { k = 'bind_back', type = 'text', label = 'Raccourci : retour à la position précédente', default = '', maxlen = 12, pattern = '^[%w_]*$' },
    { k = 'bind_god', type = 'text', label = 'Raccourci : invincibilité', default = '', maxlen = 12, pattern = '^[%w_]*$' },
    { k = 'bind_invisible', type = 'text', label = 'Raccourci : invisibilité', default = '', maxlen = 12, pattern = '^[%w_]*$' },
    { k = 'bind_names', type = 'text', label = 'Raccourci : noms au-dessus des têtes', default = '', maxlen = 12, pattern = '^[%w_]*$' },
    { k = 'bind_heal', type = 'text', label = 'Raccourci : me soigner', default = '', maxlen = 12, pattern = '^[%w_]*$' },
    { k = 'duty_god', type = 'toggle', label = 'Invincible dès la prise de service', default = false, hint = "Désactivé : le staff en service prend les dégâts comme tout le monde (utile pour tester les combats). « Invincible » et le noclip restent disponibles dans le menu staff." },
    { k = 'require_duty', type = 'toggle', label = 'Exiger le mode « en service »', default = true, hint = 'Sans service, le staff ne voit que le bouton de service (et le panel si autorisé).' },
    { k = 'duty_ped_on', type = 'toggle', label = 'Ped de service (un par grade)', default = false, hint = "En service, le staff prend le ped réglé pour son grade ; en quittant le service il retrouve son personnage. Indépendant du blocage ci-dessous." },
    { k = 'duty_peds', type = 'list', label = 'Ped de service par grade (grade|modèle, ex. moderator|s_m_m_armoured_01)', default = {}, maxitems = 30, maxlen = 60, pattern = '^[%w_%-]+|[%w_]+$', wide = true },
    { k = 'duty_block', type = 'toggle', label = 'Bloquer les accès joueur en service', default = false, hint = "En service : inventaire, métier, téléphone, banque, garage, logement, boutiques coupés. Les outils staff restent ouverts. Indépendant du ped de service." },
    { k = 'whisper_voice', type = 'toggle', label = 'Chuchoter : ouvrir aussi une voix privée (pma-voice)', default = false, hint = "Le texte chuchoté fonctionne toujours. La voix privée suppose pma-voice ; elle n'a pas été vérifiée dans un vrai client." },
    { k = 'hud_on', type = 'toggle', label = 'Tableau de bord staff en service', default = true, hint = 'Reports en attente, joueurs, staff, police… visibles seulement en service.' },
    { k = 'hud_style', type = 'select', label = 'Affichage du tableau', opts = { { 'bar', 'Barre en haut de l\'écran' }, { 'box', 'Encart sur le côté' } }, default = 'bar', hint = 'La barre s\'affiche en haut au centre, seulement quand tu es en service.' },
    { k = 'hud_items', type = 'list', label = 'Infos affichées, dans l\'ordre (online, staff, reports, bda, mine, dead, police, ems, queue, sanctions)', default = { 'online', 'staff', 'reports', 'bda' }, maxitems = 8, maxlen = 12, pattern = '^[%w_]+$', wide = true },
    { k = 'bda_channel', type = 'text', label = "Salon vocal Discord d'attente du support (identifiant)", default = '', maxlen = 24, pattern = '^%d*$', hint = "Case « bda » : joueurs connectés présents dans ce salon vocal. Mode développeur Discord → clic droit sur le salon → Copier l'identifiant. Il faut le jeton du bot et l'identifiant du serveur (module Discord)." },
    { k = 'bda_label', type = 'text', label = 'Nom de la case « bda »', default = 'Joueurs en BDA', maxlen = 30 },
    { k = 'hud_top', type = 'number', label = 'Barre : distance du haut (%)', default = 0.8, min = 0, max = 30, int = false },
    { k = 'hud_x', type = 'number', label = 'Encart latéral : position horizontale (%)', default = 1.2, min = 0, max = 95, int = false },
    { k = 'hud_y', type = 'number', label = 'Encart latéral : position verticale (%)', default = 30, min = 0, max = 95, int = false },
    { k = 'reports_on', type = 'toggle', label = 'Signalements joueurs (/report)', default = true },
    { k = 'report_cooldown', type = 'number', label = 'Délai entre deux signalements (s)', default = 60, min = 10, max = 3600 },
    { k = 'money_max', type = 'number', label = "Plafond d'un don d'argent", default = 1000000, min = 1, max = 100000000 },
    { k = 'item_max', type = 'number', label = "Plafond d'objets par don", default = 500, min = 1, max = 5000 },
    { k = 'ban_presets', type = 'list', label = 'Durées de bannissement (libellé|minutes, 0 = définitif)', default = { '1 heure|60', '1 jour|1440', '3 jours|4320', '7 jours|10080', '30 jours|43200', 'Définitif|0' }, maxitems = 10, maxlen = 40, pattern = '^[^|]+|%d+$', wide = true },
    { k = 'announce_presets', type = 'list', label = 'Annonces rapides (libellé|texte)', default = {}, maxitems = 10, maxlen = 220, pattern = '^[^|]+|.+$', wide = true },
    { k = 'spawn_presets', type = 'list', label = 'Véhicules proposés (noms de modèles)', default = { 'adder', 'sultan', 'panto', 'blista', 'police', 'ambulance', 'bmx' }, maxitems = 20, maxlen = 32, pattern = '^[%w_]+$', wide = true },
    { k = 'order', type = 'list', label = 'Ordre des catégories (identifiants : players, self, vehicles, server, reports, sanctions, panel)', default = {}, maxitems = 10, maxlen = 16, pattern = '^[%w_]+$', wide = true, hint = "Vide = ordre par défaut. Chaque staff peut ensuite réorganiser son propre menu depuis le menu lui-même." },
    { k = 'hide', type = 'list', label = 'Catégories masquées pour tout le monde', default = {}, maxitems = 10, maxlen = 16, pattern = '^[%w_]+$', wide = true },
} })

local function dur(ts) if ts == 0 then return 'Définitif' end return fmtDate(ts) end
PB.Action('staff.unban', 'staff.unban', function(ctx, p)
    local id = math.floor(tonumber(p.sid) or 0)
    local r = DB.one("SELECT id, name FROM pb_sanctions WHERE id = ? AND kind = 'ban' AND revoked = 0", { id })
    if not r then return false, 'Bannissement introuvable.' end
    DB.exec('UPDATE pb_sanctions SET revoked = 1, revoked_by = ? WHERE id = ?', { ctx.actor.name:sub(1, 64), id })
    ctx.audit('staff', 'unban', r.name, nil, { id = id })
    ctx.toast = r.name .. ' est débanni.'
    return true
end, { critical = true, confirm = { title = 'Lever ce bannissement ?', text = 'La personne pourra se reconnecter immédiatement.' } })
PB.Action('staff.report.close', 'staff.reports', function(ctx, p)
    local id = math.floor(tonumber(p.rid) or 0)
    DB.exec("UPDATE pb_reports SET status = 'closed', closed_at = ?, claimed_by = ? WHERE id = ?", { now(), ctx.actor.name:sub(1, 64), id })
    ctx.toast = 'Signalement clos.'
    return true
end)

PB.Action('staff.undo', 'staff.undo', function(ctx, p)
    if not ctx.src or ctx.src <= 0 then return false, "Disponible seulement en jeu : connecte-toi au serveur." end
    local ok, msg = S.Undo(ctx.src, p.id)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end, { critical = true, confirm = { title = 'Annuler cette action du staff ?', text = "L'effet sera défait sur le joueur." } })
PB.Module({
    id = 'staff', label = 'Menu staff (F10)', icon = 'shield', group = 'Serveur', order = 142, perm = 'staff.edit', hint = 'Outil staff en jeu : sanctions, outils, signalements',
    caps = function()
        return PB.Capsify({
            { 'Menu staff en jeu (F10) au format RageUI', 'ok', "Catégories filtrées par permission, réorganisables par chaque membre de l'équipe." },
            { 'Sanctions : avertir, expulser, bannir (durée), lever', 'ok', "Le bannissement s'applique à la connexion sur la licence et sur les autres identifiants connus." },
            { 'Hiérarchie respectée', 'ok', 'On ne peut pas sanctionner, geler ou téléporter de force un rang égal ou supérieur.' },
            { 'Noclip, invincibilité, invisibilité, noms au-dessus des têtes', 'ok', 'Le serveur autorise (permission + service), le client exécute.' },
            { 'Signalements /report', 'ok', 'Liste dans le menu : aller vers le joueur, prendre en charge, clore.' },
            { 'Observer un joueur', 'partial', "Utilise le mode spectateur du jeu : fonctionne avec OneSync, la vue peut être limitée loin du joueur." },
            { "Voir l'inventaire d'un joueur", 'partial', "Résumé des 8 premiers objets (droit sensible) ; pas d'ouverture complète du sac." },
        })
    end,
    doc = "## Menu staff\nTouche **F10** (réglable). Le staff passe d'abord **en service**, puis voit les catégories que ses permissions autorisent. Les permissions sont dans **Grades et permissions** (groupe *staff*).\n\n- Le propriétaire (et tout grade avec `panel.open`) a l'entrée **Ouvrir le panel de configuration**.\n- Les touches F10 du panel sont libérées : le panel s'ouvre par `/panel` ou depuis ce menu.\n- Chaque membre peut réorganiser son menu (dernière entrée : *Réorganiser ce menu*).\n\n### Pour développeurs\n`exports.pb_panel:IsStaffOnDuty(source)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'staff', title = 'Menu staff (exemple)', cfg = PB.Cfg.All('menus') }, { type = 'gpreview', kind = 'staffhud', title = 'Barre staff en service (exemple)', cfg = {} } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
            { id = 'journal', label = 'Journal', icon = 'history', build = function()
                if not ctx.has('staff.journal') then return { B.notice('warn', "Tu n'as pas le droit de voir le journal du staff.") } end
                local rows = {}
                for _, r in ipairs(S.Journal(300)) do
                    local undone = (tonumber(r.undone) or 0) > 0
                    local can = r.undo and r.undo ~= '' and not undone and now() - (tonumber(r.at) or 0) <= 86400 and ctx.has('staff.undo')
                    rows[#rows + 1] = { at = r.at, who = r.actor_name, what = S.JournalLabel(r.action), target = r.target_name, detail = r.detail,
                        state = undone and ('annulée par ' .. r.undone_by) or (r.undo and r.undo ~= '' and 'annulable' or ''),
                        actions = can and { { action = 'staff.undo', label = 'Annuler', icon = 'refresh', payload = { id = r.id } } } or {} }
                end
                return { B.notice('info', "Chaque action du menu staff est notée ici. « Annuler » défait l'argent, les objets, le gel, le silence, la téléportation, le bannissement et la prison (24 h, une seule fois)."),
                    B.table({ id = 'sjournal', title = 'Journal des actions du staff', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'who', label = 'Staff' }, { k = 'what', label = 'Action', type = 'badge' },
                        { k = 'target', label = 'Joueur' }, { k = 'detail', label = 'Détail' }, { k = 'state', label = 'État' } }, rows = rows, empty = 'Aucune action pour le moment.' }) }
            end },
            { id = 'bans', label = 'Bannissements', icon = 'shield', build = function()
                local rows = {}
                for _, r in ipairs(DB.q("SELECT id, name, reason, by_name, created, expires FROM pb_sanctions WHERE kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) ORDER BY id DESC LIMIT 200", { now() }) or {}) do
                    rows[#rows + 1] = { name = r.name, reason = r.reason, by = r.by_name, at = r.created, until_ = dur(r.expires), actions = ctx.has('staff.unban') and { { action = 'staff.unban', label = 'Lever', icon = 'check', payload = { sid = r.id } } } or {} }
                end
                return { B.table({ id = 'bans', title = 'Bannissements actifs (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Joueur' }, { k = 'reason', label = 'Motif' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Date', type = 'date' }, { k = 'until_', label = "Jusqu'au" } }, rows = rows, empty = 'Aucun bannissement actif.' }) }
            end },
            { id = 'history', label = 'Historique', icon = 'history', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT name, kind, reason, by_name, created FROM pb_sanctions ORDER BY id DESC LIMIT 200') or {}) do rows[#rows + 1] = { name = r.name, kind = r.kind, reason = r.reason, by = r.by_name, at = r.created } end
                return { B.table({ id = 'hist', title = 'Dernières sanctions', search = true, columns = { { k = 'name', label = 'Joueur' }, { k = 'kind', label = 'Type', type = 'badge' }, { k = 'reason', label = 'Motif' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Aucune sanction.' }) }
            end },
            { id = 'reports', label = 'Signalements', icon = 'help', build = function()
                local rows = {}
                for _, r in ipairs(DB.q("SELECT id, name, text, status, claimed_by, created FROM pb_reports ORDER BY (status <> 'closed' AND vip = 1) DESC, id DESC LIMIT 100") or {}) do
                    rows[#rows + 1] = { name = r.name, text = r.text, status = r.status, by = r.claimed_by, at = r.created, actions = (ctx.has('staff.reports') and r.status ~= 'closed') and { { action = 'staff.report.close', label = 'Clore', icon = 'check', payload = { rid = r.id } } } or {} }
                end
                return { B.table({ id = 'reps', title = 'Signalements', search = true, columns = { { k = 'name', label = 'Joueur' }, { k = 'text', label = 'Message' }, { k = 'status', label = 'État', type = 'badge' }, { k = 'by', label = 'Pris par' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Aucun signalement.' }) }
            end },
        } }
    end,
})

PB.SelfTest.Add('menu staff', function(R)
    for id, a in pairs(ACT) do R.check(type(a.run) == 'function' and type(a.perm) == 'string', 'action staff « ' .. id .. ' »', 'définition incomplète') end
    for _, c in ipairs(CATS) do R.check(c.perm ~= nil, 'catégorie « ' .. c.id .. ' »', 'sans permission') end
    for _, line in ipairs(cfg('ban_presets', {}) or {}) do R.check(tostring(line):match('^(.-)|(%d+)$') ~= nil, 'durée de ban « ' .. tostring(line) .. ' »', 'format libellé|minutes') end
end)

-- Donne les droits du menu aux grades Modérateur / Support une seule fois (les grades déjà personnalisés ne sont jamais écrasés ensuite).
local function seed(flag, give)
    if PB.Cfg.Get('staff', flag, false) then return end
    for gname, perms in pairs(give) do
        if P.Grade(gname) then
            for _, perm in ipairs(perms) do DB.exec('INSERT IGNORE INTO pb_grade_perms (grade, perm, allow_v) VALUES (?, ?, 1)', { gname, perm }) end
        end
    end
    PB.Cfg.Set('staff', flag, true, 'système', 'Droits staff par défaut', true)
    if P.Reload then P.Reload() end
end
PB.OnReady(function()
    seed('seeded', {
        moderator = { 'staff.menu', 'staff.players', 'staff.teleport', 'staff.heal', 'staff.freeze', 'staff.spectate', 'staff.warn', 'staff.kick', 'staff.vehicle', 'staff.announce', 'staff.self', 'staff.reports' },
        support = { 'staff.menu', 'staff.players', 'staff.teleport', 'staff.heal', 'staff.warn', 'staff.reports', 'staff.self' },
    })
    seed('seeded2', { moderator = { 'staff.mute', 'staff.notes' }, support = { 'staff.notes' } })
    seed('seeded3', { moderator = { 'staff.gestures' } })
    seed('seeded4', { moderator = { 'staff.whisper' }, support = { 'staff.whisper' } })
end)
