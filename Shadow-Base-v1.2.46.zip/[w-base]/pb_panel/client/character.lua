-- Créateur de personnage, application de l'apparence, écran de mort. Les règles viennent du panel, le serveur valide chaque envoi.

local G = PBG

local function loadModel(name)
    local h = GetHashKey(name)
    RequestModel(h)
    local t = GetGameTimer()
    while not HasModelLoaded(h) and GetGameTimer() - t < 6000 do Wait(10) end
    return h
end
G.loadModel = loadModel

-- Apparence ------------------------------------------------------------------------------------------------------------------------
local OVERLAY_COLOR = { [1] = 1, [2] = 1, [10] = 1, [5] = 2, [8] = 2 }   -- barbe, sourcils, torse : teinte cheveux ; blush, rouge à lèvres : teinte maquillage
local COMP_ORDER = { 1, 3, 4, 5, 6, 7, 8, 9, 10, 11 }

-- target (facultatif) : un autre ped à habiller (ex. les personnages de l'écran d'entrée) ; sans target, le joueur
function G.applyAppearance(a, setModel, target)
    if type(a) ~= 'table' or not a.head then return end
    -- ped de service staff : on garde le ped ; la tenue / coiffure sera remise en quittant le service
    if G.staffPed and not target then G.appearance = a return end
    local ped = target or PlayerPedId()
    if setModel and not target and a.model and GetEntityModel(ped) ~= GetHashKey(a.model) then
        local h = loadModel(a.model)
        SetPlayerModel(PlayerId(), h)
        SetModelAsNoLongerNeeded(h)
        ped = PlayerPedId()
    end
    SetPedDefaultComponentVariation(ped)
    SetPedHeadBlendData(ped, a.head.mother, a.head.father, 0, a.head.mother, a.head.father, 0, a.head.shape + 0.0, a.head.skin + 0.0, 0.0, false)
    for i = 1, 20 do SetPedFaceFeature(ped, i - 1, (a.face[i] or 0.0) + 0.0) end
    SetPedComponentVariation(ped, 2, a.hair.style, 0, 2)
    SetPedHairColor(ped, a.hair.color, a.hair.highlight)
    SetPedEyeColor(ped, a.eye)
    for i = 1, 13 do
        local o = a.ov[i]
        if o then
            SetPedHeadOverlay(ped, i - 1, o.s, o.o + 0.0)
            local ct = OVERLAY_COLOR[i - 1]
            if ct and o.s ~= 255 then SetPedHeadOverlayColor(ped, i - 1, ct, o.c, o.c) end
        end
    end
    for _, comp in ipairs(COMP_ORDER) do
        local c = a.comps[comp + 1]
        if c then SetPedComponentVariation(ped, comp, c.d, c.t, 2) end
    end
    for id = 0, 7 do if id == 0 or id == 1 or id == 2 or id == 6 or id == 7 then ClearPedProp(ped, id) end end
    for _, pr in ipairs(a.props or {}) do
        if pr.d >= 0 then SetPedPropIndex(ped, pr.id, pr.d, pr.t, true) end
    end
    ClearPedDecorations(ped)
    for _, t in ipairs(a.tattoos or {}) do AddPedDecorationFromHashes(ped, t.c, t.o) end
end

-- le modèle est remis à zéro à chaque (re)apparition : on réapplique l'apparence enregistrée
AddEventHandler('playerSpawned', function()
    if G.appearance and G.begun and not G.creating then
        CreateThread(function() Wait(600) G.applyAppearance(G.appearance, true) end)
    end
end)
exports('ApplyAppearance', function(a) G.applyAppearance(a, true) end)
exports('GetAppearance', function() return G.appearance end)

-- Créateur --------------------------------------------------------------------------------------------------------------------------
local cam, camMode = nil, 'face'
local CAMS = { face = { 0.0, 0.85, 0.66, 0.66 }, body = { 0.0, 2.4, 0.2, 0.15 }, feet = { 0.0, 1.5, -0.55, -0.6 } }

local function setCam(mode)
    if G.flying then ClearFocus() G.flying = false end
    camMode = mode or camMode
    local ped = PlayerPedId()
    local c = CAMS[camMode] or CAMS.face
    local pos = GetOffsetFromEntityInWorldCoords(ped, c[1], c[2], c[3])
    local tgt = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.0, c[4])
    if not cam then
        cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        RenderScriptCams(true, true, 400, true, true)
    end
    SetCamCoord(cam, pos.x, pos.y, pos.z)
    PointCamAtCoord(cam, tgt.x, tgt.y, tgt.z)
    SetCamActive(cam, true)
end

local function limits()
    local ped = PlayerPedId()
    local L = { comps = {}, props = {}, overlays = {}, hairColors = GetNumHairColors(), makeupColors = GetNumMakeupColors() }
    for i = 0, 11 do L.comps[i + 1] = GetNumberOfPedDrawableVariations(ped, i) end
    for _, id in ipairs({ 0, 1, 2, 6, 7 }) do L.props[tostring(id)] = GetNumberOfPedPropDrawableVariations(ped, id) end
    for i = 0, 12 do L.overlays[i + 1] = GetPedHeadOverlayNum(i) end
    return L
end

-- Survol du point de départ choisi : la caméra se déplace au-dessus de l'endroit (le serveur ne reçoit que l'identifiant à la validation).
local function flyTo(p)
    local x, y, z = p.x + 0.0, p.y + 0.0, p.z + 0.0
    G.flying = true
    SetFocusPosAndVel(x, y, z, 0.0, 0.0, 0.0)
    RequestCollisionAtCoord(x, y, z)
    local c2 = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', x, y - 48.0, z + 26.0, -22.0, 0.0, (p.h or 0) + 0.0, 55.0, true, 2)
    PointCamAtCoord(c2, x, y, z + 4.0)
    if cam then
        SetCamActiveWithInterp(c2, cam, 1400, 1, 1)
        local old = cam
        CreateThread(function() Wait(1500) DestroyCam(old, false) end)
    else
        SetCamActive(c2, true) RenderScriptCams(true, true, 800, true, true)
    end
    cam = c2
end

G.setCam, G.limits = setCam, limits
function G.camOff() if cam then RenderScriptCams(false, true, 300, true, true) DestroyCam(cam, false) cam = nil end end

function G.startCreator()
    G.creating, G.hidden = true, true
    DoScreenFadeOut(300) Wait(450)
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    G.applyAppearance({ model = 'mp_m_freemode_01', head = { mother = 21, father = 0, shape = 0.5, skin = 0.5 }, face = (function() local t = {} for i = 1, 20 do t[i] = 0.0 end return t end)(),
        hair = { style = 0, color = 0, highlight = 0 }, eye = 0, ov = (function() local t = {} for i = 1, 13 do t[i] = { s = 255, o = 1.0, c = 0 } end return t end)(),
        comps = (function() local t = {} for i = 1, 12 do t[i] = { d = 0, t = 0 } end return t end)(), props = {} }, true)
    ped = PlayerPedId()
    SetEntityCoords(ped, c.x, c.y, c.z, false, false, false, false)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetEntityHeading(ped, 0.0)
    setCam('face')
    RequestStreamedTextureDict('char_creator_portraits', false)   -- portraits des parents (https://nui-img/char_creator_portraits/…)
    G.focus(true)
    G.send('creator.open', { cfg = G.cfg.character or {}, limits = limits(), brand = G.cfg.brand })
    DoScreenFadeIn(500)
    CreateThread(function()
        while G.creating do DisableAllControlActions(0) Wait(0) end
    end)
end

local function endCreator(spawn)
    G.send('creator.close', {})
    SetStreamedTextureDictAsNoLongerNeeded('char_creator_portraits')
    DoScreenFadeOut(300) Wait(400)
    if cam then RenderScriptCams(false, false, 0, true, true) DestroyCam(cam, false) cam = nil end
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    SetEntityInvincible(ped, false)
    if type(spawn) == 'table' then
        SetEntityCoords(ped, spawn.x + 0.0, spawn.y + 0.0, spawn.z + 0.0, false, false, false, false)
        SetEntityHeading(ped, (spawn.h or 0) + 0.0)
        RequestCollisionAtCoord(spawn.x + 0.0, spawn.y + 0.0, spawn.z + 0.0)
        local t = GetGameTimer()
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 4000 do Wait(50) end
    end
    ClearFocus()
    G.flying = false
    G.creating, G.hidden = false, false
    G.focus(false)
    Wait(300)
    DoScreenFadeIn(600)
end

G.nui['creator.limits'] = function(d) return limits() end
G.nui['creator.textures'] = function(d)
    local ped = PlayerPedId()
    local id, dr = tonumber(d.id), tonumber(d.drawable)
    if not id or not dr then return { n = 1 } end
    if d.kind == 'prop' then return { n = math.max(1, GetNumberOfPedPropTextureVariations(ped, id, dr)) } end
    return { n = math.max(1, GetNumberOfPedTextureVariations(ped, id, dr)) }
end
G.nui['creator.preview'] = function(d)
    if not (G.creating or G.wardrobe) or type(d.appearance) ~= 'table' then return {} end
    G.applyAppearance(d.appearance, true)
    if d.sexChanged then
        FreezeEntityPosition(PlayerPedId(), true) SetEntityInvincible(PlayerPedId(), true)
        setCam(camMode)
        return limits()
    end
    return {}
end
G.nui['creator.spawn'] = function(d)
    if not G.creating then return {} end
    local pts = (G.cfg.character or {}).spawn_points or {}
    for _, p in ipairs(pts) do
        if p.id == tostring(d.id) and p.enabled ~= false then flyTo(p) break end
    end
    return {}
end
G.nui['creator.cam'] = function(d) if G.creating or G.wardrobe then setCam(tostring(d.mode)) end return {} end
G.nui['creator.rotate'] = function(d)
    if G.creating or G.wardrobe then local ped = PlayerPedId() SetEntityHeading(ped, GetEntityHeading(ped) + (tonumber(d.delta) or 0) * 1.0) end
    return {}
end
G.nui['creator.submit'] = function(d)
    if G.creating and type(d.data) == 'table' then TriggerServerEvent('pb:g:create', d.data) end
    return {}
end

RegisterNetEvent('pb:g:createError', function(msg) G.send('creator.error', { text = tostring(msg) }) end)
RegisterNetEvent('pb:g:created', function(j)
    local d = G.decode(j)
    if not d then return end
    G.appearance = d.appearance
    endCreator(d.spawn)
    G.applyAppearance(d.appearance, true)
end)

-- Début de session ------------------------------------------------------------------------------------------------------------------
RegisterNetEvent('pb:g:begin', function(j)
    local d = G.decode(j)
    if not d then return end
    G.begun = true
    G.identity, G.appearance = d.identity, d.appearance
    G.state.dead = d.dead and true or false
    local creator = G.cfg.character
    if not d.created and (not creator or creator.enabled ~= false) then
        G.startCreator()
        return
    end
    -- arrivée depuis l'écran d'entrée : la transition du jeu (ciel puis zooms) place le joueur (client/entrance.lua)
    if G.arriving and G.EntranceArrive then G.EntranceArrive(d) return end
    if d.appearance then CreateThread(function() Wait(900) G.applyAppearance(d.appearance, true) end) end
    if type(d.pos) == 'table' and tonumber(d.pos.x) then
        -- reconnexion à la dernière position : fondu, chargement du décor, placement, puis l'écran de mort s'il y a lieu
        CreateThread(function()
            DoScreenFadeOut(300) Wait(350)
            local x, y, z = d.pos.x + 0.0, d.pos.y + 0.0, d.pos.z + 0.0
            RequestCollisionAtCoord(x, y, z)
            local ped = PlayerPedId()
            FreezeEntityPosition(ped, true)
            SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)
            SetEntityHeading(ped, (tonumber(d.pos.h) or 0) + 0.0)
            local t = GetGameTimer()
            while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 5000 do Wait(50) ped = PlayerPedId() end
            FreezeEntityPosition(ped, false)
            Wait(200)
            DoScreenFadeIn(600)
            if d.dead then Wait(300) G.startDeath() end
        end)
        return
    end
    if d.dead then CreateThread(function() Wait(1500) G.startDeath() end) end
end)

exports('GetIdentity', function() return G.identity end)

-- Mort ---------------------------------------------------------------------------------------------------------------------------------
local deathAnim = { dict = 'dead', name = 'dead_a' }

local function resurrect(x, y, z, h, healthPct)
    local ped = PlayerPedId()
    NetworkResurrectLocalPlayer(x, y, z, h, true, false)
    ped = PlayerPedId()
    ClearPedTasksImmediately(ped)
    ClearPedBloodDamage(ped)
    local maxHp = GetEntityMaxHealth(ped)
    SetEntityHealth(ped, math.floor(100 + (maxHp - 100) * (healthPct or 100) / 100))
    SetPlayerInvincible(PlayerId(), false)
    StopScreenEffect('DeathFailOut')
end

function G.startDeath()
    local d = G.cfg.death or {}
    if G.dead or d.enabled == false then return end
    G.dead = true
    G.state.dead = true
    -- (v1.2.43) tomber avec une interface ouverte (téléphone, sac, banque, magasin, menu…) la laissait par-dessus l'écran de mort, souris comprise
    if G.Menu and G.Menu.IsOpen and G.Menu.IsOpen() then pcall(G.Menu.Close) end
    if G.ForceClose then pcall(G.ForceClose, 'mort') end
    local c = GetEntityCoords(PlayerPedId())
    local h = GetEntityHeading(PlayerPedId())
    resurrect(c.x, c.y, c.z, h, 20)
    SetPlayerInvincible(PlayerId(), true)
    StartScreenEffect('DeathFailOut', 0, false)
    G.staffRevive = false
    local shown = d
    if G.comaWhy then
        shown = {}
        for k, v in pairs(d) do shown[k] = v end
        shown.title = 'Coma'
        shown.subtitle = G.comaWhy == 'thirst' and "Tu t'es évanoui de soif. Un secouriste peut te réanimer." or "Tu t'es évanoui de faim. Un secouriste peut te réanimer."
        G.comaWhy = nil
    end
    G.send('death.open', { cfg = shown, delay = d.respawn_delay or 120 })
    TriggerServerEvent('pb:g:staff:canrevive')
    RequestAnimDict(deathAnim.dict)
    CreateThread(function()
        local holdStart
        local started = GetGameTimer()
        local lastEms, lastStaff = -1e9, -1e9
        while G.dead do
            local ped = PlayerPedId()
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true) EnableControlAction(0, 2, true)           -- regarder autour
            EnableControlAction(0, 38, true) EnableControlAction(0, 47, true) EnableControlAction(0, 74, true)   -- E, G, H
            EnableControlAction(0, 245, true) EnableControlAction(0, 249, true)       -- chat, push-to-talk
            if not IsEntityPlayingAnim(ped, deathAnim.dict, deathAnim.name, 3) and HasAnimDictLoaded(deathAnim.dict) then
                TaskPlayAnim(ped, deathAnim.dict, deathAnim.name, 8.0, -8.0, -1, 1, 0.0, false, false, false)
            end
            local elapsed = (GetGameTimer() - started) / 1000
            local ready = elapsed >= (d.respawn_delay or 120)
            if d.allow_ems ~= false and (IsControlJustPressed(0, 38) or IsDisabledControlJustPressed(0, 38)) and GetGameTimer() - lastEms > 3000 then
                lastEms = GetGameTimer()
                local p = GetEntityCoords(ped)
                TriggerServerEvent('pb:g:ems', p.x, p.y, p.z)
            end
            if G.staffRevive and (IsControlJustPressed(0, 74) or IsDisabledControlJustPressed(0, 74)) and GetGameTimer() - lastStaff > 1500 then
                lastStaff = GetGameTimer()
                TriggerServerEvent('pb:g:staff:selfrevive')
            end
            -- G peut être désactivée par un autre script (touche « détoner » des armes) : on lit aussi l'état désactivé
            if ready and (IsControlPressed(0, 47) or IsDisabledControlPressed(0, 47)) then
                holdStart = holdStart or GetGameTimer()
                G.send('death.hold', { p = math.min(1, (GetGameTimer() - holdStart) / 1500) })
                if GetGameTimer() - holdStart >= 1500 then
                    holdStart = nil
                    TriggerServerEvent('pb:g:respawn')
                    Wait(1500)
                end
            elseif holdStart then
                holdStart = nil
                G.send('death.hold', { p = 0 })
            end
            Wait(0)
        end
    end)
end

local function stopDeath()
    G.dead = false
    G.staffRevive = false
    G.state.dead = false
    G.send('death.close', {})
end

CreateThread(function()
    while true do
        Wait(400)
        local d = G.cfg.death
        if G.begun and not G.dead and not G.creating and (not d or d.enabled ~= false) and IsEntityDead(PlayerPedId()) then
            -- qui m'a tué (joueur à pied ou conducteur du véhicule), avec quelle arme : journal des morts du staff
            local ped = PlayerPedId()
            local by, killer = GetPedSourceOfDeath(ped), 0
            if by and by ~= 0 and DoesEntityExist(by) then
                if IsEntityAVehicle(by) then by = GetPedInVehicleSeat(by, -1) end
                if by and by ~= 0 and IsPedAPlayer(by) and by ~= ped then killer = GetPlayerServerId(NetworkGetPlayerIndexFromPed(by)) end
            end
            TriggerServerEvent('pb:g:died', killer, GetPedCauseOfDeath(ped))
            G.startDeath()
        end
    end
end)

RegisterNetEvent('pb:g:respawnAt', function(j)
    local d = G.decode(j)
    if not d or not d.pos then return end
    DoScreenFadeOut(500) Wait(600)
    stopDeath()
    resurrect(d.pos.x + 0.0, d.pos.y + 0.0, d.pos.z + 0.0, (d.pos.h or 0) + 0.0, d.health or 100)
    Wait(300)
    DoScreenFadeIn(800)
end)

RegisterNetEvent('pb:g:staff:canrevive', function(ok)
    if not G.dead then return end
    G.staffRevive = ok == true
    G.send('death.staff', { on = G.staffRevive })
end)

RegisterNetEvent('pb:g:revive', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local pct = (G.cfg.death and G.cfg.death.revive_health) or 50
    stopDeath()
    resurrect(c.x, c.y, c.z, GetEntityHeading(ped), pct)
end)

-- Point de secours sur la carte des secouristes
local emsBlips = {}
RegisterNetEvent('pb:g:emsBlip', function(j)
    local p = G.decode(j)
    if not p then return end
    local key = tostring(p.id or (math.floor(p.x) .. ':' .. math.floor(p.y)))
    if emsBlips[key] and DoesBlipExist(emsBlips[key]) then RemoveBlip(emsBlips[key]) end   -- nouvel appel du même joueur : on remplace, on n'empile pas
    local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
    emsBlips[key] = b
    SetBlipSprite(b, 153) SetBlipColour(b, 1) SetBlipScale(b, 1.0) SetBlipFlashes(b, true) SetBlipRoute(b, true)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Joueur à terre') EndTextCommandSetBlipName(b)
    SetTimeout(300000, function() if DoesBlipExist(b) then RemoveBlip(b) end if emsBlips[key] == b then emsBlips[key] = nil end end)
end)
