-- Menu ALT : tant que la touche est maintenue, on affiche un point sur soi et sur les personnes visibles à portée ; un clic envoie
-- seulement l'identifiant choisi au serveur, qui renvoie la liste des entrées permises. Ce fichier ne décide d'aucun droit.
local G = PBG
local holding, menuOpen, lastKey = false, false, ''
local visible = {}              -- clés « type:identifiant » cliquables en ce moment (p = personne, v = véhicule, o = objet)
local pickKind = 'p'
local ents, hovered = {}, nil     -- clé « type:identifiant » -> entité ; entité survolée (rendue translucide)
-- Portes (staff seulement, si la ressource des portes tourne) : le serveur dit si on y a droit ; la liste est recalculée toutes les 0,5 s
local doorCaps, doorCapsAt, doorList, doorScanAt = false, -60000, {}, 0
RegisterNetEvent('pb:g:ctx:caps', function(on) doorCaps = on == true doorCapsAt = GetGameTimer() end)
-- Une porte : le jeu ne le dit pas, on le devine à la forme : objet fin (moins de 60 cm, cadre compris), de 1,2 à 8 m de haut
-- et de 0,4 à 9 m de large (portes simples et doubles, grilles, portails, portes de garage), jamais accroché à quelqu'un.
-- Les portes déjà connues de la base (verrouillables) sont toujours retenues, quelle que soit leur forme.
local knownDoor = {}
RegisterNetEvent('pb:g:ctx:knownDoors', function(list) knownDoor = {} for _, h in ipairs(type(list) == 'table' and list or {}) do knownDoor[tonumber(h) or 0] = true end end)
local function isDoorLike(obj)
    local model = GetEntityModel(obj)
    if knownDoor[model] then return true end
    if IsEntityAttached(obj) or IsEntityAPed(obj) or IsEntityAVehicle(obj) then return false end
    local ok, mn, mx = pcall(function() local a, b = GetModelDimensions(model) return a, b end)
    if not ok or not mn then return false end
    local dx, dy, dz = mx.x - mn.x, mx.y - mn.y, mx.z - mn.z
    local thin, wide = math.min(dx, dy), math.max(dx, dy)
    return thin < 0.6 and wide >= 0.4 and wide <= 9.0 and dz >= 1.2 and dz <= 8.0
end
local function outlineDoors(on)
    for _, o in ipairs(doorList) do if DoesEntityExist(o) then SetEntityDrawOutline(o, on) end end
    if on then SetEntityDrawOutlineColor(255, 200, 80, 255) end
end
local function scanDoors(mc)
    local now = GetGameTimer()
    if now < doorScanAt then return end
    doorScanAt = now + 500
    outlineDoors(false)
    local found = {}
    for _, obj in ipairs(GetGamePool('CObject')) do
        if DoesEntityExist(obj) and #(GetEntityCoords(obj) - mc) < 12.0 and isDoorLike(obj) then found[#found + 1] = obj end
    end
    table.sort(found, function(a, b) return #(GetEntityCoords(a) - mc) < #(GetEntityCoords(b) - mc) end)
    doorList = {}
    for i = 1, math.min(#found, 16) do doorList[i] = found[i] end
    outlineDoors(true)
end


local function r4(v) return math.floor(v * 10000) / 10000 end
-- Rectangle écran (centre + taille, 0..1) qui entoure l'entité : on projette les 8 coins de sa boîte. nil si illisible.
local function screenBox(ent)
    local ok, mn, mx = pcall(function() local a, b = GetModelDimensions(GetEntityModel(ent)) return a, b end)
    if not ok or not mn or not mx then return nil end
    local x0, y0, x1, y1 = 2, 2, -1, -1
    for _, cx in ipairs({ mn.x, mx.x }) do for _, cy in ipairs({ mn.y, mx.y }) do for _, cz in ipairs({ mn.z, mx.z }) do
        local w = GetOffsetFromEntityInWorldCoords(ent, cx, cy, cz)
        local o, sx, sy = GetScreenCoordFromWorldCoord(w.x, w.y, w.z)
        if o then x0, y0, x1, y1 = math.min(x0, sx), math.min(y0, sy), math.max(x1, sx), math.max(y1, sy) end
    end end end
    if x1 < x0 or y1 < y0 then return nil end
    x0, y0, x1, y1 = math.max(0, x0), math.max(0, y0), math.min(1, x1), math.min(1, y1)
    if x1 - x0 < 0.015 or y1 - y0 < 0.03 then return nil end
    return r4((x0 + x1) / 2), r4((y0 + y1) / 2), r4(x1 - x0), r4(y1 - y0)
end

local function cfg() return G.cfg and G.cfg.ctx or {} end
local function busy() return G.locked > 0 and not menuOpen or G.creating or G.wardrobe or G.state.dead or not G.begun or (G.shopIsOpen and G.shopIsOpen()) end

local function restoreFocus()
    SetNuiFocusKeepInput(false)
    SetNuiFocus(G.locked > 0, G.locked > 0)
end

local function unhover()
    if hovered and DoesEntityExist(hovered) then ResetEntityAlpha(hovered) end
    hovered = nil
end

local function stopHold()
    unhover()
    outlineDoors(false)
    doorList = {}
    if not holding then return end
    holding = false
    lastKey = ''
    G.send('ctx.spots', { p = {} })
    if not menuOpen then restoreFocus() G.send('ctx.hide', {}) end
end

local function closeMenu()
    if not menuOpen then return end
    menuOpen = false
    G.send('ctx.close', {})
    if holding then SetNuiFocus(true, true) SetNuiFocusKeepInput(true) else restoreFocus() end
end

RegisterCommand('+pb_ctx', function()
    local c = cfg()
    if c.enabled == false or holding or menuOpen or busy() or IsPauseMenuActive() then return end
    holding = true
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(true)
    if GetGameTimer() - doorCapsAt > 60000 then doorCapsAt = GetGameTimer() TriggerServerEvent('pb:g:ctx:caps') end
    CreateThread(function()
        local me = PlayerPedId()
        while holding do
            Wait(0)
            -- le curseur est libre : on empêche la caméra de bouger et les clics d'attaquer
            for _, k in ipairs({ 1, 2, 24, 25, 68, 69, 70, 91, 92, 140, 141, 142, 257, 263, 264 }) do DisableControlAction(0, k, true) end
            if IsEntityDead(PlayerPedId()) then stopHold() break end
        end
    end)
    CreateThread(function()
        while holding do
            local cc = cfg()
            local me = PlayerPedId()
            local mc = GetEntityCoords(me)
            local maxd = (tonumber(cc.range) or 15) + 0.0
            local out, ids = {}, {}
            local myId = GetPlayerServerId(PlayerId())
            local function add(pl, ped, self_)
                local sid = GetPlayerServerId(pl)
                local bc = GetPedBoneCoords(ped, 24818, 0.0, 0.0, 0.0)
                local ok, x, y = GetScreenCoordFromWorldCoord(bc.x, bc.y, bc.z + 0.1)
                local bx, by, bw, bh = screenBox(ped)
                if bx then ok, x, y = true, bx, by end
                if ok then
                    out[#out + 1] = { i = sid, k = 'p', x = r4(x), y = r4(y), w = bw, h = bh, me = self_ and 1 or 0 }
                    ids['p:' .. sid] = true
                    ents['p:' .. sid] = ped
                end
            end
            if cc.show_self ~= false then add(PlayerId(), me, true) end
            if cc.show_others ~= false then
                for _, pl in ipairs(GetActivePlayers()) do
                    if pl ~= PlayerId() then
                        local ped = GetPlayerPed(pl)
                        if ped ~= 0 and DoesEntityExist(ped) and IsEntityVisible(ped) and #(GetEntityCoords(ped) - mc) <= maxd and (cc.walls == true or HasEntityClearLosToEntity(me, ped, 17)) then add(pl, ped, false) end
                    end
                end
            end
            -- véhicules visibles à portée
            if cc.show_vehicles ~= false and GetGamePool then
                local myVeh = GetVehiclePedIsIn(me, false)
                for _, veh in ipairs(GetGamePool('CVehicle')) do
                    if veh ~= myVeh and DoesEntityExist(veh) and IsEntityVisible(veh) then
                        local vc = GetEntityCoords(veh)
                        if #(vc - mc) <= maxd and (cc.walls == true or HasEntityClearLosToEntity(me, veh, 17)) and NetworkGetEntityIsNetworked(veh) then
                            local ok, x, y = GetScreenCoordFromWorldCoord(vc.x, vc.y, vc.z + 0.6)
                            local bx, by, bw, bh = screenBox(veh)
                            if bx then ok, x, y = true, bx, by end
                            if ok then
                                local net = NetworkGetNetworkIdFromEntity(veh)
                                out[#out + 1] = { i = net, k = 'v', x = r4(x), y = r4(y), w = bw, h = bh }
                                ids['v:' .. net] = true
                                ents['v:' .. net] = veh
                            end
                        end
                    end
                end
            end
            -- objets du décor réglés dans le panel
            if cc.show_objects ~= false and type(cc.objects) == 'table' then
                for idx, o in ipairs(cc.objects) do
                    local obj = GetClosestObjectOfType(mc.x, mc.y, mc.z, maxd, GetHashKey(tostring(o.model)), false, false, false)
                    if obj and obj ~= 0 and DoesEntityExist(obj) then
                        local oc = GetEntityCoords(obj)
                        local ok, x, y = GetScreenCoordFromWorldCoord(oc.x, oc.y, oc.z + 0.3)
                        local bx, by, bw, bh = screenBox(obj)
                        if bx then ok, x, y = true, bx, by end
                        if ok and (cc.walls == true or HasEntityClearLosToEntity(me, obj, 17)) then
                            out[#out + 1] = { i = idx, k = 'o', x = r4(x), y = r4(y), w = bw, h = bh }
                            ids['o:' .. idx] = true
                            ents['o:' .. idx] = obj
                        end
                    end
                end
            end
            -- portes (staff) : surlignées en jaune, un clic ouvre le verrouillage
            if doorCaps and GetGamePool then
                scanDoors(mc)
                for idx, obj in ipairs(doorList) do
                    if DoesEntityExist(obj) then
                        local oc = GetEntityCoords(obj)
                        local ok, x, y = GetScreenCoordFromWorldCoord(oc.x, oc.y, oc.z + 1.0)
                        local bx, by, bw, bh = screenBox(obj)
                        if bx then ok, x, y = true, bx, by end
                        if ok then
                            out[#out + 1] = { i = idx, k = 'd', x = r4(x), y = r4(y), w = bw, h = bh }
                            ids['d:' .. idx] = true
                            ents['d:' .. idx] = obj
                        end
                    end
                end
            end
            visible = ids
            local key = json.encode(out)
            if key ~= lastKey then lastKey = key G.send('ctx.spots', { p = out, show = true }) end
            Wait(33)
        end
    end)
end, false)
RegisterCommand('-pb_ctx', function() stopHold() end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.ctx and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('+pb_ctx', 'Menu contextuel (maintenir)', 'keyboard', (G.cfg.ctx and G.cfg.ctx.key) or 'LMENU')
end)

-- Survol d'une cible pendant ALT : l'entité devient translucide (on la remet normale dès qu'on la quitte).
local function kindOf(k) return (k == 'v' or k == 'o' or k == 'd') and k or 'p' end
G.nui['ctx.hover'] = function(d)
    local id = tonumber(d.i)
    local k = kindOf(d.k)
    local ent = id and holding and ents[k .. ':' .. id] or nil
    if ent == hovered then return {} end
    unhover()
    if ent and DoesEntityExist(ent) then hovered = ent SetEntityAlpha(ent, 150, false) end
    return {}
end
G.nui['ctx.pick'] = function(d)
    local id = tonumber(d.i)
    local k = kindOf(d.k)
    if not id or not visible[k .. ':' .. id] then return {} end
    if k == 'd' then
        local obj = ents['d:' .. id]
        if obj and DoesEntityExist(obj) then
            local c = GetEntityCoords(obj)
            TriggerServerEvent('pb:g:ctx:door', { model = GetEntityModel(obj), x = c.x, y = c.y, z = c.z })
        end
        stopHold()
        G.send('ctx.hide', {})
        restoreFocus()
        return {}
    end
    pickKind = k
    TriggerServerEvent(k == 'v' and 'pb:g:ctx:openv' or k == 'o' and 'pb:g:ctx:openo' or 'pb:g:ctx:open', id)
    return {}
end
G.nui['ctx.act'] = function(d)
    local t = tonumber(d.t)
    if not t or type(d.id) ~= 'string' then return {} end
    local payload = type(d.payload) == 'table' and d.payload or {}
    if pickKind == 'v' then TriggerServerEvent('pb:g:ctx:actv', t, d.id, payload)
    elseif pickKind == 'o' then TriggerServerEvent('pb:g:ctx:acto', t, d.id)
    else TriggerServerEvent('pb:g:ctx:act', t, d.id, payload) end
    return {}
end
G.nui['ctx.close'] = function() closeMenu() return {} end

RegisterNetEvent('pb:g:ctx:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' and d.spec then
        menuOpen = true
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(false)
        G.send('ctx.open', { spec = d.spec })
    elseif d.ev == 'done' then
        closeMenu()
    end
end)

RegisterNetEvent('pb:g:ctx:run', function(j)
    local d = G.decode(j)
    if not d or type(d.v) ~= 'string' then return end
    closeMenu()
    if d.kind == 'cmd' and d.v:match('^[%w_:%-]+$') then
        local t = tonumber(d.target)
        ExecuteCommand(d.v .. (t and (' ' .. math.floor(t)) or ''))
    elseif d.kind == 'gest' then
        if G.CtxGestPlay then G.CtxGestPlay(d.v) end
    elseif d.kind == 'copy' then
        if G.CtxCopy then G.CtxCopy(d.v) end
    elseif d.kind == 'anim' then
        if d.v == 'stop' then ClearPedTasks(PlayerPedId()) elseif G.PlayAnim then G.PlayAnim(d.v) end
    end
end)

-- Moteur / coffre d'un véhicule choisi dans le menu (le serveur a déjà vérifié la clé)
RegisterNetEvent('pb:g:ctx:veh', function(j)
    local d = G.decode(j)
    if not d or not d.net then return end
    local veh = NetworkGetEntityFromNetworkId(math.floor(d.net))
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    if d.act == 'engine' then
        local on = not GetIsVehicleEngineRunning(veh)
        SetVehicleEngineOn(veh, on, true, true)
    elseif d.act == 'flip' then
        NetworkRequestControlOfEntity(veh)
        local t = GetGameTimer() + 1500
        while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(0) end
        SetVehicleOnGroundProperly(veh)
    elseif d.act == 'unlock' then
        local ped = PlayerPedId()
        RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
        local t = GetGameTimer() + 1500
        while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') and GetGameTimer() < t do Wait(10) end
        if HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') then TaskPlayAnim(ped, 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', 'machinic_loop_mechandplayer', 8.0, -8.0, 4500, 49, 0, false, false, false) end
        Wait(4500)
        ClearPedTasks(ped)
        SetVehicleDoorsLocked(veh, 1) SetVehicleDoorsLockedForAllPlayers(veh, false)
    elseif d.act == 'trunk' then
        if GetVehicleDoorAngleRatio(veh, 5) > 0.1 then SetVehicleDoorShut(veh, 5, false) elseif G.openTrunk then G.openTrunk() else SetVehicleDoorOpen(veh, 5, false, false) end
    end
end)

-- Escorte : le personnage menotté s'attache à celui qui l'escorte (le serveur a déjà vérifié les droits et la distance)
local escortBy
RegisterNetEvent('pb:g:ctx:escort', function(j)
    local d = G.decode(j)
    local ped = PlayerPedId()
    if not d or d.on ~= true then
        escortBy = nil
        if IsEntityAttached(ped) then DetachEntity(ped, true, false) end
        return
    end
    escortBy = math.floor(tonumber(d.by) or 0)
    CreateThread(function()
        local attached = false
        while escortBy do
            Wait(250)
            local me = PlayerPedId()
            local pid = GetPlayerFromServerId(escortBy)
            local cop = pid ~= -1 and GetPlayerPed(pid) or 0
            if cop ~= 0 and DoesEntityExist(cop) and not IsPedInAnyVehicle(me, false) then
                if not attached or not IsEntityAttachedToEntity(me, cop) then
                    AttachEntityToEntity(me, cop, 11816, 0.38, 0.5, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
                    attached = true
                end
            end
        end
    end)
end)

-- Mise en véhicule : le personnage menotté prend une place libre dans le véhicule le plus proche de celui qui l'a désigné
RegisterNetEvent('pb:g:ctx:intoveh', function(j)
    local d = G.decode(j)
    local me = PlayerPedId()
    escortBy = nil
    if IsEntityAttached(me) then DetachEntity(me, true, false) end
    local pid = d and GetPlayerFromServerId(math.floor(tonumber(d.by) or 0)) or -1
    local cop = pid ~= -1 and GetPlayerPed(pid) or 0
    local placed = false
    if cop ~= 0 and DoesEntityExist(cop) then
        local c = GetEntityCoords(cop)
        local veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71)
        if veh ~= 0 and DoesEntityExist(veh) then
            local n = GetVehicleModelNumberOfSeats(GetEntityModel(veh))
            for seat = n - 2, 0, -1 do
                if IsVehicleSeatFree(veh, seat) then SetPedIntoVehicle(me, veh, seat) placed = true break end
            end
        end
    end
    TriggerServerEvent('pb:g:ctx:intovehres', placed)
end)
-- Actions staff sur un véhicule : exécutées par le joueur qui contrôle le véhicule (le serveur a vérifié les droits)
RegisterNetEvent('pb:g:ctx:vehfx', function(j)
    local d = G.decode(j)
    if not d or not d.net then return end
    local veh = NetworkGetEntityFromNetworkId(math.floor(d.net))
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    if not NetworkHasControlOfEntity(veh) then
        NetworkRequestControlOfEntity(veh)
        local t = GetGameTimer() + 1500
        while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(0) NetworkRequestControlOfEntity(veh) end
    end
    if d.act == 'tyres' then
        for w = 0, 7 do SetVehicleTyreBurst(veh, w, true, 1000.0) end
    elseif d.act == 'repair' then
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    elseif d.act == 'unlock' then
        SetVehicleDoorsLocked(veh, 1) SetVehicleDoorsLockedForAllPlayers(veh, false)
    elseif d.act == 'freeze' then
        FreezeEntityPosition(veh, d.on == true)
    elseif d.act == 'delete' then
        SetEntityAsMissionEntity(veh, true, true)
        DeleteVehicle(veh)
    end
end)
RegisterNetEvent('pb:g:ctx:leaveveh', function()
    local me = PlayerPedId()
    if IsPedInAnyVehicle(me, false) then TaskLeaveVehicle(me, GetVehiclePedIsIn(me, false), 16) end
end)

-- Dépanneuse : le mécanicien attache le véhicule sur le plateau (flatbed), le détache derrière, ou le laisse à la fourrière.
-- Le serveur a vérifié le métier, le service et les distances ; ici on ne fait que la physique.
local function control(ent)
    if NetworkHasControlOfEntity(ent) then return true end
    NetworkRequestControlOfEntity(ent)
    local t = GetGameTimer() + 2000
    while not NetworkHasControlOfEntity(ent) and GetGameTimer() < t do Wait(0) NetworkRequestControlOfEntity(ent) end
    return NetworkHasControlOfEntity(ent)
end
RegisterNetEvent('pb:g:tow', function(j)
    local d = G.decode(j)
    if not d or not d.bed then return end
    local bed = NetworkGetEntityFromNetworkId(math.floor(d.bed))
    local veh = d.veh and NetworkGetEntityFromNetworkId(math.floor(d.veh)) or 0
    if not bed or bed == 0 or not DoesEntityExist(bed) or not veh or veh == 0 or not DoesEntityExist(veh) then return end
    if not control(veh) then G.send('notify', { type = 'error', title = 'Dépanneuse', text = 'Impossible de prendre le véhicule (réessaie).' }) return end
    if d.act == 'load' then
        -- posé sur le plateau, centré, un peu en arrière (selon la taille du véhicule)
        local mn, mx = GetModelDimensions(GetEntityModel(veh))
        local h = math.max(0.0, -mn.z)
        AttachEntityToEntity(veh, bed, GetEntityBoneIndexByName(bed, 'bodyshell'), 0.0, -2.2, 0.55 + h, 0.0, 0.0, 0.0, false, false, true, false, 2, true)
        PlaySoundFrontend(-1, 'Hack_Success', 'DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS', true)
    else
        DetachEntity(veh, true, true)
        local back = GetOffsetFromEntityInWorldCoords(bed, 0.0, -9.5, 0.0)
        SetEntityCoords(veh, back.x, back.y, back.z, false, false, false, false)
        SetEntityHeading(veh, GetEntityHeading(bed))
        SetVehicleOnGroundProperly(veh)
    end
end)
-- Badge d'employé montré par quelqu'un (ou le sien) : carte affichée quelques secondes
RegisterNetEvent('pb:g:badge', function(j) local d = G.decode(j) if d then G.send('badge.show', d) end end)
