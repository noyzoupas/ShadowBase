-- Événements de ville : LARGAGE (une caisse tombe dans une zone annoncée ; le premier qui l'ouvre gagne) et CHASSE AU TRÉSOR
-- (un trésor caché ; la zone se resserre toutes les quelques minutes ; le premier qui creuse au bon endroit gagne).
-- Lancés automatiquement (toutes les X minutes s'il y a assez de joueurs), planifiés (Événements) ou à la main (panel).
-- Le serveur choisit l'endroit, garde la position exacte secrète jusqu'à l'atterrissage et vérifie la distance et la durée d'ouverture.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('worldev.manage', 'Lancer et régler les largages et chasses au trésor', 'game', true)
local SPOTS = { '2484|3765|41|Désert du Grand Senora', '1702|4831|42|Grapeseed', '-1104|4917|216|Forêt de Raton Canyon', '-1530|1445|117|Tongva Hills', '1366|1147|113|Vinewood Hills Est',
    '2552|-357|93|Tataviam', '-2200|2300|33|Lago Zancudo', '-424|6052|31|Paleto Bay', '3302|5183|18|Phare de Paleto', '172|2795|44|Harmony', '-780|-2595|13|Port de Los Santos', '885|-2918|6|Terminal' }
PB.Cfg.Define('worldev', { auto = false, every_min = 90, min_players = 6, kinds = { 'airdrop', 'treasure' }, spots = SPOTS, cash_min = 3000, cash_max = 12000,
    items = { 'bandage|5', 'water|3' }, open_secs = 10, dig_secs = 8, drop_delay = 4, treasure_mins = 20 })
local W = { cur = nil }
G.WorldEv = W
local function cfg(k, d) return PB.Cfg.Get('worldev', k, d) end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function spots()
    local out = {}
    for _, line in ipairs(cfg('spots', SPOTS) or {}) do
        local x, y, z, l = tostring(line):match('^(%-?[%d%.]+)|(%-?[%d%.]+)|(%-?[%d%.]+)|(.+)$')
        if x then out[#out + 1] = { x = tonumber(x), y = tonumber(y), z = tonumber(z), label = l } end
    end
    return out
end
-- ce que voient les joueurs : zone (centre décalé, rayon), et la caisse seulement quand elle est au sol
local function view(e)
    if not e then return { on = false } end
    return { on = true, kind = e.kind, label = e.label, zx = e.zx, zy = e.zy, r = e.r, crate = e.landed and { x = e.x, y = e.y, z = e.z } or nil, ends = e.ends, landsAt = e.landsAt }
end
local function push(target) TriggerClientEvent('pb:g:wev', target or -1, PB.Json(view(W.cur))) end
local function zone(e, r)   -- zone de rayon r qui contient le vrai point, centre décalé au hasard
    local a, d = math.random() * math.pi * 2, math.random() * r * 0.7
    e.zx, e.zy, e.r = e.x + math.cos(a) * d, e.y + math.sin(a) * d, r
end

function W.Start(kind, by)
    if W.cur then return false, 'Un événement est déjà en cours.' end
    local list = spots()
    if #list == 0 then return false, 'Aucun lieu configuré.' end
    local s = list[math.random(1, #list)]
    kind = kind == 'treasure' and 'treasure' or 'airdrop'
    local e = { kind = kind, label = s.label, x = s.x + math.random(-25, 25), y = s.y + math.random(-25, 25), z = s.z, at = now(), claim = {} }
    if kind == 'airdrop' then
        zone(e, 220)
        e.landsAt = now() + math.max(1, num('drop_delay', 4)) * 60
        e.ends = e.landsAt + 20 * 60
        PB.Announce(('Largage : une caisse va tomber vers %s dans %d minutes. La zone est sur ta carte.'):format(s.label, math.max(1, num('drop_delay', 4))), 'both')
    else
        zone(e, 450)
        e.ends = now() + math.max(5, num('treasure_mins', 20)) * 60
        e.nextShrink = now() + 180
        PB.Announce(('Chasse au trésor vers %s ! La zone se resserre toutes les 3 minutes. Creuse au bon endroit (E).'):format(s.label), 'both')
    end
    W.cur = e
    PB.Audit.Log('serveur', 'worldev.start', by or 'système', kind, nil, { lieu = s.label })
    push()
    return true, (kind == 'airdrop' and 'Largage' or 'Chasse au trésor') .. ' lancé(e) vers ' .. s.label .. '.'
end
function W.Stop(reason)
    if not W.cur then return false end
    local e = W.cur
    W.cur = nil
    push()
    if reason then PB.Announce(reason, 'both') end
    return true, e
end
-- récompense : argent + objets réglables
local function reward(src)
    local lo, hi = math.floor(num('cash_min', 3000)), math.floor(num('cash_max', 12000))
    local cash = math.random(math.min(lo, hi), math.max(lo, hi))
    if G.Eco and G.Eco.Income then cash = G.Eco.Income(cash, 'activity') end   -- onglet Économie
    local got = { money(cash) }
    G.AddMoney(src, 'cash', cash, 'Événement : ' .. (W.cur and W.cur.kind or ''))
    local owner = G.Inv and G.Inv.PlayerOwner(src)
    for _, line in ipairs(cfg('items', {}) or {}) do
        local it, q = tostring(line):match('^([%w_]+)|(%d+)$')
        if it and owner and G.Inv.Def and G.Inv.Def(it) and G.Inv.Add(owner, it, tonumber(q)) then got[#got + 1] = q .. ' × ' .. ((G.Inv.Def(it) or {}).label or it) end
    end
    if G.Inv and G.Inv.Push then pcall(G.Inv.Push, src) end
    return table.concat(got, ', ')
end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Quelqu\'un' end
local function dist(src, e) return G.DistTo(src, e.x, e.y, e.z) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end

-- ouverture / fouille : le client prévient au début, puis à la fin ; le serveur vérifie la distance et la durée
RegisterNetEvent('pb:g:wev:begin', function()
    local src, e = source, W.cur
    if not e or not usable(src) then return end
    if e.kind == 'airdrop' and not e.landed then return end
    if dist(src, e) > (e.kind == 'airdrop' and 3.5 or 4.0) then
        if e.kind == 'treasure' then G.Notify(src, { type = 'warn', title = 'Chasse au trésor', text = "Rien ici… cherche encore." }) end
        return
    end
    e.claim[src] = GetGameTimer()
    TriggerClientEvent('pb:g:wev:progress', src, e.kind == 'airdrop' and num('open_secs', 10) or num('dig_secs', 8))
end)
RegisterNetEvent('pb:g:wev:done', function()
    local src, e = source, W.cur
    if not e or not e.claim[src] or not usable(src) then return end
    local need = (e.kind == 'airdrop' and num('open_secs', 10) or num('dig_secs', 8)) * 1000 - 800
    if GetGameTimer() - e.claim[src] < need or dist(src, e) > 4.5 then return end
    W.cur = nil   -- premier arrivé, premier servi
    local what = reward(src)
    push()
    PB.Announce(('%s a trouvé %s !'):format(display(src), e.kind == 'airdrop' and 'la caisse du largage' or 'le trésor'), 'both')
    G.Notify(src, { type = 'success', title = e.kind == 'airdrop' and 'Largage' or 'Trésor', text = 'Tu gagnes : ' .. what, duration = 10000 })
    PB.Audit.Log('serveur', 'worldev.win', src, e.kind, nil, { gain = what })
    if G.Timeline then local p = G.Get(src) if p then G.Timeline.Add(p.license, 'event', ('Gagné %s : %s'):format(e.kind == 'airdrop' and 'un largage' or 'une chasse au trésor', what), 'ok') end end
end)
RegisterNetEvent('pb:g:wev:cancel', function() if W.cur then W.cur.claim[source] = nil end end)
table.insert(G.beginHooks, function(src) if W.cur then push(src) end end)

-- horloge : atterrissage, zone qui se resserre, fin ; lancement automatique
local lastAuto = now()
function W.Tick()
        local e = W.cur
        if e then
            if e.kind == 'airdrop' and not e.landed and now() >= e.landsAt then
                e.landed = true
                PB.Announce(('Le largage a touché le sol vers %s : la caisse est sur ta carte.'):format(e.label), 'both')
                push()
            elseif e.kind == 'treasure' and e.nextShrink and now() >= e.nextShrink and e.r > 40 then
                zone(e, math.max(40, math.floor(e.r / 2)))
                e.nextShrink = now() + 180
                PB.Announce(('Chasse au trésor : la zone se resserre (%d m).'):format(e.r), 'chat')
                push()
            end
            if W.cur and now() >= e.ends then W.Stop(e.kind == 'airdrop' and 'Personne n\'a récupéré la caisse du largage.' or 'Le trésor n\'a pas été trouvé : il est perdu.') end
        elseif cfg('auto', false) == true and now() - lastAuto >= math.max(15, num('every_min', 90)) * 60 then
            lastAuto = now()
            local n = 0
            for _ in pairs(G.Players()) do n = n + 1 end
            local kinds = cfg('kinds', { 'airdrop', 'treasure' }) or {}
            if n >= num('min_players', 6) and #kinds > 0 then W.Start(kinds[math.random(1, #kinds)], 'automatique') end
        end
end
CreateThread(function() while true do Wait(5000) W.Tick() end end)

PB.Action('worldev.start', 'worldev.manage', function(ctx, p)
    local ok, msg = W.Start(p.kind, ctx.actor and ctx.actor.name)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
PB.Action('worldev.stop', 'worldev.manage', function(ctx)
    if not W.Stop('L\'événement est annulé.') then return false, 'Aucun événement en cours.' end
    ctx.toast = 'Événement arrêté.'
    return true
end)
local form = PB.Form.Cfg({ ns = 'worldev', id = 'settings', title = 'Largages et chasses au trésor', perm = 'worldev.manage', cols = 2, fields = {
    { k = 'auto', type = 'toggle', label = 'Lancement automatique', default = false },
    { k = 'every_min', type = 'number', label = 'Toutes les (minutes)', default = 90, min = 15, max = 1440 },
    { k = 'min_players', type = 'number', label = 'Joueurs connectés minimum', default = 6, min = 1, max = 500 },
    { k = 'drop_delay', type = 'number', label = 'Largage : délai avant l\'atterrissage (minutes)', default = 4, min = 1, max = 30 },
    { k = 'treasure_mins', type = 'number', label = 'Chasse au trésor : durée (minutes)', default = 20, min = 5, max = 120 },
    { k = 'open_secs', type = 'number', label = 'Temps pour ouvrir la caisse (s)', default = 10, min = 2, max = 60 },
    { k = 'dig_secs', type = 'number', label = 'Temps pour creuser (s)', default = 8, min = 2, max = 60 },
    { k = 'cash_min', type = 'number', label = 'Gain : argent minimum ($)', default = 3000, min = 0, max = 10000000 },
    { k = 'cash_max', type = 'number', label = 'Gain : argent maximum ($)', default = 12000, min = 0, max = 10000000 },
    { k = 'items', type = 'list', label = 'Gain : objets (objet|quantité)', default = { 'bandage|5', 'water|3' }, maxitems = 12, maxlen = 48, pattern = '^[%w_]+|%d+$', wide = true },
    { k = 'spots', type = 'list', label = 'Lieux possibles (x|y|z|nom)', default = SPOTS, maxitems = 60, maxlen = 80, wide = true },
} })
PB.Module({
    id = 'worldev', label = 'Largages et trésors', icon = 'gift', group = 'Serveur', order = 139, perm = 'worldev.manage', hint = 'Événements de ville automatiques',
    caps = function() return PB.Capsify({
        { 'Largage', 'ok', 'Zone annoncée, caisse qui tombe, le premier qui l\'ouvre gagne.' },
        { 'Chasse au trésor', 'ok', 'Zone qui se resserre toutes les 3 minutes ; le premier qui creuse au bon endroit gagne.' },
        { 'Lancement automatique ou planifié', 'ok', 'Toutes les X minutes s\'il y a assez de joueurs, ou dans Événements.' },
    }) end,
    doc = "## Largages et chasses au trésor\n**Lancer maintenant** pour tester. Le lieu exact reste secret côté serveur : les joueurs ne voient qu'une zone (et la caisse quand elle a atterri).",
    view = function(ctx)
        local e = W.cur
        return { tabs = {
            { id = 'now', label = 'En direct', icon = 'gift', build = function()
                local blocks = {}
                if e then blocks[#blocks + 1] = B.notice('info', ('%s en cours vers %s · fin à %s.'):format(e.kind == 'airdrop' and 'Largage' or 'Chasse au trésor', e.label, os.date('%H:%M', e.ends))) end
                blocks[#blocks + 1] = B.actions({ { action = 'worldev.start', label = 'Lancer un largage', icon = 'gift', primary = true, payload = { kind = 'airdrop' } }, { action = 'worldev.start', label = 'Lancer une chasse au trésor', icon = 'search', payload = { kind = 'treasure' } },
                    e and { action = 'worldev.stop', label = 'Arrêter', icon = 'x', danger = true } or nil }, 'Lancer')
                return blocks
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
