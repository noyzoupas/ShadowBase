-- Armes : permis de port d'arme (délivré par la police), armes et munitions comme objets du sac, équipement contrôlé par le serveur.
-- L'armurerie est un magasin ordinaire (module Magasins) avec l'option « permis d'arme ». Les armes données par un autre script ne sont pas contrôlées ici.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local W = {}
G.Weapons = W

P.Register('weapons.edit', "Modifier les armes, munitions et permis", 'weapons', true)
P.Register('weapons.permit', "Délivrer ou retirer un permis d'arme depuis le panel", 'weapons', true)

PB.Migrate('075_weapons', "Armes : permis et objets", {
    [[CREATE TABLE IF NOT EXISTS pb_permits (license VARCHAR(64) NOT NULL, kind VARCHAR(16) NOT NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (license, kind))]],
})

local WEAPONS = {
    { item = 'weapon_pistol', label = 'Pistolet', hash = 'WEAPON_PISTOL', ammo_item = 'ammo_pistol', permit = true, weight = 1100 },
    { item = 'weapon_combatpistol', label = 'Pistolet de combat', hash = 'WEAPON_COMBATPISTOL', ammo_item = 'ammo_pistol', permit = true, weight = 1200 },
    { item = 'weapon_knife', label = 'Couteau', hash = 'WEAPON_KNIFE', ammo_item = '', permit = false, weight = 300 },
    { item = 'weapon_bat', label = 'Batte', hash = 'WEAPON_BAT', ammo_item = '', permit = false, weight = 900 },
}
PB.Cfg.Define('weapons', { enabled = true, require_permit = true, ammo_per_box = 12, strip_on_death = true, catalog = WEAPONS })
local function cfg(k, d) return PB.Cfg.Get('weapons', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function owner(src) local p = G.Get(src) return p and ('p:' .. p.license) end

-- objets du sac (créés une fois ; modifiables ensuite dans Inventaire › Objets)
PB.Migrate('076_weapon_items', 'Armes : objets du sac', function()
    for _, w in ipairs(WEAPONS) do
        DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, 1, ?, 1, ?)', { w.item, w.label, w.weight, 'weapon', 'Utilise pour équiper ou ranger.' })
    end
    DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, ?, ?, ?, ?)', { 'ammo_pistol', 'Boîte de munitions 9 mm', 250, 20, 'ammo', 1, 'Recharge l\'arme équipée.' })
    DB.exec('INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, ?, ?, ?, ?)', { 'black_money', 'Argent sale', 1, 100000, 'misc', 0, 'À blanchir.' })
    -- armurerie par défaut (magasin ordinaire, permis exigé)
    local cat = {
        { name = 'weapon_pistol', label = 'Pistolet', price = 2500, hunger = 0, thirst = 0, stress = 0, category = 'Armes' }, { name = 'weapon_combatpistol', label = 'Pistolet de combat', price = 3200, hunger = 0, thirst = 0, stress = 0, category = 'Armes' },
        { name = 'weapon_knife', label = 'Couteau', price = 150, hunger = 0, thirst = 0, stress = 0, category = 'Armes' }, { name = 'ammo_pistol', label = 'Boîte de munitions 9 mm', price = 90, hunger = 0, thirst = 0, stress = 0, category = 'Munitions' },
    }
    if DB.one("SELECT id FROM pb_shops WHERE label = 'Armurerie'") == nil then
        DB.exec("INSERT INTO pb_shops (kind, label, x, y, z, h, sprite, color, blip, price, catalog, enabled, opts) VALUES ('store', 'Armurerie', 252.7, -50.0, 69.9, 70, 110, 1, 1, 0, ?, 1, ?)",
            { PB.Json(cat), PB.Json({ permit = 'weapon', tagline = "Permis de port d'arme obligatoire", accent = '#ff9d9d', pay_mode = 'both', max_qty = 10 }) })
    end
end)

-- L'armurerie par défaut (4 articles non modifiés) passe en armurerie « cartes » avec le catalogue complet. Une armurerie déjà modifiée n'est pas touchée.
PB.Migrate('161_armory_cards', "Armurerie : interface en cartes", function()
    local r = DB.one("SELECT id, catalog, opts FROM pb_shops WHERE label = 'Armurerie' AND kind = 'store'")
    if not (r and G.DefaultArmory) then return end
    local cat, base = PB.FromJson(r.catalog, {}), { weapon_pistol = true, weapon_combatpistol = true, weapon_knife = true, ammo_pistol = true }
    if type(cat) ~= 'table' or #cat ~= 4 then return end
    for _, it in ipairs(cat) do if not base[it.name] then return end end
    local o = PB.FromJson(r.opts, {}) if type(o) ~= 'table' then o = {} end
    o.test_sec, o.test_ammo, o.give_ammo, o.accent = 20, 24, true, '#5b4ae6'
    DB.exec("UPDATE pb_shops SET kind = 'weapons', catalog = ?, opts = ? WHERE id = ?", { PB.Json(G.DefaultArmory), PB.Json(o), r.id })
end)

function W.Catalog() return cfg('catalog', {}) or {} end
function W.ByItem(item) for _, w in ipairs(W.Catalog()) do if w.item == item then return w end end end
function W.HasPermit(src, kind)
    local p = G.Get(tonumber(src) or -1)
    if not p then return false end
    return DB.one('SELECT license FROM pb_permits WHERE license = ? AND kind = ?', { p.license, kind or 'weapon' }) ~= nil
end
function W.Permits() return DB.q("SELECT pm.license, pm.kind, pm.by_name, pm.at, p.firstname, p.lastname FROM pb_permits pm LEFT JOIN pb_players p ON p.license = pm.license ORDER BY pm.at DESC LIMIT 300") or {} end
-- Délivrance : par la police (F6 / menu ALT) ou depuis le panel
function W.Grant(src, tid, by)
    local t = G.Get(tonumber(tid) or -1)
    if not t or not PB.ToBool(t.row.created) then return false, 'Personne introuvable.' end
    if W.HasPermit(tid) then return false, display(tid) .. ' a déjà un permis.' end
    DB.exec('INSERT INTO pb_permits (license, kind, by_name, at) VALUES (?, ?, ?, ?)', { t.license, 'weapon', clean(by or display(src), 64), os.time() })
    G.Notify(tid, { type = 'success', title = "Permis de port d'arme", text = 'Un permis vient de t\'être délivré.' })
    PB.Audit.Log('justice', 'permit.grant', src, display(tid) .. ' ' .. G.Tag(tid), nil, nil, { kind = 'weapon' })
    return true, ('Permis délivré à %s.'):format(display(tid))
end
function W.Revoke(src, tid, by)
    local t = G.Get(tonumber(tid) or -1)
    if not t then return false, 'Personne introuvable.' end
    if not W.HasPermit(tid) then return false, "Cette personne n'a pas de permis." end
    DB.exec('DELETE FROM pb_permits WHERE license = ? AND kind = ?', { t.license, 'weapon' })
    G.Notify(tid, { type = 'warn', title = "Permis de port d'arme", text = 'Ton permis a été retiré.' })
    PB.Audit.Log('justice', 'permit.revoke', src, display(tid) .. ' ' .. G.Tag(tid), nil, nil, { kind = 'weapon' })
    return true, ('Permis retiré à %s.'):format(display(tid))
end

-- Équipement ---------------------------------------------------------------------------------------------------------------------------
local equipped = {}        -- src -> fiche de l'arme équipée
AddEventHandler('playerDropped', function() equipped[source] = nil end)
function W.Equipped(src) return equipped[src] end
local function equip(src, w)
    equipped[src] = w
    TriggerClientEvent('pb:g:weap:equip', src, PB.Json({ hash = w.hash, ammo = 0 }))
end
local function unequip(src)
    local w = equipped[src]
    if w then TriggerClientEvent('pb:g:weap:holster', src, PB.Json({ hash = w.hash })) end
    equipped[src] = nil
end
W.Unequip = unequip

local function registerUse()
    if not (G.Inv and G.Inv.RegisterUsable) then return end
    for _, w in ipairs(W.Catalog()) do
        G.Inv.RegisterUsable(w.item, function(src)
            if not cfg('enabled', true) then return false, 'Les armes sont désactivées.' end
            local cur = equipped[src]
            if cur and cur.item == w.item then unequip(src) return true, 'Arme rangée.', true end
            if cfg('require_permit', true) ~= false and w.permit and not W.HasPermit(src) then return false, "Il te faut un permis de port d'arme." end
            equip(src, w)
            return true, w.label .. ' équipé.', true
        end)
    end
    local seen = { ammo_pistol = true }
    local list = { 'ammo_pistol' }
    for _, w in ipairs(W.Catalog()) do local a = tostring(w.ammo_item or '') if a ~= '' and not seen[a] then seen[a] = true list[#list + 1] = a end end
    for _, ammo in ipairs(list) do
        G.Inv.RegisterUsable(ammo, function(src)
            local cur = equipped[src]
            if not cur or cur.ammo_item ~= ammo then return false, "Équipe d'abord une arme qui utilise ces munitions." end
            TriggerClientEvent('pb:g:weap:ammo', src, PB.Json({ hash = cur.hash, amount = tonumber(cfg('ammo_per_box', 12)) or 12 }))
            return true, 'Chargeur rechargé.'
        end)
    end
end
registerUse()
W.Register = registerUse

-- Ajout d'une arme par une ressource addon : objet du sac, munition et entrée du catalogue.
-- def = { item='weapon_hw_glock19', label='Glock 19 Faucheur', hash='WEAPON_HW_GLOCK19',
--         ammo_item='ammo_hw_9mm', weight=800, permit=false, image='img/weapons/weapon_hw_glock19.png' }
function W.EnsureWeapon(def)
    if type(def) ~= 'table' or not (G.Inv and G.Inv.EnsureItem) then return false, 'inventaire indisponible' end
    local item = tostring(def.item or ''):lower()
    if not item:match('^weapon_[%w_]+$') or #item > 40 then return false, 'objet invalide' end
    local hash = tostring(def.hash or ''):upper()
    if not hash:match('^WEAPON_[%w_]+$') then return false, 'hash invalide' end
    local label = tostring(def.label or item):sub(1, 40)
    local weight = math.max(0, math.min(50000, math.floor(tonumber(def.weight) or 1200)))
    local ok, err = G.Inv.EnsureItem({ name = item, label = label, weight = weight, stack = 1, kind = 'weapon', usable = true,
        description = tostring(def.description or 'Utilise pour équiper ou ranger.'), image = tostring(def.image or '') })
    if not ok then return false, err or 'objet non créé' end
    local ammo = tostring(def.ammo_item or ''):lower()
    if ammo ~= '' then
        G.Inv.EnsureItem({ name = ammo, label = tostring(def.ammo_label or ammo):sub(1, 48), weight = tonumber(def.ammo_weight) or 10, stack = 500, kind = 'ammo', usable = true,
            description = 'Recharge l\'arme équipée.', image = tostring(def.ammo_image or '') })
    end
    local cat = W.Catalog()
    for _, w in ipairs(cat) do
        if w.item == item then
            w.label, w.hash, w.ammo_item, w.weight = label, hash, ammo, weight
            PB.Cfg.Set('weapons', 'catalog', cat, nil, 'Mise à jour arme addon : ' .. item)
            W.Register()
            return true
        end
    end
    cat[#cat + 1] = { item = item, label = label, hash = hash, ammo_item = ammo, permit = def.permit == true, weight = weight }
    local okc, cerr = PB.Cfg.Set('weapons', 'catalog', cat, nil, 'Arme addon : ' .. item)
    if not okc then return false, cerr end
    W.Register()
    return true
end
exports('EnsureWeapon', W.EnsureWeapon)
-- Range l'arme si c'est celle-là qui est équipée (ressources addon : matériel prêté repris, etc.)
exports('UnequipWeapon', function(src, item)
    src = tonumber(src)
    local cur = src and equipped[src]
    if cur and (item == nil or cur.item == item) then unequip(src) return true end
    return false
end)

-- l'arme équipée est rangée à la mort (le joueur la garde dans son sac)
local oldSetDead = G.SetDead
function G.SetDead(src, dead)
    local r = oldSetDead(src, dead)
    if dead and cfg('strip_on_death', true) and equipped[tonumber(src)] then unequip(tonumber(src)) end
    return r
end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
PB.Action('weapons.permit.grant', 'weapons.permit', function(ctx, p)
    local id = tonumber((p.values or {}).id)
    if not id then return false, 'Indique le numéro du joueur.' end
    local ok, msg = W.Grant(ctx.src or 0, id, ctx.name or 'Panel')
    if not ok then return false, msg end
    ctx.audit('serveur', 'weapons.permit.grant', tostring(id)) ctx.toast = msg
    return true
end)
PB.Action('weapons.permit.revoke', 'weapons.permit', function(ctx, p)
    local lic = tostring(p.license or '')
    local r = DB.one('SELECT license FROM pb_permits WHERE license = ?', { lic })
    if not r then return false, 'Permis introuvable.' end
    DB.exec('DELETE FROM pb_permits WHERE license = ?', { lic })
    ctx.audit('serveur', 'weapons.permit.revoke', lic) ctx.toast = 'Permis retiré.'
    return true
end)

local settings = Form.Cfg({ ns = 'weapons', id = 'settings', title = 'Armes et permis', perm = 'weapons.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Système d\'armes actif', default = true },
    { k = 'require_permit', type = 'toggle', label = "Permis exigé pour équiper les armes marquées « permis »", default = true },
    { k = 'ammo_per_box', type = 'number', label = 'Munitions par boîte', default = 12, min = 1, max = 250 },
    { k = 'strip_on_death', type = 'toggle', label = "Ranger l'arme équipée à la mort", default = true },
} })
local catalogForm = Form.Cfg({ ns = 'weapons', id = 'catalog', title = 'Catalogue des armes', perm = 'weapons.edit', fields = {
    { k = 'catalog', type = 'rows', label = 'Armes', default = WEAPONS, wide = true, maxitems = 150, unique = 'item',
      hint = "L'objet du sac doit exister (Inventaire › Objets) ; la boutique les vend comme n'importe quel article. Nom du jeu : WEAPON_PISTOL, WEAPON_KNIFE…",
      cols = { { k = 'item', label = 'Objet du sac', pattern = '^[%w_]+$', required = true, maxlen = 32, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'hash', label = 'Arme du jeu', pattern = '^WEAPON_[%u%d_]+$', required = true, maxlen = 40 }, { k = 'ammo_item', label = 'Objet munition (vide = aucune)', pattern = '^[%w_]*$', maxlen = 32, lower = true },
        { k = 'permit', label = 'Permis', type = 'toggle' }, { k = 'weight', label = 'Poids (g)', type = 'number', min = 0, max = 50000 } } } } })

PB.Module({
    id = 'weapons', label = 'Armes et permis', icon = 'shield', group = 'Serveur', order = 144, perm = 'weapons.edit', hint = 'Armurerie, munitions, permis',
    caps = function()
        return PB.Capsify({
            { "Permis de port d'arme", 'ok', "Délivré par la police (F6 ou menu ALT) ou depuis le panel ; exigé pour entrer à l'armurerie et équiper les armes concernées." },
            { 'Armes et munitions dans le sac', 'ok', "Utiliser l'objet équipe ou range l'arme ; une boîte de munitions recharge l'arme équipée." },
            { 'Armurerie', 'ok', "Un magasin « Armurerie » est créé au premier démarrage ; modifie-le dans Magasins." },
            { 'Contrôle des armes données par un autre script', 'off', "Seules les armes équipées par cette base sont contrôlées. Un autre script peut en donner sans passer par le sac." },
        })
    end,
    doc = "## Armes et permis\nLa police délivre le **permis de port d'arme** (F6 › Délivrer un permis d'arme, ou clic ALT sur la personne). L'**Armurerie** (magasin) exige ce permis. Les armes sont des objets du sac : les utiliser les équipe, les utiliser de nouveau les range. Les boîtes de munitions rechargent l'arme équipée.",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'weapons', title = "L'armurerie (exemple)", cfg = PB.Cfg.All('shops') } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
            { id = 'catalog', label = 'Catalogue', icon = 'shield', build = function() return { catalogForm(ctx) } end },
            { id = 'permits', label = 'Permis', icon = 'id', build = function()
                local rows = {}
                for _, r in ipairs(W.Permits()) do rows[#rows + 1] = { who = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''), by = r.by_name, at = os.date('%d/%m/%Y', r.at), actions = ctx.has('weapons.permit') and { { action = 'weapons.permit.revoke', label = 'Retirer', payload = { license = r.license }, danger = true, confirm = 'Retirer ce permis ?' } } or nil } end
                return { { type = 'form', id = 'grant', title = 'Délivrer un permis', desc = 'Numéro du joueur connecté.', fields = { { k = 'id', type = 'number', label = 'Numéro du joueur', min = 1, max = 4096 } }, values = {}, submit = { action = 'weapons.permit.grant', label = 'Délivrer' }, perm = 'weapons.permit' },
                    B.table({ id = 'permits', title = 'Permis délivrés', columns = { { k = 'who', label = 'Titulaire' }, { k = 'by', label = 'Délivré par' }, { k = 'at', label = 'Le' } }, rows = rows, empty = 'Aucun permis délivré.' }) }
            end },
        } }
    end,
})

PB.SelfTest.Add('armes', function(R)
    for _, w in ipairs(W.Catalog()) do
        R.check(G.Inv and G.Inv.Def(w.item) ~= nil, 'arme « ' .. tostring(w.item) .. ' »', "l'objet du sac n'existe pas (Inventaire › Objets)")
        if (w.ammo_item or '') ~= '' then R.check(G.Inv and G.Inv.Def(w.ammo_item) ~= nil, 'munition « ' .. tostring(w.ammo_item) .. ' »', "l'objet munition n'existe pas") end
    end
end)
