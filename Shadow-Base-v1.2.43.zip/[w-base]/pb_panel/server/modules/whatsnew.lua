-- Nouveautés : journal des mises à jour affiché dans le panel (carte sur l'accueil + module « Nouveautés »).
-- Chaque lot ajoute une entrée à PB.Changelog (voir la liste plus bas). Le « lu / non lu » est mémorisé par administrateur (licence).
-- Pour ajouter une nouveauté : PB.News.Add({ id = 'lot37', date = 'AAAA-MM-JJ', title = '…', items = { { tag = 'Nouveau', text = '…', module = 'id-du-module' } } }).

local B, P, DB = PB.B, PB.Perm, PB.DB
local N = {}
PB.News = N

PB.Migrate('192_news_seen', 'Nouveautés : dernier lot lu par administrateur', {
    [[CREATE TABLE IF NOT EXISTS pb_news_seen (license VARCHAR(64) NOT NULL PRIMARY KEY, seq INT NOT NULL DEFAULT 0)]],
})

N.list = {}   -- du plus ancien au plus récent ; seq = position
function N.Add(e)
    if type(e) ~= 'table' or not e.id then return end
    for _, x in ipairs(N.list) do if x.id == e.id then return end end
    local items = {}
    for _, it in ipairs(e.items or {}) do
        items[#items + 1] = { tag = tostring(it.tag or 'Nouveau'):sub(1, 16), text = tostring(it.text or ''):sub(1, 600), module = it.module and tostring(it.module) or nil }
    end
    N.list[#N.list + 1] = { id = tostring(e.id), seq = #N.list + 1, date = tostring(e.date or ''), title = tostring(e.title or e.id):sub(1, 160), items = items }
end

local function seenOf(license)
    local r = license and DB.one('SELECT seq FROM pb_news_seen WHERE license = ?', { license })
    return r and tonumber(r.seq) or 0
end
-- Entrées pour un administrateur : { unseen, entries (les plus récentes d'abord) }
function N.For(license, limit)
    local seen, out, unseen = seenOf(license), {}, 0
    for i = #N.list, 1, -1 do
        local e = N.list[i]
        local isNew = e.seq > seen
        if isNew then unseen = unseen + 1 end
        if #out < (limit or 50) then out[#out + 1] = { id = e.id, date = e.date, title = e.title, items = e.items, new = isNew } end
    end
    return unseen, out
end
function N.MarkRead(license)
    if not license or #N.list == 0 then return end
    DB.exec('REPLACE INTO pb_news_seen (license, seq) VALUES (?, ?)', { license, N.list[#N.list].seq })
end

-- Journal des lots ----------------------------------------------------------------------------------------------------------------------
N.Add({ id = 'lot34', date = '2026-10-17', title = 'Patch notes 34 : téléphone, inventaire, boutiques', items = {
    { tag = 'Amélioré', text = "Boutiques, inventaire, notifications et HUD repensés.", module = 'shops' },
} })
N.Add({ id = 'lot35', date = '2026-10-17', title = 'Patch notes 35 : entreprises, gangs, carte', items = {
    { tag = 'Nouveau', text = "130 entreprises et gangs prêts à installer, rangés en 10 catégories.", module = 'biz' },
    { tag = 'Nouveau', text = "Module « Carte du jeu » : clique sur la carte, tu es téléporté, E pour poser un point.", module = 'carte' },
    { tag = 'Nouveau', text = "Menu staff : emploi, second emploi, gang, grade, armes dans l'inventaire, redémarrage planifié.", module = 'staff' },
    { tag = 'Corrigé', text = "Boutiques bloquées, noclip en véhicule, boutons grisés, éditeur d'automatisations." },
} })
N.Add({ id = 'lot36', date = '2026-10-17', title = 'Patch notes 36 : coffres, concession, tablettes', items = {
    { tag = 'Nouveau', text = "Coffre de véhicule (touche K) et touches capot, moteur, ceinture, vitres.", module = 'vehtrunk' },
    { tag = 'Nouveau', text = "Concession : 45 véhicules par défaut et nouvelle fiche (vitesse, places, coffre).", module = 'shops' },
    { tag = 'Nouveau', text = "Tablettes entreprise et gang complétées : équipe, annonces, journal, stats, paie, caisse commune, territoires…", module = 'orga' },
    { tag = 'Changé', text = "Noms au-dessus des têtes réservés au staff, couleur par grade.", module = 'tags' },
    { tag = 'Changé', text = "Créateur de personnage redessiné ; tablette transparente.", module = 'character' },
} })
N.Add({ id = 'fix37', date = '2026-10-17', title = 'Gros correctif de présentation', items = {
    { tag = 'Corrigé', text = "Commandes « restreintes » : la restriction ne s'appliquait jamais (faille corrigée).", module = 'commands' },
    { tag = 'Corrigé', text = "Second emploi : il est maintenant payé à chaque paie (pourcentage réglable).", module = 'biz' },
    { tag = 'Corrigé', text = "Points « bureau du patron / siège » : la tablette s'ouvre enfin." },
    { tag = 'Corrigé', text = "Garage : une page avec une note faisait planter l'écran." },
    { tag = 'Amélioré', text = "290 actions du panel et 119 événements du jeu testés avec des données absurdes : plus aucun plantage." },
} })

-- Actions -------------------------------------------------------------------------------------------------------------------------------
PB.Action('news.read', nil, function(ctx) N.MarkRead(ctx.license) return true, { unseen = 0 } end, { read = true })

-- Module --------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'whatsnew', label = 'Nouveautés', icon = 'sparkle', group = 'Pilotage', order = 5, perm = 'whatsnew.view', hint = 'Ce qui change à chaque mise à jour',
    doc = "## Nouveautés\nChaque mise à jour de Shadow Base ajoute une entrée ici, avec un lien direct vers le module concerné. Une pastille signale ce que tu n'as pas encore lu ; « Tout marquer comme lu » l'efface pour ton compte.",
    view = function(ctx)
        return { tabs = { { id = 'all', label = 'Mises à jour', icon = 'sparkle', build = function()
            local unseen, entries = N.For(ctx.license, 50)
            local blocks = {}
            if unseen > 0 then blocks[#blocks + 1] = B.actions({ { action = 'news.read', label = 'Tout marquer comme lu (' .. unseen .. ')', icon = 'check', primary = true } }) end
            for _, e in ipairs(entries) do
                local rows = {}
                for _, it in ipairs(e.items) do
                    local row = { tag = it.tag, text = it.text }
                    if it.module then row.actions = { { nav = it.module, label = 'Ouvrir', icon = 'arrow' } } end
                    rows[#rows + 1] = row
                end
                blocks[#blocks + 1] = B.table({ id = 'news_' .. e.id, title = (e.new and 'NOUVEAU · ' or '') .. e.title .. (e.date ~= '' and ('  (' .. e.date .. ')') or ''), columns = { { k = 'tag', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' } }, rows = rows })
            end
            if #blocks == 0 then blocks[1] = B.notice('info', 'Aucune nouveauté pour le moment.') end
            return blocks
        end } } }
    end,
})

N.Add({ id = 'lot39', date = '2026-10-17', title = 'Patch notes 39 : images, tablettes, placement, nettoyage', items = {
    { tag = 'Corrigé', text = "Images d'objets de l'inventaire et tablette des organisations (mise en page)." },
    { tag = 'Changé', text = "Tablette entreprise : uniquement les outils du métier (police : appels, détenus, amendes, dossiers).", module = 'biz' },
    { tag = 'Nouveau', text = "Placement à l'écran : déplace le vrai HUD, le chat, les menus et l'invite.", module = 'placement' },
    { tag = 'Changé', text = "Onglets en double supprimés (Services, Argent, Documentation, Garages).", module = 'general' },
} })

PB.SelfTest.Add('nouveautés', function(R)
    R.check(#N.list >= 3, 'journal', 'aucune entrée')
    local seen = {}
    for _, e in ipairs(N.list) do
        R.check(not seen[e.id], 'journal', 'identifiant en double : ' .. e.id)
        seen[e.id] = true
        R.check(#e.items > 0, 'journal', 'entrée vide : ' .. e.id)
    end
end)

N.Add({ id = 'patch40', date = '2026-10-18', title = 'Patch notes 40 : inventaire, territoires, points, identité', items = {
    { tag = 'Corrigé', text = "Inventaire : glisser-déposer, vrais filtres, armes jamais consommées (touches 1 à 5)." },
    { tag = 'Nouveau', text = "Tablette illégale : carte des territoires ; Mirror Park donne un gilet toutes les 10 h dans le coffre de l'organisation." },
    { tag = 'Nouveau', text = "Carte : « Configurer tout » pose tous les points d'une entreprise ou d'un gang d'une traite.", module = 'carte' },
    { tag = 'Changé', text = "Supérette : interface d'origine avec panier. Notifications : déplacement corrigé." },
    { tag = 'Nouveau', text = "Logo W et bannières Shadow Base (offres, Halloween, patch notes)." },
    { tag = 'Nouveau', text = "Menus : bannière animée Shadow Base (réglable dans Menus > Apparence).", module = 'menus' },
} })

N.Add({ id = 'patch41', date = '2026-10-18', title = 'Patch notes 41 : aides, infos, ALT, bannière, chuchoter', items = {
    { tag = 'Nouveau', text = "Barre d'aide en bas de l'écran : noclip (molette = vitesse, Ctrl, Maj) et cabine de vêtements." },
    { tag = 'Changé', text = "Les infos d'un joueur, l'argent, les papiers et la plaque s'affichent dans une fiche à côté du menu, plus en notification." },
    { tag = 'Nouveau', text = "Menu ALT en cascade, épuré (nouvelle version par défaut).", module = 'interface' },
    { tag = 'Nouveau', text = "Bannière des menus : le W se dessine, le texte suit le menu ouvert (Menu admin, Menu police…).", module = 'menus' },
    { tag = 'Nouveau', text = "Menu staff : Chuchoter, message que seul le joueur reçoit (voix privée en option).", module = 'staff' },
    { tag = 'Changé', text = "Le W de Shadow Base est le logo par défaut du panel.", module = 'general' },
} })
N.Add({ id = 'patch42', date = '2026-10-18', title = 'Patch notes 42 : organisations, starter pack, véhicules de gang', items = {
    { tag = 'Nouveau', text = "Carte du jeu › Entreprise / organisation : tu remplis les infos, puis tu es guidé en jeu pour poser le point coffre, le point boss, le rangement des véhicules et la sortie du garage.", module = 'carte' },
    { tag = 'Nouveau', text = "Module Organisations : création d'un gang avec ses grades, liste (membres, véhicules, caisse), réglages.", module = 'orgs' },
    { tag = 'Nouveau', text = "Starter pack à la création : objets dans le coffre, argent dans la caisse et trois véhicules de départ (tout est réglable).", module = 'orgs' },
    { tag = 'Nouveau', text = "Garage de gang : tu y retrouves tes véhicules et ceux de l'organisation ; les membres ont la clé des véhicules du gang.", module = 'garage' },
    { tag = 'Nouveau', text = "Donner un de tes véhicules à l'organisation, le reprendre, et le chef peut attribuer un véhicule du gang à un membre.", module = 'garage' },
    { tag = 'Nouveau', text = "Panel : ajouter un véhicule neuf à une organisation ou en attribuer un existant (par plaque).", module = 'orgs' },
    { tag = 'Changé', text = "Un garage de gang n'apparaît (carte, marqueur, touche E) que pour les membres de ce gang.", module = 'garage' },
} })


N.Add({ id = 'patch43', date = '2026-10-20', title = 'Patch notes 43 : extensions, staff, PNJ, correctif images', items = {
    { tag = 'Nouveau', text = 'Extensions : une autre ressource se branche sur Shadow Base (pages, réglages, actions, permissions). Module Extensions.', module = 'extensions' },
    { tag = 'Nouveau', text = 'Menu staff : « Libérer de prison » et liste des détenus dans Gestion des sanctions.' },
    { tag = 'Nouveau', text = 'Monde : supprimer les PNJ et les PNJ police (activés par défaut).', module = 'world' },
    { tag = 'Correctif', text = "Envoyer une image depuis le PC (bannière, logo) ne déconnecte plus." },
} })
N.Add({ id = 'patch44', date = '2026-10-20', title = 'Patch notes 44 : activités, blips, inventaire, territoires, HUD', items = {
    { tag = 'Nouveau', text = 'Activités ouvertes à tous (pêche, mine, bois, agriculture, cueillette, décharge, craft), posées au Builder.', module = 'wb_activites' },
    { tag = 'Nouveau', text = 'Blips : coffres en dégradé aux couleurs du serveur, QG de gang, vraie icône Burger Shot.' },
    { tag = 'Nouveau', text = "Message en entrant dans un territoire ; HUD faim / soif / micro et barres vie / armure." },
    { tag = 'Correctif', text = "Fond de l'inventaire : le jeu se voit derrière (plus noir opaque)." },
} })
N.Add({ id = 'patch45', date = '2026-10-20', title = 'Patch notes 45 : portes, menu boss, builder, GPS, animations', items = {
    { tag = 'Nouveau', text = 'Portes verrouillables par groupes (F10 › Builder › Portes ou /portes).', module = 'wb_portes' },
    { tag = 'Nouveau', text = 'Gestion des entreprises et organisations seulement au point boss.' },
    { tag = 'Nouveau', text = 'Builder : supprimer un point ou tous les points ; GPS dans le F5 ; animations manger et boire.' },
    { tag = 'Correctif', text = 'Burger Shot : menus qui clignotaient, client PNJ mal placé ; menu F2 retiré (tout est dans ALT).' },
} })
N.Add({ id = 'patch46', date = '2026-10-20', title = 'Patch notes 46 : points de métier pour toutes les entreprises', items = {
    { tag = 'Nouveau', text = 'Builder : accueil, atelier (garages), cuisine / bar et comptoir de vente selon le métier.', module = 'carte' },
} })
N.Add({ id = 'patch47', date = '2026-10-20', title = 'Patch notes 47 : agence immobilière, mises à jour', items = {
    { tag = 'Nouveau', text = 'Agence immobilière : annonces, intérieurs, visites et commission (menu ALT des agents).' },
    { tag = 'Nouveau', text = 'Module Mises à jour : nouvelles versions signées, patch notes et téléchargement gratuit.', module = 'updates' },
} })

N.Add({ id = 'patch48', date = '2026-10-21', title = 'Patch notes 48 : écran de chargement', items = {
    { tag = 'Nouveau', text = 'Écran de chargement : logo, barre de progression et bandeau de messages qui défile (ressource wb_loading).' },
} })
N.Add({ id = 'patch49', date = '2026-10-21', title = 'Patch notes 49 : la base devient Shadow Base', items = {
    { tag = 'Nouveau', text = 'Nouveau nom et nouveau logo : Shadow Base.', module = 'general' },
} })
N.Add({ id = 'patch50', date = '2026-10-21', title = 'Patch notes 50 : corrections, journal des expulsions, vestiaires, braquages', items = {
    { tag = 'Nouveau', text = "Journal des expulsions et bans : raison précise, origine et référence pour chaque kick.", module = 'kicks' },
    { tag = 'Correctif', text = "Anticheat : plus d'éjections pendant un restart ou un lag.", module = 'general' },
    { tag = 'Correctif', text = "Staff affiché hors ligne, touches des menus, onglets vides, suppression des anciens points.", module = 'general' },
    { tag = 'Nouveau', text = "Vrais vestiaires d'entreprise et de gang, vendeurs derrière le comptoir et braquages animés.", module = 'general' },
} })
N.Add({ id = 'patch51', date = '2026-10-21', title = 'Patch notes 51 : petits jobs, vraie pêche, vendeurs derrière le comptoir', items = {
    { tag = 'Nouveau', text = "Petits jobs pour chaque entreprise (touche O) : livraisons, taxi, dépannage, patrouille, secours, chantiers…", module = 'general' },
    { tag = 'Nouveau', text = "Pêche : raretés de poissons et de leurres, cannes, ferrage, marché aux prix variables, records.", module = 'general' },
    { tag = 'Correctif', text = "Vendeurs placés derrière le comptoir dans toutes les supérettes, magasins comme braquages.", module = 'shops' },
    { tag = 'Correctif', text = "Menotté : plus d'animations ; saisies au casier ; annonces visibles dans le chat ; couleur des gangs.", module = 'general' },
} })
N.Add({ id = 'patch52', date = '2026-10-21', title = 'Patch notes 52 : coiffeur / barbier, bandeau de démarrage', items = {
    { tag = 'Nouveau', text = "Coiffeur / barbier : coupe, couleurs, barbe, sourcils, maquillage, aperçu en direct. Builder › Commerces.", module = 'shops' },
    { tag = 'Nouveau', text = "Au démarrage, la console affiche la version, le numéro du dernier patch notes et l'état de la licence.", module = 'general' },
} })
N.Add({ id = 'patch53', date = '2026-10-21', title = 'Patch notes 53 : moins de métiers, Builder plus rapide, Auto Exotic, packs', items = {
    { tag = 'Amélioré', text = "Catalogue court : 14 entreprises utiles (dont Auto Exotic) ; les inutilisées sont retirées.", module = 'biz' },
    { tag = 'Amélioré', text = "Builder : Entrée pose le point tout de suite ; icône du siège au choix ; patron choisi parmi les joueurs connectés.", module = 'carte' },
    { tag = 'Nouveau', text = "3 packs de départ pour les organisations, donnés à la création.", module = 'orgs' },
    { tag = 'Correctif', text = "Points accueil / atelier / cuisine et points du Burger Shot : posés, affichés et supprimables.", module = 'carte' },
    { tag = 'Amélioré', text = "Inventaire : cases moins vertes, fond plus transparent.", module = 'inv' },
} })
N.Add({ id = 'patch54', date = '2026-10-21', title = 'Patch notes 54 : grosse optimisation, noms et ID réservés au staff', items = {
    { tag = 'Amélioré', text = "Noms, grades et ID visibles par le staff seulement (étiquettes, menu ALT, inventaire).", module = 'tags' },
    { tag = 'Amélioré', text = "Optimisation client et serveur : boucles allégées, moins d'envois réseau.", module = 'monitor' },
    { tag = 'Correctif', text = "Blips des entreprises : couleur, taille et portée rétablies.", module = 'carte' },
} })
N.Add({ id = 'patch55', date = '2026-10-22', title = 'Patch notes 55 : VIP, tatoueur, chasse, braquages, logements, animaux', items = {
    { tag = 'Nouveau', text = "VIP (menu staff, /vip, panel) : multi-personnages, animaux de compagnie, meubles, canne et leurres VIP, bonus de revente.", module = 'vip' },
    { tag = 'Nouveau', text = "Salon de tatouage, chasse, braquages (cambriolages, receleur, distributeurs, GoFast, fourgons blindés).", module = 'shops' },
    { tag = 'Nouveau', text = "Logements : impôt foncier, colocation, sonnette, intérieurs instanciés, meubles et aquarium.", module = 'housing' },
    { tag = 'Amélioré', text = "Builder (fantôme, Ctrl+Z), inventaire (tri, recherche, coffre), vestiaires, spectateur, événements programmés.", module = 'events' },
    { tag = 'Amélioré', text = "Optimisation : panel chargé à la demande, images allégées, purge des journaux, index.", module = 'monitor' },
} })
N.Add({ id = 'patch56', date = '2026-10-22', title = "Patch notes 56 : atelier d'armes, portes en ALT, menu ALT admin, VIP dans F5", items = {
    { tag = 'Nouveau', text = "Atelier d'armes clandestin (wb_armes) : ateliers cachés, pièces, plans, niveau d'armurier, finition, mini-jeu, marché noir.", module = 'extensions' },
    { tag = 'Nouveau', text = "Portes en ALT pour le staff : porte surlignée, choix des entreprises et gangs qui gardent l'accès, avec recherche.", module = 'ctx' },
    { tag = 'Nouveau', text = "Menu ALT staff : DV, pneus crevés, faire descendre, occupants avec ID, donner un véhicule, mute chat et micro, TP.", module = 'ctx' },
    { tag = 'Amélioré', text = "Carte « Mon VIP » dans le menu F5 : statut, date de fin, avantages.", module = 'personal' },
    { tag = 'Corrigé', text = "Invites E des extensions (pêche, chasse…) bloquées, envoi d'images depuis le PC bloqué, invite E hors de l'écran.", module = 'general' },
} })
N.Add({ id = 'patch57', date = '2026-10-22', title = 'Patch notes 57 : entreprises sur mesure et toutes les icônes de la carte', items = {
    { tag = 'Nouveau', text = "Entreprises sur mesure : nom libre, fonctionnement de n'importe quel type (mécano, café, bar, taxi…), créées au Builder ou dans le panel.", module = 'biz' },
    { tag = 'Nouveau', text = "Sélecteur des 965 icônes de GTA avec aperçu, recherche et couleur, pour le siège des entreprises.", module = 'biz' },
    { tag = 'Amélioré', text = "Type de fonctionnement et icône modifiables après coup ; les petits jobs suivent le type choisi.", module = 'biz' },
} })
N.Add({ id = 'patch58', date = '2026-10-22', title = 'Patch notes 58 : appels vocaux au téléphone', items = {
    { tag = 'Nouveau', text = "Appels vocaux (pma-voice) : application Appels avec clavier, appels récents et manqués ; bouton Appeler sur les contacts et les conversations.", module = 'phone' },
    { tag = 'Nouveau', text = "Appeler un service de l'annuaire : tous les employés en service sonnent, le premier qui décroche prend l'appel.", module = 'phone' },
    { tag = 'Nouveau', text = "Bandeau d'appel en haut de l'écran, sonnerie, téléphone à l'oreille ; /decrocher et /raccrocher.", module = 'phone' },
    { tag = 'Sécurité', text = "Canaux d'appel tirés au hasard et surveillés : un joueur qui tente d'écouter l'appel d'un autre est retiré et journalisé.", module = 'phone' },
} })
N.Add({ id = 'patch59', date = '2026-10-22', title = 'Patch notes 59 : radio F4, tickets Discord, anti-duplication, chronologie', items = {
    { tag = 'Nouveau', text = "Poste radio sur F4 : fréquence au pavé ou aux flèches, volume retenu, raccourcis vers les canaux de ton métier ; parler avec Verr. Maj.", module = 'radio' },
    { tag = 'Nouveau', text = "Tickets : /ticket (catégorie, conversation, suivi), /report devient un ticket ; le staff répond dans le panel ou directement sur Discord.", module = 'tickets' },
    { tag = 'Nouveau', text = "Anti-duplication : alerte quand un joueur gagne trop d'argent ou reçoit trop d'objets en 1 h (staff en service + Discord).", module = 'vigil' },
    { tag = 'Nouveau', text = "Chronologie d'un joueur : connexions, argent, objets, sanctions, tickets, expulsions et journal sur une seule ligne du temps.", module = 'vigil' },
    { tag = 'Nouveau', text = "Téléphone : partager sa position par message (bouton « Y aller ») et haut-parleur pendant un appel.", module = 'phone' },
    { tag = 'Corrigé', text = "Champs du panel refusés à tort (« format invalide ») : une touche comme F4 pour le noclip, les identifiants, les listes « nom|valeur ».", module = 'general' },
    { tag = 'Changé', text = "F4 n'est plus le raccourci staff « téléportation au point GPS » (à reprendre dans Staff › Raccourcis si besoin).", module = 'staff' },
} })
N.Add({ id = 'patch60', date = '2026-10-22', title = 'Patch notes 60 : bar et discothèque, télévisions, 911, conférences, coma', items = {
    { tag = 'Nouveau', text = "Bar, discothèque, café : le barman prépare au bar (ingrédients payés par la caisse) puis sert un client avec ALT ; le client accepte et paie.", module = 'biz' },
    { tag = 'Nouveau', text = "Télévisions : ALT sur un écran, puis un lien YouTube ou Vimeo ; tout le monde autour voit et entend la même vidéo.", module = 'tv' },
    { tag = 'Nouveau', text = "Téléphone : SOS 911 (police et secours sonnent et reçoivent ta position), conférence à plusieurs, numéros bloqués, groupes de discussion.", module = 'phone' },
    { tag = 'Nouveau', text = "Faim ou soif à 0 : coma (réanimation par les secours possible), avec un avertissement sous 10 %.", module = 'hud' },
    { tag = 'Nouveau', text = "Builder : dupliquer un point, déplacer tous les points d'un coup, « y aller » avec vérification du sol ; panel › Points posés (carte et problèmes).", module = 'pointsmap' },
    { tag = 'Amélioré', text = "Garage et téléphone : carburant, moteur et carrosserie de chaque véhicule, et bouton Localiser.", module = 'garage' },
    { tag = 'Amélioré', text = "Menu F10 : recherche unique (joueur, ID, plaque, numéro). Économie : gains par heure et par activité.", module = 'staff' },
} })
N.Add({ id = 'patch61', date = '2026-10-22', title = 'Patch notes 61 : points et étiquettes, garage avec aperçu, noclip fantôme', items = {
    { tag = 'Changé', text = "Plus de flèches : un petit point lumineux marque chaque endroit où interagir, et l'étiquette « [E] GARAGE » s'affiche dessus, dans le monde.", module = 'hud' },
    { tag = 'Nouveau', text = "Garage en menu : en descendant sur un véhicule, il apparaît en transparence à la sortie, avec une caméra.", module = 'garage' },
    { tag = 'Corrigé', text = "Fourrière : la récupération marche même sans point de sortie ou si le véhicule est resté en ville ; tu es mis au volant.", module = 'garage' },
    { tag = 'Amélioré', text = "Noclip : invisible pour tous les joueurs, tu te vois en transparence (ton véhicule aussi).", module = 'staff' },
} })
N.Add({ id = 'patch62', date = '2026-10-22', title = 'Patch notes 62 : atelier mécano facturé, customisation en direct, menu Shadow retravaillé', items = {
    { tag = 'Nouveau', text = "Customisation dans le véhicule : peintures (classique, mat, métal, chrome, nacré, teinte libre), jantes, carrosserie, Benny's, performances, xénons, néons, fumée, vitres, plaque, klaxon, livrée — chaque option s'affiche sur la voiture.", module = 'mech' },
    { tag = 'Nouveau', text = "Devis puis facture au client : il paie (la caisse de l'entreprise encaisse) ou refuse (la custom est retirée). Réparer et nettoyer depuis F5 › Mon entreprise, facturés pareil.", module = 'mech' },
    { tag = 'Nouveau', text = "Mécano en service : ouvre et conduit les véhicules des clients. Tenue de service (ex. Benny's) enfilée à la prise de service, vêtements rendus à la fin.", module = 'mech' },
    { tag = 'Changé', text = "Menu Shadow retravaillé (fond, bannière, lignes et icônes de la maquette).", module = 'menus' },
    { tag = 'Corrigé', text = "Inventaire : titres en français qui ne débordent plus, plus de cadenas « Premium » dans les coffres. Portes : beaucoup plus de portes détectées en ALT (portails, grilles, portes de garage, doubles portes).", module = 'inv' },
} })
N.Add({ id = 'patch63', date = '2026-10-23', title = 'Patch notes 63 : casino et repères de la carte', items = {
    { tag = 'Nouveau', text = "Casino au Builder (Casino › Caisse / Jeu) : machine à sous, roulette, blackjack, roue de la fortune, dés, plus haut / plus bas, tickets à gratter, avec de vraies animations. Tous les tirages sont faits par le serveur.", module = 'casino' },
    { tag = 'Nouveau', text = "Jetons de casino dans l'inventaire (achetés et revendus à la caisse), loterie hebdomadaire avec cagnotte, casino de l'État ou d'une entreprise, statistiques et redistribution affichées.", module = 'casino' },
    { tag = 'Nouveau', text = "Repères : les doublons sont masqués automatiquement, les repères fantômes supprimés ; « /blips reset » ou Points posés › Repères des joueurs pour tout redessiner.", module = 'pointsmap' },
    { tag = 'Corrigé', text = "Repères qui restaient sur la carte : joueur observé par le staff, animal de compagnie, alertes 911 et secours empilées.", module = 'pointsmap' },
} })
N.Add({ id = 'patch64', date = '2026-10-23', title = 'Patch notes 64 : la ville réagit (impayés, mandats, fourrière, secours)', items = {
    { tag = 'Nouveau', text = "Factures et amendes impayées : majoration, puis saisie sur le compte (même hors ligne), puis mandat visible dans la tablette de la police.", module = 'coherence' },
    { tag = 'Nouveau', text = "Véhicule abandonné ou disparu : envoyé en fourrière, SMS au propriétaire. Messages automatiques au téléphone (Trésor public, Fourrière, Hôpital…).", module = 'coherence' },
    { tag = 'Nouveau', text = "Joueur à terre : les secouristes en service sont alertés tout seuls ; les frais d'hôpital vont à la caisse des secours, facture si le joueur n'a pas l'argent.", module = 'coherence' },
    { tag = 'Amélioré', text = "Chronologie du joueur : factures, amendes, majorations, saisies, mandats, fourrières, comas, prison, réanimations.", module = 'vigil' },
    { tag = 'Corrigé', text = "Employés restés « en service » après une déconnexion ; page Paie qui affichait toujours « payée par l'État ». Patron prévenu quand la caisse ne couvre plus la paie.", module = 'coherence' },
} })
N.Add({ id = 'patch65', date = '2026-10-23', title = 'Patch notes 65 : taxi, dépanneuse, annonces, véhicules de service, logements', items = {
    { tag = 'Nouveau', text = "Taxi : app Taxi du téléphone (commander, accepter), taximètre mesuré par le serveur, paiement automatique ou facture.", module = 'taxi' },
    { tag = 'Nouveau', text = "Dépanneuse : un mécano en service avec un plateau charge un véhicule (ALT), le décharge ou le dépose à la fourrière contre une prime pour sa caisse.", module = 'garage' },
    { tag = 'Nouveau', text = "Véhicules de service d'entreprise (clé seulement en service) et clés prêtées pour 1 à 24 h.", module = 'garage' },
    { tag = 'Nouveau', text = "Téléphone : app Annonces (vente, achat, emploi, logement…) avec Écrire / Appeler l'auteur.", module = 'phone' },
    { tag = 'Nouveau', text = "Logements : loyer prélevé même hors ligne, expulsion après les impayés tolérés, affaires mises à la consigne, dette transmise à l'agence.", module = 'housing' },
    { tag = 'Amélioré', text = "Économie › Tableau de bord ; historique récent à côté du spectateur staff ; plus d'annonces de redémarrage en double.", module = 'economy' },
} })
N.Add({ id = 'patch66', date = '2026-10-23', title = 'Patch notes 66 : Builder rangé, garages terrestres, aériens et navals', items = {
    { tag = 'Amélioré', text = "Builder (F10 › Builder) : tout est rangé en 7 sections (Entreprises, Illégal, Commerces et services, Garages et véhicules, Immobilier et coffres, Activités, Autres) avec une recherche, au lieu d'une longue liste.", module = 'carte' },
    { tag = 'Nouveau', text = "Garages créés en jeu : on pose l'entrée, la sortie du véhicule et le PNJ, étape par étape ; garage, hangar d'avions, port, et une fourrière pour chacun.", module = 'garage' },
    { tag = 'Nouveau', text = "Garages séparés par type : un avion ne se range que dans un hangar, un bateau que dans un port ; icône de carte selon le type, PNJ au comptoir.", module = 'garage' },
    { tag = 'Corrigé', text = "Le groupe Casino n'apparaissait pas dans le Builder ; nom du jeu repris du préréglage choisi.", module = 'casino' },
} })
N.Add({ id = 'patch67', date = '2026-10-23', title = 'Patch notes 67 : ville vivante (ouvert / fermé, contrats, plaques, Discord, journaux)', items = {
    { tag = 'Nouveau', text = "Entreprises ouvertes ou fermées : repère vert ou rouge sur la carte selon les employés en service, et annuaire du téléphone en direct (ouverts d'abord).", module = 'biz' },
    { tag = 'Nouveau', text = "Contrats de vente entre joueurs (app Contrats) : véhicule ou logement, signature à côté, paiement sécurisé et taxe de mutation.", module = 'economy' },
    { tag = 'Nouveau', text = "Plaques personnalisées (payantes, au garage) et fausses plaques pour les illégaux : la police ne retrouve plus le véhicule, retrait en ALT.", module = 'garage' },
    { tag = 'Nouveau', text = "Journal des morts (qui, par qui, arme, distance, position) et sauvegardes d'inventaire avec restauration à une date donnée.", module = 'kills' },
    { tag = 'Nouveau', text = "Discord ↔ personnage : rôles VIP, métier et groupe donnés et retirés tout seuls, pseudo du personnage, Discord obligatoire en option.", module = 'discordlink' },
} })
N.Add({ id = 'patch68', date = '2026-10-23', title = 'Patch notes 68 : largages, chasses au trésor, guerres de territoire', items = {
    { tag = 'Nouveau', text = "Largage : une zone est annoncée, une caisse tombe, le premier qui l'ouvre gagne argent et objets. Chasse au trésor : la zone se resserre toutes les 3 minutes, il faut creuser au bon endroit.", module = 'worldev' },
    { tag = 'Nouveau', text = "Lancement automatique (toutes les X minutes s'il y a assez de joueurs), planifié dans Événements, ou à la main depuis le panel.", module = 'worldev' },
    { tag = 'Nouveau', text = "Guerres de territoire planifiées (jour et heure) : points de présence dans la zone et d'éliminations de rivaux, tableau des scores à l'écran, la zone et la récompense au vainqueur, historique.", module = 'wars' },
} })
N.Add({ id = 'patch69', date = '2026-10-23', title = 'Patch notes 69 : grande chasse aux bugs', items = {
    { tag = 'Corrigé', text = "Duplication d'objets quand deux joueurs vident le même coffre en même temps ; aquarium et consigne qui pouvaient donner deux fois.", module = 'inv' },
    { tag = 'Corrigé', text = "Caisses (organisation, entreprise, casino, bar, atelier, missions) qui pouvaient payer deux fois ou passer dans le rouge sur un double clic.", module = 'economy' },
    { tag = 'Corrigé', text = "Garage : on ne range plus une voiture laissée ailleurs (doublon). Fourrière et atelier : la plaque est lue par le serveur, plus de saisie ou de tuning à distance.", module = 'garage' },
    { tag = 'Corrigé', text = "Location remboursée même véhicule détruit ; magasin qui encaissait sans donner l'objet ; remboursement accepté alors que le client n'avait plus les articles ; achat de logement payé sans être attribué en cas d'erreur.", module = 'shops' },
    { tag = 'Corrigé', text = "Se déconnecter menotté ne libère plus (toujours menotté à la reconnexion, police prévenue) ; virements à soi-même refusés.", module = 'biz' },
    { tag = 'Corrigé', text = "Braquages : un distributeur payé deux fois, GoFast livré avec n'importe quel véhicule. Fabrication (armes, activités) qui donnait l'objet même si les pièces manquaient.", module = 'extensions' },
    { tag = 'Corrigé', text = "Discord : synchronisations étalées (plus de limite de débit), pseudo envoyé seulement s'il change.", module = 'discordlink' },
} })
N.Add({ id = 'patch70', date = '2026-10-23', title = 'Patch notes 70 : poker entre joueurs, historique du casino', items = {
    { tag = 'Nouveau', text = "Poker Texas Hold'em entre joueurs (Builder › Casino › Jeu › Poker) : 2 à 6 places, cave en jetons, blindes, relances, tapis et pots secondaires, temps de parole, commission du casino dès le flop.", module = 'casino' },
    { tag = 'Nouveau', text = "Casino › Mes parties : bilans du jour, de la semaine et depuis toujours, jeu préféré, plus gros gain, dernières parties. Panel › Casino › Joueurs : classement des gagnants et perdants.", module = 'casino' },
} })
N.Add({ id = 'patch71', date = '2026-10-23', title = "Patch notes 71 : hélipad, où est ma voiture, meubles à vendre, tenue de service", items = {
    { tag = 'Nouveau', text = "Hélipad d'entreprise (Builder › entreprise › Hélipad) et catalogue de véhicules de service achetés avec la caisse : hélicoptères à l'hélipad, voitures au garage, bateaux au port ; revente à 50 %.", module = 'garage' },
    { tag = 'Nouveau', text = "Téléphone › Garage : où est chaque véhicule (en direct, dernière position connue, garage, fourrière la plus proche), itinéraire et repère sur la carte ; véhicules de service et clés prêtées listés aussi.", module = 'garage' },
    { tag = 'Nouveau', text = "Meubles en objets : Magasin de meubles au Builder, on pose ses meubles chez soi et ils reviennent dans le sac quand on les retire. App Contrats : vente d'objets entre joueurs (meubles et autres), paiement sécurisé.", module = 'housing' },
    { tag = 'Amélioré', text = "Tenue de service : la dernière tenue enfilée au vestiaire devient sa tenue de service ; chacun peut désactiver la tenue automatique.", module = 'biz' },
    { tag = 'Corrigé', text = "Licence : la limite de joueurs et le blocage sans licence ne s'appliquaient pas (erreur dans la connexion).", module = 'general' },
} })
N.Add({ id = 'patch72', date = '2026-10-23', title = 'Patch notes 72 : nouveau menu ALT, drapeaux de vente, tournois de poker, badge', items = {
    { tag = 'Amélioré', text = "Menu ALT refait : petite boîte bleu nuit, texte seul, barre bleue sur la ligne survolée, les catégories s'ouvrent dedans et « Retour » remonte. Les anciens styles restent au choix dans le panel.", module = 'ctx' },
    { tag = 'Amélioré', text = "Drapeaux de vente redessinés (vrai drapeau rectangulaire qui flotte dans le vent, emblème, blanc quand la zone est neutre). Plus de texte au-dessus du drapeau : l'état de la zone s'affiche sur le côté de l'écran.", module = 'flags' },
    { tag = 'Nouveau', text = "Poker : tournois (droit d'entrée, jetons de tournoi, blindes qui doublent, cagnotte partagée entre les premiers, classement dans le panel) et tables privées avec mot de passe.", module = 'casino' },
    { tag = 'Nouveau', text = "Croupiers du casino aux tables (blackjack, roulette, dés, plus haut / plus bas, poker) avec un geste à chaque donne.", module = 'casino' },
    { tag = 'Nouveau', text = "Badge d'employé : ALT › Métier › Montrer mon badge (entreprise, grade, matricule, en service ou non).", module = 'biz' },
} })
N.Add({ id = 'patch73', date = '2026-10-23', title = 'Patch notes 73 : menu ALT comme la référence, corrections', items = {
    { tag = 'Amélioré', text = "Menu ALT : large boîte bleu ardoise translucide, texte blanc bien espacé, pastille bleu cyan sur la ligne choisie, sans surlignage.", module = 'ctx' },
    { tag = 'Corrigé', text = "À la déconnexion, le joueur disparaissait avant que les autres scripts ne le lisent : le service n'était pas toujours remis à zéro et la déconnexion n'apparaissait pas dans la chronologie.", module = 'coherence' },
    { tag = 'Corrigé', text = "Points d'entreprise et sacs au sol : demandes limitées (un client modifié pouvait surcharger la base de données).", module = 'inv' },
} })
N.Add({ id = 'patch74', date = '2026-10-23', title = "Patch notes 74 : fusion 1.2.2, inventaire d'origine conservé, corrections", items = {
    { tag = 'Amélioré', text = "Tout le travail des patchs 63 à 73 est intégré (casino, poker, taxi, contrats, guerres de territoire, largages, Builder rangé…), sauf le nouvel inventaire : l'inventaire d'origine est gardé (couleur du serveur, décor assombri, flou). Les protections anti-duplication de l'inventaire sont bien reprises.", module = 'inv' },
    { tag = 'Corrigé', text = "Un serveur passé par la 1.2.2 retrouve automatiquement l'apparence d'origine de l'inventaire (une seule fois, réglable ensuite dans le panel).", module = 'inv' },
    { tag = 'Corrigé', text = "Loterie du casino : le prochain tirage pouvait être décalé d'une heure au changement d'heure été / hiver.", module = 'casino' },
    { tag = 'Corrigé', text = "Téléphone : les apps (Contrats, Annonces…) plantaient au démarrage du serveur ; Économie › Contrats ne s'ouvrait pas dans le panel.", module = 'phone' },
} })
N.Add({ id = 'patch75', date = '2026-10-23', title = "Patch notes 75 : menus F6 / F7 en lib, garage sans fenêtre, taxi facturé, HUD et police d'écriture", items = {
    { tag = 'Nouveau', text = "F6 : menu de mon entreprise (lib) avec « Prendre / Quitter mon service », facture, menottes, réparation, nettoyage, customisation, taxi, service au bar… F5 ne fait plus que dire si on est dans une entreprise.", module = 'quick' },
    { tag = 'Nouveau', text = "F7 : menu de mon organisation (lib) : ligoter, détacher, escorter, mettre dans un véhicule, fouiller, GPS du QG, coffre, caisse, membres. La tablette de l'organisation s'ouvre seulement au QG.", module = 'orga' },
    { tag = 'Amélioré', text = "Choisir quelqu'un (facture, menottes, fouille, service…) : la personne survolée est entourée et marquée d'une flèche. Une facture reçue s'affiche tout de suite : Payer ou Plus tard.", module = 'quick' },
    { tag = 'Amélioré', text = "Taxi : tout se fait au F6 (courses, compteur), et à la fin le chauffeur envoie la facture au client choisi. Le téléphone ne sert plus qu'à commander.", module = 'taxi' },
    { tag = 'Corrigé', text = "Garage : plus aucune fenêtre (Clés, Organisation, Entreprise sont dans le menu), le joueur est figé dans le menu, et une sortie ratée remet le véhicule au garage au lieu de bloquer.", module = 'garage' },
    { tag = 'Nouveau', text = "Builder : véhicules de l'entreprise choisis dans tout le catalogue, par catégorie. Aperçu en transparence avant de poser un jeu du casino, et le menu revient d'une étape après la pose.", module = 'carte' },
    { tag = 'Amélioré', text = "Portes : on coche qui a accès puis Valider. Grandes portes et portails s'ouvrent de plus loin, et en voiture jusqu'à 15 m.", module = 'extensions' },
    { tag = 'Amélioré', text = "Prise de service en menu, tablette en main à l'ouverture, klaxons audibles avant de choisir chez le mécano, micro qui marche en appel même téléphone ouvert.", module = 'biz' },
    { tag = 'Amélioré', text = "Nouveau HUD « Shadow » collé à la mini-carte, heure et serveur en haut à droite, tableau staff en petites cases, menu ALT carré et compact, une seule police partout (Poppins), inventaire compris.", module = 'hud' },
    { tag = 'Nouveau', text = "Tableau staff : case « Joueurs en BDA », les joueurs connectés présents dans le salon vocal d'attente du support sur Discord (salon à régler dans le panel).", module = 'staff' },
    { tag = 'Nouveau', text = "Point de vente : en bas à droite, chaque organisation présente sur le point avec son nombre de membres.", module = 'flags' },
    { tag = 'Amélioré', text = "Gamertags refaits : [VIP*] [entreprise] [gang] au-dessus, [ID][Joueur] Nom (Nouveau) au milieu, le ping en dessous.", module = 'tags' },
} })
N.Add({ id = 'patch76', date = '2026-10-23', title = 'Patch notes 76 : HUD comme les photos, props permanents, clic partout, musique coupée', items = {
    { tag = 'Nouveau', text = "F10 › Props permanents : le staff pose des objets (barrières, tables, décor…) avec un aperçu, et ils restent après un redémarrage. Props proches : celui survolé est entouré, Entrée pour le retirer.", module = 'props' },
    { tag = 'Amélioré', text = "Plus de musique dans les magasins (vêtements, supérettes, Ammu-Nation, coiffeurs, tatoueurs, concession, customisation).", module = 'general' },
    { tag = 'Nouveau', text = "/bdatest (staff) : vérifie tout de suite la case « Joueurs en BDA » et dit ce qui manque.", module = 'staff' },
    { tag = 'Amélioré', text = "Un seul clic partout : menus, inventaire, menu ALT, téléphone, tablettes. Volume réglable dans le panel (Menus).", module = 'menus' },
    { tag = 'Corrigé', text = "F6 ouvrait encore la tablette et F7 ne répondait pas chez les joueurs déjà venus (anciennes touches gardées par FiveM) : F6 ouvre le menu de l'entreprise, F7 celui de l'organisation. Aussi /entreprise et /organisation.", module = 'quick' },
    { tag = 'Amélioré', text = "Invite d'interaction, notifications (avec le logo du serveur) et compteur refaits comme les photos de référence ; petite touche « E » rouge à la place du rond sous les points.", module = 'hud' },
    { tag = 'Nouveau', text = "En haut à droite : ton métier et ton organisation.", module = 'hud' },
    { tag = 'Corrigé', text = "Points de missions civiles d'exemple (dont « coursier ») qui restaient sur la carte : désactivés, et supprimables au Builder.", module = 'civil' },
} })
N.Add({ id = 'patch77', date = '2026-10-23', title = "Patch notes 77 : logement, fiche d'infos, braquage, gamertags, invite", items = {
    { tag = 'Corrigé', text = "Logement : l'invite « E : sortir » restait affichée partout dans l'appartement (et même après en être sorti autrement). Elle n'apparaît plus qu'à la porte, et disparaît dès qu'on n'est plus dedans.", module = 'housing' },
    { tag = 'Corrigé', text = "Fiche d'infos (menu staff, papiers, menu ALT…) : elle se ferme en même temps que le menu au lieu de rester à l'écran.", module = 'staff' },
    { tag = 'Amélioré', text = "Fiche d'infos plus carrée et transparente, dans le style du serveur.", module = 'staff' },
    { tag = 'Corrigé', text = "Invite d'interaction : texte et touche plus petits, une touche longue (RMB…) tient dans son carré.", module = 'hud' },
    { tag = 'Corrigé', text = "Braquage de supérette : le vendeur ne reste plus à te regarder, il va vider la caisse dans un sac.", module = 'crime' },
    { tag = 'Corrigé', text = "Gamertags qui bougeaient quand on tourne la caméra ou qu'on marche : ils restent bien fixes au-dessus des joueurs.", module = 'tags' },
    { tag = 'Amélioré', text = "Inventaire : les demi-cercles en pointillés et les petites croix du fond sont retirés.", module = 'inv' },
    { tag = 'Nouveau', text = "Une vraie image pour chaque objet du serveur (265 objets) : poissons, gibier, meubles, butin, drogues, pièces d'armes, plats, matériaux, masques, sacs… dans l'inventaire et les boutiques.", module = 'inv' },
} })
N.Add({ id = 'patch78', date = '2026-10-23', title = "Patch notes 78 : commandes de chat, 220 emotes, gestes à deux", items = {
    { tag = 'Nouveau', text = "Plus de 80 commandes de chat : /bring, /goto, /tp, /tpm, /heal, /revive, /car, /dv, /fix, /kick, /ban, /jail, /givecash… pour le staff (mêmes droits et même service que le menu F10), et /id, /donner, /de, /essayer, /siege, /position, /moteur, /coffre, /e… pour tout le monde. /aide les liste.", module = 'staff' },
    { tag = 'Nouveau', text = "Menu des emotes : 220 emotes (danses, humeurs, repos, sport, accessoires, boissons, nourriture, métiers, gestes) et un aperçu dans chaque carte.", module = 'animmenu' },
    { tag = 'Nouveau', text = "8 nouveaux gestes à deux : taper dans la main, accolade, tape dans le dos, poignée virile, bise, remettre un objet, gifle et coup de tête (RP). « Checker » fait un vrai check du poing.", module = 'ctx' },
    { tag = 'Corrigé', text = "Danse 1 et Danse 2 ne se lançaient pas (animations inexistantes) : remplacées.", module = 'animmenu' },
    { tag = 'Amélioré', text = "Audit complet : animations, événements, interface et manifestes vérifiés sur toute la base.", module = 'general' },
} })
N.Add({ id = 'patch79', date = '2026-10-23', title = "Patch notes 79 : cases à cocher, notifications, taille du HUD", items = {
    { tag = 'Corrigé', text = "Menus : une case à cocher qui se cochait puis se décochait toute seule (double-clic, clics rapprochés, réglages du service staff).", module = 'menus' },
    { tag = 'Amélioré', text = "Notifications : les notifications identiques ne s'empilent plus, la carte affiche « x2, x3… ».", module = 'hud' },
    { tag = 'Corrigé', text = "HUD en haut à droite : cadre noir autour de l'ID retiré.", module = 'hud' },
    { tag = 'Nouveau', text = "F5 › Mes paramètres : taille du HUD réglable par chaque joueur (80 % à 160 %).", module = 'personal' },
} })
N.Add({ id = 'patch80', date = '2026-10-23', title = "Patch notes 80 : ID permanent, boutique en coins, HUD agrandi", items = {
    { tag = 'Nouveau', text = "ID permanent : chaque compte garde le même numéro pour toujours (têtes des joueurs, HUD, /id, menus staff, panel, journaux). Les commandes (/goto 12…) et les champs « ID du joueur » demandent cet ID ; la recherche staff trouve aussi un joueur hors ligne.", module = 'players' },
    { tag = 'Nouveau', text = "Boutique du serveur (/boutique, F11, menu Échap) : armes permanentes, véhicules, VIP, villas, argent en jeu, objets, plaques personnalisées, payés en coins.", module = 'premium' },
    { tag = 'Nouveau', text = "Les coins s'achètent uniquement avec de l'argent réel (Tebex : commande « shadowcoins add sid:{sid} <coins> {transaction} », jamais créditée deux fois). Le staff peut créditer ou retirer depuis le panel, avec un motif tracé.", module = 'premium' },
    { tag = 'Nouveau', text = "Arme permanente : liée au joueur (ni donnée, ni jetée, ni prise lors d'une fouille) ; perdue, elle se récupère dans « Mes achats ». Villa de la boutique : sans impôt ni loyer, intérieur et meubles au choix même sans VIP.", module = 'premium' },
    { tag = 'Corrigé', text = "HUD agrandi (F5 › taille du HUD) : l'argent sortait au-dessus de la carte. Il grossit maintenant depuis le haut de la carte, voix / faim / soif depuis le bas.", module = 'hud' },
    { tag = 'Corrigé', text = "Taxi : la part du chauffeur suit son compte (payée même s'il s'est déconnecté, jamais à un autre joueur qui reprend son numéro).", module = 'biz' },
    { tag = 'Corrigé', text = "Menu F7 : un membre d'organisation pouvait libérer, escorter, mettre en véhicule ou fouiller un prisonnier menotté par la police.", module = 'orga' },
    { tag = 'Corrigé', text = "Choix d'une personne (F6, F7, mécano) : le numéro de connexion des inconnus n'apparaît plus.", module = 'quick' },
    { tag = 'Amélioré', text = "Menu Échap : bouton « Boutique du serveur » et solde de coins sur l'accueil.", module = 'pause' },
} })
N.Add({ id = 'patch81', date = '2026-10-23', title = "Patch notes 81 : cadeaux et promotions dans la boutique", items = {
    { tag = 'Nouveau', text = "Boutique : « Offrir » un article à un joueur connecté (avec son ID permanent). C'est l'acheteur qui paie ; le joueur est prévenu et le retrouve dans « Mes achats » (« Offert par … »). Les plaques ne s'offrent pas.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : promotions par article (réduction en % et durée en jours) depuis le panel. Les joueurs voient le prix barré, le badge « −25 % » et la date de fin.", module = 'premium' },
    { tag = 'Corrigé', text = "ID permanent : à la déconnexion, l'ID restait associé au numéro de connexion ; un joueur qui reprenait ce numéro pouvait l'hériter. Il est maintenant libéré proprement.", module = 'players' },
} })
N.Add({ id = 'patch82', date = '2026-10-23', title = "Patch notes 82 : nouvelle boutique", items = {
    { tag = 'Amélioré', text = "Boutique entièrement redessinée : colonne avec le solde et « Acheter des coins », catégories en couleur, article à la une (promotion ou plus bel article), grandes cartes avec image, prix doré et badges (−25 %, déjà à toi, plus que 3…).", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : un clic sur un article ouvre sa fiche (grande image, ce que l'on reçoit, prix), avec confirmation de l'achat, « Offrir » et le choix de la plaque dans la même fiche. Échap ferme d'abord la fiche.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : « Mes achats » et « Historique » en listes claires, recherche dans toutes les pages, message de résultat en bas de la fenêtre.", module = 'premium' },
} })
N.Add({ id = 'patch131', date = '2026-10-27', title = "Patch notes 131 : props du staff et menu staff trié", items = {
    { tag = 'Nouveau', text = "Menu staff › Props permanents › Poser un prop : un catalogue intégré trié par thème (Barrières et signalisation, Mobilier, Événements, Éclairage et énergie, Chantier et stockage, Divers). Les modèles ajoutés dans le panel arrivent dans « Ajoutés par le serveur ».", module = 'staff' },
    { tag = 'Nouveau', text = "Aperçu au survol : en passant sur un prop (clavier ou souris), il apparaît en transparence devant toi et tourne sur lui-même. Entrée pour le placer, puis E pour le poser.", module = 'staff' },
    { tag = 'Amélioré', text = "Le réglage des noms au-dessus des têtes quitte l'accueil du menu staff : il est dans Gestion personnelle › Affichage, à côté des noms staff, du squelette et des repères.", module = 'staff' },
    { tag = 'Amélioré', text = "Gestion personnelle rangée en sections : Déplacement, Protection, Affichage, Téléportation.", module = 'staff' },
    { tag = 'Corrigé', text = "Dans tous les menus, survoler une ligne à la souris déclenche le même effet qu'au clavier (ex. le prop proche est entouré).", module = 'staff' },
} })
N.Add({ id = 'patch83', date = '2026-10-23', title = "Patch notes 83 : boutique dans la DA du serveur", items = {
    { tag = 'Amélioré', text = "Boutique dans la DA du serveur : angles carrés, gris des notifications, actions au rouge de la touche d'interaction, titres et étiquettes en capitales comme le HUD, logo du serveur, filets de couleur par catégorie. L'or reste réservé aux coins.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : le clic du serveur se joue aussi sur les cartes et l'article à la une ; rappel « ÉCHAP Fermer » avec la touche du serveur.", module = 'premium' },
} })
N.Add({ id = 'patch84', date = '2026-10-23', title = "Patch notes 84 : boutique encore plus complète", items = {
    { tag = 'Amélioré', text = "Boutique : accueil avec un carrousel « À la une » (promotions d'abord, puis le plus bel article de chaque catégorie, défilement automatique) et une rangée par catégorie avec « Voir tout ».", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : tri par prix (croissant, décroissant) et filtre « Dans mon budget » dans chaque catégorie.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : navigation au clavier (flèches, Entrée, Échap) avec la barre des touches en bas, dans le style des invites d'interaction ; solde rappelé en bas à droite.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : photo de fond discrète selon la catégorie, cartes qui apparaissent l'une après l'autre, reflet au survol, carte choisie au clavier entourée de rouge.", module = 'premium' },
} })
N.Add({ id = 'patch85', date = '2026-10-23', title = "Patch notes 85 : fiches techniques, favoris, écran d'achat", items = {
    { tag = 'Nouveau', text = "Boutique : fiche technique lue dans le jeu (vitesse en km/h, accélération, freinage, adhérence pour les véhicules ; dégâts et chargeur pour les armes), en barres sur la fiche et la vitesse sur la carte.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : favoris (étoile sur chaque carte et dans la fiche, page « Favoris »), gardés sur le poste du joueur.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique : écran « Achat réussi » / « Cadeau envoyé » avec l'article, et le solde qui défile jusqu'à sa nouvelle valeur.", module = 'premium' },
    { tag = 'Amélioré', text = "Boutique : badge « Nouveau » sur les 3 derniers articles ajoutés au catalogue.", module = 'premium' },
} })
N.Add({ id = 'patch86', date = '2026-10-23', title = "Patch notes 86 : chasse aux bugs", items = {
    { tag = 'Corrigé', text = "ID permanent et boutique : la base de données n'était pas reliée dans ces deux modules ; en jeu, l'ID n'aurait jamais été attribué et la boutique n'aurait pas pu s'ouvrir. Corrigé, et les tests le détectent désormais.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : changer la plaque d'un véhicule de la boutique permettait ensuite de s'en faire livrer un deuxième avec « Récupérer ». L'achat suit maintenant la plaque, et « Récupérer » n'apparaît que si le véhicule a vraiment disparu.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : couleurs des catégories invisibles dans le navigateur du jeu (fonction CSS trop récente) ; remplacées.", module = 'premium' },
    { tag = 'Corrigé', text = "Boutique : elle ne s'ouvre plus par-dessus une autre interface (inventaire, téléphone, menus) ni quand on est à terre.", module = 'premium' },
    { tag = 'Corrigé', text = "Menu ALT : « Remettre sur ses roues » ne détectait jamais un véhicule retourné (fonction du jeu absente côté serveur).", module = 'ctx' },
} })
N.Add({ id = 'patch87', date = '2026-10-23', title = "Patch notes 87 : nouvelle entrée en ville", items = {
    { tag = 'Nouveau', text = "Écran d'entrée dans la boîte de nuit : vue d'ensemble avec la piste qui danse et la musique, « Appuyez sur E pour commencer » ; la caméra zoome sur ton personnage accoudé à la rambarde de la mezzanine.", module = 'entrance' },
    { tag = 'Nouveau', text = "Choix du personnage : ← → déplace la caméra d'un personnage à l'autre ; fiche (naissance, métier, argent, dernière connexion) ; emplacement libre = création du personnage ; emplacements « Réservé VIP » pour les autres.", module = 'entrance' },
    { tag = 'Nouveau', text = "Entrer en ville : transition du jeu (dézoom vers le ciel puis trois zooms jusqu'au point d'apparition), comme dans GTA. Le règlement attend la fin de la transition.", module = 'entrance' },
    { tag = 'Nouveau', text = "Réglage en jeu par le staff : /entree camera, /entree place 1 à 5, /entree piste, /entree test. Tout est aussi réglable dans le panel (Écran d'entrée).", module = 'entrance' },
} })
N.Add({ id = 'patch88', date = '2026-10-23', title = "Patch notes 88 : écran d'entrée épuré", items = {
    { tag = 'Amélioré', text = "Écran d'entrée : au début, seulement le logo du serveur (sans fond) et son nom ; plus de cadre transparent ni de texte. Seule la touche E reste, discrète, en bas.", module = 'entrance' },
    { tag = 'Amélioré', text = "Choix du personnage : plus de bandeau au-dessus de la fiche, la fiche monte en haut à gauche.", module = 'entrance' },
} })
N.Add({ id = 'patch89', date = '2026-10-23', title = "Patch notes 89 : écran d'entrée", items = {
    { tag = 'Corrigé', text = "Écran d'entrée : l'indication « E Commencer » restait visible en bas pendant le choix du personnage (son animation empêchait de la cacher).", module = 'entrance' },
} })
N.Add({ id = 'patch90', date = '2026-10-23', title = "Patch notes 90 : écran d'entrée", items = {
    { tag = 'Amélioré', text = "Écran d'entrée : l'indication « E Commencer » est en haut à gauche, sous le logo et le nom du serveur.", module = 'entrance' },
} })
N.Add({ id = 'patch91', date = '2026-10-23', title = "Patch notes 91 : écran d'entrée", items = {
    { tag = 'Corrigé', text = "Écran d'entrée : après E, le logo et le nom du serveur restaient affichés derrière la fiche du personnage (l'animation d'apparition empêchait de les cacher). Ils disparaissent maintenant ; un test le vérifie.", module = 'entrance' },
} })
N.Add({ id = 'patch92', date = '2026-10-24', title = "Patch notes 92 : menus F6 / F7 sans tablette, nouvelle souris", items = {
    { tag = 'Nouveau', text = "Menu F6 de l'entreprise : plus de tablette. En bas du menu, « Gestion de l'entreprise » ouvre toutes ses pages en sous-menus (tableau de bord, citoyens et dossiers, factures, équipe, annonces, statistiques, caisse…). Formulaires (liste ← →, saisie), confirmation avant de renvoyer ou d'exclure. Employés, grades, salaires et caisse restent au bureau du patron.", module = 'quick' },
    { tag = 'Nouveau', text = "Menu F7 des organisations : plus de tablette. Après les actions (ligoter, fouiller, QG, coffre, caisse), « Gestion de l'organisation » : crypto, classement, crews, grades, laboratoires, contrats, territoires (GPS), effectif, messages, caisse, activité. Gestion du chef au point boss ; le coffre s'ouvre au QG.", module = 'orga' },
    { tag = 'Nouveau', text = "Sans entreprise, F6 ouvre l'espace citoyen (finances, virement, factures, entreprises, profil). Le point du siège / QG et /tablette ouvrent le même menu ; plus de tablette en main.", module = 'quick' },
    { tag = 'Nouveau', text = "Souris du serveur dans toutes les interfaces (boutique, menu ALT, inventaire, téléphone…) : flèche aux couleurs du serveur, main seulement sur ce qui se clique, main appuyée pendant le clic.", module = 'hud' },
} })
N.Add({ id = 'patch93', date = '2026-10-24', title = "Patch notes 93 : menu F6 pour toutes les entreprises", items = {
    { tag = 'Nouveau', text = "Menu F6 de toutes les entreprises (restaurants, cafés, bars, magasins, concession, immobilier, médias, transport…), pas seulement police, secours, garage et taxi : partie « Mon établissement » avec Ouvrir / Fermer l'établissement (annoncé à toute la ville, « Ouvert » dans l'annuaire), Annonce publique, Demander du renfort (ta position aux collègues en service) et la liste des collègues en service.", module = 'quick' },
    { tag = 'Nouveau', text = "Métiers de santé (secours, pompiers, clinique, vétérinaire) : « Soigner » une personne blessée depuis le menu F6, inscrit dans les dossiers.", module = 'quick' },
    { tag = 'Corrigé', text = "Espace citoyen (F6 sans entreprise) : les pages réservées aux employés (équipe, annonces, règlement, lieux…) n'apparaissent plus.", module = 'biz' },
    { tag = 'Nouveau', text = "Panel › Menu entreprise (F6) › Réglages : chaque action commune s'active ou se coupe, avec les délais (annonce, renfort).", module = 'quick' },
} })
N.Add({ id = 'patch94', date = '2026-10-24', title = "Patch notes 94 : gestes de chaque métier (F6)", items = {
    { tag = 'Nouveau', text = "Mécano et dépanneur (F6 › Gestes du métier) : diagnostic du véhicule (moteur, carrosserie, réservoir, pneus, carburant), réparer le moteur, la carrosserie, changer les pneus, remettre sur ses roues, ouvrir un véhicule verrouillé (le propriétaire est prévenu), faire le plein, charger / décharger le plateau de la dépanneuse, envoyer à la fourrière. Animation et barre de progression ; chaque geste est ajouté à la facture du client.", module = 'quick' },
    { tag = 'Nouveau', text = "Police : contrôle d'identité (naissance, nationalité, permis d'arme, antécédents) et contrôle de plaque (propriétaire, fourrière, véhicule non enregistré). Secours : bilan du patient. Pompiers : éteindre les feux autour.", module = 'quick' },
    { tag = 'Nouveau', text = "Armurerie : vérifier le permis d'arme avant une vente. Médias (Weazel News, radio, journal) : flash info en grand chez tous les joueurs. Station-service : faire le plein. Station de lavage : laver le véhicule. Transport et travaux : missions de l'entreprise avec GPS.", module = 'quick' },
    { tag = 'Nouveau', text = "Factures pré-remplies selon le secteur : garage (réparation, remorquage, pneus), santé (consultation, soins, ambulance), restauration (menu, boisson), commerce, services, médias, loisirs, travaux…", module = 'quick' },
    { tag = 'Sécurité', text = "Tout est revérifié par le serveur : métier et service, véhicule réellement à côté (plaque lue par le serveur), durée du travail, distance à la fin ; ouverture de véhicule et fourrière inscrites dans les dossiers et le journal.", module = 'quick' },
} })
N.Add({ id = 'patch95', date = '2026-10-24', title = "Patch notes 95 : customisation seulement au garage", items = {
    { tag = 'Modifié', text = "Mécano : plus de « Customisation » dans le menu F6. Peinture, jantes, performances… se font seulement au garage, à l'atelier (point posé au Builder). Les réparations et les gestes du métier restent dans le F6.", module = 'mech' },
    { tag = 'Corrigé', text = "La customisation pouvait s'ouvrir n'importe où (la vérification de l'atelier était ignorée). Il faut maintenant être à moins de 15 m de l'atelier de son garage ; sans atelier posé, elle est indisponible.", module = 'mech' },
} })
N.Add({ id = 'patch96', date = '2026-10-24', title = "Patch notes 96 : cohérence de toute la base", items = {
    { tag = 'Corrigé', text = "Employés : dans le menu F6, partie « Mon espace » avec leurs pages perso (finances et virement, factures à payer, entreprises, profil). Depuis la fin de la tablette, ils n'y avaient plus accès.", module = 'quick' },
    { tag = 'Corrigé', text = "Plus aucun message ne parle de la tablette ou d'anciennes touches : facture du garage (F6 › Envoyer la facture), amende et facture à régler (F6 › Factures ou téléphone), virements (F6 › Finances), points du bureau du patron, de l'accueil et du QG, permis d'arme (F6 de la police).", module = 'general' },
    { tag = 'Modifié', text = "Panel : textes, documentation et aperçus mis à jour (menu F6 au lieu de la tablette, touches F5 / F6 / F7) ; réglages d'images des anciennes tuiles retirés.", module = 'general' },
} })
N.Add({ id = 'patch97', date = '2026-10-24', title = "Patch notes 97 : nouveau créateur et interfaces redessinées", items = {
    { tag = 'Nouveau', text = "Créateur de personnage redessiné dans la DA du serveur : panneau carré avec la barre rouge, étapes en segments, titres en capitales, boutons rouges, barre des touches (Entrée = étape suivante). Carte d'identité qui se remplit en direct à droite (nom, naissance, âge, taille, nationalité, arrivée).", module = 'character' },
    { tag = 'Nouveau', text = "Créateur : les vrais portraits des parents de GTA Online ; mères parmi les femmes, pères parmi les hommes. Date de naissance en jour / mois / année (31 février corrigé tout seul). Barre de caméra Visage / Corps / Pieds et rotation.", module = 'character' },
    { tag = 'Corrigé', text = "Créateur : une barre d'erreur rouge vide s'affichait par-dessus les champs, et la date de naissance était coupée (format américain).", module = 'character' },
    { tag = 'Nouveau', text = "Banque, logement et tickets : nouvelle fenêtre dans la DA (pages à gauche, espèces et banque en bas, cartes, tableaux, formulaires, confirmation avant une action sensible). Plus de style tablette.", module = 'general' },
    { tag = 'Amélioré', text = "Garage, fourrière, supérettes, armurerie et autres magasins : angles carrés, actions rouges, titres en capitales. Écran de mort (« État critique », chrono, barre, touches rouges) et écran de bienvenue (règlement numéroté) redessinés.", module = 'general' },
    { tag = 'Modifié', text = "Argent affiché partout au format « 18 250 $ » ; le HUD garde son style GTA « $640 ».", module = 'general' },
} })
N.Add({ id = 'patch98', date = '2026-10-24', title = "Patch notes 98 : nouvelle boutique", items = {
    { tag = 'Nouveau', text = "Boutique entièrement refaite : en-tête avec le logo, le code boutique (ton ID permanent), ton VIP, tes coins et « Acheter des coins » ; catégories à gauche ; grandes cartes avec la rareté (commun, rare, épique, légendaire) ; fenêtre de confirmation avec l'image, le prix et Annuler.", module = 'premium' },
    { tag = 'Nouveau', text = "Boutique journalière : une sélection qui change chaque jour à minuit, à prix réduit, un achat par joueur ; compte à rebours avant le renouvellement ; « Déjà acheté » une fois prise.", module = 'premium' },
    { tag = 'Nouveau', text = "Coffres : contenu et chances affichés, ouverture avec une bande qui défile puis s'arrête sur le gain. Le tirage se fait sur le serveur, seulement parmi ce que tu peux encore recevoir ; le gain est livré et récupérable dans « Mes achats ».", module = 'premium' },
    { tag = 'Nouveau', text = "Boosts : paie +25 % / +50 %, missions +50 %, pendant 24 h à 3 jours ; le bonus est versé en plus à chaque paie ou mission, et les boosts actifs s'affichent dans la boutique.", module = 'premium' },
    { tag = 'Nouveau', text = "Panel › Boutique : rareté, offres du jour (nombre, réduction, nouveau tirage), contenu des coffres, boosts, couleur de la boutique.", module = 'premium' },
} })
N.Add({ id = 'patch99', date = '2026-10-24', title = "Patch notes 99 : avantages VIP", items = {
    { tag = 'Nouveau', text = "VIP : pêche automatique. Lance ta canne comme d'habitude : chaque touche est ferrée toute seule et la ligne est relancée avec le même appât, prise après prise. X pour arrêter (ou bouger, plus d'appât, sac plein).", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : paie VIP de 2 500 $ toutes les 15 minutes de présence, en plus de la paie normale. Le temps compte par compte (une reconnexion ne remet pas le compteur à zéro) et ne s'écoule pas pour un joueur immobile (AFK).", module = 'vip' },
    { tag = 'Nouveau', text = "Panel › VIP › Avantages : montant et fréquence de la paie VIP, banque ou espèces, AFK payé ou non, pêche automatique, bonus de revente.", module = 'vip' },
} })
N.Add({ id = 'patch100', date = '2026-10-24', title = "Patch notes 100 : carte rapide (touche M)", items = {
    { tag = 'Nouveau', text = "Touche M : la mini-carte s'agrandit en bas à gauche, sans couper le jeu (tu continues de marcher ou de conduire). À côté, un panneau « Destinations » : tes véhicules (position en direct), ton logement, ton entreprise, le QG de ton organisation, tes lieux enregistrés, puis les services les plus proches (distributeur, banque, supérette, station-service, garage, fourrière, armurerie, vêtements, coiffeur, police, hôpital…), avec la distance.", module = 'hud' },
    { tag = 'Nouveau', text = "Carte rapide : ↑ ↓ pour choisir, Entrée pour mettre le GPS, Suppr pour l'effacer, ← → pour zoomer, M pour fermer. Échap ouvre la carte plein écran du jeu.", module = 'hud' },
    { tag = 'Amélioré', text = "Le HUD se place au-dessus de la mini-carte agrandie pendant que la carte rapide est ouverte.", module = 'hud' },
    { tag = 'Nouveau', text = "Panel › HUD › Carte rapide (M) : activer, touche par défaut, services proposés.", module = 'hud' },
} })
N.Add({ id = 'patch101', date = '2026-10-24', title = "Patch notes 101 : avantages VIP, F5 véhicules, Galaxy Club", items = {
    { tag = 'Nouveau', text = "VIP : mode drift. /drift l'active ou le coupe ; au volant, Maj gauche maintenue fait décrocher l'arrière.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : ventes entre joueurs sans taxe (contrats du téléphone : les 5 % de taxe de mutation ne sont plus retenus).", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : comptoir de location à Cayo Perico, en plus de la location normale. Véhicules importés (Squaddie, Slamtruck, Winky) avec un grand coffre (150 à 300 kg).", module = 'rental' },
    { tag = 'Nouveau', text = "VIP : récoltes ×3 (activités, fermes des entreprises) et drogues ×3 au champ.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : +20 kg dans le sac.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : Tec-9 et fusil à pompe dans le sac pendant toute la durée de l'abonnement (liés : ni donnés, ni jetés), repris à la fin.", module = 'vip' },
    { tag = 'Nouveau', text = "VIP : factures et amendes de la LSPD et des EMS réduites de 40 % (frais d'hôpital compris).", module = 'vip' },
    { tag = 'Nouveau', text = "Réapparition à l'hôpital : les armes et les objets sont perdus (réglable : aucun, armes seulement, tout ; téléphone, papiers, clés et vêtements gardés). Les VIP gardent tout.", module = 'death' },
    { tag = 'Nouveau', text = "VIP : reports prioritaires. Le ticket passe en tête de liste du staff avec la mention ★ VIP.", module = 'staff' },
    { tag = 'Nouveau', text = "Discord : second rôle des VIP (Gold), donné et retiré avec le rôle VIP. Les salons vocaux VIP et le salon textuel VIP (enchères) suivent ces rôles.", module = 'discordlink' },
    { tag = 'Nouveau', text = "F5 › Mes véhicules : pour chaque véhicule, son emplacement, le poids du coffre et son contenu, en lecture seule (rien ne peut être pris à distance).", module = 'personal' },
    { tag = 'Nouveau', text = "Galaxy Club : nouvelle boîte de nuit (Serveur, Barman, Agent de sécurité, DJ, Chef de la sécurité, Responsable, Patron), avec les factures du club (entrée, carré VIP, bouteille…).", module = 'biz' },
    { tag = 'Nouveau', text = "Agent de sécurité (F6) : palpation (arme repérée, rien n'est pris), contrôle à l'entrée (âge, bracelet, interdit), bracelets de la soirée, interdire ou réautoriser l'entrée, expulser (GPS vers la sortie), demander du renfort.", module = 'biz' },
    { tag = 'Nouveau', text = "Panel › VIP › Avantages : chaque avantage se règle ou se coupe (multiplicateurs, kilos, armes, réduction, entreprises concernées…).", module = 'vip' },
} })
N.Add({ id = 'patch102', date = '2026-10-24', title = "Patch notes 102 : icône Burger Shot sur la carte", items = {
    { tag = 'Corrigé', text = "Burger Shot : l'icône burger apparaît de nouveau sur la carte, en orange, pour tout le monde. L'ancienne icône (98) n'a pas d'image en jeu.", module = 'biz' },
    { tag = 'Corrigé', text = "Si le siège du Burger Shot n'avait pas de point sur la carte, il est posé au restaurant de Vespucci. Un siège masqué volontairement n'est pas touché.", module = 'biz' },
} })
N.Add({ id = 'patch103', date = '2026-10-24', title = "Patch notes 103 : coffre des véhicules en lecture seule (F5)", items = {
    { tag = 'Amélioré', text = "F5 › Mes véhicules : un clic sur un véhicule ouvre l'inventaire, ton sac à gauche et le coffre du véhicule à droite, où qu'il soit. L'épingle met le GPS.", module = 'personal' },
    { tag = 'Nouveau', text = "Inventaire en lecture seule : bandeau « Lecture seule », impossible de prendre, déposer, déplacer, utiliser, donner, jeter ou trier tant que cette vue est ouverte (vérifié aussi par le serveur).", module = 'inv' },
} })
N.Add({ id = 'patch104', date = '2026-10-25', title = "Patch notes 104 : menus « Shadow Studio V2 » (lib et menu ALT)", items = {
    { tag = 'Nouveau', text = "Nouveau style de menu « Shadow Studio V2 » (panel › Menus › Style du menu) : bloc noir en haut à gauche, logo rond, titre et onglets, barre de section avec compteur (3 / 11), lignes à icônes (la ligne choisie est blanche), interrupteurs, curseurs, valeurs avec points, description à part avec les valeurs en gras, touches en bas (Parcourir, Valider, Retour).", module = 'menus' },
    { tag = 'Nouveau', text = "Nouvelle version « Shadow Studio V2 » du menu ALT (panel › Menu ALT › Version du menu) : en-tête « Nom · ID », toutes les actions à la suite avec un espace entre les catégories, icônes fines, action dangereuse en rouge, un peu transparent. Flèches, Entrée et Retour arrière au clavier.", module = 'ctx' },
    { tag = 'Nouveau', text = "Développeurs : un menu peut afficher des onglets dans le style Shadow Studio V2 avec tabs = { { icon = 'users', label = 'Personnel' }, … } et tab = n° actif.", module = 'menus' },
} })
N.Add({ id = 'patch105', date = '2026-10-25', title = "Patch notes 105 : tous les menus lib en style Shadow Studio V2", items = {
    { tag = 'Amélioré', text = "Tous les menus lib (menu admin, F5, F6, F7, garage, atelier, stations…) passent au style Shadow Studio V2. On peut revenir à l'ancien dans Menus › Apparence › Style du menu.", module = 'menus' },
    { tag = 'Amélioré', text = "Le style Shadow Studio V2 a exactement la taille et la place de l'ancienne lib (336 × 584 px sur un écran 1080p, à gauche), avec le même pas entre les lignes : pas plus large, pas plus grand.", module = 'menus' },
    { tag = 'Amélioré', text = "Menu principal : la barre sous le titre affiche le sous-titre (grade, service…) ; dans un sous-menu, son titre.", module = 'menus' },
} })
N.Add({ id = 'patch106', date = '2026-10-25', title = "Patch notes 106 : logo du serveur dans les menus", items = {
    { tag = 'Corrigé', text = "Menus Shadow Studio V2 : le logo en haut est celui du serveur (panel › Identité). Il s'affiche dès que l'image arrive, même si le menu est déjà ouvert, et suit tout changement de logo sans redémarrer.", module = 'menus' },
    { tag = 'Amélioré', text = "Sans logo en jeu envoyé depuis le PC, les interfaces prennent le logo du panel (adresse https).", module = 'general' },
} })
N.Add({ id = 'patch107', date = '2026-10-25', title = "Patch notes 107 : en-tête des menus refait", items = {
    { tag = 'Amélioré', text = "Menus Shadow Studio V2 : en-tête plus rempli, avec le logo du serveur en plus grand et un halo de la couleur du serveur, le nom du serveur au-dessus du titre, les pastilles (Discord, site) en dessous, un fond texturé et un filet de couleur en bas. La taille du menu ne change pas.", module = 'menus' },
} })
N.Add({ id = 'patch108', date = '2026-10-25', title = "Patch notes 108 : nouveau logo de base, Discord dans les menus", items = {
    { tag = 'Nouveau', text = "Nouveau logo de Shadow Base (détouré, sans fond) : il s'affiche partout tant que le serveur n'a pas mis le sien (menus, bienvenue, création de personnage, boutique, panel…).", module = 'general' },
    { tag = 'Amélioré', text = "En-tête des menus : le lien du site est retiré, il ne reste que le Discord, réglable dans Menus › Apparence › « Discord affiché en haut des menus » (vide = pas de pastille).", module = 'menus' },
} })
N.Add({ id = 'patch109', date = '2026-10-25', title = "Patch notes 109 : style Shadow Studio V2 pour les interfaces en jeu", items = {
    { tag = 'Nouveau', text = "Panel › Interface › « Style des interfaces en jeu » : Shadow (DA du serveur, comme avant) ou Shadow Studio V2 (noir et blanc, verre, angles arrondis). Le changement s'applique en direct, sans redémarrer.", module = 'general' },
    { tag = 'Nouveau', text = "En Shadow Studio V2, supérette, armurerie, garage, fourrière, concession, magasin de vêtements, masques et sacs, créateur de personnage et écran d'entrée passent en noir et blanc : l'élément choisi est blanc.", module = 'shops' },
} })
N.Add({ id = 'patch110', date = '2026-10-25', title = "Patch notes 110 : inventaire Shadow Studio V2", items = {
    { tag = 'Nouveau', text = "Inventaire en style Shadow Studio V2 : logo du serveur en haut, catégories en pastilles au-dessus du sac (Tout, Armes, Nourriture…) qui filtrent les objets, panneaux en verre autour du personnage au centre.", module = 'inv' },
    { tag = 'Nouveau', text = "Jauge de poids par catégorie : la barre se découpe selon ce que tu portes, avec la légende (kg par catégorie) et les kilos libres. Elle passe en orange à 75 % (« Lourd ») et en rouge à 90 % (« Presque plein »).", module = 'inv' },
    { tag = 'Amélioré', text = "Shadow Studio V2 : la case sélectionnée est blanche, les slots d'équipement et la barre rapide sont arrondis, le texte Premium passe sous la barre rapide pour ne plus cacher la mini-carte.", module = 'inv' },
} })
N.Add({ id = 'patch111', date = '2026-10-25', title = "Patch notes 111 : intro animée à l'entrée", items = {
    { tag = 'Nouveau', text = "Écran d'entrée › « Style de l'accueil » : boîte de nuit (comme avant) ou intro animée : logo qui apparaît, nom du serveur, slogan, barre de chargement et « Appuie sur Entrée pour continuer ».", module = 'entrance' },
    { tag = 'Nouveau', text = "L'intro affiche les joueurs en ligne (sur le maximum du serveur) et le Discord des menus. Nouveau champ « Slogan » sous le titre (vide = pas de slogan).", module = 'entrance' },
} })
N.Add({ id = 'patch112', date = '2026-10-25', title = "Patch notes 112 : interfaces Shadow Studio V2 recadrées", items = {
    { tag = 'Amélioré', text = "Style Shadow Studio V2 : toutes les interfaces suivent les mêmes marges (60 px sur les côtés, 56 px en haut et en bas), avec en haut à gauche le logo du serveur, un filet, le titre et le sous-titre, et un fond assombri sur les bords.", module = 'general' },
    { tag = 'Amélioré', text = "Supérette, armurerie, épicerie (Shadow Studio V2) : catégories en liste à gauche, articles en grandes cartes au centre, panier sur toute la hauteur à droite avec le total et le bouton de paiement en bas.", module = 'shops' },
    { tag = 'Amélioré', text = "Garage et fourrière (Shadow Studio V2) : véhicules en bande en bas de l'écran, fiche du véhicule choisi à droite (plaque, état, détails) avec Sortir, Localiser… en grands boutons.", module = 'garage' },
    { tag = 'Amélioré', text = "Magasin de vêtements, masques et sacs (Shadow Studio V2) : rail d'icônes à gauche, une ligne par modèle à droite (la ligne choisie montre ses variantes), barre de paiement en bas, caméra juste au-dessus.", module = 'shops' },
    { tag = 'Amélioré', text = "Créateur de personnage et sélection de personnage (Shadow Studio V2) : panneaux, carte d'identité, emplacements et touches alignés sur les marges. Intro animée plus sombre, titre plus grand.", module = 'entrance' },
    { tag = 'Corrigé', text = "Créateur : la carte d'identité n'affiche plus « null » sous la nationalité tant qu'aucun point d'arrivée n'est choisi.", module = 'character' },
} })
N.Add({ id = 'patch113', date = '2026-10-25', title = "Patch notes 113 : lib Shadow Studio V2 à la bonne taille", items = {
    { tag = 'Corrigé', text = "Menus lib en style Shadow Studio V2 trop petits : le texte tombait à 11 px. Ils reprennent la taille de la maquette : 380 px de large, lignes de 34 px, texte de 14 px, titre de 18 px (sur un écran 1080p).", module = 'menus' },
    { tag = 'Corrigé', text = "Menus lib Shadow Studio V2 mal placés (au milieu à gauche, sur la mini-carte) : ils s'ouvrent en haut à gauche, à 24 px des bords, et la boîte s'arrête après la dernière ligne au lieu de garder un grand vide.", module = 'menus' },
    { tag = 'Amélioré', text = "Les menus suivent la taille de l'écran : 1,33 fois plus grands en 1440p, 2 fois en 4K, pour rester lisibles partout.", module = 'menus' },
} })
N.Add({ id = 'patch114', date = '2026-10-25', title = "Patch notes 114 : HUD et menu ALT corrigés", items = {
    { tag = 'Corrigé', text = "HUD : en style Shadow Studio V2, une grande barre noire recouvrait le bas de l'écran et cachait l'argent, la voix, la faim et la soif. Le HUD reprend sa place collée à la mini-carte.", module = 'hud' },
    { tag = 'Corrigé', text = "Menu ALT en version Shadow Studio V2 beaucoup trop grand (texte de 28 px, 500 px de large). Il fait maintenant 300 px de large avec un texte de 17 px en 1080p, et grandit avec l'écran.", module = 'ctx' },
    { tag = 'Amélioré', text = "Menu ALT Shadow Studio V2 : fond plus couvrant, lisible sur un décor clair.", module = 'ctx' },
    { tag = 'Corrigé', text = "Magasin de vêtements (Shadow Studio V2) : les touches d'aide ne cachent plus l'argent en haut, elles passent au-dessus des boutons de caméra.", module = 'shops' },
} })
N.Add({ id = 'patch115', date = '2026-10-25', title = "Patch notes 115 : plus de rectangles noirs", items = {
    { tag = 'Corrigé', text = "Rectangles noirs autour des interfaces en jeu (boutiques, garage, entrée, créateur, menus…) : le flou d'arrière-plan et les mélanges de couleurs, mal gérés par FiveM, sont coupés. Les fonds restent semi-transparents.", module = 'general' },
} })
N.Add({ id = 'patch116', date = '2026-10-25', title = "Patch notes 116 : le style Nova devient Shadow Studio V2", items = {
    { tag = 'Modifié', text = "Le style « Nova » s'appelle maintenant « Shadow Studio V2 » partout dans le panel (Interface, Menus, Menu ALT). L'ancien style s'appelle « Shadow Studio V1 ». Tes réglages ne changent pas.", module = 'general' },
    { tag = 'Corrigé', text = "Patch notes : les textes longs ne sont plus coupés au milieu d'une lettre accentuée.", module = 'general' },
} })
N.Add({ id = 'patch117', date = '2026-10-26', title = "Patch notes 117 : son des menus coupable, un seul style de lib", items = {
    { tag = 'Nouveau', text = "F5 › Mes paramètres › « Sons des menus » : chaque joueur peut couper le petit clic des menus de la lib et des interfaces. Le choix est mémorisé sur son poste. Le réglage du serveur (Menus › Comportement) reste prioritaire.", module = 'menus' },
    { tag = 'Modifié', text = "Les menus de la lib (F5, F6, F7, menu admin, garage, atelier, stations…) n'ont plus qu'un style : Shadow Studio V2. Les anciens styles (V1, épuré, classique) sont retirés et les serveurs qui les utilisaient passent en V2.", module = 'menus' },
} })
N.Add({ id = 'patch118', date = '2026-10-26', title = "Patch notes 118 : Shadow Studio V2 partout, nouveau bouton d'interaction", items = {
    { tag = 'Modifié', text = "Shadow Studio V2 devient le seul style : interfaces en jeu (boutiques, garage, vêtements, créateur, entrée…), inventaire, menus de la lib et menu ALT. Les anciens styles sont retirés du panel et les serveurs qui les utilisaient passent en V2.", module = 'general' },
    { tag = 'Amélioré', text = "Bouton d'interaction refait en V2 : pastille noire à coins doux, touche blanche à lettre noire, petite pointe vers le point ; la petite touche « E » au-dessus des points passe aussi en blanc et noir.", module = 'hud' },
    { tag = 'Retiré', text = "Menu d'interaction de la touche F2 supprimé (et son onglet dans le panel). Les actions passent par le menu ALT et le F5.", module = 'general' },
} })
N.Add({ id = 'patch119', date = '2026-10-26', title = "Patch notes 119 : logo et bannière du serveur partout", items = {
    { tag = 'Corrigé', text = "Logo du serveur envoyé depuis le PC : il ne s'affichait pas à l'écran d'entrée, dans le créateur, les boutiques, le garage et les vêtements quand l'image arrivait après l'ouverture (logo Shadow Base à la place). Il est demandé dès la connexion et se met à jour tout seul.", module = 'general' },
    { tag = 'Corrigé', text = "HUD : le logo du serveur en haut à droite apparaissait cassé quand il était envoyé depuis le PC. Le nom du serveur s'affiche le temps que l'image arrive.", module = 'hud' },
    { tag = 'Nouveau', text = "Menus de la lib : la bannière s'affiche en haut, au-dessus du logo et du titre. Ordre : Menus › Image de bannière, sinon Identité › Bannière du serveur, sinon la bannière du server.cfg (banner_detail).", module = 'menus' },
    { tag = 'Amélioré', text = "Sans nom réglé dans le panel, le nom du serveur est repris du server.cfg (sv_projectName, sinon sv_hostname).", module = 'general' },
} })
N.Add({ id = 'patch120', date = '2026-10-26', title = "Patch notes 120 : créateur V2, inventaire léger, menu ALT plus petit", items = {
    { tag = 'Modifié', text = "Menus de la lib : pas de bannière au-dessus du menu (retour en arrière), seulement le logo et le titre.", module = 'menus' },
    { tag = 'Amélioré', text = "Créateur de personnage en Shadow Studio V2 : en-tête en haut à gauche, étapes en pastilles en haut au centre, formulaire à gauche, carte d'identité à droite, caméra en bas au centre, Précédent / Suivant en bas à droite. L'étape Départ affiche la grande carte à droite.", module = 'character' },
    { tag = 'Nouveau', text = "Créateur : réglages au clavier. Flèches haut / bas pour choisir un réglage (taille, curseurs, listes, ‹ ›), gauche / droite pour le changer. La souris choisit aussi le réglage survolé.", module = 'character' },
    { tag = 'Amélioré', text = "Inventaire beaucoup plus léger, presque transparent : on voit le jeu derrière, sans voile sombre.", module = 'inv' },
    { tag = 'Amélioré', text = "Menu ALT encore réduit : texte de 13 px en 1080p, un peu plus large pour les libellés.", module = 'ctx' },
} })
N.Add({ id = 'patch121', date = '2026-10-26', title = "Patch notes 121 : menus d'entreprise par métier, menu ALT rangé", items = {
    { tag = 'Corrigé', text = "Menu de l'entreprise (F6) : le patron de n'importe quelle entreprise voyait les gestes de sécurité de club (palpation, contrôle à l'entrée, bracelet, interdiction, expulsion, liste de la soirée). Ils sont maintenant réservés aux boîtes de nuit, à la sécurité privée et aux grades qui ont le droit « Sécurité ».", module = 'quick' },
    { tag = 'Corrigé', text = "Menu F6 d'une boîte de nuit : un seul « Demander du renfort » au lieu de deux.", module = 'quick' },
    { tag = 'Amélioré', text = "Menu ALT rangé par catégories : Métier, Mon personnage, Interactions, Gestes à deux, Animations, Gestes, Poses, Danses, Sport, Staff, avec le nombre d'actions. On ouvre une catégorie pour voir ses actions ; Retour (ou flèche gauche / Retour arrière) revient aux catégories. Peu d'actions : tout s'affiche directement, avec un titre par catégorie.", module = 'ctx' },
    { tag = 'Amélioré', text = "Menu ALT › Métier : la prise de service est en premier.", module = 'ctx' },
} })
N.Add({ id = 'patch122', date = '2026-10-26', title = "Patch notes 122 : photos des vêtements, serveur plus fluide", items = {
    { tag = 'Nouveau', text = "Photos de près de 5 000 vêtements du jeu (homme et femme) : masques, sacs, hauts, sous-hauts, pantalons, chaussures, gilets, accessoires, écussons, chapeaux, lunettes, oreilles, montres et bracelets. Elles s'affichent dans les magasins de vêtements, le magasin de masques et sacs, et dans l'inventaire pour les objets vêtements.", module = 'shops' },
    { tag = 'Amélioré', text = "Photos regroupées en 30 paquets (18 Mo au total) au lieu de 5 000 fichiers : téléchargement plus rapide à la connexion. Vignettes de 64 px dans la liste des vêtements.", module = 'shops' },
    { tag = 'Amélioré', text = "Les tâches automatiques du serveur (paies, loyers, véhicules sortis, événements, anti-triche, sauvegardes…) ne partent plus toutes à la même seconde : fini les pics de lag toutes les minutes.", module = 'monitor' },
    { tag = 'Amélioré', text = "Sauvegarde régulière des joueurs étalée (un joueur toutes les 60 ms) au lieu de tout le serveur d'un coup.", module = 'monitor' },
    { tag = 'Amélioré', text = "Base de données : nouveaux index pour les véhicules sortis, les doubles de clé, les loyers, les événements et les bannissements.", module = 'monitor' },
} })
N.Add({ id = 'patch123', date = '2026-10-26', title = "Patch notes 123 : garage d'entreprise, essence, tir à la tête, magasins de vêtements, plus de thème rouge", items = {
    { tag = 'Corrigé', text = "Garage d'entreprise : seuls les véhicules de l'entreprise s'y affichent, s'y sortent et s'y rangent. Les véhicules personnels restent dans les garages publics.", module = 'garage' },
    { tag = 'Corrigé', text = "Essence : on peut faire le plein à toutes les pompes du jeu (27 stations au lieu de 6), au volant ou à pied à côté de la pompe avec le véhicule garé à côté. Le moteur se coupe tout seul pendant le plein.", module = 'fuel' },
    { tag = 'Corrigé', text = "Combat : les joueurs peuvent se blesser et se tuer (tir entre joueurs autorisé explicitement). Le staff en service n'est plus invincible d'office (réglage « Invincible dès la prise de service » dans le menu staff, désactivé par défaut).", module = 'death' },
    { tag = 'Nouveau', text = "Une balle dans la tête met à terre immédiatement (armes à feu seulement). Réglable dans Écran de mort › « Balle dans la tête mortelle ».", module = 'death' },
    { tag = 'Corrigé', text = "Magasin de vêtements qui s'ouvrait en « Masques et sacs » : après un passage au magasin de masques, les autres magasins de vêtements gardaient seulement ces deux rayons. Chaque magasin affiche maintenant ses propres rayons.", module = 'shops' },
    { tag = 'Corrigé', text = "Créateur de personnage, choix du personnage et du point d'apparition : ils s'ouvrent parfois avant que la configuration arrive et prenaient l'ancien thème rouge. Shadow Studio V2 est maintenant actif dès le chargement.", module = 'character' },
    { tag = 'Corrigé', text = "Écran de mort, écran d'accueil (règlement) et carte rapide : plus aucun rouge de l'ancien thème, tout est en noir et blanc Shadow Studio V2.", module = 'death' },
} })
N.Add({ id = 'patch124', date = '2026-10-26', title = "Patch notes 124 : tenues dans l'inventaire, inventaire transparent, noms masquables", items = {
    { tag = 'Nouveau', text = "Magasin de vêtements : chaque pièce achetée (haut, pantalon, chaussures, chapeau, lunettes, masque, montre…) arrive dans l'inventaire, déjà portée, avec sa photo du magasin (homme ou femme). Utiliser l'objet l'enlève ou le remet ; il se donne et se range comme les autres objets.", module = 'shops' },
    { tag = 'Amélioré', text = "Inventaire quasi transparent : panneaux réduits à un contour, plus de voile ni de flou sur l'écran ; seules les cases et les objets ressortent (texte ombré pour rester lisible).", module = 'inv' },
    { tag = 'Nouveau', text = "Menu staff › « Noms au-dessus des têtes » : chaque membre du staff peut masquer les noms et ID affichés au-dessus des joueurs (réglage mémorisé sur son poste).", module = 'tags' },
} })
N.Add({ id = 'patch125', date = '2026-10-27', title = "Patch notes 125 : ceinture, plein à pied, réglages au clavier", items = {
    { tag = 'Corrigé', text = "Ceinture : un appui ne la bascule plus deux fois de suite (« bouclée » aussitôt suivi de « détachée »).", module = 'trunk' },
    { tag = 'Modifié', text = "Essence : on descend du véhicule pour faire le plein. À la pompe, E ouvre le choix des litres, puis le personnage remplit le réservoir (animation, durée selon les litres). Au volant près d'une pompe : « Descends du véhicule pour faire le plein ».", module = 'fuel' },
    { tag = 'Corrigé', text = "Menu F5 en grandes cartes › Mes paramètres : la taille du HUD se règle aux flèches ← → et avec des boutons ‹ › (le curseur ne répondait qu'à la souris). La valeur affichée est la bonne à la réouverture.", module = 'personal' },
    { tag = 'Amélioré', text = "Menus de la lib : les flèches gauche / droite de la manette et du clavier (deux codes de touche du jeu) changent les listes et les curseurs.", module = 'menus' },
    { tag = 'Corrigé', text = "Menu F5 en grandes cartes : plus de rouge, accents blancs Shadow Studio V2.", module = 'personal' },
} })
N.Add({ id = 'patch126', date = '2026-10-27', title = "Patch notes 126 : garde-robe, gilets pare-balles, clés prêtées, flotte, ceinture", items = {
    { tag = 'Nouveau', text = "Garde-robe : « Enregistrer ma tenue » (bouton Tenue de l'inventaire ou menu ALT sur soi) range la tenue portée dans un sac de vêtements, avec la photo du haut. Utiliser le sac remet toute la tenue, n'importe où (visage et cheveux ne changent pas). Dans un logement, menu ALT › « Mes tenues » : enfiler ou supprimer. 10 tenues par joueur.", module = 'inv' },
    { tag = 'Nouveau', text = "Gilets pare-balles en vêtement : « Gilet pare-balles léger » (blindage 50) et « lourd » (100), avec leur photo. Ils s'équipent dans la case Gilet ; le blindage restant est gardé quand on l'enlève ; à 0 le gilet est détruit. Tant qu'il tient, une balle dans la tête ne tue pas d'un coup. À ajouter au catalogue d'un magasin (objets gilet_leger et gilet_lourd).", module = 'inv' },
    { tag = 'Nouveau', text = "Menu ALT sur un joueur › « Prêter la clé de mon véhicule » : ton véhicule personnel le plus proche (30 m), pour 1 heure, sans passer par le garage.", module = 'garage' },
    { tag = 'Nouveau', text = "Flotte : le patron (menu F6) et le chef d'organisation (menu F7) voient leurs véhicules de service : sortis ou non, qui les a sortis, GPS pour les retrouver, et « Rappeler au garage » pour ceux qui sont abandonnés (personne à bord).", module = 'garage' },
    { tag = 'Nouveau', text = "HUD : pastille « Ceinture » qui clignote au-dessus du compteur quand on roule à plus de 10 km/h sans ceinture (voitures seulement).", module = 'hud' },
    { tag = 'Corrigé', text = "Stations-service : plus de station en double au même endroit (pack de base + liste des 27 stations) ; les doublons existants sont retirés au démarrage.", module = 'fuel' },
    { tag = 'Corrigé', text = "Photos des vêtements : 352 images vides (texture manquante, damier rose) retirées ; ces pièces gardent leur numéro.", module = 'shops' },
} })
N.Add({ id = 'patch127', date = '2026-10-27', title = "Patch notes 127 : braquages par niveau, invites stables, graffitis visibles", items = {
    { tag = 'Nouveau', text = "Braquages par niveau : supérette, bijouterie, banque Fleeca, grande banque (Maze Bank, Pacific…). Chaque niveau impose un temps d'attente pour laisser la police arriver : 2 min, 3 min, 5 min et 8 min par défaut (Activités illégales › Réglages). Un minuteur s'affiche en haut de l'écran ; la police reçoit l'alerte avec la durée.", module = 'crime' },
    { tag = 'Nouveau', text = "Pendant le braquage, le braqueur est libre de ses mouvements (il peut se défendre) mais doit tenir la zone (12 à 30 m selon le niveau). Sortir de la zone lance un compte à rebours de 15 s pour revenir ; mort, menotté ou trop longtemps dehors = braquage raté.", module = 'crime' },
    { tag = 'Nouveau', text = "Builder : quatre points de braquage (supérette, bijouterie, Fleeca, Maze Bank) avec des gains, des délais et un nombre de policiers adaptés. Les braquages déjà posés prennent leur niveau d'après leur nom (« Fleeca », « Maze »…) ou la nouvelle colonne Niveau.", module = 'crime' },
    { tag = 'Amélioré', text = "Bijouterie et banques : touche E au point du braquage (plus besoin de viser un vendeur qui n'existe pas). Supérette : viser le vendeur affiche maintenant la progression.", module = 'crime' },
    { tag = 'Corrigé', text = "L'invite du braquage ne s'affichait qu'un instant : celle du magasin au même comptoir l'effaçait. Elle a maintenant sa propre ligne, et le vendeur reste reconnu tant qu'il est au comptoir.", module = 'crime' },
    { tag = 'Corrigé', text = "Le braqueur restait bloqué en train de viser pendant tout le braquage ; et une prise de territoire lançait en plus l'animation d'attente des activités illégales.", module = 'crime' },
    { tag = 'Corrigé', text = "Graffitis posés mais invisibles : la page qui dessine le tag recevait parfois le tag avant d'être chargée. Le texte est maintenant inscrit dans la page elle-même et l'envoi est répété. Les tags ne sont plus affichés retournés.", module = 'graffiti' },
} })
N.Add({ id = 'patch128', date = '2026-10-27', title = "Patch notes 128 : chasse avec le guide, couleur du serveur partout, points de pêche", items = {
    { tag = 'Nouveau', text = "Chasse : le guide de chasse (PNJ) prête un fusil, des cartouches et un couteau (« Demander à chasser »). Le fusil ne blesse que le gibier, jamais un joueur ni un véhicule, et ses cartouches ne s'épuisent pas. Au marché du chasseur, le marchand reprend tout seul le matériel prêté avant d'acheter le gibier (sans le fusil, pas de vente).", module = 'chasse' },
    { tag = 'Amélioré', text = "Chasse : beaucoup plus de gibier (un animal toutes les 20 s, jusqu'à 6 autour de chaque chasseur), mais des prix bas (35 % des prix de base) pour que les entreprises restent la vraie source de revenus. Réglable dans Extensions › Chasse.", module = 'chasse' },
    { tag = 'Corrigé', text = "La couleur principale du serveur (panel › Général) s'applique de nouveau à toutes les interfaces : inventaire, magasins, garde-robe, créateur, menus, entrée… Le texte posé dessus passe en noir ou en blanc selon la couleur ; une couleur trop sombre est éclaircie pour rester lisible.", module = 'general' },
    { tag = 'Corrigé', text = "Points de pêche : « Supprimer le point de pêche le plus proche » (Builder › Pêche) retire aussi les anciennes zones de pêche et poissonneries posées avec les Activités, dont l'icône restait sur la carte. Rayon de suppression porté à 25 m.", module = 'peche' },
} })
N.Add({ id = 'patch129', date = '2026-10-27', title = "Patch notes 129 : toute l'économie suit le panel, toutes les interfaces en V2", items = {
    { tag = 'Nouveau', text = "Onglet Économie : le multiplicateur des prix et la TVA s'appliquent maintenant à tout ce que les joueurs paient : magasins, véhicules, vêtements, coiffeur, carburant, location, logements du serveur, mécanicien, plaques, petites annonces, matériel de pêche et de chasse, animalerie, marché noir, receleur. Les menus du jeu affichent le prix réellement payé.", module = 'eco' },
    { tag = 'Nouveau', text = "Onglet Économie : le multiplicateur des salaires s'applique à tous les gains (missions, petits jobs, braquages, drogue, cambriolages, distributeurs, GoFast, fourgons, territoires, guerres, pêche, chasse, récolte, événements). Deux nouveaux réglages : « Revenus illégaux (×) » et « Activités et loisirs (×) », inclus dans les presets.", module = 'eco' },
    { tag = 'Amélioré', text = "Toutes les interfaces passent dans la DA Shadow Studio V2 (verre noir, Montserrat, angles arrondis, couleur du serveur) : banque, logement, tickets du support, accueil et règlement, écran de mort, menu pause, graffitis, tablette, carte rapide, badge professionnel, boutique du serveur, casino, guerre de territoire, compteur du taxi, barre du staff, écran partagé, astuces, chat et barres de progression.", module = 'general' },
    { tag = 'Info', text = "Avec la TVA par défaut (8 %), la location, le carburant, les logements du serveur et le mécanicien coûtent 8 % de plus qu'avant : c'est la même règle que les magasins. Les logements mis en vente par un agent immobilier gardent le prix choisi par l'agent.", module = 'eco' },
} })
N.Add({ id = 'patch130', date = '2026-10-27', title = "Patch notes 130 : nouveau téléphone, AirDrop, nouvel atelier, boutique", items = {
    { tag = 'Nouveau', text = "Téléphone entièrement refait façon iPhone : coque titane, Dynamic Island, barre d'état, widgets Météo (quartier, météo et température du jeu) et Calendrier (date du jeu), nouvelles icônes, dock, bouton Rechercher (applications et contacts), applications en mode sombre avec grands titres, bulles de messages, calculatrice ronde.", module = 'phone' },
    { tag = 'Nouveau', text = "Fonds d'écran : Réglages › Fond d'écran ouvre une galerie (cuivre, argent, nuit, graphite et cinq néons) ; le « + » reprend la bannière du serveur. Les anciens fonds sont convertis automatiquement.", module = 'phone' },
    { tag = 'Nouveau', text = "AirDrop : Contacts › ta fiche (ou un contact) › choisis une personne à côté de toi (6 m) ; elle accepte ou refuse et le contact s'ajoute chez elle. Réception activable dans Réglages › AirDrop.", module = 'phone' },
    { tag = 'Nouveau', text = "Atelier du mécano refait : la voiture au centre avec une caméra qui suit l'onglet, les pièces à gauche (Performances, Extérieur, Intérieur, Peinture, Roues, Extras), les performances avant / après et le panier à droite. ↑ ↓ pièce, ← → réglage (appliqué tout de suite : le client voit le changement), Q / E onglet, Entrée valide le devis, Échap annule. « Ouvrir les portes » pour montrer l'intérieur. Clic maintenu et glisser autour de la voiture pour tourner la caméra, molette pour zoomer. Même logique qu'avant : le serveur recalcule les prix, puis F6 › Envoyer la facture.", module = 'mech' },
    { tag = 'Amélioré', text = "Boutique du serveur (coins) dans la même DA que l'atelier : panneaux noirs, onglets à liseré blanc, bouton principal blanc, réductions en vert.", module = 'premium' },
} })
