-- Choisir une personne à côté de soi dans un menu (facture, menottes, fouille, service…) : la personne survolée est entourée
-- et marquée d'une flèche au-dessus de la tête, pour être sûr de viser la bonne. Aussi : la facture reçue, à payer tout de suite.
local G = PBG
local hl = nil   -- identifiant serveur de la personne en surbrillance

local function pedOf(sid)
    local pl = GetPlayerFromServerId(tonumber(sid) or -1)
    if not pl or pl == -1 then return 0 end
    return GetPlayerPed(pl)
end
local function off(sid) local ped = sid and pedOf(sid) or 0 if ped ~= 0 and DoesEntityExist(ped) then SetEntityDrawOutline(ped, false) end end

function G.Highlight(sid)
    sid = tonumber(sid)
    if hl == sid then return end
    off(hl)
    hl = sid
    if not sid then return end
    CreateThread(function()
        local me = sid
        while hl == me do
            local ped = pedOf(me)
            if ped ~= 0 and DoesEntityExist(ped) then
                SetEntityDrawOutline(ped, true)
                SetEntityDrawOutlineColor(255, 255, 255, 255)
                local c = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
                DrawMarker(2, c.x, c.y, c.z + 0.5, 0.0, 0.0, 0.0, 180.0, 0.0, 0.0, 0.22, 0.22, 0.18, 255, 255, 255, 220, true, true, 2, false, nil, nil, false)
            end
            Wait(0)
        end
        off(me)
    end)
end

-- Personnes à côté (vue du client) : { id, name } ; le nom vient du serveur quand il le donne, sinon « Personne à 3 m »
function G.NearbyPlayers(radius, names)
    local me = GetEntityCoords(PlayerPedId())
    local out = {}
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= PlayerPedId() then
            local d = #(GetEntityCoords(ped) - me)
            if d <= (radius or 8.0) then
                local sid = GetPlayerServerId(pid)
                out[#out + 1] = { id = sid, name = names and names[sid] or nil, dist = d }
            end
        end
    end
    table.sort(out, function(a, b) return a.dist < b.dist end)
    return out
end

-- Sous-menu « Choisir la personne » : list = { { id, name } } (le serveur revérifie toujours la distance)
-- onPick(id) est appelé à l'Entrée ; la surbrillance suit la ligne survolée et s'arrête en quittant le sous-menu.
function G.PickMenu(id, title, list, onPick, subtitle)
    local me = GetEntityCoords(PlayerPedId())
    local items = {}
    for _, p in ipairs(list or {}) do
        local ped = pedOf(p.id)
        local d = (ped ~= 0 and DoesEntityExist(ped)) and #(GetEntityCoords(ped) - me) or nil
        items[#items + 1] = { label = tostring(p.name or 'Une personne'), right = d and (math.floor(d + 0.5) .. ' m') or nil, sid = p.id,
            description = 'Entourée à l\'écran. Entrée : choisir cette personne.', onSelect = function() G.Highlight(nil) onPick(p.id) end }
    end
    if #items == 0 then items[1] = { label = 'Personne à côté de toi', disabled = true, description = 'Rapproche-toi puis rouvre le menu.' } end
    return { id = id, title = title, subtitle = subtitle or 'Survole : la personne est entourée', items = items,
        onHover = function(it) G.Highlight(it and it.sid or nil) end,
        onOpen = function(m) local it = m.items and m.items[m.sel or 1] G.Highlight(it and it.sid or nil) end,
        onClose = function() G.Highlight(nil) end }
end

-- Facture reçue (entreprise, taxi…) : payer tout de suite, ou la garder pour plus tard (tablette / téléphone › Factures)
local function money(n) return PB.Money(n) end
RegisterNetEvent('pb:g:bill:offer', function(j)
    local d = G.decode(j)
    if not d or not tonumber(d.id) then return end
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    local items = {
        { type = 'separator', label = tostring(d.reason or 'Facture') },
        { label = 'Montant', right = money(d.amount), disabled = true },
        { label = 'Payer ' .. money(d.amount), icon = 'check', description = "Banque d'abord, sinon espèces.", onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:bill:answer', d.id, true) end },
        { label = 'Plus tard', icon = 'clock', description = 'Elle reste dans ton téléphone (Factures) et dans F6 › Factures.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:bill:answer', d.id, false) end },
    }
    G.Menu.Open({ id = 'bill.offer', title = tostring(d.biz or 'Facture'), subtitle = 'De ' .. tostring(d.from or ''), banner = { text = 'Facture' }, items = items })
end)

-- Point « prise de service » : petit menu pour prendre ou quitter son service (même action que le menu F6)
RegisterNetEvent('pb:g:duty:menu', function(j)
    local d = G.decode(j)
    if not d then return end
    local items = {
        { label = d.on and 'Quitter mon service' or 'Prendre mon service', icon = d.on and 'x' or 'bolt', right = d.on and 'En service' or 'Hors service',
            description = d.on and 'Tes vêtements reviennent.' or 'Ta tenue de travail est enfilée si elle est enregistrée au vestiaire.',
            onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:quick:act', 'duty', { on = not d.on }) end },
    }
    G.Menu.Open({ id = 'duty', title = 'Service', subtitle = tostring(d.biz or ''), banner = { text = 'Prise de service' }, items = items })
end)
