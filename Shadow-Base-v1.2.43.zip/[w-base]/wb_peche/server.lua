-- Shadow Base — Pêche (serveur) : lancer avec une canne et un appât / leurre, touche, ferrage, poisson tiré au sort par le serveur
-- selon l'eau, la rareté du leurre et la canne. Marché aux poissons : chaque vente fait baisser le prix de l'espèce, qui remonte avec le
-- temps ; une « pêche du jour » est mieux payée. Réglages : panel › Extensions › Pêche.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'

local cache = {}
local function cfg(k, d)
    local v = cache[k]
    if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end
    if v == nil then return d end
    return v
end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Pêche', text) end
local function label(item) local i = W:ItemInfo(item) return i and i.label or item end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end
-- Onglet Économie du panel (v1.2.42) : prix × multiplicateur × TVA, gains × salaires (× illégal / × activités)
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function ecoIn(n, kind) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoIncome(n, kind) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function near(src, s, d) local c = pos(src) if not c then return false end return #(vector2(c.x, c.y) - vector2(s.x, s.y)) <= (d or 4.0) and math.abs(c.z - s.z) < 10 end

-- Objets ----------------------------------------------------------------------------------------------------------------------------------------------
local FISH_WEIGHT = { c = 400, pc = 900, r = 2000, e = 6000, l = 9000 }
local function ensureItems()
    for _, f in ipairs(FISH) do
        local r = FISH_RARITY_BY[f.rarity]
        W:EnsureItem({ name = f.name, label = f.label, weight = FISH_WEIGHT[f.rarity], stack = f.rarity == 'l' and 5 or 50, kind = 'misc', usable = false,
            description = ('%s · %s. Se revend au marché aux poissons.'):format(r.label, f.find and 'trouvaille' or WATER_LABEL[f.water]) })
    end
    for _, l in ipairs(LURES) do
        W:EnsureItem({ name = l.name, label = l.label, weight = 20, stack = l.stack, kind = 'misc', usable = false, description = ('Appât / leurre %s pour la pêche.'):format(FISH_RARITY_BY[l.rarity].label:lower()) })
    end
    for _, r in ipairs(RODS) do
        W:EnsureItem({ name = r.name, label = r.label, weight = 1200, stack = 1, kind = 'tool', usable = true, description = r.vip and 'Canne réservée aux VIP. Utilise-la face à l\'eau pour pêcher.' or 'Utilise-la face à l\'eau pour pêcher.' })
    end
    W:EnsureItem({ name = NET.name, label = NET.label, weight = 3000, stack = 1, kind = 'tool', usable = true, description = 'Depuis un bateau à l\'arrêt : ramène plusieurs poissons d\'un coup. Peut se déchirer.' })
end

-- Marché : coefficient de prix par espèce (1 = prix de base) ---------------------------------------------------------------------------------------------
local factor, dirty = {}, {}
local DROP = { c = 0.004, pc = 0.006, r = 0.012, e = 0.025, l = 0.05 }
local function loadMarket()
    for _, r in ipairs(MySQL.query.await('SELECT item, factor FROM wb_peche_market') or {}) do factor[r.item] = tonumber(r.factor) or 1 end
end
local function saveMarket()
    for item in pairs(dirty) do MySQL.insert('REPLACE INTO wb_peche_market (item, factor, updated) VALUES (?, ?, ?)', { item, factor[item] or 1, os.time() }) end
    dirty = {}
end
local function f(item) return factor[item] or 1.0 end
local function setF(item, v)
    local lo = (tonumber(cfg('min_factor', 40)) or 40) / 100
    factor[item] = math.max(lo, math.min(1.4, v))
    dirty[item] = true
end
-- Pêche du jour : une espèce (commune à rare) mieux payée, change toutes les N heures (la même après un redémarrage)
local function featured()
    local hours = math.max(1, tonumber(cfg('featured_hours', 3)) or 3)
    local list = {}
    for _, x in ipairs(FISH) do if not x.find and FISH_RARITY_BY[x.rarity].n <= 3 then list[#list + 1] = x.name end end
    local period = math.floor(os.time() / (hours * 3600))
    return list[(period * 7919) % #list + 1], period
end
local function unitPrice(item)
    local x = FISH_BY[item]
    if not x then return 0 end
    local p = x.price * f(item) * ((tonumber(cfg('price_mult', 100)) or 100) / 100)
    if featured() == item then p = p * ((tonumber(cfg('featured_bonus', 50)) or 50) / 100 + 1) end
    return math.max(1, ecoIn(p, 'activity'))
end
CreateThread(function()
    while true do
        Wait(5 * 60000)
        local rec = (tonumber(cfg('recover', 6)) or 6) / 100
        for _, x in ipairs(FISH) do
            local cur = f(x.name)
            local nv = cur + (1 - cur) * rec + (math.random() - 0.5) * 0.04          -- remonte vers le prix normal, avec un peu de bruit
            if math.abs(nv - cur) > 0.0005 then setF(x.name, nv) end
        end
        saveMarket()
    end
end)

-- Réglages, page du panel ------------------------------------------------------------------------------------------------------------------------------------
local forms, marketBlocks, statsBlocks = {}, nil, nil
local useRod, useNet
local function isVip(src) local ok, v = pcall(function() return W:IsVip(src) end) return ok and v == true end
local XYZ = { { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } }
local function setup()
    W:ExtRegister({ label = 'Pêche', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier la pêche (marché, boutique, points)', true)
    W:ExtMigrate(RES .. '_001', 'Pêche : marché, prises, records', {
        [[CREATE TABLE IF NOT EXISTS wb_peche_market (item VARCHAR(40) NOT NULL, factor DOUBLE NOT NULL DEFAULT 1, updated INT NOT NULL DEFAULT 0, PRIMARY KEY (item))]],
        [[CREATE TABLE IF NOT EXISTS wb_peche_log (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, item VARCHAR(40) NOT NULL, kg DOUBLE NOT NULL DEFAULT 0,
            rarity VARCHAR(2) NOT NULL DEFAULT 'c', money INT NOT NULL DEFAULT 0, kind VARCHAR(6) NOT NULL DEFAULT 'catch', at INT NOT NULL, PRIMARY KEY (id), KEY k_at (at))]],
        [[CREATE TABLE IF NOT EXISTS wb_peche_records (item VARCHAR(40) NOT NULL, kg DOUBLE NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (item))]],
    })
    W:ExtMigrate(RES .. '_002', 'Pêche : concours de la semaine', {
        [[CREATE TABLE IF NOT EXISTS wb_peche_contest (week VARCHAR(8) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', item VARCHAR(40) NOT NULL,
            kg DOUBLE NOT NULL, paid TINYINT(1) NOT NULL DEFAULT 0, at INT NOT NULL, PRIMARY KEY (week))]],
    })
    ensureItems()
    loadMarket()
    forms.main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = 'Pêche active', default = true },
        { k = 'max_per_hour', type = 'number', label = 'Lancers maximum par joueur et par heure', default = 120, min = 1, max = 1000 },
        { k = 'bite_min', type = 'number', label = 'Attente minimale avant la touche (s)', default = 6, min = 1, max = 120 },
        { k = 'bite_max', type = 'number', label = 'Attente maximale avant la touche (s)', default = 18, min = 2, max = 300 },
        { k = 'price_mult', type = 'number', label = 'Prix du marché (% des prix de base)', default = 100, min = 0, max = 1000 },
        { k = 'min_factor', type = 'number', label = 'Prix plancher (% du prix de base)', default = 40, min = 5, max = 100, hint = 'Le prix d\'une espèce ne descend pas plus bas, même si tout le monde la vend.' },
        { k = 'recover', type = 'number', label = 'Remontée des prix toutes les 5 min (%)', default = 6, min = 0, max = 100, hint = 'Part de l\'écart avec le prix normal rattrapée à chaque fois.' },
        { k = 'featured_hours', type = 'number', label = 'La pêche du jour change toutes les (heures)', default = 3, min = 1, max = 48 },
        { k = 'featured_bonus', type = 'number', label = 'Bonus de la pêche du jour (%)', default = 50, min = 0, max = 500 },
        { k = 'pay', type = 'select', label = 'Paiement des ventes', opts = { { 'cash', 'Espèces' }, { 'bank', 'Banque' } }, default = 'cash' },
        { k = 'blips', type = 'toggle', label = 'Marchés et magasins sur la carte', default = true },
        { k = 'vip_bonus', type = 'number', label = 'Bonus de revente des VIP (%)', default = 15, min = 0, max = 200 },
        { k = 'contest', type = 'toggle', label = 'Concours de la semaine (plus gros poisson)', default = true },
        { k = 'contest_prize', type = 'number', label = 'Prix du concours ($, versé en banque)', default = 10000, min = 0, max = 10000000 },
    } })
    forms.spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Points posés', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Marchés aux poissons et magasins de pêche', default = {}, wide = true, maxitems = 50, unique = 'id',
          hint = 'Pose-les en jeu : menu staff (F10) › Builder › Pêche. Type : market (revente) ou shop (cannes et leurres).',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true },
            { k = 'label', label = 'Nom', required = true, maxlen = 40 }, XYZ[1], XYZ[2], XYZ[3] } } } })
    W:ExtModule({
        id = RES, label = 'Pêche', icon = 'gem', perm = PERM, hint = 'Raretés de poissons et de leurres, marché aux prix variables',
        caps = {
            { 'Pêche partout face à l\'eau', 'ok', 'Mer, lac, rivière et pêche au large en bateau : chaque eau a ses poissons.' },
            { 'Raretés', 'ok', 'Commun, peu commun, rare, épique, légendaire, pour les poissons comme pour les leurres. La canne aide aussi.' },
            { 'Ferrage', 'ok', 'À la touche, appuie sur E quand le curseur passe dans la zone verte : plus le poisson est rare, plus c\'est dur.' },
            { 'Marché vivant', 'ok', 'Chaque vente fait baisser le prix de l\'espèce, qui remonte avec le temps. Pêche du jour mieux payée.' },
            { 'Records du serveur', 'ok', 'Le plus gros spécimen de chaque espèce.' },
        },
        doc = "## Pêche\nAchète une canne et des appâts au **magasin de pêche**, place-toi face à l'eau et **utilise la canne** depuis l'inventaire. Choisis l'appât, attends la touche, puis **ferre avec E** quand le curseur est dans la zone verte. Revends au **marché aux poissons** : les prix bougent selon les ventes.\n\nPoser les points : **F10 › Builder › Pêche**.",
        tabs = {
            { id = 'market', label = 'Marché', icon = 'coins', build = function() return marketBlocks() end },
            { id = 'stats', label = 'Prises et records', icon = 'chart', build = function() return statsBlocks() end },
            { id = 'main', label = 'Réglages', icon = 'sliders', form = forms.main },
            { id = 'spots', label = 'Points posés', icon = 'pin', form = forms.spots },
        },
    })
    for _, r in ipairs(RODS) do W:RegisterUsable(r.name, function(src) return useRod(src) end) end
    W:RegisterUsable(NET.name, function(src) return useNet(src) end)
end

marketBlocks = function()
    local feat = featured()
    local rows = {}
    for _, x in ipairs(FISH) do
        local r = FISH_RARITY_BY[x.rarity]
        local pct = math.floor(f(x.name) * 100 + 0.5)
        rows[#rows + 1] = { label = x.label .. (feat == x.name and ' ★' or ''), rarity = r.label, water = x.find and 'Trouvaille' or WATER_LABEL[x.water], base = '$' .. x.price, now = '$' .. unitPrice(x.name), trend = pct .. ' %' }
    end
    return {
        { type = 'notice', level = 'info', text = ('Pêche du jour : %s (+%d %%). Chaque vente fait baisser le prix de l\'espèce ; il remonte de lui-même avec le temps.'):format(FISH_BY[feat].label, tonumber(cfg('featured_bonus', 50)) or 50) },
        { type = 'table', id = 'm', title = 'Cours du marché aux poissons', search = true, rows = rows,
          columns = { { k = 'label', label = 'Espèce' }, { k = 'rarity', label = 'Rareté' }, { k = 'water', label = 'Eau' }, { k = 'base', label = 'Prix de base' }, { k = 'now', label = 'Prix actuel' }, { k = 'trend', label = 'Cours' } } },
    }
end
statsBlocks = function()
    local since = os.time() - 86400
    local rows = MySQL.query.await("SELECT item, rarity, COUNT(*) AS n, MAX(kg) AS kg FROM wb_peche_log WHERE at > ? AND kind = 'catch' GROUP BY item, rarity ORDER BY n DESC", { since }) or {}
    local sold = MySQL.scalar.await("SELECT COALESCE(SUM(money), 0) FROM wb_peche_log WHERE at > ? AND kind = 'sell'", { since }) or 0
    local out = {}
    for _, r in ipairs(rows) do out[#out + 1] = { label = label(r.item), rarity = (FISH_RARITY_BY[r.rarity] or {}).label or r.rarity, n = tonumber(r.n) or 0, kg = ('%.1f kg'):format(tonumber(r.kg) or 0) } end
    local rec = {}
    for _, r in ipairs(MySQL.query.await('SELECT item, kg, name, at FROM wb_peche_records ORDER BY kg DESC') or {}) do rec[#rec + 1] = { label = label(r.item), kg = ('%.1f kg'):format(tonumber(r.kg) or 0), name = r.name, at = os.date('%d/%m/%Y', tonumber(r.at) or 0) } end
    return {
        { type = 'stats', items = { { label = 'Prises (24 h)', value = (function() local n = 0 for _, r in ipairs(out) do n = n + r.n end return n end)(), icon = 'gem' }, { label = 'Ventes (24 h)', value = '$' .. tostring(sold), icon = 'coins' } } },
        { type = 'table', id = 'c', title = 'Prises des dernières 24 h', rows = out, empty = 'Aucune prise.', columns = { { k = 'label', label = 'Espèce' }, { k = 'rarity', label = 'Rareté' }, { k = 'n', label = 'Prises' }, { k = 'kg', label = 'Plus gros' } } },
        { type = 'table', id = 'r', title = 'Records du serveur', rows = rec, empty = 'Aucun record.', columns = { { k = 'label', label = 'Espèce' }, { k = 'kg', label = 'Poids' }, { k = 'name', label = 'Pêcheur' }, { k = 'at', label = 'Date' } } },
    }
end

-- Données des joueurs ---------------------------------------------------------------------------------------------------------------------------------------
local function publicCfg()
    local spots = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do spots[#spots + 1] = { id = s.id, kind = s.kind, label = s.label, x = s.x, y = s.y, z = s.z } end
    return { enabled = cfg('enabled', true) ~= false, blips = cfg('blips', true) ~= false, spots = spots }
end
local function push(target) TriggerClientEvent(RES .. ':cfg', target or -1, json.encode(publicCfg())) end
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == NS then cache = {} push() end end)
RegisterNetEvent(RES .. ':hello', function() push(source) end)

-- Pêche ---------------------------------------------------------------------------------------------------------------------------------------------------------
local pending, hourly, lastRod = {}, {}, {}
AddEventHandler('playerDropped', function() local s = source pending[s], hourly[s], lastRod[s] = nil, nil, nil end)
local function bestRod(src) local vip = isVip(src) for _, r in ipairs(RODS) do if (vip or not r.vip) and W:HasItem(src, r.name, 1) then return r end end end

useRod = function(src)
    if not cfg('enabled', true) then return false, 'La pêche est désactivée.' end
    if pending[src] then return false, 'Tu pêches déjà.' end
    if not W:CanAct(src) then return false end
    local lures = {}
    for _, l in ipairs(LURES) do
        local n = W:GetItemCount(src, l.name) or 0
        if n > 0 and (not l.vip or isVip(src)) then lures[#lures + 1] = { name = l.name, label = l.label, n = n, rarity = l.rarity } end
    end
    if #lures == 0 then return false, 'Il te faut un appât ou un leurre (magasin de pêche).' end
    if not bestRod(src) then return false, 'Cette canne est réservée aux VIP.' end
    TriggerClientEvent(RES .. ':choose', src, json.encode(lures))
    return true, 'Choisis ton appât.', true
end

local WATERS = { mer = true, large = true, lac = true, riviere = true }
local function inBoat(src)
    local ped = GetPlayerPed(src)
    local v = ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
    if v == 0 then return false end
    local ok, t = pcall(GetVehicleType, v)
    return ok and t == 'boat'
end
local function roll(water, lure, rod)
    local all = (math.random() * 100)
    if all < 0.4 * (lure.name == 'leurre_dore' and 2 or 1) then return 'fish_tresor' end
    if all < 1.0 and FISH_RARITY_BY[lure.rarity].n >= 3 then return 'leurre_dore', true end
    if all < 5.0 then
        local junk = math.random() < 0.1 and 'message_bottle' or 'old_boot'
        if W:ItemInfo(junk) then return junk, true end
    end
    local weights, total = {}, 0
    for i, r in ipairs(FISH_RARITY) do
        local w = r.weight * lure.mult[i] * rod.luck[i] * ((lure.best == water or lure.best == '*') and i >= 2 and 1.25 or 1)
        weights[i] = w
        total = total + w
    end
    local x, tier = math.random() * total, 1
    for i, w in ipairs(weights) do x = x - w if x <= 0 then tier = i break end end
    for t = tier, 1, -1 do
        local pool = {}
        for _, fsh in ipairs(FISH) do if fsh.water == water and FISH_RARITY_BY[fsh.rarity].n == t then pool[#pool + 1] = fsh.name end end
        if #pool > 0 then return pool[math.random(#pool)] end
    end
    return nil
end

RegisterNetEvent(RES .. ':cast', function(lureName, water)
    local src = source
    if not cfg('enabled', true) or pending[src] or not W:CanAct(src) then return end
    local lure, rod = LURE_BY[tostring(lureName)], bestRod(src)
    if not lure or not rod or not W:HasItem(src, lure.name, 1) or (lure.vip and not isVip(src)) then return end
    water = WATERS[water] and water or 'mer'
    if water == 'large' and not inBoat(src) then water = 'mer' end
    local now = os.time()
    local h = hourly[src]
    if not h or now - h.t >= 3600 then h = { t = now, n = 0 } hourly[src] = h end
    if h.n >= (tonumber(cfg('max_per_hour', 120)) or 120) then notify(src, 'warn', 'Les poissons boudent : reviens dans un moment.') return end
    h.n = h.n + 1
    local item, junk = roll(water, lure, rod)
    if not item then return end
    local fsh = FISH_BY[item]
    local rar = FISH_RARITY_BY[(fsh and fsh.rarity) or 'c']
    local lo, hi = tonumber(cfg('bite_min', 6)) or 6, tonumber(cfg('bite_max', 18)) or 18
    local wait = math.floor((lo + math.random() * math.max(0, hi - lo)) * lure.bite + 0.5)
    local c = pos(src)
    -- VIP : pêche automatique (chaque touche est ferrée, la ligne est relancée par le client) ; réglage dans le panel › VIP › Avantages
    local auto = isVip(src) and (function() local ok, v = pcall(function() return W:CfgGet('vip', 'fish_auto', true) end) return not ok or v ~= false end)()
    pending[src] = { item = item, junk = junk, rar = rar, lure = lure, rod = rod, water = water, t0 = now, wait = math.max(2, wait), at = c, auto = auto }
    local diff = junk and 1 or rar.diff
    TriggerClientEvent(RES .. ':bite', src, json.encode({ wait = math.max(2, wait), hits = junk and 1 or rar.hits, misses = rod.power, zone = math.max(0.06, math.min(0.26, 0.21 - 0.028 * diff + 0.03 * (rod.power - 1))),
        speed = 0.55 + 0.17 * diff, water = water, rod = rod.label, lure = lure.label, big = (not junk) and rar.n >= 4, auto = auto or nil, lureName = lure.name }))
end)

RegisterNetEvent(RES .. ':cancel', function() pending[source] = nil end)

local function loseLure(src, p, mult)
    if math.random(100) <= math.min(100, p.lure.loss * (mult or 1)) then
        W:RemoveItem(src, p.lure.name, 1)
        if p.lure.loss < 100 then notify(src, 'warn', ('%s perdu.'):format(p.lure.label)) end
    end
end
local function playerName(src) local ok, i = pcall(function() return W:GetIdentity(src) end) if ok and i and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 64) end return (GetPlayerName(src) or 'Pêcheur'):sub(1, 64) end

RegisterNetEvent(RES .. ':reel', function(ok)
    local src = source
    local p = pending[src]
    pending[src] = nil
    if not p then return end
    local el = os.time() - p.t0
    if el < p.wait - 1 or el > p.wait + 60 then return end
    local c = pos(src)
    if not c or not p.at or #(c - p.at) > 8.0 then notify(src, 'error', 'Tu as bougé : la ligne s\'est détendue.') return end
    if p.auto then ok = true end   -- VIP : ferrage automatique (décidé ici, au lancer, jamais par le client)
    if ok ~= true then
        loseLure(src, p, 1.5)
        notify(src, 'warn', p.rar.n >= 3 and 'Il a cassé la ligne… il était gros !' or 'Le poisson s\'est décroché.')
        return
    end
    loseLure(src, p, 1)
    if not W:CanCarryItem(src, p.item, 1) then notify(src, 'error', 'Ton sac est plein : tu relâches ta prise.') return end
    W:AddItem(src, p.item, 1)
    local fsh = FISH_BY[p.item]
    local lic = W:GetLicense(src)
    if not fsh then
        notify(src, 'success', ('Tu remontes : %s.'):format(label(p.item)))
        TriggerClientEvent(RES .. ':caught', src, json.encode({ label = label(p.item), rarity = p.item == 'leurre_dore' and 'l' or 'c' }))
        return
    end
    -- poids : la moyenne revient plus souvent que les extrêmes
    local t = (math.random() + math.random() + math.random()) / 3
    local kg = math.floor((fsh.kg[1] + (fsh.kg[2] - fsh.kg[1]) * t) * 100) / 100
    local record = false
    local best = MySQL.scalar.await('SELECT kg FROM wb_peche_records WHERE item = ?', { p.item })
    if not best or kg > tonumber(best) then
        record = best ~= nil or FISH_RARITY_BY[fsh.rarity].n >= 3
        MySQL.insert('REPLACE INTO wb_peche_records (item, kg, name, at) VALUES (?, ?, ?, ?)', { p.item, kg, playerName(src), os.time() })
    end
    if lic then MySQL.insert('INSERT INTO wb_peche_log (license, item, kg, rarity, kind, at) VALUES (?, ?, ?, ?, ?, ?)', { lic, p.item, kg, fsh.rarity, 'catch', os.time() }) end
    local week = os.date('%Y%W')
    if cfg('contest', true) ~= false and lic then
        local cur = MySQL.single.await('SELECT kg FROM wb_peche_contest WHERE week = ?', { week })
        if not cur or kg > (tonumber(cur.kg) or 0) then
            MySQL.insert('REPLACE INTO wb_peche_contest (week, license, name, item, kg, paid, at) VALUES (?, ?, ?, ?, ?, 0, ?)', { week, lic, playerName(src), p.item, kg, os.time() })
            notify(src, 'success', ('Tu prends la tête du concours de la semaine : %s de %.2f kg !'):format(fsh.label, kg))
        end
    end
    TriggerClientEvent(RES .. ':caught', src, json.encode({ label = fsh.label, rarity = fsh.rarity, kg = kg, record = record }))
    TriggerEvent(RES .. ':caught', src, p.item, kg, fsh.rarity)
end)

-- Marché aux poissons et magasin ------------------------------------------------------------------------------------------------------------------------------
function contestLeaderText() return CONTEST_LEADER and CONTEST_LEADER() or nil end
RegisterNetEvent(RES .. ':open', function(id)
    local src = source
    local s = find(cfg('spots', {}), tostring(id))
    if not s then notify(src, 'error', "Ce point n'existe plus : reconnecte-toi ou demande au staff de le reposer.") return end
    if not near(src, s, 5.0) then notify(src, 'warn', 'Rapproche-toi du comptoir.') return end
    local list = {}
    if s.kind == 'market' then
        local feat = featured()
        for _, x in ipairs(FISH) do
            local n = W:GetItemCount(src, x.name) or 0
            list[#list + 1] = { item = x.name, label = x.label, n = n, price = unitPrice(x.name), base = x.price, rarity = x.rarity, featured = feat == x.name or nil, pct = math.floor(f(x.name) * 100 + 0.5) }
        end
    elseif s.kind == 'shop' then
        local vip = isVip(src)
        for i = #RODS, 1, -1 do local r = RODS[i] list[#list + 1] = { item = r.name, label = r.label, price = ecoPrice(r.price), rod = true, power = r.power, vip = r.vip or nil, locked = (r.vip and not vip) or nil } end
        for _, l in ipairs(LURES) do if not l.nosell then list[#list + 1] = { item = l.name, label = l.label, price = ecoPrice(l.price), rarity = l.rarity, vip = l.vip or nil, locked = (l.vip and not vip) or nil } end end
        list[#list + 1] = { item = NET.name, label = NET.label, price = ecoPrice(NET.price), net = true }
    else return end
    TriggerClientEvent(RES .. ':shop', src, s.id, s.kind, s.label, json.encode(list), s.kind == 'market' and cfg('contest', true) ~= false and contestLeaderText() or nil, isVip(src))
end)

local lastAct = {}
local function throttle(src) local t = GetGameTimer() if lastAct[src] and t - lastAct[src] < 700 then return false end lastAct[src] = t return true end
AddEventHandler('playerDropped', function() lastAct[source] = nil end)

RegisterNetEvent(RES .. ':sell', function(id, item)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local x = FISH_BY[tostring(item)]
    if not s or s.kind ~= 'market' or not x or not near(src, s) then return end
    local n = math.min(W:GetItemCount(src, x.name) or 0, 100)
    if n <= 0 then return end
    if not W:RemoveItem(src, x.name, n) then return end
    -- vendre en gros fait baisser le prix au fil des unités
    local total = 0
    for _ = 1, n do
        total = total + unitPrice(x.name)
        setF(x.name, f(x.name) - DROP[x.rarity])
    end
    local bonus = isVip(src) and math.floor(total * (tonumber(cfg('vip_bonus', 15)) or 15) / 100) or 0
    total = total + bonus
    W:AddMoney(src, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash', total, 'Vente de poisson')
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO wb_peche_log (license, item, kg, rarity, money, kind, at) VALUES (?, ?, 0, ?, ?, ?, ?)', { lic, x.name, x.rarity, total, 'sell', os.time() }) end
    notify(src, 'success', ('Vendu : %d × %s pour $%d%s. Nouveau cours : $%d.'):format(n, x.label, total, bonus > 0 and (' (dont bonus VIP $' .. bonus .. ')') or '', unitPrice(x.name)))
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)

RegisterNetEvent(RES .. ':buy', function(id, item, qty)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    if not s or s.kind ~= 'shop' or not near(src, s) then return end
    local price, stack
    local vipOnly = false
    for _, r in ipairs(RODS) do if r.name == item then price, stack, vipOnly = r.price, 1, r.vip end end
    local l = LURE_BY[tostring(item)]
    if l and not l.nosell then price, stack, vipOnly = l.price, l.stack, l.vip end
    if item == NET.name then price, stack = NET.price, 1 end
    if not price then return end
    price = ecoPrice(price)
    if vipOnly and not isVip(src) then notify(src, 'error', 'Réservé aux VIP.') return end
    qty = math.max(1, math.min(stack, math.floor(tonumber(qty) or 1)))
    if not W:CanCarryItem(src, item, qty) then notify(src, 'error', 'Ton sac est plein.') return end
    if not W:Pay(src, price * qty, 'cash', 'Magasin de pêche') then notify(src, 'error', 'Pas assez d\'argent.') return end
    W:AddItem(src, item, qty)
    notify(src, 'success', ('Acheté : %d × %s pour $%d.'):format(qty, label(item), price * qty))
end)

-- Filet de pêche (bateau à l'arrêt) -----------------------------------------------------------------------------------------------------------------------------
local netting = {}
AddEventHandler('playerDropped', function() netting[source] = nil end)
useNet = function(src)
    if not cfg('enabled', true) then return false, 'La pêche est désactivée.' end
    if netting[src] or pending[src] then return false, 'Tu pêches déjà.' end
    local ped = GetPlayerPed(src)
    local v = ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
    local ok, t = pcall(GetVehicleType, v)
    if v == 0 or not ok or t ~= 'boat' then return false, 'Le filet se jette depuis un bateau.' end
    if GetEntitySpeed(v) > 2.0 then return false, 'Arrête le bateau pour jeter le filet.' end
    netting[src] = { t0 = os.time(), at = GetEntityCoords(ped) }
    TriggerClientEvent(RES .. ':net', src, NET.secs)
    return true, 'Filet à l\'eau…', true
end
RegisterNetEvent(RES .. ':netdone', function(ok)
    local src = source
    local n = netting[src]
    netting[src] = nil
    if not n or ok ~= true then return end
    if os.time() - n.t0 < NET.secs - 1 then return end
    local c = pos(src)
    if not c or #(c - n.at) > 25.0 then notify(src, 'warn', 'Le bateau a dérivé : le filet est vide.') return end
    if not W:HasItem(src, NET.name, 1) then return end
    local water = 'mer'
    local pool = {}
    for _, x in ipairs(FISH) do if not x.find and (x.water == 'large' or x.water == 'mer') and FISH_RARITY_BY[x.rarity].n <= NET.maxRarity then pool[#pool + 1] = x end end
    local got, count = {}, math.random(NET.min, NET.max)
    for _ = 1, count do
        local w, total = {}, 0
        for i, x in ipairs(pool) do local r = FISH_RARITY_BY[x.rarity] w[i] = r.weight total = total + r.weight end
        local roll, pick = math.random() * total, pool[1]
        for i, x in ipairs(pool) do roll = roll - w[i] if roll <= 0 then pick = x break end end
        if W:CanCarryItem(src, pick.name, 1) and W:AddItem(src, pick.name, 1) then got[pick.label] = (got[pick.label] or 0) + 1 end
    end
    local parts = {}
    for k, q in pairs(got) do parts[#parts + 1] = q .. ' × ' .. k end
    local torn = math.random(100) <= NET.tear
    if torn then W:RemoveItem(src, NET.name, 1) end
    notify(src, #parts > 0 and 'success' or 'warn', (#parts > 0 and ('Filet relevé : ' .. table.concat(parts, ', ') .. '.') or 'Filet vide (sac plein ?).') .. (torn and ' Le filet s\'est déchiré.' or ''))
end)

-- Concours de la semaine : le plus gros poisson (en kg) de la semaine gagne le prix, versé en banque au début de la semaine suivante -------------------------
local function payContest()
    if cfg('contest', true) == false then return end
    local cur = os.date('%Y%W')
    for _, r in ipairs(MySQL.query.await('SELECT * FROM wb_peche_contest WHERE paid = 0 AND week < ?', { cur }) or {}) do
        local prize = ecoIn(tonumber(cfg('contest_prize', 10000)) or 0, 'activity')
        local paidOnline = false
        for _, id in ipairs(GetPlayers()) do
            local sid = tonumber(id)
            if W:GetLicense(sid) == r.license then
                if prize > 0 then W:AddMoney(sid, 'bank', prize, 'Concours de pêche') end
                notify(sid, 'success', ('Tu remportes le concours de pêche de la semaine (%s, %.2f kg) : $%d en banque !'):format(label(r.item), tonumber(r.kg) or 0, prize))
                paidOnline = true
            end
        end
        if not paidOnline and prize > 0 then MySQL.update.await('UPDATE pb_players SET bank = bank + ? WHERE license = ?', { prize, r.license }) end
        MySQL.update.await('UPDATE wb_peche_contest SET paid = 1 WHERE week = ?', { r.week })
        for _, id in ipairs(GetPlayers()) do notify(tonumber(id), 'info', ('Concours de pêche : %s gagne avec %s de %.2f kg !'):format(r.name, label(r.item), tonumber(r.kg) or 0)) end
    end
end
CreateThread(function() Wait(60000) while true do pcall(payContest) Wait(30 * 60000) end end)
local function contestLeader()
    local r = MySQL.single.await('SELECT * FROM wb_peche_contest WHERE week = ?', { os.date('%Y%W') })
    return r and ('%s · %s de %.2f kg'):format(r.name, label(r.item), tonumber(r.kg) or 0) or 'Personne pour le moment'
end
RegisterCommand('concours', function(src) if src > 0 then notify(src, 'info', 'Concours de la semaine : ' .. contestLeader() .. (' (prix : $%d)'):format(tonumber(cfg('contest_prize', 10000)) or 0)) end end, false)
CONTEST_LEADER = contestLeader

-- Builder (F10 › Builder › Pêche) ------------------------------------------------------------------------------------------------------------------------------
local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = #(vector2(c.x, c.y) - vector2(s.x + 0.0, s.y + 0.0)) if d < 25 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then
            -- anciennes « zones de pêche » et poissonneries posées avec les Activités (wb_activites) : supprimées aussi d'ici
            if GetResourceState('wb_activites') == 'started' then TriggerEvent('wb_activites:deleteNear', src, c.x, c.y, 25.0, { 'peche', 'poissonnerie' }) return true end
            notify(src, 'error', 'Aucun point de pêche à moins de 25 m.') return false
        end
        local s = table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', ('« %s » supprimé.'):format(s.label))
        return true
    end
    if what ~= 'market' and what ~= 'shop' then return false end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    local n = 1
    while find(spots, what .. '_' .. n) do n = n + 1 end
    spots[#spots + 1] = { id = what .. '_' .. n, kind = what, label = name ~= '' and name or (what == 'market' and 'Marché aux poissons' or 'Magasin de pêche'),
        x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100 }
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : ' .. spots[#spots].label)
    notify(src, 'success', spots[#spots].label .. ' posé ici.')
    return true
end

local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        W:RegisterBuilder({ id = 'peche', label = 'Pêche', icon = 'map', points = {
            { id = 'market', label = 'Marché aux poissons (revente, prix variables)', ask = 'Nom affiché (vide = « Marché aux poissons »)' },
            { id = 'shop', label = 'Magasin de pêche (cannes, appâts, leurres)', ask = 'Nom affiché (vide = « Magasin de pêche »)' },
            { id = 'delete', label = 'Supprimer le point de pêche le plus proche' },
        } }, function(src, what, extra) return placeSpot(src, tostring(what), tostring(extra or '')) end)
    end)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
AddEventHandler('onResourceStop', function(res) if res == RES then saveMarket() end end)
