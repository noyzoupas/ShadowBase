-- Shadow Base — Petits jobs : étapes, types de missions et attribution par entreprise (modifiable dans le panel : Extensions › Petits jobs).

-- Étapes ------------------------------------------------------------------------------------------------------------------------------------------
-- kind : drive (aller quelque part en véhicule puis agir à pied), stop (s'arrêter en véhicule, rien à faire à pied),
--        here (sur place, au départ), service (un poste de l'entreprise)
-- range : distance (m) entre l'étape précédente et celle-ci ; pay : paie de base ; perkm : bonus par km parcouru
-- npc : customer (client à la porte), passenger_in / passenger_out (taxi), injured (blessé au sol), stranded (véhicule en panne + conducteur)
JOB_PHASES = {
    load       = { kind = 'here',  label = 'Charger la marchandise', secs = 6, anim = 'anim@heists@box_carry@|idle', prop = 'hei_prop_heist_box', pay = 0 },
    getcar     = { kind = 'here',  label = 'Récupérer le véhicule du client', secs = 3, anim = 'WORLD_HUMAN_CLIPBOARD', pay = 0 },
    drop       = { kind = 'drive', label = 'Livrer le colis', goal = 'Livre le colis au client', range = { 300, 1600 }, secs = 4, anim = 'anim@heists@box_carry@|idle', prop = 'hei_prop_heist_box', npc = 'customer', pay = 120, perkm = 40 },
    food       = { kind = 'drive', label = 'Remettre la commande', goal = 'Livre la commande', range = { 250, 1400 }, secs = 3, anim = 'mp_common|givetake1_a', prop = 'prop_food_bs_bag_01', npc = 'customer', pay = 100, perkm = 40 },
    pickup     = { kind = 'stop',  label = 'Prendre le client', goal = 'Va chercher le client', range = { 200, 1200 }, npc = 'passenger_in', pay = 0 },
    dropoff    = { kind = 'stop',  label = 'Déposer le client', goal = 'Dépose le client à destination', range = { 400, 2200 }, npc = 'passenger_out', pay = 120, perkm = 70 },
    repair     = { kind = 'drive', label = 'Réparer le véhicule', goal = 'Dépanne le véhicule en panne', range = { 300, 1800 }, secs = 10, anim = 'mini@repair|fixing_a_ped', npc = 'stranded', pay = 200, perkm = 40 },
    rescue     = { kind = 'drive', label = 'Prodiguer les soins', goal = 'Porte secours à la victime', range = { 300, 1800 }, secs = 10, anim = 'mini@cpr@char_a@cpr_str|cpr_pumpchest', npc = 'injured', pay = 200, perkm = 40 },
    checkpoint = { kind = 'stop',  label = 'Point de contrôle', goal = 'Patrouille jusqu\'au point suivant', range = { 300, 1200 }, pay = 80, perkm = 30 },
    worksite   = { kind = 'drive', label = 'Intervention', goal = 'Va sur le chantier', range = { 300, 1600 }, secs = 12, anim = 'WORLD_HUMAN_HAMMERING', pay = 150, perkm = 30 },
    trash      = { kind = 'drive', label = 'Ramasser les poubelles', goal = 'Ramasse les poubelles', range = { 120, 500 }, secs = 4, anim = 'anim@heists@narcotics@trash|throw_b', prop = 'prop_cs_rub_binbag_01', pay = 60, perkm = 20 },
    report     = { kind = 'drive', label = 'Couvrir l\'évènement', goal = 'Va couvrir l\'évènement', range = { 300, 1600 }, secs = 8, anim = 'WORLD_HUMAN_PAPARAZZI', pay = 150, perkm = 30 },
    unload     = { kind = 'drive', label = 'Décharger la cargaison', goal = 'Livre la cargaison', range = { 900, 3000 }, secs = 8, anim = 'anim@heists@box_carry@|idle', prop = 'hei_prop_heist_box', pay = 260, perkm = 60 },
    delivercar = { kind = 'stop',  label = 'Livrer le véhicule', goal = 'Livre le véhicule au client', range = { 600, 2500 }, leaveveh = true, pay = 220, perkm = 60 },
    task       = { kind = 'service', label = 'Tâche', goal = 'Va à ton poste', secs = 8, pay = 60 },
}

-- Types de missions ---------------------------------------------------------------------------------------------------------------------------------
-- head : étapes faites une seule fois au début ; unit : étapes répétées units[1] à units[2] fois ; veh : véhicule de service (nil = à pied)
JOB_TYPES = {
    livraison  = { label = 'Livraisons', icon = 'bag', desc = 'Charge les colis puis livre-les chez les clients.', veh = 'speedo', head = { 'load' }, unit = { 'drop' }, units = { 3, 5 } },
    repas      = { label = 'Livraison de repas', icon = 'food', desc = 'Récupère les commandes et livre-les en scooter.', veh = 'faggio', head = { 'load' }, unit = { 'food' }, units = { 2, 4 } },
    taxi       = { label = 'Courses', icon = 'car', desc = 'Prends des clients au bord de la route et dépose-les à destination.', veh = 'taxi', unit = { 'pickup', 'dropoff' }, units = { 2, 3 } },
    depannage  = { label = 'Dépannages', icon = 'engine', desc = 'Des automobilistes sont en panne : va les réparer.', veh = 'towtruck', unit = { 'repair' }, units = { 2, 3 } },
    patrouille = { label = 'Patrouille', icon = 'shield', desc = 'Passe par les points de contrôle de la ville.', veh = 'police', unit = { 'checkpoint' }, units = { 4, 6 } },
    secours    = { label = 'Appels de secours', icon = 'heart', desc = 'Des victimes attendent des soins : rejoins-les.', veh = 'ambulance', unit = { 'rescue' }, units = { 2, 3 } },
    chantier   = { label = 'Interventions', icon = 'brush', desc = 'Des clients t\'attendent pour des travaux.', veh = 'bison', unit = { 'worksite' }, units = { 2, 4 } },
    ordures    = { label = 'Tournée des poubelles', icon = 'trash', desc = 'Ramasse les sacs poubelles du quartier.', veh = 'trash', unit = { 'trash' }, units = { 5, 8 } },
    reportage  = { label = 'Reportages', icon = 'image', desc = 'Couvre les évènements de la ville (photos, vidéo).', veh = 'rumpo', unit = { 'report' }, units = { 2, 4 } },
    transport  = { label = 'Transport de marchandises', icon = 'route', desc = 'Charge la cargaison et livre-la loin d\'ici.', veh = 'mule', head = { 'load' }, unit = { 'unload' }, units = { 1, 2 } },
    convoyage  = { label = 'Convoyage', icon = 'key', desc = 'Livre un véhicule vendu à son nouveau propriétaire.', veh = '@client', head = { 'getcar' }, unit = { 'delivercar' }, units = { 1, 1 } },
    service    = { label = 'Service sur place', icon = 'star', desc = 'Accueil, préparation, rangement : fais tourner l\'établissement.', unit = { 'task' }, units = { 4, 6 } },
}
JOB_ORDER = { 'service', 'livraison', 'repas', 'taxi', 'depannage', 'patrouille', 'secours', 'chantier', 'ordures', 'reportage', 'transport', 'convoyage' }

-- Véhicules livrés en convoyage (voitures « vendues » au client)
JOB_CLIENT_CARS = { 'oracle2', 'felon', 'schafter2', 'tailgater', 'jackal', 'baller2', 'cavalcade2', 'huntley', 'f620', 'sentinel2', 'buffalo', 'exemplar' }

-- Attribution par défaut : entreprise du catalogue -> missions (le reste suit sa catégorie)
JOB_BY_BIZ = {
    lspd = 'patrouille', sheriff = 'patrouille', fib = 'patrouille', douane = 'patrouille', rangers = 'patrouille', prison = 'patrouille', security = 'patrouille,service',
    ems = 'secours', fire = 'secours', clinic = 'secours,service', ambulance_priv = 'secours', vet = 'secours,service',
    mecano = 'depannage', bodyshop = 'depannage', tires = 'depannage,service', towing = 'depannage', scrapyard = 'depannage,service',
    taxi = 'taxi', limo = 'taxi', airtaxi = 'taxi',
    cardealer = 'convoyage,service', luxurycars = 'convoyage,service', bikes = 'convoyage,service', rental = 'convoyage,service',
    carwash = 'service', gasstation = 'service,livraison', driving = 'service', dmv = 'service',
    burgershot = 'repas,service', pizzeria = 'repas,service', sushi = 'repas,service', bakery = 'repas,service', icecream = 'repas,service', foodtruck = 'repas,service',
    catering = 'repas,service', restaurant = 'repas,service', cafe = 'repas,service', bean = 'repas,service',
    bahamas = 'service,livraison', unicorn = 'service', tequilala = 'service,livraison', pub = 'service,livraison', nightclub = 'service', casino = 'service', nightcover = 'service',
    vineyard = 'transport,service', brewery = 'transport,service', farm = 'transport', lumber = 'transport', mining = 'transport', fishing = 'transport',
    oil = 'transport', port = 'transport', trucking = 'transport', airline = 'transport', boats = 'transport',
    delivery = 'livraison', post = 'livraison', movers = 'livraison', garbage = 'ordures',
    construction = 'chantier', electrician = 'chantier', plumber = 'chantier', gardener = 'chantier', urbanisme = 'chantier', cleaning = 'chantier,service',
    weazel = 'reportage', newspaper = 'reportage', radio = 'reportage,service', photo = 'reportage,service', studio = 'reportage,service', pi = 'reportage',
}
JOB_BY_CAT = { public = 'service,livraison', sante = 'livraison,service', auto = 'service', resto = 'repas,service', commerce = 'livraison,service', services = 'service,livraison',
    medias = 'reportage', loisirs = 'service', industrie = 'transport', facade = 'service,livraison' }

-- Véhicule de service propre à une entreprise
JOB_VEH_BY_BIZ = {
    sheriff = 'sheriff', fib = 'fbi', rangers = 'pranger', douane = 'police4', prison = 'policet', security = 'dilettante2', lspd = 'police',
    fire = 'firetruk', vet = 'speedo', limo = 'stretch', airtaxi = 'taxi', mecano = 'towtruck2', bodyshop = 'towtruck2', tires = 'towtruck2', scrapyard = 'towtruck',
    post = 'boxville2', movers = 'mule', delivery = 'speedo', trucking = 'pounder', oil = 'pounder', port = 'pounder', airline = 'pounder',
    electrician = 'utillitruck3', urbanisme = 'utillitruck3', plumber = 'burrito3', gardener = 'bison', cleaning = 'burrito3',
    newspaper = 'rumpo', radio = 'rumpo', photo = 'rumpo', studio = 'rumpo', pi = 'tailgater',
}

-- Gestes des interventions et des tâches sur place
JOB_WORK_ANIM = { construction = 'WORLD_HUMAN_HAMMERING', electrician = 'WORLD_HUMAN_WELDING', plumber = 'WORLD_HUMAN_HAMMERING', gardener = 'WORLD_HUMAN_GARDENER_PLANT',
    urbanisme = 'WORLD_HUMAN_CONST_DRILL', cleaning = 'WORLD_HUMAN_MAID_CLEAN' }
JOB_TASKS = {
    resto = { { 'Prendre une commande', 'WORLD_HUMAN_CLIPBOARD' }, { 'Préparer en cuisine', 'PROP_HUMAN_BBQ' }, { 'Nettoyer les tables', 'WORLD_HUMAN_MAID_CLEAN' }, { 'Servir au comptoir', 'mp_common|givetake1_a' } },
    auto = { { 'Laver un véhicule', 'WORLD_HUMAN_MAID_CLEAN' }, { 'Inspecter un véhicule', 'WORLD_HUMAN_CLIPBOARD' }, { 'Ranger l\'atelier', 'anim@heists@box_carry@|idle' }, { 'Renseigner un client', 'WORLD_HUMAN_STAND_MOBILE' } },
    default = { { 'Accueillir un client', 'WORLD_HUMAN_CLIPBOARD' }, { 'Ranger le stock', 'anim@heists@box_carry@|idle' }, { 'Nettoyer', 'WORLD_HUMAN_MAID_CLEAN' }, { 'Passer des appels', 'WORLD_HUMAN_STAND_MOBILE' }, { 'Classer des dossiers', 'PROP_HUMAN_PARKING_METER' } },
}
