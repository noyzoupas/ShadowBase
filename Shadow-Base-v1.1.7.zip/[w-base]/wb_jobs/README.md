# wb_jobs — petits jobs des entreprises (extension Shadow Base)

Chaque entreprise a des missions adaptées à son métier. Un employé **en service** appuie sur **O** (ou tape `/jobs`) près de son entreprise, choisit une mission et suit le GPS étape par étape.
Extension de `pb_panel` : redémarrable seule (`restart wb_jobs`). Réglages : **panel › Extensions › Petits jobs**.

## Missions
| Mission | Déroulement | Véhicule fourni | Exemples d'entreprises |
|---|---|---|---|
| Service sur place | Tâches aux postes de l'entreprise (commande, cuisine, ménage, rangement…) | à pied | bars, boutiques, banque, casino, salle de sport |
| Livraisons | Charger les colis puis livrer les clients à leur porte | Speedo (Boxville pour la Poste) | livraison, poste, boutiques, déménageurs |
| Livraison de repas | Récupérer les commandes, livrer en scooter | Faggio | Burger Shot, pizzeria, sushi, café |
| Courses | Prendre un client au bord de la route, le déposer | Taxi (limousine pour les VTC) | taxi, limousines |
| Dépannages | Réparer des voitures en panne (capot ouvert, conducteur qui attend) | dépanneuse | LS Customs, carrosserie, fourrière |
| Patrouille | Points de contrôle en ville | voiture de police de l'entreprise | LSPD, shérif, FIB, gardes forestiers, sécurité |
| Appels de secours | Soigner des victimes au sol (massage cardiaque) | ambulance (camion pour les pompiers) | EMS, pompiers, clinique |
| Interventions | Travaux chez les clients (marteau, soudure, jardinage, ménage…) | utilitaire | BTP, électricien, plombier, jardinier |
| Tournée des poubelles | Ramasser les sacs du quartier | benne | éboueurs |
| Reportages | Photos / vidéo sur les lieux | van Weazel | Weazel News, journal, radio |
| Transport | Charger la cargaison, livrer loin | camion | transport routier, port, ferme, mine, bûcherons |
| Convoyage | Livrer une voiture vendue à son client | la voiture du client | concessions, location |

L'onglet **Catalogue** montre les missions de chaque entreprise ; **Missions par entreprise** les remplace (ex. `burgershot` → `repas,service,livraison`).

## Paie
Chaque étape est payée (base + bonus au kilomètre) ; l'entreprise touche en plus un bonus (25 % par défaut) sur son compte. Montants, compte (banque / espèces), plafond horaire, pause entre deux missions : onglet **Réglages**.

## Sécurité
Le serveur vérifie : service en cours, distance de l'entreprise au départ, distance entre deux étapes, position à l'arrivée, temps de trajet minimum, plafond par heure. Quitter son service arrête la mission.

## Évènement serveur
`wb_jobs:done` (src, entreprise, mission, total payé)
