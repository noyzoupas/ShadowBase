-- Shadow Base — Petits jobs (client) : menu (O / /jobs), véhicule de service, destinations sur la route, GPS, PNJ (clients, passagers,
-- blessés, automobilistes en panne), gestes et barre de progression. Le serveur valide chaque étape et paie.
local W = exports.pb_panel
local RES = GetCurrentResourceName()

local mission       -- { label, phases, i, last = vector3, target, veh, vehBlip, npcs = {}, passenger }
local blip

local function notify(kind, text) W:Notify({ type = kind, title = 'Petits jobs', text = text }) end
local function d2(a, b) local dx, dy = a.x - b.x, a.y - b.y return math.sqrt(dx * dx + dy * dy) end
local function objective(text)
    BeginTextCommandPrint('STRING') AddTextComponentSubstringPlayerName(text) EndTextCommandPrint(7000, true)
end
local function loadModel(m)
    local h = type(m) == 'number' and m or joaat(m)
    if not IsModelInCdimage(h) then return nil end
    RequestModel(h)
    local t = GetGameTimer() + 5000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
    return HasModelLoaded(h) and h or nil
end
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
local function del(e) if e and DoesEntityExist(e) then SetEntityAsMissionEntity(e, true, true) DeleteEntity(e) end end
local function later(e, ms) SetTimeout(ms, function() del(e) end) end

-- Menu -------------------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand('jobs', function() TriggerServerEvent(RES .. ':menu') end, false)
RegisterKeyMapping('jobs', "Petits jobs de l'entreprise", 'keyboard', 'O')

RegisterNetEvent(RES .. ':menu', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    local items = {}
    if d.active then
        items[#items + 1] = { label = d.active.label, icon = 'briefcase', right = ('%d/%d'):format(math.min(d.active.i, d.active.n), d.active.n), description = ('Mission en cours : $%d gagnés pour le moment.'):format(d.active.earned), disabled = true }
        items[#items + 1] = { label = 'Abandonner la mission', icon = 'x', description = 'Le véhicule de service est rendu ; les étapes faites restent payées.', onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':stop') end }
    else
        if not d.duty then items[#items + 1] = { label = 'Prends ton service', icon = 'clock', description = 'Les missions ne se lancent qu\'en service.', disabled = true } end
        for _, t in ipairs(d.list or {}) do
            items[#items + 1] = { label = t.label, icon = t.icon, right = t.veh and 'véhicule fourni' or nil, description = t.desc, disabled = (not d.duty) or nil,
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':start', t.id) end }
        end
        if #(d.list or {}) == 0 then items[#items + 1] = { label = 'Aucune mission pour ce métier', disabled = true } end
    end
    W:OpenMenu({ id = RES .. '.menu', title = d.biz or 'Entreprise', subtitle = 'Petits jobs', items = items })
end)

-- Destinations : un point au bord d'une route, à bonne distance du précédent ------------------------------------------------------------------------------
local nodesLoaded = false
local function findDest(from, range)
    if not nodesLoaded then pcall(LoadAllPathNodes, true) nodesLoaded = true end
    for _ = 1, 40 do
        local a = math.random() * math.pi * 2
        local dist = range[1] + math.random() * (range[2] - range[1])
        local x, y = from.x + math.cos(a) * dist, from.y + math.sin(a) * dist
        if x > -3800 and x < 4200 and y > -3800 and y < 7800 then
            local ok, node, heading = GetClosestVehicleNodeWithHeading(x, y, from.z + 0.0, 1, 3.0, 0)
            if ok and node then
                local dd = d2(node, from)
                if dd >= range[1] * 0.6 and dd <= range[2] * 1.4 then
                    local ok2, side = GetPointOnRoadSide(node.x, node.y, node.z, 1)
                    local p = (ok2 and side and d2(side, node) < 15.0) and side or node
                    return vector3(p.x, p.y, p.z), heading or 0.0
                end
            end
        end
        Wait(0)
    end
    return nil
end

-- Fin de mission --------------------------------------------------------------------------------------------------------------------------------------------
local function clearBlip() if blip and DoesBlipExist(blip) then SetBlipRoute(blip, false) RemoveBlip(blip) end blip = nil end
local function cleanup()
    if not mission then return end
    local m = mission
    mission = nil
    clearBlip()
    W:HidePrompt()
    if m.vehBlip and DoesBlipExist(m.vehBlip) then RemoveBlip(m.vehBlip) end
    for _, e in ipairs(m.npcs) do later(e, 15000) end
    if m.passenger then later(m.passenger, 15000) end
    local v = m.veh
    if v and DoesEntityExist(v) then
        local ped = PlayerPedId()
        if GetVehiclePedIsIn(ped, false) == v then TaskLeaveVehicle(ped, v, 0) SetTimeout(2500, function() del(v) end) else del(v) end
    end
end
RegisterNetEvent(RES .. ':ended', function(done, reason)
    if not mission then return end
    cleanup()
    if not done then notify('info', 'Mission arrêtée' .. ((reason or '') ~= '' and (' (' .. reason .. ')') or '') .. '.') end
end)
AddEventHandler('onResourceStop', function(res) if res == RES then cleanup() end end)

-- Véhicule de service ------------------------------------------------------------------------------------------------------------------------------------
local function spawnVehicle(model)
    local h = loadModel(model)
    if not h then return nil end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local ok, node, heading = GetClosestVehicleNodeWithHeading(c.x, c.y, c.z, 1, 3.0, 0)
    local p, hd = c + GetEntityForwardVector(ped) * 4.0, GetEntityHeading(ped)
    if ok and node and #(node - c) < 60.0 then p, hd = node, heading end
    local v = CreateVehicle(h, p.x, p.y, p.z + 0.5, hd + 0.0, true, false)
    SetModelAsNoLongerNeeded(h)
    if not v or v == 0 then return nil end
    SetVehicleOnGroundProperly(v)
    SetVehicleNumberPlateText(v, ('JOB%05d'):format(math.random(0, 99999)))
    SetVehicleDirtLevel(v, 0.0)
    SetVehicleEngineOn(v, false, true, false)
    SetEntityAsMissionEntity(v, true, true)
    return v
end

-- PNJ des étapes -------------------------------------------------------------------------------------------------------------------------------------------
local CIVS = { 'a_m_y_business_02', 'a_f_y_business_01', 'a_m_m_bevhills_01', 'a_f_m_bevhills_01', 'a_m_y_hipster_01', 'a_f_y_hipster_02', 'a_m_m_eastsa_01', 'a_f_y_tourist_01', 'a_m_y_stbla_02', 'a_f_m_downtown_01' }
local CARS = { 'asea', 'blista', 'premier', 'ingot', 'stanier', 'primo', 'emperor', 'regina', 'tailgater', 'washington' }
local function spawnPed(model, p, h)
    local m = loadModel(model or CIVS[math.random(#CIVS)])
    if not m then return nil end
    local ped = CreatePed(4, m, p.x, p.y, p.z, h or 0.0, false, true)
    SetModelAsNoLongerNeeded(m)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedFleeAttributes(ped, 0, false)
    SetPedKeepTask(ped, true)
    return ped
end
local function ground(p)
    local ok, z = GetGroundZFor_3dCoord(p.x, p.y, p.z + 2.0, false)
    return vector3(p.x, p.y, ok and z or p.z)
end

local function prepareStage(ph, t)
    local m = mission
    if ph.npc == 'customer' or ph.npc == 'passenger_in' then
        local ped = spawnPed(nil, ground(t), math.random(0, 359) + 0.0)
        if ped then
            TaskStartScenarioInPlace(ped, ph.npc == 'customer' and 'WORLD_HUMAN_STAND_IMPATIENT' or 'WORLD_HUMAN_STAND_MOBILE', 0, true)
            m.npcs[#m.npcs + 1] = ped
            m.stageNpc = ped
        end
    elseif ph.npc == 'injured' then
        local ped = spawnPed(nil, ground(t), 0.0)
        if ped then
            SetEntityInvincible(ped, true)
            if loadDict('combat@damage@writhe') then TaskPlayAnim(ped, 'combat@damage@writhe', 'writhe_loop', 8.0, -8.0, -1, 1, 0, false, false, false) end
            m.npcs[#m.npcs + 1] = ped
            m.stageNpc = ped
        end
    elseif ph.npc == 'stranded' then
        local h = loadModel(CARS[math.random(#CARS)])
        if h then
            local car = CreateVehicle(h, t.x, t.y, t.z + 0.5, (m.heading or 0.0) + 0.0, false, true)
            SetModelAsNoLongerNeeded(h)
            SetVehicleOnGroundProperly(car)
            SetVehicleDoorOpen(car, 4, false, false)
            SetVehicleEngineHealth(car, 150.0)
            SetVehicleUndriveable(car, true)
            SetVehicleIndicatorLights(car, 0, true) SetVehicleIndicatorLights(car, 1, true)
            m.npcs[#m.npcs + 1] = car
            m.stageCar = car
            local side = GetOffsetFromEntityInWorldCoords(car, 2.2, 1.5, 0.0)
            local ped = spawnPed(nil, ground(side), GetEntityHeading(car))
            if ped then TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_STAND_MOBILE', 0, true) m.npcs[#m.npcs + 1] = ped m.stageNpc = ped end
        end
    end
end

-- Geste + objet en main + barre ; annulable (X, s'éloigner, mourir) : l'étape reste à faire
local function attachProp(ped, model)
    local h = loadModel(model)
    if not h then return nil end
    local c = GetEntityCoords(ped)
    local o = CreateObject(h, c.x, c.y, c.z + 0.2, true, true, false)
    local box = model:find('box') ~= nil
    AttachEntityToEntity(o, ped, GetPedBoneIndex(ped, box and 28422 or 57005), box and 0.0 or 0.12, box and -0.05 or 0.0, box and -0.05 or -0.02, box and 0.0 or -80.0, 0.0, 0.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(h)
    return o
end
local function act(ph, at)
    local ped = PlayerPedId()
    local anim = tostring(ph.anim or '')
    local dict, clip = anim:match('^([^|]+)|(.+)$')
    if dict then if loadDict(dict) then TaskPlayAnim(ped, dict, clip, 3.0, 3.0, -1, 49, 0, false, false, false) end
    elseif anim ~= '' then TaskStartScenarioInPlace(ped, anim, 0, true) end
    local prop = (ph.prop or '') ~= '' and attachProp(ped, ph.prop) or nil
    local npc = mission and mission.stageNpc
    if npc and DoesEntityExist(npc) and ph.npc == 'customer' then
        ClearPedTasks(npc) TaskTurnPedToFaceEntity(npc, ped, 1500)
        if loadDict('mp_common') then SetTimeout(900, function() if DoesEntityExist(npc) then TaskPlayAnim(npc, 'mp_common', 'givetake1_b', 8.0, -8.0, 1500, 49, 0, false, false, false) end end) end
    end
    W:Progress(ph.label, ph.secs or 3)
    local stop, cancelled = GetGameTimer() + math.floor((ph.secs or 3) * 1000), false
    while GetGameTimer() < stop do
        Wait(0)
        DisableControlAction(0, 24, true) DisableControlAction(0, 25, true)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) or #(GetEntityCoords(ped) - at) > 8.0 then cancelled = true break end
    end
    ClearPedTasks(ped)
    del(prop)
    if cancelled then W:CancelProgress() notify('warn', 'Action annulée : recommence avec E.') return false end
    return true
end

-- Après l'étape : réactions des PNJ
local function afterStage(ph)
    local m = mission
    if not m then return end
    local npc, car = m.stageNpc, m.stageCar
    m.stageNpc, m.stageCar = nil, nil
    if ph.npc == 'customer' and npc and DoesEntityExist(npc) then ClearPedTasks(npc) TaskWanderStandard(npc, 10.0, 10) later(npc, 20000)
    elseif ph.npc == 'injured' and npc and DoesEntityExist(npc) then ClearPedTasks(npc) PlayPedAmbientSpeechNative(npc, 'GENERIC_THANKS', 'SPEECH_PARAMS_FORCE') TaskWanderStandard(npc, 10.0, 10) later(npc, 25000)
    elseif ph.npc == 'stranded' and car and DoesEntityExist(car) then
        SetVehicleFixed(car) SetVehicleEngineHealth(car, 1000.0) SetVehicleUndriveable(car, false) SetVehicleDoorShut(car, 4, false)
        SetVehicleIndicatorLights(car, 0, false) SetVehicleIndicatorLights(car, 1, false)
        if npc and DoesEntityExist(npc) then
            ClearPedTasks(npc) PlayPedAmbientSpeechNative(npc, 'GENERIC_THANKS', 'SPEECH_PARAMS_FORCE')
            TaskEnterVehicle(npc, car, 10000, -1, 1.0, 1, 0)
            SetTimeout(9000, function() if DoesEntityExist(npc) and DoesEntityExist(car) then TaskVehicleDriveWander(npc, car, 15.0, 786603) end end)
        end
        later(car, 45000) later(npc, 45000)
    end
end

-- Déroulé d'une mission -------------------------------------------------------------------------------------------------------------------------------------
local function requestTarget()
    local m = mission
    if not m then return end
    local ph = m.phases[m.i]
    m.target, m.waiting = nil, true
    if ph.kind == 'drive' or ph.kind == 'stop' then
        local p, h = findDest(m.last, ph.range)
        if not p then notify('error', 'Aucune destination trouvée : mission arrêtée.') TriggerServerEvent(RES .. ':stop') return end
        m.heading = h
        TriggerServerEvent(RES .. ':target', m.i, p.x, p.y, p.z)
    else
        local c = GetEntityCoords(PlayerPedId())
        TriggerServerEvent(RES .. ':target', m.i, c.x, c.y, c.z)
    end
end
-- étape refusée par le serveur (trop loin, trop tôt) : le point reste à faire
RegisterNetEvent(RES .. ':retry', function(i, why)
    local m = mission
    if not m or m.i ~= i or not m.sent then return end
    m.target, m.hold = m.sent, GetGameTimer() + 2000
    if (why or '') ~= '' then notify('warn', why) end
end)
RegisterNetEvent(RES .. ':retarget', function(i) if mission and mission.i == i then requestTarget() end end)

RegisterNetEvent(RES .. ':goto', function(i, x, y, z)
    local m = mission
    if not m or m.i ~= i then return end
    local ph = m.phases[i]
    m.target, m.waiting, m.prepared = vector3(x, y, z), false, false
    if ph.kind == 'service' and #(m.target - GetEntityCoords(PlayerPedId())) < 1.0 then
        -- pas de poste posé pour l'entreprise : une tâche à quelques pas
        local a = math.random() * math.pi * 2
        m.target = ground(vector3(x + math.cos(a) * 4.0, y + math.sin(a) * 4.0, z))
    end
    clearBlip()
    if ph.kind ~= 'here' then
        blip = AddBlipForCoord(m.target.x, m.target.y, m.target.z)
        SetBlipSprite(blip, 1) SetBlipColour(blip, 5) SetBlipScale(blip, 0.9)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(ph.goal) EndTextCommandSetBlipName(blip)
        if ph.kind ~= 'service' then SetBlipRoute(blip, true) SetBlipRouteColour(blip, 5) end
    end
    objective(('%s (%d/%d)'):format(ph.goal, i, #m.phases))
end)

RegisterNetEvent(RES .. ':advance', function(i, pay)
    local m = mission
    if not m then return end
    if (pay or 0) > 0 then notify('success', ('+$%d'):format(pay)) end
    m.last = m.sent or GetEntityCoords(PlayerPedId())
    m.i = i
    requestTarget()
end)

RegisterNetEvent(RES .. ':begin', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' or mission then return end
    local c = GetEntityCoords(PlayerPedId())
    mission = { label = d.label, phases = d.phases, i = 1, last = c, npcs = {} }
    notify('info', ('%s : %d étapes. Suis le GPS. O pour abandonner.'):format(d.label, #d.phases))
    if d.veh then
        local v = spawnVehicle(d.veh)
        if v then
            mission.veh = v
            local b = AddBlipForEntity(v)
            SetBlipSprite(b, 225) SetBlipColour(b, 3) SetBlipScale(b, 0.7)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Véhicule de service') EndTextCommandSetBlipName(b)
            mission.vehBlip = b
        end
    end
    requestTarget()
end)

-- Boucle : arrivée, invite E, gestes, PNJ ------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local shown
    local function prompt(text) if shown ~= text then shown = text local t = mission and mission.target W:Prompt(text, 'E', t and t.x, t and t.y, t and t.z) end end
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local m = mission
        if not m or not m.target or (m.hold and GetGameTimer() < m.hold) then hide() Wait(400)
        else
            Wait(0)
            local ph = m.phases[m.i]
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local veh = GetVehiclePedIsIn(ped, false)
            local dist = #(c - m.target)
            if m.veh and m.vehBlip and DoesBlipExist(m.vehBlip) then SetBlipAlpha(m.vehBlip, veh == m.veh and 0 or 255) end
            if not m.prepared and dist < 150.0 then m.prepared = true prepareStage(ph, m.target) end
            if dist < 60.0 and ph.kind ~= 'stop' then DrawMarker(1, m.target.x, m.target.y, m.target.z - 1.0, 0, 0, 0, 0, 0, 0, 1.6, 1.6, 0.6, 255, 196, 0, 90, false, false, 2, false, nil, nil, false) end
            if ph.kind == 'stop' then
                if dist < 60.0 then DrawMarker(1, m.target.x, m.target.y, m.target.z - 1.0, 0, 0, 0, 0, 0, 0, 6.0, 6.0, 1.0, 255, 196, 0, 70, false, false, 2, false, nil, nil, false) end
                local stopped = veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and GetEntitySpeed(veh) < 3.0
                if dist < 20.0 and stopped then
                    if ph.npc == 'passenger_in' then
                        hide()
                        local p = m.stageNpc
                        m.stageNpc = nil
                        if p and DoesEntityExist(p) then
                            ClearPedTasks(p)
                            TaskEnterVehicle(p, veh, 15000, IsVehicleSeatFree(veh, 2) and 2 or 0, 1.0, 1, 0)
                            local t = GetGameTimer() + 15000
                            while GetVehiclePedIsIn(p, false) ~= veh and GetGameTimer() < t do Wait(200) end
                            if GetVehiclePedIsIn(p, false) ~= veh then SetPedIntoVehicle(p, veh, IsVehicleSeatFree(veh, 2) and 2 or 0) end
                            m.passenger = p
                        end
                        m.sent, m.target = m.target, nil
                        TriggerServerEvent(RES .. ':step', m.i)
                    elseif ph.npc == 'passenger_out' then
                        hide()
                        local p = m.passenger
                        m.passenger = nil
                        if p and DoesEntityExist(p) then
                            TaskLeaveVehicle(p, GetVehiclePedIsIn(p, false), 0)
                            SetTimeout(2500, function() if DoesEntityExist(p) then PlayPedAmbientSpeechNative(p, 'GENERIC_THANKS', 'SPEECH_PARAMS_FORCE') TaskWanderStandard(p, 10.0, 10) end end)
                            later(p, 30000)
                        end
                        m.sent, m.target = m.target, nil
                        TriggerServerEvent(RES .. ':step', m.i)
                    elseif ph.leaveveh then
                        prompt(ph.label)
                        if IsControlJustPressed(0, 38) then
                            hide()
                            TaskLeaveVehicle(ped, veh, 0)
                            Wait(2000)
                            if veh == m.veh then
                                if m.vehBlip and DoesBlipExist(m.vehBlip) then RemoveBlip(m.vehBlip) end
                                m.vehBlip = nil
                                SetVehicleDoorsLocked(veh, 2)
                                later(veh, 8000)
                                m.veh = nil
                            end
                            m.sent, m.target = m.target, nil
                            TriggerServerEvent(RES .. ':step', m.i)
                        end
                    else
                        hide()
                        m.sent, m.target = m.target, nil
                        TriggerServerEvent(RES .. ':step', m.i)
                    end
                else hide() end
            else
                local reach = (ph.kind == 'drive' and 6.0) or (ph.kind == 'here' and 10.0) or 2.5
                if dist < reach and veh == 0 then
                    prompt(ph.label)
                    if IsControlJustPressed(0, 38) then
                        hide()
                        local at = GetEntityCoords(ped)
                        if act(ph, at) and mission == m then
                            afterStage(ph)
                            m.sent, m.target = m.target, nil
                            TriggerServerEvent(RES .. ':step', m.i)
                        end
                    end
                elseif dist < reach and veh ~= 0 then prompt('Descends du véhicule')
                else hide() end
            end
        end
    end
end)
