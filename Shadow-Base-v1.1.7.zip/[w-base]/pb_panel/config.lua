-- Fichier chargé uniquement côté serveur (jamais envoyé aux joueurs).
-- Il ne contient que l'amorçage : tout le reste se règle depuis le panel et est stocké en base.

Config = {}

-- Identifiants "license:" des propriétaires : accès total au panel, impossible à retirer depuis le panel.
-- Tu peux aussi donner l'ACE  add_ace identifier.license:xxxx pb_panel.owner allow  dans ton server.cfg.
Config.Owners = {
    -- 'license:0123456789abcdef0123456789abcdef01234567',
}

-- Coupe de force la liste blanche de Shadow Base (utile si tu es bloqué à la connexion). Remets false ensuite.
Config.DisableWhitelist = false

-- Touche et commande d'ouverture (modifiables en jeu par chaque joueur dans les réglages FiveM).
Config.OpenKey = ''   -- vide : pas de touche par défaut (F10 ouvre le menu staff ; le panel s'ouvre avec /panel ou depuis le menu staff)
Config.OpenCommand = 'panel'

-- Licence : la ressource ne démarre qu'avec une licence valide (fichier license.key à la racine, ou  set wbase_license "WB1...."  dans server.cfg).
-- revocation_url : adresse https d'une liste de révocation signée (facultatif, vide = pas de vérification en ligne) ; check_hours : fréquence.
Config.License = { revocation_url = '', check_hours = 6 }

-- Framework : Shadow Base ne fonctionne qu'avec « wframework » (ressource fournie à côté, à lancer avant pb_panel). ESX, QBCore, Qbox et les
-- inventaires externes (ox_inventory, qb-inventory...) sont arrêtés automatiquement. Aucun réglage : c'est voulu.

-- Chemin du dossier du serveur (celui qui contient server.cfg et resources/).
-- Laisse vide pour la détection automatique ; renseigne-le si le panel dit qu'il ne trouve pas server.cfg.
Config.ServerPath = ''

-- Superviseur qui relance le serveur après un `quit` : 'txadmin', 'autre' (systemd, pm2, Docker...) ou 'aucun'.
-- Les redémarrages programmés sont désactivés tant que ce n'est pas 'txadmin' ou 'autre'.
Config.Supervisor = 'txadmin'

-- Pont vers ta librairie admin existante (voir README, section « Librairie admin »).
-- mode 'ace'    : les grades du panel sont poussés en groupes ACE (group.pb_<grade>) lus par la plupart des librairies.
-- mode 'export' : le panel appelle des exports de ta librairie (noms à renseigner ci-dessous, tous optionnels).
Config.AdminLib = {
    mode = 'ace',
    resource = '',           -- nom de la ressource de ta librairie admin
    -- Noms des exports de ta librairie (laisse '' ce que ta librairie ne fournit pas). Modifiables depuis le panel.
    exports = {
        listGrades = '',       -- function() -> { { name=, label=, priority= }, ... }
        saveGrade = '',        -- function(grade) -> boolean   (grade = { name, label, priority, color, parent, permissions })
        deleteGrade = '',      -- function(name) -> boolean
        setPlayerGrade = '',   -- function(license, nomDuGrade|nil) -> boolean
        listPermissions = '',  -- function() -> { { perm=, label= }, ... }
        setLayout = '',        -- facultatif : function({ x=, y=, scale=, opacity= }) pour positionner le menu de la librairie
    },
}

Config.Debug = false

-- Mises à jour : adresse du fichier latest.json publié (GitHub Pages), vérifié toutes les check_hours heures.
-- La signature est contrôlée avec la clé de licence : un fichier modifié est refusé. Vide = pas de vérification.
-- (On peut aussi la donner dans server.cfg :  set wbase_update_url "https://…/latest.json")
Config.Update = { url = '', check_hours = 6 }
