-- Vendeurs des supérettes de GTA : position DERRIÈRE le comptoir (x, y, z, cap) de chaque 24/7, LTD et Rob's Liquor de la carte.
-- Un magasin ou un braquage posé à moins de 25 m d'une de ces boutiques y place son vendeur automatiquement.
-- Builder › « position du vendeur » remplace cette position pour un magasin ou un braquage précis.
PB = PB or {}

PB.CLERKS = {
    -- 24/7
    { 24.47, -1346.62, 29.50, 271.7 },  { -3039.54, 584.38, 7.91, 17.3 },  { -3242.97, 1000.01, 12.83, 357.6 }, { 1728.07, 6415.63, 35.04, 243.0 },
    { 1959.82, 3740.48, 32.34, 301.6 }, { 549.13, 2670.85, 42.16, 99.4 },  { 2677.47, 3279.76, 55.24, 335.1 },  { 2556.66, 380.84, 108.62, 356.7 },
    { 372.66, 326.98, 103.57, 253.7 },
    -- LTD Gasoline
    { -47.02, -1758.23, 29.42, 45.1 },  { -706.06, -913.97, 19.22, 88.0 }, { -1820.02, 794.03, 138.09, 135.5 }, { 1164.71, -322.94, 69.21, 101.7 },
    { 1697.87, 4922.96, 42.06, 324.7 },
    -- Rob's Liquor
    { -1221.58, -908.15, 12.33, 35.5 }, { -1486.59, -377.68, 40.16, 139.5 }, { -2966.39, 391.42, 15.04, 87.5 }, { 1165.17, 2710.88, 38.16, 179.4 },
    { 1134.20, -982.91, 46.42, 277.2 },
}

-- Position du vendeur de la supérette la plus proche de (x, y, z), ou nil s'il n'y en a pas à moins de maxd mètres
function PB.ClerkSpot(x, y, z, maxd)
    x, y, z = tonumber(x), tonumber(y), tonumber(z) or 0
    if not x or not y then return nil end
    local best, bd = nil, (maxd or 25.0) ^ 2
    for _, c in ipairs(PB.CLERKS) do
        local d = (c[1] - x) ^ 2 + (c[2] - y) ^ 2
        if d < bd and math.abs(c[3] - z) < 12.0 then best, bd = c, d end
    end
    if not best then return nil end
    return { x = best[1], y = best[2], z = best[3], h = best[4] }
end
