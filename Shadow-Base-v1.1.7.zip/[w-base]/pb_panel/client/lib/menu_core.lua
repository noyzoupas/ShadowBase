-- pb_menu — cœur de la bibliothèque de menu (style « RageUI ») : logique pure, sans native GTA, donc testable.
-- Un menu a un titre, un sous-titre, des éléments (bouton, liste, case à cocher, curseur, saisie, séparateur, sous-menu).
-- Navigation : haut / bas (avec bouclage), gauche / droite (listes, curseurs, cases), entrée, retour.
-- Le rendu (NUI) et les touches sont dans client/menu.lua ; ce fichier ne fait que calculer l'état à afficher.

PBMenuCore = {}
local C = PBMenuCore

local function callable(f)
    if type(f) == 'function' then return true end
    if type(f) == 'table' then local mt = getmetatable(f) return mt ~= nil and mt.__call ~= nil end
    return false
end
C.callable = callable

local function safe(f, ...)
    if not callable(f) then return nil end
    local ok, a, b = pcall(f, ...)
    if not ok then if print then print('[pb_menu] erreur dans un rappel : ' .. tostring(a)) end return nil end
    return a, b
end

local KINDS = { button = true, list = true, checkbox = true, slider = true, input = true, separator = true, submenu = true }

local function clampN(v, lo, hi) v = tonumber(v) or lo if v < lo then return lo elseif v > hi then return hi end return v end

-- Copie « utile » d'un élément : on garde les rappels par référence (pas de copie profonde des fonctions)
local function normItem(raw)
    if type(raw) ~= 'table' then return nil end
    if raw.hidden then return nil end
    local it = {}
    for k, v in pairs(raw) do it[k] = v end
    it.type = KINDS[it.type] and it.type or (it.submenu and 'submenu' or 'button')
    it.label = tostring(it.label or '')
    if it.type == 'list' then
        it.list = type(it.list) == 'table' and it.list or {}
        it.index = clampN(it.index or 1, 1, math.max(1, #it.list))
    elseif it.type == 'slider' then
        it.min = tonumber(it.min) or 0
        it.max = tonumber(it.max) or 100
        if it.max < it.min then it.max = it.min end
        it.step = tonumber(it.step) or 1
        it.value = clampN(it.value or it.min, it.min, it.max)
    elseif it.type == 'checkbox' then
        it.checked = it.checked and true or false
    end
    return it
end

local function selectable(it) return it.type ~= 'separator' end

-- Menu ----------------------------------------------------------------------------------------------------------------------------------
local Menu = {}
Menu.__index = Menu

function Menu:rebuild(keepSel)
    local list = self.def.items
    if callable(self.def.build) then
        local ok, res = pcall(self.def.build, self)
        if ok and type(res) == 'table' then list = res end
    end
    local oldSel = self.sel
    self.items = {}
    for _, raw in ipairs(list or {}) do
        local it = normItem(raw)
        if it then self.items[#self.items + 1] = it end
    end
    if not keepSel then oldSel = 1 end
    self.sel = math.max(1, math.min(oldSel or 1, math.max(1, #self.items)))
    self:fixSel(1)
end

-- place la sélection sur un élément sélectionnable (dir : sens de recherche)
function Menu:fixSel(dir)
    local n = #self.items
    if n == 0 then self.sel = 1 return end
    for _ = 1, n do
        if selectable(self.items[self.sel]) then return end
        self.sel = ((self.sel - 1 + dir) % n) + 1
    end
end

function Menu:selectableCount()
    local c = 0
    for _, it in ipairs(self.items) do if selectable(it) then c = c + 1 end end
    return c
end
function Menu:selectableIndex()
    local c = 0
    for i = 1, self.sel do if self.items[i] and selectable(self.items[i]) then c = c + 1 end end
    return c
end

-- Une ligne telle que l'interface la reçoit (utilisée par le rendu « lib » et par le rendu « UI »)
function C.RowOf(it, active)
    local row = { label = it.label, kind = it.type, icon = it.icon, right = it.right, badge = it.badge, disabled = it.disabled and true or nil, active = active or nil }
    if it.type == 'list' then row.value = tostring(it.list[it.index] ~= nil and (type(it.list[it.index]) == 'table' and (it.list[it.index].label or it.list[it.index][1]) or it.list[it.index]) or '') row.count = #it.list row.pos = it.index
    elseif it.type == 'slider' then row.value = it.value row.min = it.min row.max = it.max
    elseif it.type == 'checkbox' then row.checked = it.checked
    elseif it.type == 'input' then row.value = it.value and tostring(it.value) or nil end
    return row
end

-- Pile de menus ------------------------------------------------------------------------------------------------------------------------
function C.NewStack(opts)
    opts = opts or {}
    local S = { menus = {}, maxVisible = opts.maxVisible or 10, wrap = opts.wrap ~= false }

    function S:IsOpen() return #self.menus > 0 end
    function S:Current() return self.menus[#self.menus] end
    function S:Depth() return #self.menus end

    function S:Open(def)
        if type(def) ~= 'table' then return false end
        local m = setmetatable({ def = def, items = {}, sel = 1, top = 1 }, Menu)
        m:rebuild(false)
        if tonumber(def.sel) and m.items[def.sel] then m.sel = math.floor(def.sel) m:fixSel(1) end   -- ligne choisie à l'ouverture
        self.menus[#self.menus + 1] = m
        safe(def.onOpen, m)
        return true
    end

    function S:Close()
        while #self.menus > 0 do
            local m = table.remove(self.menus)
            safe(m.def.onClose, m)
        end
        return 'back'
    end

    function S:Back()
        local m = self:Current()
        if not m then return nil end
        if m.def.canBack and callable(m.def.canBack) and safe(m.def.canBack, m) == false then return 'error' end
        if #self.menus == 1 then
            if m.def.closable == false then return 'error' end
            return self:Close()
        end
        table.remove(self.menus)
        safe(m.def.onBack, m)
        safe(m.def.onClose, m)
        local p = self:Current()
        if p and p.def.refreshOnReturn then p:rebuild(true) end
        return 'back'
    end

    function S:Move(dir)
        local m = self:Current()
        if not m or #m.items == 0 or m:selectableCount() <= 1 then return nil end
        local n = #m.items
        local i = m.sel
        for _ = 1, n do
            i = i + dir
            if i < 1 then if not self.wrap then return nil end i = n elseif i > n then if not self.wrap then return nil end i = 1 end
            if selectable(m.items[i]) then break end
        end
        m.sel = i
        local it = m.items[i]
        safe(m.def.onHover, it, m)
        return 'nav'
    end

    function S:Change(dir)
        local m = self:Current()
        local it = m and m.items[m.sel]
        if not it or it.disabled then return nil end
        if it.type == 'list' and #it.list > 0 then
            local n = #it.list
            it.index = ((it.index - 1 + dir) % n) + 1
            safe(it.onChange, it, it.list[it.index], it.index, m)
            return 'change'
        elseif it.type == 'slider' then
            local v = clampN(it.value + dir * it.step, it.min, it.max)
            if v == it.value then return nil end
            it.value = v
            safe(it.onChange, it, v, m)
            return 'change'
        elseif it.type == 'checkbox' then
            it.checked = dir > 0
            safe(it.onChange, it, it.checked, m)
            return 'change'
        end
        return nil
    end

    -- Retourne le son à jouer et, pour une saisie, la demande { input = item }
    function S:Select()
        local m = self:Current()
        local it = m and m.items[m.sel]
        if not it or it.type == 'separator' then return nil end
        if it.disabled then return 'error' end
        if it.type == 'checkbox' then
            it.checked = not it.checked
            safe(it.onChange, it, it.checked, m)
            return 'select'
        elseif it.type == 'input' then
            return 'select', { input = it, menu = m }
        elseif it.type == 'submenu' or it.submenu then
            local sub = it.submenu
            if callable(sub) then sub = safe(sub, it, m) end
            if type(sub) == 'table' then
                safe(it.onSelect, it, m)
                self:Open(sub)
                return 'select'
            end
            return 'error'
        elseif it.type == 'list' then
            safe(it.onSelect, it, it.list[it.index], it.index, m)
            return 'select'
        elseif it.type == 'slider' then
            safe(it.onSelect, it, it.value, m)
            return 'select'
        end
        safe(it.onSelect, it, m)
        return 'select'
    end

    -- Résultat d'une saisie au clavier (nil = annulée)
    function S:SetInput(item, text)
        if text == nil then return nil end
        local maxlen = tonumber(item.maxlen) or 120
        text = tostring(text):sub(1, maxlen)
        item.value = text
        safe(item.onChange, item, text, self:Current())
        safe(item.onSelect, item, text, self:Current())
        return 'select'
    end

    function S:Rebuild() local m = self:Current() if m then m:rebuild(true) end end

    -- État à envoyer à l'interface (fenêtre glissante de maxVisible éléments)
    function S:Snapshot()
        local m = self:Current()
        if not m then return nil end
        local n = #m.items
        local maxv = math.max(3, tonumber(m.def.maxVisible) or self.maxVisible)
        if m.sel < m.top then m.top = m.sel end
        if m.sel >= m.top + maxv then m.top = m.sel - maxv + 1 end
        if m.top < 1 then m.top = 1 end
        if n <= maxv then m.top = 1 end
        local last = math.min(n, m.top + maxv - 1)
        local out = {}
        for i = m.top, last do
            local it = m.items[i]
            local row = C.RowOf(it, i == m.sel)
            out[#out + 1] = row
        end
        local cur = m.items[m.sel]
        local snap = {
            id = m.def.id, title = m.def.title or '', subtitle = m.def.subtitle,
            items = out, sel = m.sel - m.top + 1,
            counter = { m:selectableIndex(), m:selectableCount() },
            desc = cur and cur.description or nil,
            up = m.top > 1 or nil, down = last < n or nil,
            depth = #self.menus,
        }
        if m.def.banner then snap.banner = m.def.banner end
        if m.def.hint then snap.hint = m.def.hint end
        return snap
    end

    -- Menu entier (rendu « UI » : toute la liste, pas de fenêtre glissante). `i` = position réelle, utilisée par SetSel.
    function S:Full()
        local m = self:Current()
        if not m then return nil end
        local out, path = {}, {}
        for i, it in ipairs(m.items) do
            local row = C.RowOf(it, i == m.sel)
            row.i = i
            row.desc = it.description
            out[i] = row
        end
        for _, mm in ipairs(self.menus) do path[#path + 1] = mm.def.title or '' end
        local snap = { id = m.def.id, title = m.def.title or '', subtitle = m.def.subtitle, items = out, sel = m.sel, path = path, depth = #self.menus }
        if m.def.banner then snap.banner = m.def.banner end
        return snap
    end

    -- Place la sélection sur l'élément n° i (clic de souris). Refuse un séparateur ou un indice hors liste.
    function S:SetSel(i)
        local m = self:Current()
        i = math.floor(tonumber(i) or 0)
        if not m or not m.items[i] or not selectable(m.items[i]) then return false end
        m.sel = i
        return true
    end

    return S
end

-- Répétition des touches maintenues : retourne true quand il faut agir (appui, puis répétition après `first` ms, puis toutes les `every` ms)
function C.NewRepeater(first, every)
    first, every = first or 380, every or 85
    local st = {}
    return function(key, down, now, f2, e2)
        local first, every = f2 or first, e2 or every
        local s = st[key]
        if not down then st[key] = nil return false end
        if not s then st[key] = { t = now, rep = false } return true end
        local wait = s.rep and every or first
        if now - s.t >= wait then s.t = now s.rep = true return true end
        return false
    end
end

-- Ordre personnalisable ---------------------------------------------------------------------------------------------------------------
-- Les éléments qui ont un `id` peuvent être déplacés ; les autres (séparateurs, en-têtes) restent à leur place.
-- `order` : liste d'identifiants (ordre voulu). Les identifiants inconnus de la liste gardent leur ordre d'origine, après les connus.
function C.SortItems(items, order)
    local rank = {}
    for i, id in ipairs(order or {}) do if rank[id] == nil then rank[id] = i end end
    local slots, movable = {}, {}
    for i, it in ipairs(items) do if it.id then slots[#slots + 1] = i movable[#movable + 1] = { it = it, o = i } end end
    table.sort(movable, function(a, b)
        local ra, rb = rank[a.it.id] or (100000 + a.o), rank[b.it.id] or (100000 + b.o)
        if ra ~= rb then return ra < rb end
        return a.o < b.o
    end)
    local out = {}
    for i, it in ipairs(items) do out[i] = it end
    for k, pos in ipairs(slots) do out[pos] = movable[k].it end
    return out
end

-- Déplace un identifiant dans une liste : 'up', 'down', 'top', 'bottom'. Retourne la nouvelle liste.
function C.MoveId(ids, id, how)
    local list, at = {}, nil
    for i, v in ipairs(ids) do list[i] = v if v == id then at = i end end
    if not at then return list end
    local to = at
    if how == 'up' then to = math.max(1, at - 1) elseif how == 'down' then to = math.min(#list, at + 1)
    elseif how == 'top' then to = 1 elseif how == 'bottom' then to = #list end
    if to ~= at then table.remove(list, at) table.insert(list, to, id) end
    return list
end
