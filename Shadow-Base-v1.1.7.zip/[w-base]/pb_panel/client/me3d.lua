-- Texte au-dessus de la tête : le serveur envoie le texte, on le dessine au-dessus du personnage tant qu'il est valable.
local G = PBG
local texts = {}   -- identifiant serveur -> liste { t, fin }

RegisterNetEvent('pb:g:me3d', function(j)
    local d = G.decode(j)
    if not d or not d.i or type(d.t) ~= 'string' then return end
    local l = texts[d.i] or {}
    texts[d.i] = l
    l[#l + 1] = { t = d.t:sub(1, 120), fin = GetGameTimer() + math.min(20000, tonumber(d.ms) or 6000) }
    while #l > 3 do table.remove(l, 1) end
end)

local function rgb()
    local hex = (G.cfg and G.cfg.me3d and G.cfg.me3d.color) or '#7fd8ff'
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 127, 216, 255 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end

local function draw(x, y, z, text, r, g, b)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.0, 0.36)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(r, g, b, 255)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

CreateThread(function()
    while true do
        if next(texts) == nil then Wait(300) else
            Wait(0)
            local now = GetGameTimer()
            local r, g, b = rgb()
            for sid, l in pairs(texts) do
                for i = #l, 1, -1 do if l[i].fin < now then table.remove(l, i) end end
                if #l == 0 then texts[sid] = nil else
                    local pl = GetPlayerFromServerId(sid)
                    local ped = pl ~= -1 and GetPlayerPed(pl) or 0
                    if ped ~= 0 and DoesEntityExist(ped) and IsEntityVisible(ped) then
                        local c = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
                        for i = 1, #l do draw(c.x, c.y, c.z + 0.55 + (#l - i) * 0.17, l[i].t, r, g, b) end
                    end
                end
            end
        end
    end
end)
