-- Activités illégales : marqueurs, invite E, barre de progression ; le serveur valide le départ et la fin.
local G = PBG
local spots, active = {}, false
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local cr = c.crime or {}
    spots = {}
    if cr.enabled == false then return end
    local function add(kind, list) for _, s in ipairs(list or {}) do spots[#spots + 1] = { kind = kind, id = s.id, label = s.label, x = s.x + 0.0, y = s.y + 0.0, z = s.z + 0.0, r = tonumber(s.radius) or 3.0 } end end
    add('chain', cr.chain) for _, s in ipairs(cr.heists or {}) do spots[#spots + 1] = { kind = 'heist', id = s.id, label = s.label, x = s.x + 0.0, y = s.y + 0.0, z = s.z + 0.0, r = tonumber(s.radius) or 3.0, ped = s.ped, h = s.h, px = tonumber(s.px), py = tonumber(s.py), pz = tonumber(s.pz) } end add('launder', cr.launder)
    G.crimeCfg = cr
end

-- Filière : le geste remplace la barre de progression (récolte : se penche ; transformation : prépare ; vente : échange), joué en boucle pendant l'action
local GESTURE = {
    harvest = { 'pickup_object', 'pickup_low' },
    process = { 'mp_arresting', 'a_uncuff' },
    sell = { 'mp_common', 'givetake1_a' },
}
local function playGesture(kind, secs)
    local g = GESTURE[kind]
    if not g then return false end
    RequestAnimDict(g[1])
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded(g[1]) and GetGameTimer() < t do Wait(10) end
    if not HasAnimDictLoaded(g[1]) then return false end
    CreateThread(function()
        local stop = GetGameTimer() + secs * 1000
        while active and GetGameTimer() < stop do
            TaskPlayAnim(PlayerPedId(), g[1], g[2], 8.0, -8.0, -1, 0, 0, false, false, false)
            local len = math.max(600, math.floor((GetAnimDuration(g[1], g[2]) or 1.0) * 1000))
            Wait(math.min(len, math.max(200, stop - GetGameTimer())))
        end
        RemoveAnimDict(g[1])
    end)
    return true
end

RegisterNetEvent('pb:g:crime:go', function(j)
    local d = G.decode(j)
    if not d then return end
    active = true
    local ped = PlayerPedId()
    local secs = tonumber(d.time) or 5
    local gesture = d.anim and GESTURE[d.anim] ~= nil
    if not gesture then G.send('crime.progress', { label = d.label, secs = secs }) end
    local clerk = G.heistClerk
    G.heistClerk = nil
    local scene
    if clerk and DoesEntityExist(clerk) then scene = G.RobberyScene(clerk, ped, secs)
    elseif not gesture and d.kind == 'heist' then scene = G.LootScene(ped, d.label or '', secs) end
    if gesture then playGesture(d.anim, secs)
    elseif not scene then TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_STAND_IMPATIENT', 0, true) end
    CreateThread(function()
        local t0, ok = GetGameTimer(), true
        while GetGameTimer() - t0 < secs * 1000 do
            Wait(100)
            local p = PlayerPedId()
            local c = GetEntityCoords(p)
            if IsEntityDead(p) or #(c - vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)) > (tonumber(d.radius) or 4.5) then ok = false break end
        end
        active = false
        if scene then scene.stop(ok) end
        ClearPedTasks(PlayerPedId())
        if not gesture then G.send('crime.progress', { cancel = true }) end
        if not ok then G.send('notify', { type = 'warn', title = 'Activité', text = 'Interrompu.' }) end
        TriggerServerEvent('pb:g:crime:end', ok)
    end)
end)

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #spots == 0 or active or G.Menu.IsOpen() then hide() Wait(500)
        else
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(spots) do if s.kind ~= 'heist' then local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end end
            local cr = G.crimeCfg or {}
            if best and bd < 25.0 and cr.show_markers ~= false then G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 255, 255, 255, 1.0) end
            if best and bd <= math.max(best.r, tonumber(cr.use_dist) or 2.5) and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt', { show = true, key = 'E', text = best.label }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:crime:start', best.kind, best.id) end
                Wait(0)
            else hide() Wait(bd and bd < 40 and 150 or 700) end
        end
    end
end)

-- Braquage : on vise le vendeur (arme à feu ou arme blanche) pendant un instant. Le vendeur est le ped du jeu déjà présent au comptoir ;
-- s'il n'y en a pas, on en pose un. Le serveur relit la distance, l'arme en main, les policiers en service et le délai.
local clerks = {}        -- id du point -> ped posé par nous
local MELEE = 2685387236
local function clerkPos(s)
    if s.px and s.py then return s.px, s.py, s.pz or s.z, s.h end
    local c = PB.ClerkSpot(s.x, s.y, s.z)
    if c then return c.x, c.y, c.z, c.h end
    return s.x, s.y, s.z, s.h
end
local found = {}   -- vendeur trouvé dans le décor : mis en cache 1 s (parcourir tous les PNJ à chaque image coûte cher)
local function clerkAt(s)
    local ped = clerks[s.id]
    if ped and DoesEntityExist(ped) and not IsEntityDead(ped) then return ped end
    local f = found[s.id]
    if f and GetGameTimer() < f.t and (not f.ped or (DoesEntityExist(f.ped) and not IsEntityDead(f.ped))) then return f.ped end
    local me = PlayerPedId()
    local best, bd
    local cx, cy, cz = clerkPos(s)
    local pool = GetGamePool and GetGamePool('CPed') or {}
    for _, p in ipairs(pool) do
        if p ~= me and not IsPedAPlayer(p) and not IsPedDeadOrDying(p, true) and not IsPedInAnyVehicle(p, false) then
            local d = #(GetEntityCoords(p) - vector3(cx, cy, cz))
            if d < 4.5 and (not bd or d < bd) then best, bd = p, d end
        end
    end
    found[s.id] = { ped = best, t = GetGameTimer() + 1000 }
    return best
end
local function spawnClerk(s)
    local model = joaat(s.ped ~= nil and s.ped ~= '' and s.ped or 'mp_m_shopkeep_01')
    RequestModel(model)
    local t = GetGameTimer() + 3000
    while not HasModelLoaded(model) and GetGameTimer() < t do Wait(50) end
    if not HasModelLoaded(model) then return end
    local cx, cy, cz, ch = clerkPos(s)
    local ped = CreatePed(4, model, cx, cy, G.Ground(cx, cy, cz), (tonumber(ch) or 0.0) + 0.0, false, false)
    SetEntityInvincible(ped, false) SetBlockingOfNonTemporaryEvents(ped, true) SetPedFleeAttributes(ped, 0, false) FreezeEntityPosition(ped, true)
    SetModelAsNoLongerNeeded(model)
    clerks[s.id] = ped
end
CreateThread(function()
    local hold, shown = 0, nil
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        local sleep = 700
        if G.begun and not active and not G.Menu.IsOpen() then
            local me = PlayerPedId()
            local c = GetEntityCoords(me)
            for _, s in ipairs(spots) do
                if s.kind == 'heist' then
                    local d = #(c - vector3(s.x, s.y, s.z))
                    if d < 45.0 then
                        sleep = 250
                        if not clerkAt(s) and not clerks[s.id] and d < 30.0 then spawnClerk(s) end
                    end
                    if d < s.r + 4.0 and GetVehiclePedIsIn(me, false) == 0 then
                        sleep = 0
                        local ped = clerkAt(s)
                        local _, w = GetCurrentPedWeapon(me, true)
                        local armed = w and w ~= joaat('WEAPON_UNARMED')
                        if ped then
                            if shown ~= s.id then shown = s.id G.send('prompt', { show = true, key = 'RMB', text = armed and ('Vise le vendeur pour braquer : ' .. s.label) or 'Sors une arme (même blanche) et vise le vendeur' }) end
                            local aiming = false
                            if armed then
                                if GetWeapontypeGroup(w) == MELEE then
                                    local dd = #(GetEntityCoords(ped) - c)
                                    local fwd = GetEntityForwardVector(me)
                                    local to = GetEntityCoords(ped) - c
                                    local len = #to
                                    aiming = IsControlPressed(0, 25) and dd < 3.5 and len > 0.01 and ((fwd.x * to.x + fwd.y * to.y) / len) > 0.6
                                else
                                    aiming = IsPlayerFreeAimingAtEntity(PlayerId(), ped)
                                end
                            end
                            if aiming then
                                hold = hold + (GetFrameTime and GetFrameTime() or 0.016)
                                if hold >= 0.7 then
                                    hold = 0 hide()
                                    G.heistClerk = ped
                                    TriggerServerEvent('pb:g:crime:start', 'heist', s.id)
                                    Wait(1500)
                                end
                            else hold = 0 end
                        else hide() end
                    elseif shown == s.id then hide() hold = 0 end
                end
            end
        else hide() end
        Wait(sleep)
    end
end)
-- le vendeur lève les mains pendant le braquage

-- Mise en scène des braquages ----------------------------------------------------------------------------------------------------------------
local function dict(d) RequestAnimDict(d) local t = GetGameTimer() + 1500 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
local function prop(model, ped, bone, pos, rot)
    local h = GetHashKey(model)
    if not IsModelInCdimage(h) then return nil end
    RequestModel(h)
    local t = GetGameTimer() + 1500
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
    if not HasModelLoaded(h) then return nil end
    local c = GetEntityCoords(ped)
    local o = CreateObject(h, c.x, c.y, c.z, false, false, false)
    AttachEntityToEntity(o, ped, GetPedBoneIndex(ped, bone), pos[1], pos[2], pos[3], rot[1], rot[2], rot[3], true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(h)
    return o
end

-- Supérette : le vendeur lève les mains, crie, remplit un sac à la caisse, puis se recroqueville ; le braqueur le tient en joue.
function G.RobberyScene(clerk, robber, secs)
    local alive, bag = true, nil
    FreezeEntityPosition(clerk, false)
    SetBlockingOfNonTemporaryEvents(clerk, true)
    ClearPedTasksImmediately(clerk)
    TaskAimGunAtEntity(robber, clerk, -1, true)                         -- garde l'arme pointée sur le vendeur
    CreateThread(function()
        PlayPedAmbientSpeechNative(clerk, 'GENERIC_FRIGHTENED_HIGH', 'SPEECH_PARAMS_FORCE_SHOUTED')
        if dict('missminuteman_1ig_2') then TaskPlayAnim(clerk, 'missminuteman_1ig_2', 'handsup_base', 4.0, -4.0, -1, 49, 0, false, false, false) end
        Wait(2200)
        if not alive then return end
        -- à la caisse : l'animation de braquage du jeu (le vendeur remplit le sac)
        if dict('mp_am_hold_up') then
            TaskPlayAnim(clerk, 'mp_am_hold_up', 'holdup_victim_20s', 2.0, -2.0, -1, 1, 0, false, false, false)
            bag = prop('p_poly_bag_01_s', clerk, 28422, { 0.05, 0.0, -0.05 }, { 0.0, 0.0, 0.0 })
        end
        local t0 = GetGameTimer()
        while alive and GetGameTimer() - t0 < math.max(0, secs * 1000 - 2400) do
            Wait(1000)
            if math.random() < 0.25 then PlayPedAmbientSpeechNative(clerk, 'GENERIC_FRIGHTENED_MED', 'SPEECH_PARAMS_FORCE') end
        end
    end)
    return { stop = function(ok)
        alive = false
        if bag and DoesEntityExist(bag) then DeleteEntity(bag) end
        if not DoesEntityExist(clerk) then return end
        ClearPedTasks(clerk)
        -- caisse vidée : il se recroqueville derrière le comptoir ; braquage interrompu : il reste les mains levées
        if ok and dict('amb@code_human_cower_stand@male@base') then TaskPlayAnim(clerk, 'amb@code_human_cower_stand@male@base', 'base', 4.0, -4.0, 45000, 1, 0, false, false, false)
        elseif dict('missminuteman_1ig_2') then TaskPlayAnim(clerk, 'missminuteman_1ig_2', 'handsup_base', 4.0, -4.0, 20000, 49, 0, false, false, false) end
        SetTimeout(46000, function() if DoesEntityExist(clerk) then ClearPedTasks(clerk) FreezeEntityPosition(clerk, true) end end)
        if ok and dict('mp_common') then TaskPlayAnim(robber, 'mp_common', 'givetake1_b', 8.0, -8.0, 1500, 49, 0, false, false, false) end
    end }
end

-- Banque / bijouterie (sans vendeur) : le braqueur ramasse les billets ou casse les vitrines en boucle
function G.LootScene(robber, label, secs)
    local l = tostring(label):lower()
    local d, a = 'anim@heists@ornate_bank@grab_cash', 'grab'
    if l:find('bijou', 1, true) or l:find('jewel', 1, true) then d, a = 'missheist_jewel', 'smash_case' end
    local alive = true
    local bag = prop('p_ld_heist_bag_s_1', robber, 24818, { -0.25, -0.25, 0.0 }, { 0.0, 90.0, 180.0 })
    CreateThread(function()
        if not dict(d) then TaskStartScenarioInPlace(robber, 'PROP_HUMAN_BUM_BIN', 0, true) return end
        local stop = GetGameTimer() + secs * 1000
        while alive and GetGameTimer() < stop do
            TaskPlayAnim(robber, d, a, 8.0, -8.0, -1, 0, 0, false, false, false)
            Wait(math.max(800, math.floor((GetAnimDuration(d, a) or 1.5) * 1000)))
        end
    end)
    return { stop = function() alive = false if bag and DoesEntityExist(bag) then DeleteEntity(bag) end end }
end
