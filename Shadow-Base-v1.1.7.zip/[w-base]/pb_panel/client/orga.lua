-- Tablette des organisations : ouverture (touche réglable ou /orga), navigation, GPS. Tout vient du serveur.
local G = PBG
local isOpen = false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end
local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.send('orga.close', {})
end
local function open()
    if isOpen or busy() or not G.begun then return end
    TriggerServerEvent('pb:g:orga:open')
end

RegisterNetEvent('pb:g:orga:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('orga.' .. tostring(d.ev), d)
end)
RegisterNetEvent('pb:g:orga:shut', function() if isOpen then close() end end)
RegisterNetEvent('pb:g:orga:gps', function(j)
    local d = G.decode(j)
    if d and tonumber(d.x) and tonumber(d.y) then SetNewWaypoint(d.x + 0.0, d.y + 0.0) end
end)
G.nui['orga.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:orga:page', tostring(d.page or 'home')) end return {} end
G.nui['orga.act'] = function(d)
    if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:orga:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end
    return {}
end
G.nui['orga.close'] = function() close() return {} end
RegisterCommand('pb_orga', open, false)
RegisterCommand('orga', open, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.tablets and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_orga', 'Ouvrir la tablette des organisations', 'keyboard', (G.cfg.tablets and G.cfg.tablets.orga_key) or 'F7')
end)
CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
