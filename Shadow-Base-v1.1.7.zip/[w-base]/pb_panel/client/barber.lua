-- Coiffeur / barbier : coupe, couleurs, barbe, sourcils, poils, maquillage. Aperçu en direct sur le personnage, caméra sur le visage.
-- Le serveur ne garde que les cheveux et ces détails du visage, revalide tout et encaisse le prix du passage.
local G = PBG

local OV_COLOR = { [1] = 1, [2] = 1, [10] = 1, [5] = 2, [8] = 2 }   -- détail -> type de teinte (1 cheveux, 2 maquillage)
local look, saved, shopId, heading0
local busy = false

local function copy(t) if type(t) ~= 'table' then return t end local o = {} for k, v in pairs(t) do o[k] = copy(v) end return o end

-- applique seulement ce que le coiffeur change (le reste de l'apparence ne bouge pas)
local function preview()
    local ped = PlayerPedId()
    SetPedComponentVariation(ped, 2, look.hair.style, 0, 2)
    SetPedHairColor(ped, look.hair.color, look.hair.highlight)
    for _, idx in ipairs({ 1, 2, 4, 5, 8, 10 }) do
        local o = look.ov[idx + 1]
        if o then
            SetPedHeadOverlay(ped, idx, o.s, o.o + 0.0)
            if OV_COLOR[idx] and o.s ~= 255 then SetPedHeadOverlayColor(ped, idx, OV_COLOR[idx], o.c, o.c) end
        end
    end
end

local function finish(restore)
    if not shopId then return end
    if restore and saved then G.applyAppearance(saved, false) end
    shopId, look, saved, busy = nil, nil, nil, false
    G.barberOpen = false
    local ped = PlayerPedId()
    if heading0 then SetEntityHeading(ped, heading0) end
    ClearPedTasks(ped)
    FreezeEntityPosition(ped, false)
    G.camOff()
    if G.closeShop then G.closeShop() end
end

-- curseur : style d'un détail (0 = aucun), densité (0-10), teinte
local function ovItems(items, title, idx, maxColors)
    local o = look.ov[idx + 1]
    local n = GetPedHeadOverlayNum(idx)
    items[#items + 1] = { type = 'separator', label = title }
    items[#items + 1] = { type = 'slider', label = 'Style', min = 0, max = n, value = o.s == 255 and 0 or (o.s + 1), description = '0 = aucun',
        onChange = function(_, v) o.s = v == 0 and 255 or (v - 1) if o.s ~= 255 and o.o <= 0 then o.o = 1.0 end preview() end }
    items[#items + 1] = { type = 'slider', label = 'Densité', min = 0, max = 10, value = math.floor((o.o or 1) * 10 + 0.5),
        onChange = function(_, v) o.o = v / 10 preview() end }
    if OV_COLOR[idx] then
        items[#items + 1] = { type = 'slider', label = 'Teinte', min = 0, max = math.max(0, maxColors - 1), value = o.c or 0,
            onChange = function(_, v) o.c = v preview() end }
    end
end

function G.openBarber(d)
    if shopId or type(d.appearance) ~= 'table' or type(d.appearance.ov) ~= 'table' then if G.closeShop then G.closeShop() end return end
    shopId, saved, look = d.id, copy(d.appearance), copy(d.appearance)
    local ped = PlayerPedId()
    heading0 = GetEntityHeading(ped)
    FreezeEntityPosition(ped, true)
    G.applyAppearance(saved, false)
    G.setCam('face')
    local hairColors, makeupColors = GetNumHairColors(), GetNumMakeupColors()
    local nHair = GetNumberOfPedDrawableVariations(ped, 2)
    local price = tonumber(d.price) or 0
    local items = {
        { type = 'separator', label = 'Cheveux' },
        { type = 'slider', label = 'Coupe', min = 0, max = math.max(0, nHair - 1), value = look.hair.style, onChange = function(_, v) look.hair.style = v preview() end },
        { type = 'slider', label = 'Couleur', min = 0, max = math.max(0, hairColors - 1), value = look.hair.color, onChange = function(_, v) look.hair.color = v preview() end },
        { type = 'slider', label = 'Reflets', min = 0, max = math.max(0, hairColors - 1), value = look.hair.highlight, onChange = function(_, v) look.hair.highlight = v preview() end },
    }
    ovItems(items, 'Barbe', 1, hairColors)
    ovItems(items, 'Sourcils', 2, hairColors)
    ovItems(items, 'Poils du torse', 10, hairColors)
    ovItems(items, 'Maquillage des yeux', 4, makeupColors)
    ovItems(items, 'Blush', 5, makeupColors)
    ovItems(items, 'Rouge à lèvres', 8, makeupColors)
    items[#items + 1] = { type = 'separator', label = 'Vue' }
    items[#items + 1] = { type = 'slider', label = 'Tourner la tête', min = -3, max = 3, value = 0, description = 'Voir de profil',
        onChange = function(_, v) SetEntityHeading(PlayerPedId(), heading0 + v * 40.0) end }
    items[#items + 1] = { type = 'separator', label = '' }
    items[#items + 1] = { label = price > 0 and ('Valider — %d $'):format(price) or 'Valider', icon = 'check', description = 'Enregistre ta nouvelle tête.',
        onSelect = function()
            if busy or not shopId then return end
            busy = true
            TriggerServerEvent('pb:g:shop:barber', shopId, { hair = look.hair, ov = look.ov })
        end }
    items[#items + 1] = { label = 'Annuler', icon = 'x', description = 'Repars comme tu es venu.', onSelect = function() G.Menu.Close() finish(true) end }
    G.barberOpen = true
    local ok = G.Menu.Open({ id = 'barber', title = d.label or 'Coiffeur', subtitle = d.tagline or 'Coupe, barbe et maquillage', items = items,
        onClose = function() if shopId and not busy then finish(true) end end })
    if not ok then finish(true) end
end

RegisterNetEvent('pb:g:shop:barberOk', function(j)
    local a = G.decode(j)
    if a then G.appearance = a end
    busy = false
    local id = shopId
    shopId = nil   -- évite de restaurer l'ancienne tête à la fermeture du menu
    G.Menu.Close()
    shopId = id
    finish(false)
    if a then G.applyAppearance(a, false) end
end)
RegisterNetEvent('pb:g:shop:cancel', function() if shopId then busy = false end end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and shopId then finish(true) end end)
