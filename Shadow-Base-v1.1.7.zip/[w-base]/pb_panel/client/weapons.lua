-- Armes : le serveur décide quelle arme est équipée ; ici on la met en main, on range, on recharge.
local G = PBG
local cur
RegisterNetEvent('pb:g:weap:equip', function(j)
    local d = G.decode(j)
    if not d or not d.hash then return end
    local ped = PlayerPedId()
    local h = GetHashKey(d.hash)
    if cur then RemoveWeaponFromPed(ped, cur) end
    GiveWeaponToPed(ped, h, tonumber(d.ammo) or 0, false, true)
    SetCurrentPedWeapon(ped, h, true)
    cur = h
end)
RegisterNetEvent('pb:g:weap:holster', function(j)
    local d = G.decode(j)
    local ped = PlayerPedId()
    if d and d.hash then RemoveWeaponFromPed(ped, GetHashKey(d.hash)) end
    if cur then RemoveWeaponFromPed(ped, cur) end
    cur = nil
    SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
end)
RegisterNetEvent('pb:g:weap:ammo', function(j)
    local d = G.decode(j)
    if not d or not d.hash then return end
    AddAmmoToPed(PlayerPedId(), GetHashKey(d.hash), math.floor(tonumber(d.amount) or 0))
end)
