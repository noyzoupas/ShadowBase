-- Actions rapides (F2) : le serveur envoie la liste des entrées autorisées, ce fichier en fait un menu RageUI. Rien n'est décidé ici.
local G = PBG
local spec, targetId = nil, nil

local function notify(t, text) G.send('notify', { type = t, title = 'Actions rapides', text = text }) end

local function targetItem()
    local names, idx = {}, 1
    for i, n in ipairs(spec.near or {}) do
        names[#names + 1] = ('%s (#%d)'):format(n.name, n.id)
        if n.id == targetId then idx = i end
    end
    if #names == 0 then return { type = 'button', label = 'Cible', right = 'Personne à proximité', description = "Rapproche-toi d'un joueur puis rouvre le menu.", disabled = true } end
    if not targetId then targetId = spec.near[1].id end
    return { type = 'list', label = 'Cible', list = names, index = idx, description = 'Joueur proche sur lequel agiront les actions ci-dessous.', onChange = function(_, _, i) local n = spec.near[i] targetId = n and n.id end }
end

local function send(id, payload) TriggerServerEvent('pb:g:quick:act', id, payload or {}) end

local function askInputs(e, payload)
    for _, inp in ipairs(e.inputs or {}) do
        local v = G.Menu.Ask(inp.label, payload[inp.k] and tostring(payload[inp.k]) or '', inp.maxlen or 60)
        if v == nil or v == '' then return false end
        payload[inp.k] = inp.number and tonumber(v) or v
    end
    return true
end

local function entryItem(e)
    if e.type == 'toggle' then
        return { type = 'checkbox', label = e.label, description = e.desc, icon = e.icon, checked = e.on, onChange = function(_, v) send('duty', { on = v }) end }
    end
    local function fire(extra)
        local p = extra or {}
        if e.needs == 'target' then
            if not targetId then notify('warn', "Choisis d'abord une cible.") return end
            p.id = targetId
        end
        if e.id == 'cmd' then p.cmd = e.cmd end
        if not askInputs(e, p) then return end
        send(e.id, p)
    end
    if e.pick and #e.pick > 0 then
        local items = {}
        for _, pk in ipairs(e.pick) do
            items[#items + 1] = { label = pk.label, right = pk.amount and (tostring(pk.amount) .. ' $') or nil, onSelect = function()
                if not targetId then notify('warn', "Choisis d'abord une cible.") return end
                local p = { id = targetId, code = pk.code, amount = pk.amount, reason = pk.label }
                if e.id == 'invoice' then p.code = nil if not askInputs({ inputs = { { k = 'reason', label = 'Motif', maxlen = 60 } } }, p) then return end end
                send(e.id, p)
            end }
        end
        if e.id == 'invoice' then items[#items + 1] = { label = 'Montant libre…', description = 'Saisis le montant et le motif au clavier.', onSelect = function() fire() end } end
        return { type = 'submenu', label = e.label, description = e.desc, icon = e.icon, submenu = { id = 'quick.' .. e.id, title = e.label, subtitle = 'Choisis puis valide', items = items } }
    end
    return { type = 'button', label = e.label, description = e.desc, icon = e.icon, onSelect = function() fire() end }
end

local function items()
    local out = { { type = 'separator', label = spec.biz .. ' · ' .. spec.grade }, targetItem() }
    for _, e in ipairs(spec.entries) do out[#out + 1] = entryItem(e) end
    return out
end

local def = { id = 'quick', title = 'Actions rapides', build = function() return items() end }

RegisterNetEvent('pb:g:quick:ui', function(j)
    local d = G.decode(j)
    if not d or not d.spec then if d and d.ev == 'update' and G.Menu.IsOpen() then G.Menu.Close() end return end
    spec = d.spec
    if d.ev == 'open' then
        targetId = nil
        def.subtitle = (spec.duty and 'En service' or 'Hors service')
        def.banner = { text = 'Menu ' .. tostring(spec.biz or 'entreprise') }
        G.Menu.Open(def)
    elseif G.Menu.IsOpen() then
        G.Menu.Refresh()
    end
end)
RegisterNetEvent('pb:g:quick:tablet', function() G.Menu.Close() ExecuteCommand('pb_tablet') end)
RegisterNetEvent('pb:g:quick:cmd', function(cmd) G.Menu.Close() if type(cmd) == 'string' and cmd:match('^[%w_:%-]+$') then ExecuteCommand(cmd) end end)

RegisterCommand('pb_quick', function()
    if not (G.cfg.quick and G.cfg.quick.f2_menu == true) then return end   -- menu F2 retiré (réglage) : tout passe par le menu ALT
    if not G.begun or G.creating or G.wardrobe or G.state.dead then return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    TriggerServerEvent('pb:g:quick:open')
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.quick and GetGameTimer() < t do Wait(250) end
    if G.cfg.quick and G.cfg.quick.f2_menu == true then RegisterKeyMapping('pb_quick', 'Actions rapides du métier', 'keyboard', G.cfg.quick.key or 'F2') end
end)
