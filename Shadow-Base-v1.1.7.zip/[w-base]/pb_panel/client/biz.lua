-- Tablette citoyen / entreprise : ouverture, navigation, réparation du garage. Toutes les données et vérifications viennent du serveur.
local G = PBG
local isOpen = false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.send('tablet.close', {})
end

local function open()
    if isOpen or busy() or not G.begun then return end
    TriggerServerEvent('pb:g:biz:open')
end

RegisterNetEvent('pb:g:biz:open', function() open() end)   -- ouverture demandée par un point (bureau du patron / siège)

RegisterNetEvent('pb:g:biz:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('tablet.' .. tostring(d.ev), d)
end)

RegisterNetEvent('pb:g:biz:job', function(j) G.job = G.decode(j) end)

G.nui['tablet.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:biz:page', tostring(d.page or 'home')) end return {} end
G.nui['tablet.act'] = function(d)
    if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:biz:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end
    return {}
end
G.nui['tablet.close'] = function() close() return {} end

-- Réparation demandée par le serveur (le mécanicien a le droit « repair » et est en service)
RegisterNetEvent('pb:g:biz:repair', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    if veh == 0 or not DoesEntityExist(veh) then G.send('notify', { type = 'error', text = 'Aucun véhicule à proximité.' }) return end
    SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    G.send('notify', { type = 'success', text = 'Véhicule réparé.' })
end)

RegisterCommand('pb_tablet', open, false)
RegisterCommand('tablette', open, false)

CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.biz and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_tablet', 'Ouvrir la tablette', 'keyboard', (G.cfg.biz and G.cfg.biz.tablet_key) or 'F6')
end)

CreateThread(function()
    while true do
        Wait(500)
        if isOpen and busy() then close() end
    end
end)
G.onForceClose(function() close() end)
