-- Tickets (/ticket) : fenêtre de suivi des demandes au staff. Le serveur décide de tout.
local G = PBG
local isOpen = false

local function close()
    if not isOpen then return end
    isOpen = false
    TriggerServerEvent('pb:g:ticket:close')
    G.focus(false)
    G.send('ticket.close', {})
end

RegisterNetEvent('pb:g:ticket:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or G.creating or G.wardrobe then TriggerServerEvent('pb:g:ticket:close') return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('ticket.' .. tostring(d.ev), d)
end)

G.nui['ticket.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:ticket:page', tostring(d.page or 'home')) end return {} end
G.nui['ticket.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:ticket:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end return {} end
G.nui['ticket.close'] = function() close() return {} end
G.onForceClose(function() close() end)
