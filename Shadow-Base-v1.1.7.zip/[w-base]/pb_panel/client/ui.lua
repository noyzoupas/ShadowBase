-- Chat et menu d'interaction. Les règles (portée, cadence, filtre) sont appliquées par le serveur.
local G = PBG

local open = { chat = false, menu = false }
local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

-- Chat ----------------------------------------------------------------------------------------------------------------------------
local KINDS = { me = 'me', ['do'] = 'do', ooc = 'ooc', annonce = 'announce' }

local function closeChat()
    if not open.chat then return end
    open.chat = false
    G.focus(false)
    G.send('chat.close', {})
end

G.nui['chat.submit'] = function(d)
    local text = type(d.text) == 'string' and d.text or ''
    closeChat()
    text = text:sub(1, 500)
    if text == '' then return {} end
    if text:sub(1, 1) == '/' then
        local cmd, rest = text:match('^/(%S+)%s*(.*)$')
        cmd = cmd and cmd:lower()
        if cmd and KINDS[cmd] then TriggerServerEvent('pb:g:chatSend', KINDS[cmd], rest)
        elseif cmd then ExecuteCommand(text:sub(2)) end
    else
        TriggerServerEvent('pb:g:chatSend', 'say', text)
    end
    return {}
end
G.nui['chat.close'] = function() closeChat() return {} end

-- Suggestions de commandes (comme le chat de base de FiveM) : les ressources les déclarent avec chat:addSuggestion,
-- le serveur envoie ses commandes, et on ajoute celles enregistrées ici. Affichées sous la saisie quand on tape « / ».
local sugg = {}       -- nom -> { name, help, params }
local serverCmds = {}
local function addSugg(name, help, params)
    if type(name) ~= 'string' then return end
    name = name:gsub('^/', '')
    if not name:match('^[%w_%-%.:]+$') or #name > 40 then return end
    local ps = {}
    if type(params) == 'table' then for _, p in ipairs(params) do if type(p) == 'table' and p.name then ps[#ps + 1] = { name = tostring(p.name):sub(1, 24), help = tostring(p.help or ''):sub(1, 80) } end end end
    sugg[name] = { name = name, help = type(help) == 'string' and help:sub(1, 120) or '', params = ps }
end
AddEventHandler('chat:addSuggestion', addSugg)
AddEventHandler('chat:addSuggestions', function(list) if type(list) == 'table' then for _, x in ipairs(list) do if type(x) == 'table' then addSugg(x.name, x.help, x.params) end end end end)
AddEventHandler('chat:removeSuggestion', function(name) if type(name) == 'string' then sugg[name:gsub('^/', '')] = nil end end)
RegisterNetEvent('pb:g:chatCmds', function(j) local t = G.decode(j) if type(t) == 'table' then serverCmds = t end end)
local BUILTIN = { { name = 'me', help = 'Action de ton personnage' }, { name = 'do', help = 'Décrire la scène' }, { name = 'ooc', help = 'Message hors personnage' }, { name = 'annonce', help = 'Annonce (si autorisé)' } }
local function suggestions()
    local out, seen = {}, {}
    local function put(x) if x and x.name and not seen[x.name] and not x.name:match('^[%+%-]') then seen[x.name] = true out[#out + 1] = x end end
    for _, x in ipairs(BUILTIN) do put(x) end
    for _, x in pairs(sugg) do put(x) end
    for _, x in ipairs(serverCmds) do put(sugg[x.name] or x) end
    pcall(function() for _, c in ipairs(GetRegisteredCommands() or {}) do if type(c.name) == 'string' and c.name:match('^[%w_%-]+$') then put(sugg[c.name] or { name = c.name, help = '' }) end end end)
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

RegisterNetEvent('pb:g:chat', function(j)
    local m = G.decode(j)
    if m then G.send('chat.msg', m) end
end)
RegisterNetEvent('pb:g:chatClear', function() G.send('chat.clear', {}) end)

-- Menu d'interaction --------------------------------------------------------------------------------------------------------------
local ANIMS = {
    handsup   = { 'missminuteman_1ig_2', 'handsup_base', 49 },
    crossarms = { 'amb@world_human_hang_out_street@female_arms_crossed@idle_a', 'idle_a', 49 },
    sit       = { 'anim@heists@prison_heiststation@cop_reactions', 'cop_b_idle', 1 },
    salute    = { 'anim@mp_player_intincarsalutestd@ds@', 'idle_a', 49 },
    facepalm  = { 'anim@mp_player_intcelebrationmale@face_palm', 'face_palm', 49 },
    dance     = { 'anim@amb@nightclub@dancers@crowddance_groups@', 'hi_idle_a_m03', 1 },
}
local function playAnim(name)
    local a = ANIMS[name]
    if not a then return end
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) or IsEntityDead(ped) then return end
    RequestAnimDict(a[1])
    local t = GetGameTimer() + 3000
    while not HasAnimDictLoaded(a[1]) and GetGameTimer() < t do Wait(10) end
    if HasAnimDictLoaded(a[1]) then TaskPlayAnim(ped, a[1], a[2], 4.0, -4.0, -1, a[3], 0, false, false, false) end
end

local function driverVehicle()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then return veh end
end

G.PlayAnim = playAnim

local DO = {
    id = function() TriggerServerEvent('pb:g:interact', 'id') end,
    ems = function() TriggerServerEvent('pb:g:interact', 'ems') TriggerServerEvent('pb:g:ems') end,
    cancel = function() ClearPedTasks(PlayerPedId()) end,
    engine = function()
        local v = driverVehicle()
        if v then SetVehicleEngineOn(v, not GetIsVehicleEngineRunning(v), false, true) else G.send('notify', { type = 'warn', text = 'Tu dois être conducteur.' }) end
    end,
    lights = function()
        local v = driverVehicle()
        if v then
            local _, lights, high = GetVehicleLightsState(v)
            SetVehicleLights(v, (lights == 1 or high == 1) and 1 or 2)
        else G.send('notify', { type = 'warn', text = 'Tu dois être conducteur.' }) end
    end,
    doors = function()
        local v = driverVehicle()
        if v then
            local locked = GetVehicleDoorLockStatus(v) >= 2
            SetVehicleDoorsLocked(v, locked and 1 or 2)
            G.send('notify', { type = 'info', text = locked and 'Portes déverrouillées.' or 'Portes verrouillées.' })
        else G.send('notify', { type = 'warn', text = 'Tu dois être conducteur.' }) end
    end,
}

local function closeMenu()
    if not open.menu then return end
    open.menu = false
    G.focus(false)
    G.send('menu.close', {})
end
G.nui['menu.close'] = function() closeMenu() return {} end
G.nui['menu.pick'] = function(d)
    local e = type(d.entry) == 'string' and d.entry or ''
    closeMenu()
    -- la liste doit être celle de la configuration reçue du serveur ; le serveur revérifie ce qui le concerne
    local ok = false
    for _, k in ipairs((G.cfg.interact or {}).entries or {}) do if k == e then ok = true end end
    if not ok then return {} end
    if DO[e] then DO[e]() else playAnim(e) end
    return {}
end

local function openMenu()
    local c = G.cfg.interact
    if not c or not c.enabled or open.menu or open.chat or busy() then return end
    open.menu = true
    G.focus(true)
    G.send('menu.open', { entries = c.entries or {}, defs = G.cfg.interact_entries or {}, cfg = c })
end

local function openChat()
    local c = G.cfg.chat
    if not c or not c.enabled or open.chat or open.menu or busy() then return end
    open.chat = true
    G.focus(true)
    G.send('chat.open', { cmds = suggestions() })
end

RegisterCommand('pb_chat', openChat, false)
RegisterCommand('pb_interact', openMenu, false)

-- La touche par défaut est celle de la configuration au moment où le joueur se connecte ; il peut ensuite la changer dans les raccourcis de FiveM.
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not (G.cfg.chat and G.cfg.interact) and GetGameTimer() < t do Wait(250) end
    local ck = (G.cfg.chat and G.cfg.chat.key) or 'T'
    local ik = (G.cfg.interact and G.cfg.interact.key) or 'F2'
    RegisterKeyMapping('pb_chat', 'Ouvrir le chat', 'keyboard', ck)
    RegisterKeyMapping('pb_interact', "Menu d'interaction", 'keyboard', ik)
end)

-- Masque le chat par défaut quand le nôtre est actif (sans l'arrêter) et ferme les interfaces si le joueur meurt.
CreateThread(function()
    while true do
        Wait(500)
        if G.state.dead then closeChat() closeMenu() end
    end
end)
G.onForceClose(function() closeChat() closeMenu() end)
