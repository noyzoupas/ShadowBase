-- Location de véhicules : comptoir (E) → choix du véhicule ; E dans le véhicule loué près du comptoir pour le rendre. Le serveur encaisse et vérifie.
local G = PBG
local points, myPlate = {}, nil

local function list() return (G.cfg and G.cfg.rental and G.cfg.rental.points) or {} end
local function vehicles()
    local out = {}
    for _, line in ipairs((G.cfg and G.cfg.rental and G.cfg.rental.vehicles) or {}) do
        local m, l, p = tostring(line):match('^([%w_]+)|([^|]+)|(%d+)$')
        if m then out[#out + 1] = { model = m, label = l, price = tonumber(p) } end
    end
    return out
end

local blips = {}
local function drawBlips()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    for _, p in ipairs(list()) do
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(b, 225) SetBlipColour(b, 5) SetBlipScale(b, 0.7) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label or 'Location')) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end
local prev = G.onCfg
G.onCfg = function(c) if prev then prev(c) end drawBlips() end

local function openMenu(pt)
    local items = {}
    for i, v in ipairs(vehicles()) do
        items[#items + 1] = { label = v.label, right = v.price .. ' $', submenu = { id = 'rent_pay', title = v.label, build = function()
            return {
                { label = 'Payer en espèces', right = v.price .. ' $', icon = 'cash', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:rent:take', pt.id, i, 'cash') end },
                { label = 'Payer par carte', right = v.price .. ' $', icon = 'card', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:rent:take', pt.id, i, 'bank') end },
            }
        end } }
    end
    if #items == 0 then items[1] = { label = 'Aucun véhicule à louer', disabled = true } end
    local mins = (G.cfg.rental and tonumber(G.cfg.rental.minutes)) or 30
    G.Menu.Open({ id = 'rental', title = tostring(pt.label or 'Location'), subtitle = ('Location pour %d minutes'):format(mins), items = items })
end

RegisterNetEvent('pb:g:rent:spawn', function(j)
    local d = G.decode(j)
    if not d then return end
    local hash = GetHashKey(d.model)
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then return end
    RequestModel(hash)
    local t = GetGameTimer() + 8000
    while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
    if not HasModelLoaded(hash) then return end
    local sp = d.spawn or {}
    local veh = CreateVehicle(hash, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, (sp.h or 0) + 0.0, true, false)
    SetVehicleNumberPlateText(veh, d.plate)
    SetVehicleOnGroundProperly(veh)
    SetModelAsNoLongerNeeded(hash)
    SetPedIntoVehicle(PlayerPedId(), veh, -1)
    myPlate = d.plate
    TriggerServerEvent('pb:g:rent:spawned', d.plate, NetworkGetNetworkIdFromEntity(veh))
end)

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        local pts = list()
        if not G.begun or #pts == 0 or G.Menu.IsOpen() then hide() Wait(800)
        else
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd
            for _, p in ipairs(pts) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if not bd or d < bd then best, bd = p, d end end
            local veh = GetVehiclePedIsIn(ped, false)
            local mine = veh ~= 0 and myPlate and GetVehicleNumberPlateText(veh):gsub('%s+$', '') == myPlate
            if best and bd < 20.0 and veh == 0 then G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 255, 198, 92, 0.8) end
            if best and ((veh == 0 and bd < 2.0) or (mine and bd < 20.0)) then
                local text = mine and 'Rendre le véhicule de location' or ('Louer un véhicule : ' .. tostring(best.label))
                if shown ~= text then shown = text G.send('prompt', { show = true, key = 'E', text = text }) end
                if IsControlJustPressed(0, 38) then
                    hide()
                    if mine then TaskLeaveVehicle(ped, veh, 0) Wait(1200) TriggerServerEvent('pb:g:rent:back', best.id) myPlate = nil
                    else openMenu(best) end
                end
                Wait(0)
            else hide() Wait(bd and bd < 40 and 150 or 800) end
        end
    end
end)
