-- Métiers civils : points de départ (blip, marqueur, E), trajet de la mission (blip + GPS + marqueur), arrivée signalée au serveur, /stopjob.
local G = PBG
local points, blips = {}, {}
local run = nil      -- { job, label, idx, total, step, radius, blip }

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function clearRun()
    if run and run.blip and DoesBlipExist(run.blip) then RemoveBlip(run.blip) end
    run = nil
end

RegisterNetEvent('pb:g:civil:step', function(j)
    local d = G.decode(j)
    if not d or not d.step then return end
    if run and run.blip and DoesBlipExist(run.blip) then RemoveBlip(run.blip) end
    local s = d.step
    local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
    SetBlipSprite(b, 1) SetBlipColour(b, 5) SetBlipRoute(b, true) SetBlipRouteColour(b, 5)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(('%s — étape %d/%d'):format(d.label, d.idx, d.total)) EndTextCommandSetBlipName(b)
    run = { job = d.job, label = d.label, idx = d.idx, total = d.total, step = s, radius = (d.radius or 6.0) + 0.0, blip = b }
end)
RegisterNetEvent('pb:g:civil:stop', function() clearRun() end)

RegisterCommand('stopjob', function() if run then TriggerServerEvent('pb:g:civil:cancel') end end, false)

local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    points = c.civil_points or {}
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (c.civil and c.civil.blips) then return end
    for _, p in ipairs(points) do
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(b, 477) SetBlipColour(b, 5) SetBlipScale(b, 0.8) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end

CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    local sentFor = nil
    while true do
        if not G.begun or busy() then hide() Wait(700)
        elseif run then
            hide()
            local c = GetEntityCoords(PlayerPedId())
            local s = run.step
            local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0))
            if d <= 80.0 then G.Zone(s.x + 0.0, s.y + 0.0, s.z - 1.0, 255, 213, 87, run.radius) end
            if d <= run.radius then
                local k = run.job .. ':' .. run.idx
                if sentFor ~= k then sentFor = k TriggerServerEvent('pb:g:civil:arrive', run.idx) end
            elseif sentFor and d > run.radius + 3.0 then sentFor = nil end
            Wait(d <= 80.0 and 0 or 400)
        elseif #points == 0 then hide() Wait(1000)
        else
            local cc = G.cfg.civil or {}
            local c = GetEntityCoords(PlayerPedId())
            local best, bd = nil, 1e9
            for _, p in ipairs(points) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd = p, d end end
            if best and bd <= 15.0 then
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 1.0, 255, 213, 87, 1.3)
                if bd <= (cc.use_distance or 2.5) then
                    if not shown or key ~= best.id then shown, key = true, best.id G.send('prompt', { show = true, key = 'E', text = ('%s — %d $'):format(best.label, best.pay or 0) }) end
                    if IsControlJustPressed(0, 38) then sentFor = nil TriggerServerEvent('pb:g:civil:start', best.id) Wait(800) end
                else hide() end
                Wait(0)
            else hide() Wait(500) end
        end
    end
end)
