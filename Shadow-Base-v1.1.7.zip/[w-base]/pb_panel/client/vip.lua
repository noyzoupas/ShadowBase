-- VIP : le serveur dit au joueur s'il est VIP (avantages affichés dans les menus des autres ressources).
local G = PBG
G.vip = false
RegisterNetEvent('pb:g:vip', function(on) G.vip = on == true end)
exports('IsVip', function() return G.vip == true end)

-- Choix du personnage à la connexion (VIP) : le serveur envoie la liste des emplacements
RegisterNetEvent('pb:g:charselect', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' or type(d.list) ~= 'table' then return end
    DoScreenFadeIn(500)
    local picked = false
    local items = { { type = 'separator', label = 'Tes personnages (avantage VIP)' } }
    for _, c in ipairs(d.list) do
        items[#items + 1] = { label = c.name or ('Emplacement %d : nouveau personnage'):format(c.slot), icon = c.name and 'user' or 'plus', right = c.money and ('$' .. c.money) or nil,
            description = c.name and 'Jouer avec ce personnage.' or 'Créer un nouveau personnage dans cet emplacement.',
            onSelect = function() picked = true G.Menu.Close() TriggerServerEvent('pb:g:charpick', c.slot) end }
    end
    local function open()
        G.Menu.Open({ id = 'charselect', title = 'Personnages', subtitle = 'Choisis avec qui tu joues', items = items,
            onClose = function() if not picked then SetTimeout(200, open) end end })
    end
    open()
end)
