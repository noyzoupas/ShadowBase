-- Images envoyées depuis le panel : le NUI demande une image par son identifiant, le serveur l'envoie en morceaux, on la renvoie recomposée.
local G = PBG
local parts, asked = {}, {}

G.nui['asset.want'] = function(d)
    local id = tostring(d.id or '')
    if not id:match('^%x+$') or #id > 32 then return {} end
    local t = GetGameTimer()
    if asked[id] and t - asked[id] < 5000 then return {} end
    asked[id] = t
    TriggerServerEvent('pb:g:asset:get', id)
    return {}
end

RegisterNetEvent('pb:g:asset:part', function(id, i, n, part)
    if type(id) ~= 'string' or type(i) ~= 'number' or type(n) ~= 'number' or type(part) ~= 'string' or n < 1 or n > 100 then return end
    local c = parts[id]
    if not c or c.n ~= n then c = { n = n, p = {}, got = 0 } parts[id] = c end
    if not c.p[i] then c.p[i] = part c.got = c.got + 1 end
    if c.got == c.n then
        parts[id] = nil
        local uri = table.concat(c.p)
        if G.onAsset then G.onAsset(id, uri) end
        G.send('asset', { id = id, uri = uri })
    end
end)

RegisterNetEvent('pb:g:asset:none', function(id) G.send('asset', { id = tostring(id), uri = '' , none = true }) end)
