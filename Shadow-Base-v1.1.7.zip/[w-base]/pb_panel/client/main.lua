-- Client du panel : ouvre l'interface (NUI), relaie les appels vers le serveur et reçoit les réponses.
-- Aucune donnée sensible n'est stockée ici : le jeton de session est celui du serveur, les droits sont vérifiés côté serveur.

local isOpen = false
local chunks = {}

local function toNui(kind, id, json)
    SendNUIMessage({ type = 'msg', kind = kind, id = id, json = json })
end

local function openPanel()
    if isOpen then return end
    TriggerServerEvent('pb:open')
end

local function closePanel(notifyServer)
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'closed' })
    if notifyServer ~= false then TriggerServerEvent('pb:close') end
end

-- Touche et commande (valeurs publiées par le serveur : voir Config.OpenKey / Config.OpenCommand)
local cmd = GetConvar('pb_panel_cmd', 'panel')
local key = GetConvar('pb_panel_key', '')
RegisterCommand(cmd, function() if isOpen then closePanel() else openPanel() end end, false)
RegisterKeyMapping(cmd, 'Ouvrir le panel de configuration', 'keyboard', key)

-- Réception des messages du serveur (réponses, notifications, session ouverte / révoquée)
local function handleMessage(kind, id, json)
    if kind == 'opened' then
        isOpen = true
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(false)
    elseif kind == 'denied' or kind == 'revoked' then
        if isOpen then closePanel(false) end
    end
    toNui(kind, id, json)
end

RegisterNetEvent('pb:msg', function(kind, id, json) handleMessage(kind, id, json) end)

RegisterNetEvent('pb:msgChunk', function(kind, id, i, n, part)
    local key2 = kind .. ':' .. tostring(id)
    local c = chunks[key2]
    if not c or c.n ~= n then c = { n = n, parts = {}, got = 0 } chunks[key2] = c end
    if not c.parts[i] then c.parts[i] = part c.got = c.got + 1 end
    if c.got == c.n then
        chunks[key2] = nil
        handleMessage(kind, id, table.concat(c.parts))
    end
end)

-- Rappels de l'interface -----------------------------------------------------------------------------------------------------
RegisterNUICallback('call', function(data, cb)
    if type(data) == 'table' and type(data.name) == 'string' then
        TriggerServerEvent('pb:call', data.token, data.id, data.name, data.json)
    end
    cb('ok')
end)

local UP_BPS = 200000   -- octets par seconde pour les envois volumineux du panel
RegisterNUICallback('upChunk', function(data, cb)
    if type(data) == 'table' and type(data.name) == 'string' then
        -- évènement « latent » (débit limité) : une image de ~1 Mo envoyée en évènements normaux dépasse la limite réseau de FiveM
        -- et le serveur déconnecte le joueur (« Reliable network event size overflow: pb:upChunk »)
        TriggerLatentServerEvent('pb:upChunk', UP_BPS, data.token, data.id, data.name, data.i, data.n, data.part)
    end
    cb('ok')
end)

RegisterNUICallback('close', function(_, cb)
    closePanel()
    cb('ok')
end)

-- Si la ressource s'arrête ou que le joueur meurt / se déconnecte, on rend la main
AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and isOpen then SetNuiFocus(false, false) end
end)

-- Position du joueur (bouton « Ma position » des formulaires)
RegisterNetEvent('pb:reqCoords', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    TriggerServerEvent('pb:coords', c.x, c.y, c.z, GetEntityHeading(ped))
end)

-- Annonce à l'écran (fil d'actualité du jeu)
RegisterNetEvent('pb:announce', function(text)
    if type(text) ~= 'string' or text == '' then return end
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(text:sub(1, 300))
    EndTextCommandThefeedPostTicker(false, true)
end)

-- Le créateur et le règlement n'apparaissent qu'une fois l'écran de chargement terminé (jamais dessus) :
-- session active, écran de chargement fermé, écran revenu du noir, puis une courte pause. Au bout de 60 s on ferme l'écran de chargement nous-mêmes.
CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(500) end
    local t0 = GetGameTimer()
    local function busy()
        if GetIsLoadingScreenActive and GetIsLoadingScreenActive() then return true end
        if IsScreenFadedOut() or IsScreenFadingOut() or IsScreenFadingIn() then return true end
        if IsPlayerSwitchInProgress and IsPlayerSwitchInProgress() then return true end
        return false
    end
    -- Attente normale : 15 s. Si personne ne ferme le chargement / ne fait apparaître le joueur (spawnmanager, ESX multicharacter
    -- ou écran de chargement arrêtés ou absents), on prend la main nous-mêmes : fermeture du chargement, apparition, fondu.
    while busy() and GetGameTimer() - t0 < 15000 do Wait(500) end
    local function notSpawned()
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) or IsEntityDead(ped) then return true end
        local c = GetEntityCoords(ped)
        return math.abs(c.x) < 1.0 and math.abs(c.y) < 1.0
    end
    if busy() or notSpawned() then
        ShutdownLoadingScreen()
        if ShutdownLoadingScreenNui then ShutdownLoadingScreenNui() end
        if notSpawned() then
            local m = GetHashKey('mp_m_freemode_01')
            RequestModel(m)
            local t = GetGameTimer()
            while not HasModelLoaded(m) and GetGameTimer() - t < 5000 do Wait(50) end
            if HasModelLoaded(m) then SetPlayerModel(PlayerId(), m) SetModelAsNoLongerNeeded(m) end
            local x, y, z = -269.4, -955.3, 31.2
            RequestCollisionAtCoord(x, y, z)
            NetworkResurrectLocalPlayer(x, y, z, 0.0, true, false)
            local ped = PlayerPedId()
            SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)
            FreezeEntityPosition(ped, false)
            ClearPedTasksImmediately(ped)
            local t2 = GetGameTimer()
            while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t2 < 4000 do Wait(50) end
        end
        if IsScreenFadedOut() or IsScreenFadingOut() then DoScreenFadeIn(500) end
        Wait(1500)
    end
    Wait(3000)
    TriggerServerEvent('pb:clientReady')
end)
