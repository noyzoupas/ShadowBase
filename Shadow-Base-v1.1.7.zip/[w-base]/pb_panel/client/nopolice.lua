-- Serveur GTA RP : pas d'étoiles de recherche, pas de patrouilles ni d'hélicoptères de la police du jeu.
-- Réglable dans Monde › Réglages (« Police du jeu »). Tout est appliqué ici, côté client ; aucune donnée sensible.
local G = PBG

local DISPATCH = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }
local applied = nil

local function apply(off)
    if applied == off then return end
    applied = off
    for _, i in ipairs(DISPATCH) do pcall(EnableDispatchService, i, not off) end
    SetCreateRandomCops(not off)
    SetCreateRandomCopsNotOnScenarios(not off)
    SetCreateRandomCopsOnScenarios(not off)
    SetMaxWantedLevel(off and 0 or 5)
    if off then
        local pid = PlayerId()
        ClearPlayerWantedLevel(pid)
        SetPlayerWantedLevel(pid, 0, false)
        SetPlayerWantedLevelNow(pid, false)
    end
end

CreateThread(function()
    while true do
        Wait(1000)
        local off = not (G.cfg and G.cfg.gta_police == true)
        apply(off)
        if off then
            local pid = PlayerId()
            if GetPlayerWantedLevel(pid) > 0 then
                SetPlayerWantedLevel(pid, 0, false)
                SetPlayerWantedLevelNow(pid, false)
            end
            SetPoliceIgnorePlayer(pid, true)
        end
    end
end)
