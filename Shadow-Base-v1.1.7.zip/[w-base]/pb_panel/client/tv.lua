-- Télévisions : menu de l'écran (ALT -> écran -> commande pb_tv), affichage des vidéos sur les écrans proches (page interne DUI projetée
-- sur la cible de rendu du modèle), volume selon la distance. Le serveur valide les liens et tient la liste des écrans allumés.
local G = PBG
local RES = GetCurrentResourceName()
local MODELS = {   -- même liste que server/game/tv.lua
    { 'prop_tv_flat_01', 'tvscreen' }, { 'prop_tv_flat_01_screen', 'tvscreen' }, { 'prop_tv_flat_02', 'tvscreen' }, { 'prop_tv_flat_02b', 'tvscreen' }, { 'prop_tv_flat_03', 'tvscreen' },
    { 'prop_tv_flat_03b', 'tvscreen' }, { 'prop_tv_flat_michael', 'tvscreen' }, { 'prop_trev_tv_01', 'tvscreen' }, { 'prop_tv_03', 'tvscreen' }, { 'des_tvsmash_start', 'tvscreen' },
    { 'v_ilev_cin_screen', 'cinscreen' }, { 'prop_huge_display_01', 'big_disp' }, { 'prop_huge_display_02', 'big_disp' },
}
local screens, range, volume = {}, 25, 60
local kv = GetResourceKvpInt('pb_tv_vol')
local myVol = kv > 0 and (kv - 1) or 100   -- réglage personnel (0..100), mémorisé +1 (0 = jamais réglé)

RegisterNetEvent('pb:g:tv:list', function(j)
    local d = G.decode(j)
    if not d then return end
    range, volume = tonumber(d.range) or 25, tonumber(d.volume) or 60
    local by = {}
    for _, s in ipairs(d.screens or {}) do by[s.id] = s end
    screens = by
end)

-- Écran le plus proche (4 m) : { name, rt, obj, x, y, z }
local function nearestScreen()
    local me = GetEntityCoords(PlayerPedId())
    local best, bd
    for _, m in ipairs(MODELS) do
        local obj = GetClosestObjectOfType(me.x, me.y, me.z, 4.0, joaat(m[1]), false, false, false)
        if obj and obj ~= 0 and DoesEntityExist(obj) then
            local c = GetEntityCoords(obj)
            local d = #(me - c)
            if not bd or d < bd then best, bd = { name = m[1], rt = m[2], obj = obj, x = c.x, y = c.y, z = c.z }, d end
        end
    end
    return best
end
local function idOf(s) return ('%s:%d:%d:%d'):format(s.name, math.floor(s.x + 0.5), math.floor(s.y + 0.5), math.floor(s.z + 0.5)) end

RegisterCommand('pb_tv', function()
    if not G.begun then return end
    local s = nearestScreen()
    if not s then G.send('notify', { type = 'warn', title = 'Télévision', text = "Approche-toi d'un écran." }) return end
    local id = idOf(s)
    local on = screens[id]
    local items = {
        { label = on and 'Changer de vidéo' or 'Diffuser une vidéo', icon = 'eye', description = 'Colle un lien YouTube ou Vimeo (Ctrl+V).', onSelect = function()
            local url = G.Menu.Ask('Lien de la vidéo (https://…)', '', 300)
            if url and url ~= '' then G.Menu.Close() TriggerServerEvent('pb:g:tv:play', s.name, s.x, s.y, s.z, url) end
        end },
    }
    if on then items[#items + 1] = { label = 'Arrêter la diffusion', icon = 'x', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:tv:stop', id) end } end
    items[#items + 1] = { label = 'Mon volume des télés : ' .. myVol .. ' %', icon = 'music', description = 'Réglage personnel, pour toutes les télés.', onSelect = function()
        local v = tonumber(G.Menu.Ask('Volume (0 à 100)', tostring(myVol), 3) or '')
        if v then myVol = math.max(0, math.min(100, math.floor(v))) SetResourceKvpInt('pb_tv_vol', myVol + 1) G.Menu.Close() end
    end }
    G.Menu.Open({ id = 'tv', title = 'Télévision', subtitle = on and 'En cours de diffusion' or 'Éteinte', items = items, banner = { text = 'Écran' } })
end, false)

-- Affichage : une page interne par écran allumé proche ------------------------------------------------------------------------------------
local live = {}   -- id -> { dui, txd, tex, rt, rid, obj, sent }
local n = 0
local function stopLive(id)
    local l = live[id]
    if not l then return end
    if l.dui then DestroyDui(l.dui) end
    if l.rt and l.rid and IsNamedRendertargetRegistered(l.rt) then ReleaseNamedRendertarget(l.rt) end
    live[id] = nil
end
local function startLive(s, obj)
    n = n + 1
    local dui = CreateDui(('nui://%s/web/tvdui.html'):format(RES), 1280, 720)
    local txd = 'pb_tv_txd_' .. n
    CreateRuntimeTextureFromDuiHandle(CreateRuntimeTxd(txd), 'pb_tv_tex', GetDuiHandle(dui))
    if not IsNamedRendertargetRegistered(s.rt) then RegisterNamedRendertarget(s.rt, false) end
    if not IsNamedRendertargetLinked(GetEntityModel(obj)) then LinkNamedRendertarget(GetEntityModel(obj)) end
    live[s.id] = { dui = dui, txd = txd, tex = 'pb_tv_tex', rt = s.rt, rid = GetNamedRendertargetRenderId(s.rt), obj = obj, key = s.kind .. s.vid .. s.at, born = GetGameTimer() }
    return live[s.id]
end
local function play(l, s)
    -- la page met un instant à charger : on renvoie la vidéo jusqu'à ce qu'elle réponde (2 essais suffisent en pratique)
    local start = math.max(0, GetCloudTimeAsInt() - (tonumber(s.at) or 0))
    SendDuiMessage(l.dui, json.encode({ type = 'play', kind = s.kind, id = s.vid, start = start }))
end

CreateThread(function()
    while true do
        Wait(500)
        local me = GetEntityCoords(PlayerPedId())
        local wanted = {}
        local byRt = {}
        for id, s in pairs(screens) do
            local d = #(me - vector3(s.x, s.y, s.z))
            if d <= range + 10 and (not byRt[s.rt] or d < byRt[s.rt].d) then byRt[s.rt] = { id = id, d = d } end
        end
        for _, b in pairs(byRt) do wanted[b.id] = b.d end
        for id in pairs(live) do if not wanted[id] or not screens[id] then stopLive(id) end end
        for id, d in pairs(wanted) do
            local s = screens[id]
            local obj = GetClosestObjectOfType(s.x, s.y, s.z, 2.0, joaat(s.model), false, false, false)
            if obj and obj ~= 0 then
                local l = live[id]
                if l and l.key ~= s.kind .. s.vid .. s.at then stopLive(id) l = nil end
                if not l then l = startLive(s, obj) end
                if GetGameTimer() - l.born > 1500 and (l.sent or 0) < 2 then play(l, s) l.sent = (l.sent or 0) + 1 l.born = GetGameTimer() end
                local v = math.floor(volume * (myVol / 100) * math.max(0, 1 - d / range) + 0.5)
                if v ~= l.vol then l.vol = v SendDuiMessage(l.dui, json.encode({ type = 'vol', v = v })) end
            end
        end
    end
end)
-- dessin sur l'écran, à chaque image, seulement s'il y a un écran allumé à côté
CreateThread(function()
    while true do
        if next(live) then
            for _, l in pairs(live) do
                SetTextRenderId(l.rid)
                SetScriptGfxDrawOrder(4)
                SetScriptGfxDrawBehindPausemenu(true)
                DrawSprite(l.txd, l.tex, 0.5, 0.5, 1.0, 1.0, 0.0, 255, 255, 255, 255)
                SetTextRenderId(GetDefaultScriptRendertargetRenderId())
            end
            Wait(0)
        else Wait(500) end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == RES then for id in pairs(live) do stopLive(id) end end end)
