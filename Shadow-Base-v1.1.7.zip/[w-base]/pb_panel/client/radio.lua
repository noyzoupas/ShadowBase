-- Poste radio (F4) : interface pour choisir sa fréquence et son volume. Le serveur valide chaque fréquence (plages réservées, objet,
-- état du joueur) et place le joueur avec pma-voice ; on parle ensuite avec la touche radio de pma-voice.
local G = PBG
local isOpen = false

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end
local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.send('radio.close', {})
end
G.radioOpen = function() return isOpen end

local function volume()
    local ok, v = pcall(function() return exports['pma-voice']:getRadioVolume() end)
    return ok and math.floor((tonumber(v) or 30) + 0.5) or 30
end

RegisterNetEvent('pb:g:radio', function(j)
    local d = G.decode(j)
    if not d then return end
    d.vol = volume()
    d.talk = GetConvar('voice_defaultRadio', 'LMENU')
    if d.ev == 'open' then
        if isOpen or busy() then return end
        isOpen = true
        G.focus(true)
    end
    G.radioCh = tonumber(d.ch) or 0
    G.send('radio.' .. tostring(d.ev), d)
end)

G.nui['radio.join'] = function(d) if isOpen then TriggerServerEvent('pb:g:radio:join', tonumber(d.ch) or 0) end return {} end
G.nui['radio.leave'] = function() TriggerServerEvent('pb:g:radio:leave') return {} end
G.nui['radio.vol'] = function(d)
    local v = math.max(0, math.min(100, math.floor(tonumber(d.vol) or 30)))
    pcall(function() exports['pma-voice']:setRadioVolume(v) end)
    SetResourceKvpInt('pb_radio_vol', v + 1)
    return {}
end
G.nui['radio.close'] = function() close() return {} end

RegisterCommand('pb_radio', function()
    if not G.begun or busy() then return end
    if not (G.cfg.radio and G.cfg.radio.ui ~= false) then return end
    if isOpen then close() else TriggerServerEvent('pb:g:radio:open') end
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.radio and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_radio', 'Ouvrir la radio', 'keyboard', (G.cfg.radio and G.cfg.radio.key) or 'F4')
    -- volume radio retenu d'une session à l'autre (0 = jamais réglé)
    local v = GetResourceKvpInt('pb_radio_vol')
    if v > 0 then pcall(function() exports['pma-voice']:setRadioVolume(v - 1) end) end
end)
CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
