-- Appels vocaux : bandeau d'appel (visible même téléphone fermé), téléphone à l'oreille pendant l'appel, /decrocher et /raccrocher.
-- La voix passe par pma-voice : c'est le serveur qui place les deux joueurs sur le même canal, le client n'en choisit jamais.
local G = PBG
local cur          -- dernier état reçu : { state, id, label, num, svc, since, ring }

RegisterNetEvent('pb:g:call', function(j)
    local d = G.decode(j)
    if not d then return end
    cur = d.state ~= 'ended' and d or nil
    G.callState = cur
    G.send('call.state', d)
end)

local function answer() if cur and cur.state == 'incoming' then TriggerServerEvent('pb:g:call:answer', cur.id) end end
local function hangup() if cur then TriggerServerEvent('pb:g:call:hangup', cur.id) end end
RegisterCommand('decrocher', answer, false)
RegisterCommand('raccrocher', hangup, false)
G.nui['call.answer'] = function() answer() return {} end
G.nui['call.hangup'] = function() hangup() return {} end
G.nui['call.start'] = function(d) if type(d.num) == 'string' then TriggerServerEvent('pb:g:call:start', d.num:sub(1, 40)) end return {} end
G.nui['call.speaker'] = function() if cur and cur.state == 'live' then TriggerServerEvent('pb:g:call:speaker') end return {} end
G.nui['call.invite'] = function(d) if cur and cur.state == 'live' and type(d.num) == 'string' then TriggerServerEvent('pb:g:call:invite', d.num:sub(1, 12)) end return {} end
-- Appel 911 reçu (police / secours en service) : point clignotant et itinéraire vers l'appelant pendant 5 minutes
RegisterNetEvent('pb:g:phone:alert', function(j)
    local p = G.decode(j)
    if not p or not p.x then return end
    local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, (p.z or 0) + 0.0)
    SetBlipSprite(b, 153) SetBlipColour(b, 1) SetBlipScale(b, 1.1) SetBlipFlashes(b, true) SetBlipRoute(b, true) SetBlipRouteColour(b, 1)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label or 'Appel 911')) EndTextCommandSetBlipName(b)
    PlaySoundFrontend(-1, 'TIMER_STOP', 'HUD_MINI_GAME_SOUNDSET', true)
    SetTimeout(300000, function() if DoesBlipExist(b) then RemoveBlip(b) end end)
end)
G.nui['call.sync'] = function() TriggerServerEvent('pb:g:call:sync') return {} end

-- Téléphone à l'oreille pendant l'appel (sauf si le téléphone est ouvert : il a déjà sa propre animation)
local prop, dict
local function earOff()
    if not prop then return end
    if DoesEntityExist(prop) then DetachEntity(prop, true, true) DeleteEntity(prop) end
    prop = nil
    if dict then StopAnimTask(PlayerPedId(), dict, 'cellphone_call_listen_base', 1.0) end
    dict = nil
end
local function load(kind, name, check, ms)
    kind(name)
    local t = GetGameTimer() + (ms or 1500)
    while not check(name) and GetGameTimer() < t do Wait(10) end
    return check(name)
end
local function earOn()
    local ped = PlayerPedId()
    if IsEntityDead(ped) then return end
    local want = IsPedInAnyVehicle(ped, false) and 'anim@cellphone@in_car@ps' or 'cellphone@'
    if not prop then
        local model = joaat('prop_npc_phone_02')
        if not load(RequestModel, model, HasModelLoaded) then return end
        local c = GetEntityCoords(ped)
        prop = CreateObject(model, c.x, c.y, c.z + 0.2, true, true, false)
        AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
        SetModelAsNoLongerNeeded(model)
    end
    if dict ~= want or not IsEntityPlayingAnim(ped, want, 'cellphone_call_listen_base', 3) then
        if dict and dict ~= want then StopAnimTask(ped, dict, 'cellphone_call_listen_base', 1.0) end
        if load(RequestAnimDict, want, HasAnimDictLoaded) then
            TaskPlayAnim(ped, want, 'cellphone_call_listen_base', 3.0, -1.0, -1, 50, 0, false, false, false)
            dict = want
        end
    end
end
CreateThread(function()
    while true do
        Wait(500)
        local want = cur and cur.state == 'live' and not (G.phoneOpen and G.phoneOpen()) and not (G.cfg.phone and G.cfg.phone.anim == false)
        if want then earOn() elseif prop then earOff() end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then earOff() end end)
