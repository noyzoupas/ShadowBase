-- Portrait du personnage : le serveur le demande (screenshot-basic requis) ; on cadre le visage, on capture, l'interface réduit l'image
-- en petit carré JPEG, puis on l'envoie au serveur qui la valide de nouveau.
local G = PBG
local busy = false

local function capture(cb)
    local ok = pcall(function() exports['screenshot-basic']:requestScreenshot({ encoding = 'jpg', quality = 0.8 }, cb) end)
    if not ok then pcall(function() exports['screenshot-basic']:requestScreenshot(cb) end) end
end

RegisterNetEvent('pb:g:photo:ask', function()
    if busy or GetResourceState('screenshot-basic') ~= 'started' then return end
    local ped = PlayerPedId()
    if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) or (G.IsCuffed and G.IsCuffed()) or not G.begun or G.creating then return end
    busy = true
    CreateThread(function()
        local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        local o = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.8, 0.62)
        SetCamCoord(cam, o.x, o.y, o.z) PointCamAtPedBone(cam, ped, 31086, 0.0, 0.0, 0.0, true) SetCamFov(cam, 32.0)
        RenderScriptCams(true, false, 0, true, false)
        Wait(900)
        local got = false
        capture(function(data) got = true G.send('photo.shrink', { img = tostring(data or '') }) end)
        local t = GetGameTimer() + 4000
        while not got and GetGameTimer() < t do Wait(50) end
        RenderScriptCams(false, false, 0, true, false) DestroyCam(cam, false)
        busy = false
    end)
end)
G.nui['photo.result'] = function(d)
    if type(d.img) == 'string' and #d.img < 60000 and d.img:sub(1, 23) == 'data:image/jpeg;base64,' then TriggerServerEvent('pb:g:photo:set', d.img) end
    return {}
end
