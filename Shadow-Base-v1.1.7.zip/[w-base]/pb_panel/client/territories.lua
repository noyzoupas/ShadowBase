-- Territoires : invite E dans une zone, couleur de la zone sur la carte, ré-utilise la barre de progression des activités.
local G = PBG
local zones, owners, me, blips = {}, {}, nil, {}
local active = false
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local t = c.territories or {}
    zones = t.enabled == false and {} or (t.zones or {})
    G.terrBlips = t.show_blips ~= false
    G.redrawTerr()
end
-- Couleurs de blip du jeu (approximations RGB) : la carte du jeu ne sait afficher que cette palette, on prend la plus proche de la couleur du gang.
local PALETTE = {
    { 1, 224, 50, 50 }, { 2, 114, 204, 114 }, { 3, 93, 182, 229 }, { 5, 238, 198, 80 }, { 7, 156, 110, 175 }, { 8, 255, 123, 196 }, { 17, 234, 143, 53 },
    { 25, 59, 150, 60 }, { 29, 37, 102, 159 }, { 38, 36, 98, 165 }, { 40, 77, 77, 77 }, { 4, 240, 240, 240 }, { 39, 170, 170, 170 }, { 43, 140, 230, 200 }, { 46, 238, 220, 120 }, { 49, 155, 40, 40 }, { 54, 20, 120, 120 },
}
function G.blipColourFor(hex)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 4 end
    r, g, b = tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
    local best, bd = 4, 1e9
    for _, p in ipairs(PALETTE) do
        local d = (p[2] - r) ^ 2 + (p[3] - g) ^ 2 + (p[4] - b) ^ 2
        if d < bd then best, bd = p[1], d end
    end
    return best
end
function G.redrawTerr()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not G.terrBlips then return end
    if not me or me == '' then return end   -- territoires visibles seulement par les membres d'un groupe illégal
    for _, z in ipairs(zones) do
        local o = owners[z.id]
        local colour = o and G.blipColourFor(o.color) or 4
        local b = AddBlipForRadius(z.x + 0.0, z.y + 0.0, z.z + 0.0, (tonumber(z.radius) or 30) + 0.0)
        SetBlipColour(b, colour) SetBlipAlpha(b, o and 110 or 40)
        blips[#blips + 1] = b
        -- petit repère au centre avec le nom de la zone et du gang qui la tient (visible sur la carte du jeu)
        local c = AddBlipForCoord(z.x + 0.0, z.y + 0.0, z.z + 0.0)
        SetBlipSprite(c, 84) SetBlipColour(c, colour) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(z.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
        blips[#blips + 1] = c
    end
end
RegisterNetEvent('pb:g:terr:owners', function(j) local d = G.decode(j) if d then owners = d.owners or {} me = d.me G.redrawTerr() end end)
RegisterNetEvent('pb:g:terr:wait', function() active = true end)
-- fin de la barre : on confirme au serveur (la barre elle-même est celle des activités)
RegisterNetEvent('pb:g:crime:go', function(j)
    local d = G.decode(j)
    if not active or not d then return end
    CreateThread(function()
        local secs = tonumber(d.time) or 30
        local t0, ok = GetGameTimer(), true
        while GetGameTimer() - t0 < secs * 1000 do
            Wait(200)
            local p = PlayerPedId()
            if IsEntityDead(p) or #(GetEntityCoords(p) - vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)) > (tonumber(d.radius) or 30) + 3.0 then ok = false break end
        end
        active = false
        TriggerServerEvent('pb:g:terr:end', ok)
    end)
end)
-- cercle très fin autour de chaque zone proche (couleur du gang qui la tient, gris si libre)
CreateThread(function()
    while true do
        if not G.begun or #zones == 0 then Wait(1000) else
            local c = GetEntityCoords(PlayerPedId())
            local any = false
            for _, z in ipairs(zones) do
                local zx, zy, zz = z.x + 0.0, z.y + 0.0, z.z + 0.0
                local rr = (tonumber(z.radius) or 30) + 0.0
                if #(c - vector3(zx, zy, zz)) < rr + 120.0 then
                    any = true
                    local o = owners[z.id]
                    local r, g, b = 200, 204, 212
                    local hex = o and (o.color or '')
                    if type(hex) == 'string' then local rr2, gg, bb = hex:match('^#(%x%x)(%x%x)(%x%x)$') if rr2 then r, g, b = tonumber(rr2, 16), tonumber(gg, 16), tonumber(bb, 16) end end
                    G.Zone(zx, zy, zz - 0.95, r, g, b, rr)
                end
            end
            Wait(any and 0 or 500)
        end
    end
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #zones == 0 or not me or active or G.Menu.IsOpen() then hide() Wait(700)
        else
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if #(c - vector3(z.x + 0.0, z.y + 0.0, z.z + 0.0)) <= (tonumber(z.radius) or 30) then hit = z break end end
            local o = hit and owners[hit.id]
            if hit and (not o or o.gang ~= me) then
                if shown ~= hit.id then shown = hit.id G.send('prompt', { show = true, key = 'E', text = 'Prendre : ' .. hit.label }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:terr:start', hit.id) end
                Wait(0)
            else hide() Wait(400) end
        end
    end
end)

-- Entrée dans un territoire : carte « Vous entrez en territoire / Sous le contrôle de … » au-dessus de la mini-carte (une fois par entrée)
CreateThread(function()
    local inside
    while true do
        Wait(700)
        if G.begun and #zones > 0 then
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do
                local dx, dy = c.x - (z.x + 0.0), c.y - (z.y + 0.0)
                if math.sqrt(dx * dx + dy * dy) <= (tonumber(z.radius) or 30) + 0.0 then hit = z break end
            end
            local id = hit and hit.id or nil
            if id ~= inside then
                inside = id
                if hit then
                    local o = owners[hit.id]
                    G.send('zone.enter', { zone = hit.label, gang = o and o.label or nil, color = o and o.color or nil })
                end
            end
        else Wait(1000) end
    end
end)

RegisterNetEvent('pb:g:zone:banner', function(j) local d = G.decode(j) if d then G.send('zone.banner', d) end end)
