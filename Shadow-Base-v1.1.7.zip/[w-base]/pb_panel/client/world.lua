-- Rendu côté client : blips / marqueurs / zones du module Cartographie, météo / heure / densités du module Monde.

local blips, markers = {}, {}
local world = { enabled = false }
local clock = { h = 12, m = 0, mode = 'cycle', ms = 2000 }

local function decode(s)
    if type(s) ~= 'string' or s == '' then return nil end
    local ok, v = pcall(json.decode, s)
    return ok and v or nil
end

local function hexToRgb(hex)
    hex = tostring(hex or '#dfe2e7'):gsub('#', '')
    return tonumber(hex:sub(1, 2), 16) or 155, tonumber(hex:sub(3, 4), 16) or 140, tonumber(hex:sub(5, 6), 16) or 255
end

-- Emplacements -----------------------------------------------------------------------------------------------------------------------------------
local function clearPlaces()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips, markers = {}, {}
end

local function nameBlip(b, label)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(tostring(label):sub(1, 60))
    EndTextCommandSetBlipName(b)
end

RegisterNetEvent('pb:places', function(json_)
    local list = decode(json_) or {}
    clearPlaces()
    for _, p in ipairs(list) do
        if p.kind == 'blip' then
            local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, p.sprite or 1)
            SetBlipColour(b, p.color or 0)
            SetBlipScale(b, (p.scale or 0.8) + 0.0)
            SetBlipAsShortRange(b, p.shortrange and true or false)
            nameBlip(b, p.label)
            blips[#blips + 1] = b
        elseif p.kind == 'zone' then
            local b = AddBlipForRadius(p.x + 0.0, p.y + 0.0, p.z + 0.0, (p.radius or 50) + 0.0)
            SetBlipColour(b, p.color or 1)
            SetBlipAlpha(b, 120)
            blips[#blips + 1] = b
        elseif p.kind == 'marker' then
            local r, g, b = hexToRgb(p.rgba)
            markers[#markers + 1] = { x = p.x + 0.0, y = p.y + 0.0, z = p.z + 0.0, t = p.mtype or 1, s = (p.radius or 2) + 0.0, r = r, g = g, b = b }
        end
    end
end)

local nearM, nextNear = {}, 0
CreateThread(function()
    while true do
        if #markers == 0 then
            Wait(1500)
        else
            -- on ne dessine à chaque image que les repères à moins de 60 m ; la liste est recalculée deux fois par seconde
            local now = GetGameTimer()
            if now >= (nextNear or 0) then
                nextNear = now + 500
                local c = GetEntityCoords(PlayerPedId())
                nearM = {}
                for _, m in ipairs(markers) do
                    if #(c - vector3(m.x, m.y, m.z)) < 60.0 then nearM[#nearM + 1] = m end
                end
            end
            if #nearM == 0 then Wait(400)
            else
                Wait(0)
                for _, m in ipairs(nearM) do
                    PBG.Point(m.x, m.y, m.z, m.r, m.g, m.b, 1.0)   -- flèche blanche (plus de cercle)
                end
            end
        end
    end
end)

-- Monde ----------------------------------------------------------------------------------------------------------------------------------------------
local appliedWeather
local function applyWeather(w)
    if not w or w == appliedWeather then return end
    appliedWeather = w
    ClearOverrideWeather()
    ClearWeatherTypePersist()
    SetWeatherTypePersist(w)
    SetWeatherTypeNow(w)
    SetWeatherTypeNowPersist(w)
    if w == 'XMAS' or w == 'SNOW' or w == 'BLIZZARD' or w == 'SNOWLIGHT' then
        SetForceVehicleTrails(true)
        SetForcePedFootstepsTracks(true)
    else
        SetForceVehicleTrails(false)
        SetForcePedFootstepsTracks(false)
    end
end

RegisterNetEvent('pb:world', function(json_)
    local s = decode(json_)
    if not s then return end
    if not s.enabled then
        if world.enabled then
            ClearOverrideWeather() ClearWeatherTypePersist() appliedWeather = nil
            SetArtificialLightsState(false)
        end
        world = s   -- seulement la population (PNJ, densités)
        return
    end
    world = s
    clock.h, clock.m, clock.mode, clock.ms = s.hour or 12, s.minute or 0, s.mode or 'cycle', s.minute_ms or 2000
    applyWeather(s.weather)
    SetArtificialLightsState(s.blackout and true or false)
    SetArtificialLightsStateAffectsVehicles(false)
    SetWindSpeed((s.wind or 0.0) + 0.0)
end)

-- Horloge locale : le serveur donne le point de départ, le client avance minute par minute
CreateThread(function()
    local last = GetGameTimer()
    while true do
        Wait(250)
        if world.enabled then
            if clock.mode == 'cycle' then
                local now = GetGameTimer()
                while now - last >= clock.ms do
                    last = last + clock.ms
                    clock.m = clock.m + 1
                    if clock.m >= 60 then clock.m = 0 clock.h = (clock.h + 1) % 24 end
                end
            else
                last = GetGameTimer()
            end
            NetworkOverrideClockTime(clock.h, clock.m, 0)
        else
            last = GetGameTimer()
        end
    end
end)

-- Densités : doivent être réappliquées à chaque image (même si le panel ne pilote pas la météo et l'heure)
-- « Supprimer les PNJ » : piétons et circulation à zéro. Le serveur bloque aussi leur création (server/modules/world.lua).
-- (une tâche de la boucle unique « à chaque image » de client/game.lua : pas de thread de plus)
local function densityHook()
    local ped, veh, parked = world.ped or 1.0, world.veh or 1.0, world.parked or 1.0
    if world.no_npc then ped, veh = 0.0, 0.0 end
    if not (ped < 1.0 or veh < 1.0 or parked < 1.0) then return false end
    SetPedDensityMultiplierThisFrame(ped + 0.0)
    SetScenarioPedDensityMultiplierThisFrame(ped + 0.0, ped + 0.0)
    SetVehicleDensityMultiplierThisFrame(veh + 0.0)
    SetRandomVehicleDensityMultiplierThisFrame(veh + 0.0)
    SetParkedVehicleDensityMultiplierThisFrame(parked + 0.0)
    if world.no_npc then SetAmbientVehicleRangeMultiplierThisFrame(0.0) end
    return true
end
CreateThread(function()   -- ce fichier est chargé avant client/game.lua (qui crée PBG)
    while not PBG do Wait(0) end
    PBG.frameHooks = PBG.frameHooks or {}
    PBG.frameHooks[#PBG.frameHooks + 1] = densityHook
end)

-- « Supprimer les PNJ police » : modèles de police interdits, scénarios de police (voitures garées, barrages, commissariats) coupés
local COP_PEDS = { 's_m_y_cop_01', 's_f_y_cop_01', 's_m_y_sheriff_01', 's_f_y_sheriff_01', 's_m_y_hwaycop_01', 's_m_y_swat_01', 's_m_m_snowcop_01',
    's_m_y_ranger_01', 's_f_y_ranger_01', 's_m_m_ciasec_01', 's_m_m_fiboffice_01', 's_m_m_fibsec_01', 'csb_cop', 's_m_y_uscg_01', 's_m_m_prisguard_01' }
local COP_VEHS = { 'police', 'police2', 'police3', 'police4', 'policeb', 'policet', 'policeold1', 'policeold2', 'sheriff', 'sheriff2', 'fbi', 'fbi2',
    'pranger', 'riot', 'riot2', 'polmav', 'predator', 'pbus', 'lguard' }
local COP_SCENARIOS = { 'WORLD_VEHICLE_POLICE_BIKE', 'WORLD_VEHICLE_POLICE_CAR', 'WORLD_VEHICLE_POLICE_NEXT_TO_CAR', 'CODE_HUMAN_POLICE_CROWD_CONTROL',
    'CODE_HUMAN_POLICE_INVESTIGATE', 'WORLD_HUMAN_COP_IDLES' }
local COP_GROUPS = { 'MP_POLICE', 'MP_POLICE2', 'POLICE_POUND1', 'POLICE_POUND2', 'POLICE_POUND3', 'POLICE_POUND4', 'POLICE_POUND5', 'SANDY_PLANES', 'ARMY_HELI', 'ARMY_GUARD' }
local copsApplied = nil
CreateThread(function()
    while true do
        Wait(1000)
        local off = world.no_cops == true
        if copsApplied ~= off then
            copsApplied = off
            for _, m in ipairs(COP_PEDS) do SetPedModelIsSuppressed(GetHashKey(m), off) end
            for _, m in ipairs(COP_VEHS) do SetVehicleModelIsSuppressed(GetHashKey(m), off) end
            for _, s in ipairs(COP_SCENARIOS) do SetScenarioTypeEnabled(s, not off) end
            for _, g in ipairs(COP_GROUPS) do if DoesScenarioGroupExist(g) then SetScenarioGroupEnabled(g, not off) end end
        end
        -- (SetCreateRandomCops est déjà géré par client/nopolice.lua ; les PNJ restants sont retirés par le serveur)
        if off then
            local p = GetEntityCoords(PlayerPedId())
            ClearAreaOfCops(p.x, p.y, p.z, 400.0, 0)
        end
    end
end)
