/* Interfaces en jeu — noyau : messages du client Lua, petit constructeur DOM, icônes, aperçus pour le panel. Aucune donnée serveur n'est insérée via innerHTML. */
(function () {
'use strict';
const IN_GAME = typeof GetParentResourceName === 'function';
const RES = IN_GAME ? GetParentResourceName() : 'pb_panel';
const PBGame = window.PBGame = { cfg: {}, state: { hunger: 100, thirst: 100, stress: 0, cash: 0, bank: 0 }, handlers: {}, preview: {}, IN_GAME };

PBGame.h = function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k]; if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') { for (const s in v) { if (s.indexOf('--') === 0) el.style.setProperty(s, v[s]); else el.style[s] = v[s]; } }
    else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'readOnly') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  (function add(list) { for (const c of list) { if (c == null || c === false) continue; if (Array.isArray(c)) add(c); else el.appendChild(c.nodeType ? c : document.createTextNode(String(c))); } })(kids);
  return el;
};
const h = PBGame.h;
PBGame.clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

const IC = {
  crosshair: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 3v5M12 16v5M3 12h5M16 12h5', gun: 'M3 8h13l2-2h3v5h-3l-1 2h-4l-1 5H8l1-5H5L3 8zM11 11h3', knife: 'M5 19L18 4c2 1 3 3 2 5L9 20zM5 19l-1 1', ammo: 'M9 4h6l1 5v11H8V9zM8 12h8', home: 'M4 11l8-7 8 7v9h-5v-6H9v6H4z', list: 'M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01', crown: 'M3 8l4 4 5-7 5 7 4-4-2 11H5z', coin2: 'M12 4c4 0 7 1.3 7 3s-3 3-7 3-7-1.3-7-3 3-3 7-3zM5 7v4c0 1.7 3 3 7 3s7-1.3 7-3V7M5 11v4c0 1.7 3 3 7 3s7-1.3 7-3v-4',
  heart: 'M12 20s-8-5-8-11a4.5 4.5 0 018-2.5A4.5 4.5 0 0120 9c0 6-8 11-8 11z', shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
  food: 'M7 3v8a2 2 0 002 2v8M7 3v6M11 3v6M9 3v10M17 3c-2 2-3 5-3 8h3v10', drop: 'M12 3s6 6.5 6 11a6 6 0 01-12 0c0-4.5 6-11 6-11z',
  stress: 'M3 12c2-6 4-6 6 0s4 6 6 0 4-6 6 0', bolt: 'M13 3 5 14h6l-1 7 8-11h-6z', mic: 'M12 3a3 3 0 013 3v6a3 3 0 01-6 0V6a3 3 0 013-3zM6 11a6 6 0 0012 0M12 17v4',
  clock: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2', coins: 'M8 8a6 3 0 1012 0 6 3 0 10-12 0zM8 8v5c0 1.7 2.7 3 6 3s6-1.3 6-3V8M4 12v4c0 1.5 2 2.7 5 3',
  pin: 'M12 21s-6-6-6-11a6 6 0 0112 0c0 5-6 11-6 11zM12 12a2 2 0 100-4 2 2 0 000 4z', fuel: 'M5 21V5a2 2 0 012-2h6a2 2 0 012 2v16M5 21h10M15 9h2a2 2 0 012 2v6a1.5 1.5 0 003 0V9l-3-3',
  engine: 'M4 9h3l2-2h6v3h3v6h-3v2H9l-2-2H4zM2 12h2M20 12h2', info: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v6M12 7.5h.01', check: 'M5 12l5 5L20 7',
  alert: 'M12 4l9 16H3zM12 10v4M12 17h.01', x: 'M6 6l12 12M18 6 6 18', skull: 'M12 3a8 8 0 00-5 14v3h10v-3a8 8 0 00-5-14zM9 12h.01M15 12h.01M10 17v3M14 17v3', cart: 'M3 4h3l2 11h10l2-8H7M10 20h.01M17 20h.01',
  hanger: 'M12 8a2 2 0 10-2-2M12 8v2L3 17h18z', car: 'M5 16V11l2-5h10l2 5v5M3 16h18M7.5 19a1 1 0 100-2 1 1 0 000 2zM16.5 19a1 1 0 100-2 1 1 0 000 2z',
  user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 3.5-6 8-6s8 2 8 6', card: 'M3 6h18v12H3zM3 10h18', hand: 'M8 11V5a1.5 1.5 0 013 0v5M11 10V4a1.5 1.5 0 013 0v6M14 10V6a1.5 1.5 0 013 0v8c0 4-2 7-6 7-3 0-5-2-6-5l-1-4a1.5 1.5 0 013-1',
  chat: 'M4 5h16v11H9l-5 4z', siren: 'M6 18v-6a6 6 0 0112 0v6M4 18h16M12 3v2M3.5 6.5 5 8M20.5 6.5 19 8', chevron: 'M9 6l6 6-6 6', users: 'M9 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM2.5 20c0-3.5 3-5.5 6.5-5.5S15.5 16.5 15.5 20M16 4.5a3.5 3.5 0 010 6.5M18 14.8c2.2.6 3.5 2.3 3.5 5.2', face: 'M12 21a8 8 0 100-16 8 8 0 000 16zM9 10v1.5M15 10v1.5M9 15c1.7 1.6 4.3 1.6 6 0M12 11.5v2', scissors: 'M6 8a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM6 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM8 6.5 20 17M8 17.5 20 7', sparkle: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z', book: 'M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM5 17a3 3 0 013-3h11', dice: 'M5 4h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V5a1 1 0 011-1zM8.5 8.5h.01M15.5 8.5h.01M12 12h.01M8.5 15.5h.01M15.5 15.5h.01', undo: 'M9 14 4 9l5-5M4 9h10a6 6 0 010 12h-3', music: 'M9 18V6l10-2v12M9 18a3 3 0 11-6 0 3 3 0 016 0zM19 16a3 3 0 11-6 0 3 3 0 016 0z', lock: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3', id: 'M3 5h18v14H3zM7 10a2 2 0 104 0 2 2 0 00-4 0zM6 16c.5-2 5.5-2 6 0M14 10h4M14 14h4',
 home: 'M4 11 12 4l8 7v9h-5v-6H9v6H4z', file: 'M6 3h9l4 4v14H6zM14 3v5h5M9 13h6M9 17h6', briefcase: 'M4 8h16v12H4zM9 8V5h6v3M4 13h16', building: 'M5 21V4h10v17M15 9h4v12M8 8h4M8 12h4M8 16h4M3 21h18', crown: 'M4 18h16M4 18l-1-10 5 4 4-7 4 7 5-4-1 10', chart: 'M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-8', power: 'M12 3v8M7 6a8 8 0 1010 0',
};
Object.assign(IC, {
  bag: 'M6 8h12l1 12H5zM9 8V6a3 3 0 016 0v2', tablet: 'M6 3h12a1 1 0 011 1v16a1 1 0 01-1 1H6a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2', phone: 'M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2',
  call: 'M5 4h3.5l2 5-2.3 1.4a11 11 0 005.4 5.4L15 13.5l5 2V19a2 2 0 01-2 2A15 15 0 013 6a2 2 0 012-2z', volume: 'M4 9h4l5-4v14l-5-4H4zM16 9a4 4 0 010 6M18.5 6.5a8 8 0 010 11',
  paw: 'M12 20c-3 0-5-1.5-5-3.5S9.5 13 12 13s5 1.5 5 3.5S15 20 12 20zM6.5 11a1.5 2 0 100-4 1.5 2 0 000 4zM10 8a1.5 2 0 100-4 1.5 2 0 000 4zM14 8a1.5 2 0 100-4 1.5 2 0 000 4zM17.5 11a1.5 2 0 100-4 1.5 2 0 000 4z',
  sliders: 'M4 7h9M17 7h3M4 17h3M11 17h9M13 5v4M7 15v4', globe: 'M12 21a9 9 0 100-18 9 9 0 000 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  link: 'M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1', discord: 'M7 8c3-1.3 7-1.3 10 0l2 9c-1.5 1.2-3 1.8-4.5 2l-1-2c-1 .3-2 .3-3 0l-1 2c-1.5-.2-3-.8-4.5-2zM9.5 13h.01M14.5 13h.01',
  close: 'M6 6l12 12M18 6 6 18', key: 'M14 10a4 4 0 11-3.5 6L4 17l-1-3 1-1 1 1 2-2 1 1 1.5-1.5A4 4 0 0114 10z', map: 'M9 4 3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14', wallet: 'M4 7h14a2 2 0 012 2v9a2 2 0 01-2 2H6a2 2 0 01-2-2zM4 7l12-3v3M16 13h2',
  star: 'M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.3l1-6.2L3 9.7l6.2-.9z', refresh: 'M4 12a8 8 0 0114-5l2-2v6h-6l2.3-2.3A5.5 5.5 0 006 12M20 12a8 8 0 01-14 5l-2 2v-6h6l-2.3 2.3A5.5 5.5 0 0018 12',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z', search: 'M11 18a7 7 0 100-14 7 7 0 000 14zM20 20l-4-4', plus: 'M12 5v14M5 12h14', arrow: 'M5 12h14M13 6l6 6-6 6',
  tag: 'M3 12V4h8l10 10-8 8zM7.5 8h.01', gps: 'M12 21s-6-6-6-11a6 6 0 0112 0c0 5-6 11-6 11zM12 12a2 2 0 100-4 2 2 0 000 4z', gift: 'M4 11h16v9H4zM3 8h18v3H3zM12 8v12M12 8c-2-4-6-3-5 0M12 8c2-4 6-3 5 0',
  wifi: 'M3 9a14 14 0 0118 0M6 12.5a9.5 9.5 0 0112 0M9 16a5 5 0 016 0M12 19.5h.01', battery: 'M3 8h16v8H3zM21 11v2', route: 'M6 19a2 2 0 100-4 2 2 0 000 4zM18 9a2 2 0 100-4 2 2 0 000 4zM8 17h7a3 3 0 000-6H9a3 3 0 010-6h7',
});
Object.assign(IC, {
  calc: 'M6 3h12a1 1 0 011 1v16a1 1 0 01-1 1H6a1 1 0 01-1-1V4a1 1 0 011-1zM8 7h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 18h.01M12 18h.01M16 18h.01',
  back: 'M15 6l-6 6 6 6', trash: 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13', send: 'M4 12l16-8-6 16-3-7z', edit: 'M4 20l4-1 11-11-3-3L5 16z', minus: 'M5 12h14', note: 'M6 3h12v18H6zM9 8h6M9 12h6M9 16h3', backspace: 'M9 5h11v14H9l-6-7zM12 9l5 6M17 9l-5 6',
});
Object.assign(IC, {
  brush: 'M18.5 3.5l2 2-8.5 8.5-3-3zM8.5 11.5c-2.4 0-4 1.6-4 4 0 2-.8 3.2-1.5 4 3.5.5 8.5-.5 8.5-5', copy: 'M9 9h11v11H9zM5 15V4h11', help: 'M12 21a9 9 0 100-18 9 9 0 000 18zM9.5 9.5a2.5 2.5 0 114 2c-1 .7-1.5 1.2-1.5 2.5M12 17h.01',
  bed: 'M3 18V7M3 14h18v4M21 14v-2a3 3 0 00-3-3h-8v5M7 11.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z', image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9.5h.01', palette: 'M12 3a9 9 0 100 18c1.4 0 2-1 1.5-2-.6-1.2.2-2.5 1.6-2.5H18a3 3 0 003-3c0-5-4-10.5-9-10.5zM7.5 11h.01M10 7.5h.01M14.5 7.5h.01M17 11h.01',
});
PBGame.ico = function (name, cls) {
  const NS = 'http://www.w3.org/2000/svg', s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'gi' + (cls ? ' ' + cls : ''));
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', IC[name] || IC.info); s.appendChild(p); return s;
};

PBGame.post = function (ev, data) {
  if (window.__pbGamePost) return window.__pbGamePost(ev, data);
  return fetch('https://' + RES + '/g', { method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify({ ev, data: data || {} }) }).then((r) => r.json()).catch(() => ({}));
};
// plusieurs modules peuvent écouter le même message (ex. « cfg ») : les écouteurs s'ajoutent, ils ne se remplacent pas
PBGame.on = (ev, fn) => { (PBGame.handlers[ev] = PBGame.handlers[ev] || []).push(fn); };

const root = PBGame.root = document.getElementById('game');
const GLASS = { clear: [0.22, 0.30], soft: [0.42, 0.50], solid: [0.66, 0.72], full: [0.88, 0.92] };
PBGame.applyGlass = function () { const g = GLASS[(PBGame.cfg && PBGame.cfg.ui && PBGame.cfg.ui.glass)] || GLASS.solid; root.style.setProperty('--ga-bg', String(g[0])); root.style.setProperty('--ga', String(g[1])); };
// Position du chat, de l'invite « E » et de la barre de progression (réglées dans Placement à l'écran) : bornées ici aussi
PBGame.applyPlace = function () {
  const c = (PBGame.cfg && PBGame.cfg.place) || {}, n = (v, a, b, d) => { v = Number(v); return isFinite(v) ? Math.max(a, Math.min(b, v)) : d; };
  root.style.setProperty('--ch-x', n(c.chat_x, 0, 80, 0.9) + '%'); root.style.setProperty('--ch-y', n(c.chat_y, 0, 80, 22.5) + '%');
  root.style.setProperty('--pp-x', n(c.prompt_x, 0, 100, 50) + '%'); root.style.setProperty('--pp-y', n(c.prompt_y, 0, 100, 82) + '%');
  root.style.setProperty('--gp-x', n(c.prog_x, 0, 100, 50) + '%'); root.style.setProperty('--gp-y', n(c.prog_y, 0, 100, 82) + '%');
};
PBGame.applyGlass();
PBGame.applyPlace();
window.addEventListener('message', (e) => {
  const d = e.data || {};
  if (d.type !== 'g') return;
  if (d.ev === 'cfg') { PBGame.cfg = d.data || {}; PBGame.applyGlass(); PBGame.applyPlace(); }
  else if (d.ev === 'state') PBGame.state = Object.assign(PBGame.state, d.data || {});
  (PBGame.handlers[d.ev] || []).forEach((fn) => { try { fn(d.data || {}); } catch (err) { console.error('game', d.ev, err); } });
});
window.__pbGameMsg = (ev, data) => window.dispatchEvent(new MessageEvent('message', { data: { type: 'g', ev, data } }));

PBGame.hexToRgb = (hex) => { const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return '223,226,231'; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255].join(','); };
PBGame.money = (n) => '$' + (Number(n) || 0).toLocaleString('fr-FR');
// Images envoyées depuis le panel : la configuration contient « asset:<id> » ; le contenu arrive séparément (cache). Les liens https / img/ restent acceptés.
PBGame.assets = {};
// Fête en cours (Halloween / Noël) côté jeu : { id, decor } ou null. Le serveur n'envoie rien si l'option « interfaces des joueurs » est coupée.
PBGame.season = function () { const b = PBGame.cfg && PBGame.cfg.brand; return (b && b.season && (b.season.id === 'halloween' || b.season.id === 'noel')) ? b.season : null; };
// Calque de décor à poser dans une fenêtre de jeu (null si pas de fête ou décor coupé)
PBGame.festEl = function () { const f = PBGame.season(); return f && f.decor !== false ? PBGame.h('div', { class: 'fest fest-' + f.id }) : null; };
// Nom de la base, toujours lu dans la configuration reçue du serveur
PBGame.brandName = function () { const b = PBGame.cfg && PBGame.cfg.brand; return (b && b.name) || ''; };
PBGame.assetUrl = function (v) {
  if (typeof v !== 'string' || !v) return '';
  const m = /^asset:([a-z0-9]{6,32})$/.exec(v);
  if (m) { const d = PBGame.assets[m[1]]; if (d) return d; if (PBGame.wantAsset) PBGame.wantAsset(m[1]); return ''; }
  return /^(https:\/\/|img\/|nui:\/\/|\.\/|\/)[^"'()<>\s]*$/i.test(v) ? v : '';
};
// demande d'une image : en jeu via le client Lua, dans le panel via une requête au serveur (mise en cache)
const wanted = {};
PBGame.wantAsset = function (id) {
  if (wanted[id] && Date.now() - wanted[id] < 4000) return;
  wanted[id] = Date.now();
  if (PBGame.assetFetcher) PBGame.assetFetcher(id); else PBGame.post('asset.want', { id });
};
PBGame.on('asset', (d) => {
  if (!d || !/^[a-z0-9]{6,32}$/.test(d.id || '')) return;
  if (typeof d.uri === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(d.uri)) PBGame.assets[d.id] = d.uri;
  (PBGame.handlers.cfg || []).forEach((fn) => { try { fn(PBGame.cfg); } catch (e) { console.error(e); } });   // redessine ce qui attendait l'image
});
// Sonde du garde-fou côté jeu : y a-t-il vraiment une interface qui attend la souris ? (sinon le client remet le focus à zéro)
PBGame.anyOpen = function () {
  if ((PBGame.uiStack || []).length) return true;
  const panel = document.getElementById('root');
  if (panel && !panel.classList.contains('hidden')) return true;
  const g = document.getElementById('game');
  if (!g) return false;
  const NOT = { 'g-hud': 1, 'g-prompt': 1, 'g-hints': 1, 'g-info': 1, 'g-zone': 1, 'g-test': 1, 'g-gfxhelp': 1, 'g-notify': 1, 'g-death': 1, 'g-tags': 1, 'g-follow': 1, 'g-gxbanner': 1, 'g-gxmedia': 1, 'g-gxscreen': 1 };
  for (const c of g.children) {
    if (!c.id || NOT[c.id] || c.classList.contains('hidden') || !c.childElementCount) continue;
    if (/^g-(ctxinv|ctx)$/.test(c.id) || /^g-(bank|garage|housing|inv|phone|pause|me|menu|umenu|rmenu|shop|wardrobe|creator|welcome|gfx|justice|chat|tablet)/.test(c.id)) return true;
  }
  return false;
};
// le bandeau staff s'efface dès qu'une interface plein écran est ouverte (il ne passe plus par-dessus)
setInterval(() => { try { const g = document.getElementById('game'); document.body.classList.toggle('ui-open', !!(g && PBGame.anyOpen && PBGame.anyOpen())); } catch (e) { /* aperçu */ } }, 400);
// Mode photo du staff : toute l'interface est cachée, sauf les menus (pour pouvoir en sortir)
PBGame.on('photo', (d) => { document.body.classList.toggle('photo-mode', !!(d && d.on)); });
PBGame.on('ui.probe', () => { PBGame.post('ui.state', { open: PBGame.anyOpen() }); });
PBGame.uiStack = [];   // interfaces plein écran ouvertes (la dernière reçoit Échap)
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  const top = PBGame.uiStack[PBGame.uiStack.length - 1];
  if (top && top.onEscape) top.onEscape();
});
})();

// Aperçu à taille de conception fixe (1240×720) réduit pour tenir dans la largeur disponible — lisible sur téléphone
PBGame.fitStage = function (el, DW, DH) {
  DW = DW || 1240; DH = DH || 720;
  const h = PBGame.h;
  const inner = h('div', { class: 'fs-in', style: { width: DW + 'px', height: DH + 'px' } }, el);
  const outer = h('div', { class: 'gstage fs' }, inner);
  function fit() {
    const w = outer.clientWidth; if (!w) return;
    const k = Math.min(1, (w - 2) / DW);
    inner.style.transform = 'scale(' + k + ')';
    inner.style.left = Math.max(0, (w - DW * k) / 2) + 'px';
    outer.style.height = Math.round(DH * k + 2) + 'px';
  }
  requestAnimationFrame(fit);
  if (window.ResizeObserver) new ResizeObserver(fit).observe(outer);
  return outer;
};
