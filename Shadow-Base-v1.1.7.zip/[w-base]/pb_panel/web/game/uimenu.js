/* pb_umenu — rendu « UI » (souris + clavier) des menus : exactement le même visuel que le menu « lib » (web/game/rmenu.js), avec en plus
   clic, survol, flèches cliquables et bouton retour / fermer. La logique (sélection, listes, cases, saisie) reste dans le jeu :
   ce fichier envoie seulement l'indice de la ligne touchée. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;

let host = null, state = { snap: null, brand: null, staff: false }, askEl = null;
const box = () => host || (host = (function () { const e = h('div', { id: 'g-umenu', class: 'hidden' }); G.root.appendChild(e); return e; })());

function post(ev, d) { G.post(ev, d || {}); }
let lastHover = 0;
const cb = {
  select: (i) => post('umenu.select', { i }), change: (i, dir) => post('umenu.change', { i, dir }), input: (i, text) => post('umenu.input', { i, text }),
  back: () => post('umenu.back'), close: () => post('umenu.close'), style: (s) => post('umenu.style', { style: s }),
  hover: (i) => { const t = Date.now(); if (t - lastHover < 60) return; lastHover = t; post('umenu.hover', { i }); },
};

// instantané complet de la pile -> forme attendue par le rendu « lib »
function toRm(s) {
  const items = s.items || [];
  const sel = items.filter((x) => x.kind !== 'separator');
  const idx = sel.findIndex((x) => x.active);
  const cur = items.find((x) => x.active) || {};
  return { title: s.title, subtitle: s.subtitle, items, counter: [idx + 1, sel.length], desc: cur.desc, banner: s.banner, depth: s.depth, path: s.path };
}

function draw(fresh) {
  const b = box();
  if (!state.snap) { G.clear(b); return; }
  const prev = b.querySelector('.rm-list'), keep = prev ? prev.scrollTop : 0;
  G.clear(b);
  const brandName = (state.brand && state.brand.name) || (G.cfg.brand && G.cfg.brand.name) || '';
  const callbacks = Object.assign({}, cb);
  if (G.cfg && G.cfg.menus && G.cfg.menus.ui_allow_choice === false) delete callbacks.style;
  const m = G.rmenu.build(state.staff ? G.rmenu.staffTheme(G.cfg && G.cfg.menus) : (G.cfg && G.cfg.menus), toRm(state.snap), brandName, callbacks);
  if (!fresh) m.classList.add('still');
  b.appendChild(m);
  const list = b.querySelector('.rm-list');
  if (list) {
    list.scrollTop = keep;
    const on = list.querySelector('.rm-r.on');
    if (on) { const lt = list.getBoundingClientRect(), ot = on.getBoundingClientRect(); if (ot.top < lt.top || ot.bottom > lt.bottom) on.scrollIntoView({ block: 'nearest' }); }
  }
}
G.on('umenu.open', (d) => { G.rmenu.restartBanner(); state = { snap: d.menu, brand: d.brand, staff: !!d.staff }; box().classList.remove('hidden'); draw(true); });
G.on('umenu.render', (d) => { if (!host || host.classList.contains('hidden')) return; state.snap = d.menu; state.staff = !!d.staff; if (d.brand) state.brand = d.brand; draw(); });
G.on('umenu.close', () => { if (host) { G.clear(host); host.classList.add('hidden'); } closeAsk(); });
G.on('cfg', () => { if (host && !host.classList.contains('hidden') && state.snap) draw(); });

function closeAsk() { if (askEl) { askEl.remove(); askEl = null; } }
G.on('umenu.ask', (d) => {
  closeAsk();
  const t = G.rmenu.themeOf(G.cfg && G.cfg.menus);
  const inp = h('input', { class: 'um-in big', type: 'text', value: String(d.value || ''), maxlength: String(d.maxlen || 120) });
  const done = (txt) => { closeAsk(); post('umenu.asked', { text: txt }); };
  askEl = h('div', { class: 'um-ask', style: { '--ac': t.accent, '--acr': G.hexToRgb(t.accent), '--bg': t.bg, '--bgr': G.hexToRgb(t.bg), '--tx': t.text, '--mu': t.muted } },
    h('div', { class: 'um-ab' }, h('b', null, String(d.prompt || 'Saisie')), inp,
      h('div', { class: 'um-ar2' }, h('button', { class: 'um-b', onclick: () => done(null) }, 'Annuler'), h('button', { class: 'um-b pri', onclick: () => done(inp.value) }, 'Valider'))));
  inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') done(inp.value); else if (e.key === 'Escape') done(null); });
  box().appendChild(askEl); setTimeout(() => inp.focus(), 30);
});

// clavier : flèches / Entrée / Retour (quand aucune zone de saisie n'a le focus)
document.addEventListener('keydown', (e) => {
  if (!host || host.classList.contains('hidden') || !state.snap || askEl) return;
  const tag = (document.activeElement && document.activeElement.tagName) || '';
  if (tag === 'INPUT') { if (e.key === 'Escape') document.activeElement.blur(); return; }
  const sel = state.snap.sel;
  if (e.key === 'ArrowDown') { post('umenu.move', { dir: 1 }); e.preventDefault(); }
  else if (e.key === 'ArrowUp') { post('umenu.move', { dir: -1 }); e.preventDefault(); }
  else if (e.key === 'ArrowLeft') { cb.change(sel, -1); e.preventDefault(); }
  else if (e.key === 'ArrowRight') { cb.change(sel, 1); e.preventDefault(); }
  else if (e.key === 'Enter') { cb.select(sel); e.preventDefault(); }
  else if (e.key === 'Escape' || e.key === 'Backspace') { cb.back(); e.preventDefault(); }
}, true);

// ---- aperçu du panel : même rendu, avec la souris activée
G.umenu = {
  build: function (theme, snap, brand) { return G.rmenu.build(theme, toRm(snap), brand, Object.assign({}, cb, { select() {}, change() {}, back() {}, close() {}, hover() {}, style: null })); },
};
})();
