/* Réduit une capture d'écran en petit portrait carré (JPEG) avant de l'envoyer au serveur. */
(function () {
'use strict';
const G = window.PBGame;
G.on('photo.shrink', (d) => {
  const src = String(d.img || '');
  if (!/^data:image\/(jpeg|jpg|png);base64,/.test(src) || src.length > 6000000) return;
  const im = new Image();
  im.onload = () => {
    const side = Math.min(im.width, im.height) * 0.8, sx = (im.width - side) / 2, sy = (im.height - side) / 2;
    const c = document.createElement('canvas'); c.width = c.height = 112;
    c.getContext('2d').drawImage(im, sx, sy, side, side, 0, 0, 112, 112);
    G.post('photo.result', { img: c.toDataURL('image/jpeg', 0.7) });
  };
  im.src = src;
});
})();
