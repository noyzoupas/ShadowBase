/* Dessin d'un tag dans un canevas 1024 × 512 (fond transparent) : image (ajustée) ou texte stylisé.
   Utilisé par le menu des tags (aperçu) et par la page interne qui projette le tag sur le mur. Aucun HTML n'est construit : seulement du canevas. */
(function () {
'use strict';
const W = 1024, H = 512;
const FONTS = {
  street: { css: "italic 800 {s}px 'Barlow Condensed', 'Poppins', sans-serif", upper: true, lw: 0.07 },
  bold: { css: "700 {s}px 'Poppins', sans-serif", upper: false, lw: 0.06 },
  script: { css: "italic 700 {s}px 'Poppins', sans-serif", upper: false, lw: 0.06, skew: -0.12 },
  stencil: { css: "600 {s}px 'Barlow Condensed', 'Poppins', sans-serif", upper: true, lw: 0.04, spacing: 10 },
};
const hex = (c, d) => (typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c)) ? c : d;
function drawText(cv, spec) {
  const ctx = cv.getContext('2d');
  const f = FONTS[spec.font] || FONTS.street;
  let t = String(spec.text || '').slice(0, 20);
  if (f.upper) t = t.toUpperCase();
  let size = 360;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  const fit = () => { ctx.font = f.css.replace('{s}', size); if (f.spacing && ctx.letterSpacing !== undefined) ctx.letterSpacing = f.spacing + 'px'; return ctx.measureText(t).width; };
  while (fit() > W * 0.9 && size > 40) size -= 8;
  ctx.save();
  ctx.translate(W / 2, H / 2);
  if (f.skew) ctx.transform(1, 0, f.skew, 1, 0, 0);
  ctx.lineWidth = Math.max(4, size * f.lw * 2);
  ctx.strokeStyle = hex(spec.outline, '#000000');
  ctx.strokeText(t, 0, 0);
  ctx.fillStyle = hex(spec.color, '#ffffff');
  ctx.fillText(t, 0, 0);
  ctx.restore();
}
function drawImg(cv, spec, done) {
  const ctx = cv.getContext('2d');
  const im = new Image();
  im.onload = () => {
    const k = Math.min(W / im.width, H / im.height);
    const w = im.width * k, h = im.height * k;
    ctx.drawImage(im, (W - w) / 2, (H - h) / 2, w, h);
    if (done) done(true);
  };
  im.onerror = () => { if (done) done(false); };
  if (typeof spec.src === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+\/=]+$/.test(spec.src)) im.src = spec.src;
  else if (typeof spec.src === 'string' && /^(img\/|\.\/)[\w\/.\-]+$/.test(spec.src)) im.src = spec.src;
  else if (done) done(false);
}
// spec : { kind:'txt', text, font, color, outline } ou { kind:'img', src }
function draw(cv, spec, done) {
  cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  ctx.clearRect(0, 0, W, H);
  const fonts = (document.fonts && document.fonts.load) ? Promise.all([document.fonts.load("italic 800 100px 'Barlow Condensed'"), document.fonts.load("700 100px 'Poppins'")]).catch(() => {}) : Promise.resolve();
  fonts.then(() => { if (spec && spec.kind === 'img') drawImg(cv, spec, done); else { drawText(cv, spec || {}); if (done) done(true); } });
}
window.PBTagRender = { draw, W, H, fonts: Object.keys(FONTS) };
})();
