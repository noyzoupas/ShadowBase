/* Effets visuels des gestes du staff : bandeau plein écran, média (image/son/vidéo), vue d'écran d'un joueur.
   Tout texte passe par textContent ; une image d'écran n'est acceptée que si c'est un data:image/jpeg. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let banner = null, media = null, screen = null, bt = 0, mt = 0, st = 0;
function drop(el) { if (el && el.parentNode) el.parentNode.removeChild(el); }
function stopMedia() { clearTimeout(mt); if (media) { const v = media.querySelector('video,audio'); if (v) { try { v.pause(); } catch (e) {} } drop(media); media = null; } }
G.on('gx.banner', (d) => {
  clearTimeout(bt); drop(banner);
  const ms = Math.max(3000, Math.min(300000, Number(d.ms) || 8000));
  banner = h('div', { id: 'g-gxbanner' }, h('div', null, String(d.text || '').slice(0, 140)));
  G.root.appendChild(banner);
  bt = setTimeout(() => { drop(banner); banner = null; }, ms);
});
G.on('gx.media', (d) => {
  stopMedia();
  const url = String(d.url || '');
  if (url.slice(0, 8) !== 'https://') return;
  const kind = d.kind === 'video' ? 'video' : d.kind === 'audio' ? 'audio' : 'image';
  let el;
  if (kind === 'image') el = h('img', { src: url, alt: '' });
  else { el = document.createElement(kind); el.src = url; el.autoplay = true; if (kind === 'video') { el.controls = false; } }
  media = h('div', { id: 'g-gxmedia', class: kind }, kind === 'audio' ? null : el);
  if (kind === 'audio') document.body.appendChild(el);
  G.root.appendChild(media);
  mt = setTimeout(() => { if (kind === 'audio') drop(el); stopMedia(); }, Math.max(3000, Math.min(300000, Number(d.ms) || 15000)));
});
G.on('gx.clear', () => { clearTimeout(bt); drop(banner); banner = null; stopMedia(); });
function closeScreen() { clearTimeout(st); drop(screen); screen = null; }
G.on('gx.screen', (d) => {
  if (d.stop) { closeScreen(); return; }
  const img = String(d.img || '');
  if (!/^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/.test(img) || img.length > 900000) return;
  if (!screen) {
    screen = h('div', { id: 'g-gxscreen' }, h('div', { class: 'gxs-t' }, h('i', { class: 'gsh-dot' }), h('span', { class: 'gxs-n' }), h('b', { class: 'gxs-l' })), h('img', { alt: '' }));
    G.root.appendChild(screen);
  }
  screen.querySelector('.gxs-n').textContent = 'Écran de ' + String(d.name || '').slice(0, 60) + ' #' + Number(d.id);
  screen.querySelector('.gxs-l').textContent = d.live ? 'EN DIRECT' : 'CAPTURE';
  screen.querySelector('img').src = img;
  clearTimeout(st);
  st = setTimeout(closeScreen, d.live ? 12000 : 20000);
});
G.preview.gestures = function (box) {
  G.clear(box);
  const px = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><rect width="320" height="180" fill="#25303d"/><circle cx="160" cy="90" r="40" fill="#4a90e2"/></svg>');
  box.appendChild(G.fitStage(h('div', { class: 'tg-scene', style: { width: '900px', height: '300px' } },
    h('div', { id: 'g-gxbanner', style: { position: 'absolute' } }, h('div', null, 'Un membre du staff arrive.')),
    h('div', { id: 'g-gxscreen', style: { position: 'absolute' } }, h('div', { class: 'gxs-t' }, h('i', { class: 'gsh-dot' }), h('span', { class: 'gxs-n' }, 'Écran de Jean Dupont #12'), h('b', { class: 'gxs-l' }, 'EN DIRECT')), h('img', { src: px, alt: '' })))
  , 900, 300));
};
})();
