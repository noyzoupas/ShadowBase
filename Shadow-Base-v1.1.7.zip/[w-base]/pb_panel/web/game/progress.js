/* Barre de progression d'une activité (filière, braquage, blanchiment) : nom + barre qui se remplit. */
(function () {
const G = window.PBGame, h = G.h; let box;
G.on('crime.progress', (d) => {
  if (box) { box.remove(); box = null; }
  if (d.cancel) return;
  const secs = Number(d.secs) || 5;
  box = h('div', { class: 'gp-box' }, h('b', null, String(d.label || '')), h('div', { class: 'gp-bar' }, h('i', { style: { animationDuration: secs + 's' } })));
  G.root.appendChild(box);
  const mine = box; setTimeout(() => { if (box === mine) { box.remove(); box = null; } }, secs * 1000 + 150);
});
G.preview.crime = (el) => {
  G.clear(el);
  const row = (label, node) => h('div', { style: { display: 'grid', gap: '8px', justifyItems: 'center', alignContent: 'start' } }, h('small', { style: { opacity: '.6' } }, label), node);
  const prompt = h('div', { class: 'gp-box', style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none', width: 'auto', display: 'flex', gap: '10px', alignItems: 'center' } }, h('kbd', { style: { padding: '2px 8px', border: '1px solid rgba(223,226,231,.4)', borderRadius: '4px' } }, 'E'), h('b', null, 'Labo de séchage'));
  const bar = h('div', { class: 'gp-box', style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none' } }, h('b', null, 'Braquage de supérette'), h('div', { class: 'gp-bar' }, h('i', { style: { animation: 'none', width: '60%' } })));
  const terr = h('div', { class: 'gp-box', style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none' } }, h('b', null, 'Capture : Grove Street'), h('div', { class: 'gp-bar' }, h('i', { style: { animation: 'none', width: '35%' } })));
  el.appendChild(h('div', { class: 'cx-stage', style: { display: 'grid', gap: '18px', padding: '24px 10px', justifyItems: 'center', alignContent: 'center', height: 'auto' } }, row("Invite près d'un point", prompt), row('Braquage en cours', bar), row('Prise de territoire', terr)));
};
})();
