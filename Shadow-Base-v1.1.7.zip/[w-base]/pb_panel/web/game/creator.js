/* Créateur de personnage v2 : parcours cinématique (identité, famille, visage, cheveux, peau, tenue, histoire, point de départ sur la carte, validation). */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

const MALE = ['Benjamin', 'Daniel', 'Joshua', 'Noah', 'Andrew', 'Juan', 'Alex', 'Isaac', 'Evan', 'Ethan', 'Vincent', 'Angel', 'Diego', 'Adrian', 'Gabriel', 'Michael', 'Santiago', 'Kevin', 'Louis', 'Samuel', 'Anthony'];
const FEMALE = ['Hannah', 'Aubrey', 'Jasmine', 'Gisele', 'Amelia', 'Isabella', 'Zoe', 'Ava', 'Camila', 'Violet', 'Sophia', 'Evelyn', 'Nicole', 'Ashley', 'Gracie', 'Brianna', 'Natalie', 'Olivia', 'Elizabeth', 'Charlotte', 'Emma'];
const SPECIAL = ['Claude', 'Niko', 'John', 'Misty'];
const PARENTS = MALE.concat(FEMALE, SPECIAL);   // index = identifiant du jeu (0 à 45)

const FACE_GROUPS = [
  ['Nez', [0, 1, 2, 3, 4, 5]], ['Sourcils et yeux', [6, 7, 11]], ['Joues et pommettes', [8, 9, 10]], ['Lèvres et menton', [12, 15, 16, 17, 18]], ['Mâchoire et cou', [13, 14, 19]],
];
const FACE = ['Largeur du nez', 'Hauteur de la pointe du nez', 'Longueur du nez', 'Hauteur du pont du nez', 'Affaissement du nez', 'Torsion du nez', 'Hauteur des sourcils', 'Avancée des sourcils',
  'Hauteur des pommettes', 'Largeur des pommettes', 'Largeur des joues', 'Ouverture des yeux', 'Épaisseur des lèvres', 'Largeur de la mâchoire', 'Longueur de la mâchoire', 'Hauteur du menton',
  'Longueur du menton', 'Largeur du menton', 'Fossette du menton', 'Épaisseur du cou'];
const OV_HAIR = [['Barbe', 1, true], ['Sourcils', 2, true], ['Poils du torse', 10, true]];
const OV_SKIN = [['Imperfections', 0], ['Vieillissement', 3], ['Teint', 6], ['Dommages du soleil', 7], ['Grains de beauté', 9], ['Taches du corps', 11], ['Maquillage', 4, true], ['Blush', 5, true], ['Rouge à lèvres', 8, true]];
const COMPS = [['Haut', 11], ['Sous-haut', 8], ['Bras / torse', 3], ['Pantalon', 4], ['Chaussures', 6], ['Accessoires', 7], ['Masque', 1], ['Sac', 5], ['Gilet', 9], ['Écusson', 10]];
const PROPS = [['Chapeau', 0], ['Lunettes', 1], ['Oreilles', 2], ['Montre', 6], ['Bracelet', 7]];
const hairHue = (i) => 'hsl(' + ((i * 37) % 360) + ',' + (i < 8 ? 6 : 45) + '%,' + (i < 8 ? 10 + i * 8 : 38) + '%)';
const rnd = (a, b) => a + Math.random() * (b - a), rndi = (a, b) => Math.floor(rnd(a, b + 1));

const STEP_DEFS = {
  ident: { label: 'Identité', icon: 'user', sub: 'Qui es-tu ? Ces informations ne se changent plus ensuite.', cam: 'face' },
  family: { label: 'Famille', icon: 'users', sub: 'Choisis tes deux parents : ton visage est un mélange des deux.', cam: 'face' },
  face: { label: 'Visage', icon: 'face', sub: 'Affine chaque trait du visage.', cam: 'face' },
  hair: { label: 'Cheveux', icon: 'scissors', sub: 'Coiffure, couleur, barbe et sourcils.', cam: 'face' },
  skin: { label: 'Peau', icon: 'sparkle', sub: 'Teint, imperfections et maquillage.', cam: 'face' },
  outfit: { label: 'Tenue', icon: 'hanger', sub: 'Habille ton personnage. Tu pourras changer dans les magasins.', cam: 'body' },
  story: { label: 'Histoire', icon: 'book', sub: "Quelques lignes sur ton personnage (facultatif).", cam: 'body' },
  spawn: { label: 'Départ', icon: 'pin', sub: 'Choisis où ta vie commence sur la carte.', cam: null },
  final: { label: 'Validation', icon: 'check', sub: 'Relis tout avant de te lancer.', cam: 'body' },
};

function defaults() {
  return { model: 'mp_m_freemode_01', head: { mother: 21, father: 0, shape: 0.5, skin: 0.5 }, face: Array(20).fill(0), hair: { style: 0, color: 0, highlight: 0 }, eye: 0,
    ov: Array.from({ length: 13 }, () => ({ s: 255, o: 1, c: 0 })), comps: Array.from({ length: 12 }, () => ({ d: 0, t: 0 })), props: [] };
}

/* Carte schématique : les points viennent du panel (coordonnées du jeu). Ce n'est pas une carte du jeu, seulement un repère. */
const MAP = { x0: -4000, x1: 4500, y0: -4500, y1: 8500, W: 640, H: 980 };
const mx = (x) => (x - MAP.x0) / (MAP.x1 - MAP.x0) * MAP.W, my = (y) => (MAP.y1 - y) / (MAP.y1 - MAP.y0) * MAP.H;
const LAND = [[-3400, -2900], [-1200, -3700], [1500, -3600], [3600, -2200], [4100, -300], [3600, 1500], [3000, 3600], [2600, 5500], [1200, 7300], [-600, 7500], [-1800, 6600], [-2000, 4800], [-3300, 3500], [-3600, 1200], [-3500, -1000]];
const MCAL = { ax: -5206.4, bx: 11493.2, ay: 8271.8, by: 12556 };   // même calibrage que la carte du panel : x = u*bx + ax ; y = ay - v*by
function spawnMap(points, selected, onPick, acc) {
  const box = h('div', { class: 'gk-map gk-map2', style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } });
  const inner = h('div', { class: 'gk-mi' }, h('img', { class: 'gk-mimg', src: 'img/map.jpg', alt: '', draggable: false }));
  const dots = [];
  points.forEach((p) => {
    const u = (p.x - MCAL.ax) / MCAL.bx, v = (MCAL.ay - p.y) / MCAL.by;
    const d = h('button', { type: 'button', class: 'gk-pt2' + (p.id === selected ? ' on' : ''), style: { left: (u * 100) + '%', top: (v * 100) + '%' }, title: p.label, onclick: () => onPick(p) },
      h('i', { class: 'gk-halo2' }), h('b', { class: 'gk-dot2' }), h('span', { class: 'gk-lab2' }, p.label));
    inner.appendChild(d); dots.push([p, d]);
  });
  box.appendChild(inner);
  box.appendChild(h('span', { class: 'gk-map-note' }, 'Carte de Los Santos'));
  box.select = (id) => dots.forEach(([p, d]) => d.classList.toggle('on', p.id === id));
  return box;
}

// creatorView(cfg, { preview, only, appearance, limits, ... })
function creatorView(cfg, opt) {
  opt = opt || {};
  cfg = cfg || {};
  const preview = !!opt.preview;
  const acc = cfg.c_accent || '#dfe2e7';
  const points = (cfg.spawn_points || []).filter((p) => p.enabled !== false);
  const S = { step: 0, sex: cfg.allow_male === false ? 'f' : 'm', first: '', last: '', dob: '1995-06-15', height: 175, nat: (cfg.nationalities && cfg.nationalities[0]) || '', bio: '', accept: false, tagc: ((G.cfg && G.cfg.tags) || {}).name_color_default || '#d9cb8f',
    spawn: points.length ? points[0].id : '', app: opt.appearance ? JSON.parse(JSON.stringify(opt.appearance)) : defaults(), limits: opt.limits || null };
  let order = ['ident', 'family', 'face', 'hair', 'skin'];
  if (cfg.show_clothes !== false) order.push('outfit');
  if (cfg.ask_bio !== false) order.push('story');
  if (cfg.allow_spawn_choice !== false && points.length) order.push('spawn');
  order.push('final');
  if (opt.only) order = ['outfit'];
  const root = h('div', { class: 'gk' + (preview ? ' gk-prev' : '') + (opt.only ? ' gk-only' : ''), style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } });
  const rail = h('div', { class: 'gk-rail' }), panel = h('div', { class: 'gk-panel' }), head = h('div', { class: 'gk-head' }), body = h('div', { class: 'gk-body' }), err = h('div', { class: 'gk-err hidden' }), nav = h('div', { class: 'gk-nav' });
  const bar = h('i');
  panel.append(h('div', { class: 'gk-prog' }, bar), head, body, err, nav);
  if (!opt.only) root.appendChild(rail);
  root.appendChild(panel);
  let mapEl = null;
  if (!preview) {
    root.appendChild(h('div', { class: 'gk-cams' }, [['face', 'Visage'], ['body', 'Corps'], ['feet', 'Pieds']].map(([m, l]) => h('button', { onclick: () => G.post('creator.cam', { mode: m }) }, l)),
      h('button', { title: 'Tourner à gauche', onclick: () => G.post('creator.rotate', { delta: -25 }) }, '⟲'), h('button', { title: 'Tourner à droite', onclick: () => G.post('creator.rotate', { delta: 25 }) }, '⟳')));
  }

  let timer = null;
  function sendPreview(sexChanged) {
    if (preview) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      S.app.model = S.sex === 'f' ? 'mp_f_freemode_01' : 'mp_m_freemode_01';
      G.post('creator.preview', { appearance: S.app, sexChanged: !!sexChanged }).then((r) => { if (r && r.comps) S.limits = r; });
    }, 70);
  }
  const L = () => S.limits || { comps: Array(12).fill(60), props: { 0: 60, 1: 30, 2: 20, 6: 20, 7: 20 }, overlays: Array(13).fill(12), hairColors: 64, makeupColors: 64 };
  const field = (label, el, hint) => h('div', { class: 'gkf' }, h('label', null, label), el, hint ? h('small', null, hint) : null);
  const slider = (label, min, max, step, get, set, fmt) => {
    const out = h('output', null, fmt ? fmt(get()) : String(get()));
    const i = h('input', { type: 'range', min, max, step, value: get() });
    const paint = () => i.style.setProperty('--p', ((Number(i.value) - min) / (max - min) * 100) + '%');
    i.addEventListener('input', () => { set(Number(i.value)); out.textContent = fmt ? fmt(Number(i.value)) : i.value; paint(); sendPreview(); });
    paint();
    const w = h('div', { class: 'gkf' }, h('label', null, label, out), i);
    w.refresh = () => { i.value = get(); out.textContent = fmt ? fmt(get()) : String(get()); paint(); };
    return w;
  };
  const pick = (label, get, set, max, afterChange) => {
    const out = h('b', null, '');
    const upd = () => { out.textContent = (get() + 1) + ' / ' + Math.max(1, max()); };
    const mv = (d) => { const m = Math.max(1, max()); set(((get() + d) % m + m) % m); upd(); sendPreview(); if (afterChange) afterChange(); };
    upd();
    const w = h('div', { class: 'gkf row' }, h('label', null, label), h('div', { class: 'gks' }, h('button', { onclick: () => mv(-1) }, '‹'), out, h('button', { onclick: () => mv(1) }, '›')));
    w.refresh = upd;
    return w;
  };
  // Grille de toutes les coiffures disponibles (le nombre vient du jeu : DLC compris), en plus des flèches.
  function numGrid(get, set, max) {
    const g = h('div', { class: 'gk-num' });
    const n = Math.max(1, max());
    for (let i = 0; i < n; i++) g.appendChild(h('button', { type: 'button', class: get() === i ? 'on' : '', onclick: () => { set(i); Array.from(g.children).forEach((c, k) => c.classList.toggle('on', k === i)); sendPreview(); } }, String(i + 1)));
    return g;
  }
  function colorGrid(get, set, n) {
    const g = h('div', { class: 'gkc' });
    for (let i = 0; i < n; i++) {
      const b = h('button', { class: get() === i ? 'on' : '', title: 'Teinte ' + (i + 1), style: { background: hairHue(i) }, onclick: () => { set(i); Array.from(g.children).forEach((c, k) => c.classList.toggle('on', k === i)); sendPreview(); } });
      g.appendChild(b);
    }
    return g;
  }
  const section = (title, ...kids) => h('div', { class: 'gk-sec' }, h('div', { class: 'gk-sec-t' }, title), ...kids);
  const overlayCtl = (name, idx, col) => {
    const o = S.app.ov[idx];
    const max = () => (L().overlays[idx] || 1) + 1;
    const out = h('b', null, '');
    const upd = () => { out.textContent = o.s === 255 ? 'Aucun' : (o.s + 1) + ' / ' + (max() - 1); };
    const mv = (d) => { const cur = o.s === 255 ? 0 : o.s + 1; const m = max(); const nx = ((cur + d) % m + m) % m; o.s = nx === 0 ? 255 : nx - 1; upd(); sendPreview(); };
    upd();
    const wrap = h('div', { class: 'gk-card' }, h('div', { class: 'gkf row' }, h('label', null, name), h('div', { class: 'gks' }, h('button', { onclick: () => mv(-1) }, '‹'), out, h('button', { onclick: () => mv(1) }, '›'))),
      slider('Intensité', 0, 1, 0.05, () => o.o, (v) => { o.o = v; }, (v) => Math.round(v * 100) + ' %'));
    if (col) wrap.appendChild(colorGrid(() => o.c, (v) => { o.c = v; }, 64));
    return wrap;
  };

  // --- actions aléatoire / réinitialiser par étape ---
  const actions = {
    family: { random: () => { S.app.head = { mother: rndi(21, 41), father: rndi(0, 20), shape: +rnd(0.1, 0.9).toFixed(2), skin: +rnd(0.1, 0.9).toFixed(2) }; S.app.eye = rndi(0, 31); }, reset: () => { S.app.head = defaults().head; S.app.eye = 0; } },
    face: { random: () => { S.app.face = S.app.face.map(() => +rnd(-0.6, 0.6).toFixed(2)); }, reset: () => { S.app.face = Array(20).fill(0); } },
    hair: { random: () => { S.app.hair = { style: rndi(0, Math.max(0, L().comps[2] - 1)), color: rndi(0, 63), highlight: rndi(0, 63) }; }, reset: () => { S.app.hair = { style: 0, color: 0, highlight: 0 }; } },
    skin: { random: () => { [0, 3, 6, 7, 9, 11].forEach((i) => { S.app.ov[i] = Math.random() < 0.4 ? { s: rndi(0, Math.max(0, (L().overlays[i] || 1) - 1)), o: +rnd(0.2, 0.8).toFixed(2), c: 0 } : { s: 255, o: 1, c: 0 }; }); }, reset: () => { [0, 3, 4, 5, 6, 7, 8, 9, 11, 12].forEach((i) => { S.app.ov[i] = { s: 255, o: 1, c: 0 }; }); } },
    outfit: { random: () => { [11, 8, 4, 6].forEach((id) => { S.app.comps[id] = { d: rndi(0, Math.max(0, L().comps[id] - 1)), t: 0 }; }); }, reset: () => { S.app.comps = defaults().comps; S.app.props = []; } },
  };

  const pages = {
    ident: () => {
      const f1 = h('input', { type: 'text', maxlength: cfg.name_max || 20, value: S.first, placeholder: 'Prénom', oninput: (e) => { S.first = e.target.value; } });
      const f2 = h('input', { type: 'text', maxlength: cfg.name_max || 20, value: S.last, placeholder: 'Nom', oninput: (e) => { S.last = e.target.value; } });
      const dob = h('input', { type: 'date', value: S.dob, oninput: (e) => { S.dob = e.target.value; } });
      const nats = cfg.nationalities || [];
      const nat = nats.length ? h('select', { onchange: (e) => { S.nat = e.target.value; } }, nats.map((n) => h('option', { value: n, selected: n === S.nat }, n))) : h('input', { type: 'text', maxlength: 32, value: S.nat, oninput: (e) => { S.nat = e.target.value; } });
      const hv = h('output', null, S.height + ' cm');
      const hs = h('input', { type: 'range', min: cfg.height_min || 150, max: cfg.height_max || 205, value: S.height });
      const paint = () => hs.style.setProperty('--p', ((S.height - hs.min) / (hs.max - hs.min) * 100) + '%'); paint();
      hs.addEventListener('input', () => { S.height = Number(hs.value); hv.textContent = S.height + ' cm'; paint(); });
      const sexCard = (v, l, ok) => {
        const b = h('button', { class: 'gk-sex' + (S.sex === v ? ' on' : ''), disabled: ok === false, onclick: () => {
          if (S.sex === v) return; S.sex = v; S.app.model = v === 'f' ? 'mp_f_freemode_01' : 'mp_m_freemode_01';
          S.app.head.mother = v === 'f' ? 21 : 21; Array.from(b.parentNode.children).forEach((c) => c.classList.toggle('on', c === b)); sendPreview(true);
        } }, h('span', null, ico('user')), l);
        return b;
      };
      return [h('div', { class: 'gk-sexes' }, sexCard('m', 'Homme', cfg.allow_male), sexCard('f', 'Femme', cfg.allow_female)),
        h('div', { class: 'gk-two' }, field('Prénom', f1), field('Nom', f2)),
        h('div', { class: 'gk-two' }, field('Date de naissance', dob, 'Âge : ' + (cfg.age_min || 18) + ' à ' + (cfg.age_max || 80) + ' ans'), field('Nationalité', nat)),
        h('div', { class: 'gkf' }, h('label', null, 'Taille', hv), hs)];
    },
    family: () => {
      const tiles = (key) => {
        const grid = h('div', { class: 'gk-tiles' });
        PARENTS.forEach((n, i) => { grid.appendChild(h('button', { class: 'gk-tile' + (S.app.head[key] === i ? ' on' : ''), title: n, onclick: () => { S.app.head[key] = i; Array.from(grid.children).forEach((c, k) => c.classList.toggle('on', k === i)); sendPreview(); } }, h('b', null, n.slice(0, 2)), h('small', null, n))); });
        return grid;
      };
      return [section('Parent 1', tiles('mother')), section('Parent 2', tiles('father')),
        slider('Ressemblance des traits (parent 1 → parent 2)', 0, 1, 0.01, () => S.app.head.shape, (v) => { S.app.head.shape = v; }, (v) => Math.round(v * 100) + ' %'),
        slider('Ressemblance du teint (parent 1 → parent 2)', 0, 1, 0.01, () => S.app.head.skin, (v) => { S.app.head.skin = v; }, (v) => Math.round(v * 100) + ' %'),
        section('Yeux', slider('Couleur des yeux', 0, 31, 1, () => S.app.eye, (v) => { S.app.eye = v; }))];
    },
    face: () => FACE_GROUPS.map(([t, idx]) => section(t, ...idx.map((i) => slider(FACE[i], -1, 1, 0.05, () => S.app.face[i], (v) => { S.app.face[i] = v; }, (v) => v.toFixed(2))))),
    hair: () => [
      section('Coiffure', pick('Style', () => S.app.hair.style, (v) => { S.app.hair.style = v; }, () => L().comps[2], () => { const g = document.querySelector('.gk-num'); if (g) Array.from(g.children).forEach((c, k) => c.classList.toggle('on', k === S.app.hair.style)); }),
        field('Toutes les coiffures', numGrid(() => S.app.hair.style, (v) => { S.app.hair.style = v; }, () => L().comps[2])),
        field('Couleur', colorGrid(() => S.app.hair.color, (v) => { S.app.hair.color = v; }, 64), 'Les pastilles donnent un ordre de teintes, pas la couleur exacte du jeu : regarde le personnage.'),
        field('Mèches', colorGrid(() => S.app.hair.highlight, (v) => { S.app.hair.highlight = v; }, 64))),
      section('Pilosité', ...OV_HAIR.map(([n, i, c]) => overlayCtl(n, i, c)))],
    skin: () => [section('Peau et maquillage', ...OV_SKIN.map(([n, i, c]) => overlayCtl(n, i, c)))],
    outfit: () => {
      const items = COMPS.map(([name, id]) => {
        const c = S.app.comps[id]; let tex = 1;
        const texOut = h('b', null, '');
        const upT = () => { texOut.textContent = (c.t + 1) + ' / ' + tex; };
        const loadTex = () => {
          if (preview) { tex = 4; c.t = Math.min(c.t, tex - 1); upT(); return; }
          G.post('creator.textures', { kind: 'comp', id, drawable: c.d }).then((r) => { tex = (r && r.n) || 1; c.t = Math.min(c.t, tex - 1); upT(); });
        };
        loadTex();
        const sTex = h('div', { class: 'gks' }, h('button', { onclick: () => { c.t = ((c.t - 1) % tex + tex) % tex; upT(); sendPreview(); } }, '‹'), texOut, h('button', { onclick: () => { c.t = (c.t + 1) % tex; upT(); sendPreview(); } }, '›'));
        return h('div', { class: 'gk-card' }, pick(name, () => c.d, (v) => { c.d = v; c.t = 0; }, () => L().comps[id], loadTex), h('div', { class: 'gkf row' }, h('label', null, 'Variante'), sTex));
      });
      const props = PROPS.map(([name, id]) => {
        let pr = S.app.props.find((p) => p.id === id); if (!pr) { pr = { id, d: -1, t: 0 }; S.app.props.push(pr); }
        const maxP = () => (L().props[id] || 1);
        const out = h('b', null, ''); const upd = () => { out.textContent = pr.d < 0 ? 'Aucun' : (pr.d + 1) + ' / ' + maxP(); };
        const mv = (d) => { const m = maxP() + 1; const nx = (((pr.d + 1) + d) % m + m) % m; pr.d = nx - 1; pr.t = 0; upd(); sendPreview(); };
        upd();
        return h('div', { class: 'gk-card' }, h('div', { class: 'gkf row' }, h('label', null, name), h('div', { class: 'gks' }, h('button', { onclick: () => mv(-1) }, '‹'), out, h('button', { onclick: () => mv(1) }, '›'))));
      });
      return [section('Vêtements', ...items), section('Accessoires', ...props)];
    },
    story: () => {
      const max = cfg.bio_max || 240;
      const ta = h('textarea', { maxlength: max, rows: 6, placeholder: "D'où viens-tu ? Pourquoi es-tu à Los Santos ? Quel est ton but ?", oninput: (e) => { S.bio = e.target.value; cnt.textContent = S.bio.length + ' / ' + max; } }, S.bio);
      const cnt = h('small', null, S.bio.length + ' / ' + max);
      return [field('Histoire de ton personnage', ta), cnt];
    },
    spawn: () => {
      const info = h('div', { class: 'gk-spinfo' });
      const showInfo = () => { const p = points.find((x) => x.id === S.spawn); G.clear(info); if (p) info.append(h('b', null, p.label), h('p', null, p.desc || '')); };
      const list = h('div', { class: 'gk-splist' });
      const choose = (p, fromMap) => {
        S.spawn = p.id; showInfo(); Array.from(list.children).forEach((c) => c.classList.toggle('on', c.dataset.id === p.id)); if (mapEl && mapEl.select) mapEl.select(p.id);
        if (!preview) G.post('creator.spawn', { id: p.id });
      };
      points.forEach((p) => list.appendChild(h('button', { class: 'gk-sp' + (S.spawn === p.id ? ' on' : ''), 'data-id': p.id, onclick: () => choose(p) }, h('span', null, ico('pin')), h('div', null, h('b', null, p.label), h('small', null, p.desc || '')))));
      showInfo();
      if (!preview) { mapEl = spawnMap(points, S.spawn, (p) => choose(p, true), acc); mapEl.classList.add('gk-map-big'); root.appendChild(mapEl); }
      else { mapEl = spawnMap(points, S.spawn, (p) => choose(p, true), acc); }
      return preview ? [list, mapEl, info] : [list, info];
    },
    final: () => {
      const sp = points.find((x) => x.id === S.spawn);
      const out = [h('div', { class: 'gk-sum' }, h('div', { class: 'gk-sum-n' }, (S.first || '—') + ' ' + (S.last || '—')),
        h('div', { class: 'gk-sum-r' }, h('span', null, S.sex === 'f' ? 'Femme' : 'Homme'), h('span', null, S.dob), h('span', null, S.height + ' cm'), h('span', null, S.nat || '—'), sp ? h('span', null, 'Départ : ' + sp.label) : null),
        S.bio ? h('p', null, S.bio) : null)];
      if (cfg.rules_required) out.push(h('label', { class: 'gk-acc' }, h('input', { type: 'checkbox', checked: S.accept, onchange: (e) => { S.accept = e.target.checked; } }), h('span', null, cfg.rules_text || 'J\'accepte le règlement.')));
      out.push(h('p', { class: 'gk-note' }, "Tu pourras changer de vêtements dans les magasins. L'identité, elle, ne se change plus."));
      return out;
    },
  };

  const cur = () => order[S.step];
  function showError(t) { err.textContent = t || ''; err.classList.toggle('hidden', !t); }
  function cleanupMap() { if (mapEl && mapEl.parentNode === root) root.removeChild(mapEl); mapEl = null; }
  function render() {
    G.clear(body); G.clear(nav); G.clear(rail); G.clear(head); showError(''); cleanupMap();
    const id = cur(), def = id === 'outfit' && opt.only ? { label: opt.title || 'Tenue', sub: opt.subtitle || '', cam: 'body' } : STEP_DEFS[id];
    bar.style.width = ((S.step + 1) / order.length * 100) + '%';
    order.forEach((sid, i) => {
      const d = STEP_DEFS[sid];
      rail.appendChild(h('button', { class: 'gk-rs' + (i === S.step ? ' on' : (i < S.step ? ' done' : '')), title: d.label, onclick: () => { if (i < S.step || validateUpTo(i)) { S.step = i; render(); } } }, ico(d.icon), h('span', null, d.label)));
    });
    const act = actions[id];
    head.append(...[h('div', null, h('small', null, opt.only ? '' : ('Étape ' + (S.step + 1) + ' sur ' + order.length)), h('b', null, def.label), h('p', null, id === 'ident' && !opt.only ? (cfg.welcome || def.sub) : def.sub)),
      act && cfg.allow_random !== false ? h('div', { class: 'gk-ha' }, h('button', { title: 'Au hasard', onclick: () => { act.random(); sendPreview(); render(); } }, ico('dice'), 'Aléatoire'), h('button', { title: 'Remettre à zéro', onclick: () => { act.reset(); sendPreview(); render(); } }, ico('undo'))) : null].filter(Boolean));
    (pages[id]() || []).forEach((e) => body.appendChild(e));
    body.scrollTop = 0;
    root.classList.toggle('gk-wide', id === 'spawn');
    if (!preview && def.cam) G.post('creator.cam', { mode: def.cam });
    if (opt.only) {
      nav.append(h('button', { class: 'gb', onclick: () => { if (opt.onCancel) opt.onCancel(); } }, 'Annuler'), h('button', { class: 'gb pri', onclick: () => { if (opt.onSubmit) opt.onSubmit(S.app); else showError("Aperçu : rien n'est envoyé."); } }, opt.submitLabel || 'Valider'));
      return;
    }
    const last = S.step === order.length - 1;
    nav.append(h('button', { class: 'gb', disabled: S.step === 0, onclick: () => { S.step--; render(); } }, 'Précédent'),
      h('button', { class: 'gb pri', onclick: () => { if (last) submit(); else if (validateStep(true)) { S.step++; render(); } } }, last ? 'Créer mon personnage' : 'Suivant'));
  }
  function validateStep(show) {
    if (cur() !== 'ident') return true;
    const re = /^[A-Za-zÀ-ÖØ-öø-ÿ' -]+$/, mn = cfg.name_min || 2, mx = cfg.name_max || 20;
    for (const [v, l] of [[S.first.trim(), 'Prénom'], [S.last.trim(), 'Nom']]) {
      if (v.length < mn || v.length > mx || !re.test(v)) { if (show) showError(l + ' : ' + mn + ' à ' + mx + ' lettres (accents, espace, tiret et apostrophe autorisés).'); return false; }
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(S.dob)) { if (show) showError('Date de naissance invalide.'); return false; }
    return true;
  }
  function validateUpTo(i) { const keep = S.step; for (let k = S.step; k < i; k++) { S.step = k; if (!validateStep(true)) { return false; } } S.step = keep; return true; }
  function submit() {
    if (preview) { showError("Aperçu : rien n'est envoyé."); return; }
    if (cfg.rules_required && !S.accept) { showError('Accepte le règlement pour continuer.'); return; }
    S.app.model = S.sex === 'f' ? 'mp_f_freemode_01' : 'mp_m_freemode_01';
    G.post('creator.submit', { data: { firstname: S.first.trim(), lastname: S.last.trim(), dob: S.dob, sex: S.sex, height: S.height, nationality: S.nat, appearance: S.app, bio: S.bio.trim(), spawn_id: S.spawn, accept: !!S.accept } });
  }
  render();
  return { el: root, showError, setLimits: (l) => { S.limits = l; }, render, destroy: cleanupMap };
}
G.creatorView = creatorView;
G.spawnMap = spawnMap;

let view = null;
G.on('creator.open', (d) => {
  const r = document.getElementById('g-creator') || (function () { const e = h('div', { id: 'g-creator' }); G.root.appendChild(e); return e; })();
  G.clear(r); r.classList.remove('hidden');
  view = creatorView(d.cfg || {}, { limits: d.limits });
  r.appendChild(view.el);
});
G.on('creator.error', (d) => { if (view) view.showError(d.text); });
G.on('creator.close', () => { const r = document.getElementById('g-creator'); if (view && view.destroy) view.destroy(); if (r) { G.clear(r); r.classList.add('hidden'); } view = null; });

G.preview.creator = function (box, cfg) {
  G.clear(box);
  const v = creatorView(cfg, { preview: true });
  box.appendChild(h('div', { class: 'gstage tall gk-stage' }, v.el));
};
G.preview.spawnmap = function (box, cfg) {
  G.clear(box);
  const pts = (cfg.spawn_points || []).filter((p) => p.enabled !== false);
  const info = h('div', { class: 'gk-spinfo' }, pts.length ? h('p', null, 'Clique un point pour voir sa fiche.') : h('p', null, 'Aucun point actif : les joueurs apparaîtront à la position par défaut.'));
  let m;
  m = spawnMap(pts, '', (p) => { m.select(p.id); G.clear(info); info.append(h('b', null, p.label), h('p', null, p.desc || '')); }, cfg.c_accent || '#dfe2e7');
  box.appendChild(h('div', { class: 'gk-spprev' }, m, info));
};

})();
