/* Armurerie : compte à rebours de l'essai d'une arme (l'interface d'achat est dans shopflow.js). */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

// état de l'essai : compte à rebours en bas de l'écran (la boutique est fermée pendant l'essai pour pouvoir tirer)
let tIv = null;
G.on('shop.testState', (d) => {
  let t = document.getElementById('g-test');
  if (!t) { t = h('div', { id: 'g-test' }); G.root.appendChild(t); }
  if (tIv) { clearInterval(tIv); tIv = null; }
  G.clear(t);
  if (d.text) { t.classList.remove('hidden'); t.appendChild(h('span', null, d.text)); setTimeout(() => t.classList.add('hidden'), 3500); return; }
  if (d.done) { t.classList.add('hidden'); return; }
  let left = Math.max(1, Math.round(d.seconds || 20));
  const lab = h('b', null, left + ' s');
  t.classList.remove('hidden'); t.appendChild(h('span', null, ico('shield'), 'Essai en cours ', lab, h('kbd', null, 'X'), 'pour terminer'));
  tIv = setInterval(() => { left -= 1; lab.textContent = Math.max(0, left) + ' s'; if (left <= 0) { clearInterval(tIv); tIv = null; } }, 1000);
});
})();
