/* Tickets (/ticket) : réutilise la tablette (pages, tableaux, formulaires) dans une fenêtre dédiée. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let cur = null;
const host = () => document.getElementById('g-ticket') || (function () { const e = h('div', { id: 'g-ticket', class: 'hidden' }); G.root.appendChild(e); return e; })();
G.on('ticket.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = G.tabletView({ frame: d.frame, page: d.page, onClose: () => G.post('ticket.close', {}), onPage: (p) => G.post('ticket.page', { page: p }), onAct: (n, pl, p) => G.post('ticket.act', { name: n, payload: pl, page: p }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'ticket'); G.uiStack.push({ id: 'ticket', onEscape: () => G.post('ticket.close', {}) });
});
G.on('ticket.page', (d) => { if (cur) cur.set(d); });
G.on('ticket.result', (d) => { if (!cur) return; cur.set(d); cur.say(d.ok, d.msg); });
G.on('ticket.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'ticket'); });
})();
