/* Chat et menu d'interaction. Tout texte reçu est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

// ---------- chat ----------
const KIND_LABEL = { say: '', me: '/me', do: '/do', ooc: 'OOC', announce: 'ANNONCE' };
function chatLine(cfg, m) {
  const kind = KIND_LABEL[m.kind] != null ? m.kind : 'say';
  const col = cfg['c_' + kind] || '#ffffff';
  const body = kind === 'me' || kind === 'do' ? [h('b', null, m.name), ' ', String(m.text)] : [h('b', null, m.name + (kind === 'announce' ? '' : ' ')), kind === 'announce' ? ' ' : (kind === 'ooc' ? '(OOC) ' : ''), String(m.text)];
  const el = h('div', { class: 'gch-l gch-' + kind, style: { '--cc': col } }, cfg.show_time && m.at ? h('i', null, m.at) : null, kind === 'announce' ? h('em', null, 'ANNONCE') : null, body);
  return el;
}
let log = null, input = null, wrap = null, sug = null, cmds = [], pick = 0, shown = [];
// Suggestions de commandes : la liste arrive à l'ouverture du chat ; ↑ ↓ pour choisir, Tab pour compléter
function drawSugg() {
  G.clear(sug); shown = [];
  const v = input.value;
  if (v[0] !== '/') { sug.classList.add('hidden'); return; }
  const word = v.slice(1).split(' ')[0].toLowerCase(), typedArgs = v.includes(' ');
  shown = cmds.filter((c) => typedArgs ? c.name.toLowerCase() === word : c.name.toLowerCase().startsWith(word)).slice(0, 8);
  if (!shown.length) { sug.classList.add('hidden'); return; }
  pick = Math.min(pick, shown.length - 1);
  shown.forEach((c, i) => {
    const ps = (c.params || []).map((p) => h('i', { title: p.help || '' }, '[' + p.name + ']'));
    sug.appendChild(h('div', { class: 'gch-s' + (i === pick ? ' on' : ''), onmousedown: (e) => { e.preventDefault(); input.value = '/' + c.name + ' '; pick = 0; drawSugg(); input.focus(); } },
      h('b', null, '/' + c.name), ps.length ? ' ' : null, ps, c.help ? h('small', null, c.help) : null));
  });
  sug.classList.remove('hidden');
}
function chatBox() {
  if (wrap) return wrap;
  log = h('div', { class: 'gch-log' });
  input = h('input', { type: 'text', class: 'gch-in', maxlength: 500, placeholder: 'Écris un message, ou /me /do /ooc…' });
  sug = h('div', { class: 'gch-sug hidden' });
  input.addEventListener('input', () => { pick = 0; drawSugg(); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { const t = input.value; input.value = ''; drawSugg(); G.post('chat.submit', { text: t }); }
    else if (e.key === 'Escape') { input.value = ''; drawSugg(); G.post('chat.close', {}); }
    else if (e.key === 'Tab') { e.preventDefault(); if (shown[pick]) { input.value = '/' + shown[pick].name + ' '; pick = 0; drawSugg(); } }
    else if (e.key === 'ArrowDown' && shown.length) { e.preventDefault(); pick = (pick + 1) % shown.length; drawSugg(); }
    else if (e.key === 'ArrowUp' && shown.length) { e.preventDefault(); pick = (pick - 1 + shown.length) % shown.length; drawSugg(); }
    e.stopPropagation();
  });
  wrap = h('div', { id: 'g-chat' }, log, h('div', { class: 'gch-bar hidden' }, input, sug));
  G.root.appendChild(wrap);
  return wrap;
}
function pushLine(el, cfg, box) {
  box.appendChild(el);
  while (box.children.length > 60) box.firstChild.remove();
  box.scrollTop = box.scrollHeight;
  const fade = Number(cfg.fade) || 0;
  if (fade > 0) setTimeout(() => el.classList.add('old'), fade * 1000);
}
G.on('chat.msg', (m) => { const w = chatBox(); pushLine(chatLine(G.cfg.chat || {}, m), G.cfg.chat || {}, log); });
G.on('chat.clear', () => { chatBox(); G.clear(log); });
G.on('chat.open', (d) => {
  const w = chatBox(); w.classList.add('open'); w.querySelector('.gch-bar').classList.remove('hidden'); input.value = '';
  cmds = Array.isArray(d && d.cmds) ? d.cmds.filter((c) => c && typeof c.name === 'string').slice(0, 400) : cmds;
  drawSugg(); setTimeout(() => input.focus(), 30);
});
G.on('chat.close', () => { if (!wrap) return; wrap.classList.remove('open'); wrap.querySelector('.gch-bar').classList.add('hidden'); input.blur(); });

G.preview.chat = function (box, cfg) {
  G.clear(box);
  const l = h('div', { class: 'gch-log static' });
  [['say', 'Camille Roux', 'Bonjour, vous avez vu passer une berline noire ?'], ['me', 'Camille Roux', "regarde autour d'elle."], ['do', 'Camille Roux', 'Son regard est inquiet.'], ['ooc', 'Alex', 'je reviens dans 5 minutes'], ['announce', 'Annonce', 'Redémarrage du serveur dans 10 minutes.']]
    .forEach((s) => l.appendChild(chatLine(cfg, { kind: s[0], name: s[1], text: s[2], at: '21:04' })));
  box.appendChild(h('div', { class: 'gstage' }, h('div', { id: 'g-chat', class: 'static' }, l)));
};

// ---------- menu d'interaction ----------
function menuView(entries, defs, cfg, onPick, onClose) {
  const acc = cfg.c_accent || '#dfe2e7';
  entries = Array.isArray(entries) ? entries : [];
  const list = entries.filter((k) => defs[k]);
  const root = h('div', { class: 'gm gm-' + (cfg.style || 'radial'), style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } });
  const label = h('div', { class: 'gm-c' }, h('b', null, "Interaction"), h('small', null, list.length ? 'Choisis une action' : 'Aucune action configurée'));
  if ((cfg.style || 'radial') === 'radial') {
    const R = 128, n = list.length;
    const ring = h('div', { class: 'gm-ring' }, label);
    list.forEach((k, i) => {
      const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
      const b = h('button', { class: 'gm-b', style: { left: 'calc(50% + ' + (Math.cos(a) * R).toFixed(1) + 'px)', top: 'calc(50% + ' + (Math.sin(a) * R).toFixed(1) + 'px)' }, onclick: () => onPick(k),
        onmouseenter: () => { label.firstChild.textContent = defs[k].label; label.lastChild.textContent = ''; } }, ico(defs[k].icon));
      b.title = defs[k].label; ring.appendChild(b);
    });
    root.appendChild(ring);
  } else {
    const l = h('div', { class: 'gm-list' }, h('div', { class: 'gm-lh' }, h('b', null, 'Interaction')));
    list.forEach((k) => l.appendChild(h('button', { class: 'gm-r', onclick: () => onPick(k) }, h('span', null, ico(defs[k].icon)), defs[k].label)));
    if (!list.length) l.appendChild(h('div', { class: 'gs-empty' }, 'Aucune action configurée.'));
    root.appendChild(l);
  }
  if (onClose) root.addEventListener('mousedown', (e) => { if (e.target === root) onClose(); });
  return root;
}
G.on('menu.open', (d) => {
  let r = document.getElementById('g-menu');
  if (!r) { r = h('div', { id: 'g-menu' }); G.root.appendChild(r); }
  G.clear(r); r.classList.remove('hidden');
  r.appendChild(menuView(d.entries || [], d.defs || {}, d.cfg || {}, (k) => G.post('menu.pick', { entry: k }), () => G.post('menu.close', {})));
  G.uiStack.push({ id: 'menu', onEscape: () => G.post('menu.close', {}) });
});
G.on('menu.close', () => { const r = document.getElementById('g-menu'); if (r) { G.clear(r); r.classList.add('hidden'); } G.uiStack = G.uiStack.filter((u) => u.id !== 'menu'); });

G.preview.interact = function (box, cfg, blk) {
  G.clear(box);
  box.appendChild(h('div', { class: 'gstage gm-stage' }, menuView(cfg.entries || [], (blk && blk.entries) || {}, cfg, () => {}, null)));
};
})();
