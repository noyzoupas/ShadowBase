/* Barre d'aide en bas de l'écran : touches + explications courtes (noclip, vêtements…). Purement visuelle, ne capte pas la souris.
   Jeu → NUI : G.send('hints', { items: [{ k: 'CTRL', t: 'Ralenti' }, { k: 'mouse', t: 'Vitesse 0.5' }] }) ; liste vide = masquer.
   NUI → NUI : G.hints.set([...]) / G.hints.clear(). Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null;
const host = () => el || (el = (function () { const e = h('div', { id: 'g-hints', class: 'hidden' }); G.root.appendChild(e); return e; })());

function mouse() {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'hn-mouse');
  s.innerHTML = '<rect x="6" y="2" width="12" height="20" rx="6" fill="none" stroke="currentColor" stroke-width="2"/><rect x="11" y="6" width="2" height="5" rx="1" fill="currentColor"/>';
  return s;
}
function set(items) {
  const r = host(); G.clear(r);
  const list = (Array.isArray(items) ? items : []).slice(0, 8);
  if (!list.length) { r.classList.add('hidden'); return; }
  list.forEach((it) => {
    if (!it) return;
    const k = String(it.k == null ? '' : it.k).slice(0, 24), t = String(it.t == null ? '' : it.t).slice(0, 48);
    r.appendChild(h('span', { class: 'hn' },
      k === 'mouse' ? h('i', { class: 'hn-k hn-m' }, mouse()) : (k ? h('i', { class: 'hn-k' }, k) : null),
      h('b', null, t)));
  });
  r.classList.remove('hidden');
}
G.hints = { set, clear() { set([]); } };
G.on('hints', (d) => set(d && d.items));
G.preview = G.preview || {};
G.preview.hints = function (box) {
  G.clear(box);
  const stage = h('div', { class: 'hn-stage' }); box.appendChild(stage);
  const bar = h('div', { id: 'g-hints', class: 'in-preview' });
  [['CTRL', 'Ralenti'], ['SHIFT', 'Boost'], ['mouse', 'Vitesse 0.5']].forEach(([k, t]) => bar.appendChild(h('span', { class: 'hn' }, k === 'mouse' ? h('i', { class: 'hn-k hn-m' }, mouse()) : h('i', { class: 'hn-k' }, k), h('b', null, t))));
  stage.appendChild(bar);
};
})();
