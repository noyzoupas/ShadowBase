/* Poste radio (F4) : écran LCD, pavé numérique, volume, raccourcis vers les canaux de son métier.
   L'interface ne fait que demander : le serveur valide la fréquence et répond avec l'état réel. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

G.radioView = function (opts) {
  const st = { ch: 0, label: '', entry: '', max: 999, ranges: [], vol: 30, voice: true, talk: 'LMENU', msg: null, bad: false };
  const dev = h('div', { class: 'rd-dev' });
  let msgT = null;
  function say(text, bad) { st.msg = text || null; st.bad = !!bad; clearTimeout(msgT); if (text) msgT = setTimeout(() => { st.msg = null; draw(); }, 3500); draw(); }
  const pad = (n) => String(n).padStart(3, '0');
  function press(k) {
    if (k === 'C') st.entry = '';
    else if (k === 'OK') { const n = Number(st.entry); if (n >= 1) { opts.join(n); st.entry = ''; } else say('Tape une fréquence.', true); return; }
    else if (st.entry.length < String(st.max).length) st.entry = (st.entry + k).replace(/^0+/, '');
    draw();
  }
  function step(d) { const base = st.entry ? Number(st.entry) : st.ch; const n = Math.min(st.max, Math.max(1, (base || 0) + d)); st.entry = ''; opts.join(n); }
  function keyLabel(k) { return { LMENU: 'Alt gauche', RMENU: 'Alt droit', CAPITAL: 'Verr. Maj', LCONTROL: 'Ctrl gauche', LSHIFT: 'Maj gauche' }[k] || k; }
  function draw() {
    G.clear(dev);
    const on = st.ch > 0;
    const shown = st.entry ? st.entry : on ? pad(st.ch) : '---';
    dev.appendChild(h('i', { class: 'rd-ant' }));
    const lcd = h('div', { class: 'rd-lcd' + (on ? ' on' : '') + (st.entry ? ' typing' : '') },
      h('div', { class: 'rd-top' }, h('span', null, on ? 'EN LIGNE' : 'ÉTEINTE'), h('span', null, 'VOL ' + st.vol)),
      h('b', null, st.entry ? shown : (on ? 'CH ' + shown : shown)),
      h('small', null, st.msg ? st.msg : st.entry ? 'OK pour rejoindre' : on ? (st.label || 'Fréquence libre') : 'Choisis une fréquence'));
    if (st.msg && st.bad) lcd.classList.add('err');
    dev.appendChild(lcd);
    dev.appendChild(h('div', { class: 'rd-row' },
      h('button', { type: 'button', class: 'rd-b', title: 'Fréquence précédente', onclick: () => step(-1) }, '◀'),
      h('button', { type: 'button', class: 'rd-b pw' + (on ? ' on' : ''), title: on ? 'Éteindre' : 'Allumer', onclick: () => (on ? opts.leave() : (st.entry ? press('OK') : opts.join(st.last || 1))) }, ico('power')),
      h('button', { type: 'button', class: 'rd-b', title: 'Fréquence suivante', onclick: () => step(1) }, '▶')));
    const keys = h('div', { class: 'rd-keys' });
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].forEach((k) => keys.appendChild(h('button', { type: 'button', class: 'rd-k' + (k === 'OK' ? ' ok' : k === 'C' ? ' c' : ''), onclick: () => press(k) }, k)));
    dev.appendChild(keys);
    const vol = h('input', { type: 'range', min: 0, max: 100, step: 5, value: st.vol, class: 'rd-vol', 'aria-label': 'Volume' });
    vol.addEventListener('input', () => { st.vol = Number(vol.value); dev.querySelector('.rd-top span:last-child').textContent = 'VOL ' + st.vol; });
    vol.addEventListener('change', () => opts.vol(st.vol));
    dev.appendChild(h('label', { class: 'rd-vl' }, h('span', null, 'Volume'), vol));
    const mine = st.ranges.filter((r) => r.ok);
    if (mine.length) dev.appendChild(h('div', { class: 'rd-fav' }, mine.slice(0, 6).map((r) => h('button', { type: 'button', class: 'rd-chip' + (st.ch >= r.from && st.ch <= r.to ? ' on' : ''), onclick: () => opts.join(r.from) }, r.label + ' ' + r.from + (r.to > r.from ? '–' + r.to : '')))));
    dev.appendChild(h('p', { class: 'rd-hint' }, st.voice === false ? 'Voix indisponible sur le serveur.' : h('span', null, 'Parler : maintiens ', h('kbd', null, keyLabel(st.talk)), ' · Échap pour ranger')));
  }
  function set(d) {
    if (!d) return;
    ['ch', 'label', 'max', 'ranges', 'vol', 'voice', 'talk'].forEach((k) => { if (d[k] != null) st[k] = d[k]; });
    if (st.ch > 0) st.last = st.ch;
    if (d.kicked) say('Retiré de la fréquence.', true);
    else if (d.ok === false && d.msg) say(d.msg, true);
    else if (d.ev === 'state' && d.ok) say(st.ch > 0 ? 'Fréquence ' + pad(st.ch) + ' rejointe.' : 'Radio éteinte.', false);
    else draw();
  }
  draw();
  return { el: dev, set };
};

let cur = null;
const host = () => document.getElementById('g-radio') || (function () { const e = h('div', { id: 'g-radio', class: 'hidden' }); G.root.appendChild(e); return e; })();
G.on('radio.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = G.radioView({ join: (ch) => G.post('radio.join', { ch }), leave: () => G.post('radio.leave', {}), vol: (v) => G.post('radio.vol', { vol: v }) });
  r.appendChild(cur.el); cur.set(d);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'radio'); G.uiStack.push({ id: 'radio', onEscape: () => G.post('radio.close', {}) });
});
G.on('radio.state', (d) => { if (cur) cur.set(d); });
G.on('radio.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'radio'); });

// aperçu dans le panel
G.preview.radio = function (box) {
  G.clear(box);
  const rv = G.radioView({ join: (ch) => setTimeout(() => rv.set({ ev: 'state', ok: true, ch, label: ch <= 10 ? 'Police' : '' }), 30), leave: () => setTimeout(() => rv.set({ ev: 'state', ok: true, ch: 0, label: '' }), 30), vol: () => {} });
  rv.set({ ev: 'open', ch: 3, label: 'Police', max: 999, vol: 40, voice: true, talk: 'CAPITAL', ranges: [{ label: 'Police', from: 1, to: 10, ok: true }, { label: 'Secours', from: 11, to: 20, ok: false }] });
  box.appendChild(G.fitStage(h('div', { class: 'gph-prev' }, h('div', { class: 'rd-prev' }, rv.el)), 1240, 820));
};
})();
