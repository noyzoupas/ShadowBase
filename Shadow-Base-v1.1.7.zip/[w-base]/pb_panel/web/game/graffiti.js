/* Menu des tags : choisir un tag de la bibliothèque (images envoyées depuis le panel) ou écrire un texte stylisé, voir l'aperçu transparent,
   régler la taille puis lancer la pose (le jeu affiche alors le tag en transparence sur le mur visé). Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

let host = null, st = null, view = 'lib', pick = null, txt = { text: '', font: 'street', color: '#ffffff', outline: '#111111' }, size = 1.4, live = true, last = null;
const root = () => host || (host = (function () { const e = h('div', { id: 'g-gfx', class: 'hidden' }); G.root.appendChild(e); return e; })());
const send = (n, d) => { if (live) G.post(n, d || {}); };

function spec() {
  if (view === 'txt') return { kind: 'txt', text: txt.text || 'Tag', font: txt.font, color: txt.color, outline: txt.outline };
  const t = pick && (st.tags || []).find((x) => x.id === pick);
  return t ? { kind: 'img', src: G.assetUrl(t.img) } : null;
}
function paint(cv) {
  const s = spec();
  if (!s || (s.kind === 'img' && !s.src)) { const c = cv.getContext('2d'); cv.width = 1024; cv.height = 512; c.clearRect(0, 0, 1024, 512); return; }
  if (window.PBTagRender) window.PBTagRender.draw(cv, s);
}

function draw() {
  const r = root();
  G.clear(r);
  if (!st) return;
  const tabBtn = (id, label, i) => h('button', { type: 'button', class: 'gx-tab' + (view === id ? ' on' : ''), onclick: () => { view = id; draw(); } }, ico(i), label);
  const tabs = h('div', { class: 'gx-tabs' }, tabBtn('lib', 'Bibliothèque', 'image'), st.allowText ? tabBtn('txt', 'Texte', 'chat') : null);
  const body = h('div', { class: 'gx-body' });
  if (view === 'lib') {
    const grid = h('div', { class: 'gx-grid' });
    if (!(st.tags || []).length) grid.appendChild(h('p', { class: 'gx-mu' }, "Aucun tag dans la bibliothèque. Un administrateur peut en ajouter depuis le panel."));
    (st.tags || []).forEach((t) => {
      const u = G.assetUrl(t.img);
      grid.appendChild(h('button', { type: 'button', class: 'gx-tile' + (pick === t.id ? ' on' : ''), onclick: () => { pick = t.id; draw(); } },
        u ? h('img', { src: u, alt: '' }) : h('i', { class: 'gx-ph' }), h('span', null, t.name), t.gang ? h('small', null, 'Logo de groupe') : null));
    });
    body.appendChild(grid);
  } else {
    const inp = h('input', { type: 'text', class: 'gx-in', maxlength: '20', placeholder: 'Ton texte (20 caractères)', value: txt.text });
    inp.addEventListener('keydown', (e) => e.stopPropagation());
    inp.addEventListener('input', () => { txt.text = inp.value; const cv = document.getElementById('gx-cv'); if (cv) paint(cv); });
    const fonts = h('div', { class: 'gx-chips' }, (st.fonts || []).map((f) => h('button', { type: 'button', class: 'gx-chip' + (txt.font === f.id ? ' on' : ''), onclick: () => { txt.font = f.id; draw(); } }, f.label)));
    const sw = (key) => h('div', { class: 'gx-sw' }, (st.colors || []).map((c) => h('button', { type: 'button', 'aria-label': c, class: 'gx-c' + (txt[key] === c ? ' on' : ''), style: { background: c }, onclick: () => { txt[key] = c; draw(); } })));
    body.appendChild(h('div', { class: 'gx-f' }, h('label', null, 'Texte'), inp, h('label', null, 'Style'), fonts, h('label', null, 'Couleur'), sw('color'), h('label', null, 'Contour'), sw('outline')));
  }
  const cv = h('canvas', { id: 'gx-cv', class: 'gx-cv', width: '1024', height: '512' });
  const wall = h('div', { class: 'gx-wall' }, cv, h('span', null, 'Aperçu : le tag sera transparent sur le mur avant la pose'));
  const sl = h('input', { type: 'range', min: String(st.wMin), max: String(st.wMax), step: '0.1', value: String(size) }), out = h('output', null, size.toFixed(1) + ' m');
  sl.addEventListener('input', () => { size = Number(sl.value); out.textContent = size.toFixed(1) + ' m'; });
  const ready = view === 'txt' ? (txt.text || '').trim().length >= 2 : !!pick;
  const go = h('button', { type: 'button', class: 'gx-go', disabled: ready ? null : 'disabled', onclick: () => {
    const t = view === 'txt' ? { kind: 'txt', text: txt.text.trim(), font: txt.font, color: txt.color, outline: txt.outline, w: size } : { kind: 'img', ref: pick, w: size };
    last = t; send('gfx.choose', t);
  } }, ico('brush'), 'Choisir un mur');
  const note = st.item ? h('p', { class: 'gx-mu' }, 'Consomme 1 « ' + st.item + ' » par tag.') : null;
  r.appendChild(h('div', { class: 'gx-card' },
    h('div', { class: 'gx-h' }, h('b', null, 'Menu des tags'), h('small', null, (st.gang ? st.gang.label + ' · ' : '') + st.mine + ' / ' + st.max + ' tags posés'),
      h('button', { type: 'button', class: 'gx-x', 'aria-label': 'Fermer', onclick: () => send('gfx.close') }, ico('x'))),
    tabs, h('div', { class: 'gx-main' }, body, h('div', { class: 'gx-side' }, wall, h('div', { class: 'gx-sz' }, h('label', null, 'Taille'), sl, out), note, go,
      h('p', { class: 'gx-mu' }, 'Dans le jeu : molette = taille, Q / E = rotation, clic gauche = poser, clic droit = annuler.')))));
  paint(cv);
}

function open(d) {
  st = d.data || {}; live = true; view = (st.tags || []).length || !st.allowText ? 'lib' : 'txt'; pick = null;
  root().classList.remove('hidden'); draw();
  G.uiStack = G.uiStack.filter((u) => u.id !== 'gfx');
  G.uiStack.push({ id: 'gfx', onEscape: () => send('gfx.close') });
}
G.on('gfx.open', open);
G.on('gfx.close', () => { st = null; if (host) { G.clear(host); host.classList.add('hidden'); } G.uiStack = G.uiStack.filter((u) => u.id !== 'gfx'); });
G.on('asset', () => { if (st && host && !host.classList.contains('hidden')) draw(); });
G.on('gfx.help', (d) => {
  let el = document.getElementById('g-gfxhelp');
  if (d.stop) { if (el) el.remove(); return; }
  if (!el) { el = h('div', { id: 'g-gfxhelp' }); G.root.appendChild(el); }
  el.textContent = String(d.text || '').slice(0, 160);
  el.classList.toggle('bad', !!d.bad);
});

G.preview.graffiti = function (box) {
  G.clear(box);
  const pl = live, ps = st, ph = host, pv = view, pp = pick;
  live = false; st = { tags: [{ id: 't1', name: 'Logo Ballas', img: 'img/cards/city.jpg', gang: 'ballas' }, { id: 't2', name: 'Cible', img: 'img/cards/city.jpg' }], fonts: [{ id: 'street', label: 'Rue' }, { id: 'bold', label: 'Gras' }, { id: 'script', label: 'Italique' }, { id: 'stencil', label: 'Pochoir' }],
    colors: ['#ffffff', '#ff3b4e', '#ff9f1a', '#ffe14d', '#3ddc84', '#35c4ff'], allowText: true, wMin: 0.6, wMax: 2.5, mine: 2, max: 5, gang: { label: 'Ballas' } };
  view = 'txt'; txt.text = 'BALLAS';
  const mine = h('div', { id: 'g-gfx', class: 'gx-static' });
  host = mine; draw();
  host = ph; st = ps; live = pl; view = pv; pick = pp;
  box.appendChild(G.fitStage(h('div', { class: 'gx-scene', style: { width: '1100px', height: '620px' } }, mine), 1100, 620));
};
})();
