/* Justice : petit bandeau en haut de l'écran pour la prison (minuteur) et le TIG (tâches restantes), plus la barre de progression d'une tâche. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, st = { kind: 'none', remaining: 0 }, t0 = 0, tick = null, prog = null;
const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ':' + (s % 60 < 10 ? '0' : '') + (s % 60); };
const box = () => el || (el = (function () { const e = h('div', { id: 'g-justice', class: 'hidden' }); G.root.appendChild(e); return e; })());
function draw() {
  const b = box(); G.clear(b);
  if (st.kind === 'none') { b.classList.add('hidden'); clearInterval(tick); return; }
  b.classList.remove('hidden');
  const left = st.kind === 'jail' ? fmt(st.remaining - (Date.now() - t0) / 1000) : String(st.remaining);
  b.appendChild(h('div', { class: 'gj' }, h('span', { class: 'gj-i' }, G.ico(st.kind === 'jail' ? 'lock' : 'hand')),
    h('div', null, h('b', null, st.kind === 'jail' ? 'Prison' : "Travaux d'intérêt général"), h('small', null, String(st.reason || ''))),
    h('em', null, st.kind === 'jail' ? left : left + ' tâche(s)')));
}
G.on('justice.state', (d) => {
  st = { kind: d.kind || 'none', remaining: Number(d.remaining) || 0, reason: d.reason }; t0 = Date.now();
  clearInterval(tick); draw();
  if (st.kind === 'jail') tick = setInterval(draw, 1000);
});
G.on('justice.progress', (d) => {
  const b = box(); if (prog) prog.remove();
  prog = h('div', { class: 'gj-p' }, h('i', { style: { animationDuration: (Number(d.secs) || 8) + 's' } }));
  b.appendChild(prog); setTimeout(() => { if (prog) { prog.remove(); prog = null; } }, (Number(d.secs) || 8) * 1000 + 100);
});
})();
