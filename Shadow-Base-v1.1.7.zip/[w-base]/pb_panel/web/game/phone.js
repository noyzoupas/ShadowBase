/* Téléphone : un vrai téléphone avec écran d'accueil et applications (Messages, Contacts, Annuaire, Banque, Factures, Garage, GPS, Notes,
   Calculatrice, Réglages). Le serveur envoie des données déjà filtrées ; tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const DW = 372, DH = 760;

const WALLS = {
  dusk: 'linear-gradient(165deg,#1d2140 0%,#4b2f5e 55%,#d0705f 100%)',
  ocean: 'linear-gradient(165deg,#07182b 0%,#0f4c6e 60%,#35b4c2 100%)',
  ember: 'linear-gradient(165deg,#1c0d12 0%,#6b1f25 55%,#f08a3c 100%)',
  forest: 'linear-gradient(165deg,#07140f 0%,#12543a 60%,#7fd18b 100%)',
  rose: 'linear-gradient(165deg,#1a1020 0%,#7a2b5f 55%,#f3a1b5 100%)',
  mono: 'linear-gradient(165deg,#0d0e11 0%,#2a2d34 60%,#6b707b 100%)',
};
const APPC = { calls: ['#5bea7a', '#1a9c47'], messages:['#4be08a', '#14a653'], contacts: ['#a9b0be', '#5d6471'], services: ['#68b3ff', '#2f6fe0'], bank: ['#34d8c9', '#0f8a86'], bills: ['#ffbc5c', '#e0791f'],
  garage: ['#ff7b8c', '#c93a52'], gps: ['#8be8b0', '#2b9a68'], notes: ['#ffdc6a', '#d9a421'], calc: ['#4a515d', '#1f2329'], settings: ['#b4bac5', '#6a707b'] };
const money = (n) => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' $';
const initials = (s) => { const p = String(s || '?').trim().split(/\s+/); return ((p[0] || '?')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase(); };
const dur = (s) => { s = Math.max(0, Math.floor(s)); const m = Math.floor(s / 60); return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s % 60).padStart(2, '0'); };
const hue = (s) => { let x = 0; for (const c of String(s)) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };

const APPI = { calls: 'call', messages: 'chat', contacts: 'users', services: 'building', bank: 'card', bills: 'file', garage: 'car', gps: 'pin', notes: 'note', calc: 'calc', settings: 'sliders' };
function appIcon(id, size) {
  const c = APPC[id] || ['#888', '#444'];
  return h('span', { class: 'ph-ai', style: { background: 'linear-gradient(160deg,' + c[0] + ',' + c[1] + ')', width: size + 'px', height: size + 'px' } }, ico(APPI[id] || 'info'));
}

/* opts : { page(name), act(name, payload, page), close() } */
G.phoneView = function (opts) {
  const st = { view: 'home', data: null, info: null, loading: false, toast: null, sel: null, compose: null, edit: null, calc: { a: '0', left: null, op: null, rep: null, fresh: true }, send: null, clock: [12, 0],
    call: null, back: 'home', dial: '', ctab: 'keys' };
  const dev = h('div', { class: 'ph-dev' });
  const scr = h('div', { class: 'ph-scr' }), bar = h('div', { class: 'ph-st' }), body = h('div', { class: 'ph-body' }), home = h('button', { class: 'ph-hi', type: 'button', title: "Écran d'accueil", onclick: () => nav('home') });
  const toast = h('div', { class: 'ph-toast hidden' });
  scr.appendChild(h('div', { class: 'ph-wall' }));
  scr.appendChild(bar); scr.appendChild(body); scr.appendChild(toast); scr.appendChild(home);
  dev.appendChild(h('div', { class: 'ph-btn b1' })); dev.appendChild(h('div', { class: 'ph-btn b2' })); dev.appendChild(h('div', { class: 'ph-btn b3' }));
  dev.appendChild(scr);

  let toastT = null;
  function say(ok, msg) {
    if (!msg) return;
    toast.textContent = String(msg); toast.className = 'ph-toast ' + (ok ? 'ok' : 'bad');
    clearTimeout(toastT); toastT = setTimeout(() => toast.classList.add('hidden'), 3200);
  }
  function wall() {
    const w = (st.info && st.info.wall) || 'dusk', el = scr.firstChild;
    if (w === 'banner') {
      const b = (G.cfg && G.cfg.brand && G.cfg.brand.banner) ? G.assetUrl(G.cfg.brand.banner) : '';
      el.style.background = b ? 'linear-gradient(rgba(0,0,0,.35),rgba(0,0,0,.55)),url("' + b + '") center/cover' : WALLS.mono;
    } else el.style.background = WALLS[w] || WALLS.dusk;
  }
  function drawBar() {
    G.clear(bar);
    const hh = String(st.clock[0]).padStart(2, '0'), mm = String(st.clock[1]).padStart(2, '0');
    bar.appendChild(h('b', { class: 'ph-t' }, hh + ':' + mm));
    bar.appendChild(h('i', { class: 'ph-isl' }));
    bar.appendChild(h('span', { class: 'ph-sys' }, st.info && st.info.dnd ? h('i', { class: 'ph-dnd', title: 'Ne pas déranger' }, ico('alert')) : null, ico('wifi'), ico('battery')));
  }

  // ---- navigation
  const NOSERVER = { home: 1, calc: 1, newmsg: 1, newcontact: 1, editnote: 1, call: 1, invite: 1, newgroup: 1 };
  function nav(page) {
    st.sel = null;
    if (page !== 'call' && st.view !== 'call') st.back = page;
    if (page === 'home' && st.info) { st.view = 'home'; render(); opts.page('home'); return; }
    st.view = page;
    if (NOSERVER[page]) { render(); return; }
    st.data = null; st.loading = true; render(); opts.page(page);
  }
  function set(d) {
    if (d && d.frame && d.frame.phone) { st.info = d.frame.phone; wall(); drawBar(); }
    // action refusée depuis un formulaire local : on reste sur le formulaire (rien n'est effacé), le message s'affiche en bas
    if (d && d.ok === false && NOSERVER[st.view] && st.view !== 'home') return;
    if (d && d.page && d.page.page) {
      const pg = d.page.page;
      // une réponse de page ne remplace pas un écran local en cours de saisie
      // l'écran d'appel reste devant tant que l'appel dure
      if (!(NOSERVER[st.view] && st.view !== 'home' && pg === st.view) && !((st.view === 'call' || st.view === 'invite') && st.call)) { st.view = pg; }
      st.data = d.page.data || null; st.loading = false;
      if (st.data && (st.data.contacts || (pg === 'contacts' && st.data.list))) st.contactsCache = st.data.contacts || st.data.list;
      if (pg === 'thread' && st.data && st.data.num) st.sel = st.data.num;
    } else if (d && d.err) { st.loading = false; say(false, d.err); }
    render();
  }

  // ---- éléments communs
  function header(title, back, right) {
    return h('div', { class: 'ph-hd' }, back ? h('button', { class: 'ph-bk', type: 'button', onclick: back, title: 'Retour' }, ico('back')) : h('i', { class: 'ph-bk0' }), h('b', null, title), right || h('i', { class: 'ph-bk0' }));
  }
  const empty = (txt) => h('div', { class: 'ph-empty' }, txt);
  const act = (n, p, pg) => opts.act(n, p || {}, pg || st.view);
  function row(lead, title, sub, right, onclick) {
    return h('div', { class: 'ph-row' + (onclick ? ' tap' : ''), onclick }, lead, h('div', { class: 'ph-rt' }, h('b', null, title), sub != null ? h('small', null, sub) : null), right || null);
  }
  const avatar = (name, svc) => svc ? h('span', { class: 'ph-av svc' }, ico('building')) : h('span', { class: 'ph-av', style: { '--hu': hue(name) } }, initials(name));
  function field(label, props) { const inp = h('input', Object.assign({ class: 'ph-in', type: 'text', autocomplete: 'off', spellcheck: 'false' }, props || {})); return { el: h('label', { class: 'ph-f' }, h('span', null, label), inp), inp }; }
  const btn = (label, onclick, kind, icon) => h('button', { type: 'button', class: 'ph-b ' + (kind || ''), onclick }, icon ? ico(icon) : null, label);

  // ---- écrans
  const R = {};
  R.home = () => {
    const info = st.info || { apps: [] }, apps = info.apps || [];
    const grid = h('div', { class: 'ph-grid' });
    apps.forEach((a) => {
      grid.appendChild(h('button', { type: 'button', class: 'ph-app', onclick: () => nav(a.id === 'calc' ? 'calc' : a.id) }, h('span', { class: 'ph-ap' }, appIcon(a.id, 62), a.badge > 0 ? h('i', { class: 'ph-bd' }, a.badge > 99 ? '99+' : String(a.badge)) : null), h('small', null, a.label)));
    });
    return h('div', { class: 'ph-homeview' },
      h('div', { class: 'ph-hello' }, h('b', null, info.name || ''), h('small', null, info.number ? 'Mon numéro : ' + info.number : '')),
      grid,
      h('div', { class: 'ph-widget' }, h('div', null, h('small', null, 'Banque'), h('b', null, money(info.bank))), h('div', null, h('small', null, 'Espèces'), h('b', null, money(info.cash)))));
  };

  // ---- appels : clavier, récents, contacts ; écran d'appel en cours
  const callAct = (n) => (opts.callAct ? opts.callAct(n) : G.post('call.' + n, {}));
  const callBtn = (num, title) => h('button', { class: 'ph-bk call', type: 'button', title: title || 'Appeler', onclick: (e) => { e.stopPropagation(); act('call', { num }, st.view); } }, ico('call'));
  R.calls = () => {
    const d = st.data || {}, tab = st.ctab;
    const seg = h('div', { class: 'ph-seg' }, [['keys', 'Clavier'], ['recent', 'Récents'], ['contacts', 'Contacts']].map((t) => h('button', { type: 'button', class: tab === t[0] ? 'on' : '', onclick: () => { st.ctab = t[0]; render(); } }, t[1])));
    let main;
    if (d.voice === false) main = empty("Les appels sont indisponibles sur ce serveur pour le moment. Tu peux toujours envoyer des messages.");
    else if (tab === 'recent') {
      const rows = (d.recent || []).map((c) => row(avatar(c.label, c.svc), c.label,
        h('span', { class: 'ph-cl' + (c.missed ? ' miss' : '') }, h('i', { class: 'ph-dir' + (c.out ? ' out' : '') }, ico('arrow')), c.missed ? 'Manqué' : c.status === 'declined' ? 'Refusé' : c.secs > 0 ? dur(c.secs) : c.out ? 'Sans réponse' : 'Manqué', ' · ' + c.at),
        callBtn(c.num), () => act('call', { num: c.num }, 'calls')));
      main = h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun appel récent.'));
    } else if (tab === 'contacts') {
      const rows = (d.contacts || []).map((c) => row(avatar(c.name), c.name, c.number, callBtn(c.number), () => act('call', { num: c.number }, 'calls')));
      main = h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun contact.'));
    } else {
      const disp = h('b', null, st.dial || ' ');
      const press = (k) => {
        if (k === '⌫') st.dial = st.dial.replace(/-$/, '').replace(/\d$/, '');
        else if (st.dial.replace('-', '').length < 7) { st.dial += k; if (/^\d{3}$/.test(st.dial)) st.dial += '-'; }
        disp.textContent = st.dial || ' ';
      };
      const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'].map((k) => k ? h('button', { type: 'button', class: 'ph-dk', onclick: () => press(k) }, k) : h('i'));
      main = h('div', { class: 'ph-dial' }, h('div', { class: 'ph-dd' }, disp), h('div', { class: 'ph-dks' }, keys),
        h('div', { class: 'ph-dialb' },
          h('button', { type: 'button', class: 'ph-sos', title: "Appel d'urgence : police et secours en service, ta position leur est envoyée", onclick: () => act('call', { num: '911' }, 'calls') }, 'SOS 911'),
          h('button', { type: 'button', class: 'ph-cb go', title: 'Appeler', onclick: () => { if (st.dial) act('call', { num: st.dial }, 'calls'); } }, ico('call')),
          h('i', { class: 'ph-sos0' })));
    }
    return h('div', { class: 'ph-app-v' }, header('Appels', () => nav('home')), seg, main);
  };
  R.call = () => {
    const c = st.call;
    if (!c) return h('div', { class: 'ph-app-v' }, header('Appels', () => nav('calls')), empty('Aucun appel en cours.'));
    const status = c.state === 'incoming' ? (c.svc ? 'Appel pour ton service' : 'Appel entrant…') : c.state === 'outgoing' ? 'Appel en cours…' : dur(c.since + Math.floor((Date.now() - c.t) / 1000));
    const btns = c.state === 'incoming'
      ? [h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb end', title: 'Refuser', onclick: () => callAct('hangup') }, ico('call')), h('small', null, 'Refuser')),
         h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb go', title: 'Décrocher', onclick: () => callAct('answer') }, ico('call')), h('small', null, 'Décrocher'))]
      : [c.state === 'live' ? h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb spk' + (c.speaker ? ' on' : ''), title: 'Haut-parleur : les personnes à côté de toi entendent l\'appel', onclick: () => callAct('speaker') }, ico('volume')), h('small', null, c.speaker ? 'Haut-parleur activé' : 'Haut-parleur')) : null,
         c.state === 'live' && !c.emergency ? h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb spk', title: 'Ajouter quelqu\'un à l\'appel (conférence)', onclick: () => { st.view = 'invite'; render(); } }, ico('plus')), h('small', null, 'Ajouter')) : null,
         h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb end', title: 'Raccrocher', onclick: () => callAct('hangup') }, ico('call')), h('small', null, 'Raccrocher'))];
    return h('div', { class: 'ph-callv' + (c.state === 'incoming' ? ' ring' : '') },
      h('div', { class: 'ph-cid' }, h('span', { class: 'ph-av big' + (c.svc ? ' svc' : ''), style: { '--hu': hue(c.label) } }, c.svc ? ico('building') : initials(c.label)), h('b', null, c.label || c.num || ''), h('small', null, c.label !== c.num && !c.svc ? c.num : ''), h('em', { class: 'ph-cst' }, status)),
      h('div', { class: 'ph-cbs' }, btns));
  };
  // conférence : numéro à ajouter (ou un contact), puis retour à l'écran d'appel
  R.invite = () => {
    const num = field('Numéro à ajouter (555-0123)', { maxlength: 8 });
    const go = () => { if (num.inp.value) { (opts.invite ? opts.invite(num.inp.value) : G.post('call.invite', { num: num.inp.value })); st.view = 'call'; render(); } };
    num.inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    setTimeout(() => num.inp.focus(), 30);
    const chips = h('div', { class: 'ph-chips' }, ((st.contactsCache || []).slice(0, 12)).map((c) => h('button', { type: 'button', class: 'ph-chip', onclick: () => { num.inp.value = c.number; } }, c.name)));
    return h('div', { class: 'ph-app-v' }, header('Ajouter à l\'appel', () => { st.view = 'call'; render(); }), h('div', { class: 'ph-form' }, chips.children.length ? chips : null, num.el, btn('Faire sonner', go, 'go', 'call')));
  };
  function onCall(d) {
    if (d.state === 'ended') {
      const was = st.call; st.call = null;
      if (d.reason) say(false, d.reason);
      if (st.view === 'call' || st.view === 'invite') nav(st.back === 'call' || st.back === 'invite' ? 'calls' : (st.back || 'calls'));
      return was;
    }
    st.call = Object.assign({}, d, { t: Date.now() });
    if (st.view !== 'call' && st.view !== 'invite') { st.back = st.view; st.view = 'call'; }
    render();
  }

  R.messages = () => {
    const d = st.data || {}, list = d.threads || [];
    const right = h('span', { class: 'ph-hx' },
      h('button', { class: 'ph-bk', type: 'button', title: 'Nouveau groupe', onclick: () => { st.edit = { name: '', numbers: '' }; nav('newgroup'); } }, ico('users')),
      h('button', { class: 'ph-bk', type: 'button', title: 'Nouveau message', onclick: () => { st.compose = { num: '', body: '' }; nav('newmsg'); } }, ico('edit')));
    const rows = list.map((t) => row(t.group ? h('span', { class: 'ph-av grp' }, ico('users')) : avatar(t.label, t.svc), t.label, (t.mine ? 'Toi : ' : '') + t.last, h('div', { class: 'ph-rr' }, h('small', null, t.at), t.unread > 0 ? h('i', { class: 'ph-bd s' }, String(t.unread)) : null), () => act('open_thread', { num: t.num }, 'messages')));
    return h('div', { class: 'ph-app-v' }, header('Messages', () => nav('home'), right), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucune conversation. Appuie sur le crayon pour écrire.')));
  };
  R.newmsg = () => {
    const num = field('Numéro (555-0123)', { maxlength: 8, value: st.compose ? st.compose.num : '' }), bodyF = field('Message', { maxlength: 240, value: st.compose ? st.compose.body : '' });
    const go = () => { st.compose = { num: num.inp.value, body: bodyF.inp.value }; act('send_new', { num: num.inp.value, body: bodyF.inp.value }, 'messages'); };
    bodyF.inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    setTimeout(() => (st.compose && st.compose.num ? bodyF.inp : num.inp).focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouveau message', () => nav('messages')), h('div', { class: 'ph-form' }, num.el, bodyF.el, btn('Envoyer', go, 'pri', 'send')));
  };
  R.newgroup = () => {
    const e = st.edit || { name: '', numbers: '' };
    const nm = field('Nom du groupe', { maxlength: 32, value: e.name || '' }), nu = field('Numéros (séparés par des virgules)', { maxlength: 120, value: e.numbers || '' });
    const chips = h('div', { class: 'ph-chips' }, ((st.contactsCache || []).slice(0, 16)).map((c) => h('button', { type: 'button', class: 'ph-chip', onclick: () => { if (nu.inp.value.indexOf(c.number) < 0) nu.inp.value = (nu.inp.value ? nu.inp.value + ', ' : '') + c.number; } }, c.name)));
    const go = () => { st.edit = { name: nm.inp.value, numbers: nu.inp.value }; act('group_create', { name: nm.inp.value, numbers: nu.inp.value }, 'messages'); };
    setTimeout(() => nm.inp.focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouveau groupe', () => nav('messages')), h('div', { class: 'ph-form' }, nm.el, chips.children.length ? h('small', { class: 'ph-note' }, 'Touche un contact pour l\'ajouter :') : null, chips.children.length ? chips : null, nu.el, btn('Créer le groupe', go, 'pri', 'users')));
  };
  R.thread = () => {
    const d = st.data || {};
    if (d.empty || !d.num) return h('div', { class: 'ph-app-v' }, header('Messages', () => nav('messages')), empty('Choisis une conversation.'));
    const feed = h('div', { class: 'ph-feed' });
    (d.msgs || []).forEach((m) => feed.appendChild(h('div', { class: 'ph-bub ' + (m.mine ? 'me' : 'in') + (m.pos ? ' pos' : '') }, m.pos ? h('span', { class: 'ph-posm' }, ico('pin'), h('b', null, m.mine ? 'Ta position' : 'Position partagée'), h('button', { type: 'button', class: 'ph-pgo', onclick: () => act('gps_msg', { id: m.id }, 'thread') }, 'Y aller')) : h('span', null, m.who ? h('b', { class: 'ph-who' }, m.who) : null, m.body), h('small', null, m.at,
      (!m.mine && !m.reported) ? h('button', { type: 'button', class: 'ph-rep', title: 'Signaler ce message au staff', onclick: () => act('report', { id: m.id }, 'thread') }, 'signaler') : null))));
    const inp = h('input', { class: 'ph-in msg', type: 'text', maxlength: d.maxlen || 240, placeholder: 'Message', autocomplete: 'off', spellcheck: 'false' });
    const send = () => { const t = inp.value.trim(); if (!t) return; inp.value = ''; act('send', { body: t }, 'thread'); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });
    setTimeout(() => { feed.scrollTop = feed.scrollHeight; inp.focus(); }, 30);
    const right = d.group ? h('button', { class: 'ph-bk', type: 'button', title: 'Quitter le groupe', onclick: () => act('group_leave', {}, 'thread') }, ico('x'))
      : d.canAdd ? h('button', { class: 'ph-bk', type: 'button', title: 'Ajouter aux contacts', onclick: () => { st.edit = { number: d.num, name: '' }; nav('newcontact'); } }, ico('plus')) : null;
    const sub = d.group ? h('div', { class: 'ph-sub' }, h('span', null, (d.members || []).join(', ')))
      : h('div', { class: 'ph-sub' }, h('span', null, d.svc ? 'Service : les employés en service reçoivent ton message' : d.num), h('button', { type: 'button', class: 'ph-pcall', title: 'Appeler', onclick: () => act('call', { num: d.num }, 'thread') }, ico('call'), 'Appeler'));
    return h('div', { class: 'ph-app-v chat' }, header(d.label, () => nav('messages'), right), sub, feed,
      h('div', { class: 'ph-bar' }, h('button', { type: 'button', class: 'ph-snd loc', title: 'Envoyer ma position', onclick: () => act('send_pos', {}, 'thread') }, ico('pin')), inp, h('button', { type: 'button', class: 'ph-snd', title: 'Envoyer', onclick: send }, ico('send'))));
  };

  R.contacts = () => {
    const d = st.data || {}, list = d.list || [];
    const right = h('button', { class: 'ph-bk', type: 'button', title: 'Nouveau contact', onclick: () => { st.edit = { name: '', number: '' }; nav('newcontact'); } }, ico('plus'));
    const rows = list.map((c) => {
      const open = st.sel === 'c' + c.id;
      const r = row(avatar(c.name), c.name, c.number, h('i', { class: 'ph-chv' }, ico('chevron')), () => { st.sel = open ? null : 'c' + c.id; render(); });
      return h('div', { class: 'ph-grp' }, r, open ? h('div', { class: 'ph-acts five' }, btn('Appeler', () => act('call', { num: c.number }, 'contacts'), 'go', 'call'), btn('Écrire', () => act('open_thread', { num: c.number }, 'contacts'), 'pri', 'chat'), btn('Virer', () => { st.send = c.number; nav('bank'); }, '', 'card'),
        c.blocked ? btn('Débloquer', () => act('unblock', { num: c.number }, 'contacts'), '', 'check') : btn('Bloquer', () => act('block', { num: c.number }, 'contacts'), 'bad', 'lock'),
        btn('Supprimer', () => act('del_contact', { id: c.id }, 'contacts'), 'bad', 'trash')) : null);
    });
    const bl = (d.blocked || []).map((b) => row(h('span', { class: 'ph-ti out' }, ico('lock')), b.name || b.number, b.name ? b.number : 'Numéro bloqué', btn('Débloquer', () => act('unblock', { num: b.number }, 'contacts'), 'small')));
    return h('div', { class: 'ph-app-v' }, header('Contacts', () => nav('home'), right), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun contact.'),
      bl.length ? h('div', { class: 'ph-sec' }, 'Numéros bloqués') : null, bl));
  };
  R.newcontact = () => {
    const e = st.edit || { name: '', number: '' };
    const nm = field('Nom', { maxlength: 40, value: e.name }), nu = field('Numéro (555-0123)', { maxlength: 8, value: e.number });
    const go = () => { st.edit = { name: nm.inp.value, number: nu.inp.value }; act('add_contact', { name: nm.inp.value, number: nu.inp.value }, 'contacts'); };
    setTimeout(() => nm.inp.focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouveau contact', () => nav('contacts')), h('div', { class: 'ph-form' }, nm.el, nu.el, btn('Enregistrer', go, 'pri', 'check')));
  };

  R.services = () => {
    const list = (st.data && st.data.list) || [];
    const rows = list.map((s) => row(avatar(s.name, true), s.name, s.duty > 0 ? s.duty + ' en service' : 'Personne en service', s.duty > 0 ? callBtn('svc:' + s.id, 'Appeler le service') : h('i', { class: 'ph-dot' }), () => act('open_thread', { num: 'svc:' + s.id }, 'services')));
    return h('div', { class: 'ph-app-v' }, header('Annuaire', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty("Aucun service n'est listé."), h('p', { class: 'ph-note' }, 'Appelle un service : tous les employés en service sonnent. Un message les prévient aussi ; ils te répondent sur ton numéro.')));
  };

  R.bank = () => {
    const d = st.data || {};
    const num = field('Numéro du destinataire', { maxlength: 8, value: st.send || '' }), amt = field('Montant ($)', { type: 'number', inputmode: 'numeric', min: d.min || 1, max: d.max || 250000 }), note = field('Motif (facultatif)', { maxlength: 60 });
    const chips = h('div', { class: 'ph-chips' }, (d.contacts || []).slice(0, 8).map((c) => h('button', { type: 'button', class: 'ph-chip', onclick: () => { num.inp.value = c.number; } }, c.name)));
    const go = () => { st.send = null; act('bank_send', { num: num.inp.value, amount: Number(amt.inp.value), note: note.inp.value }, 'bank'); };
    return h('div', { class: 'ph-app-v scroll' }, header('Banque', () => nav('home')),
      h('div', { class: 'ph-card' }, h('small', null, 'Solde du compte'), h('b', { class: 'big' }, money(d.bank)), h('div', { class: 'ph-split' }, h('span', null, 'Espèces ', h('b', null, money(d.cash))), h('span', null, d.iban || ''))),
      h('div', { class: 'ph-sec' }, 'Envoyer de l\'argent'),
      h('div', { class: 'ph-form tight' }, chips.children.length ? chips : null, num.el, amt.el, note.el, btn('Envoyer le virement' + (d.fee ? ' (frais ' + d.fee + ' %)' : ''), go, 'pri', 'send')),
      h('div', { class: 'ph-sec' }, 'Dernières opérations'),
      h('div', { class: 'ph-list' }, (d.tx || []).length ? (d.tx || []).map((t) => row(h('span', { class: 'ph-ti ' + (t.plus ? 'in' : 'out') }, ico(t.plus ? 'arrow' : 'arrow')), t.label, (t.note ? t.note + ' · ' : '') + t.at, h('b', { class: 'ph-am ' + (t.plus ? 'in' : 'out') }, (t.plus ? '+' : '−') + money(Math.abs(t.amount))))) : [empty('Aucune opération.')]));
  };

  R.bills = () => {
    const d = st.data || {}, list = d.list || [];
    const rows = list.map((b) => row(h('span', { class: 'ph-ti ' + (b.status === 'pending' ? 'out' : 'in') }, ico(b.fine ? 'alert' : 'file')), (b.fine ? 'Amende' : 'Facture') + (b.from ? ' · ' + b.from : ''), b.reason || '', b.status === 'pending' ? btn('Payer ' + money(b.amount), () => act('pay_bill', { id: b.id }, 'bills'), 'pri small') : h('small', { class: 'ph-pill' }, b.status === 'paid' ? 'Réglée' : 'Annulée')));
    return h('div', { class: 'ph-app-v' }, header('Factures', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucune facture. Tout est réglé.'), h('p', { class: 'ph-note' }, 'Le paiement se fait depuis ton compte en banque : ' + money(d.bank) + ' disponibles.')));
  };

  R.garage = () => {
    const list = (st.data && st.data.list) || [];
    const S = { garage: 'Rangé', out: 'Sorti', impound: 'Fourrière' };
    const bar = (label, v) => v == null ? null : h('span', { class: 'ph-gb' + (v < 25 ? ' low' : v < 60 ? ' mid' : '') }, h('i', { style: { width: v + '%' } }), h('em', null, label + ' ' + v + ' %'));
    const rows = list.map((v) => h('div', { class: 'ph-grp' }, row(h('span', { class: 'ph-ti car' }, ico('car')), v.label, v.plate + (v.garage ? ' · ' + v.garage : ''), v.state === 'out' ? btn('Localiser', () => act('gps_car', { plate: v.plate }, 'garage'), 'pri small', 'pin') : h('small', { class: 'ph-pill' }, S[v.state] || v.state)),
      h('div', { class: 'ph-gbs' }, bar('Carburant', v.fuel), bar('Moteur', v.engine), bar('Carrosserie', v.body), h('small', null, v.live ? 'En direct' : 'Au dernier rangement'))));
    return h('div', { class: 'ph-app-v' }, header('Garage', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty("Tu n'as aucun véhicule.")));
  };

  R.gps = () => {
    const pl = (st.data && st.data.places) || [];
    const rows = pl.map((p) => row(h('span', { class: 'ph-ti pin' }, ico('pin')), p.label, null, btn('Y aller', () => act('gps_set', { id: p.id }, 'gps'), 'pri small')));
    return h('div', { class: 'ph-app-v' }, header('GPS', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun lieu enregistré.')), h('div', { class: 'ph-form tight' }, btn("Effacer l'itinéraire", () => act('gps_clear', {}, 'gps'), '', 'x')));
  };

  R.notes = () => {
    const list = (st.data && st.data.list) || [];
    const right = h('button', { class: 'ph-bk', type: 'button', title: 'Nouvelle note', onclick: () => { st.edit = { id: 0, title: '', body: '' }; nav('editnote'); } }, ico('plus'));
    const rows = list.map((n) => row(h('span', { class: 'ph-ti note' }, ico('note')), n.title || 'Sans titre', n.body.replace(/\s+/g, ' ').slice(0, 60), h('small', null, n.at), () => { st.edit = { id: n.id, title: n.title, body: n.body }; nav('editnote'); }));
    return h('div', { class: 'ph-app-v' }, header('Notes', () => nav('home'), right), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucune note.')));
  };
  R.editnote = () => {
    const e = st.edit || { id: 0, title: '', body: '' };
    const t = field('Titre', { maxlength: 60, value: e.title }), b = h('textarea', { class: 'ph-in ta', maxlength: 1500, placeholder: 'Écris ici…', spellcheck: 'false' }); b.value = e.body || '';
    const go = () => act('note_save', { id: e.id, title: t.inp.value, body: b.value }, 'notes');
    setTimeout(() => (e.id ? b : t.inp).focus(), 30);
    return h('div', { class: 'ph-app-v' }, header(e.id ? 'Modifier la note' : 'Nouvelle note', () => nav('notes'), e.id ? h('button', { class: 'ph-bk', type: 'button', title: 'Supprimer', onclick: () => act('note_del', { id: e.id }, 'notes') }, ico('trash')) : null),
      h('div', { class: 'ph-form' }, t.el, h('label', { class: 'ph-f' }, h('span', null, 'Texte'), b), btn('Enregistrer', go, 'pri', 'check')));
  };

  R.settings = () => {
    const d = st.data || {};
    const tog = (label, sub, on, name) => h('div', { class: 'ph-row tap', onclick: () => act(name, { on: !on }, 'settings') }, h('div', { class: 'ph-rt' }, h('b', null, label), h('small', null, sub)), h('i', { class: 'ph-sw' + (on ? ' on' : '') }));
    const wallsEl = h('div', { class: 'ph-walls' }, (d.walls || []).map((w) => h('button', { type: 'button', class: 'ph-wl' + (d.wall === w ? ' on' : ''), title: w === 'banner' ? 'Bannière du serveur' : w, style: { background: w === 'banner' ? WALLS.mono : WALLS[w] }, onclick: () => act('set_wall', { wall: w }, 'settings') }, w === 'banner' ? ico('star') : null)));
    return h('div', { class: 'ph-app-v scroll' }, header('Réglages', () => nav('home')),
      h('div', { class: 'ph-card' }, h('b', { class: 'mid' }, d.name || ''), h('div', { class: 'ph-split' }, h('span', null, 'Numéro ', h('b', null, d.number || '')), h('span', null, d.iban || ''))),
      h('div', { class: 'ph-sec' }, "Fond d'écran"), wallsEl,
      h('div', { class: 'ph-sec' }, 'Notifications'),
      h('div', { class: 'ph-list' }, tog('Ne pas déranger', 'Plus de notification ni de son à la réception', d.dnd, 'set_dnd'), tog('Sons', 'Son à la réception d\'un message', d.sound, 'set_sound')),
      h('div', { class: 'ph-form tight' }, btn('Fermer le téléphone', () => opts.close(), '', 'x')));
  };

  // ---- calculatrice (locale : aucune évaluation de texte, seulement des opérations sur des nombres)
  function calcPress(k) {
    const c = st.calc;
    const fmt = (n) => { if (!isFinite(n)) return 'Erreur'; const t = String(Math.round(n * 1e9) / 1e9); return t.length > 12 ? Number(n).toExponential(5) : t; };
    const op = (l, o, r) => (o === '+' ? l + r : o === '−' ? l - r : o === '×' ? l * r : o === '÷' ? (r === 0 ? NaN : l / r) : r);
    if (c.a === 'Erreur' && k !== 'C') return;
    if (/^\d$/.test(k)) { if (c.fresh || c.a === '0') { c.a = k; c.fresh = false; } else if (c.a.replace(/[-.]/g, '').length < 12) c.a += k; }
    else if (k === ',') { if (c.fresh) { c.a = '0'; c.fresh = false; } if (c.a.indexOf('.') < 0) c.a += '.'; }
    else if (k === 'C') st.calc = { a: '0', left: null, op: null, rep: null, fresh: true };
    else if (k === '⌫') { if (!c.fresh) { c.a = c.a.length > 1 ? c.a.slice(0, -1) : '0'; if (c.a === '-') c.a = '0'; } }
    else if (k === '±') { if (c.a !== '0') c.a = c.a[0] === '-' ? c.a.slice(1) : '-' + c.a; }
    else if (k === '%') { c.a = fmt(Number(c.a) / 100); c.fresh = true; }
    else if (k === '=') { if (c.op && c.left != null) { const r = c.fresh && c.rep != null ? c.rep : Number(c.a); const res = op(c.left, c.op, r); c.rep = r; c.left = res; c.a = fmt(res); c.fresh = true; } }
    else { // + − × ÷
      if (c.op && !c.fresh && c.left != null) { const res = op(c.left, c.op, Number(c.a)); c.left = res; c.a = fmt(res); } else c.left = Number(c.a);
      c.op = k; c.rep = null; c.fresh = true;
    }
    render();
  }
  R.calc = () => {
    const keys = [['C', 'fn'], ['±', 'fn'], ['%', 'fn'], ['÷', 'op'], ['7'], ['8'], ['9'], ['×', 'op'], ['4'], ['5'], ['6'], ['−', 'op'], ['1'], ['2'], ['3'], ['+', 'op'], ['0', 'zero'], [','], ['=', 'op eq']];
    return h('div', { class: 'ph-app-v calc' }, header('Calculatrice', () => nav('home'), h('button', { class: 'ph-bk', type: 'button', title: 'Effacer un chiffre', onclick: () => calcPress('⌫') }, ico('backspace'))),
      h('div', { class: 'ph-disp' }, h('small', null, st.calc.op && st.calc.left != null ? String(Math.round(st.calc.left * 1e9) / 1e9).replace('.', ',') + ' ' + st.calc.op : ''), h('b', null, st.calc.a.replace('.', ','))),
      h('div', { class: 'ph-keys' }, keys.map((k) => h('button', { type: 'button', class: 'ph-k ' + (k[1] || ''), onclick: () => calcPress(k[0]) }, k[0]))));
  };

  // ---- dessin
  function render() {
    G.clear(body);
    drawBar();
    const fn = R[st.view] || R.home;
    let el;
    try { el = fn(); } catch (e) { el = empty('Application indisponible.'); }
    if (st.loading && !st.data && !NOSERVER[st.view]) el = h('div', { class: 'ph-app-v' }, el.firstChild || null, empty('Chargement…'));
    body.appendChild(el);
    home.classList.toggle('hidden', st.view === 'home');
  }
  function start(d) {
    st.info = (d.frame && d.frame.phone) || null;
    if (d.clock) st.clock = d.clock;
    st.view = 'home'; wall(); render();
    if (d.page && d.page.data) { st.data = d.page.data; render(); }
  }
  // chronomètre de l'appel : redessine l'écran d'appel chaque seconde, s'arrête quand le téléphone est fermé
  const tick = setInterval(() => { if (!dev.isConnected && st.started) { clearInterval(tick); return; } if (st.view === 'call' && st.call && st.call.state === 'live') render(); }, 1000);
  const start0 = start;
  return { el: dev, start: (d) => { st.started = true; start0(d); }, set, say, onCall, setClock: (hh, mm) => { st.clock = [hh, mm]; drawBar(); }, view: () => st.view };
};

// ---- bandeau d'appel (visible même téléphone fermé) et sonnerie (synthétisée : aucun fichier son à charger)
let callNow = null, ringT = null, bandT = null, audio = null;
function tone(freqs, ms, vol) {
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    if (audio.state === 'suspended') audio.resume();
    const t0 = audio.currentTime, g = audio.createGain();
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(vol, t0 + 0.02); g.gain.setValueAtTime(vol, t0 + ms / 1000 - 0.04); g.gain.linearRampToValueAtTime(0, t0 + ms / 1000);
    g.connect(audio.destination);
    freqs.forEach((f) => { const o = audio.createOscillator(); o.type = 'sine'; o.frequency.value = f; o.connect(g); o.start(t0); o.stop(t0 + ms / 1000); });
  } catch (e) { /* pas d'audio : tant pis, le bandeau suffit */ }
}
function ring(kind) {
  clearInterval(ringT); ringT = null;
  if (kind === 'in') { const r = () => { tone([660, 880], 380, 0.18); setTimeout(() => tone([660, 880], 380, 0.18), 520); }; r(); ringT = setInterval(r, 2600); }
  else if (kind === 'out') { const r = () => tone([440, 480], 1500, 0.07); r(); ringT = setInterval(r, 4500); }
}
const band = () => document.getElementById('g-call') || (function () { const e = h('div', { id: 'g-call', class: 'hidden' }); G.root.appendChild(e); return e; })();
function drawBand() {
  const el = band(), c = callNow;
  if (!c) return;
  G.clear(el); el.className = 'st-' + c.state;
  const secs = c.state === 'live' ? c.since + Math.floor((Date.now() - c.t) / 1000) : 0;
  const what = c.state === 'incoming' ? (c.svc ? 'Appel pour ton service' : 'Appel entrant') : c.state === 'outgoing' ? 'Appel en cours…' : c.state === 'live' ? dur(secs) : (c.reason || 'Appel terminé');
  const key = (G.cfg && G.cfg.phone && G.cfg.phone.key) || 'F1';
  el.appendChild(h('span', { class: 'gc-ic' }, ico('call')));
  el.appendChild(h('div', { class: 'gc-t' }, h('b', null, c.label || c.num || 'Appel'), h('small', null, what)));
  if (c.state !== 'ended') el.appendChild(h('div', { class: 'gc-k' }, c.state === 'incoming' ? [h('span', null, h('kbd', null, key), ' répondre'), h('span', null, '/raccrocher')] : [h('span', null, h('kbd', null, key), ' téléphone'), h('span', null, '/raccrocher')]));
}
setInterval(() => { if (callNow && callNow.state === 'live') drawBand(); }, 1000);
G.on('call.state', (d) => {
  clearTimeout(bandT);
  if (d.state === 'ended') {
    ring(null);
    const had = callNow; callNow = null;
    if (cur) cur.onCall(d);
    if (had || d.reason) { callNow = Object.assign({}, had || {}, { state: 'ended', reason: d.reason, t: Date.now() }); drawBand(); callNow = null; bandT = setTimeout(() => band().classList.add('hidden'), 2600); }
    return;
  }
  callNow = Object.assign({}, d, { t: Date.now() });
  ring(d.state === 'incoming' ? (d.sound === false ? null : 'in') : d.state === 'outgoing' ? 'out' : null);
  drawBand();
  if (cur) cur.onCall(callNow);
});

// ---- fenêtre en jeu
let cur = null;
const host = () => document.getElementById('g-phone') || (function () { const e = h('div', { id: 'g-phone', class: 'hidden' }); G.root.appendChild(e); return e; })();
function fit(el) { const k = Math.max(0.5, Math.min(1.15, (window.innerHeight * 0.9) / DH)); el.style.setProperty('--k', k.toFixed(3)); }
G.on('phone.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = G.phoneView({ page: (p) => G.post('phone.page', { page: p }), act: (n, pl, p) => G.post('phone.act', { name: n, payload: pl, page: p }), close: () => G.post('phone.close', {}) });
  fit(cur.el); r.appendChild(cur.el); cur.start(d);
  if (callNow) cur.onCall(callNow); else G.post('call.sync', {});
  G.uiStack = G.uiStack.filter((u) => u.id !== 'phone'); G.uiStack.push({ id: 'phone', onEscape: () => G.post('phone.close', {}) });
});
G.on('phone.page', (d) => { if (cur) cur.set(d); });
G.on('phone.result', (d) => { if (!cur) return; cur.set(d); cur.say(d.ok, d.msg); });
G.on('phone.clock', (d) => { if (cur) cur.setClock(Number(d.h) || 0, Number(d.m) || 0); });
G.on('phone.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'phone'); });
window.addEventListener('resize', () => { if (cur) fit(cur.el); });

// ---- aperçu dans le panel : le vrai téléphone avec des données d'exemple, applications cliquables
G.preview.phone = function (box) {
  G.clear(box);
  const info = { name: 'Camille Durand', number: '555-0123', wall: 'dusk', dnd: false, sound: true, cash: 640, bank: 18250, unread: 2, bills: 1, apps: [
    { id: 'calls', label: 'Appels', badge: 1 }, { id: 'messages', label: 'Messages', badge: 2 }, { id: 'contacts', label: 'Contacts', badge: 0 }, { id: 'services', label: 'Annuaire', badge: 0 }, { id: 'bank', label: 'Banque', badge: 0 }, { id: 'bills', label: 'Factures', badge: 1 },
    { id: 'garage', label: 'Garage', badge: 0 }, { id: 'gps', label: 'GPS', badge: 0 }, { id: 'notes', label: 'Notes', badge: 0 }, { id: 'calc', label: 'Calculatrice', badge: 0 }, { id: 'settings', label: 'Réglages', badge: 0 }] };
  const DATA = {
    home: { info },
    calls: { voice: true, contacts: [{ name: 'Alex Martin', number: '555-0456' }, { name: 'Léa Roche', number: '555-0789' }], recent: [
      { num: '555-0456', label: 'Alex Martin', out: false, missed: true, status: 'missed', secs: 0, at: '14/10 18:10' },
      { num: 'svc:police', label: 'Police', out: true, missed: false, status: 'done', secs: 74, at: '14/10 17:41', svc: true },
      { num: '555-0789', label: 'Léa Roche', out: true, missed: false, status: 'done', secs: 312, at: '13/10 21:05' }] },
    messages: { threads: [{ num: '555-0456', label: 'Alex', last: 'On se retrouve au garage ?', mine: false, at: '14/10 18:02', unread: 2 }, { num: 'svc:police', label: 'Police', last: 'Cambriolage rue Alta', mine: true, at: '14/10 17:40', unread: 0, svc: true }] },
    contacts: { list: [{ id: 1, name: 'Alex Martin', number: '555-0456' }, { id: 2, name: 'Léa Roche', number: '555-0789' }] },
    services: { list: [{ id: 'police', name: 'Police', duty: 3 }, { id: 'ems', name: 'Ambulanciers', duty: 0 }, { id: 'mecano', name: 'Garage Central', duty: 1 }] },
    bank: { bank: 18250, cash: 640, iban: 'PB00123456', min: 1, max: 250000, fee: 1, contacts: [{ name: 'Alex', number: '555-0456' }], tx: [{ label: 'Salaire', amount: 450, plus: true, note: '', at: '14/10 12:00' }, { label: 'Virement émis', amount: 120, plus: false, note: 'loyer', at: '13/10 20:11' }] },
    bills: { bank: 18250, list: [{ id: 1, from: 'Garage Central', reason: 'Réparation', amount: 300, fine: false, status: 'pending', at: '14/10' }, { id: 2, from: 'Police', reason: 'Excès de vitesse', amount: 150, fine: true, status: 'paid', at: '12/10' }] },
    garage: { list: [{ plate: 'AB123CD', label: 'Sultan', state: 'out', garage: '' }, { plate: 'ZX987YT', label: 'Panto', state: 'garage', garage: 'Garage Legion' }] },
    gps: { places: [{ id: 1, label: 'Hôpital Pillbox' }, { id: 2, label: 'Commissariat de Mission Row' }, { id: 3, label: 'Legion Square' }] },
    notes: { list: [{ id: 1, title: 'Courses', body: 'Pain\nLait', at: '14/10 09:00' }] },
    settings: { wall: 'dusk', walls: ['dusk', 'ocean', 'ember', 'forest', 'rose', 'mono', 'banner'], dnd: false, sound: true, number: '555-0123', name: 'Camille Durand', iban: 'PB00123456' },
    thread: { num: '555-0456', label: 'Alex', svc: false, canAdd: false, maxlen: 240, msgs: [{ id: 1, mine: false, body: 'On se retrouve au garage ?', at: '14/10 18:02' }, { id: 2, mine: true, body: 'Oui, dans dix minutes.', at: '14/10 18:03' }] },
  };
  const ph = G.phoneView({ page: (p) => { setTimeout(() => ph.set({ frame: { phone: info }, page: { page: p, data: DATA[p] || {} } }), 30); }, act: (n, pl, pg) => { setTimeout(() => {
    if (n === 'call') {   // aperçu : un faux appel qui décroche au bout de 2 s
      const lbl = { '555-0456': 'Alex Martin', '555-0789': 'Léa Roche', 'svc:police': 'Police' }[pl.num] || pl.num;
      ph.onCall({ state: 'outgoing', id: 1, label: lbl, num: pl.num, svc: String(pl.num).startsWith('svc:'), since: 0, t: Date.now() });
      setTimeout(() => ph.onCall({ state: 'live', id: 1, label: lbl, num: pl.num, svc: String(pl.num).startsWith('svc:'), since: 0, t: Date.now() }), 2000);
      return;
    }
    ph.say(true, 'Aperçu : action « ' + n + ' » non exécutée.');
    if (n === 'open_thread') ph.set({ frame: { phone: info }, page: { page: 'thread', data: DATA.thread } }); }, 30); }, close: () => {},
    callAct: (n) => (n === 'speaker' ? ph.onCall({ state: 'live', id: 1, label: 'Alex Martin', num: '555-0456', since: 12, speaker: !ph.spk, t: Date.now() }, (ph.spk = !ph.spk)) : ph.onCall({ state: 'ended', reason: 'Aperçu : appel terminé.' })) });
  const scene = h('div', { class: 'gph-prev' }, h('div', { class: 'gph-win' }, ph.el));
  box.appendChild(G.fitStage(scene, 1240, 820));
  ph.start({ frame: { phone: info }, clock: [21, 37], page: { page: 'home', data: DATA.home } });
};
})();
