/* Écran de mort : chronomètre, appel des secours, réapparition. Les touches sont gérées par le client (E : secours, G maintenu : réapparaître). */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ':' + (s % 60 < 10 ? '0' : '') + (s % 60); };

function deathView(cfg, opt) {
  opt = opt || {};
  const acc = cfg.c_accent || '#ff6b7d';
  const total = Math.max(1, opt.delay != null ? opt.delay : (cfg.respawn_delay || 120));
  const NS = 'http://www.w3.org/2000/svg', C = 2 * Math.PI * 54;
  const sv = (t, a) => { const e = document.createElementNS(NS, t); Object.keys(a).forEach((k) => e.setAttribute(k, a[k])); return e; };
  const svg = sv('svg', { viewBox: '0 0 120 120', class: 'gd-svg' });
  svg.appendChild(sv('circle', { cx: 60, cy: 60, r: 54, class: 'gd-tr' }));
  const arc = sv('circle', { cx: 60, cy: 60, r: 54, class: 'gd-ar', 'stroke-dasharray': C.toFixed(1), 'stroke-dashoffset': 0, transform: 'rotate(-90 60 60)' });
  svg.appendChild(arc);
  const t = h('b', { class: 'gd-time' }, fmt(total)), fill = h('i', { class: 'gd-fill' }), keys = h('div', { class: 'gd-keys' });
  let staff = !!opt.staff, last = total;
  const el = h('div', { class: 'gd', style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } },
    h('div', { class: 'gd-in' },
      h('div', { class: 'gd-top' }, h('h1', null, cfg.title || 'Tu es inconscient'), cfg.subtitle ? h('p', null, cfg.subtitle) : null),
      h('div', { class: 'gd-clock' }, svg, h('div', { class: 'gd-ct' }, t, h('small', null, 'avant de pouvoir réapparaître'))),
      keys));
  function key(k, label, cls, extra) { return h('div', { class: 'gd-k ' + (cls || '') }, h('kbd', null, k), h('span', null, label), extra || null); }
  function paint(rem) {
    G.clear(keys);
    if (cfg.allow_ems !== false) keys.appendChild(key('E', 'Appeler les secours'));
    const cost = Number(cfg.respawn_cost) || 0;
    keys.appendChild(key('G', rem <= 0 ? 'Maintiens pour réapparaître' + (cost ? ' (' + G.money(cost) + ')' : '') : 'Réapparition bientôt disponible', rem <= 0 ? 'ok' : 'wait', h('div', { class: 'gd-hold' }, fill)));
    if (staff) keys.appendChild(key('H', 'Se réanimer (staff)', 'staff'));
  }
  function setRemaining(rem) {
    rem = Math.max(0, rem);
    t.textContent = fmt(rem);
    arc.setAttribute('stroke-dashoffset', (C * (1 - rem / total)).toFixed(1));
    const was = last <= 0; last = rem;
    if (!keys.firstChild || (rem <= 0) !== was) paint(rem);
  }
  setRemaining(total);
  return { el, setRemaining, setHold: (p) => { fill.style.transform = 'scaleX(' + Math.max(0, Math.min(1, p)) + ')'; }, setStaff: (v) => { staff = !!v; paint(last); } };
}
G.deathView = deathView;

let cur = null, tick = null;
G.on('death.open', (d) => {
  clearInterval(tick);
  const cfg = d.cfg || {}; const start = Date.now(), delay = d.delay || cfg.respawn_delay || 120;
  cur = deathView(cfg, { delay, staff: d.staff });
  const r = G.clear(document.getElementById('g-death') || (function () { const e = h('div', { id: 'g-death' }); G.root.appendChild(e); return e; })());
  r.classList.remove('hidden'); r.appendChild(cur.el);
  tick = setInterval(() => { if (cur) cur.setRemaining(delay - (Date.now() - start) / 1000); }, 250);
});
G.on('death.staff', (d) => { if (cur) cur.setStaff(d && d.on); });
G.on('death.hold', (d) => { if (cur) cur.setHold(d.p || 0); });
G.on('death.close', () => { clearInterval(tick); const r = document.getElementById('g-death'); if (r) { G.clear(r); r.classList.add('hidden'); } cur = null; });

G.preview.death = function (box, cfg) {
  G.clear(box);
  const v = deathView(cfg, { delay: 102, staff: true });
  box.appendChild(G.fitStage(h('div', { class: 'tg-scene', style: { width: '1240px', height: '640px', background: 'linear-gradient(160deg,#3a4a66,#171b28 70%)' } }, v.el), 1240, 640));
};
})();
