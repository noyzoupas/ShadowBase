/* Éditeur de placement : l'écran 1920×1080 avec les VRAIS éléments (compteur, HUD, bandeau staff, notifications, menu).
   On les attrape et on les pose ; l'enregistrement est validé par le serveur. Texte inséré avec textContent uniquement. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const W = 1920, H = 1080;
const NPOS_LABEL = { 'top-left': 'Haut gauche', 'top-center': 'Haut centre', 'top-right': 'Haut droite', 'bottom-left': 'Bas gauche', 'bottom-center': 'Bas centre', 'bottom-right': 'Bas droite', map: 'Sous la mini-carte' };
const NPOS = { 'top-left': [4, 6], 'top-center': [50, 6], 'top-right': [96, 6], 'bottom-left': [4, 94], 'bottom-center': [50, 94], 'bottom-right': [96, 94], map: [10, 70] };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const r1 = (v) => Math.round(v * 10) / 10;
const STAFF_ITEMS = [
  { label: 'Prendre mon service', desc: 'Obligatoire pour utiliser les outils.', icon: 'bolt' }, { label: 'Gestion des joueurs', desc: 'Liste des joueurs et actions.', icon: 'users', badge: '12' },
  { label: 'Gestion personnelle', desc: 'Noclip, invincible, invisible…', icon: 'bolt' }, { label: 'Gestion des véhicules', desc: 'Créer, réparer, supprimer.', icon: 'engine' },
  { label: 'Gestion du serveur', desc: 'Annonces, redémarrage, météo.', icon: 'globe' }, { label: 'Gestion des reports', desc: 'Signalements en attente.', icon: 'help', badge: '3' },
  { label: 'Gestion des sanctions', desc: 'Bannissements et avertissements.', icon: 'shield' }, { label: 'Options supplémentaires', desc: 'Ouvrir le panel.', icon: 'sliders' }];

/* api : { save(groups) -> Promise|void }   blk : { cfg:{hud,staff,notify,menus}, can:{hud,staff,notify,menus} } */
G.layoutEditor = function (blk, api) {
  const init = JSON.parse(JSON.stringify(blk.cfg || {}));
  let st = JSON.parse(JSON.stringify(init));
  const can = blk.can || {};
  let sel = null, snap = true, dirty = {};
  const wrap = h('div', { class: 'lay' });
  const info = h('div', { class: 'lay-info' });
  const host = h('div', { class: 'lay-host' });
  wrap.appendChild(host); wrap.appendChild(info);

  function items() {
    const hud = st.hud || {}, out = [];
    const style = hud.style || 'ring';
    const hv = G.hudView ? G.hudView(Object.assign({}, hud, { status_on: true, show_vehicle: true })) : null;
    if (hv) {
      if (style === 'photo') out.push({ id: 'hud.main', label: 'HUD (infos en bas à gauche)', ns: 'hud', el: hv.main, mode: 'bottom', kx: 'photo_x', ky: 'photo_y' });
      else out.push({ id: 'hud.main', label: style === 'ring' ? 'Anneaux (faim, soif…)' : 'HUD (barres, heure, argent)', ns: 'hud', el: hv.main, mode: 'pos', kx: style === 'ring' ? 'ring_x' : 'pos_x', ky: style === 'ring' ? 'ring_y' : 'pos_y', ks: 'scale', ko: 'opacity' });
      if (style === 'ring' && hv.bar) out.push({ id: 'hud.bar', label: 'Barre vie / armure', ns: 'hud', el: hv.bar, mode: 'pos', kx: 'bar_x', ky: 'bar_y' });
      out.push({ id: 'hud.veh', label: 'Compteur du véhicule', ns: 'hud', el: hv.veh, mode: 'pos', kx: 'veh_x', ky: 'veh_y', ks: 'veh_scale', live: hv });
      if (hv.top && style !== 'photo') out.push({ id: 'hud.top', label: 'Rue et boussole (fixe)', ns: 'hud', el: hv.top, fixed: true });
    }
    const sc = st.staff || {};
    if (G.staffHudView) {
      const sitems = [{ label: 'Reports en attente', value: 3, icon: 'alert', warn: true }, { label: 'Pris par moi', value: 1, icon: 'check' }, { label: 'Joueurs', value: 42, icon: 'users' }, { label: 'Staff', value: 4, icon: 'shield' }];
      const boxStyle = sc.hud_style === 'box';
      const el = G.staffHudView({ style: boxStyle ? 'box' : 'bar', top: sc.hud_top, x: sc.hud_x, y: sc.hud_y, items: sitems });
      if (el) out.push(boxStyle ? { id: 'staff.box', label: 'Tableau staff en service', ns: 'staff', el, mode: 'pos', kx: 'hud_x', ky: 'hud_y' } : { id: 'staff.bar', label: 'Barre staff en service (vertical seulement)', ns: 'staff', el, mode: 'top', ky: 'hud_top' });
    }
    const nc = st.notify || {};
    const pc = st.place || (st.place = {});
    [['chat_x', 0.9], ['chat_y', 22.5], ['prompt_x', 50], ['prompt_y', 82], ['prog_x', 50], ['prog_y', 82]].forEach((d) => { if (pc[d[0]] == null) pc[d[0]] = d[1]; });
    const LINES = [['', 'Camille Roux', 'Bonjour, vous avez vu passer une berline noire ?'], ['/me', 'Camille Roux', "regarde autour d'elle."], ['OOC', 'Alex', 'je reviens dans 5 minutes']];
    out.push({ id: 'place.chat', label: 'Chat (coin bas-gauche du texte)', ns: 'place', mode: 'bottom', kx: 'chat_x', ky: 'chat_y',
      el: h('div', { class: 'lay-chat' }, LINES.map((l) => h('div', null, l[0] ? h('i', { style: { opacity: '.6', marginRight: '6px' } }, l[0]) : null, h('b', null, l[1] + ' '), l[2]))) });
    out.push({ id: 'place.prompt', label: "Invite « Appuyez sur E pour… »", ns: 'place', mode: 'pos', kx: 'prompt_x', ky: 'prompt_y', cen: true,
      el: h('div', { class: 'lay-prompt lay-cen' }, h('span', null, 'Appuyez sur '), h('kbd', null, 'E'), h('span', null, ' pour ouvrir la boutique.')) });
    out.push({ id: 'place.prog', label: 'Barre de progression (braquage, filière, capture)', ns: 'place', mode: 'pos', kx: 'prog_x', ky: 'prog_y', cen: true,
      el: h('div', { class: 'lay-prog lay-cen' }, h('b', null, 'Braquage de supérette'), h('div', { class: 'gp-bar' }, h('i'))) });
    out.push({ id: 'notify', label: 'Notifications (se place sur 7 emplacements)', ns: 'notify', mode: 'notify' });
    out.push({ id: 'menu', label: 'Menu personnel (haut du menu)', ns: 'menus', mode: 'menu' });
    if (st.staffmenu) out.push({ id: 'staffmenu', label: 'Menu staff F10 (haut du menu)', ns: 'staffmenu', mode: 'smenu', ks: 'scale', ko: 'opacity' });
    return out;
  }

  function put(it) {
    const c = st[it.ns] || (st[it.ns] = {});
    if (it.mode === 'pos') { it.el.style.left = r1(c[it.kx]) + '%'; it.el.style.top = r1(c[it.ky]) + '%'; }
    else if (it.mode === 'bottom') { it.el.style.left = r1(c[it.kx]) + '%'; it.el.style.bottom = r1(c[it.ky]) + '%'; it.el.style.top = 'auto'; }
    else if (it.mode === 'top') it.el.style.top = r1(c[it.ky]) + '%';
  }

  function draw() {
    G.clear(host);
    const scene = h('div', { class: 'lay-scene' });
    scene.appendChild(h('div', { class: 'lay-world' }));
    scene.appendChild(h('div', { class: 'lay-mm' }, h('span', null, 'Mini-carte du jeu')));
    scene.appendChild(h('i', { class: 'lay-gx' })); scene.appendChild(h('i', { class: 'lay-gy' }));
    const list = items(), timers = [];
    list.forEach((it) => {
      const c = st[it.ns] || {};
      if (it.mode === 'notify') {
        const pos = c.position || 'map';
        const box = { position: 'absolute', width: '470px', display: 'flex', flexDirection: 'column', gap: '9px' };
        if (pos === 'map') { box.left = '28px'; box.bottom = clamp(Number(c.lift) || 24, 5, 60) + '%'; }
        else {
          if (/top/.test(pos)) box.top = '24px'; else box.bottom = '24px';
          if (/left/.test(pos)) box.left = '24px'; else if (/right/.test(pos)) { box.right = '24px'; box.alignItems = 'flex-end'; } else { box.left = 'calc(50% - 235px)'; box.alignItems = 'center'; }
          if (/bottom/.test(pos)) box.justifyContent = 'flex-end';
        }
        const cont = h('div', { class: 'lay-notif', style: box });
        const samples = [['success', 'Achat réussi', 'Tu as payé 120 $ en espèces.'], ['announce', 'Annonce', 'Redémarrage du serveur dans 10 minutes.'], ['warn', 'Attention', 'Ta soif est très basse.']];
        samples.forEach((s) => { const t = G.toastEl(c, { type: s[0] === 'announce' ? 'info' : s[0], kind: s[0] === 'announce' ? 'announce' : undefined, title: s[1], text: s[2], duration: 1e7 }); t.el.classList.add('lay-nt'); cont.appendChild(t.el); });
        it.el = cont; it.holder = cont; scene.appendChild(cont);
      } else if (it.mode === 'menu') {
        const tmp = h('div'); let m = null;
        try { G.preview.rmenu(tmp, Object.assign({}, c), { sel: 2 }); m = tmp.querySelector('.rm'); } catch (e) { m = null; }
        const box = h('div', { class: 'lay-menu' }, m || h('div', { class: 'lay-fb' }, 'Menu'));
        it.el = box; scene.appendChild(box);
        box.style.left = 'calc(50% + ' + (Number(c.offset_x) || 0) + 'px)'; box.style.top = 'calc(50% + ' + (Number(c.offset_y) || 0) + 'px)';
      } else if (it.mode === 'smenu') {
        // le vrai menu staff : même rendu qu'en jeu (bannière, titre, lignes), posé par son HAUT
        const sc = Number(c.scale) || 1, tmp = h('div'); let m = null;
        const th = G.rmenu && G.rmenu.staffTheme ? G.rmenu.staffTheme(Object.assign({}, st.menus || {}), Object.assign({}, c), W, H) : (st.menus || {});
        try { G.preview.rmenu(tmp, th, { sel: 1, menuTitle: 'Menu staff', subtitle: 'Staff · en service', items: STAFF_ITEMS }); m = tmp.querySelector('.rm'); } catch (e) { m = null; }
        const box = h('div', { class: 'lay-menu lay-smenu' }, m || h('div', { class: 'lay-fb' }, 'Menu staff'));
        it.el = box; scene.appendChild(box);
        box.style.left = r1(Number(c.x != null ? c.x : 50)) + '%'; box.style.top = r1(Number(c.y != null ? c.y : 12)) + '%';
      } else if (it.el) {
        if (it.fixed) { it.el.classList.add('lay-fixed'); }
        scene.appendChild(it.el); put(it);
      }
      if (it.el && !it.fixed) {
        it.el.classList.add('lay-it'); it.el.dataset.lay = it.id;
        if (it.id === sel) it.el.classList.add('on');
        if (!can[it.ns]) it.el.classList.add('lock');
        it.el.addEventListener('pointerdown', (e) => start(e, it, scene));
      }
      if (it.live && it.live.update) {   // le compteur vit, comme en jeu
        const base = { visible: true, hp: 82, armor: 40, hour: 21, minute: 37 };
        let t = 0.6; const f = () => { const sp = Math.round((1 - Math.cos(t)) / 2 * 200); it.live.update(Object.assign({}, base, { veh: { speed: sp, fuel: 62, range: 12.4, rangemax: 20, gear: Math.min(6, 1 + Math.floor(sp / 35)), rpm: 40 + (sp % 35), engine: 90, on: true, odo: 48213.7 } }), { hunger: 74, thirst: 45, stress: 20, cash: 4250, bank: 18900 }); };
        f(); const iv = setInterval(() => { if (!host.isConnected || !it.el.isConnected) { clearInterval(iv); return; } t += 0.06; f(); }, 100); timers.push(iv);
      }
    });
    const stage = G.fitStage(scene, W, H);
    host.appendChild(stage); stage._scene = scene; stage._items = list;
    drawInfo(list);
    return stage;
  }

  function k(scene) { const r = scene.getBoundingClientRect(); return r.width / W || 1; }
  function start(e, it, scene) {
    e.preventDefault(); e.stopPropagation();
    if (sel !== it.id) { sel = it.id; scene.querySelectorAll('.lay-it').forEach((n) => n.classList.toggle('on', n.dataset.lay === sel)); drawInfo(curStage ? curStage._items : []); }
    if (!can[it.ns]) return;
    const c = st[it.ns], sx = e.clientX, sy = e.clientY, kk = k(scene), gx = scene.querySelector('.lay-gx'), gy = scene.querySelector('.lay-gy');
    const o = { x: c[it.kx], y: c[it.ky], ox: Number(c.offset_x) || 0, oy: Number(c.offset_y) || 0, sx: Number(c.x != null ? c.x : 50), sy: Number(c.y != null ? c.y : 12) };
    it.el.setPointerCapture(e.pointerId); it.el.classList.add('drag'); it.pending = null;
    if (it.mode === 'notify') Object.keys(NPOS).forEach((n) => { const g = h('i', { class: 'lay-slot' + (n === (c.position || 'map') ? ' on' : ''), 'data-slot': n, style: { left: NPOS[n][0] + '%', top: NPOS[n][1] + '%' } }); g.appendChild(h('b', null, NPOS_LABEL[n])); scene.appendChild(g); });
    const mv = (ev) => {
      const dx = (ev.clientX - sx) / kk, dy = (ev.clientY - sy) / kk;
      if (it.mode === 'pos') { let x = clamp(o.x + dx / W * 100, 0, 100), y = clamp(o.y + dy / H * 100, 0, 100); if (snap) { if (Math.abs(x - 50) < 0.8) x = 50; if (Math.abs(y - 50) < 0.8) y = 50; } c[it.kx] = r1(x); c[it.ky] = r1(y); put(it); }
      else if (it.mode === 'bottom') { c[it.kx] = r1(clamp(o.x + dx / W * 100, 0, 95)); c[it.ky] = r1(clamp(o.y - dy / H * 100, 0, 60)); put(it); }
      else if (it.mode === 'top') { c[it.ky] = r1(clamp(o.y + dy / H * 100, 0, 30)); put(it); }
      else if (it.mode === 'smenu') {
        let x = clamp(o.sx + dx / W * 100, 0, 100), y = clamp(o.sy + dy / H * 100, 0, 100);
        if (snap && Math.abs(x - 50) < 0.8) x = 50;
        c.x = r1(x); c.y = r1(y);
        it.el.style.left = c.x + '%'; it.el.style.top = c.y + '%';
      } else if (it.mode === 'menu') {
        let ox = clamp(Math.round(o.ox + dx), -1900, 1900), oy = clamp(Math.round(o.oy + dy), -1000, 1000);
        if (snap) { if (Math.abs(ox) < 14) ox = 0; if (Math.abs(oy) < 14) oy = 0; }
        c.offset_x = ox; c.offset_y = oy; c.position = 'center';
        it.el.style.left = 'calc(50% + ' + ox + 'px)'; it.el.style.top = 'calc(50% + ' + oy + 'px)';
      } else if (it.mode === 'notify') {
        // la pile suit le curseur ; l'emplacement le plus proche s'éclaire et ne s'applique qu'au relâchement
        const r = scene.getBoundingClientRect(), px = (ev.clientX - r.left) / r.width * 100, py = (ev.clientY - r.top) / r.height * 100;
        let best = 'map', bd = 1e9;
        Object.keys(NPOS).forEach((n) => { const d = Math.hypot(NPOS[n][0] - px, NPOS[n][1] - py); if (d < bd) { bd = d; best = n; } });
        it.el.style.transform = 'translate(' + Math.round(dx) + 'px,' + Math.round(dy) + 'px)';
        scene.querySelectorAll('.lay-slot').forEach((n) => n.classList.toggle('on', n.dataset.slot === best));
        it.pending = best; return;
      }
      dirty[it.ns] = true; mark(it.ns);
      if (gx) gx.style.display = (it.mode === 'pos' && c[it.kx] === 50) || (it.mode === 'menu' && c.offset_x === 0) || (it.mode === 'smenu' && c.x === 50) ? 'block' : 'none';
      if (gy) gy.style.display = (it.mode === 'pos' && c[it.ky] === 50) || (it.mode === 'menu' && c.offset_y === 0) ? 'block' : 'none';
      refreshNums();
    };
    const up = () => { it.el.releasePointerCapture && it.el.releasePointerCapture(e.pointerId); it.el.classList.remove('drag'); if (gx) gx.style.display = 'none'; if (gy) gy.style.display = 'none'; it.el.removeEventListener('pointermove', mv); it.el.removeEventListener('pointerup', up); it.el.removeEventListener('pointercancel', up); if (it.mode === 'notify') { it.el.style.transform = ''; scene.querySelectorAll('.lay-slot').forEach((n) => n.remove()); if (it.pending && it.pending !== c.position) { c.position = it.pending; dirty[it.ns] = true; mark(it.ns); } redraw(); } };
    it.el.addEventListener('pointermove', mv); it.el.addEventListener('pointerup', up); it.el.addEventListener('pointercancel', up);
  }

  let saveBtn, nums, status;
  function mark(ns) { if (saveBtn) { saveBtn.disabled = !Object.keys(dirty).some((n) => dirty[n]); saveBtn.textContent = 'Enregistrer' + (Object.keys(dirty).filter((n) => dirty[n]).length ? ' (' + Object.keys(dirty).filter((n) => dirty[n]).length + ')' : ''); } }
  let curStage = null;
  function redraw() { curStage = draw(); }
  function curItem(list) { return (list || []).find((i) => i.id === sel); }
  function refreshNums() {
    if (!nums) return;
    const it = curItem(curStage && curStage._items); if (!it) { nums.textContent = ''; return; }
    const c = st[it.ns] || {};
    if (it.mode === 'pos' || it.mode === 'bottom') nums.textContent = 'X ' + r1(c[it.kx]) + ' %   ·   Y ' + r1(c[it.ky]) + ' %';
    else if (it.mode === 'top') nums.textContent = 'Distance du haut : ' + r1(c[it.ky]) + ' %';
    else if (it.mode === 'smenu') nums.textContent = 'Milieu ' + r1(Number(c.x != null ? c.x : 50)) + ' %  ·  Haut ' + r1(Number(c.y != null ? c.y : 12)) + ' %';
    else if (it.mode === 'menu') nums.textContent = 'Décalage : ' + (c.offset_x || 0) + ' px / ' + (c.offset_y || 0) + ' px depuis le centre';
    else if (it.mode === 'notify') nums.textContent = 'Emplacement : ' + (c.position || 'map');
  }
  function drawInfo(list) {
    G.clear(info);
    const it = curItem(list);
    saveBtn = h('button', { class: 'pl pri', onclick: doSave }, 'Enregistrer'); saveBtn.disabled = !Object.keys(dirty).some((n) => dirty[n]);
    nums = h('span', { class: 'chip' }, ''); status = h('span', { class: 'lay-st' }, '');
    const head = h('div', { class: 'lay-h' }, h('b', null, it ? it.label : 'Clique sur un élément pour le choisir, puis glisse-le.'), nums);
    const row = h('div', { class: 'lay-r' });
    if (it && it.ks && can[it.ns]) {
      const c = st[it.ns]; const o = h('output', null, String(c[it.ks] != null ? c[it.ks] : 1));
      const inp = h('input', { type: 'range', min: 0.6, max: 1.6, step: 0.05, value: c[it.ks] != null ? c[it.ks] : 1, oninput: () => { c[it.ks] = Number(inp.value); o.textContent = inp.value; dirty[it.ns] = true; redraw(); } });
      row.appendChild(h('label', { class: 'lay-s' }, 'Taille', inp, o));
    }
    if (it && it.ko && can[it.ns]) {
      const c = st[it.ns]; const o = h('output', null, String(c[it.ko] != null ? c[it.ko] : 1));
      const inp = h('input', { type: 'range', min: 0.3, max: 1, step: 0.05, value: c[it.ko] != null ? c[it.ko] : 1, oninput: () => { c[it.ko] = Number(inp.value); o.textContent = inp.value; dirty[it.ns] = true; redraw(); } });
      row.appendChild(h('label', { class: 'lay-s' }, 'Opacité', inp, o));
    }
    if (it && it.mode === 'notify' && (st.notify || {}).position === 'map' && can.notify) {
      const c = st.notify; const o = h('output', null, String(c.lift || 24));
      const inp = h('input', { type: 'range', min: 5, max: 60, step: 1, value: c.lift || 24, oninput: () => { c.lift = Number(inp.value); o.textContent = inp.value; dirty.notify = true; redraw(); } });
      row.appendChild(h('label', { class: 'lay-s' }, 'Hauteur', inp, o));
    }
    const tools = h('div', { class: 'lay-r' },
      h('label', { class: 'lay-ck' }, h('input', { type: 'checkbox', checked: snap, onchange: (e) => { snap = e.target.checked; } }), 'Aimanter au centre'),
      h('button', { class: 'pl', onclick: () => { st = JSON.parse(JSON.stringify(init)); dirty = {}; sel = null; redraw(); } }, 'Annuler les changements'), saveBtn, status);
    info.appendChild(head); if (row.children.length) info.appendChild(row); info.appendChild(tools);
    if (!Object.keys(can).some((n) => can[n])) info.appendChild(h('div', { class: 'lay-note' }, "Tu n'as pas le droit de modifier ces positions : l'aperçu est en lecture seule."));
    refreshNums(); mark();
  }
  function doSave() {
    const groups = {};
    Object.keys(dirty).forEach((ns) => { if (dirty[ns] && can[ns]) groups[ns] = st[ns]; });
    if (!Object.keys(groups).length) return;
    saveBtn.disabled = true;
    Promise.resolve(api && api.save ? api.save(groups) : null).then((ok) => { if (ok !== false) { Object.keys(groups).forEach((n) => { init[n] = JSON.parse(JSON.stringify(st[n])); dirty[n] = false; }); } mark(); }, () => mark());
  }
  redraw();
  return wrap;
};
})();
