/* Garage et fourrière, au style « boutique » (coque G.shell) : rail des pages, liste des véhicules, fiche à droite avec les actions.
   Les formulaires (donner une clé) s'affichent dans la fiche. Les envois restent garage.page / garage.act / garage.close. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let cur = null;
const host = () => document.getElementById('g-garage') || (function () { const e = h('div', { id: 'g-garage', class: 'hidden' }); G.root.appendChild(e); return e; })();

function garageView(o) {
  let frame = o.frame || {}, page = o.page || { blocks: [] };
  const nav = () => (frame.nav || []).map((n) => ({ id: n.id, icon: n.icon || 'car', label: n.label }));
  const photos = ((G.cfg && G.cfg.shops_settings) || {}).vehicle_images !== false;
  const mk = G.marketView({ title: frame.brand || 'Garage', sub: frame.name || '', money: { cash: frame.cash, bank: frame.bank }, onClose: o.onClose, search: false,
    tabs: nav(), tabOn: page.page, onTab: (id) => { o.onPage && o.onPage(id); } });
  const table = () => (page.blocks || []).find((b) => b.type === 'table');
  function drawForm(b) {
    const vals = {};
    const fields = (b.fields || []).map((f) => {
      const s = h('select', { class: 'mk-sel' }, (f.opts || []).map((op) => h('option', { value: op[1] === undefined ? op : op[0] }, op[1] === undefined ? op : op[1])));
      vals[f.k] = s; return h('label', { class: 'mk-fl' }, h('span', null, f.label), s);
    });
    b.submit = b.submit || { act: '', label: 'Valider' };
    const go = h('button', { class: 'mk-b pri', disabled: b.submit.disabled || null, onclick: () => { const p = {}; Object.keys(vals).forEach((k) => { p[k] = vals[k].value; }); o.onAct && o.onAct(b.submit.act, p, page.page); } }, b.submit.label);
    return h('div', { class: 'mk-form' }, h('h2', null, b.title || ''), b.desc ? h('p', null, b.desc) : null, fields, go);
  }
  function draw() {
    const t = table(), rows = (t && t.rows) || [];
    const form = (page.blocks || []).find((b) => b.type === 'form');
    const note = (page.blocks || []).find((b) => b.type === 'notice');
    const cols = ((t && t.columns) || []).filter((c) => ['plate', 'label', 'model', 'state'].indexOf(c.k) < 0);
    mk.setCards(rows.map((r, i) => ({ id: 'r' + i, title: r.label || r.plate, sub: r.plate || '', badge: r.state || null, art: 'car', icon: 'car',
      img: photos && /^[a-z0-9_]+$/i.test(r.model || '') ? 'https://docs.fivem.net/vehicles/' + String(r.model).toLowerCase() + '.webp' : '',
      chips: cols.map((c) => r[c.k]).filter((x) => x != null && x !== '').map((x) => h('span', { class: 'mk-chip s' }, String(x))),
      actions: (r.actions || []).map((a) => ({ label: a.label, primary: !!a.primary, ghost: !a.primary, onclick: () => o.onAct && o.onAct(a.act, a.payload || {}, page.page) })) })), []);
    const nodes = [];
    if (form) nodes.push(drawForm(form));
    if (note) nodes.push(h('span', null, G.ico('info'), ' ' + note.text));
    mk.note(nodes.length ? h('div', null, nodes) : null);
  }
  draw();
  return {
    el: mk.el,
    set(d) { if (d.frame) { frame = d.frame; mk.setMoney({ cash: frame.cash, bank: frame.bank }); mk.setTabs(nav(), (d.page && d.page.page) || page.page); } if (d.page) { page = d.page; mk.setTabs(nav(), page.page); } draw(); },
    say(ok, msg) { mk.say(ok, msg); },
  };
}
G.garageView = garageView;

G.on('garage.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = garageView({ frame: d.frame, page: d.page, onClose: () => G.post('garage.close', {}), onPage: (p) => G.post('garage.page', { page: p }), onAct: (n, pl, p) => G.post('garage.act', { name: n, payload: pl, page: p }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'garage'); G.uiStack.push({ id: 'garage', onEscape: () => G.post('garage.close', {}) });
});
G.on('garage.page', (d) => { if (cur) cur.set(d); });
G.on('garage.result', (d) => { if (!cur) return; cur.set(d); cur.say(d.ok, d.msg); });
G.on('garage.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'garage'); });

G.preview.garage = function (box) {
  G.clear(box);
  const frame = { name: 'Camille Durand', brand: 'Garage public — Legion Square', tone: '#dfe2e7', cash: 640, bank: 18250,
    nav: [{ id: 'cars', label: 'Véhicules', icon: 'car' }, { id: 'keys', label: 'Clés', icon: 'lock' }] };
  const page = { page: 'cars', title: 'Garage public — Legion Square', blocks: [
    { type: 'table', title: 'Mes véhicules', columns: [{ k: 'plate', label: 'Plaque' }, { k: 'label', label: 'Modèle' }, { k: 'state', label: 'État' }, { k: 'where', label: 'Détail' }],
      rows: [{ plate: 'PB 4821', label: 'Sultan', state: 'Au garage', where: "N'importe quel garage", actions: [{ act: 'take', label: 'Sortir', primary: true }] }, { plate: 'PB 1107', label: 'Blista', state: 'Dehors', where: '', actions: [] }] }] };
  box.appendChild(G.fitStage(h('div', { class: 'sh-stage', style: { width: '1240px' } }, garageView({ frame, page, onPage: () => {}, onAct: () => {} }).el), 1240, 640));
};
})();
