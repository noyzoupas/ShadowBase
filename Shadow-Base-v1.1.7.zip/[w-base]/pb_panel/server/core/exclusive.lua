-- Exclusivité Shadow Framework : Shadow Base ne fonctionne qu'avec « wframework ». Les frameworks et inventaires concurrents (ESX, QBCore, Qbox, ox_inventory...)
-- sont arrêtés dès qu'ils démarrent, et un bandeau le dit en console. Non désactivable : c'est le but de la base.
-- Pour qu'ils ne reviennent pas, retire leurs lignes « ensure » de server.cfg.

PB = PB or {}
PB.Exclusive = PB.Exclusive or { stopped = {} }
local X = PB.Exclusive
local RES = GetCurrentResourceName()

local EXACT = { es_extended = true, ['qb-core'] = true, qbx_core = true, ox_inventory = true, ['qs-inventory'] = true, core_inventory = true,
    ['ps-inventory'] = true, ['lj-inventory'] = true, ['ox_core'] = true, ['ND_Core'] = true, vrp = true }
local PREFIX = { 'esx_', 'qb-', 'qbx_', 'es_' }

function X.IsForeign(name)
    name = tostring(name or '')
    if name == '' or name == RES or name == 'wframework' then return false end
    if EXACT[name] then return true end
    for _, p in ipairs(PREFIX) do if name:sub(1, #p) == p then return true end end
    return false
end

local function live(n) local ok, s = pcall(GetResourceState, n) s = ok and s or 'missing' return s == 'started' or s == 'starting' end

function X.Running()
    local out = {}
    local n = GetNumResources and GetNumResources() or 0
    for i = 0, n - 1 do
        local r = GetResourceByFindIndex(i)
        if r and X.IsForeign(r) and live(r) then out[#out + 1] = r end
    end
    table.sort(out)
    return out
end

function X.Enforce()
    if PB.License and PB.License.Locked then return {} end
    local found = X.Running()
    for _, r in ipairs(found) do
        X.stopped[r] = os.time()
        print(('^1[Shadow Base]^7 « %s » n\'est pas compatible : Shadow Base fonctionne uniquement avec wframework. Ressource arrêtée. Retire « ensure %s » de server.cfg.'):format(r, r))
        StopResource(r)
    end
    return found
end

function X.WFramework() return live('wframework') end

CreateThread(function()
    Wait(1000)
    X.Enforce()
    if not X.WFramework() then
        print('^3[Shadow Base]^7 La ressource « wframework » n\'est pas démarrée : ajoute « ensure wframework » avant « ensure ' .. RES .. ' » dans server.cfg.')
    end
    while true do Wait(30000) X.Enforce() end
end)

AddEventHandler('onResourceStart', function(name)
    if X.IsForeign(name) then SetTimeout(500, X.Enforce) end
end)

exports('Exclusive', function() return { framework = 'wframework', companion = X.WFramework(), stopped = X.stopped } end)
