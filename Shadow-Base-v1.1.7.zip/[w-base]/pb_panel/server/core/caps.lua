-- Matrice de compatibilité : chaque fonctionnalité dit honnêtement si elle est prise en charge.
-- statuts : 'ok' (pris en charge), 'partial' (partiel, voir la raison), 'off' (non pris en charge ici).

PB.Env = PB.Env or {}

local function can(fn) local ok, r = pcall(fn) return ok and r or false end

-- Détection des capacités de l'environnement (une fois au démarrage, refaite à la demande).
function PB.DetectEnv()
    local E = PB.Env
    E.io = can(function() return io ~= nil and type(io.open) == 'function' end)
    E.popen = can(function() return io ~= nil and type(io.popen) == 'function' end)
    E.exec = can(function() return os ~= nil and type(os.execute) == 'function' end)
    E.proc = E.io and can(function() local f = io.open('/proc/meminfo', 'r') if f then f:close() return true end end)
    E.consoleListener = type(RegisterConsoleListener) == 'function'
    E.http = type(PerformHttpRequest) == 'function'
    E.registeredCommands = type(GetRegisteredCommands) == 'function'
    E.saveResourceFile = type(SaveResourceFile) == 'function'
    E.oxmysql = GetResourceState and GetResourceState('oxmysql') == 'started' or false
    return E
end

-- Aide : construit une entrée de matrice.
function PB.Cap(feature, status, reason) return { feature = feature, status = status, reason = reason } end

function PB.Capsify(list)
    -- Normalise : accepte { feature, status, reason } ou { f, s, r }.
    local out = {}
    for _, c in ipairs(list or {}) do out[#out + 1] = { feature = c.feature or c[1], status = c.status or c[2], reason = c.reason or c[3] } end
    return out
end

-- Résume une liste : 'ok' si tout est ok, 'off' si tout est off, sinon 'partial'.
function PB.CapSummary(list)
    local ok, off = 0, 0
    for _, c in ipairs(list or {}) do
        if c.status == 'ok' then ok = ok + 1 elseif c.status == 'off' then off = off + 1 end
    end
    local n = #(list or {})
    if n == 0 or ok == n then return 'ok' end
    if off == n then return 'off' end
    return 'partial'
end
