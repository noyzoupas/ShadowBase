-- Formulaires de configuration : un bloc `form` + son action d'enregistrement, générés ensemble.
-- Valeurs stockées en base (pb_kv), validées par PB.Validate, historisées avant/après, annulables.
-- Ce fichier fournit aussi de petits constructeurs de blocs d'interface (PB.B).

PB.Form = PB.Form or {}
PB.B = PB.B or {}
local Form = PB.Form
local B = PB.B

local permByNs = {}

-- Constructeurs de blocs -------------------------------------------------------------------------------------------
function B.notice(level, text, title) return { type = 'notice', level = level or 'info', text = text, title = title } end
function B.stats(items) return { type = 'stats', items = items } end
function B.kv(title, items) return { type = 'kv', title = title, items = items } end
function B.actions(items, title) return { type = 'actions', title = title, items = items } end
function B.table(def) def.type = 'table' return def end
function B.cols(...) return { type = 'columns', cols = { ... } } end
function B.unsupported(title, reason) return { type = 'notice', level = 'off', title = title, text = reason } end

-- Formulaire lié à des clés de configuration --------------------------------------------------------------------------
-- def : ns, id, title, desc, perm (écriture), fields = { {k,type,label,hint,default,...} },
--       after(changed, values, ctx) (facultatif), cols, restart (texte si un redémarrage est nécessaire)
-- Renvoie une fonction `build(ctx)` à appeler dans une vue.
function Form.Cfg(def)
    local defaults = {}
    for _, f in ipairs(def.fields) do
        if f.k and f.default ~= nil then defaults[f.k] = f.default end
    end
    PB.Cfg.Define(def.ns, defaults)
    if def.perm then
        permByNs[def.ns] = def.perm
        PB.Perm.Register(def.perm, def.permLabel or ('Modifier : ' .. (def.title or def.ns)), def.ns:match('^[^%.]+'))
    end
    local action = 'cfg.' .. def.ns .. '.' .. def.id
    PB.Action(action, def.perm, function(ctx, p)
        -- un champ absent de la requête reste inchangé (on le complète avec la valeur actuelle avant de valider)
        local values = {}
        for k, v in pairs(p.values or {}) do values[k] = v end
        for _, f in ipairs(def.fields) do
            if f.k and values[f.k] == nil and f.type ~= 'secret' and f.type ~= 'image' then values[f.k] = PB.Cfg.Get(def.ns, f.k, f.default) end
        end
        local clean, err = PB.Validate(def.fields, values)
        if not clean then return false, err end
        local before = {}
        for k in pairs(clean) do before[k] = PB.Cfg.Get(def.ns, k) end
        -- les champs secrets vides ne modifient rien
        for _, f in ipairs(def.fields) do
            if (f.type == 'secret' or f.type == 'image') and (clean[f.k] == nil or clean[f.k] == '') then clean[f.k] = nil before[f.k] = nil end
        end
        local changed, e = PB.Cfg.SetMany(def.ns, clean, ctx.actor, def.title or def.id)
        if not changed then return false, e or 'Enregistrement impossible.' end
        if #changed == 0 then ctx.toast = 'Aucun changement.' ctx.refresh = false return true, { changed = {} } end
        local after, b2 = {}, {}
        local imageKey = {}
        for _, f in ipairs(def.fields) do if f.type == 'image' or f.type == 'secret' then imageKey[f.k] = true end end
        for _, k in ipairs(changed) do
            after[k] = imageKey[k] and '(contenu masqué)' or clean[k]
            b2[k] = imageKey[k] and '(contenu masqué)' or before[k]
        end
        ctx.audit('config', action, def.ns, b2, after)
        if def.after then
            local ok, r = pcall(def.after, changed, clean, ctx)
            if not ok then PB.Err('après-enregistrement ' .. action .. ' : ' .. tostring(r)) ctx.toast = 'Enregistré, mais la mise en application a échoué (voir la console).'
            elseif type(r) == 'string' then ctx.toast = r end
        end
        ctx.toast = ctx.toast or ('Enregistré (' .. #changed .. ' modification' .. (#changed > 1 and 's' or '') .. ').')
        return true, { changed = changed }
    end, { audit = nil })

    return function(ctx)
        local values = {}
        for _, f in ipairs(def.fields) do
            if f.k then
                if f.type == 'secret' or f.type == 'image' then
                    values[f.k] = ''
                else
                    local v = PB.Cfg.Get(def.ns, f.k, f.default)
                    values[f.k] = v
                end
            end
        end
        local fields = {}
        for _, f in ipairs(def.fields) do
            local c = PB.DeepCopy(f)
            if f.type == 'secret' or f.type == 'image' then c.set = (PB.Cfg.Get(def.ns, f.k, '') or '') ~= '' end
            fields[#fields + 1] = c
        end
        return {
            type = 'form', id = def.ns .. '.' .. def.id, title = def.title, desc = def.desc, cols = def.cols or 2,
            fields = fields, values = values, restart = def.restart,
            submit = def.perm and { action = action, label = def.submitLabel or 'Enregistrer' } or nil,
            history = { ns = def.ns },
        }
    end
end

-- Historique et retour arrière ----------------------------------------------------------------------------------------
PB.Action('cfg.history', nil, function(ctx, p)
    local ns = tostring(p.ns or '')
    local perm = permByNs[ns]
    if perm and not ctx.has(perm) and not ctx.has('general.view') then return false, 'Permission refusée.' end
    local rows = PB.Cfg.History({ ns = ns, k = p.k }, 40)
    local out = {}
    for _, r in ipairs(rows) do
        out[#out + 1] = { id = r.id, key = r.k, before = r.before_v, after = r.after_v, actor = r.actor, at = r.created_at, reverted = PB.ToBool(r.reverted), reason = r.reason }
    end
    return true, out
end, { read = true })

PB.Action('cfg.revert', function(ctx, p)
    local row = PB.DB.one('SELECT ns FROM pb_cfg_history WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not row then return false end
    local perm = permByNs[row.ns]
    return perm == nil and ctx.has('general.restore') or (perm ~= nil and ctx.has(perm))
end, function(ctx, p)
    local row = PB.DB.one('SELECT * FROM pb_cfg_history WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not row then return false, 'Entrée introuvable.' end
    local ok, err = PB.Cfg.Revert(row.id, ctx.actor)
    if not ok then return false, err end
    ctx.audit('config', 'cfg.revert', row.ns .. '.' .. row.k, PB.FromJson(row.after_v), PB.FromJson(row.before_v))
    ctx.toast = 'Valeur restaurée.'
    return true
end, { critical = true, confirm = { title = 'Annuler cette modification ?', text = "L'ancienne valeur sera réappliquée.", danger = false } })

-- Formulaire lié au server.cfg ---------------------------------------------------------------------------------------------
-- def : id, title, desc, perm, fields = { {k = clé du convar, type, label, mode = 'plain'|'set'|'sets'|'setr', bool = 'truefalse'|'onoff'|'01',
--       optional (ligne retirée si vide), secret...} }, restart (texte)
function Form.Srv(def)
    PB.Perm.Register(def.perm, def.permLabel or ('Modifier : ' .. def.title), 'general')
    local action = 'srv.' .. def.id
    local function boolText(f, v)
        if f.bool == 'onoff' then return v and 'on' or 'off' end
        if f.bool == '01' then return v and '1' or '0' end
        return v and 'true' or 'false'
    end
    PB.Action(action, def.perm, function(ctx, p)
        local fields = {}
        for _, f in ipairs(def.fields) do fields[#fields + 1] = f end
        local clean, err = PB.Validate(fields, p.values)
        if not clean then return false, err end
        local ops = {}
        for _, f in ipairs(def.fields) do
            local v = clean[f.k]
            if f.type == 'secret' then
                if v ~= nil and v ~= '' then ops[#ops + 1] = { op = 'set', key = f.k, value = v, mode = f.mode or 'set' } end
            elseif v ~= nil then
                if f.type == 'toggle' then v = boolText(f, v) end
                if (v == '' or v == nil) and f.optional then ops[#ops + 1] = { op = 'remove', key = f.k, skipMissing = true }
                elseif v ~= '' then ops[#ops + 1] = { op = 'set', key = f.k, value = tostring(v), mode = f.mode or 'set' } end
            end
        end
        -- les suppressions de lignes absentes sont ignorées
        local view = PB.Files.CfgView()
        if not view then return false, select(2, PB.Files.CfgView()) or 'server.cfg illisible.' end
        local present = {}
        for _, c in ipairs(view.convars) do present[c.key:lower()] = true end
        local final = {}
        for _, o in ipairs(ops) do
            if o.op == 'remove' then if present[o.key:lower()] then final[#final + 1] = o end else final[#final + 1] = o end
        end
        local ok, e, info = PB.Files.CfgApply(final, ctx.actor, def.title)
        if not ok then return false, e end
        if info and info.unchanged then ctx.toast = 'Aucun changement.' ctx.refresh = false return true end
        ctx.audited = true
        local liveDone = false
        if def.live then
            for _, o in ipairs(final) do
                if o.op == 'set' and o.mode == 'sets' and SetConvarServerInfo then pcall(SetConvarServerInfo, o.key, o.value) liveDone = true
                elseif o.op == 'set' and o.mode == 'plain' and SetConvar then pcall(SetConvar, o.key, o.value) liveDone = true end
            end
        end
        ctx.toast = 'server.cfg mis à jour.' .. (liveDone and ' Appliqué en direct (la liste FiveM se met à jour à la prochaine annonce du serveur).' or (def.restart and (' ' .. def.restart) or ''))
        return true
    end)

    return function(ctx)
        local view, err = PB.Files.CfgView()
        if not view then return PB.B.unsupported(def.title, (err or 'server.cfg illisible') .. ' — ces réglages ne sont pas modifiables ici.') end
        local byKey = {}
        for _, c in ipairs(view.convars) do byKey[c.key:lower()] = c end
        local fields, values = {}, {}
        for _, f in ipairs(def.fields) do
            local g = PB.DeepCopy(f)
            local c = byKey[f.k:lower()]
            if f.type == 'secret' then
                g.set = c ~= nil and c.value ~= ''
                values[f.k] = ''
            else
                local v = c and c.value or nil
                if v == nil then values[f.k] = f.default
                elseif f.type == 'toggle' then values[f.k] = (v == '1' or v:lower() == 'true' or v:lower() == 'on' or v:lower() == 'yes')
                elseif f.type == 'number' or f.type == 'range' then values[f.k] = tonumber(v) or f.default
                else values[f.k] = v end
            end
            fields[#fields + 1] = g
        end
        return {
            type = 'form', id = 'srv.' .. def.id, title = def.title, desc = def.desc, cols = def.cols or 2, fields = fields, values = values,
            restart = def.restart, source = 'server.cfg',
            submit = { action = action, label = 'Enregistrer dans le server.cfg' },
        }
    end
end


-- Détail d'une entrée du journal (avant / après) ------------------------------------------------------------------------------
local AUDIT_VIEW = { grade = 'grades.view', permission = 'grades.view' }
PB.Action('audit.detail', function(ctx, p)
    local row = PB.DB.one('SELECT cat FROM pb_audit WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not row then return false end
    return ctx.has(AUDIT_VIEW[row.cat] or 'logs.view') or ctx.has('logs.view')
end, function(ctx, p)
    local r = PB.DB.one('SELECT * FROM pb_audit WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not r then return false, 'Entrée introuvable.' end
    return true, { id = r.id, cat = r.cat, action = r.action, actor = r.actor, target = r.target, at = r.created_at,
        before = PB.FromJson(r.before_v, r.before_v), after = PB.FromJson(r.after_v, r.after_v), data = PB.FromJson(r.data, r.data) }
end, { read = true })
