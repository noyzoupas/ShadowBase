-- Mises à jour de Shadow Base : le serveur lit régulièrement un fichier latest.json publié gratuitement (GitHub Pages / Releases),
-- vérifie sa signature Ed25519 (même clé publique que les licences : une fausse mise à jour est refusée), et prévient les administrateurs
-- (console, notification du panel, module « Mises à jour » avec les patch notes et le lien de téléchargement). Rien n'est installé tout seul.
--
-- latest.json : { "v":1, "version":"1.2.0", "date":"2026-10-20", "title":"…", "notes":["…"], "download":"https://…zip", "sha256":"…", "site":"https://…", "sig":"<hex>" }
-- Signature sur :  WBUPD1|version|date|download|sha256   (outil : W-Base/outils/publier.py)

PB.Update = PB.Update or {}
local U = PB.Update
local E = PB.Ed25519
local RES = GetCurrentResourceName()

local P = PB.Perm
P.Register('updates.view', 'Voir les mises à jour de Shadow Base', 'panel')

local function cfg() return (Config and Config.Update) or {} end
-- adresse : convar wbase_update_url > Config.Update.url > fichier update_url.txt (écrit par l'outil de publication, livré dans le zip)
local function url()
    local c = GetConvar('wbase_update_url', '') if c ~= '' then return c end
    local u = tostring(cfg().url or '') if u ~= '' then return u end
    return (tostring(LoadResourceFile(RES, 'update_url.txt') or ''):gsub('%s+', ''))
end
U.Current = GetResourceMetadata(RES, 'version', 0) or '0.0.0'
U.Latest, U.Checked, U.Error = nil, 0, nil

local function parts(v) local a, b, c = tostring(v or ''):match('^(%d+)%.(%d+)%.(%d+)') return tonumber(a) or 0, tonumber(b) or 0, tonumber(c) or 0 end
function U.Newer(a, b)   -- a plus récente que b ?
    local a1, a2, a3 = parts(a)
    local b1, b2, b3 = parts(b)
    if a1 ~= b1 then return a1 > b1 end
    if a2 ~= b2 then return a2 > b2 end
    return a3 > b3
end

function U.Verify(doc)
    if type(doc) ~= 'table' or doc.v ~= 1 then return false, 'Fichier de mise à jour illisible.' end
    for _, k in ipairs({ 'version', 'date', 'download', 'sha256', 'sig' }) do if type(doc[k]) ~= 'string' or doc[k] == '' then return false, 'Champ manquant : ' .. k end end
    if not tostring(doc.download):match('^https://') then return false, 'Lien de téléchargement non sécurisé.' end
    local pub = E.unhex(PB.LicensePub or '')
    local sig = E.unhex(doc.sig)
    if not pub or #pub ~= 32 or not sig or #sig ~= 64 then return false, 'Signature absente.' end
    local msg = ('WBUPD1|%s|%s|%s|%s'):format(doc.version, doc.date, doc.download, doc.sha256)
    if not E.verify(sig, msg, pub) then return false, 'Signature incorrecte : mise à jour ignorée (fichier modifié ou faux).' end
    return true
end

function U.Check(cb)
    local u = url()
    if not u:match('^https://') then U.Error = 'Adresse de mise à jour non renseignée (Config.Update.url).' if cb then cb(false) end return end
    PerformHttpRequest(u .. (u:find('?', 1, true) and '&' or '?') .. 't=' .. os.time(), function(status, body)
        U.Checked = os.time()
        if status ~= 200 or not body then U.Error = 'Serveur de mises à jour injoignable (' .. tostring(status) .. ').' if cb then cb(false) end return end
        local doc = PB.FromJson(body, nil)
        local ok, why = U.Verify(doc)
        if not ok then U.Error = why PB.Warn('[mises à jour] ' .. why) if cb then cb(false) end return end
        U.Error = nil
        local was = U.Latest and U.Latest.version
        U.Latest = doc
        if U.Newer(doc.version, U.Current) and was ~= doc.version then
            print('^3============================================================^7')
            print(('^3[Shadow Base]^7 Mise à jour disponible : ^2%s^7 (installée : %s) — %s'):format(doc.version, U.Current, tostring(doc.title or '')))
            print('^3[Shadow Base]^7 Téléchargement : ' .. doc.download)
            print('^3============================================================^7')
            if PB.Notify then PB.Notify('info', 'Mise à jour Shadow Base ' .. doc.version, tostring(doc.title or 'Nouvelle version disponible.')) end
        end
        if cb then cb(true) end
    end, 'GET', '', { ['Accept'] = 'application/json' })
end

CreateThread(function()
    Wait(20000)
    while true do
        pcall(U.Check)
        Wait(math.max(1, tonumber(cfg().check_hours) or 6) * 3600 * 1000)
    end
end)

RegisterCommand('wbase_update', function(src)
    if src ~= 0 then return end
    U.Check(function(ok)
        if not ok then print('^1[Shadow Base]^7 ' .. tostring(U.Error)) return end
        if U.Newer(U.Latest.version, U.Current) then print(('^3[Shadow Base]^7 Version %s disponible (installée : %s) : %s'):format(U.Latest.version, U.Current, U.Latest.download))
        else print(('^2[Shadow Base]^7 À jour (%s).'):format(U.Current)) end
    end)
end, true)

exports('UpdateInfo', function()
    return { current = U.Current, latest = U.Latest and U.Latest.version or nil, available = U.Latest ~= nil and U.Newer(U.Latest.version, U.Current) or false }
end)

PB.Action('updates.check', 'updates.view', function(ctx)
    U.Check()
    ctx.toast = 'Vérification lancée : rouvre l\'onglet dans quelques secondes.'
    ctx.refresh = false
    return true
end, { rate = 6 })

PB.Module({
    id = 'updates', label = 'Mises à jour', icon = 'download', group = 'Système', order = 960, perm = 'updates.view', hint = 'Nouvelle version de Shadow Base',
    doc = "## Mises à jour\nShadow Base vérifie toutes les 6 heures si une nouvelle version est publiée. Le fichier est **signé** : une fausse mise à jour est refusée.\n\nPour installer : télécharge le zip, arrête le serveur, remplace les dossiers des ressources **sans écraser** `pb_panel/config.lua` ni `pb_panel/license.key`, puis redémarre. Les tables de la base se mettent à jour seules.",
    view = function()
        return { tabs = { { id = 'main', label = 'Version', icon = 'download', build = function()
            local L = U.Latest
            local avail = L ~= nil and U.Newer(L.version, U.Current)
            local blocks = {
                PB.B.stats({ { label = 'Installée', value = U.Current, icon = 'cpu' }, { label = 'Dernière publiée', value = L and L.version or '—', icon = 'download' },
                    { label = 'Vérifiée', value = U.Checked > 0 and os.date('%d/%m %H:%M', U.Checked) or 'jamais', icon = 'clock' } }),
            }
            if U.Error then blocks[#blocks + 1] = PB.B.notice('warn', U.Error) end
            if avail then
                blocks[#blocks + 1] = PB.B.notice('info', ('Version %s disponible (%s). Télécharge le zip, arrête le serveur, remplace les ressources sans écraser pb_panel/config.lua ni license.key, puis redémarre.'):format(L.version, L.date), L.title)
                blocks[#blocks + 1] = PB.B.kv('Téléchargement (gratuit)', { { 'Zip', L.download }, { 'Empreinte SHA-256', L.sha256 }, { 'Patch notes', L.site or '—' } })
                local rows = {}
                for i, n in ipairs(type(L.notes) == 'table' and L.notes or {}) do if i <= 60 then rows[#rows + 1] = { n = tostring(n):sub(1, 300) } end end
                if #rows > 0 then blocks[#blocks + 1] = PB.B.table({ id = 'notes', title = 'Nouveautés', columns = { { k = 'n', label = '' } }, rows = rows }) end
            elseif L then
                blocks[#blocks + 1] = PB.B.notice('info', 'Shadow Base est à jour.')
            end
            blocks[#blocks + 1] = PB.B.actions({ { action = 'updates.check', label = 'Vérifier maintenant', icon = 'refresh' } })
            return blocks
        end } } }
    end,
})
