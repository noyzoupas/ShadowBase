-- Journal d'audit : toute action sensible est écrite ici avec l'état avant / après.
-- Catégories : config, grade, permission, sanction, transaction, connexion, commande, ressource,
--              sql, securite, sauvegarde, automatisation, discord, erreur_lua, serveur, panel.

PB.Audit = PB.Audit or {}
local Audit = PB.Audit

PB.Migrate('002_audit', "Journal d'audit", {
    [[CREATE TABLE IF NOT EXISTS pb_audit (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, cat VARCHAR(24) NOT NULL, action VARCHAR(96) NOT NULL,
        actor VARCHAR(96) NOT NULL DEFAULT '', actor_license VARCHAR(80) NOT NULL DEFAULT '',
        target VARCHAR(120) NOT NULL DEFAULT '', before_v MEDIUMTEXT NULL, after_v MEDIUMTEXT NULL, data TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id),
        KEY idx_cat (cat), KEY idx_created (created_at))]],
})

local listeners = {}
function Audit.OnEntry(fn) listeners[#listeners + 1] = fn end

-- Identité de l'auteur d'une action (joueur, console ou système).
function PB.Actor(src)
    if src == nil or src == 0 then return { src = 0, name = 'Console', license = '' } end
    if type(src) == 'table' then return src end
    if type(src) == 'string' then return { src = 0, name = src, license = '' } end -- appel interne (jamais issu d'un client)
    local name = GetPlayerName(src) or ('ID ' .. tostring(src))
    local license = ''
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
        if id:sub(1, 8) == 'license:' then license = id break end
    end
    return { src = src, name = name, license = license }
end

local function enc(v)
    if v == nil then return nil end
    local s = PB.Json(v)
    if #s > 60000 then s = s:sub(1, 60000) end
    return s
end

-- Écrit une entrée. `before` / `after` : tables ou valeurs simples. Ne lève jamais d'erreur.
function Audit.Log(cat, action, actor, target, before, after, data)
    actor = PB.Actor(actor)
    local row = { cat = cat, action = action, actor = actor.name, license = actor.license, target = tostring(target or '') }
    local id = PB.DB.insert('INSERT INTO pb_audit (cat, action, actor, actor_license, target, before_v, after_v, data) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        { cat, action:sub(1, 96), actor.name:sub(1, 96), actor.license:sub(1, 80), row.target:sub(1, 120), enc(before) or '', enc(after) or '', enc(data) or '' })
    row.id = id row.before = before row.after = after row.data = data row.at = os.time()
    for _, fn in ipairs(listeners) do pcall(fn, row) end
    return id
end

-- Recherche paginée pour le module « Logs ».
-- filters : cat, q (texte), actor, from, to (timestamps), page, per
function Audit.Search(f)
    f = f or {}
    local where, params = {}, {}
    if f.cat and f.cat ~= '' and f.cat ~= 'all' then
        if type(f.cat) == 'table' then
            local qs = {}
            for _, c in ipairs(f.cat) do qs[#qs + 1] = '?' params[#params + 1] = c end
            where[#where + 1] = 'cat IN (' .. table.concat(qs, ',') .. ')'
        else
            where[#where + 1] = 'cat = ?' params[#params + 1] = f.cat
        end
    end
    if f.q and f.q ~= '' then
        local like = '%' .. f.q:gsub('[\\%%_]', '\\%0') .. '%'
        where[#where + 1] = '(action LIKE ? OR target LIKE ? OR actor LIKE ? OR data LIKE ?)'
        for _ = 1, 4 do params[#params + 1] = like end
    end
    if f.actor and f.actor ~= '' then where[#where + 1] = 'actor LIKE ?' params[#params + 1] = '%' .. f.actor .. '%' end
    local w = #where > 0 and (' WHERE ' .. table.concat(where, ' AND ')) or ''
    local per = PB.Clamp(PB.ToInt(f.per, 25), 1, 500)
    local page = math.max(1, PB.ToInt(f.page, 1))
    local total = tonumber(PB.DB.scalar('SELECT COUNT(*) FROM pb_audit' .. w, params)) or 0
    local p2 = PB.DeepCopy(params)
    local rows = PB.DB.q('SELECT id, cat, action, actor, target, before_v, after_v, data, created_at FROM pb_audit' .. w ..
        ' ORDER BY id DESC LIMIT ' .. per .. ' OFFSET ' .. ((page - 1) * per), p2) or {}
    return rows, total, per, page
end

function Audit.Prune(days)
    return PB.DB.exec("DELETE FROM pb_audit WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)", { days }) or 0
end
