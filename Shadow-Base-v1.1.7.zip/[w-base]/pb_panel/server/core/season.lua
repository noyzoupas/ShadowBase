-- Thèmes de fête (Halloween, Noël) : choix manuel ou automatique selon la date. Le serveur décide ; le panel et le jeu lisent le résultat.
-- Quand une fête est active, les couleurs principale et secondaire du panel et des interfaces en jeu (si l'option est cochée) prennent celles de la fête.

PB.Season = PB.Season or {}
local S = PB.Season

PB.Cfg.Define('general', { season = 'off', season_game = true, season_decor = true })

S.Presets = {
    halloween = { id = 'halloween', label = 'Halloween', theme = 'halloween', color = '#ff8a2a', color2 = '#ff8a2a', dates = 'du 15 octobre au 1er novembre' },
    noel = { id = 'noel', label = 'Noël', theme = 'noel', color = '#e5484d', color2 = '#3fae6a', dates = 'du 1er décembre au 2 janvier' },
}

-- Période automatique pour un mois / jour donnés (fonction pure, testable)
function S.AutoFor(month, day)
    month, day = tonumber(month) or 0, tonumber(day) or 0
    if (month == 10 and day >= 15) or (month == 11 and day <= 1) then return 'halloween' end
    if month == 12 or (month == 1 and day <= 2) then return 'noel' end
    return nil
end

-- Identifiant de la fête active ('halloween' | 'noel') ou nil
function S.Current(at)
    local mode = tostring(PB.Cfg.Get('general', 'season', 'off'))
    if S.Presets[mode] then return mode end
    if mode == 'auto' then
        local d = os.date('*t', at or os.time())
        return S.AutoFor(d.month, d.day)
    end
    return nil
end

-- Description de la fête active pour les interfaces (nil si aucune)
function S.Info(at)
    local id = S.Current(at)
    if not id then return nil end
    local p = S.Presets[id]
    return { id = id, label = p.label, theme = p.theme, color = p.color, color2 = p.color2,
        decor = PB.Cfg.Get('general', 'season_decor', true) ~= false, game = PB.Cfg.Get('general', 'season_game', true) ~= false }
end
