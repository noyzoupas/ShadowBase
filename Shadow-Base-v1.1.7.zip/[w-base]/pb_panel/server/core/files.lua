-- Fichiers : lecture/écriture sûres des fichiers de ressources et du server.cfg.
-- Règles : chemin contrôlé, extensions autorisées, taille limitée, validation avant écriture,
-- sauvegarde automatique (en base), vérification après écriture, audit, retour arrière.
-- Les valeurs sensibles du server.cfg ne quittent jamais le serveur (masquées).

PB.Files = PB.Files or {}
local F = PB.Files

F.MASK = '••••••••'
F.MaxSize = 2 * 1024 * 1024
F.KeepBackups = 30

PB.Migrate('003_files', 'Sauvegardes de fichiers', {
    [[CREATE TABLE IF NOT EXISTS pb_file_backups (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, resource VARCHAR(96) NOT NULL, path VARCHAR(255) NOT NULL,
        content MEDIUMTEXT NULL, checksum VARCHAR(64) NOT NULL DEFAULT '', size INT NOT NULL DEFAULT 0,
        actor VARCHAR(96) NOT NULL DEFAULT '', reason VARCHAR(160) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_file (resource, path))]],
})

local ALLOW = { lua = true, json = true, cfg = true, js = true, css = true, html = true, txt = true, md = true,
    sql = true, yml = true, yaml = true, xml = true, ini = true, conf = true }
local DENY = { '%.env', 'id_rsa', '%.pem$', '%.key$', 'secret', 'password', '^%.git', '/%.git', 'node_modules/', 'cfx_credentials' }

local function actorName(a) if type(a) == 'table' then return a.name or 'inconnu' end return tostring(a or 'système') end

-- Chemins ------------------------------------------------------------------------------------------------
function F.ResourceExists(name)
    if type(name) ~= 'string' or name == '' or #name > 96 or not name:match('^[%w_%-%.]+$') then return false end
    local st = GetResourceState(name)
    return st ~= nil and st ~= 'missing'
end

function F.CheckPath(p)
    if type(p) ~= 'string' or p == '' or #p > 255 then return nil, 'Chemin invalide.' end
    p = p:gsub('\\', '/')
    if p:find('..', 1, true) or p:sub(1, 1) == '/' or p:find(':', 1, true) or p:find('//', 1, true) or p:find('%c') then
        return nil, 'Chemin refusé.'
    end
    local ext = p:match('%.([%w]+)$')
    if not ext or not ALLOW[ext:lower()] then return nil, 'Type de fichier non autorisé (.' .. tostring(ext or '?') .. ').' end
    local low = p:lower()
    for _, pat in ipairs(DENY) do
        if low:find(pat) then return nil, 'Fichier protégé (contenu sensible).' end
    end
    return p, nil, ext:lower()
end

function F.ValidateContent(ext, content)
    if content:find('\0', 1, true) then return false, 'Le fichier contient des octets nuls.' end
    if ext == 'lua' then
        local fn, err = load(content, '=fichier', 't', {})
        if not fn then return false, 'Lua invalide : ' .. tostring(err) end
    elseif ext == 'json' then
        if PB.FromJson(content, nil) == nil and PB.Trim(content) ~= 'null' then return false, 'JSON invalide.' end
    end
    return true
end

function F.Read(res, path)
    if not F.ResourceExists(res) then return nil, 'Ressource introuvable.' end
    local p, err = F.CheckPath(path)
    if not p then return nil, err end
    local data = LoadResourceFile(res, p)
    if data == nil then return nil, 'Fichier introuvable : ' .. p end
    if #data > F.MaxSize then return nil, 'Fichier trop volumineux (' .. PB.FormatBytes(#data) .. ').' end
    return data, nil, p
end

-- Sauvegardes ---------------------------------------------------------------------------------------------
function F.Backup(res, path, content, actor, reason)
    local id = PB.DB.insert('INSERT INTO pb_file_backups (resource, path, content, checksum, size, actor, reason) VALUES (?, ?, ?, ?, ?, ?, ?)',
        { res, path, content, PB.Checksum(content), #content, actorName(actor):sub(1, 96), (reason or ''):sub(1, 160) })
    if id then
        local old = PB.DB.q('SELECT id FROM pb_file_backups WHERE resource = ? AND path = ? ORDER BY id DESC LIMIT 1000 OFFSET ' .. F.KeepBackups, { res, path }) or {}
        for _, r in ipairs(old) do PB.DB.exec('DELETE FROM pb_file_backups WHERE id = ?', { r.id }) end
    end
    return id
end

function F.Backups(res, path, limit)
    return PB.DB.q('SELECT id, resource, path, checksum, size, actor, reason, created_at FROM pb_file_backups WHERE resource = ? AND path = ? ORDER BY id DESC LIMIT ' ..
        PB.Clamp(PB.ToInt(limit, 30), 1, 200), { res, path }) or {}
end

-- Écriture d'un fichier de ressource ------------------------------------------------------------------------
function F.Write(res, path, content, actor, reason)
    if not PB.Env.saveResourceFile and not (SaveResourceFile) then return false, "Écriture de fichiers de ressource indisponible sur ce serveur." end
    if not F.ResourceExists(res) then return false, 'Ressource introuvable.' end
    local p, err, ext = F.CheckPath(path)
    if not p then return false, err end
    if type(content) ~= 'string' then return false, 'Contenu invalide.' end
    if #content > F.MaxSize then return false, 'Contenu trop volumineux.' end
    local old = LoadResourceFile(res, p)
    -- conserve les fins de ligne d'origine
    if old and old:find('\r\n', 1, true) and not content:find('\r', 1, true) then content = content:gsub('\n', '\r\n') end
    local ok, verr = F.ValidateContent(ext, content)
    if not ok then return false, verr end
    if old == content then return true, nil, { unchanged = true } end
    local backupId
    if old then
        backupId = F.Backup(res, p, old, actor, reason or 'Avant modification')
        if not backupId then return false, 'Sauvegarde impossible : écriture annulée.' end
    end
    local saved = SaveResourceFile(res, p, content, -1)
    if not saved then return false, "Écriture refusée par le serveur (droits d'accès ?)." end
    local back = LoadResourceFile(res, p)
    if back == nil or PB.Checksum(back) ~= PB.Checksum(content) then
        if old then SaveResourceFile(res, p, old, -1) end
        return false, "Vérification après écriture échouée : ancien contenu restauré."
    end
    PB.Audit.Log('ressource', 'fichier.ecriture', actor, res .. '/' .. p,
        { checksum = old and PB.Checksum(old) or nil, size = old and #old or 0 },
        { checksum = PB.Checksum(content), size = #content }, { backup = backupId, reason = reason })
    return true, nil, { backup = backupId, size = #content }
end

function F.Restore(backupId, actor)
    local b = PB.DB.one('SELECT * FROM pb_file_backups WHERE id = ?', { backupId })
    if not b then return false, 'Sauvegarde introuvable.' end
    if b.resource == '@server' then return F.CfgRestore(b, actor) end
    return F.Write(b.resource, b.path, b.content or '', actor, 'Restauration #' .. backupId)
end

-- Liste de fichiers : manifeste + candidats usuels (+ parcours disque si possible) ----------------------------
local META = { 'client_script', 'server_script', 'shared_script', 'file', 'ui_page', 'data_file' }
local COMMON = { 'config.lua', 'shared/config.lua', 'config/config.lua', 'config/shared.lua', 'config/server.lua', 'config/client.lua',
    'configs/config.lua', 'shared/items.lua', 'shared/jobs.lua', 'shared/gangs.lua', 'shared/vehicles.lua', 'shared/weapons.lua',
    'data/items.lua', 'data/weapons.lua', 'data/shops.lua', 'data/vehicles.lua', 'data/stashes.lua', 'config.json', 'locales/fr.lua', 'locales/en.lua',
    'fxmanifest.lua', '__resource.lua', 'README.md' }

function F.ListFiles(res)
    if not F.ResourceExists(res) then return nil, 'Ressource introuvable.' end
    local seen, out = {}, {}
    local function add(p, how)
        if p and not seen[p] and F.CheckPath(p) then
            seen[p] = true
            out[#out + 1] = { path = p, from = how }
        end
    end
    for _, key in ipairs(META) do
        for i = 0, (GetNumResourceMetadata(res, key) or 0) - 1 do
            local v = GetResourceMetadata(res, key, i)
            if v and not v:find('[%*@]') then add(v, 'manifeste') end
        end
    end
    for _, c in ipairs(COMMON) do
        if LoadResourceFile(res, c) ~= nil then add(c, 'usuel') end
    end
    table.sort(out, function(a, b) return a.path < b.path end)
    return out
end

-- server.cfg ---------------------------------------------------------------------------------------------------
local cfgPath
local function isSensitive(key)
    local k = (key or ''):lower()
    return k == 'sv_licensekey' or k == 'rcon_password' or k == 'mysql_connection_string' or k == 'steam_webapikey'
        or k:find('password', 1, true) or k:find('secret', 1, true) or k:find('token', 1, true) or k:find('apikey', 1, true)
        or k:find('webhook', 1, true) or k:find('licensekey', 1, true) or k:find('connection_string', 1, true) or false
end
F.IsSensitiveKey = isSensitive

local function norm(p) return (p:gsub('\\', '/'):gsub('/+$', '')) end

function F.ServerCfgPath(force)
    if cfgPath and not force then return cfgPath end
    if not PB.Env.io then return nil, "Accès disque indisponible : le server.cfg ne peut pas être modifié depuis le panel." end
    local explicit = Config and Config.ServerPath or ''
    local candidates = {}
    if explicit ~= '' then
        explicit = norm(explicit)
        candidates[#candidates + 1] = explicit:match('%.cfg$') and explicit or (explicit .. '/server.cfg')
    else
        local base = GetResourcePath and GetResourcePath(GetCurrentResourceName()) or nil
        if base then
            base = norm(base)
            for _ = 1, 7 do
                candidates[#candidates + 1] = base .. '/server.cfg'
                base = base:match('^(.*)/[^/]+$')
                if not base or base == '' then break end
            end
        end
    end
    for _, c in ipairs(candidates) do
        local f = io.open(c, 'rb')
        if f then f:close() cfgPath = c return c end
    end
    return nil, "server.cfg introuvable : renseigne Config.ServerPath dans config.lua."
end

local function readServerCfg()
    local p, err = F.ServerCfgPath()
    if not p then return nil, err end
    local f = io.open(p, 'rb')
    if not f then return nil, 'Lecture impossible de ' .. p end
    local t = f:read('*a') f:close()
    if #t > F.MaxSize then return nil, 'server.cfg trop volumineux.' end
    return t
end

local function splitArgs(s)
    local args, i, n = {}, 1, #s
    while i <= n do
        local c = s:sub(i, i)
        if c:match('%s') then i = i + 1
        elseif c == '#' or s:sub(i, i + 1) == '//' then break
        elseif c == '"' then
            local j = s:find('"', i + 1, true)
            if not j then args[#args + 1] = { t = s:sub(i + 1), q = true, s = i, e = n } break end
            args[#args + 1] = { t = s:sub(i + 1, j - 1), q = true, s = i, e = j }
            i = j + 1
        else
            local j = i
            while j <= n and not s:sub(j, j):match('%s') do j = j + 1 end
            args[#args + 1] = { t = s:sub(i, j - 1), q = false, s = i, e = j - 1 }
            i = j
        end
    end
    return args
end

local SETS = { set = true, setr = true, sets = true }

-- Analyse : renvoie la liste des entrées et les lignes brutes.
local function parseCfg(text)
    local eol = text:find('\r\n', 1, true) and '\r\n' or '\n'
    local lines = {}
    for l in (text .. '\n'):gmatch('([^\n]*)\n') do lines[#lines + 1] = (l:gsub('\r$', '')) end
    if lines[#lines] == '' then lines[#lines] = nil end
    local entries = {}
    for n, line in ipairs(lines) do
        local e = { n = n, raw = line, kind = 'other' }
        local dname, dcmd = line:match('^%s*#%s*(ensure)%s+([%w_%-%.]+)%s*$')
        local d2cmd, d2name = line:match('^%s*#%s*(start)%s+([%w_%-%.]+)%s*$')
        if dname then e.kind, e.cmd, e.name, e.disabled = 'resource', 'ensure', dcmd, true
        elseif d2cmd then e.kind, e.cmd, e.name, e.disabled = 'resource', 'start', d2name, true
        else
            local args = splitArgs(line)
            if #args == 0 then e.kind = line:match('^%s*[#/]') and 'comment' or 'blank'
            else
                local cmd = args[1].t:lower()
                e.args = args
                if (cmd == 'ensure' or cmd == 'start') and args[2] then
                    e.kind, e.cmd, e.name = 'resource', cmd, args[2].t
                elseif SETS[cmd] and args[2] then
                    e.kind, e.mode, e.key = 'convar', cmd, args[2].t
                    e.vi = 3
                elseif args[2] then
                    e.kind, e.mode, e.key = 'cmd', 'plain', args[1].t
                    e.vi = 2
                end
                if e.vi and args[e.vi] then
                    local parts = {}
                    for i = e.vi, #args do parts[#parts + 1] = args[i].t end
                    e.value = table.concat(parts, ' ')
                    e.vs, e.ve = args[e.vi].s, args[#args].e
                elseif e.vi then e.value = '' end
                e.sensitive = e.key and isSensitive(e.key) or false
            end
        end
        entries[#entries + 1] = e
    end
    return entries, lines, eol
end

local function join(lines, eol) return table.concat(lines, eol) .. eol end

local function quote(v)
    v = tostring(v)
    if v ~= '' and v:match('^[%w_%.:/%-%+@]+$') then return v end
    return '"' .. v .. '"'
end

local function checkKey(k) return type(k) == 'string' and k:match('^[%w_%.:%-]+$') and #k <= 96 end
local function checkVal(v)
    if v:find('[%c;"]') then return false, 'Valeur refusée : les caractères ; " et les sauts de ligne sont interdits dans le server.cfg.' end
    return true
end

function F.IsProtectedResource(name)
    return name == GetCurrentResourceName() or name == 'oxmysql'
end

-- Vue pour l'interface : valeurs sensibles masquées.
function F.CfgView()
    local text, err = readServerCfg()
    if not text then return nil, err end
    local entries = parseCfg(text)
    local conv, res, other = {}, {}, {}
    for _, e in ipairs(entries) do
        if e.kind == 'convar' or e.kind == 'cmd' then
            conv[#conv + 1] = { n = e.n, key = e.key, mode = e.mode, value = e.sensitive and (e.value ~= '' and F.MASK or '') or e.value, sensitive = e.sensitive, kind = e.kind, raw = (not e.sensitive) and e.raw or nil }
        elseif e.kind == 'resource' then
            res[#res + 1] = { n = e.n, name = e.name, cmd = e.cmd, enabled = not e.disabled, state = GetResourceState(e.name), protected = F.IsProtectedResource(e.name) }
        end
    end
    return { path = cfgPath, checksum = PB.Checksum(text), convars = conv, resources = res, lines = #entries }
end

function F.CfgRawMasked()
    local text, err = readServerCfg()
    if not text then return nil, err end
    local entries, lines, eol = parseCfg(text)
    for _, e in ipairs(entries) do
        if e.sensitive and e.vs and e.value ~= '' then
            lines[e.n] = e.raw:sub(1, e.vs - 1) .. F.MASK .. e.raw:sub(e.ve + 1)
        end
    end
    return join(lines, eol), nil, PB.Checksum(text)
end

local function applyOp(text, op)
    local entries, lines, eol = parseCfg(text)
    local desc = { op = op.op }
    if op.op == 'set' then
        if not checkKey(op.key) then return nil, 'Clé invalide.' end
        local value = op.value
        if type(value) == 'boolean' then value = value and 'true' or 'false' end
        value = tostring(value == nil and '' or value)
        local okv, verr = checkVal(value)
        if not okv then return nil, verr end
        local want = op.mode
        local found
        for _, e in ipairs(entries) do
            if (e.kind == 'convar' or e.kind == 'cmd') and e.key and e.key:lower() == op.key:lower() and (not want or e.mode == want or (want ~= 'plain' and SETS[e.mode])) then found = e break end
        end
        desc.key = op.key
        if found then
            if found.sensitive and value == F.MASK then return text, nil, nil end
            desc.before = found.sensitive and F.MASK or found.value
            desc.after = found.sensitive and F.MASK or value
            if found.value == value then return text, nil, nil end
            if found.vs then
                lines[found.n] = found.raw:sub(1, found.vs - 1) .. quote(value) .. found.raw:sub(found.ve + 1)
            else
                lines[found.n] = found.raw:gsub('%s+$', '') .. ' ' .. quote(value)
            end
        else
            if isSensitive(op.key) and value == F.MASK then return nil, 'Valeur manquante pour ' .. op.key end
            local m = want or 'set'
            lines[#lines + 1] = (m == 'plain') and (op.key .. ' ' .. quote(value)) or (m .. ' ' .. op.key .. ' ' .. quote(value))
            desc.after = isSensitive(op.key) and F.MASK or value
        end
    elseif op.op == 'ensure' then
        local name = op.name
        if type(name) ~= 'string' or not name:match('^[%w_%-%.]+$') then return nil, 'Nom de ressource invalide.' end
        local enable = op.enabled ~= false
        if not enable and F.IsProtectedResource(name) then return nil, 'Ressource protégée : ' .. name .. ' ne peut pas être désactivée depuis le panel.' end
        local found
        for _, e in ipairs(entries) do if e.kind == 'resource' and e.name == name then found = e if not e.disabled then break end end end
        desc.key = name
        desc.before = found and (found.disabled and 'désactivée' or 'activée') or 'absente'
        desc.after = enable and 'activée' or 'désactivée'
        if enable then
            if found and not found.disabled then return text, nil, nil end
            if found then lines[found.n] = found.cmd .. ' ' .. name
            else lines[#lines + 1] = 'ensure ' .. name end
        else
            if not found or found.disabled then return text, nil, nil end
            lines[found.n] = '# ' .. found.raw:gsub('^%s+', '')
        end
    elseif op.op == 'move' then
        local list = {}
        for _, e in ipairs(entries) do if e.kind == 'resource' and not e.disabled then list[#list + 1] = e end end
        local idx
        for i, e in ipairs(list) do if e.name == op.name then idx = i break end end
        if not idx then return nil, 'Ressource introuvable dans le server.cfg : ' .. tostring(op.name) end
        local j = idx + (op.dir == -1 and -1 or 1)
        if j < 1 or j > #list then return text, nil, nil end
        lines[list[idx].n], lines[list[j].n] = lines[list[j].n], lines[list[idx].n]
        desc.key = op.name desc.after = (op.dir == -1) and 'monte' or 'descend'
    elseif op.op == 'append' then
        -- ajout d'une ligne de commande autorisée (ACE, principals...)
        local line = PB.Trim(tostring(op.line or ''))
        local cmd = line:match('^(%S+)')
        local allowed = { add_ace = 3, add_principal = 2, remove_ace = 3, remove_principal = 2 }
        if not cmd or not allowed[cmd] then return nil, 'Commande non autorisée dans cette opération.' end
        if line:find('[%c;"#]') then return nil, 'Caractères interdits dans la ligne.' end
        local n = 0
        for _ in line:gmatch('%S+') do n = n + 1 end
        if n ~= allowed[cmd] + 1 then return nil, 'Nombre de paramètres incorrect.' end
        for w in line:gmatch('%S+') do if not w:match('^[%w_%.:%-%*]+$') then return nil, 'Paramètre invalide : ' .. w end end
        for _, e in ipairs(entries) do if PB.Trim(e.raw) == line then return text, nil, nil end end
        lines[#lines + 1] = line
        desc.key = cmd desc.after = line
    elseif op.op == 'removeline' then
        local e = entries[PB.ToInt(op.n, 0)]
        if not e or PB.Trim(e.raw) ~= PB.Trim(tostring(op.expect or '')) then return nil, 'La ligne a changé : recharge la page.' end
        if e.kind == 'resource' or e.sensitive then return nil, 'Ligne protégée.' end
        table.remove(lines, e.n)
        desc.key = tostring(op.n) desc.before = PB.Trim(e.raw)
    elseif op.op == 'remove' then
        local found
        for _, e in ipairs(entries) do
            if (e.kind == 'convar' or e.kind == 'cmd') and e.key == op.key and (op.n == nil or e.n == op.n) then found = e break end
        end
        if not found then return nil, 'Ligne introuvable : ' .. tostring(op.key) end
        table.remove(lines, found.n)
        desc.key = op.key desc.before = found.sensitive and F.MASK or found.value
    else
        return nil, 'Opération inconnue.'
    end
    return join(lines, eol), nil, desc
end

local function writeServerCfg(newText, oldText, actor, reason, descs)
    if oldText == newText then return true, nil, { unchanged = true } end
    if newText:find('%z') then return false, 'Contenu invalide.' end
    -- le panel lui-même doit rester actif
    local entries = parseCfg(newText)
    local alive = false
    for _, e in ipairs(entries) do if e.kind == 'resource' and e.name == GetCurrentResourceName() and not e.disabled then alive = true end end
    if not alive then return false, 'Refusé : ' .. GetCurrentResourceName() .. ' doit rester démarré dans le server.cfg.' end
    local backup = F.Backup('@server', 'server.cfg', oldText, actor, reason or 'Avant modification')
    if not backup then return false, 'Sauvegarde impossible : écriture annulée.' end
    local f, err = io.open(cfgPath, 'wb')
    if not f then return false, "Écriture impossible : " .. tostring(err) end
    f:write(newText) f:close()
    local back = readServerCfg()
    if back ~= newText then
        local r = io.open(cfgPath, 'wb') if r then r:write(oldText) r:close() end
        return false, "Vérification après écriture échouée : ancien server.cfg restauré."
    end
    local masked = {}
    for _, d in ipairs(descs or {}) do masked[#masked + 1] = d end
    PB.Audit.Log('config', 'server.cfg', actor, 'server.cfg', nil, nil, { backup = backup, changes = masked, reason = reason })
    return true, nil, { backup = backup }
end

-- Applique une liste d'opérations ; tout ou rien.
function F.CfgApply(ops, actor, reason)
    local old, err = readServerCfg()
    if not old then return false, err end
    local text, descs = old, {}
    for _, op in ipairs(ops or {}) do
        local nt, e, d = applyOp(text, op)
        if not nt then return false, e end
        text = nt
        if d then descs[#descs + 1] = d end
    end
    return writeServerCfg(text, old, actor, reason, descs)
end

-- Édition brute (valeurs sensibles masquées, restaurées à l'enregistrement).
function F.CfgWriteRaw(masked, actor, reason)
    if type(masked) ~= 'string' or #masked > F.MaxSize then return false, 'Contenu invalide.' end
    local old, err = readServerCfg()
    if not old then return false, err end
    local oldEntries = parseCfg(old)
    local originals = {}
    for _, e in ipairs(oldEntries) do if e.sensitive and e.key then originals[e.key:lower()] = e.value end end
    local entries, lines, eol = parseCfg((masked:gsub('\r\n', '\n')))
    for _, e in ipairs(entries) do
        if e.sensitive and e.vs and e.value == F.MASK then
            local orig = originals[e.key:lower()]
            if not orig then return false, 'Valeur masquée sans original pour ' .. e.key .. ' : saisis la vraie valeur.' end
            lines[e.n] = e.raw:sub(1, e.vs - 1) .. quote(orig) .. e.raw:sub(e.ve + 1)
        end
    end
    local oldEol = old:find('\r\n', 1, true) and '\r\n' or '\n'
    return writeServerCfg(join(lines, oldEol), old, actor, reason or 'Édition brute', { { op = 'raw' } })
end

function F.CfgRestore(backupRow, actor)
    local old, err = readServerCfg()
    if not old then return false, err end
    return writeServerCfg(backupRow.content or '', old, actor, 'Restauration #' .. backupRow.id, { { op = 'restore', key = tostring(backupRow.id) } })
end

-- Vue masquée d'une sauvegarde de server.cfg.
function F.MaskBackup(content)
    local entries, lines, eol = parseCfg(content or '')
    for _, e in ipairs(entries) do
        if e.sensitive and e.vs and e.value ~= '' then lines[e.n] = e.raw:sub(1, e.vs - 1) .. F.MASK .. e.raw:sub(e.ve + 1) end
    end
    return join(lines, eol)
end

function F.Caps()
    local p = F.ServerCfgPath()
    return PB.Capsify({
        { 'Lire / écrire les fichiers de ressource', (SaveResourceFile and 'ok' or 'off'), SaveResourceFile and nil or 'SaveResourceFile indisponible.' },
        { 'Modifier le server.cfg', p and 'ok' or 'off', p and nil or (PB.Env.io and 'server.cfg introuvable : renseigne Config.ServerPath.' or 'Accès disque indisponible.') },
        { 'Lister tous les fichiers d\'une ressource', 'partial', "Fichiers du manifeste et fichiers usuels uniquement (pas de parcours disque)." },
        { 'Sauvegarde avant chaque écriture', 'ok', 'Stockée en base, 30 versions par fichier.' },
    })
end
