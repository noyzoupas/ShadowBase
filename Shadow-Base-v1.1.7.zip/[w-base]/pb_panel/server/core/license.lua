-- Licence de Shadow Base : signature Ed25519 vérifiée au démarrage et régulièrement. Sans licence valide, la ressource se coupe d'elle-même.
-- La clé publique est dans license_pub.lua ; la clé privée n'est JAMAIS dans cette ressource (elle reste chez toi, avec l'outil de délivrance).
-- Format d'une licence :  WB1.<charge utile JSON en hexadécimal>.<signature Ed25519 en hexadécimal>
-- Limite à connaître : un code Lua lisible peut être modifié par quelqu'un qui a les fichiers. La licence décourage le partage et
-- permet de révoquer ; une vraie protection demande en plus l'escrow Cfx.re (assets chiffrés) ou un code non fourni.

PB = PB or {}
PB.License = PB.License or {}
local L = PB.License
local E = PB.Ed25519
local RES = GetCurrentResourceName()

L.Locked = true
L.Reason = 'Licence non vérifiée'
L.Info = nil

local function cfg() return (Config and Config.License) or {} end

-- Empreinte du serveur : à donner pour obtenir une licence liée à ce serveur ---------------------------------------------------------------------
function L.Fingerprint()
    local key = GetConvar('sv_licenseKey', '')
    local basis
    if key ~= '' then
        basis = 'k:' .. key
    else
        local id = PB.Trim(LoadResourceFile(RES, 'install.id') or '')
        if #id < 16 then
            id = E.hex(E.sha512(tostring(os.time()) .. ':' .. tostring(GetGameTimer()) .. ':' .. tostring(math.random(1, 2 ^ 30)) .. tostring({}))):sub(1, 32)
            SaveResourceFile(RES, 'install.id', id, -1)
        end
        basis = 'i:' .. id
    end
    return E.hex(E.sha512('wbase|' .. basis)):sub(1, 32)
end

local function pubKey() return E.unhex(PB.LicensePub or '') end

-- Vérifie une licence. Renvoie true, infos  ou  false, raison.
function L.Check(token, now)
    token = PB.Trim(tostring(token or ''))
    local pay, sig = token:match('^WB1%.(%x+)%.(%x+)$')
    if not pay then return false, 'Format de licence invalide.' end
    local pub = pubKey()
    if not pub or #pub ~= 32 then return false, 'Clé publique de licence absente ou invalide (license_pub.lua).' end
    local sigb = E.unhex(sig)
    if not sigb or #sigb ~= 64 then return false, 'Signature de licence invalide.' end
    if not E.verify(sigb, 'WB1.' .. pay, pub) then return false, 'Signature de licence incorrecte : licence falsifiée ou délivrée avec une autre clé.' end
    local info = PB.FromJson(E.unhex(pay) or '', nil)
    if type(info) ~= 'table' or info.v ~= 1 then return false, 'Contenu de licence illisible.' end
    if type(info.id) ~= 'string' or info.id == '' then return false, 'Licence sans identifiant.' end
    if info.fp ~= '*' and info.fp ~= L.Fingerprint() then return false, 'Cette licence est liée à un autre serveur (empreinte différente).' end
    now = now or os.time()
    local exp = tonumber(info.exp) or 0
    if exp > 0 and now >= exp then return false, 'Licence expirée le ' .. os.date('%d/%m/%Y', exp) .. '.' end
    if L.revoked and L.revoked[info.id] then return false, 'Licence révoquée.' end
    return true, { id = info.id, customer = tostring(info.cust or ''), fp = info.fp, exp = exp, max = tonumber(info.max) or 0,
        feat = type(info.feat) == 'table' and info.feat or {}, iat = tonumber(info.iat) or 0 }
end

local function readToken()
    local c = PB.Trim(GetConvar('wbase_license', ''))
    if c ~= '' then return c, 'convar wbase_license' end
    local f = PB.Trim(LoadResourceFile(RES, 'license.key') or '')
    if f ~= '' then return f, 'license.key' end
    return nil
end

function L.Has(feature)
    if L.Locked or not L.Info then return false end
    if #L.Info.feat == 0 then return true end    -- licence sans liste de fonctions : tout est inclus
    for _, f in ipairs(L.Info.feat) do if f == feature or f == 'all' then return true end end
    return false
end

local function banner(reason)
    print('^1============================================================^7')
    print('^1[Shadow Base] LICENCE INVALIDE — le panel est verrouillé.^7')
    print('^1[Shadow Base] ' .. tostring(reason) .. '^7')
    print('^3[Shadow Base] Empreinte de ce serveur : ^7' .. L.Fingerprint())
    print('^3[Shadow Base] Donne cette empreinte pour obtenir ta licence, puis :^7')
    print('^3[Shadow Base]   - soit mets-la dans le fichier license.key (à la racine de la ressource)^7')
    print('^3[Shadow Base]   - soit ajoute dans server.cfg :  set wbase_license "WB1...."^7')
    print('^1============================================================^7')
end

local function kickAll(reason)
    for _, p in ipairs(GetPlayers()) do
        if not (PB.Perm and PB.Perm.IsOwner and PB.Perm.IsOwner(tonumber(p))) then
            if PB.Drop then PB.Drop(tonumber(p), 'kick', 'licence', 'Shadow Base : ' .. reason, 'Licence du serveur verrouillée : ' .. tostring(reason)) else DropPlayer(tonumber(p) or p, 'Shadow Base : ' .. reason) end
        end
    end
end

function L.Lock(reason, kick)
    L.Locked, L.Reason, L.Info = true, reason, nil
    banner(reason)
    if kick then kickAll(reason) end
    -- La ressource reste en vie en « mode verrouillé » : seuls les propriétaires peuvent se connecter et activer une licence (module Licence).
end

-- Vérification au chargement ---------------------------------------------------------------------------------------------------------------------
do
    local token, from = readToken()
    if not token then
        L.Reason = 'Aucune licence trouvée.'
        L.Lock(L.Reason)
    else
        local ok, info = L.Check(token)
        if ok then
            L.Locked, L.Reason, L.Info, L.Source = false, 'Licence valide', info, from
            print(('^2[Shadow Base]^7 Licence valide — %s (%s)%s'):format(info.customer ~= '' and info.customer or info.id, info.id, info.exp > 0 and (' · expire le ' .. os.date('%d/%m/%Y', info.exp)) or ' · sans expiration'))
        else
            L.Lock(info)
        end
    end
end

-- Révocation (optionnelle) : fichier signé hébergé chez toi, { "at": …, "ids": ["…"], "sig": "…" } -----------------------------------------------
function L.ApplyRevocation(doc)
    if type(doc) ~= 'table' or type(doc.ids) ~= 'table' or type(doc.sig) ~= 'string' then return false, 'Liste de révocation illisible.' end
    local ids = {}
    for _, v in ipairs(doc.ids) do ids[#ids + 1] = tostring(v) end
    table.sort(ids)
    local msg = 'WBREV1.' .. tostring(math.floor(tonumber(doc.at) or 0)) .. '.' .. table.concat(ids, ',')
    local sigb, pub = E.unhex(doc.sig), pubKey()
    if not sigb or not pub or not E.verify(sigb, msg, pub) then return false, 'Signature de la liste de révocation incorrecte.' end
    local set = {}
    for _, v in ipairs(ids) do set[v] = true end
    L.revoked, L.revokedAt = set, tonumber(doc.at) or 0
    if L.Info and set[L.Info.id] then L.Lock('Licence révoquée.', true) return true, 'revoked' end
    return true
end

local function fetchRevocation()
    local url = tostring(cfg().revocation_url or '')
    if not url:match('^https://') then return end
    PerformHttpRequest(url, function(status, body)
        if status ~= 200 or not body then return end
        local ok, why = L.ApplyRevocation(PB.FromJson(body, nil))
        if not ok then print('^3[Shadow Base]^7 Révocation ignorée : ' .. tostring(why)) end
    end, 'GET', '', {})
end

CreateThread(function()
    Wait(5000)
    local last = 0
    while true do
        if not L.Locked and L.Info then
            local exp = L.Info.exp
            if exp > 0 and os.time() >= exp then L.Lock('Licence expirée.', true) break end
            local every = math.max(1, tonumber(cfg().check_hours) or 6) * 3600
            if os.time() - last >= every then last = os.time() fetchRevocation() end
        end
        Wait(60000)
    end
end)

-- Limite de joueurs de la licence ------------------------------------------------------------------------------------------------------------------
AddEventHandler('playerConnecting', function()
    if L.Locked then
        local src = source
        local owner = false
        for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
            if id:sub(1, 8) == 'license:' and PB.Perm and PB.Perm.HasLicense and PB.Perm.HasLicense(id, 'license.edit') then owner = true end
        end
        if not owner then
            if PB.LogRefusal then PB.LogRefusal(src, 'licence', 'Serveur non licencié', 'Connexion refusée : licence absente ou invalide (' .. tostring(L.Reason) .. ')') end
            setKickReason('Shadow Base : serveur non licencié.') CancelEvent()
        end
        return
    end
    local max = L.Info and L.Info.max or 0
    if max > 0 and #GetPlayers() >= max then
        if PB.LogRefusal then PB.LogRefusal(source, 'licence', 'Limite de joueurs de la licence atteinte', ('%d joueurs connectés, maximum %d'):format(#GetPlayers(), max)) end
        setKickReason('Shadow Base : limite de joueurs de la licence atteinte (' .. max .. ').') CancelEvent()
    end
end)

-- Console -------------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand('wbase_licence', function(src)
    if src ~= 0 then return end
    if L.Locked then print('^1[Shadow Base]^7 ' .. tostring(L.Reason)) else
        print(('^2[Shadow Base]^7 %s — %s — %s'):format(L.Info.customer ~= '' and L.Info.customer or L.Info.id, L.Info.id, L.Info.exp > 0 and ('expire le ' .. os.date('%d/%m/%Y', L.Info.exp)) or 'sans expiration'))
    end
    print('^3[Shadow Base]^7 Empreinte : ' .. L.Fingerprint())
end, true)

exports('LicenseInfo', function()
    if L.Locked or not L.Info then return { valid = false, reason = L.Reason } end
    return { valid = true, id = L.Info.id, customer = L.Info.customer, exp = L.Info.exp, max = L.Info.max, feat = L.Info.feat }
end)
