-- Lecture / modification sûre de fichiers de configuration Lua (config.lua, data/items.lua, shared/jobs.lua...).
-- On repère les valeurs simples (nombres, textes, booléens) avec leur position exacte, et on ne remplace QUE ce texte :
-- commentaires, mise en forme et code restent intacts. Les expressions et fonctions sont listées comme non modifiables.

PB.LuaCfg = PB.LuaCfg or {}
local L = PB.LuaCfg

local function unescape(raw)
    local q = raw:sub(1, 1)
    local body = raw:sub(2, -2)
    if q == '[' then return raw:gsub('^%[=*%[\n?', ''):gsub('%]=*%]$', '') end
    local map = { n = '\n', t = '\t', r = '\r', ['\\'] = '\\', ['"'] = '"', ["'"] = "'", ['0'] = '\0', a = '\a', b = '\b', f = '\f', v = '\v' }
    body = body:gsub('\\(%d%d?%d?)', function(d) return string.char(math.min(255, tonumber(d))) end)
    body = body:gsub('\\(.)', function(c) return map[c] or c end)
    return body
end

local function tokenize(src)
    local toks, comments = {}, {}
    local i, n, line = 1, #src, 1
    local function push(t, s, e, v) toks[#toks + 1] = { t = t, s = s, e = e, v = v, line = line } end
    while i <= n do
        local c = src:sub(i, i)
        if c == '\n' then line = line + 1 i = i + 1
        elseif c:match('%s') then i = i + 1
        elseif src:sub(i, i + 1) == '--' then
            local eq = src:match('^%-%-%[(=*)%[', i)
            if eq then
                local close = ']' .. eq .. ']'
                local _, k = src:find(close, i, true)
                k = k or n
                local text = src:sub(i, k)
                comments[#comments + 1] = { line = line, text = PB.Trim(text:gsub('^%-%-%[=*%[', ''):gsub('%]=*%]$', '')), pos = i }
                for _ in text:gmatch('\n') do line = line + 1 end
                i = k + 1
            else
                local e = src:find('\n', i, true) or (n + 1)
                comments[#comments + 1] = { line = line, text = PB.Trim(src:sub(i + 2, e - 1)), pos = i }
                i = e
            end
        elseif c == '"' or c == "'" then
            local j = i + 1
            while j <= n do
                local d = src:sub(j, j)
                if d == '\\' then j = j + 2
                elseif d == c or d == '\n' then break
                else j = j + 1 end
            end
            local raw = src:sub(i, j)
            push('string', i, j, unescape(raw))
            toks[#toks].raw = raw
            i = j + 1
        elseif c == '[' and src:match('^%[=*%[', i) then
            local eq = src:match('^%[(=*)%[', i)
            local close = ']' .. eq .. ']'
            local _, k = src:find(close, i, true)
            k = k or n
            local raw = src:sub(i, k)
            push('string', i, k, unescape(raw))
            toks[#toks].raw = raw toks[#toks].long = true
            for _ in raw:gmatch('\n') do line = line + 1 end
            i = k + 1
        elseif c:match('[%a_]') then
            local w = src:match('^[%w_]+', i)
            push('name', i, i + #w - 1, w)
            i = i + #w
        elseif c:match('%d') or (c == '.' and src:sub(i + 1, i + 1):match('%d')) then
            local w = src:match('^0[xX]%x+', i) or src:match('^%d*%.?%d+[eE][%+%-]?%d+', i) or src:match('^%d+%.?%d*', i) or src:match('^%.%d+', i)
            push('number', i, i + #w - 1, tonumber(w))
            toks[#toks].raw = w
            i = i + #w
        else
            local three = src:sub(i, i + 2)
            local two = src:sub(i, i + 1)
            local op = (three == '...') and three or ((two == '==' or two == '~=' or two == '<=' or two == '>=' or two == '..' or two == '::' or two == '//' or two == '<<' or two == '>>') and two or c)
            push('op', i, i + #op - 1, op)
            i = i + #op
        end
    end
    push('eof', n + 1, n + 1, '<eof>')
    return toks, comments
end

local VEC = { vec2 = true, vec3 = true, vec4 = true, vector2 = true, vector3 = true, vector4 = true }
local BLOCK_OPEN = { ['function'] = true, ['if'] = true, ['do'] = true, ['for'] = true, ['while'] = true, ['repeat'] = true }

-- Parse -----------------------------------------------------------------------------------------------
-- Renvoie la liste des instructions d'affectation de premier niveau : { path=, node=, start=, stop= }
function L.Parse(src)
    local toks, comments = tokenize(src)
    local p = 1
    local function cur() return toks[p] end
    local function isOp(v) return toks[p].t == 'op' and toks[p].v == v end

    local parseValue

    -- Consomme une expression non modifiable jusqu'à ',' ';' '}' de premier niveau.
    local function skipExpr()
        local startTok = toks[p]
        local depth, blocks = 0, 0
        local last = startTok
        while toks[p].t ~= 'eof' do
            local t = toks[p]
            if t.t == 'op' and (t.v == '(' or t.v == '{' or t.v == '[') then depth = depth + 1
            elseif t.t == 'op' and (t.v == ')' or t.v == '}' or t.v == ']') then
                if depth == 0 then break end
                depth = depth - 1
            elseif t.t == 'op' and (t.v == ',' or t.v == ';') and depth == 0 and blocks == 0 then break
            elseif t.t == 'name' and BLOCK_OPEN[t.v] then if not (t.v == 'do' and false) then blocks = blocks + 1 end
            elseif t.t == 'name' and t.v == 'end' then blocks = blocks - 1
            elseif t.t == 'name' and t.v == 'until' then blocks = blocks - 1 end
            last = t
            p = p + 1
            if blocks == 0 and depth == 0 then
                -- une expression simple se termine à la fin de la ligne si le jeton suivant n'est pas un opérateur
                local nx = toks[p]
                if nx.t == 'eof' then break end
                if nx.line > t.line and not (nx.t == 'op' and (nx.v == '.' or nx.v == ':' or nx.v == '(' or nx.v == '+' or nx.v == '-' or nx.v == '*' or nx.v == '/' or nx.v == '..' or nx.v == '==' or nx.v == '[')) and not (t.t == 'op' and t.v ~= ')' and t.v ~= ']' and t.v ~= '}') and not (nx.t == 'name' and (nx.v == 'and' or nx.v == 'or')) and not (t.t == 'name' and (t.v == 'and' or t.v == 'or' or t.v == 'not')) then break end
            end
        end
        return { kind = 'expr', start = startTok.s, stop = last.e }
    end

    local function parseTable()
        local open = toks[p]
        p = p + 1
        local node = { kind = 'table', start = open.s, entries = {}, line = open.line }
        local idx = 0
        while not isOp('}') and cur().t ~= 'eof' do
            local e = { start = cur().s, line = cur().line }
            local t1, t2, t3 = toks[p], toks[p + 1], toks[p + 2]
            if t1.t == 'name' and t2.t == 'op' and t2.v == '=' and not (t3.t == 'op' and t3.v == '=') then
                e.key = t1.v e.keyKind = 'name'
                p = p + 2
                e.node = parseValue()
            elseif t1.t == 'op' and t1.v == '[' and (t2.t == 'string' or t2.t == 'number') and toks[p + 2].t == 'op' and toks[p + 2].v == ']' and toks[p + 3].t == 'op' and toks[p + 3].v == '=' then
                e.key = t2.t == 'string' and t2.v or tostring(t2.v) e.keyKind = t2.t == 'string' and 'bracket' or 'index'
                e.keyRaw = t2.raw
                p = p + 4
                e.node = parseValue()
            else
                idx = idx + 1
                e.key = idx e.keyKind = 'pos'
                e.node = parseValue()
            end
            e.stop = e.node.stop
            -- virgule / point-virgule de fin d'entrée
            if (isOp(',') or isOp(';')) then e.comma = cur().e p = p + 1 end
            node.entries[#node.entries + 1] = e
        end
        local close = cur()
        node.stop = close.e
        node.closeStart = close.s
        if isOp('}') then p = p + 1 end
        return node
    end

    function parseValue()
        local t = cur()
        if t.t == 'op' and t.v == '{' then return parseTable() end
        local neg = false
        local startTok = t
        if t.t == 'op' and t.v == '-' and toks[p + 1].t == 'number' then neg = true p = p + 1 t = cur() end
        -- vec2/vec3/vec4/vector3... avec arguments numériques
        if t.t == 'name' and VEC[t.v] and toks[p + 1].t == 'op' and toks[p + 1].v == '(' then
            local q, vals, okv = p + 2, {}, true
            while true do
                local a = toks[q]
                local sign = 1
                if a.t == 'op' and a.v == '-' then sign = -1 q = q + 1 a = toks[q] end
                if a.t ~= 'number' then okv = false break end
                vals[#vals + 1] = sign * a.v
                q = q + 1
                local sep = toks[q]
                if sep.t == 'op' and sep.v == ',' then q = q + 1
                elseif sep.t == 'op' and sep.v == ')' then break
                else okv = false break end
            end
            if okv and #vals >= 2 and #vals <= 4 then
                local after = toks[q + 1]
                local endsHere = (after.t == 'op' and (after.v == ',' or after.v == ';' or after.v == '}')) or after.t == 'eof' or after.line > toks[q].line
                if endsHere then
                    local names = { 'x', 'y', 'z', 'w' }
                    local v = {}
                    for i2, n2 in ipairs(vals) do v[names[i2]] = n2 end
                    local node = { kind = 'vec', value = v, fn = t.v, count = #vals, start = t.s, stop = toks[q].e, raw = src:sub(t.s, toks[q].e) }
                    p = q + 1
                    return node
                end
            end
        end
        local nx = toks[p + 1]
        local simpleEnd = (nx.t == 'op' and (nx.v == ',' or nx.v == ';' or nx.v == '}')) or nx.t == 'eof' or (nx.line > t.line and not (nx.t == 'op' and (nx.v == '..' or nx.v == '+' or nx.v == '-' or nx.v == '*' or nx.v == '/' or nx.v == '.' or nx.v == '(' or nx.v == '[' or nx.v == '==')) and not (nx.t == 'name' and (nx.v == 'and' or nx.v == 'or')))
        if simpleEnd then
            if t.t == 'number' then p = p + 1 return { kind = 'number', value = neg and -t.v or t.v, start = startTok.s, stop = t.e, raw = (neg and '-' or '') .. t.raw } end
            if t.t == 'string' then p = p + 1 return { kind = 'string', value = t.v, start = t.s, stop = t.e, raw = t.raw } end
            if t.t == 'name' and (t.v == 'true' or t.v == 'false') then p = p + 1 return { kind = 'boolean', value = t.v == 'true', start = t.s, stop = t.e, raw = t.v } end
            if t.t == 'name' and t.v == 'nil' then p = p + 1 return { kind = 'nil', start = t.s, stop = t.e, raw = 'nil' } end
        end
        if neg then p = p - 1 end
        return skipExpr()
    end

    local stmts = {}
    local function skipStatement()
        local t = cur()
        if t.t == 'name' and BLOCK_OPEN[t.v] then
            local depth = 0
            while cur().t ~= 'eof' do
                local c = cur()
                if c.t == 'name' and BLOCK_OPEN[c.v] then depth = depth + 1
                elseif c.t == 'name' and (c.v == 'end' or c.v == 'until') then depth = depth - 1 end
                p = p + 1
                if depth == 0 then break end
            end
            return
        end
        local startLine, depth = t.line, 0
        repeat
            local c = cur()
            if c.t == 'op' and (c.v == '(' or c.v == '{' or c.v == '[') then depth = depth + 1
            elseif c.t == 'op' and (c.v == ')' or c.v == '}' or c.v == ']') then depth = depth - 1 end
            p = p + 1
            local nx = cur()
            if depth <= 0 and (nx.t == 'eof' or nx.line > c.line) then break end
        until cur().t == 'eof'
    end

    local guard = 0
    while cur().t ~= 'eof' do
        guard = guard + 1
        if guard > 200000 then break end
        local t = cur()
        if t.t == 'name' and t.v == 'local' then p = p + 1
        elseif t.t == 'name' and t.v == 'return' then
            p = p + 1
            local v = parseValue()
            stmts[#stmts + 1] = { path = '<return>', node = v, start = t.s, stop = v.stop }
        elseif t.t == 'name' and not BLOCK_OPEN[t.v] and t.v ~= 'end' and t.v ~= 'else' and t.v ~= 'elseif' then
            -- Nom(.Nom | ["x"])* =
            local save = p
            local path = t.v
            p = p + 1
            local ok = true
            while true do
                if isOp('.') and toks[p + 1].t == 'name' then path = path .. '.' .. toks[p + 1].v p = p + 2
                elseif isOp('[') and (toks[p + 1].t == 'string' or toks[p + 1].t == 'number') and toks[p + 2].t == 'op' and toks[p + 2].v == ']' then
                    path = path .. '.' .. tostring(toks[p + 1].v) p = p + 3
                else break end
            end
            if isOp('=') and not (toks[p + 1].t == 'op' and toks[p + 1].v == '=') then
                p = p + 1
                local v = parseValue()
                stmts[#stmts + 1] = { path = path, node = v, start = t.s, stop = v.stop }
            else
                p = save
                skipStatement()
            end
        else
            skipStatement()
        end
    end
    return stmts, comments
end

-- Aplatit les valeurs simples : { path=, kind=, value=, start=, stop=, raw=, comment=, line= }
function L.Scan(src)
    local stmts, comments = L.Parse(src)
    local byLine = {}
    for _, c in ipairs(comments) do byLine[c.line] = byLine[c.line] or c end
    local leaves, unsupported = {}, 0
    local function lineOf(pos) local _, n = src:sub(1, pos):gsub('\n', '') return n + 1 end
    local function walk(node, path)
        if node.kind == 'table' then
            for _, e in ipairs(node.entries) do
                local seg = tostring(e.key)
                walk(e.node, path .. (e.keyKind == 'pos' and ('[' .. seg .. ']') or ('.' .. seg)))
            end
        elseif node.kind == 'expr' then
            unsupported = unsupported + 1
        elseif node.kind ~= 'nil' then
            local ln = lineOf(node.start)
            local c = byLine[ln] or byLine[ln - 1]
            leaves[#leaves + 1] = { path = path, kind = node.kind, value = node.value, start = node.start, stop = node.stop, raw = node.raw, line = ln, comment = c and c.text or nil, fn = node.fn }
        end
    end
    for _, s in ipairs(stmts) do walk(s.node, s.path == '<return>' and '' or s.path) end
    return leaves, unsupported, stmts
end

local function num(n)
    if n == math.floor(n) and math.abs(n) < 1e15 then return string.format('%d', n) end
    local s = string.format('%.4f', n):gsub('0+$', ''):gsub('%.$', '')
    return s
end
L.Num = num

function L.Format(kind, value, rawHint, fn)
    if kind == 'vec' then
        local parts = { num(value.x or 0), num(value.y or 0) }
        local cnt = (fn and fn:match('(%d)$')) and tonumber(fn:match('(%d)$')) or 3
        if cnt >= 3 then parts[3] = num(value.z or 0) end
        if cnt >= 4 then parts[4] = num(value.w or 0) end
        return (fn or 'vec3') .. '(' .. table.concat(parts, ', ') .. ')'
    end
    if kind == 'boolean' then return value and 'true' or 'false' end
    if kind == 'number' then
        local n = tonumber(value)
        if n == math.floor(n) and math.abs(n) < 1e15 then return string.format('%d', n) end
        local s = string.format('%.14g', n)
        return s
    end
    local q = (rawHint and rawHint:sub(1, 1) == '"') and '"' or "'"
    local s = tostring(value):gsub('\\', '\\\\'):gsub('\n', '\\n'):gsub('\r', '\\r'):gsub('\t', '\\t')
    if q == '"' then s = s:gsub('"', '\\"') else s = s:gsub("'", "\\'") end
    return q .. s .. q
end

function L.Validate(src)
    local fn, err = load(src, '=config', 't', {})
    if not fn then return false, tostring(err) end
    return true
end

-- Remplace la valeur d'une feuille. Plusieurs remplacements : à appliquer du bas vers le haut.
function L.SetLeaf(src, leaf, newValue)
    local v = newValue
    if leaf.kind == 'vec' then
        if type(v) == 'string' then
            local a = PB.Split(v, ',')
            v = { x = tonumber(a[1]), y = tonumber(a[2]), z = tonumber(a[3]), w = tonumber(a[4]) }
        end
        if type(v) ~= 'table' or tonumber(v.x) == nil or tonumber(v.y) == nil then return nil, 'Coordonnées invalides pour ' .. leaf.path end
        local fnn = leaf.raw and leaf.raw:match('^(%a+%d)') or 'vec3'
        local text = L.Format('vec', { x = tonumber(v.x), y = tonumber(v.y), z = tonumber(v.z) or 0, w = tonumber(v.w) or 0 }, nil, fnn)
        return src:sub(1, leaf.start - 1) .. text .. src:sub(leaf.stop + 1)
    end
    if leaf.kind == 'number' then
        v = tonumber(newValue)
        if v == nil then return nil, 'Nombre attendu pour ' .. leaf.path end
    elseif leaf.kind == 'boolean' then
        v = PB.ToBool(newValue)
    else
        v = tostring(newValue)
        if leaf.raw and leaf.raw:sub(1, 1) == '[' then return nil, 'Texte long non modifiable : ' .. leaf.path end
    end
    local text = L.Format(leaf.kind, v, leaf.raw)
    return src:sub(1, leaf.start - 1) .. text .. src:sub(leaf.stop + 1)
end

-- Applique plusieurs modifications { path = newValue } d'un coup (positions recalculées une seule fois).
function L.Apply(src, changes)
    local leaves = L.Scan(src)
    local todo = {}
    for _, lf in ipairs(leaves) do
        if changes[lf.path] ~= nil then todo[#todo + 1] = lf end
    end
    if #todo ~= PB.Count(changes) then
        local found = {}
        for _, lf in ipairs(todo) do found[lf.path] = true end
        for path in pairs(changes) do if not found[path] then return nil, 'Paramètre introuvable ou non modifiable : ' .. path end end
    end
    table.sort(todo, function(a, b) return a.start > b.start end)
    local out = src
    for _, lf in ipairs(todo) do
        local r, err = L.SetLeaf(out, lf, changes[lf.path])
        if not r then return nil, err end
        out = r
    end
    local ok, err = L.Validate(out)
    if not ok then return nil, 'Le fichier obtenu ne serait plus valide : ' .. tostring(err) end
    return out
end

-- Entrées d'une table de premier niveau (ex. objets) : { key=, start=, stop=, node= }
function L.TableEntries(src, rootPath)
    local _, _, stmts = L.Scan(src)
    for _, s in ipairs(stmts) do
        local want = rootPath == '' and '<return>' or rootPath
        if s.path == want and s.node.kind == 'table' then return s.node.entries, s.node end
    end
    return nil
end

-- Retire une entrée (ligne entière si elle est seule sur sa ligne, sinon en ligne).
function L.RemoveEntry(src, e)
    local stop = e.comma or e.stop
    local lineStart = (src:sub(1, e.start - 1):match('.*()\n') or 0) + 1
    local prefix = src:sub(lineStart, e.start - 1)
    local lineEnd = src:find('\n', stop + 1, true) or (#src + 1)
    local suffix = src:sub(stop + 1, lineEnd - 1)
    if prefix:match('^%s*$') and (suffix:match('^%s*$') or suffix:match('^%s*%-%-')) then
        return src:sub(1, lineStart - 1) .. src:sub(lineEnd + 1)
    end
    local rest = src:sub(stop + 1):gsub('^[ \t]*', '', 1)
    return src:sub(1, e.start - 1) .. rest
end

local function lineIndent(src, pos)
    local ls = (src:sub(1, pos - 1):match('.*()\n') or 0) + 1
    return src:sub(ls, pos - 1):match('^[ \t]*') or ''
end

-- Ajoute du texte (une entrée complète, sans virgule finale) à la fin d'une table.
-- L'indentation suit celle du fichier (tabulations ou espaces).
local function useTabs(text, indent)
    if indent:find('\t', 1, true) then
        return (text:gsub('\n( +)', function(sp) return '\n' .. string.rep('\t', #sp // 4) end))
    end
    return text
end

function L.AppendEntry(src, tableNode, text)
    local last = tableNode.entries[#tableNode.entries]
    local base = lineIndent(src, tableNode.start)
    if not last then
        local unit = base:find('\t', 1, true) and '\t' or '    '
        local inner = base .. unit
        local body = useTabs(text, base):gsub('\n', '\n' .. inner)
        return src:sub(1, tableNode.start) .. '\n' .. inner .. body .. ',\n' .. base .. src:sub(tableNode.closeStart)
    end
    local indent = lineIndent(src, last.start)
    local insertAt = last.comma or last.stop
    local comma = last.comma and '' or ','
    local lineEnd = src:find('\n', insertAt + 1, true) or (#src + 1)
    local tail = src:sub(insertAt + 1, lineEnd - 1)
    local body = useTabs(text, indent):gsub('\n', '\n' .. indent)
    if tail:match('^%s*$') or tail:match('^%s*%-%-') then
        return src:sub(1, insertAt) .. comma .. tail .. '\n' .. indent .. body .. ',' .. src:sub(lineEnd)
    end
    return src:sub(1, insertAt) .. comma .. ' ' .. body .. ',' .. src:sub(insertAt + 1)
end

function L.QuoteKey(key) return "['" .. tostring(key):gsub('\\', '\\\\'):gsub("'", "\\'") .. "']" end

-- Retrouve une entrée par chemin de clés depuis une table racine (rootPath '' pour `return {...}`).
-- Renvoie (entrée, tableDeLEntrée|nil, tableRacine).
function L.Locate(src, rootPath, keys)
    local _, rootNode = L.TableEntries(src, rootPath)
    if not rootNode then return nil end
    local cur, entry = rootNode, nil
    for i = 1, #keys do
        local found
        for _, e in ipairs(cur.entries) do
            if tostring(e.key) == tostring(keys[i]) then found = e break end
        end
        if not found then return nil end
        entry = found
        if found.node.kind == 'table' then cur = found.node
        elseif i < #keys then return nil
        else cur = nil end
    end
    return entry, entry and entry.node.kind == 'table' and entry.node or nil, rootNode
end

-- Lit les entrées d'une table sous forme de valeurs simples : { clé = valeur, ... } et les clés non littérales.
function L.Literals(node)
    local out, complex = {}, {}
    for _, e in ipairs(node.entries or {}) do
        local n = e.node
        if n.kind == 'string' or n.kind == 'number' or n.kind == 'boolean' or n.kind == 'vec' then out[tostring(e.key)] = n.value
        else complex[tostring(e.key)] = n.kind end
    end
    return out, complex
end

-- Texte Lua pour une valeur (utilisé pour créer de nouvelles entrées).
function L.FormatValue(v)
    local t = type(v)
    if t == 'boolean' then return v and 'true' or 'false' end
    if t == 'number' then return num(v) end
    if t == 'string' then return L.Format('string', v, "'") end
    if t == 'table' and v.x ~= nil and v.y ~= nil then return L.Format('vec', v, nil, v.w ~= nil and 'vec4' or (v.z ~= nil and 'vec3' or 'vec2')) end
    return 'nil'
end
