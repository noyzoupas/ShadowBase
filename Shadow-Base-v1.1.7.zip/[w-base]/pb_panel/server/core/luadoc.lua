-- Document Lua modifiable : ouvre un fichier de données (items, shops, stashes, véhicules...), lit/modifie/ajoute/retire
-- des entrées par chemin de clés, puis enregistre via PB.Files (validation + sauvegarde + vérification).
-- Seul le texte concerné est modifié : le reste du fichier (commentaires, code, mise en forme) reste intact.

PB.LuaDoc = PB.LuaDoc or {}
local LD = PB.LuaDoc
local L = PB.LuaCfg

local Doc = {}
Doc.__index = Doc

function LD.Open(res, file, root)
    local src, err = PB.Files.Read(res, file)
    if not src then return nil, err end
    return setmetatable({ res = res, file = file, root = root or '', src = src, orig = src }, Doc)
end

function LD.FromSource(src, root)
    return setmetatable({ src = src, orig = src, root = root or '' }, Doc)
end

-- Sérialise une valeur Lua en texte (tables imbriquées indentées).
local function isIdent(k) return type(k) == 'string' and k:match('^[%a_][%w_]*$') ~= nil and not ({ ['end'] = true, ['and'] = true, ['or'] = true, ['not'] = true, ['if'] = true, ['then'] = true, ['for'] = true, ['in'] = true, ['do'] = true, ['nil'] = true, ['true'] = true, ['false'] = true, ['function'] = true, ['local'] = true, ['return'] = true, ['while'] = true, ['repeat'] = true, ['until'] = true, ['else'] = true, ['elseif'] = true, ['break'] = true, ['goto'] = true })[k] end
function LD.Serialize(v, depth, order)
    depth = depth or 0
    if type(v) ~= 'table' or (v.x ~= nil and v.y ~= nil and type(v.x) == 'number') then return L.FormatValue(v) end
    local pad, pad2 = string.rep('    ', depth), string.rep('    ', depth + 1)
    local parts = {}
    if PB.IsArray(v) and next(v) ~= nil then
        local simple = true
        for _, x in ipairs(v) do if type(x) == 'table' and not (x.x ~= nil and x.y ~= nil) then simple = false end end
        if simple and #v <= 6 then
            for _, x in ipairs(v) do parts[#parts + 1] = LD.Serialize(x, depth + 1) end
            return '{ ' .. table.concat(parts, ', ') .. ' }'
        end
        for _, x in ipairs(v) do parts[#parts + 1] = pad2 .. LD.Serialize(x, depth + 1) .. ',' end
        return '{\n' .. table.concat(parts, '\n') .. '\n' .. pad .. '}'
    end
    local keys = {}
    local seen = {}
    for _, k in ipairs(order or {}) do if v[k] ~= nil then keys[#keys + 1] = k seen[k] = true end end
    local rest = {}
    for k in pairs(v) do if not seen[k] then rest[#rest + 1] = k end end
    table.sort(rest, function(a, b) return tostring(a) < tostring(b) end)
    for _, k in ipairs(rest) do keys[#keys + 1] = k end
    if #keys == 0 then return '{}' end
    for _, k in ipairs(keys) do
        local ks = isIdent(k) and k or ((type(k) == 'number') and ('[' .. k .. ']') or L.QuoteKey(k))
        parts[#parts + 1] = pad2 .. ks .. ' = ' .. LD.Serialize(v[k], depth + 1) .. ','
    end
    return '{\n' .. table.concat(parts, '\n') .. '\n' .. pad .. '}'
end

local function rootNode(self)
    local entries, node = L.TableEntries(self.src, self.root)
    return node
end

function Doc:locate(keys)
    if #keys == 0 then return nil, rootNode(self) end
    local entry, tnode = L.Locate(self.src, self.root, keys)
    return entry, tnode
end

function Doc:list(keys)
    local entry, tnode = self:locate(keys or {})
    if not tnode then return nil end
    return tnode.entries
end

-- Valeurs simples d'une table + liste des clés « complexes » (non modifiables).
function Doc:describe(keys)
    local _, tnode = self:locate(keys or {})
    if not tnode then return nil end
    return L.Literals(tnode)
end

function Doc:get(keys)
    local entry = self:locate(keys)
    if not entry then return nil end
    local n = entry.node
    if n.kind == 'string' or n.kind == 'number' or n.kind == 'boolean' or n.kind == 'vec' then return n.value end
    return nil
end

local function keyText(tnode, key)
    local first = tnode.entries[1]
    local style = first and first.keyKind or nil
    if style == 'index' or (style == nil and type(key) == 'number') then
        if type(key) == 'number' or tostring(key):match('^%d+$') then return '[' .. tostring(key) .. ']' end
    end
    if style == 'bracket' then return L.QuoteKey(key) end
    if style == 'name' or style == nil then
        if isIdent(tostring(key)) then return tostring(key) end
    end
    if tostring(key):match('^%d+$') and style == 'index' then return '[' .. key .. ']' end
    return L.QuoteKey(key)
end
LD.KeyText = keyText

local function replace(self, a, b, text) self.src = self.src:sub(1, a - 1) .. text .. self.src:sub(b + 1) end

-- Modifie ou crée une valeur simple.
function Doc:set(keys, value)
    local entry = self:locate(keys)
    if entry then
        local n = entry.node
        if n.kind == 'table' or n.kind == 'expr' then return false, 'Valeur non modifiable (' .. (n.kind == 'table' and 'table' or 'expression') .. ') : ' .. tostring(keys[#keys]) end
        local text
        if n.kind == 'string' then
            if n.raw and n.raw:sub(1, 1) == '[' then return false, 'Texte long non modifiable.' end
            text = L.Format('string', tostring(value), n.raw)
        elseif n.kind == 'vec' then text = L.Format('vec', value, nil, n.fn)
        else text = L.FormatValue(value) end
        replace(self, n.start, n.stop, text)
        return true
    end
    local parent = {}
    for i = 1, #keys - 1 do parent[i] = keys[i] end
    local _, ptable = self:locate(parent)
    if not ptable then return false, 'Table parente introuvable pour ' .. tostring(keys[#keys]) end
    self.src = L.AppendEntry(self.src, ptable, keyText(ptable, keys[#keys]) .. ' = ' .. L.FormatValue(value))
    return true
end

function Doc:unset(keys)
    local entry = self:locate(keys)
    if not entry then return true end
    self.src = L.RemoveEntry(self.src, entry)
    return true
end

-- Ajoute une entrée à la table `keys` : clé nil = positionnelle ; value = valeur Lua (tables sérialisées).
function Doc:add(keys, key, value, order)
    local _, tnode = self:locate(keys or {})
    if not tnode then return false, 'Table introuvable.' end
    if key ~= nil then
        for _, e in ipairs(tnode.entries) do if tostring(e.key) == tostring(key) then return false, 'Existe déjà : ' .. tostring(key) end end
    end
    local text = LD.Serialize(value, 0, order)
    if key ~= nil then text = keyText(tnode, key) .. ' = ' .. text end
    self.src = L.AppendEntry(self.src, tnode, text)
    return true
end

function Doc:remove(keys) return self:unset(keys) end

-- Insère un texte brut (déjà au format Lua) à la fin d'une table.
function Doc:addRaw(keys, text)
    local _, tnode = self:locate(keys or {})
    if not tnode then return false, 'Table introuvable.' end
    self.src = L.AppendEntry(self.src, tnode, text)
    return true
end

function Doc:valid() return L.Validate(self.src) end
function Doc:changed() return self.src ~= self.orig end

function Doc:save(actor, reason)
    local ok, err = L.Validate(self.src)
    if not ok then return false, 'Le fichier obtenu ne serait plus valide : ' .. tostring(err) end
    if not self:changed() then return true, nil, { unchanged = true } end
    local w, werr, info = PB.Files.Write(self.res, self.file, self.src, actor, reason)
    if not w then return false, werr end
    self.orig = self.src
    return true, nil, info
end
