-- Comparateur de textes ligne à ligne (plus longue sous-séquence commune), avec lignes de contexte.

local function lines(s)
    local t = {}
    for l in (s .. '\n'):gmatch('([^\n]*)\n') do t[#t + 1] = (l:gsub('\r$', '')) end
    if t[#t] == '' then t[#t] = nil end
    return t
end

-- Renvoie { lines = { {t = ' '|'+'|'-'|'…', s = texte, a = n° ancien, b = n° nouveau} }, added, removed, identical }
function PB.TextDiff(a, b, context)
    context = context or 3
    local A, Bl = lines(a or ''), lines(b or '')
    local n, m = #A, #Bl
    local pre = 0
    while pre < n and pre < m and A[pre + 1] == Bl[pre + 1] do pre = pre + 1 end
    local suf = 0
    while suf < n - pre and suf < m - pre and A[n - suf] == Bl[m - suf] do suf = suf + 1 end
    local ops = {}
    for i = 1, pre do ops[#ops + 1] = { t = ' ', s = A[i], a = i, b = i } end
    local an, bn = n - pre - suf, m - pre - suf
    if an * bn <= 1000000 then
        -- table LCS
        local w = bn + 1
        local L = {}
        for i = 0, an do for j = 0, bn do L[i * w + j] = 0 end end
        for i = an - 1, 0, -1 do
            for j = bn - 1, 0, -1 do
                if A[pre + i + 1] == Bl[pre + j + 1] then L[i * w + j] = L[(i + 1) * w + j + 1] + 1
                else
                    local x, y = L[(i + 1) * w + j], L[i * w + j + 1]
                    L[i * w + j] = x >= y and x or y
                end
            end
        end
        local i, j = 0, 0
        while i < an and j < bn do
            if A[pre + i + 1] == Bl[pre + j + 1] then
                ops[#ops + 1] = { t = ' ', s = A[pre + i + 1], a = pre + i + 1, b = pre + j + 1 } i = i + 1 j = j + 1
            elseif L[(i + 1) * w + j] >= L[i * w + j + 1] then
                ops[#ops + 1] = { t = '-', s = A[pre + i + 1], a = pre + i + 1 } i = i + 1
            else
                ops[#ops + 1] = { t = '+', s = Bl[pre + j + 1], b = pre + j + 1 } j = j + 1
            end
        end
        while i < an do ops[#ops + 1] = { t = '-', s = A[pre + i + 1], a = pre + i + 1 } i = i + 1 end
        while j < bn do ops[#ops + 1] = { t = '+', s = Bl[pre + j + 1], b = pre + j + 1 } j = j + 1 end
    else
        for i = 1, an do ops[#ops + 1] = { t = '-', s = A[pre + i], a = pre + i } end
        for j = 1, bn do ops[#ops + 1] = { t = '+', s = Bl[pre + j], b = pre + j } end
    end
    for k = 1, suf do ops[#ops + 1] = { t = ' ', s = A[n - suf + k], a = n - suf + k, b = m - suf + k } end
    local added, removed = 0, 0
    for _, o in ipairs(ops) do if o.t == '+' then added = added + 1 elseif o.t == '-' then removed = removed + 1 end end
    -- n'affiche que les modifications et leur contexte
    local keep = {}
    for idx, o in ipairs(ops) do
        if o.t ~= ' ' then for k = math.max(1, idx - context), math.min(#ops, idx + context) do keep[k] = true end end
    end
    local out, gap = {}, false
    for idx, o in ipairs(ops) do
        if keep[idx] then
            if gap then out[#out + 1] = { t = '…', s = '' } gap = false end
            if #o.s > 400 then o.s = o.s:sub(1, 400) .. '…' end
            out[#out + 1] = o
        else gap = true end
        if #out > 1500 then out[#out + 1] = { t = '…', s = 'Comparaison tronquée.' } break end
    end
    return { lines = out, added = added, removed = removed, identical = added == 0 and removed == 0 }
end
