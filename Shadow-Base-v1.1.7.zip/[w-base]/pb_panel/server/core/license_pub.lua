-- Clé publique de licence (générée par wlicense.py embed). Ne contient aucun secret.
PB = PB or {}
PB.LicensePub = '594efb9f31e6e65a7f6df4c861709332072432eb2b4402bb260401a6fb993fe4'
