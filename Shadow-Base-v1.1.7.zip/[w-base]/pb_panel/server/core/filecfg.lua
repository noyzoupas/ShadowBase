-- Formulaires basés sur des FICHIERS de configuration Lua (config.lua d'une ressource, shared/*.lua d'un framework...).
-- Lecture : repère les valeurs simples avec leur position. Écriture : ne remplace que ces valeurs, valide le fichier,
-- le sauvegarde en base puis l'écrit et le relit. Les expressions et fonctions sont comptées comme « non modifiables ».

PB.FileCfg = PB.FileCfg or {}
local FC = PB.FileCfg

local cache = {}

function FC.Load(res, file)
    local src, err = PB.Files.Read(res, file)
    if not src then return nil, err end
    local key = res .. '/' .. file
    local sum = PB.Checksum(src)
    local c = cache[key]
    if c and c.checksum == sum then return c end
    local ok, leaves, unsupported = pcall(PB.LuaCfg.Scan, src)
    if not ok then return nil, "Analyse impossible de ce fichier : " .. tostring(leaves) end
    c = { src = src, checksum = sum, leaves = leaves, unsupported = unsupported, by = {} }
    for _, lf in ipairs(leaves) do
        local p = lf.path:gsub('^%.', '')
        lf.p = p
        c.by[p] = lf
    end
    cache[key] = c
    return c
end

-- Table { chemin = valeur } pratique pour les modules.
function FC.Values(res, file)
    local c, err = FC.Load(res, file)
    if not c then return nil, err end
    local out = {}
    for p, lf in pairs(c.by) do out[p] = lf.value end
    return out
end

-- Applique des modifications { chemin = valeur } : validation, sauvegarde, écriture, vérification.
function FC.Apply(res, file, changes, actor, reason)
    local c, err = FC.Load(res, file)
    if not c then return false, err end
    local map = {}
    for p, v in pairs(changes) do
        local lf = c.by[p]
        if not lf then return false, 'Paramètre introuvable dans ' .. file .. ' : ' .. p end
        if lf.value ~= v then
            local pathKey = lf.path
            map[pathKey] = v
        end
    end
    if next(map) == nil then return true, nil, { unchanged = true } end
    local out, aerr = PB.LuaCfg.Apply(c.src, map)
    if not out then return false, aerr end
    local ok, werr, info = PB.Files.Write(res, file, out, actor, reason or 'Modification depuis le panel')
    if not ok then return false, werr end
    cache[res .. '/' .. file] = nil
    return true, nil, { changed = PB.Keys(changes), backup = info and info.backup }
end

local function labelOf(path) return (path:match('([^%.%[%]]+)$') or path) end

-- Champ de formulaire déduit d'une valeur du fichier.
local function autoField(lf)
    local f = { k = lf.p, label = labelOf(lf.p), hint = lf.comment, group = lf.p:match('^(.*)%.[^%.]+$') or lf.p:match('^(.*)%[%d+%]$') or '' }
    if lf.kind == 'boolean' then f.type = 'toggle'
    elseif lf.kind == 'number' then f.type = 'number' f.int = (lf.value == math.floor(lf.value)) and nil or false f.step = (lf.value ~= math.floor(lf.value)) and 0.01 or 1
    else f.type = 'text' f.maxlen = 400 end
    return f
end

function FC.Caps(res, file)
    local c = FC.Load(res, file)
    if not c then return nil end
    return { editable = #c.leaves, unsupported = c.unsupported }
end

-- Bloc d'édition automatique d'un fichier entier (module Ressources).
function FC.AutoForm(res, file, opts)
    opts = opts or {}
    local c, err = FC.Load(res, file)
    if not c then return PB.B.notice('error', err or 'Fichier illisible.') end
    local fields, values = {}, {}
    local limit = opts.max or 600
    for i, lf in ipairs(c.leaves) do
        if i > limit then break end
        local f = autoField(lf)
        fields[#fields + 1] = f
        values[f.k] = lf.value
    end
    local notes = {}
    if #c.leaves > limit then notes[#notes + 1] = (#c.leaves - limit) .. ' autres valeurs non affichées : utilise l\'éditeur de fichier.' end
    if c.unsupported > 0 then notes[#notes + 1] = c.unsupported .. " valeur(s) calculée(s) (expressions, fonctions) : non modifiables ici, visibles dans l'éditeur de fichier." end
    if #fields == 0 then
        return PB.B.notice('warn', "Aucune valeur simple (nombre, texte, vrai/faux) trouvée dans " .. file .. ". Utilise l'éditeur de fichier.", 'Rien à afficher')
    end
    return {
        type = 'form', id = 'filecfg.' .. res .. '.' .. file, title = opts.title or file, desc = table.concat(notes, ' '), cols = 2, grouped = true,
        fields = fields, values = values,
        submit = { action = 'res.cfg.save', label = 'Enregistrer dans le fichier', payload = { res = res, file = file } },
        restartHint = res,
    }
end

PB.Action('res.cfg.save', 'resources.edit', function(ctx, p)
    local res, file = tostring(p.res or ''), tostring(p.file or '')
    local c, err = FC.Load(res, file)
    if not c then return false, err end
    local changes = {}
    for k, v in pairs(p.values or {}) do
        local lf = c.by[k]
        if lf then
            if lf.kind == 'number' then
                local n = tonumber(v)
                if n == nil then return false, k .. ' : nombre attendu.' end
                v = n
            elseif lf.kind == 'boolean' then v = PB.ToBool(v)
            else
                v = PB.Sanitize(tostring(v), 400)
                if v:find('[%c]') then return false, k .. ' : caractères de contrôle interdits.' end
            end
            if v ~= lf.value then changes[k] = v end
        end
    end
    local ok, e, info = FC.Apply(res, file, changes, ctx.actor, 'Éditeur de valeurs')
    if not ok then return false, e end
    if info and info.unchanged then ctx.toast = 'Aucun changement.' ctx.refresh = false return true end
    local before = {}
    for k in pairs(changes) do before[k] = c.by[k].value end
    ctx.audit('config', 'ressource.config', res .. '/' .. file, before, changes)
    ctx.toast = #PB.Keys(changes) .. ' valeur(s) écrite(s) dans ' .. file .. '. Redémarre la ressource pour les appliquer.'
    return true, { restartNeeded = res }
end)

-- Formulaire à champs choisis, lié à un fichier d'une ressource (ex. config du framework).
-- def : id, title, desc, res, file, perm, fields = { {path=, type=, label=, hint=, min=, max=, opts=...} }, after(changes, ctx)
function FC.Form(def)
    PB.Perm.Register(def.perm, def.permLabel or ('Modifier : ' .. def.title), def.module or def.perm:match('^[^%.]+'))
    local action = 'filecfg.' .. def.id
    -- res et file peuvent être des fonctions (framework détecté à l'exécution) ; file peut aussi être une liste de candidats
    local function resolve()
        local res = type(def.res) == 'function' and def.res() or def.res
        local file = type(def.file) == 'function' and def.file() or def.file
        if type(file) == 'table' then
            local pick
            for _, f in ipairs(file) do
                local c = res and FC.Load(res, f)
                if c then
                    for _, fd in ipairs(def.fields) do if c.by[fd.path] then pick = f break end end
                end
                if pick then break end
            end
            file = pick or file[1]
        end
        return res, file
    end
    PB.Action(action, def.perm, function(ctx, p)
        local res, file = resolve()
        if not res then return false, 'Ressource introuvable.' end
        local c, err = FC.Load(res, file)
        if not c then return false, err end
        local usable = {}
        for _, f in ipairs(def.fields) do
            if c.by[f.path] then
                local g = PB.DeepCopy(f)
                g.k = f.path
                usable[#usable + 1] = g
            end
        end
        local clean, verr = PB.Validate(usable, p.values)
        if not clean then return false, verr end
        local changes, before = {}, {}
        for k, v in pairs(clean) do
            if c.by[k].value ~= v then changes[k] = v before[k] = c.by[k].value end
        end
        if next(changes) == nil then ctx.toast = 'Aucun changement.' ctx.refresh = false return true end
        local ok, e = FC.Apply(res, file, changes, ctx.actor, def.title)
        if not ok then return false, e end
        ctx.audit('config', action, res .. '/' .. file, before, changes)
        local msg = 'Écrit dans ' .. file .. '.'
        if def.after then
            local okc, r = pcall(def.after, changes, ctx)
            if okc and type(r) == 'string' then msg = msg .. ' ' .. r
            elseif not okc then PB.Err(action .. ' : ' .. tostring(r)) end
        else
            msg = msg .. ' Redémarre ' .. res .. ' pour appliquer.'
        end
        ctx.toast = msg
        return true, { changed = PB.Keys(changes) }
    end)

    return function(ctx)
        local res, file = resolve()
        local c, err = nil, 'Ressource introuvable ou non démarrée.'
        if res and GetResourceState(res) ~= 'missing' then c, err = FC.Load(res, file) end
        if not c then
            return PB.B.unsupported(def.title, (err or 'Fichier illisible') .. " — ce réglage n'est pas modifiable ici.")
        end
        local fields, values, missing = {}, {}, {}
        for _, f in ipairs(def.fields) do
            local lf = c.by[f.path]
            local g = PB.DeepCopy(f)
            g.k = f.path
            if lf then
                fields[#fields + 1] = g
                values[f.path] = lf.value
                if not g.hint and lf.comment then g.hint = lf.comment end
            else
                missing[#missing + 1] = (f.label or f.path)
            end
        end
        if #fields == 0 then
            return PB.B.unsupported(def.title, 'Aucun de ces paramètres n\'a été trouvé dans ' .. res .. '/' .. file .. ' (version différente ?). Utilise l\'éditeur de fichier du module Ressources.')
        end
        local desc = def.desc or ''
        if #missing > 0 then desc = desc .. (desc ~= '' and ' ' or '') .. 'Non trouvés dans ' .. file .. ' (non modifiables) : ' .. table.concat(missing, ', ') .. '.' end
        return {
            type = 'form', id = 'filecfg.' .. def.id, title = def.title, desc = desc, cols = def.cols or 2, fields = fields, values = values,
            submit = { action = action, label = 'Enregistrer' }, source = res .. '/' .. file,
        }
    end
end
