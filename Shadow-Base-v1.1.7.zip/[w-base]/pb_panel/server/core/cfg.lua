-- Configuration persistante (clé/valeur par espace de noms), historique avant/après avec retour arrière,
-- secrets (jamais envoyés au client) et validation des formulaires.

PB.Cfg = PB.Cfg or {}
PB.Secret = PB.Secret or {}
local Cfg = PB.Cfg

PB.Migrate('001_cfg', 'Configuration, historique et secrets', {
    [[CREATE TABLE IF NOT EXISTS pb_kv (
        ns VARCHAR(48) NOT NULL, k VARCHAR(96) NOT NULL, v MEDIUMTEXT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_by VARCHAR(96) NOT NULL DEFAULT '',
        PRIMARY KEY (ns, k))]],
    [[CREATE TABLE IF NOT EXISTS pb_cfg_history (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, ns VARCHAR(48) NOT NULL, k VARCHAR(96) NOT NULL,
        before_v MEDIUMTEXT NULL, after_v MEDIUMTEXT NULL, actor VARCHAR(96) NOT NULL DEFAULT '',
        reason VARCHAR(160) NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reverted TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY idx_ns (ns, k))]],
    [[CREATE TABLE IF NOT EXISTS pb_secrets (
        name VARCHAR(64) NOT NULL, value TEXT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_by VARCHAR(96) NOT NULL DEFAULT '', PRIMARY KEY (name))]],
})

local defaults, cache, hooks = {}, {}, {}
local loaded = false

function Cfg.Define(ns, tbl)
    defaults[ns] = defaults[ns] or {}
    for k, v in pairs(tbl) do defaults[ns][k] = v end
end

function Cfg.OnChange(ns, fn) hooks[ns] = hooks[ns] or {} table.insert(hooks[ns], fn) end

local function load()
    cache = {}
    for _, r in ipairs(PB.DB.q('SELECT ns, k, v FROM pb_kv') or {}) do
        cache[r.ns] = cache[r.ns] or {}
        cache[r.ns][r.k] = PB.FromJson(r.v, nil)
    end
    loaded = true
end
PB.OnReady(load)
function Cfg.Reload() load() end

function Cfg.Get(ns, k, fallback)
    local v = cache[ns] and cache[ns][k]
    if v ~= nil then return v end
    local d = defaults[ns] and defaults[ns][k]
    if d ~= nil then return PB.DeepCopy(d) end
    return fallback
end

-- Vrai si la valeur a été enregistrée (et pas seulement la valeur par défaut).
function Cfg.Has(ns, k) return cache[ns] ~= nil and cache[ns][k] ~= nil end

function Cfg.All(ns)
    local out = PB.DeepCopy(defaults[ns] or {})
    for k, v in pairs(cache[ns] or {}) do out[k] = v end
    return out
end

local function fire(ns, k, new, old)
    for _, fn in ipairs(hooks[ns] or {}) do
        local ok, err = pcall(fn, k, new, old)
        if not ok then PB.Err('hook cfg ' .. ns .. ' : ' .. tostring(err)) end
    end
    TriggerEvent('pb_panel:cfgChanged', ns, k, new)
end

local function actorName(actor)
    if type(actor) == 'table' then return actor.name or actor.license or 'inconnu' end
    return tostring(actor or 'système')
end

function Cfg.Set(ns, k, v, actor, reason, silent)
    local old = Cfg.Get(ns, k)
    if PB.DeepEqual(old, v) and cache[ns] and cache[ns][k] ~= nil then return true end
    local _, err = PB.DB.upsert('pb_kv', { ns = ns, k = k, v = PB.Json(v), updated_by = actorName(actor):sub(1, 96) }, { 'ns', 'k' })
    if err then return false, 'Écriture impossible en base.' end
    cache[ns] = cache[ns] or {}
    cache[ns][k] = PB.DeepCopy(v)
    if not silent then
        PB.DB.insert('INSERT INTO pb_cfg_history (ns, k, before_v, after_v, actor, reason) VALUES (?, ?, ?, ?, ?, ?)',
            { ns, k, PB.Json(old), PB.Json(v), actorName(actor):sub(1, 96), (reason or ''):sub(1, 160) })
    end
    fire(ns, k, v, old)
    return true
end

-- Applique plusieurs clés d'un coup ; renvoie la liste des clés réellement modifiées.
function Cfg.SetMany(ns, tbl, actor, reason)
    local changed = {}
    for _, k in ipairs(PB.Keys(tbl)) do
        local before = Cfg.Get(ns, k)
        if not PB.DeepEqual(before, tbl[k]) then
            local ok, err = Cfg.Set(ns, k, tbl[k], actor, reason)
            if not ok then return nil, err end
            changed[#changed + 1] = k
        end
    end
    return changed
end

function Cfg.Delete(ns, k, actor)
    PB.DB.exec('DELETE FROM pb_kv WHERE ns = ? AND k = ?', { ns, k })
    if cache[ns] then cache[ns][k] = nil end
    fire(ns, k, nil, nil)
end

function Cfg.History(filter, limit)
    filter = filter or {}
    local where, params = {}, {}
    if filter.ns then where[#where + 1] = 'ns = ?' params[#params + 1] = filter.ns end
    if filter.k then where[#where + 1] = 'k = ?' params[#params + 1] = filter.k end
    local sql = 'SELECT id, ns, k, before_v, after_v, actor, reason, created_at, reverted FROM pb_cfg_history'
    if #where > 0 then sql = sql .. ' WHERE ' .. table.concat(where, ' AND ') end
    sql = sql .. ' ORDER BY id DESC LIMIT ' .. PB.Clamp(PB.ToInt(limit, 50), 1, 500)
    return PB.DB.q(sql, params) or {}
end

-- Retour arrière : réapplique la valeur "avant" d'une entrée d'historique.
function Cfg.Revert(id, actor)
    local row = PB.DB.one('SELECT * FROM pb_cfg_history WHERE id = ?', { id })
    if not row then return false, 'Entrée introuvable.' end
    if PB.ToBool(row.reverted) then return false, 'Déjà annulée.' end
    local before = PB.FromJson(row.before_v, nil)
    local ok, err = Cfg.Set(row.ns, row.k, before, actor, 'Retour arrière #' .. id)
    if not ok then return false, err end
    PB.DB.exec('UPDATE pb_cfg_history SET reverted = 1 WHERE id = ?', { id })
    return true
end

-- Secrets ---------------------------------------------------------------------------------------
-- Un secret peut venir d'un convar `pb_secret_<nom>` (prioritaire, non modifiable ici) ou de la base.
local secrets = {}
PB.OnReady(function()
    for _, r in ipairs(PB.DB.q('SELECT name, value FROM pb_secrets') or {}) do secrets[r.name] = r.value end
end)

function PB.Secret.Get(name)
    local c = GetConvar('pb_secret_' .. name, '')
    if c ~= '' then return c end
    local v = secrets[name]
    if v and v ~= '' then return v end
    return nil
end

function PB.Secret.Source(name)
    if GetConvar('pb_secret_' .. name, '') ~= '' then return 'convar' end
    if secrets[name] and secrets[name] ~= '' then return 'base' end
    return nil
end

function PB.Secret.Set(name, value, actor)
    if value == nil or value == '' then
        PB.DB.exec('DELETE FROM pb_secrets WHERE name = ?', { name })
        secrets[name] = nil
        return true
    end
    local _, err = PB.DB.upsert('pb_secrets', { name = name, value = value, updated_by = actorName(actor):sub(1, 96) }, { 'name' })
    if err then return false, 'Écriture impossible en base.' end
    secrets[name] = value
    return true
end

-- Valeur affichable : jamais le secret complet.
function PB.Secret.Mask(name)
    local v = PB.Secret.Get(name)
    if not v then return '' end
    if #v <= 8 then return '••••••••' end
    return '••••••••' .. v:sub(-4)
end

-- Validation de formulaires ---------------------------------------------------------------------------
-- fields : liste de { k, type, min, max, opts, maxlen, pattern, required, label }
-- Renvoie `cleaned, nil` ou `nil, "message d'erreur"`.
local function optValues(opts)
    local set = {}
    for _, o in ipairs(opts or {}) do set[type(o) == 'table' and o[1] or o] = true end
    return set
end

function PB.Validate(fields, values)
    local out = {}
    values = values or {}
    for _, f in ipairs(fields) do
        local v = values[f.k]
        local label = f.label or f.k
        local t = f.type or 'text'
        if f.readonly or f.disabled or t == 'readonly' or t == 'info' then
            -- ignoré : non modifiable
        elseif v == nil or (v == '' and t ~= 'text' and t ~= 'area' and t ~= 'secret' and t ~= 'image' and t ~= 'asset') then
            if f.required then return nil, label .. ' est obligatoire.' end
        else
            if t == 'text' or t == 'area' or t == 'secret' then
                if type(v) ~= 'string' then v = tostring(v) end
                v = PB.Sanitize(v, f.maxlen or (t == 'area' and 4000 or 160))
                if t ~= 'area' then v = PB.Trim(v) end
                if f.required and v == '' then return nil, label .. ' est obligatoire.' end
                if v ~= '' and f.pattern and not v:match(f.pattern) then return nil, label .. " n'est pas valide." end
                if f.lower then v = v:lower() end
            elseif t == 'number' or t == 'range' then
                local n = tonumber(v)
                if n == nil or n ~= n then return nil, label .. ' doit être un nombre.' end
                if f.int ~= false and (f.step == nil or f.step >= 1) then n = math.floor(n + 0.5) end
                if f.min and n < f.min then return nil, label .. ' doit être au moins ' .. f.min .. '.' end
                if f.max and n > f.max then return nil, label .. ' doit être au plus ' .. f.max .. '.' end
                v = n
            elseif t == 'toggle' then
                v = PB.ToBool(v)
            elseif t == 'select' or t == 'cards' then
                if not optValues(f.opts)[v] then return nil, label .. ' : choix inconnu.' end
            elseif t == 'multi' or t == 'tags' or t == 'list' then
                if type(v) == 'string' then v = PB.Split(v, '\n') end
                if type(v) ~= 'table' then return nil, label .. ' : liste invalide.' end
                local set = (t == 'multi') and optValues(f.opts) or nil
                local clean, seen = {}, {}
                for _, x in ipairs(v) do
                    x = PB.Trim(PB.Sanitize(tostring(x), f.maxlen or 96))
                    if x ~= '' and not seen[x] then
                        if set and not set[x] then return nil, label .. ' : valeur inconnue (' .. x .. ').' end
                        if f.pattern and not x:match(f.pattern) then return nil, label .. ' : « ' .. x .. " » n'est pas valide." end
                        seen[x] = true clean[#clean + 1] = x
                    end
                end
                if f.maxitems and #clean > f.maxitems then return nil, label .. ' : trop d\'éléments.' end
                v = clean
            elseif t == 'rows' then
                if type(v) ~= 'table' then return nil, label .. ' : tableau invalide.' end
                if #v > (f.maxitems or 60) then return nil, label .. ' : trop de lignes (' .. (f.maxitems or 60) .. ' au plus).' end
                local clean, seen = {}, {}
                for i, r in ipairs(v) do
                    if type(r) ~= 'table' then return nil, label .. ' : ligne ' .. i .. ' invalide.' end
                    local cols = {}
                    for _, c in ipairs(f.cols or {}) do cols[#cols + 1] = { k = c.k, type = c.type or 'text', label = (c.label or c.k) .. ' (ligne ' .. i .. ')', min = c.min, max = c.max, maxlen = c.maxlen or 48, pattern = c.pattern, opts = c.opts, required = c.required, lower = c.lower, int = c.int } end
                    local row, err = PB.Validate(cols, r)
                    if not row then return nil, label .. ' : ' .. err end
                    for _, c in ipairs(f.cols or {}) do if row[c.k] == nil and c.default ~= nil then row[c.k] = c.default end end
                    if f.unique then
                        local key = tostring(row[f.unique])
                        if seen[key] then return nil, label .. ' : « ' .. key .. ' » est en double.' end
                        seen[key] = true
                    end
                    clean[#clean + 1] = row
                end
                v = clean
            elseif t == 'asset' then
                if type(v) ~= 'string' then return nil, label .. ' : image invalide.' end
                if v ~= '' and not (PB.Asset and PB.Asset.Exists(v)) then return nil, label .. " : image introuvable (renvoie-la depuis ton PC)." end
            elseif t == 'image' then
                if type(v) ~= 'string' then return nil, label .. ' : image invalide.' end
                if v ~= '' then
                    if not v:match('^data:image/png;base64,[%w%+/=]+$') and not v:match('^data:image/jpeg;base64,[%w%+/=]+$') and not v:match('^data:image/webp;base64,[%w%+/=]+$') then
                        return nil, label .. ' : format accepté PNG, JPEG ou WebP.'
                    end
                    if #v > (f.maxbytes or 400000) * 1.37 then return nil, label .. ' : image trop lourde.' end
                end
            elseif t == 'color' then
                if type(v) ~= 'string' or not v:match('^#%x%x%x%x%x%x$') then return nil, label .. ' : couleur invalide.' end
                v = v:lower()
            elseif t == 'coords' then
                if type(v) ~= 'table' then return nil, label .. ' : position invalide.' end
                local x, y, z, hd = tonumber(v.x), tonumber(v.y), tonumber(v.z), tonumber(v.h) or 0
                if not x or not y or not z or x ~= x or y ~= y or z ~= z or math.abs(x) > 10000 or math.abs(y) > 10000 or math.abs(z) > 3000 then return nil, label .. ' : coordonnées hors de la carte.' end
                v = { x = PB.Round(x, 2), y = PB.Round(y, 2), z = PB.Round(z, 2), h = PB.Round(hd % 360, 2) }
            elseif t == 'time' then
                if type(v) ~= 'string' or not v:match('^%d%d:%d%d$') then return nil, label .. ' : heure invalide (HH:MM).' end
                local h, m = tonumber(v:sub(1, 2)), tonumber(v:sub(4, 5))
                if h > 23 or m > 59 then return nil, label .. ' : heure invalide.' end
            elseif t == 'json' then
                if type(v) == 'string' then
                    local d = PB.FromJson(v, nil)
                    if d == nil then return nil, label .. ' : JSON invalide.' end
                    v = d
                end
            end
            out[f.k] = v
        end
    end
    return out
end
