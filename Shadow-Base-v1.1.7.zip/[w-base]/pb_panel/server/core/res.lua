-- Ressources du serveur : liste, état, métadonnées, dépendances, démarrage / arrêt / redémarrage contrôlés.

PB.Res = PB.Res or {}
local R = PB.Res

local NEVER_STOP = { [GetCurrentResourceName()] = true, oxmysql = true, spawnmanager = false }

function R.Valid(name) return type(name) == 'string' and #name <= 96 and name:match('^[%w_%-%.]+$') ~= nil end

function R.All()
    local out = {}
    local n = GetNumResources and GetNumResources() or 0
    for i = 0, n - 1 do
        local name = GetResourceByFindIndex(i)
        if name and name ~= '' then out[#out + 1] = name end
    end
    table.sort(out)
    return out
end

function R.State(name) return GetResourceState(name) end

function R.Meta(name, key, index) return GetResourceMetadata(name, key, index or 0) end

function R.Info(name)
    local function m(k) return GetResourceMetadata(name, k, 0) end
    return {
        name = name, state = GetResourceState(name), version = m('version'), author = m('author'), description = m('description'),
        fx = m('fx_version'), game = m('game'), lua54 = m('lua54'),
        path = GetResourcePath and GetResourcePath(name) or nil,
    }
end

-- Dépendances déclarées dans le fxmanifest (les entrées /server:, /onesync... sont des exigences du serveur).
function R.Deps(name)
    local deps, reqs = {}, {}
    for i = 0, (GetNumResourceMetadata(name, 'dependency') or 0) - 1 do
        local d = GetResourceMetadata(name, 'dependency', i)
        if d then
            if d:sub(1, 1) == '/' then reqs[#reqs + 1] = d else deps[#deps + 1] = d end
        end
    end
    return deps, reqs
end

-- Catégorie = dossier [xxx] qui contient la ressource.
function R.Category(name)
    local p = GetResourcePath and GetResourcePath(name) or nil
    if not p then return 'inconnue' end
    p = p:gsub('\\', '/')
    local cat = p:match('/%[([^/%]]+)%]/[^/]+/?$')
    if not cat then
        local all = {}
        for c in p:gmatch('/%[([^/%]]+)%]') do all[#all + 1] = c end
        cat = all[#all]
    end
    return cat or 'racine'
end

function R.Protected(name) return NEVER_STOP[name] == true or name == 'oxmysql' end

-- Actions : retournent ok, erreur. Le démarrage est asynchrone (l'état se vérifie ensuite avec R.State).
function R.Do(action, name)
    if not R.Valid(name) then return false, 'Nom de ressource invalide.' end
    if GetResourceState(name) == 'missing' and action ~= 'refresh' then return false, 'Ressource introuvable : ' .. name end
    if (action == 'stop' or action == 'restart') and R.Protected(name) then return false, 'Ressource protégée : ' .. name .. ' ne peut pas être arrêtée depuis le panel.' end
    if (action == 'stop' or action == 'restart') and PB.AC and PB.AC.Expect then PB.AC.Expect(name, 30) end
    if action == 'start' then ExecuteCommand('start ' .. name)
    elseif action == 'stop' then ExecuteCommand('stop ' .. name)
    elseif action == 'restart' then ExecuteCommand('restart ' .. name)
    elseif action == 'ensure' then ExecuteCommand('ensure ' .. name)
    elseif action == 'refresh' then ExecuteCommand('refresh')
    else return false, 'Action inconnue.' end
    return true
end

-- Attend (jusqu'à `ms`) que l'état de la ressource devienne `want`.
function R.WaitState(name, want, ms)
    local waited = 0
    while waited < (ms or 4000) do
        if GetResourceState(name) == want then return true end
        Wait(100)
        waited = waited + 100
    end
    return GetResourceState(name) == want
end
