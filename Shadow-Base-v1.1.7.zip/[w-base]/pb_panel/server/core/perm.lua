-- Grades et permissions : UN SEUL système, utilisé par le panel et synchronisé avec la librairie admin.
-- Tables : pb_grades, pb_grade_perms (par grade), pb_staff (joueur -> grade), pb_staff_perms (exceptions individuelles).
-- Règle de décision : la règle la plus précise l'emporte ; à précision égale, le refus l'emporte ;
-- les exceptions individuelles passent avant les règles du grade.
-- Synchronisation : mode 'ace' (groupes group.pb_<grade>) ou mode 'export' (exports de la librairie, voir config.lua).

PB.Perm = PB.Perm or {}
local P = PB.Perm

PB.Migrate('004_perm', 'Grades, permissions et équipe', {
    [[CREATE TABLE IF NOT EXISTS pb_grades (
        name VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, color VARCHAR(7) NOT NULL DEFAULT '#dfe2e7', icon VARCHAR(24) NOT NULL DEFAULT 'shield',
        level INT NOT NULL DEFAULT 10, parent VARCHAR(32) NULL, principals TEXT NULL,
        protected TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (name))]],
    [[CREATE TABLE IF NOT EXISTS pb_grade_perms (
        grade VARCHAR(32) NOT NULL, perm VARCHAR(96) NOT NULL, allow_v TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (grade, perm))]],
    [[CREATE TABLE IF NOT EXISTS pb_staff (
        identifier VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', grade VARCHAR(32) NOT NULL,
        added_by VARCHAR(96) NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (identifier))]],
    [[CREATE TABLE IF NOT EXISTS pb_staff_perms (
        identifier VARCHAR(80) NOT NULL, perm VARCHAR(96) NOT NULL, allow_v TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (identifier, perm))]],
})

local OWNER_LEVEL = 10000
local grades, staff = {}, {}
local compiled, ownerSet, hooks = {}, {}, {}
local catalog, catalogOrder = {}, {}

-- Catalogue des permissions connues (affiché dans l'éditeur de grades) -----------------------------------------
function P.Register(perm, label, group, danger)
    if not catalog[perm] then catalogOrder[#catalogOrder + 1] = perm end
    catalog[perm] = { perm = perm, label = label or perm, group = group or perm:match('^[^%.]+') or 'autre', danger = danger and true or false }
end

function P.Catalog()
    local out = {}
    for _, p in ipairs(catalogOrder) do out[#out + 1] = catalog[p] end
    return out
end

function P.OnChange(fn) hooks[#hooks + 1] = fn end
local function fire(kind, ...)
    for _, fn in ipairs(hooks) do
        local ok, err = pcall(fn, kind, ...)
        if not ok then PB.Err('hook perm : ' .. tostring(err)) end
    end
    TriggerEvent('pb_panel:permChanged', kind)
end

-- Motifs --------------------------------------------------------------------------------------------------------
local function patOk(p) return type(p) == 'string' and #p >= 1 and #p <= 96 and p:match('^[%w_%.%*]+$') ~= nil end
local function toLua(p) return '^' .. p:gsub('[%^%$%(%)%%%.%[%]%+%-%?]', '%%%0'):gsub('%*', '.*') .. '$' end
local function spec(p) return #(p:gsub('%*', '')) end

-- Chargement ---------------------------------------------------------------------------------------------------
-- Propriétaires définis dans config.lua (relu à chaque appel : la liste est courte).
local function rebuildOwners()
    local set = {}
    for _, l in ipairs(Config.Owners or {}) do if type(l) == 'string' and l ~= '' then set[l] = true end end
    return set
end
ownerSet = setmetatable({}, { __index = function(_, k) return rebuildOwners()[k] end, __pairs = function() return pairs(rebuildOwners()) end })

local function load()
    grades, staff, compiled = {}, {}, {}
    for _, g in ipairs(PB.DB.q('SELECT name, label, color, icon, level, parent, principals, protected FROM pb_grades') or {}) do
        grades[g.name] = { name = g.name, label = g.label, color = g.color, icon = g.icon or 'shield', level = tonumber(g.level) or 0, parent = (g.parent and g.parent ~= '') and g.parent or nil,
            principals = PB.FromJson(g.principals, {}) or {}, protected = PB.ToBool(g.protected), perms = {} }
    end
    for _, r in ipairs(PB.DB.q('SELECT grade, perm, allow_v FROM pb_grade_perms') or {}) do
        if grades[r.grade] then grades[r.grade].perms[r.perm] = PB.ToBool(r.allow_v) end
    end
    for _, s in ipairs(PB.DB.q('SELECT identifier, name, grade, added_by, created_at FROM pb_staff') or {}) do
        staff[s.identifier] = { identifier = s.identifier, name = s.name, grade = s.grade, added_by = s.added_by, created_at = s.created_at, perms = {} }
    end
    for _, r in ipairs(PB.DB.q('SELECT identifier, perm, allow_v FROM pb_staff_perms') or {}) do
        if staff[r.identifier] then staff[r.identifier].perms[r.perm] = PB.ToBool(r.allow_v) end
    end
end

-- Grades fournis par défaut (créés seulement si la table est vide) -------------------------------------------------
local function seed()
    if next(grades) ~= nil then return end
    local function add(name, label, color, level, protected, perms, icon)
        PB.DB.exec('INSERT INTO pb_grades (name, label, color, icon, level, protected) VALUES (?, ?, ?, ?, ?, ?)', { name, label, color, icon or 'shield', level, protected and 1 or 0 })
        for p, a in pairs(perms) do PB.DB.exec('INSERT INTO pb_grade_perms (grade, perm, allow_v) VALUES (?, ?, ?)', { name, p, a and 1 or 0 }) end
    end
    add('owner', 'Propriétaire', '#aab0bb', 1000, true, { ['*'] = true }, 'crown')
    add('admin', 'Administrateur', '#dfe2e7', 80, false, { ['*'] = true, ['grades.*'] = false, ['database.*'] = false, ['security.*'] = false, ['backups.restore'] = false }, 'shield')
    add('manager', 'Gérant', '#5ad1ff', 60, false, { ['panel.open'] = true, ['*.view'] = true, ['general.*'] = true, ['jobs.*'] = true, ['gangs.*'] = true, ['items.*'] = true,
        ['vehicles.*'] = true, ['economy.*'] = true, ['services.*'] = true, ['mapping.*'] = true, ['world.*'] = true, ['interface.*'] = true, ['grades.*'] = false }, 'briefcase')
    add('moderator', 'Modérateur', '#7be0a4', 40, false, { ['panel.open'] = true, ['logs.view'] = true, ['general.view'] = true, ['monitor.view'] = true }, 'gavel')
    add('support', 'Support', '#ffd166', 20, false, { ['panel.open'] = true, ['logs.view'] = true }, 'help')
    load()
end

PB.OnReady(function() load() seed() P.SyncAll(true) end)
function P.Reload() load() P.SyncAll(true) end

-- Résolution -----------------------------------------------------------------------------------------------------
local function chainPerms(gname)
    local chain, seen = {}, {}
    local g = grades[gname]
    while g and not seen[g.name] do
        seen[g.name] = true
        table.insert(chain, 1, g)
        g = g.parent and grades[g.parent] or nil
    end
    local map = {}
    for _, gr in ipairs(chain) do for p, a in pairs(gr.perms) do map[p] = a end end
    return map
end

local function compile(map, bonus)
    local list = {}
    for p, a in pairs(map) do list[#list + 1] = { pat = p, allow = a, lua = toLua(p), spec = spec(p) + (bonus or 0) } end
    return list
end

local function entriesFor(license)
    local st = staff[license]
    if not st then return nil end
    local c = compiled[license]
    if c then return c end
    local list = compile(chainPerms(st.grade))
    for _, e in ipairs(compile(st.perms, 1000)) do list[#list + 1] = e end
    compiled[license] = list
    return list
end

local function decide(entries, perm)
    local best, bs = nil, -1
    for _, e in ipairs(entries) do
        if perm:match(e.lua) and (e.spec > bs or (e.spec == bs and not e.allow)) then best, bs = e.allow, e.spec end
    end
    return best
end

function P.GetLicense(src)
    if not src or src == 0 then return nil end
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
        if id:sub(1, 8) == 'license:' then return id end
    end
    return nil
end

local function isOwner(src, license)
    if license and ownerSet[license] then return true end
    if src and src ~= 0 and IsPlayerAceAllowed(tostring(src), 'pb_panel.owner') then return true end
    return false
end

function P.IsOwner(src) return src == 0 or isOwner(src, P.GetLicense(src)) end

function P.HasLicense(license, perm)
    if license and ownerSet[license] then return true end
    local e = license and entriesFor(license)
    return e ~= nil and decide(e, perm) == true
end

function P.Has(src, perm)
    if src == 0 then return true end
    if type(perm) ~= 'string' then return false end
    local lic = P.GetLicense(src)
    -- Sans licence valide : seuls les propriétaires entrent, et seulement pour ouvrir le panel et activer la licence.
    if PB.License and PB.License.Locked then
        return isOwner(src, lic) and (perm == 'panel.open' or perm:sub(1, 8) == 'license.')
    end
    if isOwner(src, lic) then return true end
    return lic ~= nil and P.HasLicense(lic, perm)
end

function P.GetGrade(src)
    local lic = P.GetLicense(src)
    if isOwner(src, lic) then return 'owner', grades.owner end
    local st = lic and staff[lic]
    if not st then return nil end
    return st.grade, grades[st.grade]
end

function P.GradeOf(license) local st = staff[license] return st and st.grade or nil end

function P.Level(src)
    if src == 0 then return OWNER_LEVEL end
    local lic = P.GetLicense(src)
    if isOwner(src, lic) then return OWNER_LEVEL end
    local st = lic and staff[lic]
    local g = st and grades[st.grade]
    return g and g.level or 0
end

function P.Effective(gname)
    local out = {}
    for p, a in pairs(chainPerms(gname)) do out[p] = a end
    return out
end

-- Lecture ----------------------------------------------------------------------------------------------------------
local function snapshot(g)
    if not g then return nil end
    return { name = g.name, label = g.label, color = g.color, icon = g.icon, level = g.level, parent = g.parent, principals = g.principals, perms = g.perms }
end

function P.Grades()
    local out = {}
    for _, g in pairs(grades) do
        local n = 0
        for _, s in pairs(staff) do if s.grade == g.name then n = n + 1 end end
        out[#out + 1] = { name = g.name, label = g.label, color = g.color, icon = g.icon, level = g.level, parent = g.parent, principals = g.principals,
            protected = g.protected, perms = g.perms, members = n }
    end
    table.sort(out, function(a, b) return a.level > b.level end)
    return out
end

function P.Grade(name) return grades[name] end

-- Joueurs connectés, indexés par TOUS leurs identifiants (license, license2, fivem, discord…) : un membre du staff
-- enregistré avec un autre identifiant que « license: » est quand même vu en ligne.
local function onlineIndex()
    local online = {}
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        for _, ident in ipairs(GetPlayerIdentifiers(src) or {}) do online[ident] = src end
    end
    return online
end
P.OnlineIndex = onlineIndex

function P.Staff()
    local online = onlineIndex()
    local out = {}
    for _, s in pairs(staff) do
        out[#out + 1] = { identifier = s.identifier, name = s.name, grade = s.grade, added_by = s.added_by, created_at = s.created_at, perms = s.perms, online = online[s.identifier] }
    end
    for l in pairs(ownerSet) do
        out[#out + 1] = { identifier = l, name = '', grade = 'owner', added_by = 'config.lua', fixed = true, online = online[l], perms = {} }
    end
    table.sort(out, function(a, b) return (grades[a.grade] and grades[a.grade].level or 0) > (grades[b.grade] and grades[b.grade].level or 0) end)
    return out
end

-- Droits d'agir ------------------------------------------------------------------------------------------------------
local function canGrant(actor, pat)
    if actor.src == 0 or isOwner(actor.src, actor.license) then return true end
    return P.Has(actor.src, pat)
end

local function wrapActor(actor)
    actor = PB.Actor(actor)
    actor.owner = actor.src == 0 or isOwner(actor.src, actor.license)
    actor.level = actor.owner and OWNER_LEVEL or P.Level(actor.src)
    return actor
end

local function validPerms(actor, perms)
    local clean = {}
    for p, a in pairs(perms or {}) do
        if not patOk(p) then return nil, 'Permission invalide : ' .. tostring(p) end
        local allow = (a == true or a == 'allow' or a == 1)
        if allow and not canGrant(actor, p) then return nil, "Tu ne peux pas accorder « " .. p .. " » : tu ne la possèdes pas toi-même." end
        clean[p] = allow
    end
    return clean
end

-- Synchronisation avec la librairie admin ---------------------------------------------------------------------------------
local appliedAce = { aces = {}, principals = {} }
local function lib() return (Config.AdminLib and Config.AdminLib.mode) or 'ace' end
local function libCall(kind, ...)
    local cfg = Config.AdminLib or {}
    if lib() ~= 'export' then return nil, 'mode' end
    local fn = cfg.exports and cfg.exports[kind]
    if not fn or fn == '' or not cfg.resource or cfg.resource == '' then return nil, 'non configuré' end
    local args = { ... }
    local ok, res = pcall(function() return exports[cfg.resource][fn](exports[cfg.resource], table.unpack(args)) end)
    if not ok then PB.Warn('librairie admin (' .. kind .. ') : ' .. tostring(res)) return nil, tostring(res) end
    return res == nil and true or res
end

local function aceNames(entries)
    -- Convertit les motifs en noms ACE ; les motifs avec * au milieu sont développés sur le catalogue.
    local out = {}
    for _, e in ipairs(entries) do
        if e.pat == '*' then out['pb_panel'] = e.allow
        elseif e.pat:sub(-2) == '.*' and not e.pat:sub(1, -3):find('*', 1, true) then out['pb_panel.' .. e.pat:sub(1, -3)] = e.allow
        elseif not e.pat:find('*', 1, true) then out['pb_panel.' .. e.pat] = e.allow
        else
            for _, c in ipairs(catalogOrder) do if c:match(e.lua) then out['pb_panel.' .. c] = e.allow end end
        end
    end
    return out
end

local function safeName(s) return type(s) == 'string' and s:match('^[%w_]+$') ~= nil end
local function safeAce(s) return type(s) == 'string' and s:match('^[%w_%.]+$') ~= nil end
local function safePrincipal(s) return type(s) == 'string' and s:match('^[%w_%.:]+$') ~= nil end

-- FiveM refuse add_ace / remove_ace à une ressource qui n'a pas le droit « command.add_ace » (« Access denied for command add_ace »).
-- On teste ce droit une fois : sans lui, on n'envoie aucune commande (plus de centaines de lignes d'erreur) et on explique quoi ajouter au server.cfg.
local aceOk, aceWarned
function P.AceAllowed()
    if aceOk ~= nil then return aceOk end
    if type(IsPrincipalAceAllowed) ~= 'function' then aceOk = true return true end
    local okc, a = pcall(IsPrincipalAceAllowed, 'resource.' .. GetCurrentResourceName(), 'command.add_ace')
    local okr, b = pcall(IsPrincipalAceAllowed, 'resource.' .. GetCurrentResourceName(), 'command.remove_ace')
    aceOk = (okc and a and okr and b) and true or false
    if not aceOk and not aceWarned then
        aceWarned = true
        PB.Warn("La ressource n'a pas le droit de gérer les ACE : synchronisation ACE ignorée (le panel fonctionne quand même, ses permissions sont internes). Pour l'activer, ajoute dans server.cfg : add_ace resource." .. GetCurrentResourceName() .. " command.add_ace allow / add_ace resource." .. GetCurrentResourceName() .. " command.remove_ace allow / add_ace resource." .. GetCurrentResourceName() .. " command.add_principal allow / add_ace resource." .. GetCurrentResourceName() .. " command.remove_principal allow  (voir server.cfg.example).")
    end
    return aceOk
end
function P.AceReset() aceOk, aceWarned = nil, nil end
function P.AceExec(line)
    if not P.AceAllowed() then return false end
    ExecuteCommand(line)
    return true
end

function P.SyncAce()
    if lib() ~= 'ace' then return false, 'mode' end
    if not P.AceAllowed() then return false, 'denied' end
    for _, a in ipairs(appliedAce.aces) do P.AceExec(('remove_ace %s %s %s'):format(a[1], a[2], a[3])) end
    for _, a in ipairs(appliedAce.principals) do P.AceExec(('remove_principal %s %s'):format(a[1], a[2])) end
    appliedAce = { aces = {}, principals = {} }
    local function ace(g, o, v)
        if safePrincipal(g) and safeAce(o) then
            P.AceExec(('add_ace %s %s %s'):format(g, o, v))
            appliedAce.aces[#appliedAce.aces + 1] = { g, o, v }
        end
    end
    local function prin(c, p)
        if safePrincipal(c) and safePrincipal(p) then
            P.AceExec(('add_principal %s %s'):format(c, p))
            appliedAce.principals[#appliedAce.principals + 1] = { c, p }
        end
    end
    for name, g in pairs(grades) do
        if safeName(name) then
            local grp = 'group.pb_' .. name
            for obj, allow in pairs(aceNames(compile(chainPerms(name)))) do ace(grp, obj, allow and 'allow' or 'deny') end
            -- 'pb_panel.owner' ne doit jamais être hérité d'un joker : seuls les propriétaires l'ont
            if name ~= 'owner' then ace(grp, 'pb_panel.owner', 'deny') end
            for _, extra in ipairs(g.principals or {}) do prin(grp, extra) end
        end
    end
    for lic, st in pairs(staff) do
        if safeName(st.grade) and lic:match('^license2?:%x+$') then prin('identifier.' .. lic, 'group.pb_' .. st.grade) end
    end
    for lic in pairs(ownerSet) do
        if lic:match('^license2?:%x+$') then prin('identifier.' .. lic, 'group.pb_owner') end
    end
    return true
end

function P.AppliedAce() return appliedAce end

function P.SyncAll(silent)
    local res = {}
    if lib() == 'ace' then
        P.SyncAce()
        res.ace = true
    elseif lib() == 'export' then
        for _, g in pairs(grades) do
            local ok = libCall('saveGrade', { name = g.name, label = g.label, priority = g.level, color = g.color, parent = g.parent, permissions = P.Effective(g.name) })
            res.pushed = (res.pushed or 0) + (ok and 1 or 0)
        end
        for lic, st in pairs(staff) do libCall('setPlayerGrade', lic, st.grade) end
    end
    if not silent then PB.Audit.Log('grade', 'sync', 0, lib(), nil, res) end
    return res
end

local function changed(kind, ...)
    compiled = {}
    local a = ...
    if kind == 'grade' or kind == 'perms' then
        if lib() == 'ace' then P.SyncAce() end
    elseif kind == 'staff' then
        if lib() == 'ace' then P.SyncAce() end
    end
    fire(kind, ...)
end

-- Écriture : grades ---------------------------------------------------------------------------------------------------------
function P.SaveGrade(actor, d)
    actor = wrapActor(actor)
    if type(d) ~= 'table' then return false, 'Données invalides.' end
    local name = type(d.name) == 'string' and d.name:lower() or ''
    if not name:match('^[a-z][a-z0-9_]+$') or #name < 2 or #name > 24 then return false, 'Identifiant du grade : 2 à 24 caractères (a-z, 0-9, _), commence par une lettre.' end
    local existing = grades[name]
    local label = PB.Trim(PB.Sanitize(tostring(d.label or name), 32))
    if label == '' then return false, 'Le nom affiché est obligatoire.' end
    local color = tostring(d.color or (existing and existing.color) or '#dfe2e7'):lower()
    if not color:match('^#%x%x%x%x%x%x$') then return false, 'Couleur invalide.' end
    local icon = tostring(d.icon or (existing and existing.icon) or 'shield')
    if not icon:match('^[%w_%-]+$') or #icon > 24 then return false, 'Icône invalide.' end
    local level = PB.ToInt(d.level, nil)
    if name == 'owner' then level = 1000
    elseif not level or level < 1 or level > 999 then return false, 'Niveau : entier entre 1 et 999.' end
    local parent = (d.parent and d.parent ~= '') and tostring(d.parent) or nil
    if name == 'owner' then
        if not actor.owner then return false, 'Seul un propriétaire peut modifier le grade propriétaire.' end
        level = 1000 parent = nil d.perms = { ['*'] = true }
    end
    if parent then
        if parent == name then return false, 'Un grade ne peut pas hériter de lui-même.' end
        if not grades[parent] then return false, 'Grade parent introuvable.' end
        local seen, cur = { [name] = true }, parent
        while cur do
            if seen[cur] then return false, "Héritage circulaire détecté." end
            seen[cur] = true
            cur = grades[cur] and grades[cur].parent or nil
        end
        if not actor.owner and grades[parent].level >= actor.level then return false, 'Tu ne peux pas hériter d\'un grade supérieur ou égal au tien.' end
    end
    if existing then
        if existing.protected and not actor.owner then return false, 'Grade protégé.' end
        if not actor.owner and existing.level >= actor.level then return false, 'Tu ne peux pas modifier un grade supérieur ou égal au tien.' end
    end
    if not actor.owner and level >= actor.level then return false, 'Le niveau doit rester inférieur au tien.' end
    local principals = {}
    for _, x in ipairs(d.principals or {}) do
        x = PB.Trim(tostring(x))
        if x ~= '' then
            if not safePrincipal(x) then return false, 'Principal ACE invalide : ' .. x end
            principals[#principals + 1] = x
        end
    end
    if #principals > 0 and not actor.owner then return false, 'Seul un propriétaire peut lier un grade à des groupes ACE.' end
    local perms, perr = validPerms(actor, d.perms or (existing and existing.perms) or {})
    if not perms then return false, perr end
    -- un grade modifié par un non-propriétaire ne peut pas retirer un refus qu'il n'a pas le droit de lever
    local before = snapshot(existing)
    local q = {
        { query = 'INSERT INTO pb_grades (name, label, color, icon, level, parent, principals, protected) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), color = VALUES(color), icon = VALUES(icon), level = VALUES(level), parent = VALUES(parent), principals = VALUES(principals)',
          values = { name, label, color, icon, level, parent or '', PB.Json(principals), (existing and existing.protected or name == 'owner') and 1 or 0 } },
        { query = 'DELETE FROM pb_grade_perms WHERE grade = ?', values = { name } },
    }
    for p, a in pairs(perms) do q[#q + 1] = { query = 'INSERT INTO pb_grade_perms (grade, perm, allow_v) VALUES (?, ?, ?)', values = { name, p, a and 1 or 0 } } end
    local ok = PB.DB.tx(q)
    if not ok then return false, "Écriture en base impossible : modification annulée." end
    load()
    local g = grades[name]
    PB.Audit.Log(existing and 'permission' or 'grade', existing and 'grade.modifier' or 'grade.creer', actor, name, before, snapshot(g))
    if lib() == 'export' then libCall('saveGrade', { name = g.name, label = g.label, priority = g.level, color = g.color, parent = g.parent, permissions = P.Effective(g.name) }) end
    changed('grade', name)
    return true, nil, g
end

function P.DeleteGrade(actor, name, moveTo)
    actor = wrapActor(actor)
    local g = grades[name]
    if not g then return false, 'Grade introuvable.' end
    if g.protected or name == 'owner' then return false, 'Ce grade est protégé.' end
    if not actor.owner and g.level >= actor.level then return false, 'Tu ne peux pas supprimer un grade supérieur ou égal au tien.' end
    for _, o in pairs(grades) do if o.parent == name then return false, 'Le grade « ' .. o.label .. ' » en hérite : change son parent d\'abord.' end end
    local members = {}
    for _, s in pairs(staff) do if s.grade == name then members[#members + 1] = s end end
    if #members > 0 then
        if not moveTo or not grades[moveTo] or moveTo == name then return false, #members .. ' membre(s) ont ce grade : choisis un grade de remplacement.' end
        if not actor.owner and grades[moveTo].level >= actor.level then return false, 'Grade de remplacement trop élevé.' end
    end
    local q = {}
    if #members > 0 then q[#q + 1] = { query = 'UPDATE pb_staff SET grade = ? WHERE grade = ?', values = { moveTo, name } } end
    q[#q + 1] = { query = 'DELETE FROM pb_grade_perms WHERE grade = ?', values = { name } }
    q[#q + 1] = { query = 'DELETE FROM pb_grades WHERE name = ?', values = { name } }
    if not PB.DB.tx(q) then return false, 'Écriture en base impossible : suppression annulée.' end
    local before = snapshot(g)
    load()
    PB.Audit.Log('grade', 'grade.supprimer', actor, name, before, nil, { moved = #members, to = moveTo })
    if lib() == 'export' then
        libCall('deleteGrade', name)
        for _, s in ipairs(members) do libCall('setPlayerGrade', s.identifier, moveTo) end
    end
    changed('grade', name)
    return true
end

-- Écriture : équipe ----------------------------------------------------------------------------------------------------------
local function licenseOk(l) return type(l) == 'string' and l:match('^license2?:%x+$') ~= nil and #l <= 80 end

function P.SetStaff(actor, license, name, gradeName)
    actor = wrapActor(actor)
    license = PB.Trim(tostring(license or '')):lower()   -- FiveM écrit les licences en minuscules : une saisie en majuscules ne serait jamais reconnue
    -- « license2: » (affiché par txAdmin) d'un joueur connecté -> sa « license: » principale, celle qui porte les permissions
    if license:match('^license2:') then
        local src = onlineIndex()[license]
        local main = src and P.GetLicense(src)
        if main then license = main end
    end
    if not licenseOk(license) then return false, 'Identifiant invalide (attendu : license:xxxxxxxx).' end
    if ownerSet[license] then return false, 'Ce joueur est propriétaire (défini dans config.lua).' end
    if actor.license == license and not actor.owner then return false, 'Tu ne peux pas modifier ton propre grade.' end
    local cur = staff[license]
    if cur and grades[cur.grade] and not actor.owner and grades[cur.grade].level >= actor.level then return false, 'Ce membre a un grade supérieur ou égal au tien.' end
    if gradeName == nil or gradeName == '' then
        if not cur then return true end
        PB.DB.tx({ { query = 'DELETE FROM pb_staff_perms WHERE identifier = ?', values = { license } }, { query = 'DELETE FROM pb_staff WHERE identifier = ?', values = { license } } })
        load()
        PB.Audit.Log('grade', 'equipe.retirer', actor, license, { grade = cur.grade, name = cur.name }, nil)
        libCall('setPlayerGrade', license, nil)
        changed('staff', license)
        return true
    end
    local g = grades[gradeName]
    if not g then return false, 'Grade introuvable.' end
    if gradeName == 'owner' and actor.src ~= 0 then return false, 'Le grade propriétaire se définit dans config.lua ou depuis la console du serveur (pb_grant).' end
    if not actor.owner and g.level >= actor.level then return false, 'Tu ne peux pas attribuer un grade supérieur ou égal au tien.' end
    name = PB.Trim(PB.Sanitize(tostring(name or (cur and cur.name) or ''), 64))
    local ok = PB.DB.exec('INSERT INTO pb_staff (identifier, name, grade, added_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), grade = VALUES(grade)',
        { license, name, gradeName, actor.name:sub(1, 96) })
    if ok == nil then return false, 'Écriture en base impossible.' end
    load()
    PB.Audit.Log('grade', cur and 'equipe.changer' or 'equipe.ajouter', actor, license, cur and { grade = cur.grade } or nil, { grade = gradeName, name = name })
    libCall('setPlayerGrade', license, gradeName)
    changed('staff', license)
    return true
end

function P.SetStaffPerms(actor, license, perms)
    actor = wrapActor(actor)
    local cur = staff[license]
    if not cur then return false, "Ce joueur n'est pas dans l'équipe." end
    if actor.license == license and not actor.owner then return false, 'Tu ne peux pas modifier tes propres exceptions.' end
    if grades[cur.grade] and not actor.owner and grades[cur.grade].level >= actor.level then return false, 'Ce membre a un grade supérieur ou égal au tien.' end
    local clean, err = validPerms(actor, perms)
    if not clean then return false, err end
    local q = { { query = 'DELETE FROM pb_staff_perms WHERE identifier = ?', values = { license } } }
    for p, a in pairs(clean) do q[#q + 1] = { query = 'INSERT INTO pb_staff_perms (identifier, perm, allow_v) VALUES (?, ?, ?)', values = { license, p, a and 1 or 0 } } end
    if not PB.DB.tx(q) then return false, 'Écriture en base impossible.' end
    local before = cur.perms
    load()
    PB.Audit.Log('permission', 'equipe.exceptions', actor, license, before, clean)
    changed('perms', license)
    return true
end

-- Renommage : met à jour toutes les références (permissions, équipe, héritage) en une transaction ------------------------------------------
function P.RenameGrade(actor, old, new)
    actor = wrapActor(actor)
    new = type(new) == 'string' and new:lower() or ''
    local g = grades[old]
    if not g then return false, 'Grade introuvable.' end
    if old == 'owner' or g.protected then return false, 'Ce grade est protégé.' end
    if not new:match('^[a-z][a-z0-9_]+$') or #new < 2 or #new > 24 then return false, 'Identifiant : 2 à 24 caractères (a-z, 0-9, _), commence par une lettre.' end
    if grades[new] then return false, 'Un grade porte déjà cet identifiant.' end
    if not actor.owner and g.level >= actor.level then return false, 'Tu ne peux pas modifier un grade supérieur ou égal au tien.' end
    local q = {
        { query = 'UPDATE pb_grades SET name = ? WHERE name = ?', values = { new, old } },
        { query = 'UPDATE pb_grades SET parent = ? WHERE parent = ?', values = { new, old } },
        { query = 'UPDATE pb_grade_perms SET grade = ? WHERE grade = ?', values = { new, old } },
        { query = 'UPDATE pb_staff SET grade = ? WHERE grade = ?', values = { new, old } },
    }
    if not PB.DB.tx(q) then return false, 'Écriture en base impossible : renommage annulé.' end
    load()
    PB.Audit.Log('grade', 'grade.renommer', actor, old, { name = old }, { name = new })
    if lib() == 'export' then
        libCall('deleteGrade', old)
        local ng = grades[new]
        libCall('saveGrade', { name = ng.name, label = ng.label, priority = ng.level, color = ng.color, parent = ng.parent, permissions = P.Effective(new) })
        for lic, st in pairs(staff) do if st.grade == new then libCall('setPlayerGrade', lic, new) end end
    end
    changed('grade', new)
    return true
end

function P.DuplicateGrade(actor, src, newName, newLabel)
    local g = grades[src]
    if not g then return false, 'Grade introuvable.' end
    if src == 'owner' then return false, 'Le grade propriétaire ne se duplique pas.' end
    local perms = {}
    for k, v in pairs(g.perms) do perms[k] = v end
    return P.SaveGrade(actor, { name = newName, label = newLabel or (g.label .. ' (copie)'), color = g.color, icon = g.icon, level = math.max(1, g.level - 1), parent = g.parent, perms = perms })
end

-- Copie les règles d'un grade vers un autre (remplace les règles du grade cible).
function P.CopyPerms(actor, from, to)
    local a, b = grades[from], grades[to]
    if not a or not b then return false, 'Grade introuvable.' end
    local perms = {}
    for k, v in pairs(a.perms) do perms[k] = v end
    if to == 'owner' then return false, 'Le grade propriétaire a toujours toutes les permissions.' end
    return P.SaveGrade(actor, { name = to, label = b.label, color = b.color, icon = b.icon, level = b.level, parent = b.parent, principals = b.principals, perms = perms })
end

-- Explique une décision : quelle règle l'emporte et d'où elle vient.
local function chainEntries(gname)
    local chain, seen = {}, {}
    local g = grades[gname]
    while g and not seen[g.name] do
        seen[g.name] = true
        table.insert(chain, 1, g)
        g = g.parent and grades[g.parent] or nil
    end
    local map = {}
    for _, gr in ipairs(chain) do for p, a in pairs(gr.perms) do map[p] = { allow = a, from = gr.name } end end
    local list = {}
    for p, e in pairs(map) do list[#list + 1] = { pat = p, allow = e.allow, lua = toLua(p), spec = spec(p), from = e.from } end
    return list
end

local function explain(entries, perm)
    local best, bs = nil, -1
    for _, e in ipairs(entries) do
        if perm:match(e.lua) and (e.spec > bs or (e.spec == bs and not e.allow)) then best, bs = e, e.spec end
    end
    if not best then return { allowed = false } end
    return { allowed = best.allow, rule = best.pat, from = best.from }
end

function P.ExplainGrade(gname, perm) return explain(chainEntries(gname), perm) end

function P.ExplainStaff(license, perm)
    if ownerSet[license] then return { allowed = true, rule = '*', from = 'propriétaire' } end
    local st = staff[license]
    if not st then return { allowed = false } end
    local list = chainEntries(st.grade)
    for p, a in pairs(st.perms) do list[#list + 1] = { pat = p, allow = a, lua = toLua(p), spec = spec(p) + 1000, from = 'personnel' } end
    return explain(list, perm)
end

-- Import depuis la librairie admin (mode export) ---------------------------------------------------------------------------------
function P.ImportFromLib(actor)
    actor = wrapActor(actor)
    if not actor.owner then return false, 'Réservé aux propriétaires.' end
    if lib() ~= 'export' then return false, "Disponible uniquement en mode 'export'." end
    local list, err = libCall('listGrades')
    if type(list) ~= 'table' then return false, 'La librairie ne renvoie pas de liste (' .. tostring(err or 'export non configuré') .. ').' end
    local n = 0
    for _, g in ipairs(list) do
        local name = tostring(g.name or ''):lower():gsub('[^a-z0-9_]', '_')
        if name:match('^[a-z][a-z0-9_]+$') and #name <= 24 and not grades[name] then
            PB.DB.exec('INSERT INTO pb_grades (name, label, color, icon, level) VALUES (?, ?, ?, ?, ?)', { name, PB.Sanitize(tostring(g.label or name), 32), '#dfe2e7', 'shield', PB.Clamp(PB.ToInt(g.priority, 10), 1, 999) })
            n = n + 1
        end
    end
    load()
    PB.Audit.Log('grade', 'grade.import', actor, Config.AdminLib.resource, nil, { imported = n })
    changed('grade')
    return true, nil, n
end

function P.Caps()
    local cfg = Config.AdminLib or {}
    local list = {}
    if lib() == 'ace' then
        list[#list + 1] = { 'Synchronisation des grades avec la librairie admin', 'ok', 'Groupes ACE group.pb_<grade> + principaux supplémentaires par grade.' }
        list[#list + 1] = { 'Import des grades existants de la librairie', 'off', "Possible uniquement en mode 'export' avec un export listGrades." }
    else
        local ex = cfg.exports or {}
        local function c(label, key, hint)
            list[#list + 1] = { label, (ex[key] and ex[key] ~= '' and cfg.resource ~= '') and 'ok' or 'off', (ex[key] and ex[key] ~= '' and cfg.resource ~= '') and nil or ('Export « ' .. key .. ' » non renseigné dans Config.AdminLib. ' .. (hint or '')) }
        end
        c('Création / modification de grades dans la librairie', 'saveGrade')
        c('Suppression de grades dans la librairie', 'deleteGrade')
        c('Attribution des grades aux joueurs', 'setPlayerGrade')
        c('Import des grades existants', 'listGrades')
        c('Liste des permissions de la librairie', 'listPermissions')
    end
    list[#list + 1] = { 'Un seul système de grades', 'ok', 'Le panel et la librairie lisent les mêmes grades (tables pb_grades / pb_staff).' }
    return PB.Capsify(list)
end

-- Exports utiles aux autres ressources
exports('HasPermission', function(src, perm) return P.Has(src, perm) end)
exports('GetPlayerGrade', function(src) local g = P.GetGrade(src) return g end)
exports('GetGradeLevel', function(src) return P.Level(src) end)
