-- Accès base de données : erreurs et lenteurs enregistrées, migrations versionnées, file d'initialisation.

PB.DB = PB.DB or {}
local DB = PB.DB

DB.Errors = {}        -- historique des erreurs SQL (mémoire, 100 dernières)
DB.Slow = {}          -- requêtes lentes observées par le panel (mémoire, 100 dernières)
DB.SlowMs = 200
DB.Stats = { queries = 0, errors = 0, totalMs = 0 }

local readyCallbacks = {}
PB.IsReady = false

function PB.OnReady(fn) readyCallbacks[#readyCallbacks + 1] = fn end

local function short(sql) return (sql:gsub('%s+', ' '):sub(1, 160)) end

local function record(sql, ms, err)
    DB.Stats.queries = DB.Stats.queries + 1
    DB.Stats.totalMs = DB.Stats.totalMs + ms
    if err then
        DB.Stats.errors = DB.Stats.errors + 1
        table.insert(DB.Errors, 1, { at = os.time(), sql = short(sql), error = tostring(err) })
        if #DB.Errors > 100 then table.remove(DB.Errors) end
        if PB.OnSqlError then pcall(PB.OnSqlError, sql, err) end
    elseif ms >= DB.SlowMs then
        table.insert(DB.Slow, 1, { at = os.time(), sql = short(sql), ms = ms })
        if #DB.Slow > 100 then table.remove(DB.Slow) end
    end
end

-- Cache mémoire des lectures fréquentes (entreprises, grades, membres, signalements, points…) : les menus ne repassent plus par la base
-- à chaque ouverture. Toute écriture qui cite une de ces tables vide son cache : la donnée lue est toujours celle de la base.
local CACHED = { pb_biz = true, pb_biz_members = true, pb_biz_grades = true, pb_reports = true, pb_places = true, pb_points = true,
    pb_tag_gang = true, pb_gang_boss = true, pb_tasks = true, pb_territories = true, pb_properties = true, pb_garages = true, pb_bank_points = true, pb_vehicles = true, pb_vehicle_keys = true }
DB.CacheTtl = 60000
local cache = {}     -- table -> { [clé] = { t, res } }
local gen, size = {}, {}   -- génération (écritures) et nombre d'entrées par table
local function tablesOf(sql)
    local out = {}
    for t in tostring(sql):lower():gmatch('pb_[%w_]+') do out[t] = true end
    return out
end
local function copy(v)
    if type(v) ~= 'table' then return v end
    local o = {}
    for k, x in pairs(v) do o[k] = copy(x) end
    return o
end
function DB.Invalidate(sql)
    if not sql then cache, size = {}, {} for t in pairs(gen) do gen[t] = gen[t] + 1 end return end
    for t in pairs(tablesOf(sql)) do cache[t] = nil size[t] = nil gen[t] = (gen[t] or 0) + 1 end
end
local function cacheKey(fnName, sql, params)
    if fnName ~= 'query' and fnName ~= 'single' and fnName ~= 'scalar' then return end
    if not tostring(sql):match('^%s*[Ss][Ee][Ll][Ee][Cc][Tt]') then return end
    local ts, first = tablesOf(sql), nil
    for t in pairs(ts) do if not CACHED[t] then return end first = first or t end
    if not first then return end
    local parts = { fnName, sql }
    for i, v in ipairs(params or {}) do parts[#parts + 1] = type(v) .. ':' .. tostring(v) end
    return ts, table.concat(parts, '\31')
end

local function run(fnName, sql, params)
    if PB.License and PB.License.Locked then return nil, 'licence' end    -- sans licence valide, aucune écriture ni lecture
    local ts, key = cacheKey(fnName, sql, params)
    if key then
        local now = GetGameTimer()
        local hit
        for t in pairs(ts) do local c = cache[t] and cache[t][key] if c and now - c.t < DB.CacheTtl then hit = c end end
        if hit then
            local all = true
            for t in pairs(ts) do if not (cache[t] and cache[t][key]) then all = false end end
            if all then return copy(hit.res) end
        end
    end
    local g0 = {}
    if key then for t in pairs(ts) do g0[t] = gen[t] or 0 end end
    local t0 = GetGameTimer()
    local ok, res = pcall(MySQL[fnName].await, sql, params or {})
    record(sql, GetGameTimer() - t0, (not ok) and res or nil)
    if not ok then return nil, res end
    if key then
        local fresh = true   -- une écriture pendant la lecture : on ne garde pas un résultat peut-être dépassé
        for t in pairs(ts) do if (gen[t] or 0) ~= g0[t] then fresh = false end end
        if fresh then
            local e = { t = GetGameTimer(), res = copy(res) }
            for t in pairs(ts) do
                if (size[t] or 0) > 300 then cache[t], size[t] = nil, 0 end   -- requêtes à paramètres variables (heure…) : pas d'accumulation
                cache[t] = cache[t] or {}
                if not cache[t][key] then size[t] = (size[t] or 0) + 1 end
                cache[t][key] = e
            end
        end
    elseif not tostring(sql):match('^%s*[Ss][Ee][Ll][Ee][Cc][Tt]') then
        DB.Invalidate(sql)
    end
    return res
end

-- Les fonctions renvoient `nil, erreur` en cas d'échec (jamais d'exception).
function DB.q(sql, params) return run('query', sql, params) end
function DB.one(sql, params) return run('single', sql, params) end
function DB.scalar(sql, params) return run('scalar', sql, params) end
function DB.exec(sql, params) return run('update', sql, params) end
function DB.insert(sql, params) return run('insert', sql, params) end

function DB.tx(queries)
    local t0 = GetGameTimer()
    for _, q in ipairs(queries or {}) do DB.Invalidate(type(q) == 'table' and (q.query or q[1]) or q) end
    local ok, res = pcall(MySQL.transaction.await, queries)
    for _, q in ipairs(queries or {}) do DB.Invalidate(type(q) == 'table' and (q.query or q[1]) or q) end
    record('TRANSACTION (' .. #queries .. ')', GetGameTimer() - t0, (not ok) and res or (res == false and 'transaction annulée' or nil))
    if not ok then return nil, res end
    return res
end

-- Migrations ---------------------------------------------------------------------------
local migrations = {}
local SUFFIX = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'

-- Enregistre une migration (une liste de requêtes SQL ou une fonction). `id` doit être unique et stable.
function PB.Migrate(id, name, steps) migrations[#migrations + 1] = { id = id, name = name, steps = steps } end
function PB.Table(sql) return sql .. SUFFIX end

function DB.MigrationState()
    local applied = {}
    for _, r in ipairs(DB.q('SELECT id, name, applied_at FROM pb_migrations ORDER BY applied_at, id') or {}) do applied[r.id] = r end
    local out = {}
    for _, m in ipairs(migrations) do
        out[#out + 1] = { id = m.id, name = m.name, applied = applied[m.id] ~= nil, applied_at = applied[m.id] and applied[m.id].applied_at or nil }
    end
    return out
end

local function runMigrations()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_migrations (
        id VARCHAR(64) NOT NULL, name VARCHAR(128) NOT NULL DEFAULT '',
        applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id))]]))
    local applied = {}
    for _, r in ipairs(DB.q('SELECT id FROM pb_migrations') or {}) do applied[r.id] = true end
    for _, m in ipairs(migrations) do
        if not applied[m.id] then
            local ok = true
            if type(m.steps) == 'function' then
                local s, e = pcall(m.steps)
                if not s then ok = false PB.Err('migration ' .. m.id .. ' : ' .. tostring(e)) end
            else
                for _, sql in ipairs(m.steps) do
                    local _, err = DB.exec(sql:find('^%s*CREATE TABLE') and PB.Table(sql) or sql)
                    if err then ok = false PB.Err('migration ' .. m.id .. ' : ' .. tostring(err)) break end
                end
            end
            if ok then DB.exec('INSERT INTO pb_migrations (id, name) VALUES (?, ?)', { m.id, m.name }) end
        end
    end
end

-- Construit un INSERT ... ON DUPLICATE KEY UPDATE à partir d'une ligne.
function DB.upsert(tbl, row, keys)
    local cols, qs, params, ups = {}, {}, {}, {}
    local isKey = {}
    for _, k in ipairs(keys) do isKey[k] = true end
    for _, c in ipairs(PB.Keys(row)) do
        cols[#cols + 1] = c
        qs[#qs + 1] = '?'
        params[#params + 1] = row[c]
        if not isKey[c] then ups[#ups + 1] = c .. ' = VALUES(' .. c .. ')' end
    end
    local sql = 'INSERT INTO ' .. tbl .. ' (' .. table.concat(cols, ', ') .. ') VALUES (' .. table.concat(qs, ', ') .. ')'
    if #ups > 0 then sql = sql .. ' ON DUPLICATE KEY UPDATE ' .. table.concat(ups, ', ') end
    return DB.exec(sql, params)
end

function DB.TableExists(name)
    local n = DB.scalar('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', { name })
    return (tonumber(n) or 0) > 0
end

function DB.ColumnExists(tbl, col)
    local n = DB.scalar('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?', { tbl, col })
    return (tonumber(n) or 0) > 0
end

MySQL.ready(function()
    runMigrations()
    for _, fn in ipairs(readyCallbacks) do
        local ok, err = pcall(fn)
        if not ok then PB.Err("erreur d'initialisation : " .. tostring(err)) end
    end
    PB.IsReady = true
    PB.Log('base de données prête.')
    TriggerEvent('pb_panel:ready')
end)
