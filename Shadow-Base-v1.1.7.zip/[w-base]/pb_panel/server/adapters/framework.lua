-- Shadow Framework — organisations de la base (métiers légaux, gangs illégaux), uniquement dans les tables pb_org_* de la base.
-- Aucun autre framework (ESX, QBCore, Qbox) n'est lu ni écrit : la base fonctionne avec « wframework » seul (voir server/core/exclusive.lua).
-- API commune utilisée par les modules Métiers, Gangs, Économie, Effectifs :
--   Fw.Groups(kind)            kind = 'job' | 'gang'   -> liste de { name,label,type,defaultDuty,offDutyPay,grades = { {grade,name,label,salary,boss} } }
--   Fw.SaveGroup(kind, def, actor) / Fw.DeleteGroup(kind, name, actor, reassignTo)
--   Fw.Members(kind, name)     -> effectifs { id, name, grade, gradeLabel, online }
--   Fw.Assign(kind, target, name, grade)   target = { src= } ou { id= } (licence du personnage)
--   Fw.SearchPlayers(q)        -> { id, name, src, job, jobGrade }

PB.Fw = PB.Fw or {}
local Fw = PB.Fw
Fw.name, Fw.label, Fw.resource = 'none', 'Shadow Framework', 'wframework'

-- Le seul framework possible : celui de la base. 'none' = aucun framework externe (valeur interne conservée pour les modules).
function Fw.Detect() return 'none' end

local function sortedGrades(list) table.sort(list, function(a, b) return a.grade < b.grade end) return list end

-- ======================================================================================================================
PB.Migrate('170_native_orgs', 'Organisations de la base (métiers légaux, gangs illégaux)', {
    [[CREATE TABLE IF NOT EXISTS pb_org_groups (
        kind VARCHAR(8) NOT NULL, name VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, otype VARCHAR(24) NOT NULL DEFAULT '', color VARCHAR(9) NOT NULL DEFAULT '',
        default_duty TINYINT(1) NOT NULL DEFAULT 0, offduty_pay TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (kind, name))]],
    [[CREATE TABLE IF NOT EXISTS pb_org_grades (
        kind VARCHAR(8) NOT NULL, name VARCHAR(32) NOT NULL, grade INT NOT NULL, gname VARCHAR(48) NOT NULL, label VARCHAR(48) NOT NULL, salary INT NOT NULL DEFAULT 0,
        boss TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (kind, name, grade))]],
    [[CREATE TABLE IF NOT EXISTS pb_org_members (
        kind VARCHAR(8) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(32) NOT NULL, grade INT NOT NULL DEFAULT 0, since INT NOT NULL DEFAULT 0,
        PRIMARY KEY (kind, license), KEY idx_org (kind, name))]],
})
local native = {}
local NATIVE_DEFAULT = { job = { 'unemployed', 'Sans emploi', 'Sans emploi' }, gang = { 'none', 'Aucun gang', 'Libre' } }
local seeded = {}
local function seed(kind)
    if seeded[kind] then return end
    local d = NATIVE_DEFAULT[kind]
    if not d then return end
    local n = tonumber(PB.DB.scalar('SELECT COUNT(*) FROM pb_org_groups WHERE kind = ? AND name = ?', { kind, d[1] })) or 0
    if n == 0 then
        PB.DB.exec('INSERT INTO pb_org_groups (kind, name, label) VALUES (?, ?, ?)', { kind, d[1], d[2] })
        PB.DB.exec('INSERT INTO pb_org_grades (kind, name, grade, gname, label, salary, boss) VALUES (?, ?, 0, ?, ?, 0, 0)', { kind, d[1], d[3]:lower():gsub('%s', '_'), d[3] })
    end
    seeded[kind] = true
end
local function licenseOf(src) return PB.Perm and PB.Perm.GetLicense and PB.Perm.GetLicense(src) or nil end
local function onlineByLicense()
    local out = {}
    for _, id in ipairs(GetPlayers and GetPlayers() or {}) do
        local l = licenseOf(tonumber(id))
        if l then out[l] = tonumber(id) end
    end
    return out
end

function native.groups(kind)
    seed(kind)
    local list, by = {}, {}
    for _, g in ipairs(PB.DB.q('SELECT name, label, otype, color, default_duty, offduty_pay FROM pb_org_groups WHERE kind = ? ORDER BY name', { kind }) or {}) do
        local o = { name = g.name, label = g.label, type = g.otype ~= '' and g.otype or nil, color = g.color ~= '' and g.color or nil, grades = {}, source = 'base',
            defaultDuty = PB.ToBool(g.default_duty), offDutyPay = PB.ToBool(g.offduty_pay) }
        list[#list + 1] = o by[g.name] = o
    end
    for _, r in ipairs(PB.DB.q('SELECT name, grade, gname, label, salary, boss FROM pb_org_grades WHERE kind = ? ORDER BY name, grade', { kind }) or {}) do
        local o = by[r.name]
        if o then o.grades[#o.grades + 1] = { grade = tonumber(r.grade), name = r.gname, label = r.label, salary = tonumber(r.salary) or 0, boss = PB.ToBool(r.boss) } end
    end
    return list
end

function native.save(kind, def, actor)
    seed(kind)
    local col = def.color and tostring(def.color):match('^#%x%x%x%x%x%x$') or ''
    local q = {
        { query = 'INSERT INTO pb_org_groups (kind, name, label, otype, color, default_duty, offduty_pay) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), otype = VALUES(otype), color = VALUES(color), default_duty = VALUES(default_duty), offduty_pay = VALUES(offduty_pay)',
          values = { kind, def.name, def.label, def.type or '', col, def.defaultDuty and 1 or 0, def.offDutyPay and 1 or 0 } },
        { query = 'DELETE FROM pb_org_grades WHERE kind = ? AND name = ?', values = { kind, def.name } },
    }
    for _, g in ipairs(def.grades) do
        q[#q + 1] = { query = 'INSERT INTO pb_org_grades (kind, name, grade, gname, label, salary, boss) VALUES (?, ?, ?, ?, ?, ?, ?)', values = { kind, def.name, g.grade, g.name, g.label, g.salary or 0, g.boss and 1 or 0 } }
    end
    if not PB.DB.tx(q) then return false, 'Écriture en base impossible : modification annulée.' end
    if kind == 'gang' and PB.G and PB.G.Tags and PB.G.Tags.RefreshNative then PB.G.Tags.RefreshNative() end
    return true, nil, { msg = 'Enregistré (organisations de la base).', note = 'Appliqué tout de suite, sans redémarrage.' }
end

function native.delete(kind, name, actor, reassign)
    local d = NATIVE_DEFAULT[kind]
    if d and name == d[1] then return false, 'Ce groupe par défaut est requis.' end
    local n = tonumber(PB.DB.scalar('SELECT COUNT(*) FROM pb_org_members WHERE kind = ? AND name = ?', { kind, name })) or 0
    local q = {}
    if n > 0 then
        if not reassign then return false, n .. ' membre(s) : choisis un groupe de remplacement.' end
        q[#q + 1] = { query = 'DELETE FROM pb_org_members WHERE kind = ? AND name = ?', values = { kind, name } }
    end
    q[#q + 1] = { query = 'DELETE FROM pb_org_grades WHERE kind = ? AND name = ?', values = { kind, name } }
    q[#q + 1] = { query = 'DELETE FROM pb_org_groups WHERE kind = ? AND name = ?', values = { kind, name } }
    if not PB.DB.tx(q) then return false, 'Écriture en base impossible : suppression annulée.' end
    if kind == 'gang' and PB.G and PB.G.Tags and PB.G.Tags.RefreshNative then PB.G.Tags.RefreshNative() end
    return true, nil, { msg = 'Supprimé.' }
end

function native.members(kind, name)
    local online = onlineByLicense()
    local grades = {}
    for _, r in ipairs(PB.DB.q('SELECT grade, label FROM pb_org_grades WHERE kind = ? AND name = ?', { kind, name }) or {}) do grades[tonumber(r.grade)] = r.label end
    local out = {}
    for _, r in ipairs(PB.DB.q('SELECT m.license, m.grade, p.firstname, p.lastname FROM pb_org_members m LEFT JOIN pb_players p ON p.license = m.license WHERE m.kind = ? AND m.name = ? ORDER BY m.grade DESC LIMIT 500', { kind, name }) or {}) do
        out[#out + 1] = { id = r.license, name = PB.Trim((r.firstname or '') .. ' ' .. (r.lastname or '')), grade = tonumber(r.grade) or 0, gradeLabel = grades[tonumber(r.grade)] or '?', online = online[r.license] }
    end
    return out
end

function native.assign(kind, target, name, grade)
    seed(kind)
    local ok = tonumber(PB.DB.scalar('SELECT COUNT(*) FROM pb_org_grades WHERE kind = ? AND name = ? AND grade = ?', { kind, name, grade })) or 0
    if ok == 0 then return false, "Ce groupe ou ce grade n'existe pas." end
    local license, src = target.id, target.src
    if src then license = licenseOf(src) end
    if not license then return false, 'Joueur introuvable.' end
    local d = NATIVE_DEFAULT[kind]
    if d and name == d[1] then PB.DB.exec('DELETE FROM pb_org_members WHERE kind = ? AND license = ?', { kind, license })
    else PB.DB.exec('REPLACE INTO pb_org_members (kind, license, name, grade, since) VALUES (?, ?, ?, ?, ?)', { kind, license, name, grade, os.time() }) end
    if kind == 'gang' and PB.G and PB.G.Tags and PB.G.Tags.SetGang then
        local live = src
        if not live then live = onlineByLicense()[license] end
        if live then PB.G.Tags.SetGang(live, (d and name == d[1]) and nil or name) end
    end
    return true, nil, { live = src ~= nil }
end

function native.search(q)
    local like = '%' .. q:gsub('[\\%%_]', '\\%0') .. '%'
    local online = onlineByLicense()
    local out = {}
    for _, r in ipairs(PB.DB.q('SELECT license, firstname, lastname FROM pb_players WHERE firstname LIKE ? OR lastname LIKE ? OR license LIKE ? LIMIT 25', { like, like, like }) or {}) do
        local j = PB.DB.one('SELECT name, grade FROM pb_org_members WHERE kind = ? AND license = ?', { 'job', r.license })
        out[#out + 1] = { id = r.license, name = PB.Trim((r.firstname or '') .. ' ' .. (r.lastname or '')), src = online[r.license], job = j and j.name or 'unemployed', jobGrade = j and tonumber(j.grade) or 0 }
    end
    return out
end


-- ======================================================================================================================
-- Interface commune
-- ======================================================================================================================
local function impl() return native end

function Fw.Groups(kind) return impl().groups(kind) end
function Fw.SaveGroup(kind, def, actor) return impl().save(kind, def, actor) end
function Fw.DeleteGroup(kind, name, actor, reassign) return impl().delete(kind, name, actor, reassign) end
function Fw.Members(kind, name) return impl().members(kind, name) end
function Fw.Assign(kind, target, name, grade) return impl().assign(kind, target, name, grade) end
function Fw.SearchPlayers(q) return impl().search(q) end

-- Valide une définition de métier/gang venant de l'interface.
function Fw.CleanGroup(kind, d)
    local name = tostring(d.name or ''):lower()
    if not name:match('^[a-z0-9_]+$') or #name < 2 or #name > 32 then return nil, "Identifiant : 2 à 32 caractères (a-z, 0-9, _)." end
    local label = PB.Trim(PB.Sanitize(tostring(d.label or name), 48))
    if label == '' then return nil, "Le nom affiché est obligatoire." end
    local out = { name = name, label = label, grades = {} }
    if d.type and d.type ~= '' then
        out.type = tostring(d.type):lower()
        if not out.type:match('^[a-z0-9_]+$') or #out.type > 24 then return nil, 'Type invalide.' end
    end
    if d.defaultDuty ~= nil then out.defaultDuty = PB.ToBool(d.defaultDuty) end
    if d.offDutyPay ~= nil then out.offDutyPay = PB.ToBool(d.offDutyPay) end
    local seen = {}
    for _, g in ipairs(d.grades or {}) do
        local lvl = PB.ToInt(g.grade, nil)
        if lvl == nil or lvl < 0 or lvl > 99 then return nil, 'Niveau de grade invalide (0 à 99).' end
        if seen[lvl] then return nil, 'Deux grades ont le niveau ' .. lvl .. '.' end
        seen[lvl] = true
        local gname = tostring(g.name or ''):gsub('^%s+', ''):gsub('%s+$', '')
        if gname == '' or #gname > 48 or gname:find('[%c]') then return nil, 'Nom de grade invalide (niveau ' .. lvl .. ').' end
        local sal = PB.ToInt(g.salary, 0)
        if sal < 0 or sal > 1000000 then return nil, 'Salaire invalide (0 à 1 000 000).' end
        out.grades[#out.grades + 1] = { grade = lvl, name = PB.Sanitize(gname, 48), label = PB.Sanitize(tostring(g.label or gname), 48), salary = sal, boss = PB.ToBool(g.boss) }
    end
    if #out.grades == 0 then return nil, 'Ajoute au moins un grade.' end
    sortedGrades(out.grades)
    return out
end

-- Compatibilité : tout est toujours disponible, c'est la base qui porte les organisations.
function Fw.Supports(feature) return true end

function Fw.Caps(kind)
    return PB.Capsify({ { 'Shadow Framework', 'ok', 'Métiers (légaux) et gangs (illégaux) gérés par les tables de la base : création, grades, attribution, sans redémarrage.' } })
end

function Fw.AccountNames() return {} end
