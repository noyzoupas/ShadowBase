-- Pont vers la librairie admin existante. Le panel ne la remplace pas : il lui pousse les grades (voir perm.lua)
-- et peut vérifier que les exports configurés répondent.

PB.AdminLib = PB.AdminLib or {}
local AL = PB.AdminLib

function AL.Mode() return (Config.AdminLib and Config.AdminLib.mode) or 'ace' end
function AL.Resource() return (Config.AdminLib and Config.AdminLib.resource) or '' end

function AL.State()
    local r = AL.Resource()
    if r == '' then return 'non renseignée' end
    return GetResourceState(r)
end

local function call(kind, ...)
    local cfg = Config.AdminLib or {}
    local fn = cfg.exports and cfg.exports[kind]
    if not fn or fn == '' or AL.Resource() == '' then return nil, 'non configuré' end
    local args = { ... }
    local ok, res = pcall(function() return exports[cfg.resource][fn](exports[cfg.resource], table.unpack(args)) end)
    if not ok then return nil, tostring(res) end
    return res == nil and true or res
end

function AL.Call(kind, ...) return call(kind, ...) end

-- Vérifie chaque export lisible sans rien modifier.
function AL.Test()
    local out = {}
    local mode = AL.Mode()
    out[#out + 1] = { name = 'Mode', ok = true, detail = mode == 'ace' and 'Groupes ACE group.pb_<grade>' or 'Exports de la librairie' }
    if mode == 'export' then
        local state = AL.State()
        out[#out + 1] = { name = 'Ressource ' .. AL.Resource(), ok = state == 'started', detail = state }
        for _, kind in ipairs({ 'listGrades', 'listPermissions' }) do
            local r, err = call(kind)
            out[#out + 1] = { name = kind, ok = r ~= nil and type(r) == 'table', detail = r ~= nil and (type(r) == 'table' and (#r .. ' élément(s)') or tostring(r)) or tostring(err) }
        end
        for _, kind in ipairs({ 'saveGrade', 'deleteGrade', 'setPlayerGrade' }) do
            local fn = Config.AdminLib.exports and Config.AdminLib.exports[kind]
            out[#out + 1] = { name = kind, ok = fn ~= nil and fn ~= '', detail = (fn and fn ~= '') and ('export « ' .. fn .. ' » (non testé : modifie des données)') or 'non renseigné' }
        end
    else
        out[#out + 1] = { name = 'Principals ACE', ok = true, detail = 'Appliqués via add_ace / add_principal à chaque changement.' }
    end
    return out
end

-- Permissions propres à la librairie (si elle les expose).
function AL.LibPermissions()
    if AL.Mode() ~= 'export' then return nil, "Disponible en mode 'export' avec un export listPermissions." end
    local r, err = call('listPermissions')
    if type(r) ~= 'table' then return nil, 'La librairie ne fournit pas de liste (' .. tostring(err or 'export absent') .. ').' end
    return r
end
