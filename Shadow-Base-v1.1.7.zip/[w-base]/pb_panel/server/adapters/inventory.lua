-- Adaptateur inventaire : l'inventaire de Shadow Base uniquement (tables pb_inv_items / pb_inv). Aucun inventaire externe n'est lu.

PB.Inv = PB.Inv or {}
local Inv = PB.Inv

function Inv.Detect()
    -- Un seul inventaire : celui de Shadow Base (sac intégré). Aucun inventaire externe (ox_inventory, qb-inventory...) n'est utilisé.
    local kind = (PB.G and PB.G.Inv) and 'pb' or 'none'
    local name = kind == 'pb' and 'Shadow Base' or nil
    Inv.name, Inv.kind = name, kind
    return kind, name
end

function Inv.ItemFields()
        return {
            { k = 'label', type = 'text', label = 'Nom affiché', required = true, maxlen = 48 },
            { k = 'weight', type = 'number', label = 'Poids (g)', min = 0, max = 1000000, default = 100 },
            { k = 'stack', type = 'number', label = 'Pile maximale', min = 1, max = 1000, default = 20 },
            { k = 'kind', type = 'select', label = 'Type', opts = { { 'food', 'Nourriture' }, { 'drink', 'Boisson' }, { 'medical', 'Soin' }, { 'tool', 'Outil' }, { 'doc', 'Document' }, { 'misc', 'Divers' } }, default = 'misc' },
            { k = 'hunger', type = 'number', label = 'Faim', min = -100, max = 100, default = 0 },
            { k = 'thirst', type = 'number', label = 'Soif', min = -100, max = 100, default = 0 },
            { k = 'stress', type = 'number', label = 'Stress', min = -100, max = 100, default = 0 },
            { k = 'health', type = 'number', label = 'Vie', min = -100, max = 100, default = 0 },
            { k = 'usable', type = 'toggle', label = 'Utilisable', default = false },
            { k = 'description', type = 'text', label = 'Description', maxlen = 160 },
            { k = 'image', type = 'text', label = 'Image (vide = automatique ; img/ox/nom.png ou https://…)', maxlen = 200 },
        }, { 'label', 'weight', 'stack', 'kind', 'hunger', 'thirst', 'stress', 'health', 'usable', 'description', 'image' }
end

-- Liste d'objets ------------------------------------------------------------------------------------------------------------------------
-- Renvoie { items = {...}, total = n } ; filtre texte et pagination côté serveur (les fichiers peuvent contenir des milliers d'objets).
function Inv.Items(q, page, per)
    per = per or 25
    page = page or 1
    q = (q or ''):lower()
    local all = {}
        for name, d in pairs(PB.G.Inv.Defs()) do
            all[#all + 1] = { name = name, label = d.label, weight = tonumber(d.weight) or 0, stack = tonumber(d.stack) or 1, kind = d.kind, hunger = d.hunger, thirst = d.thirst, stress = d.stress, health = d.health,
                usable = d.usable, description = d.description, image = d.image or '', complex = {} }
        end
        table.sort(all, function(a, b) return a.name < b.name end)
    local out = {}
    for _, it in ipairs(all) do
        if q == '' or it.name:lower():find(q, 1, true) or (it.label and tostring(it.label):lower():find(q, 1, true)) then out[#out + 1] = it end
    end
    local total = #out
    local from = (page - 1) * per + 1
    local slice = {}
    for i = from, math.min(total, from + per - 1) do slice[#slice + 1] = out[i] end
    return { items = slice, total = total }
end

function Inv.Why() return nil end

function Inv.Get(name)
    local r = Inv.Items(name, 1, 200)
    if not r then return nil end
    for _, it in ipairs(r.items) do if it.name == name then return it end end
end

-- Création / modification ------------------------------------------------------------------------------------------------------------------
function Inv.SaveItem(name, props, actor, isNew)
    if type(name) ~= 'string' or not name:match('^[%w_%-]+$') or #name > 64 then return false, "Identifiant d'objet invalide (lettres, chiffres, _ et -)." end
    local I = PB.G.Inv
    local exists = I.Def(name) ~= nil
    if isNew and exists then return false, 'Cet objet existe déjà.' end
    if not isNew and not exists then return false, 'Objet introuvable.' end
    if #name > 40 or not name:match('^[%w_]+$') then return false, "Identifiant d'objet invalide (lettres, chiffres et _, 40 caractères au plus)." end
    if not I.ValidImage(props.image) then return false, 'Image invalide : img/dossier/nom.png ou une adresse https://.' end
    local cur = I.Def(name)
    if cur and tonumber(cur.stack) and props.stack and tonumber(props.stack) < tonumber(cur.stack) then
        local over = PB.DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE item = ? AND qty > ?', { name, props.stack })
        if over and over.n > 0 then return false, ('%d pile(s) existante(s) dépassent cette taille : agrandis la pile ou vide-les.'):format(over.n) end
    end
    local kindv = (cur and cur.kind == 'clothes') and 'clothes' or props.kind or 'misc'
    PB.DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), weight = VALUES(weight), stack = VALUES(stack), kind = VALUES(kind), hunger = VALUES(hunger), thirst = VALUES(thirst), stress = VALUES(stress), health = VALUES(health), usable = VALUES(usable), description = VALUES(description), image = VALUES(image)',
        { name, props.label, props.weight or 0, props.stack or 20, kindv, props.hunger or 0, props.thirst or 0, props.stress or 0, props.health or 0, props.usable and 1 or 0, props.description or '', props.image or '' })
    I.Reload()
    return true, nil, { msg = 'Objet enregistré : actif tout de suite dans le jeu.' }
end

function Inv.DeleteItem(name, actor)
    local I = PB.G.Inv
    if not I.Def(name) then return false, 'Objet introuvable.' end
    PB.DB.exec('DELETE FROM pb_inv WHERE item = ?', { name })
    PB.DB.exec('DELETE FROM pb_inv_items WHERE name = ?', { name })
    I.Reload()
    return true, nil, { msg = 'Objet supprimé, ainsi que ses exemplaires dans les sacs.' }
end

-- Matrice de compatibilité -------------------------------------------------------------------------------------------------------------------------
function Inv.Caps()
    return PB.Capsify({
        { 'Inventaire', 'ok', 'Inventaire de Shadow Base (le seul pris en charge).' },
        { 'Objets (nom, poids, pile, type, effets, image)', 'ok', 'Effet immédiat dans le jeu.' },
        { 'Boutiques, coffres, réglages', 'ok', 'Modules « Boutiques » et « Inventaire » de Shadow Base.' },
        { 'Inventaires externes (ox_inventory, qb-inventory…)', 'off', 'Non pris en charge : ils sont refusés au démarrage.' },
    })
end

-- Donne un objet à un joueur connecté (magasins du panel) : directement dans le sac de Shadow Base.
function Inv.Give(src, name, count)
    count = math.floor(tonumber(count) or 1)
    local I = PB.G and PB.G.Inv
    if count < 1 or not (I and I.Add and I.PlayerOwner) then return false end
    local o = I.PlayerOwner(tonumber(src))
    if not o then return false end
    local ok, r = pcall(I.Add, o, tostring(name), count)
    if ok and r and I.PushOwners then pcall(I.PushOwners, o) end
    return ok and r and true or false
end
