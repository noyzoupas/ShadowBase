-- Module 9 : Véhicules et garages. Catalogue de Shadow Base, véhicules des joueurs,
-- réglages du script de garages détecté.

local B, P, FC = PB.B, PB.Perm, PB.FileCfg

P.Register('vehicles.edit', 'Modifier le catalogue de véhicules', 'vehicles')
P.Register('vehicles.delete', 'Supprimer des véhicules du catalogue', 'vehicles', true)
P.Register('vehicles.owned', 'Gérer les véhicules des joueurs', 'vehicles', true)

local PER = 25

local function catalog(q, page)
    q = (q or ''):lower()
    local all = {}
    for _, v in ipairs(PB.G.VehCat.Effective()) do all[#all + 1] = { key = v.model, name = v.label, price = v.price, category = v.class } end
    local out = {}
    for _, v in ipairs(all) do
        if q == '' or v.key:lower():find(q, 1, true) or tostring(v.name):lower():find(q, 1, true) then out[#out + 1] = v end
    end
    local total, slice = #out, {}
    for i = (page - 1) * PER + 1, math.min(total, page * PER) do slice[#slice + 1] = out[i] end
    return slice, total
end

local function clean(v)
    local fields = {
        { k = 'name', type = 'text', label = 'Nom', required = true, maxlen = 64 },
        { k = 'price', type = 'number', label = 'Prix', min = 0, max = 100000000 },
        { k = 'category', type = 'text', label = 'Catégorie', maxlen = 32 },
        { k = 'brand', type = 'text', label = 'Marque', maxlen = 32 },
    }
    return PB.Validate(fields, { name = v.name, price = v.price or 0, category = v.category or '', brand = v.brand or '' })
end

PB.Action('vehicles.save', 'vehicles.edit', function(ctx, p)
    local key = tostring(p.mode == 'edit' and p.original or (p.values and p.values.key) or ''):lower()
    if not key:match('^[%w_]+$') or #key > 32 then return false, 'Modèle invalide (lettres, chiffres et _).' end
    local c, err = clean(p.values or {})
    if not c then return false, err end
    local isNew = p.mode ~= 'edit'
    local VC = PB.G.VehCat
    local exists = VC.Find(key) ~= nil
    if isNew and exists then return false, 'Ce modèle existe déjà.' end
    if not isNew and not exists then return false, 'Véhicule introuvable.' end
    local ok, e = VC.Save(key, c.name, c.price, c.category)
    if not ok then return false, e end
    ctx.audit('config', isNew and 'vehicule.creer' or 'vehicule.modifier', key, nil, c)
    ctx.toast = 'Enregistré : les concessions de Shadow Base utilisent déjà ce catalogue.'
    return true, { open = { tab = 'edit', params = { key = key } } }
end)

PB.Action('vehicles.delete', 'vehicles.delete', function(ctx, p)
    local key = tostring(p.key or ''):lower()
    if not PB.G.VehCat.Find(key) then return false, 'Véhicule introuvable.' end
    PB.G.VehCat.Remove(key)
    ctx.audit('config', 'vehicule.supprimer', key)
    ctx.toast = 'Retiré du catalogue.'
    return true
end, { critical = true, confirm = { title = 'Retirer ce véhicule du catalogue ?', text = 'Les véhicules déjà possédés par des joueurs ne sont pas touchés.' } })

local function ownedTable()
    if PB.DB.TableExists('pb_vehicles') then return 'pb_vehicles', 'plate', 'license', 'model' end
end

PB.Action('vehicles.owned.delete', 'vehicles.owned', function(ctx, p)
    local t, plate = ownedTable()
    if not t then return false, 'Table des véhicules joueurs introuvable.' end
    local pl = tostring(p.plate or '')
    if #pl < 1 or #pl > 12 then return false, 'Plaque invalide.' end
    local before = PB.DB.one('SELECT * FROM ' .. t .. ' WHERE plate = ?', { pl })
    if not before then return false, 'Véhicule introuvable.' end
    PB.DB.exec('DELETE FROM ' .. t .. ' WHERE plate = ?', { pl })
    ctx.audit('config', 'vehicule.joueur.supprimer', pl, { owner = before.owner or before.citizenid or before.license, model = before.vehicle or before.mods and 'mods' or nil })
    ctx.toast = 'Véhicule ' .. pl .. ' supprimé de la base.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Supprimer ce véhicule ?', text = 'Le joueur le perd définitivement.' } })

PB.Module({
    id = 'vehicles', label = 'Véhicules', icon = 'car', group = 'Serveur', order = 80, perm = 'vehicles.view', hint = 'Catalogue et véhicules des joueurs',
    caps = function()
        return PB.Capsify({
            { 'Catalogue de véhicules', 'ok', 'Catalogue de Shadow Base : prix, noms, ajouts et retraits, utilisés par les concessions (effet immédiat).' },
            { 'Véhicules des joueurs (lecture, suppression)', ownedTable() and 'ok' or 'off', ownedTable() and ('Table ' .. ownedTable()) or 'Table introuvable.' },
            { 'Modèles personnalisés (stream)', 'off', "Le streaming des modèles se fait dans les ressources de véhicules, pas depuis le panel." },
        })
    end,
    doc = "## Véhicules\nCatalogue de Shadow Base (concessions et garages). Le panel ne modifie pas les véhicules en circulation.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        local key = tostring(params and params.key or '')
        return { tabs = {
            tab('list', 'Catalogue', 'list', function()
                local q = tostring(params and params.q or '')
                local page = math.max(1, PB.ToInt(params and params.page, 1))
                local rows, total = catalog(q, page)
                if not rows then return { B.unsupported('Catalogue', total) } end
                local out = {}
                for _, v in ipairs(rows) do out[#out + 1] = { key = v.key, name = v.name, price = v.price, category = v.category, actions = { { nav = { tab = 'edit', params = { key = v.key } }, label = 'Modifier', icon = 'edit' } } } end
                return { B.stats({ { label = 'Véhicules', value = total, icon = 'car' } }),
                    { type = 'form', id = 'veh.search', title = 'Rechercher', cols = 2, fields = { { k = 'q', type = 'text', label = 'Modèle ou nom', maxlen = 64 } }, values = { q = q }, submit = { nav = { tab = 'list' }, label = 'Chercher', as = 'params' } },
                    B.table({ id = 'veh', columns = { { k = 'key', label = 'Modèle', type = 'mono' }, { k = 'name', label = 'Nom' }, { k = 'price', label = 'Prix', type = 'num' }, { k = 'category', label = 'Catégorie' } }, rows = out,
                        page = { n = page, per = PER, total = total, tab = 'list', q = q }, empty = 'Aucun véhicule.' }) }
            end),
            tab('edit', 'Éditeur', 'edit', function()
                local cur
                if key ~= '' then
                    local rows = catalog(key, 1)
                    for _, v in ipairs(rows or {}) do if v.key == key then cur = v end end
                end
                local fields = {
                    { k = 'key', type = 'text', label = 'Modèle (nom du spawn)', required = true, maxlen = 32, pattern = '^[%w_]+$', readonly = cur ~= nil },
                    { k = 'name', type = 'text', label = 'Nom', required = true, maxlen = 64 },
                    { k = 'price', type = 'number', label = 'Prix', min = 0, max = 100000000 },
                    { k = 'category', type = 'text', label = 'Catégorie', maxlen = 32 },
                }
                local opts = {}
                for _, c in ipairs(PB.G.VehCat.classes) do opts[#opts + 1] = { c.id, c.id } end
                fields[4] = { k = 'category', type = 'select', label = 'Catégorie', opts = opts }
                local blocks = { { type = 'form', id = 'veh.form', title = cur and ('Modifier ' .. cur.name) or 'Ajouter un véhicule', cols = 2, fields = fields,
                    values = cur or { key = '', name = '', price = 0, category = 'Compactes' },
                    submit = { action = 'vehicles.save', label = cur and 'Enregistrer' or 'Ajouter', payload = { mode = cur and 'edit' or 'create', original = cur and cur.key or nil } } } }
                if cur and ctx.has('vehicles.delete') then blocks[#blocks + 1] = B.actions({ { action = 'vehicles.delete', label = 'Retirer du catalogue', icon = 'trash', danger = true, payload = { key = cur.key } } }) end
                return blocks
            end, 'vehicles.edit'),
            tab('owned', 'Véhicules des joueurs', 'users', function()
                local t = ownedTable()
                if not t then return { B.unsupported('Véhicules des joueurs', 'Table owned_vehicles / player_vehicles introuvable.') } end
                local q = tostring(params and params.q or '')
                local sql = 'SELECT * FROM ' .. t .. (q ~= '' and ' WHERE plate LIKE ?' or '') .. ' LIMIT 100'
                local rows = PB.DB.q(sql, q ~= '' and { '%' .. q:gsub('[%%_]', '') .. '%' } or {}) or {}
                local out = {}
                for _, r in ipairs(rows) do
                    out[#out + 1] = { plate = r.plate, owner = r.owner or r.citizenid or r.license or '', model = r.vehicle_model or r.vehicle or r.model or '',
                        actions = ctx.has('vehicles.owned') and { { action = 'vehicles.owned.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { plate = r.plate } } } or nil }
                end
                return { { type = 'form', id = 'veh.osearch', title = 'Chercher une plaque', cols = 2, fields = { { k = 'q', type = 'text', label = 'Plaque', maxlen = 12 } }, values = { q = q }, submit = { nav = { tab = 'owned' }, label = 'Chercher', as = 'params' } },
                    B.table({ id = 'owned', columns = { { k = 'plate', label = 'Plaque', type = 'mono' }, { k = 'owner', label = 'Propriétaire' }, { k = 'model', label = 'Modèle' } }, rows = out, empty = 'Aucun véhicule.' }) }
            end),
        } }
    end,
})
