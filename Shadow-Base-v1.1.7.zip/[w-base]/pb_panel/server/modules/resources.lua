-- Module 4 : Ressources et scripts (état, démarrage/arrêt, dépendances, fichiers, comparaison, valeurs de config, erreurs).

local B, P, F, FC, R = PB.B, PB.Perm, PB.Files, PB.FileCfg, PB.Res

P.Register('resources.edit', 'Modifier les fichiers et valeurs de configuration des ressources', 'resources', true)
P.Register('resources.control', 'Démarrer, arrêter et redémarrer des ressources', 'resources')
P.Register('resources.restore', 'Restaurer une version précédente d\'un fichier', 'resources', true)

-- Erreurs de scripts relevées dans la console (si le serveur le permet) ---------------------------------------------------------
local errors = {}
PB.ScriptErrors = errors
local canListen = type(RegisterConsoleListener) == 'function'
if canListen then
    RegisterConsoleListener(function(channel, text)
        if type(text) ~= 'string' then return end
        if text:find('SCRIPT ERROR', 1, true) or text:find('Error loading script', 1, true) or text:find('Could not find dependency', 1, true) then
            errors[#errors + 1] = { at = os.time(), text = text:gsub('%^%d', ''):gsub('%s+$', ''):sub(1, 400) }
            if #errors > 100 then table.remove(errors, 1) end
        end
    end)
end

local function stateTone(s)
    if s == 'started' then return { text = 'Démarrée', tone = 'ok' }
    elseif s == 'stopped' then return { text = 'Arrêtée', tone = 'off' }
    elseif s == 'starting' then return { text = 'Démarrage', tone = 'warn' }
    elseif s == 'uninitialized' then return { text = 'Non initialisée', tone = 'warn' }
    elseif s == 'missing' then return { text = 'Introuvable', tone = 'err' } end
    return { text = s or '?', tone = 'warn' }
end

-- Actions -------------------------------------------------------------------------------------------------------------------------------------------------
local function doAction(kind, label)
    return function(ctx, p)
        local name = tostring(p.res or '')
        local ok, err = R.Do(kind, name)
        if not ok then return false, err end
        ctx.audit('ressource', 'ressource.' .. kind, name)
        ctx.toast = label .. ' : ' .. name
        return true
    end
end
PB.Action('res.start', 'resources.control', doAction('start', 'Démarrage demandé'))
PB.Action('res.ensure', 'resources.control', doAction('ensure', 'Assurée'))
PB.Action('res.stop', 'resources.control', doAction('stop', 'Arrêt demandé'),
    { critical = true, confirm = { title = 'Arrêter cette ressource ?', text = 'Les joueurs peuvent perdre des fonctionnalités immédiatement.' } })
PB.Action('res.restart', 'resources.control', doAction('restart', 'Redémarrage demandé'),
    { critical = true, confirm = { title = 'Redémarrer cette ressource ?', text = 'Les joueurs peuvent être déconnectés de ses interfaces.', danger = false } })
PB.Action('res.refresh', 'resources.control', function(ctx)
    R.Do('refresh', '')
    ctx.toast = 'Liste des ressources actualisée.'
    return true
end)

PB.Action('res.file.save', 'resources.edit', function(ctx, p)
    local res, file = tostring(p.res or ''), tostring(p.file or '')
    if R.Protected(res) and res ~= GetCurrentResourceName() then return false, 'Ressource protégée.' end
    if res == GetCurrentResourceName() then return false, 'Le panel ne modifie pas ses propres fichiers.' end
    local ok, err, info = F.Write(res, file, tostring(p.content or ''), ctx.actor, 'Éditeur de fichier')
    if not ok then return false, err end
    if info and info.unchanged then ctx.toast = 'Aucun changement.' ctx.refresh = false return true end
    ctx.audited = true
    ctx.toast = 'Fichier enregistré (version précédente sauvegardée). Redémarre la ressource pour appliquer.'
    return true, { restartNeeded = res }
end, { critical = true, confirm = { title = 'Écrire ce fichier ?', text = 'Une sauvegarde est faite avant, le contenu est vérifié après.', danger = false } })

PB.Action('res.file.diff', 'resources.view', function(ctx, p)
    local b = PB.DB.one('SELECT * FROM pb_file_backups WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not b or b.resource == '@server' then return false, 'Sauvegarde introuvable.' end
    local cur = F.Read(b.resource, b.path) or ''
    return true, { title = ('Sauvegarde #%d → version actuelle de %s'):format(b.id, b.path), diff = PB.TextDiff(b.content or '', cur) }
end, { read = true })

PB.Action('res.file.restore', 'resources.restore', function(ctx, p)
    local b = PB.DB.one('SELECT resource FROM pb_file_backups WHERE id = ?', { PB.ToInt(p.id, 0) })
    if b and b.resource == '@server' then return false, 'Le server.cfg se restaure depuis Configuration.' end
    local ok, err = F.Restore(PB.ToInt(p.id, 0), ctx.actor)
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Version restaurée.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Restaurer cette version ?', text = 'Le fichier actuel est sauvegardé puis remplacé.' } })

PB.Action('res.search', 'resources.view', function(ctx, p)
    local q = PB.Trim(tostring(p.q or ''))
    local res = tostring(p.res or '')
    if #q < 2 or #q > 80 then return false, 'Saisis 2 à 80 caractères.' end
    local files, err = F.ListFiles(res)
    if not files then return false, err end
    local out = {}
    for _, f in ipairs(files) do
        local data = F.Read(res, f.path)
        if data then
            local n = 0
            for line in (data .. '\n'):gmatch('([^\n]*)\n') do
                n = n + 1
                if line:lower():find(q:lower(), 1, true) then
                    out[#out + 1] = { file = f.path, line = n, text = line:sub(1, 200) }
                    if #out >= 100 then break end
                end
            end
        end
        if #out >= 100 then break end
    end
    return true, out
end, { read = true })

-- Vue -------------------------------------------------------------------------------------------------------------------------------------------------------
local function resOptions(filter)
    local opts = {}
    for _, n in ipairs(R.All()) do
        if not filter or filter(n) then opts[#opts + 1] = { n, n } end
    end
    return opts
end

PB.Module({
    id = 'resources', label = 'Ressources', icon = 'box', group = 'Pilotage', order = 40, perm = 'resources.view', hint = 'Scripts, état, fichiers, configuration',
    caps = function()
        return PB.Capsify({
            { 'Lister et filtrer les ressources', 'ok', 'État, version, catégorie (dossier [xxx]).' },
            { 'Démarrer / arrêter / redémarrer', 'ok', 'oxmysql et le panel sont protégés.' },
            { 'Éditer les fichiers', SaveResourceFile and 'ok' or 'off', 'Sauvegarde avant chaque écriture, vérification après.' },
            { 'Formulaire automatique des valeurs simples', 'partial', 'Nombres, textes, vrai/faux. Les expressions et fonctions restent dans l\'éditeur.' },
            { 'Journal des erreurs de scripts', canListen and 'ok' or 'off', canListen and 'Relevé depuis la console.' or "Ce serveur ne fournit pas l'écoute de la console." },
            { 'Installer ou supprimer une ressource', 'off', "Opération sur les dossiers du serveur : à faire hors du panel." },
        })
    end,
    doc = "## Ressources\nVue de toutes les ressources, avec leur état, leurs dépendances et leurs fichiers de configuration. Les fichiers sont sauvegardés avant chaque modification et peuvent être comparés puis restaurés.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        local res = tostring(params and params.res or '')
        local file = tostring(params and params.file or '')
        return { tabs = {
            tab('list', 'Ressources', 'list', function()
                local rows, cats, counts = {}, {}, { started = 0, stopped = 0, other = 0 }
                for _, n in ipairs(R.All()) do
                    local st = GetResourceState(n)
                    local cat = R.Category(n)
                    cats[cat] = true
                    counts[st == 'started' and 'started' or st == 'stopped' and 'stopped' or 'other'] = counts[st == 'started' and 'started' or st == 'stopped' and 'stopped' or 'other'] + 1
                    local acts = {}
                    if st ~= 'started' then acts[#acts + 1] = { action = 'res.start', label = 'Démarrer', icon = 'play', payload = { res = n } } end
                    if st == 'started' and not R.Protected(n) then
                        acts[#acts + 1] = { action = 'res.restart', label = 'Redémarrer', icon = 'sync', payload = { res = n } }
                        acts[#acts + 1] = { action = 'res.stop', label = 'Arrêter', icon = 'stop', danger = true, payload = { res = n } }
                    end
                    acts[#acts + 1] = { nav = { tab = 'details', params = { res = n } }, label = 'Détails', icon = 'info' }
                    rows[#rows + 1] = { name = n, state = stateTone(st), cat = cat, version = GetResourceMetadata(n, 'version', 0) or '', protected = R.Protected(n), actions = acts }
                end
                return {
                    B.stats({ { label = 'Démarrées', value = counts.started, icon = 'check' }, { label = 'Arrêtées', value = counts.stopped, icon = 'stop' }, { label = 'Autres états', value = counts.other, icon = 'alert' }, { label = 'Catégories', value = PB.Count(cats), icon = 'folder' } }),
                    B.table({ id = 'res', search = true, columns = { { k = 'name', label = 'Ressource', type = 'mono' }, { k = 'state', label = 'État', type = 'badge' }, { k = 'cat', label = 'Catégorie' }, { k = 'version', label = 'Version' }, { k = 'protected', label = 'Protégée', type = 'bool' } }, rows = rows, empty = 'Aucune ressource.' }),
                    B.actions({ { action = 'res.refresh', label = 'Actualiser la liste', icon = 'sync' } }),
                }
            end),
            tab('details', 'Détails', 'info', function()
                local opts = resOptions()
                if res == '' or GetResourceState(res) == 'missing' then
                    return { { type = 'picker', id = 'res', label = 'Ressource', options = opts, value = res }, B.notice('info', 'Choisis une ressource pour voir ses informations.') }
                end
                local info = R.Info(res)
                local deps, reqs = R.Deps(res)
                local depRows = {}
                for _, d in ipairs(deps) do depRows[#depRows + 1] = { name = d, state = stateTone(GetResourceState(d)) } end
                local blocks = {
                    { type = 'picker', id = 'res', label = 'Ressource', options = opts, value = res },
                    B.kv(res, { { 'État', stateTone(info.state).text }, { 'Version', info.version or '—' }, { 'Auteur', info.author or '—' }, { 'Description', info.description or '—' },
                        { 'fx_version', info.fx or '—' }, { 'Catégorie', R.Category(res) } }),
                    B.table({ id = 'deps', title = 'Dépendances', columns = { { k = 'name', label = 'Ressource', type = 'mono' }, { k = 'state', label = 'État', type = 'badge' } }, rows = depRows, empty = 'Aucune dépendance déclarée.' }),
                }
                for _, d in ipairs(deps) do
                    if GetResourceState(d) ~= 'started' then blocks[#blocks + 1] = B.notice('warn', d .. " n'est pas démarrée alors que " .. res .. ' en dépend.', 'Dépendance manquante') end
                end
                return blocks
            end),
            tab('files', 'Fichiers', 'file', function()
                local opts = resOptions(function(n) return n ~= GetCurrentResourceName() end)
                local blocks = { { type = 'picker', id = 'res', label = 'Ressource', options = opts, value = res } }
                if res == '' then blocks[#blocks + 1] = B.notice('info', 'Choisis une ressource.') return blocks end
                local files, err = F.ListFiles(res)
                if not files then blocks[#blocks + 1] = B.notice('error', err) return blocks end
                local fopts = {}
                for _, f in ipairs(files) do fopts[#fopts + 1] = { f.path, f.path } end
                blocks[#blocks + 1] = { type = 'picker', id = 'file', label = 'Fichier', options = fopts, value = file }
                if file == '' then return blocks end
                local data, rerr = F.Read(res, file)
                if not data then blocks[#blocks + 1] = B.notice('error', rerr) return blocks end
                local ext = (file:match('%.([%w]+)$') or ''):lower()
                if ctx.has('resources.edit') then
                    blocks[#blocks + 1] = { type = 'editor', id = 'file', language = ext, content = data, save = { action = 'res.file.save', label = 'Enregistrer le fichier', payload = { res = res, file = file } } }
                else
                    blocks[#blocks + 1] = { type = 'editor', id = 'file', language = ext, content = data, readonly = true }
                end
                local rows = {}
                for _, b in ipairs(F.Backups(res, file, 30)) do
                    rows[#rows + 1] = { id = b.id, at = b.created_at, by = b.actor, why = b.reason, size = PB.FormatBytes(b.size or 0),
                        actions = { { action = 'res.file.diff', label = 'Comparer', icon = 'diff', payload = { id = b.id } },
                            { action = 'res.file.restore', label = 'Restaurer', icon = 'undo', danger = true, payload = { id = b.id } } } }
                end
                blocks[#blocks + 1] = B.table({ id = 'bk', title = 'Versions sauvegardées', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'by', label = 'Par' }, { k = 'why', label = 'Raison' }, { k = 'size', label = 'Taille' } }, rows = rows, empty = 'Aucune sauvegarde pour ce fichier.' })
                return blocks
            end),
            tab('values', 'Valeurs', 'sliders', function()
                local opts = resOptions(function(n) return n ~= GetCurrentResourceName() end)
                local blocks = { { type = 'picker', id = 'res', label = 'Ressource', options = opts, value = res } }
                if res == '' then blocks[#blocks + 1] = B.notice('info', 'Choisis une ressource.') return blocks end
                local files, err = F.ListFiles(res)
                if not files then blocks[#blocks + 1] = B.notice('error', err) return blocks end
                local fopts = {}
                for _, f in ipairs(files) do if f.path:match('%.lua$') and f.path ~= 'fxmanifest.lua' then fopts[#fopts + 1] = { f.path, f.path } end end
                blocks[#blocks + 1] = { type = 'picker', id = 'file', label = 'Fichier de configuration', options = fopts, value = file }
                if file ~= '' then blocks[#blocks + 1] = FC.AutoForm(res, file, { title = res .. '/' .. file }) end
                return blocks
            end, 'resources.edit'),
            tab('search', 'Recherche', 'search', function()
                local blocks = { { type = 'picker', id = 'res', label = 'Ressource', options = resOptions(), value = res } }
                if res == '' then blocks[#blocks + 1] = B.notice('info', 'Choisis une ressource puis cherche dans ses fichiers.') return blocks end
                local q = tostring(params and params.q or '')
                blocks[#blocks + 1] = { type = 'form', id = 'rs.search', title = 'Chercher dans ' .. res, cols = 1, fields = { { k = 'q', type = 'text', label = 'Texte', maxlen = 80, required = true } },
                    values = { q = q }, submit = { action = 'res.search', label = 'Chercher', payload = { res = res }, show = 'table' } }
                return blocks
            end),
            tab('errors', 'Erreurs', 'alert', function()
                if not canListen then return { B.unsupported('Journal des erreurs', "Ce serveur ne fournit pas l'écoute de la console : consulte la console du serveur ou txAdmin.") } end
                local rows = {}
                for i = #errors, 1, -1 do rows[#rows + 1] = { at = errors[i].at, text = errors[i].text } end
                return { B.table({ id = 'errs', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'text', label = 'Message' } }, rows = rows, empty = "Aucune erreur relevée depuis le démarrage du panel." }) }
            end),
        } }
    end,
})
