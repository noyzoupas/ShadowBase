-- Placement à l'écran : un seul endroit pour déplacer tous les éléments du jeu (HUD, compteur, tableau staff, notifications, menus,
-- chat, invite « E », barre de progression). L'éditeur affiche les VRAIS éléments (web/game/layout.js) ; le serveur valide chaque valeur.

local B, P = PB.B, PB.Perm

local GROUPS = {
    { 'hud', 'HUD et compteur du véhicule' }, { 'staff', 'Tableau staff en service' }, { 'notify', 'Notifications' }, { 'menus', 'Menu personnel' },
    { 'staffmenu', 'Menu staff (F10)' }, { 'place', "Chat, invite « E » et barre de progression" },
}

local function canMap(ctx)
    local can = {}
    for ns, g in pairs(PB.Interface and PB.Interface.Place or {}) do can[ns] = ctx.has(g.perm) and true or false end
    return can
end

-- Remise à zéro d'un groupe : les valeurs par défaut reviennent (réglage supprimé), journalisé.
PB.Action('placement.reset', 'panel.open', function(ctx, p)
    local ns = tostring(p.group or '')
    local g = PB.Interface and PB.Interface.Place and PB.Interface.Place[ns]
    if not g then return false, 'Groupe inconnu.' end
    if not ctx.has(g.perm) then return false, "Tu n'as pas le droit de modifier : " .. g.why:lower() .. '.' end
    local before = {}
    if g.special then
        before = PB.Cfg.Get('interface', 'staffmenu', {})
        PB.Cfg.Delete('interface', 'staffmenu', ctx.actor)
        pcall(function() PB.AdminLib.Call('setLayout', { x = 50, y = 12, scale = 1, opacity = 1 }) end)
    else
        for k in pairs(g.keys) do before[k] = PB.Cfg.Get(ns, k) PB.Cfg.Delete(ns, k, ctx.actor) end
    end
    ctx.audit('config', 'placement.reset', ns, before, nil)
    ctx.toast = 'Position par défaut rétablie.'
    return true
end, { confirm = { title = 'Remettre la position par défaut ?', text = "Le groupe d'éléments revient à sa place d'origine." } })

PB.Module({
    id = 'placement', label = "Placement à l'écran", icon = 'move', group = 'Serveur', order = 129, perm = 'panel.open', hint = "Déplace le HUD, les listes, le chat…",
    caps = function()
        return PB.Capsify({
            { 'Aperçu avec les vrais éléments', 'ok', "Le compteur, le HUD, les notifications et les menus sont dessinés par le même code qu'en jeu." },
            { 'Positions enregistrées et envoyées aux joueurs', 'ok', "Chaque valeur est bornée et validée côté serveur, puis journalisée." },
            { 'Rendu dans un vrai client FiveM', 'warn', "Vérifié seulement dans un navigateur de test : la position réelle dépend de la résolution du joueur (l'écran de référence est 1920 × 1080)." },
        })
    end,
    doc = "## Placement à l'écran\nClique sur un élément, glisse-le où tu veux, règle sa taille, puis **Enregistrer** : les joueurs le voient à la même place. Les éléments fixes (rue et boussole) ne bougent pas. L'onglet **Remise à zéro** rétablit les positions d'origine.",
    view = function(ctx)
        local function tab(id, label, icon, fn) return { id = id, label = label, icon = icon, build = fn } end
        return { tabs = {
            tab('editor', 'Éditeur', 'move', function()
                local can = canMap(ctx)
                local place = PB.Cfg.All('place')
                return { B.notice('info', "L'écran ci-dessous est celui du jeu (1920 × 1080) avec les vrais éléments : compteur du véhicule, HUD, tableau staff, notifications, menu personnel, menu staff, chat, invite « E » et barre de progression. Clique sur un élément, glisse-le, règle sa taille, puis enregistre. La carte et la mini-carte ne sont que des repères."),
                    { type = 'layout', id = 'layout', title = "Placement à l'écran (1920 × 1080)", can = can, save = { action = 'interface.place.save' },
                        cfg = { hud = PB.Cfg.All('hud'), staff = PB.Cfg.All('staff'), notify = PB.Cfg.All('notify'), menus = PB.Cfg.All('menus'), place = place,
                            staffmenu = PB.Cfg.Get('interface', 'staffmenu', { x = math.max(0, math.min(100, 50 + (tonumber(PB.Cfg.Get('menus', 'offset_x', 0)) or 0) / 19.2)), y = math.max(0, math.min(100, 50 + (tonumber(PB.Cfg.Get('menus', 'offset_y', -300)) or -300) / 10.8)), scale = 1, opacity = 1 }) } } }
            end),
            tab('reset', 'Remise à zéro', 'undo', function()
                local acts = {}
                for _, g in ipairs(GROUPS) do
                    if ctx.has((PB.Interface.Place[g[1]] or {}).perm or 'panel.open') then
                        acts[#acts + 1] = { action = 'placement.reset', label = g[2], icon = 'undo', danger = true, payload = { group = g[1] } }
                    end
                end
                return { B.notice('info', "Rétablit la position d'origine d'un groupe d'éléments. Les autres réglages (couleurs, éléments affichés) ne changent pas."), B.actions(acts) }
            end),
        } }
    end,
})

PB.OnReady(function() PB.SelfTest.Add('placement à l\'écran', function(R)
    R.check(PB.Interface and PB.Interface.Place and PB.Interface.Place.place ~= nil, 'Placement', 'le groupe chat / invite / progression manque')
    for _, g in ipairs(GROUPS) do R.check(PB.Interface.Place[g[1]] ~= nil, 'Placement', 'groupe inconnu : ' .. g[1]) end
    R.check(PB.Cfg.Get('place', 'prompt_y') ~= nil and PB.Cfg.Get('place', 'chat_x') ~= nil, 'Placement', 'valeurs par défaut manquantes')
end) end)
