-- Modules 6 et 7 : Métiers et Gangs. Un seul constructeur (PB.GroupModule) pour les deux : tout passe par l'adaptateur
-- framework (PB.Fw), qui écrit en base (ESX) ou dans shared/jobs.lua / shared/gangs.lua (QBCore, Qbox).

local B, P, Fw = PB.B, PB.Perm, PB.Fw

local TEXT = {
    job = { id = 'jobs', label = 'Métiers', icon = 'briefcase', one = 'métier', order = 50, fallback = 'unemployed', file = 'jobs.json' },
    gang = { id = 'gangs', label = 'Gangs', icon = 'users', one = 'gang', order = 60, fallback = 'none', file = 'gangs.json' },
}

local function gradeRows(g)
    local rows = {}
    for _, x in ipairs(g and g.grades or {}) do rows[#rows + 1] = { grade = x.grade, name = x.name, label = x.label or x.name, salary = x.salary or 0, boss = x.boss and true or false } end
    return rows
end

function PB.GroupModule(kind)
    local T = TEXT[kind]
    local id = T.id
    P.Register(id .. '.edit', 'Créer et modifier les ' .. T.label:lower(), id)
    P.Register(id .. '.delete', 'Supprimer des ' .. T.label:lower(), id, true)
    P.Register(id .. '.assign', 'Attribuer un ' .. T.one .. ' à un joueur', id)
    P.Register(id .. '.io', 'Importer / exporter les ' .. T.label:lower(), id, true)

    local function find(name)
        local list = Fw.Groups(kind)
        for _, g in ipairs(list or {}) do if g.name == name then return g end end
    end

    PB.Action(id .. '.save', id .. '.edit', function(ctx, p)
        local v = p.values or {}
        local def, err = Fw.CleanGroup(kind, { name = v.name, label = v.label, type = v.type, defaultDuty = v.defaultDuty, offDutyPay = v.offDutyPay, grades = v.grades })
        if not def then return false, err end
        local before = find(def.name)
        if p.mode == 'create' and before then return false, 'Cet identifiant existe déjà.' end
        if p.mode == 'edit' and not before then return false, T.one:gsub('^%l', string.upper) .. ' introuvable.' end
        if before and before.readonly then return false, 'Ce ' .. T.one .. ' est en lecture seule.' end
        local ok, e, info = Fw.SaveGroup(kind, def, ctx.actor)
        if not ok then return false, e end
        ctx.audit('config', id .. (before and '.modifier' or '.creer'), def.name, before and { label = before.label, grades = #before.grades } or nil, { label = def.label, grades = #def.grades })
        ctx.toast = (before and 'Enregistré' or 'Créé') .. '.' .. ((info and info.note) and (' ' .. info.note) or '')
        return true, { open = { tab = 'editor', params = { name = def.name } } }
    end)

    PB.Action(id .. '.delete', id .. '.delete', function(ctx, p)
        local v = p.values or {}
        local name = tostring(p.name or v.name or '')
        local g = find(name)
        if not g then return false, 'Introuvable.' end
        if name == T.fallback then return false, 'Le ' .. T.one .. ' par défaut « ' .. T.fallback .. ' » ne peut pas être supprimé.' end
        local ok, e = Fw.DeleteGroup(kind, name, ctx.actor, T.fallback)
        if not ok then return false, e end
        ctx.audit('config', id .. '.supprimer', name, { label = g.label })
        ctx.toast = 'Supprimé. Les membres sont passés en « ' .. T.fallback .. ' ».'
        return true
    end, { critical = true, pin = true, confirm = { title = 'Supprimer ce ' .. T.one .. ' ?', text = 'Les membres sont déplacés vers « ' .. T.fallback .. ' ». Action définitive.' } })

    PB.Action(id .. '.assign', id .. '.assign', function(ctx, p)
        local v = p.values or {}
        local name = tostring(p.name or v.name or '')
        local g = find(name)
        if not g then return false, T.one:gsub('^%l', string.upper) .. ' introuvable.' end
        local grade = PB.ToInt(v.grade, nil)
        local okg = false
        for _, x in ipairs(g.grades) do if x.grade == grade then okg = true end end
        if not okg then return false, 'Ce grade n\'existe pas dans ' .. g.label .. '.' end
        local target = {}
        if tostring(v.player or '') ~= '' then
            local n = tonumber(v.player)
            if n and GetPlayerName(n) then target.src = n else target.id = tostring(v.player) end
        else return false, 'Choisis un joueur.' end
        local ok, e = Fw.Assign(kind, target, name, grade)
        if not ok then return false, e end
        ctx.audit('config', id .. '.attribuer', tostring(v.player), nil, { [kind] = name, grade = grade })
        ctx.toast = 'Attribué.'
        return true
    end)

    PB.Action(id .. '.fire', id .. '.assign', function(ctx, p)
        local target = {}
        local n = tonumber(p.member)
        if n and GetPlayerName(n) then target.src = n else target.id = tostring(p.member or '') end
        local fb = find(T.fallback)
        local ok, e = Fw.Assign(kind, target, T.fallback, fb and fb.grades[1] and fb.grades[1].grade or 0)
        if not ok then return false, e end
        ctx.audit('config', id .. '.retirer', tostring(p.member), nil, { [kind] = T.fallback })
        ctx.toast = 'Membre retiré.'
        return true
    end, { critical = true, confirm = { title = 'Retirer ce membre ?', text = 'Il passe en « ' .. T.fallback .. ' ».' } })

    PB.Action(id .. '.export', id .. '.io', function(ctx)
        local list = Fw.Groups(kind) or {}
        local out = {}
        for _, g in ipairs(list) do out[#out + 1] = Fw.CleanGroup(kind, g) or nil end
        ctx.audit('config', id .. '.export', T.file)
        return true, { download = { name = T.file, text = PB.Json({ format = 'pb_panel-' .. id, version = 1, groups = out }), mime = 'application/json' } }
    end, { read = true })

    PB.Action(id .. '.import', id .. '.io', function(ctx, p)
        local doc = PB.FromJson(tostring(p.values and p.values.json or ''), nil)
        if type(doc) ~= 'table' or doc.format ~= 'pb_panel-' .. id or type(doc.groups) ~= 'table' then return false, "Ce fichier n'est pas une exportation de ce module." end
        if #doc.groups > 200 then return false, 'Trop d\'entrées (200 maximum).' end
        local defs = {}
        for _, g in ipairs(doc.groups) do
            local d, err = Fw.CleanGroup(kind, g)
            if not d then return false, (tostring(g.name) .. ' : ' .. err) end
            defs[#defs + 1] = d
        end
        local n = 0
        for _, d in ipairs(defs) do
            local cur = find(d.name)
            if not (cur and cur.readonly) then
                local ok, e = Fw.SaveGroup(kind, d, ctx.actor)
                if not ok then return false, d.name .. ' : ' .. tostring(e) .. ' (' .. n .. ' déjà importé(s))' end
                n = n + 1
            end
        end
        ctx.audit('config', id .. '.import', T.file, nil, { count = n })
        ctx.toast = n .. ' importé(s).'
        return true
    end, { critical = true, pin = true, confirm = { title = 'Importer ces ' .. T.label:lower() .. ' ?', text = 'Les entrées existantes de même identifiant sont remplacées.' } })

    -- Création depuis un modèle (PB.Presets). Ne remplace jamais un groupe existant.
    local function fromPreset(ctx, pr)
        if find(pr.name) then return false, 'exists' end
        local def, err = Fw.CleanGroup(kind, { name = pr.name, label = pr.label, type = pr.type, defaultDuty = pr.defaultDuty, offDutyPay = pr.offDutyPay, grades = pr.grades })
        if not def then return false, err end
        local ok, e = Fw.SaveGroup(kind, def, ctx.actor)
        if not ok then return false, e end
        ctx.audit('config', id .. '.modele', def.name, nil, { label = def.label, grades = #def.grades })
        return true
    end

    PB.Action(id .. '.preset', id .. '.edit', function(ctx, p)
        local pr = PB.Presets.Find(kind, tostring(p.preset or (p.values and p.values.preset) or ''))
        if not pr then return false, 'Modèle introuvable.' end
        local ok, e = fromPreset(ctx, pr)
        if not ok then return false, e == 'exists' and ('« ' .. pr.name .. ' » existe déjà : modifie-le dans l\'éditeur.') or e end
        ctx.toast = pr.label .. ' créé.'
        return true, { open = { tab = 'editor', params = { name = pr.name } } }
    end)

    PB.Action(id .. '.presetall', id .. '.edit', function(ctx)
        local made, skipped = 0, 0
        for _, pr in ipairs(PB.Presets.List(kind)) do
            local ok, e = fromPreset(ctx, pr)
            if ok then made = made + 1
            elseif e == 'exists' then skipped = skipped + 1
            else return false, pr.name .. ' : ' .. tostring(e) .. ' (' .. made .. ' déjà créé(s))' end
        end
        ctx.toast = made .. ' créé(s)' .. (skipped > 0 and (', ' .. skipped .. ' déjà présent(s) ignoré(s)') or '') .. '.'
        return true
    end, { critical = true, confirm = { title = 'Créer tous les modèles ?', text = 'Les ' .. T.label:lower() .. ' qui existent déjà ne sont pas touchés.' } })

    PB.Module({
        id = id, label = T.label, icon = T.icon, group = 'Serveur', order = T.order, perm = id .. '.view', hint = 'Grades, salaires, effectifs',
        caps = function()
            local c = Fw.Caps(kind)
            c[#c + 1] = { feature = 'Emplacements (vestiaires, garages, coffres, blips)', status = 'partial', reason = 'Gérés dans le module Cartographie ; leur utilisation dépend du script concerné.' }
            return c
        end,
        doc = '## ' .. T.label .. "\nCréation et modification dans le framework détecté (base de données ou fichier partagé, avec sauvegarde). L'attribution agit sur les joueurs en ligne comme hors ligne.",
        view = function(ctx, params)
            local function tab(tid, label, icon, fn, perm) return { id = tid, label = label, icon = icon, build = fn, perm = perm } end
            local name = tostring(params and params.name or '')
            local function offline()
                local ok, why = Fw.Supports(kind == 'gang' and 'gangs' or 'jobs')
                if not ok then return { B.unsupported(T.label, why) } end
            end
            return { tabs = {
                tab('list', T.label, 'list', function()
                    local no = offline() if no then return no end
                    local list = Fw.Groups(kind) or {}
                    local rows, grades = {}, 0
                    for _, g in ipairs(list) do
                        grades = grades + #g.grades
                        local acts = { { nav = { tab = 'editor', params = { name = g.name } }, label = 'Modifier', icon = 'edit' }, { nav = { tab = 'members', params = { name = g.name } }, label = 'Effectifs', icon = 'users' } }
                        rows[#rows + 1] = { name = g.name, label = g.label, type = g.type or '', grades = #g.grades, ro = g.readonly and true or false, actions = acts }
                    end
                    return {
                        B.stats({ { label = T.label, value = #list, icon = T.icon }, { label = 'Grades', value = grades, icon = 'layers' }, { label = 'Framework', value = Fw.label, icon = 'box' } }),
                        B.table({ id = id, search = true, columns = { { k = 'name', label = 'Identifiant', type = 'mono' }, { k = 'label', label = 'Nom' }, { k = 'type', label = 'Type' }, { k = 'grades', label = 'Grades', type = 'num' }, { k = 'ro', label = 'Lecture seule', type = 'bool' } }, rows = rows, empty = 'Aucun ' .. T.one .. '.' }),
                    }
                end),
                tab('editor', 'Éditeur', 'edit', function()
                    local no = offline() if no then return no end
                    local list = Fw.Groups(kind) or {}
                    local opts = { { '', '— Nouveau ' .. T.one .. ' —' } }
                    for _, g in ipairs(list) do opts[#opts + 1] = { g.name, g.label .. ' (' .. g.name .. ')' } end
                    local g = name ~= '' and find(name) or nil
                    local fields = {
                        { k = 'name', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[a-z0-9_]+$', readonly = g ~= nil, hint = 'Minuscules, chiffres et _. Non modifiable ensuite.' },
                        { k = 'label', type = 'text', label = 'Nom affiché', required = true, maxlen = 48 },
                        { k = 'type', type = 'text', label = 'Type', maxlen = 24, hint = 'Ex. : leo, ems, mechanic (selon ton framework).' },
                        { k = 'defaultDuty', type = 'toggle', label = 'En service par défaut' },
                        { k = 'offDutyPay', type = 'toggle', label = 'Payé hors service' },
                        { k = 'grades', type = 'rows', label = 'Grades', wide = true, cols = {
                            { k = 'grade', label = 'Niveau', type = 'number', min = 0, max = 99 }, { k = 'name', label = 'Nom' }, { k = 'label', label = 'Affichage' },
                            { k = 'salary', label = 'Salaire', type = 'number', min = 0, max = 1000000 }, { k = 'boss', label = 'Patron', type = 'toggle' } } },
                    }
                    local values = g and { name = g.name, label = g.label, type = g.type or '', defaultDuty = g.defaultDuty and true or false, offDutyPay = g.offDutyPay and true or false, grades = gradeRows(g) }
                        or { name = '', label = '', type = '', defaultDuty = true, offDutyPay = false, grades = { { grade = 0, name = 'Recrue', label = 'Recrue', salary = 0, boss = false } } }
                    local blocks = {
                        { type = 'picker', id = 'name', label = T.label, options = opts, value = name },
                        { type = 'form', id = id .. '.edit', title = g and ('Modifier ' .. g.label) or ('Créer un ' .. T.one), cols = 2, fields = fields, values = values,
                            submit = (g and g.readonly) and nil or { action = id .. '.save', label = g and 'Enregistrer' or 'Créer', payload = { mode = g and 'edit' or 'create' } } },
                    }
                    if g and g.readonly then blocks[#blocks + 1] = B.notice('warn', 'Ce ' .. T.one .. " est en lecture seule dans ton framework : il n'est pas modifiable ici.") end
                    if g and not g.readonly and g.name ~= T.fallback then
                        blocks[#blocks + 1] = { type = 'form', id = id .. '.del', title = 'Supprimer', cols = 1, fields = {}, values = { name = g.name },
                            submit = { action = id .. '.delete', label = 'Supprimer ce ' .. T.one, danger = true, payload = { name = g.name } } }
                    end
                    return blocks
                end, id .. '.edit'),
                tab('presets', 'Modèles', 'layers', function()
                    local no = offline() if no then return no end
                    local rows = {}
                    for _, pr in ipairs(PB.Presets.List(kind)) do
                        local sal = 0
                        for _, x in ipairs(pr.grades) do if x.salary > sal then sal = x.salary end end
                        local exists = find(pr.name) ~= nil
                        rows[#rows + 1] = { name = pr.name, label = pr.label, type = pr.type or '', grades = #pr.grades, salary = sal, desc = pr.desc,
                            exists = exists and { text = 'Déjà créé', tone = 'off' } or { text = 'Disponible', tone = 'ok' },
                            actions = (not exists) and { { action = id .. '.preset', label = 'Créer', icon = 'plus', payload = { preset = pr.key } } } or { { nav = { tab = 'editor', params = { name = pr.name } }, label = 'Modifier', icon = 'edit' } } }
                    end
                    local blocks = { B.notice('info', 'Modèles prêts à l\'emploi : un clic crée le ' .. T.one .. ' avec ses grades et salaires, que tu ajustes ensuite dans l\'éditeur. Un ' .. T.one .. ' existant n\'est jamais écrasé.') }
                    blocks[#blocks + 1] = B.table({ id = id .. '.presets', search = true, columns = { { k = 'label', label = 'Modèle' }, { k = 'name', label = 'Identifiant', type = 'mono' }, { k = 'type', label = 'Type' }, { k = 'grades', label = 'Grades', type = 'num' }, { k = 'salary', label = 'Salaire max', type = 'num' }, { k = 'exists', label = 'État', type = 'badge' }, { k = 'desc', label = 'Description' } }, rows = rows, empty = 'Aucun modèle.' })
                    if ctx.has(id .. '.edit') then blocks[#blocks + 1] = B.actions({ { action = id .. '.presetall', label = 'Créer tous les modèles manquants', icon = 'plus' } }, 'Pack complet') end
                    return blocks
                end, id .. '.edit'),
                tab('members', 'Effectifs', 'users', function()
                    local no = offline() if no then return no end
                    local list = Fw.Groups(kind) or {}
                    local opts = {}
                    for _, g in ipairs(list) do opts[#opts + 1] = { g.name, g.label } end
                    local blocks = { { type = 'picker', id = 'name', label = T.label, options = opts, value = name } }
                    local g = name ~= '' and find(name) or nil
                    if not g then blocks[#blocks + 1] = B.notice('info', 'Choisis un ' .. T.one .. '.') return blocks end
                    local members, err = Fw.Members(kind, g.name)
                    if not members then blocks[#blocks + 1] = B.notice('error', err or 'Lecture impossible.') return blocks end
                    local rows = {}
                    for _, m in ipairs(members) do
                        rows[#rows + 1] = { name = m.name, grade = m.gradeLabel or m.grade, online = m.online and { text = 'En ligne', tone = 'ok' } or { text = 'Hors ligne', tone = 'off' },
                            actions = ctx.has(id .. '.assign') and { { action = id .. '.fire', label = 'Retirer', icon = 'trash', danger = true, payload = { member = m.src or m.id } } } or nil }
                    end
                    local gopts = {}
                    for _, x in ipairs(g.grades) do gopts[#gopts + 1] = { x.grade, x.name } end
                    blocks[#blocks + 1] = B.table({ id = id .. '.members', title = g.label .. ' — ' .. #rows .. ' membre(s)', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'online', label = 'Statut', type = 'badge' } }, rows = rows, empty = 'Aucun membre.' })
                    if ctx.has(id .. '.assign') then
                        blocks[#blocks + 1] = { type = 'form', id = id .. '.assign', title = 'Attribuer à un joueur', cols = 2, fields = {
                            { k = 'player', type = 'text', label = 'Joueur (ID en jeu ou identifiant du personnage)', required = true, maxlen = 64 },
                            { k = 'grade', type = 'select', label = 'Grade', options = gopts, required = true } },
                            values = { player = '', grade = gopts[1] and gopts[1][1] }, submit = { action = id .. '.assign', label = 'Attribuer', payload = { name = g.name } } }
                    end
                    return blocks
                end),
                tab('payroll', 'Salaires', 'coins', function()
                    local no = offline() if no then return no end
                    local rows, top = {}, 0
                    for _, g in ipairs(Fw.Groups(kind) or {}) do
                        for _, x in ipairs(g.grades) do
                            rows[#rows + 1] = { grp = g.label, grade = x.name, level = x.grade, salary = x.salary or 0, boss = x.boss and true or false }
                            if (x.salary or 0) > top then top = x.salary end
                        end
                    end
                    table.sort(rows, function(a, b) return a.salary > b.salary end)
                    return { B.stats({ { label = 'Salaire maximum', value = top, icon = 'coins' }, { label = 'Lignes', value = #rows, icon = 'list' } }),
                        B.table({ id = id .. '.pay', search = true, columns = { { k = 'grp', label = T.label:sub(1, -2) }, { k = 'grade', label = 'Grade' }, { k = 'level', label = 'Niveau', type = 'num' }, { k = 'salary', label = 'Salaire', type = 'num' }, { k = 'boss', label = 'Patron', type = 'bool' } }, rows = rows, empty = 'Aucun grade.' }) }
                end),
                tab('io', 'Import / export', 'download', function()
                    local no = offline() if no then return no end
                    return {
                        B.actions({ { action = id .. '.export', label = 'Exporter en JSON', icon = 'download' } }, 'Exportation'),
                        { type = 'form', id = id .. '.import', title = 'Importer', cols = 1, fields = { { k = 'json', type = 'area', label = 'Contenu JSON', required = true, rows = 10 } }, values = { json = '' },
                            submit = { action = id .. '.import', label = 'Importer' } },
                    }
                end, id .. '.io'),
            } }
        end,
    })
end

PB.GroupModule('job')
