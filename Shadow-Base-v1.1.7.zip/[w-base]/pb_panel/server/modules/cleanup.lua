-- Nettoyage des ressources arrêtées.
-- Au premier démarrage, le panel LISTE les ressources à l'état « arrêtée » (sans rien toucher) et attend ton accord, dans le panel
-- (Nettoyage) ou dans la console du serveur (pb_cleanup).
-- « Supprimer » = DÉSACTIVER : le fxmanifest du dossier est renommé en « fxmanifest.lua.pb-off ». La ressource disparaît du serveur
-- et ne peut plus être démarrée par erreur, mais rien n'est effacé : « Restaurer » la remet. Lua ne sait ni lister ni effacer un
-- dossier, donc les fichiers restants peuvent être supprimés à la main si tu le souhaites.

local B, P, R = PB.B, PB.Perm, PB.Res
PB.Cleanup = PB.Cleanup or {}
local C = PB.Cleanup

P.Register('cleanup.view', 'Voir les ressources arrêtées à nettoyer', 'resources')
P.Register('cleanup.apply', 'Désactiver ou restaurer des ressources arrêtées', 'resources', true)

PB.Cfg.Define('cleanup', { done = false, kept = {}, disabled = {} })

local SUFFIX = '.pb-off'
local MANIFESTS = { 'fxmanifest.lua', '__resource.lua' }
-- Ressources du serveur / indispensables : jamais proposées.
local SYSTEM = { chat = true, spawnmanager = true, mapmanager = true, sessionmanager = true, hardcap = true, baseevents = true,
    playernames = true, oxmysql = true, monitor = true, webpack = true, yarn = true, ['screenshot-basic'] = true, fivem = true }
local SYSTEM_CATS = { ['cfx-default'] = true, system = true, ['system-resources'] = true }

function C.CanRename() return type(os) == 'table' and type(os.rename) == 'function' end
-- Points d'injection pour les tests (le vrai serveur utilise os.rename).
C._rename = function(a, b) return os.rename(a, b) end

local function cfgGet(k, d) return PB.Cfg.Get('cleanup', k, d) end
local function cleanPath(p) return type(p) == 'string' and (p:gsub('\\', '/'):gsub('/+$', '')) or nil end

local function manifestOf(path)
    -- Le dossier doit contenir un manifeste : on teste par le renommage lui-même (pas de lecture de fichier binaire).
    for _, m in ipairs(MANIFESTS) do
        local f = io and io.open and io.open(path .. '/' .. m, 'rb')
        if f then f:close() return m end
    end
    return nil
end
C._manifestOf = manifestOf

-- Qui dépend de qui (uniquement parmi les ressources démarrées) ; une ressource arrêtée dont dépend une ressource active est gardée.
local function neededBy(name)
    local out = {}
    for _, n in ipairs(R.All()) do
        local st = GetResourceState(n)
        if st == 'started' or st == 'starting' then
            local deps = R.Deps(n)
            for _, d in ipairs(deps) do if d == name then out[#out + 1] = n end end
        end
    end
    return out
end

function C.Reason(name)
    if not R.Valid(name) then return 'nom invalide' end
    if name == GetCurrentResourceName() or R.Protected(name) or SYSTEM[name] then return 'ressource protégée' end
    if GetResourceState(name) ~= 'stopped' then return 'pas à l\'état arrêtée' end
    local cat = R.Category(name)
    if SYSTEM_CATS[cat] then return 'ressource système (' .. cat .. ')' end
    local kept = cfgGet('kept', {})
    if kept[name] then return 'marquée « à garder »' end
    local p = cleanPath(GetResourcePath and GetResourcePath(name))
    if not p or p == '' then return 'dossier introuvable' end
    local nb = neededBy(name)
    if #nb > 0 then return 'utilisée par ' .. table.concat(nb, ', ') end
    return nil, p
end

function C.Candidates()
    local out = {}
    for _, n in ipairs(R.All()) do
        if GetResourceState(n) == 'stopped' then
            local why, p = C.Reason(n)
            if not why then out[#out + 1] = { name = n, path = p, cat = R.Category(n) } end
        end
    end
    return out
end

-- Désactivation : renomme le manifeste. Renvoie ok, erreur.
function C.Disable(name, who)
    if not C.CanRename() then return false, "Ce serveur ne permet pas de renommer des fichiers depuis un script." end
    local why, p = C.Reason(name)
    if why then return false, name .. ' : ' .. why .. '.' end
    local m = manifestOf(p)
    if not m then return false, name .. ' : manifeste introuvable (déjà désactivée ?).' end
    local ok, err = C._rename(p .. '/' .. m, p .. '/' .. m .. SUFFIX)
    if not ok then return false, name .. ' : renommage refusé (' .. tostring(err) .. ').' end
    local dis = cfgGet('disabled', {})
    dis[name] = { path = p, manifest = m, at = os.time(), by = tostring(who or 'inconnu') }
    PB.Cfg.Set('cleanup', 'disabled', dis, 0, tostring(who or 'inconnu'))
    PB.Audit.Log('ressource', 'ressource.nettoyee', tostring(who or 'inconnu'), name, nil, nil, { path = p })
    return true
end

function C.Restore(name, who)
    local dis = cfgGet('disabled', {})
    local d = dis[name]
    if not d or not C.CanRename() then return false, 'Aucune désactivation enregistrée pour ' .. tostring(name) .. '.' end
    local ok, err = C._rename(d.path .. '/' .. d.manifest .. SUFFIX, d.path .. '/' .. d.manifest)
    if not ok then return false, name .. ' : restauration refusée (' .. tostring(err) .. ').' end
    dis[name] = nil
    PB.Cfg.Set('cleanup', 'disabled', dis, 0, tostring(who or 'inconnu'))
    PB.Audit.Log('ressource', 'ressource.restauree', tostring(who or 'inconnu'), name, nil, nil, { path = d.path })
    return true
end

local function refreshList() if ExecuteCommand then ExecuteCommand('refresh') end end

-- Applique à une liste de noms (jamais "tout" sans liste : seuls les noms fournis ET toujours candidats sont traités).
function C.DisableMany(names, who)
    local done, failed = 0, {}
    for _, n in ipairs(names) do
        local ok, err = C.Disable(tostring(n), who)
        if ok then done = done + 1 else failed[#failed + 1] = err end
    end
    if done > 0 then refreshList() end
    return done, failed
end

-- Actions du panel ----------------------------------------------------------------------------------------------------
PB.Action('cleanup.disable', 'cleanup.apply', function(ctx, p)
    local ok, err = C.Disable(tostring(p.res or ''), ctx.actor and ctx.actor.name)
    if not ok then return false, err end
    refreshList()
    PB.Cfg.Set('cleanup', 'done', true, 0, 'panel')
    ctx.audited = true
    ctx.toast = 'Ressource désactivée : ' .. tostring(p.res) .. ' (restaurable).'
    return true
end, { critical = true, confirm = { title = 'Désactiver cette ressource ?', text = 'Son fxmanifest est renommé : elle disparaît du serveur mais ses fichiers restent, tu peux la restaurer.' } })

PB.Action('cleanup.all', 'cleanup.apply', function(ctx, p)
    local names = {}
    for _, c in ipairs(C.Candidates()) do names[#names + 1] = c.name end
    local n, failed = C.DisableMany(names, ctx.actor and ctx.actor.name)
    PB.Cfg.Set('cleanup', 'done', true, 0, 'panel')
    ctx.audited = true
    ctx.toast = n .. ' ressource(s) désactivée(s).' .. (#failed > 0 and (' Échecs : ' .. table.concat(failed, ' ')) or '')
    return #failed == 0 or n > 0
end, { critical = true, confirm = { title = 'Désactiver toutes les ressources arrêtées listées ?', text = 'Seules les ressources affichées dans la liste sont concernées. Chacune peut être restaurée.' } })

PB.Action('cleanup.keep', 'cleanup.apply', function(ctx, p)
    local n = tostring(p.res or '')
    if not R.Valid(n) then return false, 'Nom invalide.' end
    local kept = cfgGet('kept', {})
    kept[n] = true
    PB.Cfg.Set('cleanup', 'kept', kept, 0, ctx.actor and ctx.actor.name or 'panel')
    ctx.toast = n .. ' sera gardée (plus proposée).'
    return true
end)

PB.Action('cleanup.unkeep', 'cleanup.apply', function(ctx, p)
    local kept = cfgGet('kept', {})
    kept[tostring(p.res or '')] = nil
    PB.Cfg.Set('cleanup', 'kept', kept, 0, ctx.actor and ctx.actor.name or 'panel')
    ctx.toast = 'De nouveau proposée.'
    return true
end)

PB.Action('cleanup.restore', 'cleanup.apply', function(ctx, p)
    local ok, err = C.Restore(tostring(p.res or ''), ctx.actor and ctx.actor.name)
    if not ok then return false, err end
    refreshList()
    ctx.audited = true
    ctx.toast = 'Ressource restaurée : ' .. tostring(p.res) .. '. Fais « ensure » pour la démarrer.'
    return true
end, { critical = true, confirm = { title = 'Restaurer cette ressource ?', text = 'Le fxmanifest retrouve son nom ; la ressource redevient démarrable.', danger = false } })

PB.Action('cleanup.dismiss', 'cleanup.apply', function(ctx)
    PB.Cfg.Set('cleanup', 'done', true, 0, ctx.actor and ctx.actor.name or 'panel')
    ctx.toast = 'Compris : plus de rappel au démarrage.'
    return true
end)

-- Module --------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'cleanup', label = 'Nettoyage', icon = 'trash', group = 'Pilotage', order = 45, perm = 'cleanup.view', hint = 'Ressources arrêtées à retirer',
    caps = function()
        return PB.Capsify({
            { 'Lister les ressources arrêtées', 'ok', 'Les ressources système, protégées ou utilisées par une ressource active ne sont jamais proposées.' },
            { 'Désactiver (avec ton accord)', C.CanRename() and 'ok' or 'off', 'Renomme le fxmanifest en .pb-off ; restaurable à tout moment.' },
            { 'Effacer les fichiers du dossier', 'off', "Lua ne peut ni lister ni supprimer un dossier : supprime-le à la main si tu veux libérer la place." },
        })
    end,
    doc = "## Nettoyage\nAu premier démarrage, les ressources **arrêtées** sont listées. Rien n'est modifié sans ton accord (bouton ici, ou `pb_cleanup apply` dans la console). La désactivation est réversible.",
    view = function(ctx) return { tabs = { { id = 'list', label = 'Ressources arrêtées', icon = 'trash', build = function()
        local cands = C.Candidates()
        local blocks = {}
        if not cfgGet('done', false) and #cands > 0 then
            blocks[#blocks + 1] = B.notice('warn', #cands .. " ressource(s) arrêtée(s) détectée(s) au premier démarrage. Choisis ce que tu désactives ci-dessous.", 'Autorisation demandée')
        end
        if not C.CanRename() then blocks[#blocks + 1] = B.notice('error', "Ce serveur ne permet pas de renommer des fichiers depuis un script : le nettoyage automatique est indisponible.") end
        local rows = {}
        for _, c in ipairs(cands) do
            rows[#rows + 1] = { name = c.name, cat = c.cat, path = c.path, actions = {
                { action = 'cleanup.disable', label = 'Désactiver', icon = 'trash', danger = true, payload = { res = c.name } },
                { action = 'cleanup.keep', label = 'Garder', icon = 'check', payload = { res = c.name } } } }
        end
        blocks[#blocks + 1] = B.stats({ { label = 'À nettoyer', value = #cands, icon = 'trash' }, { label = 'Désactivées', value = PB.Count(cfgGet('disabled', {})), icon = 'stop' }, { label = 'Gardées', value = PB.Count(cfgGet('kept', {})), icon = 'check' } })
        blocks[#blocks + 1] = B.table({ id = 'cl', title = 'Ressources arrêtées', search = true, columns = { { k = 'name', label = 'Ressource', type = 'mono' }, { k = 'cat', label = 'Catégorie' }, { k = 'path', label = 'Dossier', type = 'mono' } }, rows = rows, empty = 'Aucune ressource arrêtée à nettoyer.' })
        if #cands > 0 and C.CanRename() then
            blocks[#blocks + 1] = B.actions({ { action = 'cleanup.all', label = 'Tout désactiver (' .. #cands .. ')', icon = 'trash', danger = true }, { action = 'cleanup.dismiss', label = 'Ne plus me le proposer', icon = 'close' } })
        end
        local dr = {}
        for n, d in pairs(cfgGet('disabled', {})) do
            dr[#dr + 1] = { name = n, at = d.at, by = d.by, path = d.path, actions = { { action = 'cleanup.restore', label = 'Restaurer', icon = 'undo', payload = { res = n } } } }
        end
        table.sort(dr, function(a, b) return a.name < b.name end)
        blocks[#blocks + 1] = B.table({ id = 'cld', title = 'Déjà désactivées', columns = { { k = 'name', label = 'Ressource', type = 'mono' }, { k = 'at', label = 'Date', type = 'date' }, { k = 'by', label = 'Par' }, { k = 'path', label = 'Dossier', type = 'mono' } }, rows = dr, empty = 'Aucune.' })
        local kr = {}
        for n in pairs(cfgGet('kept', {})) do kr[#kr + 1] = { name = n, actions = { { action = 'cleanup.unkeep', label = 'Reproposer', icon = 'undo', payload = { res = n } } } } end
        table.sort(kr, function(a, b) return a.name < b.name end)
        if #kr > 0 then blocks[#blocks + 1] = B.table({ id = 'clk', title = 'Gardées', columns = { { k = 'name', label = 'Ressource', type = 'mono' } }, rows = kr, empty = '' }) end
        return blocks
    end } } } end,
})

-- Premier démarrage : on LISTE seulement, on demande l'accord, on ne touche à rien.
local function printList(cands)
    print('^3[pb_panel]^7 Ressources arrêtées détectées (' .. #cands .. ') :')
    for _, c in ipairs(cands) do print('   - ' .. c.name .. '  (' .. c.path .. ')') end
    print("^3[pb_panel]^7 Pour les désactiver : panel › Nettoyage, ou console « pb_cleanup apply ». Pour ignorer : « pb_cleanup skip ». Rien n'est modifié sans ton accord.")
end

PB.OnReady(function()
    if cfgGet('done', false) then return end
    local cands = C.Candidates()
    if #cands == 0 then return end
    SetTimeout(5000, function() printList(C.Candidates()) end)
end)

-- Console du serveur uniquement : pb_cleanup list | apply | skip | restore <nom>
RegisterCommand('pb_cleanup', function(src, args)
    if src ~= 0 then return end
    local a = tostring(args[1] or 'list'):lower()
    if a == 'list' then
        local c = C.Candidates()
        if #c == 0 then print('[pb_panel] Aucune ressource arrêtée à nettoyer.') else printList(c) end
    elseif a == 'apply' then
        local names = {}
        for _, c in ipairs(C.Candidates()) do names[#names + 1] = c.name end
        local n, failed = C.DisableMany(names, 'console')
        PB.Cfg.Set('cleanup', 'done', true, 0, 'console')
        print('[pb_panel] ' .. n .. ' ressource(s) désactivée(s).')
        for _, f in ipairs(failed) do print('   ! ' .. f) end
    elseif a == 'skip' then
        PB.Cfg.Set('cleanup', 'done', true, 0, 'console')
        print('[pb_panel] Compris, plus de rappel au démarrage.')
    elseif a == 'restore' then
        local ok, err = C.Restore(tostring(args[2] or ''), 'console')
        if ok then refreshList() print('[pb_panel] Restaurée : ' .. tostring(args[2])) else print('[pb_panel] ' .. tostring(err)) end
    else print('[pb_panel] pb_cleanup list | apply | skip | restore <ressource>') end
end, true)

PB.OnReady(function() PB.SelfTest.Add('nettoyage: renommage possible et ressources protégées', function(R2)
    R2.check(C.CanRename(), 'Nettoyage', 'os.rename indisponible', 'Le nettoyage ne pourra pas désactiver de ressource sur ce serveur.')
    R2.check(C.Reason(GetCurrentResourceName()) ~= nil, 'Nettoyage', 'le panel doit être protégé du nettoyage')
    R2.check(C.Reason('oxmysql') ~= nil, 'Nettoyage', 'oxmysql doit être protégé')
end) end)
