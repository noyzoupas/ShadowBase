-- Module 16 : Sauvegardes (configuration du panel, fichiers, base de données), planification, rétention, envoi distant, restauration.

local B, P, Form, F, DB = PB.B, PB.Perm, PB.Form, PB.Files, PB.DB

P.Register('backups.create', 'Créer une sauvegarde', 'backups')
P.Register('backups.restore', 'Restaurer une sauvegarde', 'backups', true)
P.Register('backups.download', 'Télécharger une sauvegarde', 'backups', true)
P.Register('backups.delete', 'Supprimer une sauvegarde', 'backups', true)
P.Register('backups.settings', 'Planifier les sauvegardes', 'backups', true)

PB.Migrate('023_backups', 'Sauvegardes', {
    [[CREATE TABLE IF NOT EXISTS pb_backups (
        id INT NOT NULL AUTO_INCREMENT, kind VARCHAR(12) NOT NULL, name VARCHAR(96) NOT NULL DEFAULT '', size INT NOT NULL DEFAULT 0,
        checksum VARCHAR(16) NOT NULL DEFAULT '', actor VARCHAR(96) NOT NULL DEFAULT '', auto TINYINT(1) NOT NULL DEFAULT 0,
        remote VARCHAR(16) NOT NULL DEFAULT '', content LONGTEXT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id))]],
})

local KINDS = { config = 'Configuration du panel', files = 'Fichiers (server.cfg + ressources choisies)', database = 'Base de données' }
local MAX_BYTES = 30 * 1024 * 1024
local SKIP_NS = { prefs = true, security = true, monitor = true }

local settings = Form.Cfg({
    ns = 'backups', id = 'settings', title = 'Planification et rétention', perm = 'backups.settings', cols = 2,
    desc = "Les sauvegardes sont stockées dans la base du panel. Pour les mettre à l'abri d'une panne du serveur, active l'envoi distant.",
    fields = {
        { k = 'auto', type = 'toggle', label = 'Sauvegarde automatique quotidienne', default = false },
        { k = 'auto_time', type = 'time', label = 'Heure (heure du serveur)', default = '04:30' },
        { k = 'auto_kinds', type = 'multi', label = 'Types sauvegardés', opts = { { 'config', 'Configuration du panel' }, { 'files', 'Fichiers' }, { 'database', 'Base de données' } }, default = { 'config', 'files' } },
        { k = 'files_resources', type = 'tags', label = 'Ressources dont les fichiers sont sauvegardés', default = {}, pattern = '^[%w_%-%.]+$', hint = 'Ex. : qb-core, ox_inventory. Le server.cfg est toujours inclus.' },
        { k = 'keep', type = 'number', label = 'Sauvegardes conservées par type', default = 7, min = 1, max = 60 },
        { k = 'remote', type = 'toggle', label = 'Envoyer chaque sauvegarde à une adresse distante (HTTP PUT)', default = false },
        { k = 'remote_url', type = 'secret', label = 'Adresse distante (https)', hint = "Stockée comme un secret, jamais réaffichée. L'adresse doit accepter un PUT." },
    },
})

local function realServerCfg()
    local path = F.ServerCfgPath()
    if not path then return nil end
    local f = io.open(path, 'rb')
    if not f then return nil end
    local d = f:read('*a') f:close()
    return d
end

local builders = {}
function builders.config()
    local out = {}
    for _, r in ipairs(DB.q('SELECT ns, k, v FROM pb_kv ORDER BY ns, k') or {}) do
        if not SKIP_NS[r.ns] and r.ns:sub(1, 6) ~= 'prefs:' then out[r.ns] = out[r.ns] or {} out[r.ns][r.k] = PB.FromJson(r.v, nil) end
    end
    return PB.Json({ format = 'pb_panel-backup-config', version = 1, kv = out })
end
function builders.files()
    local files = {}
    local cfg = realServerCfg()
    if cfg then files[#files + 1] = { res = '@server', path = 'server.cfg', content = cfg } end
    local total = cfg and #cfg or 0
    for _, res in ipairs(PB.Cfg.Get('backups', 'files_resources', {})) do
        if res ~= GetCurrentResourceName() then
            for _, f in ipairs(F.ListFiles(res) or {}) do
                if f.path ~= 'fxmanifest.lua' then
                    local data = F.Read(res, f.path)
                    if data then
                        total = total + #data
                        if total > MAX_BYTES then return nil, 'Fichiers trop volumineux (' .. PB.FormatBytes(MAX_BYTES) .. ' maximum).' end
                        files[#files + 1] = { res = res, path = f.path, content = data }
                    end
                end
            end
        end
    end
    return PB.Json({ format = 'pb_panel-backup-files', version = 1, files = files })
end
function builders.database()
    local text, sum = PB.Dump.Build(PB.Dump.Tables(), { maxRows = 500000 })
    if not text then return nil, sum end
    if #text > MAX_BYTES then return nil, 'Base trop volumineuse pour une sauvegarde dans la base (' .. PB.FormatBytes(#text) .. ') : utilise mysqldump hors du panel.' end
    if #sum.truncated > 0 then return nil, 'Tables tronquées (' .. table.concat(sum.truncated, ', ') .. ') : sauvegarde refusée plutôt qu\'incomplète.' end
    return text
end

local function prune(kind)
    local keep = PB.Cfg.Get('backups', 'keep', 7)
    local old = DB.q('SELECT id FROM pb_backups WHERE kind = ? ORDER BY id DESC LIMIT 1000 OFFSET ' .. keep, { kind }) or {}
    for _, r in ipairs(old) do DB.exec('DELETE FROM pb_backups WHERE id = ?', { r.id }) end
end

local function sendRemote(id, kind, content)
    if not PB.Cfg.Get('backups', 'remote', false) then return end
    local url = PB.Secret.Get('backups_remote_url')
    if not url or not url:match('^https://') then return end
    local name = ('%s-%s-%d'):format(kind, os.date('!%Y%m%d-%H%M%S'), id)
    local pr = promise.new()
    PerformHttpRequest(url:gsub('/$', '') .. '/' .. name, function(status) pr:resolve(status) end, 'PUT', content, { ['Content-Type'] = 'application/octet-stream' })
    local status = Citizen.Await(pr)
    local okS = tonumber(status) and status >= 200 and status < 300
    DB.exec('UPDATE pb_backups SET remote = ? WHERE id = ?', { okS and 'ok' or ('échec ' .. tostring(status)), id })
    return okS
end

function PB.CreateBackup(kind, actor, auto)
    if not builders[kind] then return nil, 'Type inconnu.' end
    local content, err = builders[kind]()
    if not content then return nil, err end
    local a = PB.Actor(actor)
    local id = DB.insert('INSERT INTO pb_backups (kind, name, size, checksum, actor, auto, content) VALUES (?, ?, ?, ?, ?, ?, ?)',
        { kind, (auto and 'auto-' or 'manuel-') .. os.date('!%Y%m%d-%H%M%S'), #content, PB.Checksum(content), a.name:sub(1, 96), auto and 1 or 0, content })
    if not id then return nil, 'Écriture de la sauvegarde impossible.' end
    prune(kind)
    sendRemote(id, kind, content)
    PB.Audit.Log('sauvegarde', 'sauvegarde.creer', actor, kind .. ' #' .. id, nil, { size = #content, auto = auto and true or false })
    return id
end

-- Planification
CreateThread(function()
    local last
    while true do
        Wait(60000)
        if PB.IsReady and PB.Cfg.Get('backups', 'auto', false) then
            local now = os.date('%H:%M')
            local day = os.date('%Y%m%d')
            if now == PB.Cfg.Get('backups', 'auto_time', '04:30') and last ~= day then
                last = day
                for _, k in ipairs(PB.Cfg.Get('backups', 'auto_kinds', {})) do
                    local id, err = PB.CreateBackup(k, 'planification', true)
                    if not id then PB.Err('sauvegarde automatique ' .. k .. ' : ' .. tostring(err)) PB.Notify('warn', 'Sauvegarde automatique échouée', k .. ' : ' .. tostring(err), 'backups.view') end
                end
            end
        end
    end
end)

PB.Action('backups.create', 'backups.create', function(ctx, p)
    local kind = tostring(p.kind or '')
    local id, err = PB.CreateBackup(kind, ctx.actor, false)
    if not id then return false, err end
    ctx.audited = true
    ctx.toast = 'Sauvegarde #' .. id .. ' créée.'
    return true
end, { rate = 6 })

PB.Action('backups.delete', 'backups.delete', function(ctx, p)
    local id = PB.ToInt(p.id, 0)
    local b = DB.one('SELECT id, kind FROM pb_backups WHERE id = ?', { id })
    if not b then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_backups WHERE id = ?', { id })
    ctx.audit('sauvegarde', 'sauvegarde.supprimer', '#' .. id, { kind = b.kind })
    ctx.toast = 'Supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette sauvegarde ?', text = 'Elle ne pourra plus être restaurée.' } })

PB.Action('backups.download', 'backups.download', function(ctx, p)
    local b = DB.one('SELECT * FROM pb_backups WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not b then return false, 'Introuvable.' end
    ctx.audit('sauvegarde', 'sauvegarde.telecharger', '#' .. b.id)
    return true, { download = { name = b.name .. (b.kind == 'database' and '.sql' or '.json'), text = b.content or '', mime = b.kind == 'database' and 'application/sql' or 'application/json' } }
end, { critical = true, pin = true, rate = 5, confirm = { title = 'Télécharger cette sauvegarde ?', text = 'Elle peut contenir des secrets (server.cfg) ou des données de joueurs.', danger = false } })

PB.Action('backups.verify', 'backups.view', function(ctx, p)
    local b = DB.one('SELECT * FROM pb_backups WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not b then return false, 'Introuvable.' end
    local ok = PB.Checksum(b.content or '') == b.checksum
    ctx.toast = ok and 'Intégrité vérifiée : le contenu correspond à la somme de contrôle.' or 'Contenu altéré : la somme de contrôle ne correspond plus.'
    ctx.refresh = false
    return ok, ok and nil or 'Sauvegarde corrompue.'
end, { read = true })

PB.Action('backups.restore', 'backups.restore', function(ctx, p)
    local b = DB.one('SELECT * FROM pb_backups WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not b then return false, 'Introuvable.' end
    if PB.Checksum(b.content or '') ~= b.checksum then return false, 'Sauvegarde corrompue : restauration refusée.' end
    local msg
    if b.kind == 'config' then
        local doc = PB.FromJson(b.content, nil)
        if type(doc) ~= 'table' or type(doc.kv) ~= 'table' then return false, 'Contenu invalide.' end
        local n = 0
        for ns, tbl in pairs(doc.kv) do
            if not SKIP_NS[ns] and type(tbl) == 'table' then for k, v in pairs(tbl) do if PB.Cfg.Set(ns, k, v, ctx.actor, 'Restauration #' .. b.id) then n = n + 1 end end end
        end
        msg = n .. ' valeur(s) de configuration restaurée(s).'
    elseif b.kind == 'files' then
        local doc = PB.FromJson(b.content, nil)
        if type(doc) ~= 'table' or type(doc.files) ~= 'table' then return false, 'Contenu invalide.' end
        local n = 0
        for _, f in ipairs(doc.files) do
            local ok, e
            if f.res == '@server' then ok, e = F.CfgWriteRaw(f.content, ctx.actor, 'Restauration #' .. b.id)
            else ok, e = F.Write(f.res, f.path, f.content, ctx.actor, 'Restauration #' .. b.id) end
            if not ok then return false, tostring(f.res) .. '/' .. tostring(f.path) .. ' : ' .. tostring(e) .. ' (' .. n .. ' fichier(s) déjà restauré(s))' end
            n = n + 1
        end
        msg = n .. ' fichier(s) restauré(s). Redémarre le serveur pour appliquer.'
    elseif b.kind == 'database' then
        local stmts, err = PB.Dump.Parse(b.content)
        if not stmts then return false, err end
        local q = {}
        for _, s in ipairs(stmts) do
            local t = s:match('^DELETE FROM `([%w_]+)`') or s:match('^INSERT INTO `([%w_]+)`')
            if t ~= 'pb_migrations' and t ~= 'pb_backups' then q[#q + 1] = { query = s } end
        end
        local ok, e = DB.tx(q)
        if not ok then return false, 'Restauration annulée, base inchangée : ' .. tostring(e) end
        msg = #q .. ' instruction(s) appliquées (les sauvegardes du panel sont conservées).'
    else return false, 'Type inconnu.' end
    ctx.audit('sauvegarde', 'sauvegarde.restaurer', '#' .. b.id, nil, { kind = b.kind })
    ctx.toast = msg
    return true
end, { critical = true, pin = true, confirm = { title = 'Restaurer cette sauvegarde ?', text = "L'état actuel est remplacé. Crée d'abord une sauvegarde récente si tu as un doute." } })

PB.Module({
    id = 'backups', label = 'Sauvegardes', icon = 'archive', group = 'Système', order = 150, perm = 'backups.view', hint = 'Planification, rétention, restauration',
    caps = function()
        return PB.Capsify({
            { 'Configuration du panel', 'ok', 'Export JSON de toutes les valeurs du panel.' },
            { 'Fichiers (server.cfg et ressources choisies)', F.ServerCfgPath() and 'ok' or 'partial', 'Le server.cfg est inclus avec ses secrets : les sauvegardes sont protégées par permission et PIN.' },
            { 'Base de données', 'partial', 'Export SQL stocké dans la base, limité à ' .. PB.FormatBytes(MAX_BYTES) .. '. Au-delà : mysqldump hors du panel.' },
            { 'Planification quotidienne', 'ok', 'Une heure par jour, heure du serveur.' },
            { 'Envoi distant', 'partial', 'HTTP PUT vers une adresse https de ton choix (S3 pré-signé, WebDAV...). Pas d\'authentification propriétaire intégrée.' },
            { 'Sauvegarde du dossier complet du serveur', 'off', "Hors du périmètre : un script Lua ne peut pas archiver le disque." },
        })
    end,
    doc = "## Sauvegardes\nLes sauvegardes sont vérifiées par somme de contrôle avant restauration. Pense à tester une restauration sur un serveur de test.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('list', 'Sauvegardes', 'archive', function()
                local rows, total = {}, 0
                for _, b in ipairs(DB.q('SELECT id, kind, name, size, checksum, actor, auto, remote, created_at FROM pb_backups ORDER BY id DESC LIMIT 100') or {}) do
                    total = total + (b.size or 0)
                    local acts = { { action = 'backups.verify', label = 'Vérifier', icon = 'check', payload = { id = b.id } } }
                    if ctx.has('backups.restore') then acts[#acts + 1] = { action = 'backups.restore', label = 'Restaurer', icon = 'undo', danger = true, payload = { id = b.id } } end
                    if ctx.has('backups.download') then acts[#acts + 1] = { action = 'backups.download', label = 'Télécharger', icon = 'download', payload = { id = b.id } } end
                    if ctx.has('backups.delete') then acts[#acts + 1] = { action = 'backups.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = b.id } } end
                    rows[#rows + 1] = { at = b.created_at, kind = KINDS[b.kind] or b.kind, name = b.name, size = PB.FormatBytes(b.size or 0), by = b.auto == 1 and 'Planification' or b.actor, remote = b.remote or '', actions = acts }
                end
                local create = {}
                if ctx.has('backups.create') then for k, l in pairs(KINDS) do create[#create + 1] = { action = 'backups.create', label = 'Sauvegarder : ' .. l, icon = 'plus', payload = { kind = k } } end end
                table.sort(create, function(a, b) return a.label < b.label end)
                return { B.stats({ { label = 'Sauvegardes', value = #rows, icon = 'archive' }, { label = 'Taille totale', value = PB.FormatBytes(total), icon = 'hard-drive' } }),
                    #create > 0 and B.actions(create, 'Créer maintenant') or nil,
                    B.table({ id = 'bk', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'kind', label = 'Type' }, { k = 'name', label = 'Nom', type = 'mono' }, { k = 'size', label = 'Taille' }, { k = 'by', label = 'Par' }, { k = 'remote', label = 'Envoi distant' } }, rows = rows, empty = "Aucune sauvegarde. Crée la première avant de modifier quoi que ce soit." }) }
            end),
            tab('settings', 'Planification', 'clock', function() return { settings(ctx) } end, 'backups.settings'),
        } }
    end,
})
