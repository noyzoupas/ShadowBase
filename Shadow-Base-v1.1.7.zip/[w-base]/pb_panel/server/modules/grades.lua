-- Module 2 : Grades administrateurs et permissions.
-- Interface du système UNIQUE de grades (PB.Perm), synchronisé avec la librairie admin existante.

local B, P, F, FC = PB.B, PB.Perm, PB.Files, PB.FileCfg

P.Register('grades.edit', 'Créer et modifier les grades et leurs permissions', 'grades', true)
P.Register('grades.delete', 'Supprimer des grades', 'grades', true)
P.Register('grades.assign', "Attribuer et retirer les grades de l'équipe", 'grades', true)
P.Register('grades.sync', 'Synchroniser avec la librairie admin', 'grades', true)
P.Register('grades.ace', 'Gérer les groupes et principals ACE', 'grades', true)

local ICONS = { 'shield', 'crown', 'gavel', 'help', 'briefcase', 'wrench', 'code', 'star', 'eye', 'bolt', 'heart', 'user', 'users', 'key', 'flag', 'bug' }

local function gradeOpts(withNone, exceptName)
    local out = {}
    if withNone then out[#out + 1] = { '', '— aucun —' } end
    for _, g in ipairs(P.Grades()) do
        if g.name ~= exceptName then out[#out + 1] = { g.name, g.label .. ' (' .. g.name .. ')' } end
    end
    return out
end

local function countKeys(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end

-- Grille de permissions d'un jeu de règles (grade ou exceptions d'un membre) -------------------------------------------------------
local function permGrid(id, title, rules, explain, submit)
    local groups, order, byGroup = {}, {}, {}
    local isCatalog = {}
    for _, c in ipairs(P.Catalog()) do
        isCatalog[c.perm] = true
        local g = byGroup[c.group]
        if not g then g = { id = c.group, label = c.group, perms = {} } byGroup[c.group] = g order[#order + 1] = g end
        local own = rules[c.perm]
        local e = explain(c.perm)
        g.perms[#g.perms + 1] = { perm = c.perm, label = c.label, danger = c.danger, own = own == true and 'allow' or (own == false and 'deny' or nil),
            eff = e.allowed, rule = e.rule, from = e.from }
    end
    table.sort(order, function(a, b) return a.id < b.id end)
    local extra = {}
    for pat, allow in pairs(rules) do
        if not isCatalog[pat] then extra[#extra + 1] = { pat = pat, allow = allow } end
    end
    table.sort(extra, function(a, b) return a.pat < b.pat end)
    return { type = 'permgrid', id = id, title = title, groups = order, rules = extra, submit = submit,
        help = "Autorisé / Refusé / Hérité. La règle la plus précise l'emporte ; à précision égale, le refus l'emporte. Les motifs (ex. jobs.* ou *.view) s'ajoutent en bas." }
end

local function parseRules(raw)
    local rules = {}
    for pat, v in pairs(raw or {}) do
        if type(pat) == 'string' then rules[pat] = (v == true or v == 'allow' or v == 1) end
    end
    return rules
end

-- Actions : grades -----------------------------------------------------------------------------------------------------------------------------
PB.Action('grades.save', 'grades.edit', function(ctx, p)
    local v = p.values or {}
    local mode = p.mode == 'edit' and 'edit' or 'create'
    local name = mode == 'edit' and tostring(p.original or '') or tostring(v.name or '')
    local existing = P.Grade(name)
    if mode == 'edit' and not existing then return false, 'Grade introuvable.' end
    if mode == 'create' and existing then return false, 'Cet identifiant existe déjà.' end
    local principals = v.principals
    if not ctx.has('grades.ace') and existing then principals = existing.principals end
    local ok, err = P.SaveGrade(ctx.src, {
        name = name, label = v.label, color = v.color, icon = v.icon, level = v.level, parent = (v.parent ~= '' and v.parent or nil),
        principals = principals or {}, perms = existing and existing.perms or {},
    })
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = mode == 'edit' and 'Grade enregistré.' or 'Grade créé. Règle maintenant ses permissions.'
    return true, { name = name, open = { tab = 'editor', params = { grade = name } } }
end)

PB.Action('grades.perms.save', 'grades.edit', function(ctx, p)
    local g = P.Grade(tostring(p.grade or ''))
    if not g then return false, 'Grade introuvable.' end
    local ok, err = P.SaveGrade(ctx.src, { name = g.name, label = g.label, color = g.color, icon = g.icon, level = g.level, parent = g.parent, principals = g.principals, perms = parseRules(p.rules) })
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Permissions enregistrées et synchronisées.'
    return true
end)

PB.Action('grades.duplicate', 'grades.edit', function(ctx, p)
    local v = p.values or {}
    local ok, err = P.DuplicateGrade(ctx.src, tostring(v.source or ''), tostring(v.name or ''), tostring(v.label or ''))
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Grade dupliqué.'
    return true
end)

PB.Action('grades.rename', 'grades.edit', function(ctx, p)
    local v = p.values or {}
    local ok, err = P.RenameGrade(ctx.src, tostring(v.grade or ''), tostring(v.name or ''))
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Grade renommé : tous les membres et les héritages ont été mis à jour.'
    return true
end, { critical = true, confirm = { title = 'Renommer ce grade ?', text = "L'identifiant change partout (équipe, héritage, groupes ACE). Les scripts qui utilisent l'ancien identifiant devront être mis à jour.", danger = false } })

PB.Action('grades.delete', 'grades.delete', function(ctx, p)
    local v = p.values or {}
    local ok, err = P.DeleteGrade(ctx.src, tostring(v.grade or ''), (v.moveTo and v.moveTo ~= '') and v.moveTo or nil)
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Grade supprimé.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Supprimer ce grade ?', text = "Les membres seront déplacés vers le grade de remplacement choisi. Cette action est définitive." } })

PB.Action('grades.copyperms', 'grades.edit', function(ctx, p)
    local v = p.values or {}
    local ok, err = P.CopyPerms(ctx.src, tostring(v.from or ''), tostring(v.to or ''))
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Permissions copiées.'
    return true
end, { critical = true, confirm = { title = 'Remplacer les permissions ?', text = 'Les règles du grade cible sont remplacées par celles du grade source.', danger = false } })

-- Actions : équipe ---------------------------------------------------------------------------------------------------------------------------
PB.Action('grades.staff.set', 'grades.assign', function(ctx, p)
    local v = p.values or {}
    local license = PB.Trim(tostring(v.player or '') ~= '' and tostring(v.player) or tostring(v.license or ''))
    local name = tostring(v.name or '')
    if name == '' then
        for _, id in ipairs(GetPlayers()) do
            if P.GetLicense(tonumber(id)) == license then name = GetPlayerName(tonumber(id)) or '' end
        end
    end
    local ok, err = P.SetStaff(ctx.src, license, name, tostring(v.grade or ''))
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Grade attribué.'
    return true
end)

PB.Action('grades.staff.remove', 'grades.assign', function(ctx, p)
    local ok, err = P.SetStaff(ctx.src, tostring(p.id or ''), '', nil)
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = "Membre retiré de l'équipe."
    return true
end, { critical = true, pin = true, confirm = { title = "Retirer ce membre de l'équipe ?", text = "Il perd immédiatement l'accès au panel et ses permissions." } })

PB.Action('grades.staff.perms', 'grades.assign', function(ctx, p)
    local ok, err = P.SetStaffPerms(ctx.src, tostring(p.id or ''), parseRules(p.rules))
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'Exceptions enregistrées.'
    return true
end)

-- Actions : librairie admin ----------------------------------------------------------------------------------------------------------------------
PB.Action('grades.sync', 'grades.sync', function(ctx)
    local res = P.SyncAll()
    ctx.toast = 'Synchronisation envoyée' .. (res.pushed and (' (' .. res.pushed .. ' grade(s) poussé(s) vers la librairie)') or ' (groupes ACE mis à jour)') .. '.'
    return true, res
end, { audit = nil })

PB.Action('grades.import', 'grades.sync', function(ctx)
    local ok, err, n = P.ImportFromLib(ctx.src)
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = n .. ' grade(s) importé(s) depuis la librairie. Règle leurs permissions dans l\'éditeur.'
    return true
end, { critical = true, confirm = { title = 'Importer les grades de la librairie ?', text = "Les grades inconnus du panel sont créés (sans permission) ; rien n'est supprimé.", danger = false } })

PB.Action('grades.libtest', 'grades.view', function(ctx)
    return true, PB.AdminLib.Test()
end, { read = true })

-- Actions : ACE --------------------------------------------------------------------------------------------------------------------------------------
local ACE_OBJ = '^[%w_%.%-]+$'

PB.Action('grades.ace.add', 'grades.ace', function(ctx, p)
    local v = p.values or {}
    local line
    if p.kind == 'principal' then
        line = ('add_principal %s %s'):format(tostring(v.child or ''), tostring(v.parent or ''))
        if not tostring(v.child or ''):match('^[%w_%.:%-]+$') or not tostring(v.parent or ''):match('^[%w_%.:%-]+$') then return false, 'Principals invalides.' end
    else
        local allow = v.allow == 'deny' and 'deny' or 'allow'
        if not tostring(v.principal or ''):match('^[%w_%.:%-]+$') or not tostring(v.object or ''):match(ACE_OBJ) then return false, 'Principal ou objet invalide (lettres, chiffres, . _ - :).' end
        line = ('add_ace %s %s %s'):format(v.principal, v.object, allow)
    end
    local ok, err = F.CfgApply({ { op = 'append', line = line } }, ctx.actor, 'ACE : ' .. line)
    if not ok then return false, err end
    local applied = P.AceExec(line)
    ctx.audit('permission', 'ace.ajouter', line)
    ctx.toast = applied and 'Ajouté au server.cfg et appliqué immédiatement.' or "Ajouté au server.cfg ; appliqué au prochain redémarrage (la ressource n'a pas le droit d'appliquer les ACE à chaud, voir server.cfg.example)."
    return true
end, { critical = true, pin = true, confirm = { title = 'Ajouter cette règle ACE ?', text = "Elle est écrite dans le server.cfg et appliquée tout de suite. Une règle trop large peut donner des droits à tout le monde." } })

PB.Action('grades.ace.remove', 'grades.ace', function(ctx, p)
    local line = PB.Trim(tostring(p.raw or ''))
    local cmd, a, b, c = line:match('^(%S+)%s+(%S+)%s+(%S+)%s*(%S*)$')
    local ok, err = F.CfgApply({ { op = 'removeline', n = PB.ToInt(p.n, 0), expect = line } }, ctx.actor, 'ACE retirée')
    if not ok then return false, err end
    if cmd == 'add_ace' and c ~= '' then P.AceExec(('remove_ace %s %s %s'):format(a, b, c))
    elseif cmd == 'add_principal' then P.AceExec(('remove_principal %s %s'):format(a, b)) end
    ctx.audit('permission', 'ace.retirer', line)
    ctx.toast = 'Retiré du server.cfg et du serveur en cours.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Retirer cette règle ?', text = "La ligne est supprimée du server.cfg et retirée immédiatement du serveur en cours." } })

-- Protection (réglages) --------------------------------------------------------------------------------------------------------------------------------
local protection = PB.Form.Cfg({
    ns = 'grades', id = 'protection', title = 'Protection des grades', perm = 'grades.edit',
    desc = "Les règles de hiérarchie ci-dessous sont toujours appliquées. Tu peux ajouter une alerte Discord à chaque changement.",
    fields = {
        { k = 'alert_changes', type = 'toggle', label = "Alerter l'équipe à chaque changement de grade", default = true },
    },
    after = function() end,
})

PB.Audit.OnEntry(function(row)
    if (row.cat == 'grade' or row.cat == 'permission') and PB.Cfg.Get('grades', 'alert_changes', true) and PB.Notify and row.action ~= 'sync' then
        PB.Notify('info', 'Grades : ' .. row.action, tostring(row.actor) .. ' → ' .. tostring(row.target), 'grades.view')
    end
end)

-- Module ------------------------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'grades', label = 'Grades et permissions', icon = 'shield', group = 'Pilotage', order = 20, perm = 'grades.view', hint = 'Équipe, grades, ACE, librairie admin',
    caps = function() return P.Caps() end,
    doc = "## Grades et permissions\nIl n'existe qu'**un seul système de grades** : celui-ci. Chaque changement est écrit en base puis poussé vers ta librairie admin (groupes ACE `group.pb_<grade>` ou exports, selon `Config.AdminLib`).\n\n- **Hiérarchie** : tu ne peux modifier que des grades de niveau inférieur au tien, et accorder uniquement des permissions que tu possèdes.\n- **Règle de décision** : la règle la plus précise l'emporte ; à précision égale, le refus gagne ; une exception individuelle passe avant le grade.\n- **Propriétaires** : définis dans `config.lua` ou depuis la console (`pb_grant`).",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('grades', 'Grades', 'shield', function(_, params)
                local rows = {}
                for _, g in ipairs(P.Grades()) do
                    local acts = { { nav = { tab = 'editor', params = { grade = g.name } }, label = 'Modifier', icon = 'edit' } }
                    rows[#rows + 1] = { id = g.name, color = g.color, label = g.label, name = g.name, level = g.level, parent = g.parent or '—', members = g.members,
                        rules = countKeys(g.perms), flag = g.protected and { text = 'Protégé', tone = 'off' } or '', actions = acts }
                end
                return {
                    B.table({ id = 'grades', title = 'Grades (du plus haut au plus bas)', search = true,
                        columns = { { k = 'color', label = '', type = 'color', w = 40 }, { k = 'label', label = 'Nom affiché' }, { k = 'name', label = 'Identifiant', type = 'mono' }, { k = 'level', label = 'Niveau', type = 'num' },
                            { k = 'parent', label = 'Hérite de', type = 'mono' }, { k = 'members', label = 'Membres', type = 'num' }, { k = 'rules', label = 'Règles', type = 'num' }, { k = 'flag', label = '', type = 'badge' } },
                        rows = rows, toolbar = { { nav = { tab = 'editor', params = { grade = '' } }, label = 'Nouveau grade', icon = 'plus', perm = 'grades.edit' } } }),
                    { type = 'columns', cols = {
                        { { type = 'form', id = 'dup', title = 'Dupliquer un grade', cols = 1, values = {},
                            fields = { { k = 'source', type = 'select', label = 'Grade à copier', opts = gradeOpts(false, 'owner'), required = true },
                                { k = 'name', type = 'text', label = 'Nouvel identifiant', pattern = '^[a-z][a-z0-9_]+$', required = true, maxlen = 24 },
                                { k = 'label', type = 'text', label = 'Nom affiché', maxlen = 32 } },
                            submit = { action = 'grades.duplicate', label = 'Dupliquer' } } },
                        { { type = 'form', id = 'ren', title = 'Renommer un identifiant', cols = 1, values = {},
                            fields = { { k = 'grade', type = 'select', label = 'Grade', opts = gradeOpts(false, 'owner'), required = true },
                                { k = 'name', type = 'text', label = 'Nouvel identifiant', pattern = '^[a-z][a-z0-9_]+$', required = true, maxlen = 24 } },
                            submit = { action = 'grades.rename', label = 'Renommer' } } },
                        { { type = 'form', id = 'del', title = 'Supprimer un grade', cols = 1, values = {},
                            fields = { { k = 'grade', type = 'select', label = 'Grade', opts = gradeOpts(false, 'owner'), required = true },
                                { k = 'moveTo', type = 'select', label = 'Déplacer ses membres vers', opts = gradeOpts(true, 'owner') } },
                            submit = { action = 'grades.delete', label = 'Supprimer', danger = true } } },
                    } },
                }
            end),
            tab('editor', 'Éditeur de grade', 'edit', function(_, params)
                local name = tostring(params.grade or '')
                local g = name ~= '' and P.Grade(name) or nil
                local blocks = {}
                local opts = {}
                for _, i in ipairs(ICONS) do opts[#opts + 1] = i end
                local fields = {
                    { k = 'name', type = 'text', label = 'Identifiant', readonly = g ~= nil, pattern = '^[a-z][a-z0-9_]+$', maxlen = 24, required = true, hint = g and "Pour le changer, utilise « Renommer »." or 'Lettres minuscules, chiffres et _.' },
                    { k = 'label', type = 'text', label = 'Nom affiché', maxlen = 32, required = true },
                    { k = 'color', type = 'color', label = 'Couleur' },
                    { k = 'icon', type = 'icon', label = 'Icône', opts = opts },
                    { k = 'level', type = 'number', label = 'Priorité (niveau)', min = 1, max = 999, required = true, hint = 'Plus le niveau est haut, plus le grade est puissant. Chacun ne gère que les niveaux inférieurs au sien.' },
                    { k = 'parent', type = 'select', label = 'Hérite des permissions de', opts = gradeOpts(true, name) },
                }
                if ctx.has('grades.ace') then
                    fields[#fields + 1] = { k = 'principals', type = 'list', label = 'Groupes ACE supplémentaires', hint = "Ex. group.admin : le grade hérite des droits ACE de ce groupe (utile si ta librairie admin lit group.admin).", wide = true }
                end
                local values = g and { name = g.name, label = g.label, color = g.color, icon = g.icon, level = g.level, parent = g.parent or '', principals = g.principals }
                    or { name = '', label = '', color = '#dfe2e7', icon = 'shield', level = 10, parent = '', principals = {} }
                blocks[#blocks + 1] = { type = 'form', id = 'gedit', title = g and ('Grade « ' .. g.label .. ' »') or 'Nouveau grade', cols = 2, fields = fields, values = values,
                    pickers = nil, submit = { action = 'grades.save', label = g and 'Enregistrer' or 'Créer le grade', payload = { mode = g and 'edit' or 'create', original = g and g.name or nil } } }
                if g then
                    blocks[#blocks + 1] = permGrid('gperms', 'Permissions du grade', g.perms, function(perm) return P.ExplainGrade(g.name, perm) end,
                        g.name ~= 'owner' and { action = 'grades.perms.save', label = 'Enregistrer les permissions', payload = { grade = g.name } } or nil)
                    if g.name == 'owner' then blocks[#blocks] = B.notice('info', 'Le grade propriétaire possède toutes les permissions, en permanence.') end
                    blocks[#blocks + 1] = { type = 'form', id = 'copy', title = "Copier les permissions d'un autre grade", cols = 1, values = { to = g.name },
                        fields = { { k = 'from', type = 'select', label = 'Copier depuis', opts = gradeOpts(false, g.name), required = true }, { k = 'to', type = 'text', label = 'Vers', readonly = true } },
                        submit = g.name ~= 'owner' and { action = 'grades.copyperms', label = 'Remplacer mes règles par les siennes' } or nil }
                else
                    blocks[#blocks + 1] = B.notice('info', 'Crée le grade pour accéder à ses permissions.')
                end
                return blocks
            end, 'grades.edit'),
            tab('team', 'Équipe', 'users', function()
                local rows = {}
                local staff = P.Staff()
                local counts = {}
                for _, s in ipairs(staff) do
                    local g = P.Grade(s.grade)
                    counts[s.grade] = (counts[s.grade] or 0) + 1
                    local acts = {}
                    if not s.fixed then
                        acts[#acts + 1] = { nav = { tab = 'member', params = { id = s.identifier } }, label = 'Modifier', icon = 'edit', perm = 'grades.assign' }
                        acts[#acts + 1] = { action = 'grades.staff.remove', label = 'Retirer', icon = 'trash', danger = true, payload = { id = s.identifier } }
                    end
                    rows[#rows + 1] = { id = s.identifier, name = s.name ~= '' and s.name or '—', identifier = s.identifier, grade = { text = g and g.label or s.grade, tone = 'ok', color = g and g.color or nil },
                        online = s.online and { text = 'En ligne (' .. s.online .. ')', tone = 'ok' } or { text = 'Hors ligne', tone = 'off' }, by = s.added_by or '', exc = countKeys(s.perms), actions = acts }
                end
                local stats = {}
                for _, g in ipairs(P.Grades()) do stats[#stats + 1] = { label = g.label, value = counts[g.name] or 0, icon = g.icon, color = g.color } end
                local players = { { '', '— saisir un identifiant —' } }
                for _, id in ipairs(GetPlayers()) do
                    local lic = P.GetLicense(tonumber(id))
                    if lic then players[#players + 1] = { lic, (GetPlayerName(tonumber(id)) or '?') .. ' (id ' .. id .. ')' } end
                end
                local gopts = {}
                for _, g in ipairs(P.Grades()) do if g.name ~= 'owner' then gopts[#gopts + 1] = { g.name, g.label } end end
                return {
                    B.stats(stats),
                    B.table({ id = 'staff', title = "Membres de l'équipe", search = true,
                        columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade', type = 'badge' }, { k = 'online', label = 'Statut', type = 'badge' }, { k = 'identifier', label = 'Identifiant', type = 'mono' }, { k = 'exc', label = 'Exceptions', type = 'num' }, { k = 'by', label = 'Ajouté par' } },
                        rows = rows, empty = "Personne dans l'équipe pour l'instant. Les propriétaires de config.lua sont affichés ici." }),
                    { type = 'form', id = 'addstaff', title = 'Attribuer un grade', cols = 2, values = { grade = gopts[#gopts] and gopts[#gopts][1] or '' },
                        fields = { { k = 'player', type = 'select', label = 'Joueur connecté', opts = players },
                            { k = 'license', type = 'text', label = 'Ou identifiant', pattern = '^license2?:%x+$', maxlen = 80, hint = 'license:xxxxxxxx…' },
                            { k = 'name', type = 'text', label = 'Nom (facultatif)', maxlen = 64 },
                            { k = 'grade', type = 'select', label = 'Grade', opts = gopts, required = true } },
                        submit = { action = 'grades.staff.set', label = 'Attribuer' } },
                }
            end),
            tab('member', 'Membre', 'user', function(_, params)
                local id = tostring(params.id or '')
                local member
                for _, s in ipairs(P.Staff()) do if s.identifier == id and not s.fixed then member = s end end
                if not member then return { B.notice('info', "Choisis un membre dans l'onglet Équipe.") } end
                local gopts = {}
                for _, g in ipairs(P.Grades()) do if g.name ~= 'owner' then gopts[#gopts + 1] = { g.name, g.label } end end
                return {
                    { type = 'form', id = 'member', title = (member.name ~= '' and member.name or id), desc = id, cols = 2, values = { license = id, name = member.name, grade = member.grade },
                        fields = { { k = 'license', type = 'text', label = 'Identifiant', readonly = true }, { k = 'name', type = 'text', label = 'Nom', maxlen = 64 },
                            { k = 'grade', type = 'select', label = 'Grade', opts = gopts, required = true } },
                        submit = { action = 'grades.staff.set', label = 'Enregistrer' } },
                    permGrid('mperms', 'Exceptions individuelles', member.perms, function(perm) return P.ExplainStaff(id, perm) end,
                        { action = 'grades.staff.perms', label = 'Enregistrer les exceptions', payload = { id = id } }),
                }
            end, 'grades.assign'),
            tab('effective', 'Permissions effectives', 'eye', function(_, params)
                local who = tostring(params.who or '')
                local opts = {}
                for _, g in ipairs(P.Grades()) do opts[#opts + 1] = { 'grade:' .. g.name, 'Grade : ' .. g.label } end
                for _, s in ipairs(P.Staff()) do opts[#opts + 1] = { 'staff:' .. s.identifier, 'Membre : ' .. (s.name ~= '' and s.name or s.identifier) } end
                if who == '' and opts[1] then who = opts[1][1] end
                local kind, key = who:match('^(%a+):(.+)$')
                local rows = {}
                for _, c in ipairs(P.Catalog()) do
                    local e = kind == 'grade' and P.ExplainGrade(key, c.perm) or (kind == 'staff' and P.ExplainStaff(key, c.perm) or { allowed = false })
                    rows[#rows + 1] = { module = c.group, perm = c.perm, label = c.label, allowed = { text = e.allowed and 'Autorisé' or 'Refusé', tone = e.allowed and 'ok' or 'off' },
                        rule = e.rule or '—', from = e.from or '—', danger = c.danger and { text = 'Sensible', tone = 'warn' } or '' }
                end
                return {
                    { type = 'picker', id = 'who', label = 'Afficher pour', options = opts, value = who },
                    B.table({ id = 'eff', search = true, columns = { { k = 'module', label = 'Module' }, { k = 'label', label = 'Action' }, { k = 'perm', label = 'Permission', type = 'mono' }, { k = 'allowed', label = 'Résultat', type = 'badge' },
                        { k = 'rule', label = 'Règle appliquée', type = 'mono' }, { k = 'from', label = "Vient de" }, { k = 'danger', label = '', type = 'badge' } }, rows = rows }),
                }
            end),
            tab('compare', 'Comparaison', 'diff', function(_, params)
                local opts = {}
                for _, g in ipairs(P.Grades()) do opts[#opts + 1] = { g.name, g.label } end
                local a = tostring(params.a or (opts[1] and opts[1][1]) or '')
                local b = tostring(params.b or (opts[2] and opts[2][1]) or a)
                local rows = {}
                for _, c in ipairs(P.Catalog()) do
                    local ea, eb = P.ExplainGrade(a, c.perm), P.ExplainGrade(b, c.perm)
                    rows[#rows + 1] = { module = c.group, perm = c.perm, label = c.label,
                        a = { text = ea.allowed and 'Oui' or 'Non', tone = ea.allowed and 'ok' or 'off' }, b = { text = eb.allowed and 'Oui' or 'Non', tone = eb.allowed and 'ok' or 'off' },
                        diff = (ea.allowed ~= eb.allowed) and { text = 'Différent', tone = 'warn' } or '' }
                end
                return {
                    { type = 'columns', cols = { { { type = 'picker', id = 'a', label = 'Grade A', options = opts, value = a } }, { { type = 'picker', id = 'b', label = 'Grade B', options = opts, value = b } } } },
                    B.table({ id = 'cmp', search = true, columns = { { k = 'module', label = 'Module' }, { k = 'label', label = 'Action' }, { k = 'perm', label = 'Permission', type = 'mono' },
                        { k = 'a', label = a, type = 'badge' }, { k = 'b', label = b, type = 'badge' }, { k = 'diff', label = '', type = 'badge' } }, rows = rows, onlyDiffToggle = true }),
                }
            end),
            tab('lib', 'Librairie admin', 'link', function()
                local test = PB.AdminLib.Test()
                local rows = {}
                for _, t in ipairs(test) do rows[#rows + 1] = { name = t.name, state = { text = t.ok and 'OK' or 'Indisponible', tone = t.ok and 'ok' or 'err' }, detail = t.detail } end
                local libperms, lerr = PB.AdminLib.LibPermissions()
                local prow = {}
                for _, x in ipairs(libperms or {}) do prow[#prow + 1] = { perm = tostring(x.perm or x.name or x[1] or ''), label = tostring(x.label or x[2] or '') } end
                local cfgForm = FC.Form({ id = 'adminlib', title = 'Connexion à la librairie (config.lua)', perm = 'grades.sync', module = 'grades', res = 'pb_panel', file = 'config.lua',
                    desc = 'Tape « restart pb_panel » dans la console du serveur après modification.',
                    fields = {
                        { path = 'Config.AdminLib.mode', type = 'select', label = 'Mode', opts = { { 'ace', 'Groupes ACE (group.pb_<grade>)' }, { 'export', 'Exports de la librairie' } } },
                        { path = 'Config.AdminLib.resource', type = 'text', label = 'Ressource de la librairie', maxlen = 64, pattern = '^[%w_%-%.]*$' },
                        { path = 'Config.AdminLib.exports.listGrades', type = 'text', label = 'Export : lister les grades', maxlen = 64 },
                        { path = 'Config.AdminLib.exports.saveGrade', type = 'text', label = 'Export : enregistrer un grade', maxlen = 64 },
                        { path = 'Config.AdminLib.exports.deleteGrade', type = 'text', label = 'Export : supprimer un grade', maxlen = 64 },
                        { path = 'Config.AdminLib.exports.setPlayerGrade', type = 'text', label = 'Export : attribuer un grade', maxlen = 64 },
                        { path = 'Config.AdminLib.exports.listPermissions', type = 'text', label = 'Export : lister les permissions', maxlen = 64 },
                        { path = 'Config.AdminLib.exports.setLayout', type = 'text', label = 'Export : positionner le menu (facultatif)', maxlen = 64 },
                    }, after = function() return 'Tape « restart pb_panel » dans la console du serveur.' end })
                return {
                    B.notice('info', "Le panel ne remplace pas ta librairie admin : il lui pousse les grades. Mode actuel : " .. PB.AdminLib.Mode() .. (PB.AdminLib.Resource() ~= '' and (' — ressource ' .. PB.AdminLib.Resource() .. ' : ' .. PB.AdminLib.State()) or '') .. '.'),
                    B.table({ id = 'libtest', title = 'Vérification', columns = { { k = 'name', label = 'Élément' }, { k = 'state', label = 'État', type = 'badge' }, { k = 'detail', label = 'Détail' } }, rows = rows }),
                    B.actions({ { action = 'grades.sync', label = 'Synchroniser maintenant', icon = 'sync' }, { action = 'grades.import', label = 'Importer les grades de la librairie', icon = 'download' } }, 'Actions'),
                    #prow > 0 and B.table({ id = 'libperms', title = 'Permissions fournies par la librairie', search = true, columns = { { k = 'perm', label = 'Permission', type = 'mono' }, { k = 'label', label = 'Description' } }, rows = prow })
                        or B.notice('off', lerr or 'Aucune permission de la librairie à afficher.', 'Permissions de la librairie'),
                    cfgForm(ctx),
                }
            end, 'grades.sync'),
            tab('ace', 'Groupes et principals ACE', 'key', function()
                local view = F.CfgView()
                local rows = {}
                if view then
                    for _, c in ipairs(view.convars) do
                        if c.kind == 'cmd' and (c.key == 'add_ace' or c.key == 'add_principal') and c.raw then
                            local a, b, cc = c.value:match('^(%S+)%s+(%S+)%s*(%S*)$')
                            rows[#rows + 1] = { id = c.n, kind = c.key == 'add_ace' and 'Règle' or 'Principal', a = a or '', b = b or '', c = cc or '', source = 'server.cfg',
                                actions = { { action = 'grades.ace.remove', label = 'Retirer', icon = 'trash', danger = true, payload = { n = c.n, raw = c.raw } } } }
                        end
                    end
                end
                local applied = P.AppliedAce()
                for _, a in ipairs(applied.aces) do rows[#rows + 1] = { kind = 'Règle', a = a[1], b = a[2], c = a[3], source = 'Synchronisation du panel', actions = {} } end
                for _, a in ipairs(applied.principals) do rows[#rows + 1] = { kind = 'Principal', a = a[1], b = a[2], c = '', source = 'Synchronisation du panel', actions = {} } end
                return {
                    B.notice('info', "Seules les lignes du server.cfg et celles posées par le panel sont listées : FiveM ne permet pas de lister les ACE créées autrement pendant que le serveur tourne."),
                    B.table({ id = 'ace', search = true, columns = { { k = 'kind', label = 'Type' }, { k = 'a', label = 'Principal / enfant', type = 'mono' }, { k = 'b', label = 'Objet / parent', type = 'mono' }, { k = 'c', label = 'Droit', type = 'mono' }, { k = 'source', label = 'Origine' } }, rows = rows, empty = 'Aucune ligne add_ace / add_principal.' }),
                    { type = 'columns', cols = {
                        { { type = 'form', id = 'ace_rule', title = 'Ajouter une règle ACE', cols = 1, values = { allow = 'allow' },
                            fields = { { k = 'principal', type = 'text', label = 'Principal', placeholder = 'group.admin', required = true, pattern = '^[%w_%.:%-]+$' },
                                { k = 'object', type = 'text', label = 'Objet', placeholder = 'command', required = true, pattern = '^[%w_%.%-]+$' },
                                { k = 'allow', type = 'select', label = 'Droit', opts = { { 'allow', 'Autoriser' }, { 'deny', 'Refuser' } } } },
                            submit = { action = 'grades.ace.add', label = 'Ajouter', payload = { kind = 'ace' } } } },
                        { { type = 'form', id = 'ace_prin', title = 'Ajouter un principal', cols = 1, values = {},
                            fields = { { k = 'child', type = 'text', label = 'Enfant', placeholder = 'identifier.license:…', required = true, pattern = '^[%w_%.:%-]+$' },
                                { k = 'parent', type = 'text', label = 'Parent', placeholder = 'group.admin', required = true, pattern = '^[%w_%.:%-]+$' } },
                            submit = { action = 'grades.ace.add', label = 'Ajouter', payload = { kind = 'principal' } } } },
                    } },
                }
            end, 'grades.ace'),
            tab('history', 'Historique', 'history', function()
                local rows = {}
                local list = PB.Audit.Search({ cat = { 'grade', 'permission' }, per = 80 })
                for _, r in ipairs(list) do
                    rows[#rows + 1] = { id = r.id, at = r.created_at, cat = r.cat, what = r.action, target = r.target, actor = r.actor,
                        actions = { { action = 'audit.detail', label = 'Détails', icon = 'diff', payload = { id = r.id } } } }
                end
                return { B.table({ id = 'gh', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'what', label = 'Action', type = 'mono' }, { k = 'target', label = 'Cible' }, { k = 'actor', label = 'Par' } }, rows = rows, empty = 'Aucun changement enregistré.' }) }
            end),
            tab('protection', 'Protection', 'lock', function()
                return {
                    B.table({ id = 'rules', title = 'Règles toujours appliquées', columns = { { k = 'rule', label = 'Règle' }, { k = 'why', label = 'Pourquoi' } }, rows = {
                        { rule = 'Chacun ne gère que les grades de niveau inférieur au sien.', why = "Un modérateur ne peut pas se promouvoir ni modifier un administrateur." },
                        { rule = 'On ne peut accorder que les permissions que l\'on possède.', why = "Pas d'escalade de privilèges par la création d'un grade." },
                        { rule = 'Impossible de modifier son propre grade ou ses propres exceptions.', why = 'Même pour un grade élevé (sauf propriétaire).' },
                        { rule = 'Les propriétaires sont définis dans config.lua ou en console.', why = "Ils ne peuvent pas être retirés depuis l'interface." },
                        { rule = 'Les liens avec des groupes ACE sont réservés aux propriétaires.', why = 'Ils peuvent donner des droits hors du panel.' },
                        { rule = 'Chaque changement est journalisé avec son état avant / après.', why = 'Voir l\'onglet Historique.' },
                    } }),
                    protection(ctx),
                }
            end, 'grades.edit'),
        } }
    end,
})
