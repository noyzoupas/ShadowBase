-- Module 7 : Gangs (voir jobs.lua : même constructeur, groupes de type « gang »).
PB.GroupModule('gang')
