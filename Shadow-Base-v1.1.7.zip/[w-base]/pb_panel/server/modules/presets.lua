-- Modèles prêts à l'emploi pour les métiers et les gangs (module Métiers / Gangs › onglet « Modèles »).
-- Chaque modèle est un groupe complet (identifiant, nom, type, grades et salaires) créé en un clic, puis modifiable dans l'éditeur.
-- Les salaires sont des valeurs de départ raisonnables : ajuste-les ensuite à ton économie.

PB.Presets = {}

local function g(level, name, salary, boss) return { grade = level, name = name, label = name, salary = salary, boss = boss and true or false } end

PB.Presets.job = {
    { key = 'police', name = 'police', label = 'Police', type = 'leo', defaultDuty = false, offDutyPay = false, desc = 'Forces de l\'ordre : 6 grades, du cadet au commissaire.',
      grades = { g(0, 'Cadet', 300), g(1, 'Officier', 450), g(2, 'Sergent', 600), g(3, 'Lieutenant', 750), g(4, 'Capitaine', 900), g(5, 'Commissaire', 1100, true) } },
    { key = 'sheriff', name = 'sheriff', label = 'Sheriff', type = 'leo', defaultDuty = false, offDutyPay = false, desc = 'Bureau du shérif (comté) : 5 grades.',
      grades = { g(0, 'Deputy stagiaire', 300), g(1, 'Deputy', 450), g(2, 'Sergent', 600), g(3, 'Lieutenant', 800), g(4, 'Shérif', 1050, true) } },
    { key = 'ems', name = 'ambulance', label = 'EMS (Ambulance)', type = 'ems', defaultDuty = false, offDutyPay = false, desc = 'Urgentistes et médecins : 5 grades.',
      grades = { g(0, 'Ambulancier', 300), g(1, 'Infirmier', 450), g(2, 'Médecin', 700), g(3, 'Chirurgien', 900), g(4, 'Directeur', 1100, true) } },
    { key = 'fire', name = 'fire', label = 'Pompiers', type = 'ems', defaultDuty = false, offDutyPay = false, desc = 'Sapeurs-pompiers : 5 grades.',
      grades = { g(0, 'Sapeur', 300), g(1, 'Caporal', 420), g(2, 'Sergent', 560), g(3, 'Lieutenant', 720), g(4, 'Chef de caserne', 950, true) } },
    { key = 'mechanic', name = 'mechanic', label = 'Mécanicien', type = 'mechanic', defaultDuty = true, offDutyPay = false, desc = 'Garage de réparation : 4 grades.',
      grades = { g(0, 'Apprenti', 200), g(1, 'Mécanicien', 350), g(2, 'Chef d\'atelier', 500), g(3, 'Patron', 700, true) } },
    { key = 'taxi', name = 'taxi', label = 'Taxi', type = 'taxi', defaultDuty = true, offDutyPay = false, desc = 'Chauffeurs de taxi : 3 grades.',
      grades = { g(0, 'Chauffeur', 200), g(1, 'Chauffeur confirmé', 300), g(2, 'Patron', 500, true) } },
    { key = 'cardealer', name = 'cardealer', label = 'Concessionnaire', type = 'dealer', defaultDuty = true, offDutyPay = false, desc = 'Vente de véhicules : 4 grades.',
      grades = { g(0, 'Vendeur', 250), g(1, 'Vendeur confirmé', 350), g(2, 'Responsable', 500), g(3, 'Patron', 750, true) } },
    { key = 'realestate', name = 'realestate', label = 'Agent immobilier', type = 'realestate', defaultDuty = true, offDutyPay = false, desc = 'Agence immobilière : 3 grades.',
      grades = { g(0, 'Agent', 250), g(1, 'Agent senior', 400), g(2, 'Directeur', 650, true) } },
    { key = 'journalist', name = 'journalist', label = 'Journaliste', type = 'press', defaultDuty = true, offDutyPay = false, desc = 'Presse locale : 3 grades.',
      grades = { g(0, 'Stagiaire', 150), g(1, 'Reporter', 300), g(2, 'Rédacteur en chef', 500, true) } },
    { key = 'bank', name = 'banker', label = 'Banquier', type = 'bank', defaultDuty = true, offDutyPay = false, desc = 'Employés de banque : 3 grades.',
      grades = { g(0, 'Conseiller', 300), g(1, 'Gestionnaire', 450), g(2, 'Directeur', 700, true) } },
    { key = 'bartender', name = 'bartender', label = 'Barman', type = 'bar', defaultDuty = true, offDutyPay = false, desc = 'Bar / boîte de nuit : 3 grades.',
      grades = { g(0, 'Serveur', 150), g(1, 'Barman', 250), g(2, 'Gérant', 450, true) } },
    { key = 'judge', name = 'justice', label = 'Justice', type = 'justice', defaultDuty = false, offDutyPay = false, desc = 'Tribunal : 4 grades.',
      grades = { g(0, 'Greffier', 350), g(1, 'Avocat', 500), g(2, 'Procureur', 800), g(3, 'Juge', 1000, true) } },
    { key = 'unemployed', name = 'unemployed', label = 'Chômeur', type = '', defaultDuty = true, offDutyPay = true, desc = 'Emploi par défaut (déjà présent en général) : 1 grade.',
      grades = { g(0, 'Sans emploi', 50) } },
}

PB.Presets.gang = {
    { key = 'ballas', name = 'ballas', label = 'Ballas', desc = 'Gang de rue : 4 grades.', grades = { g(0, 'Recrue', 0), g(1, 'Soldat', 0), g(2, 'Lieutenant', 0), g(3, 'Chef', 0, true) } },
    { key = 'families', name = 'families', label = 'Families', desc = 'Gang de rue : 4 grades.', grades = { g(0, 'Recrue', 0), g(1, 'Soldat', 0), g(2, 'Lieutenant', 0), g(3, 'Chef', 0, true) } },
    { key = 'vagos', name = 'vagos', label = 'Vagos', desc = 'Gang de rue : 4 grades.', grades = { g(0, 'Recrue', 0), g(1, 'Soldat', 0), g(2, 'Lieutenant', 0), g(3, 'Chef', 0, true) } },
    { key = 'lostmc', name = 'lostmc', label = 'Lost MC', desc = 'Club de motards : 5 grades.', grades = { g(0, 'Prospect', 0), g(1, 'Membre', 0), g(2, 'Road captain', 0), g(3, 'Vice-président', 0), g(4, 'Président', 0, true) } },
    { key = 'mafia', name = 'mafia', label = 'Mafia', desc = 'Organisation criminelle : 5 grades.', grades = { g(0, 'Associé', 0), g(1, 'Soldat', 0), g(2, 'Capo', 0), g(3, 'Consigliere', 0), g(4, 'Parrain', 0, true) } },
    { key = 'cartel', name = 'cartel', label = 'Cartel', desc = 'Organisation criminelle : 4 grades.', grades = { g(0, 'Mule', 0), g(1, 'Sicario', 0), g(2, 'Lieutenant', 0), g(3, 'Patron', 0, true) } },
    { key = 'yakuza', name = 'yakuza', label = 'Yakuza', desc = 'Organisation criminelle : 4 grades.', grades = { g(0, 'Kyodai', 0), g(1, 'Shatei', 0), g(2, 'Wakagashira', 0), g(3, 'Oyabun', 0, true) } },
    { key = 'triad', name = 'triad', label = 'Triades', desc = 'Organisation criminelle : 4 grades.', grades = { g(0, 'Associé', 0), g(1, 'Soldat', 0), g(2, 'Officier', 0), g(3, 'Dragon', 0, true) } },
}

-- Retourne la liste (copie) des modèles d'un type : 'job' ou 'gang'.
function PB.Presets.List(kind) return PB.Presets[kind] or {} end

function PB.Presets.Find(kind, key)
    for _, p in ipairs(PB.Presets[kind] or {}) do if p.key == key then return p end end
end
