-- Module 19 : Sécurité du panel (sessions, PIN, limites, secrets, évènements de sécurité, propriétaires).

local B, P, Form = PB.B, PB.Perm, PB.Form

P.Register('security.sessions', 'Voir et fermer les sessions du panel', 'security')
P.Register('security.pin', 'Définir le code PIN des actions critiques', 'security', true)
P.Register('security.secrets', 'Supprimer des secrets stockés', 'security', true)
P.Register('security.limits', 'Régler les limites de session', 'security', true)

local limits = Form.Cfg({
    ns = 'security', id = 'limits', title = 'Sessions et limites', perm = 'security.limits', cols = 2,
    desc = "Une session se ferme seule après une période sans activité. Une limite de débit protège contre les clients qui spamment le serveur.",
    fields = {
        { k = 'session_minutes', type = 'number', label = "Fermeture après inactivité (minutes)", default = 30, min = 2, max = 480 },
        { k = 'rate_limit', type = 'number', label = 'Requêtes maximum par 5 secondes', default = 40, min = 10, max = 500 },
    },
})

PB.Action('security.session.close', 'security.sessions', function(ctx, p)
    local src = PB.ToInt(p.src, 0)
    if src == ctx.src then return false, 'Tu ne peux pas fermer ta propre session ici.' end
    local s = PB.Session.Get(src)
    if not s then return false, 'Session introuvable.' end
    PB.Session.Revoke(src, 'Session fermée par ' .. tostring(ctx.actor.name))
    ctx.audit('securite', 'session.fermer', tostring(s.name))
    ctx.toast = 'Session fermée.'
    return true
end, { critical = true, confirm = { title = 'Fermer cette session ?', text = 'La personne devra rouvrir le panel.', danger = false } })

PB.Action('security.pin.set', 'security.pin', function(ctx, p)
    local v = p.values or {}
    local newPin, current = tostring(v.pin or ''), tostring(v.current or '')
    if PB.Pin.IsSet() then
        local ok, err = PB.Pin.Verify(ctx.license or '?', current)
        if not ok then return false, err end
    end
    local ok, err = PB.Pin.Set(newPin, ctx.actor)
    if not ok then return false, err end
    ctx.audit('securite', newPin == '' and 'pin.retirer' or 'pin.definir', 'code PIN')
    ctx.toast = newPin == '' and 'PIN retiré : les actions critiques demandent seulement une confirmation.' or 'PIN enregistré.'
    return true
end, { rate = 6 })

PB.Action('security.secret.delete', 'security.secrets', function(ctx, p)
    local name = tostring(p.name or '')
    if not name:match('^[%w_%-]+$') then return false, 'Nom invalide.' end
    if PB.Secret.Source(name) ~= 'base' then return false, "Ce secret vient d'une convar : retire-le du server.cfg." end
    PB.Secret.Set(name, '', ctx.actor)
    ctx.audit('securite', 'secret.supprimer', name)
    ctx.toast = 'Secret supprimé.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Supprimer ce secret ?', text = 'Les fonctions qui en dépendent cessent de marcher (webhook, bot, envoi distant).' } })

local function secretLabel(name)
    if name:sub(1, 6) == 'dc_wh_' then return 'Webhook Discord : ' .. name:sub(7) end
    if name == 'discord_bot_token' then return 'Jeton du bot Discord' end
    if name == 'backups_remote_url' then return "Adresse d'envoi des sauvegardes" end
    return name
end

PB.Module({
    id = 'security', label = 'Sécurité', icon = 'lock', group = 'Système', order = 170, perm = 'security.view', hint = 'Sessions, PIN, secrets, limites',
    caps = function()
        return PB.Capsify({
            { 'Permissions vérifiées côté serveur', 'ok', 'Chaque action est contrôlée ; un bouton absent ne remplace pas la vérification.' },
            { 'Sessions avec expiration et révocation', 'ok', 'Fermées si la permission du panel est retirée.' },
            { 'Code PIN des actions critiques', 'ok', 'Haché et salé ; 5 erreurs verrouillent 5 minutes.' },
            { 'Secrets masqués', 'ok', 'Jamais envoyés au navigateur ; convar `pb_secret_<nom>` possible pour ne pas les stocker en base.' },
            { 'Restriction par adresse IP', 'off', "Le panel s'ouvre depuis le jeu : l'adresse IP du joueur n'est pas un critère fiable." },
            { 'Authentification à deux facteurs', 'off', "Non fournie : repose sur ton compte FiveM / licence et le PIN." },
        })
    end,
    doc = "## Sécurité\nLes propriétaires sont définis dans `config.lua` (Config.Owners) ou avec la commande console `pb_grant`. Un grade ne peut jamais gérer un grade égal ou supérieur au sien.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('sessions', 'Sessions', 'users', function()
                local rows = {}
                for _, s in ipairs(PB.Session.List()) do
                    rows[#rows + 1] = { name = s.name, grade = s.grade or '', opened = s.opened, last = s.last,
                        actions = (ctx.has('security.sessions') and s.src ~= ctx.src) and { { action = 'security.session.close', label = 'Fermer', icon = 'x', danger = true, payload = { src = s.src } } } or nil }
                end
                return { B.table({ id = 'sessions', columns = { { k = 'name', label = 'Joueur' }, { k = 'grade', label = 'Grade' }, { k = 'opened', label = 'Ouverte', type = 'date' }, { k = 'last', label = 'Dernière activité', type = 'date' } }, rows = rows, empty = 'Aucune session.' }) }
            end, 'security.sessions'),
            tab('pin', 'Code PIN', 'key', function()
                local set = PB.Pin.IsSet()
                local fields = { { k = 'pin', type = 'secret', label = set and 'Nouveau PIN (vide = retirer)' or 'PIN (4 à 8 chiffres)', maxlen = 8, pattern = '^%d*$' } }
                if set then table.insert(fields, 1, { k = 'current', type = 'secret', label = 'PIN actuel', maxlen = 8, required = true }) end
                return { B.notice(set and 'ok' or 'warn', set and 'Un PIN protège les actions critiques (suppressions, restaurations, console SQL...).' or "Aucun PIN : les actions critiques demandent une confirmation mais pas de code. Définis-en un.", 'Code PIN'),
                    { type = 'form', id = 'sec.pin', title = set and 'Changer ou retirer le PIN' or 'Définir un PIN', cols = 1, fields = fields, values = { pin = '', current = '' }, submit = { action = 'security.pin.set', label = 'Enregistrer' } } }
            end, 'security.pin'),
            tab('limits', 'Limites', 'sliders', function() return { limits(ctx) } end),
            tab('secrets', 'Secrets', 'key', function()
                local rows = {}
                local names = {}
                for _, r in ipairs(PB.DB.q('SELECT name, updated_by FROM pb_secrets ORDER BY name') or {}) do names[r.name] = r.updated_by end
                for name, by in pairs(names) do
                    rows[#rows + 1] = { label = secretLabel(name), name = name, value = PB.Secret.Mask(name), by = by or '',
                        actions = ctx.has('security.secrets') and { { action = 'security.secret.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { name = name } } } or nil }
                end
                table.sort(rows, function(a, b) return a.name < b.name end)
                return { B.notice('info', "Les valeurs complètes ne sont jamais affichées. Pour ne rien stocker en base, utilise une convar `pb_secret_<nom>` dans le server.cfg.", 'Secrets stockés'),
                    B.table({ id = 'secrets', columns = { { k = 'label', label = 'Usage' }, { k = 'name', label = 'Nom', type = 'mono' }, { k = 'value', label = 'Valeur', type = 'mono' }, { k = 'by', label = 'Modifié par' } }, rows = rows, empty = 'Aucun secret stocké en base.' }) }
            end),
            tab('events', 'Évènements', 'shield', function()
                local rows = PB.Audit.Search({ cat = 'securite', per = 50 })
                local out = {}
                for _, r in ipairs(rows) do out[#out + 1] = { at = r.created_at, what = r.action, actor = r.actor, target = r.target } end
                return { B.table({ id = 'secev', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'what', label = 'Évènement', type = 'mono' }, { k = 'actor', label = 'Auteur' }, { k = 'target', label = 'Cible' } }, rows = out, empty = 'Aucun évènement de sécurité.' }) }
            end, 'logs.view'),
            tab('owners', 'Propriétaires', 'crown', function()
                local rows = {}
                for _, o in ipairs(Config.Owners or {}) do rows[#rows + 1] = { id = tostring(o) } end
                return { B.notice(#rows == 0 and 'warn' or 'info', #rows == 0 and 'Aucun propriétaire dans config.lua. Utilise la commande console `pb_grant <licence> owner`.' or 'Les propriétaires sont fixés dans config.lua : ils ne peuvent pas être modifiés depuis le panel.', 'Propriétaires'),
                    B.table({ id = 'owners', columns = { { k = 'id', label = 'Identifiant', type = 'mono' } }, rows = rows, empty = 'Aucun.' }) }
            end),
        } }
    end,
})
