-- Module 8 : Objets de l'inventaire de Shadow Base (création, modification, suppression ; effet immédiat dans le jeu).

local B, P, Inv = PB.B, PB.Perm, PB.Inv

P.Register('items.edit', 'Créer et modifier des objets', 'items')
P.Register('items.delete', 'Supprimer des objets', 'items', true)

local PER = 20

local function strip(fields)
    local out = {}
    for _, f in ipairs(fields) do out[#out + 1] = f end
    return out
end

local function validated(p, isNew)
    local fields = Inv.ItemFields()
    local values = {}
    for k, v in pairs(p.values or {}) do values[k] = v end
    for _, f in ipairs(fields) do
        if values[f.k] == nil and f.default ~= nil then values[f.k] = f.default end
        if values[f.k] == nil and f.type == 'text' then values[f.k] = '' end
        if values[f.k] == nil and f.type == 'area' then values[f.k] = '' end
        if values[f.k] == nil and f.type == 'number' and f.default == nil then values[f.k] = 0 end
    end
    return PB.Validate(strip(fields), values)
end

PB.Action('items.save', 'items.edit', function(ctx, p)
    local name = tostring(p.mode == 'edit' and p.original or (p.values and p.values.name) or '')
    local clean, err = validated(p, p.mode ~= 'edit')
    if not clean then return false, err end
    local before = p.mode == 'edit' and Inv.Get(name) or nil
    local ok, e, info = Inv.SaveItem(name, clean, ctx.actor, p.mode ~= 'edit')
    if not ok then return false, e end
    ctx.audit('config', p.mode == 'edit' and 'objet.modifier' or 'objet.creer', name, before, clean)
    ctx.toast = (info and info.msg) or 'Enregistré.'
    return true, { restartNeeded = info and info.restartNeeded, open = { tab = 'edit', params = { item = name } } }
end)

PB.Action('items.delete', 'items.delete', function(ctx, p)
    local name = tostring(p.item or '')
    local before = Inv.Get(name)
    local ok, e, info = Inv.DeleteItem(name, ctx.actor)
    if not ok then return false, e end
    ctx.audit('config', 'objet.supprimer', name, before)
    ctx.toast = (info and info.msg) or 'Supprimé.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Supprimer cet objet ?', text = 'Il est retiré du fichier ou de la base (sauvegarde avant).' } })

PB.Module({
    id = 'items', label = 'Objets', icon = 'package', group = 'Serveur', order = 70, perm = 'items.view', hint = 'Objets de Shadow Base',
    caps = Inv.Caps,
    doc = "## Objets\nObjets de l'inventaire de Shadow Base : poids, pile, type, effets (faim, soif, stress, vie), image. Les changements sont actifs tout de suite dans le jeu.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        local item = tostring(params and params.item or '')
        return { tabs = {
            tab('list', 'Objets', 'list', function()
                local why = Inv.Why()
                if why then return { B.unsupported('Objets', why) } end
                local q = tostring(params and params.q or '')
                local page = math.max(1, PB.ToInt(params and params.page, 1))
                local r, err = Inv.Items(q, page, PER)
                if not r then return { B.notice('error', err) } end
                local rows = {}
                for _, it in ipairs(r.items) do
                    rows[#rows + 1] = { name = it.name, label = it.label or '', weight = it.weight or 0, extra = (it.complex and #it.complex > 0) and (#it.complex .. ' réglage(s) avancé(s)') or '',
                        actions = { { nav = { tab = 'edit', params = { item = it.name } }, label = 'Modifier', icon = 'edit' } } }
                end
                return {
                    B.stats({ { label = 'Objets', value = r.total, icon = 'package' }, { label = 'Inventaire', value = Inv.name or 'Shadow Base', icon = 'box' } }),
                    { type = 'form', id = 'items.search', title = 'Rechercher', cols = 2, fields = { { k = 'q', type = 'text', label = 'Nom ou identifiant', maxlen = 64 } }, values = { q = q }, submit = { nav = { tab = 'list' }, label = 'Chercher', as = 'params' } },
                    B.table({ id = 'items', columns = { { k = 'name', label = 'Identifiant', type = 'mono' }, { k = 'label', label = 'Nom' }, { k = 'weight', label = 'Poids', type = 'num' }, { k = 'extra', label = 'Avancé' } }, rows = rows,
                        page = { n = page, per = PER, total = r.total, tab = 'list', q = q }, empty = 'Aucun objet.' }),
                }
            end),
            tab('edit', 'Éditeur', 'edit', function()
                local why = Inv.Why()
                if why then return { B.unsupported('Objets', why) } end
                local fields = Inv.ItemFields()
                local it = item ~= '' and Inv.Get(item) or nil
                local f2 = { { k = 'name', type = 'text', label = 'Identifiant', required = true, maxlen = 64, pattern = '^[%w_%-]+$', readonly = it ~= nil, hint = 'Lettres, chiffres, _ et -. Non modifiable ensuite.' } }
                for _, f in ipairs(fields) do f2[#f2 + 1] = f end
                local values = { name = it and it.name or '' }
                for _, f in ipairs(fields) do values[f.k] = it and it[f.k] or f.default end
                local blocks = {
                    { type = 'form', id = 'items.form', title = it and ('Modifier ' .. (it.label or it.name)) or 'Créer un objet', cols = 2, fields = f2, values = values,
                        submit = { action = 'items.save', label = it and 'Enregistrer' or 'Créer', payload = { mode = it and 'edit' or 'create', original = it and it.name or nil } } },
                }
                if it and it.complex and #it.complex > 0 then
                    blocks[#blocks + 1] = B.notice('info', 'Réglages avancés non modifiables ici (' .. table.concat(it.complex, ', ') .. ') : utilise Ressources › Fichiers.', 'Réglages avancés')
                end
                if it and ctx.has('items.delete') then
                    blocks[#blocks + 1] = B.actions({ { action = 'items.delete', label = 'Supprimer cet objet', icon = 'trash', danger = true, payload = { item = it.name } } })
                end
                return blocks
            end, 'items.edit'),
        } }
    end,
})
