-- Module 12 : Cartographie. Blips, marqueurs et zones gérés par le panel et affichés par le client du panel (client/world.lua).
-- Les emplacements sont aussi publiés par exports (GetPlaces) pour que d'autres scripts les utilisent.

local B, P, DB = PB.B, PB.Perm, PB.DB

P.Register('mapping.edit', 'Créer et modifier des emplacements', 'mapping')
P.Register('mapping.delete', 'Supprimer des emplacements', 'mapping', true)
P.Register('mapping.io', 'Importer / exporter les emplacements', 'mapping', true)

PB.Migrate('022_places', 'Emplacements cartographiques', {
    [[CREATE TABLE IF NOT EXISTS pb_places (
        id INT NOT NULL AUTO_INCREMENT, kind VARCHAR(12) NOT NULL DEFAULT 'blip', label VARCHAR(64) NOT NULL DEFAULT '',
        grp VARCHAR(48) NOT NULL DEFAULT '', x DOUBLE NOT NULL DEFAULT 0, y DOUBLE NOT NULL DEFAULT 0, z DOUBLE NOT NULL DEFAULT 0,
        sprite INT NOT NULL DEFAULT 1, color INT NOT NULL DEFAULT 0, scale DOUBLE NOT NULL DEFAULT 0.8, radius DOUBLE NOT NULL DEFAULT 2,
        mtype INT NOT NULL DEFAULT 1, rgba VARCHAR(9) NOT NULL DEFAULT '#dfe2e7', shortrange TINYINT(1) NOT NULL DEFAULT 1,
        enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
})

local KINDS = { blip = 'Blip', marker = 'Marqueur', zone = 'Zone (cercle sur la carte)' }
local LIMIT = 500

local function all(onlyEnabled)
    return DB.q('SELECT * FROM pb_places' .. (onlyEnabled and ' WHERE enabled = 1' or '') .. ' ORDER BY grp, label') or {}
end

local function payload()
    local out = {}
    for _, r in ipairs(all(true)) do
        out[#out + 1] = { id = r.id, kind = r.kind, label = r.label, x = r.x, y = r.y, z = r.z, sprite = r.sprite, color = r.color, scale = r.scale,
            radius = r.radius, mtype = r.mtype, rgba = r.rgba, shortrange = PB.ToBool(r.shortrange) }
    end
    return out
end

function PB.PushPlaces(target)
    TriggerClientEvent('pb:places', target or -1, PB.Json(payload()))
end

exports('GetPlaces', function(group)
    local out = {}
    for _, r in ipairs(all(true)) do if not group or r.grp == group then out[#out + 1] = r end end
    return out
end)

AddEventHandler('playerJoining', function() local s = source SetTimeout(5000, function() PB.PushPlaces(s) end) end)
RegisterNetEvent('pb:clientReady', function() PB.PushPlaces(source) end)

local FIELDS = {
    { k = 'kind', type = 'select', label = 'Type', opts = { 'blip', 'marker', 'zone' }, required = true },
    { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 64 },
    { k = 'grp', type = 'text', label = 'Groupe (ex. métier, quartier)', maxlen = 48 },
    { k = 'coords', type = 'coords', label = 'Position', required = true },
    { k = 'sprite', type = 'number', label = 'Icône du blip (n°)', min = 0, max = 900, hint = 'Numéros listés sur la documentation FiveM (blips).' },
    { k = 'color', type = 'number', label = 'Couleur du blip (n°)', min = 0, max = 85 },
    { k = 'scale', type = 'number', label = 'Taille', min = 0.2, max = 3, int = false, step = 0.1 },
    { k = 'radius', type = 'number', label = 'Rayon (m)', min = 0.5, max = 500, int = false },
    { k = 'mtype', type = 'number', label = 'Forme du marqueur (n°)', min = 0, max = 43 },
    { k = 'rgba', type = 'color', label = 'Couleur du marqueur / de la zone' },
    { k = 'shortrange', type = 'toggle', label = 'Visible seulement à proximité' },
    { k = 'enabled', type = 'toggle', label = 'Actif' },
}

local function clean(v)
    local vals = {}
    for k, x in pairs(v) do vals[k] = x end
    local c = type(vals.coords) == 'table' and vals.coords or {}
    vals.coords = { x = PB.ToNum(c.x, nil), y = PB.ToNum(c.y, nil), z = PB.ToNum(c.z, 0) }
    if vals.coords.x == nil or vals.coords.y == nil then return nil, 'Position obligatoire.' end
    for _, f in ipairs(FIELDS) do
        if vals[f.k] == nil and f.k ~= 'coords' then
            vals[f.k] = ({ kind = 'blip', label = '', grp = '', sprite = 1, color = 0, scale = 0.8, radius = 2, mtype = 1, rgba = '#dfe2e7', shortrange = true, enabled = true })[f.k]
        end
    end
    local fields = {}
    for _, f in ipairs(FIELDS) do if f.k ~= 'coords' then fields[#fields + 1] = f end end
    local out, err = PB.Validate(fields, vals)
    if not out then return nil, err end
    out.x, out.y, out.z = vals.coords.x, vals.coords.y, vals.coords.z
    if math.abs(out.x) > 10000 or math.abs(out.y) > 10000 or math.abs(out.z) > 3000 then return nil, 'Coordonnées hors de la carte.' end
    return out
end

PB.Action('map.save', 'mapping.edit', function(ctx, p)
    local c, err = clean(p.values or {})
    if not c then return false, err end
    local id = PB.ToInt(p.id, 0)
    local before = id > 0 and DB.one('SELECT * FROM pb_places WHERE id = ?', { id }) or nil
    if id > 0 and not before then return false, 'Emplacement introuvable.' end
    if not before and (tonumber(DB.scalar('SELECT COUNT(*) FROM pb_places')) or 0) >= LIMIT then return false, 'Limite de ' .. LIMIT .. ' emplacements atteinte.' end
    local row = { kind = c.kind, label = c.label, grp = c.grp or '', x = c.x, y = c.y, z = c.z, sprite = c.sprite, color = c.color, scale = c.scale, radius = c.radius,
        mtype = c.mtype, rgba = c.rgba, shortrange = c.shortrange and 1 or 0, enabled = c.enabled and 1 or 0 }
    if before then
        row.id = id
        DB.upsert('pb_places', row, { 'id' })
    else
        local keys, qs, params = {}, {}, {}
        for _, k in ipairs(PB.Keys(row)) do keys[#keys + 1] = k qs[#qs + 1] = '?' params[#params + 1] = row[k] end
        id = DB.insert('INSERT INTO pb_places (' .. table.concat(keys, ',') .. ') VALUES (' .. table.concat(qs, ',') .. ')', params)
    end
    PB.PushPlaces()
    ctx.audit('config', before and 'lieu.modifier' or 'lieu.creer', c.label, before, row)
    ctx.toast = 'Enregistré et envoyé aux joueurs connectés.'
    return true, { open = { tab = 'edit', params = { id = id } } }
end)

PB.Action('map.delete', 'mapping.delete', function(ctx, p)
    local id = PB.ToInt(p.id, 0)
    local before = DB.one('SELECT * FROM pb_places WHERE id = ?', { id })
    if not before then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_places WHERE id = ?', { id })
    PB.PushPlaces()
    ctx.audit('config', 'lieu.supprimer', before.label, before)
    ctx.toast = 'Supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cet emplacement ?', text = 'Il disparaît immédiatement de la carte des joueurs.' } })

PB.Action('map.toggle', 'mapping.edit', function(ctx, p)
    local id = PB.ToInt(p.id, 0)
    local r = DB.one('SELECT enabled, label FROM pb_places WHERE id = ?', { id })
    if not r then return false, 'Introuvable.' end
    DB.exec('UPDATE pb_places SET enabled = ? WHERE id = ?', { PB.ToBool(r.enabled) and 0 or 1, id })
    PB.PushPlaces()
    ctx.audit('config', 'lieu.activer', r.label, { enabled = r.enabled }, { enabled = PB.ToBool(r.enabled) and 0 or 1 })
    ctx.toast = PB.ToBool(r.enabled) and 'Désactivé.' or 'Activé.'
    return true
end)

-- Position du joueur qui utilise le panel -------------------------------------------------------------------------------------------------------
local waiting = {}
RegisterNetEvent('pb:coords', function(x, y, z, h)
    local src = source
    local w = waiting[src]
    if w then waiting[src] = nil w:resolve({ x = PB.Round(tonumber(x) or 0, 2), y = PB.Round(tonumber(y) or 0, 2), z = PB.Round(tonumber(z) or 0, 2), h = PB.Round(tonumber(h) or 0, 2) }) end
end)

PB.Action('map.mypos', 'panel.open', function(ctx)
    if not ctx.src or ctx.src <= 0 then return false, 'Disponible seulement en jeu.' end
    local pr = promise.new()
    waiting[ctx.src] = pr
    TriggerClientEvent('pb:reqCoords', ctx.src)
    SetTimeout(3000, function() if waiting[ctx.src] == pr then waiting[ctx.src] = nil pr:resolve(nil) end end)
    local pos = Citizen.Await(pr)
    if not pos then return false, 'Position indisponible : réessaie.' end
    return true, { coords = pos }
end, { read = true })

PB.Action('map.export', 'mapping.io', function(ctx)
    ctx.audit('config', 'lieu.export', 'pb_places')
    return true, { download = { name = 'emplacements.json', text = PB.Json({ format = 'pb_panel-places', version = 1, places = all(false) }), mime = 'application/json' } }
end, { read = true })

PB.Action('map.import', 'mapping.io', function(ctx, p)
    local doc = PB.FromJson(tostring(p.values and p.values.json or ''), nil)
    if type(doc) ~= 'table' or doc.format ~= 'pb_panel-places' or type(doc.places) ~= 'table' then return false, "Ce fichier n'est pas une exportation d'emplacements." end
    if #doc.places > LIMIT then return false, 'Trop d\'entrées.' end
    local list = {}
    for i, r in ipairs(doc.places) do
        local c, err = clean({ kind = r.kind, label = r.label, grp = r.grp, coords = { x = r.x, y = r.y, z = r.z }, sprite = r.sprite, color = r.color, scale = r.scale, radius = r.radius,
            mtype = r.mtype, rgba = r.rgba, shortrange = r.shortrange, enabled = r.enabled })
        if not c then return false, 'Entrée ' .. i .. ' : ' .. tostring(err) end
        list[#list + 1] = c
    end
    for _, c in ipairs(list) do
        DB.insert('INSERT INTO pb_places (kind,label,grp,x,y,z,sprite,color,scale,radius,mtype,rgba,shortrange,enabled) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            { c.kind, c.label, c.grp or '', c.x, c.y, c.z, c.sprite, c.color, c.scale, c.radius, c.mtype, c.rgba, c.shortrange and 1 or 0, c.enabled and 1 or 0 })
    end
    PB.PushPlaces()
    ctx.audit('config', 'lieu.import', 'pb_places', nil, { count = #list })
    ctx.toast = #list .. ' emplacement(s) importé(s).'
    return true
end, { critical = true, confirm = { title = 'Importer ces emplacements ?', text = 'Ils sont ajoutés à ceux qui existent déjà.', danger = false } })

PB.Module({
    id = 'mapping', label = 'Cartographie', icon = 'map', group = 'Serveur', order = 110, perm = 'mapping.view', hint = 'Blips, marqueurs, zones, import / export',
    caps = function()
        return PB.Capsify({
            { 'Blips, marqueurs, zones', 'ok', 'Affichés par le client du panel, sans autre script.' },
            { 'Capture de la position en jeu', 'ok', 'Bouton « Ma position » : fonctionne si tu es connecté au serveur.' },
            { 'Carte interactive dans le panel', 'partial', 'Aperçu des points sur un plan simplifié (pas les tuiles du jeu).' },
            { 'Utilisation par d\'autres scripts', 'partial', 'Export GetPlaces(groupe) : le script doit l\'appeler.' },
            { 'MLO / props / mapping 3D', 'off', 'Hors du périmètre du panel : ce sont des ressources à installer.' },
        })
    end,
    doc = "## Cartographie\nLes emplacements sont stockés dans la base du panel et envoyés aux joueurs à la connexion et à chaque modification.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        local id = PB.ToInt(params and params.id, 0)
        return { tabs = {
            tab('list', 'Emplacements', 'list', function()
                local rows, groups = {}, {}
                for _, r in ipairs(all(false)) do
                    groups[r.grp] = true
                    rows[#rows + 1] = { label = r.label, kind = KINDS[r.kind] or r.kind, grp = r.grp, pos = ('%.1f, %.1f, %.1f'):format(r.x, r.y, r.z), on = PB.ToBool(r.enabled),
                        actions = ctx.has('mapping.edit') and { { nav = { tab = 'edit', params = { id = r.id } }, label = 'Modifier', icon = 'edit' }, { action = 'map.toggle', label = PB.ToBool(r.enabled) and 'Désactiver' or 'Activer', icon = 'power', payload = { id = r.id } } } or nil }
                end
                return { B.stats({ { label = 'Emplacements', value = #rows, icon = 'map' }, { label = 'Groupes', value = PB.Count(groups), icon = 'folder' } }),
                    B.table({ id = 'places', search = true, columns = { { k = 'label', label = 'Nom' }, { k = 'kind', label = 'Type' }, { k = 'grp', label = 'Groupe' }, { k = 'pos', label = 'Position', type = 'mono' }, { k = 'on', label = 'Actif', type = 'bool' } }, rows = rows, empty = 'Aucun emplacement.' }) }
            end),
            tab('edit', 'Éditeur', 'edit', function()
                local r = id > 0 and DB.one('SELECT * FROM pb_places WHERE id = ?', { id }) or nil
                local values = r and { kind = r.kind, label = r.label, grp = r.grp, coords = { x = r.x, y = r.y, z = r.z }, sprite = r.sprite, color = r.color, scale = r.scale, radius = r.radius,
                    mtype = r.mtype, rgba = r.rgba, shortrange = PB.ToBool(r.shortrange), enabled = PB.ToBool(r.enabled) }
                    or { kind = 'blip', label = '', grp = '', coords = { x = 0, y = 0, z = 0 }, sprite = 1, color = 0, scale = 0.8, radius = 2, mtype = 1, rgba = '#dfe2e7', shortrange = true, enabled = true }
                local blocks = { { type = 'form', id = 'place.form', title = r and ('Modifier ' .. r.label) or 'Créer un emplacement', cols = 3, fields = FIELDS, values = values,
                    submit = { action = 'map.save', label = r and 'Enregistrer' or 'Créer', payload = { id = r and r.id or 0 } } } }
                if r and ctx.has('mapping.delete') then blocks[#blocks + 1] = B.actions({ { action = 'map.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = r.id } } }) end
                return blocks
            end, 'mapping.edit'),
            tab('map', 'Plan', 'map', function()
                local pts = {}
                for _, r in ipairs(all(false)) do pts[#pts + 1] = { id = r.id, label = r.label, kind = r.kind, x = r.x, y = r.y, color = r.rgba, on = PB.ToBool(r.enabled) } end
                return { { type = 'map', id = 'plan', bounds = { minx = -4000, maxx = 4500, miny = -4500, maxy = 8000 }, points = pts, open = { tab = 'edit', key = 'id' } },
                    B.notice('info', 'Plan simplifié (coordonnées en mètres). Clique sur un point pour le modifier.') }
            end),
            tab('io', 'Import / export', 'download', function()
                return { B.actions({ { action = 'map.export', label = 'Exporter en JSON', icon = 'download' } }, 'Exportation'),
                    { type = 'form', id = 'places.import', title = 'Importer', cols = 1, fields = { { k = 'json', type = 'area', label = 'Contenu JSON', required = true, rows = 10 } }, values = { json = '' }, submit = { action = 'map.import', label = 'Importer' } } }
            end, 'mapping.io'),
        } }
    end,
})
