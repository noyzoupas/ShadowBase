-- Module 10 : Économie. Réglages de l'économie de Shadow Base, amendes et taxes (catalogue publié par exports), supervision de la masse monétaire.

local B, P, Form, FC, DB = PB.B, PB.Perm, PB.Form, PB.FileCfg, PB.DB

P.Register('economy.edit', "Modifier l'économie", 'economy')
P.Register('economy.catalog', 'Gérer les amendes et les taxes', 'economy')

-- Catalogues : amendes et taxes ------------------------------------------------------------------------------------------------------------------
PB.Migrate('021_economy', 'Amendes et taxes', {
    [[CREATE TABLE IF NOT EXISTS pb_fines (
        code VARCHAR(48) NOT NULL, label VARCHAR(96) NOT NULL, amount INT NOT NULL DEFAULT 0, jail INT NOT NULL DEFAULT 0, category VARCHAR(32) NOT NULL DEFAULT '', PRIMARY KEY (code))]],
    [[CREATE TABLE IF NOT EXISTS pb_taxes (
        code VARCHAR(48) NOT NULL, label VARCHAR(96) NOT NULL, rate DOUBLE NOT NULL DEFAULT 0, PRIMARY KEY (code))]],
})

exports('GetFines', function() return DB.q('SELECT code, label, amount, jail, category FROM pb_fines ORDER BY category, label') or {} end)
exports('GetFine', function(code) return DB.one('SELECT code, label, amount, jail, category FROM pb_fines WHERE code = ?', { tostring(code) }) end)
exports('GetTaxRate', function(code)
    local r = DB.one('SELECT rate FROM pb_taxes WHERE code = ?', { tostring(code) })
    return r and tonumber(r.rate) or 0
end)

PB.Action('economy.fine.save', 'economy.catalog', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' },
        { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
        { k = 'amount', type = 'number', label = 'Montant', min = 0, max = 100000000 },
        { k = 'jail', type = 'number', label = 'Prison (minutes)', min = 0, max = 100000 },
        { k = 'category', type = 'text', label = 'Catégorie', maxlen = 32 },
    }, { code = v.code, label = v.label, amount = v.amount or 0, jail = v.jail or 0, category = v.category or '' })
    if not c then return false, err end
    local before = DB.one('SELECT * FROM pb_fines WHERE code = ?', { c.code })
    DB.upsert('pb_fines', c, { 'code' })
    ctx.audit('config', before and 'amende.modifier' or 'amende.creer', c.code, before, c)
    ctx.toast = 'Amende enregistrée.'
    return true
end)

PB.Action('economy.fine.delete', 'economy.catalog', function(ctx, p)
    local code = tostring(p.code or '')
    local before = DB.one('SELECT * FROM pb_fines WHERE code = ?', { code })
    if not before then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_fines WHERE code = ?', { code })
    ctx.audit('config', 'amende.supprimer', code, before)
    ctx.toast = 'Amende supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette amende ?', text = 'Les scripts qui la lisent ne la trouveront plus.' } })

PB.Action('economy.tax.save', 'economy.catalog', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' },
        { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
        { k = 'rate', type = 'number', label = 'Taux (%)', min = 0, max = 100, int = false },
    }, { code = v.code, label = v.label, rate = v.rate or 0 })
    if not c then return false, err end
    local before = DB.one('SELECT * FROM pb_taxes WHERE code = ?', { c.code })
    DB.upsert('pb_taxes', c, { 'code' })
    ctx.audit('config', before and 'taxe.modifier' or 'taxe.creer', c.code, before, c)
    ctx.toast = 'Taxe enregistrée.'
    return true
end)

PB.Action('economy.tax.delete', 'economy.catalog', function(ctx, p)
    local code = tostring(p.code or '')
    local before = DB.one('SELECT * FROM pb_taxes WHERE code = ?', { code })
    if not before then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_taxes WHERE code = ?', { code })
    ctx.audit('config', 'taxe.supprimer', code, before)
    ctx.toast = 'Taxe supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette taxe ?', text = 'Les scripts qui la lisent utiliseront 0 %.' } })

-- Supervision -------------------------------------------------------------------------------------------------------------------------------------------
local function supervision()
    local rows, totals = {}, {}
    if DB.TableExists('pb_players') then
        for _, u in ipairs(DB.q("SELECT firstname, lastname, license, cash, bank FROM pb_players WHERE created = 1 LIMIT 5000") or {}) do
            local cash, bank = tonumber(u.cash) or 0, tonumber(u.bank) or 0
            totals.cash, totals.bank = (totals.cash or 0) + cash, (totals.bank or 0) + bank
            local who = ((u.firstname or '') .. ' ' .. (u.lastname or '')):gsub('^%s+', '')
            rows[#rows + 1] = { who = who ~= '' and who or u.license, total = cash + bank, detail = PB.Json({ cash = cash, bank = bank }) }
        end
    else
        return nil
    end
    table.sort(rows, function(a, b) return a.total > b.total end)
    return rows, totals
end

PB.Module({
    id = 'economy', label = 'Amendes et taxes', icon = 'gavel', group = 'Serveur', order = 91, perm = 'economy.view', hint = 'Amendes, taxes, masse monétaire',
    caps = function()
        local c = PB.Capsify({
            { 'Réglages d\'argent', 'ok', "Économie intégrée de Shadow Base : salaires, impôts, prix, banque, argent de départ (effet immédiat)." },
            { 'Supervision de la masse monétaire', 'ok', 'Comptes des joueurs de Shadow Base (lecture seule).' },
            { 'Amendes et taxes', 'partial', 'Catalogue publié par exports (GetFines, GetFine, GetTaxRate) : un script doit les utiliser.' },
            { 'Transfert / création d\'argent', 'off', "Outil d'administration en jeu : fourni par ta librairie admin, pas par le panel." },
        })
        return c
    end,
    doc = "## Économie\nLes amendes et les taxes sont un catalogue central. Tes scripts les lisent avec `exports.pb_panel:GetFine('code')` et `exports.pb_panel:GetTaxRate('code')`.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('fines', 'Amendes', 'gavel', function()
                local rows = {}
                for _, f in ipairs(DB.q('SELECT * FROM pb_fines ORDER BY category, label') or {}) do
                    rows[#rows + 1] = { code = f.code, label = f.label, amount = f.amount, jail = f.jail, category = f.category,
                        actions = ctx.has('economy.catalog') and { { action = 'economy.fine.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { code = f.code } } } or nil }
                end
                local blocks = { B.table({ id = 'fines', search = true, columns = { { k = 'code', label = 'Code', type = 'mono' }, { k = 'label', label = 'Intitulé' }, { k = 'amount', label = 'Montant', type = 'num' }, { k = 'jail', label = 'Prison (min)', type = 'num' }, { k = 'category', label = 'Catégorie' } }, rows = rows, empty = "Aucune amende. Ajoute-en : ton script de police pourra les lire." }) }
                if ctx.has('economy.catalog') then
                    blocks[#blocks + 1] = { type = 'form', id = 'fine.new', title = 'Ajouter ou modifier une amende', cols = 3, fields = {
                        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' }, { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
                        { k = 'amount', type = 'number', label = 'Montant', min = 0, max = 100000000 }, { k = 'jail', type = 'number', label = 'Prison (min)', min = 0, max = 100000 }, { k = 'category', type = 'text', label = 'Catégorie', maxlen = 32 } },
                        values = { code = '', label = '', amount = 0, jail = 0, category = '' }, submit = { action = 'economy.fine.save', label = 'Enregistrer' } }
                end
                return blocks
            end),
            tab('taxes', 'Taxes', 'percent', function()
                local rows = {}
                for _, t in ipairs(DB.q('SELECT * FROM pb_taxes ORDER BY label') or {}) do
                    rows[#rows + 1] = { code = t.code, label = t.label, rate = t.rate,
                        actions = ctx.has('economy.catalog') and { { action = 'economy.tax.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { code = t.code } } } or nil }
                end
                local blocks = { B.table({ id = 'taxes', columns = { { k = 'code', label = 'Code', type = 'mono' }, { k = 'label', label = 'Intitulé' }, { k = 'rate', label = 'Taux (%)', type = 'num' } }, rows = rows, empty = 'Aucune taxe.' }) }
                if ctx.has('economy.catalog') then
                    blocks[#blocks + 1] = { type = 'form', id = 'tax.new', title = 'Ajouter ou modifier une taxe', cols = 3, fields = {
                        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' }, { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
                        { k = 'rate', type = 'number', label = 'Taux (%)', min = 0, max = 100, int = false, step = 0.1 } },
                        values = { code = '', label = '', rate = 0 }, submit = { action = 'economy.tax.save', label = 'Enregistrer' } }
                end
                return blocks
            end),
            tab('supervision', 'Masse monétaire', 'chart', function()
                local rows, totals = supervision()
                if not rows then return { B.unsupported('Masse monétaire', 'Table des joueurs introuvable pour le framework détecté.') } end
                local items = {}
                for k, v in pairs(totals) do items[#items + 1] = { label = k, value = v, icon = 'coins' } end
                table.sort(items, function(a, b) return a.label < b.label end)
                local top = {}
                for i = 1, math.min(20, #rows) do top[#top + 1] = rows[i] end
                return { B.stats(items), B.table({ id = 'rich', title = 'Les 20 plus gros patrimoines', columns = { { k = 'who', label = 'Joueur' }, { k = 'total', label = 'Total', type = 'num' }, { k = 'detail', label = 'Détail', type = 'mono' } }, rows = top, empty = 'Aucun joueur.' }) }
            end),
        } }
    end,
})
