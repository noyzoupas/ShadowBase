-- Module 14 : Base de données (état, tables, migrations, recherche en lecture seule, entretien, exportation / restauration SQL,
-- console SQL). Les écritures sont réservées, confirmées avec le code PIN et journalisées.

local B, P, DB = PB.B, PB.Perm, PB.DB

P.Register('database.maintain', 'Optimiser / analyser des tables', 'database')
P.Register('database.dump', 'Exporter la base (SQL)', 'database', true)
P.Register('database.restore', 'Restaurer un export SQL', 'database', true)
P.Register('database.sql.read', 'Console SQL en lecture seule', 'database', true)
P.Register('database.sql.write', 'Console SQL avec écriture', 'database', true)

local NAME = '^[%w_]+$'

-- Export SQL -----------------------------------------------------------------------------------------------------------------------------------------
PB.Dump = PB.Dump or {}
local function esc(v)
    if v == nil then return 'NULL' end
    local t = type(v)
    if t == 'number' then return (v ~= v or v == math.huge or v == -math.huge) and 'NULL' or tostring(v) end
    if t == 'boolean' then return v and '1' or '0' end
    local s = tostring(v)
    s = s:gsub('\\', '\\\\'):gsub("'", "\\'"):gsub('\n', '\\n'):gsub('\r', '\\r'):gsub('%z', '\\0'):gsub('\26', '\\Z')
    return "'" .. s .. "'"
end
PB.Dump.Escape = esc

function PB.Dump.Tables()
    local rows = DB.q('SELECT TABLE_NAME AS name FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME')
    local out = {}
    for _, r in ipairs(rows or {}) do out[#out + 1] = r.name or r.TABLE_NAME end
    return out
end

-- tables : liste de noms ; opts.maxRows (par table). Renvoie texte, résumé.
function PB.Dump.Build(tables, opts)
    opts = opts or {}
    local maxRows = opts.maxRows or 100000
    local parts = { '-- pb_panel export SQL\n-- ' .. os.date('!%Y-%m-%dT%H:%M:%SZ') .. '\n' }
    local summary = { tables = 0, rows = 0, truncated = {} }
    for _, t in ipairs(tables) do
        if not t:match(NAME) then return nil, 'Nom de table invalide : ' .. t end
        local cols = DB.q('SELECT COLUMN_NAME AS name FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION', { t })
        if not cols or #cols == 0 then return nil, 'Table introuvable : ' .. t end
        local names = {}
        for _, c in ipairs(cols) do names[#names + 1] = '`' .. (c.name or c.COLUMN_NAME) .. '`' end
        parts[#parts + 1] = '\n-- table ' .. t .. '\nDELETE FROM `' .. t .. '`;\n'
        local offset, n = 0, 0
        while true do
            local rows = DB.q('SELECT * FROM `' .. t .. '` LIMIT 500 OFFSET ' .. offset)
            if not rows or #rows == 0 then break end
            for _, r in ipairs(rows) do
                local vals = {}
                for _, c in ipairs(cols) do vals[#vals + 1] = esc(r[c.name or c.COLUMN_NAME]) end
                parts[#parts + 1] = 'INSERT INTO `' .. t .. '` (' .. table.concat(names, ', ') .. ') VALUES (' .. table.concat(vals, ', ') .. ');\n'
                n = n + 1
            end
            offset = offset + 500
            if n >= maxRows then summary.truncated[#summary.truncated + 1] = t break end
            if #rows < 500 then break end
        end
        summary.tables = summary.tables + 1
        summary.rows = summary.rows + n
    end
    return table.concat(parts), summary
end

-- Découpe un export en instructions DELETE / INSERT autorisées ; refuse tout le reste.
function PB.Dump.Parse(text)
    local stmts = {}
    local i, len = 1, #text
    local buf, inStr, esc2 = {}, false, false
    local function flush(s)
        s = PB.Trim(s)
        if s == '' then return true end
        if s:match('^DELETE FROM `[%w_]+`$') or s:match('^INSERT INTO `[%w_]+` %(`[%w_`, ]+`%) VALUES %(') then stmts[#stmts + 1] = s return true end
        return false, s:sub(1, 60)
    end
    local cur = {}
    for line in (text .. '\n'):gmatch('([^\n]*)\n') do
        if #cur == 0 and (line:sub(1, 2) == '--' or PB.Trim(line) == '') then
            -- commentaire ou ligne vide hors instruction
        else
            cur[#cur + 1] = line
            -- une instruction se termine par « ; » hors chaîne : on compte les apostrophes non échappées
            local joined = table.concat(cur, '\n')
            local quotes, esc3 = 0, false
            for ch in joined:gmatch('.') do
                if esc3 then esc3 = false elseif ch == '\\' then esc3 = true elseif ch == "'" then quotes = quotes + 1 end
            end
            if quotes % 2 == 0 and joined:sub(-1) == ';' then
                local ok, bad = flush(joined:sub(1, -2))
                if not ok then return nil, 'Instruction non autorisée : ' .. tostring(bad) end
                cur = {}
            end
        end
    end
    if #cur > 0 then return nil, 'Export incomplet (instruction non terminée).' end
    return stmts
end

-- Actions ---------------------------------------------------------------------------------------------------------------------------------------------
PB.Action('database.maintain', 'database.maintain', function(ctx, p)
    local t, kind = tostring(p.table or ''), tostring(p.kind or '')
    if not t:match(NAME) then return false, 'Nom de table invalide.' end
    if kind ~= 'analyze' and kind ~= 'optimize' and kind ~= 'check' then return false, 'Opération inconnue.' end
    local res, err = DB.q((kind == 'check' and 'CHECK TABLE' or kind == 'analyze' and 'ANALYZE TABLE' or 'OPTIMIZE TABLE') .. ' `' .. t .. '`')
    if not res then return false, 'Échec : ' .. tostring(err) end
    local msg = res[1] and (res[1].Msg_text or res[1].msg_text) or 'OK'
    ctx.audit('config', 'bdd.' .. kind, t, nil, { result = msg })
    ctx.toast = kind .. ' ' .. t .. ' : ' .. tostring(msg)
    return true
end, { critical = true, confirm = { title = 'Lancer cette opération ?', text = 'Elle peut verrouiller brièvement la table.', danger = false } })

PB.Action('database.dump', 'database.dump', function(ctx, p)
    local tables = type(p.tables) == 'table' and p.tables or nil
    if not tables then
        tables = {}
        local v = p.values and p.values.tables
        if type(v) == 'table' then tables = v elseif type(v) == 'string' and v ~= '' then tables = PB.Split(v, ',') end
    end
    if #tables == 0 then tables = PB.Dump.Tables() end
    for i, t in ipairs(tables) do tables[i] = PB.Trim(t) end
    local text, sum = PB.Dump.Build(tables, { maxRows = 200000 })
    if not text then return false, sum end
    if #text > 12 * 1024 * 1024 then return false, "Export trop volumineux pour le navigateur (12 Mo) : utilise un export complet depuis le module Sauvegardes." end
    ctx.audit('config', 'bdd.export', #tables .. ' table(s)', nil, { rows = sum.rows })
    ctx.toast = sum.tables .. ' table(s), ' .. sum.rows .. ' ligne(s).' .. (#sum.truncated > 0 and (' Tronquées : ' .. table.concat(sum.truncated, ', ')) or '')
    return true, { download = { name = 'export-' .. os.date('!%Y%m%d-%H%M%S') .. '.sql', text = text, mime = 'application/sql' } }
end, { critical = true, pin = true, confirm = { title = 'Exporter la base ?', text = 'Le fichier peut contenir des données personnelles de tes joueurs.', danger = false } })

PB.Action('database.restore', 'database.restore', function(ctx, p)
    local text = tostring(p.values and p.values.sql or '')
    if #text < 10 then return false, 'Colle le contenu d\'un export du panel.' end
    local stmts, err = PB.Dump.Parse(text)
    if not stmts then return false, err end
    if #stmts == 0 then return false, 'Aucune instruction.' end
    if #stmts > 300000 then return false, 'Trop d\'instructions.' end
    local protected = { pb_migrations = true }
    local queries = {}
    for _, s in ipairs(stmts) do
        local t = s:match('^DELETE FROM `([%w_]+)`') or s:match('^INSERT INTO `([%w_]+)`')
        if protected[t] then return false, 'Table protégée : ' .. t end
        queries[#queries + 1] = { query = s }
    end
    local ok, e = DB.tx(queries)
    if not ok then return false, 'Restauration annulée (aucune modification) : ' .. tostring(e) end
    ctx.audit('config', 'bdd.restore', #stmts .. ' instruction(s)')
    ctx.toast = #stmts .. ' instruction(s) appliquées.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Restaurer cet export ?', text = 'Les tables présentes dans l\'export sont vidées puis remplies. Fais un export avant. Tout ou rien.' } })

local function firstWord(sql) return (sql:match('^%s*(%a+)') or ''):upper() end
local READ = { SELECT = true, SHOW = true, DESCRIBE = true, DESC = true, EXPLAIN = true }

PB.Action('database.sql', 'database.sql.read', function(ctx, p)
    local sql = PB.Trim(tostring(p.values and p.values.sql or ''))
    sql = sql:gsub(';%s*$', '')
    if sql == '' or #sql > 4000 then return false, 'Requête vide ou trop longue.' end
    if sql:find(';', 1, true) or sql:find('--', 1, true) or sql:find('/*', 1, true) then return false, 'Une seule instruction, sans commentaire.' end
    local w = firstWord(sql)
    if not READ[w] then return false, 'Lecture seule : SELECT, SHOW, DESCRIBE ou EXPLAIN.' end
    if w == 'SELECT' and (sql:upper():find('INTO%s+OUTFILE') or sql:upper():find('INTO%s+DUMPFILE') or sql:upper():find('LOAD_FILE')) then return false, 'Instruction interdite.' end
    if w == 'SELECT' and not sql:upper():find('%sLIMIT%s') then sql = sql .. ' LIMIT 200' end
    local rows, err = DB.q(sql)
    if not rows then return false, 'Erreur SQL : ' .. tostring(err) end
    local cols, seen = {}, {}
    for i = 1, math.min(#rows, 200) do for k in pairs(rows[i]) do if not seen[k] then seen[k] = true cols[#cols + 1] = k end end end
    table.sort(cols)
    local out = {}
    for i = 1, math.min(#rows, 200) do
        local r = {}
        for _, c in ipairs(cols) do local v = rows[i][c] if type(v) == 'table' then v = PB.Json(v) end r[c] = (v == nil) and '' or tostring(v):sub(1, 300) end
        out[#out + 1] = r
    end
    ctx.audit('config', 'bdd.sql.lecture', sql:sub(1, 160))
    return true, { table = { columns = cols, rows = out, total = #rows } }
end, { read = true, rate = 20 })

PB.Action('database.sql.write', 'database.sql.write', function(ctx, p)
    local sql = PB.Trim(tostring(p.values and p.values.sql or ''))
    sql = sql:gsub(';%s*$', '')
    if sql == '' or #sql > 4000 then return false, 'Requête vide ou trop longue.' end
    if sql:find(';', 1, true) or sql:find('--', 1, true) or sql:find('/*', 1, true) then return false, 'Une seule instruction, sans commentaire.' end
    local w = firstWord(sql)
    local WRITE = { INSERT = true, UPDATE = true, DELETE = true, ALTER = true, CREATE = true }
    if not WRITE[w] then return false, 'Instructions autorisées : INSERT, UPDATE, DELETE, ALTER, CREATE (pas DROP / TRUNCATE).' end
    if (w == 'UPDATE' or w == 'DELETE') and not sql:upper():find('%sWHERE%s') then return false, 'UPDATE et DELETE exigent une clause WHERE.' end
    local up = sql:upper()
    if up:find('OUTFILE') or up:find('DUMPFILE') or up:find('LOAD_FILE') or up:find('DROP%s') or up:find('TRUNCATE') then return false, 'Instruction interdite.' end
    local n, err = DB.exec(sql)
    if n == nil then return false, 'Erreur SQL : ' .. tostring(err) end
    ctx.audit('config', 'bdd.sql.ecriture', sql:sub(1, 200), nil, { affected = n })
    ctx.toast = n .. ' ligne(s) affectée(s).'
    return true
end, { critical = true, pin = true, rate = 10, confirm = { title = 'Exécuter cette requête ?', text = 'Elle modifie directement la base de données. Aucun retour arrière automatique.' } })

PB.Action('database.search', 'database.sql.read', function(ctx, p)
    local t, q = tostring(p.values and p.values.table or ''), PB.Trim(tostring(p.values and p.values.q or ''))
    if not t:match(NAME) or #q < 2 or #q > 80 then return false, 'Table ou texte invalide.' end
    local cols = DB.q('SELECT COLUMN_NAME AS name, DATA_TYPE AS dt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', { t })
    if not cols or #cols == 0 then return false, 'Table introuvable.' end
    local conds, params = {}, {}
    for _, c in ipairs(cols) do
        local dt = tostring(c.dt or c.DATA_TYPE):lower()
        if dt:find('char') or dt:find('text') or dt == 'json' then conds[#conds + 1] = '`' .. (c.name or c.COLUMN_NAME) .. '` LIKE ?' params[#params + 1] = '%' .. q:gsub('[%%_\\]', '') .. '%' end
    end
    if #conds == 0 then return false, 'Cette table n\'a pas de colonne texte.' end
    local rows = DB.q('SELECT * FROM `' .. t .. '` WHERE ' .. table.concat(conds, ' OR ') .. ' LIMIT 100', params) or {}
    local names, seen = {}, {}
    for _, r in ipairs(rows) do for k in pairs(r) do if not seen[k] then seen[k] = true names[#names + 1] = k end end end
    table.sort(names)
    local out = {}
    for _, r in ipairs(rows) do
        local o = {}
        for _, k in ipairs(names) do local v = r[k] o[k] = (v == nil) and '' or tostring(v):sub(1, 200) end
        out[#out + 1] = o
    end
    ctx.audit('config', 'bdd.recherche', t .. ' : ' .. q)
    return true, { table = { columns = names, rows = out, total = #rows } }
end, { read = true, rate = 20 })

-- Vue -----------------------------------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'database', label = 'Base de données', icon = 'database', group = 'Système', order = 130, perm = 'database.view', hint = 'Tables, migrations, exports, console',
    caps = function()
        return PB.Capsify({
            { 'État, tables, migrations', 'ok', 'Lecture de information_schema.' },
            { 'Requêtes lentes et erreurs', 'partial', 'Seules les requêtes passées par le panel sont mesurées (pas celles des autres scripts).' },
            { 'Exportation SQL', 'ok', 'Fichier téléchargé (données JSON/texte). Les colonnes binaires ne sont pas garanties.' },
            { 'Restauration SQL', 'ok', "Accepte uniquement les exports du panel (DELETE / INSERT), en transaction : tout ou rien." },
            { 'Console SQL', 'ok', 'Lecture : SELECT/SHOW/DESCRIBE/EXPLAIN. Écriture : réservée, PIN, sans DROP ni TRUNCATE.' },
            { 'Sauvegarde automatique complète', 'partial', 'Voir le module Sauvegardes (exports planifiés limités en taille).' },
        })
    end,
    doc = "## Base de données\nTout ce qui modifie la base est confirmé, journalisé et réservé aux grades autorisés. Fais un export avant toute écriture.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        local function resultTable(title) return { type = 'result', id = 'sqlresult', title = title } end
        return { tabs = {
            tab('overview', "Vue d'ensemble", 'home', function()
                local ver = DB.scalar('SELECT VERSION()') or '?'
                local size = DB.scalar('SELECT ROUND(SUM(DATA_LENGTH + INDEX_LENGTH)) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()')
                local n = DB.scalar('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()')
                local s = DB.Stats
                return { B.stats({ { label = 'Version', value = tostring(ver), icon = 'database' }, { label = 'Tables', value = tonumber(n) or 0, icon = 'table' },
                    { label = 'Taille', value = PB.FormatBytes(tonumber(size) or 0), icon = 'hard-drive' }, { label = 'Requêtes du panel', value = s.queries, icon = 'activity' },
                    { label = 'Erreurs SQL', value = s.errors, icon = 'alert' }, { label = 'Moyenne (ms)', value = s.queries > 0 and PB.Round(s.totalMs / s.queries, 1) or 0, icon = 'clock' } }) }
            end),
            tab('tables', 'Tables', 'table', function()
                local rows = {}
                for _, t in ipairs(DB.q('SELECT TABLE_NAME AS name, TABLE_ROWS AS n, ROUND(DATA_LENGTH + INDEX_LENGTH) AS size, ENGINE AS engine FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME') or {}) do
                    local name = t.name or t.TABLE_NAME
                    rows[#rows + 1] = { name = name, rows = tonumber(t.n or t.TABLE_ROWS) or 0, size = PB.FormatBytes(tonumber(t.size) or 0), engine = t.engine or t.ENGINE or '',
                        actions = ctx.has('database.maintain') and { { action = 'database.maintain', label = 'Analyser', icon = 'activity', payload = { table = name, kind = 'analyze' } }, { action = 'database.maintain', label = 'Vérifier', icon = 'check', payload = { table = name, kind = 'check' } }, { action = 'database.maintain', label = 'Optimiser', icon = 'wrench', payload = { table = name, kind = 'optimize' } } } or nil }
                end
                return { B.table({ id = 'dbtables', search = true, columns = { { k = 'name', label = 'Table', type = 'mono' }, { k = 'rows', label = 'Lignes (estimées)', type = 'num' }, { k = 'size', label = 'Taille' }, { k = 'engine', label = 'Moteur' } }, rows = rows, empty = 'Aucune table.' }) }
            end),
            tab('migrations', 'Migrations', 'layers', function()
                local rows = {}
                for _, m in ipairs(DB.MigrationState()) do rows[#rows + 1] = { id = m.id, name = m.name, ok = m.applied and { text = 'Appliquée', tone = 'ok' } or { text = 'En attente', tone = 'warn' }, at = m.applied_at or '' } end
                return { B.table({ id = 'mig', columns = { { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'name', label = 'Nom' }, { k = 'ok', label = 'État', type = 'badge' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Aucune migration.' }) }
            end),
            tab('slow', 'Lenteurs et erreurs', 'alert', function()
                local slow, errs = {}, {}
                for _, s in ipairs(DB.Slow) do slow[#slow + 1] = { at = s.at, ms = s.ms, sql = s.sql } end
                for _, e in ipairs(DB.Errors) do errs[#errs + 1] = { at = e.at, sql = e.sql, err = e.error } end
                return { B.table({ id = 'slow', title = 'Requêtes lentes (≥ ' .. DB.SlowMs .. ' ms, panel uniquement)', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'ms', label = 'Durée (ms)', type = 'num' }, { k = 'sql', label = 'Requête', type = 'mono' } }, rows = slow, empty = 'Aucune requête lente.' }),
                    B.table({ id = 'errs', title = 'Erreurs SQL', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'sql', label = 'Requête', type = 'mono' }, { k = 'err', label = 'Erreur' } }, rows = errs, empty = 'Aucune erreur.' }) }
            end),
            tab('search', 'Recherche', 'search', function()
                local opts = {}
                for _, n in ipairs(PB.Dump.Tables()) do opts[#opts + 1] = { n, n } end
                return { { type = 'form', id = 'db.search', title = 'Chercher dans une table (lecture seule)', cols = 2, fields = { { k = 'table', type = 'select', label = 'Table', options = opts, required = true }, { k = 'q', type = 'text', label = 'Texte', required = true, maxlen = 80 } },
                    values = { table = opts[1] and opts[1][1] or '', q = '' }, submit = { action = 'database.search', label = 'Chercher', show = 'result' } }, resultTable('Résultats') }
            end, 'database.sql.read'),
            tab('sql', 'Console SQL', 'terminal', function()
                local blocks = { B.notice('warn', "Une seule instruction par envoi. Chaque requête est journalisée.", 'Console SQL'),
                    { type = 'form', id = 'db.sql', title = 'Lecture seule', cols = 1, fields = { { k = 'sql', type = 'area', label = 'SELECT / SHOW / DESCRIBE / EXPLAIN', required = true, rows = 4, maxlen = 4000 } }, values = { sql = '' },
                        submit = { action = 'database.sql', label = 'Exécuter', show = 'result' } }, resultTable('Résultat') }
                if ctx.has('database.sql.write') then
                    blocks[#blocks + 1] = { type = 'form', id = 'db.sqlw', title = 'Écriture (INSERT / UPDATE / DELETE / ALTER / CREATE)', cols = 1, fields = { { k = 'sql', type = 'area', label = 'Requête', required = true, rows = 4, maxlen = 4000 } }, values = { sql = '' },
                        submit = { action = 'database.sql.write', label = 'Exécuter', danger = true } }
                end
                return blocks
            end, 'database.sql.read'),
            tab('dump', 'Export / restauration', 'download', function()
                local opts = {}
                for _, n in ipairs(PB.Dump.Tables()) do opts[#opts + 1] = { n, n } end
                local blocks = { { type = 'form', id = 'db.dump', title = 'Exporter', desc = 'Laisse vide pour exporter toutes les tables.', cols = 1, fields = { { k = 'tables', type = 'multi', label = 'Tables', options = opts } }, values = { tables = {} }, submit = { action = 'database.dump', label = 'Télécharger l\'export' } } }
                if ctx.has('database.restore') then
                    blocks[#blocks + 1] = { type = 'form', id = 'db.restore', title = 'Restaurer', desc = "Colle un export généré par le panel. Tout est exécuté en transaction.", cols = 1, fields = { { k = 'sql', type = 'area', label = 'Contenu SQL', required = true, rows = 10, maxlen = 12000000 } }, values = { sql = '' },
                        submit = { action = 'database.restore', label = 'Restaurer', danger = true } }
                end
                return blocks
            end, 'database.dump'),
        } }
    end,
})
