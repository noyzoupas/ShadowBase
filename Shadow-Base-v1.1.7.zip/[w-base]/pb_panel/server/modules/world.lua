-- Module 13 : Météo et monde (météo, heure, densité de population / véhicules). Appliqué par le client du panel (client/world.lua).
-- Un autre script de météo/heure actif entre en conflit : le panel le signale et ne l'arrête pas.

local B, P, Form = PB.B, PB.Perm, PB.Form

local WEATHER = { 'EXTRASUNNY', 'CLEAR', 'CLOUDS', 'OVERCAST', 'RAIN', 'THUNDER', 'SMOG', 'FOGGY', 'CLEARING', 'NEUTRAL', 'SNOW', 'BLIZZARD', 'SNOWLIGHT', 'XMAS', 'HALLOWEEN' }
local CONFLICTS = { 'vSync', 'cd_easytime', 'qb-weathersync', 'qbx_weathersync', 'Renewed-Weathersync', 'weathersync', 'esx_weather' }

local state = { weather = 'EXTRASUNNY', hour = 12, minute = 0, frozen = false, blackout = false }

local function opts() local o = {} for _, w in ipairs(WEATHER) do o[#o + 1] = w end return o end

local form = Form.Cfg({
    ns = 'world', id = 'main', title = 'Météo, heure et densité', perm = 'world.edit', cols = 2,
    desc = "Appliqué à tous les joueurs connectés dès l'enregistrement, et à chaque connexion.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Le panel pilote le monde', default = false, hint = 'Désactivé : ni météo ni heure (les PNJ et densités ci-dessous restent appliqués).' },
        { k = 'weather', type = 'select', label = 'Météo', opts = opts(), default = 'EXTRASUNNY' },
        { k = 'dynamic', type = 'toggle', label = 'Météo dynamique', default = false },
        { k = 'dynamic_list', type = 'multi', label = 'Météos possibles', opts = opts(), default = { 'EXTRASUNNY', 'CLEAR', 'CLOUDS', 'RAIN' } },
        { k = 'dynamic_minutes', type = 'number', label = 'Changement toutes les (minutes)', default = 20, min = 2, max = 240 },
        { k = 'time_mode', type = 'select', label = 'Heure', opts = { 'cycle', 'fixed', 'real' }, default = 'cycle', hint = 'cycle : le temps avance ; fixed : heure figée ; real : heure réelle du serveur.' },
        { k = 'fixed_hour', type = 'number', label = 'Heure figée', default = 12, min = 0, max = 23 },
        { k = 'minute_ms', type = 'number', label = 'Durée d\'une minute du jeu (ms)', default = 2000, min = 100, max = 60000 },
        { k = 'blackout', type = 'toggle', label = 'Panne de courant', default = false },
        { k = 'ped_density', type = 'range', label = 'Densité de piétons', default = 1.0, min = 0, max = 1, step = 0.05 },
        { k = 'veh_density', type = 'range', label = 'Densité de véhicules en circulation', default = 1.0, min = 0, max = 1, step = 0.05 },
        { k = 'parked_density', type = 'range', label = 'Densité de véhicules garés', default = 1.0, min = 0, max = 1, step = 0.05 },
        { k = 'police_wanted', type = 'toggle', label = 'Police du jeu (étoiles, patrouilles, hélicoptères)', default = false, hint = 'Désactivée par défaut : serveur GTA RP, la police est jouée par des joueurs.' },
        { k = 'no_npc', type = 'toggle', label = 'Supprimer les PNJ (piétons et circulation)', default = true, hint = 'Ville vide : plus aucun piéton ni voiture conduite par un PNJ. Les véhicules garés suivent leur curseur ; les PNJ des scripts (vendeurs…) restent.' },
        { k = 'no_npc_cops', type = 'toggle', label = 'Supprimer les PNJ police (agents, voitures, hélicoptères, bateaux)', default = true, hint = 'Même les voitures de police garées devant les commissariats. Les véhicules sortis par un joueur ou le staff ne sont pas touchés.' },
        { k = 'wind', type = 'range', label = 'Vent (vitesse)', default = 0.0, min = 0, max = 12, step = 0.5 },
    },
    after = function() PB.World.Push() return 'Appliqué aux joueurs.' end,
})

PB.World = PB.World or {}
local W = PB.World

function W.State()
    local c = PB.Cfg.All('world') or {}
    local mode = PB.Cfg.Get('world', 'time_mode', 'cycle')
    local hour, minute = state.hour, state.minute
    if mode == 'fixed' then hour, minute = PB.Cfg.Get('world', 'fixed_hour', 12), 0
    elseif mode == 'real' then local t = os.date('*t') hour, minute = t.hour, t.min end
    return {
        enabled = PB.Cfg.Get('world', 'enabled', false), weather = state.weather, hour = hour, minute = minute, mode = mode, minute_ms = PB.Cfg.Get('world', 'minute_ms', 2000),
        blackout = PB.Cfg.Get('world', 'blackout', false), ped = PB.Cfg.Get('world', 'ped_density', 1.0), veh = PB.Cfg.Get('world', 'veh_density', 1.0),
        parked = PB.Cfg.Get('world', 'parked_density', 1.0), wanted = PB.Cfg.Get('world', 'police_wanted', false), wind = PB.Cfg.Get('world', 'wind', 0.0),
        no_npc = PB.Cfg.Get('world', 'no_npc', true) == true, no_cops = PB.Cfg.Get('world', 'no_npc_cops', true) == true,
    }
end

-- Population (PNJ, densités) : appliquée même quand le panel ne pilote pas la météo et l'heure
local function popState()
    return { enabled = false, ped = PB.Cfg.Get('world', 'ped_density', 1.0), veh = PB.Cfg.Get('world', 'veh_density', 1.0), parked = PB.Cfg.Get('world', 'parked_density', 1.0),
        no_npc = PB.Cfg.Get('world', 'no_npc', true) == true, no_cops = PB.Cfg.Get('world', 'no_npc_cops', true) == true }
end

function W.Push(target)
    if not PB.Cfg.Get('world', 'enabled', false) then
        TriggerClientEvent('pb:world', target or -1, PB.Json(popState()))
        return
    end
    if not PB.Cfg.Get('world', 'dynamic', false) then state.weather = PB.Cfg.Get('world', 'weather', 'EXTRASUNNY') end
    TriggerClientEvent('pb:world', target or -1, PB.Json(W.State()))
end

W.Weathers = WEATHER
-- Utilisé par le menu staff : météo immédiate / heure figée (nil = le temps reprend son cours)
function W.SetWeather(w, actor)
    for _, x in ipairs(WEATHER) do
        if x == w then PB.Cfg.Set('world', 'weather', w, actor, 'Menu staff') state.weather = w W.Push() return true end
    end
    return false
end
function W.SetHour(h, actor)
    if h == nil then PB.Cfg.Set('world', 'time_mode', 'cycle', actor, 'Menu staff') W.Push() return true end
    h = math.floor(tonumber(h) or -1)
    if h < 0 or h > 23 then return false end
    PB.Cfg.Set('world', 'fixed_hour', h, actor, 'Menu staff') PB.Cfg.Set('world', 'time_mode', 'fixed', actor, 'Menu staff') W.Push()
    return true
end

RegisterNetEvent('pb:clientReady', function() W.Push(source) end)

-- PNJ et PNJ police : bloqués à la création (OneSync), puis nettoyage de ceux déjà présents ---------------------------------------------------------
-- Types de population GTA : 1 à 5 = PNJ du jeu (permanents, garés, patrouilles, scénarios, ambiants) ; 7 = créé par un script (jamais touché).
local COP_PEDS = { 's_m_y_cop_01', 's_f_y_cop_01', 's_m_y_sheriff_01', 's_f_y_sheriff_01', 's_m_y_hwaycop_01', 's_m_y_swat_01', 's_m_m_snowcop_01',
    's_m_y_ranger_01', 's_f_y_ranger_01', 's_m_m_ciasec_01', 's_m_m_fiboffice_01', 's_m_m_fibsec_01', 'csb_cop', 's_m_y_uscg_01', 's_m_m_prisguard_01' }
local COP_VEHS = { 'police', 'police2', 'police3', 'police4', 'policeb', 'policet', 'policeold1', 'policeold2', 'sheriff', 'sheriff2', 'fbi', 'fbi2',
    'pranger', 'riot', 'riot2', 'polmav', 'predator', 'pbus', 'lguard' }
local copModel = {}
for _, m in ipairs(COP_PEDS) do copModel[GetHashKey(m)] = true end
for _, m in ipairs(COP_VEHS) do copModel[GetHashKey(m)] = true end
W.CopPeds, W.CopVehs = COP_PEDS, COP_VEHS

local function ambient(ent)
    local pt = GetEntityPopulationType(ent)
    return pt >= 1 and pt <= 5, pt
end
-- type d'entité : 1 = ped, 2 = véhicule
local function unwanted(ent, noNpc, noCops)
    local amb, pt = ambient(ent)
    if not amb then return false end
    local kind = GetEntityType(ent)
    if noCops and copModel[GetEntityModel(ent)] then return true end
    if noNpc then
        if kind == 1 then return true end
        -- sans PNJ, plus personne ne conduit : la circulation part aussi (les véhicules garés, type 2, restent)
        if kind == 2 and pt ~= 2 then return true end
    end
    return false
end
local function popFlags() return PB.Cfg.Get('world', 'no_npc', true) == true, PB.Cfg.Get('world', 'no_npc_cops', true) == true end

AddEventHandler('entityCreating', function(ent)
    local noNpc, noCops = popFlags()
    if (noNpc or noCops) and unwanted(ent, noNpc, noCops) then CancelEvent() end
end)

function W.PurgePopulation()
    local noNpc, noCops = popFlags()
    if not noNpc and not noCops then return 0 end
    local n = 0
    for _, list in ipairs({ GetAllPeds(), GetAllVehicles() }) do
        for _, ent in ipairs(list) do
            if DoesEntityExist(ent) and unwanted(ent, noNpc, noCops) then
                -- jamais un véhicule avec un joueur dedans
                local hasPlayer = false
                if GetEntityType(ent) == 2 then
                    for seat = -1, 6 do
                        local ped = GetPedInVehicleSeat(ent, seat)
                        if ped ~= 0 and IsPedAPlayer(ped) then hasPlayer = true break end
                    end
                end
                if not hasPlayer then DeleteEntity(ent) n = n + 1 end
            end
        end
    end
    return n
end
PB.Cfg.OnChange('world', function(k) if k == nil or k == 'no_npc' or k == 'no_npc_cops' then SetTimeout(500, W.PurgePopulation) end end)
-- filet de sécurité : ce qui aurait échappé au blocage (entités déjà là au démarrage, créées avant l'activation…)
CreateThread(function()
    while true do
        Wait(15000)
        pcall(W.PurgePopulation)
    end
end)

-- Horloge et météo dynamique côté serveur (une seule source de vérité) --------------------------------------------------------------------
CreateThread(function()
    local sinceChange = 0
    while true do
        local ms = PB.Cfg.Get('world', 'minute_ms', 2000)
        Wait(math.max(500, ms))
        if PB.Cfg.Get('world', 'enabled', false) then
            if PB.Cfg.Get('world', 'time_mode', 'cycle') == 'cycle' then
                state.minute = state.minute + math.max(1, math.floor(500 / math.max(100, ms)) )
                if state.minute >= 60 then state.minute = 0 state.hour = (state.hour + 1) % 24 end
            end
            if PB.Cfg.Get('world', 'dynamic', false) then
                sinceChange = sinceChange + math.max(500, ms)
                if sinceChange >= PB.Cfg.Get('world', 'dynamic_minutes', 20) * 60000 then
                    sinceChange = 0
                    local list = PB.Cfg.Get('world', 'dynamic_list', { 'CLEAR' })
                    if type(list) == 'table' and #list > 0 then state.weather = list[math.random(#list)] W.Push() end
                end
            end
        end
    end
end)

local function conflicts()
    local out = {}
    for _, r in ipairs(CONFLICTS) do if GetResourceState(r) == 'started' then out[#out + 1] = r end end
    return out
end

PB.Action('world.weather.now', 'world.edit', function(ctx, p)
    local w = tostring(p.weather or '')
    local ok = false
    for _, x in ipairs(WEATHER) do if x == w then ok = true end end
    if not ok then return false, 'Météo inconnue.' end
    PB.Cfg.Set('world', 'weather', w, ctx.actor, 'Météo immédiate')
    state.weather = w
    W.Push()
    ctx.audit('config', 'monde.meteo', w)
    ctx.toast = 'Météo : ' .. w .. '.'
    return true
end)

PB.Module({
    id = 'world', label = 'Monde', icon = 'cloud', group = 'Serveur', order = 120, perm = 'world.view', hint = 'Météo, heure, densité',
    caps = function()
        local c = conflicts()
        return PB.Capsify({
            { 'Météo, heure, panne de courant', 'ok', 'Appliqués par le client du panel.' },
            { 'Densités de population et de circulation', 'ok', 'Multiplicateurs appliqués à chaque image.' },
            { 'Autre script de météo actif', #c == 0 and 'ok' or 'partial', #c == 0 and 'Aucun conflit détecté.' or ('Conflit possible avec ' .. table.concat(c, ', ') .. ' : n\'en garde qu\'un seul.') },
            { 'Saisons / neige permanente', 'partial', 'Les météos SNOW / XMAS sont disponibles ; la neige persistante au sol dépend du jeu.' },
        })
    end,
    doc = "## Monde\nCe module pilote la météo, l'heure et les densités. Active « Le panel pilote le monde » seulement si aucun autre script de météo n'est lancé.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('main', 'Réglages', 'sliders', function()
                local blocks = {}
                local c = conflicts()
                if #c > 0 then blocks[#blocks + 1] = B.notice('warn', 'Scripts de météo détectés : ' .. table.concat(c, ', ') .. '. Deux scripts qui pilotent la météo se battent entre eux.', 'Conflit possible') end
                blocks[#blocks + 1] = form(ctx)
                return blocks
            end),
            tab('now', 'Météo immédiate', 'cloud', function()
                local items = {}
                for _, w in ipairs(WEATHER) do items[#items + 1] = { action = 'world.weather.now', label = w, payload = { weather = w } } end
                local s = W.State()
                return { B.stats({ { label = 'Météo actuelle', value = s.weather, icon = 'cloud' }, { label = 'Heure', value = ('%02d:%02d'):format(s.hour, s.minute), icon = 'clock' }, { label = 'Piloté par le panel', value = s.enabled and 'Oui' or 'Non', icon = 'power' } }),
                    B.actions(items, 'Changer maintenant') }
            end, 'world.edit'),
        } }
    end,
})
