-- Nouveautés : journal des mises à jour affiché dans le panel (carte sur l'accueil + module « Nouveautés »).
-- Chaque lot ajoute une entrée à PB.Changelog (voir la liste plus bas). Le « lu / non lu » est mémorisé par administrateur (licence).
-- Pour ajouter une nouveauté : PB.News.Add({ id = 'lot37', date = 'AAAA-MM-JJ', title = '…', items = { { tag = 'Nouveau', text = '…', module = 'id-du-module' } } }).

local B, P, DB = PB.B, PB.Perm, PB.DB
local N = {}
PB.News = N

PB.Migrate('192_news_seen', 'Nouveautés : dernier lot lu par administrateur', {
    [[CREATE TABLE IF NOT EXISTS pb_news_seen (license VARCHAR(64) NOT NULL PRIMARY KEY, seq INT NOT NULL DEFAULT 0)]],
})

N.list = {}   -- du plus ancien au plus récent ; seq = position
function N.Add(e)
    if type(e) ~= 'table' or not e.id then return end
    for _, x in ipairs(N.list) do if x.id == e.id then return end end
    local items = {}
    for _, it in ipairs(e.items or {}) do
        items[#items + 1] = { tag = tostring(it.tag or 'Nouveau'):sub(1, 16), text = tostring(it.text or ''):sub(1, 240), module = it.module and tostring(it.module) or nil }
    end
    N.list[#N.list + 1] = { id = tostring(e.id), seq = #N.list + 1, date = tostring(e.date or ''), title = tostring(e.title or e.id):sub(1, 160), items = items }
end

local function seenOf(license)
    local r = license and DB.one('SELECT seq FROM pb_news_seen WHERE license = ?', { license })
    return r and tonumber(r.seq) or 0
end
-- Entrées pour un administrateur : { unseen, entries (les plus récentes d'abord) }
function N.For(license, limit)
    local seen, out, unseen = seenOf(license), {}, 0
    for i = #N.list, 1, -1 do
        local e = N.list[i]
        local isNew = e.seq > seen
        if isNew then unseen = unseen + 1 end
        if #out < (limit or 50) then out[#out + 1] = { id = e.id, date = e.date, title = e.title, items = e.items, new = isNew } end
    end
    return unseen, out
end
function N.MarkRead(license)
    if not license or #N.list == 0 then return end
    DB.exec('REPLACE INTO pb_news_seen (license, seq) VALUES (?, ?)', { license, N.list[#N.list].seq })
end

-- Journal des lots ----------------------------------------------------------------------------------------------------------------------
N.Add({ id = 'lot34', date = '2026-10-17', title = 'Patch notes 34 : téléphone, inventaire, boutiques', items = {
    { tag = 'Amélioré', text = "Boutiques, inventaire, notifications et HUD repensés.", module = 'shops' },
} })
N.Add({ id = 'lot35', date = '2026-10-17', title = 'Patch notes 35 : entreprises, gangs, carte', items = {
    { tag = 'Nouveau', text = "130 entreprises et gangs prêts à installer, rangés en 10 catégories.", module = 'biz' },
    { tag = 'Nouveau', text = "Module « Carte du jeu » : clique sur la carte, tu es téléporté, E pour poser un point.", module = 'carte' },
    { tag = 'Nouveau', text = "Menu staff : emploi, second emploi, gang, grade, armes dans l'inventaire, redémarrage planifié.", module = 'staff' },
    { tag = 'Corrigé', text = "Boutiques bloquées, noclip en véhicule, boutons grisés, éditeur d'automatisations." },
} })
N.Add({ id = 'lot36', date = '2026-10-17', title = 'Patch notes 36 : coffres, concession, tablettes', items = {
    { tag = 'Nouveau', text = "Coffre de véhicule (touche K) et touches capot, moteur, ceinture, vitres.", module = 'vehtrunk' },
    { tag = 'Nouveau', text = "Concession : 45 véhicules par défaut et nouvelle fiche (vitesse, places, coffre).", module = 'shops' },
    { tag = 'Nouveau', text = "Tablettes entreprise et gang complétées : équipe, annonces, journal, stats, paie, caisse commune, territoires…", module = 'orga' },
    { tag = 'Changé', text = "Noms au-dessus des têtes réservés au staff, couleur par grade.", module = 'tags' },
    { tag = 'Changé', text = "Créateur de personnage redessiné ; tablette transparente.", module = 'character' },
} })
N.Add({ id = 'fix37', date = '2026-10-17', title = 'Gros correctif de présentation', items = {
    { tag = 'Corrigé', text = "Commandes « restreintes » : la restriction ne s'appliquait jamais (faille corrigée).", module = 'commands' },
    { tag = 'Corrigé', text = "Second emploi : il est maintenant payé à chaque paie (pourcentage réglable).", module = 'biz' },
    { tag = 'Corrigé', text = "Points « bureau du patron / siège » : la tablette s'ouvre enfin." },
    { tag = 'Corrigé', text = "Garage : une page avec une note faisait planter l'écran." },
    { tag = 'Amélioré', text = "290 actions du panel et 119 événements du jeu testés avec des données absurdes : plus aucun plantage." },
} })

-- Actions -------------------------------------------------------------------------------------------------------------------------------
PB.Action('news.read', nil, function(ctx) N.MarkRead(ctx.license) return true, { unseen = 0 } end, { read = true })

-- Module --------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'whatsnew', label = 'Nouveautés', icon = 'sparkle', group = 'Pilotage', order = 5, perm = 'whatsnew.view', hint = 'Ce qui change à chaque mise à jour',
    doc = "## Nouveautés\nChaque mise à jour de Shadow Base ajoute une entrée ici, avec un lien direct vers le module concerné. Une pastille signale ce que tu n'as pas encore lu ; « Tout marquer comme lu » l'efface pour ton compte.",
    view = function(ctx)
        return { tabs = { { id = 'all', label = 'Mises à jour', icon = 'sparkle', build = function()
            local unseen, entries = N.For(ctx.license, 50)
            local blocks = {}
            if unseen > 0 then blocks[#blocks + 1] = B.actions({ { action = 'news.read', label = 'Tout marquer comme lu (' .. unseen .. ')', icon = 'check', primary = true } }) end
            for _, e in ipairs(entries) do
                local rows = {}
                for _, it in ipairs(e.items) do
                    local row = { tag = it.tag, text = it.text }
                    if it.module then row.actions = { { nav = it.module, label = 'Ouvrir', icon = 'arrow' } } end
                    rows[#rows + 1] = row
                end
                blocks[#blocks + 1] = B.table({ id = 'news_' .. e.id, title = (e.new and 'NOUVEAU · ' or '') .. e.title .. (e.date ~= '' and ('  (' .. e.date .. ')') or ''), columns = { { k = 'tag', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' } }, rows = rows })
            end
            if #blocks == 0 then blocks[1] = B.notice('info', 'Aucune nouveauté pour le moment.') end
            return blocks
        end } } }
    end,
})

N.Add({ id = 'lot39', date = '2026-10-17', title = 'Patch notes 39 : images, tablettes, placement, nettoyage', items = {
    { tag = 'Corrigé', text = "Images d'objets de l'inventaire et tablette des organisations (mise en page)." },
    { tag = 'Changé', text = "Tablette entreprise : uniquement les outils du métier (police : appels, détenus, amendes, dossiers).", module = 'biz' },
    { tag = 'Nouveau', text = "Placement à l'écran : déplace le vrai HUD, le chat, les menus et l'invite.", module = 'placement' },
    { tag = 'Changé', text = "Onglets en double supprimés (Services, Argent, Documentation, Garages).", module = 'general' },
} })

PB.SelfTest.Add('nouveautés', function(R)
    R.check(#N.list >= 3, 'journal', 'aucune entrée')
    local seen = {}
    for _, e in ipairs(N.list) do
        R.check(not seen[e.id], 'journal', 'identifiant en double : ' .. e.id)
        seen[e.id] = true
        R.check(#e.items > 0, 'journal', 'entrée vide : ' .. e.id)
    end
end)

N.Add({ id = 'patch40', date = '2026-10-18', title = 'Patch notes 40 : inventaire, territoires, points, identité', items = {
    { tag = 'Corrigé', text = "Inventaire : glisser-déposer, vrais filtres, armes jamais consommées (touches 1 à 5)." },
    { tag = 'Nouveau', text = "Tablette illégale : carte des territoires ; Mirror Park donne un gilet toutes les 10 h dans le coffre de l'organisation." },
    { tag = 'Nouveau', text = "Carte : « Configurer tout » pose tous les points d'une entreprise ou d'un gang d'une traite.", module = 'carte' },
    { tag = 'Changé', text = "Supérette : interface d'origine avec panier. Notifications : déplacement corrigé." },
    { tag = 'Nouveau', text = "Logo W et bannières Shadow Base (offres, Halloween, patch notes)." },
    { tag = 'Nouveau', text = "Menus : bannière animée Shadow Base (réglable dans Menus > Apparence).", module = 'menus' },
} })

N.Add({ id = 'patch41', date = '2026-10-18', title = 'Patch notes 41 : aides, infos, ALT, bannière, chuchoter', items = {
    { tag = 'Nouveau', text = "Barre d'aide en bas de l'écran : noclip (molette = vitesse, Ctrl, Maj) et cabine de vêtements." },
    { tag = 'Changé', text = "Les infos d'un joueur, l'argent, les papiers et la plaque s'affichent dans une fiche à côté du menu, plus en notification." },
    { tag = 'Nouveau', text = "Menu ALT en cascade, épuré (nouvelle version par défaut).", module = 'interface' },
    { tag = 'Nouveau', text = "Bannière des menus : le W se dessine, le texte suit le menu ouvert (Menu admin, Menu police…).", module = 'menus' },
    { tag = 'Nouveau', text = "Menu staff : Chuchoter, message que seul le joueur reçoit (voix privée en option).", module = 'staff' },
    { tag = 'Changé', text = "Le W de Shadow Base est le logo par défaut du panel.", module = 'general' },
} })
N.Add({ id = 'patch42', date = '2026-10-18', title = 'Patch notes 42 : organisations, starter pack, véhicules de gang', items = {
    { tag = 'Nouveau', text = "Carte du jeu › Entreprise / organisation : tu remplis les infos, puis tu es guidé en jeu pour poser le point coffre, le point boss, le rangement des véhicules et la sortie du garage.", module = 'carte' },
    { tag = 'Nouveau', text = "Module Organisations : création d'un gang avec ses grades, liste (membres, véhicules, caisse), réglages.", module = 'orgs' },
    { tag = 'Nouveau', text = "Starter pack à la création : objets dans le coffre, argent dans la caisse et trois véhicules de départ (tout est réglable).", module = 'orgs' },
    { tag = 'Nouveau', text = "Garage de gang : tu y retrouves tes véhicules et ceux de l'organisation ; les membres ont la clé des véhicules du gang.", module = 'garage' },
    { tag = 'Nouveau', text = "Donner un de tes véhicules à l'organisation, le reprendre, et le chef peut attribuer un véhicule du gang à un membre.", module = 'garage' },
    { tag = 'Nouveau', text = "Panel : ajouter un véhicule neuf à une organisation ou en attribuer un existant (par plaque).", module = 'orgs' },
    { tag = 'Changé', text = "Un garage de gang n'apparaît (carte, marqueur, touche E) que pour les membres de ce gang.", module = 'garage' },
} })


N.Add({ id = 'patch43', date = '2026-10-20', title = 'Patch notes 43 : extensions, staff, PNJ, correctif images', items = {
    { tag = 'Nouveau', text = 'Extensions : une autre ressource se branche sur Shadow Base (pages, réglages, actions, permissions). Module Extensions.', module = 'extensions' },
    { tag = 'Nouveau', text = 'Menu staff : « Libérer de prison » et liste des détenus dans Gestion des sanctions.' },
    { tag = 'Nouveau', text = 'Monde : supprimer les PNJ et les PNJ police (activés par défaut).', module = 'world' },
    { tag = 'Correctif', text = "Envoyer une image depuis le PC (bannière, logo) ne déconnecte plus." },
} })
N.Add({ id = 'patch44', date = '2026-10-20', title = 'Patch notes 44 : activités, blips, inventaire, territoires, HUD', items = {
    { tag = 'Nouveau', text = 'Activités ouvertes à tous (pêche, mine, bois, agriculture, cueillette, décharge, craft), posées au Builder.', module = 'wb_activites' },
    { tag = 'Nouveau', text = 'Blips : coffres en dégradé aux couleurs du serveur, QG de gang, vraie icône Burger Shot.' },
    { tag = 'Nouveau', text = "Message en entrant dans un territoire ; HUD faim / soif / micro et barres vie / armure." },
    { tag = 'Correctif', text = "Fond de l'inventaire : le jeu se voit derrière (plus noir opaque)." },
} })
N.Add({ id = 'patch45', date = '2026-10-20', title = 'Patch notes 45 : portes, menu boss, builder, GPS, animations', items = {
    { tag = 'Nouveau', text = 'Portes verrouillables par groupes (F10 › Builder › Portes ou /portes).', module = 'wb_portes' },
    { tag = 'Nouveau', text = 'Gestion des entreprises et organisations seulement au point boss.' },
    { tag = 'Nouveau', text = 'Builder : supprimer un point ou tous les points ; GPS dans le F5 ; animations manger et boire.' },
    { tag = 'Correctif', text = 'Burger Shot : menus qui clignotaient, client PNJ mal placé ; menu F2 retiré (tout est dans ALT).' },
} })
N.Add({ id = 'patch46', date = '2026-10-20', title = 'Patch notes 46 : points de métier pour toutes les entreprises', items = {
    { tag = 'Nouveau', text = 'Builder : accueil, atelier (garages), cuisine / bar et comptoir de vente selon le métier.', module = 'carte' },
} })
N.Add({ id = 'patch47', date = '2026-10-20', title = 'Patch notes 47 : agence immobilière, mises à jour', items = {
    { tag = 'Nouveau', text = 'Agence immobilière : annonces, intérieurs, visites et commission (menu ALT des agents).' },
    { tag = 'Nouveau', text = 'Module Mises à jour : nouvelles versions signées, patch notes et téléchargement gratuit.', module = 'updates' },
} })

N.Add({ id = 'patch48', date = '2026-10-21', title = 'Patch notes 48 : écran de chargement', items = {
    { tag = 'Nouveau', text = 'Écran de chargement : logo, barre de progression et bandeau de messages qui défile (ressource wb_loading).' },
} })
N.Add({ id = 'patch49', date = '2026-10-21', title = 'Patch notes 49 : la base devient Shadow Base', items = {
    { tag = 'Nouveau', text = 'Nouveau nom et nouveau logo : Shadow Base.', module = 'general' },
} })
N.Add({ id = 'patch50', date = '2026-10-21', title = 'Patch notes 50 : corrections, journal des expulsions, vestiaires, braquages', items = {
    { tag = 'Nouveau', text = "Journal des expulsions et bans : raison précise, origine et référence pour chaque kick.", module = 'kicks' },
    { tag = 'Correctif', text = "Anticheat : plus d'éjections pendant un restart ou un lag.", module = 'general' },
    { tag = 'Correctif', text = "Staff affiché hors ligne, touches des menus, onglets vides, suppression des anciens points.", module = 'general' },
    { tag = 'Nouveau', text = "Vrais vestiaires d'entreprise et de gang, vendeurs derrière le comptoir et braquages animés.", module = 'general' },
} })
N.Add({ id = 'patch51', date = '2026-10-21', title = 'Patch notes 51 : petits jobs, vraie pêche, vendeurs derrière le comptoir', items = {
    { tag = 'Nouveau', text = "Petits jobs pour chaque entreprise (touche O) : livraisons, taxi, dépannage, patrouille, secours, chantiers…", module = 'general' },
    { tag = 'Nouveau', text = "Pêche : raretés de poissons et de leurres, cannes, ferrage, marché aux prix variables, records.", module = 'general' },
    { tag = 'Correctif', text = "Vendeurs placés derrière le comptoir dans toutes les supérettes, magasins comme braquages.", module = 'shops' },
    { tag = 'Correctif', text = "Menotté : plus d'animations ; saisies au casier ; annonces visibles dans le chat ; couleur des gangs.", module = 'general' },
} })
N.Add({ id = 'patch52', date = '2026-10-21', title = 'Patch notes 52 : coiffeur / barbier, bandeau de démarrage', items = {
    { tag = 'Nouveau', text = "Coiffeur / barbier : coupe, couleurs, barbe, sourcils, maquillage, aperçu en direct. Builder › Commerces.", module = 'shops' },
    { tag = 'Nouveau', text = "Au démarrage, la console affiche la version, le numéro du dernier patch notes et l'état de la licence.", module = 'general' },
} })
N.Add({ id = 'patch53', date = '2026-10-21', title = 'Patch notes 53 : moins de métiers, Builder plus rapide, Auto Exotic, packs', items = {
    { tag = 'Amélioré', text = "Catalogue court : 14 entreprises utiles (dont Auto Exotic) ; les inutilisées sont retirées.", module = 'biz' },
    { tag = 'Amélioré', text = "Builder : Entrée pose le point tout de suite ; icône du siège au choix ; patron choisi parmi les joueurs connectés.", module = 'carte' },
    { tag = 'Nouveau', text = "3 packs de départ pour les organisations, donnés à la création.", module = 'orgs' },
    { tag = 'Correctif', text = "Points accueil / atelier / cuisine et points du Burger Shot : posés, affichés et supprimables.", module = 'carte' },
    { tag = 'Amélioré', text = "Inventaire : cases moins vertes, fond plus transparent.", module = 'inv' },
} })
N.Add({ id = 'patch54', date = '2026-10-21', title = 'Patch notes 54 : grosse optimisation, noms et ID réservés au staff', items = {
    { tag = 'Amélioré', text = "Noms, grades et ID visibles par le staff seulement (étiquettes, menu ALT, inventaire).", module = 'tags' },
    { tag = 'Amélioré', text = "Optimisation client et serveur : boucles allégées, moins d'envois réseau.", module = 'monitor' },
    { tag = 'Correctif', text = "Blips des entreprises : couleur, taille et portée rétablies.", module = 'carte' },
} })
N.Add({ id = 'patch55', date = '2026-10-22', title = 'Patch notes 55 : VIP, tatoueur, chasse, braquages, logements, animaux', items = {
    { tag = 'Nouveau', text = "VIP (menu staff, /vip, panel) : multi-personnages, animaux de compagnie, meubles, canne et leurres VIP, bonus de revente.", module = 'vip' },
    { tag = 'Nouveau', text = "Salon de tatouage, chasse, braquages (cambriolages, receleur, distributeurs, GoFast, fourgons blindés).", module = 'shops' },
    { tag = 'Nouveau', text = "Logements : impôt foncier, colocation, sonnette, intérieurs instanciés, meubles et aquarium.", module = 'housing' },
    { tag = 'Amélioré', text = "Builder (fantôme, Ctrl+Z), inventaire (tri, recherche, coffre), vestiaires, spectateur, événements programmés.", module = 'events' },
    { tag = 'Amélioré', text = "Optimisation : panel chargé à la demande, images allégées, purge des journaux, index.", module = 'monitor' },
} })
N.Add({ id = 'patch56', date = '2026-10-22', title = "Patch notes 56 : atelier d'armes, portes en ALT, menu ALT admin, VIP dans F5", items = {
    { tag = 'Nouveau', text = "Atelier d'armes clandestin (wb_armes) : ateliers cachés, pièces, plans, niveau d'armurier, finition, mini-jeu, marché noir.", module = 'extensions' },
    { tag = 'Nouveau', text = "Portes en ALT pour le staff : porte surlignée, choix des entreprises et gangs qui gardent l'accès, avec recherche.", module = 'ctx' },
    { tag = 'Nouveau', text = "Menu ALT staff : DV, pneus crevés, faire descendre, occupants avec ID, donner un véhicule, mute chat et micro, TP.", module = 'ctx' },
    { tag = 'Amélioré', text = "Carte « Mon VIP » dans le menu F5 : statut, date de fin, avantages.", module = 'personal' },
    { tag = 'Corrigé', text = "Invites E des extensions (pêche, chasse…) bloquées, envoi d'images depuis le PC bloqué, invite E hors de l'écran.", module = 'general' },
} })
N.Add({ id = 'patch57', date = '2026-10-22', title = 'Patch notes 57 : entreprises sur mesure et toutes les icônes de la carte', items = {
    { tag = 'Nouveau', text = "Entreprises sur mesure : nom libre, fonctionnement de n'importe quel type (mécano, café, bar, taxi…), créées au Builder ou dans le panel.", module = 'biz' },
    { tag = 'Nouveau', text = "Sélecteur des 965 icônes de GTA avec aperçu, recherche et couleur, pour le siège des entreprises.", module = 'biz' },
    { tag = 'Amélioré', text = "Type de fonctionnement et icône modifiables après coup ; les petits jobs suivent le type choisi.", module = 'biz' },
} })
N.Add({ id = 'patch58', date = '2026-10-22', title = 'Patch notes 58 : appels vocaux au téléphone', items = {
    { tag = 'Nouveau', text = "Appels vocaux (pma-voice) : application Appels avec clavier, appels récents et manqués ; bouton Appeler sur les contacts et les conversations.", module = 'phone' },
    { tag = 'Nouveau', text = "Appeler un service de l'annuaire : tous les employés en service sonnent, le premier qui décroche prend l'appel.", module = 'phone' },
    { tag = 'Nouveau', text = "Bandeau d'appel en haut de l'écran, sonnerie, téléphone à l'oreille ; /decrocher et /raccrocher.", module = 'phone' },
    { tag = 'Sécurité', text = "Canaux d'appel tirés au hasard et surveillés : un joueur qui tente d'écouter l'appel d'un autre est retiré et journalisé.", module = 'phone' },
} })
N.Add({ id = 'patch59', date = '2026-10-22', title = 'Patch notes 59 : radio F4, tickets Discord, anti-duplication, chronologie', items = {
    { tag = 'Nouveau', text = "Poste radio sur F4 : fréquence au pavé ou aux flèches, volume retenu, raccourcis vers les canaux de ton métier ; parler avec Verr. Maj.", module = 'radio' },
    { tag = 'Nouveau', text = "Tickets : /ticket (catégorie, conversation, suivi), /report devient un ticket ; le staff répond dans le panel ou directement sur Discord.", module = 'tickets' },
    { tag = 'Nouveau', text = "Anti-duplication : alerte quand un joueur gagne trop d'argent ou reçoit trop d'objets en 1 h (staff en service + Discord).", module = 'vigil' },
    { tag = 'Nouveau', text = "Chronologie d'un joueur : connexions, argent, objets, sanctions, tickets, expulsions et journal sur une seule ligne du temps.", module = 'vigil' },
    { tag = 'Nouveau', text = "Téléphone : partager sa position par message (bouton « Y aller ») et haut-parleur pendant un appel.", module = 'phone' },
    { tag = 'Corrigé', text = "Champs du panel refusés à tort (« format invalide ») : une touche comme F4 pour le noclip, les identifiants, les listes « nom|valeur ».", module = 'general' },
    { tag = 'Changé', text = "F4 n'est plus le raccourci staff « téléportation au point GPS » (à reprendre dans Staff › Raccourcis si besoin).", module = 'staff' },
} })
N.Add({ id = 'patch60', date = '2026-10-22', title = 'Patch notes 60 : bar et discothèque, télévisions, 911, conférences, coma', items = {
    { tag = 'Nouveau', text = "Bar, discothèque, café : le barman prépare au bar (ingrédients payés par la caisse) puis sert un client avec ALT ; le client accepte et paie.", module = 'biz' },
    { tag = 'Nouveau', text = "Télévisions : ALT sur un écran, puis un lien YouTube ou Vimeo ; tout le monde autour voit et entend la même vidéo.", module = 'tv' },
    { tag = 'Nouveau', text = "Téléphone : SOS 911 (police et secours sonnent et reçoivent ta position), conférence à plusieurs, numéros bloqués, groupes de discussion.", module = 'phone' },
    { tag = 'Nouveau', text = "Faim ou soif à 0 : coma (réanimation par les secours possible), avec un avertissement sous 10 %.", module = 'hud' },
    { tag = 'Nouveau', text = "Builder : dupliquer un point, déplacer tous les points d'un coup, « y aller » avec vérification du sol ; panel › Points posés (carte et problèmes).", module = 'pointsmap' },
    { tag = 'Amélioré', text = "Garage et téléphone : carburant, moteur et carrosserie de chaque véhicule, et bouton Localiser.", module = 'garage' },
    { tag = 'Amélioré', text = "Menu F10 : recherche unique (joueur, ID, plaque, numéro). Économie : gains par heure et par activité.", module = 'staff' },
} })
N.Add({ id = 'patch61', date = '2026-10-22', title = 'Patch notes 61 : points et étiquettes, garage avec aperçu, noclip fantôme', items = {
    { tag = 'Changé', text = "Plus de flèches : un petit point lumineux marque chaque endroit où interagir, et l'étiquette « [E] GARAGE » s'affiche dessus, dans le monde.", module = 'hud' },
    { tag = 'Nouveau', text = "Garage en menu : en descendant sur un véhicule, il apparaît en transparence à la sortie, avec une caméra.", module = 'garage' },
    { tag = 'Corrigé', text = "Fourrière : la récupération marche même sans point de sortie ou si le véhicule est resté en ville ; tu es mis au volant.", module = 'garage' },
    { tag = 'Amélioré', text = "Noclip : invisible pour tous les joueurs, tu te vois en transparence (ton véhicule aussi).", module = 'staff' },
} })
N.Add({ id = 'patch62', date = '2026-10-22', title = 'Patch notes 62 : atelier mécano facturé, customisation en direct, menu Shadow retravaillé', items = {
    { tag = 'Nouveau', text = "Customisation dans le véhicule : peintures (classique, mat, métal, chrome, nacré, teinte libre), jantes, carrosserie, Benny's, performances, xénons, néons, fumée, vitres, plaque, klaxon, livrée — chaque option s'affiche sur la voiture.", module = 'mech' },
    { tag = 'Nouveau', text = "Devis puis facture au client : il paie (la caisse de l'entreprise encaisse) ou refuse (la custom est retirée). Réparer et nettoyer depuis F5 › Mon entreprise, facturés pareil.", module = 'mech' },
    { tag = 'Nouveau', text = "Mécano en service : ouvre et conduit les véhicules des clients. Tenue de service (ex. Benny's) enfilée à la prise de service, vêtements rendus à la fin.", module = 'mech' },
    { tag = 'Changé', text = "Menu Shadow retravaillé (fond, bannière, lignes et icônes de la maquette).", module = 'menus' },
    { tag = 'Corrigé', text = "Inventaire : titres en français qui ne débordent plus, plus de cadenas « Premium » dans les coffres. Portes : beaucoup plus de portes détectées en ALT (portails, grilles, portes de garage, doubles portes).", module = 'inv' },
} })
