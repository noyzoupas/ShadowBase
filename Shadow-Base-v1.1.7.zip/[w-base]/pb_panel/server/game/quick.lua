-- Actions rapides (touche F2) : un menu « RageUI » construit par le serveur selon le métier, le grade et le service du joueur.
-- Aucune logique d'action ici : chaque entrée appelle l'action de la tablette (Biz.Act), qui revérifie droits, service, distance et montants.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Biz = G.Biz
local Q = {}
G.Quick = Q

P.Register('quick.edit', 'Modifier les actions rapides (F2)', 'quick', true)
PB.Cfg.Define('quick', { enabled = true, f2_menu = false, key = 'F2', fines_shown = 12, invoice_presets = { 'Prestation|250', 'Intervention|500', 'Dépannage|800' }, extra = {}, show_tablet = true, nearby_dist = 8 })
local function cfg(k, d) return PB.Cfg.Get('quick', k, d) end

-- Seules ces actions de la tablette peuvent être lancées depuis le menu F2
local ALLOWED = { duty = true, invoice = true, fine = true, cuff = true, uncuff = true, escort = true, put_veh = true, search = true, seize = true, revive = true, repair = true, jail = true, tig = true, casier = true }
Q.ALLOWED = ALLOWED

local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

-- Spécification pure (sans fonction) du menu : le client la transforme en éléments
function Q.Spec(src)
    if not cfg('enabled', true) then return nil, 'Les actions rapides sont désactivées.' end
    local c = Biz.Ctx(src)
    if not c then return nil, "Tu n'as pas d'entreprise." end
    local near = {}
    for _, n in ipairs(Biz.Nearby(src, cfg('nearby_dist', 8))) do near[#near + 1] = { id = n.id, name = n.name } end
    local e = {}
    local function add(x) e[#e + 1] = x end
    add({ id = 'duty', type = 'toggle', label = 'En service', desc = 'Prends ou quitte ton service.', icon = 'bolt', on = c.duty })
    if c.duty then
        if Biz.Allowed(c, 'cuff') then
            add({ id = 'cuff', needs = 'target', label = 'Menotter', desc = 'Menotte la personne ciblée, tout près de toi.', icon = 'lock' })
            add({ id = 'uncuff', needs = 'target', label = 'Libérer', desc = 'Retire les menottes de la personne ciblée.', icon = 'key' })
            add({ id = 'escort', needs = 'target', label = 'Escorter / lâcher', desc = 'La personne menottée te suit ; relance pour la lâcher.', icon = 'hand' })
            add({ id = 'put_veh', needs = 'target', label = 'Mettre dans le véhicule', desc = "Assied la personne menottée à l'arrière du véhicule le plus proche.", icon = 'car' })
        end
        if Biz.Allowed(c, 'search') then add({ id = 'search', needs = 'target', label = 'Fouiller', desc = 'Fouille une personne menottée.', icon = 'search' }) end
        if Biz.Allowed(c, 'fine') then
            local items = {}
            for _, f in ipairs(DB.q('SELECT code, label, amount FROM pb_fines ORDER BY category, label LIMIT ?', { cfg('fines_shown', 12) }) or {}) do items[#items + 1] = { code = f.code, label = f.label, amount = f.amount } end
            add({ id = 'fine', needs = 'target', label = 'Amende', desc = "Choisis l'infraction du catalogue, puis valide.", icon = 'tag', pick = items })
        end
        if Biz.Allowed(c, 'seize') then add({ id = 'seize', label = 'Mise en fourrière', desc = 'Saisit le véhicule le plus proche (motif demandé).', icon = 'key', inputs = { { k = 'reason', label = 'Motif', maxlen = 70 } } }) end
        if Biz.Allowed(c, 'jail') then
            add({ id = 'jail', needs = 'target', label = 'Prison', desc = 'Condamne une personne menottée : durée en minutes, puis motif.', icon = 'lock', inputs = { { k = 'amount', label = 'Minutes', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } } })
            add({ id = 'tig', needs = 'target', label = "Travaux d'intérêt général", desc = 'Nombre de tâches à effectuer, puis motif.', icon = 'hand', inputs = { { k = 'amount', label = 'Tâches', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } } })
        end
        if c.biz.kind == 'police' and (Biz.Allowed(c, 'records') or Biz.Allowed(c, 'jail')) then add({ id = 'casier', needs = 'target', label = 'Casier judiciaire', desc = "Affiche les dernières lignes du casier de la personne ciblée.", icon = 'book' }) end
        if c.biz.kind == 'police' and Biz.Allowed(c, 'records') and G.Weapons then
            add({ id = 'permit', needs = 'target', label = "Délivrer un permis d'arme", desc = "Donne le permis de port d'arme à la personne ciblée.", icon = 'id' })
            add({ id = 'permit_revoke', needs = 'target', label = "Retirer le permis d'arme", desc = "Retire le permis de la personne ciblée.", icon = 'x' })
        end
        if Biz.Allowed(c, 'revive') then add({ id = 'revive', needs = 'target', label = 'Réanimer', desc = "Réanime une personne inconsciente à côté de toi.", icon = 'heart' }) end
        if Biz.Allowed(c, 'repair') then
            add({ id = 'repair', label = 'Réparer le véhicule', desc = 'Répare le véhicule le plus proche.', icon = 'engine' })
            if PB.Cfg.Get('mech', 'enabled', true) then add({ id = 'workshop', label = 'Atelier', desc = 'Réparation complète et améliorations du véhicule le plus proche.', icon = 'engine' }) end
        end
        if Biz.Allowed(c, 'invoice') then
            local presets = {}
            for _, line in ipairs(cfg('invoice_presets', {}) or {}) do
                local l, a = tostring(line):match('^(.-)|(%d+)$')
                if l and l ~= '' then presets[#presets + 1] = { label = clean(l, 40), amount = tonumber(a) } end
            end
            add({ id = 'invoice', needs = 'target', label = 'Facturer', desc = 'Envoie une facture à la personne ciblée.', icon = 'card', pick = presets, inputs = { { k = 'amount', label = 'Montant', number = true, maxlen = 7 }, { k = 'reason', label = 'Motif', maxlen = 60 } } })
        end
    end
    for _, line in ipairs(cfg('extra', {}) or {}) do
        local l, d, cmd = tostring(line):match('^(.-)|(.-)|([%w_:%-]+)$')
        if l and l ~= '' then add({ id = 'cmd', label = clean(l, 40), desc = clean(d, 120), icon = 'link', cmd = cmd }) end
    end
    if cfg('show_tablet', true) then add({ id = 'tablet', label = 'Ouvrir la tablette', desc = 'Tableau de bord complet de ton entreprise.', icon = 'tablet' }) end
    return { biz = c.biz.label, kind = c.biz.kind, grade = c.grade.label, duty = c.duty, color = c.biz.color, near = near, entries = e }
end

local function has(spec, id) for _, x in ipairs(spec.entries) do if x.id == id then return x end end end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end

RegisterNetEvent('pb:g:quick:open', function()
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    local spec, err = Q.Spec(src)
    if not spec then G.Notify(src, { type = 'warn', title = 'Actions rapides', text = err }) return end
    TriggerClientEvent('pb:g:quick:ui', src, PB.Json({ ev = 'open', spec = spec }))
end)

function Q.Do(src, id, payload)
    id = tostring(id or '')
    local spec, err = Q.Spec(src)
    if not spec then return false, err end
    if id == 'workshop' then if has(spec, 'workshop') then TriggerClientEvent('pb:g:quick:workshop', src) return true end return false, 'Action indisponible.' end
    if id == 'tablet' then if has(spec, 'tablet') then TriggerClientEvent('pb:g:quick:tablet', src) return true end return false, 'Action indisponible.' end
    if id == 'cmd' then
        local cmd = type(payload) == 'table' and tostring(payload.cmd or '') or ''
        for _, x in ipairs(spec.entries) do if x.id == 'cmd' and x.cmd == cmd then TriggerClientEvent('pb:g:quick:cmd', src, cmd) return true end end
        return false, 'Action indisponible.'
    end
    if id == 'permit' or id == 'permit_revoke' then
        if not has(spec, id) then return false, 'Action indisponible.' end
        local tid = type(payload) == 'table' and tonumber(payload.id) or nil
        if not tid or tid == src or G.DistBetween(src, tid) > PB.Cfg.Get('ctx', 'act_dist', 3.5) + 1.5 then return false, 'Choisis une personne proche.' end
        local c = Biz.Ctx(src)
        local ok, msg = (id == 'permit' and G.Weapons.Grant or G.Weapons.Revoke)(src, tid, c and c.biz.label or nil)
        return ok, msg
    end
    if not ALLOWED[id] or not has(spec, id) then return false, 'Action indisponible.' end
    local p = type(payload) == 'table' and payload or {}
    local clean_p = { id = tonumber(p.id), on = p.on == true, code = p.code and clean(p.code, 40) or nil, amount = tonumber(p.amount), reason = clean(p.reason, 120) }
    if id == 'duty' then clean_p.on = p.on == true end
    return Biz.Act(src, id, clean_p, 'quick')
end

RegisterNetEvent('pb:g:quick:act', function(id, payload)
    local src = source
    if not usable(src) or not throttle(src, 300) then return end
    local ok, msg = Q.Do(src, id, payload)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Actions rapides', text = tostring(msg) }) end
    local spec = Q.Spec(src)
    TriggerClientEvent('pb:g:quick:ui', src, PB.Json({ ev = 'update', spec = spec, ok = ok and true or false }))
end)

local settings = Form.Cfg({ ns = 'quick', id = 'settings', title = 'Actions rapides', perm = 'quick.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Actions rapides actives', default = true, hint = 'Ce sont aussi les actions du métier du menu ALT : laisse activé.' },
    { k = 'f2_menu', type = 'toggle', label = 'Menu F2 (touche dédiée)', default = false, hint = 'Désactivé par défaut : les mêmes actions sont dans le menu ALT (sur la personne ou sur soi).' }, { k = 'key', type = 'text', label = "Touche d'ouverture (par défaut)", default = 'F2', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
    { k = 'nearby_dist', type = 'number', label = 'Distance de la liste des cibles (m)', default = 8, min = 2, max = 30 }, { k = 'fines_shown', type = 'number', label = "Infractions proposées (amende)", default = 12, min = 3, max = 30 },
    { k = 'show_tablet', type = 'toggle', label = "Proposer « Ouvrir la tablette »", default = true },
    { k = 'invoice_presets', type = 'list', label = 'Factures rapides (libellé|montant, un par ligne)', default = { 'Prestation|250', 'Intervention|500', 'Dépannage|800' }, maxitems = 10, maxlen = 60, pattern = '^[^|]+|%d+$', wide = true },
    { k = 'extra', type = 'list', label = 'Entrées personnalisées (libellé|description|commande, un par ligne)', default = {}, maxitems = 10, maxlen = 200, pattern = '^[^|]+|[^|]*|[%w_:%-]+$', wide = true, hint = "La commande est exécutée côté joueur (ex. un /emote de ton serveur). Pas d'espace dans la commande." },
} })

PB.Module({
    id = 'quick', label = 'Actions rapides (F2)', icon = 'bolt', group = 'Serveur', order = 140, perm = 'quick.edit', hint = 'Menu F2 des entreprises',
    caps = function()
        return PB.Capsify({
            { 'Menu F2 selon le métier (police, secours, garage, autres)', 'ok', "Les entrées dépendent du métier, du grade et du service." },
            { 'Cible : joueurs proches', 'ok', 'Liste actualisée à chaque ouverture ; le serveur revérifie la distance.' },
            { 'Mêmes règles que la tablette', 'ok', 'Chaque entrée appelle la même action : droits, service, montants et dossiers identiques.' },
            { 'Actions hors liste', 'off', "Le menu ne peut lancer que les actions prévues : pas d'action arbitraire envoyée par le client." },
        })
    end,
    doc = "## Actions rapides\nLe joueur appuie sur **F2** (réglable). Il voit seulement ce que son métier, son grade et son service lui permettent.\n\nPour menotter, fouiller, facturer ou réanimer, il choisit d'abord la **cible** (joueurs proches), puis l'action. Le serveur revérifie tout.\n\nTu peux ajouter des entrées personnalisées qui lancent une commande de ton serveur.",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'quick', title = "Menu F2 d'un officier (exemple)", cfg = PB.Cfg.All('menus') } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('actions rapides F2', function(R)
    for id in pairs(ALLOWED) do R.check(Biz.ACT[id] ~= nil, 'action « ' .. id .. ' »', "l'action n'existe plus dans la tablette") end
end)
