-- VIP : statut donné par le staff (menu staff F10 sur un joueur, commande /vip, panel), avec durée ou permanent.
-- Avantages (lus par les autres modules et ressources via G.Vip.Is / exports.pb_panel:IsVip) : multi-personnages, animal de compagnie,
-- meubles dans les logements, canne et leurre VIP, bonus de vente (pêche, chasse).

local G, DB, P, B = PB.G, PB.DB, PB.Perm, PB.B
local V = {}
G.Vip = V

P.Register('staff.vip', 'Donner ou retirer le VIP (menu staff, commande /vip)', 'staff', true)
P.Register('vip.view', 'Voir la liste des VIP', 'game')

PB.Migrate('214_vip', 'VIP : statut des joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_vip (license VARCHAR(64) NOT NULL, until_at INT NOT NULL DEFAULT 0, name VARCHAR(64) NOT NULL DEFAULT '', given_by VARCHAR(64) NOT NULL DEFAULT '',
        at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
})
PB.Cfg.Define('vip', { enabled = true, sell_bonus = 15, chars = 3, label = 'VIP' })

-- cache : licence -> fin (0 = permanent) | false ; relu au plus toutes les 60 s
local cache = {}
local function now() return os.time() end
local function untilOf(license)
    if not license then return false end
    local c = cache[license]
    if c and now() - c.t < 60 then return c.v end
    local r = DB.one('SELECT until_at FROM pb_vip WHERE license = ?', { license })
    local v = r and tonumber(r.until_at) or false
    cache[license] = { t = now(), v = v }
    return v
end
function V.IsLicense(license)
    if PB.Cfg.Get('vip', 'enabled', true) == false then return false end
    local u = untilOf(license)
    return u ~= false and (u == 0 or u > now())
end
local function account(src) return P.GetLicense(tonumber(src) or -1) end   -- le VIP est celui du compte, quel que soit le personnage
function V.Is(src) local lic = account(src) return lic ~= nil and V.IsLicense(lic) end
function V.Until(src) local lic = account(src) return lic and untilOf(lic) or false end

local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 64) end return (GetPlayerName(src) or ('Joueur ' .. src)):sub(1, 64) end
local function push(src) TriggerClientEvent('pb:g:vip', src, V.Is(src) and true or false) end

-- days : nombre de jours (0 ou nil = permanent). Prolonge un VIP en cours.
function V.Give(src, days, by)
    local p = G.Get(tonumber(src) or -1)
    if not p then return false, 'Joueur introuvable.' end
    p = { license = account(src) }
    days = math.floor(tonumber(days) or 0)
    if days < 0 or days > 3650 then return false, 'Durée invalide (0 = permanent, sinon 1 à 3650 jours).' end
    local cur = untilOf(p.license)
    local base = (cur and cur > now()) and cur or now()
    local u = days == 0 and 0 or (cur == 0 and 0 or base + days * 86400)
    DB.exec('REPLACE INTO pb_vip (license, until_at, name, given_by, at) VALUES (?, ?, ?, ?, ?)', { p.license, u, display(src), tostring(by or 'système'):sub(1, 64), now() })
    cache[p.license] = nil
    PB.Audit.Log('staff', 'vip.give', by or 0, display(src) .. ' #' .. src, nil, { jours = days, jusque = u })
    push(src)
    G.Notify(src, { type = 'success', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = u == 0 and 'Tu es VIP à vie. Merci !' or ('Tu es VIP jusqu\'au %s. Merci !'):format(os.date('%d/%m/%Y', u)) })
    TriggerEvent('pb_panel:vipChanged', src, true)
    return true, u == 0 and (display(src) .. ' est VIP à vie.') or (display(src) .. (' est VIP jusqu\'au %s.'):format(os.date('%d/%m/%Y', u)))
end
function V.RemoveLicense(license, by)
    DB.exec('DELETE FROM pb_vip WHERE license = ?', { tostring(license) })
    cache[tostring(license)] = nil
    PB.Audit.Log('staff', 'vip.remove', by or 0, tostring(license), nil, nil)
    for src in pairs(G.Players()) do
        if account(src) == license then push(src) G.Notify(src, { type = 'info', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = 'Ton statut VIP a pris fin.' }) TriggerEvent('pb_panel:vipChanged', src, false) end
    end
    return true
end
function V.Remove(src, by)
    local p = G.Get(tonumber(src) or -1)
    if not p then return false, 'Joueur introuvable.' end
    p = { license = account(src) }
    if not V.IsLicense(p.license) then return false, display(src) .. " n'est pas VIP." end
    V.RemoveLicense(p.license, by)
    return true, display(src) .. " n'est plus VIP."
end

exports('IsVip', function(src) return V.Is(src) end)
exports('SetVip', function(src, days) return V.Give(src, days, GetInvokingResource() or 'script') end)
exports('RemoveVip', function(src) return V.Remove(src, GetInvokingResource() or 'script') end)

table.insert(G.beginHooks, function(src) push(src) end)
-- fin d'un VIP à durée : on prévient le joueur (vérifié toutes les 5 min)
CreateThread(function()
    while true do
        Wait(300000)
        for src in pairs(G.Players()) do
            local lic = account(src)
            local c = lic and cache[lic]
            if c and c.v and c.v > 0 and c.v <= now() then cache[lic] = nil push(src) end
        end
    end
end)

-- Commandes : /vip <id> [jours] (0 = permanent) et /unvip <id>. Console ou staff avec le droit « staff.vip ».
local function can(src) return src == 0 or P.Has(src, 'staff.vip') end
local function reply(src, ok, msg) if src == 0 then print(('[VIP] %s'):format(tostring(msg))) else G.Notify(src, { type = ok and 'success' or 'error', title = 'VIP', text = tostring(msg) }) end end
RegisterCommand('vip', function(src, args)
    if not can(src) then return end
    local t = tonumber(args[1])
    if not t or not G.Get(t) then reply(src, false, 'Usage : /vip <id du joueur> [jours, 0 = permanent]') return end
    reply(src, V.Give(t, tonumber(args[2]) or 0, src == 0 and 'console' or display(src)))
end, false)
RegisterCommand('unvip', function(src, args)
    if not can(src) then return end
    local t = tonumber(args[1])
    if not t or not G.Get(t) then reply(src, false, 'Usage : /unvip <id du joueur>') return end
    reply(src, V.Remove(t, src == 0 and 'console' or display(src)))
end, false)

-- Menu staff (F10) : actions sur un joueur
PB.OnReady(function()
    if not (G.Staff and G.Staff.Def) then return end
    G.Staff.Def('vip_give', 'staff.vip', { target = true, inputs = { { k = 'days', label = 'Durée en jours (0 = permanent)', number = true, maxlen = 4 } }, run = function(src, t, p)
        return V.Give(t, tonumber(p.days) or 0, display(src))
    end })
    G.Staff.Def('vip_remove', 'staff.vip', { target = true, run = function(src, t) return V.Remove(t, display(src)) end })
end)

-- Panel : liste, ajout par licence, retrait
PB.Action('vip.remove', 'staff.vip', function(ctx, p)
    local lic = tostring(p.license or '')
    if lic == '' then return false, 'Licence manquante.' end
    V.RemoveLicense(lic, ctx.actor)
    ctx.toast = 'VIP retiré.'
    return true
end, { confirm = { title = 'Retirer le VIP ?', text = 'Le joueur perd ses avantages tout de suite.' } })
PB.Action('vip.add', 'staff.vip', function(ctx, p)
    local v = p.values or p
    local id = tonumber(v.id)
    if not id or not G.Get(id) then return false, 'Joueur introuvable (ID en jeu).' end
    local ok, msg = V.Give(id, tonumber(v.days) or 0, ctx.actor)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
PB.Module({
    id = 'vip', label = 'VIP', icon = 'crown', group = 'Serveur', order = 139, perm = 'vip.view', hint = 'Joueurs VIP et leurs avantages',
    doc = "## VIP\nDonne le VIP en jeu : **menu staff (F10) › Joueurs › un joueur › Donner le VIP** (durée en jours, 0 = permanent), ou la commande **/vip <id> [jours]** (et **/unvip <id>**), utilisable aussi depuis la console.\n\nAvantages : plusieurs personnages, animal de compagnie, meubles dans les logements, canne et leurre VIP, bonus de revente (pêche, chasse).",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Joueurs VIP', icon = 'crown', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_vip ORDER BY at DESC') or {}) do
                    local u = tonumber(r.until_at) or 0
                    rows[#rows + 1] = { name = r.name, license = '…' .. tostring(r.license):sub(-8), till = u == 0 and 'Permanent' or os.date('%d/%m/%Y %H:%M', u), state = (u == 0 or u > now()) and { text = 'Actif', tone = 'ok' } or { text = 'Expiré', tone = 'off' },
                        by = r.given_by, actions = ctx.has('staff.vip') and { { action = 'vip.remove', label = 'Retirer', icon = 'x', danger = true, payload = { license = r.license } } } or {} }
                end
                local blocks = { B.table({ id = 'vipl', title = 'VIP (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Joueur' }, { k = 'license', label = 'Licence', type = 'mono' }, { k = 'till', label = "Jusqu'au" }, { k = 'state', label = 'État', type = 'badge' }, { k = 'by', label = 'Donné par' } }, rows = rows, empty = 'Aucun VIP pour le moment.' }) }
                if ctx.has('staff.vip') then
                    blocks[#blocks + 1] = { type = 'form', id = 'vip.add', title = 'Donner le VIP à un joueur connecté', cols = 2, fields = { { k = 'id', type = 'number', label = 'ID en jeu', required = true, min = 1, max = 65535 }, { k = 'days', type = 'number', label = 'Jours (0 = permanent)', min = 0, max = 3650 } },
                        values = { id = '', days = 30 }, submit = { action = 'vip.add', label = 'Donner' } }
                end
                return blocks
            end },
        } }
    end,
})
