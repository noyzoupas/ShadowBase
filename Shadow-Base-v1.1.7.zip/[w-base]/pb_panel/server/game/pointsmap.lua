-- Points posés : carte de TOUS les points du serveur (entreprises, groupes, magasins, garages, banques) avec les problèmes détectables
-- côté serveur (position vide, hors carte, sous le niveau de la mer, doublon, très loin du siège), et « Tester en jeu » :
-- le staff est téléporté sur le point, puis son jeu vérifie le sol (sous le sol, dans le vide, en l'air).
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G
local PM = {}
G.PointsMap = PM

local function f(v) return tonumber(v) or 0 end
local function d2(a, b) local dx, dy = f(a.x) - f(b.x), f(a.y) - f(b.y) return math.sqrt(dx * dx + dy * dy) end

function PM.Collect()
    local out = {}
    local function add(kind, oid, owner, key, label, x, y, z, hq)
        out[#out + 1] = { key = kind .. '|' .. oid .. '|' .. key, kind = kind, oid = oid, owner = owner, label = label, x = f(x), y = f(y), z = f(z), hq = hq }
    end
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do
        local hq = (f(b.hx) ~= 0 or f(b.hy) ~= 0) and { x = b.hx, y = b.hy } or nil
        for _, p in ipairs(G.BuilderAllPoints and G.BuilderAllPoints('biz', b.id, 0) or {}) do add('biz', b.id, b.label, p.key, p.label, p.x, p.y, p.z, hq) end
    end
    for gid, g in pairs(G.Tags and G.Tags.GangDefs() or {}) do
        local all = G.BuilderAllPoints and G.BuilderAllPoints('gang', gid, 0) or {}
        local hq
        for _, p in ipairs(all) do if p.label:find('QG', 1, true) then hq = p break end end
        for _, p in ipairs(all) do add('gang', gid, g.label or gid, p.key, p.label, p.x, p.y, p.z, hq) end
    end
    for _, r in ipairs(DB.q("SELECT id, kind, label, x, y, z, opts FROM pb_shops WHERE opts NOT LIKE '%biz%' OR opts IS NULL") or {}) do add('shop', 'shops', 'Magasins', 'sh:' .. r.id, (r.label ~= '' and r.label or r.kind), r.x, r.y, r.z) end
    for _, r in ipairs(DB.q("SELECT id, label, kind, x, y, z FROM pb_garages WHERE biz = ''") or {}) do add('garage', 'garages', 'Garages publics', 'ga:' .. r.id, r.label, r.x, r.y, r.z) end
    for _, r in ipairs(DB.q('SELECT id, kind, label, x, y, z FROM pb_bank_points') or {}) do add('bank', 'bank', 'Banques', 'bk:' .. r.id, r.label, r.x, r.y, r.z) end
    return out
end

-- Problèmes visibles sans être en jeu
function PM.Issues(list)
    for i, p in ipairs(list) do
        local iss = {}
        if p.x == 0 and p.y == 0 then iss[#iss + 1] = 'Position vide (0, 0)'
        else
            if p.x < -4500 or p.x > 4600 or p.y < -4600 or p.y > 8600 then iss[#iss + 1] = 'Hors de la carte' end
            if p.z < -5 then iss[#iss + 1] = ('Sous le niveau de la mer (z = %.0f)'):format(p.z) end
            if p.hq and d2(p, p.hq) > 1500 and not p.label:find('Garage', 1, true) then iss[#iss + 1] = ('À %.1f km du siège'):format(d2(p, p.hq) / 1000) end
            for j = 1, i - 1 do
                local q = list[j]
                if q.oid == p.oid and q.label == p.label and d2(p, q) < 0.4 and math.abs(p.z - q.z) < 1 then iss[#iss + 1] = 'Doublon (même point au même endroit)' break end
            end
        end
        p.issues = iss
    end
    return list
end

PB.Action('points.goto', 'carte.place', function(ctx, p)
    local src = tonumber(ctx.src) or 0
    if src <= 0 or not G.Get(src) then return false, 'Ouvre le panel en jeu pour te téléporter.' end
    for _, pt in ipairs(PM.Collect()) do
        if pt.key == tostring(p.key) then
            TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = pt.x, y = pt.y, z = pt.z }))
            TriggerClientEvent('pb:g:points:check', src, PB.Json({ x = pt.x, y = pt.y, z = pt.z, label = pt.owner .. ' — ' .. pt.label }))
            ctx.close = true
            ctx.toast = 'Téléporté : ton jeu vérifie le sol sous le point.'
            return true
        end
    end
    return false, 'Point introuvable (supprimé entre-temps ?).'
end)

local COLOR = { biz = '#6fb4ff', gang = '#ff7a7a', shop = '#7bd88f', garage = '#f2c14e', bank = '#b48cff' }
local KIND = { biz = 'Entreprise', gang = 'Groupe', shop = 'Magasin', garage = 'Garage', bank = 'Banque' }
local function rows(list, onlyBad)
    local out = {}
    for _, p in ipairs(list) do
        if not onlyBad or #p.issues > 0 then
            out[#out + 1] = { owner = p.owner, kind = KIND[p.kind] or p.kind, label = p.label, pos = ('%.0f, %.0f, %.0f'):format(p.x, p.y, p.z), issue = #p.issues > 0 and { text = table.concat(p.issues, ' · '), tone = 'warn' } or { text = 'OK', tone = 'ok' },
                actions = { { action = 'points.goto', label = 'Tester en jeu', icon = 'pin', payload = { key = p.key } } } }
        end
    end
    return out
end
local COLS = { { k = 'owner', label = 'À qui' }, { k = 'kind', label = 'Type' }, { k = 'label', label = 'Point' }, { k = 'pos', label = 'Position', type = 'mono' }, { k = 'issue', label = 'Problème', type = 'badge' } }

PB.Module({
    id = 'pointsmap', label = 'Points posés', icon = 'map', group = 'Serveur', order = 82, perm = 'carte.place', hint = 'Carte de tous les points, problèmes, tester en jeu',
    caps = function()
        return PB.Capsify({
            { 'Carte de tous les points', 'ok', 'Entreprises, groupes, magasins, garages publics, banques.' },
            { 'Problèmes détectés par le serveur', 'ok', 'Position vide, hors carte, sous le niveau de la mer, doublon, très loin du siège.' },
            { 'Sol vérifié en jeu', 'ok', '« Tester en jeu » téléporte le staff ; son jeu dit si le point est sous le sol, dans le vide ou en l\'air (le serveur ne voit pas le décor).' },
        })
    end,
    doc = "## Points posés\nTous les points du serveur sur une carte. L'onglet **Problèmes** liste ceux qui sont visiblement faux ; **Tester en jeu** t'y téléporte et ton jeu vérifie le sol. Pour corriger : F10 › Builder › la cible › le point (« Y aller », « Dupliquer ici », « Tout déplacer »).",
    view = function()
        local list = PM.Issues(PM.Collect())
        local bad = 0
        for _, p in ipairs(list) do if #p.issues > 0 then bad = bad + 1 end end
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                for _, p in ipairs(list) do if p.x ~= 0 or p.y ~= 0 then pts[#pts + 1] = { x = p.x, y = p.y, color = #p.issues > 0 and '#ff3b30' or COLOR[p.kind], label = p.owner .. ' — ' .. p.label, sub = #p.issues > 0 and table.concat(p.issues, ' · ') or nil } end end
                local legend = { { color = '#ff3b30', label = 'Problème' } }
                for k, c in pairs(COLOR) do legend[#legend + 1] = { color = c, label = KIND[k] } end
                return { B.stats({ { label = 'Points posés', value = tostring(#list), icon = 'pin' }, { label = 'Avec un problème', value = tostring(bad), icon = 'alert' } }),
                    { type = 'map', id = 'pmap', title = 'Tous les points', points = pts, legend = legend } }
            end },
            { id = 'issues', label = 'Problèmes (' .. bad .. ')', icon = 'alert', build = function()
                return { B.table({ id = 'pi', title = 'Points à vérifier', columns = COLS, rows = rows(list, true), empty = 'Aucun problème détecté côté serveur. Pense quand même à tester en jeu les points importants.' }) }
            end },
            { id = 'all', label = 'Tous', icon = 'list', build = function()
                return { B.table({ id = 'pa', title = 'Tous les points', columns = COLS, rows = rows(list, false), empty = 'Aucun point posé.' }) }
            end },
        } }
    end,
})
