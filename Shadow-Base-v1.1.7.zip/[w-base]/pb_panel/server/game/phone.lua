-- Téléphone : numéro unique par joueur, contacts, messages texte (joueurs et services), annuaire des entreprises, signalement.
-- Appels vocaux : voir phonecall.lua (pma-voice). Le serveur décide de tout.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('phone.edit', 'Modifier les réglages du téléphone', 'phone', true)
P.Register('phone.moderate', 'Traiter les messages signalés et réduire un joueur au silence', 'phone', true)

local PHONE_SQL = {
    [[CREATE TABLE IF NOT EXISTS pb_phone_numbers (license VARCHAR(64) NOT NULL, number VARCHAR(12) NOT NULL, muted_until INT NOT NULL DEFAULT 0, created INT NOT NULL DEFAULT 0, PRIMARY KEY (license), UNIQUE KEY num (number))]],
    [[CREATE TABLE IF NOT EXISTS pb_phone_contacts (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(40) NOT NULL, number VARCHAR(12) NOT NULL, PRIMARY KEY (id), UNIQUE KEY own (license, number))]],
    [[CREATE TABLE IF NOT EXISTS pb_phone_msgs (id INT NOT NULL AUTO_INCREMENT, from_num VARCHAR(40) NOT NULL, to_num VARCHAR(40) NOT NULL, body VARCHAR(300) NOT NULL, at INT NOT NULL, read_at INT NOT NULL DEFAULT 0, reported TINYINT(1) NOT NULL DEFAULT 0, del_from TINYINT(1) NOT NULL DEFAULT 0, del_to TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY idx_to (to_num), KEY idx_from (from_num))]],
}
PB.Migrate('050_game_phone', 'Téléphone : numéros, contacts, messages', function() for _, sql in ipairs(PHONE_SQL) do DB.exec(PB.Table(sql)) end end)
PB.Migrate('054_phone_social', 'Téléphone : numéros bloqués et groupes', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_blocks (license VARCHAR(64) NOT NULL, number VARCHAR(12) NOT NULL, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license, number))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_groups (id INT NOT NULL AUTO_INCREMENT, name VARCHAR(32) NOT NULL, owner VARCHAR(64) NOT NULL, created INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_phone_group_members (group_id INT NOT NULL, license VARCHAR(64) NOT NULL, last_read INT NOT NULL DEFAULT 0, PRIMARY KEY (group_id, license), KEY k_lic (license))]]))
end)
PB.Migrate('053_phone_pos', 'Téléphone : position jointe à un message', { "ALTER TABLE pb_phone_msgs ADD COLUMN pos VARCHAR(40) NOT NULL DEFAULT ''" })

PB.Cfg.Define('phone', { enabled = true, key = 'F1', require_item = false, prefix = '555', max_contacts = 60, msg_maxlen = 240, thread_view = 40, msgs_per_min = 12, keep_days = 30, hide_services = {}, mute_hours = 24, service_notify = true })

local Ph = {}
G.Phone = Ph
local function cfg(k, d) return PB.Cfg.Get('phone', k, d) end
local function now() return os.time() end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function clip(s, n) s = tostring(s or ''):gsub('[%c]', ' '):gsub('%s+', ' '):gsub('^%s+', ''):gsub('%s+$', '') return s:sub(1, n) end

-- Numéros ---------------------------------------------------------------------------------------------------------------------------------
function Ph.Number(license)
    local r = DB.one('SELECT number FROM pb_phone_numbers WHERE license = ?', { license })
    if r then return r.number end
    local prefix = tostring(cfg('prefix', '555')):gsub('[^%d]', ''):sub(1, 3)
    if prefix == '' then prefix = '555' end
    for _ = 1, 80 do
        local n = ('%s-%04d'):format(prefix, math.random(0, 9999))
        if DB.exec('INSERT IGNORE INTO pb_phone_numbers (license, number, created) VALUES (?, ?, ?)', { license, n, now() }) > 0 then return n end
        local mine = DB.one('SELECT number FROM pb_phone_numbers WHERE license = ?', { license })
        if mine then return mine.number end
    end
    return nil
end
function Ph.LicenseOf(number) local r = DB.one('SELECT license FROM pb_phone_numbers WHERE number = ?', { tostring(number) }) return r and r.license or nil end
local function sourceOf(license) for id, p in pairs(G.Players()) do if p.license == license then return id end end return nil end
local function validNumber(n) return type(n) == 'string' and n:match('^%d%d%d%-%d%d%d%d$') ~= nil end
exports('GetPhoneNumber', function(src) local p = G.Get(tonumber(src)) return p and Ph.Number(p.license) or nil end)

local function contactName(license, number)
    local r = DB.one('SELECT name FROM pb_phone_contacts WHERE license = ? AND number = ?', { license, number })
    return r and r.name or nil
end
local function svcOf(num) return type(num) == 'string' and num:match('^svc:([%w_]+)$') or nil end
local function grpOf(num) local g = type(num) == 'string' and num:match('^grp:(%d+)$') return g and tonumber(g) or nil end
-- Numéros bloqués : « license » ne reçoit plus rien de « number » (messages refusés, appels qui ne sonnent pas)
function Ph.Blocked(license, number) return DB.one('SELECT 1 AS x FROM pb_phone_blocks WHERE license = ? AND number = ?', { license, tostring(number) }) ~= nil end
-- Groupes : membre ?
function Ph.InGroup(license, gid) return DB.one('SELECT 1 AS x FROM pb_phone_group_members WHERE group_id = ? AND license = ?', { tonumber(gid) or 0, license }) ~= nil end
function Ph.Group(gid) return DB.one('SELECT * FROM pb_phone_groups WHERE id = ?', { tonumber(gid) or 0 }) end
Ph.GrpOf = grpOf
local function labelOf(license, num)
    local g = grpOf(num)
    if g then local r = Ph.Group(g) return r and r.name or 'Groupe' end
    local svc = svcOf(num)
    if svc then local b = G.Biz and G.Biz.Get(svc) return b and b.label or 'Service' end
    return contactName(license, num) or num
end

local function onDutyOf(bizId)
    local out = {}
    if not G.Biz then return out end
    for id in pairs(G.Players()) do local c = G.Biz.Ctx(id) if c and c.biz.id == bizId and c.duty then out[#out + 1] = id end end
    return out
end
local function listedServices()
    local hidden = {}
    for _, id in ipairs(cfg('hide_services', {}) or {}) do hidden[id] = true end
    local out = {}
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do if PB.ToBool(b.enabled) and not hidden[b.id] then out[#out + 1] = b end end
    return out
end

-- Envoi -----------------------------------------------------------------------------------------------------------------------------------
local sent = {}   -- licence -> { t1, t2, ... } (limite de débit)
local function rate(license)
    local list = sent[license] or {}
    local t = now()
    local keep = {}
    for _, v in ipairs(list) do if t - v < 60 then keep[#keep + 1] = v end end
    if #keep >= cfg('msgs_per_min', 12) then sent[license] = keep return false end
    keep[#keep + 1] = t
    sent[license] = keep
    return true
end

-- Retourne true ou false + raison. pos = « x,y » lu par le serveur (partage de position), jamais fourni par le client
function Ph.Send(src, to, body, pos)
    local p = G.Get(src)
    if not p then return false, 'Joueur inconnu.' end
    local me = Ph.Number(p.license)
    local mu = DB.one('SELECT muted_until FROM pb_phone_numbers WHERE license = ?', { p.license })
    if mu and mu.muted_until > now() then return false, ('Tes messages sont suspendus jusqu\'au %s.'):format(os.date('%d/%m %H:%M', mu.muted_until)) end
    body = clip(body, cfg('msg_maxlen', 240))
    if body == '' then return false, 'Écris un message.' end
    to = tostring(to or '')
    local svc = svcOf(to)
    local grp = grpOf(to)
    if grp then
        local g = Ph.Group(grp)
        if not g or not Ph.InGroup(p.license, grp) then return false, 'Tu ne fais pas partie de ce groupe.' end
        if not rate(p.license) then return false, 'Trop de messages : attends un instant.' end
        DB.insert('INSERT INTO pb_phone_msgs (from_num, to_num, body, at, pos) VALUES (?, ?, ?, ?, ?)', { me, to, body, now(), pos or '' })
        for _, m in ipairs(DB.q('SELECT license FROM pb_phone_group_members WHERE group_id = ? AND license <> ?', { grp, p.license }) or {}) do
            local dst = sourceOf(m.license)
            if dst and not Ph.Blocked(m.license, me) then
                local quiet = Ph.QuietFor and Ph.QuietFor(m.license) or false
                if not quiet then G.Notify(dst, { type = 'info', title = '👥 ' .. g.name .. ' · ' .. (contactName(m.license, me) or me), text = body:sub(1, 120) }) end
                local pf = Ph.Prefs and Ph.Prefs(m.license) or {}
                TriggerClientEvent('pb:g:phone:incoming', dst, PB.Json({ from = to, quiet = quiet, sound = (not quiet) and pf.sound ~= false }))
            end
        end
        return true
    end
    if svc then
        local b = G.Biz and G.Biz.Get(svc)
        if not b or not PB.ToBool(b.enabled) then return false, 'Service introuvable.' end
    elseif not validNumber(to) then return false, 'Numéro invalide (ex. 555-0123).'
    elseif to == me then return false, 'Tu ne peux pas t\'écrire à toi-même.'
    elseif not Ph.LicenseOf(to) then return false, "Ce numéro n'existe pas."
    elseif Ph.Blocked(Ph.LicenseOf(to), me) then return false, 'Message non distribué : ce numéro ne reçoit pas tes messages.' end
    if not rate(p.license) then return false, 'Trop de messages : attends un instant.' end
    DB.insert('INSERT INTO pb_phone_msgs (from_num, to_num, body, at, pos) VALUES (?, ?, ?, ?, ?)', { me, to, body, now(), pos or '' })
    -- notification en direct
    local sender = display(src)
    if svc then
        if cfg('service_notify', true) then
            for _, id in ipairs(onDutyOf(svc)) do G.Notify(id, { type = 'info', title = 'Message pour le service', text = ('%s (%s) : %s'):format(sender, me, body:sub(1, 120)) }) end
        end
    else
        local dst = sourceOf(Ph.LicenseOf(to))
        if dst then
            local cn = contactName(Ph.LicenseOf(to), me)
            local dl = Ph.LicenseOf(to)
            local quiet = Ph.QuietFor and Ph.QuietFor(dl) or false
            if not quiet then G.Notify(dst, { type = 'info', title = '✉ ' .. (cn or me), text = body:sub(1, 120) }) end
            local pf = Ph.Prefs and Ph.Prefs(dl) or {}
            TriggerClientEvent('pb:g:phone:incoming', dst, PB.Json({ from = me, quiet = quiet, sound = (not quiet) and pf.sound ~= false }))
        end
    end
    return true
end

function Ph.Unread(license)
    local me = Ph.Number(license)
    local r = DB.one('SELECT COUNT(*) AS n FROM pb_phone_msgs WHERE to_num = ? AND read_at = 0 AND del_to = 0', { me })
    local n = r and r.n or 0
    for _, gm in ipairs(DB.q('SELECT group_id, last_read FROM pb_phone_group_members WHERE license = ?', { license }) or {}) do
        local g = DB.one('SELECT COUNT(*) AS n FROM pb_phone_msgs WHERE to_num = ? AND id > ? AND from_num <> ?', { 'grp:' .. gm.group_id, gm.last_read, me })
        n = n + (g and g.n or 0)
    end
    return n
end

-- Sessions -------------------------------------------------------------------------------------------------------------------------------
local sessions = {}
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end
local function hasPhone(src)
    if not cfg('require_item', false) then return true end
    local o = G.Inv and G.Inv.PlayerOwner(src)
    return o ~= nil and G.Inv.Count(o, 'phone') > 0
end
local function stamp(t) return os.date('%d/%m %H:%M', t) end

-- Conversations : { num, last, at, unread }
local function threads(license)
    local me = Ph.Number(license)
    local rows = DB.q('SELECT from_num, to_num, body, at, read_at, del_from, del_to FROM pb_phone_msgs WHERE (from_num = ? AND del_from = 0) OR (to_num = ? AND del_to = 0) ORDER BY id DESC LIMIT 600', { me, me }) or {}
    local by, order = {}, {}
    for _, m in ipairs(rows) do
        local other = m.from_num == me and m.to_num or m.from_num
        if not by[other] then by[other] = { num = other, last = m.body, at = m.at, unread = 0, mine = m.from_num == me } order[#order + 1] = other end
        if m.to_num == me and m.read_at == 0 then by[other].unread = by[other].unread + 1 end
    end
    for _, gm in ipairs(DB.q('SELECT group_id, last_read FROM pb_phone_group_members WHERE license = ?', { license }) or {}) do
        local key = 'grp:' .. gm.group_id
        local last = DB.one('SELECT from_num, body, at FROM pb_phone_msgs WHERE to_num = ? ORDER BY id DESC LIMIT 1', { key })
        local un = DB.one('SELECT COUNT(*) AS n FROM pb_phone_msgs WHERE to_num = ? AND id > ? AND from_num <> ?', { key, gm.last_read, me })
        local g = Ph.Group(gm.group_id)
        if g then
            by[key] = { num = key, last = last and last.body or 'Groupe créé', at = last and last.at or g.created, unread = un and un.n or 0, mine = last and last.from_num == me or false, group = true }
            order[#order + 1] = key
        end
    end
    table.sort(order, function(a, b) return (by[a].at or 0) > (by[b].at or 0) end)
    local out = {}
    for _, k in ipairs(order) do out[#out + 1] = by[k] end
    return out
end

-- Pages ---------------------------------------------------------------------------------------------------------------------------------
local PAGES = {}
Ph.PAGES = PAGES
PAGES.home = function(src)
    local p = G.Get(src)
    local me = Ph.Number(p.license)
    local nc = DB.one('SELECT COUNT(*) AS n FROM pb_phone_contacts WHERE license = ?', { p.license })
    return { { type = 'hero', title = display(src), sub = 'Ton téléphone', tone = '#7be0a4', chips = { { 'Numéro', me or '—' }, { 'Messages non lus', tostring(Ph.Unread(p.license)) }, { 'Contacts', tostring(nc and nc.n or 0) } } },
        { type = 'notice', text = "Appelle ou écris à un joueur par son numéro, ou à un service de l'annuaire." } }, 'Téléphone'
end
PAGES.contacts = function(src)
    local p = G.Get(src)
    local rows = {}
    for _, c in ipairs(DB.q('SELECT * FROM pb_phone_contacts WHERE license = ? ORDER BY name', { p.license }) or {}) do
        rows[#rows + 1] = { name = c.name, number = c.number, actions = { { act = 'open_thread', label = 'Écrire', payload = { num = c.number }, primary = true }, { act = 'del_contact', label = 'Supprimer', payload = { id = c.id }, danger = true, confirm = 'Supprimer ce contact ?' } } }
    end
    return { { type = 'table', title = 'Contacts', columns = { { k = 'name', label = 'Nom' }, { k = 'number', label = 'Numéro' } }, rows = rows, empty = 'Aucun contact pour le moment.' },
        { type = 'form', id = 'addc', title = 'Ajouter un contact', fields = { { k = 'name', type = 'text', label = 'Nom', maxlen = 40 }, { k = 'number', type = 'text', label = 'Numéro (555-0123)', maxlen = 8 } }, submit = { act = 'add_contact', label = 'Ajouter' } } }, 'Contacts'
end
PAGES.messages = function(src)
    local p = G.Get(src)
    local rows = {}
    for _, t in ipairs(threads(p.license)) do
        rows[#rows + 1] = { who = labelOf(p.license, t.num), last = (t.mine and 'Toi : ' or '') .. t.last:sub(1, 60), at = stamp(t.at), unread = t.unread > 0 and tostring(t.unread) or '', actions = { { act = 'open_thread', label = 'Ouvrir', payload = { num = t.num }, primary = t.unread > 0 } } }
    end
    return { { type = 'table', title = 'Conversations', columns = { { k = 'who', label = 'Contact' }, { k = 'last', label = 'Dernier message' }, { k = 'at', label = 'Date' }, { k = 'unread', label = 'Non lus' } }, rows = rows, empty = "Aucune conversation. Écris à un contact ou à un service." },
        { type = 'form', id = 'newmsg', title = 'Nouveau message', fields = { { k = 'num', type = 'text', label = 'Numéro (555-0123)', maxlen = 8 }, { k = 'body', type = 'text', label = 'Message', maxlen = cfg('msg_maxlen', 240) } }, submit = { act = 'send_new', label = 'Envoyer' } } }, 'Messages'
end
PAGES.thread = function(src, s)
    local p = G.Get(src)
    local me = Ph.Number(p.license)
    local num = s.thread
    if not num then return { { type = 'notice', text = 'Choisis une conversation.' } }, 'Messages' end
    DB.exec('UPDATE pb_phone_msgs SET read_at = ? WHERE to_num = ? AND from_num = ? AND read_at = 0', { now(), me, num })
    local list = DB.q('SELECT * FROM pb_phone_msgs WHERE ((from_num = ? AND to_num = ? AND del_from = 0) OR (from_num = ? AND to_num = ? AND del_to = 0)) ORDER BY id DESC LIMIT ?', { me, num, num, me, cfg('thread_view', 40) }) or {}
    local rows = {}
    for i = #list, 1, -1 do
        local m = list[i]
        local mineMsg = m.from_num == me
        rows[#rows + 1] = { who = mineMsg and 'Toi' or labelOf(p.license, num), body = m.body, at = stamp(m.at), actions = (not mineMsg and m.reported == 0) and { { act = 'report', label = 'Signaler', payload = { id = m.id }, danger = true, confirm = 'Signaler ce message au staff ?' } } or {} }
    end
    local blocks = { { type = 'table', title = labelOf(p.license, num) .. (svcOf(num) and '' or (' · ' .. num)), columns = { { k = 'who', label = 'De' }, { k = 'body', label = 'Message' }, { k = 'at', label = 'Date' } }, rows = rows, empty = 'Aucun message. Écris le premier !' },
        { type = 'form', id = 'reply', title = 'Répondre', fields = { { k = 'body', type = 'text', label = 'Message', maxlen = cfg('msg_maxlen', 240) } }, submit = { act = 'send', label = 'Envoyer' } } }
    local acts = { { act = 'to_messages', label = 'Retour aux conversations' } }
    if not svcOf(num) and not contactName(p.license, num) then acts[#acts + 1] = { act = 'quick_contact', label = 'Ajouter ce numéro aux contacts' } end
    blocks[#blocks + 1] = { type = 'actions', items = acts }
    return blocks, 'Conversation'
end
PAGES.services = function(src)
    local rows = {}
    for _, b in ipairs(listedServices()) do
        local n = #onDutyOf(b.id)
        rows[#rows + 1] = { name = b.label, duty = n > 0 and (n .. ' en service') or 'Personne en service', actions = { { act = 'open_thread', label = 'Envoyer un message', payload = { num = 'svc:' .. b.id }, primary = n > 0 } } }
    end
    return { { type = 'table', title = 'Services', columns = { { k = 'name', label = 'Service' }, { k = 'duty', label = 'Disponibilité' } }, rows = rows, empty = "Aucun service n'est listé." },
        { type = 'notice', text = 'Un message envoyé à un service prévient les employés en service. Ils te répondent par message sur ton numéro.' } }, 'Annuaire'
end

local function frame(src)
    local p = G.Get(src)
    local un = Ph.Unread(p.license)
    return { phone = Ph.Info and Ph.Info(src) or nil, name = display(src), id = src, tone = '#7be0a4', brand = 'Téléphone · ' .. tostring(Ph.Number(p.license) or ''), cash = p.row.cash, bank = p.row.bank,
        nav = { { id = 'home', label = 'Accueil', icon = 'home', group = 'Téléphone' }, { id = 'messages', label = un > 0 and ('Messages (' .. un .. ')') or 'Messages', icon = 'chat', group = 'Téléphone' },
            { id = 'contacts', label = 'Contacts', icon = 'users', group = 'Téléphone' }, { id = 'services', label = 'Annuaire', icon = 'building', group = 'Téléphone' } } }
end
local function page(src, name)
    local s = sessions[src]
    local fn = s and PAGES[name or 'home']
    if not fn then return nil end
    local blocks, title = fn(src, s)
    return { page = name or 'home', title = title, blocks = blocks, data = Ph.Data and Ph.Data(src, name or 'home', s) or nil }
end
local function ui(src, ev, extra)
    local msg = { ev = ev, frame = frame(src) }
    for k, v in pairs(extra or {}) do msg[k] = v end
    TriggerClientEvent('pb:g:phone:ui', src, PB.Json(msg))
end

RegisterNetEvent('pb:g:phone:open', function()
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 400) then return end
    if not hasPhone(src) then G.Notify(src, { type = 'error', text = "Tu n'as pas de téléphone sur toi." }) return end
    sessions[src] = {}
    ui(src, 'open', { page = page(src, 'home') })
end)
RegisterNetEvent('pb:g:phone:page', function(name)
    local src = source
    if not sessions[src] or not throttle(src, 150) then return end
    name = tostring(name)
    if name ~= 'thread' then sessions[src].thread = nil end
    local pg = page(src, name)
    ui(src, 'page', { page = pg, err = pg == nil and 'Page indisponible.' or nil })
end)
RegisterNetEvent('pb:g:phone:close', function() sessions[source] = nil end)
AddEventHandler('playerDropped', function() sessions[source] = nil last[tostring(source)] = nil end)

-- Actions --------------------------------------------------------------------------------------------------------------------------------
local ACT = {}
Ph.ACT = ACT
Ph.Display, Ph.Clip = display, clip
ACT.open_thread = function(s, src, p)
    local num = tostring(p.num or '')
    if grpOf(num) then if not Ph.InGroup(G.Get(src).license, grpOf(num)) then return false, 'Groupe introuvable.' end s.thread = num return true, nil, 'thread' end
    if not svcOf(num) and not validNumber(num) then return false, 'Numéro invalide.' end
    s.thread = num
    return true, nil, 'thread'
end
ACT.to_messages = function(s) s.thread = nil return true, nil, 'messages' end
ACT.send = function(s, src, p)
    if not s.thread then return false, 'Ouvre une conversation.' end
    local ok, why = Ph.Send(src, s.thread, p.body)
    return ok, ok and 'Message envoyé.' or why, 'thread'
end
ACT.send_new = function(s, src, p)
    local num = clip(p.num, 8)
    local ok, why = Ph.Send(src, num, p.body)
    if ok then s.thread = num return true, 'Message envoyé.', 'thread' end
    return false, why
end
ACT.add_contact = function(s, src, p)
    local pl = G.Get(src)
    local name, num = clip(p.name, 40), clip(p.number, 8)
    if name == '' then return false, 'Donne un nom.' end
    if not validNumber(num) then return false, 'Numéro invalide (ex. 555-0123).' end
    if num == Ph.Number(pl.license) then return false, "C'est ton propre numéro." end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_contacts WHERE license = ?', { pl.license })
    if n and n.n >= cfg('max_contacts', 60) then return false, ('Maximum %d contacts.'):format(cfg('max_contacts', 60)) end
    DB.exec('INSERT INTO pb_phone_contacts (license, name, number) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name)', { pl.license, name, num })
    return true, 'Contact enregistré.', 'contacts'
end
ACT.quick_contact = function(s, src)
    local pl = G.Get(src)
    if not s.thread or svcOf(s.thread) then return false, 'Rien à enregistrer.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_contacts WHERE license = ?', { pl.license })
    if n and n.n >= cfg('max_contacts', 60) then return false, ('Maximum %d contacts.'):format(cfg('max_contacts', 60)) end
    DB.exec('INSERT IGNORE INTO pb_phone_contacts (license, name, number) VALUES (?, ?, ?)', { pl.license, 'Contact ' .. s.thread, s.thread })
    return true, 'Numéro ajouté : renomme-le en le recréant avec un nom.', 'thread'
end
ACT.del_contact = function(s, src, p)
    local pl = G.Get(src)
    DB.exec('DELETE FROM pb_phone_contacts WHERE id = ? AND license = ?', { math.floor(tonumber(p.id) or 0), pl.license })
    return true, 'Contact supprimé.', 'contacts'
end
ACT.report = function(s, src, p)
    local pl = G.Get(src)
    local me = Ph.Number(pl.license)
    local id = math.floor(tonumber(p.id) or 0)
    local m = DB.one('SELECT * FROM pb_phone_msgs WHERE id = ? AND to_num = ?', { id, me })
    if not m then return false, 'Message introuvable.' end
    DB.exec('UPDATE pb_phone_msgs SET reported = 1 WHERE id = ?', { id })
    return true, 'Message signalé au staff.', 'thread'
end

Ph.Usable, Ph.HasPhone = usable, hasPhone
Ph.Stamp, Ph.LabelOf, Ph.Threads, Ph.ValidNumber, Ph.OnDutyOf, Ph.Services, Ph.Sessions, Ph.SourceOf, Ph.ContactName = stamp, labelOf, threads, validNumber, onDutyOf, listedServices, sessions, sourceOf, contactName

RegisterNetEvent('pb:g:phone:act', function(name, payload, pgname)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    local s = sessions[src]
    if not s or not usable(src) or not throttle(src, 350) then return end
    local fn = ACT[tostring(name)]
    local ok, msg, goto_ = false, 'Action inconnue.', nil
    if fn then ok, msg, goto_ = fn(s, src, type(payload) == 'table' and payload or {}) end
    ui(src, 'result', { ok = ok and true or false, msg = msg, page = page(src, goto_ or tostring(pgname or 'home')) })
end)

-- Ménage : on garde les messages « keep_days » jours
local function purge()
    local d = cfg('keep_days', 30)
    if d > 0 then DB.exec('DELETE FROM pb_phone_msgs WHERE at < ? AND reported = 0', { now() - d * 86400 }) end
end
CreateThread(function() while true do Wait(3600000) pcall(purge) end end)
Ph.Purge = purge

function G.PhoneInfo() return { key = cfg('key', 'F1') } end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
PB.Action('phone.msg.delete', 'phone.moderate', function(ctx, p)
    local id = math.floor(tonumber(p.id) or 0)
    local m = DB.one('SELECT * FROM pb_phone_msgs WHERE id = ? AND reported = 1', { id })
    if not m then return false, 'Seuls les messages signalés peuvent être supprimés.' end
    DB.exec('DELETE FROM pb_phone_msgs WHERE id = ?', { id })
    ctx.audit('serveur', 'phone.msg.delete', tostring(id), { from = m.from_num, to = m.to_num, body = m.body }, nil)
    ctx.toast = 'Message supprimé.'
    return true
end)
PB.Action('phone.msg.dismiss', 'phone.moderate', function(ctx, p)
    local id = math.floor(tonumber(p.id) or 0)
    if DB.exec('UPDATE pb_phone_msgs SET reported = 0 WHERE id = ? AND reported = 1', { id }) == 0 then return false, 'Signalement introuvable.' end
    ctx.audit('serveur', 'phone.msg.dismiss', tostring(id), nil, nil)
    ctx.toast = 'Signalement classé.'
    return true
end)
PB.Action('phone.mute', 'phone.moderate', function(ctx, p)
    local num = tostring(p.number or '')
    local lic = Ph.LicenseOf(num)
    if not lic then return false, 'Numéro inconnu.' end
    local until_ = now() + cfg('mute_hours', 24) * 3600
    DB.exec('UPDATE pb_phone_numbers SET muted_until = ? WHERE license = ?', { until_, lic })
    ctx.audit('serveur', 'phone.mute', num, nil, { until_ = until_ })
    ctx.toast = ('Messages suspendus pour %d h.'):format(cfg('mute_hours', 24))
    return true
end)
PB.Action('phone.unmute', 'phone.moderate', function(ctx, p)
    local num = tostring(p.number or '')
    local lic = Ph.LicenseOf(num)
    if not lic then return false, 'Numéro inconnu.' end
    DB.exec('UPDATE pb_phone_numbers SET muted_until = 0 WHERE license = ?', { lic })
    ctx.audit('serveur', 'phone.unmute', num, nil, nil)
    ctx.toast = 'Messages rétablis.'
    return true
end)

local settings = Form.Cfg({ ns = 'phone', id = 'settings', title = 'Réglages du téléphone', perm = 'phone.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Téléphone actif', default = true }, { k = 'require_item', type = 'toggle', label = "Exiger l'objet « Téléphone » dans l'inventaire", default = false },
    { k = 'key', type = 'text', label = "Touche d'ouverture (par défaut)", default = 'F1', maxlen = 12, pattern = '^[%w_]+$' }, { k = 'prefix', type = 'text', label = 'Préfixe des numéros (3 chiffres)', default = '555', maxlen = 3, pattern = '^%d%d%d$', hint = 'Ne change que les nouveaux numéros.' },
    { k = 'max_contacts', type = 'number', label = 'Contacts maximum par joueur', default = 60, min = 1, max = 500 }, { k = 'msg_maxlen', type = 'number', label = 'Longueur maximale d\'un message', default = 240, min = 20, max = 300 },
    { k = 'msgs_per_min', type = 'number', label = 'Messages maximum par minute', default = 12, min = 1, max = 120 }, { k = 'thread_view', type = 'number', label = 'Messages affichés par conversation', default = 40, min = 10, max = 200 },
    { k = 'keep_days', type = 'number', label = 'Conservation des messages (jours, 0 = toujours)', default = 30, min = 0, max = 365, hint = 'Les messages signalés ne sont jamais purgés automatiquement.' },
    { k = 'mute_hours', type = 'number', label = 'Durée de suspension des messages (heures)', default = 24, min = 1, max = 720 },
    { k = 'calls', type = 'toggle', label = 'Appels vocaux (pma-voice)', default = true },
    { k = 'svc_calls', type = 'toggle', label = "Les services de l'annuaire prennent les appels", default = true, hint = "Fait sonner les employés en service ; le premier qui décroche prend l'appel." },
    { k = 'ring_secs', type = 'number', label = 'Durée de la sonnerie (secondes)', default = 30, min = 10, max = 90 },
    { k = 'call_max_mins', type = 'number', label = "Durée maximale d'un appel (minutes, 0 = sans limite)", default = 30, min = 0, max = 240 },
    { k = 'calls_per_min', type = 'number', label = 'Appels maximum par minute', default = 6, min = 1, max = 30 },
    { k = 'service_notify', type = 'toggle', label = 'Prévenir les employés en service quand un service reçoit un message', default = true },
    { k = 'anim', type = 'toggle', label = "Animation et objet téléphone en main (client)", default = true, hint = 'Non testé dans un vrai client FiveM : désactive-le si le personnage se bloque.' },
    { k = 'hide_apps', type = 'list', label = "Applications masquées (messages, contacts, services, bank, bills, garage, gps, notes, calc, settings)", default = {}, maxitems = 12, maxlen = 12, pattern = '^[a-z]+$', wide = true },
    { k = 'places', type = 'list', label = 'Lieux du GPS (nom|x|y, ex. Hôpital|298.0|-584.0)', default = {}, maxitems = 40, maxlen = 80, pattern = '^[^|]+|%-?%d+%.?%d*|%-?%d+%.?%d*$', wide = true },
    { k = 'hide_services', type = 'list', label = "Entreprises masquées de l'annuaire (identifiants, un par ligne)", default = {}, maxitems = 50, maxlen = 32, pattern = '^[%w_]+$', wide = true },
} })

PB.Module({
    id = 'phone', label = 'Téléphone', icon = 'chat', group = 'Serveur', order = 98, perm = 'phone.view', hint = 'Numéros, appels, contacts, messages, annuaire',
    caps = function()
        return PB.Capsify({
            { 'Numéro unique par joueur', 'ok', 'Créé à la première ouverture, format 555-0123.' },
            { 'Contacts et messages texte', 'ok', 'Limites de débit et de longueur ; messages hors ligne remis à la connexion.' },
            { 'Annuaire des services et messages aux employés en service', 'ok', 'Les entreprises du panel sont listées, avec les employés en service.' },
            { 'Signalement et modération', 'ok', 'Le staff ne lit que les messages signalés par leur destinataire ; chaque action est journalisée.' },
            { 'Applications : Messages, Contacts, Annuaire, Banque, Factures, Garage, GPS, Notes, Calculatrice, Réglages', 'ok', 'Chaque application lit les vrais systèmes du panel (banque, factures des entreprises, garage, messages) ; le serveur vérifie chaque action.' },
            { 'Appels vocaux (joueurs et services)', (Ph.Calls and Ph.Calls.VoiceUp()) and 'ok' or 'off', (Ph.Calls and Ph.Calls.VoiceUp()) and "Par pma-voice : sonnerie, décrocher / raccrocher, appels manqués. Canaux tirés au hasard et surveillés : impossible d'écouter l'appel d'un autre." or 'pma-voice ne tourne pas : les appels sont refusés proprement.' },
            { 'Photos, applications tierces', 'off', 'Non prévu.' },
            { 'Bloquer un numéro', 'off', 'Non prévu : utilise le signalement.' },
        })
    end,
    doc = "## Téléphone\nLe joueur ouvre son téléphone avec la touche réglée (F1 par défaut). Il y trouve ses appels, ses messages, ses contacts et l'annuaire des services.\n\n**Appels vocaux** (pma-voice) : application Appels (clavier, récents, manqués), bouton Appeler sur un contact, une conversation ou un service. Un appel entrant s'affiche en haut de l'écran : on ouvre le téléphone pour décrocher, ou on tape `/decrocher` et `/raccrocher`. Un appel à un service fait sonner tous les employés en service ; le premier qui décroche le prend.\n\nLe staff **ne lit pas** les conversations : il traite les messages que leurs destinataires ont signalés (supprimer, classer, suspendre l'expéditeur).\n\nPour tes scripts : `GetPhoneNumber(source)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'overview', label = "Vue d'ensemble", icon = 'chart', build = function()
                local n = DB.one('SELECT COUNT(*) AS n FROM pb_phone_numbers')
                local m = DB.one('SELECT COUNT(*) AS n FROM pb_phone_msgs')
                local r = DB.one('SELECT COUNT(*) AS n FROM pb_phone_msgs WHERE reported = 1')
                return { { type = 'cards', items = {
                    { title = 'Numéros', value = tostring(n and n.n or 0), icon = 'users', tone = '#6fb4ff', sub = 'Joueurs ayant un téléphone' }, { title = 'Messages stockés', value = tostring(m and m.n or 0), icon = 'chat', tone = '#dfe2e7', sub = ('Conservés %s'):format(cfg('keep_days', 30) > 0 and (cfg('keep_days', 30) .. ' jours') or 'sans limite') },
                    { title = 'Signalements', value = tostring(r and r.n or 0), icon = 'alert', tone = (r and r.n or 0) > 0 and '#ffb457' or '#7be0a4', sub = 'À traiter' } } } }
            end },
            { id = 'reports', label = 'Signalements', icon = 'alert', perm = 'phone.moderate', build = function()
                local rows = {}
                for _, m in ipairs(DB.q('SELECT * FROM pb_phone_msgs WHERE reported = 1 ORDER BY id DESC LIMIT 100') or {}) do
                    rows[#rows + 1] = { at = stamp(m.at), from = m.from_num, to = m.to_num, body = m.body, actions = {
                        { action = 'phone.msg.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = m.id } }, { action = 'phone.msg.dismiss', label = 'Classer', icon = 'check', payload = { id = m.id } },
                        { action = 'phone.mute', label = ('Suspendre l\'expéditeur (%d h)'):format(cfg('mute_hours', 24)), icon = 'lock', payload = { number = m.from_num } } } }
                end
                return { B.table({ id = 'rep', title = 'Messages signalés', columns = { { k = 'at', label = 'Date' }, { k = 'from', label = 'Expéditeur', type = 'mono' }, { k = 'to', label = 'Destinataire', type = 'mono' }, { k = 'body', label = 'Message' } }, rows = rows, empty = 'Aucun message signalé.' }),
                    B.notice('info', 'Seuls les messages signalés par leur destinataire sont visibles ici.') }
            end },
            { id = 'muted', label = 'Messages suspendus', icon = 'lock', perm = 'phone.moderate', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT n.number, n.muted_until, p.firstname, p.lastname FROM pb_phone_numbers n LEFT JOIN pb_players p ON p.license = n.license WHERE n.muted_until > ? ORDER BY n.muted_until DESC', { now() }) or {}) do
                    rows[#rows + 1] = { number = r.number, who = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''), till = os.date('%d/%m %H:%M', r.muted_until), actions = { { action = 'phone.unmute', label = 'Rétablir', icon = 'refresh', payload = { number = r.number } } } }
                end
                return { B.table({ id = 'mut', title = 'Joueurs suspendus', columns = { { k = 'number', label = 'Numéro', type = 'mono' }, { k = 'who', label = 'Joueur' }, { k = 'till', label = "Jusqu'au" } }, rows = rows, empty = 'Personne n\'est suspendu.' }) }
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'phone', title = 'Téléphone vu par le joueur', cfg = {} } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'phone.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('téléphone', function(R)
    local dup = DB.one('SELECT COUNT(*) AS n FROM (SELECT number FROM pb_phone_numbers GROUP BY number HAVING COUNT(*) > 1) d')
    R.check(not dup or dup.n == 0, 'numéros de téléphone', 'des numéros sont en double')
    if cfg('require_item', false) then R.check(G.Inv ~= nil and G.Inv.Def('phone') ~= nil, "objet « Téléphone »", "l'objet « phone » n'existe pas dans l'inventaire : personne ne pourra ouvrir son téléphone") end
    R.check(tostring(cfg('prefix', '555')):match('^%d%d%d$') ~= nil, 'préfixe des numéros', 'le préfixe doit faire 3 chiffres')
end)
