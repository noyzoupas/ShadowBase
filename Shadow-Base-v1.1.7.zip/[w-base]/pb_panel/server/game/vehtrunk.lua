-- Coffre de véhicule : s'ouvre à pied, derrière le véhicule, avec une touche réglable (ou depuis le menu contextuel).
-- La capacité dépend de la classe du véhicule (réglable). Le serveur vérifie la distance au véhicule, la clé pour un véhicule possédé et le verrouillage.
-- Touches du véhicule (coffre, capot, moteur, ceinture, vitres) : réglables par le joueur dans Paramètres > Raccourcis clavier de FiveM.

local B, P, DB, Form = PB.B, PB.Perm, PB.DB, PB.Form
local G = PB.G
local Inv = G.Inv
local T = {}
G.VehTrunk = T

P.Register('trunk.edit', 'Régler les coffres et les touches des véhicules', 'trunk', true)

-- classe du jeu -> { libellé, emplacements, poids en grammes }
local CLASSES = {
    { 0, 'Compactes', 20, 40000 }, { 1, 'Berlines', 25, 50000 }, { 2, 'SUV', 35, 80000 }, { 3, 'Coupés', 20, 40000 }, { 4, 'Muscle', 20, 45000 }, { 5, 'Sportives classiques', 15, 30000 },
    { 6, 'Sportives', 15, 30000 }, { 7, 'Supersportives', 8, 16000 }, { 8, 'Motos', 4, 8000 }, { 9, 'Tout-terrain', 35, 90000 }, { 10, 'Industriels', 60, 200000 }, { 11, 'Utilitaires', 50, 150000 },
    { 12, 'Fourgons', 50, 180000 }, { 13, 'Vélos', 2, 3000 }, { 14, 'Bateaux', 30, 80000 }, { 15, 'Hélicoptères', 15, 40000 }, { 16, 'Avions', 20, 60000 }, { 17, 'Services', 40, 100000 },
    { 18, 'Urgences', 40, 100000 }, { 19, 'Militaires', 50, 150000 }, { 20, 'Commerciaux', 70, 250000 },
}
local DEF = {}
for _, c in ipairs(CLASSES) do DEF[#DEF + 1] = { class = c[1], label = c[2], slots = c[3], weight = c[4] } end
PB.Cfg.Define('trunk', { enabled = true, key_trunk = 'K', key_hood = 'J', key_engine = 'Y', key_belt = 'B', key_windows = 'U', open_dist = 3.5, need_key = true, open_locked = false, classes = DEF })
local function cfg(k, d) return PB.Cfg.Get('trunk', k, d) end

local caps = {}   -- plaque -> { slots, weight, net }
function Inv.TrunkCap(plate) local c = caps[tostring(plate)] return c and { c[1], c[2] } or nil end

local function capFor(class)
    for _, r in ipairs(cfg('classes', DEF) or DEF) do
        if tonumber(r.class) == class then return math.max(1, math.floor(tonumber(r.slots) or 10)), math.max(1000, math.floor(tonumber(r.weight) or 40000)) end
    end
    return 12, 60000
end

function T.Cap(class) local a, b = capFor(math.floor(tonumber(class) or 1)) return { a, b } end

local function vehOf(netId)
    netId = math.floor(tonumber(netId) or 0)
    if netId <= 0 then return nil end
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, netId)
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) then return nil end
    local plate = ''
    pcall(function() plate = tostring(GetVehicleNumberPlateText(ent) or ''):gsub('%s+$', ''):upper() end)
    local c = GetEntityCoords(ent)
    return { ent = ent, plate = plate, x = c.x, y = c.y, z = c.z, net = netId }
end

-- Peut-on ouvrir ce coffre ? Renvoie ok, message.
function T.Check(src, v)
    if not v or v.plate == '' then return false, 'Véhicule introuvable.' end
    local d = G.DistTo(src, v.x, v.y, v.z)
    if d > (tonumber(cfg('open_dist', 3.5)) or 3.5) + 3.5 then return false, 'Tu es trop loin du véhicule.' end
    local owned = G.Garage and G.Garage.Vehicle(v.plate)
    if owned and cfg('need_key', true) ~= false then
        local p = G.Get(src)
        if not (p and (G.Garage.HasKey(p.license, v.plate) or (G.Garage.IsMechanic and G.Garage.IsMechanic(src)))) then return false, "Tu n'as pas la clé de ce véhicule." end
    end
    if cfg('open_locked', false) ~= true then
        local ok, st = pcall(GetVehicleDoorLockStatus, v.ent)
        if ok and tonumber(st) and tonumber(st) >= 2 then return false, 'Le véhicule est verrouillé.' end
    end
    return true
end

RegisterNetEvent('pb:g:veh:trunk', function(netId, class)
    local src = source
    if cfg('enabled', true) == false then return end
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) then return end
    local v = vehOf(netId)
    local ok, why = T.Check(src, v)
    if not ok then G.Notify(src, { type = 'error', title = 'Coffre', text = why }) return end
    local slots, weight = capFor(math.floor(tonumber(class) or 1))
    caps[v.plate] = { slots, weight, v.net }
    TriggerClientEvent('pb:g:veh:trunkok', src, PB.Json({ net = v.net }))
    Inv.OpenFor(src, 'v:' .. v.plate)
end)

-- accès aux conteneurs « v:PLAQUE » (utilisé par l'inventaire à chaque mouvement)
local prev = Inv.ExtraAccess
Inv.ExtraAccess = function(src, kind, id)
    if kind == 'v' then
        local c = caps[tostring(id)]
        if not c then return false end
        local v = vehOf(c[3])
        if not v or v.plate ~= tostring(id) then return false end
        return T.Check(src, v) and true or false
    end
    if prev then return prev(src, kind, id) end
    return false
end

-- Menu contextuel : « Coffre : ouvrir / fermer » ouvre aussi le sac du coffre
exports('OpenTrunk', function(src, netId, class) TriggerEvent('pb:g:veh:trunk', netId, class) end)

-- Réglages dans le panel ----------------------------------------------------------------------------------------------------------------------
local keys = Form.Cfg({ ns = 'trunk', id = 'keys', title = 'Touches et règles', perm = 'trunk.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Coffres de véhicules actifs', default = true },
    { k = 'need_key', type = 'toggle', label = 'Clé obligatoire pour un véhicule possédé', default = true },
    { k = 'open_locked', type = 'toggle', label = 'Ouvrir même si le véhicule est verrouillé', default = false },
    { k = 'open_dist', type = 'number', label = 'Distance maximale du coffre (m)', default = 3.5, min = 1, max = 8, step = 0.5, int = false },
    { k = 'key_trunk', type = 'text', label = 'Touche : coffre', default = 'K', maxlen = 16, hint = 'Chaque joueur peut la changer dans Paramètres › Raccourcis clavier › FiveM.' },
    { k = 'key_hood', type = 'text', label = 'Touche : capot', default = 'J', maxlen = 16 }, { k = 'key_engine', type = 'text', label = 'Touche : moteur', default = 'Y', maxlen = 16 },
    { k = 'key_belt', type = 'text', label = 'Touche : ceinture', default = 'B', maxlen = 16 }, { k = 'key_windows', type = 'text', label = 'Touche : vitres', default = 'U', maxlen = 16 },
} })
local cls = Form.Cfg({ ns = 'trunk', id = 'classes', title = 'Capacité par classe de véhicule', perm = 'trunk.edit', fields = {
    { k = 'classes', type = 'rows', label = 'Classes', default = DEF, wide = true, maxitems = 30, unique = 'class', cols = {
        { k = 'class', label = 'Classe du jeu', type = 'number', min = 0, max = 30 }, { k = 'label', label = 'Nom', maxlen = 30 },
        { k = 'slots', label = 'Emplacements', type = 'number', min = 1, max = 200 }, { k = 'weight', label = 'Poids max (g)', type = 'number', min = 1000, max = 2000000 } } } } })

PB.Module({
    id = 'vehtrunk', label = 'Coffres de véhicules', icon = 'engine', group = 'Serveur', order = 131, perm = 'trunk.edit', hint = 'Capacité et touches du véhicule',
    caps = function()
        return PB.Capsify({
            { 'Coffre à pied, clé et distance vérifiées côté serveur', 'ok', "Le serveur relit la position et le verrouillage du véhicule à chaque ouverture." },
            { 'Classe du véhicule', 'warn', "La classe vient du client (limitée aux capacités que tu fixes) : un client modifié pourrait choisir une autre classe." },
            { 'Touches capot / moteur / ceinture / vitres', 'warn', "Actions locales au joueur ; jamais vérifiées dans un vrai client FiveM." },
        })
    end,
    doc = "## Coffres de véhicules\nÀ pied, près de l'arrière du véhicule, appuie sur la touche **coffre** (K par défaut) : le coffre s'ouvre et son contenu apparaît à droite de ton sac. Les touches **capot** (J), **moteur** (Y), **ceinture** (B) et **vitres** (U) sont aussi réglables ici et par chaque joueur dans les raccourcis FiveM.",
    view = function(ctx)
        return { tabs = { { id = 'keys', label = 'Touches et règles', icon = 'sliders', build = function() return { keys(ctx) } end },
            { id = 'classes', label = 'Capacités', icon = 'box', build = function() return { cls(ctx) } end } } }
    end,
})

PB.SelfTest.Add('coffres de véhicules', function(R)
    R.check(#cfg('classes', DEF) >= 15, 'coffre', 'classes de véhicules manquantes')
    R.check(Inv and Inv.ExtraAccess ~= nil and Inv.OpenFor ~= nil, 'coffre', "l'inventaire n'est pas chargé")
    local s, w = capFor(7)
    R.check(s < capFor(12), 'coffre', 'une supersportive devrait avoir moins de place qu\'un fourgon')
end)
