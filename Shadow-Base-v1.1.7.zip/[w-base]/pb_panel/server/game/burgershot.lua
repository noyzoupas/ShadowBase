-- Burger Shot (ressource « burgershot ») : réglages du métier dans le panel. La ressource les lit avec exports.pb_panel:GetBurgerShotSettings().

local Form = PB.Form

local look = Form.Cfg({ ns = 'burgershot', id = 'main', title = 'Burger Shot', perm = 'burgershot.edit', permLabel = 'Régler le Burger Shot (prix, livraison, cuisine)', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Bornes de commande ouvertes', default = true },
    { k = 'auto_kitchen', type = 'toggle', label = 'Sans équipier en service : cuisine automatique', default = true, hint = 'La commande est préparée seule puis posée au comptoir. Désactivé : les bornes sont fermées sans équipier.' },
    { k = 'auto_prep_secs', type = 'number', label = 'Cuisine automatique : durée de préparation (s)', default = 60, min = 10, max = 600 },
    { k = 'commission', type = 'number', label = "Prime de l'équipier par commande (% du prix)", default = 15, min = 0, max = 80, hint = "Prise dans la caisse de l'entreprise et versée sur le compte de celui qui remet la commande." },
    { k = 'delivery_fee', type = 'number', label = 'Frais de livraison ($)', default = 25, min = 0, max = 1000 },
    { k = 'delivery_share', type = 'number', label = 'Part des frais de livraison pour le livreur (%)', default = 100, min = 0, max = 100 },
    { k = 'npc_orders', type = 'toggle', label = 'Commandes de PNJ à livrer quand des équipiers sont en service', default = true },
    { k = 'npc_every', type = 'number', label = 'Une commande de PNJ toutes les (minutes)', default = 4, min = 1, max = 60 },
    { k = 'npc_max', type = 'number', label = 'Commandes de PNJ en attente au maximum', default = 3, min = 1, max = 10 },
    { k = 'price_pct', type = 'number', label = 'Prix de toute la carte (%)', default = 100, min = 25, max = 400 },
    { k = 'prices', type = 'list', label = 'Prix par article (identifiant|prix)', default = {}, maxitems = 40, maxlen = 40, pattern = '^[%w_]+|%d+$', wide = true,
      hint = 'Ex. bleeder|9. Articles : bleeder, heartstopper, prickly, meatfree, torpedo, fries, nuggets, rings, sprunk, ecola, water, coffee, shake, donut, icecream, menu_bleeder, menu_moneyshot, menu_prickly, menu_kids.' },
    { k = 'disabled', type = 'tags', label = 'Articles retirés de la carte', default = {}, maxitems = 40 },
    { k = 'order_timeout', type = 'number', label = 'Commande remboursée si elle n’est pas remise après (minutes)', default = 25, min = 5, max = 120 },
    { k = 'difficulty', type = 'select', label = 'Difficulté des postes de cuisine', default = 'normal', opts = { { 'easy', 'Facile' }, { 'normal', 'Normale' }, { 'hard', 'Difficile' } } },
    { k = 'manager_grade', type = 'number', label = 'Grade minimum pour annuler et rembourser', default = 1, min = 0, max = 20, hint = 'Le patron peut toujours le faire.' },
} })

PB.Module({
    id = 'burgershot', label = 'Burger Shot', icon = 'food', group = 'Serveur', order = 141, perm = 'burgershot.edit',
    hint = 'Bornes de commande, cuisine, livraison et prix du Burger Shot',
    doc = "## Burger Shot\nLe client commande et paie à une **borne**. Un équipier en service prend la commande sur l'**écran de cuisine**, la prépare aux postes (grill, friteuse, boissons, desserts, montage), puis la **remet au client** en main propre, au comptoir ou en **livraison** (scooter de l'entreprise).\n\n- Placer les points en jeu : commande `/bsplace` (bornes, postes, comptoir, écran, garage, tableau, adresses de livraison).\n- Argent : le paiement va dans la caisse de l'entreprise ; l'équipier touche une prime et le livreur les frais de livraison et le pourboire.\n- Sans équipier : cuisine automatique (réglable) et retrait au comptoir.",
    view = function(ctx)
        return { tabs = { { id = 'main', label = 'Réglages', icon = 'sliders', build = function() return { look(ctx) } end } } }
    end,
})

exports('GetBurgerShotSettings', function() return PB.Cfg.All('burgershot') end)
