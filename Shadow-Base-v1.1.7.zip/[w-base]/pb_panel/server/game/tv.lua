-- Télévisions : ALT sur un écran du décor (télé, écran de cinéma, grand écran) -> « Diffuser une vidéo » avec un lien YouTube ou Vimeo.
-- Tout le monde à proximité voit la même vidéo, au même moment, et l'entend de plus en plus fort en s'approchant.
-- Seuls les sites de la liste blanche sont acceptés : un lien quelconque serait chargé chez tous les joueurs proches.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('tv.manage', 'Gérer les télévisions (couper une diffusion, réglages)', 'world')
PB.Cfg.Define('tv', { enabled = true, range = 25, volume = 60, max_mins = 180, domains = { 'youtube.com', 'youtu.be', 'vimeo.com' } })
local TV = { screens = {} }
G.TV = TV
local function cfg(k, d) return PB.Cfg.Get('tv', k, d) end
local function now() return os.time() end

-- Écrans connus : modèle -> cible de rendu du jeu (render target)
TV.MODELS = {
    { 'prop_tv_flat_01', 'tvscreen', 'Télévision' }, { 'prop_tv_flat_01_screen', 'tvscreen', 'Télévision' }, { 'prop_tv_flat_02', 'tvscreen', 'Télévision' }, { 'prop_tv_flat_02b', 'tvscreen', 'Télévision' },
    { 'prop_tv_flat_03', 'tvscreen', 'Télévision' }, { 'prop_tv_flat_03b', 'tvscreen', 'Télévision' }, { 'prop_tv_flat_michael', 'tvscreen', 'Télévision' }, { 'prop_trev_tv_01', 'tvscreen', 'Télévision' },
    { 'prop_tv_03', 'tvscreen', 'Télévision' }, { 'des_tvsmash_start', 'tvscreen', 'Télévision' }, { 'v_ilev_cin_screen', 'cinscreen', 'Écran de cinéma' }, { 'prop_huge_display_01', 'big_disp', 'Grand écran' },
    { 'prop_huge_display_02', 'big_disp', 'Grand écran' },
}
local MODEL_OK = {}
for _, m in ipairs(TV.MODELS) do MODEL_OK[GetHashKey and GetHashKey(m[1]) or m[1]] = m MODEL_OK[m[1]] = m end

-- Lien -> { kind = 'yt' | 'vimeo', id } ; nil si le site n'est pas autorisé ou le lien illisible
function TV.Parse(url)
    url = tostring(url or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if #url > 300 or not url:match('^https://') then return nil, 'Colle un lien complet qui commence par https://' end
    local host = (url:match('^https://([^/%?#:]+)') or ''):lower()
    local allowed = false
    for _, d in ipairs(cfg('domains', {}) or {}) do
        d = tostring(d):lower()
        if host == d or host:sub(-(#d + 1)) == '.' .. d then allowed = true end
    end
    if not allowed then return nil, 'Ce site n\'est pas autorisé sur les télés (' .. host .. ').' end
    local id = url:match('youtu%.be/([%w_%-]+)') or url:match('[%?&]v=([%w_%-]+)') or url:match('/shorts/([%w_%-]+)') or url:match('/live/([%w_%-]+)') or url:match('/embed/([%w_%-]+)')
    if host:find('youtu', 1, true) then
        if not id or #id < 6 or #id > 20 then return nil, 'Lien YouTube illisible.' end
        return { kind = 'yt', id = id }
    end
    if host:find('vimeo', 1, true) then
        id = url:match('vimeo%.com/video/(%d+)') or url:match('vimeo%.com/(%d+)')
        return id and { kind = 'vimeo', id = id } or nil, 'Lien Vimeo illisible.'
    end
    return nil, "Ce site n'est pas encore pris en charge (YouTube ou Vimeo)."
end

local function sid(model, x, y, z) return ('%s:%d:%d:%d'):format(tostring(model), math.floor(x + 0.5), math.floor(y + 0.5), math.floor(z + 0.5)) end
local function list()
    local out = {}
    for _, s in pairs(TV.screens) do out[#out + 1] = { id = s.id, model = s.model, rt = s.rt, x = s.x, y = s.y, z = s.z, kind = s.kind, vid = s.vid, at = s.at, title = s.title } end
    return out
end
function TV.Push(target) TriggerClientEvent('pb:g:tv:list', target or -1, PB.Json({ screens = list(), range = tonumber(cfg('range', 25)) or 25, volume = tonumber(cfg('volume', 60)) or 60 })) end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return GetPlayerName(src) or ('Joueur ' .. src) end

function TV.Play(src, model, x, y, z, url)
    if cfg('enabled', true) == false then return false, 'Les télévisions sont désactivées.' end
    local m = MODEL_OK[tonumber(model) or model]
    x, y, z = tonumber(x), tonumber(y), tonumber(z)
    if not m or not x then return false, "Ce n'est pas un écran." end
    if G.DistTo(src, x, y, z) > 8.0 then return false, "Approche-toi de l'écran." end
    local v, why = TV.Parse(url)
    if not v then return false, why end
    local id = sid(m[1], x, y, z)
    TV.screens[id] = { id = id, model = m[1], rt = m[2], x = x, y = y, z = z, kind = v.kind, vid = v.id, at = now(), by = G.Get(src) and G.Get(src).license or '', byName = display(src), title = m[3] }
    PB.Audit.Log('monde', 'tv.play', display(src), id, nil, nil, { url = tostring(url):sub(1, 200) })
    TV.Push()
    return true, 'Diffusion lancée sur l\'écran.'
end
function TV.Stop(src, id, force)
    local s = TV.screens[tostring(id)]
    if not s then return false, 'Rien ne passe sur cet écran.' end
    if not force and G.DistTo(src, s.x, s.y, s.z) > 8.0 then return false, "Approche-toi de l'écran." end
    TV.screens[s.id] = nil
    TV.Push()
    return true, 'Diffusion arrêtée.'
end
-- Arrêt automatique au bout de max_mins
CreateThread(function()
    while true do
        Wait(60000)
        local max, changed = (tonumber(cfg('max_mins', 180)) or 0) * 60, false
        if max > 0 then for id, s in pairs(TV.screens) do if now() - s.at > max then TV.screens[id] = nil changed = true end end end
        if changed then TV.Push() end
    end
end)

local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
RegisterNetEvent('pb:g:tv:play', function(model, x, y, z, url)
    local src = source
    if not throttle(src, 2000) or not usable(src) then return end
    local ok, msg = TV.Play(src, model, x, y, z, url)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Télévision', text = msg })
end)
RegisterNetEvent('pb:g:tv:stop', function(id)
    local src = source
    if not throttle(src, 800) or not usable(src) then return end
    local ok, msg = TV.Stop(src, id, P.Has(src, 'tv.manage'))
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Télévision', text = msg })
end)
table.insert(G.beginHooks, function(src) TV.Push(src) end)
AddEventHandler('playerDropped', function() last[source] = nil end)

-- Le menu ALT doit connaître les écrans : on les ajoute à la liste des objets (une fois, sans écraser ce que le staff a réglé)
PB.OnReady(function()
    local objs = PB.Cfg.Get('ctx', 'objects', {}) or {}
    local have = {}
    for _, o in ipairs(objs) do have[tostring(o.model)] = true end
    local added = false
    for _, m in ipairs(TV.MODELS) do
        if not have[m[1]] then objs[#objs + 1] = { model = m[1], label = m[3], cmd = 'pb_tv', icon = 'eye' } added = true end
    end
    if added then PB.Cfg.Set('ctx', 'objects', objs, 0, 'Télévisions : écrans ajoutés au menu ALT', true) end
end)

PB.Action('tv.stop', 'tv.manage', function(ctx, p)
    local ok, msg = TV.Stop(ctx.src, p.id, true)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
local form = PB.Form.Cfg({ ns = 'tv', id = 'settings', title = 'Télévisions', perm = 'tv.manage', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Diffusion sur les écrans (ALT sur une télé)', default = true },
    { k = 'range', type = 'number', label = 'Distance où l\'on entend et voit (m)', default = 25, min = 5, max = 100 },
    { k = 'volume', type = 'number', label = 'Volume maximal (%)', default = 60, min = 5, max = 100 },
    { k = 'max_mins', type = 'number', label = 'Arrêt automatique après (minutes, 0 = jamais)', default = 180, min = 0, max = 1440 },
    { k = 'domains', type = 'list', label = 'Sites autorisés', default = { 'youtube.com', 'youtu.be', 'vimeo.com' }, maxitems = 12, maxlen = 40, pattern = '^[%w%.%-]+$', wide = true,
      hint = 'Un site ajouté ici est chargé chez tous les joueurs proches de l\'écran : n\'ajoute que des sites de vidéos connus.' },
} })
PB.Module({
    id = 'tv', label = 'Télévisions', icon = 'eye', group = 'Serveur', order = 84, perm = 'tv.manage', hint = 'Vidéos diffusées sur les écrans',
    caps = function()
        return PB.Capsify({
            { 'Diffusion YouTube et Vimeo', 'ok', 'ALT sur un écran du décor, puis le lien. Même vidéo, au même moment, pour tous les joueurs proches.' },
            { 'Son selon la distance', 'ok', 'Plus fort en s\'approchant, coupé au-delà de la distance réglée.' },
            { 'Testé dans un vrai client FiveM', 'warn', "Non : l'affichage passe par une page web interne (DUI) et le lecteur YouTube. Si un écran reste noir, essaie un autre modèle de télé ou une autre vidéo (certaines refusent d'être intégrées)." },
            { 'Plusieurs vidéos sur deux télés du même modèle côte à côte', 'off', "Le jeu n'a qu'une cible d'affichage par modèle : seule la plus proche s'affiche." },
        })
    end,
    doc = "## Télévisions\nUn joueur s'approche d'une télé, maintient **ALT**, clique sur l'écran puis **Diffuser une vidéo** et colle un lien YouTube (ou Vimeo). Tout le monde autour voit et entend la même vidéo. **Arrêter** coupe la diffusion. Le staff coupe n'importe quel écran ici.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'En cours', icon = 'eye', build = function()
                local rows = {}
                for _, s in pairs(TV.screens) do rows[#rows + 1] = { title = s.title, pos = ('%.0f, %.0f'):format(s.x, s.y), what = s.kind .. ' · ' .. s.vid, by = s.byName, at = s.at, actions = { { action = 'tv.stop', label = 'Couper', icon = 'x', payload = { id = s.id }, danger = true } } } end
                return { B.table({ id = 'tvl', title = 'Diffusions en cours', columns = { { k = 'title', label = 'Écran' }, { k = 'pos', label = 'Position', type = 'mono' }, { k = 'what', label = 'Vidéo' }, { k = 'by', label = 'Lancée par' }, { k = 'at', label = 'Depuis', type = 'date' } }, rows = rows, empty = 'Aucun écran allumé.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
