-- Photos des joueurs : portrait du personnage (capture de son visage, nécessite screenshot-basic) sinon photo Discord (nécessite le jeton du bot).
-- Le portrait est stocké en petit JPEG (data:image/jpeg) validé ; la photo Discord n'est qu'une adresse du CDN officiel, jamais téléchargée ici.
local DB = PB.DB
local G = PB.G
local Ph = {}
G.Photos = Ph

PB.Migrate('172_photos', 'Photos des joueurs (portrait et Discord)', {
    [[CREATE TABLE IF NOT EXISTS pb_photos (
        license VARCHAR(64) NOT NULL, portrait MEDIUMTEXT NULL, discord_id VARCHAR(32) NOT NULL DEFAULT '', discord_url VARCHAR(255) NOT NULL DEFAULT '',
        updated INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
})
PB.Cfg.Define('photos', { enabled = true, ask_portrait = true, max_chars = 60000, discord_ttl = 43200 })
local function cfg(k, d) return PB.Cfg.Get('photos', k, d) end
local function now() return os.time() end

local MAX = 60000
local function validPortrait(s) return type(s) == 'string' and #s <= math.min(MAX, cfg('max_chars', MAX)) and s:match('^data:image/jpeg;base64,[%w%+/=]+$') ~= nil end
local function validDiscordUrl(u) return type(u) == 'string' and #u <= 255 and u:match('^https://cdn%.discordapp%.com/avatars/%d+/[%w_]+%.png%?size=%d+$') ~= nil end
Ph.ValidPortrait, Ph.ValidDiscordUrl = validPortrait, validDiscordUrl

-- Photo à afficher pour une licence : portrait d'abord, sinon Discord, sinon nil.
function Ph.Url(license)
    if cfg('enabled', true) ~= true then return nil end
    local r = DB.one('SELECT portrait, discord_url FROM pb_photos WHERE license = ?', { license })
    if not r then return nil end
    if r.portrait and validPortrait(r.portrait) then return r.portrait, 'portrait' end
    if r.discord_url and r.discord_url ~= '' and validDiscordUrl(r.discord_url) then return r.discord_url, 'discord' end
    return nil
end
function Ph.Of(src) local p = G.Get(src) return p and Ph.Url(p.license) or nil end

function Ph.SetPortrait(license, data)
    if not validPortrait(data) then return false, 'Image invalide.' end
    DB.exec('INSERT INTO pb_photos (license, portrait, updated) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE portrait = VALUES(portrait), updated = VALUES(updated)', { license, data, now() })
    return true
end
function Ph.ClearPortrait(license) DB.exec('UPDATE pb_photos SET portrait = NULL, updated = ? WHERE license = ?', { now(), license }) end

local lastSet = {}
RegisterNetEvent('pb:g:photo:set', function(data)
    local src = source
    local p = G.Get(src)
    if not p or cfg('enabled', true) ~= true then return end
    local t = GetGameTimer and GetGameTimer() or now() * 1000
    if lastSet[src] and t - lastSet[src] < 20000 then return end
    lastSet[src] = t
    if Ph.SetPortrait(p.license, data) then TriggerEvent('pb_panel:portraitSet', src) end
end)
AddEventHandler('playerDropped', function() lastSet[source] = nil end)

local function shotReady() return GetResourceState and GetResourceState('screenshot-basic') == 'started' end
function Ph.Ask(src)
    if cfg('ask_portrait', true) ~= true or cfg('enabled', true) ~= true or not shotReady() then return false end
    TriggerClientEvent('pb:g:photo:ask', src)
    return true
end
-- après la création du personnage, ou à la connexion si le portrait manque
AddEventHandler('pb_panel:characterCreated', function(src) SetTimeout(6000, function() if G.Get(src) then Ph.Ask(src) end end) end)

-- Photo Discord : le serveur lit l'avatar via l'API du bot (jeton requis) puis ne garde que l'adresse du CDN.
function Ph.FetchDiscord(src)
    if cfg('enabled', true) ~= true then return end
    local p = G.Get(src)
    local did = p and GetPlayerIdentifierByType and GetPlayerIdentifierByType(src, 'discord')
    did = did and tostring(did):match('^discord:(%d+)$')
    if not did then return end
    local r = DB.one('SELECT discord_id, discord_url, updated FROM pb_photos WHERE license = ?', { p.license })
    if r and r.discord_id == did and r.discord_url ~= '' and now() - (tonumber(r.updated) or 0) < cfg('discord_ttl', 43200) then return end
    local D = PB.Discord
    if not (D and D.Api and D.BotToken and D.BotToken()) then
        DB.exec('INSERT INTO pb_photos (license, discord_id, updated) VALUES (?, ?, 0) ON DUPLICATE KEY UPDATE discord_id = VALUES(discord_id)', { p.license, did })
        return
    end
    D.Api('GET', '/users/' .. did, nil, function(status, text)
        if status ~= 200 then return end
        local u = PB.FromJson(text, nil)
        local av = type(u) == 'table' and tostring(u.avatar or '')
        if not av or not av:match('^[%w_]+$') then return end
        local url = ('https://cdn.discordapp.com/avatars/%s/%s.png?size=128'):format(did, av)
        if not validDiscordUrl(url) then return end
        DB.exec('INSERT INTO pb_photos (license, discord_id, discord_url, updated) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE discord_id = VALUES(discord_id), discord_url = VALUES(discord_url), updated = VALUES(updated)', { p.license, did, url, now() })
    end)
end
RegisterNetEvent('pb:clientReady', function() local src = source SetTimeout(4000, function() if G.Get(src) then pcall(Ph.FetchDiscord, src) end end) end)

PB.SelfTest.Add('photos', function(R)
    R.check(validPortrait('data:image/jpeg;base64,AAAA') and not validPortrait('data:image/png;base64,AAAA') and not validPortrait('javascript:alert(1)'), 'photos', 'validation du portrait')
    R.check(validDiscordUrl('https://cdn.discordapp.com/avatars/123/abc_1.png?size=128') and not validDiscordUrl('https://evil.example/avatars/1/a.png?size=1'), 'photos', "validation de l'adresse Discord")
end)
