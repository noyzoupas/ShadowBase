-- Menus (bibliothèque « RageUI ») : apparence 100 % réglable depuis le panel. Le rendu est dans web/game/rmenu.js, la logique dans client/lib/menu_core.lua.
-- Les menus F2 (actions rapides) et F5 (menu personnel) s'appuient sur cette apparence.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G = PB.G

P.Register('menus.edit', "Modifier l'apparence et les touches des menus", 'menus', true)

local HEX = '^#%x%x%x%x%x%x$'
PB.Cfg.Define('menus', {
    accent = '#dfe2e7', bg = '#111216', bg2 = '#2b2e35', text = '#ffffff', muted = '#8d939e',
    banner_mode = 'anim', banner_text = '', banner_sub = '', banner_image = '', banner_height = 110, banner_band = true, skin = 'shadow', banner_logo = '',
    chips = { 'discord|DISCORD.GG/MONSERVEUR', 'globe|HTTPS://MONSERVEUR.FR' },
    width = 440, radius = 10, opacity = 88, blur = 0, row_height = 44, font_scale = 100, position = 'center', offset_x = 0, offset_y = -300,
    show_counter = true, show_desc = true, show_progress = true, title_case = 'upper', selected_style = 'bar',
    max_visible = 10, wrap = true, sounds = true, repeat_first = 380, repeat_every = 85,
    ui_mode = 'auto', ui_allow_choice = true, ui_overrides = {},
})

local look = Form.Cfg({ ns = 'menus', id = 'look', title = 'Apparence du menu', perm = 'menus.edit', cols = 2, fields = {
    { k = 'accent', type = 'color', label = "Couleur d'accent", default = '#dfe2e7' }, { k = 'bg', type = 'color', label = 'Fond', default = '#111216' },
    { k = 'bg2', type = 'color', label = 'Fond de la bannière', default = '#2b2e35' }, { k = 'text', type = 'color', label = 'Texte', default = '#ffffff' },
    { k = 'muted', type = 'color', label = 'Texte discret', default = '#8d939e' },
    { k = 'skin', type = 'select', label = 'Style du menu', opts = { { 'shadow', 'Shadow Studio (sombre, à puces)' }, { 'flat', 'Épuré (plat)' }, { 'classic', 'Classique (dégradé)' } }, default = 'shadow' },
    { k = 'selected_style', type = 'select', label = 'Élément sélectionné', opts = { { 'bar', 'Dégradé + barre' }, { 'fill', 'Rempli' }, { 'soft', 'Dégradé seul' } }, default = 'bar' },
    { k = 'banner_mode', type = 'select', label = 'Bannière', opts = { { 'anim', 'Shadow Base animée' }, { 'text', 'Logo texte' }, { 'image', 'Image de bannière' } }, default = 'anim' },
    { k = 'banner_height', type = 'number', label = 'Hauteur de la bannière (0 = aucune)', default = 110, min = 0, max = 260 },
    { k = 'banner_text', type = 'text', label = 'Texte du logo (vide = nom du serveur)', default = '', maxlen = 24 }, { k = 'banner_sub', type = 'text', label = 'Sous-titre du logo', default = '', maxlen = 40 },
    { k = 'banner_image', type = 'asset', label = 'Image de bannière (depuis mon PC)', default = '', wide = true, maxw = 1000, maxh = 320, hint = "Utilisée si « Image » est choisi. Style Shadow : remplace le logo en haut du menu (format conseillé 1000 × 380, l'image se fond vers le bas comme la maquette)." },
    { k = 'banner_logo', type = 'asset', label = 'Logo centré dans la bannière (depuis mon PC)', default = '', wide = true, maxw = 600, maxh = 240, hint = 'Vide = le logo du serveur (Identité), sinon le texte.' },
    { k = 'banner_band', type = 'toggle', label = 'Bandeau coloré derrière le logo', default = true },
    { k = 'chips', type = 'list', label = 'Pastilles de la bannière (icône|texte, 3 maximum)', default = { 'discord|DISCORD.GG/MONSERVEUR', 'globe|HTTPS://MONSERVEUR.FR' }, maxitems = 3, maxlen = 48, wide = true, hint = 'Icônes : discord, globe, link, star, gps, gift, wifi…' },
    { k = 'width', type = 'number', label = 'Largeur (px)', default = 440, min = 280, max = 640 }, { k = 'radius', type = 'number', label = 'Arrondi (px)', default = 10, min = 0, max = 32 },
    { k = 'row_height', type = 'number', label = "Hauteur d'une ligne (px)", default = 44, min = 32, max = 72 }, { k = 'font_scale', type = 'number', label = 'Taille du texte (%)', default = 100, min = 70, max = 160 },
    { k = 'opacity', type = 'number', label = 'Transparence : opacité du fond (%)', default = 88, min = 10, max = 100 }, { k = 'blur', type = 'number', label = 'Flou du fond (px)', default = 0, min = 0, max = 30 },
    { k = 'position', type = 'select', label = "Position à l'écran", opts = { { 'left', 'Gauche' }, { 'center', 'Centre' }, { 'right', 'Droite' } }, default = 'center' },
    { k = 'title_case', type = 'select', label = 'Titre', opts = { { 'upper', 'MAJUSCULES' }, { 'normal', 'Tel quel' } }, default = 'upper' },
    { k = 'offset_x', type = 'number', label = 'Décalage horizontal (px)', default = 0, min = -2000, max = 2000 }, { k = 'offset_y', type = 'number', label = 'Décalage vertical (px) — le haut du menu reste fixe', default = -300, min = -2000, max = 2000 },
    { k = 'show_counter', type = 'toggle', label = 'Afficher le compteur (3 / 8)', default = true }, { k = 'show_progress', type = 'toggle', label = 'Afficher la ligne de progression', default = true },
    { k = 'show_desc', type = 'toggle', label = 'Afficher la description', default = true },
} })

local behave = Form.Cfg({ ns = 'menus', id = 'behave', title = 'Comportement', perm = 'menus.edit', cols = 2, fields = {
    { k = 'max_visible', type = 'number', label = 'Éléments visibles à la fois', default = 10, min = 4, max = 16 },
    { k = 'wrap', type = 'toggle', label = 'Boucler en bas / en haut de la liste', default = true }, { k = 'sounds', type = 'toggle', label = 'Sons de navigation', default = true },
    { k = 'ui_mode', type = 'select', label = 'Style des menus', opts = { { 'auto', 'Selon chaque menu (lib par défaut)' }, { 'lib', 'Tous en lib (flèches + Entrée)' }, { 'ui', 'Tous en interface (souris, grandes cartes)' } }, default = 'auto', hint = "L'interface reprend exactement les mêmes menus : choix, listes, cases, saisies." },
    { k = 'ui_allow_choice', type = 'toggle', label = 'Laisser chaque joueur choisir (commande /menustyle)', default = true, hint = "Le choix du joueur passe avant les réglages ci-dessous." },
    { k = 'ui_overrides', type = 'list', label = 'Style par menu (identifiant|lib ou ui)', default = {}, maxitems = 30, maxlen = 40, pattern = '^[%w_%.%-]+|%a+$', wide = true, hint = "Ex. staff|ui, quick|lib, me|ui, shop|ui. Un identifiant s'applique aussi à ses sous-menus. Liste : staff, quick, me, mechanic, justice…" },
    { k = 'repeat_first', type = 'number', label = 'Délai avant répétition (ms)', default = 380, min = 150, max = 1000 }, { k = 'repeat_every', type = 'number', label = 'Répétition (ms)', default = 85, min = 40, max = 400 },
} })

PB.Module({
    id = 'menus', label = 'Menus', icon = 'sliders', group = 'Serveur', order = 139, perm = 'menus.edit', hint = 'Menu style RageUI : apparence, F2, F5, bibliothèque',
    caps = function()
        return PB.Capsify({
            { 'Menu complet (boutons, listes, curseurs, cases, saisie, sous-menus)', 'ok', 'Navigation flèches + Entrée + Retour, sans souris : le joueur peut continuer à bouger.' },
            { 'Apparence 100 % réglable', 'ok', 'Couleurs, bannière (logo ou image), largeur, arrondi, position, textes.' },
            { 'Utilisable par tes autres scripts', 'ok', "Exports Lua : voir l'onglet Développeur." },
            { 'Manette', 'ok', 'Les mêmes touches de navigation fonctionnent à la manette (croix directionnelle, A, B).' },
        })
    end,
    doc = "## Menus\nUn seul style de menu pour tout le serveur : touche **F2** (actions rapides de ton entreprise), touche **F5** (menu personnel), et tes propres scripts.\n\n### Pour développeurs\n```lua\nexports.pb_panel:OpenMenu({\n  id = 'demo', title = 'Mon menu', subtitle = 'Sous-titre',\n  items = {\n    { label = 'Bouton', description = 'Texte du bas', onSelect = function() print('ok') end },\n    { type = 'checkbox', label = 'Option', checked = true, onChange = function(_, v) print(v) end },\n    { type = 'list', label = 'Choix', list = { 'A', 'B', 'C' }, onChange = function(_, v) print(v) end },\n    { type = 'slider', label = 'Volume', min = 0, max = 10, value = 5 },\n    { type = 'input', label = 'Nom', maxlen = 30, onSelect = function(_, text) print(text) end },\n    { label = 'Plus…', submenu = { id = 'sub', title = 'Sous-menu', items = { } } },\n  },\n})\nexports.pb_panel:CloseMenu()\nexports.pb_panel:IsMenuOpen()\n```\nUn élément peut être caché (`hidden = true`) ou grisé (`disabled = true`). Un menu peut être reconstruit à chaque ouverture avec `build = function() return items end`.",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function()
                return { { type = 'gpreview', kind = 'rmenu', title = 'Aperçu du menu (le mode « UI » en jeu a exactement le même rendu, avec la souris)', form = 'menus.look', cfg = PB.Cfg.All('menus') } }
            end },
            { id = 'look', label = 'Apparence', icon = 'star', build = function() return { look(ctx) } end },
            { id = 'behave', label = 'Comportement', icon = 'sliders', build = function() return { behave(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('menus', function(R)
    local c = PB.Cfg.All('menus') or {}
    R.check(tostring(c.accent or ''):match(HEX) ~= nil, "couleur d'accent des menus", 'la couleur d\'accent est invalide')
    local img = tostring(c.banner_image or '')
    R.check(img == '' or img:match('^asset:%x+$') ~= nil or img:match('^https://') ~= nil or img:match('^img/') ~= nil, 'image de bannière', "image invalide : renvoie-la depuis ton PC")
    R.check((tonumber(c.width) or 440) >= 280, 'largeur du menu', 'trop étroite')
end)

-- Le menu est maintenant accroché par le HAUT (la bannière ne bouge plus quand la liste change de taille) : on convertit une seule fois l'ancien réglage centré.
PB.OnReady(function()
    -- Menu Shadow Studio : la première version du style avait ramené la largeur à 342 px.
    -- On rétablit la largeur historique de 440 px, une seule fois, pour les installations concernées.
    if tostring(PB.Cfg.Get('menus', 'skin', 'shadow')) == 'shadow' and PB.Cfg.Get('menus', 'shadow_width_440', false) ~= true then
        local w = tonumber(PB.Cfg.Get('menus', 'width', 440)) or 440
        if w <= 342 then
            PB.Cfg.Set('menus', 'width', 440, nil, 'Largeur du menu Shadow Studio (440 px)')
        end
        PB.Cfg.Set('menus', 'shadow_width_440', true, nil, 'Migration')
    end

    if PB.Cfg.Get('menus', 'top_anchor', false) == true then return end
    if PB.Cfg.Has('menus', 'offset_y') then
        local oy = tonumber(PB.Cfg.Get('menus', 'offset_y', 0)) or 0
        PB.Cfg.Set('menus', 'offset_y', math.max(-2000, math.min(2000, oy - 300)), nil, 'Menu accroché par le haut')
    end
    local sm = PB.Cfg.Has('interface', 'staffmenu') and PB.Cfg.Get('interface', 'staffmenu', nil) or nil
    if type(sm) == 'table' then
        sm.y = math.max(0, math.min(100, (tonumber(sm.y) or 50) - 28))
        PB.Cfg.Set('interface', 'staffmenu', sm, nil, 'Menu staff accroché par le haut')
    end
    PB.Cfg.Set('menus', 'top_anchor', true, nil, 'Migration')
end)
