-- Gestes du staff sur un joueur, rangés par thème : vie, déplacement, apparence, animations, médias, troll, véhicule, écran.
-- Chaque geste est une action du menu staff (droit, service, rang, journal) ET utilisable depuis le panel (Joueurs › Gestes).
-- Le serveur décide de tout : liste blanche d'effets, durées bornées, URL de médias limitées aux hôtes autorisés, captures d'écran
-- seulement avec screenshot-basic. Le client n'exécute que des effets prévus (jamais de code ni de texte libre interprété).

local P = PB.Perm
local G = PB.G
local S = G.Staff
local Ge = {}
G.Gestures = Ge

P.Register('staff.gestures', 'Gestes sur un joueur (vie, déplacement, apparence, animations, véhicule)', 'staff', false)
P.Register('staff.troll', 'Gestes « troll » et médias plein écran sur un joueur', 'staff', true)
P.Register('staff.screen', "Voir l'écran d'un joueur (capture ou direct)", 'staff', true)

PB.Cfg.Define('gestures', { media_hosts = {}, max_seconds = 120, cooldown_ms = 700, screen_max = 90, screen_interval = 2500, screen_notify = false })
local function cfg(k, d) return PB.Cfg.Get('gestures', k, d) end

Ge.THEMES = {
    { id = 'vie', label = 'Vie' }, { id = 'depl', label = 'Déplacement' }, { id = 'appa', label = 'Apparence' }, { id = 'anim', label = 'Animations' },
    { id = 'media', label = 'Médias' }, { id = 'troll', label = 'Troll' }, { id = 'veh', label = 'Véhicule' }, { id = 'ecran', label = 'Écran' },
}

-- Animations proposées (clés envoyées au client ; le client possède la table dict/nom).
Ge.ANIMS = {
    { 'salute', 'Salut militaire' }, { 'handsup', 'Mains en l\'air' }, { 'facepalm', 'Facepalm' }, { 'thumbs', 'Pouce levé' }, { 'dj', 'DJ' }, { 'guitar', 'Guitare imaginaire' },
    { 'wave', 'Coucou' }, { 'cheer', 'Acclamer' }, { 'pushups', 'Pompes' }, { 'situps', 'Abdos' }, { 'yoga', 'Yoga' }, { 'flex', 'Montrer ses muscles' },
    { 'party', 'Faire la fête' }, { 'smoke', 'Fumer' }, { 'impatient', 'Attendre, impatient' }, { 'slump', 'S\'effondrer par terre' },
}
Ge.SOUNDS = { { 'beep', 'Bip' }, { 'alert', 'Alerte' }, { 'success', 'Succès' }, { 'timer', 'Minuteur' } }

local LIST, BY = {}, {}
local function def(g)
    g.perm = g.perm or 'staff.gestures'
    g.actId = 'g_' .. g.id
    LIST[#LIST + 1] = g
    BY[g.id] = g
end

local function secs(g, p)
    local d = math.floor(tonumber(p.duration) or g.dur or 30)
    return PB.Clamp and PB.Clamp(d, 3, cfg('max_seconds', 120)) or math.max(3, math.min(cfg('max_seconds', 120), d))
end
local function op(o, extra) return function(src, t, p, g) local d = { op = o } for k, v in pairs(extra or {}) do d[k] = v end if g.dur then d.dur = secs(g, p) end return d end end

-- VIE
def { id = 'hunger_full', theme = 'vie', label = 'Rassasier', desc = 'Faim au maximum.', server = function(src, t) G.AddStatus(t, 'hunger', 100) return true, 'Faim remplie.' end }
def { id = 'thirst_full', theme = 'vie', label = 'Désaltérer', desc = 'Soif au maximum.', server = function(src, t) G.AddStatus(t, 'thirst', 100) return true, 'Soif remplie.' end }
def { id = 'hunger_zero', theme = 'vie', label = 'Vider la faim', desc = 'Le joueur a très faim.', server = function(src, t) G.AddStatus(t, 'hunger', -100) return true, 'Faim vidée.' end }
def { id = 'thirst_zero', theme = 'vie', label = 'Vider la soif', desc = 'Le joueur a très soif.', server = function(src, t) G.AddStatus(t, 'thirst', -100) return true, 'Soif vidée.' end }
def { id = 'stress_max', theme = 'vie', label = 'Stress au maximum', server = function(src, t) G.AddStatus(t, 'stress', 100) return true, 'Stress au maximum.' end }
def { id = 'stress_zero', theme = 'vie', label = 'Calmer', desc = 'Stress à zéro.', server = function(src, t) G.AddStatus(t, 'stress', -100) return true, 'Stress retiré.' end }
def { id = 'hp1', theme = 'vie', label = 'Mettre à 1 PV', desc = 'Quasi mort, mais pas à terre.', data = op('hp', { value = 1 }) }
def { id = 'armor_half', theme = 'vie', label = 'Gilet à moitié', data = op('armor', { value = 50 }) }
def { id = 'armor_off', theme = 'vie', label = 'Retirer le gilet', data = op('armor', { value = 0 }) }
def { id = 'god', theme = 'vie', label = 'Invincible un moment', desc = 'Durée en secondes (3–120).', dur = 30, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('god') }
def { id = 'sleep', theme = 'vie', label = 'Endormir', desc = 'Le fait tomber au sol, inconscient quelques secondes.', dur = 20, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('ragdoll') }

-- DÉPLACEMENT
def { id = 'speed_up', theme = 'depl', label = 'Course rapide', dur = 60, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('speed', { mult = 1.49 }) }
def { id = 'speed_down', theme = 'depl', label = 'Ralentir', dur = 60, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('speed', { mult = 0.7 }) }
def { id = 'jump', theme = 'depl', label = 'Super saut', dur = 60, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('jump') }
def { id = 'behind', theme = 'depl', label = 'Me placer à côté de lui', desc = 'Tu apparais à côté de lui (sans le déplacer).', server = function(src, t)
    local ped = GetPlayerPed(t)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return false, 'Position illisible (OneSync requis).' end
    TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = c.x + 1.5, y = c.y, z = c.z }))
    return true, 'Tu es à côté de lui.'
end }
def { id = 'into_my_veh', theme = 'depl', label = 'Le mettre dans mon véhicule', desc = 'Il monte dans le véhicule où tu es (place libre).', server = function(src, t)
    local ok, net = pcall(function() local v = GetVehiclePedIsIn(GetPlayerPed(src), false) if not v or v == 0 then return nil end return NetworkGetNetworkIdFromEntity(v) end)
    if not ok or not net then return false, 'Monte dans un véhicule avant.' end
    TriggerClientEvent('pb:g:gx', t, PB.Json({ op = 'intoveh', net = net }))
    return true, 'Il est placé dans ton véhicule.'
end }

-- APPARENCE
def { id = 'ped', theme = 'appa', label = 'Changer de ped', desc = 'Modèle (ex. a_c_chop). Il garde ce ped jusqu\'à « Rétablir ».', perm = 'staff.troll', inputs = { { k = 'model', label = 'Modèle de ped', maxlen = 40 } },
    check = function(p) local m = tostring(p.model or '') if not m:match('^[%w_]+$') or #m < 3 then return false, 'Modèle invalide.' end return true end, data = function(src, t, p) return { op = 'ped', model = tostring(p.model) } end }
def { id = 'ped_restore', theme = 'appa', label = 'Rétablir son apparence', desc = 'Remet le personnage et sa tenue.', data = op('restore') }
def { id = 'hide', theme = 'appa', label = 'Rendre invisible', dur = 30, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('hide') }
def { id = 'props', theme = 'appa', label = 'Retirer chapeau et lunettes', data = op('props') }
def { id = 'clean', theme = 'appa', label = 'Nettoyer (sang, saleté)', data = op('clean') }

-- ANIMATIONS (une entrée par animation + arrêt)
for _, a in ipairs(Ge.ANIMS) do def { id = 'anim_' .. a[1], theme = 'anim', label = a[2], desc = 'Joue l\'animation sur le joueur (il peut l\'interrompre en bougeant).', data = op('anim', { key = a[1] }) } end
def { id = 'anim_stop', theme = 'anim', label = 'Arrêter l\'animation', data = op('animstop') }

-- MÉDIAS
local EXT = { png = 'image', jpg = 'image', jpeg = 'image', gif = 'image', webp = 'image', mp3 = 'audio', ogg = 'audio', wav = 'audio', mp4 = 'video', webm = 'video' }
function Ge.CheckUrl(u)
    u = tostring(u or '')
    if #u > 300 or u:find('[%s%c"\'<>\\]') then return nil, 'Adresse invalide.' end
    local host, path = u:match('^https://([%w%.%-]+)(/[^?#]*)')
    if not host then return nil, "Adresse https:// obligatoire (avec un chemin vers le fichier)." end
    host = host:lower()
    local ok = false
    for _, h in ipairs(cfg('media_hosts', {}) or {}) do
        h = tostring(h):lower()
        if h ~= '' and (host == h or host:sub(-#h - 1) == '.' .. h) then ok = true break end
    end
    if not ok then return nil, "Hôte non autorisé : ajoute-le dans Joueurs › Gestes › Hôtes de médias." end
    local ext = path:match('%.(%w+)$')
    local kind = ext and EXT[ext:lower()]
    if not kind then return nil, 'Type de fichier non géré (png, jpg, gif, webp, mp3, ogg, wav, mp4, webm).' end
    return kind
end
def { id = 'banner', theme = 'media', label = 'Message plein écran', desc = 'Un grand message au centre de son écran.', perm = 'staff.troll', dur = 8, inputs = { { k = 'text', label = 'Message', maxlen = 140 }, { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } },
    check = function(p) if PB.Trim(PB.Sanitize(tostring(p.text or ''), 140)) == '' then return false, 'Écris un message.' end return true end,
    data = function(src, t, p, g) return { op = 'banner', text = PB.Trim(PB.Sanitize(tostring(p.text), 140)), dur = secs(g, p) } end }
for _, s in ipairs(Ge.SOUNDS) do def { id = 'sound_' .. s[1], theme = 'media', label = 'Son : ' .. s[2], perm = 'staff.troll', data = op('sound', { key = s[1] }) } end
def { id = 'media', theme = 'media', label = 'Image, son ou vidéo (adresse)', desc = 'Seuls les hôtes autorisés sont acceptés (réglage ci-dessous). Désactivé tant qu\'aucun hôte n\'est autorisé.', perm = 'staff.troll', dur = 15,
    inputs = { { k = 'url', label = 'Adresse https://… du fichier', maxlen = 300 }, { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } },
    check = function(p) local k, e = Ge.CheckUrl(p.url) if not k then return false, e end return true end,
    data = function(src, t, p, g) local k = Ge.CheckUrl(p.url) return { op = 'media', url = tostring(p.url), kind = k, dur = secs(g, p) } end }

-- TROLL
def { id = 'ragdoll', theme = 'troll', label = 'Faire tomber', perm = 'staff.troll', dur = 4, data = op('ragdoll') }
def { id = 'drunk', theme = 'troll', label = 'Rendre ivre', perm = 'staff.troll', dur = 45, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('drunk') }
def { id = 'shake', theme = 'troll', label = 'Faire trembler l\'écran', perm = 'staff.troll', dur = 10, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('shake') }
def { id = 'blur', theme = 'troll', label = 'Vue floue', perm = 'staff.troll', dur = 20, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('blur') }
def { id = 'black', theme = 'troll', label = 'Écran noir', perm = 'staff.troll', dur = 5, inputs = { { k = 'duration', label = 'Secondes (3–15)', number = true, maxlen = 2, optional = true } }, data = function(src, t, p, g) local d = secs(g, p) return { op = 'black', dur = math.min(d, 15) } end }
def { id = 'scream', theme = 'troll', label = 'Cri de peur', perm = 'staff.troll', data = op('scream') }
def { id = 'dance', theme = 'troll', label = 'Le faire danser', perm = 'staff.troll', data = op('anim', { key = 'party' }) }
def { id = 'stop_all', theme = 'vie', label = 'Tout arrêter', desc = 'Annule les effets en cours (ivresse, flou, tremblement, médias…).', data = op('stop') }

-- VÉHICULE (celui où il est, ou le plus proche)
def { id = 'v_repair', theme = 'veh', label = 'Réparer', data = op('vrepair') }
def { id = 'v_flip', theme = 'veh', label = 'Remettre sur les roues', data = op('vflip') }
def { id = 'v_engine', theme = 'veh', label = 'Moteur : couper / démarrer', data = op('vengine') }
def { id = 'v_lock', theme = 'veh', label = 'Verrouiller / déverrouiller', data = op('vlock') }
def { id = 'v_burst', theme = 'veh', label = 'Crever les pneus', perm = 'staff.troll', data = op('vburst') }
def { id = 'v_brake', theme = 'veh', label = 'Frein à main bloqué', perm = 'staff.troll', dur = 10, inputs = { { k = 'duration', label = 'Secondes (3–120)', number = true, maxlen = 3, optional = true } }, data = op('vbrake') }
def { id = 'v_boost', theme = 'veh', label = 'Coup de boost', perm = 'staff.troll', data = op('vboost') }
def { id = 'v_spin', theme = 'veh', label = 'Faire pivoter', perm = 'staff.troll', data = op('vspin') }
def { id = 'v_doors', theme = 'veh', label = 'Ouvrir toutes les portes', data = op('vdoors') }
def { id = 'v_delete', theme = 'veh', label = 'Supprimer le véhicule', perm = 'staff.troll', data = op('vdelete') }

-- ÉCRAN : capture / direct (nécessite screenshot-basic) -----------------------------------------------------------------------------------
local function shotApi()
    if not (GetResourceState and GetResourceState('screenshot-basic') == 'started') then return nil end
    return true
end
local live = {}      -- staff -> { t, untilAt }
local function validShot(img)
    return type(img) == 'string' and #img < 900000 and img:match('^data:image/jpeg;base64,[%w%+/=]+$') ~= nil
end
function Ge.Capture(src, t, cb)
    if not shotApi() then return false, "Capture d'écran indisponible : la ressource screenshot-basic doit être démarrée sur le serveur." end
    local ok, err = pcall(function()
        exports['screenshot-basic']:requestClientScreenshot(t, { encoding = 'jpg', quality = 0.45 }, function(e, data)
            if e or not validShot(data) then cb(nil, 'Capture refusée ou invalide.') else cb(data) end
        end)
    end)
    if not ok then return false, "screenshot-basic n'a pas répondu (version trop ancienne ?)." end
    return true
end
Ge.last = {}
local function push(src, t, img, isLive)
    Ge.last[src] = { name = S.RpName(t), img = img, at = os.time() }
    TriggerClientEvent('pb:g:gx:screen', src, PB.Json({ id = t, name = S.RpName(t), img = img, live = isLive and true or false }))
end
function Ge.Screen(src, t, mode)
    if mode == 'stop' then live[src] = nil TriggerClientEvent('pb:g:gx:screen', src, PB.Json({ stop = true })) return true, "Direct arrêté." end
    local ok, why = Ge.Capture(src, t, function(img, e) if img then push(src, t, img, mode == 'live') else G.Notify(src, { type = 'error', title = 'Écran', text = e }) end end)
    if not ok then return false, why end
    if mode == 'live' then live[src] = { t = t, untilAt = os.time() + cfg('screen_max', 90) } end
    if cfg('screen_notify', false) then G.Notify(t, { type = 'info', title = 'Staff', text = 'Un membre du staff consulte ton écran.' }) end
    return true, mode == 'live' and 'Direct démarré.' or 'Capture demandée.'
end
CreateThread(function()
    while true do
        Wait(math.max(1000, tonumber(cfg('screen_interval', 2500)) or 2500))
        for src, l in pairs(live) do
            if os.time() > l.untilAt or not G.Get(src) or not G.Get(l.t) then
                live[src] = nil
                if G.Get(src) then TriggerClientEvent('pb:g:gx:screen', src, PB.Json({ stop = true })) end
            else pcall(Ge.Capture, src, l.t, function(img) if img and live[src] then push(src, l.t, img, true) end end) end
        end
    end
end)
AddEventHandler('playerDropped', function() live[source] = nil end)
Ge.live = live
RegisterNetEvent('pb:g:gx:screenstop', function() live[source] = nil end)
def { id = 'screen_shot', theme = 'ecran', label = 'Capture de son écran', desc = 'Une image de son écran (nécessite screenshot-basic).', perm = 'staff.screen', server = function(src, t) return Ge.Screen(src, t, 'shot') end }
def { id = 'screen_live', theme = 'ecran', label = 'Écran en direct', desc = 'Images renouvelées toutes les quelques secondes, durée limitée.', perm = 'staff.screen', server = function(src, t) return Ge.Screen(src, t, 'live') end }
-- Enregistrement : 15 images sur 30 secondes, gardées en mémoire (les 10 derniers enregistrements) et revisionnables comme un diaporama
Ge.records = {}
local function record(src, t)
    if not shotApi() then return false, "Capture d'écran indisponible : la ressource screenshot-basic doit être démarrée sur le serveur." end
    local rec = { t = t, name = S.RpName(t), at = os.time(), frames = {}, by = src }
    table.insert(Ge.records, 1, rec)
    while #Ge.records > 10 do table.remove(Ge.records) end
    CreateThread(function()
        for i = 1, 15 do
            if not G.Get(t) then break end
            pcall(Ge.Capture, src, t, function(img) if img then rec.frames[#rec.frames + 1] = img end end)
            Wait(2000)
        end
        Wait(3000)
        if G.Get(src) then G.Notify(src, { type = 'success', title = 'Enregistrement', text = ('Enregistrement de %s terminé : %d image(s). « Revoir le dernier enregistrement » pour le regarder.'):format(rec.name, #rec.frames) }) end
    end)
    PB.Audit.Log('staff', 'staff.screen_record', src, rec.name .. ' #' .. t)
    return true, 'Enregistrement de 30 secondes lancé.'
end
local function replay(src, t)
    local rec
    for _, r in ipairs(Ge.records) do if r.t == t or not t then rec = r break end end
    if not rec or #rec.frames == 0 then return false, 'Aucun enregistrement pour ce joueur.' end
    CreateThread(function()
        for i, img in ipairs(rec.frames) do
            TriggerClientEvent('pb:g:gx:screen', src, PB.Json({ id = rec.t, name = ('%s · enregistré le %s · %d/%d'):format(rec.name, os.date('%d/%m %H:%M', rec.at), i, #rec.frames), img = img, live = true }))
            Wait(1200)
        end
    end)
    return true, ('Lecture de l\'enregistrement (%d images).'):format(#rec.frames)
end
def { id = 'screen_record', theme = 'ecran', label = 'Enregistrer son écran (30 s)', desc = '15 images sur 30 secondes, revisionnables ensuite (nécessite screenshot-basic).', perm = 'staff.screen', server = function(src, t) return record(src, t) end }
def { id = 'screen_replay', theme = 'ecran', label = 'Revoir le dernier enregistrement', desc = 'Diaporama du dernier enregistrement de ce joueur.', perm = 'staff.screen', server = function(src, t) return replay(src, t) end }
def { id = 'screen_stop', theme = 'ecran', label = 'Arrêter le direct', perm = 'staff.screen', noTarget = false, server = function(src, t) return Ge.Screen(src, t, 'stop') end }

-- Exécution ---------------------------------------------------------------------------------------------------------------------------------
local lastAt = {}
local function nowMs() return GetGameTimer and GetGameTimer() or os.time() * 1000 end
function Ge.Get(id) return BY[id] end
-- panel = true : pas besoin d'être « en service » (le panel est protégé par ses propres droits).
function Ge.Run(src, id, t, p, panel)
    local g = BY[tostring(id or '')]
    if not g then return false, 'Geste inconnu.' end
    p = type(p) == 'table' and p or {}
    if not P.Has(src, g.perm) then return false, "Tu n'as pas la permission pour ce geste." end
    t = tonumber(t)
    if not t or not G.Get(t) then return false, 'Joueur introuvable ou pas encore connecté.' end
    if t == src then return false, 'Choisis un autre joueur que toi.' end
    if not S.Outranks(src, t) then return false, 'Ce joueur a un rang égal ou supérieur au tien.' end
    local now = nowMs()
    if lastAt[src] and now - lastAt[src] < cfg('cooldown_ms', 700) then return false, 'Doucement : un geste à la fois.' end
    if g.check then local ok, why = g.check(p) if not ok then return false, why end end
    lastAt[src] = now
    local ok, msg
    if g.server then ok, msg = g.server(src, t, p, g) else
        local d = g.data(src, t, p, g)
        TriggerClientEvent('pb:g:gx', t, PB.Json(d))
        ok, msg = true, g.label .. ' : envoyé à ' .. S.RpName(t) .. '.'
    end
    if ok then
        PB.Audit.Log('staff', 'gesture.' .. g.id, src, S.RpName(t) .. ' #' .. t, nil, nil, { text = g.label, duration = p.duration, model = p.model, url = g.id == 'media' and p.url or nil, panel = panel or nil })
    end
    return ok and true or false, msg
end
AddEventHandler('playerDropped', function() lastAt[source] = nil Ge.last[source] = nil end)

-- Branchement sur les actions du menu staff
for _, g in ipairs(LIST) do
    S.ACT[g.actId] = { perm = g.perm, target = true, rank = true, inputs = g.inputs, quiet = true, run = function(src, t, p) return Ge.Run(src, g.id, t, p, false) end }
end

-- Description du menu pour un staff : seulement ce qu'il a le droit de faire
function Ge.Menu(src)
    local out = {}
    for _, th in ipairs(Ge.THEMES) do
        local items = {}
        for _, g in ipairs(LIST) do
            if g.theme == th.id and P.Has(src, g.perm) then
                items[#items + 1] = { id = g.actId, label = g.label, desc = g.desc, inputs = g.inputs }
            end
        end
        if #items > 0 then out[#out + 1] = { id = th.id, label = th.label, items = items } end
    end
    return out
end
function Ge.List() return LIST end

-- Panel : Joueurs › Gestes ---------------------------------------------------------------------------------------------------------------
PB.Action('players.gesture', 'staff.gestures', function(ctx, p)
    local ok, msg = Ge.Run(ctx.src, p.gesture, p.id, { duration = p.duration, text = p.text, model = p.text, url = p.text }, true)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
function Ge.PanelOptions(src)
    local out = {}
    for _, th in ipairs(Ge.THEMES) do
        for _, g in ipairs(LIST) do
            if g.theme == th.id and P.Has(src, g.perm) then out[#out + 1] = { g.id, th.label .. ' · ' .. g.label } end
        end
    end
    return out
end

local Form = PB.Form
G.GesturesForm = Form.Cfg({ ns = 'gestures', id = 'settings', title = 'Réglages des gestes', perm = 'staff.edit', cols = 2, fields = {
    { k = 'media_hosts', type = 'list', label = 'Hôtes de médias autorisés (ex. i.imgur.com)', default = {}, maxitems = 20, maxlen = 80, pattern = '^[%w%.%-]+$', wide = true,
      hint = "Les images, sons et vidéos envoyés à un joueur doivent venir d'un de ces hôtes (https). Vide : l'envoi d'un média est désactivé." },
    { k = 'max_seconds', type = 'number', label = 'Durée maximale d\'un effet (secondes)', default = 120, min = 10, max = 300 },
    { k = 'cooldown_ms', type = 'number', label = 'Délai entre deux gestes d\'un même staff (ms)', default = 700, min = 200, max = 5000 },
    { k = 'screen_max', type = 'number', label = 'Durée maximale du direct (secondes)', default = 90, min = 10, max = 600 },
    { k = 'screen_interval', type = 'number', label = 'Intervalle entre deux images du direct (ms)', default = 2500, min = 1000, max = 10000 },
    { k = 'screen_notify', type = 'toggle', label = 'Prévenir le joueur qu\'on consulte son écran', default = false, hint = 'Chaque consultation est de toute façon journalisée.' },
} })

PB.SelfTest.Add('gestes', function(R)
    local seen = {}
    for _, g in ipairs(LIST) do
        R.check(not seen[g.id], 'geste ' .. g.id, 'identifiant en double')
        seen[g.id] = true
        R.check(g.server ~= nil or type(g.data) == 'function', 'geste ' .. g.id, 'aucun effet défini')
        R.check(P.Has ~= nil and g.perm ~= nil, 'geste ' .. g.id, 'droit manquant')
    end
    R.check(#LIST >= 50, 'gestes', 'moins de 50 gestes : ' .. #LIST)
end)
