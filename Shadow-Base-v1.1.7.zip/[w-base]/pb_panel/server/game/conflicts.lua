-- Scripts en doublon (ESX et autres) : détecte ceux qui tournent et peut les arrêter tout seul.
-- pb_panel fournit lui-même personnage, HUD, inventaire, boutiques, garages, banque, chat et métiers de base ; ces scripts feraient doublon.
-- Un arrêt au démarrage est temporaire : pour qu'ils ne reviennent pas, retire leur ligne « ensure » de server.cfg (le panel te donne les lignes).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G = PB.G
local Cf = {}
G.Conflicts = Cf

P.Register('conflicts.edit', 'Modifier la liste des scripts en doublon et les arrêter', 'conflicts', true)

local LIST = {
    { res = 'esx_multicharacter', covers = 'Création / choix du personnage' }, { res = 'esx_identity', covers = 'Identité du personnage' }, { res = 'esx_skin', covers = 'Apparence' }, { res = 'skinchanger', covers = 'Apparence' },
    { res = 'esx_status', covers = 'Faim / soif' }, { res = 'esx_basicneeds', covers = 'Faim / soif' }, { res = 'esx_hud', covers = 'HUD' }, { res = 'esx_inventoryhud', covers = 'Inventaire' },
    { res = 'ox_inventory', covers = 'Inventaire' }, { res = 'esx_addoninventory', covers = 'Inventaire des entreprises' },
    { res = 'esx_vehicleshop', covers = 'Concession' }, { res = 'esx_advancedgarage', covers = 'Garages' }, { res = 'esx_garage', covers = 'Garages' }, { res = 'esx_atm', covers = 'Distributeurs' }, { res = 'esx_shops', covers = 'Supérettes' },
    { res = 'esx_clotheshop', covers = 'Magasin de vêtements' }, { res = 'esx_menu_default', covers = 'Menus' }, { res = 'esx_menu_dialog', covers = 'Menus' }, { res = 'esx_menu_list', covers = 'Menus' }, { res = 'esx_context', covers = 'Menus' },
    { res = 'esx_notify', covers = 'Notifications' }, { res = 'esx_phone', covers = 'Téléphone' }, { res = 'esx_billing', covers = 'Factures' },
    { res = 'esx_policejob', covers = 'Métier police' }, { res = 'esx_ambulancejob', covers = 'Métier secours' }, { res = 'esx_mechanicjob', covers = 'Métier mécanicien' },
    { res = 'esx_society', covers = 'Entreprises' }, { res = 'esx_jobs', covers = 'Métiers' }, { res = 'esx_property', covers = 'Logements' }, { res = 'esx_realestateagentjob', covers = 'Logements' },
    { res = 'chat', covers = 'Chat de base de FiveM' },
}
PB.Cfg.Define('conflicts', { auto_stop = true, keep = {}, extra = {} })
local function cfg(k, d) return PB.Cfg.Get('conflicts', k, d) end
local function clean(s) return tostring(s or ''):gsub('[^A-Za-z0-9_%-]', ''):sub(1, 48) end

function Cf.List()
    local keep, out, seen = {}, {}, {}
    for _, k in ipairs(cfg('keep', {}) or {}) do keep[clean(k)] = true end
    for _, e in ipairs(LIST) do if not keep[e.res] and not seen[e.res] then seen[e.res] = true out[#out + 1] = e end end
    for _, r in ipairs(cfg('extra', {}) or {}) do
        local n = clean(r)
        if n ~= '' and n ~= 'pb_panel' and n ~= 'oxmysql' and n ~= 'es_extended' and not keep[n] and not seen[n] then seen[n] = true out[#out + 1] = { res = n, covers = 'Ajouté par toi' } end
    end
    return out
end
local function state(n) local ok, s = pcall(GetResourceState, n) return ok and s or 'missing' end
local function live(n) local s = state(n) return s == 'started' or s == 'starting' end
function Cf.Running()
    local out = {}
    for _, e in ipairs(Cf.List()) do if live(e.res) then out[#out + 1] = e end end
    return out
end
function Cf.Stop(name, who)
    name = clean(name)
    if name == '' or name == 'pb_panel' or name == 'oxmysql' or name == 'es_extended' or not live(name) then return false end
    local ok = pcall(StopResource, name)
    if ok then PB.Audit.Log('serveur', 'conflicts.stop', who or 0, name, nil, nil, nil) end
    return ok
end
function Cf.StopAll(who)
    local n = 0
    for _, e in ipairs(Cf.Running()) do if Cf.Stop(e.res, who) then n = n + 1 end end
    return n
end

-- Arrêt automatique : au démarrage (deux passes, certains scripts démarrent après nous) et quand l'un d'eux démarre plus tard
CreateThread(function()
    Wait(4000)
    if cfg('auto_stop', true) then local n = Cf.StopAll(0) if n > 0 then print(('^3[pb_panel]^7 %d script(s) en doublon arrêté(s). Retire-les de server.cfg (panel : Scripts en doublon).'):format(n)) end end
    Wait(20000)
    if cfg('auto_stop', true) then Cf.StopAll(0) end
end)
AddEventHandler('onResourceStart', function(res)
    if not cfg('auto_stop', true) then return end
    for _, e in ipairs(Cf.List()) do
        if e.res == res then SetTimeout(500, function() if cfg('auto_stop', true) then Cf.Stop(res, 0) end end) end
    end
end)

PB.Action('conflicts.stop', 'conflicts.edit', function(ctx, p) if Cf.Stop(p.res, ctx.src) then ctx.toast = 'Arrêté : ' .. clean(p.res) return true end return false, "Impossible d'arrêter cette ressource." end)
PB.Action('conflicts.stopall', 'conflicts.edit', function(ctx) local n = Cf.StopAll(ctx.src) ctx.toast = n .. ' script(s) arrêté(s).' return true end)

local settings = Form.Cfg({ ns = 'conflicts', id = 'settings', title = 'Scripts en doublon', perm = 'conflicts.edit', fields = {
    { k = 'auto_stop', type = 'toggle', label = 'Arrêter automatiquement ces scripts', default = true, hint = "Fait au démarrage du serveur et dès qu'un de ces scripts démarre. Ne touche jamais à pb_panel, oxmysql ni es_extended." },
    { k = 'keep', type = 'list', label = 'Scripts à garder malgré tout (noms de ressources)', default = {}, maxitems = 60, maxlen = 48, pattern = '^[%w_%-]+$', wide = true, hint = "Exemple : garde esx_policejob si tu veux ce métier-là plutôt que celui de pb_panel." },
    { k = 'extra', type = 'list', label = 'Autres scripts à arrêter (noms de ressources)', default = {}, maxitems = 60, maxlen = 48, pattern = '^[%w_%-]+$', wide = true },
} })

PB.Module({
    id = 'conflicts', label = 'Scripts en doublon', icon = 'shield', group = 'Serveur', order = 147, perm = 'conflicts.edit', hint = 'ESX et autres : détection et arrêt',
    caps = function() return PB.Capsify({
        { 'Détection', 'ok', "Liste de scripts ESX courants (personnage, HUD, inventaire, garages, boutiques, métiers…) et les tiens." },
        { 'Arrêt automatique', 'ok', "Au démarrage et quand l'un d'eux démarre, sauf ceux que tu choisis de garder." },
        { 'Arrêt définitif', 'off', "Un arrêt est temporaire : retire leur ligne « ensure » de server.cfg (les lignes sont affichées dans l'onglet Détectés)." },
        { 'Scripts qui en dépendent', 'off', "Un script ESX tiers qui a besoin d'un script arrêté peut afficher des erreurs : garde-le dans la liste « à garder »." },
    }) end,
    doc = "## Scripts en doublon\npb_panel fournit lui-même le personnage, le HUD, l'inventaire, les boutiques, les garages, la banque, le chat et les métiers de base. Les scripts ESX équivalents feraient doublon. Ce module les détecte et peut les arrêter tout seul.",
    view = function(ctx) return { tabs = {
        { id = 'running', label = 'Détectés', icon = 'alert', build = function()
            local rows, cfgLines = {}, {}
            for _, e in ipairs(Cf.Running()) do
                rows[#rows + 1] = { res = e.res, covers = e.covers, actions = ctx.has('conflicts.edit') and { { action = 'conflicts.stop', label = 'Arrêter', payload = { res = e.res }, danger = true } } or nil }
                cfgLines[#cfgLines + 1] = 'ensure ' .. e.res
            end
            local blocks = { B.table({ id = 'cf', title = 'Scripts en doublon qui tournent', columns = { { k = 'res', label = 'Ressource', type = 'mono' }, { k = 'covers', label = 'Remplacé par pb_panel' } }, rows = rows, empty = 'Aucun script en doublon ne tourne.' }) }
            if #rows > 0 then
                if ctx.has('conflicts.edit') then blocks[#blocks + 1] = B.actions({ { action = 'conflicts.stopall', label = 'Tout arrêter maintenant', icon = 'power', danger = true } }) end
                blocks[#blocks + 1] = B.notice('info', "Pour qu'ils ne reviennent pas au prochain démarrage, supprime ces lignes de server.cfg : " .. table.concat(cfgLines, ' · '))
            end
            return blocks
        end },
        { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
        { id = 'list', label = 'Liste surveillée', icon = 'book', build = function()
            local rows = {}
            for _, e in ipairs(Cf.List()) do rows[#rows + 1] = { res = e.res, covers = e.covers, st = state(e.res) } end
            return { B.table({ id = 'cl', title = 'Scripts surveillés (' .. #rows .. ')', search = true, columns = { { k = 'res', label = 'Ressource', type = 'mono' }, { k = 'covers', label = 'Remplacé par pb_panel' }, { k = 'st', label = 'État', type = 'badge' } }, rows = rows }) }
        end },
    } } end,
})
PB.SelfTest.Add('scripts en doublon', function(R)
    local list = Cf.Running()
    if cfg('auto_stop', true) then return end
    for _, e in ipairs(list) do R.check(false, 'script en doublon « ' .. e.res .. ' »', e.covers .. ' : pb_panel le gère déjà. Arrête-le ou active l\'arrêt automatique.') end
end)
