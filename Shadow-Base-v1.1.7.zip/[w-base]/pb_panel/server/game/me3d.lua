-- Texte au-dessus de la tête : chaque action (inventaire, menu ALT, véhicule) s'écrit toute seule au-dessus du personnage,
-- visible des joueurs proches (comme « ** Déverrouille le véhicule ** »). Le serveur décide du texte et des destinataires.

local Form = PB.Form
local G = PB.G

PB.Cfg.Define('me3d', { enabled = true, duration = 6, range = 25, auto_inv = true, auto_ctx = true, color = '#7fd8ff' })
local function cfg(k, d) return PB.Cfg.Get('me3d', k, d) end

local last = {}
local function nowMs() return GetGameTimer and GetGameTimer() or os.time() * 1000 end

-- Envoie `text` au-dessus de la tête de `src` à tous les joueurs proches (lui compris).
function G.Me(src, text)
    if not cfg('enabled', true) or not src or tonumber(src) == nil then return false end
    text = PB.Trim(PB.Sanitize(tostring(text or ''), 120))
    if text == '' then return false end
    local t = nowMs()
    if last[src] and t - last[src] < 400 then return false end
    last[src] = t
    local msg = PB.Json({ i = src, t = text, ms = math.floor(PB.Clamp and PB.Clamp(cfg('duration', 6), 2, 20) * 1000 or 6000) })
    local range = tonumber(cfg('range', 25)) or 25
    local sent = 0
    for _, pid in ipairs(GetPlayers()) do
        local id = tonumber(pid)
        if id == src or not G.DistBetween or G.DistBetween(src, id) <= range then TriggerClientEvent('pb:g:me3d', id, msg) sent = sent + 1 end
    end
    return sent > 0
end
exports('Me', function(src, text) return G.Me(src, text) end)
AddEventHandler('playerDropped', function() last[source] = nil end)

local function container(o)
    o = tostring(o or '')
    local k = o:sub(1, 2)
    if k == 'v:' then return 'le véhicule' elseif k == 'd:' then return 'le sol' elseif k == 'p:' then return 'son sac' end
    return 'le stockage'
end
local function label(item)
    local d = G.Inv and G.Inv.Def and G.Inv.Def(item)
    return d and d.label or tostring(item)
end

AddEventHandler('pb_panel:itemMoved', function(src, item, qty, fromO, toO)
    if not cfg('auto_inv', true) then return end
    if tostring(toO):sub(1, 2) == 'p:' then G.Me(src, ("récupère %d × %s dans %s"):format(qty, label(item), container(fromO)))
    else G.Me(src, ("met %d × %s dans %s"):format(qty, label(item), container(toO))) end
end)
AddEventHandler('pb_panel:itemUsed', function(src, item) if cfg('auto_inv', true) then G.Me(src, 'utilise ' .. label(item)) end end)
AddEventHandler('pb_panel:itemDropped', function(src, item, qty) if cfg('auto_inv', true) then G.Me(src, ("jette %d × %s"):format(qty, label(item))) end end)
AddEventHandler('pb_panel:itemGiven', function(src, to, item, qty) if cfg('auto_inv', true) then G.Me(src, ("donne %d × %s"):format(qty, label(item))) end end)

local form = Form.Cfg({ ns = 'me3d', id = 'look', title = 'Texte au-dessus de la tête', perm = 'uikit.edit', cols = 2,
    desc = "Chaque action (déplacer un objet, l'utiliser, le jeter, verrouiller un véhicule…) s'affiche toute seule au-dessus du personnage, pour les joueurs proches.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Texte automatique actif', default = true },
        { k = 'auto_inv', type = 'toggle', label = "Actions de l'inventaire", default = true },
        { k = 'auto_ctx', type = 'toggle', label = 'Actions du menu ALT et des véhicules', default = true },
        { k = 'duration', type = 'number', label = 'Durée (secondes)', default = 6, min = 2, max = 20 },
        { k = 'range', type = 'number', label = 'Visible jusqu\'à (m)', default = 25, min = 5, max = 80 },
        { k = 'color', type = 'color', label = 'Couleur du texte', default = '#7fd8ff' },
    } })
G.Me3DForm = form

PB.SelfTest.Add('texte 3D', function(R)
    R.check(type(G.Me) == 'function', 'texte 3D', 'G.Me absent')
end)
