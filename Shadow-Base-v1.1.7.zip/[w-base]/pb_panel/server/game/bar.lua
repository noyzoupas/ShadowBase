-- Service au bar : le barman (employé en service d'un bar, d'une discothèque, d'un café, d'un restaurant…) prépare au point « cuisine / bar »
-- les produits de la carte de son entreprise, puis les SERT à un client avec ALT sur lui. Le client voit la commande et son prix, accepte
-- ou refuse ; s'il accepte, il paie, reçoit le produit, et la caisse de l'entreprise encaisse. Le serveur vérifie tout (service, distance,
-- stock du barman, argent du client, délai de l'offre).
local P, DB, G = PB.Perm, PB.DB, PB.G
local Place = PB.Place

PB.Cfg.Define('bar', { enabled = true, prep_cost_pct = 30, prep_secs = 4, max_batch = 10, offer_secs = 30, serve_dist = 3.5 })
local Bar = {}
G.Bar = Bar
local function cfg(k, d) return PB.Cfg.Get('bar', k, d) end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function dist(a, b) return G.DistBetween and G.DistBetween(a, b) or 99999 end
local function acct(id) return 'biz:' .. id end

-- Carte de l'entreprise : celle de son comptoir (modifiable par le patron), sinon la carte type du catalogue
function Bar.Catalog(b)
    if not b then return {} end
    local r = DB.one("SELECT catalog FROM pb_shops WHERE kind = 'store' AND opts LIKE ? ORDER BY id LIMIT 1", { '%"biz_counter":"' .. b.id .. '"%' })
    local list = r and PB.FromJson(r.catalog, nil)
    if type(list) ~= 'table' or #list == 0 then list = Place.CatalogFor and Place.CatalogFor(b) or {} end
    local out = {}
    for _, a in ipairs(list or {}) do if type(a) == 'table' and tostring(a.name or ''):match('^[%w_]+$') then out[#out + 1] = a end end
    return out
end
-- Le joueur peut-il servir ? (en service dans une entreprise qui a une carte)
function Bar.Ctx(src)
    if cfg('enabled', true) == false then return nil end
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or not c.duty then return nil end
    local cat = Bar.Catalog(c.biz)
    if #cat == 0 then return nil end
    local by = {}
    for _, a in ipairs(cat) do by[a.name] = a end
    return { biz = c.biz, cat = cat, by = by }
end
function Bar.CanServe(src) return Bar.Ctx(src) ~= nil end

local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function owner(src) return G.Inv and G.Inv.PlayerOwner(src) end

-- Préparation au bar ------------------------------------------------------------------------------------------------------------------------
local atBar = {}     -- src -> point de bar ouvert { id, x, y, z, biz }
local prepping = {}  -- src -> { name, n, done = os.time() de fin }
function Bar.Open(src, p)
    local x = Bar.Ctx(src)
    if not x or x.biz.id ~= p.owner then G.Notify(src, { type = 'warn', title = p.label, text = 'Prends ton service.' }) return end
    atBar[src] = { id = p.id, x = p.x, y = p.y, z = p.z, biz = p.owner }
    local items = {}
    local pct = tonumber(cfg('prep_cost_pct', 30)) or 30
    for _, a in ipairs(x.cat) do items[#items + 1] = { name = a.name, label = a.label or a.name, price = tonumber(a.price) or 0, cost = math.ceil((tonumber(a.price) or 0) * pct / 100) } end
    TriggerClientEvent('pb:g:bar:menu', src, PB.Json({ mode = 'prep', label = p.label, biz = x.biz.label, items = items, secs = tonumber(cfg('prep_secs', 4)) or 4, max = tonumber(cfg('max_batch', 10)) or 10,
        recipes = GetResourceState('wb_activites') == 'started', balance = G.Eco and G.Eco.Balance(acct(x.biz.id)) or 0 }))
end
local function nearBar(src)
    local b = atBar[src]
    if not b then return nil end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c then return nil end
    local dx, dy, dz = c.x - b.x, c.y - b.y, c.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz) <= 4.5 and b or nil
end
function Bar.Prep(src, name, n)
    local x = Bar.Ctx(src)
    local b = nearBar(src)
    if not x or not b or b.biz ~= x.biz.id then return false, 'Retourne au bar (en service).' end
    if prepping[src] then return false, 'Tu prépares déjà quelque chose.' end
    local a = x.by[tostring(name)]
    if not a then return false, "Ce produit n'est pas à la carte." end
    n = math.max(1, math.min(tonumber(cfg('max_batch', 10)) or 10, math.floor(tonumber(n) or 1)))
    if not G.Inv.Ensure(a) then return false, 'Produit invalide.' end
    local ok, why = G.Inv.CanCarry(owner(src), a.name, n)
    if not ok then return false, why end
    local cost = math.ceil((tonumber(a.price) or 0) * (tonumber(cfg('prep_cost_pct', 30)) or 30) / 100) * n
    if cost > 0 then
        if (G.Eco.Balance(acct(x.biz.id)) or 0) < cost then return false, ('La caisse de l\'entreprise ne peut pas payer les ingrédients (%s).'):format(money(cost)) end
        G.Eco.Book(acct(x.biz.id), -cost, 'Ingrédients du bar : ' .. n .. ' × ' .. (a.label or a.name), G.Get(src).license)
    end
    local secs = (tonumber(cfg('prep_secs', 4)) or 4) * n
    prepping[src] = { name = a.name, label = a.label or a.name, n = n, done = now() + secs, biz = x.biz.id }
    TriggerClientEvent('pb:g:bar:progress', src, PB.Json({ label = 'Préparation : ' .. n .. ' × ' .. (a.label or a.name), secs = secs }))
    return true, nil, secs
end
-- fin de préparation (le client la signale à la fin de la barre ; le serveur vérifie la durée et la présence au bar)
function Bar.PrepDone(src)
    local pr = prepping[src]
    if not pr then return false end
    if now() < pr.done - 1 then return false, 'Trop rapide.' end
    prepping[src] = nil
    local b = nearBar(src)
    if not b or b.biz ~= pr.biz then return false, "Tu as quitté le bar : préparation perdue." end
    local ok = G.Inv.Add(owner(src), pr.name, pr.n)
    if not ok then return false, 'Ton sac est plein.' end
    if G.Inv.Push then pcall(G.Inv.Push, src) end
    return true, ('%d × %s prêt(s) : sers-les avec ALT sur un client.'):format(pr.n, pr.label)
end

-- Service à un client --------------------------------------------------------------------------------------------------------------------------
local offers = {}   -- client -> { from, name, label, qty, price, at, biz }
function Bar.ServeMenu(src, t)
    local x = Bar.Ctx(src)
    if not x then return false, "Tu dois être en service dans un bar, un café ou un restaurant." end
    local o = owner(src)
    local items = {}
    for _, a in ipairs(x.cat) do
        local have = G.Inv.Count(o, a.name)
        if have > 0 then items[#items + 1] = { name = a.name, label = a.label or a.name, price = tonumber(a.price) or 0, have = have } end
    end
    if #items == 0 then return false, "Tu n'as rien de la carte sur toi : prépare d'abord au bar." end
    TriggerClientEvent('pb:g:bar:menu', src, PB.Json({ mode = 'serve', target = t, targetName = display(t), items = items, biz = x.biz.label }))
    return true
end
function Bar.Offer(src, t, name, qty)
    t = tonumber(t)
    local x = Bar.Ctx(src)
    if not x or not t or t == src or not G.Get(t) or not usable(t) then return false, 'Client indisponible.' end
    if dist(src, t) > (tonumber(cfg('serve_dist', 3.5)) or 3.5) + 1 then return false, 'Le client est trop loin.' end
    local a = x.by[tostring(name)]
    if not a then return false, "Ce produit n'est pas à la carte." end
    qty = math.max(1, math.min(20, math.floor(tonumber(qty) or 1)))
    if G.Inv.Count(owner(src), a.name) < qty then return false, "Tu n'en as pas assez sur toi." end
    local cur = offers[t]
    if cur and now() - cur.at < (tonumber(cfg('offer_secs', 30)) or 30) and cur.from ~= src then return false, 'Ce client a déjà une commande en attente.' end
    local price = (tonumber(a.price) or 0) * qty
    offers[t] = { from = src, name = a.name, label = a.label or a.name, qty = qty, price = price, at = now(), biz = x.biz.id, bizLabel = x.biz.label }
    TriggerClientEvent('pb:g:bar:offer', t, PB.Json({ from = display(src), biz = x.biz.label, label = a.label or a.name, qty = qty, price = price, secs = tonumber(cfg('offer_secs', 30)) or 30 }))
    return true, ('Commande proposée à %s : %d × %s pour %s.'):format(display(t), qty, a.label or a.name, money(price))
end
function Bar.Answer(t, accept)
    local o = offers[t]
    offers[t] = nil
    if not o then return false, 'Aucune commande en attente.' end
    local src = o.from
    if now() - o.at > (tonumber(cfg('offer_secs', 30)) or 30) then G.Notify(t, { type = 'warn', title = 'Commande', text = 'Commande expirée.' }) return false end
    if not accept then
        G.Notify(src, { type = 'warn', title = 'Commande refusée', text = display(t) .. ' a refusé ' .. o.qty .. ' × ' .. o.label .. '.' })
        return true
    end
    local x = Bar.Ctx(src)
    if not x or x.biz.id ~= o.biz or not G.Get(src) then G.Notify(t, { type = 'error', title = 'Commande', text = "Le barman n'est plus en service." }) return false end
    if dist(src, t) > (tonumber(cfg('serve_dist', 3.5)) or 3.5) + 2 then G.Notify(t, { type = 'error', title = 'Commande', text = 'Le barman est trop loin.' }) return false end
    if G.Inv.Count(owner(src), o.name) < o.qty then G.Notify(t, { type = 'error', title = 'Commande', text = "Le barman n'a plus ce produit." }) G.Notify(src, { type = 'error', text = "Tu n'as plus " .. o.label .. '.' }) return false end
    local ok, why = G.Inv.CanCarry(owner(t), o.name, o.qty)
    if not ok then G.Notify(t, { type = 'error', title = 'Commande', text = why }) G.Notify(src, { type = 'warn', text = display(t) .. ' ne peut pas porter la commande.' }) return false end
    if o.price > 0 and not G.Pay(t, o.price, 'cash') then
        G.Notify(t, { type = 'error', title = 'Commande', text = "Tu n'as pas assez d'argent (" .. money(o.price) .. ').' })
        G.Notify(src, { type = 'warn', title = 'Commande', text = display(t) .. " n'a pas de quoi payer." })
        return false
    end
    G.Inv.Remove(owner(src), o.name, o.qty)
    G.Inv.Add(owner(t), o.name, o.qty)
    if G.Inv.Push then pcall(G.Inv.Push, src) pcall(G.Inv.Push, t) end
    if o.price > 0 then G.Eco.Book(acct(o.biz), o.price, 'Vente au bar : ' .. o.qty .. ' × ' .. o.label, G.Get(src).license) end
    PB.Audit.Log('economie', 'bar.sale', display(src), display(t), nil, nil, { biz = o.biz, item = o.name, qty = o.qty, price = o.price })
    TriggerEvent('pb_panel:barSold', src, t, o.biz, o.name, o.qty, o.price)
    G.Notify(t, { type = 'success', title = o.bizLabel, text = ('Servi : %d × %s (%s). Bonne dégustation !'):format(o.qty, o.label, money(o.price)) })
    G.Notify(src, { type = 'success', title = 'Commande servie', text = ('%d × %s à %s : %s encaissés pour %s.'):format(o.qty, o.label, display(t), money(o.price), o.bizLabel) })
    return true
end

-- Évènements -----------------------------------------------------------------------------------------------------------------------------------
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
RegisterNetEvent('pb:g:bar:prep', function(name, n)
    local src = source
    if not throttle(src, 500) or not usable(src) then return end
    local ok, why = Bar.Prep(src, name, n)
    if not ok then G.Notify(src, { type = 'error', title = 'Bar', text = why }) end
end)
RegisterNetEvent('pb:g:bar:prepDone', function()
    local src = source
    local ok, msg = Bar.PrepDone(src)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Bar', text = msg }) end
end)
RegisterNetEvent('pb:g:bar:prepCancel', function() prepping[source] = nil end)
RegisterNetEvent('pb:g:bar:recipes', function()
    local src = source
    local b = nearBar(src)
    local x = Bar.Ctx(src)
    if not b or not x or GetResourceState('wb_activites') ~= 'started' then return end
    TriggerEvent('pb_panel:bizCraft', src, b.biz, x.biz.category or '', b.id, b.x, b.y, b.z, 'Recettes')
end)
RegisterNetEvent('pb:g:bar:offer', function(t, name, qty)
    local src = source
    if not throttle(src, 600) or not usable(src) then return end
    local ok, msg = Bar.Offer(src, t, name, qty)
    G.Notify(src, { type = ok and 'info' or 'error', title = 'Bar', text = msg })
end)
RegisterNetEvent('pb:g:bar:answer', function(accept)
    local src = source
    if not throttle(src, 400) then return end
    Bar.Answer(src, accept == true)
end)
AddEventHandler('playerDropped', function() local s = source atBar[s] = nil prepping[s] = nil offers[s] = nil last[s] = nil end)

local form = PB.Form.Cfg({ ns = 'bar', id = 'settings', title = 'Service au bar', perm = 'biz.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Service au bar (préparer puis servir un client avec ALT)', default = true },
    { k = 'prep_cost_pct', type = 'number', label = 'Coût des ingrédients payé par la caisse (% du prix de vente)', default = 30, min = 0, max = 100 },
    { k = 'prep_secs', type = 'number', label = 'Temps de préparation par produit (secondes)', default = 4, min = 1, max = 60 },
    { k = 'max_batch', type = 'number', label = 'Produits préparés en une fois (maximum)', default = 10, min = 1, max = 50 },
    { k = 'offer_secs', type = 'number', label = 'Le client a (secondes) pour accepter', default = 30, min = 10, max = 120 },
} })
Bar.Form = form
if G.Biz and G.Biz.ExtraSettings then table.insert(G.Biz.ExtraSettings, form) end
