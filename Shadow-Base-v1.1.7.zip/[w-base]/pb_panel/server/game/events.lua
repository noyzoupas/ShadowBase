-- Planificateur d'événements : annonce, météo, bonus de paie pendant une durée, à une date et une heure (heure du serveur).
-- Panel › Événements. Un événement peut se répéter chaque jour ou chaque semaine.

local G, DB, P, B = PB.G, PB.DB, PB.Perm, PB.B
local Ev = {}
G.Events = Ev

P.Register('events.edit', 'Planifier des événements (annonce, météo, bonus de paie)', 'game', true)
PB.Migrate('217_events', 'Planificateur d\'événements', {
    [[CREATE TABLE IF NOT EXISTS pb_events (id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, kind VARCHAR(12) NOT NULL, label VARCHAR(80) NOT NULL DEFAULT '',
        data TEXT NOT NULL, repeat_mode VARCHAR(8) NOT NULL DEFAULT 'none', done TINYINT(1) NOT NULL DEFAULT 0, by_name VARCHAR(64) NOT NULL DEFAULT '', PRIMARY KEY (id), KEY k_at (at))]],
})

local KIND = { announce = 'Annonce', weather = 'Météo', paybonus = 'Bonus de paie' }
local REPEAT = { none = 0, day = 86400, week = 7 * 86400 }
local function now() return os.time() end

-- Bonus de paie en cours (lu par la paie des entreprises)
G.PayBonus = nil   -- { mult, untilAt, label }
function G.PayMult() local b = G.PayBonus if b and b.untilAt > now() then return b.mult end return 1 end

local function run(e)
    local d = PB.FromJson(e.data, {}) or {}
    if e.kind == 'announce' then
        PB.Announce(tostring(d.text or e.label), 'both')
    elseif e.kind == 'weather' then
        if PB.World and PB.World.SetWeather then PB.World.SetWeather(tostring(d.weather or 'EXTRASUNNY'), 'Événement') end
    elseif e.kind == 'paybonus' then
        local mult = math.max(1, math.min(5, tonumber(d.mult) or 2))
        local mins = math.max(5, math.min(720, math.floor(tonumber(d.minutes) or 60)))
        G.PayBonus = { mult = mult, untilAt = now() + mins * 60, label = e.label }
        PB.Announce(('%s : la paie est multipliée par %s pendant %d minutes !'):format(e.label ~= '' and e.label or 'Événement', tostring(mult), mins), 'both')
    end
    PB.Audit.Log('serveur', 'events.run', 'système', e.label, nil, { kind = e.kind })
    local step = REPEAT[e.repeat_mode] or 0
    if step > 0 then
        local nextAt = e.at
        while nextAt <= now() do nextAt = nextAt + step end
        DB.exec('UPDATE pb_events SET at = ? WHERE id = ?', { nextAt, e.id })
    else
        DB.exec('UPDATE pb_events SET done = 1 WHERE id = ?', { e.id })
    end
end
CreateThread(function()
    while true do
        Wait(30000)
        if PB.IsReady then
            for _, e in ipairs(DB.q('SELECT * FROM pb_events WHERE done = 0 AND at <= ?', { now() }) or {}) do pcall(run, e) end
        end
    end
end)

-- « 24/12 20:30 » (année en cours, ou suivante si la date est passée) ou « 2026-12-24 20:30 »
local function parseWhen(s)
    s = tostring(s or '')
    local Y, M, D, h, m = s:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)%s+(%d%d?):(%d%d)$')
    if not Y then D, M, h, m = s:match('^(%d%d?)/(%d%d?)%s+(%d%d?):(%d%d)$') Y = os.date('%Y') end
    if not D then return nil end
    local t = os.time({ year = tonumber(Y), month = tonumber(M), day = tonumber(D), hour = tonumber(h), min = tonumber(m), sec = 0 })
    if t and t < now() - 60 and not s:match('^%d%d%d%d') then t = os.time({ year = tonumber(Y) + 1, month = tonumber(M), day = tonumber(D), hour = tonumber(h), min = tonumber(m), sec = 0 }) end
    return t
end

PB.Action('events.add', 'events.edit', function(ctx, p)
    local v = p.values or p
    local kind = tostring(v.kind or '')
    if not KIND[kind] then return false, 'Type inconnu.' end
    local at = parseWhen(v.when)
    if not at then return false, 'Date invalide : écris « JJ/MM HH:MM » (ex. 24/12 20:30).' end
    local label = PB.Trim(PB.Sanitize(tostring(v.label or ''), 80))
    local data = {}
    if kind == 'announce' then
        data.text = PB.Trim(PB.Sanitize(tostring(v.text or ''), 300))
        if #data.text < 3 then return false, "Écris le texte de l'annonce." end
    elseif kind == 'weather' then
        data.weather = tostring(v.weather or 'EXTRASUNNY'):upper()
    elseif kind == 'paybonus' then
        data.mult = math.max(1, math.min(5, tonumber(v.mult) or 2))
        data.minutes = math.max(5, math.min(720, math.floor(tonumber(v.minutes) or 60)))
    end
    local rep = REPEAT[tostring(v.repeat_mode or 'none')] and tostring(v.repeat_mode) or 'none'
    DB.insert('INSERT INTO pb_events (at, kind, label, data, repeat_mode, done, by_name) VALUES (?, ?, ?, ?, ?, 0, ?)', { at, kind, label ~= '' and label or KIND[kind], PB.Json(data), rep, tostring(ctx.actor or ''):sub(1, 64) })
    ctx.audit('config', 'events.add', label, nil, { kind = kind, at = at })
    ctx.toast = ('Événement planifié le %s.'):format(os.date('%d/%m/%Y à %H:%M', at))
    return true
end)
PB.Action('events.delete', 'events.edit', function(ctx, p)
    DB.exec('DELETE FROM pb_events WHERE id = ?', { tonumber(p.id) or -1 })
    ctx.toast = 'Événement supprimé.'
    return true
end)
PB.Action('events.now', 'events.edit', function(ctx, p)
    local e = DB.one('SELECT * FROM pb_events WHERE id = ?', { tonumber(p.id) or -1 })
    if not e then return false, 'Événement introuvable.' end
    run(e)
    ctx.toast = 'Événement lancé.'
    return true
end)

PB.Module({
    id = 'events', label = 'Événements', icon = 'clock', group = 'Serveur', order = 138, perm = 'events.edit', hint = 'Annonces, météo et bonus de paie programmés',
    doc = "## Événements\nProgramme une **annonce**, un **changement de météo** ou un **bonus de paie** (×2 pendant une heure, par exemple) à une date et une heure (heure du serveur). Un événement peut se répéter chaque jour ou chaque semaine.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Programmés', icon = 'clock', build = function()
                local rows = {}
                for _, e in ipairs(DB.q('SELECT * FROM pb_events WHERE done = 0 ORDER BY at') or {}) do
                    rows[#rows + 1] = { when = os.date('%d/%m/%Y %H:%M', e.at), kind = KIND[e.kind] or e.kind, label = e.label, rep = ({ none = 'Une fois', day = 'Chaque jour', week = 'Chaque semaine' })[e.repeat_mode] or e.repeat_mode,
                        actions = { { action = 'events.now', label = 'Lancer maintenant', icon = 'play', payload = { id = e.id } }, { action = 'events.delete', label = 'Supprimer', icon = 'x', danger = true, payload = { id = e.id } } } }
                end
                local blocks = {}
                if G.PayBonus and G.PayBonus.untilAt > now() then blocks[#blocks + 1] = B.notice('info', ('Bonus de paie en cours : ×%s jusqu\'à %s.'):format(tostring(G.PayBonus.mult), os.date('%H:%M', G.PayBonus.untilAt))) end
                blocks[#blocks + 1] = B.table({ id = 'evl', title = 'Événements à venir', columns = { { k = 'when', label = 'Date' }, { k = 'kind', label = 'Type' }, { k = 'label', label = 'Nom' }, { k = 'rep', label = 'Répétition' } }, rows = rows, empty = 'Aucun événement programmé.' })
                local weathers = {}
                for _, w in ipairs(PB.World and PB.World.Weathers or { 'EXTRASUNNY', 'CLEAR', 'RAIN', 'THUNDER', 'FOGGY', 'SNOW', 'XMAS' }) do weathers[#weathers + 1] = { w, w } end
                blocks[#blocks + 1] = { type = 'form', id = 'events.add', title = 'Programmer un événement', cols = 2, fields = {
                    { k = 'kind', type = 'select', label = 'Type', opts = { { 'announce', 'Annonce' }, { 'weather', 'Météo' }, { 'paybonus', 'Bonus de paie' } }, required = true },
                    { k = 'when', type = 'text', label = 'Date et heure (JJ/MM HH:MM)', required = true, maxlen = 20 },
                    { k = 'label', type = 'text', label = 'Nom (ex. Soirée double paie)', maxlen = 80 },
                    { k = 'repeat_mode', type = 'select', label = 'Répétition', opts = { { 'none', 'Une fois' }, { 'day', 'Chaque jour' }, { 'week', 'Chaque semaine' } } },
                    { k = 'text', type = 'text', label = 'Annonce : texte', maxlen = 300, wide = true },
                    { k = 'weather', type = 'select', label = 'Météo', opts = weathers },
                    { k = 'mult', type = 'number', label = 'Bonus de paie : multiplicateur (1 à 5)', min = 1, max = 5, int = false, step = 0.5 },
                    { k = 'minutes', type = 'number', label = 'Bonus de paie : durée (minutes)', min = 5, max = 720 },
                }, values = { kind = 'announce', when = os.date('%d/%m %H:%M', now() + 3600), label = '', repeat_mode = 'none', text = '', weather = 'EXTRASUNNY', mult = 2, minutes = 60 }, submit = { action = 'events.add', label = 'Programmer' } }
                return blocks
            end },
        } }
    end,
})
