-- Tablette des organisations (gangs) : crypto, gestion, classement, crews, grades, laboratoires, contrats.
-- Tout est réel : la crypto a un cours qui bouge, les grades et l'exclusion sont réservés au chef, les laboratoires et les contrats
-- sont les filières et braquages définis dans « Activités illégales », l'XP vient des braquages, ventes et captures de territoires.
-- Le serveur compose les pages et valide chaque action ; le client ne fait qu'afficher.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local O = {}
G.Orga = O

P.Register('orga.edit', 'Modifier la tablette des organisations', 'orga', true)
PB.Migrate('095_orga', 'Tablette des organisations', {
    [[CREATE TABLE IF NOT EXISTS pb_orga_xp (license VARCHAR(64) NOT NULL PRIMARY KEY, gang VARCHAR(32) NOT NULL DEFAULT '', xp INT NOT NULL DEFAULT 0)]],
    [[CREATE TABLE IF NOT EXISTS pb_orga_grade (license VARCHAR(64) NOT NULL PRIMARY KEY, grade INT NOT NULL DEFAULT 1)]],
    [[CREATE TABLE IF NOT EXISTS pb_orga_crypto (license VARCHAR(64) NOT NULL PRIMARY KEY, coins DOUBLE NOT NULL DEFAULT 0)]],
})
local function cfg(k, d) return PB.Cfg.Get('tablets', k, d) end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end
local function nameOf(src) local i = G.Identity(src) or {} local n = ((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') return n ~= '' and n or ('Joueur ' .. tostring(src)) end
local function gradeNames() local t = cfg('grade_names', nil) if type(t) ~= 'table' or #t < 2 then t = { 'Recrue', 'Membre', 'Lieutenant', 'Chef' } end return t end

-- XP ------------------------------------------------------------------------------------------------------------------------------------
function O.AddXp(src, n, why)
    local p, g = G.Get(src), gangOf(src)
    n = math.floor(tonumber(n) or 0)
    if not p or not g or n <= 0 then return false end
    DB.exec('INSERT INTO pb_orga_xp (license, gang, xp) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE gang = VALUES(gang), xp = xp + VALUES(xp)', { p.license, g.id, n })
    return true
end
function O.Xp(src) local p = G.Get(src) local r = p and DB.one('SELECT xp FROM pb_orga_xp WHERE license = ?', { p.license }) return r and tonumber(r.xp) or 0 end
function O.GangXp(gid) return tonumber(DB.scalar('SELECT COALESCE(SUM(xp), 0) FROM pb_orga_xp WHERE gang = ?', { gid })) or 0 end
AddEventHandler('pb_panel:heistDone', function(src, id, amount) O.AddXp(src, 10 + math.floor((tonumber(amount) or 0) / 100), 'braquage') end)
AddEventHandler('pb_panel:drugSold', function(src, id, n) O.AddXp(src, math.max(1, math.floor((tonumber(n) or 0) / 2)), 'vente') end)
AddEventHandler('pb_panel:territoryTaken', function(src) O.AddXp(src, 50, 'territoire') end)

O.GradeNames = function() return gradeNames() end
-- Grades ----------------------------------------------------------------------------------------------------------------------------------
function O.Grade(src)
    local p, g = G.Get(src), gangOf(src)
    if not p or not g then return 0 end
    if G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, g.id) then return #gradeNames() end
    local r = DB.one('SELECT grade FROM pb_orga_grade WHERE license = ?', { p.license })
    return math.max(1, math.min(#gradeNames() - 1, r and tonumber(r.grade) or 1))
end
local function isBoss(src) local g = gangOf(src) return g ~= nil and G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, g.id) == true end
local function sameGang(a, b) local ga, gb = gangOf(a), gangOf(b) return ga and gb and ga.id == gb.id end
local function members(gid)
    local out = {}
    for s in pairs(G.Players()) do local g = gangOf(s) if g and g.id == gid then out[#out + 1] = s end end
    table.sort(out)
    return out
end

-- Crypto ------------------------------------------------------------------------------------------------------------------------------------
local price, history = 100.0, { 100.0 }
function O.Price() return price end
function O.Step(r)
    r = r or (math.random(-80, 80) / 1000)
    price = math.max(20.0, math.min(500.0, price * (1 + r)))
    history[#history + 1] = price
    while #history > 12 do table.remove(history, 1) end
end
CreateThread(function() while true do Wait(10 * 60 * 1000) O.Step() end end)
local function coins(src) local p = G.Get(src) local r = p and DB.one('SELECT coins FROM pb_orga_crypto WHERE license = ?', { p.license }) return r and tonumber(r.coins) or 0 end
local function fee() return math.max(0, math.min(20, tonumber(cfg('crypto_fee', 2)) or 2)) / 100 end

-- Pages -------------------------------------------------------------------------------------------------------------------------------------
local PAGES, ACT = {}, {}
local function stat(title, value, icon, tone, sub) return { title = title, value = value, icon = icon, tone = tone, sub = sub } end

local function tileList()
    local T = {
        { id = 'crypto', title = 'Crypto', icon = 'coins' }, { id = 'gestion', title = 'Gestion', icon = 'sliders' },
        { id = 'leaderboard', title = 'Leaderboard', icon = 'chart' }, { id = 'crews', title = 'Crews', icon = 'users' },
        { id = 'orgagrades', title = 'Grades', icon = 'crown' }, { id = 'labs', title = 'Laboratoires', icon = 'pin' },
        { id = 'contracts', title = 'Contrats', icon = 'alert' },
        { id = 'territories', title = 'Territoires', icon = 'pin' }, { id = 'roster', title = 'Effectif', icon = 'user' }, { id = 'orgnews', title = 'Messages', icon = 'chat' },
        { id = 'orgvault', title = 'Caisse', icon = 'wallet' }, { id = 'activity', title = 'Activité', icon = 'star' },
    }
    for _, t in ipairs(T) do t.page = t.id t.img = cfg('img_' .. t.id, '') end
    return T
end

function O.Frame(src)
    local g = gangOf(src)
    local ranks = O.Ranking()
    local myRank = '#–'
    for i, r in ipairs(ranks) do if g and r.id == g.id then myRank = '#' .. i end end
    return { kind = 'orga', name = nameOf(src), id = src, title = 'Organisation', subtitle = g and ('Accueil tablette illégale · ' .. g.label) or 'Accueil tablette illégale', icon = 'skull',
        tone = '#dfe2e7', logo = PB.Cfg.Get('general', 'server_logo', ''), tiles = tileList(),
        tools = { { icon = 'chart', label = 'Classement', page = 'leaderboard' }, { icon = 'sliders', label = 'Gestion', page = 'gestion' }, { icon = 'pin', label = 'Laboratoires', page = 'labs' } },
        xp = { { icon = 'star', value = O.Xp(src) .. ' XP', rank = '' }, { icon = 'users', value = (g and O.GangXp(g.id) or 0) .. ' XP', rank = myRank } },
        nav = {} }
end

PAGES.home = function() return {}, '' end

PAGES.crypto = function(src)
    local held = coins(src)
    local rows = {}
    for i = #history, 1, -1 do rows[#rows + 1] = { n = (#history - i == 0) and 'Maintenant' or ('-' .. (#history - i) .. ' × 10 min'), v = money(history[i]) } end
    return { { type = 'cards', items = { stat('Cours', money(price), 'chart', '#7b6cff', 'Un jeton, bouge toutes les 10 minutes'), stat('Mes jetons', ('%.4f'):format(held), 'coins', '#7b6cff', 'Valeur ' .. money(held * price)),
            stat('Banque', money(G.GetMoney(src, 'bank') or 0), 'bank', '#5fd0d0', ('Frais %d %%'):format(math.floor(fee() * 100 + 0.5))) } },
        { type = 'form', title = 'Acheter', desc = 'Payé depuis ton compte bancaire.', fields = { { k = 'amount', label = 'Montant ($)', type = 'number', min = 1, max = 1000000 } }, submit = { label = 'Acheter', act = 'crypto_buy' } },
        { type = 'form', title = 'Vendre', desc = 'Versé sur ton compte bancaire.', fields = { { k = 'coins', label = 'Jetons à vendre', type = 'number', min = 0, max = 100000000 } }, submit = { label = 'Vendre', act = 'crypto_sell' } },
        { type = 'table', title = 'Historique du cours', columns = { { k = 'n', label = 'Quand' }, { k = 'v', label = 'Cours' } }, rows = rows } }, 'Crypto'
end
ACT.crypto_buy = function(src, p)
    local amount = math.floor(tonumber(p.amount) or 0)
    if amount < 1 or amount > 1000000 then return false, 'Montant invalide.' end
    if not G.RemoveMoney(src, 'bank', amount, 'Achat crypto') then return false, 'Solde bancaire insuffisant.' end
    local got = amount * (1 - fee()) / price
    DB.exec('INSERT INTO pb_orga_crypto (license, coins) VALUES (?, ?) ON DUPLICATE KEY UPDATE coins = coins + VALUES(coins)', { G.Get(src).license, got })
    PB.Audit.Log('economie', 'orga.crypto.buy', src, '', nil, nil, { amount = amount, coins = got, price = price })
    return true, ('%.4f jeton(s) achetés.'):format(got)
end
ACT.crypto_sell = function(src, p)
    local n = tonumber(p.coins) or 0
    if n <= 0 or n ~= n then return false, 'Quantité invalide.' end
    local held = coins(src)
    if n > held + 1e-9 then return false, "Tu n'as pas autant de jetons." end
    local back = math.floor(n * price * (1 - fee()))
    DB.exec('UPDATE pb_orga_crypto SET coins = GREATEST(0, coins - ?) WHERE license = ?', { n, G.Get(src).license })
    if back > 0 then G.AddMoney(src, 'bank', back, 'Vente crypto') end
    PB.Audit.Log('economie', 'orga.crypto.sell', src, '', nil, nil, { coins = n, back = back, price = price })
    return true, ('%s versés sur ton compte.'):format(money(back))
end

PAGES.gestion = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local boss = isBoss(src)
    local names, rows = gradeNames(), {}
    for _, s in ipairs(members(g.id)) do
        local row = { name = nameOf(s), grade = names[O.Grade(s)] or '', xp = tostring(O.Xp(s)) }
        if boss and s ~= src then row.actions = { { label = 'Exclure', act = 'kick', payload = { id = s }, danger = true, confirm = true, icon = 'close' } } end
        rows[#rows + 1] = row
    end
    local total = tonumber(DB.scalar('SELECT COUNT(*) FROM pb_tag_gang WHERE gang = ?', { g.id })) or 0
    local blocks = { { type = 'cards', items = { stat('Organisation', g.label, 'users', nil, boss and 'Tu en es le chef' or 'Tu en es membre'), stat('Membres', tostring(total), 'user', nil, #rows .. ' en ligne'), stat('XP de groupe', tostring(O.GangXp(g.id)), 'star', nil, 'Cumul des membres') } },
        { type = 'table', title = 'Membres en ligne', columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'xp', label = 'XP' } }, rows = rows, empty = 'Personne.' } }
    if boss then
        blocks[#blocks + 1] = { type = 'actions', title = 'Recrutement', items = { { label = 'Inviter la personne la plus proche', act = 'invite', icon = 'user', primary = true } } }
    else blocks[#blocks + 1] = { type = 'notice', text = "Seul le chef peut recruter et exclure." } end
    return blocks, 'Gestion'
end
local function dist(a, b)
    local pa, pb = GetEntityCoords(GetPlayerPed(a)), GetEntityCoords(GetPlayerPed(b))
    return math.sqrt((pa.x - pb.x) ^ 2 + (pa.y - pb.y) ^ 2 + (pa.z - pb.z) ^ 2)
end
local pending = {}   -- cible -> { gang, by, t }
ACT.invite = function(src)
    local g = gangOf(src)
    if not g or not isBoss(src) then return false, 'Réservé au chef.' end
    local best, bd
    for s in pairs(G.Players()) do
        if s ~= src and usable(s) and not gangOf(s) then
            local d = dist(src, s)
            if d <= 5.0 and (not bd or d < bd) then best, bd = s, d end
        end
    end
    if not best then return false, "Personne sans organisation à moins de 5 m." end
    pending[best] = { gang = g.id, by = src, t = os.time() }
    G.Notify(best, { type = 'info', title = g.label, text = ('%s t\'invite à rejoindre %s. Tape /rejoindre pour accepter.'):format(nameOf(src), g.label), duration = 12000 })
    return true, ('Invitation envoyée à %s.'):format(nameOf(best))
end
RegisterCommand('rejoindre', function(src)
    src = tonumber(src)
    local pd = src and pending[src]
    if not pd or os.time() - pd.t > (tonumber(cfg('invite_secs', 60)) or 60) then if src then G.Notify(src, { type = 'error', title = 'Organisation', text = 'Aucune invitation en cours.' }) end return end
    pending[src] = nil
    if gangOf(src) then return end
    local ok, msg = G.Tags.SetGang(src, pd.gang)
    if ok then
        G.Notify(src, { type = 'success', title = 'Organisation', text = 'Tu as rejoint l\'organisation.' })
        PB.Audit.Log('serveur', 'orga.join', src, pd.gang, nil, nil, { by = pd.by })
    else G.Notify(src, { type = 'error', title = 'Organisation', text = msg or 'Impossible.' }) end
end, false)
ACT.kick = function(src, p)
    local g = gangOf(src)
    local t = tonumber(p.id)
    if not g or not isBoss(src) then return false, 'Réservé au chef.' end
    if not t or t == src or not G.Get(t) or not sameGang(src, t) then return false, 'Membre introuvable.' end
    local lic = G.Get(t).license
    G.Tags.SetGang(t, nil)
    DB.exec('DELETE FROM pb_orga_grade WHERE license = ?', { lic })
    G.Notify(t, { type = 'warn', title = g.label, text = 'Tu as été exclu(e) de l\'organisation.' })
    PB.Audit.Log('serveur', 'orga.kick', src, lic, nil, nil, { gang = g.id })
    return true, nameOf(t) .. ' a été exclu(e).'
end

function O.Ranking()
    local out = {}
    local defs = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs() or {}
    local terr = {}
    if G.Territories then for _, o in pairs(G.Territories.Owners()) do if o then terr[o.gang] = (terr[o.gang] or 0) + 1 end end end
    for id, d in pairs(defs) do
        local xp = O.GangXp(id)
        out[#out + 1] = { id = id, label = d.label or id, color = d.color or '#dfe2e7', xp = xp, terr = terr[id] or 0, points = xp + (terr[id] or 0) * 500, online = #members(id) }
    end
    table.sort(out, function(a, b) if a.points ~= b.points then return a.points > b.points end return a.id < b.id end)
    return out
end
PAGES.leaderboard = function()
    local rows = {}
    for i, r in ipairs(O.Ranking()) do rows[#rows + 1] = { rank = '#' .. i, name = r.label, terr = tostring(r.terr), xp = tostring(r.xp), pts = tostring(r.points) } end
    return { { type = 'notice', text = 'Points = XP cumulée + 500 par territoire tenu.' },
        { type = 'table', title = 'Classement des organisations', columns = { { k = 'rank', label = 'Rang' }, { k = 'name', label = 'Organisation' }, { k = 'terr', label = 'Territoires' }, { k = 'xp', label = 'XP' }, { k = 'pts', label = 'Points' } }, rows = rows, empty = "Aucune organisation n'est définie." } }, 'Leaderboard'
end
PAGES.crews = function()
    local items = {}
    for _, r in ipairs(O.Ranking()) do
        local total = tonumber(DB.scalar('SELECT COUNT(*) FROM pb_tag_gang WHERE gang = ?', { r.id })) or 0
        items[#items + 1] = { title = r.label, value = tostring(total) .. ' membre(s)', icon = 'users', sub = ('%d en ligne · %d territoire(s)'):format(r.online, r.terr) }
    end
    return { { type = 'cards', items = items } }, 'Crews'
end
PAGES.orgagrades = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local names, rows, boss = gradeNames(), {}, isBoss(src)
    for _, s in ipairs(members(g.id)) do
        local gr = O.Grade(s)
        local row = { name = nameOf(s), grade = names[gr] or '' }
        if boss and s ~= src then row.actions = { { label = 'Monter', act = 'grade_up', payload = { id = s }, icon = 'check' }, { label = 'Descendre', act = 'grade_down', payload = { id = s } } } end
        rows[#rows + 1] = row
    end
    return { { type = 'notice', text = 'Grades : ' .. table.concat(names, ' → ') .. '. Le chef peut monter ou descendre les autres membres (jusqu\'à « ' .. (names[#names - 1] or '') .. ' »).' },
        { type = 'table', title = 'Grades des membres en ligne', columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' } }, rows = rows } }, 'Grades'
end
local function setGrade(src, p, d)
    local g = gangOf(src)
    local t = tonumber(p.id)
    if not g or not isBoss(src) then return false, 'Réservé au chef.' end
    if not t or t == src or not G.Get(t) or not sameGang(src, t) then return false, 'Membre introuvable.' end
    local new = math.max(1, math.min(#gradeNames() - 1, O.Grade(t) + d))
    DB.exec('REPLACE INTO pb_orga_grade (license, grade) VALUES (?, ?)', { G.Get(t).license, new })
    PB.Audit.Log('serveur', 'orga.grade', src, G.Get(t).license, nil, new, { gang = g.id })
    return true, ('%s : %s.'):format(nameOf(t), gradeNames()[new])
end
ACT.grade_up = function(src, p) return setGrade(src, p, 1) end
ACT.grade_down = function(src, p) return setGrade(src, p, -1) end

PAGES.labs = function(src)
    if not gangOf(src) then return nil end
    local rows = {}
    local cr = PB.Cfg.All('crime') or {}
    local KIND = { harvest = 'Récolte', process = 'Transformation', sell = 'Vente' }
    for _, s in ipairs(cr.chain or {}) do
        local owner = G.Flags and G.Flags.Owner and G.Flags.Owner(s.id)
        rows[#rows + 1] = { name = s.label, kind = KIND[s.kind] or s.kind, who = owner and ((G.Tags.GangDefs()[owner] or {}).label or owner) or '—',
            actions = { { label = 'GPS', act = 'gps', payload = { kind = 'chain', id = s.id }, icon = 'pin' } } }
    end
    return { { type = 'notice', text = "Les points de filière du serveur : récolte, transformation (laboratoires) et vente. « Tenu par » = organisation qui tient le drapeau de ce point (ventes améliorées)." },
        { type = 'table', title = 'Laboratoires et filières', columns = { { k = 'name', label = 'Point' }, { k = 'kind', label = 'Type' }, { k = 'who', label = 'Tenu par' } }, rows = rows, empty = 'Aucune filière définie.' } }, 'Laboratoires'
end
PAGES.contracts = function(src)
    if not gangOf(src) then return nil end
    local rows = {}
    local cr = PB.Cfg.All('crime') or {}
    local cds = G.Crime and G.Crime.Cooldowns and G.Crime.Cooldowns() or {}
    for _, s in ipairs(cr.heists or {}) do
        local left = cds[s.id]
        rows[#rows + 1] = { name = s.label, gain = money(s.min) .. ' – ' .. money(s.max), police = tostring(s.police or 0), state = left and ('Dans ' .. math.ceil(left / 60) .. ' min') or 'Disponible',
            actions = { { label = 'GPS', act = 'gps', payload = { kind = 'heist', id = s.id }, icon = 'pin' } } }
    end
    return { { type = 'notice', text = "Contrats = braquages disponibles. Vise le vendeur avec une arme (même blanche) pour commencer ; ça rapporte de l'argent sale et de l'XP." },
        { type = 'table', title = 'Contrats disponibles', columns = { { k = 'name', label = 'Contrat' }, { k = 'gain', label = 'Gain' }, { k = 'police', label = 'Policiers min.' }, { k = 'state', label = 'État' } }, rows = rows, empty = 'Aucun contrat défini.' } }, 'Contrats'
end
ACT.gps = function(src, p)
    local s = G.Crime and G.Crime.Spot and G.Crime.Spot(tostring(p.kind), tostring(p.id))
    if not s then return false, 'Point inconnu.' end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = s.x, y = s.y, label = s.label }))
    return true, 'Position marquée sur ta carte.'
end

-- Pages complémentaires : territoires, effectif complet, annonces, caisse commune, activité --------------------------------------------
PB.Migrate('191_orga_more', 'Tablette organisations : annonces et caisse commune', {
    [[CREATE TABLE IF NOT EXISTS pb_orga_news (id INT NOT NULL AUTO_INCREMENT, gang VARCHAR(32) NOT NULL, text VARCHAR(240) NOT NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_g (gang))]],
    [[CREATE TABLE IF NOT EXISTS pb_orga_vault (gang VARCHAR(32) NOT NULL PRIMARY KEY, balance BIGINT NOT NULL DEFAULT 0)]],
})
local function vaultBal(gid) return tonumber(DB.scalar('SELECT balance FROM pb_orga_vault WHERE gang = ?', { gid })) or 0 end
local function nameOfLicense(lic)
    local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { lic })
    local n = r and ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') or ''
    return n ~= '' and n or lic:sub(-6)
end

PAGES.territories = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local zones, mine, out = (PB.Cfg.Get('territories', 'zones', {}) or {}), 0, {}
    local Tr = G.Territories
    local owners = Tr and Tr.Owners() or {}
    local function fmt(sec)
        if not sec then return nil end
        if sec <= 0 then return 'Livraison imminente' end
        local h, m = math.floor(sec / 3600), math.floor((sec % 3600) / 60)
        return ('Prochaine livraison dans %dh%02d'):format(h, m)
    end
    for _, z in ipairs(zones) do
        local o = owners[z.id]
        if o and o.gang == g.id then mine = mine + 1 end
        local rw = Tr and Tr.RewardOf(z)
        local d = rw and G.Inv and G.Inv.Def(rw.item)
        out[#out + 1] = { id = z.id, label = z.label or z.id, x = z.x, y = z.y, owner = o and o.label or nil, color = o and o.color or nil, mine = (o and o.gang == g.id) or false,
            reward = rw and ('%d× %s / %d h'):format(rw.qty, d and d.label or rw.item, rw.hours) or nil, next = (o and o.gang == g.id) and rw and fmt(Tr.NextReward(z)) or nil,
            gps = (tonumber(z.x) and tonumber(z.y)) and true or nil }
    end
    return { { type = 'cards', items = { stat('Territoires tenus', tostring(mine), 'pin', nil, 'Chacun rapporte 500 points'), stat('Zones du serveur', tostring(#zones), 'map', nil, 'À capturer') } },
        { type = 'terrmap', title = 'Carte des territoires', zones = out },
        { type = 'actions', title = 'Récompenses', items = { { label = "Ouvrir le coffre de l'organisation", icon = 'lock', act = 'open_stash', primary = true } } },
        { type = 'notice', text = "Chaque territoire tenu dépose son objet dans le coffre de l'organisation, à intervalle fixe. Le coffre s'ouvre ici ou au point « Coffre » posé par le staff." } }, 'Territoires'
end
-- Coffre d'objets de l'organisation : propriétaire 'o:<gang>'. Accessible aux membres, depuis la tablette (2 min) ou près d'un point « coffre » du gang.
local vaultOk = {}
AddEventHandler('playerDropped', function() vaultOk[source] = nil end)
if G.Inv then
    local prevExtra = G.Inv.ExtraAccess
    G.Inv.ExtraAccess = function(src, kind, id)
        if kind == 'o' then
            local g = gangOf(src)
            if not g or g.id ~= id then return false end
            if (vaultOk[src] or 0) > os.time() then return true end
            for _, p in ipairs(G.Points and G.Points.Of('gang', id) or {}) do
                if p.kind == 'stash' and G.DistTo(src, p.x, p.y, p.z) <= (p.radius or 2.0) + 6 then return true end
            end
            return false
        end
        if prevExtra then return prevExtra(src, kind, id) end
        return false
    end
end
function O.OpenStash(src, viaTablet)
    local g = gangOf(src)
    if not g or not G.Inv then return false, "Pas d'organisation." end
    if viaTablet then
        vaultOk[src] = os.time() + 120
        TriggerClientEvent('pb:g:orga:shut', src)        -- la tablette rend la main, puis l'inventaire s'ouvre
        SetTimeout(350, function() if G.Get(src) then G.Inv.OpenFor(src, 'o:' .. g.id) end end)
    else G.Inv.OpenFor(src, 'o:' .. g.id) end
    return true
end
ACT.open_stash = function(src)
    return O.OpenStash(src, true)
end
ACT.gps_zone = function(src, p)
    local zones = PB.Cfg.Get('territories', 'zones', {}) or {}
    for _, z in ipairs(zones) do
        if z.id == tostring(p.id) and tonumber(z.x) and tonumber(z.y) then
            TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = z.x, y = z.y, label = z.label }))
            return true, 'Position marquée sur ta carte.'
        end
    end
    return false, 'Zone inconnue.'
end

PAGES.roster = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local names, rows = gradeNames(), {}
    local online = {}
    for _, s in ipairs(members(g.id)) do online[G.Get(s).license] = s end
    for _, r in ipairs(DB.q('SELECT license FROM pb_tag_gang WHERE gang = ?', { g.id }) or {}) do
        local s = online[r.license]
        local gr = s and O.Grade(s) or math.max(1, math.min(#names - 1, tonumber(DB.scalar('SELECT grade FROM pb_orga_grade WHERE license = ?', { r.license })) or 1))
        local xp = tonumber(DB.scalar('SELECT xp FROM pb_orga_xp WHERE license = ?', { r.license })) or 0
        rows[#rows + 1] = { name = s and nameOf(s) or nameOfLicense(r.license), grade = names[gr] or '', xp = xp, state = s and 'En ligne' or 'Hors ligne' }
    end
    table.sort(rows, function(a, b) return a.xp > b.xp end)
    for _, r in ipairs(rows) do r.xp = tostring(r.xp) end
    return { { type = 'table', title = 'Tous les membres', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'xp', label = 'XP' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows, empty = 'Aucun membre.' } }, 'Effectif'
end

PAGES.orgnews = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local rows = {}
    for _, n in ipairs(DB.q('SELECT * FROM pb_orga_news WHERE gang = ? ORDER BY id DESC LIMIT 20', { g.id }) or {}) do rows[#rows + 1] = { at = os.date('%d/%m %H:%M', n.at or 0), by = n.by_name, text = n.text } end
    local blocks = {}
    if isBoss(src) then blocks[#blocks + 1] = { type = 'form', title = 'Message à la famille', desc = 'Les membres connectés le reçoivent tout de suite.', fields = { { k = 'text', type = 'text', label = 'Message', maxlen = 240 } }, submit = { act = 'org_announce', label = 'Envoyer' } } end
    blocks[#blocks + 1] = { type = 'table', title = 'Messages du chef', columns = { { k = 'at', label = 'Date' }, { k = 'by', label = 'Par' }, { k = 'text', label = 'Message' } }, rows = rows, empty = 'Aucun message.' }
    return blocks, 'Messages'
end
ACT.org_announce = function(src, p)
    local g = gangOf(src)
    if not g or not isBoss(src) then return false, 'Réservé au chef.' end
    local text = tostring(p.text or ''):gsub('[%c<>]', ''):sub(1, 240)
    if #text < 3 then return false, 'Message trop court.' end
    DB.exec('INSERT INTO pb_orga_news (gang, text, by_name, at) VALUES (?, ?, ?, ?)', { g.id, text, nameOf(src), os.time() })
    for _, s in ipairs(members(g.id)) do G.Notify(s, { type = 'info', title = g.label, text = text, duration = 9000 }) end
    PB.Audit.Log('serveur', 'orga.announce', src, g.id, nil, nil, { text = text })
    return true, 'Message envoyé.'
end

PAGES.orgvault = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local boss = isBoss(src)
    local blocks = { { type = 'cards', items = { stat('Caisse commune', money(vaultBal(g.id)), 'coins', nil, 'Argent liquide de l\'organisation'), stat('Mes espèces', money(G.GetMoney(src, 'cash') or 0), 'wallet', '#7be0a4', 'À verser si tu veux') } },
        { type = 'form', title = 'Verser dans la caisse', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 10000000 } }, submit = { act = 'vault_in', label = 'Verser' } } }
    if boss then blocks[#blocks + 1] = { type = 'form', title = 'Retirer de la caisse', desc = 'Réservé au chef.', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 10000000 } }, submit = { act = 'vault_out', label = 'Retirer' } }
    else blocks[#blocks + 1] = { type = 'notice', text = 'Seul le chef retire de la caisse.' } end
    return blocks, 'Caisse'
end
ACT.vault_in = function(src, p)
    local g = gangOf(src)
    local n = math.floor(tonumber(p.amount) or 0)
    if not g or n < 1 or n > 10000000 then return false, 'Montant invalide.' end
    if not G.RemoveMoney(src, 'cash', n, 'Caisse ' .. g.label) then return false, "Tu n'as pas assez d'espèces." end
    DB.exec('INSERT INTO pb_orga_vault (gang, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)', { g.id, n })
    PB.Audit.Log('economie', 'orga.vault.in', src, g.id, nil, nil, { amount = n })
    return true, money(n) .. ' versés dans la caisse.'
end
ACT.vault_out = function(src, p)
    local g = gangOf(src)
    local n = math.floor(tonumber(p.amount) or 0)
    if not g or not isBoss(src) then return false, 'Réservé au chef.' end
    if n < 1 or n > vaultBal(g.id) then return false, 'Montant invalide ou caisse insuffisante.' end
    DB.exec('UPDATE pb_orga_vault SET balance = balance - ? WHERE gang = ? AND balance >= ?', { n, g.id, n })
    G.AddMoney(src, 'cash', n, 'Caisse ' .. g.label)
    PB.Audit.Log('economie', 'orga.vault.out', src, g.id, nil, nil, { amount = n })
    return true, money(n) .. ' retirés de la caisse.'
end

PAGES.activity = function(src)
    local g = gangOf(src)
    if not g then return nil end
    local rows = {}
    for _, r in ipairs(DB.q('SELECT license, xp FROM pb_orga_xp WHERE gang = ? ORDER BY xp DESC LIMIT 15', { g.id }) or {}) do rows[#rows + 1] = { name = nameOfLicense(r.license), xp = tostring(r.xp) } end
    local rk, pos = O.Ranking(), '–'
    for i, r in ipairs(rk) do if r.id == g.id then pos = '#' .. i end end
    return { { type = 'cards', items = { stat('Mon XP', tostring(O.Xp(src)), 'star', nil, 'Braquages, ventes, territoires'), stat('XP du groupe', tostring(O.GangXp(g.id)), 'users', nil, 'Cumul des membres'), stat('Classement', pos, 'chart', '#46b6ff', 'Sur ' .. #rk .. ' organisation(s)') } },
        { type = 'table', title = 'Meilleurs contributeurs', columns = { { k = 'name', label = 'Membre' }, { k = 'xp', label = 'XP' } }, rows = rows, empty = "Aucune activité pour l'instant." } }, 'Activité'
end

-- Réseau ----------------------------------------------------------------------------------------------------------------------------------
-- Gestion de l'organisation (menu boss) : seulement au point boss du groupe, comme pour les entreprises
local BOSS_PAGES = { gestion = true, orgagrades = true, orgvault = true }
local BOSS_ACTS = { invite = true, kick = true, grade_up = true, grade_down = true, vault_out = true }
local BOSS_MSG = "Gestion de l'organisation : rends-toi au point boss."
local function atBoss(src) local g = gangOf(src) return g ~= nil and (not (G.Points and G.Points.AtBoss) or G.Points.AtBoss(src, 'gang', g.id)) end
function O.Page(src, page)
    local fn = PAGES[tostring(page or 'home')]
    if not fn then return nil, 'Page inconnue.' end
    if BOSS_PAGES[tostring(page)] and not atBoss(src) then return nil, BOSS_MSG end
    local blocks, title = fn(src)
    if not blocks then return nil, "Tu n'as pas d'organisation." end
    return { page = tostring(page or 'home'), title = title or '', blocks = blocks }
end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil pending[source] = nil end)
local function send(src, ev, extra) extra = extra or {} extra.ev = ev extra.frame = O.Frame(src) TriggerClientEvent('pb:g:orga:ui', src, PB.Json(extra)) end
RegisterNetEvent('pb:g:orga:open', function()
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    if not gangOf(src) then G.Notify(src, { type = 'error', title = 'Organisation', text = "Tu n'appartiens à aucune organisation." }) return end
    send(src, 'open', { page = O.Page(src, 'home') })
end)
RegisterNetEvent('pb:g:orga:page', function(page)
    local src = source
    if not usable(src) or not throttle(src, 150) then return end
    local data, err = O.Page(src, page)
    send(src, 'page', { page = data, err = err })
end)
RegisterNetEvent('pb:g:orga:act', function(name, payload, page)
    local src = source
    if not usable(src) or not throttle(src, 250) then return end
    local fn = ACT[tostring(name)]
    local ok, msg = false, 'Action inconnue.'
    if fn then
        if not gangOf(src) then ok, msg = false, "Tu n'as pas d'organisation."
        elseif BOSS_ACTS[tostring(name)] and not atBoss(src) then ok, msg = false, BOSS_MSG
        else ok, msg = fn(src, type(payload) == 'table' and payload or {}) end
    end
    send(src, 'result', { ok = ok and true or false, msg = msg, page = O.Page(src, page) })
end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------------
local function imgField(id, label) return { k = 'img_' .. id, type = 'asset', label = label, default = '', maxw = 900, maxh = 600 } end
local orgaForm = Form.Cfg({ ns = 'tablets', id = 'orga', title = 'Tablette des organisations : réglages et images', perm = 'orga.edit', cols = 2,
    desc = "Chaque tuile peut avoir sa photo (depuis ton PC). Sans photo, la tuile prend la couleur de l'organisation.", fields = {
        { k = 'boss_at_point', type = 'toggle', label = 'Gestion (menu boss) seulement au bureau du patron / point boss', default = true, hint = "Entreprises et organisations : employés, grades, salaires, caisse ne s'ouvrent plus depuis la tablette n'importe où. Sans point boss posé, la gestion reste accessible partout." },
        { k = 'orga_key', type = 'text', label = 'Touche (par défaut)', default = 'F7', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM. Commande : /orga' },
        { k = 'crypto_fee', type = 'number', label = 'Frais crypto (%)', default = 2, min = 0, max = 20 },
        { k = 'invite_secs', type = 'number', label = "Durée d'une invitation (s)", default = 60, min = 10, max = 600 },
        { k = 'grade_names', type = 'list', label = 'Grades (du plus bas au chef, un par ligne)', default = { 'Recrue', 'Membre', 'Lieutenant', 'Chef' }, maxitems = 8, maxlen = 24, wide = true },
        imgField('crypto', 'Image — Crypto'), imgField('gestion', 'Image — Gestion'), imgField('leaderboard', 'Image — Leaderboard'), imgField('crews', 'Image — Crews'),
        imgField('orgagrades', 'Image — Grades'), imgField('labs', 'Image — Laboratoires'), imgField('contracts', 'Image — Contrats'),
        imgField('territories', 'Image — Territoires'), imgField('roster', 'Image — Effectif'), imgField('orgnews', 'Image — Messages'), imgField('orgvault', 'Image — Caisse'), imgField('activity', 'Image — Activité') } })
local legalForm = Form.Cfg({ ns = 'tablets', id = 'legal', title = 'Tablette entreprise : images des tuiles', perm = 'orga.edit', cols = 2,
    desc = "Même habillage que la tablette des organisations. Chaque page de la tablette citoyen/entreprise devient une tuile.", fields = {
        imgField('home', 'Image — Accueil'), imgField('finance', 'Image — Finances'), imgField('invoices', 'Image — Factures'), imgField('directory', 'Image — Entreprises'), imgField('profile', 'Image — Mon profil'),
        imgField('biz', 'Image — Mon entreprise'), imgField('staff', 'Image — Employés'), imgField('grades', 'Image — Grades et salaires'), imgField('vault', 'Image — Caisse'), imgField('bills', 'Image — Factures émises'),
        imgField('citizens', 'Image — Citoyens / Dossiers'), imgField('patients', 'Image — Patients'),
        imgField('team', 'Image — Équipe'), imgField('news', 'Image — Annonces'), imgField('journal', 'Image — Journal'), imgField('stats', 'Image — Statistiques'), imgField('payroll', 'Image — Paie'), imgField('rules', 'Image — Règlement'), imgField('places', 'Image — Lieux') } })

G.LegalForm = legalForm

PB.Module({
    id = 'orga', label = 'Tablette des organisations', icon = 'tablet', group = 'Serveur', order = 146, perm = 'orga.edit', hint = 'Tablette illégale des organisations',
    caps = function() return PB.Capsify({
        { 'Crypto, gestion, classement, crews, grades', 'ok', 'Tout est calculé et validé par le serveur ; actions du chef journalisées.' },
        { 'Laboratoires et contrats', 'ok', 'Reprennent les filières et braquages de « Activités illégales », avec GPS.' },
        { 'Photos des tuiles', 'ok', 'Envoyées depuis ton PC dans le panel.' },
        { 'Laboratoire propre à chaque organisation (production automatique)', 'off', "Non fait : les laboratoires sont les points de filière du serveur." },
        { 'Vérifié dans un vrai client FiveM', 'off', "Non : testé en simulation et dans un navigateur." } }) end,
    doc = "## Tablette des organisations\nTouche réglable (F7) ou `/orga`, pour les membres d'un gang. Sept tuiles : **Crypto** (cours qui bouge toutes les 10 minutes), **Gestion** (membres, recrutement avec `/rejoindre`, exclusion), **Leaderboard** (XP + 500 par territoire), **Crews**, **Grades**, **Laboratoires** et **Contrats** (avec GPS).\n\nLes images de la tablette entreprise se règlent dans *Entreprises > Aperçu de la tablette*.",
    view = function(ctx)
        return { tabs = {
            { id = 'orga', label = 'Organisations', icon = 'users', build = function() return { orgaForm(ctx), { type = 'gpreview', kind = 'orga', title = 'Vue du joueur', cfg = {} } } end },
        } }
    end,
})

PB.SelfTest.Add('tablette des organisations', function(R)
    R.check(#gradeNames() >= 2, 'grades', 'au moins deux grades')
    R.check(price >= 20 and price <= 500, 'cours crypto', 'hors bornes')
    R.check(#tileList() == 12, 'tuiles', 'douze tuiles attendues')
end)
