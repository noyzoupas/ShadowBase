-- Menu des animations (ressource « animation_menu ») : couleur et néon réglables depuis le panel.
-- Les valeurs partent aux joueurs avec la configuration de jeu (namespace « animmenu », voir G.ClientConfig) ; le menu les applique en direct.

local Form = PB.Form

local HEX = '^#%x%x%x%x%x%x$'

local look = Form.Cfg({ ns = 'animmenu', id = 'look', title = 'Menu animations', perm = 'menus.edit', cols = 2, fields = {
    { k = 'color_mode', type = 'select', label = 'Couleur du menu', default = 'server', opts = {
        { 'server', 'Couleur du serveur (Identité)' }, { 'menus', "Couleur d'accent des menus" }, { 'custom', 'Couleur personnalisée' }, { 'original', 'Vert néon d’origine' } },
      hint = "« Couleur du serveur » suit la couleur principale réglée dans Identité (et celle des fêtes quand elles sont actives)." },
    { k = 'color', type = 'color', label = 'Couleur personnalisée', default = '#00f895', hint = 'Utilisée seulement avec « Couleur personnalisée ».' },
    { k = 'neon', type = 'toggle', label = 'Effet néon (arc de droite et écriture du bas)', default = true },
    { k = 'neon_power', type = 'number', label = 'Intensité du néon (%)', default = 100, min = 20, max = 200 },
} })

PB.Module({
    id = 'animmenu', label = 'Menu animations', icon = 'music', group = 'Serveur', order = 140, perm = 'menus.edit',
    hint = 'Couleur et néon du menu des animations (F9 / ALT > Animations)',
    doc = "## Menu animations\nRègle l'apparence du menu des animations (ressource **animation_menu**, touche **F9** ou **ALT > Animations**).\n\n- **Couleur du serveur** : reprend la couleur principale d'Identité, comme le reste du serveur.\n- **Couleur d'accent des menus** : reprend la couleur réglée dans Menus > Apparence.\n- **Couleur personnalisée** : la couleur choisie ici.\n- **Vert néon d'origine** : la maquette d'origine.\n\nLe changement s'applique en direct aux joueurs connectés.",
    view = function(ctx)
        return { tabs = {
            { id = 'look', label = 'Apparence', icon = 'star', build = function() return { look(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('animmenu', function(R)
    R.check(tostring(PB.Cfg.Get('animmenu', 'color', '#00f895')):match(HEX) ~= nil, 'couleur du menu animations', 'la couleur personnalisée est invalide')
end)
