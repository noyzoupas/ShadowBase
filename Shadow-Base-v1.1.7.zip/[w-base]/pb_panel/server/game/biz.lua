-- Entreprises (police, EMS, garage, générique) : grades, employés, paie, caisse, factures, amendes, dossiers et tablette de gestion en jeu.
-- Autonome (tables pb_biz*). Tout ce que le client demande est revérifié ici : appartenance, grade, service, distance, montants.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('biz.edit', 'Créer, modifier et supprimer les entreprises', 'biz', true)
P.Register('biz.members', 'Engager et renvoyer des employés depuis le panel', 'biz', true)
P.Register('biz.ledger', 'Voir les caisses des entreprises', 'biz')

PB.Migrate('044_game_biz', 'Entreprises, grades, employés, factures, dossiers', {
    [[CREATE TABLE IF NOT EXISTS pb_biz (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, kind VARCHAR(16) NOT NULL DEFAULT 'generic', color VARCHAR(7) NOT NULL DEFAULT '#dfe2e7', icon VARCHAR(24) NOT NULL DEFAULT 'building',
        pay_from VARCHAR(8) NOT NULL DEFAULT 'free', enabled TINYINT(1) NOT NULL DEFAULT 1, hx DOUBLE NULL, hy DOUBLE NULL, hz DOUBLE NULL, hiring TINYINT(1) NOT NULL DEFAULT 0,
        description VARCHAR(160) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_grades (
        biz_id VARCHAR(32) NOT NULL, grade INT NOT NULL, label VARCHAR(40) NOT NULL, salary INT NOT NULL DEFAULT 0, boss TINYINT(1) NOT NULL DEFAULT 0, perms VARCHAR(160) NOT NULL DEFAULT '',
        PRIMARY KEY (biz_id, grade))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_members (
        license VARCHAR(64) NOT NULL, biz_id VARCHAR(32) NOT NULL, grade INT NOT NULL DEFAULT 0, name VARCHAR(64) NOT NULL DEFAULT '', hired_at INT NOT NULL DEFAULT 0, on_duty TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (license), KEY k_biz (biz_id))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_invoices (
        id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', amount BIGINT NOT NULL, reason VARCHAR(120) NOT NULL DEFAULT '',
        kind VARCHAR(8) NOT NULL DEFAULT 'invoice', status VARCHAR(10) NOT NULL DEFAULT 'pending', by_name VARCHAR(64) NOT NULL DEFAULT '', by_license VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, paid_at INT NULL,
        PRIMARY KEY (id), KEY k_lic (license, status), KEY k_biz (biz_id, status))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_records (
        id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', kind VARCHAR(10) NOT NULL, text VARCHAR(240) NOT NULL DEFAULT '',
        amount BIGINT NOT NULL DEFAULT 0, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_lic (license), KEY k_biz (biz_id))]],
})

PB.Cfg.Define('tablets', { img_home = '', img_finance = '', img_invoices = '', img_directory = '', img_profile = '', img_biz = '', img_staff = '', img_grades = '', img_vault = '', img_bills = '', img_citizens = '', img_patients = '', img_team = '', img_news = '', img_journal = '', img_stats = '', img_payroll = '', img_rules = '', img_places = '', img_territories = '', img_roster = '', img_orgnews = '', img_orgvault = '', img_activity = '', img_crypto = '', img_gestion = '', img_leaderboard = '', img_crews = '', img_orgagrades = '', img_labs = '', img_contracts = '', orga_key = 'F7', crypto_fee = 2, invite_secs = 60, grade_names = { 'Recrue', 'Membre', 'Lieutenant', 'Chef' } })
PB.Cfg.Define('biz', { max_invoice = 50000, max_fine = 25000, fine_to = 'state', pay_off_duty = false, max_members = 60, allow_transfers = true, transfer_fee = 0, transfer_max = 100000, tablet_key = 'F6', near_dist = 8, full_catalog = false, trimmed_v1 = false })

local Biz = {}
G.Biz = Biz
local ALL_PERMS = { 'hire', 'fire', 'promote', 'vault', 'invoice', 'fine', 'revive', 'repair', 'records', 'cuff', 'search', 'seize', 'jail', 'dispatch' }
local PERM_LABEL = { hire = 'Engager', fire = 'Renvoyer', promote = 'Promouvoir', vault = 'Caisse', invoice = 'Facturer', fine = 'Amendes', revive = 'Réanimer', repair = 'Réparer', records = 'Dossiers', cuff = 'Menotter', search = 'Fouiller', seize = 'Saisir un véhicule', jail = 'Prison et TIG', dispatch = 'Répartiteur (appels)' }
local KIND_PERMS = { police = { 'fine', 'records', 'cuff', 'search', 'seize', 'jail', 'dispatch' }, ems = { 'revive', 'records', 'dispatch' }, garage = { 'repair' }, generic = {} }
local KIND_LABEL = { police = 'Police', ems = 'Secours (EMS)', garage = 'Garage', generic = 'Entreprise' }

local TEMPLATES = {
    police = { label = 'Police', kind = 'police', color = '#6fb4ff', icon = 'shield', description = "Maintien de l'ordre : amendes, dossiers, caisse du commissariat.", grades = {
        { 0, 'Cadet', 250, false, 'records' }, { 1, 'Officier', 350, false, 'fine,records,cuff,search,jail' }, { 2, 'Sergent', 450, false, 'fine,records,invoice,cuff,search,seize,jail,dispatch' }, { 3, 'Lieutenant', 600, false, 'fine,records,invoice,cuff,search,seize,jail,dispatch,hire' },
        { 4, 'Capitaine', 800, false, 'fine,records,invoice,cuff,search,seize,jail,dispatch,hire,fire,promote,vault' }, { 5, 'Chef de la police', 1100, true, '' } } },
    ems = { label = 'Secours (EMS)', kind = 'ems', color = '#ff6b7d', icon = 'heart', description = 'Soins, réanimation et facturation des interventions.', grades = {
        { 0, 'Stagiaire', 230, false, 'records' }, { 1, 'Ambulancier', 330, false, 'revive,records,invoice' }, { 2, 'Infirmier', 430, false, 'revive,records,invoice,dispatch' }, { 3, 'Médecin', 580, false, 'revive,records,invoice,dispatch' },
        { 4, 'Chef de service', 780, false, 'revive,records,invoice,dispatch,hire,fire,promote,vault' }, { 5, 'Directeur', 1000, true, '' } } },
    garage = { label = 'Garage', kind = 'garage', color = '#ffb457', icon = 'engine', description = 'Réparations, dépannage et facturation des clients.', grades = {
        { 0, 'Apprenti', 200, false, 'repair' }, { 1, 'Mécanicien', 300, false, 'repair,invoice' }, { 2, "Chef d'atelier", 420, false, 'repair,invoice,hire,vault' }, { 3, 'Patron', 700, true, '' } } },
    generic = { label = 'Entreprise', kind = 'generic', color = '#dfe2e7', icon = 'building', description = 'Une entreprise simple avec caisse et factures.', grades = {
        { 0, 'Employé', 200, false, 'invoice' }, { 1, 'Gérant', 400, false, 'invoice,hire,fire,promote,vault' }, { 2, 'Patron', 600, true, '' } } },
}
Biz.Templates = TEMPLATES

local function now() return os.time() end
local function acct(id) return 'biz:' .. id end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function setOf(csv) local t = {} for w in tostring(csv or ''):gmatch('[%a_]+') do t[w] = true end return t end

-- Données ---------------------------------------------------------------------------------------------------------------------------
function Biz.Get(id) return DB.one('SELECT * FROM pb_biz WHERE id = ?', { tostring(id) }) end
function Biz.List() return DB.q('SELECT * FROM pb_biz ORDER BY label') or {} end
function Biz.Grades(id) return DB.q('SELECT * FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade', { tostring(id) }) or {} end
function Biz.Grade(id, n) return DB.one('SELECT * FROM pb_biz_grades WHERE biz_id = ? AND grade = ?', { tostring(id), tonumber(n) or -1 }) end
function Biz.Members(id) return DB.q('SELECT * FROM pb_biz_members WHERE biz_id = ? ORDER BY grade DESC, name', { tostring(id) }) or {} end
function Biz.MemberOf(license) return DB.one('SELECT * FROM pb_biz_members WHERE license = ?', { tostring(license) }) end

-- Contexte d'un joueur en ligne : { member, biz, grade, boss, perms }
function Biz.Ctx(src)
    local p = G.Get(src)
    if not p then return nil end
    local m = Biz.MemberOf(p.license)
    if not m then return nil end
    local b = Biz.Get(m.biz_id)
    if not b or not PB.ToBool(b.enabled) then return nil end
    local g = Biz.Grade(m.biz_id, m.grade)
    if not g then return nil end
    local boss = PB.ToBool(g.boss)
    return { member = m, biz = b, grade = g, boss = boss, perms = setOf(g.perms), license = p.license, src = src, duty = PB.ToBool(m.on_duty) }
end
function Biz.Can(c, perm) return c and (c.boss or c.perms[perm]) and true or false end
local function kindAllows(c, perm) local ok = false for _, k in ipairs(KIND_PERMS[c.biz.kind] or {}) do if k == perm then ok = true end end return ok or perm == 'invoice' or perm == 'hire' or perm == 'fire' or perm == 'promote' or perm == 'vault' end
-- un droit propre à un métier n'a d'effet que dans ce métier, même pour le patron
function Biz.Allowed(c, perm)
    if not c then return false end
    if perm == 'fine' or perm == 'revive' or perm == 'repair' or perm == 'records' or perm == 'cuff' or perm == 'search' or perm == 'seize' or perm == 'jail' or perm == 'dispatch' then if not kindAllows(c, perm) then return false end end
    return Biz.Can(c, perm)
end

function Biz.Job(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    return { biz = c.biz.id, label = c.biz.label, kind = c.biz.kind, grade = c.grade.grade, gradeLabel = c.grade.label, boss = c.boss, onDuty = c.duty, salary = c.grade.salary }
end
exports('GetJob', function(src) return Biz.Job(tonumber(src)) end)
exports('IsOnDuty', function(src, bizId) local j = Biz.Job(tonumber(src)) return j ~= nil and j.onDuty and (bizId == nil or j.biz == bizId) end)
exports('GetBusinessBalance', function(id) return G.Eco and G.Eco.Balance(acct(id)) or 0 end)
exports('AddBusinessMoney', function(id, amount, reason) if not Biz.Get(id) then return false end return G.Eco.Book(acct(id), amount, reason or 'Script', '') end)

local function display(src) local i = G.Identity(src) if i and i.created and i.firstname ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return (GetPlayerName and GetPlayerName(src)) or ('Joueur ' .. src) end

function Biz.SetJob(src, bizId, gradeNo, actorName)
    local p = G.Get(tonumber(src))
    if not p then return false, 'Joueur introuvable.' end
    if bizId == nil or bizId == '' then
        DB.exec('DELETE FROM pb_biz_members WHERE license = ?', { p.license })
        TriggerClientEvent('pb:g:biz:job', src, 'null')
        TriggerEvent('pb_panel:jobChanged', tonumber(src), nil, nil)
        return true
    end
    local b = Biz.Get(bizId)
    if not b then return false, 'Entreprise introuvable.' end
    local g = Biz.Grade(bizId, gradeNo or 0)
    if not g then return false, 'Grade introuvable.' end
    local count = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { bizId })
    local old = Biz.MemberOf(p.license)
    if (not old or old.biz_id ~= bizId) and count and count.n >= PB.Cfg.Get('biz', 'max_members', 60) then return false, 'Cette entreprise a atteint son nombre maximal d\'employés.' end
    DB.exec('INSERT INTO pb_biz_members (license, biz_id, grade, name, hired_at, on_duty) VALUES (?, ?, ?, ?, ?, 0) ON DUPLICATE KEY UPDATE biz_id = VALUES(biz_id), grade = VALUES(grade), name = VALUES(name), on_duty = 0' ..
        ((old and old.biz_id == bizId) and '' or ', hired_at = VALUES(hired_at)'), { p.license, bizId, g.grade, display(src), now() })
    TriggerEvent('pb_panel:jobChanged', src, bizId, g.grade)
    G.Notify(src, { type = 'info', title = b.label, text = 'Ton poste : ' .. g.label .. '.' })
    return true
end
exports('SetJob', function(src, bizId, grade) return Biz.SetJob(tonumber(src), bizId, grade) end)

-- Proximité ---------------------------------------------------------------------------------------------------------------------------
local function coordsOf(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return nil end
    return c
end
local function distance(a, b)
    local ca, cb = coordsOf(a), coordsOf(b)
    if not ca or not cb then return 0 end   -- lecture impossible (tests / hors jeu)
    local dx, dy, dz = ca.x - cb.x, ca.y - cb.y, ca.z - cb.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end
function Biz.Nearby(src, radius)
    local out = {}
    radius = radius or PB.Cfg.Get('biz', 'near_dist', 8)
    for id, p in pairs(G.Players()) do
        if id ~= src and PB.ToBool(p.row.created) and distance(src, id) <= radius then out[#out + 1] = { id = id, name = display(id), license = p.license } end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end
-- cible choisie par identifiant : doit être en ligne, créée, et proche
local function target(src, id, selfOk)
    id = tonumber(id)
    if not id then return nil, 'Choisis un joueur dans la liste.' end
    if id == src and not selfOk then return nil, 'Tu ne peux pas faire ça sur toi-même.' end
    local p = G.Get(id)
    if not p or not PB.ToBool(p.row.created) then return nil, "Ce joueur n'est pas disponible." end
    if id ~= src and distance(src, id) > PB.Cfg.Get('biz', 'near_dist', 8) + 2 then return nil, "Ce joueur est trop loin." end
    return p, nil, id
end

-- Dossiers, factures ----------------------------------------------------------------------------------------------------------------
local function record(c, lic, name, kind, text, amount)
    DB.exec('INSERT INTO pb_biz_records (biz_id, license, name, kind, text, amount, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', { c.biz.id, lic, name, kind, tostring(text):sub(1, 240), amount or 0, display(c.src), now() })
end
Biz.Record = record   -- aussi utilisé par le menu ALT (saisie d'un véhicule : inscrite au casier)
local function cleanText(s, n) return PB.Trim(PB.Sanitize(tostring(s or ''), n)) end

local function chargeInvoice(inv, payerSrc)
    local p = G.Get(payerSrc)
    if not p or p.license ~= inv.license then return false, 'Cette facture ne te concerne pas.' end
    if inv.status ~= 'pending' then return false, 'Facture déjà réglée ou annulée.' end
    local acc = G.Pay(payerSrc, inv.amount, 'bank')
    if not acc then return false, "Tu n'as pas assez d'argent." end
    DB.exec("UPDATE pb_biz_invoices SET status = 'paid', paid_at = ? WHERE id = ? AND status = 'pending'", { now(), inv.id })
    if inv.kind == 'fine' and PB.Cfg.Get('biz', 'fine_to', 'state') == 'state' then
        G.Eco.Book('state', inv.amount, 'Amende #' .. inv.id, p.license)
    else
        G.Eco.Book(acct(inv.biz_id), inv.amount, (inv.kind == 'fine' and 'Amende #' or 'Facture #') .. inv.id, p.license)
    end
    TriggerEvent('pb_panel:invoicePaid', inv.id, payerSrc, inv.biz_id, inv.amount, inv.kind)
    return true
end

function Biz.PayInvoice(src, id)
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { tonumber(id) or -1 })
    if not inv then return false, 'Facture introuvable.' end
    local ok, err = chargeInvoice(inv, src)
    if not ok then return false, err end
    G.PushState(src)
    return true, inv
end

-- Actions de la tablette --------------------------------------------------------------------------------------------------------------
local ACT = {}

ACT.duty = function(c, src, p)
    local on = p.on == true
    DB.exec('UPDATE pb_biz_members SET on_duty = ? WHERE license = ?', { on and 1 or 0, c.license })
    TriggerEvent('pb_panel:duty', src, c.biz.id, on)
    return true, on and 'Tu prends ton service.' or 'Tu quittes ton service.'
end

ACT.pay_invoice = function(_, src, p)
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { tonumber(p.id) or -1 })
    if not inv then return false, 'Facture introuvable.' end
    local ok, err = chargeInvoice(inv, src)
    if not ok then return false, err end
    G.PushState(src)
    return true, ('Facture réglée : %s.'):format(money(inv.amount))
end

ACT.transfer = function(_, src, p)
    local cfg = PB.Cfg.All('biz')
    if not cfg.allow_transfers then return false, 'Les virements sont désactivés.' end
    local amount = math.floor(tonumber(p.amount) or 0)
    if amount < 1 or amount > cfg.transfer_max then return false, ('Montant : 1 à %s.'):format(money(cfg.transfer_max)) end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local fee = math.floor(amount * (cfg.transfer_fee or 0) / 100 + 0.5)
    if G.GetMoney(src, 'bank') < amount + fee then return false, 'Solde bancaire insuffisant.' end
    G.RemoveMoney(src, 'bank', amount + fee)
    G.AddMoney(tid, 'bank', amount)
    if fee > 0 then G.Eco.Book('state', fee, 'Frais de virement', G.Get(src).license) end
    G.Notify(tid, { type = 'success', title = 'Virement reçu', text = ('%s de %s'):format(money(amount), display(src)) })
    G.PushState(src)
    return true, ('Virement de %s envoyé à %s.'):format(money(amount), display(tid))
end

ACT.hire = function(c, src, p)
    if not Biz.Can(c, 'hire') then return false, "Tu n'as pas le droit d'engager." end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    if Biz.MemberOf(tp.license) then return false, 'Cette personne a déjà un emploi.' end
    local first = DB.one('SELECT grade FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade LIMIT 1', { c.biz.id })
    local ok, e = Biz.SetJob(tid, c.biz.id, first and first.grade or 0)
    if not ok then return false, e end
    return true, display(tid) .. ' est engagé(e).'
end

local function memberAction(c, p, need)
    if not Biz.Can(c, need) then return nil, "Tu n'as pas ce droit." end
    local m = DB.one('SELECT * FROM pb_biz_members WHERE license = ? AND biz_id = ?', { tostring(p.license or ''), c.biz.id })
    if not m then return nil, 'Employé introuvable.' end
    if m.license == c.license then return nil, 'Tu ne peux pas le faire sur toi-même.' end
    local mg = Biz.Grade(c.biz.id, m.grade)
    if mg and PB.ToBool(mg.boss) and not c.boss then return nil, 'Seul un patron peut agir sur un patron.' end
    if mg and not c.boss and mg.grade >= c.grade.grade then return nil, 'Tu ne peux agir que sur un grade inférieur au tien.' end
    return m, nil, mg
end

ACT.fire = function(c, src, p)
    local m, err = memberAction(c, p, 'fire')
    if not m then return false, err end
    DB.exec('DELETE FROM pb_biz_members WHERE license = ?', { m.license })
    for id, pl in pairs(G.Players()) do if pl.license == m.license then TriggerClientEvent('pb:g:biz:job', id, 'null') G.Notify(id, { type = 'warn', title = c.biz.label, text = 'Tu as été renvoyé(e).' }) end end
    return true, m.name .. ' est renvoyé(e).'
end

local function shift(c, p, delta)
    local m, err, mg = memberAction(c, p, 'promote')
    if not m then return false, err end
    local ng = Biz.Grade(c.biz.id, m.grade + delta)
    if not ng then return false, delta > 0 and 'Déjà au grade maximum.' or 'Déjà au grade minimum.' end
    if delta > 0 and PB.ToBool(ng.boss) and not c.boss then return false, 'Seul un patron peut nommer un patron.' end
    if delta > 0 and not c.boss and ng.grade >= c.grade.grade then return false, 'Tu ne peux pas promouvoir au-delà de ton propre grade.' end
    DB.exec('UPDATE pb_biz_members SET grade = ? WHERE license = ?', { ng.grade, m.license })
    for id, pl in pairs(G.Players()) do if pl.license == m.license then G.Notify(id, { type = delta > 0 and 'success' or 'warn', title = c.biz.label, text = 'Nouveau grade : ' .. ng.label .. '.' }) end end
    return true, ('%s : %s.'):format(m.name, ng.label)
end
ACT.promote = function(c, _, p) return shift(c, p, 1) end
ACT.demote = function(c, _, p) return shift(c, p, -1) end

ACT.set_salary = function(c, _, p)
    if not c.boss then return false, 'Réservé au patron.' end
    local g = Biz.Grade(c.biz.id, p.grade)
    if not g then return false, 'Grade introuvable.' end
    local s = math.floor(tonumber(p.salary) or -1)
    if s < 0 or s > 20000 then return false, 'Salaire : 0 à 20 000 $.' end
    DB.exec('UPDATE pb_biz_grades SET salary = ? WHERE biz_id = ? AND grade = ?', { s, c.biz.id, g.grade })
    return true, ('Salaire de « %s » : %s.'):format(g.label, money(s))
end

ACT.deposit = function(c, src, p)
    if not Biz.Can(c, 'vault') then return false, "Tu n'as pas accès à la caisse." end
    local a = math.floor(tonumber(p.amount) or 0)
    if a < 1 or a > 10000000 then return false, 'Montant invalide.' end
    if not G.RemoveMoney(src, 'cash', a) then return false, "Tu n'as pas assez d'espèces." end
    G.Eco.Book(acct(c.biz.id), a, 'Dépôt', c.license)
    G.PushState(src)
    return true, ('%s déposés dans la caisse.'):format(money(a))
end

ACT.withdraw = function(c, src, p)
    if not Biz.Can(c, 'vault') then return false, "Tu n'as pas accès à la caisse." end
    local a = math.floor(tonumber(p.amount) or 0)
    if a < 1 or a > 10000000 then return false, 'Montant invalide.' end
    if G.Eco.Balance(acct(c.biz.id)) < a then return false, 'La caisse ne contient pas autant.' end
    G.Eco.Book(acct(c.biz.id), -a, 'Retrait', c.license)
    G.AddMoney(src, 'cash', a)
    G.PushState(src)
    return true, ('%s retirés de la caisse.'):format(money(a))
end

ACT.invoice = function(c, src, p)
    if not Biz.Allowed(c, 'invoice') then return false, "Tu n'as pas le droit de facturer." end
    if not c.duty then return false, 'Prends ton service pour facturer.' end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local a = math.floor(tonumber(p.amount) or 0)
    local max = PB.Cfg.Get('biz', 'max_invoice', 50000)
    if a < 1 or a > max then return false, ('Montant : 1 à %s.'):format(money(max)) end
    local reason = cleanText(p.reason, 120)
    if reason == '' then return false, 'Indique le motif de la facture.' end
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { c.biz.id, tp.license, display(tid), a, reason, 'invoice', 'pending', display(src), c.license, now() })
    G.Notify(tid, { type = 'info', title = 'Nouvelle facture — ' .. c.biz.label, text = ('%s : %s. Règle-la dans ta tablette > Factures.'):format(reason, money(a)), duration = 9000 })
    TriggerEvent('pb_panel:invoice', src, tid, c.biz.id, a, reason)
    return true, ('Facture de %s envoyée à %s.'):format(money(a), display(tid))
end

ACT.cancel_invoice = function(c, _, p)
    if not Biz.Can(c, 'invoice') then return false, "Tu n'as pas le droit." end
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ? AND biz_id = ?', { tonumber(p.id) or -1, c.biz.id })
    if not inv or inv.status ~= 'pending' then return false, 'Facture introuvable ou déjà réglée.' end
    if not c.boss and inv.by_license ~= c.license then return false, "Seul l'émetteur ou un patron peut annuler." end
    DB.exec("UPDATE pb_biz_invoices SET status = 'cancelled' WHERE id = ?", { inv.id })
    return true, 'Facture annulée.'
end

-- Police : amende (immédiate si le citoyen peut payer, sinon facture en attente) et notes au dossier
ACT.fine = function(c, src, p)
    if not Biz.Allowed(c, 'fine') then return false, "Tu n'as pas le droit d'infliger une amende." end
    if not c.duty then return false, 'Prends ton service pour verbaliser.' end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local amount, reason
    if p.code and tostring(p.code) ~= '' and tostring(p.code) ~= 'custom' then
        local f = DB.one('SELECT * FROM pb_fines WHERE code = ?', { tostring(p.code) })
        if not f then return false, "Cette infraction n'existe pas dans le catalogue." end
        amount, reason = G.Eco.Fine(f.amount), f.label
    else
        amount = math.floor(tonumber(p.amount) or 0)
        reason = cleanText(p.reason, 120)
        if reason == '' then return false, "Indique le motif de l'amende." end
    end
    local max = PB.Cfg.Get('biz', 'max_fine', 25000)
    if amount < 1 or amount > max then return false, ('Amende : 1 à %s.'):format(money(max)) end
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { c.biz.id, tp.license, display(tid), amount, reason, 'fine', 'pending', display(src), c.license, now() })
    record(c, tp.license, display(tid), 'fine', reason, amount)
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { id })
    local ok = chargeInvoice(inv, tid)
    G.Notify(tid, { type = 'warn', title = 'Amende', text = ('%s : %s%s'):format(reason, money(amount), ok and ' (prélevée sur ton compte)' or ' — à régler dans ta tablette > Factures'), duration = 9000 })
    G.PushState(tid)
    TriggerEvent('pb_panel:fine', src, tid, amount, reason)
    return true, ok and ('Amende de %s prélevée sur %s.'):format(money(amount), display(tid)) or ('Amende de %s enregistrée : %s doit la régler.'):format(money(amount), display(tid))
end

ACT.note = function(c, src, p)
    if not Biz.Allowed(c, 'records') then return false, "Tu n'as pas accès aux dossiers." end
    local tp, err, tid = target(src, p.id, true)
    if not tp then return false, err end
    local text = cleanText(p.text, 240)
    if text == '' then return false, 'La note est vide.' end
    record(c, tp.license, display(tid), 'note', text, 0)
    return true, 'Note ajoutée au dossier.'
end

-- EMS : réanimation d'un patient à proximité
ACT.revive = function(c, src, p)
    if not Biz.Allowed(c, 'revive') then return false, "Tu n'as pas le droit de réanimer." end
    if not c.duty then return false, 'Prends ton service pour intervenir.' end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    if not PB.ToBool(tp.row.dead) then return false, "Cette personne n'a pas besoin de réanimation." end
    G.Revive(tid)
    record(c, tp.license, display(tid), 'care', 'Réanimation', 0)
    G.Notify(tid, { type = 'success', title = c.biz.label, text = 'Tu as été réanimé(e) par ' .. display(src) .. '.' })
    TriggerEvent('pb_panel:revivedBy', src, tid)
    return true, display(tid) .. ' est réanimé(e).'
end

-- Garage : réparer le véhicule du client à proximité (le client du mécanicien exécute la réparation sur le véhicule le plus proche)
local lastRepair = {}
ACT.repair = function(c, src, p)
    if not Biz.Allowed(c, 'repair') then return false, "Tu n'as pas le droit de réparer." end
    if not c.duty then return false, 'Prends ton service pour réparer.' end
    local t = now()
    if lastRepair[src] and t - lastRepair[src] < 8 then return false, 'Attends quelques secondes entre deux réparations.' end
    lastRepair[src] = t
    TriggerClientEvent('pb:g:biz:repair', src)
    return true, 'Réparation du véhicule le plus proche en cours.'
end

-- Pages -------------------------------------------------------------------------------------------------------------------------------
local PAGES = {}
Biz.PAGES, Biz.ACT, Biz.Target, Biz.Record, Biz.Display, Biz.Clean = PAGES, ACT, target, record, display, cleanText
Biz.ExtraSettings = {}   -- formulaires de réglages ajoutés par d'autres modules (police, métiers civils…)
Biz.NavAllow = {}   -- id de page -> function(c) : peut-on voir cette page ? (pour les modules qui ajoutent des pages)
local function stat(title, value, icon, tone, sub, extra) local t = { title = title, value = value, icon = icon, tone = tone, sub = sub } for k, v in pairs(extra or {}) do t[k] = v end return t end

local function nearOptions(src, withSelf)
    local opts = {}
    for _, n in ipairs(Biz.Nearby(src)) do opts[#opts + 1] = { tostring(n.id), n.name .. ' (' .. n.id .. ')' } end
    if withSelf then opts[#opts + 1] = { tostring(src), 'Moi-même (' .. src .. ')' } end
    return opts
end

local bizHome
PAGES.home = function(src)
    local p = G.Get(src)
    local r = p.row
    local c = Biz.Ctx(src)
    if c then return bizHome(src) end   -- employé : uniquement l'entreprise (rien de perso)
    local unpaid = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE license = ? AND status = 'pending'", { p.license })
    local name = display(src)
    local job = c and (c.biz.label .. ' · ' .. c.grade.label) or 'Sans emploi'
    local cards = {
        stat('Compte bancaire', money(r.bank), 'card', '#6fb4ff', 'Solde disponible'),
        stat('Argent liquide', money(r.cash), 'coins', '#7be0a4', 'Espèces sur toi'),
        stat('Factures', tostring(unpaid and unpaid.n or 0), 'file', '#ffb457', (unpaid and unpaid.n or 0) > 0 and (money(unpaid.s) .. ' à régler') or 'Aucune facture en attente'),
        stat('Emploi actuel', c and c.biz.label or 'Sans emploi', 'briefcase', c and c.biz.color or '#9aa3b2', c and (c.grade.label .. (c.duty and ' · en service' or ' · hors service')) or ("Allocation : " .. money(math.floor((G.Eco.Get('unemployed_allowance') or 0) * 1)))),
    }
    local blocks = { { type = 'hero', eyebrow = 'Espace ' .. (c and 'professionnel' or 'citoyen') .. ' · accès sécurisé', title = 'Tableau de bord citoyen', sub = "Retrouve en un coup d'œil ta situation, tes finances, tes factures et les services disponibles en ville.", chips = { { 'Statut', 'Actif' }, { 'ID', tostring(src) }, { 'Emploi', c and c.biz.label or 'aucun' } } },
        { type = 'cards', items = cards },
        { type = 'tiles', title = 'Accès rapides', tag = 'Services citoyens', items = {
            { title = 'Finances', sub = 'Comptes et soldes', icon = 'card', page = 'finance' }, { title = 'Factures', sub = 'Paiements en attente', icon = 'file', page = 'invoices' },
            { title = 'Entreprises', sub = 'Services disponibles', icon = 'building', page = 'directory' }, { title = 'Profil', sub = 'Informations personnelles', icon = 'user', page = 'profile' } } } }
    if c then
        local d = 'Prendre mon service'
        blocks[#blocks + 1] = { type = 'actions', title = 'Mon poste', items = { { act = 'duty', label = c.duty and 'Quitter le service' or 'Prendre mon service', payload = { on = not c.duty }, icon = 'power', primary = not c.duty } } }
    end
    return blocks, 'Bonjour, ' .. name .. '.'
end

PAGES.finance = function(src)
    local p = G.Get(src)
    local cfg = PB.Cfg.All('biz')
    local blocks = { { type = 'cards', items = { stat('Compte bancaire', money(p.row.bank), 'card', '#6fb4ff', 'Solde disponible'), stat('Argent liquide', money(p.row.cash), 'coins', '#7be0a4', 'Espèces sur toi') } } }
    if cfg.allow_transfers then
        blocks[#blocks + 1] = { type = 'form', id = 'transfer', title = 'Virement bancaire', desc = (cfg.transfer_fee or 0) > 0 and ('Frais : ' .. cfg.transfer_fee .. ' %') or 'Sans frais.', fields = {
            { k = 'id', type = 'select', label = 'Destinataire (à proximité)', opts = nearOptions(src) }, { k = 'amount', type = 'number', label = 'Montant', min = 1, max = cfg.transfer_max } },
            submit = { act = 'transfer', label = 'Envoyer' } }
    end
    return blocks, 'Finances'
end

PAGES.invoices = function(src)
    local p = G.Get(src)
    local rows = {}
    for _, i in ipairs(DB.q('SELECT i.*, b.label AS blabel FROM pb_biz_invoices i LEFT JOIN pb_biz b ON b.id = i.biz_id WHERE i.license = ? ORDER BY i.id DESC LIMIT 40', { p.license }) or {}) do
        rows[#rows + 1] = { from = i.blabel or i.biz_id, reason = i.reason, amount = money(i.amount), kind = i.kind == 'fine' and 'Amende' or 'Facture', status = ({ pending = 'À régler', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status,
            actions = i.status == 'pending' and { { act = 'pay_invoice', label = 'Payer', payload = { id = i.id }, primary = true } } or nil }
    end
    return { { type = 'table', title = 'Mes factures et amendes', columns = { { k = 'from', label = 'Émetteur' }, { k = 'kind', label = 'Type' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant' }, { k = 'status', label = 'Statut' } }, rows = rows, empty = 'Aucune facture. Profites-en !' } }, 'Factures'
end

PAGES.directory = function(src)
    local items = {}
    for _, b in ipairs(Biz.List()) do
        if PB.ToBool(b.enabled) then
            local n = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { b.id })
            items[#items + 1] = { title = b.label, sub = KIND_LABEL[b.kind] or 'Entreprise', icon = b.icon, tone = b.color, badge = PB.ToBool(b.hiring) and 'Recrute' or nil, text = b.description, stats = { { label = 'Employés', value = tostring(n and n.n or 0) } } }
        end
    end
    return { { type = 'cards', big = true, items = items }, #items == 0 and { type = 'notice', text = "Aucune entreprise pour le moment." } or nil }, 'Entreprises'
end

PAGES.profile = function(src)
    local i = G.Identity(src) or {}
    return { { type = 'hero', title = display(src), sub = 'Carte d\'identité', chips = { { 'Naissance', tostring(i.dob or '—') }, { 'Taille', tostring(i.height or '—') .. ' cm' }, { 'Nationalité', tostring(i.nationality or '—') }, { 'Sexe', i.sex == 'f' and 'Femme' or 'Homme' } } } }, 'Mon profil'
end

-- Pages d'entreprise
function bizHome(src)
    local c = Biz.Ctx(src)
    local acc = acct(c.biz.id)
    local members = Biz.Members(c.biz.id)
    local online, duty = 0, 0
    for _, m in ipairs(members) do for _, pl in pairs(G.Players()) do if pl.license == m.license then online = online + 1 if PB.ToBool(m.on_duty) then duty = duty + 1 end end end end
    local pend = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'pending'", { c.biz.id })
    local week = DB.one("SELECT COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'paid' AND paid_at >= ?", { c.biz.id, now() - 7 * 86400 })
    local bal = G.Eco.Balance(acc)
    local cards = {
        stat('Caisse', money(bal), 'coins', c.biz.color, 'Compte de l\'entreprise'),
        stat('Employés', tostring(#members), 'users', '#6fb4ff', ('%d en ligne · %d en service'):format(online, duty)),
        stat('Factures en attente', tostring(pend and pend.n or 0), 'file', '#ffb457', money(pend and pend.s or 0) .. ' à encaisser'),
        stat('Encaissé (7 jours)', money(week and week.s or 0), 'chart', '#7be0a4', 'Factures et amendes réglées'),
    }
    if c.biz.kind == 'police' or c.biz.kind == 'ems' then
        local calls = DB.one("SELECT COUNT(*) AS n FROM pb_calls WHERE status <> 'closed'")
        cards[#cards + 1] = stat('Appels ouverts', tostring(calls and calls.n or 0), 'siren', '#ffb457', 'À traiter par les unités')
        if c.biz.kind == 'police' then
            local jl = DB.one('SELECT COUNT(*) AS n FROM pb_jail')
            local fines = DB.one("SELECT COUNT(*) AS n FROM pb_biz_records WHERE biz_id = ? AND kind = 'fine' AND at >= ?", { c.biz.id, now() - 7 * 86400 })
            cards[#cards + 1] = stat('Détenus', tostring(jl and jl.n or 0), 'shield', '#ff6b7d', 'Prison et TIG')
            cards[#cards + 1] = stat('Amendes (7 jours)', tostring(fines and fines.n or 0), 'file', '#6fb4ff', 'Verbalisations du service')
        end
    end
    local mine = c.grade.salary * (G.Eco.Get('income_mult') or 1)
    local tax = mine * (G.Eco.Get('tax_income') or 0) / 100
    local blocks = { { type = 'hero', title = c.biz.label, sub = c.biz.description ~= '' and c.biz.description or (KIND_LABEL[c.biz.kind] or ''), chips = { { 'Mon grade', c.grade.label }, { 'Service', c.duty and 'En service' or 'Hors service' }, { 'Paie nette', money(mine - tax) .. ' / ' .. (G.Eco.Get('paycheck_interval') or 15) .. ' min' } }, tone = c.biz.color },
        { type = 'cards', items = cards },
        { type = 'actions', title = 'Mon service', items = { { act = 'duty', label = c.duty and 'Quitter le service' or 'Prendre mon service', payload = { on = not c.duty }, icon = 'power', primary = not c.duty } } } }
    if Biz.Allowed(c, 'repair') then blocks[#blocks + 1] = { type = 'actions', title = 'Atelier', items = { { act = 'repair', label = 'Réparer le véhicule le plus proche', icon = 'engine', primary = true } } } end
    return blocks, c.biz.label
end
PAGES.biz = function(src) if not Biz.Ctx(src) then return nil end return bizHome(src) end

PAGES.staff = function(src)
    local c = Biz.Ctx(src)
    if not c or not (Biz.Can(c, 'hire') or Biz.Can(c, 'fire') or Biz.Can(c, 'promote')) then return nil end
    local rows = {}
    local online = {}
    for id, pl in pairs(G.Players()) do online[pl.license] = id end
    for _, m in ipairs(Biz.Members(c.biz.id)) do
        local g = Biz.Grade(c.biz.id, m.grade)
        local acts = {}
        if m.license ~= c.license then
            if Biz.Can(c, 'promote') then acts[#acts + 1] = { act = 'promote', label = 'Promouvoir', payload = { license = m.license } } acts[#acts + 1] = { act = 'demote', label = 'Rétrograder', payload = { license = m.license } } end
            if Biz.Can(c, 'fire') then acts[#acts + 1] = { act = 'fire', label = 'Renvoyer', payload = { license = m.license }, danger = true, confirm = 'Renvoyer ' .. m.name .. ' ?' } end
        end
        rows[#rows + 1] = { name = m.name, grade = g and g.label or m.grade, state = online[m.license] and (PB.ToBool(m.on_duty) and 'En service' or 'En ligne') or 'Hors ligne', salary = g and money(g.salary) or '—', actions = acts }
    end
    local blocks = { { type = 'table', title = 'Employés', columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'state', label = 'Statut' }, { k = 'salary', label = 'Salaire' } }, rows = rows, empty = 'Aucun employé.' } }
    if Biz.Can(c, 'hire') then
        local opts = {}
        for _, n in ipairs(Biz.Nearby(src)) do if not Biz.MemberOf(n.license) then opts[#opts + 1] = { tostring(n.id), n.name .. ' (' .. n.id .. ')' } end end
        blocks[#blocks + 1] = { type = 'form', id = 'hire', title = 'Engager quelqu\'un', desc = 'Seules les personnes sans emploi, à proximité, apparaissent ici.', fields = { { k = 'id', type = 'select', label = 'Personne', opts = opts } }, submit = { act = 'hire', label = 'Engager', disabled = #opts == 0 } }
    end
    return blocks, 'Employés'
end

PAGES.grades = function(src)
    local c = Biz.Ctx(src)
    if not c or not c.boss then return nil end
    local items = {}
    for _, g in ipairs(Biz.Grades(c.biz.id)) do
        items[#items + 1] = { title = g.label, sub = 'Grade ' .. g.grade .. (PB.ToBool(g.boss) and ' · patron' or ''), icon = PB.ToBool(g.boss) and 'crown' or 'user', tone = c.biz.color, value = money(g.salary), text = 'Droits : ' .. (PB.ToBool(g.boss) and 'tous' or (g.perms ~= '' and g.perms or 'aucun')) }
    end
    local opts = {}
    for _, g in ipairs(Biz.Grades(c.biz.id)) do opts[#opts + 1] = { tostring(g.grade), g.label } end
    return { { type = 'cards', items = items }, { type = 'form', id = 'salary', title = 'Modifier un salaire', desc = ("Salaire de base par paie, avant le multiplicateur de l'économie (×%s) et l'impôt."):format(tostring(G.Eco.Get('income_mult'))),
        fields = { { k = 'grade', type = 'select', label = 'Grade', opts = opts }, { k = 'salary', type = 'number', label = 'Salaire', min = 0, max = 20000 } }, submit = { act = 'set_salary', label = 'Enregistrer' } } }, 'Grades et salaires'
end

PAGES.vault = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'vault') then return nil end
    local rows = {}
    for _, r in ipairs(DB.q('SELECT at, delta, reason FROM pb_ledger WHERE account = ? ORDER BY id DESC LIMIT 30', { acct(c.biz.id) }) or {}) do rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at), delta = (r.delta > 0 and '+' or '') .. money(r.delta), reason = r.reason } end
    return { { type = 'cards', items = { stat('Caisse', money(G.Eco.Balance(acct(c.biz.id))), 'coins', c.biz.color, 'Compte de l\'entreprise') } },
        { type = 'form', id = 'dep', title = 'Déposer des espèces', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 10000000 } }, submit = { act = 'deposit', label = 'Déposer' } },
        { type = 'form', id = 'wd', title = 'Retirer des espèces', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 10000000 } }, submit = { act = 'withdraw', label = 'Retirer' } },
        { type = 'table', title = 'Mouvements récents', columns = { { k = 'at', label = 'Date' }, { k = 'delta', label = 'Montant' }, { k = 'reason', label = 'Motif' } }, rows = rows, empty = 'Aucun mouvement.' } }, 'Caisse'
end

PAGES.bills = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'invoice') then return nil end
    local rows = {}
    for _, i in ipairs(DB.q('SELECT * FROM pb_biz_invoices WHERE biz_id = ? ORDER BY id DESC LIMIT 40', { c.biz.id }) or {}) do
        rows[#rows + 1] = { who = i.name, reason = i.reason, amount = money(i.amount), by = i.by_name, status = ({ pending = 'En attente', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status,
            actions = i.status == 'pending' and { { act = 'cancel_invoice', label = 'Annuler', payload = { id = i.id }, danger = true } } or nil }
    end
    local blocks = {}
    if Biz.Allowed(c, 'invoice') then
        blocks[#blocks + 1] = { type = 'form', id = 'inv', title = 'Nouvelle facture', desc = c.duty and 'Choisis un client à proximité.' or 'Prends ton service pour facturer.', fields = {
            { k = 'id', type = 'select', label = 'Client (à proximité)', opts = nearOptions(src) }, { k = 'amount', type = 'number', label = 'Montant', min = 1, max = PB.Cfg.Get('biz', 'max_invoice', 50000) }, { k = 'reason', type = 'text', label = 'Motif', maxlen = 120 } },
            submit = { act = 'invoice', label = 'Envoyer la facture' } }
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Factures émises', columns = { { k = 'who', label = 'Client' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant' }, { k = 'by', label = 'Par' }, { k = 'status', label = 'Statut' } }, rows = rows, empty = 'Aucune facture émise.' }
    return blocks, 'Factures émises'
end

PAGES.citizens = function(src)
    local c = Biz.Ctx(src)
    if not c or not (Biz.Allowed(c, 'fine') or Biz.Allowed(c, 'records')) then return nil end
    local blocks = {}
    if Biz.Allowed(c, 'fine') then
        local codes = { { 'custom', 'Autre (montant libre)' } }
        for _, f in ipairs(DB.q('SELECT code, label, amount FROM pb_fines ORDER BY category, label') or {}) do codes[#codes + 1] = { f.code, ('%s — %s'):format(f.label, money(G.Eco.Fine(f.amount))) } end
        blocks[#blocks + 1] = { type = 'form', id = 'fine', title = 'Infliger une amende', desc = c.duty and "Le montant du catalogue tient compte du multiplicateur d'amendes de l'économie." or 'Prends ton service pour verbaliser.', fields = {
            { k = 'id', type = 'select', label = 'Citoyen (à proximité)', opts = nearOptions(src) }, { k = 'code', type = 'select', label = 'Infraction', opts = codes },
            { k = 'amount', type = 'number', label = 'Montant (si libre)', min = 0, max = PB.Cfg.Get('biz', 'max_fine', 25000) }, { k = 'reason', type = 'text', label = 'Motif (si libre)', maxlen = 120 } },
            submit = { act = 'fine', label = 'Verbaliser' } }
    end
    if Biz.Allowed(c, 'records') then
        blocks[#blocks + 1] = { type = 'form', id = 'note', title = 'Ajouter une note au dossier', fields = { { k = 'id', type = 'select', label = 'Citoyen (à proximité)', opts = nearOptions(src, true) }, { k = 'text', type = 'text', label = 'Note', maxlen = 240 } }, submit = { act = 'note', label = 'Ajouter' } }
        local rows = {}
        for _, r in ipairs(DB.q('SELECT * FROM pb_biz_records WHERE biz_id = ? ORDER BY id DESC LIMIT 40', { c.biz.id }) or {}) do
            rows[#rows + 1] = { who = r.name, kind = ({ fine = 'Amende', note = 'Note', care = 'Soin', repair = 'Réparation', cuff = 'Arrestation', search = 'Fouille', seize = 'Saisie' })[r.kind] or r.kind, text = r.text, amount = r.amount > 0 and money(r.amount) or '', by = r.by_name, at = os.date('%d/%m %H:%M', r.at) }
        end
        blocks[#blocks + 1] = { type = 'table', title = 'Dossiers récents', columns = { { k = 'at', label = 'Date' }, { k = 'who', label = 'Citoyen' }, { k = 'kind', label = 'Type' }, { k = 'text', label = 'Détail' }, { k = 'amount', label = 'Montant' }, { k = 'by', label = 'Par' } }, rows = rows, empty = 'Aucun dossier.' }
    end
    return blocks, c.biz.kind == 'police' and 'Citoyens et amendes' or 'Dossiers'
end
PAGES.patients = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Allowed(c, 'revive') then return nil end
    local rows = {}
    for _, n in ipairs(Biz.Nearby(src, 30)) do
        local pl = G.Get(n.id)
        local dead = pl and PB.ToBool(pl.row.dead)
        rows[#rows + 1] = { name = n.name, state = dead and 'À terre' or 'Conscient', dist = math.floor(distance(src, n.id)) .. ' m', actions = dead and { { act = 'revive', label = 'Réanimer', payload = { id = n.id }, primary = true } } or nil }
    end
    local dead = 0
    for _, pl in pairs(G.Players()) do if PB.ToBool(pl.row.dead) then dead = dead + 1 end end
    return { { type = 'cards', items = { stat('Patients à terre', tostring(dead), 'heart', '#ff6b7d', 'Sur tout le serveur') } },
        { type = 'table', title = 'Personnes à proximité (30 m)', columns = { { k = 'name', label = 'Nom' }, { k = 'state', label = 'État' }, { k = 'dist', label = 'Distance' } }, rows = rows, empty = 'Personne à proximité.' } }, 'Patients'
end

-- Pages complémentaires : équipe, journal, statistiques, annonces, paie, règlement, lieux ------------------------------------------------
PB.Migrate('190_biz_news', 'Annonces internes des entreprises', {
    [[CREATE TABLE IF NOT EXISTS pb_biz_news (id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, text VARCHAR(240) NOT NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_biz (biz_id))]],
})
local function isOnline(license) for src, pl in pairs(G.Players()) do if pl.license == license then return src end end end
Biz.NavAllow.team = function(c) return true end
Biz.NavAllow.news = function(c) return true end
Biz.NavAllow.rules = function(c) return true end
Biz.NavAllow.places = function(c) return true end
Biz.NavAllow.journal = function(c) return Biz.Can(c, 'vault') end
Biz.NavAllow.stats = function(c) return Biz.Can(c, 'vault') end
Biz.NavAllow.payroll = function(c) return c.boss == true end

PAGES.team = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local rows, online, duty = {}, 0, 0
    for _, m in ipairs(Biz.Members(c.biz.id)) do
        local on = isOnline(m.license)
        if on then online = online + 1 end
        if PB.ToBool(m.on_duty) then duty = duty + 1 end
        local g = Biz.Grade(c.biz.id, m.grade)
        rows[#rows + 1] = { name = m.name, grade = g and g.label or tostring(m.grade), state = PB.ToBool(m.on_duty) and 'En service' or (on and 'En ligne' or 'Hors ligne'), since = os.date('%d/%m/%Y', m.hired_at or 0) }
    end
    return { { type = 'cards', items = { stat('Effectif', tostring(#rows), 'users', c.biz.color, 'Employés au total'), stat('En ligne', tostring(online), 'user', '#6fb4ff', 'Connectés maintenant'), stat('En service', tostring(duty), 'power', '#7be0a4', 'Services pris') } },
        { type = 'table', title = "Équipe de l'entreprise", search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'state', label = 'État', type = 'badge' }, { k = 'since', label = 'Embauché le' } }, rows = rows, empty = 'Aucun employé.' } }, 'Équipe'
end

PAGES.journal = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'vault') then return nil end
    local rows = {}
    for _, i in ipairs(DB.q('SELECT * FROM pb_biz_invoices WHERE biz_id = ? ORDER BY id DESC LIMIT 40', { c.biz.id }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', i.at or 0), kind = i.kind == 'fine' and 'Amende' or 'Facture', who = i.name, by = i.by_name, amount = money(i.amount), status = ({ pending = 'En attente', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status, t = i.at or 0 }
    end
    for _, r in ipairs(DB.q('SELECT * FROM pb_biz_records WHERE biz_id = ? ORDER BY id DESC LIMIT 20', { c.biz.id }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at or 0), kind = 'Dossier', who = r.name, by = r.by_name, amount = r.amount > 0 and money(r.amount) or '', status = r.text, t = r.at or 0 }
    end
    table.sort(rows, function(a, b) return a.t > b.t end)
    return { { type = 'table', title = "Journal d'activité", search = true, columns = { { k = 'at', label = 'Date' }, { k = 'kind', label = 'Type' }, { k = 'who', label = 'Client' }, { k = 'by', label = 'Par' }, { k = 'amount', label = 'Montant' }, { k = 'status', label = 'Détail' } }, rows = rows, empty = 'Aucune activité.' } }, 'Journal'
end

PAGES.stats = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'vault') then return nil end
    local day = 86400
    local rows, total = {}, 0
    for d = 0, 6 do
        local from, to = now() - (d + 1) * day, now() - d * day
        local r = DB.one("SELECT COALESCE(SUM(amount), 0) AS s, COUNT(*) AS n FROM pb_biz_invoices WHERE biz_id = ? AND status = 'paid' AND paid_at >= ? AND paid_at < ?", { c.biz.id, from, to })
        total = total + (r and tonumber(r.s) or 0)
        rows[#rows + 1] = { day = d == 0 and "Dernières 24 h" or ('Il y a ' .. d .. ' j'), n = tostring(r and r.n or 0), amount = money(r and r.s or 0) }
    end
    local top = {}
    for _, r in ipairs(DB.q("SELECT by_name, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'paid' GROUP BY by_name ORDER BY s DESC LIMIT 10", { c.biz.id }) or {}) do
        top[#top + 1] = { name = r.by_name, n = tostring(r.n), amount = money(r.s) }
    end
    local pend = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'pending'", { c.biz.id })
    return { { type = 'cards', items = { stat('Encaissé (7 jours)', money(total), 'chart', '#7be0a4', 'Factures et amendes réglées'), stat('En attente', money(pend and pend.s or 0), 'file', '#ffb457', (pend and pend.n or 0) .. ' facture(s)'), stat('Caisse', money(G.Eco.Balance(acct(c.biz.id))), 'coins', c.biz.color, 'Compte de l\'entreprise') } },
        { type = 'table', title = 'Encaissements par jour', columns = { { k = 'day', label = 'Période' }, { k = 'n', label = 'Paiements' }, { k = 'amount', label = 'Montant' } }, rows = rows },
        { type = 'table', title = 'Meilleurs employés (encaissé)', columns = { { k = 'name', label = 'Employé' }, { k = 'n', label = 'Paiements' }, { k = 'amount', label = 'Montant' } }, rows = top, empty = 'Aucun paiement.' } }, 'Statistiques'
end

PAGES.news = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local rows = {}
    for _, n in ipairs(DB.q('SELECT * FROM pb_biz_news WHERE biz_id = ? ORDER BY id DESC LIMIT 20', { c.biz.id }) or {}) do rows[#rows + 1] = { at = os.date('%d/%m %H:%M', n.at or 0), by = n.by_name, text = n.text } end
    local blocks = {}
    if Biz.Can(c, 'promote') then
        blocks[#blocks + 1] = { type = 'form', id = 'news', title = 'Publier une annonce', desc = "Elle s'affiche à tous les employés connectés et reste dans la liste.", fields = { { k = 'text', type = 'text', label = 'Message', maxlen = 240 } }, submit = { act = 'announce', label = 'Publier' } }
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Annonces', columns = { { k = 'at', label = 'Date' }, { k = 'by', label = 'Par' }, { k = 'text', label = 'Message' } }, rows = rows, empty = 'Aucune annonce.' }
    return blocks, 'Annonces'
end
ACT.announce = function(c, src, p)
    if not Biz.Can(c, 'promote') then return false, 'Réservé à la direction.' end
    local text = tostring(p.text or ''):gsub('[%c<>]', ''):sub(1, 240)
    if #text < 3 then return false, 'Message trop court.' end
    DB.exec('INSERT INTO pb_biz_news (biz_id, text, by_name, at) VALUES (?, ?, ?, ?)', { c.biz.id, text, display(src), now() })
    for _, m in ipairs(Biz.Members(c.biz.id)) do
        local on = isOnline(m.license)
        if on then G.Notify(on, { type = 'info', title = c.biz.label, text = text, duration = 9000 }) end
    end
    PB.Audit.Log('serveur', 'biz.announce', src, c.biz.id, nil, nil, { text = text })
    return true, 'Annonce publiée.'
end

PAGES.payroll = function(src)
    local c = Biz.Ctx(src)
    if not c or not c.boss then return nil end
    local mult = G.Eco.Get('income_mult') or 1
    local members = Biz.Members(c.biz.id)
    local per, rows, total = {}, {}, 0
    for _, m in ipairs(members) do per[m.grade] = (per[m.grade] or 0) + 1 end
    for _, g in ipairs(Biz.Grades(c.biz.id)) do
        local n = per[g.grade] or 0
        local sub = n * g.salary * mult
        total = total + sub
        rows[#rows + 1] = { grade = g.label, n = tostring(n), salary = money(g.salary * mult), total = money(sub) }
    end
    local interval = G.Eco.Get('paycheck_interval') or 15
    return { { type = 'cards', items = { stat('Masse salariale', money(total), 'coins', c.biz.color, ('par paie, toutes les %s min'):format(tostring(interval))), stat('Caisse', money(G.Eco.Balance(acct(c.biz.id))), 'bank', '#7be0a4', c.biz.pay_from == 'biz' and "Paie prélevée sur la caisse" or "Paie versée par l'État"),
            stat('Employés', tostring(#members), 'users', '#6fb4ff', 'Payés selon leur grade') } },
        { type = 'table', title = 'Paie par grade (avant impôt)', columns = { { k = 'grade', label = 'Grade' }, { k = 'n', label = 'Employés' }, { k = 'salary', label = 'Salaire' }, { k = 'total', label = 'Total' } }, rows = rows } }, 'Paie'
end

PAGES.rules = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local PERM = { hire = 'Engager', fire = 'Renvoyer', promote = 'Promouvoir', vault = 'Caisse', invoice = 'Facturer', fine = 'Amendes', revive = 'Réanimer', repair = 'Réparer', records = 'Dossiers', cuff = 'Menotter', search = 'Fouiller', seize = 'Saisir', jail = 'Prison', dispatch = 'Appels' }
    local rows = {}
    for _, g in ipairs(Biz.Grades(c.biz.id)) do
        local list = {}
        if g.boss then list[1] = 'Tous les droits' else for _, k in ipairs(ALL_PERMS) do if g.perms and tostring(g.perms):find(k, 1, true) then list[#list + 1] = PERM[k] end end end
        rows[#rows + 1] = { grade = g.label, salary = money(g.salary), perms = #list > 0 and table.concat(list, ', ') or 'Service de base' }
    end
    local kind = c.biz.kind
    local TIPS = { police = "Prends ton service avant d'agir. Toute amende, fouille ou saisie est consignée dans les dossiers.", ems = 'Prends ton service. Réanime les patients à terre, tout soin est consigné dans les dossiers.', garage = 'Prends ton service pour facturer. Répare les véhicules à proximité.', generic = "Prends ton service pour facturer tes clients. Le patron gère les grades et la caisse." }
    return { { type = 'notice', text = TIPS[kind] or TIPS.generic }, { type = 'table', title = 'Grades, salaires et droits', columns = { { k = 'grade', label = 'Grade' }, { k = 'salary', label = 'Salaire' }, { k = 'perms', label = 'Droits' } }, rows = rows } }, 'Règlement'
end

PAGES.places = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local KIND = { hq = 'Siège', duty = 'Prise de service', boss = 'Bureau du patron', stash = 'Coffre', garage = 'Garage', wardrobe = 'Vestiaire' }
    local rows = {}
    for _, pt in ipairs(G.Points and G.Points.Of('biz', c.biz.id) or {}) do
        rows[#rows + 1] = { name = pt.label ~= '' and pt.label or (KIND[pt.kind] or pt.kind), kind = KIND[pt.kind] or pt.kind, actions = { { label = 'GPS', act = 'gps', payload = { id = pt.id }, icon = 'pin' } } }
    end
    return { { type = 'table', title = "Lieux de l'entreprise", columns = { { k = 'name', label = 'Lieu' }, { k = 'kind', label = 'Type' } }, rows = rows, empty = "Aucun lieu n'est placé (Carte du jeu, dans le panel)." } }, 'Lieux'
end
ACT.gps = function(c, src, p)
    local pt = DB.one("SELECT x, y, label, owner FROM pb_points WHERE id = ? AND owner_kind = 'biz'", { math.floor(tonumber(p.id) or 0) })
    if not pt or pt.owner ~= c.biz.id then return false, 'Lieu inconnu.' end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = pt.x, y = pt.y, label = pt.label }))
    return true, 'Position marquée sur ta carte.'
end

local PAGE_META = {
    home = { label = 'Accueil', icon = 'home', group = 'Citoyen' }, finance = { label = 'Finances', icon = 'card', group = 'Citoyen' }, invoices = { label = 'Factures', icon = 'file', group = 'Citoyen' },
    directory = { label = 'Entreprises', icon = 'building', group = 'Citoyen' }, profile = { label = 'Mon profil', icon = 'user', group = 'Citoyen' },
    biz = { label = 'Mon entreprise', icon = 'briefcase', group = 'Entreprise' }, staff = { label = 'Employés', icon = 'users', group = 'Entreprise' }, grades = { label = 'Grades et salaires', icon = 'crown', group = 'Entreprise' },
    vault = { label = 'Caisse', icon = 'coins', group = 'Entreprise' }, bills = { label = 'Factures émises', icon = 'file', group = 'Entreprise' },
    citizens = { label = 'Citoyens', icon = 'shield', group = 'Entreprise' }, patients = { label = 'Patients', icon = 'heart', group = 'Entreprise' },
    team = { label = 'Équipe', icon = 'users', group = 'Entreprise' }, news = { label = 'Annonces', icon = 'chat', group = 'Entreprise' }, journal = { label = 'Journal', icon = 'file', group = 'Entreprise' },
    stats = { label = 'Statistiques', icon = 'chart', group = 'Entreprise' }, payroll = { label = 'Paie', icon = 'coins', group = 'Entreprise' }, rules = { label = 'Règlement', icon = 'book', group = 'Entreprise' }, places = { label = 'Lieux', icon = 'pin', group = 'Entreprise' },
}
local ORDER = { 'home', 'finance', 'invoices', 'directory', 'profile', 'biz', 'staff', 'grades', 'vault', 'bills', 'citizens', 'patients', 'team', 'news', 'stats', 'journal', 'payroll', 'rules', 'places' }
Biz.PAGE_META, Biz.ORDER = PAGE_META, ORDER

-- Gestion (menu boss) : seulement au bureau du patron (point « boss » posé au Builder), plus depuis la tablette n'importe où
local BOSS_PAGES = { staff = true, grades = true, vault = true, payroll = true, journal = true, stats = true }
local BOSS_ACTS = { hire = true, fire = true, promote = true, demote = true, set_salary = true, deposit = true, withdraw = true }
Biz.BOSS_PAGES, Biz.BOSS_ACTS = BOSS_PAGES, BOSS_ACTS
function Biz.AtBoss(src, c)
    c = c or Biz.Ctx(src)
    if not c then return false end
    return not (G.Points and G.Points.AtBoss) or G.Points.AtBoss(src, 'biz', c.biz.id)
end
local BOSS_MSG = "Gestion de l'entreprise : rends-toi au bureau du patron."

local function navFor(src)
    local c = Biz.Ctx(src)
    local atBoss = c and Biz.AtBoss(src, c)
    local nav = {}
    for _, id in ipairs(ORDER) do
        local m = PAGE_META[id]
        local ok = true
        local grp = m.group
        if c and (id == 'finance' or id == 'invoices' or id == 'directory' or id == 'profile' or id == 'biz') then ok = false   -- perso et doublon de l'accueil
        elseif id == 'home' and c then grp = 'Entreprise'
        elseif id == 'biz' then ok = c ~= nil
        elseif id == 'staff' then ok = c ~= nil and (Biz.Can(c, 'hire') or Biz.Can(c, 'fire') or Biz.Can(c, 'promote'))
        elseif id == 'grades' then ok = c ~= nil and c.boss
        elseif id == 'vault' then ok = c ~= nil and Biz.Can(c, 'vault')
        elseif id == 'bills' then ok = c ~= nil and Biz.Can(c, 'invoice')
        elseif id == 'citizens' then ok = c ~= nil and (Biz.Allowed(c, 'fine') or Biz.Allowed(c, 'records'))
        elseif id == 'patients' then ok = c ~= nil and Biz.Allowed(c, 'revive')
        elseif Biz.NavAllow[id] then ok = c ~= nil and Biz.NavAllow[id](c) == true end
        if ok and BOSS_PAGES[id] and not atBoss then ok = false end
        if ok then
            local label = m.label
            if id == 'home' and c then label = 'Accueil' end
            if id == 'citizens' and c and c.biz.kind ~= 'police' then label = 'Dossiers' end
            nav[#nav + 1] = { id = id, label = label, icon = m.icon, group = grp, img = PB.Cfg.Get('tablets', 'img_' .. id, '') }
        end
    end
    return nav
end

function Biz.Page(src, page)
    local fn = PAGES[page or 'home']
    if not fn then return nil, 'Page inconnue.' end
    if BOSS_PAGES[page] and not Biz.AtBoss(src) then return nil, BOSS_MSG end
    local blocks, title = fn(src)
    if not blocks then return nil, 'Accès refusé.' end
    local clean = {}
    for _, b in ipairs(blocks) do if b then clean[#clean + 1] = b end end
    return { page = page or 'home', title = title, blocks = clean }
end

function Biz.Frame(src)
    local c = Biz.Ctx(src)
    local p = G.Get(src)
    return { name = display(src), id = src, nav = navFor(src), tone = c and c.biz.color or '#dfe2e7', biz = c and { label = c.biz.label, kind = c.biz.kind, grade = c.grade.label, duty = c.duty, boss = c.boss } or nil,
        brand = PB.Cfg.Get('general', 'server_name', ''), title = PB.Cfg.Get('general', 'server_name', ''), subtitle = c and ('Tablette · ' .. c.biz.label) or 'Accueil tablette', icon = 'briefcase', cash = p and p.row.cash or 0, bank = p and p.row.bank or 0 }
end

-- Réseau --------------------------------------------------------------------------------------------------------------------------------
local lastReq = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if lastReq[src] and t - lastReq[src] < ms then return false end lastReq[src] = t return true end

local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end

RegisterNetEvent('pb:g:biz:open', function()
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    local page = Biz.Page(src, 'home')
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'open', frame = Biz.Frame(src), page = page }))
end)

RegisterNetEvent('pb:g:biz:page', function(page)
    local src = source
    if not usable(src) or not throttle(src, 150) then return end
    local data, err = Biz.Page(src, tostring(page))
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'page', frame = Biz.Frame(src), page = data, err = err }))
end)

function Biz.Act(src, name, payload, page)
    local fn = ACT[tostring(name)]
    if not fn then return false, 'Action inconnue.' end
    if type(payload) ~= 'table' then payload = {} end
    local citizen = (name == 'pay_invoice' or name == 'transfer')
    local c = Biz.Ctx(src)
    if not citizen and not c then return false, "Tu n'as pas d'entreprise." end
    if BOSS_ACTS[name] and not Biz.AtBoss(src, c) then return false, BOSS_MSG end
    local ok, msg = fn(c, src, payload)
    return ok, msg
end

RegisterNetEvent('pb:g:biz:act', function(name, payload, page)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usable(src) or not throttle(src, 250) then return end
    local ok, msg = Biz.Act(src, name, payload, page)
    local data = Biz.Page(src, tostring(page or 'home'))
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'result', ok = ok and true or false, msg = msg, frame = Biz.Frame(src), page = data }))
end)

-- Paie ---------------------------------------------------------------------------------------------------------------------------------------
local lastPay = os.time()
function Biz.PayTick()
    local eco = G.Eco
    local paid, skipped = 0, 0
    local offDuty = PB.Cfg.Get('biz', 'pay_off_duty', false)
    for src, p in pairs(G.Players()) do
        if PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) then
            local c = Biz.Ctx(src)
            local gross, source
            if c then
                if c.duty or offDuty then
                    gross = math.floor(c.grade.salary * eco.Get('income_mult') * (G.PayMult and G.PayMult() or 1) + 0.5)   -- bonus de paie (événement)
                    source = c.biz.pay_from or 'free'
                end
            else
                gross = math.floor(eco.Get('unemployed_allowance') + 0.5)
                source = 'state_allow'
            end
            if gross and gross > 0 then
                local tax = c and math.floor(gross * eco.Get('tax_income') / 100 + 0.5) or 0
                local net = gross - tax
                local ok = true
                if source == 'society' then
                    if eco.Balance(acct(c.biz.id)) < gross then ok = false else eco.Book(acct(c.biz.id), -gross, 'Salaire ' .. display(src), p.license) end
                elseif source == 'free' then
                    eco.Book('salaires', -gross, 'Salaire ' .. c.biz.id, p.license)
                else
                    eco.Book('state', -gross, 'Allocation', p.license)
                end
                if ok then
                    if tax > 0 then eco.Book('state', tax, 'Impôt sur le revenu', p.license) end
                    G.AddMoney(src, 'bank', net)
                    G.Notify(src, { type = 'success', title = c and c.biz.label or 'Allocation', text = ('Paie reçue : %s%s'):format(money(net), tax > 0 and (' (impôt ' .. money(tax) .. ')') or '') })
                    paid = paid + 1
                else
                    G.Notify(src, { type = 'warn', title = c.biz.label, text = "La caisse de l'entreprise est vide : ta paie n'a pas pu être versée." })
                    skipped = skipped + 1
                end
            end
            -- second emploi : un pourcentage du salaire du grade, versé à chaque paie
            local j2 = G.BizCat and G.BizCat.Job2 and G.BizCat.Job2(p.license)
            local pct = tonumber(PB.Cfg.Get('biz', 'job2_pct', 50)) or 0
            if j2 and pct > 0 and (j2.salary or 0) > 0 then
                local g2 = math.floor(j2.salary * eco.Get('income_mult') * pct / 100 + 0.5)
                local b2 = Biz.Get(j2.biz)
                local src2 = b2 and b2.pay_from or 'free'
                local ok2 = true
                if g2 > 0 then
                    if src2 == 'society' then
                        if eco.Balance(acct(j2.biz)) < g2 then ok2 = false else eco.Book(acct(j2.biz), -g2, 'Salaire (second emploi) ' .. display(src), p.license) end
                    else eco.Book('salaires', -g2, 'Salaire second emploi ' .. j2.biz, p.license) end
                    if ok2 then
                        local tax2 = math.floor(g2 * eco.Get('tax_income') / 100 + 0.5)
                        if tax2 > 0 then eco.Book('state', tax2, 'Impôt sur le revenu', p.license) end
                        G.AddMoney(src, 'bank', g2 - tax2)
                        G.Notify(src, { type = 'success', title = j2.label, text = ('Second emploi : %s reçus'):format(money(g2 - tax2)) })
                        paid = paid + 1
                    else skipped = skipped + 1 end
                end
            end
        end
    end
    return paid, skipped
end
CreateThread(function()
    while true do
        Wait(30000)
        local interval = (G.Eco and G.Eco.Get('paycheck_interval') or 15) * 60
        if os.time() - lastPay >= interval then lastPay = os.time() Biz.PayTick() end
    end
end)

-- Panel ------------------------------------------------------------------------------------------------------------------------------------
local function validGrades(rows, kind)
    if type(rows) ~= 'table' or #rows < 1 then return nil, 'Il faut au moins un grade.' end
    if #rows > 12 then return nil, 'Au plus 12 grades.' end
    local out, seen, boss = {}, {}, false
    for _, r in ipairs(rows) do
        local n = math.floor(tonumber(r.grade) or -1)
        if n < 0 or n > 50 or seen[n] then return nil, 'Numéros de grade : uniques, de 0 à 50.' end
        seen[n] = true
        local label = cleanText(r.label, 40)
        if label == '' then return nil, 'Chaque grade a un nom.' end
        local sal = math.floor(tonumber(r.salary) or -1)
        if sal < 0 or sal > 20000 then return nil, 'Salaire de « ' .. label .. ' » : 0 à 20 000.' end
        local perms = {}
        for tok in tostring(r.perms or ''):gmatch('[%a_]+') do
            local ok = false
            for _, a in ipairs(ALL_PERMS) do if a == tok then ok = true end end
            if not ok then return nil, 'Droit inconnu : « ' .. tok .. ' » (' .. table.concat(ALL_PERMS, ', ') .. ').' end
            perms[#perms + 1] = tok
        end
        local isBoss = PB.ToBool(r.boss)
        if isBoss then boss = true end
        out[#out + 1] = { grade = n, label = label, salary = sal, boss = isBoss, perms = table.concat(perms, ',') }
    end
    if not boss then return nil, "Au moins un grade doit être « patron »." end
    table.sort(out, function(a, b) return a.grade < b.grade end)
    return out
end

local function saveGrades(id, grades)
    DB.exec('DELETE FROM pb_biz_grades WHERE biz_id = ?', { id })
    for _, g in ipairs(grades) do DB.exec('INSERT INTO pb_biz_grades (biz_id, grade, label, salary, boss, perms) VALUES (?, ?, ?, ?, ?, ?)', { id, g.grade, g.label, g.salary, g.boss and 1 or 0, g.perms }) end
end

PB.Action('biz.create', 'biz.edit', function(ctx, p)
    local v = p.values or {}
    -- à partir d'un modèle du catalogue (garde son fonctionnement : cuisine, comptoir, missions, droits du métier)
    local model = G.BizCat and G.BizCat.ByKey[tostring(v.model or '')]
    if model then
        local label = cleanText(v.label, 48)
        if #label < 2 then return false, "Donne un nom à l'entreprise." end
        local id = tostring(v.id or ''):lower():gsub('[^A-Za-z0-9_]', '')
        if id == '' then id = label:lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', '') end
        id = id:sub(1, 32)
        if id == '' then id = model.key end
        if Biz.Get(id) then return false, 'Une entreprise « ' .. id .. ' » existe déjà : choisis un autre identifiant.' end
        local copy = {}
        for k, x in pairs(model) do copy[k] = x end
        local ok, e = G.BizCat.Create(copy, { id = id, label = label, nopos = true, blip = tonumber(v.blip), bcolor = tonumber(v.bcolor) })
        if not ok then return false, tostring(e) end
        ctx.audit('config', 'biz.create', id, nil, { model = model.key, label = label })
        G.PushConfig()
        ctx.toast = ('Entreprise « %s » créée (fonctionne comme : %s).'):format(label, model.label)
        if v.points ~= false and ctx.src and ctx.src > 0 and PB.Place and PB.Place.PackStart then
            local okp = PB.Place.PackStart(ctx.src, 'biz', id)
            if okp then ctx.close = true ctx.toast = ctx.toast .. ' Pose maintenant ses points en jeu (E pour poser, Retour arrière pour passer).' end
        end
        return true
    end
    local t = TEMPLATES[tostring(v.template or '')]
    if not t then return false, 'Modèle inconnu.' end
    local label = cleanText(v.label, 48)
    if label == '' then label = t.label end
    local id = tostring(v.id or ''):lower():gsub('[^A-Za-z0-9_]', '')
    if id == '' then id = label:lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', '') end
    id = id:sub(1, 32)
    if id == '' then return false, 'Identifiant invalide.' end
    if Biz.Get(id) then return false, 'Une entreprise « ' .. id .. ' » existe déjà.' end
    local cat = tostring(v.category or 'services')
    if not (G.BizCat and G.BizCat.CatBy[cat]) then cat = 'services' end
    DB.exec('INSERT INTO pb_biz (id, label, kind, color, icon, pay_from, enabled, hiring, description, created_at, category) VALUES (?, ?, ?, ?, ?, ?, 1, 0, ?, ?, ?)', { id, label, t.kind, t.color, t.icon, 'free', t.description, now(), cat })
    local grades = {}
    for _, g in ipairs(t.grades) do grades[#grades + 1] = { grade = g[1], label = g[2], salary = g[3], boss = g[4], perms = g[5] } end
    saveGrades(id, grades)
    ctx.audit('config', 'biz.create', id, nil, { template = v.template, label = label })
    ctx.toast = 'Entreprise « ' .. label .. ' » créée avec ses grades. Ajuste-la dans « Modifier ».'
    if v.points ~= false and ctx.src and ctx.src > 0 and PB.Place and PB.Place.PackStart then
        local ok = PB.Place.PackStart(ctx.src, 'biz', id)
        if ok then ctx.close = true ctx.toast = 'Entreprise créée. Pose maintenant ses points en jeu (E pour poser, Retour arrière pour passer).' end
    end
    return true
end)

PB.Action('biz.save', 'biz.edit', function(ctx, p)
    local v = p.values or {}
    local b = Biz.Get(p.id)
    if not b then return false, 'Entreprise introuvable.' end
    local c, err = PB.Validate({
        { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'color', type = 'color', label = 'Couleur' },
        { k = 'pay_from', type = 'select', label = 'Salaires payés par', opts = { { 'free', 'Création monétaire' }, { 'society', "La caisse de l'entreprise" } } },
        { k = 'enabled', type = 'toggle', label = 'Active' }, { k = 'hiring', type = 'toggle', label = 'Recrute' }, { k = 'description', type = 'text', label = 'Description', maxlen = 160 },
    }, { label = v.label, color = v.color, pay_from = v.pay_from, enabled = v.enabled, hiring = v.hiring, description = v.description or '' })
    if not c then return false, err end
    local grades, gerr = validGrades(v.grades, b.kind)
    if not grades then return false, gerr end
    -- on ne supprime pas un grade qui a encore des employés
    local have = {}
    for _, g in ipairs(grades) do have[g.grade] = true end
    for _, m in ipairs(Biz.Members(b.id)) do if not have[m.grade] then return false, ('Le grade %d a encore des employés (%s) : déplace-les avant de le supprimer.'):format(m.grade, m.name) end end
    local hx, hy, hz
    if type(v.hq) == 'table' and v.hq.x and (tonumber(v.hq.x) ~= 0 or tonumber(v.hq.y) ~= 0) then
        local cc = PB.Validate({ { k = 'hq', type = 'coords', label = 'Siège' } }, { hq = v.hq })
        if not cc then return false, 'Position du siège invalide.' end
        hx, hy, hz = cc.hq.x, cc.hq.y, cc.hq.z
    end
    local before = { b = b, grades = Biz.Grades(b.id) }
    local cat = tostring(v.category or b.category or 'services')
    if not (G.BizCat and G.BizCat.CatBy[cat]) then cat = b.category or 'services' end
    DB.exec('UPDATE pb_biz SET label = ?, color = ?, pay_from = ?, enabled = ?, hiring = ?, description = ?, hx = ?, hy = ?, hz = ?, category = ? WHERE id = ?', { c.label, c.color, c.pay_from, c.enabled and 1 or 0, c.hiring and 1 or 0, c.description, hx, hy, hz, cat, b.id })
    saveGrades(b.id, grades)
    -- type d'activité et icône (le siège déjà posé prend la nouvelle icône)
    local mk = tostring(v.model or b.activity or '')
    if mk ~= '' and not G.BizCat.ByKey[mk] then mk = tostring(b.activity or '') end
    local bs, bc = math.floor(tonumber(v.blip) or tonumber(b.blip) or -1), math.floor(tonumber(v.bcolor) or tonumber(b.bcolor) or -1)
    if bs < -1 or bs > 999 then bs = -1 end
    if bc < -1 or bc > 85 then bc = -1 end
    DB.exec('UPDATE pb_biz SET activity = ?, blip = ?, bcolor = ? WHERE id = ?', { mk, bs, bc, b.id })
    local bl = G.BizCat.BlipOf(b.id)
    DB.exec("UPDATE pb_points SET sprite = ?, bcolor = ? WHERE owner_kind = 'biz' AND owner = ? AND kind = 'hq'", { bl[1], bl[2], b.id })
    if G.Points and G.Points.PushAll then G.Points.PushAll() end
    ctx.audit('config', 'biz.save', b.id, before, { c = c, grades = grades })
    G.PushConfig()
    ctx.toast = 'Entreprise enregistrée.'
    return true
end)

PB.Action('biz.delete', 'biz.edit', function(ctx, p)
    local b = Biz.Get(p.id)
    if not b then return false, 'Introuvable.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { b.id })
    if n and n.n > 0 then return false, ('Cette entreprise a encore %d employé(s) : renvoie-les d\'abord.'):format(n.n) end
    local bal = G.Eco.Balance(acct(b.id))
    if bal ~= 0 then return false, ('La caisse contient %s : vide-la avant de supprimer.'):format(money(bal)) end
    DB.exec('DELETE FROM pb_biz WHERE id = ?', { b.id }) DB.exec('DELETE FROM pb_biz_grades WHERE biz_id = ?', { b.id }) DB.exec("DELETE FROM pb_points WHERE owner_kind = 'biz' AND owner = ?", { b.id })
    ctx.audit('config', 'biz.delete', b.id, b, nil)
    G.PushConfig()
    ctx.toast = 'Entreprise supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette entreprise ?', text = "Ses grades disparaissent. Les factures et dossiers déjà émis sont conservés.", danger = true } })

PB.Action('biz.member.set', 'biz.members', function(ctx, p)
    local b = Biz.Get(p.biz)
    if not b then return false, 'Entreprise introuvable.' end
    local lic = tostring(p.license or '')
    local pl = DB.one('SELECT license, firstname, lastname FROM pb_players WHERE license = ?', { lic })
    if not pl then return false, 'Aucun personnage pour cette licence.' end
    local g = Biz.Grade(b.id, p.grade or 0)
    if not g then return false, 'Grade introuvable.' end
    DB.exec('INSERT INTO pb_biz_members (license, biz_id, grade, name, hired_at, on_duty) VALUES (?, ?, ?, ?, ?, 0) ON DUPLICATE KEY UPDATE biz_id = VALUES(biz_id), grade = VALUES(grade), name = VALUES(name), on_duty = 0',
        { lic, b.id, g.grade, ((pl.firstname or '') .. ' ' .. (pl.lastname or '')):gsub('^%s+', ''), now() })
    ctx.audit('config', 'biz.member.set', lic, nil, { biz = b.id, grade = g.grade })
    ctx.toast = 'Employé enregistré.'
    return true
end)

PB.Action('biz.member.remove', 'biz.members', function(ctx, p)
    local m = Biz.MemberOf(tostring(p.license or ''))
    if not m then return false, 'Employé introuvable.' end
    DB.exec('DELETE FROM pb_biz_members WHERE license = ?', { m.license })
    for id, pl in pairs(G.Players()) do if pl.license == m.license then TriggerClientEvent('pb:g:biz:job', id, 'null') end end
    ctx.audit('config', 'biz.member.remove', m.license, m, nil)
    ctx.toast = m.name .. ' n\'a plus d\'emploi.'
    return true
end, { critical = true, confirm = { title = "Retirer cet employé ?", text = "Il perd son poste immédiatement." } })

local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end

local settingsForm = Form.Cfg({
    ns = 'biz', id = 'settings', title = 'Réglages des entreprises et de la tablette', perm = 'biz.edit', cols = 2,
    desc = "S'appliquent à toutes les entreprises. Les limites sont vérifiées par le serveur à chaque action.",
    fields = {
        { k = 'tablet_key', type = 'text', label = 'Touche de la tablette (par défaut)', default = 'F6', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
        { k = 'near_dist', type = 'number', label = 'Distance maximale pour agir sur un joueur (m)', default = 8, min = 2, max = 30 },
        { k = 'max_invoice', type = 'number', label = 'Facture maximale', default = 50000, min = 1, max = 10000000 },
        { k = 'max_fine', type = 'number', label = 'Amende maximale', default = 25000, min = 1, max = 10000000 },
        { k = 'fine_to', type = 'select', label = 'Les amendes vont à', opts = { { 'state', "Au compte « État »" }, { 'biz', "À la caisse de l'entreprise émettrice" } }, default = 'state' },
        { k = 'pay_off_duty', type = 'toggle', label = 'Payer aussi les employés hors service', default = false },
        { k = 'job2_pct', type = 'number', label = 'Salaire du second emploi (% du salaire du grade)', default = 50, min = 0, max = 100, hint = '0 = le second emploi ne rapporte rien.' },
        { k = 'max_members', type = 'number', label = "Employés maximum par entreprise", default = 60, min = 1, max = 500 },
        { k = 'allow_transfers', type = 'toggle', label = 'Virements entre joueurs depuis la tablette', default = true },
        { k = 'transfer_fee', type = 'number', label = 'Frais de virement (%)', default = 0, min = 0, max = 50, int = false, step = 0.5 },
        { k = 'transfer_max', type = 'number', label = 'Virement maximal', default = 100000, min = 1, max = 100000000 },
        { k = 'full_catalog', type = 'toggle', label = 'Catalogue complet (120 métiers)', default = false, hint = "Désactivé : seules les entreprises essentielles sont proposées (police, EMS, justice, mécanos, taxi, concession, Burger Shot, cafés et bars, immobilier, Weazel News, livraison)." },
    },
})

PB.Module({
    id = 'biz', label = 'Entreprises', icon = 'briefcase', group = 'Serveur', order = 92, perm = 'biz.view', hint = 'Police, EMS, garage, grades, paie, tablette patron',
    caps = function()
        return PB.Capsify({
            { 'Entreprises avec grades, employés, caisse, paie', 'ok', 'Autonomes : tables pb_biz*. Salaires versés selon les réglages de l\'économie (multiplicateur, impôt, intervalle).' },
            { 'Tablette citoyen et patron en jeu', 'ok', 'Touche réglable ou /tablette : accueil, finances, factures, entreprises, employés, grades, caisse.' },
            { 'Police : amendes, dossiers', 'ok', "Amendes du catalogue de l'économie, prélevées ou mises en facture." },
            { 'EMS : réanimation, dossiers de soins', 'ok', 'Réanime un patient à proximité (agit sur la mort du panel).' },
            { 'Garage : réparation, facturation', 'ok', 'Répare le véhicule le plus proche côté client du mécanicien.' },
            { 'Menottes, fouille, coffre d\'objets, saisie de véhicule', 'off', "Prévus avec l'inventaire et les garages (lots suivants)." },
            { 'Jobs ESX / QBCore existants', 'off', "Les emplois du framework restent séparés : n'utilise pas les deux en même temps." },
        })
    end,
    doc = "## Entreprises\nCrée une entreprise à partir d'un **modèle** (police, EMS, garage, générique) puis ajuste ses grades, couleurs et droits. Chaque grade a un **salaire** et des **droits** : `hire, fire, promote, vault, invoice, fine, revive, repair, records` ; le grade « patron » a tous les droits.\n\n- **Tablette** : touche réglable (F5 par défaut) ou `/tablette` en jeu. Les patrons y gèrent employés, grades, caisse et factures.\n- **Droits propres à un métier** (`fine`, `revive`, `repair`) n'agissent que dans leur métier.\n- **Pour tes scripts** : `exports.pb_panel:GetJob(source)`, `SetJob(source, 'police', 2)`, `IsOnDuty(source)`, `AddBusinessMoney('garage', 500, 'raison')`.",
    view = function(ctx)
        return { tabs = {
            tab('list', 'Entreprises', 'briefcase', function()
                local items = {}
                for _, b in ipairs(Biz.List()) do
                    local n = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { b.id })
                    local pend = DB.one("SELECT COUNT(*) AS n FROM pb_biz_invoices WHERE biz_id = ? AND status = 'pending'", { b.id })
                    items[#items + 1] = { title = b.label, sub = (KIND_LABEL[b.kind] or b.kind) .. ' · ' .. b.id, icon = b.icon, tone = b.color, badge = PB.ToBool(b.enabled) and nil or 'Désactivée',
                        value = money(G.Eco.Balance(acct(b.id))), text = b.description, stats = { { label = 'Employés', value = tostring(n and n.n or 0) }, { label = 'Factures', value = tostring(pend and pend.n or 0) }, { label = 'Salaires', value = b.pay_from == 'society' and 'Caisse' or 'Libre' } },
                        action = ctx.has('biz.edit') and { nav = { tab = 'edit', params = { id = b.id } }, label = 'Modifier', icon = 'sliders' } or nil }
                end
                local blocks = { { type = 'cards', big = true, items = items } }
                if #items == 0 then blocks[#blocks + 1] = B.notice('info', "Aucune entreprise : crée la première depuis l'onglet « Nouvelle entreprise ».") end
                return blocks
            end),
            tab('new', 'Nouvelle entreprise', 'plus', function(_, params)
                local C = G.BizCat
                local cat = tostring(params and params.cat or 'public')
                if not C.CatBy[cat] then cat = 'public' end
                local cards = {}
                for _, c in ipairs(C.Cats) do
                    local total, have = 0, 0
                    for _, t in ipairs(C.List) do if t.cat == c.id and C.Visible(t) then total = total + 1 if Biz.Get(t.key) then have = have + 1 end end end
                    cards[#cards + 1] = { title = c.label, sub = have .. ' / ' .. total .. ' installées', icon = c.icon, tone = c.color, text = c.desc, badge = c.id == cat and 'Affichée' or nil,
                        action = { nav = { tab = 'new', params = { cat = c.id } }, label = 'Voir', icon = 'eye' } }
                end
                local rows = {}
                for _, t in ipairs(C.List) do
                    if t.cat == cat and C.Visible(t) then
                        local g1, gN = t.grades[1], t.grades[#t.grades]
                        local done = Biz.Get(t.key) ~= nil
                        rows[#rows + 1] = { name = t.label, grades = #t.grades .. ' grades (' .. g1 .. ' → ' .. gN .. ')', pay = money(t.pay[1]) .. ' → ' .. money(t.pay[2]), kind = KIND_LABEL[t.kind] or t.kind, pos = t.pos and 'Siège + blip' or 'À placer (carte)',
                            state = done and { text = 'Installée', tone = 'ok' } or { text = 'Disponible', tone = 'off' },
                            actions = done and { { nav = { tab = 'edit', params = { id = t.key } }, label = 'Modifier', icon = 'sliders' } } or { { action = 'biz.cat.create', label = 'Installer', icon = 'plus', payload = { key = t.key } } } }
                    end
                end
                local kinds = {}
                for _, k in ipairs({ 'generic', 'police', 'ems', 'garage' }) do kinds[#kinds + 1] = { k, KIND_LABEL[k] } end
                local copts = {}
                for _, c in ipairs(C.Cats) do copts[#copts + 1] = { c.id, c.label } end
                -- tous les modèles, classés par catégorie (celle de l'onglet en premier)
                local mopts, mdef = {}, nil
                local order = { cat }
                for _, c in ipairs(C.Cats) do if c.id ~= cat then order[#order + 1] = c.id end end
                for _, cid in ipairs(order) do
                    for _, t in ipairs(C.List) do if t.cat == cid then mopts[#mopts + 1] = { t.key, C.CatBy[cid].label .. ' · ' .. t.label } mdef = mdef or t.key end end
                end
                return {
                    { type = 'cards', items = cards },
                    B.table({ id = 'bizcat', title = C.CatBy[cat].label .. ' : modèles prêts à installer', search = true, columns = { { k = 'name', label = 'Entreprise' }, { k = 'kind', label = 'Type' }, { k = 'grades', label = 'Grades' }, { k = 'pay', label = 'Salaires' }, { k = 'pos', label = 'Position' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows, empty = 'Aucun modèle.' }),
                    B.actions({ { action = 'biz.cat.install', label = 'Installer toute la catégorie', icon = 'plus', payload = { cat = cat } }, { action = 'biz.cat.install', label = 'Tout installer (' .. #C.List .. ' entreprises)', icon = 'plus', payload = { cat = 'all' } } }),
                    { type = 'form', id = 'biz.new', title = 'Créer une entreprise sur mesure', desc = "Donne-lui le nom que tu veux et choisis comment elle fonctionne : elle garde tout ce que fait ce type (mécano : atelier et réparations ; café, restaurant, bar : cuisine et comptoir ; taxi : courses…). Grades, salaires et droits sont générés, tu les ajustes ensuite dans « Modifier ».", cols = 2, fields = {
                        { k = 'label', type = 'text', label = "Nom de l'entreprise", required = true, maxlen = 48, hint = "Ex. Benny's Motorworks, Le Petit Café, Garage du Port." },
                        { k = 'model', type = 'select', label = 'Fonctionne comme', opts = mopts, hint = 'Tous les types du catalogue, classés par catégorie.' },
                        { k = 'blip', type = 'number', label = 'Icône sur la carte (blip GTA)', min = -1, max = 999, picker = 'blip', pickerColor = 'bcolor', hint = '-1 = icône du type choisi. Le bouton ouvre toutes les icônes du jeu.' },
                        { k = 'bcolor', type = 'number', label = "Couleur de l'icône", min = -1, max = 85, hint = '-1 = couleur du type. Se choisit aussi dans le sélecteur.' },
                        { k = 'id', type = 'text', label = 'Identifiant (facultatif)', maxlen = 32, pattern = '^[%w_]*$', hint = 'Lettres, chiffres, _ : sert dans les scripts.' },
                        { k = 'points', type = 'toggle', label = 'Poser tous les points maintenant (en jeu)', hint = 'Siège, service, patron, coffre, garage (entrée et sortie), vestiaire, atelier, cuisine, comptoir, selon le type. Sinon : Carte du jeu › Configurer tout.' } },
                        values = { model = mdef, label = '', id = '', blip = -1, bcolor = -1, points = true }, submit = { action = 'biz.create', label = "Créer l'entreprise" } } }
            end, 'biz.edit'),
            tab('edit', 'Modifier', 'sliders', function(_, params)
                local list = Biz.List()
                local opts = {}
                for _, b in ipairs(list) do opts[#opts + 1] = { b.id, b.label } end
                if #opts == 0 then return { B.notice('info', "Aucune entreprise à modifier.") } end
                local id = tostring(params.id or opts[1][1])
                local b = Biz.Get(id) or Biz.Get(opts[1][1])
                local g = {}
                for _, r in ipairs(Biz.Grades(b.id)) do g[#g + 1] = { grade = r.grade, label = r.label, salary = r.salary, boss = PB.ToBool(r.boss), perms = r.perms } end
                local hq = (b.hx and b.hy) and { x = b.hx, y = b.hy, z = b.hz or 0, h = 0 } or { x = 0, y = 0, z = 0, h = 0 }
                local sub = ctx.has('biz.edit')
                local blocks = { { type = 'picker', id = 'id', label = 'Entreprise', options = opts, value = b.id },
                    { type = 'form', id = 'biz.edit', title = 'Modifier « ' .. b.label .. ' »', cols = 2, fields = {
                        { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'color', type = 'color', label = 'Couleur' },
                        { k = 'category', type = 'select', label = 'Catégorie', opts = (function() local o = {} for _, c in ipairs(G.BizCat.Cats) do o[#o + 1] = { c.id, c.label } end return o end)() },
                        { k = 'pay_from', type = 'select', label = 'Salaires payés par', opts = { { 'free', 'Création monétaire (sans limite)' }, { 'society', "La caisse de l'entreprise" } } },
                        { k = 'description', type = 'text', label = 'Description', maxlen = 160 }, { k = 'enabled', type = 'toggle', label = 'Active' }, { k = 'hiring', type = 'toggle', label = 'Affichée comme « Recrute »' },
                        { k = 'model', type = 'select', label = 'Fonctionne comme', opts = (function() local o = { { '', '(identique à son identifiant)' } } for _, t in ipairs(G.BizCat.List) do o[#o + 1] = { t.key, G.BizCat.CatBy[t.cat].label .. ' · ' .. t.label } end return o end)(), hint = 'Décide de la cuisine, du comptoir, de l\'atelier et des petits jobs.' },
                        { k = 'blip', type = 'number', label = 'Icône sur la carte (blip GTA)', min = -1, max = 999, picker = 'blip', pickerColor = 'bcolor', hint = '-1 = icône du type.' },
                        { k = 'bcolor', type = 'number', label = "Couleur de l'icône", min = -1, max = 85 },
                        { k = 'hq', type = 'coords', label = 'Siège (facultatif)', wide = true, hint = 'Laisse 0, 0 pour ne pas en définir.' },
                        { k = 'grades', type = 'rows', label = 'Grades', wide = true, cols = { { k = 'grade', label = 'N°', type = 'number' }, { k = 'label', label = 'Nom' }, { k = 'salary', label = 'Salaire', type = 'number' }, { k = 'boss', label = 'Patron', type = 'toggle' },
                            { k = 'perms', label = 'Droits (séparés par des virgules)' } } } },
                        values = { label = b.label, color = b.color, model = tostring(b.activity or ''), blip = tonumber(b.blip) or -1, bcolor = tonumber(b.bcolor) or -1, category = b.category or 'services', pay_from = b.pay_from, description = b.description, enabled = PB.ToBool(b.enabled), hiring = PB.ToBool(b.hiring), hq = hq, grades = g },
                        submit = sub and { action = 'biz.save', label = 'Enregistrer', payload = { id = b.id } } or nil },
                    B.notice('info', 'Droits disponibles : ' .. table.concat(ALL_PERMS, ', ') .. '. Le grade « patron » a tous les droits. Les droits `fine`, `revive`, `repair`, `cuff`, `search` et `seize` n\'agissent que dans une entreprise du métier correspondant.') }
                if sub then blocks[#blocks + 1] = B.actions({ { action = 'biz.delete', label = "Supprimer l'entreprise", icon = 'trash', danger = true, payload = { id = b.id } } }) end
                return blocks
            end, 'biz.edit'),
            tab('members', 'Employés', 'users', function()
                local rows = {}
                for _, m in ipairs(DB.q('SELECT m.*, b.label AS blabel, g.label AS glabel FROM pb_biz_members m LEFT JOIN pb_biz b ON b.id = m.biz_id LEFT JOIN pb_biz_grades g ON g.biz_id = m.biz_id AND g.grade = m.grade ORDER BY b.label, m.grade DESC LIMIT 300') or {}) do
                    rows[#rows + 1] = { name = m.name, biz = m.blabel or m.biz_id, grade = m.glabel or m.grade, duty = PB.ToBool(m.on_duty) and { text = 'En service', tone = 'ok' } or { text = 'Hors service', tone = 'off' }, lic = m.license,
                        actions = ctx.has('biz.members') and { { action = 'biz.member.remove', label = 'Retirer', icon = 'trash', danger = true, payload = { license = m.license } } } or {} }
                end
                local blocks = { B.table({ id = 'mem', title = 'Tous les employés', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'biz', label = 'Entreprise' }, { k = 'grade', label = 'Grade' }, { k = 'duty', label = 'Service', type = 'badge' }, { k = 'lic', label = 'Licence', type = 'mono' } }, rows = rows, empty = 'Aucun employé.' }) }
                if ctx.has('biz.members') then
                    local opts = {}
                    for _, b in ipairs(Biz.List()) do opts[#opts + 1] = { b.id, b.label } end
                    if #opts > 0 then blocks[#blocks + 1] = { type = 'form', id = 'mem.set', title = 'Affecter une personne', desc = 'Par licence Rockstar (visible dans Créateur > Joueurs).', cols = 3, fields = {
                        { k = 'license', type = 'text', label = 'Licence', required = true, maxlen = 64 }, { k = 'biz', type = 'select', label = 'Entreprise', opts = opts }, { k = 'grade', type = 'number', label = 'Grade', min = 0, max = 50 } },
                        values = { license = '', biz = opts[1][1], grade = 0 }, submit = { action = 'biz.member.set', label = 'Affecter' } } end
                end
                return blocks
            end),
            tab('ledger', 'Caisses et factures', 'coins', function()
                local items, rows = {}, {}
                for _, b in ipairs(Biz.List()) do items[#items + 1] = { title = b.label, sub = 'Caisse', icon = b.icon, tone = b.color, value = money(G.Eco.Balance(acct(b.id))) } end
                if ctx.has('biz.ledger') then
                    for _, i in ipairs(DB.q('SELECT * FROM pb_biz_invoices ORDER BY id DESC LIMIT 100') or {}) do
                        rows[#rows + 1] = { at = i.at, biz = i.biz_id, who = i.name, reason = i.reason, amount = i.amount, kind = i.kind == 'fine' and 'Amende' or 'Facture', status = ({ pending = 'En attente', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status }
                    end
                end
                return { { type = 'cards', items = items }, ctx.has('biz.ledger') and B.table({ id = 'inv', title = 'Dernières factures et amendes', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'biz', label = 'Entreprise' }, { k = 'kind', label = 'Type' },
                    { k = 'who', label = 'Client' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant', type = 'num' }, { k = 'status', label = 'Statut' } }, rows = rows, empty = 'Aucune facture.' }) or nil }
            end, 'biz.ledger'),
            tab('tablet', 'Tablette et images', 'grid', function()
                return { G.LegalForm and G.LegalForm(ctx) or nil, { type = 'gpreview', kind = 'tablet', title = 'Tablette vue par un patron', cfg = { c_accent = '#dfe2e7', server = PB.Cfg.Get('general', 'server_name', '') } } }
            end),
            tab('settings', 'Réglages', 'sliders', function() local out = { settingsForm(ctx) } for _, f in ipairs(Biz.ExtraSettings) do out[#out + 1] = f(ctx) end return out end, 'biz.edit'),
        } }
    end,
})

-- Auto-test : modèles valides, grades cohérents, paie sans erreur ------------------------------------------------------------------------
PB.SelfTest.Add('entreprises', function(R)
    for k, t in pairs(TEMPLATES) do
        local rows = {}
        for _, g in ipairs(t.grades) do rows[#rows + 1] = { grade = g[1], label = g[2], salary = g[3], boss = g[4], perms = g[5] } end
        local ok, err = validGrades(rows, t.kind)
        R.check(ok, 'modèle ' .. k, 'grades invalides', err)
    end
    for _, b in ipairs(Biz.List()) do
        local grades = Biz.Grades(b.id)
        local boss = false
        for _, g in ipairs(grades) do if PB.ToBool(g.boss) then boss = true end end
        R.check(boss, 'entreprise ' .. b.id, 'aucun grade patron')
        R.check(#grades > 0, 'entreprise ' .. b.id, 'aucun grade')
    end
    R.check(pcall(Biz.PayTick), 'entreprises', 'la paie plante')
end)

-- nettoyage des tables par joueur (évite qu'elles grossissent sans fin)
AddEventHandler('playerDropped', function() local s = source lastRepair[s] = nil lastReq[s] = nil end)
