-- Carburant : consommation côté joueur (le jeu connaît le régime et la vitesse), stations et paiement côté serveur.
-- Le niveau d'essence est celui du jeu (GetVehicleFuelLevel) : le compteur du HUD, la sauvegarde en garage et le plein utilisent la même valeur.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local F = {}
G.Fuel = F

P.Register('fuel.edit', 'Modifier le carburant et les stations', 'fuel', true)

local STATIONS = {
    { id = 'strawberry', label = 'Station Strawberry', x = 265.6, y = -1261.3, z = 29.3, price = 0 },
    { id = 'mirror', label = 'Station Mirror Park', x = 1208.9, y = -1402.6, z = 35.2, price = 0 },
    { id = 'lasmesa', label = 'Station La Mesa', x = 819.6, y = -1028.8, z = 26.4, price = 0 },
    { id = 'littleseoul', label = 'Station Little Seoul', x = -724.6, y = -935.2, z = 19.2, price = 0 },
    { id = 'sandy', label = 'Station Sandy Shores', x = 2679.9, y = 3263.9, z = 55.2, price = 0 },
    { id = 'paleto', label = 'Station Paleto Bay', x = 1701.3, y = 6416.0, z = 32.8, price = 0 },
}
PB.Cfg.Define('fuel', { enabled = true, idle_pct_min = 0.35, drive_pct_min = 2.6, price = 3, pay = 'cash', use_dist = 5, max_buy = 120, blips = true, engine_off_to_fill = true, wreck_to_impound = true, stations = STATIONS })
local function cfg(k, d) return PB.Cfg.Get('fuel', k, d) end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

function F.Station(id) for _, s in ipairs(cfg('stations', {}) or {}) do if s.id == id then return s end end end
-- prix du litre dans une station (0 = prix général), après le coefficient de prix de l'économie
function F.Price(st)
    local base = tonumber(st and st.price) or 0
    if base <= 0 then base = tonumber(cfg('price', 3)) or 3 end
    local mult = G.Eco and G.Eco.Get and tonumber(G.Eco.Get('price_mult')) or 1
    return base * (mult or 1)
end
function F.Cost(st, liters) return math.max(1, math.floor(F.Price(st) * liters + 0.5)) end

RegisterNetEvent('pb:g:fuel:buy', function(id, liters)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 700) then return end
    local st = F.Station(tostring(id))
    liters = math.floor(tonumber(liters) or 0)
    if not st or liters < 1 or liters > (tonumber(cfg('max_buy', 120)) or 120) then return end
    if G.DistTo(src, st.x, st.y, st.z) > (tonumber(cfg('use_dist', 5)) or 5) + 8 then G.Notify(src, { type = 'error', title = st.label, text = 'Tu es trop loin de la pompe.' }) return end
    local cost = F.Cost(st, liters)
    local acc = G.Pay(src, cost, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash')
    if not acc then G.Notify(src, { type = 'error', title = st.label, text = ('Il te faut %s.'):format(money(cost)) }) return end
    if G.Eco then G.Eco.Book('state', cost, 'Carburant ' .. st.label, G.Get(src).license) end
    TriggerClientEvent('pb:g:fuel:add', src, PB.Json({ liters = liters }))
    G.Notify(src, { type = 'success', title = st.label, text = ('%d L pour %s.'):format(liters, money(cost)) })
    TriggerEvent('pb_panel:fuelBought', src, liters, cost)
end)

local settings = Form.Cfg({ ns = 'fuel', id = 'settings', title = 'Carburant', perm = 'fuel.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Consommation et stations actives', default = true },
    { k = 'idle_pct_min', type = 'number', label = 'Consommation au ralenti (% du réservoir / minute)', default = 0.35, min = 0, max = 10, step = 0.05, int = false },
    { k = 'drive_pct_min', type = 'number', label = 'Consommation à pleine vitesse (% / minute)', default = 2.6, min = 0, max = 20, step = 0.1, int = false, hint = 'Entre les deux, elle suit la vitesse. 2,6 % par minute ≈ un plein en 38 minutes à fond.' },
    { k = 'price', type = 'number', label = 'Prix du litre par défaut ($)', default = 3, min = 0, max = 500, step = 0.1, int = false },
    { k = 'pay', type = 'select', label = 'Paiement', opts = { { 'cash', 'Espèces d\'abord' }, { 'bank', 'Banque d\'abord' } }, default = 'cash' },
    { k = 'use_dist', type = 'number', label = 'Distance à la pompe (m)', default = 5, min = 2, max = 20 },
    { k = 'max_buy', type = 'number', label = 'Litres maximum par achat', default = 120, min = 5, max = 500 },
    { k = 'engine_off_to_fill', type = 'toggle', label = 'Moteur coupé obligatoire pour faire le plein', default = true },
    { k = 'blips', type = 'toggle', label = 'Icônes de station sur la carte', default = true },
    { k = 'wreck_to_impound', type = 'toggle', label = 'Un véhicule détruit part en fourrière', default = true },
} })
local stationsForm = Form.Cfg({ ns = 'fuel', id = 'stations', title = 'Stations-service', perm = 'fuel.edit', fields = {
    { k = 'stations', type = 'rows', label = 'Stations', default = STATIONS, wide = true, maxitems = 40, unique = 'id', cols = {
        { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'price', label = 'Prix du litre (0 = général)', type = 'number', min = 0, max = 500, int = false },
        { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } } } } })

PB.Module({
    id = 'fuel', label = 'Carburant', icon = 'fuel', group = 'Serveur', order = 142, perm = 'fuel.edit', hint = 'Consommation, stations, prix',
    caps = function()
        return PB.Capsify({
            { 'Consommation selon la vitesse et le régime', 'ok', "Le moteur s'arrête à sec ; le niveau est sauvegardé en garage." },
            { 'Stations avec paiement', 'ok', 'Prix par station, paiement espèces ou banque, argent versé à la caisse de la ville.' },
            { 'Autonomie du compteur', 'ok', "Calculée avec le niveau réel et la consommation moyenne réglée dans le HUD." },
            { 'Véhicules électriques, jerrican, pompes en 3D', 'off', "Cette version gère des points de station, pas les modèles de pompe ni les bornes." },
        })
    end,
    doc = "## Carburant\nLe moteur consomme selon la vitesse. À sec, il cale. Les stations sont des points de la carte : le joueur s'arrête, coupe le moteur et choisit combien de litres (10, 25 ou le plein).\n\nLe niveau d'essence est sauvegardé avec le véhicule quand il est rangé ou en route (toutes les 30 s).",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'fuel', title = 'Menu de la pompe (exemple)', cfg = PB.Cfg.All('menus') } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
            { id = 'stations', label = 'Stations', icon = 'fuel', build = function() return { stationsForm(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('carburant', function(R)
    for _, s in ipairs(cfg('stations', {}) or {}) do R.check(not (s.x == 0 and s.y == 0), 'station ' .. tostring(s.label), 'position 0,0 : au milieu de la mer') end
end)
