-- Vestiaire d'entreprise / de gang : tenues enregistrées par le patron (ou le staff), choisies par les membres selon leur grade.
-- « Tenue civile » remet les vêtements du personnage. Le point se pose au Builder (Vestiaire). Le serveur vérifie l'appartenance et le grade.

local G, DB, P = PB.G, PB.DB, PB.Perm
local Wd = {}
G.Wardrobe = Wd

PB.Migrate('210_outfits', "Vestiaires : tenues d'entreprise et de gang", {
    [[CREATE TABLE IF NOT EXISTS pb_outfits (
        id INT NOT NULL AUTO_INCREMENT, owner_kind VARCHAR(8) NOT NULL, owner VARCHAR(48) NOT NULL, label VARCHAR(40) NOT NULL, min_grade INT NOT NULL DEFAULT 0,
        sex VARCHAR(1) NOT NULL DEFAULT '', data TEXT NOT NULL, created_by VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_owner (owner_kind, owner))]],
})
-- Accessoires par grade (gilet = composant 9, badge / insigne = composant 10) : ajoutés automatiquement sur chaque tenue du vestiaire
PB.Migrate('215_outfit_acc', 'Vestiaires : accessoires automatiques par grade', {
    [[CREATE TABLE IF NOT EXISTS pb_outfit_acc (owner_kind VARCHAR(8) NOT NULL, owner VARCHAR(48) NOT NULL, grade INT NOT NULL, sex VARCHAR(1) NOT NULL,
        data TEXT NOT NULL, PRIMARY KEY (owner_kind, owner, grade, sex))]],
})
local ACC_COMPS = { [9] = 'gilet', [10] = 'badge' }
-- accessoires du grade le plus haut (≤ grade du membre) pour son sexe
local function accFor(kind, owner, grade, sex)
    local r = DB.one('SELECT data FROM pb_outfit_acc WHERE owner_kind = ? AND owner = ? AND sex = ? AND grade <= ? ORDER BY grade DESC LIMIT 1', { kind, owner, sex, grade or 0 })
    return r and PB.FromJson(r.data, nil) or nil
end

-- Appartenance au groupe du vestiaire : { grade, manager } ou nil
local function membership(src, kind, owner)
    if kind == 'biz' then
        local c = G.Biz and G.Biz.Ctx(src)
        if not c or c.biz.id ~= owner then return nil end
        return { grade = tonumber(c.grade.grade) or 0, manager = c.boss == true }
    elseif kind == 'gang' then
        local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
        if not g or g.id ~= owner then return nil end
        local boss = G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, g.id)
        return { grade = 0, manager = boss == true }
    end
end
local function isStaff(src) return P.Has(src, 'carte.place') and true or false end

local function nearPoint(src, p)
    local c = GetEntityCoords(GetPlayerPed(src))
    return c and #(c - vector3(p.x, p.y, p.z)) <= (tonumber(p.radius) or 2) + 4.0
end
local function pointOf(id) local p = DB.one('SELECT * FROM pb_points WHERE id = ?', { tonumber(id) or -1 }) return p and p.kind == 'wardrobe' and p or nil end
local function sexOf(src) local pl = G.Get(src) return pl and (pl.row.sex == 'f' and 'f' or 'm') or 'm' end

-- Ouverture (appelée par le point « vestiaire »)
function Wd.Open(src, p)
    local m = membership(src, p.owner_kind, p.owner)
    local staff = isStaff(src)
    if not m and not staff then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Réservé aux membres.' }) return end
    local sex, list = sexOf(src), {}
    for _, o in ipairs(DB.q('SELECT id, label, min_grade, sex FROM pb_outfits WHERE owner_kind = ? AND owner = ? ORDER BY min_grade, label', { p.owner_kind, p.owner }) or {}) do
        if o.sex == '' or o.sex == sex then
            list[#list + 1] = { id = o.id, label = o.label, min = tonumber(o.min_grade) or 0, ok = staff or (m and m.grade >= (tonumber(o.min_grade) or 0)) or false }
        end
    end
    TriggerClientEvent('pb:g:wardrobe:open', src, PB.Json({ point = p.id, title = p.label ~= '' and p.label or 'Vestiaire', outfits = list, manage = (m and m.manager) or staff, sex = sex }))
end

local last = {}
local function throttle(src) local t = GetGameTimer() if last[src] and t - last[src] < 700 then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

RegisterNetEvent('pb:g:wardrobe:wear', function(pointId, outfitId)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local o = DB.one('SELECT * FROM pb_outfits WHERE id = ? AND owner_kind = ? AND owner = ?', { tonumber(outfitId) or -1, p.owner_kind, p.owner })
    if not o then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not isStaff(src) and not (m and m.grade >= (tonumber(o.min_grade) or 0)) then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Ton grade ne permet pas cette tenue.' }) return end
    -- accessoires du grade (gilet, badge) par-dessus la tenue
    local data = PB.FromJson(o.data, nil)
    local acc = data and accFor(p.owner_kind, p.owner, m and m.grade or 99, sexOf(src))
    if data and acc and type(acc.comps) == 'table' then
        for _, a in ipairs(acc.comps) do
            local done = false
            for _, c in ipairs(data.comps or {}) do if c[1] == a[1] then c[2], c[3] = a[2], a[3] done = true end end
            if not done then data.comps[#data.comps + 1] = a end
        end
        TriggerClientEvent('pb:g:wardrobe:apply', src, PB.Json(data), o.label)
        return
    end
    TriggerClientEvent('pb:g:wardrobe:apply', src, o.data, o.label)
end)

-- Enregistrer les accessoires portés (gilet, badge) pour un grade et plus : ajoutés à toutes les tenues de ces grades
RegisterNetEvent('pb:g:wardrobe:acc', function(pointId, minGrade, data)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not ((m and m.manager) or isStaff(src)) then return end
    local d = PB.FromJson(type(data) == 'string' and data or '', nil)
    if type(d) ~= 'table' or type(d.comps) ~= 'table' then return end
    local clean = { comps = {} }
    for _, c in ipairs(d.comps) do
        local ci, di, ti = math.floor(tonumber(c[1]) or -1), math.floor(tonumber(c[2]) or -1), math.floor(tonumber(c[3]) or 0)
        if ACC_COMPS[ci] and di >= 0 and di < 1000 and ti >= 0 and ti < 100 then clean.comps[#clean.comps + 1] = { ci, di, ti } end
    end
    local g = math.max(0, math.min(50, math.floor(tonumber(minGrade) or 0)))
    if #clean.comps == 0 then
        DB.exec('DELETE FROM pb_outfit_acc WHERE owner_kind = ? AND owner = ? AND grade = ? AND sex = ?', { p.owner_kind, p.owner, g, sexOf(src) })
        G.Notify(src, { type = 'info', title = 'Vestiaire', text = ('Accessoires du grade %d retirés.'):format(g) })
    else
        DB.exec('REPLACE INTO pb_outfit_acc (owner_kind, owner, grade, sex, data) VALUES (?, ?, ?, ?, ?)', { p.owner_kind, p.owner, g, sexOf(src), PB.Json(clean) })
        G.Notify(src, { type = 'success', title = 'Vestiaire', text = ('Gilet et badge enregistrés pour le grade %d et plus : ajoutés automatiquement à chaque tenue.'):format(g) })
    end
    Wd.Open(src, p)
end)

-- Enregistrer la tenue portée (patron du groupe ou staff). data = { comps = { {c, d, t} }, props = { {id, d, t} } } lu sur le personnage.
RegisterNetEvent('pb:g:wardrobe:save', function(pointId, label, minGrade, data)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not ((m and m.manager) or isStaff(src)) then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Seul le patron peut enregistrer une tenue.' }) return end
    label = PB.Trim(PB.Sanitize(tostring(label or ''), 40))
    if #label < 2 then G.Notify(src, { type = 'error', title = 'Vestiaire', text = 'Donne un nom à la tenue.' }) return end
    local d = PB.FromJson(type(data) == 'string' and data or '', nil)
    if type(d) ~= 'table' or type(d.comps) ~= 'table' then return end
    -- on ne garde que des nombres entiers raisonnables (rien d'autre n'est réappliqué)
    local clean = { comps = {}, props = {} }
    for _, c in ipairs(d.comps) do
        local ci, di, ti = math.floor(tonumber(c[1]) or -1), math.floor(tonumber(c[2]) or -1), math.floor(tonumber(c[3]) or 0)
        if ci >= 1 and ci <= 11 and ci ~= 2 and di >= 0 and di < 1000 and ti >= 0 and ti < 100 then clean.comps[#clean.comps + 1] = { ci, di, ti } end
    end
    for _, c in ipairs(type(d.props) == 'table' and d.props or {}) do
        local id, di, ti = math.floor(tonumber(c[1]) or -1), math.floor(tonumber(c[2]) or -2), math.floor(tonumber(c[3]) or 0)
        if (id == 0 or id == 1 or id == 2 or id == 6 or id == 7) and di >= -1 and di < 1000 and ti >= 0 and ti < 100 then clean.props[#clean.props + 1] = { id, di, ti } end
    end
    if #clean.comps == 0 then return end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_outfits WHERE owner_kind = ? AND owner = ?', { p.owner_kind, p.owner })
    if n and tonumber(n.n) >= 40 then G.Notify(src, { type = 'error', title = 'Vestiaire', text = '40 tenues au maximum : supprimes-en une.' }) return end
    DB.insert('INSERT INTO pb_outfits (owner_kind, owner, label, min_grade, sex, data, created_by, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        { p.owner_kind, p.owner, label, math.max(0, math.min(50, math.floor(tonumber(minGrade) or 0))), sexOf(src), PB.Json(clean), PB.Actor(src).name:sub(1, 64), os.time() })
    PB.Audit.Log('config', 'vestiaire.tenue', src, p.owner_kind .. ':' .. p.owner, nil, { tenue = label, grade = minGrade })
    G.Notify(src, { type = 'success', title = 'Vestiaire', text = ('Tenue « %s » enregistrée (%s).'):format(label, sexOf(src) == 'f' and 'femmes' or 'hommes') })
    Wd.Open(src, p)
end)

RegisterNetEvent('pb:g:wardrobe:del', function(pointId, outfitId)
    local src = source
    if not throttle(src) then return end
    local p = pointOf(pointId)
    if not p or not nearPoint(src, p) then return end
    local m = membership(src, p.owner_kind, p.owner)
    if not ((m and m.manager) or isStaff(src)) then return end
    DB.exec('DELETE FROM pb_outfits WHERE id = ? AND owner_kind = ? AND owner = ?', { tonumber(outfitId) or -1, p.owner_kind, p.owner })
    G.Notify(src, { type = 'success', title = 'Vestiaire', text = 'Tenue supprimée.' })
    Wd.Open(src, p)
end)

-- Tenue de service automatique : à la prise de service, la meilleure tenue du vestiaire de l'entreprise pour son grade (et son sexe)
-- est enfilée (ex. la combinaison Benny's du garage) ; à la fin du service, le joueur retrouve ses vêtements civils.
PB.Cfg.Define('biz', { duty_outfit = true })
AddEventHandler('pb_panel:duty', function(src, bizId, on)
    if PB.Cfg.Get('biz', 'duty_outfit', true) == false then return end
    if not on then TriggerClientEvent('pb:g:wardrobe:civil', src) return end
    local m = membership(src, 'biz', bizId)
    local sex = sexOf(src)
    local best
    for _, o in ipairs(DB.q("SELECT * FROM pb_outfits WHERE owner_kind = 'biz' AND owner = ? ORDER BY min_grade DESC, id", { tostring(bizId) }) or {}) do
        if (o.sex == '' or o.sex == sex) and (tonumber(o.min_grade) or 0) <= (m and m.grade or 0) then best = o break end
    end
    if not best then
        if m and m.manager then G.Notify(src, { type = 'info', title = 'Tenue de service', text = "Enregistre la tenue de l'entreprise au vestiaire (point « vestiaire » au Builder) : elle sera enfilée à chaque prise de service." }) end
        return
    end
    local data = PB.FromJson(best.data, nil)
    if type(data) ~= 'table' then return end
    local acc = accFor('biz', bizId, m and m.grade or 0, sex)
    if acc and type(acc.comps) == 'table' then
        data.comps = data.comps or {}
        for _, a in ipairs(acc.comps) do
            local done = false
            for _, c in ipairs(data.comps) do if c[1] == a[1] then c[2], c[3] = a[2], a[3] done = true end end
            if not done then data.comps[#data.comps + 1] = a end
        end
    end
    TriggerClientEvent('pb:g:wardrobe:apply', src, PB.Json(data), best.label, true)
end)
