-- Utilisation :  shared_script '@wframework/import.lua'   puis, côté serveur :  WF.GetMoney(source, 'cash')
-- Toutes les fonctions appellent Shadow Base (pb_panel). Aucune n'existe côté client, sauf WF.Notify.

WF = WF or { name = 'wframework' }
local BASE = 'pb_panel'

if IsDuplicityVersion() then
    local function B() return exports[BASE] end
    function WF.GetIdentity(src) return B():GetIdentity(src) end
    function WF.GetMoney(src, account) return B():GetMoney(src, account) end
    function WF.AddMoney(src, account, amount, reason) return B():AddMoney(src, account, amount, reason) end
    function WF.RemoveMoney(src, account, amount, reason) return B():RemoveMoney(src, account, amount, reason) end
    function WF.GetJob(src) return B():GetJob(src) end
    function WF.SetJob(src, jobId, grade) return B():SetJob(src, jobId, grade) end
    function WF.GetGang(src) return B():GetPlayerGang(src) end
    function WF.SetGang(src, id) return B():SetPlayerGang(src, id) end
    function WF.AddItem(src, name, count) return B():AddItem(src, name, count) end
    function WF.RemoveItem(src, name, count) return B():RemoveItem(src, name, count) end
    function WF.GetItemCount(src, name) return B():GetItemCount(src, name) end
    function WF.HasItem(src, name, count) return B():HasItem(src, name, count) end
    function WF.HasPermission(src, perm) return B():HasPermission(src, perm) end
    function WF.IsDead(src) return B():IsDead(src) end
    function WF.Revive(src) return B():Revive(src) end
    function WF.Notify(src, text, kind) return B():Notify(src, { type = kind or 'info', text = tostring(text or '') }) end
else
    function WF.Notify(text, kind) return exports[BASE]:Notify({ type = kind or 'info', text = tostring(text or '') }) end
end
