-- Shadow Framework : ressource compagnon de Shadow Base. Elle ne duplique rien : toutes les données (personnage, argent, métiers, gangs, inventaire)
-- vivent dans pb_panel (tables pb_*). Cette ressource donne le nom, une API stable (WF) et vérifie que Shadow Base est là.
-- Aucun lien avec ESX / QBCore / Qbox : si l'un d'eux tourne, Shadow Base l'arrête.

local BASE = 'pb_panel'
local function base() return GetResourceState(BASE) == 'started' end

exports('GetVersion', function() return '1.0.0' end)
exports('IsReady', base)
exports('GetFrameworkName', function() return 'wframework' end)

CreateThread(function()
    Wait(2000)
    if base() then
        print('^2[wframework]^7 Shadow Base détecté : framework actif.')
    else
        print('^3[wframework]^7 « pb_panel » (Shadow Base) n\'est pas démarré : ajoute « ensure pb_panel » après « ensure wframework » dans server.cfg.')
    end
end)
