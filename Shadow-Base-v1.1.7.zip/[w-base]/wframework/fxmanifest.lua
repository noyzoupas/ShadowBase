fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wframework'
description 'Shadow Framework — le framework de Shadow Base (personnage, argent, métiers, gangs, inventaire). Remplace ESX / QBCore / Qbox.'
author 'Shadow Base'
version '1.0.0'

-- À lancer AVANT pb_panel dans server.cfg :  ensure oxmysql / ensure wframework / ensure pb_panel
server_scripts { 'server.lua' }

-- Pour les autres ressources :  shared_script '@wframework/import.lua'  puis  WF.GetMoney(src, 'cash')
files { 'import.lua' }
