# wframework

Le framework de **Shadow Base** (`pb_panel`). Il remplace ESX, QBCore et Qbox : si l'un d'eux (ou ox_inventory, qb-inventory…) tourne, Shadow Base l'arrête.

## Installation (server.cfg)
```
ensure oxmysql
ensure wframework
ensure pb_panel
```
Retire toute ligne `ensure` d'ESX / QBCore / Qbox / ox_inventory et de leurs scripts (`esx_*`, `qb-*`, `qbx_*`).

## Pour tes scripts
Ajoute `shared_script '@wframework/import.lua'` à leur fxmanifest, puis côté serveur :
`WF.GetMoney(src, 'cash')`, `WF.AddMoney(src, 'bank', 500, 'raison')`, `WF.GetJob(src)`, `WF.SetJob(src, 'police', 2)`, `WF.AddItem(src, 'water', 1)`, `WF.HasItem(src, 'water')`, `WF.Notify(src, 'texte', 'success')`…

## Limites
- Les données restent dans les tables `pb_*` de Shadow Base ; cette ressource n'en crée aucune.
- Les scripts écrits pour ESX / QBCore (`ESX = exports['es_extended']…`) ne fonctionnent pas : ils doivent utiliser `WF`.
- Non vérifié dans un vrai client FiveM.
