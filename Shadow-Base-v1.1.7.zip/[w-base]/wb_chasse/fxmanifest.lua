fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_chasse'
description "Shadow Base — chasse : zones, animaux de rareté différente, appeaux, dépeçage, marché aux prix variables, bonus VIP. Extension de pb_panel."
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

shared_script 'shared.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'
