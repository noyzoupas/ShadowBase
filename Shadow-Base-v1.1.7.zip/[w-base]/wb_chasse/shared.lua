-- Shadow Base — Chasse : animaux, appeaux, produits (viande, peaux, trophées).

HUNT_RARITY = {
    { id = 'c',  label = 'Commun',     weight = 60 },
    { id = 'pc', label = 'Peu commun', weight = 26 },
    { id = 'r',  label = 'Rare',       weight = 10 },
    { id = 'e',  label = 'Épique',     weight = 3 },
    { id = 'l',  label = 'Légendaire', weight = 1 },
}
HUNT_RARITY_BY = {}
for i, r in ipairs(HUNT_RARITY) do r.n = i HUNT_RARITY_BY[r.id] = r end

-- loot : { objet, min, max }. hostile : l'animal attaque le chasseur.
ANIMALS = {
    { id = 'lapin',    label = 'Lapin',        model = 'a_c_rabbit_01', rarity = 'c',  loot = { { 'viande_lapin', 1, 1 }, { 'peau_lapin', 1, 1 } } },
    { id = 'biche',    label = 'Biche',        model = 'a_c_deer',      rarity = 'c',  loot = { { 'viande_gibier', 2, 3 }, { 'peau_biche', 1, 1 } } },
    { id = 'coyote',   label = 'Coyote',       model = 'a_c_coyote',    rarity = 'pc', loot = { { 'viande_gibier', 1, 2 }, { 'peau_coyote', 1, 1 } } },
    { id = 'sanglier', label = 'Sanglier',     model = 'a_c_boar',      rarity = 'pc', loot = { { 'viande_sanglier', 2, 4 }, { 'peau_sanglier', 1, 1 } } },
    { id = 'cerf',     label = 'Cerf',         model = 'a_c_deer',      rarity = 'r',  loot = { { 'viande_gibier', 3, 5 }, { 'peau_cerf', 1, 1 }, { 'bois_cerf', 1, 1 } } },
    { id = 'puma',     label = 'Puma',         model = 'a_c_mtlion',    rarity = 'e',  hostile = true, loot = { { 'peau_puma', 1, 1 }, { 'griffes_puma', 1, 2 } } },
    { id = 'panthere', label = 'Panthère noire', model = 'a_c_panther', rarity = 'l',  hostile = true, loot = { { 'peau_panthere', 1, 1 }, { 'griffes_puma', 2, 3 } } },
}
ANIMAL_BY = {}
for _, a in ipairs(ANIMALS) do ANIMAL_BY[a.id] = a end

-- Produits vendus au marché (prix de base, rareté : plus c'est rare, plus le cours chute vite quand on en vend beaucoup)
HUNT_GOODS = {
    { name = 'viande_lapin',    label = 'Viande de lapin',    rarity = 'c',  price = 8,    weight = 300 },
    { name = 'viande_gibier',   label = 'Viande de gibier',   rarity = 'c',  price = 14,   weight = 500 },
    { name = 'viande_sanglier', label = 'Viande de sanglier', rarity = 'pc', price = 22,   weight = 600 },
    { name = 'peau_lapin',      label = 'Peau de lapin',      rarity = 'c',  price = 10,   weight = 200 },
    { name = 'peau_biche',      label = 'Peau de biche',      rarity = 'c',  price = 30,   weight = 800 },
    { name = 'peau_coyote',     label = 'Peau de coyote',     rarity = 'pc', price = 55,   weight = 800 },
    { name = 'peau_sanglier',   label = 'Peau de sanglier',   rarity = 'pc', price = 60,   weight = 900 },
    { name = 'peau_cerf',       label = 'Peau de cerf',       rarity = 'r',  price = 140,  weight = 1200 },
    { name = 'bois_cerf',       label = 'Bois de cerf',       rarity = 'r',  price = 220,  weight = 1500 },
    { name = 'peau_puma',       label = 'Peau de puma',       rarity = 'e',  price = 520,  weight = 1500 },
    { name = 'griffes_puma',    label = 'Griffes de puma',    rarity = 'e',  price = 160,  weight = 100 },
    { name = 'peau_panthere',   label = 'Peau de panthère noire', rarity = 'l', price = 1800, weight = 1500 },
}
HUNT_GOOD_BY = {}
for _, g in ipairs(HUNT_GOODS) do HUNT_GOOD_BY[g.name] = g end

-- Appeaux : utilisés dans une zone de chasse, ils attirent tout de suite un animal (bonus sur chaque rareté c, pc, r, e, l)
CALLS = {
    { name = 'appeau_simple', label = 'Appeau en bois',     price = 40,  mult = { 1.0, 1.2, 1.2, 1.0, 1.0 } },
    { name = 'appeau_pro',    label = 'Appeau électronique', price = 350, mult = { 0.6, 1.4, 2.0, 2.0, 1.5 } },
    { name = 'appeau_vip',    label = 'Appeau VIP « Alpha »', price = 900, mult = { 0.4, 1.2, 2.6, 3.2, 3.6 }, vip = true },
}
CALL_BY = {}
for _, c in ipairs(CALLS) do CALL_BY[c.name] = c end

KNIFE = { name = 'couteau_chasse', label = 'Couteau de dépeçage', price = 250 }
