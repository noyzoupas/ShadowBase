# wb_chasse — chasse (extension Shadow Base)

- **Zones de chasse** posées au Builder (F10 › Builder › Chasse, rayon 150 m réglable) : des animaux y apparaissent régulièrement.
- **Raretés** : lapin et biche (communs), coyote et sanglier (peu communs), cerf (rare), puma (épique, il attaque), panthère noire (légendaire, elle attaque).
- **Appeaux** (boutique du chasseur) : attirent un animal tout de suite, plus souvent rare. L'appeau « Alpha » est réservé aux VIP.
- **Dépeçage** : couteau de dépeçage, E sur l'animal abattu → viande, peaux, bois, griffes. Une arme s'achète à l'armurerie.
- **Marché du chasseur** : chaque vente fait baisser le cours du produit, qui remonte avec le temps. Bonus de revente pour les VIP (15 % par défaut).
- Réglages : panel › Extensions › Chasse.
