# wb_portes — portes verrouillables (extension Shadow Base)

N'importe quelle porte du jeu peut être verrouillée, par **groupes** (ex. « Commissariat », « Labo des Ballas »).

## Gestion (staff, permission `wb_portes.edit`)
Menu staff **F10 › Builder › Portes** (puis Entrée) ou commande **/portes** :
- **Nouveau groupe** : un nom.
- Dans un groupe : **Ajouter une porte** (vise la porte, E ; pour une double porte, ajoute les deux battants), **Qui peut ouvrir** (cases : tout le monde, chaque entreprise, chaque gang / organisation), **Verrouillée par défaut**, **Renommer**, **Supprimer le groupe**.
- **Retirer la porte visée**.

## Joueurs
Devant une porte qu'il a le droit d'utiliser : **E** pour déverrouiller / verrouiller. Le staff en service ouvre toutes les portes. L'état est gardé par le serveur (base de données) et synchronisé pour tous.

## Limites
- Les portes qui ne sont pas des objets « porte » du jeu (décors fixes) ne bougent pas même déverrouillées.
- Non testé dans un vrai client FiveM au moment de l'écriture.
