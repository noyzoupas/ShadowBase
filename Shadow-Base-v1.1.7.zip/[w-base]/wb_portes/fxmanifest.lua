fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_portes'
description 'Shadow Base — portes verrouillables : groupes de portes, accès par entreprise / gang / tout le monde, gestion par le staff (F10 › Builder › Portes ou /portes). Extension de pb_panel.'
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'
