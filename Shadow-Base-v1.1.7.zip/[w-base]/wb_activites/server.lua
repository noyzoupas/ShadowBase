-- Shadow Base — Activités (ouvertes à tous) : récolte -> transformation -> revente, établis de craft.
-- Extension de pb_panel (voir pb_panel/server/core/ext.lua) : réglages dans le panel (Extensions › Activités),
-- points posés en jeu depuis le Builder du menu staff (F10 › Builder › Activités : choisir l'activité puis Entrée sur place).
-- Le serveur décide de tout : distance (au sol), outil, objets, durée écoulée, place dans le sac, plafond horaire.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'
local TPL = {}
for _, t in ipairs(ACT_TEMPLATES) do TPL[t.id] = t end

-- Réglages (cache vidé à chaque changement dans le panel) -------------------------------------------------------------------------------------
local cache = {}
local function cfg(k, d)
    local v = cache[k]
    if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end
    if v == nil then return d end
    return v
end

local XYZ = { { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } }
local function ITEM(k, label) return { k = k, label = label, pattern = '^[%w_]*$', maxlen = 32, lower = true } end
local function cols(...) local out = {} for _, t in ipairs({ ... }) do for _, c in ipairs(t) do out[#out + 1] = c end end return out end

local forms, statsBlocks, catalogBlocks = {}, nil, nil
local function setup()
    W:ExtRegister({ label = 'Activités', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier les activités (récolte, revente, craft)', true)
    W:ExtMigrate(RES .. '_001_log', 'Activités : journal de production', {
        [[CREATE TABLE IF NOT EXISTS wb_activites_log (
            id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, kind VARCHAR(8) NOT NULL, ref VARCHAR(40) NOT NULL, item VARCHAR(40) NOT NULL DEFAULT '',
            qty INT NOT NULL DEFAULT 0, money INT NOT NULL DEFAULT 0, at INT NOT NULL, PRIMARY KEY (id), KEY k_at (at), KEY k_lic (license))]],
    })
    for _, it in ipairs(ACT_ITEMS) do W:EnsureItem(it) end

    forms.main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = 'Activités actives', default = true },
        { k = 'use_dist', type = 'number', label = 'Distance d\'interaction des petits points (m)', default = 2.5, min = 1, max = 10, step = 0.5, int = false },
        { k = 'markers', type = 'toggle', label = 'Marqueurs et cercles au sol', default = true },
        { k = 'blips', type = 'toggle', label = 'Icônes sur la carte', default = true },
        { k = 'max_per_hour', type = 'number', label = 'Actions maximum par joueur et par heure', default = 150, min = 1, max = 2000, hint = 'Anti-farm : récolte, transformation et craft confondus.' },
        { k = 'pay', type = 'select', label = 'Paiement des ventes', opts = { { 'cash', 'Espèces' }, { 'bank', 'Banque' } }, default = 'cash' },
        { k = 'max_sell', type = 'number', label = 'Quantité maximale vendue par passage', default = 100, min = 1, max = 1000 },
        { k = 'eco_mult', type = 'toggle', label = 'Les prix de vente suivent le coefficient de l\'économie', default = true },
    } })
    forms.spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Points posés', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Points', default = {}, wide = true, maxitems = 200, unique = 'id',
          hint = "Pose-les plutôt en jeu : menu staff (F10) › Builder › Activités. Type : harvest (récolte), process (transformation), sell (grossiste), bench (établi). Butin : objet:poids séparés par des virgules (tirage au sort à chaque récolte). Animation : scénario GTA ou dictionnaire|animation. Objet en main : modèle (ex. prop_tool_pickaxe).",
          cols = cols({ { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 } }, XYZ, {
            { k = 'radius', label = 'Rayon', type = 'number', min = 1, max = 80, int = false }, ITEM('tool', 'Outil requis'), ITEM('item_in', 'Objet entrée'), { k = 'qty_in', label = 'Qté entrée', type = 'number', min = 0, max = 500 },
            ITEM('item_out', 'Objet sortie'), { k = 'qty_out', label = 'Qté sortie', type = 'number', min = 0, max = 500 },
            { k = 'loot', label = 'Butin (objet:poids,…)', pattern = '^[%w_:, ]*$', maxlen = 200, lower = true }, { k = 'time', label = 'Durée (s)', type = 'number', min = 0, max = 600 },
            { k = 'anim', label = 'Animation', pattern = '^[%w_@|]*$', maxlen = 80 }, { k = 'prop', label = 'Objet en main', pattern = '^[%w_]*$', maxlen = 48 },
            { k = 'sprite', label = 'Icône carte', type = 'number', min = 0, max = 999 }, { k = 'color', label = 'Couleur icône', type = 'number', min = 0, max = 85 } }) } } })
    forms.market = W:ExtSettings({ ns = NS, id = 'market', title = 'Marché (prix de revente)', perm = PERM, fields = {
        { k = 'market', type = 'rows', label = 'Prix au grossiste', default = ACT_MARKET, wide = true, maxitems = 150, unique = 'item', hint = 'Prix à l\'unité. Seuls ces objets se revendent au grossiste.',
          cols = { { k = 'item', label = 'Objet', pattern = '^[%w_]+$', required = true, maxlen = 32, lower = true }, { k = 'price', label = 'Prix unité ($)', type = 'number', min = 0, max = 1000000 } } } } })
    forms.recipes = W:ExtSettings({ ns = NS, id = 'recipes', title = 'Recettes des établis', perm = PERM, fields = {
        { k = 'recipes', type = 'rows', label = 'Recettes', default = ACT_RECIPES, wide = true, maxitems = 200, unique = 'id',
          hint = "Ingrédients : objet:quantité séparés par des virgules (ex. iron_ingot:2,plank:2). Établi : identifiant d'un point de type bench, vide = tous les établis.",
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'bench', label = 'Établi', pattern = '^[%w_:]*$', maxlen = 40, lower = true },
            { k = 'label', label = 'Nom', required = true, maxlen = 40 }, { k = 'ingredients', label = 'Ingrédients', pattern = '^[%w_:, ]*$', required = true, maxlen = 200, lower = true },
            ITEM('item_out', 'Objet obtenu'), { k = 'qty_out', label = 'Quantité', type = 'number', min = 1, max = 100 }, { k = 'time', label = 'Durée (s)', type = 'number', min = 1, max = 300 } } } } })

    W:ExtModule({
        id = RES, label = 'Activités', icon = 'tool', perm = PERM, hint = 'Pêche, mine, bois, agriculture, cueillette, récupération, craft',
        caps = {
            { 'Récolte avec butin aléatoire, transformation, revente', 'ok', 'Par exemple la pêche donne surtout du poisson, parfois un saumon, rarement une bouteille à la mer.' },
            { 'Pose des points en jeu', 'ok', 'Menu staff (F10) › Builder › Activités : choisir l\'activité puis Entrée sur place. « Supprimer » retire le point le plus proche.' },
            { 'Établis de craft', 'ok', 'Recettes à plusieurs ingrédients, pour tous les établis ou un seul.' },
            { 'Anti-farm', 'ok', 'Distance et durée revérifiées par le serveur, plafond d\'actions par heure.' },
            { 'Objets en main', 'partial', 'Pioche et hache tenues en main ; la canne à pêche vient du scénario GTA.' },
        },
        doc = "## Activités\nOuvertes à tous, sans métier. Le joueur va dans la zone, appuie sur **E** et reste sur place pendant la durée (animation + barre). **X** ou s'éloigner annule.\n\n**Poser les points** : menu staff **F10 › Builder › Activités**, choisis l'activité (zone de pêche, filon, champ, fonderie, grossiste, établi…), va sur place et appuie sur **Entrée**. « Supprimer le point d'activité le plus proche » retire une erreur.\n\nLes objets sont créés au premier démarrage ; modifie-les dans **Inventaire › Objets**.",
        tabs = {
            { id = 'stats', label = 'Production', icon = 'chart', build = function() return statsBlocks() end },
            { id = 'catalog', label = 'Catalogue', icon = 'list', build = function() return catalogBlocks() end },
            { id = 'main', label = 'Réglages', icon = 'sliders', form = forms.main },
            { id = 'spots', label = 'Points posés', icon = 'pin', form = forms.spots },
            { id = 'market', label = 'Marché', icon = 'coins', form = forms.market },
            { id = 'recipes', label = 'Recettes', icon = 'tool', form = forms.recipes },
        },
    })
end

-- Onglets calculés --------------------------------------------------------------------------------------------------------------------------------
local KIND_FR = { harvest = 'Récolte', process = 'Transformation', sell = 'Revente', bench = 'Établi', craft = 'Craft' }
statsBlocks = function()
    local since = os.time() - 86400
    local rows = MySQL.query.await('SELECT kind, ref, item, SUM(qty) AS qty, SUM(money) AS money, COUNT(DISTINCT license) AS players FROM wb_activites_log WHERE at > ? GROUP BY kind, ref, item ORDER BY money DESC, qty DESC LIMIT 100', { since }) or {}
    local total, people = 0, MySQL.scalar.await('SELECT COUNT(DISTINCT license) FROM wb_activites_log WHERE at > ?', { since }) or 0
    local out = {}
    for _, r in ipairs(rows) do
        total = total + (tonumber(r.money) or 0)
        out[#out + 1] = { kind = KIND_FR[r.kind] or r.kind, ref = r.ref, item = r.item, qty = tonumber(r.qty) or 0, money = '$' .. tostring(tonumber(r.money) or 0), players = tonumber(r.players) or 0 }
    end
    return {
        { type = 'stats', items = { { label = 'Argent versé (24 h)', value = '$' .. total, icon = 'coins' }, { label = 'Joueurs actifs (24 h)', value = people, icon = 'users' }, { label = 'Points posés', value = #(cfg('spots', {}) or {}), icon = 'pin' } } },
        { type = 'table', id = 'prod', title = 'Production des dernières 24 h', search = true, rows = out, empty = 'Rien pour le moment.',
          columns = { { k = 'kind', label = 'Activité' }, { k = 'ref', label = 'Point / recette' }, { k = 'item', label = 'Objet' }, { k = 'qty', label = 'Quantité' }, { k = 'money', label = 'Argent' }, { k = 'players', label = 'Joueurs' } } },
    }
end
catalogBlocks = function()
    local placed = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do placed[s.tpl or ''] = (placed[s.tpl or ''] or 0) + 1 end
    local rows = {}
    for _, t in ipairs(ACT_TEMPLATES) do
        local what = t.kind == 'harvest' and (t.loot or '') or (t.kind == 'process' and ('%d %s → %d %s'):format(t.qty_in or 1, t.item_in or '', t.qty_out or 1, t.item_out or '') or '')
        rows[#rows + 1] = { group = t.group, label = t.label, kind = KIND_FR[t.kind], tool = t.tool ~= '' and t.tool or '—', what = what, placed = placed[t.id] or 0 }
    end
    return { { type = 'notice', level = 'info', text = "Pose ces activités en jeu : menu staff (F10) › Builder › Activités, puis Entrée à l'endroit voulu." },
        { type = 'table', id = 'cat', title = 'Activités disponibles', rows = rows, columns = { { k = 'group', label = 'Famille' }, { k = 'label', label = 'Activité' }, { k = 'kind', label = 'Type' }, { k = 'tool', label = 'Outil' }, { k = 'what', label = 'Produit' }, { k = 'placed', label = 'Posés' } } } }
end

-- Données envoyées aux joueurs (positions et libellés seulement) ---------------------------------------------------------------------------------------
local function publicCfg()
    local spots = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do
        spots[#spots + 1] = { id = s.id, kind = s.kind, label = s.label, x = s.x, y = s.y, z = s.z, r = tonumber(s.radius) or 3, sprite = tonumber(s.sprite) or 0, color = tonumber(s.color) or 0 }
    end
    return { enabled = cfg('enabled', true) ~= false, use_dist = tonumber(cfg('use_dist', 2.5)) or 2.5, markers = cfg('markers', true) ~= false, blips = cfg('blips', true) ~= false, spots = spots }
end
local function push(target) TriggerClientEvent(RES .. ':cfg', target or -1, json.encode(publicCfg())) end
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == NS then cache = {} push() end end)
RegisterNetEvent(RES .. ':hello', function() push(source) end)

-- Outils ----------------------------------------------------------------------------------------------------------------------------------------------
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Activités', text) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end

-- Cuisines / bars des entreprises (point « cuisine / bar » posé au Builder de pb_panel) : établi réservé aux employés en service.
-- Recettes : champ « Établi » = biz:<entreprise>, tag:<famille> (bar, resto, sushi, cafe, bakery, icecream, wine, beer) ou cat:<catégorie>.
local KITCHEN_TAG = { bahamas = 'bar', unicorn = 'bar', tequilala = 'bar', pub = 'bar', nightclub = 'bar', nightcover = 'bar', casino = 'bar',
    restaurant = 'resto', pizzeria = 'resto', foodtruck = 'resto', catering = 'resto', sushi = 'sushi', bean = 'cafe', cafe = 'cafe', bakery = 'bakery',
    icecream = 'icecream', vineyard = 'wine', brewery = 'beer' }
local kitchens = {}   -- src -> établi de cuisine ouvert par ce joueur
AddEventHandler('playerDropped', function() kitchens[source] = nil end)
local function spotOf(src, id)
    id = tostring(id or '')
    local k = kitchens[src]
    if k and k.id == id then
        local j = W:GetJob(src)
        if not (j and j.biz == k.biz and j.onDuty) then return nil end
        return k
    end
    return find(cfg('spots', {}), id)
end
local function recipeFits(r, s)
    local b = r.bench or ''
    if s.biz then return b == 'biz:' .. s.biz or b == 'tag:' .. tostring(s.tag or '') or b == 'cat:' .. tostring(s.cat or '') end
    return b == '' or b == s.id
end
local function label(item) local i = W:ItemInfo(item) return i and i.label or item end
local function pairsList(s, sep)
    local out = {}
    for name, n in tostring(s or ''):gmatch('([%w_]+)%s*:%s*(%d+)') do out[#out + 1] = { item = name, n = tonumber(n) } end
    return out
end
local function rollLoot(s)
    local list, total = pairsList(s), 0
    for _, l in ipairs(list) do total = total + l.n end
    if total <= 0 then return nil end
    local r = math.random(1, total)
    for _, l in ipairs(list) do r = r - l.n if r <= 0 then return l.item end end
    return list[#list].item
end
-- distance au sol (le Z des zones posées varie : talus, ponton, champ en pente), avec 15 m de tolérance verticale
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function near(src, s, extra)
    local c = pos(src)
    if not c then return false end
    local dx, dy = c.x - (tonumber(s.x) or 0), c.y - (tonumber(s.y) or 0)
    return math.sqrt(dx * dx + dy * dy) <= (tonumber(s.radius) or 3) + (extra or 3) and math.abs(c.z - (tonumber(s.z) or 0)) <= 15
end
local function log(src, kind, ref, item, qty, money)
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO wb_activites_log (license, kind, ref, item, qty, money, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { lic, kind, ref, item or '', qty or 0, money or 0, os.time() }) end
end

local hourly = {}
local function underCap(src)
    local now = os.time()
    local h = hourly[src]
    if not h or now - h.t >= 3600 then h = { t = now, n = 0 } hourly[src] = h end
    return h.n < (tonumber(cfg('max_per_hour', 150)) or 150)
end
local function countAction(src) local h = hourly[src] if h then h.n = h.n + 1 end end

-- Actions avec durée : début vérifié, fin revérifiée ---------------------------------------------------------------------------------------------------
local busy = {}
AddEventHandler('playerDropped', function() busy[source], hourly[source] = nil, nil end)

local function startJob(src, job)
    busy[src] = job
    job.t0 = os.time()
    TriggerClientEvent(RES .. ':go', src, json.encode({ secs = job.secs, label = job.label, anim = job.anim, prop = job.prop, x = job.spot.x, y = job.spot.y, z = job.spot.z, r = (tonumber(job.spot.radius) or 3) }))
end

RegisterNetEvent(RES .. ':start', function(kind, id, recipeId)
    local src = source
    if not cfg('enabled', true) or busy[src] or type(id) ~= 'string' then return end
    if not W:CanAct(src) then return end
    if not underCap(src) then notify(src, 'warn', 'Tu as assez travaillé pour cette heure : reviens plus tard.') return end
    local s = spotOf(src, id)
    if not s or not near(src, s) then return end
    if kind == 'spot' and (s.kind == 'harvest' or s.kind == 'process') then
        if (s.tool or '') ~= '' and not W:HasItem(src, s.tool, 1) then notify(src, 'error', 'Il te faut : ' .. label(s.tool) .. '.') return end
        if s.kind == 'process' and (W:GetItemCount(src, s.item_in) or 0) < (tonumber(s.qty_in) or 1) then
            notify(src, 'error', ('Il te faut %d × %s.'):format(tonumber(s.qty_in) or 1, label(s.item_in))) return
        end
        local out = s.kind == 'harvest' and (rollLoot(s.loot) or s.item_out) or s.item_out
        if not out or out == '' then return end
        if not W:CanCarryItem(src, out, tonumber(s.qty_out) or 1) then notify(src, 'error', 'Ton sac est plein.') return end
        startJob(src, { kind = s.kind, spot = s, out = out, label = s.label, secs = math.max(1, tonumber(s.time) or 5), anim = s.anim, prop = s.prop })
    elseif kind == 'craft' and s.kind == 'bench' then
        local r = find(cfg('recipes', ACT_RECIPES), tostring(recipeId))
        if not r or not recipeFits(r, s) then return end
        for _, ing in ipairs(pairsList(r.ingredients)) do
            if (W:GetItemCount(src, ing.item) or 0) < ing.n then notify(src, 'error', ('Il manque : %d × %s.'):format(ing.n, label(ing.item))) return end
        end
        if not W:CanCarryItem(src, r.item_out, tonumber(r.qty_out) or 1) then notify(src, 'error', 'Ton sac est plein.') return end
        startJob(src, { kind = 'craft', spot = s, recipe = r.id, label = r.label, secs = math.max(1, tonumber(r.time) or 5), anim = 'PROP_HUMAN_PARKING_METER', prop = '' })
    end
end)

RegisterNetEvent(RES .. ':cancel', function() busy[source] = nil end)

RegisterNetEvent(RES .. ':finish', function()
    local src = source
    local job = busy[src]
    busy[src] = nil
    if not job then return end
    if os.time() - job.t0 < job.secs - 1 then return end                         -- trop tôt : client modifié
    if not near(src, job.spot, 5) then notify(src, 'error', 'Tu t\'es éloigné.') return end
    if not W:CanAct(src) then return end
    if job.kind == 'craft' then
        local r = find(cfg('recipes', ACT_RECIPES), job.recipe)
        if not r then return end
        local ings = pairsList(r.ingredients)
        for _, ing in ipairs(ings) do if (W:GetItemCount(src, ing.item) or 0) < ing.n then notify(src, 'error', 'Il te manque des ingrédients.') return end end
        for _, ing in ipairs(ings) do W:RemoveItem(src, ing.item, ing.n) end
        local q = tonumber(r.qty_out) or 1
        -- cuisine / bar d'une entreprise : le plat part en rayon au comptoir (stock de la cuisine), le reste dans le sac
        local stocked, where = 0, nil
        if job.spot.biz then local ok, n, lab = pcall(function() return W:AddBizStock(job.spot.biz, r.item_out, q) end) if ok and tonumber(n) then stocked, where = tonumber(n), lab end end
        if q - stocked > 0 then W:AddItem(src, r.item_out, q - stocked) end
        countAction(src)
        log(src, 'craft', r.id, r.item_out, q, 0)
        if stocked > 0 then notify(src, 'success', ('Préparé : %d × %s, mis en rayon au comptoir%s.'):format(stocked, label(r.item_out), where and (' « ' .. where .. ' »') or ''))
        else notify(src, 'success', ('Fabriqué : %d × %s.'):format(q, label(r.item_out))) end
        return
    end
    local s = job.spot
    if s.kind == 'process' and not W:RemoveItem(src, s.item_in, tonumber(s.qty_in) or 1) then notify(src, 'error', 'Il te manque : ' .. label(s.item_in) .. '.') return end
    local q = tonumber(s.qty_out) or 1
    if not W:AddItem(src, job.out, q) then
        if s.kind == 'process' then W:AddItem(src, s.item_in, tonumber(s.qty_in) or 1) end   -- rendu si le sac a débordé entre-temps
        notify(src, 'error', 'Ton sac est plein.') return
    end
    countAction(src)
    log(src, s.kind, s.id, job.out, q, 0)
    notify(src, 'success', ('+%d × %s'):format(q, label(job.out)))
    TriggerEvent(RES .. ':done', src, s.kind, s.id, job.out, q)
end)

-- Grossiste et établis : menus construits côté client avec ce que le serveur renvoie ---------------------------------------------------------------------
local function unitPrice(p)
    p = tonumber(p) or 0
    if cfg('eco_mult', true) ~= false then local ok, v = pcall(function() return W:EcoPrice(p) end) if ok and tonumber(v) then return math.floor(tonumber(v)) end end
    return math.floor(p)
end

local function sendMenu(src, s)
    local list = {}
    if s.kind == 'sell' then
        for _, m in ipairs(cfg('market', ACT_MARKET) or {}) do
            local n = W:GetItemCount(src, m.item) or 0
            if n > 0 then list[#list + 1] = { item = m.item, label = label(m.item), count = n, price = unitPrice(m.price) } end
        end
    elseif s.kind == 'bench' then
        for _, r in ipairs(cfg('recipes', ACT_RECIPES) or {}) do
            if recipeFits(r, s) then
                local parts, can = {}, true
                for _, ing in ipairs(pairsList(r.ingredients)) do
                    local have = W:GetItemCount(src, ing.item) or 0
                    if have < ing.n then can = false end
                    parts[#parts + 1] = ('%s %d/%d'):format(label(ing.item), math.min(have, ing.n), ing.n)
                end
                list[#list + 1] = { id = r.id, label = r.label, qty = tonumber(r.qty_out) or 1, time = tonumber(r.time) or 5, need = table.concat(parts, ' · '), can = can }
            end
        end
    else return end
    if s.biz and #list == 0 then W:NotifyPlayer(src, 'warn', s.label, "Aucune recette pour ce métier : ajoute-les dans Activités › Recettes (établi « biz:" .. s.biz .. " »).") return end
    TriggerClientEvent(RES .. ':menu', src, s.id, s.kind, s.label, json.encode(list))
end
RegisterNetEvent(RES .. ':menu', function(id)
    local src = source
    local s = spotOf(src, tostring(id))
    if not s or not near(src, s) then return end
    sendMenu(src, s)
end)
-- pb_panel : un employé en service a appuyé sur E à la cuisine / au bar de son entreprise (évènement serveur, jamais envoyé par un client)
AddEventHandler('pb_panel:bizCraft', function(src, bizId, cat, pointId, x, y, z, label)
    local k = { id = 'biz_' .. tostring(pointId), kind = 'bench', label = tostring(label or 'Cuisine'), x = tonumber(x) or 0, y = tonumber(y) or 0, z = tonumber(z) or 0, radius = 3,
        biz = tostring(bizId), cat = tostring(cat or ''), tag = KITCHEN_TAG[tostring(bizId)] or tostring(cat or '') }
    kitchens[src] = k
    sendMenu(src, k)
end)

local lastSell = {}
RegisterNetEvent(RES .. ':sell', function(id, item)
    local src = source
    local now = GetGameTimer()
    if lastSell[src] and now - lastSell[src] < 800 then return end
    lastSell[src] = now
    if not cfg('enabled', true) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    if not s or s.kind ~= 'sell' or not near(src, s) then return end
    local m
    for _, x in ipairs(cfg('market', ACT_MARKET) or {}) do if x.item == item then m = x end end
    if not m then return end
    local n = math.min(W:GetItemCount(src, m.item) or 0, tonumber(cfg('max_sell', 100)) or 100)
    if n <= 0 then return end
    local price = unitPrice(m.price)
    if not W:RemoveItem(src, m.item, n) then return end
    local total = price * n
    if total > 0 then W:AddMoney(src, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash', total, 'Vente ' .. m.item) end
    log(src, 'sell', s.id, m.item, n, total)
    notify(src, 'success', ('Vendu : %d × %s pour $%d.'):format(n, label(m.item), total))
    TriggerEvent(RES .. ':sold', src, m.item, n, total)
end)

-- Builder du menu staff (F10 › Builder › Activités) : un point par modèle, posé à la position du staff -----------------------------------------------------
local function canPlace(src)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    return ok and r
end
local function newId(tpl)
    local spots = cfg('spots', {}) or {}
    local n = 1
    for _, s in ipairs(spots) do if (s.tpl or '') == tpl then n = n + 1 end end
    local id = tpl .. '_' .. n
    while find(spots, id) do n = n + 1 id = tpl .. '_' .. n end
    return id
end
local function placeSpot(src, what, extra)
    if not canPlace(src) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local best, bd, bi
        for i, s in ipairs(spots) do
            local d = math.sqrt((c.x - s.x) ^ 2 + (c.y - s.y) ^ 2)
            if d < 10.0 and (not bd or d < bd) then best, bd, bi = s, d, i end
        end
        if not best then notify(src, 'error', 'Aucun point d\'activité à moins de 10 m.') return false end
        table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', ('« %s » supprimé.'):format(best.label))
        return true
    end
    local t = TPL[what]
    if not t then return false end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    local row = { id = newId(t.id), tpl = t.id, kind = t.kind, label = name ~= '' and name or t.label,
        x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, radius = t.radius or 3,
        tool = t.tool or '', item_in = t.item_in or '', qty_in = t.qty_in or 0, item_out = t.item_out or '', qty_out = t.qty_out or 0, loot = t.loot or '',
        time = t.time or 0, anim = t.anim or '', prop = t.prop or '', sprite = t.sprite or 0, color = t.color or 0 }
    spots[#spots + 1] = row
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : ' .. row.label)
    notify(src, 'success', ('%s posé ici (rayon %d m).'):format(row.label, row.radius))
    return true
end
local function registerBuilder()
    local points = {}
    for _, t in ipairs(ACT_TEMPLATES) do points[#points + 1] = { id = t.id, label = t.group .. ' : ' .. t.label, ask = 'Nom affiché (vide = « ' .. t.label .. ' »)' } end
    points[#points + 1] = { id = 'delete', label = 'Supprimer le point d\'activité le plus proche' }
    W:RegisterBuilder({ id = 'activites', label = 'Activités', icon = 'tool', points = points }, function(src, what, extra) return placeSpot(src, tostring(what), tostring(extra or '')) end)
end

-- Démarrage : attendre que pb_panel (et sa base) soient prêts --------------------------------------------------------------------------------------------
local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end   -- démarrage simultané : un seul branchement
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^1[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(registerBuilder)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
-- pb_panel redémarré : il a oublié nos pages, actions et points du Builder, on se rebranche
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
