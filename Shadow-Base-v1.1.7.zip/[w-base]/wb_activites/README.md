# wb_activites — activités ouvertes à tous (extension Shadow Base)

Pas de métier : n'importe quel joueur peut pêcher, miner, couper du bois, récolter, cueillir, fouiller la décharge, transformer, revendre et fabriquer.
Extension de `pb_panel` (API `pb_panel/server/core/ext.lua`) : redémarrable seule (`restart wb_activites`).

## Poser les points (en jeu)
Menu staff **F10 › Builder › Activités** → choisis l'activité → (nom facultatif) → va à l'endroit voulu → **Entrée**.
« Supprimer le point d'activité le plus proche » retire un point posé par erreur (10 m).
Les points se retouchent ensuite dans le panel : **Extensions › Activités › Points posés** (rayon, durée, butin, outil…).

## Catalogue
| Famille | Récolte (outil) → butin | Transformation |
|---|---|---|
| Pêche | Zone de pêche (canne) → poisson, saumon, crabe, vieille chaussure, bouteille à la mer (rare) | Poissonnerie : 2 poissons → 1 filet |
| Mine | Filon (pioche) → pierre, fer, cuivre, pépite d'or, diamant brut (très rare) | Fonderie fer, fonderie cuivre, concasseur (pierre → sable), verrerie (sable → verre) |
| Bûcheron | Coupe de bois (hache) → bûche, résine | Scierie : 1 bûche → 2 planches |
| Agriculture | Champ de blé, vignes, verger d'orangers | Moulin (farine), pressoir (vin), presse-agrumes (jus) |
| Cueillette | Forêt → champignons, baies, truffe (rare) | — |
| Récupération | Décharge → ferraille, plastique, débris de verre, vieux téléphone | Recyclerie : ferraille → fer |
| Commerce | Grossiste (revente de tout ce qui précède) | Établi : kit de réparation, outils, pain, crochet, bandage |

Prix, recettes et butins : onglets **Marché**, **Recettes** et **Points posés**.

## Côté joueur
Entrer dans la zone (cercle au sol), **E**, rester sur place (animation, outil en main, barre). **X**, s'éloigner ou monter en voiture annule.

## Sécurité
Le serveur revérifie au départ et à la fin : distance au sol, outil, objets, place dans le sac, durée réellement écoulée, plafond d'actions par heure. Le butin est tiré au sort par le serveur.

## Évènements serveur
`wb_activites:done` (src, kind, spotId, item, qty) · `wb_activites:sold` (src, item, qty, total)
