fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_loading'
description 'Shadow Base — écran de chargement : logo au centre, bandeau qui défile en bas, barre de progression du chargement.'
author 'Shadow Base'
version '1.0.0'

loadscreen 'index.html'

files {
    'index.html',
    'logo.png',
}
