fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_animaux'
description "Shadow Base — animaux de compagnie (VIP) : animalerie, chien ou chat qui suit, monte en voiture, assis, couché. Extension de pb_panel."
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'
