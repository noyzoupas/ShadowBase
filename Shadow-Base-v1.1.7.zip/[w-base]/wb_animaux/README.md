# wb_animaux — animaux de compagnie (extension Shadow Base)

- **Réservés aux VIP** (désactivable). Achat à l'**animalerie** (F10 › Builder › Animaux) : husky, golden retriever, berger allemand, rottweiler, carlin, caniche, westie, chat.
- Un animal **par personnage**, avec le nom de ton choix.
- **/animal** : l'appeler, assis, couché, rester / suivre, le renommer, le renvoyer à la maison. Il monte en voiture avec toi et te rejoint si tu t'éloignes.
- Fin du VIP : l'animal rentre (il revient si le VIP est redonné). Prix : panel › Extensions › Animaux de compagnie.
