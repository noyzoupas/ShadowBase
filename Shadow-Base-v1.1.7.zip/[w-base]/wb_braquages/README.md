# wb_braquages — braquages et trafics (extension Shadow Base)

Tout se pose au Builder : **F10 › Builder › Braquages**. Paiement en argent sale.

- **Cambriolages** : maison à cambrioler → crocheter la porte (crochet), puis fouiller (4 fouilles). Le voisin peut appeler la police. Délai avant de revisiter la même maison.
- **Receleur** (point caché, sans icône, visible seulement quand on est juste à côté) : rachète le butin, vend la perceuse et la charge thermique.
- **Distributeurs** : utilise la **perceuse** depuis l'inventaire près d'un distributeur de la banque (40 s), alerte police.
- **GoFast** : départs **cachés** à trouver en RP. Une voiture chargée à livrer à une arrivée (à plus de 800 m) avant la fin du chrono ; la police reçoit sa position toutes les 45 s. Plus tu arrives tôt, plus tu gagnes.
- **Fourgons blindés** : un fourgon part d'un point posé (toutes les 60 min si assez de policiers). Charge thermique à l'arrière (15 s), puis 4 sacs à ramasser.
- Réglages (gains, délais, policiers minimum) : panel › Extensions › Braquages et trafics.
