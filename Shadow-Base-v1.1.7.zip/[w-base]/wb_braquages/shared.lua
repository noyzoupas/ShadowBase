-- Shadow Base — Braquages et trafics : cambriolages, receleur, distributeurs, GoFast, fourgons blindés.

BURGLARY_LOOT = {   -- objet, poids du tirage, prix chez le receleur
    { name = 'butin_bijoux',     label = 'Bijoux volés',          w = 30, price = 180 },
    { name = 'butin_montre',     label = 'Montre de luxe',        w = 18, price = 450 },
    { name = 'butin_portable',   label = 'Ordinateur portable',   w = 16, price = 380 },
    { name = 'butin_console',    label = 'Console de jeux',       w = 14, price = 260 },
    { name = 'butin_tableau',    label = "Tableau d'art",         w = 6,  price = 1200 },
    { name = 'butin_cash',       label = 'Liasse de billets',     w = 12, price = 300 },
    { name = 'butin_statuette',  label = 'Statuette en or',       w = 4,  price = 1800 },
}
BURGLARY_BY = {}
for _, b in ipairs(BURGLARY_LOOT) do BURGLARY_BY[b.name] = b end

TOOLS = {
    { name = 'perceuse',  label = 'Perceuse', price = 1500, desc = "Utilise-la près d'un distributeur pour le forcer." },
    { name = 'thermite',  label = 'Charge thermique', price = 4000, desc = "Pour ouvrir l'arrière d'un fourgon blindé." },
}
