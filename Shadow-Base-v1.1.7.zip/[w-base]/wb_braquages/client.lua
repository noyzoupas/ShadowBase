-- Shadow Base — Braquages et trafics (client) : invites E, crochetage, fouilles, perceuse, GoFast (voiture, chrono, GPS), fourgon blindé.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {}, atms = {} }
local near = {}          -- points cachés signalés par le serveur (juste à côté)
local busy = false
local houseOpen = {}     -- maison -> fouilles restantes
local gf                 -- GoFast en cours
local truckNet, truckBlip

local function notify(kind, text) W:Notify({ type = kind, title = 'Illégal', text = text }) end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
-- geste + barre ; X ou s'éloigner annule
local function act(label, secs, dict, clip, scenario)
    local ped = PlayerPedId()
    local at = GetEntityCoords(ped)
    if scenario then TaskStartScenarioInPlace(ped, scenario, 0, true) elseif dict and loadDict(dict) then TaskPlayAnim(ped, dict, clip, 3.0, 3.0, -1, 1, 0, false, false, false) end
    W:Progress(label, secs)
    local stop, ok = GetGameTimer() + secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - at) > 3.0 then ok = false break end
    end
    ClearPedTasks(ped)
    if not ok then W:CancelProgress() end
    return ok
end

RegisterNetEvent(RES .. ':cfg', function(j) local ok, c = pcall(json.decode, j) if ok and type(c) == 'table' then C = c end end)
RegisterNetEvent(RES .. ':near', function(j) local ok, l = pcall(json.decode, j) near = ok and l or {} end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(3000)
    TriggerServerEvent(RES .. ':hello')
end)

-- Invite unique : point le plus proche parmi maisons, receleurs / GoFast (cachés), distributeurs, arrivée du GoFast, fourgon
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 700
        if C.enabled and not busy and isFree() and not IsPedInAnyVehicle(PlayerPedId(), false) then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd, text
            local function consider(p, d, t) if d < 2.2 and (not bd or d < bd) then best, bd, text = p, d, t end end
            for _, s in ipairs(C.spots or {}) do
                if s.kind == 'house' then
                    local d = #(c - vector3(s.x, s.y, s.z))
                    if d < 20 then sleep = 200 end
                    consider(s, d, houseOpen[s.id] and ('Fouiller la maison (%d)'):format(houseOpen[s.id]) or ('Crocheter la porte : ' .. s.label))
                end
            end
            for _, s in ipairs(near) do
                local d = #(c - vector3(s.x, s.y, s.z))
                sleep = math.min(sleep, 200)
                consider(s, d, s.kind == 'fence' and 'Parler au receleur' or 'Prendre un GoFast')
            end
            if truckNet and NetworkDoesNetworkIdExist(truckNet) then
                local v = NetToVeh(truckNet)
                if DoesEntityExist(v) then
                    local rear = GetOffsetFromEntityInWorldCoords(v, 0.0, -4.2, 0.0)
                    local d = #(c - rear)
                    if d < 30 then sleep = 0 end
                    consider({ kind = 'truck', x = rear.x, y = rear.y, z = rear.z }, d, GetVehicleDoorAngleRatio(v, 2) > 0.1 and 'Ramasser un sac' or "Poser la charge thermique à l'arrière")
                end
            end
            if best then
                sleep = 0
                if shown ~= text then shown = text W:Prompt(text, 'E', best.x, best.y, best.z) end
                if IsControlJustPressed(0, 38) then
                    hide()
                    local k = best.kind
                    if k == 'house' then TriggerServerEvent(RES .. ':house', best.id, houseOpen[best.id] and 'search' or 'pick')
                    elseif k == 'fence' then TriggerServerEvent(RES .. ':fence', best.id, 'menu')
                    elseif k == 'gofast_start' then TriggerServerEvent(RES .. ':gofast', best.id, 'start')
                    elseif k == 'atm' then TriggerServerEvent(RES .. ':atm', best.id, 'start')
                    elseif k == 'truck' then
                        local v = NetToVeh(truckNet)
                        if GetVehicleDoorAngleRatio(v, 2) > 0.1 then if act('Ramassage du sac', 4, 'anim@heists@ornate_bank@grab_cash', 'grab') then TriggerServerEvent(RES .. ':truck', 'loot') end
                        else TriggerServerEvent(RES .. ':truck', 'charge') end
                    end
                    Wait(600)
                end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Cambriolage
RegisterNetEvent(RES .. ':lockpick', function(id)
    busy = true
    local ok = act('Crochetage de la serrure', 8, 'mini@safe_cracking', 'idle_base')
    busy = false
    if ok then TriggerServerEvent(RES .. ':house', id, 'picked') else notify('warn', 'Crochetage interrompu.') end
end)
RegisterNetEvent(RES .. ':houseopen', function(id, left)
    houseOpen[id] = (left or 0) > 0 and left or nil
    if left and left > 0 then
        busy = true
        local ok = act('Fouille de la maison', 6, nil, nil, 'PROP_HUMAN_BUM_BIN')
        busy = false
        if ok then TriggerServerEvent(RES .. ':house', id, 'search') end
    end
end)

-- Receleur
RegisterNetEvent(RES .. ':fencemenu', function(id, j)
    local d = json.decode(j or '{}') or {}
    local items = { { type = 'separator', label = 'Revendre' } }
    for _, b in ipairs(d.loot or {}) do
        items[#items + 1] = { label = b.label, right = b.n > 0 and (b.n .. ' × $' .. b.price) or ('$' .. b.price), disabled = b.n <= 0 or nil, onSelect = function() TriggerServerEvent(RES .. ':fence', id, 'sell', b.item) end }
    end
    items[#items + 1] = { type = 'separator', label = 'Matériel (espèces)' }
    for _, t in ipairs(d.tools or {}) do items[#items + 1] = { label = t.label, right = '$' .. t.price, description = t.desc, onSelect = function() TriggerServerEvent(RES .. ':fence', id, 'buy', t.item) end } end
    W:CloseMenu()
    W:OpenMenu({ id = RES .. '.fence', title = 'Receleur', subtitle = 'Pas de questions', items = items })
end)

-- Distributeur
RegisterNetEvent(RES .. ':drill', function(id, secs)
    busy = true
    local ok = act('Perçage du distributeur', secs, nil, nil, 'WORLD_HUMAN_WELDING')
    busy = false
    TriggerServerEvent(RES .. ':atm', id, ok and 'done' or 'cancel')
end)

-- GoFast : voiture chargée, GPS vers l'arrivée, chrono à l'écran
RegisterNetEvent(RES .. ':gfgo', function(j)
    local d = json.decode(j or '{}')
    if not d then return end
    local models = { 'sultan', 'kuruma', 'jester', 'elegy2', 'comet2' }
    local h = joaat(models[math.random(#models)])
    RequestModel(h)
    local t = GetGameTimer() + 5000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
    local ped = PlayerPedId()
    local c = GetOffsetFromEntityInWorldCoords(ped, 0.0, 4.0, 0.0)
    local v = CreateVehicle(h, c.x, c.y, c.z + 0.5, GetEntityHeading(ped), true, false)
    SetModelAsNoLongerNeeded(h)
    SetVehicleOnGroundProperly(v)
    SetVehicleNumberPlateText(v, ('GF%05d'):format(math.random(0, 99999)))
    SetEntityAsMissionEntity(v, true, true)
    gf = { veh = v, x = d.x, y = d.y, z = d.z, label = d.label, deadline = GetGameTimer() + d.secs * 1000 }
    TriggerServerEvent(RES .. ':gofast', '', 'car', VehToNet(v))
    gf.blip = AddBlipForCoord(d.x + 0.0, d.y + 0.0, d.z + 0.0)
    SetBlipSprite(gf.blip, 1) SetBlipColour(gf.blip, 1) SetBlipRoute(gf.blip, true) SetBlipRouteColour(gf.blip, 1)
    notify('info', ("GoFast : livre la voiture à « %s » en moins de %d minutes. La police va te pister."):format(d.label, math.floor(d.secs / 60)))
end)
local function endGf()
    if not gf then return end
    if gf.blip and DoesBlipExist(gf.blip) then RemoveBlip(gf.blip) end
    gf = nil
end
CreateThread(function()
    while true do
        if not gf then Wait(500) else
            Wait(0)
            local left = math.max(0, math.floor((gf.deadline - GetGameTimer()) / 1000))
            SetTextFont(4) SetTextScale(0.5, 0.5) SetTextColour(255, 210, 80, 230) SetTextOutline() SetTextCentre(true)
            BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(('GoFast · %02d:%02d'):format(math.floor(left / 60), left % 60)) EndTextCommandDisplayText(0.5, 0.06)
            local ped = PlayerPedId()
            if not DoesEntityExist(gf.veh) or IsEntityDead(gf.veh) then notify('error', 'La voiture est perdue : GoFast raté.') TriggerServerEvent(RES .. ':gofast', '', 'fail') endGf()
            elseif left <= 0 then notify('error', 'Trop tard : GoFast raté.') TriggerServerEvent(RES .. ':gofast', '', 'fail') endGf()
            elseif #(GetEntityCoords(gf.veh) - vector3(gf.x, gf.y, gf.z)) < 10.0 and GetEntitySpeed(gf.veh) < 2.0 then
                if IsPedInVehicle(ped, gf.veh, false) then TaskLeaveVehicle(ped, gf.veh, 0) Wait(1500) end
                TriggerServerEvent(RES .. ':gofast', '', 'drop')
                endGf()
            end
        end
    end
end)

-- Fourgon blindé
RegisterNetEvent(RES .. ':truckspawn', function(j)
    local d = json.decode(j or '{}')
    if not d then return end
    local h = joaat('stockade')
    RequestModel(h)
    local t = GetGameTimer() + 5000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
    local v = CreateVehicle(h, d.x, d.y, d.z + 0.5, (d.h or 0) + 0.0, true, false)
    local dm = joaat('s_m_m_security_01')
    RequestModel(dm)
    t = GetGameTimer() + 3000
    while not HasModelLoaded(dm) and GetGameTimer() < t do Wait(20) end
    local driver = CreatePedInsideVehicle(v, 26, dm, -1, true, false)
    SetModelAsNoLongerNeeded(h) SetModelAsNoLongerNeeded(dm)
    SetEntityAsMissionEntity(v, true, true)
    SetBlockingOfNonTemporaryEvents(driver, true)
    TaskVehicleDriveWander(driver, v, 14.0, 786603)
    TriggerServerEvent(RES .. ':truck', 'spawned', VehToNet(v))
end)
RegisterNetEvent(RES .. ':truckinfo', function(j)
    local d = json.decode(j or '{}')
    if truckBlip and DoesBlipExist(truckBlip) then RemoveBlip(truckBlip) end
    truckBlip = AddBlipForRadius(d.x + 0.0, d.y + 0.0, d.z + 0.0, 300.0)
    SetBlipColour(truckBlip, 1) SetBlipAlpha(truckBlip, 70)
    SetTimeout(10 * 60000, function() if truckBlip and DoesBlipExist(truckBlip) then RemoveBlip(truckBlip) truckBlip = nil end end)
    -- le réseau : retrouver l'identifiant du fourgon pour l'invite (le plus proche « stockade »)
    CreateThread(function()
        local t = GetGameTimer() + 600000
        while GetGameTimer() < t and not truckNet do
            Wait(2000)
            for _, v in ipairs(GetGamePool('CVehicle')) do if GetEntityModel(v) == joaat('stockade') and NetworkGetEntityIsNetworked(v) then truckNet = VehToNet(v) break end end
        end
    end)
end)
RegisterNetEvent(RES .. ':truckboom', function(net, secs)
    truckNet = net
    CreateThread(function()
        Wait(secs * 1000)
        if not NetworkDoesNetworkIdExist(net) then return end
        local v = NetToVeh(net)
        if not DoesEntityExist(v) then return end
        local rear = GetOffsetFromEntityInWorldCoords(v, 0.0, -4.0, 0.0)
        AddExplosion(rear.x, rear.y, rear.z, 2, 0.3, true, false, 1.0)
        SetVehicleDoorOpen(v, 2, false, false) SetVehicleDoorOpen(v, 3, false, false)
        SetVehicleUndriveable(v, true)
        TriggerServerEvent(RES .. ':truck', 'opened')
    end)
end)
RegisterNetEvent(RES .. ':truckend', function()
    truckNet = nil
    if truckBlip and DoesBlipExist(truckBlip) then RemoveBlip(truckBlip) truckBlip = nil end
end)
