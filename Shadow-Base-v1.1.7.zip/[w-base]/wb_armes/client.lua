-- Shadow Base — Atelier d'armes clandestin (client) : invite E à côté d'un atelier caché, menu de fabrication, geste + barre,
-- mini-jeu d'assemblage (touche affichée à presser à temps) pour les armes.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local near = {}          -- ateliers signalés par le serveur (juste à côté)
local busy = false
local data               -- dernier menu reçu

local function notify(kind, text) W:Notify({ type = kind, title = 'Atelier', text = text }) end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end

RegisterNetEvent(RES .. ':near', function(j) local ok, l = pcall(json.decode, j) near = ok and type(l) == 'table' and l or {} end)

-- Invite E ------------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if #near > 0 and not busy and isFree() and not IsPedInAnyVehicle(PlayerPedId(), false) then
            sleep = 200
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(near) do local d = #(c - vector3(s.x, s.y, s.z)) if d < 2.0 and (not bd or d < bd) then best, bd = s, d end end
            if best then
                sleep = 0
                if shown ~= best.id then shown = best.id W:Prompt('Utiliser l\'établi', 'E', best.x, best.y, best.z) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':open', best.id) Wait(500) end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Menu --------------------------------------------------------------------------------------------------------------------------------------------
local function needsText(r, n)
    local parts = {}
    for _, x in ipairs(r.needs) do parts[#parts + 1] = ('%s %d/%d'):format(x.label, x.have, x.need * n) end
    return table.concat(parts, ' · ')
end
local function recipeMenu(r)
    local qty = 1
    return { id = RES .. '.r.' .. r.id, title = r.label, subtitle = ('Niveau %d · %ds'):format(r.level, r.time), build = function()
        local items = {}
        for _, x in ipairs(r.needs) do
            local ok = x.have >= x.need * qty
            items[#items + 1] = { label = x.label, right = ('%d / %d'):format(x.have, x.need * qty), badge = ok and 'OK' or 'MANQUE', disabled = not ok or nil }
        end
        if r.plan then items[#items + 1] = { label = r.plan, right = r.planOk and 'Possédé' or 'Manquant', badge = r.planOk and 'OK' or 'MANQUE', disabled = not r.planOk or nil } end
        items[#items + 1] = { type = 'separator', label = 'Fabrication' }
        if r.batch > 1 then
            local list = {}
            for i = 1, r.batch do list[i] = tostring(i) end
            items[#items + 1] = { type = 'list', label = 'Quantité', list = list, index = qty, description = ('Donne %d × %s par lot.'):format(r.qty, r.out), onChange = function(_, _, i) qty = i W:RefreshMenu() end }
        end
        local why = not r.lvOk and ('Niveau d\'armurier %d requis.'):format(r.level) or (r.plan and not r.planOk) and 'Plan manquant (marché noir).' or nil
        items[#items + 1] = { label = 'Fabriquer', icon = 'wrench', right = r.qty * qty > 1 and ('× ' .. r.qty * qty) or nil, disabled = why ~= nil or nil,
            description = why or (('Chance de raté : %d %%.'):format(r.fail) .. (r.cat == 'weapons' and ' Le mini-jeu d\'assemblage améliore la finition.' or '')),
            onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':start', data.id, r.id, qty) end }
        return items
    end }
end
local function openMenu()
    if not data then return end
    local items = {}
    local prog = data.next and ('%d / %d XP'):format(data.xp, data.next) or (data.xp .. ' XP · niveau maximum')
    items[#items + 1] = { label = ('Armurier niveau %d'):format(data.level), right = prog, disabled = true, description = 'Le niveau débloque des recettes, réduit les ratés et améliore la finition.' }
    for _, c in ipairs(data.cats or {}) do
        local sub = {}
        for _, r in ipairs(data.recipes or {}) do
            if r.cat == c.id then
                sub[#sub + 1] = { type = 'submenu', label = r.label, right = not r.lvOk and ('Niv. ' .. r.level) or (r.plan and not r.planOk) and 'Plan' or (r.can and 'Prêt' or nil),
                    badge = r.can and 'OK' or nil, description = needsText(r, 1), submenu = recipeMenu(r) }
            end
        end
        if #sub > 0 then items[#items + 1] = { type = 'submenu', label = c.label, icon = c.icon, description = c.desc, submenu = { id = RES .. '.c.' .. c.id, title = c.label, subtitle = data.label, items = sub } } end
    end
    local mk = {}
    for _, m in ipairs(data.market or {}) do
        if m.plan then
            mk[#mk + 1] = { label = m.label, right = m.owned and 'Possédé' or ('$' .. m.price), disabled = m.owned or nil, description = 'Plan : jamais consommé.', onSelect = function() TriggerServerEvent(RES .. ':buy', data.id, m.item, 1) end }
        else
            local list = { '1', '5', '10', '25' }
            mk[#mk + 1] = { type = 'list', label = m.label, list = list, index = 1, right = '$' .. m.price .. ' / u', description = 'Entrée : acheter la quantité choisie.',
                onSelect = function(_, v) TriggerServerEvent(RES .. ':buy', data.id, m.item, tonumber(v) or 1) end }
        end
    end
    items[#items + 1] = { type = 'submenu', label = 'Marché noir', icon = 'coins', description = data.dirty and 'Payé en argent sale si tu en as assez, sinon en espèces.' or 'Payé en espèces.', submenu = { id = RES .. '.market', title = 'Marché noir', subtitle = data.label, items = mk } }
    W:CloseMenu()
    W:OpenMenu({ id = RES .. '.main', title = data.label, subtitle = 'Établi', items = items })
end
RegisterNetEvent(RES .. ':menu', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    data = d
    if not busy then openMenu() end
end)

-- Fabrication : geste + barre ; X ou s'éloigner annule ; mini-jeu pour les armes -----------------------------------------------------------------------
local KEYS = { { 'E', 38 }, { 'G', 47 }, { 'F', 23 } }
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
RegisterNetEvent(RES .. ':go', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    busy = true
    local ped = PlayerPedId()
    local at = GetEntityCoords(ped)
    if d.mini then TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_WELDING', 0, true)
    elseif loadDict('mini@repair') then TaskPlayAnim(ped, 'mini@repair', 'fixing_a_ped', 3.0, 3.0, -1, 1, 0, false, false, false) end
    W:Progress(d.label .. (d.n > 1 and (' × ' .. d.n) or ''), d.secs)
    local stop, done, score = GetGameTimer() + d.secs * 1000, true, 0
    -- 3 moments d'assemblage répartis dans la fabrication : la touche affichée doit être pressée en moins de 1,4 s
    local marks = {}
    if d.mini then for i = 1, 3 do marks[i] = { at = GetGameTimer() + math.floor(d.secs * 1000 * (i / 4)) + math.random(-800, 800), key = KEYS[math.random(#KEYS)] } end end
    local cur
    while GetGameTimer() < stop do
        Wait(0)
        local t = GetGameTimer()
        if not cur and marks[1] and t >= marks[1].at then cur = table.remove(marks, 1) cur.until_ = t + 1400 W:Prompt('Ajuste la pièce !', cur.key[1]) end
        if cur then
            local pressed
            for _, k in ipairs(KEYS) do if IsControlJustPressed(0, k[2]) then pressed = k end end
            if pressed then
                if pressed == cur.key then score = score + 1 PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                else PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
                cur = nil W:HidePrompt()
            elseif t > cur.until_ then cur = nil W:HidePrompt() PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
        end
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - at) > 3.0 then done = false break end
    end
    if cur then W:HidePrompt() end
    ClearPedTasks(ped)
    busy = false
    if not done then W:CancelProgress() notify('warn', 'Fabrication interrompue.') TriggerServerEvent(RES .. ':cancel') return end
    if d.mini then notify(score == 3 and 'success' or 'info', ('Assemblage : %d / 3 gestes parfaits.'):format(score)) end
    TriggerServerEvent(RES .. ':done', score)
end)
