# burgershot — Burger Shot pour Shadow Base

Le client commande et paie à une **borne tactile**, un équipier **prépare** la commande aux postes de cuisine
(mini-jeux), puis la **remet** au client en main propre, au comptoir ou en **livraison**.

## Installation

1. Mets le dossier `burgershot` à côté de `pb_panel` (le `server.cfg` fourni contient déjà `ensure burgershot`).
2. Redémarre le serveur. Au démarrage, la ressource :
   - vérifie l'entreprise **Burger Shot** (catalogue Shadow Base, catégorie Restauration) et la crée si besoin ;
   - crée les 15 objets de la carte dans l'inventaire (`bs_bleeder`, `bs_fries`…), avec leurs effets faim / soif / stress.
3. Place les points en jeu (voir plus bas) : les coordonnées par défaut sont approximatives,
   surtout si ton Burger Shot a un intérieur (MLO).

## Placer les points : `/bsplace`

Réservé au staff (droit `burgershot.edit` ou ACE `command`). Place-toi à l'endroit voulu puis :

| Commande | Point |
|---|---|
| `/bsplace kiosk` | ajoute une borne de commande (autant que tu veux) |
| `/bsplace counter` | comptoir (retrait des commandes) |
| `/bsplace kds` | écran de cuisine |
| `/bsplace grill` · `fryer` · `drinks` · `dessert` · `assembly` | postes de cuisine |
| `/bsplace garage` | sortie des scooters de livraison (ton orientation compte) |
| `/bsplace board` | tableau des numéros de commande (en hauteur) |
| `/bsplace address Nom du lieu` | adresse de livraison pour les commandes de PNJ |
| `/bsplace clear kiosks` · `/bsplace clear addresses` | vide une liste |
| `/bsplace reset` | revient aux points par défaut |

Les points sont enregistrés dans `data/points.json` et envoyés aussitôt à tous les joueurs.
Le point de **prise de service** se place comme pour toute entreprise Shadow Base (panel › Entreprises › Burger Shot).

## Déroulé

**Client**
1. Borne (E) : carte par catégories, menus avec boisson au choix, panier, *sur place* ou *livraison*, espèces ou carte.
2. Ticket avec numéro ; le suivi s'affiche en bas à droite (payée → en cuisine → prête → remise),
   avec la distance du livreur et son repère sur la carte.
3. Remise : les articles arrivent dans l'inventaire, puis note (étoiles) et pourboire facultatif.

**Équipier en service**
1. Une nouvelle commande sonne. Écran de cuisine (E) : *Prendre en charge*.
2. Postes indiqués (grill, friteuse, boissons, desserts, montage) : un mini-jeu par poste,
   la qualité finale dépend des scores. Raté (< 35 %) : on recommence.
3. Au poste Montage : *Emballer* → le sac est en main.
4. Remise au client (E à côté de lui), ou pose au comptoir. Livraison : GPS vers le client en direct,
   scooter au garage.

**Commandes de PNJ** : quand des équipiers sont en service, des clients PNJ commandent à livrer à une adresse.
Un PNJ attend sur place ; la vente est payée à l'entreprise.

**Sans équipier** : *cuisine automatique* (réglable) — la commande est prête après un délai, à retirer au comptoir.

## Argent

- Le client paie la borne : l'argent va dans la **caisse de l'entreprise**.
- À la remise, l'équipier touche une **prime** (% réglable) et le livreur les **frais de livraison**, pris dans la caisse.
- **Pourboire** : du compte du client vers celui de l'équipier.
- Commande non remise après le délai réglé, annulée par un manager, ou ressource arrêtée : **remboursement**
  (même si le client est déconnecté : il est crédité à sa prochaine connexion).

## Réglages (panel Shadow Base › Serveur › Burger Shot)

Bornes ouvertes, cuisine automatique et sa durée, prime, frais de livraison et part du livreur, commandes de PNJ
(fréquence, nombre max), prix de toute la carte (%), prix par article (`bleeder|11`), articles retirés,
délai de remboursement, difficulté des postes, grade minimum pour annuler.

## Sécurité

Le serveur décide de tout : prix recalculés côté serveur, distances vérifiées (borne, postes, comptoir, client, adresse),
service vérifié, mini-jeux avec jeton à usage unique et durée minimale, anti-spam par action.

## Crédits

Images des produits : celles de l'inventaire Shadow Base (ox_inventory, GPL-3.0), chargées depuis `pb_panel` — non copiées ici.
