fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'burgershot'
description 'Burger Shot : bornes de commande, cuisine, livraison — pour Shadow Base (pb_panel)'
version '1.0.0'

dependency 'pb_panel'

ui_page 'html/index.html'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

files {
  'html/index.html',
  'html/style.css',
  'html/app.js',
}
