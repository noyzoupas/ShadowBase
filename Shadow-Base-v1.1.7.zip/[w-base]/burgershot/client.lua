-- Burger Shot (client) : points en jeu, interface (borne, écran de cuisine, mini-jeux, suivi), sac en main, livraison.

local Points, duty = {}, false
local queue, work, carry, mine = {}, nil, nil, nil
local board = { cooking = {}, ready = {} }
local ui = nil                    -- 'kiosk' | 'kds' | 'game' | 'rate'
local bag, npc, targetBlip, courierBlip, deliveryVeh = nil, nil, nil, nil, nil
local game = nil                  -- { token, station }

local function v3(p) return vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0) end
local function notify(text, kind) pcall(function() exports.pb_panel:Notify({ type = kind or 'info', title = 'Burger Shot', text = text }) end) end
-- Invite « E » : l'étiquette de Shadow Base accrochée au dernier point dessiné (au lieu de l'aide du jeu en haut à gauche)
local hlMsg, hlAt, lastMark, lastMarkAt = nil, 0, nil, 0
local function help(msg)
  msg = tostring(msg):gsub('~INPUT_CONTEXT~%s*', '')
  hlAt = GetGameTimer()
  if msg ~= hlMsg then
    hlMsg = msg
    local p = (GetGameTimer() - lastMarkAt < 250) and lastMark or nil
    pcall(function() exports.pb_panel:Prompt(msg, 'E', p and p.x, p and p.y, p and (p.z - 0.2)) end)
  end
end
CreateThread(function() while true do Wait(250) if hlMsg and GetGameTimer() - hlAt > 350 then hlMsg = nil pcall(function() exports.pb_panel:HidePrompt() end) end end end)
-- petit point lumineux (même rendu que Shadow Base)
local function marker(p)
  lastMark, lastMarkAt = p, GetGameTimer()
  local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
  DrawMarker(28, p.x + 0.0, p.y + 0.0, p.z + 0.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
  DrawMarker(28, p.x + 0.0, p.y + 0.0, p.z + 0.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local function text3d(x, y, z, txt, scale)
  SetTextScale(scale or 0.38, scale or 0.38) SetTextFont(4) SetTextProportional(true) SetTextCentre(true) SetTextOutline()
  SetTextColour(255, 255, 255, 235)
  BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(txt)
  SetDrawOrigin(x, y, z, 0) EndTextCommandDisplayText(0.0, 0.0) ClearDrawOrigin()
end
local function send(t) SendNUIMessage(t) end
local function setUi(name, cursor)
  ui = name
  SetNuiFocus(name ~= nil, name ~= nil and cursor ~= false)
end
local function loadModel(name)
  local h = joaat(name)
  if not IsModelInCdimage(h) then return nil end
  RequestModel(h)
  local t = GetGameTimer() + 5000
  while not HasModelLoaded(h) and GetGameTimer() < t do Wait(0) end
  return HasModelLoaded(h) and h or nil
end
local function loadDict(d)
  RequestAnimDict(d)
  local t = GetGameTimer() + 3000
  while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(0) end
  return HasAnimDictLoaded(d)
end
local function giveAnim()
  local ped = PlayerPedId()
  if loadDict('mp_common') then TaskPlayAnim(ped, 'mp_common', 'givetake1_a', 8.0, -8.0, 1800, 49, 0, false, false, false) end
end

-- Sac Burger Shot en main ----------------------------------------------------------------------------------------------------------
local function dropBag() if bag and DoesEntityExist(bag) then DeleteEntity(bag) end bag = nil end
local function holdBag()
  dropBag()
  local h = loadModel(Config.BagProp)
  if not h then return end
  local ped = PlayerPedId()
  local c = GetEntityCoords(ped)
  bag = CreateObject(h, c.x, c.y, c.z + 0.2, true, true, false)
  AttachEntityToEntity(bag, ped, GetPedBoneIndex(ped, 57005), 0.38, 0.0, -0.03, 0.0, -90.0, 90.0, true, true, false, true, 1, true)
  SetModelAsNoLongerNeeded(h)
end

-- Repères de livraison ---------------------------------------------------------------------------------------------------------------
local function clearTarget() if targetBlip and DoesBlipExist(targetBlip) then RemoveBlip(targetBlip) end targetBlip = nil end
local function setTarget(x, y, z, label)
  if not targetBlip or not DoesBlipExist(targetBlip) then
    targetBlip = AddBlipForCoord(x + 0.0, y + 0.0, z + 0.0)
    SetBlipSprite(targetBlip, 280) SetBlipColour(targetBlip, 47) SetBlipScale(targetBlip, 0.95) SetBlipRoute(targetBlip, true) SetBlipRouteColour(targetBlip, 47)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(label or 'Client Burger Shot') EndTextCommandSetBlipName(targetBlip)
  else SetBlipCoords(targetBlip, x + 0.0, y + 0.0, z + 0.0) end
end
local function clearCourier() if courierBlip and DoesBlipExist(courierBlip) then RemoveBlip(courierBlip) end courierBlip = nil end
local function clearNpc()
  if npc and DoesEntityExist(npc) then
    local p = npc
    TaskWanderStandard(p, 10.0, 10)
    SetTimeout(15000, function() if DoesEntityExist(p) then DeleteEntity(p) end end)
  end
  npc = nil
end

-- Événements serveur -----------------------------------------------------------------------------------------------------------------
RegisterNetEvent('bs:points', function(p) Points = type(p) == 'table' and p or {} end)
RegisterNetEvent('bs:duty', function(on)
  duty = on == true
  if not duty then work = nil send({ action = 'work', order = nil }) end
end)
RegisterNetEvent('bs:board', function(c, r) board.cooking, board.ready = c or {}, r or {} end)

RegisterNetEvent('bs:catalog', function(data)
  if ui then return end
  setUi('kiosk')
  send({ action = 'kiosk', data = data })
end)
RegisterNetEvent('bs:orderResult', function(r) send({ action = 'orderResult', result = r }) end)

RegisterNetEvent('bs:mine', function(o)
  mine = o
  send({ action = 'track', order = o })
  if not o or o.state ~= 'ready' then clearCourier() end
end)
RegisterNetEvent('bs:courier', function(id, x, y, z)
  if not mine or mine.id ~= id then return end
  local d = #(GetEntityCoords(PlayerPedId()) - vector3(x, y, z))
  send({ action = 'courier', dist = math.floor(d) })
  if d < 25.0 then clearCourier() return end
  if not courierBlip or not DoesBlipExist(courierBlip) then
    courierBlip = AddBlipForCoord(x, y, z)
    SetBlipSprite(courierBlip, 226) SetBlipColour(courierBlip, 47) SetBlipScale(courierBlip, 0.9)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Livreur Burger Shot') EndTextCommandSetBlipName(courierBlip)
  else SetBlipCoords(courierBlip, x, y, z) end
end)

RegisterNetEvent('bs:queue', function(list, me, manager)
  queue = list or {}
  if ui == 'kds' then send({ action = 'queue', list = queue, me = me, manager = manager }) end
  send({ action = 'board', cooking = #queue })
end)
RegisterNetEvent('bs:kdsOpen', function(data)
  if ui then return end
  setUi('kds')
  send({ action = 'kds', data = data, list = queue })
end)
RegisterNetEvent('bs:work', function(o) work = o send({ action = 'work', order = o, carry = carry }) end)
RegisterNetEvent('bs:ding', function(id, name, mode)
  PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
  notify(('Nouvelle commande #%d — %s (%s).'):format(id, name, mode == 'delivery' and 'livraison' or 'sur place'), 'info')
end)

RegisterNetEvent('bs:carry', function(c)
  carry = c
  clearTarget()
  if c then
    holdBag()
    work = nil
    if c.npc and c.address then setTarget(c.address.x, c.address.y, c.address.z, 'Livraison : ' .. (c.address.label or c.name)) end
    notify(c.npc and ('Livre la commande #%d à %s (repère GPS).'):format(c.id, c.address and c.address.label or c.name)
      or ('Remets la commande #%d à %s, ou pose-la au comptoir.'):format(c.id, c.name), 'info')
  else
    dropBag() clearNpc()
  end
  send({ action = 'work', order = work, carry = carry })
end)
RegisterNetEvent('bs:target', function(id, x, y, z)
  if not carry or carry.id ~= id or carry.npc then return end
  if #(GetEntityCoords(PlayerPedId()) - vector3(x, y, z)) < 15.0 then clearTarget() return end
  setTarget(x, y, z, 'Client : ' .. (carry.name or ''))
end)
RegisterNetEvent('bs:giveAnim', giveAnim)
RegisterNetEvent('bs:rate', function(id, who, quality)
  CreateThread(function()
    local t = GetGameTimer() + 4000
    while ui and GetGameTimer() < t do Wait(200) end
    if ui then return end
    setUi('rate')
    send({ action = 'rate', id = id, who = who, quality = quality })
  end)
end)

-- Mini-jeux des postes ------------------------------------------------------------------------------------------------------------------
local function stopWorkAnim() ClearPedTasks(PlayerPedId()) FreezeEntityPosition(PlayerPedId(), false) end
RegisterNetEvent('bs:game', function(g)
  if ui then return end
  game = { token = g.token, station = g.station }
  local st = Config.Stations[g.station] or {}
  local ped = PlayerPedId()
  local p = Points[g.station]
  if p then SetEntityHeading(ped, GetHeadingFromVector_2d(p.x - GetEntityCoords(ped).x, p.y - GetEntityCoords(ped).y)) end
  FreezeEntityPosition(ped, true)
  if st.scenario then TaskStartScenarioInPlace(ped, st.scenario, 0, true)
  elseif st.anim and loadDict(st.anim[1]) then TaskPlayAnim(ped, st.anim[1], st.anim[2], 4.0, -4.0, -1, 1, 0, false, false, false) end
  setUi('game', false)
  send({ action = 'game', game = g })
end)

-- Scooter de livraison -------------------------------------------------------------------------------------------------------------
RegisterNetEvent('bs:vehicleOk', function(model)
  local h = loadModel(model)
  local g = Points.garage
  if not h or not g then return end
  if deliveryVeh and DoesEntityExist(deliveryVeh) then DeleteEntity(deliveryVeh) end
  deliveryVeh = CreateVehicle(h, g.x + 0.0, g.y + 0.0, g.z + 0.0, (g.h or 0) + 0.0, true, false)
  SetVehicleNumberPlateText(deliveryVeh, 'BURGER' .. math.random(10, 99))
  SetVehicleColours(deliveryVeh, 38, 89)
  SetVehicleOnGroundProperly(deliveryVeh)
  TaskWarpPedIntoVehicle(PlayerPedId(), deliveryVeh, -1)
  SetModelAsNoLongerNeeded(h)
  notify('Scooter de livraison prêt. Ramène-le au garage à la fin du service.', 'success')
end)

-- Interface (NUI) --------------------------------------------------------------------------------------------------------------------
RegisterNUICallback('close', function(_, cb)
  if ui == 'game' then stopWorkAnim() game = nil end
  setUi(nil)
  cb('ok')
end)
RegisterNUICallback('order', function(d, cb) TriggerServerEvent('bs:order', d) cb('ok') end)
RegisterNUICallback('take', function(d, cb) TriggerServerEvent('bs:take', d.id) cb('ok') end)
RegisterNUICallback('cancel', function(d, cb) TriggerServerEvent('bs:cancel', d.id) cb('ok') end)
RegisterNUICallback('gameDone', function(d, cb)
  cb('ok')
  stopWorkAnim()
  setUi(nil)
  if game then TriggerServerEvent('bs:gameDone', game.token, d.score) end
  game = nil
end)
RegisterNUICallback('rate', function(d, cb)
  cb('ok')
  setUi(nil)
  TriggerServerEvent('bs:rate', d.id, d.stars, d.tip)
end)

-- Points en jeu : bornes, comptoir, cuisine, garage, tableau --------------------------------------------------------------------------
local function counterAction()
  if carry and not carry.npc then return 'Poser la commande #' .. carry.id .. ' au comptoir', function() TriggerServerEvent('bs:counter', carry.id) end end
  if mine and mine.state == 'counter' then return 'Récupérer ta commande #' .. mine.id, function() TriggerServerEvent('bs:pickup') end end
  if duty and not carry then
    for _, o in ipairs(queue) do if o.state == 'counter' then return 'Reprendre la commande #' .. o.id .. ' pour la remettre', function() TriggerServerEvent('bs:pickup') end end end
  end
end

local function stationHint(id)
  local st = Config.Stations[id]
  if not work then return st.label .. ' : prends d’abord une commande à l’écran' end
  if id == 'assembly' and work.state == 'cooked' then return 'Emballer la commande #' .. work.id end
  for _, s in ipairs(work.stations or {}) do
    if s.id == id then return s.done and (st.label .. ' : fait ✓') or (st.verb .. ' ×' .. s.need .. ' — ' .. st.label) end
  end
  return st.label .. ' : rien pour la commande #' .. work.id
end

CreateThread(function()
  TriggerServerEvent('bs:hello')
  while true do
    local sleep = 700
    if ui == nil and next(Points) then
      local ped = PlayerPedId()
      local c = GetEntityCoords(ped)
      local press = false
      -- bornes
      for _, k in ipairs(Points.kiosks or {}) do
        local d = #(c - v3(k))
        if d < 15.0 then
          sleep = 0
          marker(k)
          if d < Config.KioskDistance then
            help('~INPUT_CONTEXT~ Commander au Burger Shot')
            if IsControlJustPressed(0, 38) then TriggerServerEvent('bs:catalog') press = true end
          end
        end
      end
      -- comptoir
      if Points.counter and not press then
        local d = #(c - v3(Points.counter))
        if d < 15.0 then
          local label, fn = counterAction()
          if label then
            sleep = 0
            marker(Points.counter, 255, 199, 44)
            if d < 2.2 then help('~INPUT_CONTEXT~ ' .. label) if IsControlJustPressed(0, 38) then fn() end end
          end
        end
      end
      -- cuisine (équipiers en service)
      if duty then
        if Points.kds then
          local d = #(c - v3(Points.kds))
          if d < 12.0 then
            sleep = 0 marker(Points.kds, 95, 212, 244)
            if d < 2.0 then help('~INPUT_CONTEXT~ Écran de cuisine (' .. #queue .. ' commande(s))') if IsControlJustPressed(0, 38) then TriggerServerEvent('bs:kds') end end
          end
        end
        for _, id in ipairs(Config.StationOrder) do
          local p = Points[id]
          if p then
            local d = #(c - v3(p))
            if d < 8.0 then
              sleep = 0
              marker(p, 255, 122, 26)
              if d < Config.StationDistance then
                help('~INPUT_CONTEXT~ ' .. stationHint(id))
                if IsControlJustPressed(0, 38) then TriggerServerEvent('bs:station', id) end
              end
            end
          end
        end
        if Points.garage then
          local d = #(c - v3(Points.garage))
          if d < 15.0 then
            sleep = 0 marker(Points.garage, 255, 122, 26)
            if d < 4.0 then
              local veh = GetVehiclePedIsIn(ped, false)
              if veh ~= 0 and veh == deliveryVeh then
                help('~INPUT_CONTEXT~ Ranger le scooter de livraison')
                if IsControlJustPressed(0, 38) then TaskLeaveVehicle(ped, veh, 0) SetTimeout(1500, function() if DoesEntityExist(veh) then DeleteEntity(veh) end end) deliveryVeh = nil end
              elseif veh == 0 then
                help('~INPUT_CONTEXT~ Prendre un scooter de livraison')
                if IsControlJustPressed(0, 38) then TriggerServerEvent('bs:vehicle') end
              end
            end
          end
        end
      end
      -- tableau des commandes
      if Points.board and (#board.cooking > 0 or #board.ready > 0) then
        local b = Points.board
        if #(c - v3(b)) < 25.0 then
          sleep = 0
          local function nums(t) local s = {} for i = 1, math.min(#t, 8) do s[i] = '#' .. t[i] end return #s > 0 and table.concat(s, '  ') or '—' end
          text3d(b.x, b.y, b.z + 0.25, '~o~BURGER SHOT~s~  ·  Commandes', 0.5)
          text3d(b.x, b.y, b.z, 'En cuisine : ' .. nums(board.cooking), 0.42)
          text3d(b.x, b.y, b.z - 0.22, '~g~Prêtes : ' .. nums(board.ready), 0.42)
        end
      end
    end
    Wait(sleep)
  end
end)

-- Livraison : remise au client (joueur ou PNJ) -------------------------------------------------------------------------------------------
CreateThread(function()
  while true do
    if not carry or ui then Wait(500) else
      local w = 400
      local ped = PlayerPedId()
      local c = GetEntityCoords(ped)
      if bag and not DoesEntityExist(bag) then holdBag() end
      if carry.npc and carry.address then
        local a = v3(carry.address)
        local d = #(c - a)
        if d < 80.0 and not npc then
          -- le client sur le trottoir le plus proche de l'adresse (jamais sur un toit ni au milieu de la route), une fois la zone chargée
          RequestCollisionAtCoord(a.x, a.y, a.z)
          local okSafe, safe = GetSafeCoordForPed(a.x, a.y, a.z, true, 16)
          if not okSafe then okSafe, safe = GetSafeCoordForPed(a.x, a.y, a.z, false, 16) end
          local px, py, pz = a.x, a.y, a.z
          if okSafe then px, py, pz = safe.x, safe.y, safe.z
          else local okG, gz = GetGroundZFor_3dCoord(a.x, a.y, a.z + 1.5, false) if okG then pz = gz end end
          local h = loadModel(Config.NpcModels[math.random(#Config.NpcModels)])
          if h then
            npc = CreatePed(4, h, px, py, pz, math.random(0, 359) + 0.0, false, true)
            PlaceObjectOnGroundProperly(npc)
            SetEntityAsMissionEntity(npc, true, true) SetBlockingOfNonTemporaryEvents(npc, true) SetEntityInvincible(npc, true)
            TaskStartScenarioInPlace(npc, 'WORLD_HUMAN_STAND_MOBILE', 0, true)
            SetModelAsNoLongerNeeded(h)
          end
        end
        if npc and DoesEntityExist(npc) then
          local dn = #(c - GetEntityCoords(npc))
          if dn < 2.5 then
            w = 0
            help('~INPUT_CONTEXT~ Remettre la commande #' .. carry.id .. ' à ' .. carry.name)
            if IsControlJustPressed(0, 38) then
              TaskTurnPedToFaceEntity(npc, ped, 800) ClearPedTasks(npc)
              giveAnim()
              if loadDict('mp_common') then TaskPlayAnim(npc, 'mp_common', 'givetake1_b', 8.0, -8.0, 1800, 49, 0, false, false, false) end
              TriggerServerEvent('bs:handnpc', carry.id)
              Wait(1500)
            end
          end
        end
      elseif carry.customer then
        local pl = GetPlayerFromServerId(carry.customer)
        if pl ~= -1 then
          local tp = GetPlayerPed(pl)
          if tp ~= 0 and tp ~= ped then
            local d = #(c - GetEntityCoords(tp))
            if d < Config.HandDistance then
              w = 0
              help('~INPUT_CONTEXT~ Remettre la commande #' .. carry.id .. ' à ' .. carry.name)
              if IsControlJustPressed(0, 38) then TaskTurnPedToFaceEntity(ped, tp, 600) TriggerServerEvent('bs:handover', carry.id) Wait(1500) end
            end
          end
        end
      end
      Wait(w)
    end
  end
end)

AddEventHandler('onResourceStop', function(res)
  if res ~= GetCurrentResourceName() then return end
  if ui then SetNuiFocus(false, false) end
  dropBag() clearTarget() clearCourier()
  if npc and DoesEntityExist(npc) then DeleteEntity(npc) end
  if deliveryVeh and DoesEntityExist(deliveryVeh) then DeleteEntity(deliveryVeh) end
  stopWorkAnim()
end)

-- Suggestion dans le chat (Shadow Base et chat de base FiveM)
CreateThread(function()
  Wait(2000)
  TriggerEvent('chat:addSuggestion', '/bsplace', 'Burger Shot : placer un point à ta position (staff)', {
    { name = 'point', help = 'kiosk, counter, kds, grill, fryer, drinks, dessert, assembly, garage, board, address, clear, reset' },
    { name = 'nom', help = 'nom de l\'adresse (avec address)' } })
end)
