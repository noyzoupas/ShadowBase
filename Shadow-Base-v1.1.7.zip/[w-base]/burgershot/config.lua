Config = {}

Config.Business = 'burgershot'          -- identifiant de l'entreprise dans Shadow Base (catalogue : Restauration)
Config.ImageBase = 'https://cfx-nui-pb_panel/web/img/'   -- images de Shadow Base (servies par pb_panel)

--[[
  Carte. Les prix se règlent aussi dans le panel (Serveur > Burger Shot).
  stations : postes de cuisine nécessaires (grill, fryer, drinks, dessert, assembly)
  hunger / thirst / stress : effets quand on consomme l'objet (inventaire Shadow Base, objet « bs_<id> »)
]]
Config.Categories = {
  { id = 'menus', label = 'Menus', emoji = '🍱' },
  { id = 'burgers', label = 'Burgers', emoji = '🍔' },
  { id = 'sides', label = 'Accompagnements', emoji = '🍟' },
  { id = 'drinks', label = 'Boissons', emoji = '🥤' },
  { id = 'desserts', label = 'Desserts', emoji = '🍩' },
}

Config.Items = {
  bleeder      = { cat = 'burgers', label = 'The Bleeder', price = 9, kcal = 640, emoji = '🍔', img = 'ox/burger.png', stations = { 'grill', 'assembly' }, hunger = 45, thirst = -4, desc = 'Steak grillé, cheddar fondu, oignons et sauce Burger Shot.' },
  heartstopper = { cat = 'burgers', label = 'Heart Stopper', price = 14, kcal = 1240, emoji = '🍔', img = 'ox/burger.png', stations = { 'grill', 'assembly' }, hunger = 70, thirst = -8, stress = -4, desc = 'Double steak, double bacon, double cheddar. Pour les vrais.' },
  prickly      = { cat = 'burgers', label = 'Prickly Burger', price = 11, kcal = 720, emoji = '🍗', img = 'ox/burger_chicken.png', stations = { 'fryer', 'assembly' }, hunger = 50, thirst = -4, desc = 'Poulet croustillant, salade iceberg, mayo piquante.' },
  meatfree     = { cat = 'burgers', label = 'Meat Free', price = 10, kcal = 560, emoji = '🥬', img = 'ox/burger.png', stations = { 'grill', 'assembly' }, hunger = 40, thirst = -3, desc = 'Galette végétale grillée, tomate, pickles.' },
  torpedo      = { cat = 'burgers', label = 'Torpedo', price = 9, kcal = 610, emoji = '🥖', img = 'items/sandwich.svg', stations = { 'assembly' }, hunger = 42, thirst = -3, desc = 'Long sandwich poulet, crudités et sauce blanche.' },
  fries        = { cat = 'sides', label = 'Frites', price = 4, kcal = 340, emoji = '🍟', img = 'ox/fries.png', stations = { 'fryer' }, hunger = 20, thirst = -5, desc = 'Frites fines et salées, croustillantes.' },
  nuggets      = { cat = 'sides', label = 'Nuggets x6', price = 6, kcal = 290, emoji = '🍗', img = 'items/_snack.svg', stations = { 'fryer' }, hunger = 25, thirst = -3, desc = 'Six nuggets de poulet, sauce au choix du chef.' },
  rings        = { cat = 'sides', label = 'Onion Rings', price = 5, kcal = 310, emoji = '🧅', img = 'items/_snack.svg', stations = { 'fryer' }, hunger = 18, thirst = -3, desc = 'Rondelles d’oignon panées.' },
  sprunk       = { cat = 'drinks', label = 'Sprunk', price = 3, kcal = 150, emoji = '🥤', img = 'ox/sprunk.png', stations = { 'drinks' }, thirst = 35, desc = 'Le soda vert qui pique.' },
  ecola        = { cat = 'drinks', label = 'eCola', price = 3, kcal = 160, emoji = '🥤', img = 'items/soda.svg', stations = { 'drinks' }, thirst = 35, desc = 'Le cola original de Los Santos.' },
  water        = { cat = 'drinks', label = 'Eau minérale', price = 2, kcal = 0, emoji = '💧', img = 'ox/water.png', stations = { 'drinks' }, thirst = 40, desc = 'Fraîche et plate.' },
  coffee       = { cat = 'drinks', label = 'Café', price = 3, kcal = 5, emoji = '☕', img = 'items/coffee.svg', stations = { 'drinks' }, thirst = 15, stress = -6, desc = 'Serré, pour tenir le service.' },
  shake        = { cat = 'desserts', label = 'Milkshake', price = 5, kcal = 480, emoji = '🥛', img = 'items/soda.svg', stations = { 'dessert' }, hunger = 10, thirst = 25, stress = -4, desc = 'Vanille, fraise ou chocolat, bien épais.' },
  donut        = { cat = 'desserts', label = 'Donut', price = 3, kcal = 260, emoji = '🍩', img = 'ox/donut.png', stations = { 'dessert' }, hunger = 15, stress = -3, desc = 'Glaçage rose et vermicelles.' },
  icecream     = { cat = 'desserts', label = 'Glace vanille', price = 4, kcal = 210, emoji = '🍦', img = 'items/_snack.svg', stations = { 'dessert' }, hunger = 8, thirst = 6, stress = -5, desc = 'Cornet vanille à l’italienne.' },
}

-- Menus : contenu fixe + une boisson au choix
Config.Menus = {
  menu_bleeder   = { label = 'Menu Bleeder', price = 14, emoji = '🍱', img = 'ox/burger.png', contents = { 'bleeder', 'fries' }, choice = { 'sprunk', 'ecola', 'water' }, desc = 'Bleeder + frites + boisson.' },
  menu_moneyshot = { label = 'Money Shot Meal', price = 21, emoji = '💰', img = 'ox/burger.png', contents = { 'heartstopper', 'fries', 'donut' }, choice = { 'sprunk', 'ecola', 'water', 'shake' }, desc = 'Heart Stopper + frites + donut + boisson. Le best-seller.' },
  menu_prickly   = { label = 'Menu Prickly', price = 16, emoji = '🍗', img = 'ox/burger_chicken.png', contents = { 'prickly', 'nuggets' }, choice = { 'sprunk', 'ecola', 'water' }, desc = 'Prickly Burger + nuggets + boisson.' },
  menu_kids      = { label = 'Menu Kids', price = 9, emoji = '🎈', img = 'items/_snack.svg', contents = { 'meatfree', 'fries', 'icecream' }, choice = { 'water', 'sprunk' }, desc = 'Meat Free + frites + glace + boisson.' },
}

-- Postes de cuisine : mini-jeu, animation et accessoire
Config.Stations = {
  grill    = { label = 'Grill', game = 'flip', verb = 'Cuire', scenario = 'PROP_HUMAN_BBQ' },
  fryer    = { label = 'Friteuse', game = 'fry', verb = 'Frire', anim = { 'mini@repair', 'fixing_a_ped' } },
  drinks   = { label = 'Fontaine à boissons', game = 'fill', verb = 'Servir', anim = { 'mini@repair', 'fixing_a_ped' } },
  dessert  = { label = 'Desserts', game = 'timing', verb = 'Garnir', anim = { 'mini@repair', 'fixing_a_ped' } },
  assembly = { label = 'Montage', game = 'combo', verb = 'Monter', anim = { 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', 'machinic_loop_mechandplayer' } },
}
Config.StationOrder = { 'grill', 'fryer', 'drinks', 'dessert', 'assembly' }

Config.MaxUnits = 20             -- articles maximum par commande
Config.KioskDistance = 3.0
Config.StationDistance = 2.5
Config.HandDistance = 3.0
Config.BagProp = 'prop_paper_bag_small'
Config.DeliveryVehicles = { 'faggio', 'faggio2' }
Config.NpcModels = { 'a_m_y_hipster_01', 'a_f_y_hipster_02', 'a_m_m_business_01', 'a_f_y_business_02', 'a_m_y_skater_01', 'a_f_m_tourist_01', 'a_m_y_vinewood_01', 'a_f_y_genhot_01' }

--[[
  Points par défaut, autour du Burger Shot de Del Perro (siège Shadow Base -1192, -884).
  À placer précisément en jeu avec /bsplace (sauvegardé dans data/points.json), surtout avec un intérieur (MLO).
]]
Config.DefaultPoints = {
  kiosks   = { { x = -1189.5, y = -884.6, z = 13.9, h = 305.0 }, { x = -1190.7, y = -883.1, z = 13.9, h = 305.0 } },
  counter  = { x = -1193.4, y = -892.7, z = 14.0 },
  kds      = { x = -1196.0, y = -894.5, z = 14.0 },
  grill    = { x = -1198.0, y = -895.5, z = 14.0 },
  fryer    = { x = -1199.2, y = -897.0, z = 14.0 },
  drinks   = { x = -1195.0, y = -896.4, z = 14.0 },
  dessert  = { x = -1194.0, y = -897.6, z = 14.0 },
  assembly = { x = -1197.3, y = -898.6, z = 14.0 },
  garage   = { x = -1172.0, y = -881.0, z = 14.1, h = 30.0 },
  board    = { x = -1191.5, y = -887.0, z = 15.6 },
  -- adresses de livraison des commandes de PNJ (bord de route)
  addresses = {
    { x = -14.5, y = -1441.5, z = 31.1, label = 'Grove Street' },
    { x = 95.0, y = -1810.0, z = 27.0, label = 'Davis' },
    { x = 240.0, y = -1700.0, z = 29.2, label = 'Strawberry' },
    { x = 128.0, y = -1298.0, z = 29.2, label = 'Vanilla Unicorn' },
    { x = 195.0, y = -935.0, z = 30.7, label = 'Legion Square' },
    { x = 300.0, y = -600.0, z = 43.3, label = 'Hôpital Pillbox' },
    { x = 430.0, y = -980.0, z = 30.7, label = 'Commissariat Mission Row' },
    { x = -660.0, y = -880.0, z = 24.5, label = 'Little Seoul' },
    { x = -670.0, y = -170.0, z = 37.7, label = 'Rockford Hills' },
    { x = -818.0, y = 177.5, z = 72.2, label = 'Rockford Hills (villa)' },
    { x = -1450.0, y = -546.0, z = 34.7, label = 'Del Perro' },
    { x = -1130.0, y = -1090.0, z = 2.2, label = 'Canaux de Vespucci' },
    { x = -1600.0, y = -1040.0, z = 13.0, label = 'Ponton de Del Perro' },
    { x = 1229.5, y = -725.5, z = 60.6, label = 'Mirror Park' },
  },
}
