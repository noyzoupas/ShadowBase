// Données de démonstration — à remplacer par tes vraies emotes
// type : "emote" | "shared" | "props" | "action"
const EMOTES = [];
for (let i = 0; i < 27; i++) {
  EMOTES.push({
    id: `emote_${i}`,
    name: "Emote #128",
    category: "Danse",
    type: i < 18 ? "emote" : ["shared", "props", "action"][i % 3],
    image: null, // ex: "img/emotes/dance1.png"
  });
}

const STAR_SVG =
  '<svg viewBox="0 0 13 13"><path d="M6.5 0.9l1.6 3.4 3.7.5-2.7 2.6.7 3.7-3.3-1.8-3.3 1.8.7-3.7L1.2 4.8l3.7-.5z"/></svg>';

let currentTab = "emote";
let favorites = new Set(["emote_0"]);

try {
  const saved = JSON.parse(localStorage.getItem("emote_favorites"));
  if (Array.isArray(saved)) favorites = new Set(saved);
} catch (_) {}

const app = document.getElementById("app");
const grid = document.getElementById("grid");
const search = document.getElementById("search");
const tabs = document.querySelectorAll(".tab");

// ---------- Mise à l'échelle (maquette 1920x1080) ----------
function fit() {
  const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
  app.style.setProperty("--scale", scale);
}
window.addEventListener("resize", fit);
fit();

// ---------- Rendu ----------
function render() {
  const query = search.value.trim().toLowerCase();

  const list = EMOTES.filter((e) => {
    const inTab = currentTab === "favorites" ? favorites.has(e.id) : e.type === currentTab;
    const match = !query || e.name.toLowerCase().includes(query) || e.category.toLowerCase().includes(query);
    return inTab && match;
  });

  if (!list.length) {
    grid.innerHTML = '<p class="empty">Aucune animation trouvée</p>';
    return;
  }

  grid.innerHTML = list
    .map((e) => {
      const fav = favorites.has(e.id);
      return `
      <div class="card" data-id="${e.id}">
        ${e.image ? `<img class="card-image" src="${e.image}" alt="">` : ""}
        <button class="fav ${fav ? "active" : ""}" data-fav="${e.id}" aria-label="Favori">${STAR_SVG}</button>
        <div class="card-info">
          <div class="card-category">${e.category}</div>
          <div class="card-name">${e.name}</div>
        </div>
      </div>`;
    })
    .join("");
}

tabs.forEach((tab) =>
  tab.addEventListener("click", () => {
    tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    currentTab = tab.dataset.cat;
    render();
  })
);

search.addEventListener("input", render);
document.getElementById("search-btn").addEventListener("click", () => search.focus());

grid.addEventListener("click", (ev) => {
  const fav = ev.target.closest("[data-fav]");
  if (fav) {
    const id = fav.dataset.fav;
    favorites.has(id) ? favorites.delete(id) : favorites.add(id);
    try { localStorage.setItem("emote_favorites", JSON.stringify([...favorites])); } catch (_) {}
    render();
    return;
  }
  const card = ev.target.closest(".card");
  if (card) playEmote(card.dataset.id);
});

// ---------- Thème (couleur réglée dans le panel Shadow Base > Menu animations) ----------
// color : "#rrggbb", ou absent pour le vert néon d'origine ; neon : effet néon ; neonPower : intensité en %
// Accepte #rgb, #rrggbb, #rrggbbaa et rgb(r, g, b) ; renvoie [r, g, b] ou null
function parseColor(c) {
  c = String(c || "").trim();
  let m = c.match(/^#([0-9a-f]{3})$/i);
  if (m) return [...m[1]].map((x) => parseInt(x + x, 16));
  m = c.match(/^#([0-9a-f]{6})([0-9a-f]{2})?$/i);
  if (m) return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16));
  m = c.match(/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/i);
  if (m) return m.slice(1, 4).map((x) => Math.min(255, Number(x)));
  return null;
}

// Luminance relative (0 = noir, 1 = blanc)
function luminance([r, g, b]) {
  const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}

// Une couleur trop sombre disparaîtrait sur le fond sombre du menu : on l'éclaircit juste assez, en gardant sa teinte
function visible(rgb) {
  let out = rgb, t = 0;
  while (luminance(out) < 0.2 && t < 1) {
    t += 0.05;
    out = rgb.map((v) => Math.round(v + (255 - v) * t));
  }
  return out;
}

function applyTheme({ color, neon = true, neonPower = 100 } = {}) {
  const root = document.documentElement.style;
  const parsed = parseColor(color);
  const custom = parsed && parsed.join(",") !== "0,248,149";
  const rgb = (custom ? visible(parsed) : [0, 248, 149]).join(", ");
  root.setProperty("--accent-rgb", rgb);
  root.setProperty("--glow-rgb", custom ? rgb : "102, 187, 106");
  root.setProperty("--neon-k", Math.max(0.2, Math.min(2, (Number(neonPower) || 100) / 100)));
  app.classList.toggle("no-neon", !neon);
}

// ---------- Intégration FiveM (NUI) — ignorée dans un navigateur normal ----------
const IN_GAME = typeof GetParentResourceName === "function";

function post(endpoint, data = {}) {
  if (!IN_GAME) return;
  fetch(`https://${GetParentResourceName()}/${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
}

function playEmote(id) {
  post("playEmote", { id });
}

window.addEventListener("message", (ev) => {
  const { action, emotes } = ev.data || {};
  if (action === "open") app.style.display = "block";
  if (action === "close") app.style.display = "none";
  if (action === "theme") applyTheme(ev.data);
  if (action === "setEmotes" && Array.isArray(emotes)) {
    EMOTES.length = 0;
    EMOTES.push(...emotes);
    render();
  }
});

document.addEventListener("keyup", (ev) => {
  if (ev.key === "Escape") post("close");
});

// En jeu : caché jusqu'à l'ouverture. Hors FiveM : fond blanc pour comparer avec la maquette
if (IN_GAME) app.style.display = "none";
else document.body.classList.add("preview");

render();
