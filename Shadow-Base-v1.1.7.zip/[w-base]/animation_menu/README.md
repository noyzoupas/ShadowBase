# animation_menu (Shadow Base)

Menu des animations (emotes) pour FiveM, avec l'UI de la maquette Figma, branché sur Shadow Base (`pb_panel` / `wframework`).

## Installation

1. Copie le dossier `animation_menu` à côté de `pb_panel` et `wframework`.
   Le `server.cfg` fourni contient déjà la ligne `ensure animation_menu`.
2. Redémarre le serveur (ou `refresh` puis `ensure animation_menu` dans la console).

## Utilisation

- **F9** : ouvrir / fermer le menu (ou `/animmenu`) — F1 à F7 et F10 sont déjà pris par Shadow Base
- **Échap** : fermer le menu
- **Clic sur une carte** : lancer l'animation
- **X** : arrêter l'animation (ou `/stopemote`)
- **Étoile** : favoris (gardés d'une session à l'autre)

Chaque joueur peut changer les touches dans *Paramètres > Raccourcis clavier > FiveM*.

## Ce qui est branché sur Shadow Base

- **Emote partager** (Checker, Serrer la main, Câlin, Porter, Se faire porter) : utilise les gestes à deux
  de Shadow Base. L'invitation part au joueur le plus proche, il accepte avec **Y** ou refuse avec **N** ;
  pb_panel vérifie la distance et joue l'animation des deux côtés.
- **Notifications** : celles de Shadow Base (« Impossible à terre », « Personne à proximité »…).
- **Règles** : comme le menu Animations de Shadow Base — pas d'animation à terre, menotté ou en véhicule.
- **Catalogue** : les animations de Shadow Base (danses, humeur, repos, sport, gestes) sont reprises dans `config.lua`.

## Couleur (panel Shadow Base)

Dans le panel : **Serveur > Menu animations**.
- **Couleur du menu** : *Couleur du serveur (Identité)* (par défaut, suit aussi les fêtes),
  *Couleur d'accent des menus*, *Couleur personnalisée* ou *Vert néon d'origine*.
- **Effet néon** et **intensité du néon** (arc de droite et écriture du bas).

Les changements s'appliquent en direct aux joueurs connectés, sans redémarrer.
Côté code : `pb_panel/server/game/animmenu.lua` (réglages) ; le menu les reçoit avec la configuration de jeu
(`pb:g:cfg`) ou via `exports.pb_panel:GetClientConfig()`.

## Menu ALT

L'entrée **ALT > Animations** de Shadow Base ouvre ce menu : dans `pb_panel/server/game/ctxmenu.lua` (ligne 23),
la commande de l'entrée `animations` est `animmenu` au lieu de `pb_anims`. Pour revenir à l'ancien menu,
remets `cmd = 'pb_anims'`.

## Ajouter des emotes

Tout se passe dans `config.lua` (`Config.Emotes`). Pour une image sur la carte, mets le fichier dans
`html/img/emotes/` et renseigne `image = 'img/emotes/mon_image.png'`
(et ajoute `'html/img/emotes/*.png'` dans `files` de `fxmanifest.lua`).

## Police des cases

Le nom des emotes utilise **SF Pro Display Semibold**. Mets `SF-Pro-Display-Semibold.otf`
dans `html/fonts/` ; sans le fichier, Inter (très proche) est utilisée.
