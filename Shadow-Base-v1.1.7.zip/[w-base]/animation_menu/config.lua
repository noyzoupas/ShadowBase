Config = {}

-- Touches (chaque joueur peut les changer dans Paramètres > Raccourcis clavier > FiveM)
-- F1-F7 et F10 sont déjà pris par Shadow Base (téléphone, actions, noclip staff, tp, menu perso, tablettes, staff)
Config.OpenKey = 'F9'      -- ouvrir / fermer le menu
Config.CancelKey = 'X'     -- arrêter l'animation en cours

-- Fermer le menu quand on lance une animation
Config.CloseOnPlay = false

-- Distance max pour proposer une emote partagée au joueur le plus proche (Shadow Base vérifie aussi côté serveur)
Config.SharedDistance = 3.5

--[[
  Liste des emotes affichées dans le menu.

  type     : onglet -> 'emote' | 'shared' | 'props' | 'action'
  label    : nom affiché sur la carte
  category : petite ligne grise au-dessus du nom
  image    : (optionnel) image de la carte, ex: 'img/emotes/dance.png' (dans html/img/emotes/)

  Animation :
    dict + anim + flag  -> animation (flag 1 = boucle, 49 = boucle haut du corps, 48 = une fois haut du corps)
    scenario            -> scénario GTA (ex: WORLD_HUMAN_SMOKING)
    prop                -> objet tenu en main
    shared              -> geste à deux de Shadow Base (check, handshake, hug, carry, carried) :
                           invitation Y / N envoyée au joueur le plus proche, synchro gérée par pb_panel
]]
Config.Emotes = {
  -- Emote : danses, humeur, repos, sport (catalogue de Shadow Base)
  { id = 'dance1',    type = 'emote', label = 'Danse 1',        category = 'Danse', dict = 'anim@amb@nightclub@dancers@crowddance_groups@', anim = 'hi_idle_a_m03', flag = 1 },
  { id = 'dance2',    type = 'emote', label = 'Danse 2',        category = 'Danse', dict = 'anim@amb@nightclub@dancers@solo_dancers@', anim = 'hi_idle_a_f01', flag = 1 },
  { id = 'dance3',    type = 'emote', label = 'Danse 3',        category = 'Danse', dict = 'anim@amb@nightclub@mini@dance@dance_solo@male@var_a@', anim = 'high_center', flag = 1 },
  { id = 'dance4',    type = 'emote', label = 'Danse 4',        category = 'Danse', dict = 'anim@amb@nightclub@mini@dance@dance_solo@male@var_b@', anim = 'high_center_down', flag = 1 },
  { id = 'party',     type = 'emote', label = 'Fêter ça',       category = 'Danse', scenario = 'WORLD_HUMAN_PARTYING' },
  { id = 'dj',        type = 'emote', label = 'DJ',             category = 'Danse', dict = 'anim@mp_player_intcelebrationmale@dj', anim = 'dj', flag = 49 },
  { id = 'guitar',    type = 'emote', label = 'Air guitar',     category = 'Danse', dict = 'anim@mp_player_intcelebrationmale@air_guitar', anim = 'air_guitar', flag = 49 },
  { id = 'cheer',     type = 'emote', label = 'Applaudir',      category = 'Humeur', scenario = 'WORLD_HUMAN_CHEERING' },
  { id = 'slowclap',  type = 'emote', label = 'Applaudir lent', category = 'Humeur', dict = 'anim@mp_player_intcelebrationmale@slow_clap', anim = 'slow_clap', flag = 48 },
  { id = 'facepalm',  type = 'emote', label = 'Facepalm',       category = 'Humeur', dict = 'anim@mp_player_intcelebrationmale@face_palm', anim = 'face_palm', flag = 49 },
  { id = 'thumbs',    type = 'emote', label = 'Pouce en l\'air', category = 'Humeur', dict = 'anim@mp_player_intincarthumbs_upbodhi@ps@', anim = 'enter', flag = 49 },
  { id = 'kiss',      type = 'emote', label = 'Bisou',          category = 'Humeur', dict = 'anim@mp_player_intcelebrationmale@blow_kiss', anim = 'blow_kiss', flag = 48 },
  { id = 'peace',     type = 'emote', label = 'Peace',          category = 'Humeur', dict = 'anim@mp_player_intcelebrationmale@peace', anim = 'peace', flag = 48 },
  { id = 'rock',      type = 'emote', label = 'Rock',           category = 'Humeur', dict = 'anim@mp_player_intcelebrationmale@rock', anim = 'rock', flag = 48 },
  { id = 'sitground', type = 'emote', label = 'S\'asseoir par terre', category = 'Repos', scenario = 'WORLD_HUMAN_PICNIC' },
  { id = 'sitbench',  type = 'emote', label = 'S\'asseoir',     category = 'Repos', scenario = 'PROP_HUMAN_SEAT_BENCH' },
  { id = 'lean',      type = 'emote', label = 'S\'adosser',     category = 'Repos', scenario = 'WORLD_HUMAN_LEANING' },
  { id = 'lieback',   type = 'emote', label = 'S\'allonger',    category = 'Repos', scenario = 'WORLD_HUMAN_SUNBATHE_BACK' },
  { id = 'lieface',   type = 'emote', label = 'Sur le ventre',  category = 'Repos', scenario = 'WORLD_HUMAN_SUNBATHE' },
  { id = 'impatient', type = 'emote', label = 'Impatient',      category = 'Repos', scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
  { id = 'pushups',   type = 'emote', label = 'Pompes',         category = 'Sport', scenario = 'WORLD_HUMAN_PUSH_UPS' },
  { id = 'situps',    type = 'emote', label = 'Abdos',          category = 'Sport', scenario = 'WORLD_HUMAN_SIT_UPS' },
  { id = 'yoga',      type = 'emote', label = 'Yoga',           category = 'Sport', scenario = 'WORLD_HUMAN_YOGA' },
  { id = 'jog',       type = 'emote', label = 'Jogging sur place', category = 'Sport', scenario = 'WORLD_HUMAN_JOG_STANDING' },
  { id = 'flex',      type = 'emote', label = 'Muscu',          category = 'Sport', scenario = 'WORLD_HUMAN_MUSCLE_FLEX' },

  -- Emote partager : gestes à deux de Shadow Base (invitation Y / N)
  { id = 'p_check',     type = 'shared', label = 'Checker',          category = 'À deux', shared = 'check' },
  { id = 'p_handshake', type = 'shared', label = 'Serrer la main',   category = 'À deux', shared = 'handshake' },
  { id = 'p_hug',       type = 'shared', label = 'Câlin',            category = 'À deux', shared = 'hug' },
  { id = 'p_carry',     type = 'shared', label = 'Porter',           category = 'À deux', shared = 'carry' },
  { id = 'p_carried',   type = 'shared', label = 'Se faire porter',  category = 'À deux', shared = 'carried' },

  -- Emote Accesoires
  { id = 'phone',     type = 'props', label = 'Téléphone',      category = 'Accessoire', dict = 'cellphone@', anim = 'cellphone_text_read_base', flag = 49,
    prop = { model = 'prop_npc_phone_02', bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) } },
  { id = 'coffee',    type = 'props', label = 'Café',           category = 'Accessoire', dict = 'amb@world_human_drinking@coffee@male@idle_a', anim = 'idle_c', flag = 49,
    prop = { model = 'p_amb_coffeecup_01', bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) } },
  { id = 'smoke',     type = 'props', label = 'Fumer',          category = 'Accessoire', scenario = 'WORLD_HUMAN_SMOKING' },
  { id = 'drink',     type = 'props', label = 'Boire',          category = 'Accessoire', scenario = 'WORLD_HUMAN_DRINKING' },
  { id = 'phonecall', type = 'props', label = 'Téléphoner',     category = 'Accessoire', scenario = 'WORLD_HUMAN_STAND_MOBILE' },
  { id = 'binoc',     type = 'props', label = 'Jumelles',       category = 'Accessoire', scenario = 'WORLD_HUMAN_BINOCULARS' },
  { id = 'notes',     type = 'props', label = 'Prendre des notes', category = 'Accessoire', scenario = 'WORLD_HUMAN_CLIPBOARD' },
  { id = 'photo',     type = 'props', label = 'Photographier',  category = 'Accessoire', scenario = 'WORLD_HUMAN_PAPARAZZI' },
  { id = 'weld',      type = 'props', label = 'Réparer',        category = 'Accessoire', scenario = 'WORLD_HUMAN_WELDING' },

  -- Action : gestes
  { id = 'hello',     type = 'action', label = 'Bonjour',        category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_hello', flag = 48 },
  { id = 'wave',      type = 'action', label = 'Coucou',         category = 'Geste', dict = 'friends@frj@ig_1', anim = 'wave_a', flag = 49 },
  { id = 'bye',       type = 'action', label = 'Au revoir',      category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_bye_hard', flag = 48 },
  { id = 'come',      type = 'action', label = 'Viens ici',      category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_come_here_hard', flag = 48 },
  { id = 'point',     type = 'action', label = 'Montrer',        category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_point', flag = 48 },
  { id = 'halt',      type = 'action', label = 'Stop',           category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_hand_down', flag = 48 },
  { id = 'shush',     type = 'action', label = 'Chut',           category = 'Geste', dict = 'anim@mp_player_intcelebrationmale@shush', anim = 'shush', flag = 48 },
  { id = 'shrug',     type = 'action', label = 'Hausser les épaules', category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_shrug_hard', flag = 48 },
  { id = 'nope',      type = 'action', label = 'Non',            category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_head_no', flag = 48 },
  { id = 'damn',      type = 'action', label = 'Mince',          category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_damn', flag = 48 },
  { id = 'what',      type = 'action', label = 'Quoi ?',         category = 'Geste', dict = 'gestures@m@standing@casual', anim = 'gesture_what_hard', flag = 48 },
  { id = 'salute',    type = 'action', label = 'Salut militaire', category = 'Geste', dict = 'anim@mp_player_intincarsalutestd@ds@', anim = 'idle_a', flag = 49 },
  { id = 'crossarms', type = 'action', label = 'Bras croisés',   category = 'Posture', dict = 'amb@world_human_hang_out_street@female_arms_crossed@idle_a', anim = 'idle_a', flag = 49 },
  { id = 'handsup',   type = 'action', label = 'Mains en l\'air', category = 'Posture', dict = 'missminuteman_1ig_2', anim = 'handsup_base', flag = 49 },
  { id = 'surrender', type = 'action', label = 'Se rendre',      category = 'Posture', dict = 'random@arrests@busted', anim = 'idle_a', flag = 1 },
  { id = 'kneel',     type = 'action', label = 'À genoux',       category = 'Posture', dict = 'amb@medic@standing@kneel@idle_a', anim = 'idle_a', flag = 1 },
  { id = 'guard',     type = 'action', label = 'Garde',          category = 'Métier', scenario = 'WORLD_HUMAN_GUARD_STAND' },
}
