/* (patch 340) Établi vu du dessus : les pièces sont posées sur un tapis, on les glisse à la souris sur leur emplacement pour assembler.
   Mode « weapon » (armes : tapis bleu quadrillé) et « drug » (drogues : tapis sombre, balance, sachets…).
   Jeu → NUI : bench.open { mode, title, hint, secs, parts: [{ id, label, kind }] } · NUI → jeu : bench.done { ok, errors, ms }. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const NS = 'http://www.w3.org/2000/svg';
// formes (viewBox 100 × 40), remplies en noir avec un liseré clair, comme les pièces posées sur l'établi
const SHAPE = {
  barrel: 'M2 14h74l4-4h18v20H80l-4-4H2z',
  slide: 'M2 8h88l8 8v8H2z',
  receiver: 'M4 6h72l12 10v8H64l-6 12H44l4-12H4z',
  stock: 'M2 12l60-4 36 4v18l-36 4L2 28z',
  grip: 'M20 2h30l12 36H34z',
  spring: 'M2 20h12l6-14 10 28 10-28 10 28 10-28 6 14h30',
  plate: 'M4 6h92v28H4zM14 14h72v12H14z',
  jar: 'M30 6h40v6l6 6v18H24V18l6-6z',
  powder: 'M14 34c4-18 20-24 36-24s32 6 36 24z',
  pills: 'M8 20a10 10 0 0110-10h22a10 10 0 010 20H18A10 10 0 018 20zM60 20a10 10 0 0110-10h12a10 10 0 010 20H70a10 10 0 01-10-10z',
  scale: 'M10 34h80v4H10zM46 10h8v24h-8zM14 12h72l-8 12H22z',
  bag: 'M30 4h40l-4 8 14 8v18H20V20l14-8z',
};
let box = null, tick = 0;
function svg(kind, cls) {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 100 40'); s.setAttribute('class', cls || '');
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', SHAPE[kind] || SHAPE.plate);
  if (kind === 'spring') p.setAttribute('fill', 'none');
  s.appendChild(p); return s;
}
function drop(res) {
  clearInterval(tick); tick = 0;
  if (box) { box.remove(); box = null; }
  if (res) G.post('bench.done', res);
}
G.on('bench.close', () => drop(null));
G.on('bench.open', function (d) {
  drop(null);
  const mode = d.mode === 'drug' ? 'drug' : 'weapon';
  const parts = (Array.isArray(d.parts) ? d.parts : []).slice(0, 7);
  if (!parts.length) { G.post('bench.done', { ok: true, errors: 0, ms: 0 }); return; }
  const secs = Math.max(3, Math.min(240, Number(d.secs) || 10)), t0 = Date.now();
  const W = 1100, H = 600;
  let placed = 0, errors = 0, finishing = false;
  const stage = h('div', { class: 'bn-st', style: { width: W + 'px', height: H + 'px' } });
  const n = parts.length, gap = (W - 60) / n;
  const pieces = parts.map((p, i) => {
    const sx = 30 + gap * i + gap / 2;                       // emplacement (rangée du haut)
    const slot = h('div', { class: 'bn-sl', style: { left: (sx - 60) + 'px', top: '70px' } }, svg(p.kind, 'g'), h('small', null, String(p.label || '')));
    const px = 40 + Math.random() * (W - 220), py = 260 + Math.random() * 270;
    const el = h('div', { class: 'bn-p', style: { left: px + 'px', top: py + 'px', transform: 'rotate(' + Math.round(Math.random() * 50 - 25) + 'deg)' } }, svg(p.kind, 'f'));
    stage.appendChild(slot); return { p, slot, el, sx, sy: 70, done: false };
  });
  pieces.forEach((q) => stage.appendChild(q.el));
  const msg = h('div', { class: 'bn-msg' }, String(d.hint || (mode === 'drug' ? 'Glisse chaque ingrédient sur son emplacement.' : "Assemble les pièces de l'arme : clic gauche pour glisser.")));
  const bar = h('i'), barw = h('div', { class: 'bn-bar' }, bar);
  box = h('div', { id: 'g-bench', class: 'bn-' + mode }, [
    h('div', { class: 'bn-top' }, h('b', null, String(d.title || 'Établi')), h('span', null, 'Échap : annuler')),
    h('div', { class: 'bn-mat' }, stage), msg, barw]);
  G.root.appendChild(box);
  const sc = Math.min(1.4, (window.innerWidth * 0.84) / W, (window.innerHeight * 0.7) / H);
  stage.style.transform = 'scale(' + sc + ')'; stage.style.transformOrigin = '50% 0';
  let drag = null;
  pieces.forEach((q) => {
    q.el.addEventListener('pointerdown', (e) => {
      if (q.done || finishing) return;
      const r = q.el.getBoundingClientRect();
      drag = { q, dx: e.clientX - r.left, dy: e.clientY - r.top };
      q.el.classList.add('up'); q.el.style.transform = 'rotate(0deg)';
      try { q.el.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
    });
    q.el.addEventListener('pointermove', (e) => {
      if (!drag || drag.q !== q) return;
      const s = stage.getBoundingClientRect();
      q.el.style.left = ((e.clientX - s.left - drag.dx) / sc) + 'px';
      q.el.style.top = ((e.clientY - s.top - drag.dy) / sc) + 'px';
    });
    q.el.addEventListener('pointerup', () => {
      if (!drag || drag.q !== q) return;
      drag = null; q.el.classList.remove('up');
      const x = parseFloat(q.el.style.left), y = parseFloat(q.el.style.top);
      let hit = null;
      pieces.forEach((o) => { if (!o.done && Math.abs(x - (o.sx - 60)) < 48 && Math.abs(y - o.sy) < 40) hit = o; });
      if (hit === q) {
        q.done = true; placed++;
        q.el.style.left = (q.sx - 60) + 'px'; q.el.style.top = q.sy + 'px'; q.el.classList.add('ok'); q.slot.classList.add('ok');
        if (placed >= n) finish();
      } else if (hit) { errors++; q.el.classList.add('bad'); setTimeout(() => q.el.classList.remove('bad'), 300); }
    });
  });
  function finish() {
    finishing = true;
    msg.textContent = mode === 'drug' ? 'Mélange en cours…' : 'Assemblage…';
    pieces.forEach((q, i) => { const cx = W / 2 - 60 + (i - (n - 1) / 2) * 30; q.el.style.left = cx + 'px'; q.slot.style.opacity = '0'; });
    box.classList.add('fin');
  }
  tick = setInterval(() => {
    const el = (Date.now() - t0) / 1000;
    bar.style.width = Math.min(100, el / secs * 100) + '%';
    if (finishing && el >= secs) drop({ ok: true, errors, ms: Date.now() - t0 });
    else if (!finishing && el >= secs * 4 + 20) drop({ ok: false, errors, ms: Date.now() - t0 });   // trop long : abandon
  }, 100);
});
G.nui = G.nui || {};
window.addEventListener('keydown', (e) => { if (box && e.key === 'Escape') { e.preventDefault(); drop({ ok: false, errors: 0, ms: 0, cancel: true }); } }, true);
})();
