/* Téléphone : un vrai téléphone avec écran d'accueil et applications (Messages, Contacts, Annuaire, Banque, Factures, Garage, GPS, Notes,
   Calculatrice, Réglages). Le serveur envoie des données déjà filtrées ; tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const DW = 372, DH = 760;

const money = (n) => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' $';
const initials = (s) => { const p = String(s || '?').trim().split(/\s+/); return ((p[0] || '?')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase(); };
const dur = (s) => { s = Math.max(0, Math.floor(s)); const m = Math.floor(s / 60); return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s % 60).padStart(2, '0'); };
const hue = (s) => { let x = 0; for (const c of String(s)) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };

// ---- Fonds d'écran (dessins vectoriels originaux) : « Bloom » (cercles superposés, liseré lumineux) et « Prisme » (faisceaux néon)
const BLOOM = {
  copper: ['#0e0805', '#160c07', '#3a1d0e', '#b0602c', '#ffb27a'], silver: ['#09090b', '#0f0f11', '#2a2c31', '#9ba1aa', '#ffffff'],
  midnight: ['#04060c', '#060a15', '#0e1d3f', '#3466cc', '#9cc2ff'], graphite: ['#060607', '#0b0b0c', '#1d1e21', '#5d6168', '#d7dbe2'],
};
const PRISM = { blue: ['#2f7bff', '#9fd0ff'], mint: ['#1fe0b4', '#b6fff0'], green: ['#20c46a', '#a8ffcb'], amber: ['#ff8a00', '#ffd27a'], violet: ['#b04cff', '#ff9cf1'] };
const WALL_IDS = ['copper', 'silver', 'midnight', 'graphite', 'blue', 'mint', 'green', 'amber', 'violet'];
const WALL_OLD = { dusk: 'copper', ember: 'copper', ocean: 'midnight', forest: 'green', rose: 'violet', mono: 'silver' };
function svgUrl(s) { return 'url("data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s) + '")'; }
function bloomSvg(c) {
  const circ = [[-60, 1010, 560], [480, 930, 470], [140, 1230, 600], [455, 150, 250], [-80, 360, 270], [250, 620, 210]];
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 390 844" preserveAspectRatio="xMidYMid slice"><defs>'
    + '<radialGradient id="g" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="' + c[1] + '"/><stop offset=".78" stop-color="' + c[2] + '"/><stop offset=".97" stop-color="' + c[3] + '"/><stop offset="1" stop-color="' + c[4] + '"/></radialGradient>'
    + '<linearGradient id="r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + c[4] + '"/><stop offset=".5" stop-color="' + c[4] + '" stop-opacity=".12"/><stop offset="1" stop-color="' + c[4] + '" stop-opacity=".8"/></linearGradient>'
    + '<radialGradient id="v" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></radialGradient></defs>'
    + '<rect width="390" height="844" fill="' + c[0] + '"/>'
    + circ.map((k) => '<circle cx="' + k[0] + '" cy="' + k[1] + '" r="' + k[2] + '" fill="url(#g)" stroke="url(#r)" stroke-width="2.4"/>').join('')
    + '<rect width="390" height="844" fill="url(#v)"/></svg>';
}
function prismSvg(c) {
  const beam = (pts, op) => '<polygon points="' + pts + '" fill="url(#b)" opacity="' + op + '"/>';
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 390 844" preserveAspectRatio="xMidYMid slice"><defs>'
    + '<linearGradient id="b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + c[1] + '"/><stop offset=".35" stop-color="' + c[0] + '"/><stop offset="1" stop-color="' + c[0] + '" stop-opacity="0"/></linearGradient>'
    + '<filter id="f" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="22"/></filter><filter id="s"><feGaussianBlur stdDeviation="3"/></filter></defs>'
    + '<rect width="390" height="844" fill="#020307"/>'
    + '<g filter="url(#f)">' + beam('20,120 240,330 240,420 20,210', '.9') + beam('300,470 390,380 390,560 300,650', '.8') + beam('70,560 230,560 70,760', '.75') + '</g>'
    + '<g filter="url(#s)">' + beam('60,160 225,325 225,345 60,180', '1') + beam('318,505 390,433 390,450 318,522', '1') + beam('95,585 205,585 95,700', '.9') + '</g>'
    + '<rect width="390" height="844" fill="#000" opacity=".18"/></svg>';
}
const wallCache = {};
function wallBg(id) {
  id = WALL_OLD[id] || id;
  if (wallCache[id]) return wallCache[id];
  const v = BLOOM[id] ? svgUrl(bloomSvg(BLOOM[id])) + ' center/cover' : PRISM[id] ? svgUrl(prismSvg(PRISM[id])) + ' center/cover' : svgUrl(bloomSvg(BLOOM.copper)) + ' center/cover';
  wallCache[id] = v;
  return v;
}

// ---- Icônes des applications (style iOS : carré arrondi, dégradé, pictogramme blanc)
const SVG = (inner, vb) => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + (vb || '0 0 60 60') + '">' + inner + '</svg>';
const GLYPH = {
  calls: '<path fill="#fff" d="M22.6 15.5c1.2-.9 2.9-.6 3.7.6l3.3 5c.7 1.1.5 2.5-.4 3.4l-2.3 2.2c1.5 3.4 4.1 6.3 7.4 8.1l2.3-2.1c1-.9 2.4-1 3.5-.2l4.8 3.5c1.2.9 1.4 2.6.5 3.8l-1.9 2.4c-1.3 1.6-3.4 2.3-5.4 1.7C27.5 41.5 18.6 32.4 16.2 21.8c-.4-1.9.3-3.9 1.9-5.2z"/>',
  messages: '<path fill="#fff" d="M30 14c-9.9 0-18 6.5-18 14.6 0 4.6 2.6 8.7 6.7 11.4-.4 2-1.5 4-3.2 5.6 3.4-.1 6.5-1.2 8.9-3.1 1.8.5 3.7.8 5.6.8 9.9 0 18-6.5 18-14.7S39.9 14 30 14z"/>',
  contacts: '<circle cx="30" cy="23" r="9" fill="#f2f2f7"/><path fill="#f2f2f7" d="M13 47c1.6-8.4 8.5-13 17-13s15.4 4.6 17 13z"/>',
  services: '<rect x="13" y="21" width="34" height="23" rx="5" fill="#fff"/><path fill="none" stroke="#fff" stroke-width="3.4" d="M24 21v-3.5a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3V21"/><rect x="13" y="29" width="34" height="3.2" fill="#5856d6" opacity=".45"/><rect x="26.5" y="27" width="7" height="6" rx="1.5" fill="#5856d6"/>',
  bank: '<rect x="11" y="15" width="38" height="11" rx="3" fill="#ff9f0a"/><rect x="11" y="20" width="38" height="11" rx="3" fill="#30d158"/><rect x="11" y="25" width="38" height="11" rx="3" fill="#0a84ff"/><rect x="9" y="30" width="42" height="17" rx="4" fill="#3a3a3c"/><rect x="9" y="30" width="42" height="17" rx="4" fill="none" stroke="#636366" stroke-width="1"/>',
  bills: '<path fill="#fff" d="M19 12h16l9 9v24a3 3 0 0 1-3 3H19a3 3 0 0 1-3-3V15a3 3 0 0 1 3-3z"/><path fill="#ffd8a3" d="M35 12v7a2 2 0 0 0 2 2h7z"/><rect x="21" y="27" width="18" height="2.6" rx="1.3" fill="#ff9500"/><rect x="21" y="33" width="18" height="2.6" rx="1.3" fill="#ff9500"/><rect x="21" y="39" width="11" height="2.6" rx="1.3" fill="#ff9500"/>',
  garage: '<path fill="#fff" d="M30 11 10 25v3h4v18h32V28h4v-3z"/><rect x="19" y="31" width="22" height="15" rx="2" fill="#0a63e0"/><rect x="21" y="33.5" width="18" height="2" rx="1" fill="#fff" opacity=".9"/><rect x="21" y="37.5" width="18" height="2" rx="1" fill="#fff" opacity=".9"/><rect x="21" y="41.5" width="18" height="2" rx="1" fill="#fff" opacity=".9"/>',
  gps: '<rect width="60" height="60" fill="#e8f1e1"/><path d="M-2 40 62 18" stroke="#ffd34d" stroke-width="7"/><path d="M20-2 36 62" stroke="#fff" stroke-width="6"/><path d="M-2 22 30 30 62 26" stroke="#fff" stroke-width="3"/><rect x="38" y="36" width="24" height="26" fill="#b9dca3"/><path fill="#ff3b30" d="M30 13a9 9 0 0 0-9 9c0 6.5 9 16 9 16s9-9.5 9-16a9 9 0 0 0-9-9z"/><circle cx="30" cy="22" r="3.6" fill="#fff"/>',
  ads: '<path fill="#fff" d="M14 25h7l17-9v28l-17-9h-7a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3z"/><path fill="#fff" d="M18 37h6l2 9a2 2 0 0 1-2 2.4h-1.6a2 2 0 0 1-2-1.6z"/><path fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" d="M43 24c2 1.8 2 10.2 0 12"/>',
  taxi: '<path fill="#1c1c1e" d="M17 27l3-8a4 4 0 0 1 3.8-2.6h12.4A4 4 0 0 1 40 19l3 8a5 5 0 0 1 4 5v8h-4v4h-5v-4H22v4h-5v-4h-4v-8a5 5 0 0 1 4-5z"/><rect x="25" y="10.5" width="10" height="5" rx="1.5" fill="#1c1c1e"/><path fill="#ffd60a" d="M21.3 27l2.2-6.2c.2-.6.8-1 1.4-1h10.2c.6 0 1.2.4 1.4 1l2.2 6.2z"/><circle cx="19.5" cy="34" r="2.6" fill="#ffd60a"/><circle cx="40.5" cy="34" r="2.6" fill="#ffd60a"/>',
  deals: '<path fill="#fff" d="M18 12h24a3 3 0 0 1 3 3v30a3 3 0 0 1-3 3H18a3 3 0 0 1-3-3V15a3 3 0 0 1 3-3z"/><rect x="20" y="18" width="20" height="2.6" rx="1.3" fill="#0a9bb5"/><rect x="20" y="24" width="20" height="2.6" rx="1.3" fill="#0a9bb5"/><path fill="none" stroke="#0a9bb5" stroke-width="2.6" stroke-linecap="round" d="M20 40c3-5 5 2 8-2s4 1 6 0 4-2 6-1"/>',
  notes: '<rect width="60" height="60" fill="#fdfdfd"/><rect width="60" height="17" fill="#ffd426"/><rect width="60" height="17" fill="url(#ng)"/><g fill="#d8d8dc"><rect x="9" y="27" width="42" height="1.4"/><rect x="9" y="35" width="42" height="1.4"/><rect x="9" y="43" width="42" height="1.4"/><rect x="9" y="51" width="42" height="1.4"/></g><defs><linearGradient id="ng" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe066"/><stop offset="1" stop-color="#ffc300"/></linearGradient></defs><g fill="#c7c7cc"><circle cx="12" cy="20.5" r=".9"/><circle cx="18" cy="20.5" r=".9"/><circle cx="24" cy="20.5" r=".9"/><circle cx="30" cy="20.5" r=".9"/><circle cx="36" cy="20.5" r=".9"/><circle cx="42" cy="20.5" r=".9"/><circle cx="48" cy="20.5" r=".9"/></g>',
  calc: '<g fill="#a5a5aa"><circle cx="19" cy="19" r="5"/><circle cx="30" cy="19" r="5"/></g><circle cx="41" cy="19" r="5" fill="#ff9f0a"/><g fill="#505055"><circle cx="19" cy="30" r="5"/><circle cx="30" cy="30" r="5"/><circle cx="19" cy="41" r="5"/><circle cx="30" cy="41" r="5"/></g><circle cx="41" cy="30" r="5" fill="#ff9f0a"/><circle cx="41" cy="41" r="5" fill="#ff9f0a"/>',
  settings: '<g transform="translate(30 30)"><g fill="#3a3a3c">' + Array.from({ length: 12 }, (_, i) => '<rect x="-3.4" y="-21" width="6.8" height="9" rx="1.6" transform="rotate(' + (i * 30) + ')"/>').join('') + '</g><circle r="15" fill="#3a3a3c"/><circle r="12.2" fill="#8e8e93"/><circle r="9.6" fill="#3a3a3c"/>' + Array.from({ length: 6 }, (_, i) => '<rect x="-1" y="-9" width="2" height="9" fill="#8e8e93" transform="rotate(' + (i * 60) + ')"/>').join('') + '<circle r="4" fill="#8e8e93"/><circle r="2.2" fill="#3a3a3c"/></g>',
  airdrop: '<g fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><path d="M17 41a17 17 0 1 1 26 0"/><path d="M22.5 36.5a10 10 0 1 1 15 0"/></g><path fill="#fff" d="M30 26l7.5 18h-15z"/>',
  search: '<circle cx="26" cy="26" r="11" fill="none" stroke="#fff" stroke-width="4"/><path d="M34.5 34.5 45 45" stroke="#fff" stroke-width="4.5" stroke-linecap="round"/>',
};
const APPBG = {
  calls: 'linear-gradient(180deg,#65f283,#2fc853)', messages: 'linear-gradient(180deg,#65f283,#2cc24f)', contacts: 'linear-gradient(180deg,#cfd0d6,#8f9097)',
  services: 'linear-gradient(180deg,#8a87ff,#5652e0)', bank: 'linear-gradient(180deg,#2c2c2e,#0d0d0f)', bills: 'linear-gradient(180deg,#ffbd45,#ff9500)',
  garage: 'linear-gradient(180deg,#5aaeff,#0a63e0)', gps: '#e8f1e1', ads: 'linear-gradient(180deg,#ff7092,#ff2d55)', taxi: 'linear-gradient(180deg,#ffe14d,#ffbf00)',
  deals: 'linear-gradient(180deg,#5ad8ee,#0a9bb5)', notes: '#fdfdfd', calc: 'linear-gradient(180deg,#2c2c2e,#121214)', settings: 'linear-gradient(180deg,#d9dade,#8f9097)',
  airdrop: 'linear-gradient(180deg,#5aaeff,#0a63e0)',
};
function appIcon(id, size) {
  const el = h('span', { class: 'ph-ai ios', style: { width: size + 'px', height: size + 'px', background: APPBG[id] || 'linear-gradient(180deg,#8e8e93,#48484a)' } });
  el.innerHTML = SVG(GLYPH[id] || GLYPH.search);   // dessins fixes du fichier (aucune donnée du serveur)
  return el;
}
// Météo du jeu : pictogrammes et libellés
const WX = {
  clear: ['Ensoleillé', 'sun'], extrasunny: ['Ensoleillé', 'sun'], clouds: ['Nuageux', 'cloud'], overcast: ['Couvert', 'cloud'], rain: ['Pluie', 'rain'], clearing: ['Éclaircies', 'sun'],
  thunder: ['Orage', 'storm'], smog: ['Brumeux', 'fog'], foggy: ['Brouillard', 'fog'], xmas: ['Neige', 'snow'], snow: ['Neige', 'snow'], snowlight: ['Neige légère', 'snow'], blizzard: ['Blizzard', 'snow'], halloween: ['Nuit étrange', 'moon'], neutral: ['Calme', 'cloud'],
};
const WXI = {
  sun: '<circle cx="12" cy="12" r="4.6" fill="#ffd60a"/><g stroke="#ffd60a" stroke-width="1.8" stroke-linecap="round">' + Array.from({ length: 8 }, (_, i) => '<path d="M12 2.2v2.4" transform="rotate(' + i * 45 + ' 12 12)"/>').join('') + '</g>',
  moon: '<path fill="#fff" d="M15.5 3.5a8.5 8.5 0 1 0 5 15.2A9 9 0 0 1 15.5 3.5z"/>',
  cloud: '<path fill="#fff" d="M7 19h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 19z"/>',
  rain: '<path fill="#fff" d="M7 15h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 15z"/><g stroke="#64d2ff" stroke-width="1.8" stroke-linecap="round"><path d="M9 17.5 8 20.5"/><path d="M13 17.5 12 20.5"/><path d="M17 17.5 16 20.5"/></g>',
  storm: '<path fill="#fff" d="M7 14h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 14z"/><path fill="#ffd60a" d="M12.5 14 9.5 19h3l-1 4 4-6h-3l1-3z"/>',
  fog: '<g stroke="#fff" stroke-width="1.8" stroke-linecap="round"><path d="M4 9h16"/><path d="M6 13h14"/><path d="M4 17h12"/></g>',
  snow: '<path fill="#fff" d="M7 15h10.5a4 4 0 0 0 .4-8 6 6 0 0 0-11.5 1.6A3.3 3.3 0 0 0 7 15z"/><g fill="#fff"><circle cx="9" cy="19" r="1.2"/><circle cx="13" cy="20.5" r="1.2"/><circle cx="17" cy="19" r="1.2"/></g>',
};
function wxIcon(kind, size) { const s = h('span', { class: 'ph-wxi', style: { width: size + 'px', height: size + 'px' } }); s.innerHTML = SVG(WXI[kind] || WXI.cloud, '0 0 24 24'); return s; }
const MONTHS = ['JANVIER', 'FÉVRIER', 'MARS', 'AVRIL', 'MAI', 'JUIN', 'JUILLET', 'AOÛT', 'SEPTEMBRE', 'OCTOBRE', 'NOVEMBRE', 'DÉCEMBRE'];
const WDAYS = ['DIM', 'LUN', 'MAR', 'MER', 'JEU', 'VEN', 'SAM'];

/* opts : { page(name), act(name, payload, page), close() } */
G.phoneView = function (opts) {
  const st = { view: 'home', data: null, info: null, loading: false, toast: null, sel: null, compose: null, edit: null, calc: { a: '0', left: null, op: null, rep: null, fresh: true }, send: null, clock: [12, 0],
    call: null, back: 'home', dial: '', ctab: 'keys', env: null, q: '', drop: null };
  const dev = h('div', { class: 'ph-dev' });
  const scr = h('div', { class: 'ph-scr' }), bar = h('div', { class: 'ph-st' }), body = h('div', { class: 'ph-body' }), home = h('button', { class: 'ph-hi', type: 'button', title: "Écran d'accueil", onclick: () => nav('home') });
  const toast = h('div', { class: 'ph-toast hidden' });
  scr.appendChild(h('div', { class: 'ph-wall' }));
  scr.appendChild(bar); scr.appendChild(body); scr.appendChild(toast); scr.appendChild(home);
  dev.appendChild(h('div', { class: 'ph-btn b1' })); dev.appendChild(h('div', { class: 'ph-btn b2' })); dev.appendChild(h('div', { class: 'ph-btn b3' }));
  dev.appendChild(scr);

  let toastT = null;
  function say(ok, msg) {
    if (!msg) return;
    toast.textContent = String(msg); toast.className = 'ph-toast ' + (ok ? 'ok' : 'bad');
    clearTimeout(toastT); toastT = setTimeout(() => toast.classList.add('hidden'), 3200);
  }
  function bannerBg() { const b = (G.cfg && G.cfg.brand && G.cfg.brand.banner) ? G.assetUrl(G.cfg.brand.banner) : ''; return b ? 'linear-gradient(rgba(0,0,0,.25),rgba(0,0,0,.45)),url("' + b + '") center/cover' : wallBg('graphite'); }
  function wall() {
    const w = (st.info && st.info.wall) || 'copper', el = scr.firstChild;
    el.style.background = w === 'banner' ? bannerBg() : wallBg(w);
  }
  // barre d'état iOS : heure, Dynamic Island, réseau et batterie
  const SYS = SVG('<g fill="#fff"><rect x="0" y="8" width="3.2" height="4" rx="1"/><rect x="4.6" y="6" width="3.2" height="6" rx="1"/><rect x="9.2" y="3.5" width="3.2" height="8.5" rx="1"/><rect x="13.8" y="1" width="3.2" height="11" rx="1"/></g>'
    + '<g transform="translate(24 0)"><rect x=".6" y=".6" width="22" height="11" rx="3.4" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="1.2"/><rect x="2.4" y="2.4" width="16.5" height="7.4" rx="2" fill="#fff"/><path d="M24 4.2v3.6a2 2 0 0 0 0-3.6z" fill="#fff" fill-opacity=".45"/></g>', '0 0 50 12');
  function drawBar() {
    G.clear(bar);
    const hh = String(st.clock[0]).padStart(2, '0'), mm = String(st.clock[1]).padStart(2, '0');
    bar.appendChild(h('b', { class: 'ph-t' }, hh + ':' + mm));
    bar.appendChild(h('i', { class: 'ph-isl' }, h('i', { class: 'ph-cam' })));
    const sys = h('span', { class: 'ph-sys' }, st.info && st.info.dnd ? h('i', { class: 'ph-dnd', title: 'Ne pas déranger' }, ico('moon')) : null);
    const ic = h('i', { class: 'ph-sig' }); ic.innerHTML = SYS; sys.appendChild(ic);
    bar.appendChild(sys);
  }

  // ---- navigation
  const NOSERVER = { home: 1, calc: 1, newmsg: 1, newcontact: 1, editnote: 1, call: 1, invite: 1, newgroup: 1, newad: 1, walls: 1, search: 1, setup: 1, lock: 1, security: 1 };
  // écrans « racine » d'une application : grand titre façon iOS (le retour à l'accueil se fait par la barre du bas)
  const ROOT = { calls: 1, messages: 1, contacts: 1, services: 1, bank: 1, bills: 1, garage: 1, gps: 1, ads: 1, taxi: 1, deals: 1, notes: 1, settings: 1, calc: 1 };
  function nav(page) {
    st.sel = null;
    if (st.view === 'setup' || (st.view === 'lock' && !st.unlocked)) return;   // configuration / verrouillé : pas de navigation
    if (page !== 'call' && st.view !== 'call') st.back = page;
    if (page === 'home' && st.info) { st.view = 'home'; render(); opts.page('home'); return; }
    st.view = page;
    if (NOSERVER[page]) { render(); return; }
    st.data = null; st.loading = true; render(); opts.page(page);
  }
  function set(d) {
    if (d && d.ok === true && (st.view === 'lock' || st.view === 'setup')) st.unlocked = true;   // déverrouillé par le serveur (bon code / Face ID)
    if (d && d.frame && d.frame.phone) { st.info = d.frame.phone; wall(); drawBar(); }
    if (d && d.env) st.env = d.env;
    // action refusée depuis un formulaire local : on reste sur le formulaire (rien n'est effacé), le message s'affiche en bas
    if (d && d.ok === false && NOSERVER[st.view] && st.view !== 'home') return;
    if (d && d.page && d.page.page) {
      const pg = d.page.page;
      // une réponse de page ne remplace pas un écran local en cours de saisie
      // l'écran d'appel reste devant tant que l'appel dure
      if (!(NOSERVER[st.view] && st.view !== 'home' && pg === st.view) && !((st.view === 'call' || st.view === 'invite') && st.call)) { st.view = pg; }
      st.data = d.page.data || null; st.loading = false;
      if (st.data && (st.data.contacts || (pg === 'contacts' && st.data.list))) st.contactsCache = st.data.contacts || st.data.list;
      if (pg === 'thread' && st.data && st.data.num) st.sel = st.data.num;
    } else if (d && d.err) { st.loading = false; say(false, d.err); }
    render();
  }

  // ---- éléments communs
  function header(title, back, right, backLabel) {
    const chev = h('i', { class: 'ph-chev' }); chev.innerHTML = SVG('<path d="M9 2 2.5 9 9 16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>', '0 0 12 18');
    if (ROOT[st.view]) return h('div', { class: 'ph-hd ios big' }, h('div', { class: 'ph-hdr' }, right || h('i')), h('h1', null, title));
    return h('div', { class: 'ph-hd ios' }, back ? h('button', { class: 'ph-bk ios', type: 'button', onclick: back, title: 'Retour' }, chev, h('span', null, backLabel || 'Retour')) : h('i', { class: 'ph-bk0' }), h('b', null, title), right || h('i', { class: 'ph-bk0' }));
  }
  const empty = (txt) => h('div', { class: 'ph-empty' }, txt);
  const act = (n, p, pg) => opts.act(n, p || {}, pg || st.view);
  function row(lead, title, sub, right, onclick) {
    return h('div', { class: 'ph-row' + (onclick ? ' tap' : ''), onclick }, lead, h('div', { class: 'ph-rt' }, h('b', null, title), sub != null ? h('small', null, sub) : null), right || null);
  }
  const avatar = (name, svc) => svc ? h('span', { class: 'ph-av svc' }, ico('building')) : h('span', { class: 'ph-av', style: { '--hu': hue(name) } }, initials(name));
  function field(label, props) { const inp = h('input', Object.assign({ class: 'ph-in', type: 'text', autocomplete: 'off', spellcheck: 'false' }, props || {})); return { el: h('label', { class: 'ph-f' }, h('span', null, label), inp), inp }; }
  const btn = (label, onclick, kind, icon) => h('button', { type: 'button', class: 'ph-b ' + (kind || ''), onclick }, icon ? ico(icon) : null, label);

  // ---- écrans
  const R = {};
  const DOCK = ['calls', 'messages', 'contacts', 'settings'];
  function launch(id) { nav(id === 'calc' ? 'calc' : id); }
  function appBtn(a, dock) {
    return h('button', { type: 'button', class: 'ph-app', onclick: () => launch(a.id) }, h('span', { class: 'ph-ap' }, appIcon(a.id, 58), a.badge > 0 ? h('i', { class: 'ph-bd' }, a.badge > 99 ? '99+' : String(a.badge)) : null), dock ? null : h('small', null, a.label));
  }
  function weatherWidget() {
    const e = st.env || {}, w = WX[e.weather] || WX.clouds, night = st.clock[0] >= 20 || st.clock[0] < 7;
    const temp = e.temp != null ? e.temp : 21;
    return h('div', { class: 'ph-wg wx' + (night ? ' night' : '') + (/rain|thunder/.test(e.weather || '') ? ' rain' : '') },
      h('div', { class: 'ph-wgt' }, h('b', null, e.zone || 'Los Santos'), h('i', { class: 'ph-loc' }, '➤')),
      h('strong', null, temp + '°'),
      wxIcon(night && w[1] === 'sun' ? 'moon' : w[1], 18),
      h('span', null, w[0]), h('small', null, 'Ressenti ' + (temp + (e.feels || 1)) + '°'));
  }
  function calendarWidget() {
    const e = st.env || {}, now = new Date();
    const y = e.year || now.getFullYear(), m = e.month != null ? e.month : now.getMonth(), today = e.day || now.getDate();
    const first = (new Date(y, m, 1).getDay() + 6) % 7, days = new Date(y, m + 1, 0).getDate();
    const cells = ['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((l) => h('i', { class: 'hd' }, l));
    for (let i = 0; i < first; i++) cells.push(h('i'));
    for (let d = 1; d <= days; d++) cells.push(h('i', { class: d === today ? 'on' : '' }, String(d)));
    return h('div', { class: 'ph-wg cal' }, h('b', { class: 'ph-mon' }, MONTHS[m] || ''), h('div', { class: 'ph-cg' }, cells));
  }
  R.home = () => {
    const info = st.info || { apps: [] }, apps = info.apps || [];
    const byId = {}; apps.forEach((a) => { byId[a.id] = a; });
    const grid = h('div', { class: 'ph-grid ios' });
    apps.filter((a) => DOCK.indexOf(a.id) < 0).forEach((a) => grid.appendChild(appBtn(a)));
    const dock = h('div', { class: 'ph-dock' }, DOCK.filter((id) => byId[id]).map((id) => appBtn(byId[id], true)));
    return h('div', { class: 'ph-homeview ios' },
      h('div', { class: 'ph-wgs' }, h('div', { class: 'ph-wgw' }, weatherWidget(), h('small', null, 'Météo')), h('div', { class: 'ph-wgw' }, calendarWidget(), h('small', null, 'Calendrier'))),
      grid,
      h('button', { type: 'button', class: 'ph-srch', onclick: () => { st.q = ''; nav('search'); } }, h('i', { class: 'ph-mag' }, '⌕'), 'Rechercher'),
      dock);
  };
  // Recherche : applications et contacts
  R.search = () => {
    const info = st.info || { apps: [] };
    const inp = h('input', { class: 'ph-in srch', type: 'text', placeholder: 'Rechercher', value: st.q || '', autocomplete: 'off', spellcheck: 'false' });
    const out = h('div', { class: 'ph-sres' });
    const draw = () => {
      const q = inp.value.trim().toLowerCase(); st.q = inp.value; G.clear(out);
      const apps = (info.apps || []).filter((a) => !q || a.label.toLowerCase().indexOf(q) >= 0);
      if (apps.length) out.appendChild(h('div', { class: 'ph-sgrid' }, apps.slice(0, 8).map((a) => appBtn(a))));
      const cs = (st.contactsCache || []).filter((c) => q && (c.name.toLowerCase().indexOf(q) >= 0 || String(c.number).indexOf(q) >= 0)).slice(0, 6);
      if (cs.length) out.appendChild(h('div', { class: 'ph-list' }, h('div', { class: 'ph-sec' }, 'Contacts'), cs.map((c) => row(avatar(c.name), c.name, c.number, callBtn(c.number), () => act('open_thread', { num: c.number }, 'contacts')))));
      if (!apps.length && !cs.length) out.appendChild(empty('Aucun résultat.'));
    };
    inp.addEventListener('input', draw);
    setTimeout(() => { inp.focus(); draw(); }, 20);
    return h('div', { class: 'ph-app-v srchv' }, h('div', { class: 'ph-sbar' }, inp, h('button', { type: 'button', class: 'ph-cancel', onclick: () => nav('home') }, 'Annuler')), out);
  };

  // ---- appels : clavier, récents, contacts ; écran d'appel en cours
  const callAct = (n) => (opts.callAct ? opts.callAct(n) : G.post('call.' + n, {}));
  const callBtn = (num, title) => h('button', { class: 'ph-bk call', type: 'button', title: title || 'Appeler', onclick: (e) => { e.stopPropagation(); act('call', { num }, st.view); } }, ico('call'));
  R.calls = () => {
    const d = st.data || {}, tab = st.ctab;
    const seg = h('div', { class: 'ph-seg' }, [['keys', 'Clavier'], ['recent', 'Récents'], ['contacts', 'Contacts']].map((t) => h('button', { type: 'button', class: tab === t[0] ? 'on' : '', onclick: () => { st.ctab = t[0]; render(); } }, t[1])));
    let main;
    if (d.voice === false) main = empty("Les appels sont indisponibles sur ce serveur pour le moment. Tu peux toujours envoyer des messages.");
    else if (tab === 'recent') {
      const rows = (d.recent || []).map((c) => row(avatar(c.label, c.svc), c.label,
        h('span', { class: 'ph-cl' + (c.missed ? ' miss' : '') }, h('i', { class: 'ph-dir' + (c.out ? ' out' : '') }, ico('arrow')), c.missed ? 'Manqué' : c.status === 'declined' ? 'Refusé' : c.secs > 0 ? dur(c.secs) : c.out ? 'Sans réponse' : 'Manqué', ' · ' + c.at),
        callBtn(c.num), () => act('call', { num: c.num }, 'calls')));
      main = h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun appel récent.'));
    } else if (tab === 'contacts') {
      const rows = (d.contacts || []).map((c) => row(avatar(c.name), c.name, c.number, callBtn(c.number), () => act('call', { num: c.number }, 'calls')));
      main = h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun contact.'));
    } else {
      const disp = h('b', null, st.dial || ' ');
      const press = (k) => {
        if (k === '⌫') st.dial = st.dial.replace(/-$/, '').replace(/\d$/, '');
        else if (st.dial.replace('-', '').length < 7) { st.dial += k; if (/^\d{3}$/.test(st.dial)) st.dial += '-'; }
        disp.textContent = st.dial || ' ';
      };
      const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'].map((k) => k ? h('button', { type: 'button', class: 'ph-dk', onclick: () => press(k) }, k) : h('i'));
      main = h('div', { class: 'ph-dial' }, h('div', { class: 'ph-dd' }, disp), h('div', { class: 'ph-dks' }, keys),
        h('div', { class: 'ph-dialb' },
          h('button', { type: 'button', class: 'ph-sos', title: "Appel d'urgence : police et secours en service, ta position leur est envoyée", onclick: () => act('call', { num: '911' }, 'calls') }, 'SOS 911'),
          h('button', { type: 'button', class: 'ph-cb go', title: 'Appeler', onclick: () => { if (st.dial) act('call', { num: st.dial }, 'calls'); } }, ico('call')),
          h('i', { class: 'ph-sos0' })));
    }
    return h('div', { class: 'ph-app-v' }, header('Appels', () => nav('home')), seg, main);
  };
  R.call = () => {
    const c = st.call;
    if (!c) return h('div', { class: 'ph-app-v' }, header('Appels', () => nav('calls')), empty('Aucun appel en cours.'));
    const status = c.state === 'incoming' ? (c.svc ? 'Appel pour ton service' : 'Appel entrant…') : c.state === 'outgoing' ? 'Appel en cours…' : dur(c.since + Math.floor((Date.now() - c.t) / 1000));
    const btns = c.state === 'incoming'
      ? [h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb end', title: 'Refuser', onclick: () => callAct('hangup') }, ico('call')), h('small', null, 'Refuser')),
         h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb go', title: 'Décrocher', onclick: () => callAct('answer') }, ico('call')), h('small', null, 'Décrocher'))]
      : [c.state === 'live' ? h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb spk' + (c.speaker ? ' on' : ''), title: 'Haut-parleur : les personnes à côté de toi entendent l\'appel', onclick: () => callAct('speaker') }, ico('volume')), h('small', null, c.speaker ? 'Haut-parleur activé' : 'Haut-parleur')) : null,
         c.state === 'live' && !c.emergency ? h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb spk', title: 'Ajouter quelqu\'un à l\'appel (conférence)', onclick: () => { st.view = 'invite'; render(); } }, ico('plus')), h('small', null, 'Ajouter')) : null,
         h('div', { class: 'ph-cbw' }, h('button', { type: 'button', class: 'ph-cb end', title: 'Raccrocher', onclick: () => callAct('hangup') }, ico('call')), h('small', null, 'Raccrocher'))];
    return h('div', { class: 'ph-callv' + (c.state === 'incoming' ? ' ring' : '') },
      h('div', { class: 'ph-cid' }, h('span', { class: 'ph-av big' + (c.svc ? ' svc' : ''), style: { '--hu': hue(c.label) } }, c.svc ? ico('building') : initials(c.label)), h('b', null, c.label || c.num || ''), h('small', null, c.label !== c.num && !c.svc ? c.num : ''), h('em', { class: 'ph-cst' }, status)),
      h('div', { class: 'ph-cbs' }, btns));
  };
  // conférence : numéro à ajouter (ou un contact), puis retour à l'écran d'appel
  R.invite = () => {
    const num = field('Numéro à ajouter (555-0123)', { maxlength: 8 });
    const go = () => { if (num.inp.value) { (opts.invite ? opts.invite(num.inp.value) : G.post('call.invite', { num: num.inp.value })); st.view = 'call'; render(); } };
    num.inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    setTimeout(() => num.inp.focus(), 30);
    const chips = h('div', { class: 'ph-chips' }, ((st.contactsCache || []).slice(0, 12)).map((c) => h('button', { type: 'button', class: 'ph-chip', onclick: () => { num.inp.value = c.number; } }, c.name)));
    return h('div', { class: 'ph-app-v' }, header('Ajouter à l\'appel', () => { st.view = 'call'; render(); }), h('div', { class: 'ph-form' }, chips.children.length ? chips : null, num.el, btn('Faire sonner', go, 'go', 'call')));
  };
  function onCall(d) {
    if (d.state === 'ended') {
      const was = st.call; st.call = null;
      if (d.reason) say(false, d.reason);
      if (st.view === 'call' || st.view === 'invite') nav(st.back === 'call' || st.back === 'invite' ? 'calls' : (st.back || 'calls'));
      return was;
    }
    st.call = Object.assign({}, d, { t: Date.now() });
    if (st.view !== 'call' && st.view !== 'invite') { st.back = st.view; st.view = 'call'; }
    render();
  }

  R.messages = () => {
    const d = st.data || {}, list = d.threads || [];
    const right = h('span', { class: 'ph-hx' },
      h('button', { class: 'ph-bk', type: 'button', title: 'Nouveau groupe', onclick: () => { st.edit = { name: '', numbers: '' }; nav('newgroup'); } }, ico('users')),
      h('button', { class: 'ph-bk', type: 'button', title: 'Nouveau message', onclick: () => { st.compose = { num: '', body: '' }; nav('newmsg'); } }, ico('edit')));
    const rows = list.map((t) => row(t.group ? h('span', { class: 'ph-av grp' }, ico('users')) : avatar(t.label, t.svc), t.label, (t.mine ? 'Toi : ' : '') + t.last, h('div', { class: 'ph-rr' }, h('small', null, t.at), t.unread > 0 ? h('i', { class: 'ph-bd s' }, String(t.unread)) : null), () => act('open_thread', { num: t.num }, 'messages')));
    return h('div', { class: 'ph-app-v' }, header('Messages', () => nav('home'), right), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucune conversation. Appuie sur le crayon pour écrire.')));
  };
  R.newmsg = () => {
    const num = field('Numéro (555-0123)', { maxlength: 8, value: st.compose ? st.compose.num : '' }), bodyF = field('Message', { maxlength: 240, value: st.compose ? st.compose.body : '' });
    const go = () => { st.compose = { num: num.inp.value, body: bodyF.inp.value }; act('send_new', { num: num.inp.value, body: bodyF.inp.value }, 'messages'); };
    bodyF.inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    setTimeout(() => (st.compose && st.compose.num ? bodyF.inp : num.inp).focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouveau message', () => nav('messages')), h('div', { class: 'ph-form' }, num.el, bodyF.el, btn('Envoyer', go, 'pri', 'send')));
  };
  R.newgroup = () => {
    const e = st.edit || { name: '', numbers: '' };
    const nm = field('Nom du groupe', { maxlength: 32, value: e.name || '' }), nu = field('Numéros (séparés par des virgules)', { maxlength: 120, value: e.numbers || '' });
    const chips = h('div', { class: 'ph-chips' }, ((st.contactsCache || []).slice(0, 16)).map((c) => h('button', { type: 'button', class: 'ph-chip', onclick: () => { if (nu.inp.value.indexOf(c.number) < 0) nu.inp.value = (nu.inp.value ? nu.inp.value + ', ' : '') + c.number; } }, c.name)));
    const go = () => { st.edit = { name: nm.inp.value, numbers: nu.inp.value }; act('group_create', { name: nm.inp.value, numbers: nu.inp.value }, 'messages'); };
    setTimeout(() => nm.inp.focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouveau groupe', () => nav('messages')), h('div', { class: 'ph-form' }, nm.el, chips.children.length ? h('small', { class: 'ph-note' }, 'Touche un contact pour l\'ajouter :') : null, chips.children.length ? chips : null, nu.el, btn('Créer le groupe', go, 'pri', 'users')));
  };
  R.thread = () => {
    const d = st.data || {};
    if (d.empty || !d.num) return h('div', { class: 'ph-app-v' }, header('Messages', () => nav('messages')), empty('Choisis une conversation.'));
    const feed = h('div', { class: 'ph-feed' });
    (d.msgs || []).forEach((m) => feed.appendChild(h('div', { class: 'ph-bub ' + (m.mine ? 'me' : 'in') + (m.pos ? ' pos' : '') }, m.pos ? h('span', { class: 'ph-posm' }, ico('pin'), h('b', null, m.mine ? 'Ta position' : 'Position partagée'), h('button', { type: 'button', class: 'ph-pgo', onclick: () => act('gps_msg', { id: m.id }, 'thread') }, 'Y aller')) : h('span', null, m.who ? h('b', { class: 'ph-who' }, m.who) : null, m.body), h('small', null, m.at,
      (!m.mine && !m.reported) ? h('button', { type: 'button', class: 'ph-rep', title: 'Signaler ce message au staff', onclick: () => act('report', { id: m.id }, 'thread') }, 'signaler') : null))));
    const inp = h('input', { class: 'ph-in msg', type: 'text', maxlength: d.maxlen || 240, placeholder: 'Message', autocomplete: 'off', spellcheck: 'false' });
    const send = () => { const t = inp.value.trim(); if (!t) return; inp.value = ''; act('send', { body: t }, 'thread'); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });
    setTimeout(() => { feed.scrollTop = feed.scrollHeight; inp.focus(); }, 30);
    const right = d.group ? h('button', { class: 'ph-bk', type: 'button', title: 'Quitter le groupe', onclick: () => act('group_leave', {}, 'thread') }, ico('x'))
      : d.canAdd ? h('button', { class: 'ph-bk', type: 'button', title: 'Ajouter aux contacts', onclick: () => { st.edit = { number: d.num, name: '' }; nav('newcontact'); } }, ico('plus')) : null;
    if (d.ro) {   // message automatique (fourrière, trésor public…) : on lit, on ne répond pas
      setTimeout(() => { feed.scrollTop = feed.scrollHeight; }, 30);
      return h('div', { class: 'ph-app-v chat' }, header(d.label, () => nav('messages')), h('div', { class: 'ph-sub' }, h('span', null, 'Message automatique : ne pas répondre')), feed);
    }
    const sub = d.group ? h('div', { class: 'ph-sub' }, h('span', null, (d.members || []).join(', ')))
      : h('div', { class: 'ph-sub' }, h('span', null, d.svc ? 'Service : les employés en service reçoivent ton message' : d.num), h('button', { type: 'button', class: 'ph-pcall', title: 'Appeler', onclick: () => act('call', { num: d.num }, 'thread') }, ico('call'), 'Appeler'));
    return h('div', { class: 'ph-app-v chat' }, header(d.label, () => nav('messages'), right), sub, feed,
      h('div', { class: 'ph-bar' }, h('button', { type: 'button', class: 'ph-snd loc', title: 'Envoyer ma position', onclick: () => act('send_pos', {}, 'thread') }, ico('pin')), inp, h('button', { type: 'button', class: 'ph-snd', title: 'Envoyer', onclick: send }, ico('send'))));
  };

  R.contacts = () => {
    const d = st.data || {}, list = d.list || [];
    const dropBtn = h('button', { class: 'ph-bk', type: 'button', title: 'AirDrop : partager une fiche avec quelqu\'un à côté', onclick: () => { st.dropWhat = 'me'; nav('airdrop'); } }); dropBtn.innerHTML = SVG(GLYPH.airdrop.replace(/#fff/g, '#0a84ff'));
    const right = h('span', { class: 'ph-hx' }, dropBtn, h('button', { class: 'ph-bk', type: 'button', title: 'Nouveau contact', onclick: () => { st.edit = { name: '', number: '' }; nav('newcontact'); } }, ico('plus')));
    const rows = list.map((c) => {
      const open = st.sel === 'c' + c.id;
      const r = row(avatar(c.name), c.name, c.number, h('i', { class: 'ph-chv' }, ico('chevron')), () => { st.sel = open ? null : 'c' + c.id; render(); });
      return h('div', { class: 'ph-grp' }, r, open ? h('div', { class: 'ph-acts five' }, btn('Appeler', () => act('call', { num: c.number }, 'contacts'), 'go', 'call'), btn('Écrire', () => act('open_thread', { num: c.number }, 'contacts'), 'pri', 'chat'), btn('Virer', () => { st.send = c.number; nav('bank'); }, '', 'card'), btn('AirDrop', () => { st.dropWhat = String(c.id); nav('airdrop'); }, '', 'send'),
        c.blocked ? btn('Débloquer', () => act('unblock', { num: c.number }, 'contacts'), '', 'check') : btn('Bloquer', () => act('block', { num: c.number }, 'contacts'), 'bad', 'lock'),
        btn('Supprimer', () => act('del_contact', { id: c.id }, 'contacts'), 'bad', 'trash')) : null);
    });
    const bl = (d.blocked || []).map((b) => row(h('span', { class: 'ph-ti out' }, ico('lock')), b.name || b.number, b.name ? b.number : 'Numéro bloqué', btn('Débloquer', () => act('unblock', { num: b.number }, 'contacts'), 'small')));
    const meCard = d.me ? h('div', { class: 'ph-mycard', onclick: () => { st.dropWhat = 'me'; nav('airdrop'); } }, h('span', { class: 'ph-av big2', style: { '--hu': hue((st.info && st.info.name) || '') } }, initials((st.info && st.info.name) || '?')), h('div', null, h('b', null, (st.info && st.info.name) || 'Moi'), h('small', null, 'Ma fiche · ' + d.me)), h('em', null, 'AirDrop')) : null;
    return h('div', { class: 'ph-app-v' }, header('Contacts', () => nav('home'), right), meCard, h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun contact.'),
      bl.length ? h('div', { class: 'ph-sec' }, 'Numéros bloqués') : null, bl));
  };
  R.newcontact = () => {
    const e = st.edit || { name: '', number: '' };
    const nm = field('Nom', { maxlength: 40, value: e.name }), nu = field('Numéro (555-0123)', { maxlength: 8, value: e.number });
    const go = () => { st.edit = { name: nm.inp.value, number: nu.inp.value }; act('add_contact', { name: nm.inp.value, number: nu.inp.value }, 'contacts'); };
    setTimeout(() => nm.inp.focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouveau contact', () => nav('contacts')), h('div', { class: 'ph-form' }, nm.el, nu.el, btn('Enregistrer', go, 'pri', 'check')));
  };

  R.services = () => {
    const list = (st.data && st.data.list) || [];
    const open = list.filter((s) => s.duty > 0).length;
    const rows = list.map((s) => row(avatar(s.name, true), s.name, h('span', { class: 'ph-open ' + (s.duty > 0 ? 'on' : 'off') }, s.duty > 0 ? 'Ouvert · ' + s.duty + ' en service' : 'Fermé'), s.duty > 0 ? callBtn('svc:' + s.id, 'Appeler le service') : h('i', { class: 'ph-dot' }), () => act('open_thread', { num: 'svc:' + s.id }, 'services')));
    if (list.length) rows.unshift(h('div', { class: 'ph-sec' }, open + ' ouvert' + (open > 1 ? 's' : '') + ' sur ' + list.length));
    return h('div', { class: 'ph-app-v' }, header('Annuaire', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty("Aucun service n'est listé."), h('p', { class: 'ph-note' }, 'Appelle un service : tous les employés en service sonnent. Un message les prévient aussi ; ils te répondent sur ton numéro.')));
  };

  R.bank = () => {
    const d = st.data || {};
    const num = field('Numéro du destinataire', { maxlength: 8, value: st.send || '' }), amt = field('Montant ($)', { type: 'number', inputmode: 'numeric', min: d.min || 1, max: d.max || 250000 }), note = field('Motif (facultatif)', { maxlength: 60 });
    const chips = h('div', { class: 'ph-chips' }, (d.contacts || []).slice(0, 8).map((c) => h('button', { type: 'button', class: 'ph-chip', onclick: () => { num.inp.value = c.number; } }, c.name)));
    const go = () => { st.send = null; act('bank_send', { num: num.inp.value, amount: Number(amt.inp.value), note: note.inp.value }, 'bank'); };
    return h('div', { class: 'ph-app-v scroll' }, header('Banque', () => nav('home')),
      h('div', { class: 'ph-card' }, h('small', null, 'Solde du compte'), h('b', { class: 'big' }, money(d.bank)), h('div', { class: 'ph-split' }, h('span', null, 'Espèces ', h('b', null, money(d.cash))), h('span', null, d.iban || ''))),
      h('div', { class: 'ph-sec' }, 'Envoyer de l\'argent'),
      h('div', { class: 'ph-form tight' }, chips.children.length ? chips : null, num.el, amt.el, note.el, btn('Envoyer le virement' + (d.fee ? ' (frais ' + d.fee + ' %)' : ''), go, 'pri', 'send')),
      h('div', { class: 'ph-sec' }, 'Dernières opérations'),
      h('div', { class: 'ph-list' }, (d.tx || []).length ? (d.tx || []).map((t) => row(h('span', { class: 'ph-ti ' + (t.plus ? 'in' : 'out') }, ico(t.plus ? 'arrow' : 'arrow')), t.label, (t.note ? t.note + ' · ' : '') + t.at, h('b', { class: 'ph-am ' + (t.plus ? 'in' : 'out') }, (t.plus ? '+' : '−') + money(Math.abs(t.amount))))) : [empty('Aucune opération.')]));
  };

  R.bills = () => {
    const d = st.data || {}, list = d.list || [];
    const rows = list.map((b) => row(h('span', { class: 'ph-ti ' + (b.status === 'pending' ? 'out' : 'in') }, ico(b.fine ? 'alert' : 'file')), (b.fine ? 'Amende' : 'Facture') + (b.from ? ' · ' + b.from : ''), b.reason || '', b.status === 'pending' ? btn('Payer ' + money(b.amount), () => act('pay_bill', { id: b.id }, 'bills'), 'pri small') : h('small', { class: 'ph-pill' }, b.status === 'paid' ? 'Réglée' : 'Annulée')));
    return h('div', { class: 'ph-app-v' }, header('Factures', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucune facture. Tout est réglé.'), h('p', { class: 'ph-note' }, 'Le paiement se fait depuis ton compte en banque : ' + money(d.bank) + ' disponibles.')));
  };

  R.garage = () => {
    const list = (st.data && st.data.list) || [];
    const S = { garage: 'Rangé', out: 'Sorti', impound: 'Fourrière' };
    const bar = (label, v) => v == null ? null : h('span', { class: 'ph-gb' + (v < 25 ? ' low' : v < 60 ? ' mid' : '') }, h('i', { style: { width: v + '%' } }), h('em', null, label + ' ' + v + ' %'));
    const card = (v) => h('div', { class: 'ph-grp' }, row(h('span', { class: 'ph-ti car' }, ico('car')), v.label, v.plate + ' · ' + (v.where || S[v.state] || v.state),
      v.canGo ? btn(v.state === 'out' ? 'Localiser' : 'Y aller', () => act('gps_car', { plate: v.plate }, 'garage'), 'pri small', 'pin') : h('small', { class: 'ph-pill' }, S[v.state] || v.state)),
      h('div', { class: 'ph-gbs' }, bar('Carburant', v.fuel), bar('Moteur', v.engine), bar('Carrosserie', v.body), h('small', null, v.live ? 'En direct' : 'Au dernier rangement')));
    const GROUPS = [['mine', null], ['biz', 'Véhicules de service (en service)'], ['keys', 'Clés prêtées']];
    const body = [];
    GROUPS.forEach(([g, title]) => {
      const part = list.filter((v) => (v.group || 'mine') === g);
      if (!part.length) return;
      if (title) body.push(h('div', { class: 'ph-sec' }, title));
      part.forEach((v) => body.push(card(v)));
    });
    const out = list.filter((v) => v.state === 'out' && (v.group || 'mine') === 'mine').length;
    const right = out ? h('button', { class: 'ph-bk', type: 'button', title: 'Tous mes véhicules sortis sur la carte', onclick: () => act('gps_all', {}, 'garage') }, ico('pin')) : null;
    return h('div', { class: 'ph-app-v' }, header('Garage', () => nav('home'), right), h('div', { class: 'ph-list' }, body.length ? body : empty("Tu n'as aucun véhicule.")));
  };

  R.gps = () => {
    const pl = (st.data && st.data.places) || [];
    const rows = pl.map((p) => row(h('span', { class: 'ph-ti pin' }, ico('pin')), p.label, null, btn('Y aller', () => act('gps_set', { id: p.id }, 'gps'), 'pri small')));
    return h('div', { class: 'ph-app-v' }, header('GPS', () => nav('home')), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucun lieu enregistré.')), h('div', { class: 'ph-form tight' }, btn("Effacer l'itinéraire", () => act('gps_clear', {}, 'gps'), '', 'x')));
  };

  // ---- petites annonces : liste par catégorie, contacter l'auteur, publier
  R.ads = () => {
    const d = st.data || {}, list = d.list || [], cat = st.adcat || '';
    const right = h('button', { class: 'ph-bk', type: 'button', title: 'Publier une annonce', onclick: () => { st.adinfo = { cats: d.cats || [], price: d.price || 0, hours: d.hours || 48 }; nav('newad'); } }, ico('plus'));
    const chips = h('div', { class: 'ph-chips' }, [['', 'Tout']].concat(d.cats || []).map((c) => h('button', { type: 'button', class: 'ph-chip' + (cat === c[0] ? ' on' : ''), onclick: () => { st.adcat = c[0]; render(); } }, c[1])));
    const shown = list.filter((a) => !cat || a.cat === cat);
    const cards = shown.map((a) => {
      const open = st.sel === 'ad' + a.id;
      const card = h('div', { class: 'ph-ad' + (open ? ' open' : ''), onclick: () => { st.sel = open ? null : 'ad' + a.id; render(); } },
        h('div', { class: 'ph-adh' }, h('span', { class: 'ph-adc' }, a.catLabel), a.price > 0 ? h('b', { class: 'ph-adp' }, money(a.price)) : null),
        h('b', { class: 'ph-adt' }, a.title), a.body ? h('p', null, open ? a.body : a.body.slice(0, 90) + (a.body.length > 90 ? '…' : '')) : null,
        h('small', null, a.name + ' · ' + a.at));
      const actions = open ? h('div', { class: 'ph-acts' }, a.mine ? btn('Supprimer', () => act('ad_del', { id: a.id }, 'ads'), 'bad', 'trash')
        : [btn('Écrire', () => act('open_thread', { num: a.number }, 'ads'), 'pri', 'chat'), btn('Appeler', () => act('call', { num: a.number }, 'ads'), 'go', 'call')]) : null;
      return h('div', { class: 'ph-grp' }, card, actions);
    });
    return h('div', { class: 'ph-app-v' }, header('Annonces', () => nav('home'), right), chips, h('div', { class: 'ph-list' }, cards.length ? cards : empty(cat ? 'Aucune annonce dans cette catégorie.' : 'Aucune annonce pour le moment. Publie la première !')));
  };
  R.newad = () => {
    const i = st.adinfo || { cats: [], price: 0, hours: 48 };
    const t = field('Titre', { maxlength: 60, placeholder: 'Ex. : Vends Sultan RS, bon état' }), pr = field('Prix (facultatif)', { maxlength: 10, inputmode: 'numeric', placeholder: '0' });
    const b = h('textarea', { class: 'ph-in ta', maxlength: 400, placeholder: 'Détails, où te trouver…', spellcheck: 'false' });
    const sel = h('select', { class: 'ph-in' }, (i.cats || []).map((c) => h('option', { value: c[0] }, c[1])));
    const go = () => act('ad_post', { title: t.inp.value, body: b.value, cat: sel.value, price: parseInt(String(pr.inp.value).replace(/\D/g, ''), 10) || 0 }, 'ads');
    setTimeout(() => t.inp.focus(), 30);
    return h('div', { class: 'ph-app-v' }, header('Nouvelle annonce', () => nav('ads')),
      h('div', { class: 'ph-form' }, t.el, h('label', { class: 'ph-f' }, h('span', null, 'Catégorie'), sel), pr.el, h('label', { class: 'ph-f' }, h('span', null, 'Texte'), b),
        h('small', { class: 'ph-hint' }, (i.price > 0 ? 'Publication : ' + money(i.price) + ' · ' : '') + 'en ligne ' + i.hours + ' h'), btn('Publier', go, 'pri', 'send')));
  };

  // ---- taxi : commander (client) ; courses et taximètre (chauffeur en service)
  R.taxi = () => {
    const d = st.data || {}, r = d.rates || {};
    const blocks = [];
    if (!d.company) blocks.push(empty("Il n'y a pas de compagnie de taxi en ville pour le moment."));
    else if (d.driver) {
      const m = d.meter;
      blocks.push(h('div', { class: 'ph-txm' + (m ? ' on' : '') }, h('small', null, m ? 'Compteur en marche · ' + m.riders + ' passager(s)' : 'Compteur à l\'arrêt'), h('b', null, money(m ? m.fare : 0)), h('span', null, m ? String(m.km).replace('.', ',') + ' km' : 'Client à bord ? Démarre le compteur au volant.')));
      blocks.push(h('div', { class: 'ph-form tight' }, m ? btn('Arrêter et encaisser', () => act('taxi_stop', {}, 'taxi'), 'pri', 'check') : btn('Démarrer le compteur', () => act('taxi_start', {}, 'taxi'), 'pri', 'clock')));
      const calls = (d.calls || []).map((c) => row(h('span', { class: 'ph-ti pin' }, ico('user')), c.name, (c.dist >= 1000 ? (c.dist / 1000).toFixed(1).replace('.', ',') + ' km' : c.dist + ' m') + ' · il y a ' + c.ago + ' min' + (c.taken ? ' · prise' : c.mine ? ' · ta course' : ''),
        c.taken ? null : btn(c.mine ? 'GPS' : 'Accepter', () => act('taxi_accept', { id: c.id }, 'taxi'), 'pri small')));
      blocks.push(h('div', { class: 'ph-sec' }, 'Courses demandées'), h('div', { class: 'ph-list' }, calls.length ? calls : empty('Aucune course en attente.')));
    } else {
      const m = d.mine;
      blocks.push(h('div', { class: 'ph-txm' + (m ? ' on' : '') }, h('small', null, d.company), h('b', null, m ? (m.state === 'accepted' ? 'Taxi en route' : 'Recherche…') : 'Besoin d\'un taxi ?'),
        h('span', null, m ? (m.state === 'accepted' ? (m.driver || 'Un chauffeur') + ' arrive vers toi.' : 'Les chauffeurs en service sont prévenus.') : 'Prise en charge ' + money(r.base) + ' · ' + money(r.km) + ' / km · ' + money(r.min) + ' / min')));
      blocks.push(h('div', { class: 'ph-form tight' }, m ? btn('Annuler la commande', () => act('taxi_cancel', {}, 'taxi'), 'bad', 'x') : btn('Commander un taxi ici', () => act('taxi_call', {}, 'taxi'), 'pri', 'pin')));
    }
    return h('div', { class: 'ph-app-v' }, header('Taxi', () => nav('home'), h('button', { class: 'ph-bk', type: 'button', title: 'Actualiser', onclick: () => nav('taxi') }, ico('refresh'))), h('div', { class: 'ph-list' }, blocks));
  };

  // ---- contrats : vendre un véhicule ou un logement à quelqu'un à côté (il accepte sur son écran)
  R.deals = () => {
    const d = st.data || {}, goods = d.goods || [], near = d.near || [];
    if (!goods.length) return h('div', { class: 'ph-app-v' }, header('Contrats', () => nav('home')), empty("Tu n'as rien à vendre."));
    const sel = h('select', { class: 'ph-in', onchange: () => upd() }, goods.map((g, i) => h('option', { value: String(i) }, (g.kind === 'veh' ? '🚗 ' : g.kind === 'house' ? '🏠 ' : '📦 ') + g.label + (g.kind === 'item' ? ' (×' + g.max + ')' : ''))));
    const qty = field('Quantité', { maxlength: 5, inputmode: 'numeric', value: '1' });
    const upd = () => { const g = goods[Number(sel.value)] || {}; qty.el.style.display = g.kind === 'item' ? '' : 'none'; };
    const who = h('select', { class: 'ph-in' }, near.length ? near.map((p) => h('option', { value: String(p.id) }, p.name + ' (' + p.id + ')')) : [h('option', { value: '' }, 'Personne à côté de toi')]);
    const pr = field('Prix ($)', { maxlength: 10, inputmode: 'numeric', placeholder: '0' });
    const go = () => { const g = goods[Number(sel.value)] || {}; act('deal_offer', { kind: g.kind, ref: g.ref, qty: parseInt(String(qty.inp.value).replace(/\D/g, ''), 10) || 1, buyer: Number(who.value), price: parseInt(String(pr.inp.value).replace(/\D/g, ''), 10) || 0 }, 'deals'); };
    setTimeout(upd, 0);
    return h('div', { class: 'ph-app-v' }, header('Contrats', () => nav('home'), h('button', { class: 'ph-bk', type: 'button', title: 'Actualiser', onclick: () => nav('deals') }, ico('refresh'))),
      h('div', { class: 'ph-form' }, h('label', { class: 'ph-f' }, h('span', null, 'Bien à vendre'), sel), qty.el, h('label', { class: 'ph-f' }, h('span', null, 'Acheteur (à côté de toi)'), who), pr.el,
        h('small', { class: 'ph-hint' }, "L'acheteur signe sur son écran ; l'argent arrive sur ton compte" + (d.tax ? ' (taxe de mutation ' + d.tax + ' %)' : '') + '.'), btn('Proposer le contrat', go, 'pri', 'send')));
  };

  R.notes = () => {
    const list = (st.data && st.data.list) || [];
    const right = h('button', { class: 'ph-bk', type: 'button', title: 'Nouvelle note', onclick: () => { st.edit = { id: 0, title: '', body: '' }; nav('editnote'); } }, ico('plus'));
    const rows = list.map((n) => row(h('span', { class: 'ph-ti note' }, ico('note')), n.title || 'Sans titre', n.body.replace(/\s+/g, ' ').slice(0, 60), h('small', null, n.at), () => { st.edit = { id: n.id, title: n.title, body: n.body }; nav('editnote'); }));
    return h('div', { class: 'ph-app-v' }, header('Notes', () => nav('home'), right), h('div', { class: 'ph-list' }, rows.length ? rows : empty('Aucune note.')));
  };
  R.editnote = () => {
    const e = st.edit || { id: 0, title: '', body: '' };
    const t = field('Titre', { maxlength: 60, value: e.title }), b = h('textarea', { class: 'ph-in ta', maxlength: 1500, placeholder: 'Écris ici…', spellcheck: 'false' }); b.value = e.body || '';
    const go = () => act('note_save', { id: e.id, title: t.inp.value, body: b.value }, 'notes');
    setTimeout(() => (e.id ? b : t.inp).focus(), 30);
    return h('div', { class: 'ph-app-v' }, header(e.id ? 'Modifier la note' : 'Nouvelle note', () => nav('notes'), e.id ? h('button', { class: 'ph-bk', type: 'button', title: 'Supprimer', onclick: () => act('note_del', { id: e.id }, 'notes') }, ico('trash')) : null),
      h('div', { class: 'ph-form' }, t.el, h('label', { class: 'ph-f' }, h('span', null, 'Texte'), b), btn('Enregistrer', go, 'pri', 'check')));
  };

  R.settings = () => {
    const d = st.data || {};
    if (d.walls) st.wallsCache = { list: d.walls, cur: d.wall };
    const sw = (on, name) => h('i', { class: 'ph-sw' + (on ? ' on' : ''), onclick: (e) => { e.stopPropagation(); act(name, { on: !on }, 'settings'); } });
    const cell = (iconId, label, right, onclick) => h('div', { class: 'ph-cell' + (onclick ? ' tap' : ''), onclick }, appIcon(iconId, 29), h('b', null, label), right || null);
    const chev = () => h('i', { class: 'ph-chv2' }, '›');
    const wp = h('span', { class: 'ph-wthumb', style: { background: d.wall === 'banner' ? bannerBg() : wallBg(d.wall || 'copper') } });
    return h('div', { class: 'ph-app-v scroll set' }, header('Réglages', () => nav('home')),
      h('div', { class: 'ph-grp2' }, h('div', { class: 'ph-me' }, h('span', { class: 'ph-av big2', style: { '--hu': hue(d.name || '') } }, initials(d.name)), h('div', null, h('b', null, d.name || ''), h('small', null, 'Numéro ' + (d.number || '') + (d.iban ? ' · ' + d.iban : ''))))),
      h('div', { class: 'ph-grp2' },
        cell('airdrop', 'AirDrop', h('span', { class: 'ph-cr' }, h('em', null, d.airdrop === false ? 'Désactivé' : 'Tout le monde'), sw(d.airdrop !== false, 'set_airdrop'))),
        cell('settings', "Fond d'écran", h('span', { class: 'ph-cr' }, wp, chev()), () => nav('walls')),
        cell('contacts', 'Face ID et code', h('span', { class: 'ph-cr' }, h('em', null, d.haslock ? (d.faceid ? 'Face ID' : 'Code') : 'Désactivé'), chev()), () => { st.secData = { haslock: d.haslock, faceid: d.faceid }; nav('security'); })),
      h('div', { class: 'ph-grp2' },
        cell('services', 'Ne pas déranger', sw(d.dnd, 'set_dnd')),
        cell('messages', 'Sons', sw(d.sound, 'set_sound'))),
      h('p', { class: 'ph-note' }, 'AirDrop : les personnes à côté de toi peuvent t\'envoyer leur fiche contact ; tu acceptes ou refuses.'),
      h('div', { class: 'ph-grp2' }, h('div', { class: 'ph-cell tap danger', onclick: () => opts.close() }, h('b', null, 'Fermer le téléphone'))));
  };
  // Fonds d'écran : galerie (le « + » reprend la bannière du serveur)
  R.walls = () => {
    const c = st.wallsCache || { list: WALL_IDS.concat(['banner']), cur: (st.info && st.info.wall) || 'copper' };
    const cur = WALL_OLD[c.cur] || c.cur;
    const pick = (w) => { if (st.info) st.info.wall = w; c.cur = w; wall(); act('set_wall', { wall: w }, 'settings'); };
    const tiles = [];
    if (c.list.indexOf('banner') >= 0) tiles.push(h('button', { type: 'button', class: 'ph-wtile plus' + (cur === 'banner' ? ' on' : ''), title: 'Bannière du serveur', onclick: () => pick('banner') }, h('i', null, '+')));
    c.list.filter((w) => w !== 'banner').forEach((w) => tiles.push(h('button', { type: 'button', class: 'ph-wtile' + (cur === w ? ' on' : ''), style: { background: wallBg(w) }, onclick: () => pick(w) })));
    return h('div', { class: 'ph-app-v scroll wallsv' }, header("Fonds d'écran", () => nav('settings'), null, "Fond d'écran"), h('div', { class: 'ph-wgrid' }, tiles));
  };
  // AirDrop : envoyer sa fiche (ou un contact) à quelqu'un à côté
  R.airdrop = () => {
    const d = st.data || {}, near = d.near || [], list = d.contacts || [];
    const what = st.dropWhat || 'me';
    const sel = h('select', { class: 'ph-in', onchange: (e) => { st.dropWhat = e.target.value; } }, [h('option', { value: 'me' }, 'Ma fiche (' + (d.me || '') + ')')].concat(list.map((c) => h('option', { value: String(c.id) }, c.name + ' · ' + c.number))));
    sel.value = what;
    const ring = h('div', { class: 'ph-drop' }, h('span', { class: 'ph-dropi' }, appIcon('airdrop', 64)), h('b', null, 'AirDrop'), h('small', null, near.length ? 'Touche une personne pour lui envoyer la fiche.' : 'Personne à proximité avec AirDrop activé.'));
    const people = h('div', { class: 'ph-people' }, near.map((p) => h('button', { type: 'button', class: 'ph-person', onclick: () => act('airdrop_send', { to: p.id, what: sel.value }, 'airdrop') }, h('span', { class: 'ph-av big', style: { '--hu': hue(p.name) } }, initials(p.name)), h('small', null, p.name))));
    return h('div', { class: 'ph-app-v scroll' }, header('AirDrop', () => nav('contacts'), h('button', { class: 'ph-bk', type: 'button', title: 'Actualiser', onclick: () => nav('airdrop') }, ico('refresh')), 'Contacts'),
      ring, h('div', { class: 'ph-form tight' }, h('label', { class: 'ph-f' }, h('span', null, 'Fiche à envoyer'), sel)), people);
  };
  // Réception AirDrop (téléphone ouvert) : feuille en bas de l'écran
  function dropSheet() {
    const q = st.drop;
    const old = scr.querySelector('.ph-sheet'); if (old) old.remove();
    if (!q) return;
    const close = (ok) => { G.post('phone.airdrop', { ok }); st.drop = null; dropSheet(); };
    scr.appendChild(h('div', { class: 'ph-sheet' }, h('div', { class: 'ph-shc' }, h('span', { class: 'ph-dropi' }, appIcon('airdrop', 44)), h('b', null, 'AirDrop'),
      h('p', null, q.from + ' souhaite partager la fiche contact « ' + q.name + ' » (' + q.number + ').'),
      h('div', { class: 'ph-shb' }, h('button', { type: 'button', onclick: () => close(false) }, 'Refuser'), h('button', { type: 'button', class: 'pri', onclick: () => close(true) }, 'Accepter')))));
  }

  // ---- calculatrice (locale : aucune évaluation de texte, seulement des opérations sur des nombres)
  function calcPress(k) {
    const c = st.calc;
    const fmt = (n) => { if (!isFinite(n)) return 'Erreur'; const t = String(Math.round(n * 1e9) / 1e9); return t.length > 12 ? Number(n).toExponential(5) : t; };
    const op = (l, o, r) => (o === '+' ? l + r : o === '−' ? l - r : o === '×' ? l * r : o === '÷' ? (r === 0 ? NaN : l / r) : r);
    if (c.a === 'Erreur' && k !== 'C') return;
    if (/^\d$/.test(k)) { if (c.fresh || c.a === '0') { c.a = k; c.fresh = false; } else if (c.a.replace(/[-.]/g, '').length < 12) c.a += k; }
    else if (k === ',') { if (c.fresh) { c.a = '0'; c.fresh = false; } if (c.a.indexOf('.') < 0) c.a += '.'; }
    else if (k === 'C') st.calc = { a: '0', left: null, op: null, rep: null, fresh: true };
    else if (k === '⌫') { if (!c.fresh) { c.a = c.a.length > 1 ? c.a.slice(0, -1) : '0'; if (c.a === '-') c.a = '0'; } }
    else if (k === '±') { if (c.a !== '0') c.a = c.a[0] === '-' ? c.a.slice(1) : '-' + c.a; }
    else if (k === '%') { c.a = fmt(Number(c.a) / 100); c.fresh = true; }
    else if (k === '=') { if (c.op && c.left != null) { const r = c.fresh && c.rep != null ? c.rep : Number(c.a); const res = op(c.left, c.op, r); c.rep = r; c.left = res; c.a = fmt(res); c.fresh = true; } }
    else { // + − × ÷
      if (c.op && !c.fresh && c.left != null) { const res = op(c.left, c.op, Number(c.a)); c.left = res; c.a = fmt(res); } else c.left = Number(c.a);
      c.op = k; c.rep = null; c.fresh = true;
    }
    render();
  }
  R.calc = () => {
    const keys = [['C', 'fn'], ['±', 'fn'], ['%', 'fn'], ['÷', 'op'], ['7'], ['8'], ['9'], ['×', 'op'], ['4'], ['5'], ['6'], ['−', 'op'], ['1'], ['2'], ['3'], ['+', 'op'], ['0', 'zero'], [','], ['=', 'op eq']];
    return h('div', { class: 'ph-app-v calc' }, header('Calculatrice', () => nav('home'), h('button', { class: 'ph-bk', type: 'button', title: 'Effacer un chiffre', onclick: () => calcPress('⌫') }, ico('backspace'))),
      h('div', { class: 'ph-disp' }, h('small', null, st.calc.op && st.calc.left != null ? String(Math.round(st.calc.left * 1e9) / 1e9).replace('.', ',') + ' ' + st.calc.op : ''), h('b', null, st.calc.a.replace('.', ','))),
      h('div', { class: 'ph-keys' }, keys.map((k) => h('button', { type: 'button', class: 'ph-k ' + (k[1] || ''), onclick: () => calcPress(k[0]) }, k[0]))));
  };


  // ---- (patch 136) premier démarrage façon iPhone : « Bonjour », code, Face ID, fond d'écran ; puis écran verrouillé à chaque ouverture
  const HELLO = ['Bonjour', 'Hello', 'Hola', 'Ciao', 'Hallo', 'Olá', 'こんにちは', '안녕하세요', 'Привет', 'Merhaba'];
  function keypad(len, onDone, title, sub) {
    let code = '';
    const dots = h('div', { class: 'ph-dots' });
    const draw = () => { G.clear(dots); for (let i = 0; i < len; i++) dots.appendChild(h('i', { class: i < code.length ? 'on' : '' })); };
    const press = (k) => {
      if (k === '⌫') code = code.slice(0, -1);
      else if (code.length < len) code += k;
      draw();
      if (code.length === len) { const c = code; setTimeout(() => { code = ''; draw(); onDone(c); }, 160); }
    };
    draw();
    st.padPress = press;   // le clavier (chiffres, Retour arrière) tape aussi dans le pavé
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'];
    const LET = { 2: 'ABC', 3: 'DEF', 4: 'GHI', 5: 'JKL', 6: 'MNO', 7: 'PQRS', 8: 'TUV', 9: 'WXYZ' };
    return h('div', { class: 'ph-pad' }, h('b', { class: 'ph-padt' }, title), sub ? h('small', { class: 'ph-pads' }, sub) : null, dots,
      h('div', { class: 'ph-padk' }, keys.map((k) => k === '' ? h('i') : h('button', { type: 'button', class: 'ph-pk' + (k === '⌫' ? ' del' : ''), onclick: () => press(k) },
        h('span', null, k), LET[k] ? h('small', null, LET[k]) : null))));
  }
  function faceScan(onDone, label) {
    const ring = h('div', { class: 'ph-face' }, h('i', { class: 'ph-face-g' }), h('i', { class: 'ph-face-t' }));
    const el = h('div', { class: 'ph-faceb' }, ring, h('small', null, label || 'Face ID'));
    setTimeout(() => { ring.classList.add('ok'); el.querySelector('small').textContent = 'Reconnu'; }, 1100);
    setTimeout(onDone, 1700);
    return el;
  }
  R.setup = () => {
    const su = st.su || (st.su = { step: 'hello', code: '', len: 6, faceid: false, wall: (st.info && st.info.wall) || 'copper' });
    const next = (step) => { su.step = step; render(); };
    const top = (t, sub) => h('div', { class: 'ph-sut' }, h('h2', null, t), sub ? h('p', null, sub) : null);
    if (su.step === 'hello') {
      const word = h('h1', { class: 'ph-hello' }, HELLO[0]);
      let i = 0; clearInterval(st.helloT);
      st.helloT = setInterval(() => { if (!word.isConnected) { clearInterval(st.helloT); return; } i = (i + 1) % HELLO.length; word.classList.remove('in'); void word.offsetWidth; word.textContent = HELLO[i]; word.classList.add('in'); }, 1400);
      return h('div', { class: 'ph-su hello' }, word, h('button', { type: 'button', class: 'ph-sub', onclick: () => { clearInterval(st.helloT); next('code'); } }, 'Configurer'),
        h('button', { type: 'button', class: 'ph-link', onclick: () => { clearInterval(st.helloT); su.code = ''; su.faceid = false; next('done'); } }, 'Passer (sans code)'));
    }
    if (su.step === 'code' || su.step === 'code2') {
      return h('div', { class: 'ph-su' },
        keypad(su.len, (c) => {
          if (su.step === 'code') { su.code = c; next('code2'); }
          else if (c === su.code) next('face');
          else { say(false, 'Les codes ne correspondent pas.'); su.code = ''; next('code'); }
        }, su.step === 'code' ? 'Créer un code' : 'Confirmer le code', su.step === 'code' ? 'Il protège ton iPhone.' : 'Tape le même code.'),
        h('div', { class: 'ph-sul' },
          h('button', { type: 'button', class: 'ph-link', onclick: () => { su.len = su.len === 6 ? 4 : 6; su.code = ''; next('code'); } }, su.len === 6 ? 'Code à 4 chiffres' : 'Code à 6 chiffres'),
          h('button', { type: 'button', class: 'ph-link', onclick: () => { su.code = ''; next('wall'); } }, 'Pas de code')));
    }
    if (su.step === 'face') {
      if (su.scanning) return h('div', { class: 'ph-su' }, top('Face ID', 'Regarde ton iPhone…'), faceScan(() => { su.scanning = false; su.faceid = true; next('wall'); }, 'Analyse du visage'));
      return h('div', { class: 'ph-su' }, top('Face ID', 'Déverrouille ton iPhone d\'un regard, sans taper ton code.'),
        h('div', { class: 'ph-faceb idle' }, h('div', { class: 'ph-face' }, h('i', { class: 'ph-face-g' }))),
        h('button', { type: 'button', class: 'ph-sub', onclick: () => { su.scanning = true; render(); } }, 'Configurer Face ID'),
        h('button', { type: 'button', class: 'ph-link', onclick: () => { su.faceid = false; next('wall'); } }, 'Plus tard'));
    }
    if (su.step === 'wall') {
      const tiles = WALL_IDS.map((w) => h('button', { type: 'button', class: 'ph-wtile' + (su.wall === w ? ' on' : ''), style: { background: wallBg(w) }, onclick: () => { su.wall = w; if (st.info) st.info.wall = w; wall(); render(); } }));
      return h('div', { class: 'ph-su' }, top('Fond d\'écran', 'Tu pourras le changer dans Réglages.'), h('div', { class: 'ph-wgrid su' }, tiles),
        h('button', { type: 'button', class: 'ph-sub', onclick: () => next('done') }, 'Continuer'));
    }
    return h('div', { class: 'ph-su hello' }, h('h1', { class: 'ph-hello in' }, 'Bienvenue'), h('p', { class: 'ph-sup' }, 'Ton iPhone est prêt.'),
      h('button', { type: 'button', class: 'ph-sub', onclick: () => {
        if (st.info) { st.info.setup = true; st.info.locked = su.code !== ''; st.info.faceid = su.faceid; st.info.codelen = su.code.length; }
        try { localStorage.setItem('pb_phone_setup_' + ((st.info && st.info.number) || ''), '1'); } catch (e) { /* rien */ }
        st.unlocked = true; st.view = 'home'; render();   // on arrive tout de suite sur l'accueil, sans attendre le serveur
        act('setup_done', { code: su.code, faceid: su.faceid, wall: su.wall }, 'home');
      } }, 'Commencer'));
  };
  R.lock = () => {
    const hh = String(st.clock[0]).padStart(2, '0'), mm = String(st.clock[1]).padStart(2, '0');
    const e = st.env || {}, now = new Date();
    const dname = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'][now.getDay()];
    const date = dname + ' ' + (e.day || now.getDate()) + ' ' + String(MONTHS[e.month != null ? e.month : now.getMonth()] || '').toLowerCase();
    const head = h('div', { class: 'ph-lk' }, h('small', { class: 'ph-lkd' }, date), h('b', { class: 'ph-lkt' }, hh + ':' + mm));
    const unlockOk = () => { act('unlock', { faceid: true }, 'home'); };
    if (st.lockPad) {
      return h('div', { class: 'ph-su lock' }, keypad((st.info && st.info.codelen) || 6, (c) => { act('unlock', { code: c }, 'home'); }, 'Saisis le code'),
        h('div', { class: 'ph-sul' }, h('button', { type: 'button', class: 'ph-link', onclick: () => { st.lockPad = false; render(); } }, 'Annuler')));
    }
    if (st.info && st.info.faceid && !st.faceTried) {
      st.faceTried = true;
      return h('div', { class: 'ph-su lock' }, head, faceScan(unlockOk, 'Face ID'));
    }
    return h('div', { class: 'ph-su lock' }, head, h('div', { class: 'ph-lkb' }, h('i', { class: 'ph-lkic' }, ico('lock')), h('small', null, 'iPhone verrouillé')),
      h('button', { type: 'button', class: 'ph-sub', onclick: () => { st.lockPad = true; render(); } }, 'Saisir le code'),
      st.info && st.info.faceid ? h('button', { type: 'button', class: 'ph-link', onclick: () => { st.faceTried = false; render(); } }, 'Réessayer Face ID') : null);
  };
  // Réglages › Face ID et code
  R.security = () => {
    const d = st.secData || {};
    const sw = (on, fn) => h('i', { class: 'ph-sw' + (on ? ' on' : ''), onclick: (e) => { e.stopPropagation(); fn(!on); } });
    if (st.secPad) {
      const step = st.secPad;
      return h('div', { class: 'ph-su' }, keypad(step.len, (c) => {
        if (step.k === 'old') { st.secPad = { k: 'new', old: c, len: 6 }; render(); }
        else { const old = step.old || ''; st.secPad = null; act('set_code', { old, code: c }, 'settings'); }
      }, step.k === 'old' ? 'Code actuel' : 'Nouveau code'), h('div', { class: 'ph-sul' }, h('button', { type: 'button', class: 'ph-link', onclick: () => { st.secPad = null; render(); } }, 'Annuler')));
    }
    return h('div', { class: 'ph-app-v scroll set' }, header('Face ID et code', () => nav('settings'), null, 'Réglages'),
      h('div', { class: 'ph-grp2' },
        h('div', { class: 'ph-cell' }, appIcon('settings', 29), h('b', null, 'Face ID'), sw(!!d.faceid, (on) => act('set_faceid', { on }, 'settings'))),
        h('div', { class: 'ph-cell tap', onclick: () => { st.secPad = d.haslock ? { k: 'old', len: (st.info && st.info.codelen) || 6 } : { k: 'new', len: 6 }; render(); } }, appIcon('contacts', 29), h('b', null, d.haslock ? 'Modifier le code' : 'Créer un code'), h('i', { class: 'ph-chv2' }, '›'))),
      h('p', { class: 'ph-note' }, 'Le code protège ton téléphone ; Face ID le déverrouille d\'un regard.'));
  };

  // ---- dessin
  function render() {
    G.clear(body);
    drawBar();
    const fn = R[st.view] || R.home;
    let el;
    try { el = fn(); } catch (e) { el = empty('Application indisponible.'); }
    if (st.loading && !st.data && !NOSERVER[st.view]) el = h('div', { class: 'ph-app-v' }, el.firstChild || null, empty('Chargement…'));
    body.appendChild(el);
    home.classList.toggle('dark', st.view !== 'home');
    scr.classList.toggle('in-app', st.view !== 'home');
    dropSheet();
  }
  function start(d) {
    st.info = (d.frame && d.frame.phone) || null;
    if (d.clock) st.clock = d.clock;
    if (d.env) st.env = d.env;
    st.view = 'home';
    st.unlocked = false; st.faceTried = false; st.lockPad = false;
    let doneHere = false;
    try { doneHere = localStorage.getItem('pb_phone_setup_' + ((st.info && st.info.number) || '')) === '1'; } catch (e) { /* rien */ }
    if (st.info && !st.info.setup && !doneHere) { st.view = 'setup'; st.su = null; }
    else if (st.info && st.info.locked) st.view = 'lock';
    else st.unlocked = true;
    wall(); render();
    if (st.view === 'home' && d.page && d.page.data) { st.data = d.page.data; render(); }
  }
  // chronomètre de l'appel : redessine l'écran d'appel chaque seconde, s'arrête quand le téléphone est fermé
  const tick = setInterval(() => { if (!dev.isConnected && st.started) { clearInterval(tick); return; } if (st.view === 'call' && st.call && st.call.state === 'live') render(); }, 1000);
  const start0 = start;
  return { el: dev, padKey: (k) => { if (st.padPress) st.padPress(k); }, start: (d) => { st.started = true; start0(d); }, set, say, onCall, setClock: (hh, mm, env) => { st.clock = [hh, mm]; if (env) st.env = env; if (st.view === 'home') render(); else drawBar(); }, drop: (q) => { st.drop = q; dropSheet(); }, view: () => st.view };
};

// ---- bandeau d'appel (visible même téléphone fermé) et sonnerie (synthétisée : aucun fichier son à charger)
let callNow = null, ringT = null, bandT = null, audio = null;
function tone(freqs, ms, vol) {
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    if (audio.state === 'suspended') audio.resume();
    const t0 = audio.currentTime, g = audio.createGain();
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(vol, t0 + 0.02); g.gain.setValueAtTime(vol, t0 + ms / 1000 - 0.04); g.gain.linearRampToValueAtTime(0, t0 + ms / 1000);
    g.connect(audio.destination);
    freqs.forEach((f) => { const o = audio.createOscillator(); o.type = 'sine'; o.frequency.value = f; o.connect(g); o.start(t0); o.stop(t0 + ms / 1000); });
  } catch (e) { /* pas d'audio : tant pis, le bandeau suffit */ }
}
function ring(kind) {
  clearInterval(ringT); ringT = null;
  if (kind === 'in') { const r = () => { tone([660, 880], 380, 0.18); setTimeout(() => tone([660, 880], 380, 0.18), 520); }; r(); ringT = setInterval(r, 2600); }
  else if (kind === 'out') { const r = () => tone([440, 480], 1500, 0.07); r(); ringT = setInterval(r, 4500); }
}
const band = () => document.getElementById('g-call') || (function () { const e = h('div', { id: 'g-call', class: 'hidden' }); G.root.appendChild(e); return e; })();
function drawBand() {
  const el = band(), c = callNow;
  if (!c) return;
  G.clear(el); el.className = 'st-' + c.state;
  const secs = c.state === 'live' ? c.since + Math.floor((Date.now() - c.t) / 1000) : 0;
  const what = c.state === 'incoming' ? (c.svc ? 'Appel pour ton service' : 'Appel entrant') : c.state === 'outgoing' ? 'Appel en cours…' : c.state === 'live' ? dur(secs) : (c.reason || 'Appel terminé');
  const key = (G.cfg && G.cfg.phone && G.cfg.phone.key) || 'F1';
  el.appendChild(h('span', { class: 'gc-ic' }, ico('call')));
  el.appendChild(h('div', { class: 'gc-t' }, h('b', null, c.label || c.num || 'Appel'), h('small', null, what)));
  if (c.state !== 'ended') el.appendChild(h('div', { class: 'gc-k' }, c.state === 'incoming' ? [h('span', null, h('kbd', null, key), ' répondre'), h('span', null, '/raccrocher')] : [h('span', null, h('kbd', null, key), ' téléphone'), h('span', null, '/raccrocher')]));
}
setInterval(() => { if (callNow && callNow.state === 'live') drawBand(); }, 1000);
G.on('call.state', (d) => {
  clearTimeout(bandT);
  if (d.state === 'ended') {
    ring(null);
    const had = callNow; callNow = null;
    if (cur) cur.onCall(d);
    if (had || d.reason) { callNow = Object.assign({}, had || {}, { state: 'ended', reason: d.reason, t: Date.now() }); drawBand(); callNow = null; bandT = setTimeout(() => band().classList.add('hidden'), 2600); }
    return;
  }
  callNow = Object.assign({}, d, { t: Date.now() });
  ring(d.state === 'incoming' ? (d.sound === false ? null : 'in') : d.state === 'outgoing' ? 'out' : null);
  drawBand();
  if (cur) cur.onCall(callNow);
});

// ---- fenêtre en jeu
let cur = null;
const host = () => document.getElementById('g-phone') || (function () { const e = h('div', { id: 'g-phone', class: 'hidden' }); G.root.appendChild(e); return e; })();
function fit(el) { const k = Math.max(0.45, Math.min(0.95, (window.innerHeight * 0.66) / DH)); el.style.setProperty('--k', k.toFixed(3)); }
// pavé du code au clavier : chiffres (rangée du haut ou pavé numérique) et Retour arrière
window.addEventListener('keydown', (e) => {
  if (!cur || !cur.el.isConnected) return;
  const pad = cur.el.querySelector('.ph-pad');
  if (!pad || !cur.padKey) return;
  if (/^[0-9]$/.test(e.key)) { cur.padKey(e.key); e.preventDefault(); }
  else if (e.key === 'Backspace') { cur.padKey('⌫'); e.preventDefault(); }
});
G.on('phone.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = G.phoneView({ page: (p) => G.post('phone.page', { page: p }), act: (n, pl, p) => G.post('phone.act', { name: n, payload: pl, page: p }), close: () => G.post('phone.close', {}) });
  fit(cur.el); r.appendChild(cur.el); cur.start(d);
  if (callNow) cur.onCall(callNow); else G.post('call.sync', {});
  G.uiStack = G.uiStack.filter((u) => u.id !== 'phone'); G.uiStack.push({ id: 'phone', onEscape: () => G.post('phone.close', {}) });
});
G.on('phone.page', (d) => { if (cur) cur.set(d); });
G.on('phone.result', (d) => { if (!cur) return; cur.set(d); cur.say(d.ok, d.msg); });
G.on('phone.clock', (d) => { if (cur) cur.setClock(Number(d.h) || 0, Number(d.m) || 0, d.env || null); });
G.on('phone.airdrop', (d) => { if (cur && d) cur.drop({ from: String(d.from || ''), name: String(d.name || ''), number: String(d.number || '') }); });
G.on('phone.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'phone'); });
window.addEventListener('resize', () => { if (cur) fit(cur.el); });

// ---- aperçu dans le panel : le vrai téléphone avec des données d'exemple, applications cliquables
G.preview.phone = function (box) {
  G.clear(box);
  const info = { name: 'Camille Durand', number: '555-0123', wall: 'copper', dnd: false, sound: true, cash: 640, bank: 18250, unread: 2, bills: 1, apps: [
    { id: 'calls', label: 'Appels', badge: 1 }, { id: 'messages', label: 'Messages', badge: 2 }, { id: 'contacts', label: 'Contacts', badge: 0 }, { id: 'services', label: 'Annuaire', badge: 0 }, { id: 'bank', label: 'Banque', badge: 0 }, { id: 'bills', label: 'Factures', badge: 1 },
    { id: 'garage', label: 'Garage', badge: 0 }, { id: 'gps', label: 'GPS', badge: 0 }, { id: 'ads', label: 'Annonces', badge: 0 }, { id: 'taxi', label: 'Taxi', badge: 0 }, { id: 'deals', label: 'Contrats', badge: 0 }, { id: 'notes', label: 'Notes', badge: 0 }, { id: 'calc', label: 'Calculatrice', badge: 0 }, { id: 'settings', label: 'Réglages', badge: 0 }] };
  const DATA = {
    taxi: { company: 'Taxi Downtown Cab', driver: false, rates: { base: 50, km: 40, min: 5 }, mine: null },
    ads: { price: 50, hours: 48, cats: [['vente', 'Vente'], ['achat', 'Achat'], ['service', 'Service'], ['emploi', 'Emploi'], ['logement', 'Logement'], ['vehicule', 'Véhicule'], ['divers', 'Divers']], list: [
      { id: 1, cat: 'vehicule', catLabel: 'Véhicule', title: 'Vends Sultan RS, très bon état', body: 'Moteur refait chez Benny\'s, jantes sport. Visible à Legion Square.', price: 42000, name: 'Alex Martin', number: '555-0456', at: '14/10 18:20' },
      { id: 2, cat: 'emploi', catLabel: 'Emploi', title: 'Le Burger Shot recrute', body: 'Cuisiniers et livreurs, horaires souples.', price: 0, name: 'Léa Roche', number: '555-0789', at: '14/10 16:02' },
      { id: 3, cat: 'service', catLabel: 'Service', title: 'Dépannage 24 h / 24', body: '', price: 300, name: 'Camille Durand', number: '555-0123', at: '13/10 22:41', mine: true }] },
    home: { info },
    calls: { voice: true, contacts: [{ name: 'Alex Martin', number: '555-0456' }, { name: 'Léa Roche', number: '555-0789' }], recent: [
      { num: '555-0456', label: 'Alex Martin', out: false, missed: true, status: 'missed', secs: 0, at: '14/10 18:10' },
      { num: 'svc:police', label: 'Police', out: true, missed: false, status: 'done', secs: 74, at: '14/10 17:41', svc: true },
      { num: '555-0789', label: 'Léa Roche', out: true, missed: false, status: 'done', secs: 312, at: '13/10 21:05' }] },
    messages: { threads: [{ num: '555-0456', label: 'Alex', last: 'On se retrouve au garage ?', mine: false, at: '14/10 18:02', unread: 2 }, { num: 'svc:police', label: 'Police', last: 'Cambriolage rue Alta', mine: true, at: '14/10 17:40', unread: 0, svc: true }] },
    contacts: { me: '555-0123', list: [{ id: 1, name: 'Alex Martin', number: '555-0456' }, { id: 2, name: 'Léa Roche', number: '555-0789' }] },
    airdrop: { me: '555-0123', near: [{ id: 4, name: 'Alex Martin' }, { id: 7, name: 'Léa Roche' }], contacts: [{ id: 1, name: 'Alex Martin', number: '555-0456' }] },
    services: { list: [{ id: 'police', name: 'Police', duty: 3 }, { id: 'ems', name: 'Ambulanciers', duty: 0 }, { id: 'mecano', name: 'Garage Central', duty: 1 }] },
    bank: { bank: 18250, cash: 640, iban: 'PB00123456', min: 1, max: 250000, fee: 1, contacts: [{ name: 'Alex', number: '555-0456' }], tx: [{ label: 'Salaire', amount: 450, plus: true, note: '', at: '14/10 12:00' }, { label: 'Virement émis', amount: 120, plus: false, note: 'loyer', at: '13/10 20:11' }] },
    bills: { bank: 18250, list: [{ id: 1, from: 'Garage Central', reason: 'Réparation', amount: 300, fine: false, status: 'pending', at: '14/10' }, { id: 2, from: 'Police', reason: 'Excès de vitesse', amount: 150, fine: true, status: 'paid', at: '12/10' }] },
    garage: { list: [{ plate: 'AB123CD', label: 'Sultan', state: 'out', garage: '' }, { plate: 'ZX987YT', label: 'Panto', state: 'garage', garage: 'Garage Legion' }] },
    gps: { places: [{ id: 1, label: 'Hôpital Pillbox' }, { id: 2, label: 'Commissariat de Mission Row' }, { id: 3, label: 'Legion Square' }] },
    notes: { list: [{ id: 1, title: 'Courses', body: 'Pain\nLait', at: '14/10 09:00' }] },
    settings: { wall: 'copper', walls: ['copper', 'silver', 'midnight', 'graphite', 'blue', 'mint', 'green', 'amber', 'violet', 'banner'], airdrop: true, dnd: false, sound: true, number: '555-0123', name: 'Camille Durand', iban: 'PB00123456' },
    thread: { num: '555-0456', label: 'Alex', svc: false, canAdd: false, maxlen: 240, msgs: [{ id: 1, mine: false, body: 'On se retrouve au garage ?', at: '14/10 18:02' }, { id: 2, mine: true, body: 'Oui, dans dix minutes.', at: '14/10 18:03' }] },
  };
  const ph = G.phoneView({ page: (p) => { setTimeout(() => ph.set({ frame: { phone: info }, page: { page: p, data: DATA[p] || {} } }), 30); }, act: (n, pl, pg) => { setTimeout(() => {
    if (n === 'call') {   // aperçu : un faux appel qui décroche au bout de 2 s
      const lbl = { '555-0456': 'Alex Martin', '555-0789': 'Léa Roche', 'svc:police': 'Police' }[pl.num] || pl.num;
      ph.onCall({ state: 'outgoing', id: 1, label: lbl, num: pl.num, svc: String(pl.num).startsWith('svc:'), since: 0, t: Date.now() });
      setTimeout(() => ph.onCall({ state: 'live', id: 1, label: lbl, num: pl.num, svc: String(pl.num).startsWith('svc:'), since: 0, t: Date.now() }), 2000);
      return;
    }
    ph.say(true, 'Aperçu : action « ' + n + ' » non exécutée.');
    if (n === 'open_thread') ph.set({ frame: { phone: info }, page: { page: 'thread', data: DATA.thread } }); }, 30); }, close: () => {},
    callAct: (n) => (n === 'speaker' ? ph.onCall({ state: 'live', id: 1, label: 'Alex Martin', num: '555-0456', since: 12, speaker: !ph.spk, t: Date.now() }, (ph.spk = !ph.spk)) : ph.onCall({ state: 'ended', reason: 'Aperçu : appel terminé.' })) });
  const scene = h('div', { class: 'gph-prev' }, h('div', { class: 'gph-win' }, ph.el));
  box.appendChild(G.fitStage(scene, 1240, 820));
  ph.start({ frame: { phone: info }, clock: [21, 37], page: { page: 'home', data: DATA.home } });
};
})();
