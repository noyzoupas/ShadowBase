/* Territoires : scores par gang en bas à droite pendant une guerre. Le texte « Territoire / Zone en guerre » est dessiné par le client Lua (natives du jeu). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
function buildScore(rows, target) {
  const sc = h('div', { id: 'g-tscore' });
  target = Math.max(1, Number(target) || 100);
  rows.slice(0, 8).forEach((r) => {
    const col = /^#[0-9a-fA-F]{6}$/.test(r.color || '') ? r.color : '#e5384f';
    const fill = h('i', { style: { width: Math.min(100, (Number(r.pts) || 0) / target * 100) + '%', background: col } });
    sc.appendChild(h('div', { class: 'ts-row' }, h('span', null, String(r.label || '').slice(0, 24) + ' (' + (Number(r.pts) || 0) + ')'), h('div', { class: 'ts-bar' }, fill)));
  });
  return sc;
}
let sc = null;
G.on('terr.score', (d) => {
  const rows = (d && d.rows) || [];
  if (sc) { sc.remove(); sc = null; }
  if (!rows.length) return;
  sc = buildScore(rows, d.target);
  G.root.appendChild(sc);
});

// Aperçu du panel : le texte tel qu'il est dessiné en bas de l'écran, hors guerre puis en guerre avec les scores
G.preview.territory = function (box) {
  G.clear(box);
  const wrap = h('div', { style: { display: 'grid', gap: '14px', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))' } });
  const mk = (label, war) => {
    const stage = h('div', { class: 'gstage pv-terr' });
    stage.appendChild(h('div', { class: 'pv-txt' },
      h('b', { class: war ? 'war' : '' }, war ? 'ZONE EN GUERRE  ·  Grove Street  ·  10:40' : 'TERRITOIRE  ·  Grove Street'),
      h('span', { style: war ? '' : 'color:#a64dff' }, war ? 'Tirs autorisés  ·  pas de secours  ·  tiens les points de contrôle' : 'Territoire de Ballas  ·  tirs interdits')));
    if (war) stage.appendChild(buildScore([{ label: 'Ballas', color: '#a64dff', pts: 62 }, { label: 'Families', color: '#2fbf4a', pts: 41 }, { label: 'Vagos', color: '#f2c200', pts: 17 }], 100));
    stage.appendChild(h('div', { class: 'pv-cap' }, label));
    return stage;
  };
  wrap.appendChild(mk('Hors guerre : texte en bas de l\'écran', false));
  wrap.appendChild(mk('Guerre en cours : texte + scores en bas à droite', true));
  box.appendChild(wrap);
};
})();
