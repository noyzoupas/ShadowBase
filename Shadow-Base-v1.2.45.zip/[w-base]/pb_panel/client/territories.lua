-- Territoires : invite E dans une zone, couleur de la zone sur la carte, ré-utilise la barre de progression des activités.
local G = PBG
local zones, owners, me, blips = {}, {}, nil, {}
local polys = {}   -- contours dessinés au Builder : { [id] = { {x, y}, … } }
local active = false
local exempt = false
local peace = true   -- réglage « tirs interdits » envoyé par le serveur
local battle      -- bataille de zone en cours (envoyée par le serveur) : points de contrôle à dessiner + tableau des scores
-- point dans un polygone (contour de la zone) ; sinon cercle
local function inPoly(x, y, poly)
    local inside, j = false, #poly
    for i = 1, #poly do
        local xi, yi, xj, yj = poly[i][1], poly[i][2], poly[j][1], poly[j][2]
        if ((yi > y) ~= (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1e-9) + xi) then inside = not inside end
        j = i
    end
    return inside
end
G.InPoly = inPoly
local function inZoneXY(z, x, y)
    local p = polys[z.id]
    if p and #p >= 3 then return inPoly(x, y, p) end
    local dx, dy = x - (z.x + 0.0), y - (z.y + 0.0)
    return math.sqrt(dx * dx + dy * dy) <= (tonumber(z.radius) or 30) + 0.0
end
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local t = c.territories or {}
    polys = type(t.polys) == 'table' and t.polys or {}
    zones = t.enabled == false and {} or (t.zones or {})
    G.terrBlips = t.show_blips ~= false
    G.redrawTerr()
end
-- Couleurs de blip du jeu (approximations RGB) : la carte du jeu ne sait afficher que cette palette, on prend la plus proche de la couleur du gang.
local PALETTE = {
    { 1, 224, 50, 50 }, { 2, 114, 204, 114 }, { 3, 93, 182, 229 }, { 5, 238, 198, 80 }, { 7, 156, 110, 175 }, { 8, 255, 123, 196 }, { 17, 234, 143, 53 },
    { 25, 59, 150, 60 }, { 29, 37, 102, 159 }, { 38, 36, 98, 165 }, { 40, 77, 77, 77 }, { 4, 240, 240, 240 }, { 39, 170, 170, 170 }, { 43, 140, 230, 200 }, { 46, 238, 220, 120 }, { 49, 155, 40, 40 }, { 54, 20, 120, 120 },
}
function G.blipColourFor(hex)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 4 end
    r, g, b = tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
    local best, bd = 4, 1e9
    for _, p in ipairs(PALETTE) do
        local d = (p[2] - r) ^ 2 + (p[3] - g) ^ 2 + (p[4] - b) ^ 2
        if d < bd then best, bd = p[1], d end
    end
    return best
end
-- zones pour la carte du serveur (client/atlas.lua) : visibles seulement par les membres d'un groupe illégal, comme sur la carte du jeu
function G.terrZoneList()
    if not me or me == '' or not G.terrBlips then return {} end
    local out = {}
    for _, z in ipairs(zones) do
        local o = owners[z.id]
        out[#out + 1] = { x = z.x, y = z.y, r = tonumber(z.radius) or 30, label = z.label, color = o and o.color or '#dfe2e7', owner = o and o.label or nil }
    end
    return out
end
-- carte du serveur : montrer / cacher les zones et leurs repères
function G.terrShow(on)
    for i, b in ipairs(blips) do if DoesBlipExist(b) then SetBlipDisplay(b, on and (i % 2 == 1 and 8 or 2) or 0) end end
end
function G.redrawTerr()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not G.terrBlips then return end
    if not me or me == '' then return end   -- territoires visibles seulement par les membres d'un groupe illégal
    for _, z in ipairs(zones) do
        local o = owners[z.id]
        local colour = o and G.blipColourFor(o.color) or 4
        local b = AddBlipForRadius(z.x + 0.0, z.y + 0.0, z.z + 0.0, (tonumber(z.radius) or 30) + 0.0)
        SetBlipColour(b, colour) SetBlipAlpha(b, o and 110 or 40)
        blips[#blips + 1] = b
        -- petit repère au centre avec le nom de la zone et du gang qui la tient (visible sur la carte du jeu)
        local c = AddBlipForCoord(z.x + 0.0, z.y + 0.0, z.z + 0.0)
        SetBlipSprite(c, 84) SetBlipColour(c, colour) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(z.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
        blips[#blips + 1] = c
    end
end
RegisterNetEvent('pb:g:terr:owners', function(j) local d = G.decode(j) if d then owners = d.owners or {} me = d.me peace = d.peace ~= false exempt = d.exempt == true G.redrawTerr() if G.terrRefresh then G.terrRefresh() end end end)
-- cercle très fin autour de chaque zone proche (couleur du gang qui la tient, gris si libre)
CreateThread(function()
    while true do
        if not G.begun or #zones == 0 then Wait(1000) else
            local c = GetEntityCoords(PlayerPedId())
            local any = false
            for _, z in ipairs(zones) do
                local zx, zy, zz = z.x + 0.0, z.y + 0.0, z.z + 0.0
                local rr = (tonumber(z.radius) or 30) + 0.0
                if #(c - vector3(zx, zy, zz)) < rr + 120.0 then
                    any = true
                    local o = owners[z.id]
                    local r, g, b = 200, 204, 212
                    local hex = o and (o.color or '')
                    if type(hex) == 'string' then local rr2, gg, bb = hex:match('^#(%x%x)(%x%x)(%x%x)$') if rr2 then r, g, b = tonumber(rr2, 16), tonumber(gg, 16), tonumber(bb, 16) end end
                    local p = polys[z.id]
                    if p and #p >= 3 then
                        -- contour dessiné : un trait au sol entre chaque coin (hauteur du sol calculée une fois par coin)
                        p.gz = p.gz or {}
                        for i = 1, #p do
                            local a, bb = p[i], p[i % #p + 1]
                            if not p.gz[i] then p.gz[i] = G.Ground(a[1] + 0.0, a[2] + 0.0, c.z) + 0.15 end
                            local j = i % #p + 1
                            if not p.gz[j] then p.gz[j] = G.Ground(bb[1] + 0.0, bb[2] + 0.0, c.z) + 0.15 end
                            DrawLine(a[1] + 0.0, a[2] + 0.0, p.gz[i], bb[1] + 0.0, bb[2] + 0.0, p.gz[j], r, g, b, 200)
                            DrawLine(a[1] + 0.0, a[2] + 0.0, p.gz[i] + 1.2, bb[1] + 0.0, bb[2] + 0.0, p.gz[j] + 1.2, r, g, b, 90)
                        end
                    else
                        G.Zone(zx, zy, zz - 0.95, r, g, b, rr)
                    end
                end
            end
            Wait(any and 0 or 500)
        end
    end
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #zones == 0 or not me or active or G.Menu.IsOpen() then hide() Wait(700)
        else
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if inZoneXY(z, c.x, c.y) then hit = z break end end
            local o = hit and owners[hit.id]
            if hit and (not o or o.gang ~= me) then
                local txt = battle and battle.zone == hit.label and ('Bataille : ' .. hit.label) or ('Attaquer : ' .. hit.label)
                if shown ~= txt then shown = txt G.send('prompt', { show = true, key = 'E', text = txt }) end
                if IsControlJustPressed(0, 38) and not (battle and battle.zone == hit.label) then hide() TriggerServerEvent('pb:g:terr:start', hit.id) end
                Wait(0)
            else hide() Wait(400) end
        end
    end
end)

-- Territoires : petit bandeau (comme le braquage) tant qu'on est dans la zone, annonce à l'entrée, scores en bas à droite pendant une guerre,
-- tirs interdits dans une zone possédée hors guerre (sauf pour le gang propriétaire).
local cur, recvAt = nil, 0
local lastAnn = {}
local function warHere(z) return battle and battle.zid == z.id end
local info = nil   -- texte affiché en bas de l'écran tant qu'on est dans la zone
local function refreshHere()
    if not cur then info = nil return end
    local o = owners[cur.id]
    local war = warHere(cur)
    info = { zone = cur.label, war = war, owner = o and o.label or nil, color = o and o.color or nil, mine = o ~= nil and o.gang == me, peace = peace and not exempt and o ~= nil and not war }
    G.send('terr.score', { rows = war and battle.rows or {}, target = war and battle.target or nil })
end
G.terrRefresh = refreshHere
CreateThread(function()
    while true do
        Wait(500)
        if G.begun and #zones > 0 then
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if inZoneXY(z, c.x, c.y) then hit = z break end end
            local id, old = hit and hit.id or nil, cur and cur.id or nil
            if id ~= old then
                cur = hit
                refreshHere()
                if not hit then G.send('terr.score', { rows = {} }) end
            end
        else Wait(1000) end
    end
end)
-- texte propre en bas de l'écran (natives du jeu, aucune interface) : territoire, ou zone en guerre avec le temps restant
local function drawLine(text, y, scale, r, g, b, font)
    SetTextFont(font or 4) SetTextScale(0.0, scale) SetTextColour(r, g, b, 235) SetTextCentre(true)
    SetTextDropShadow(2, 0, 0, 0, 220) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.5, y)
end
local function rgbOf(hex, d)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return d[1], d[2], d[3] end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
CreateThread(function()
    while true do
        if not info or not G.begun or G.Menu.IsOpen() then Wait(300) else
            Wait(0)
            local y = 0.885
            if info.war then
                local left = math.max(0, (tonumber(battle and battle.left) or 0) - (GetGameTimer() - recvAt) / 1000)
                drawLine(('ZONE EN GUERRE  ·  %s  ·  %d:%02d'):format(info.zone, math.floor(left / 60), math.floor(left % 60)), y, 0.62, 255, 92, 108)
                drawLine('Tirs autorisés  ·  pas de secours  ·  tiens les points de contrôle', y + 0.038, 0.38, 235, 235, 240)
            else
                local r, g, b = rgbOf(info.color, { 223, 226, 231 })
                drawLine(('TERRITOIRE  ·  %s'):format(info.zone), y, 0.6, 255, 255, 255)
                if info.owner then
                    drawLine((info.mine and 'Territoire de ton gang  ·  toi seul peux tirer ici' or ('Territoire de %s%s'):format(info.owner, info.peace and '  ·  tirs interdits' or '')), y + 0.038, 0.38, r, g, b)
                else drawLine('Territoire libre', y + 0.038, 0.38, 200, 204, 212) end
            end
        end
    end
end)
-- tirs interdits : zone possédée, pas de guerre ici, et on n'est pas du gang propriétaire
CreateThread(function()
    while true do
        local o = cur and owners[cur.id]
        if peace and not exempt and o and not warHere(cur) and o.gang ~= me and G.begun then
            Wait(0)
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true) DisableControlAction(0, 257, true) DisableControlAction(0, 69, true) DisableControlAction(0, 70, true)
            DisableControlAction(0, 92, true) DisableControlAction(0, 114, true) DisableControlAction(0, 331, true)
        else Wait(300) end
    end
end)

RegisterNetEvent('pb:g:zone:banner', function(j) local d = G.decode(j) if d then G.send('zone.banner', d) end end)

-- Builder › Créer › Territoire de gang : on marche jusqu'à chaque coin et on appuie sur Entrée ; la zone se dessine au fur et à mesure.
-- Retour arrière : retirer le dernier coin · E : terminer (3 coins minimum) · X : annuler. Ensuite : nom et objet offert toutes les 5 h.
local drawing = false
function G.TerrDraw(send, rewards)
    if drawing then return end
    drawing = true
    G.Menu.Suspend()
    local pts = {}
    local function help()
        G.send('prompt', { show = true, free = true, key = '↵', text = ('Coin %d : Entrée pour l\'ajouter ici  ·  Retour arrière : retirer  ·  E : terminer (3 coins min.)  ·  X : annuler'):format(#pts + 1) })
    end
    help()
    CreateThread(function()
        local finished = false
        while drawing do
            Wait(0)
            DisableControlAction(0, 200, true) DisableControlAction(0, 199, true)
            local c = GetEntityCoords(PlayerPedId())
            -- traits déjà posés, puis le trait vers le joueur (et le retour au premier coin)
            for i = 1, #pts - 1 do DrawLine(pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z, 255, 255, 255, 230) end
            for _, q in ipairs(pts) do DrawMarker(28, q.x, q.y, q.z, 0, 0, 0, 0, 0, 0, 0.35, 0.35, 0.35, 255, 255, 255, 200, false, false, 2, false, nil, nil, false) end
            local gz = c.z - 0.9
            if #pts > 0 then
                local l = pts[#pts]
                DrawLine(l.x, l.y, l.z, c.x, c.y, gz, 255, 255, 255, 140)
                if #pts >= 2 then DrawLine(c.x, c.y, gz, pts[1].x, pts[1].y, pts[1].z, 255, 255, 255, 70) end
            end
            if IsDisabledControlJustPressed(0, 191) or IsControlJustPressed(0, 191) then
                pts[#pts + 1] = { x = c.x, y = c.y, z = gz }
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if #pts >= 40 then finished = true drawing = false end
                help()
            elseif IsDisabledControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                if #pts > 0 then table.remove(pts) help() end
            elseif IsControlJustPressed(0, 38) then
                if #pts >= 3 then finished = true drawing = false
                else G.send('notify', { type = 'warn', title = 'Territoire', text = 'Pose au moins 3 coins.' }) end
            elseif IsControlJustPressed(0, 73) then
                drawing = false
            end
        end
        G.send('prompt', { show = false })
        if not finished then G.Menu.Resume() return end
        -- fin du tracé : nom de la zone et objet offert au groupe qui la tient (toutes les 5 h)
        local st = { name = '', item = 1 }
        local list, keys = { 'Aucun objet' }, { '' }
        for _, r in ipairs(rewards or {}) do list[#list + 1] = r[2] keys[#keys + 1] = r[1] end
        G.Menu.Resume()
        G.Menu.Open({ id = 'b.terr.new', title = 'Nouveau territoire', subtitle = #pts .. ' coins', items = {
            { type = 'input', label = 'Nom de la zone', icon = 'pen', prompt = 'Nom de la zone (ex. Grove Street)', maxlen = 40, onChange = function(_, v) st.name = tostring(v or '') end },
            { type = 'list', label = 'Objet offert toutes les 5 h', icon = 'box', list = list, index = 1, description = "Déposé dans le coffre du groupe qui tient la zone.", onChange = function(_, _, i) st.item = i end },
            { type = 'button', label = 'Créer la zone', icon = 'check', onSelect = function()
                if #st.name < 2 then G.send('notify', { type = 'warn', title = 'Territoire', text = 'Donne un nom à la zone.' }) return end
                local poly = {}
                for _, q in ipairs(pts) do poly[#poly + 1] = { x = q.x, y = q.y, z = q.z } end
                G.Menu.Close()
                send('b_terr', { label = st.name, poly = poly, item = keys[st.item] or '' })
            end },
            { type = 'button', label = 'Annuler', icon = 'x', onSelect = function() G.Menu.Close() end },
        } })
    end)
end

-- Bataille de zone : tableau des scores (même carte que les guerres) + colonnes lumineuses sur chaque point de contrôle
local batBlip
RegisterNetEvent('pb:g:terr:bat', function(j)
    local d = G.decode(j) or {}
    if batBlip and DoesBlipExist(batBlip) then RemoveBlip(batBlip) end
    batBlip = nil
    battle = d.on and d or nil
    if battle then recvAt = GetGameTimer() end
    if G.terrRefresh then G.terrRefresh() end
    if d.on then
        batBlip = AddBlipForRadius(d.x + 0.0, d.y + 0.0, 0.0, (d.r or 30) + 5.0)
        SetBlipColour(batBlip, 1) SetBlipAlpha(batBlip, 110) SetBlipFlashes(batBlip, true)
    end
end)
local function rgb(hex, d)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return d[1], d[2], d[3] end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
CreateThread(function()
    while true do
        if not battle or not battle.cps then Wait(800) else
            local pc = GetEntityCoords(PlayerPedId())
            local any = false
            for _, cp in ipairs(battle.cps) do
                local x, y = cp.x + 0.0, cp.y + 0.0
                if #(pc - vector3(x, y, pc.z)) < 150.0 then
                    any = true
                    local gz = G.Ground and G.Ground(x, y, pc.z) or (cp.z + 0.0)
                    local r, g, b = rgb(cp.color, { 220, 224, 232 })
                    DrawMarker(1, x, y, gz - 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 12.0, 12.0, 1.2, r, g, b, 90, false, false, 2, false, nil, nil, false)
                    -- anneau de progression d'un gang qui prend le point : colonne plus haute et de la couleur de l'attaquant
                    if cp.by and (cp.p or 0) > 0 then
                        local r2, g2, b2 = rgb(cp.by, { 255, 255, 255 })
                        DrawMarker(1, x, y, gz - 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 12.0 * cp.p, 12.0 * cp.p, 6.0, r2, g2, b2, 140, false, false, 2, false, nil, nil, false)
                    end
                end
            end
            Wait(any and 0 or 500)
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and batBlip and DoesBlipExist(batBlip) then RemoveBlip(batBlip) end end)
