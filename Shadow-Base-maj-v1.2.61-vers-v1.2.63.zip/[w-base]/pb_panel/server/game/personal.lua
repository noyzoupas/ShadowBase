-- Menu personnel (touche F5) : soit un menu « RageUI », soit de grandes cartes avec images. Le serveur compose les informations ; le joueur ne peut
-- ouvrir que des fonctions déjà existantes (inventaire, tablette, téléphone). Le choix du mode peut être laissé au joueur (réglage du panel).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Me = {}
G.Personal = Me

P.Register('personal.edit', 'Modifier le menu personnel (F5)', 'personal', true)

local ENTRY_KEYS = { 'inventory', 'tablet', 'wallet', 'company', 'businesses', 'vehicles', 'properties', 'phone', 'vip', 'settings' }
PB.Cfg.Define('personal', {
    enabled = true, key = 'F5', mode = 'cards', allow_choice = true, title = 'Voici votre menu personnel', tint = 'card', image_strength = 55,
    show_inventory = true, show_tablet = true, show_wallet = true, show_company = true, show_vehicles = true, show_properties = true, show_phone = true, show_vip = true, show_settings = true, show_businesses = true,
    custom = {}, order = {},
})
local function cfg(k, d) return PB.Cfg.Get('personal', k, d) end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

-- Définition des cartes : image (web/img/cards/<img>.jpg), teinte propre (utilisée si « Teinte = chaque carte »)
local DEF = {
    inventory  = { label = 'Mon inventaire', icon = 'bag', img = 'inv', tone = '#dfe2e7', cmd = 'pb_inv', desc = 'Ouvre ton sac : objets, poids et raccourcis.' },
    tablet     = { label = 'Mon espace', icon = 'briefcase', img = 'sky', tone = '#6fb4ff', cmd = 'pb_tablet', desc = 'Finances, factures et tableau de bord de ton entreprise.' },
    wallet     = { label = 'Mon portefeuille', icon = 'wallet', img = 'wallet', tone = '#7be0a4', cmd = 'pb_tablet', desc = 'Espèces, compte en banque et factures à régler.' },
    company    = { label = 'Mon entreprise', icon = 'building', img = 'city', tone = '#ffb457', cmd = 'pb_tablet', desc = 'Ton poste, ton grade et ton service.' },
    vehicles   = { label = 'Mes véhicules', icon = 'engine', img = 'veh', tone = '#ff6b7d', desc = 'Tes véhicules : emplacement, poids et contenu du coffre (lecture seule). Ils se sortent dans un garage.' },
    businesses = { label = 'Entreprises de la ville', icon = 'building', img = 'city', tone = '#7be0a4', desc = 'Ouvertes ou fermées en ce moment, et le GPS de chacune.' },
    properties = { label = 'Mes propriétés', icon = 'home', img = 'sea', tone = '#5fd0d0', desc = 'Tes logements, achetés ou loués.' },
    phone      = { label = 'Mon téléphone', icon = 'phone', img = 'sky', tone = '#dfe2e7', cmd = 'pb_phone', desc = 'Messages, contacts et annuaire des services.' },
    vip        = { label = 'Mon VIP', icon = 'star', img = 'city', tone = '#f5c542', desc = 'Ton statut VIP, sa date de fin et tes avantages.' },
    settings   = { label = 'Mes paramètres', icon = 'sliders', img = nil, tone = '#8d939e', desc = "Choisis l'affichage de ce menu." },
}
Me.DEF = DEF

local function stateLabel(s) return s == 'garage' and 'Au garage' or s == 'out' and 'Dehors' or s == 'impound' and 'Fourrière' or tostring(s) end

-- Coffre d'un véhicule (lecture seule depuis F5) : poids, capacité connue (dernière ouverture du coffre) et contenu
local function kg(g) return (('%.1f'):format((tonumber(g) or 0) / 1000):gsub('%.', ',')) end
function Me.Kg(w, max) return kg(w) .. (max and (' / ' .. kg(max)) or '') .. ' kg' end
function Me.TrunkWeight(plate, known)
    local Inv = G.Inv
    local w = known or (Inv and Inv.Weight and Inv.Weight('v:' .. plate)) or 0
    local max = G.VehTrunk and G.VehTrunk.MaxOf and G.VehTrunk.MaxOf(plate) or nil
    return { w = tonumber(w) or 0, max = max }
end
function Me.Vehicle(src, plate)
    local p = G.Get(src)
    if not p or not G.Garage then return nil, 'Véhicule introuvable.' end
    plate = tostring(plate or ''):sub(1, 12)
    local v
    for _, x in ipairs(G.Garage.Owned(p.license) or {}) do if x.plate == plate then v = x end end
    if not v then return nil, 'Ce véhicule ne t\'appartient pas.' end
    local tw = Me.TrunkWeight(v.plate)
    local at = G.Garage.Where and G.Garage.Where(v.plate, src) or nil
    local items = {}
    local Inv = G.Inv
    if Inv and Inv.Contents then
        local slots = {}
        for slot, it in pairs(Inv.Contents('v:' .. v.plate)) do slots[#slots + 1] = { slot = slot, it = it } end
        table.sort(slots, function(a, b) return a.slot < b.slot end)
        for _, r in ipairs(slots) do
            local d = Inv.Def(r.it.item)
            items[#items + 1] = { label = d and d.label or r.it.item, qty = r.it.qty, w = Me.Kg((d and d.weight or 0) * r.it.qty) }
        end
    end
    return { plate = v.plate, label = (v.label ~= '' and v.label or v.model), state = stateLabel(v.state), where = at and at.text or 'Position inconnue', gps = at and at.x and ('v:' .. v.plate) or nil,
        weight = Me.Kg(tw.w, tw.max), pct = tw.max and tw.max > 0 and math.min(100, math.floor(tw.w * 100 / tw.max)) or nil, items = items }
end
-- Coffre d'un de ses véhicules, depuis F5 : l'inventaire s'ouvre en lecture seule (sac à gauche, coffre à droite), où que soit le véhicule
function Me.OpenTrunk(src, plate)
    local d, err = Me.Vehicle(src, plate)
    if not d then return false, err end
    if not (G.Inv and G.Inv.OpenView) then return false, 'Inventaire indisponible.' end
    return G.Inv.OpenView(src, 'v:' .. d.plate, ('Coffre · %s (lecture seule)'):format(d.label)), nil
end
local vehLast = {}
AddEventHandler('playerDropped', function() vehLast[source] = nil end)
RegisterNetEvent('pb:g:me:trunk', function(plate)
    local src = source
    local t = GetGameTimer()
    if vehLast[src] and t - vehLast[src] < 600 then return end
    vehLast[src] = t
    local ok, err = Me.OpenTrunk(src, plate)
    if not ok and err then G.Notify(src, { type = 'warn', title = 'Mes véhicules', text = err }) end
end)
RegisterNetEvent('pb:g:me:veh', function(plate)
    local src = source
    local t = GetGameTimer()
    if vehLast[src] and t - vehLast[src] < 600 then return end
    vehLast[src] = t
    local d, err = Me.Vehicle(src, plate)
    if not d then G.Notify(src, { type = 'warn', title = 'Mes véhicules', text = err }) return end
    TriggerClientEvent('pb:g:me:veh', src, PB.Json(d))
end)


function Me.Data(src)
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) then return nil end
    local id = G.Identity(src) or {}
    local name = ((id.firstname or '') .. ' ' .. (id.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    if name == '' then name = 'Joueur ' .. src end
    local cash, bank = tonumber(p.row.cash) or 0, tonumber(p.row.bank) or 0
    local d = { name = name, id = (G.UidOf(src) or src), cash = cash, bank = bank }
    -- métier
    local job = G.Biz and G.Biz.Job and G.Biz.Job(src)
    d.job = job and { label = job.label, grade = job.gradeLabel, duty = job.onDuty, salary = job.salary, boss = job.boss or nil, mech = job.onDuty and G.Garage and G.Garage.IsMechanic and G.Garage.IsMechanic(src) or nil } or nil
    -- (v1.2.43) second emploi (VIP) : on passe de l'un à l'autre depuis F5 › Mon entreprise
    local pl = G.Get(src)
    local j2 = pl and G.BizCat and G.BizCat.Job2 and G.BizCat.Job2(pl.license)
    d.job2 = j2 and { label = j2.label, grade = j2.gradeLabel, ok = not G.BizCat.Job2Allowed or G.BizCat.Job2Allowed(src) } or nil
    -- véhicules
    local cars = {}
    if G.Garage and G.Garage.Owned then
        local owned, owners = G.Garage.Owned(p.license), {}
        for i, v in ipairs(owned) do owners[i] = 'v:' .. v.plate end
        local weights = G.Inv and G.Inv.WeightsOf and G.Inv.WeightsOf(owners) or {}
        for _, v in ipairs(owned) do
            local w = Me.TrunkWeight(v.plate, weights['v:' .. v.plate])
            local at = G.Garage.Where and G.Garage.Where(v.plate, src, v)
            cars[#cars + 1] = { label = (v.label ~= '' and v.label or v.model), plate = v.plate, state = stateLabel(v.state), gps = 'v:' .. v.plate, veh = v.plate,
                kind = v.plate .. ' · ' .. Me.Kg(w.w, w.max), where = at and at.text or nil }
        end
    end
    d.cars = cars
    -- propriétés
    local props = {}
    if G.Housing and G.Housing.OwnedBy then
        for _, h in ipairs(G.Housing.OwnedBy(p.license)) do props[#props + 1] = { label = h.label, kind = h.kind == 'rent' and 'Location' or 'Propriété', gps = 'p:' .. h.id } end
    end
    d.props = props
    -- messages et factures
    local ph = G.Phone
    d.number = ph and ph.Number and ph.Number(p.license) or nil
    d.unread = ph and ph.Unread and ph.Unread(p.license) or 0
    local inv = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE license = ? AND status = 'pending'", { p.license })
    d.bills, d.billsSum = inv and inv.n or 0, inv and inv.s or 0
    -- VIP (lié au compte)
    local V = G.Vip
    if V and PB.Cfg.Get('vip', 'enabled', true) ~= false then d.vip = { on = V.Is(src) and true or false, ['until'] = V.Until(src) } end
    return d
end

-- Avantages VIP affichés dans la carte « Mon VIP » (cmd = commande lancée côté joueur au clic, si la ressource existe)
local function vipPerks(on)
    local st = on and 'Inclus' or 'VIP'
    local bonus = tonumber(PB.Cfg.Get('vip', 'sell_bonus', 15)) or 0
    local l = {
        { label = ('Jusqu\'à %d personnages'):format(tonumber(PB.Cfg.Get('vip', 'chars', 3)) or 3), kind = 'Au choix à la connexion', state = st },
        { label = 'Meubles et intérieurs de logement', kind = 'Dans ton logement (E)', state = st },
    }
    if GetResourceState('wb_animaux') == 'started' then l[#l + 1] = { label = 'Animal de compagnie', kind = on and 'Ouvrir /animal' or 'Animalerie', state = st, cmd = on and 'animal' or nil } end
    if GetResourceState('wb_peche') == 'started' then l[#l + 1] = { label = 'Canne et leurre VIP', kind = 'Magasin de pêche', state = st } end
    if GetResourceState('wb_chasse') == 'started' then l[#l + 1] = { label = 'Appeau VIP', kind = 'Armurerie de chasse', state = st } end
    if bonus > 0 then l[#l + 1] = { label = ('+%d %% à la revente'):format(bonus), kind = 'Poissons et gibier', state = st } end
    local function vc(k, d) local v = PB.Cfg.Get('vip', k, d) if v == nil then return d end return v end
    if vc('drift', true) ~= false then l[#l + 1] = { label = 'Mode drift', kind = on and 'Activer / couper : /drift (Maj au volant)' or 'Au volant', state = st, cmd = on and 'drift' or nil } end
    if vc('deal_notax', true) ~= false then l[#l + 1] = { label = 'Ventes entre joueurs sans taxe', kind = 'Contrats du téléphone', state = st } end
    if PB.Cfg.Get('rental', 'vip_enabled', true) ~= false then l[#l + 1] = { label = 'Véhicule VIP à Cayo Perico', kind = 'Import, grand coffre, en plus de ta location', state = st } end
    local hm, dm = tonumber(vc('harvest_mult', 3)) or 1, tonumber(vc('drug_mult', 3)) or 1
    if hm > 1 then l[#l + 1] = { label = ('Récoltes ×%d'):format(hm), kind = 'Activités et fermes', state = st } end
    if dm > 1 then l[#l + 1] = { label = ('Drogues ×%d'):format(dm), kind = 'Champs des filières', state = st } end
    local kgp = tonumber(vc('inv_kg', 20)) or 0
    if kgp > 0 then l[#l + 1] = { label = ('+%d kg dans le sac'):format(kgp), kind = 'Inventaire', state = st } end
    if vc('weapons', true) ~= false and G.Vip and G.Vip.WeaponList then
        local names = {}
        for _, w in ipairs(G.Vip.WeaponList()) do names[#names + 1] = w.label end
        if #names > 0 then l[#l + 1] = { label = table.concat(names, ' + '), kind = "Pendant l'abonnement", state = st } end
    end
    local bp = tonumber(vc('bill_pct', 40)) or 0
    if bp > 0 then l[#l + 1] = { label = ('Factures -%d %%'):format(bp), kind = 'LSPD et EMS', state = st } end
    if vc('keep_items', true) ~= false then l[#l + 1] = { label = 'Objets gardés à l\'hôpital', kind = 'Armes et objets', state = st } end
    if vc('report_prio', true) ~= false then l[#l + 1] = { label = 'Reports prioritaires', kind = '/report', state = st } end
    if vc('boombox', true) ~= false then l[#l + 1] = { label = 'Boombox portable', kind = on and 'Dans ton sac : utilise-la pour la prendre en main' or 'Musique partout', state = st } end
    if vc('weapon_tint', true) ~= false then l[#l + 1] = { label = "Teinture d'armes", kind = on and 'Arme en main : or, platine, rose…' or 'Or, platine, rose…', state = st, cmd = on and 'pb_teinture' or nil } end
    if vc('chameleon', true) ~= false then l[#l + 1] = { label = 'Peinture caméléon', kind = on and 'Au volant de ton véhicule' or 'La couleur change selon l\'angle', state = st, cmd = on and 'pb_cameleon' or nil } end
    local tk = tonumber(vc('trunk_kg', 50)) or 0
    if tk > 0 then l[#l + 1] = { label = ('+%d kg dans tes coffres de véhicule'):format(tk), kind = 'Tes véhicules', state = st } end
    local sp = tonumber(vc('shop_pct', 10)) or 0
    if sp > 0 then l[#l + 1] = { label = ('-%d %% en magasin'):format(sp), kind = 'Supérettes, vêtements, coiffeurs, tatoueurs', state = st } end
    local oe = tonumber(vc('outfits_extra', 10)) or 0
    if oe > 0 then l[#l + 1] = { label = ('+%d tenues enregistrées'):format(oe), kind = 'Mes tenues', state = st } end
    if vc('plate_free', true) ~= false then l[#l + 1] = { label = 'Plaque personnalisée gratuite', kind = 'Menu F5', state = st } end
    if (tonumber(vc('queue_prio', 100)) or 0) > 0 then l[#l + 1] = { label = "Priorité dans la file d'attente", kind = 'Serveur plein', state = st } end
    local rp = tonumber(vc('rest_pct', 50)) or 0
    if rp > 0 then l[#l + 1] = { label = ('Repos réduit de %d %%'):format(rp), kind = 'Après une réapparition', state = st } end
    if vc('impound_free', true) ~= false then l[#l + 1] = { label = 'Fourrière gratuite', kind = 'Tes véhicules', state = st } end
    local fp = tonumber(vc('fuel_pct', 20)) or 0
    if fp > 0 then l[#l + 1] = { label = ('Carburant -%d %%'):format(fp), kind = 'Stations-service', state = st } end
    local ge = tonumber(vc('garage_extra', 5)) or 0
    if ge > 0 then l[#l + 1] = { label = ('+%d places de véhicules'):format(ge), kind = 'Garage', state = st } end
    return l
end

local function entryList(d)
    local out = {}
    for _, key in ipairs(ENTRY_KEYS) do
        if cfg('show_' .. key, true) ~= false then
            local def = DEF[key]
            local e = { id = key, label = def.label, desc = def.desc, icon = def.icon, img = def.img, tone = def.tone, cmd = def.cmd }
            if key == 'inventory' then e.value = nil e.sub = 'Sac et raccourcis'
            elseif key == 'tablet' then e.sub = 'Finances et entreprise' e.badge = d.bills > 0 and (d.bills .. ' à régler') or nil
            elseif key == 'wallet' then e.value = money(d.cash + d.bank) e.sub = ('Espèces %s · Banque %s'):format(money(d.cash), money(d.bank)) e.badge = d.bills > 0 and (d.bills .. ' facture' .. (d.bills > 1 and 's' or '')) or nil
            elseif key == 'company' then
                -- information seulement : les actions du métier sont dans le menu de l'entreprise (F6)
                if d.job then e.value = d.job.label e.sub = d.job.grade .. ' · ' .. (d.job.duty and 'En service' or 'Hors service') e.badge = d.job.duty and 'EN SERVICE' or nil
                    e.list = { { label = d.job.label, kind = d.job.grade, state = d.job.duty and 'En service' or 'Hors service' }, { label = "Menu de l'entreprise", kind = 'Touche F6' } }
                    if not d.job.boss then e.list[#e.list + 1] = { label = 'Démissionner', kind = d.job.label .. ' · deux fois pour confirmer', cmd = 'demission' } end
                    e.cmd = nil
                    if d.job2 then
                        e.list[#e.list + 1] = { label = d.job2.label, kind = d.job2.grade, state = 'Second emploi' }
                        e.list[#e.list + 1] = d.job2.ok and { label = 'Passer à : ' .. d.job2.label, kind = 'Changer d\'emploi', cmd = 'jobswap' } or { label = 'Changer d\'emploi', kind = 'Réservé aux VIP' }
                        e.list[#e.list + 1] = { label = 'Quitter le second emploi', kind = d.job2.label .. ' · deux fois pour confirmer', cmd = 'demission2' }
                        e.sub = e.sub .. ' · 2 emplois'
                    end
                elseif d.job2 then
                    e.value = 'Second emploi' e.sub = d.job2.label .. ' · ' .. d.job2.grade
                    e.list = { { label = d.job2.label, kind = d.job2.grade, state = 'Second emploi' }, d.job2.ok and { label = 'Prendre cet emploi', kind = 'Changer d\'emploi', cmd = 'jobswap' } or { label = 'Changer d\'emploi', kind = 'Réservé aux VIP' } }
                    e.cmd = nil
                else e.value = 'Sans emploi' e.sub = 'Aucune entreprise' e.disabled = true end
            elseif key == 'businesses' then
                -- (patch 136) état de chaque entreprise : ouverte (annoncée par un responsable) ou fermée ; Entrée : GPS du siège
                local list, open, hqs = {}, 0, {}
                for _, pt in ipairs(G.Points and G.Points.All and G.Points.All() or {}) do
                    if pt.owner_kind == 'biz' and pt.kind == 'hq' then hqs[tostring(pt.owner)] = true end
                end
                for _, b in ipairs(PB.DB.q('SELECT id, label FROM pb_biz ORDER BY label') or {}) do
                    local on = G.BizMenu and G.BizMenu.IsOpen and G.BizMenu.IsOpen(b.id) and true or false
                    if on then open = open + 1 end
                    local hq = hqs[tostring(b.id)]
                    list[#list + 1] = { label = b.label, state = on and 'Ouvert' or 'Fermé', kind = on and 'Ouvert en ce moment' or 'Fermé', gps = hq and ('b:' .. b.id) or nil }
                end
                table.sort(list, function(a, b) if (a.state == 'Ouvert') ~= (b.state == 'Ouvert') then return a.state == 'Ouvert' end return a.label < b.label end)
                e.value = tostring(open) e.sub = open .. ' ouverte' .. (open > 1 and 's' or '') .. ' sur ' .. #list e.list = list
            elseif key == 'vehicles' then e.value = tostring(#d.cars) e.sub = #d.cars == 0 and 'Aucun véhicule' or (#d.cars > 1 and 'véhicules' or 'véhicule') e.list = d.cars
            elseif key == 'properties' then e.value = tostring(#d.props) e.sub = #d.props == 0 and 'Aucune propriété' or (#d.props > 1 and 'logements' or 'logement') e.list = d.props
            elseif key == 'phone' then e.value = d.number or '—' e.sub = d.unread > 0 and (d.unread .. ' message' .. (d.unread > 1 and 's' or '') .. ' non lu' .. (d.unread > 1 and 's' or '')) or 'Aucun message non lu' e.badge = d.unread > 0 and tostring(d.unread) or nil
            elseif key == 'vip' then
                if not d.vip then e = nil
                else
                    local u = d.vip['until']
                    e.label = 'Mon ' .. clean(PB.Cfg.Get('vip', 'label', 'VIP'), 16)
                    e.value = d.vip.on and 'Actif' or 'Non actif'
                    e.sub = not d.vip.on and 'Demande au staff pour devenir VIP' or (u == 0 or not u) and 'Permanent' or ('Jusqu\'au ' .. os.date('%d/%m/%Y', u))
                    e.badge = d.vip.on and 'VIP' or nil
                    e.list = vipPerks(d.vip.on)
                end
            elseif key == 'settings' then e.sub = 'Affichage du menu' end
            if e then out[#out + 1] = e end
            -- (v1.2.45) peinture caméléon : une entrée à part du menu F5, juste après la carte VIP
            if key == 'vip' and d.vip and d.vip.on and PB.Cfg.Get('vip', 'chameleon', true) ~= false then
                out[#out + 1] = { id = 'cmd', cmd = 'pb_cameleon', label = 'Peinture caméléon', desc = 'Choisis la peinture de ton véhicule, au volant : peintures spéciales, peintures Rockstar ou effet qui suit le regard.',
                    sub = 'Au volant de ton véhicule', icon = 'sparkle', img = def.img, tone = def.tone, badge = 'VIP' }
            end
            if key == 'vip' and d.vip and d.vip.on and PB.Cfg.Get('vip', 'weapon_tint', true) ~= false then
                out[#out + 1] = { id = 'cmd', cmd = 'pb_teinture', label = "Teinture d'arme", desc = "Teins l'arme que tu as en main : or, platine, rose…", sub = 'Arme en main', icon = 'brush', img = def.img, tone = def.tone, badge = 'VIP' }
            end
            if key == 'vip' and d.vip and d.vip.on and PB.Cfg.Get('vip', 'plate_free', true) ~= false then
                out[#out + 1] = { id = 'cmd', cmd = 'pb_vipplate', label = 'Changer de plaque', desc = "Choisis le texte de la plaque d'un de tes véhicules rangés au garage. Gratuit pour les VIP.",
                    sub = 'Gratuit pour les VIP', icon = 'card', img = def.img, tone = def.tone, badge = 'VIP' }
            end
        end
    end
    for _, line in ipairs(cfg('custom', {}) or {}) do
        local l, desc, cmd, badge = tostring(line):match('^([^|]+)|([^|]*)|([%w_:%-]+)|([^|]*)$')
        if l and l ~= '' and cmd then out[#out + 1] = { id = 'cmd', label = clean(l, 40), desc = clean(desc, 140), icon = 'star', img = 'city', tone = '#dfe2e7', cmd = cmd, badge = badge ~= '' and clean(badge, 12) or nil, sub = 'Raccourci' } end
    end
    return out
end
Me.Entries = entryList

-- GPS : repère sur la carte vers un véhicule (dehors : sa vraie position ; au garage / en fourrière : le garage) ou un logement
local function trim(s) return (tostring(s or ''):gsub('^%s+', ''):gsub('%s+$', '')) end
local function vehicleWhere(license, plate)
    local v
    for _, x in ipairs(G.Garage and G.Garage.Owned and G.Garage.Owned(license) or {}) do if x.plate == plate then v = x end end
    if not v then return nil, 'Véhicule introuvable.' end
    local label = v.label ~= '' and v.label or v.model
    if v.state == 'out' then
        for _, veh in ipairs(GetAllVehicles and GetAllVehicles() or {}) do
            if DoesEntityExist(veh) and trim(GetVehicleNumberPlateText(veh)) == trim(plate) then
                local c = GetEntityCoords(veh)
                return { x = c.x, y = c.y, label = label, text = label .. ' : position actuelle.' }
            end
        end
        return nil, label .. " est dehors, mais introuvable (trop loin de tout joueur ou détruit). Il retournera en fourrière s'il a disparu."
    end
    local g
    if v.state == 'impound' then g = DB.one("SELECT label, x, y FROM pb_garages WHERE kind = 'impound' AND enabled = 1 ORDER BY id LIMIT 1")
    elseif (v.garage or '') ~= '' then g = DB.one('SELECT label, x, y FROM pb_garages WHERE id = ?', { v.garage }) end
    if not g then return nil, label .. " : garage inconnu. Il se sort dans n'importe quel garage public." end
    return { x = g.x, y = g.y, label = label, text = label .. ' : ' .. (v.state == 'impound' and 'fourrière' or 'garage') .. ' « ' .. tostring(g.label) .. ' ».' }
end
local function propertyWhere(license, id)
    local h = DB.one('SELECT label, x, y, owner FROM pb_properties WHERE id = ?', { tostring(id) })
    if not h or h.owner ~= license then return nil, 'Logement introuvable.' end
    return { x = h.x, y = h.y, label = h.label, text = h.label .. ' : repère posé sur la porte.' }
end
local gpsLast = {}
RegisterNetEvent('pb:g:me:gps', function(ref)
    local src = source
    local t = GetGameTimer()
    if gpsLast[src] and t - gpsLast[src] < 1000 then return end
    gpsLast[src] = t
    local p = G.Get(src)
    if not p or type(ref) ~= 'string' then return end
    local kind, key = ref:match('^([vpb]):(.+)$')
    if not kind then return end
    local at, err
    if kind == 'b' then
        -- siège d'une entreprise (F5 › Entreprises de la ville)
        for _, pt in ipairs(G.Points and G.Points.Of and G.Points.Of('biz', key:sub(1, 32)) or {}) do if pt.kind == 'hq' then at = { x = pt.x, y = pt.y, text = 'Entreprise sur ta carte.' } end end
        err = "Cette entreprise n'a pas de siège sur la carte."
    elseif kind == 'v' then at, err = vehicleWhere(p.license, key:sub(1, 12)) else at, err = propertyWhere(p.license, key:sub(1, 32)) end
    if not at then G.Notify(src, { type = 'warn', title = 'GPS', text = err }) return end
    TriggerClientEvent('pb:g:me:gps', src, PB.Json({ x = at.x, y = at.y }))
    G.Notify(src, { type = 'success', title = 'GPS', text = at.text })
end)
AddEventHandler('playerDropped', function() gpsLast[source] = nil end)

function Me.Payload(src)
    if not cfg('enabled', true) then return nil, 'Le menu personnel est désactivé.' end
    local d = Me.Data(src)
    if not d then return nil, 'Crée ton personnage pour ouvrir ce menu.' end
    return {
        mode = cfg('mode', 'cards'), allow_choice = cfg('allow_choice', true) ~= false, title = clean(cfg('title', 'Voici votre menu personnel'), 60),
        tint = cfg('tint', 'card'), strength = tonumber(cfg('image_strength', 55)) or 55,
        subtitle = ('Votre ID est : %d'):format(G.UidOf(src) or src), order = cfg('order', {}), name = d.name, id = (G.UidOf(src) or src), cash = d.cash, bank = d.bank, job = d.job, entries = entryList(d),
    }
end

local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
RegisterNetEvent('pb:g:me:open', function()
    local src = source
    local t = GetGameTimer and GetGameTimer() or os.time() * 1000
    if last[src] and t - last[src] < 400 then return end
    last[src] = t
    local p = G.Get(src)
    if not p or PB.ToBool(p.row.dead) or (G.IsCuffed and G.IsCuffed(src)) then TriggerClientEvent('pb:g:me:denied', src) return end
    local data, err = Me.Payload(src)
    if not data then TriggerClientEvent('pb:g:me:denied', src) G.Notify(src, { type = 'warn', title = 'Menu personnel', text = err }) return end
    TriggerClientEvent('pb:g:me:ui', src, PB.Json({ ev = 'open', data = data }))
end)

local look = Form.Cfg({ ns = 'personal', id = 'look', title = 'Menu personnel (F5)', perm = 'personal.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Menu personnel actif', default = true }, { k = 'key', type = 'text', label = "Touche d'ouverture (par défaut)", default = 'F5', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis de FiveM.' },
    { k = 'mode', type = 'select', label = "Affichage du menu F5 (imposé, ou proposé par défaut si les joueurs peuvent choisir)", opts = { { 'cards', 'Grandes cartes (interface)' }, { 'lib', 'Menu RageUI (flèches + Entrée)' } }, default = 'cards' },
    { k = 'allow_choice', type = 'toggle', label = 'Laisser chaque joueur choisir son affichage', default = true, hint = "Désactivé : tout le monde voit l'affichage ci-dessus. Activé : chaque joueur choisit (Mes paramètres, ou boutons en haut des cartes) et son choix est mémorisé." },
    { k = 'order', type = 'list', label = "Ordre des entrées du menu RageUI (identifiants : inventory, tablet, wallet, company, vehicles, properties, phone, vip, settings)", default = {}, maxitems = 12, maxlen = 16, pattern = '^[%w_]+$', wide = true, hint = "Vide = ordre par défaut. Mets « inventory » en dernier pour ouvrir l'inventaire en bas de liste. Chaque joueur peut ensuite réorganiser le menu lui-même." },
    { k = 'title', type = 'text', label = 'Titre', default = 'Voici votre menu personnel', maxlen = 60 },
    { k = 'tint', type = 'select', label = 'Teinte des images', opts = { { 'card', 'Couleur propre à chaque carte' }, { 'server', 'Couleur du serveur partout' } }, default = 'card' },
    { k = 'image_strength', type = 'number', label = "Visibilité de l'image (%)", default = 55, min = 15, max = 90, hint = "Plus c'est haut, plus l'image se voit sous la couleur." },
    { k = 'show_inventory', type = 'toggle', label = 'Carte Inventaire', default = true }, { k = 'show_tablet', type = 'toggle', label = 'Carte Mon espace (ex-tablette)', default = true },
    { k = 'show_wallet', type = 'toggle', label = 'Carte Portefeuille', default = true }, { k = 'show_company', type = 'toggle', label = 'Carte Entreprise', default = true },
    { k = 'show_vehicles', type = 'toggle', label = 'Carte Véhicules', default = true }, { k = 'show_properties', type = 'toggle', label = 'Carte Propriétés', default = true },
    { k = 'show_phone', type = 'toggle', label = 'Carte Téléphone', default = true }, { k = 'show_vip', type = 'toggle', label = 'Carte VIP', default = true }, { k = 'show_settings', type = 'toggle', label = 'Carte Paramètres', default = true },
    { k = 'custom', type = 'list', label = 'Raccourcis personnalisés (libellé|description|commande|pastille — 4 parties, la pastille peut être vide)', default = {}, maxitems = 8, maxlen = 200, pattern = '^[^|]+|[^|]*|[%w_:%-]+|[^|]*$', wide = true, hint = "La commande est exécutée côté joueur (ex. une commande de ton script VIP). Pas d'espace dans la commande." },
} })

PB.Module({
    id = 'personal', label = 'Menu personnel (F5)', icon = 'user', group = 'Serveur', order = 141, perm = 'personal.edit', hint = 'Menu F5 : cartes ou RageUI',
    caps = function()
        return PB.Capsify({
            { 'Deux affichages : grandes cartes ou menu RageUI', 'ok', 'Au choix du serveur, et du joueur si tu le permets.' },
            { 'Infos en direct', 'ok', 'Argent, métier, nombre de véhicules et de logements, messages non lus, factures à régler.' },
            { 'Images de fond teintées', 'ok', "La couleur de chaque carte (ou celle du serveur) se mélange à l'image." },
            { 'Raccourcis personnalisés', 'ok', 'Tu ajoutes tes propres cartes qui lancent une commande de ton serveur.' },
            { 'Localiser un véhicule ou un logement (GPS)', 'ok', "Clic sur un véhicule ou un logement : repère sur la carte (position réelle si le véhicule est dehors, sinon son garage ou la fourrière)." },
        })
    end,
    doc = "## Menu personnel\nLe joueur appuie sur **F5** (réglable). Selon ton choix, il voit de **grandes cartes** avec des images, ou le **menu RageUI** (flèches + Entrée).\n\nLes images sont dans `web/img/cards/` (inv, veh, sky, city, wallet, sea). Tu peux les remplacer par les tiennes (JPEG 640×400).\n\nRaccourcis personnalisés : `Mon VIP|Avantages de ton abonnement|vip|GOLD` (4 parties ; pastille vide : `Boutique|Notre boutique|shop|`).",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'personal', title = 'Menu F5 (exemple)', form = 'personal.look', cfg = { personal = PB.Cfg.All('personal'), menus = PB.Cfg.All('menus') } } } end },
            { id = 'look', label = 'Réglages', icon = 'sliders', build = function() return { look(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('menu personnel F5', function(R)
    local m = cfg('mode', 'cards')
    R.check(m == 'cards' or m == 'lib', 'affichage du menu F5', 'valeur inconnue : ' .. tostring(m))
    R.check((tonumber(cfg('image_strength', 55)) or 0) >= 15, "visibilité de l'image", 'trop faible')
end)
