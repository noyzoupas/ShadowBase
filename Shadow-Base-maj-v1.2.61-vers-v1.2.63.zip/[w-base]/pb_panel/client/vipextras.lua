-- VIP : peinture caméléon et changement de plaque (menu F5). La boombox est dans client/music.lua.
-- Caméléon : effet écrit en script, sans fichier à ajouter au jeu. La couleur change selon l'angle de vue ; chaque joueur le calcule de son côté
-- pour les véhicules proches marqués par le serveur (état « pb_cham »). Le serveur vérifie le VIP et le propriétaire du véhicule.
local G = PBG

G.CHAM = {
    { 'Violet et vert', { 128, 40, 230 }, { 30, 220, 120 } }, { 'Bleu et rose', { 30, 90, 255 }, { 255, 50, 170 } }, { 'Rouge et or', { 210, 20, 40 }, { 255, 190, 40 } },
    { 'Turquoise et violet', { 20, 210, 210 }, { 120, 40, 220 } }, { 'Vert et bleu', { 40, 220, 90 }, { 30, 90, 240 } }, { 'Orange et violet', { 255, 110, 20 }, { 130, 40, 220 } },
    { 'Cuivre et vert', { 190, 100, 50 }, { 40, 190, 120 } }, { 'Arc-en-ciel' },
}

local function hue(h)
    local i, f = math.floor(h * 6), h * 6 % 1
    local q, t = math.floor(255 * (1 - f)), math.floor(255 * f)
    local k = i % 6
    if k == 0 then return 255, t, 0 elseif k == 1 then return q, 255, 0 elseif k == 2 then return 0, 255, t elseif k == 3 then return 0, q, 255 elseif k == 4 then return t, 0, 255 end
    return 255, 0, q
end

-- véhicules proches qui portent la peinture
local list = {}
CreateThread(function()
    while true do
        Wait(1000)
        local fresh = {}
        if G.begun then
            local me = GetEntityCoords(PlayerPedId())
            for _, v in ipairs(GetGamePool('CVehicle')) do
                if #(GetEntityCoords(v) - me) < 90.0 then
                    local c = tonumber(Entity(v).state.pb_cham) or 0
                    if G.CHAM[c] then
                        fresh[v] = c
                    elseif list[v] then
                        ClearVehicleCustomPrimaryColour(v) ClearVehicleCustomSecondaryColour(v)   -- peinture retirée
                    end
                end
            end
        end
        list = fresh
    end
end)
CreateThread(function()
    while true do
        if next(list) then
            Wait(80)
            local cam = GetFinalRenderedCamCoord()
            local now = GetGameTimer() / 1000
            for v, c in pairs(list) do
                if DoesEntityExist(v) then
                    local p, fwd = GetEntityCoords(v), GetEntityForwardVector(v)
                    local dx, dy = p.x - cam.x, p.y - cam.y
                    local n = math.sqrt(dx * dx + dy * dy)
                    local dot = n > 0.01 and (dx * fwd.x + dy * fwd.y) / n or 1.0
                    local ang = math.acos(math.max(-1.0, math.min(1.0, dot)))
                    local d, r, g, b = G.CHAM[c], 0, 0, 0
                    if d[2] then
                        local t = 0.5 + 0.5 * math.cos(ang * 2.0 + now * 0.25)   -- fait le tour de la voiture : on passe d'une teinte à l'autre
                        r = math.floor(d[2][1] + (d[3][1] - d[2][1]) * t)
                        g = math.floor(d[2][2] + (d[3][2] - d[2][2]) * t)
                        b = math.floor(d[2][3] + (d[3][3] - d[2][3]) * t)
                    else
                        r, g, b = hue((ang / math.pi + now * 0.05) % 1)
                    end
                    SetVehicleCustomPrimaryColour(v, r, g, b)
                    SetVehicleCustomSecondaryColour(v, r, g, b)
                end
            end
        else
            Wait(500)
        end
    end
end)

-- Vraies peintures du jeu (ressource spchameleon : WildBrick142, Disquse, Rockstar Games)
local PAINTS_MOD = { { 223, 'Monochrome' }, { 224, 'Jour et nuit' }, { 225, 'Verlierer' }, { 226, 'Sprunk' }, { 227, 'Vice City' }, { 228, 'Synthwave' }, { 229, 'Quatre saisons' }, { 230, 'TBoGT' },
    { 231, 'Bubblegum' }, { 232, 'Arc-en-ciel prismatique' }, { 233, 'Coucher de soleil' }, { 234, 'Visions' }, { 235, 'Maziora' }, { 236, 'Lunettes 3D' }, { 237, 'Noël' }, { 238, 'Température' },
    { 239, 'HSW' }, { 240, 'Électrique' }, { 241, 'Monika' }, { 242, 'Fubuki' } }
local PAINTS_R = { { 161, 'Anodisé rouge' }, { 162, 'Anodisé bordeaux' }, { 163, 'Anodisé violet' }, { 164, 'Anodisé bleu' }, { 165, 'Anodisé vert' }, { 166, 'Anodisé citron vert' }, { 167, 'Anodisé cuivre' },
    { 168, 'Anodisé bronze' }, { 169, 'Anodisé champagne' }, { 170, 'Anodisé or' }, { 171, 'Vert et bleu' }, { 172, 'Vert et rouge' }, { 173, 'Vert et marron' }, { 174, 'Vert et turquoise' }, { 175, 'Vert et violet' },
    { 176, 'Sarcelle et violet' }, { 177, 'Turquoise et rouge' }, { 178, 'Turquoise et violet' }, { 179, 'Cyan et violet' }, { 180, 'Bleu et rose' }, { 181, 'Bleu et vert' }, { 182, 'Violet et rouge' }, { 183, 'Violet et vert' },
    { 184, 'Magenta et vert' }, { 185, 'Magenta et jaune' }, { 186, 'Bordeaux et vert' }, { 187, 'Magenta et cyan' }, { 188, 'Cuivre et violet' }, { 189, 'Magenta et orange' }, { 190, 'Rouge et orange' }, { 191, 'Orange et violet' },
    { 192, 'Orange et bleu' }, { 193, 'Blanc et violet' }, { 194, 'Rouge arc-en-ciel' }, { 195, 'Bleu arc-en-ciel' }, { 196, 'Perle vert foncé' }, { 197, 'Perle sarcelle foncé' }, { 198, 'Perle bleu foncé' }, { 199, 'Perle violet foncé' },
    { 200, 'Perle nappe de pétrole' }, { 201, 'Perle vert clair' }, { 202, 'Perle bleu clair' }, { 203, 'Perle violet clair' }, { 204, 'Perle rose clair' }, { 205, 'Prisme blanc cassé' }, { 206, 'Perle rose' }, { 207, 'Perle jaune' },
    { 208, 'Perle verte' }, { 209, 'Perle bleue' }, { 210, 'Perle crème' }, { 211, 'Prisme blanc' }, { 212, 'Prisme graphite' }, { 213, 'Prisme bleu foncé' }, { 214, 'Prisme violet foncé' }, { 215, 'Prisme rose vif' }, { 216, 'Prisme rouge' },
    { 217, 'Prisme vert' }, { 218, 'Prisme noir' }, { 219, 'Prisme nappe de pétrole' }, { 220, 'Prisme arc-en-ciel' }, { 221, 'Holographique noir' }, { 222, 'Holographique blanc' } }
RegisterNetEvent('pb:g:vip:paint', function(net, idx)
    local veh = NetworkDoesEntityExistWithNetworkId(net) and NetworkGetEntityFromNetworkId(net) or 0
    idx = tonumber(idx)
    if veh == 0 or not idx then return end
    SetVehicleModKit(veh, 0)
    ClearVehicleCustomPrimaryColour(veh) ClearVehicleCustomSecondaryColour(veh)
    SetVehicleColours(veh, idx, idx)
end)
local function vipOnly(title)
    if G.vip == true then return true end
    G.send('notify', { type = 'warn', title = title, text = 'Réservé aux VIP.' })
    return false
end

-- Changement de plaque : le serveur envoie les véhicules du joueur et vérifie tout
RegisterCommand('pb_vipplate', function()
    if G.begun and vipOnly('Plaque') then TriggerServerEvent('pb:g:vip:plates') end
end, false)
RegisterNetEvent('pb:g:vip:plates', function(j)
    local d = G.decode(j)
    if not d then return end
    local items = {}
    for _, v in ipairs(d.rows or {}) do
        items[#items + 1] = { label = v.label, right = v.plate, icon = 'engine', disabled = (not v.ready) or nil, description = v.ready and 'Choisis le nouveau texte.' or "Range-le d'abord au garage.", onSelect = function()
            local text = G.Menu.Ask('Nouvelle plaque (2 à 8 lettres ou chiffres)', '', 8)
            if text and text ~= '' then
                G.Menu.Close()
                TriggerServerEvent('pb:g:vip:plate', v.plate, text)
            end
        end }
    end
    if #items == 0 then items[1] = { label = 'Aucun véhicule à ton nom', disabled = true } end
    G.Menu.Open({ id = 'vip.plate', title = 'Changer de plaque', subtitle = 'Avantage VIP', items = items })
end)

-- Teinture d'armes : choisie par arme, mémorisée sur le poste, remise à chaque fois que l'arme passe en main (les autres joueurs la voient)
local TINTS = { 'Noir d\'origine', 'Vert', 'Or', 'Rose', 'Armée', 'LSPD', 'Orange', 'Platine' }
local TINTS_MK2 = { 'Noir classique', 'Gris classique', 'Deux tons', 'Blanc', 'Beige', 'Vert', 'Bleu', 'Terre', 'Brun et noir', 'Contraste rouge', 'Contraste bleu', 'Contraste jaune',
    'Contraste orange', 'Rose vif', 'Violet et jaune', 'Orange vif', 'Vert et violet', 'Détails rouges', 'Détails verts', 'Détails cyan', 'Détails jaunes', 'Rouge et blanc', 'Bleu et blanc',
    'Or métallisé', 'Platine métallisé', 'Gris et lilas', 'Violet et vert', 'Rouge métallisé', 'Vert métallisé', 'Bleu métallisé', 'Blanc et turquoise', 'Rouge et jaune' }
local function tintAllowed() return G.vip == true and (G.vipPerks or {}).weapon_tint ~= false end
local function tintKey(h) return 'pb_tint_' .. tostring(h) end
local function tintName(count, i)
    local names = count > 8 and TINTS_MK2 or TINTS
    return names[i + 1] or ('Teinture ' .. i)
end
CreateThread(function()
    local last
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local h = GetSelectedPedWeapon(ped)
        if h ~= last then
            last = h
            if h ~= GetHashKey('WEAPON_UNARMED') and tintAllowed() then
                local t = GetResourceKvpInt(tintKey(h))
                if t > 0 and t < GetWeaponTintCount(h) then SetPedWeaponTintIndex(ped, h, t) end
            end
        end
    end
end)
local function tintMenu()
    local ped = PlayerPedId()
    local h = GetSelectedPedWeapon(ped)
    local count = GetWeaponTintCount(h)
    local items = {}
    for i = 0, count - 1 do
        local on = GetPedWeaponTintIndex(ped, h) == i
        items[#items + 1] = { label = tintName(count, i), icon = 'brush', right = on and 'Actif' or nil, description = 'Mémorisée pour cette arme.', onSelect = function()
            SetPedWeaponTintIndex(PlayerPedId(), h, i)
            SetResourceKvpInt(tintKey(h), i)
            G.Menu.Refresh()
        end }
    end
    return items
end
local function openTint()
    if not G.begun then return end
    if not tintAllowed() then G.send('notify', { type = 'warn', title = 'Teinture d\'arme', text = 'Réservée aux VIP.' }) return end
    local h = GetSelectedPedWeapon(PlayerPedId())
    if h == GetHashKey('WEAPON_UNARMED') then G.send('notify', { type = 'warn', title = 'Teinture d\'arme', text = 'Prends une arme en main.' }) return end
    if GetWeaponTintCount(h) <= 1 then G.send('notify', { type = 'warn', title = 'Teinture d\'arme', text = 'Cette arme ne se teinte pas.' }) return end
    G.Menu.Open({ id = 'vip.tint', title = 'Teinture d\'arme', subtitle = 'Avantage VIP', build = tintMenu })
end
RegisterCommand('pb_teinture', openTint, false)   -- ouvert par le menu F5 (server/game/personal.lua)
RegisterCommand('teinture', openTint, false)

RegisterCommand('pb_cameleon', function()   -- ouvert par le menu F5 (server/game/personal.lua)
    if not G.begun or not vipOnly('Caméléon') then return end
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 or GetPedInVehicleSeat(veh, -1) ~= PlayerPedId() then G.send('notify', { type = 'warn', title = 'Caméléon', text = 'Monte au volant de ton véhicule.' }) return end
    local net = NetworkGetNetworkIdFromEntity(veh)
    local items = {}
    for i, c in ipairs(G.CHAM) do
        items[#items + 1] = { label = c[1], icon = 'sparkle', description = 'La couleur change selon l\'angle de vue. Enregistrée sur ton véhicule.', onSelect = function() TriggerServerEvent('pb:g:vip:cham', net, i) end }
    end
    if GetResourceState('spchameleon') == 'started' then
        local function sub(id, title, list)
            local rows = {}
            for _, p in ipairs(list) do rows[#rows + 1] = { label = p[2], right = tostring(p[1]), icon = 'sparkle', onSelect = function() TriggerServerEvent('pb:g:vip:paint', net, p[1]) end } end
            return { type = 'submenu', label = title, icon = 'brush', badge = tostring(#rows), description = 'Peintures : WildBrick142, Disquse, Rockstar Games.', submenu = { id = id, title = title, subtitle = 'Avantage VIP', items = rows } }
        end
        table.insert(items, 1, sub('vip.cham.r', 'Peintures Rockstar', PAINTS_R))
        table.insert(items, 1, sub('vip.cham.m', 'Peintures spéciales', PAINTS_MOD))
        table.insert(items, 3, { type = 'separator', label = 'Effet qui suit le regard' })
    end
    items[#items + 1] = { type = 'separator', label = '' }
    items[#items + 1] = { label = 'Retirer la peinture caméléon', icon = 'x', description = "Enlève l'effet ; pour une peinture du jeu, va ensuite chez le mécano ou choisis une autre couleur.", onSelect = function() TriggerServerEvent('pb:g:vip:cham', net, 0) end }
    G.Menu.Open({ id = 'vip.cham', title = 'Peinture caméléon', subtitle = 'Avantage VIP', items = items })
end, false)

