-- Touches réglables depuis le panel. FiveM n'applique la touche par défaut d'une commande qu'UNE fois par joueur (il la mémorise ensuite
-- dans ses paramètres) : changer la touche dans le panel ne servait à rien pour les joueurs déjà venus.
-- Ici, chaque touche est enregistrée sous une commande qui porte le nom de la touche (ex. pb_staff__F9) : une nouvelle touche par défaut
-- = une nouvelle commande, donc FiveM l'applique à tout le monde. Un joueur qui a choisi sa propre touche la garde tant que la touche
-- par défaut ne change pas. Chargé avant tous les autres scripts client de pb_panel.

local _register = RegisterKeyMapping
local done = {}

-- Un joueur déjà venu garde aussi l'ancienne liaison : la touche lance alors pb_staff ET pb_staff__F10 dans la même image.
-- Une commande pb_… ne s'exécute donc qu'une fois par appui, sinon un menu s'ouvre et se referme aussitôt.
local _command = RegisterCommand
local ranAt = {}
function RegisterCommand(name, fn, restricted)
    if type(name) == 'string' and name:sub(1, 3) == 'pb_' and type(fn) == 'function' then
        local inner = fn
        fn = function(...)
            local now = GetGameTimer()
            if ranAt[name] and now - ranAt[name] < 200 then return end
            ranAt[name] = now
            return inner(...)
        end
    end
    return _command(name, fn, restricted)
end

function RegisterKeyMapping(cmd, desc, device, key)
    cmd, key = tostring(cmd or ''), tostring(key or '')
    if cmd == '' or key == '' then return _register(cmd, desc, device, key) end
    local suffix = key:upper():gsub('[^%w_]', '')
    if suffix == '' then return _register(cmd, desc, device, key) end
    local hold = cmd:sub(1, 1) == '+'
    local base = hold and cmd:sub(2) or cmd
    local alias = base .. '__' .. suffix
    if done[alias] then return end
    done[alias] = true
    if hold then
        -- commande maintenue (+/-) : les deux moitiés renvoient vers la commande d'origine
        RegisterCommand('+' .. alias, function() ExecuteCommand('+' .. base) end, false)
        RegisterCommand('-' .. alias, function() ExecuteCommand('-' .. base) end, false)
        return _register('+' .. alias, desc, device, key)
    end
    RegisterCommand(alias, function(_, args) ExecuteCommand(base .. ((args and #args > 0) and (' ' .. table.concat(args, ' ')) or '')) end, false)
    return _register(alias, desc, device, key)
end
