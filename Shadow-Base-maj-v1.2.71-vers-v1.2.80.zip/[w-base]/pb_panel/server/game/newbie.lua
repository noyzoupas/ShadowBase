-- (v1.2.79) Protection des nouveaux joueurs : pendant leurs 30 premières minutes de jeu (temps passé en ville, personnage créé),
-- ils ne peuvent ni sortir d'arme ni tirer, ni faire d'action qui gêne le RP des autres (menotter, fouiller, escorter, braquer,
-- prendre en otage…), et leur véhicule traverse les autres joueurs et leurs véhicules (pas de « freekill » à la voiture).
-- Le « (Nouveau) » des gamertags reste géré par server/game/tags.lua. Seuls les comptes vus pour la première fois après cette
-- mise à jour sont protégés : les joueurs déjà venus ne le sont pas.
local G, P, DB = PB.G, PB.Perm, PB.DB
local N = {}
G.Newbie = N
PB.Cfg.Define('newbie', { enabled = true, minutes = 30 })
local function cfg(k, d) return PB.Cfg.Get('newbie', k, d) end
local function limit() return math.max(1, math.min(600, math.floor(tonumber(cfg('minutes', 30)) or 30))) * 60 end

PB.Migrate('561_newbie', 'Protection des nouveaux joueurs (temps de jeu)', {
    [[CREATE TABLE IF NOT EXISTS pb_newbie (license VARCHAR(64) NOT NULL PRIMARY KEY, secs INT NOT NULL DEFAULT 0, done TINYINT NOT NULL DEFAULT 0, at INT NOT NULL DEFAULT 0)]],
})

local active = {}   -- src -> { license, secs }
function N.Is(src) return cfg('enabled', true) ~= false and active[tonumber(src) or -1] ~= nil end
function N.Left(src) local a = active[tonumber(src) or -1] return a and math.max(0, limit() - a.secs) or 0 end
local function push(src)
    local on = N.Is(src)
    pcall(function() Player(src).state:set('pbNew', on or nil, true) end)   -- les autres joueurs le lisent : son véhicule les traverse
    TriggerClientEvent('pb:g:newbie', src, PB.Json({ left = on and N.Left(src) or 0 }))
end
local function save(src)
    local a = active[src]
    if a then DB.exec('UPDATE pb_newbie SET secs = ? WHERE license = ?', { a.secs, a.license }) end
end
function N.Clear(src, why)
    local a = active[src]
    if not a then return false end
    active[src] = nil
    DB.exec('UPDATE pb_newbie SET secs = ?, done = 1 WHERE license = ?', { math.max(a.secs, 0), a.license })
    push(src)
    G.Notify(src, { type = 'success', title = 'Protection terminée', text = why or 'Tes premières minutes sont passées : armes et actions sont maintenant possibles. Bon jeu !' })
    return true
end

table.insert(G.beginHooks, function(src)
    SetTimeout(2500, function()   -- après server/game/tags.lua, qui note la première venue
        local p = G.Get(src)
        if not p or not p.license or cfg('enabled', true) == false then return end
        local r = DB.one('SELECT secs, done FROM pb_newbie WHERE license = ?', { p.license })
        if not r then
            local fs = DB.one('SELECT at FROM pb_first_seen WHERE license = ?', { p.license })
            if not fs or os.time() - (tonumber(fs.at) or 0) > 900 then return end   -- déjà venu avant : pas de protection
            DB.exec('INSERT IGNORE INTO pb_newbie (license, secs, done, at) VALUES (?, 0, 0, ?)', { p.license, os.time() })
            r = { secs = 0, done = 0 }
        end
        if PB.ToBool(r.done) or (tonumber(r.secs) or 0) >= limit() then return end
        active[src] = { license = p.license, secs = tonumber(r.secs) or 0 }
        push(src)
        G.Notify(src, { type = 'info', title = 'Bienvenue !', text = ('Protection des nouveaux pendant %d min de jeu : pas d\'arme ni d\'action hostile, et ton véhicule traverse les autres joueurs.'):format(math.ceil(N.Left(src) / 60)) })
    end)
end)
AddEventHandler('playerDropped', function() local src = source save(src) active[src] = nil end)

-- le temps ne compte qu'en ville, personnage créé
CreateThread(function()
    while true do
        Wait(60000)
        for src, a in pairs(active) do
            local p = G.Get(src)
            if not p then active[src] = nil
            elseif PB.ToBool(p.row.created) then
                a.secs = a.secs + 60
                if a.secs >= limit() then N.Clear(src) else save(src) TriggerClientEvent('pb:g:newbie', src, PB.Json({ left = N.Left(src) })) end
            end
        end
    end
end)
PB.Cfg.OnChange('newbie', function()
    for src in pairs(active) do
        if cfg('enabled', true) == false or active[src].secs >= limit() then N.Clear(src, 'La protection des nouveaux joueurs a été levée.') else push(src) end
    end
end)

-- Refus commun : actions qui gênent les autres (menu ALT, F7, braquages, ressources extérieures)
N.MSG = 'Protection des nouveaux joueurs : impossible pendant tes premières minutes de jeu.'
function N.Deny(src)
    if not N.Is(src) then return false end
    return true, ('%s (encore %d min)'):format(N.MSG, math.ceil(N.Left(src) / 60))
end
exports('IsNewPlayer', function(src) return N.Is(tonumber(src)) end)

-- Menu staff › un joueur : lever la protection
local S = G.Staff
if S and S.Def then
    S.Def('newbie_clear', 'staff.heal', { target = true, run = function(src, t)
        if not N.Is(t) then return false, "Ce joueur n'est pas (ou plus) protégé." end
        N.Clear(t, 'Un membre du staff a levé ta protection de nouveau joueur.')
        return true, 'Protection levée.'
    end, log = true })
end

G.NewbieForm = PB.Form.Cfg({ ns = 'newbie', id = 'settings', title = 'Protection des nouveaux joueurs', perm = 'staff.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Protéger les nouveaux joueurs', default = true },
    { k = 'minutes', type = 'number', label = 'Durée (minutes de jeu)', default = 30, min = 1, max = 600 },
} })
