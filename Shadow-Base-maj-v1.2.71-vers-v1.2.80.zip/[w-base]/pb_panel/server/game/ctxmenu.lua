-- Menu contextuel (touche ALT maintenue) : le joueur clique sur lui-même ou sur une autre personne, un petit menu s'ouvre à côté.
-- Le serveur compose toute la liste (catégories, entrées, grisées ou cachées selon distance, métier, grade et permissions staff) ;
-- le client ne peut qu'envoyer « cette entrée, sur cette cible ». À l'exécution le serveur recompose la liste et refuse tout ce qui n'y figure pas.
-- Les effets passent par les actions existantes (F6 métier, menu staff) : mêmes droits, mêmes journaux.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local C = {}
G.Ctx = C

P.Register('ctx.edit', 'Modifier le menu ALT (menu contextuel)', 'ctx', true)

-- Catalogue : scope self/other ; kind : cmd (commande côté joueur), anim, srv (traité ici), quick (action métier F6), staff (action du menu staff)
local CATALOG = {
    -- sur soi
    { id = 'inventory', scope = 'self', cat = 'personal', label = 'Mon inventaire', desc = 'Ouvre ton sac.', icon = 'bag', kind = 'cmd', cmd = 'pb_inv' },
    { id = 'phone', scope = 'self', cat = 'personal', label = 'Mon téléphone', desc = 'Messages, contacts et services.', icon = 'phone', kind = 'cmd', cmd = 'pb_phone' },
    { id = 'tablet', scope = 'self', cat = 'personal', label = 'Mon espace', desc = 'Finances, factures et entreprise (menu).', icon = 'briefcase', kind = 'cmd', cmd = 'pb_tablet' },
    { id = 'personal', scope = 'self', cat = 'personal', label = 'Menu personnel', desc = 'Tes véhicules, propriétés et papiers.', icon = 'user', kind = 'cmd', cmd = 'pb_me' },
    { id = 'graffiti', scope = 'self', cat = 'personal', label = 'Faire un tag', desc = 'Choisis un tag et pose-le sur un mur.', icon = 'brush', kind = 'cmd', cmd = 'pb_tag' },
    { id = 'graffiti_erase', scope = 'self', cat = 'personal', label = 'Effacer un tag proche', icon = 'trash', kind = 'cmd', cmd = 'pb_tagerase' },
    { id = 'wallet', scope = 'self', cat = 'personal', label = 'Voir mon argent', desc = 'Espèces et banque.', icon = 'wallet', kind = 'srv' },
    { id = 'animations', scope = 'self', cat = 'anim', label = 'Animations', desc = 'Ouvre le menu des animations.', icon = 'music', kind = 'cmd', cmd = 'animmenu' },   -- menu animations : ressource animation_menu (ancien menu : pb_anims)
    { id = 'anim_handsup', scope = 'self', cat = 'anim', label = 'Mains en l\'air', icon = 'hand', kind = 'anim', v = 'handsup' },
    { id = 'anim_crossarms', scope = 'self', cat = 'anim', label = 'Bras croisés', icon = 'user', kind = 'anim', v = 'crossarms' },
    { id = 'anim_salute', scope = 'self', cat = 'anim', label = 'Salut', icon = 'star', kind = 'anim', v = 'salute' },
    { id = 'anim_facepalm', scope = 'self', cat = 'anim', label = 'Facepalm', icon = 'face', kind = 'anim', v = 'facepalm' },
    { id = 'anim_dance', scope = 'self', cat = 'anim', label = 'Danser', icon = 'music', kind = 'anim', v = 'dance' },
    { id = 'anim_stop', scope = 'self', cat = 'anim', label = 'Arrêter l\'animation', icon = 'x', kind = 'anim', v = 'stop' },
    { id = 'duty', scope = 'self', cat = 'job', label = 'Prise de service', desc = 'Prends ou quitte ton service.', icon = 'bolt', kind = 'quick' },
    { id = 'quick', scope = 'self', cat = 'job', label = 'Menu de mon entreprise', desc = 'Le menu F6 de ton entreprise.', icon = 'briefcase', kind = 'cmd', cmd = 'pb_entreprise' },
    { id = 'my_badge', scope = 'self', cat = 'job', label = 'Voir mon badge', desc = 'Ton badge d\'employé.', icon = 'id', kind = 'srv', req = 'employed' },
    -- sur une autre personne
    { id = 'show_badge', scope = 'other', cat = 'job', label = 'Montrer mon badge', desc = 'Ton badge d\'employé (entreprise, grade, matricule).', icon = 'id', kind = 'srv', near = true, req = 'employed' },
    { id = 'show_id', scope = 'other', cat = 'people', label = 'Montrer mes papiers', desc = 'Elle voit ton identité.', icon = 'id', kind = 'srv', near = true },
    { id = 'give_cash', scope = 'other', cat = 'people', label = 'Donner de l\'argent', desc = 'Remets des espèces.', icon = 'coins', kind = 'srv', near = true, inputs = { { k = 'amount', label = 'Montant', number = true, maxlen = 6 } } },
    { id = 'report', scope = 'other', cat = 'people', label = 'Signaler cette personne', desc = 'Prévient le staff.', icon = 'alert', kind = 'srv', inputs = { { k = 'reason', label = 'Motif', maxlen = 160 } } },
    { id = 'invoice', scope = 'other', cat = 'job', label = 'Facturer', desc = 'Envoie une facture.', icon = 'card', kind = 'quick', near = true, inputs = { { k = 'amount', label = 'Montant', number = true, maxlen = 7 }, { k = 'reason', label = 'Motif', maxlen = 60 } } },
    { id = 'cuff', scope = 'other', cat = 'job', label = 'Menotter', icon = 'lock', kind = 'quick', near = true },
    { id = 'uncuff', scope = 'other', cat = 'job', label = 'Libérer', icon = 'key', kind = 'quick', near = true },
    { id = 'search', scope = 'other', cat = 'job', label = 'Fouiller', icon = 'search', kind = 'quick', near = true },
    { id = 'permit', scope = 'other', cat = 'job', label = "Délivrer un permis d'arme", icon = 'id', kind = 'quick', near = true },
    { id = 'permit_revoke', scope = 'other', cat = 'job', label = "Retirer le permis d'arme", icon = 'x', kind = 'quick', near = true },
    { id = 'revive', scope = 'other', cat = 'job', label = 'Réanimer', icon = 'heart', kind = 'quick', near = true },
    { id = 'escort', scope = 'other', cat = 'job', label = 'Escorter', desc = 'Emmène la personne menottée avec toi.', icon = 'hand', kind = 'srv', near = true, req = 'cuffed' },
    { id = 'put_veh', scope = 'other', cat = 'job', label = 'Mettre dans le véhicule', desc = 'Place la personne menottée dans le véhicule le plus proche.', icon = 'car', kind = 'srv', near = true, req = 'cuffed' },
    -- agence immobilière (agents en service)
    { id = 're_list', scope = 'self', cat = 'job', label = 'Mettre un logement en annonce ici', desc = 'La porte est à ta position. Choisis la gamme : prix et intérieur fixés par le serveur.', icon = 'home', kind = 'srv', req = 'realtor' },
    { id = 're_unlist', scope = 'self', cat = 'job', label = 'Retirer de la vente', desc = "Logement libre de l'agence devant toi (6 m).", icon = 'x', kind = 'srv', req = 'realtor', danger = true },
    { id = 'dl_test', scope = 'other', cat = 'job', label = 'Faire essayer un véhicule', desc = 'Concession : choisis le véhicule, le client part en essai.', icon = 'car', kind = 'srv', near = true, req = 'dealer' },
    { id = 'dl_sell', scope = 'other', cat = 'job', label = 'Vendre un véhicule', desc = 'Concession : le client accepte et paie, ton entreprise encaisse.', icon = 'coins', kind = 'srv', near = true, req = 'dealer' },
    { id = 're_keys', scope = 'other', cat = 'job', label = 'Remettre les clés', desc = 'Le logement de l\'agence devant toi : vente (clé définitive) ou location (tu choisis la durée). Le client accepte et paie.', icon = 'key', kind = 'srv', near = true, req = 'realtor' },
    { id = 're_visit', scope = 'other', cat = 'job', label = 'Faire visiter', desc = 'Le logement devant toi : accès de 15 minutes pour cette personne.', icon = 'home', kind = 'srv', near = true, req = 'realtor' },
    { id = 'bar_serve', scope = 'other', cat = 'job', label = 'Servir (bar, café, restaurant)', desc = 'Propose à cette personne un produit préparé ; elle paie si elle accepte.', icon = 'food', kind = 'srv', near = true, req = 'bartender' },
    { id = 'casier', scope = 'other', cat = 'job', label = 'Casier judiciaire', icon = 'book', kind = 'quick', near = true },
    -- staff : sur soi
    { id = 's_menu', scope = 'self', cat = 'staff', staff = 'staff.menu', label = 'Ouvrir le menu staff', icon = 'shield', kind = 'cmd', cmd = 'pb_staff' },
    { id = 's_duty', scope = 'self', cat = 'staff', staff = 'staff.menu', label = 'Service staff', desc = 'Prends ou quitte ton service.', icon = 'bolt', kind = 'staff', act = 'duty' },
    { id = 's_heal_me', scope = 'self', cat = 'staff', staff = 'staff.heal', label = 'Me soigner', icon = 'heart', kind = 'staff', act = 'heal_me' },
    { id = 's_tp_waypoint', scope = 'self', cat = 'staff', staff = 'staff.teleport', label = 'Aller au repère', icon = 'gps', kind = 'staff', act = 'tp_waypoint' },
    { id = 's_veh_repair', scope = 'self', cat = 'staff', staff = 'staff.vehicle', label = 'Réparer mon véhicule', icon = 'engine', kind = 'staff', act = 'veh_repair' },
    -- staff : sur une autre personne
    { id = 's_info', scope = 'other', cat = 'staff', staff = 'staff.players', label = 'Informations', icon = 'info', kind = 'staff', act = 'info' },
    { id = 's_history', scope = 'other', cat = 'staff', staff = 'staff.players', label = 'Historique', icon = 'clock', kind = 'staff', act = 'history' },
    { id = 's_goto', scope = 'other', cat = 'staff', staff = 'staff.teleport', label = 'TP sur lui (aller vers)', icon = 'gps', kind = 'staff', act = 'goto' },
    { id = 's_bring', scope = 'other', cat = 'staff', staff = 'staff.teleport', label = 'TP à moi (le ramener)', icon = 'gps', kind = 'staff', act = 'bring' },
    { id = 's_leave_veh', scope = 'other', cat = 'staff', staff = 'staff.freeze', label = 'Faire descendre du véhicule', icon = 'car', kind = 'staff', act = 'leave_veh' },
    { id = 's_give_vehicle', scope = 'other', cat = 'staff', staff = 'staff.givecar', label = 'Donner un véhicule', desc = 'Ajouté à son garage.', icon = 'car', kind = 'staff', act = 'give_vehicle', inputs = { { k = 'model', label = 'Modèle (ex. sultan)', maxlen = 32 } } },
    { id = 's_slap', scope = 'other', cat = 'staff', staff = 'staff.freeze', label = 'Gifler (troll)', desc = 'Le projette en l\'air.', icon = 'hand', kind = 'staff', act = 'slap', danger = true },
    { id = 's_heal', scope = 'other', cat = 'staff', staff = 'staff.heal', label = 'Soigner', icon = 'heart', kind = 'staff', act = 'heal' },
    { id = 's_revive', scope = 'other', cat = 'staff', staff = 'staff.heal', label = 'Réanimer', icon = 'heart', kind = 'staff', act = 'revive' },
    { id = 's_jail', scope = 'other', cat = 'staff', staff = 'staff.jail', label = 'Mettre en prison', desc = 'Prison (minutes + motif) ; relancer libère.', icon = 'lock', kind = 'staff', act = 'jail', danger = true, inputs = { { k = 'minutes', label = 'Minutes de prison', number = true, maxlen = 3 }, { k = 'reason', label = 'Motif', maxlen = 120 } } },
    { id = 's_freeze', scope = 'other', cat = 'staff', staff = 'staff.freeze', label = 'Geler / libérer', icon = 'lock', kind = 'staff', act = 'freeze' },
    { id = 's_spectate', scope = 'other', cat = 'staff', staff = 'staff.spectate', label = 'Observer', icon = 'eye', kind = 'staff', act = 'spectate' },
    { id = 's_inv', scope = 'other', cat = 'staff', staff = 'staff.inventory', label = 'Voir son inventaire', icon = 'bag', kind = 'staff', act = 'inv_view' },
    { id = 's_note', scope = 'other', cat = 'staff', staff = 'staff.notes', label = 'Ajouter une note', icon = 'file', kind = 'staff', act = 'note', inputs = { { k = 'text', label = 'Note privée', maxlen = 250 } } },
    { id = 's_message', scope = 'other', cat = 'staff', staff = 'staff.warn', label = 'Envoyer un message', icon = 'chat', kind = 'staff', act = 'message', inputs = { { k = 'reason', label = 'Message', maxlen = 150 } } },
    { id = 's_whisper', scope = 'other', cat = 'staff', staff = 'staff.whisper', label = 'Chuchoter', icon = 'chat', kind = 'staff', act = 'whisper', inputs = { { k = 'text', label = 'Message chuchoté', maxlen = 200 } } },
    { id = 's_warn', scope = 'other', cat = 'staff', staff = 'staff.warn', label = 'Avertir', icon = 'alert', kind = 'staff', act = 'warn', danger = true, inputs = { { k = 'reason', label = 'Motif', maxlen = 120 } } },
    { id = 's_mute', scope = 'other', cat = 'staff', staff = 'staff.mute', label = 'Muter (chat et micro)', desc = 'Relancer démute.', icon = 'mic', kind = 'staff', act = 'mute', danger = true, inputs = { { k = 'minutes', label = 'Minutes (0 = jusqu\'à la levée)', number = true, maxlen = 4 }, { k = 'reason', label = 'Motif', maxlen = 120 } } },
    { id = 's_kick', scope = 'other', cat = 'staff', staff = 'staff.kick', label = 'Expulser', icon = 'x', kind = 'staff', act = 'kick', danger = true, inputs = { { k = 'reason', label = 'Motif', maxlen = 120 } } },
}

-- Gestes sur soi : le client détient les animations (dictionnaire/clip) ; le serveur ne connaît que la clé et le libellé.
local GEST = {
    { 'gest', 'surrender', 'Se rendre', 'hand' }, { 'gest', 'kneel', 'À genoux', 'user' }, { 'gest', 'headhands', 'Mains sur la tête', 'hand' },
    { 'gest', 'hello', 'Dire bonjour', 'hand' }, { 'gest', 'bye', 'Dire au revoir', 'hand' }, { 'gest', 'come', 'Faire signe de venir', 'hand' },
    { 'gest', 'point', 'Montrer du doigt', 'hand' }, { 'gest', 'halt', 'Faire signe de s’arrêter', 'hand' }, { 'gest', 'shush', 'Chut', 'mic' },
    { 'gest', 'shrug', 'Hausser les épaules', 'user' }, { 'gest', 'nope', 'Non de la tête', 'x' }, { 'gest', 'damn', 'Zut !', 'alert' },
    { 'gest', 'what', 'Quoi ?', 'help' }, { 'gest', 'peace', 'Signe de paix', 'hand' }, { 'gest', 'rock', 'Rock', 'music' },
    { 'gest', 'kiss', 'Envoyer un baiser', 'heart' }, { 'gest', 'slowclap', 'Applaudir lentement', 'hand' }, { 'gest', 'cheer', 'Acclamer', 'star' },
    { 'pose', 'sitground', 'S’asseoir par terre', 'user' }, { 'pose', 'sitbench', 'S’asseoir sur un banc', 'user' }, { 'pose', 'lean', 'S’adosser au mur', 'user' },
    { 'pose', 'lieback', 'S’allonger sur le dos', 'bed' }, { 'pose', 'lieface', 'S’allonger sur le ventre', 'bed' }, { 'pose', 'smoke', 'Fumer', 'user' },
    { 'pose', 'coffee', 'Boire un café', 'user' }, { 'pose', 'drink', 'Boire', 'user' }, { 'pose', 'phonecall', 'Téléphoner', 'phone' },
    { 'pose', 'binoc', 'Regarder aux jumelles', 'eye' }, { 'pose', 'guard', 'Garde-à-vous', 'shield' }, { 'pose', 'impatient', 'Attendre', 'clock' },
    { 'sport', 'pushups', 'Pompes', 'bolt' }, { 'sport', 'situps', 'Abdos', 'bolt' }, { 'sport', 'yoga', 'Yoga', 'bolt' },
    { 'sport', 'jog', 'Jogging sur place', 'bolt' }, { 'sport', 'flex', 'Montrer ses muscles', 'bolt' },
    { 'danse', 'dance1', 'Danse 1', 'music' }, { 'danse', 'dance2', 'Danse 2', 'music' }, { 'danse', 'party', 'Faire la fête', 'music' },
}
C.GEST = GEST
for _, g in ipairs(GEST) do CATALOG[#CATALOG + 1] = { id = 'g_' .. g[2], scope = 'self', cat = g[1], label = g[3], icon = g[4], kind = 'gest', v = g[2] } end
CATALOG[#CATALOG + 1] = { id = 'gest_stop', scope = 'self', cat = 'gest', label = 'Arrêter le geste', icon = 'x', kind = 'gest', v = 'stop' }
-- (v1.2.42) garde-robe : enregistrer la tenue portée (sac de vêtements) ; « Mes tenues » dans un logement
CATALOG[#CATALOG + 1] = { id = 'outfit_save', scope = 'self', cat = 'personal', label = 'Enregistrer ma tenue', desc = 'Range la tenue portée dans un sac de vêtements (inventaire).', icon = 'hanger', kind = 'srv', inputs = { { k = 'text', label = 'Nom de la tenue', maxlen = 32 } } }
CATALOG[#CATALOG + 1] = { id = 'outfits', scope = 'self', cat = 'personal', label = 'Mes tenues', desc = 'Ta garde-robe : enfiler ou supprimer une tenue enregistrée.', icon = 'hanger', kind = 'srv', req = 'home' }
-- (v1.2.42) prêter la clé de son véhicule le plus proche pour 1 heure
CATALOG[#CATALOG + 1] = { id = 'lend_key', scope = 'other', cat = 'people', label = 'Prêter la clé de mon véhicule', desc = 'Ton véhicule le plus proche, pour 1 heure.', icon = 'key', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'copy_my_id', scope = 'self', cat = 'personal', label = 'Copier mon ID', desc = 'Copie ton numéro de joueur.', icon = 'copy', kind = 'srv' }
CATALOG[#CATALOG + 1] = { id = 'carry_stop', scope = 'self', cat = 'social', label = 'Lâcher / descendre', desc = 'Arrête de porter ou d’être porté.', icon = 'x', kind = 'srv' }
-- Gestes à deux : la personne doit accepter (Y) ou refuser (N)
CATALOG[#CATALOG + 1] = { id = 'carry', scope = 'other', cat = 'social', label = 'Porter', desc = 'Tu portes la personne (elle doit accepter).', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'carried', scope = 'other', cat = 'social', label = 'Se faire porter', desc = 'Elle te porte si elle accepte.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'check', scope = 'other', cat = 'social', label = 'Checker', desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'handshake', scope = 'other', cat = 'social', label = 'Serrer la main', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'hug', scope = 'other', cat = 'social', label = 'Faire un câlin', icon = 'heart', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'highfive', scope = 'other', cat = 'social', label = "Taper dans la main", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'brohug', scope = 'other', cat = 'social', label = "Accolade", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'heart', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'backslap', scope = 'other', cat = 'social', label = "Tape dans le dos", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'manlyshake', scope = 'other', cat = 'social', label = "Poignée de main virile", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'kiss', scope = 'other', cat = 'social', label = "Faire la bise", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'heart', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'give', scope = 'other', cat = 'social', label = "Remettre quelque chose", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'slap', scope = 'other', cat = 'social', label = "Gifler (RP)", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
CATALOG[#CATALOG + 1] = { id = 'headbutt', scope = 'other', cat = 'social', label = "Coup de tête (RP)", desc = 'Elle accepte avec Y, refuse avec N.', icon = 'hand', kind = 'srv', near = true }
-- (patch 136) actions illégales des membres d'un gang / d'une organisation (mêmes règles que le menu F7)
for _, a in ipairs({
    { 'tie', 'Ligoter', 'Utilise une corde.', 'lock' }, { 'untie', 'Détacher', nil, 'key', true }, { 'escort', 'Escorter / lâcher', nil, 'hand', true },
    { 'put_veh', 'Mettre dans le véhicule', nil, 'car', true }, { 'pull_veh', 'Sortir du véhicule', nil, 'car', true }, { 'search', 'Fouiller', 'Prends ce que tu veux.', 'search', true },
    { 'hood', 'Cagoule : mettre / retirer', nil, 'eye', true }, { 'handsup', "Braquer : mains en l'air", 'Il te faut une arme en main.', 'crosshair' },
}) do
    CATALOG[#CATALOG + 1] = { id = 'ill_' .. a[1], scope = 'other', cat = 'illegal', label = a[2], desc = a[3], icon = a[4], kind = 'srv', near = true, req = a[5] and 'gang_tied' or 'gang', gact = a[1] }
end
-- (v1.2.78) le reste du menu F7 sur soi : menu complet, GPS du QG, coffre, caisse commune
for _, a in ipairs({
    { 'menu', "Menu de mon organisation", 'Le menu F7 complet.', 'users' }, { 'gps_hq', 'GPS : notre QG', 'Met le QG sur ta carte.', 'gps' },
    { 'stash', "Coffre de l'organisation", 'Au point coffre du QG.', 'box' },
    { 'vault_in', 'Verser à la caisse commune', 'Tes espèces vont dans la caisse.', 'coins', { { k = 'amount', label = 'Montant ($)', number = true, maxlen = 7 } } },
}) do
    CATALOG[#CATALOG + 1] = { id = 'org_' .. a[1], scope = 'self', cat = 'orga', label = a[2], desc = a[3], icon = a[4], kind = a[1] == 'menu' and 'cmd' or 'srv', cmd = a[1] == 'menu' and 'pb_gang' or nil, req = 'gang', inputs = a[5], gself = a[1] }
end
CATALOG[#CATALOG + 1] = { id = 'copy_id', scope = 'other', cat = 'social', label = 'Copier son ID', desc = 'Copie son numéro de joueur.', icon = 'copy', kind = 'srv' }
C.Catalog = CATALOG
local BYID = {}
for _, e in ipairs(CATALOG) do BYID[e.id] = e end
-- Ordre d'affichage dans le menu ALT : le métier et le personnage d'abord, les animations ensuite, le staff en dernier
local CATS = {
    { id = 'job', label = 'Métier', icon = 'briefcase' }, { id = 'personal', label = 'Mon personnage', icon = 'user' },
    { id = 'people', label = 'Interactions', icon = 'users' }, { id = 'social', label = 'Gestes à deux', icon = 'users' },
    { id = 'anim', label = 'Animations', icon = 'music' }, { id = 'gest', label = 'Gestes', icon = 'hand' }, { id = 'pose', label = 'Poses et repos', icon = 'bed' },
    { id = 'danse', label = 'Danses', icon = 'music' }, { id = 'sport', label = 'Sport', icon = 'bolt' },
    { id = 'orga', label = 'Mon organisation', icon = 'users' },
    { id = 'illegal', label = 'Actions illégales', icon = 'skull' },
    { id = 'staff', label = 'Staff', icon = 'shield' },
}

-- Véhicules : entrées proposées quand on clique sur un véhicule (le serveur lit lui-même la plaque et la position du véhicule)
local VCAT = {
    { id = 'v_lock', label = 'Verrouiller / déverrouiller', icon = 'lock', key = true },
    { id = 'v_engine', label = 'Moteur : démarrer / couper', icon = 'bolt', key = true },
    { id = 'v_trunk', label = 'Coffre : ouvrir / fermer', icon = 'bag', key = true },
    { id = 'v_plate', label = 'Lire la plaque', icon = 'id' },
    { id = 'v_owner', label = 'Propriétaire (fichier)', icon = 'search', cop = 'records' },
    { id = 'v_pull', label = 'Sortir la personne menottée', icon = 'hand', escortOnly = true },
    { id = 'v_flip', label = 'Retourner le véhicule', icon = 'refresh', flipped = true },
    { id = 'v_picklock', label = 'Crocheter', icon = 'key', lockpick = true, danger = true },
    { id = 'v_impound', label = 'Mettre en fourrière', icon = 'x', cop = 'seize', danger = true, inputs = { { k = 'reason', label = 'Motif', maxlen = 70 } } },
    -- dépanneuse (mécanicien en service, avec un plateau « flatbed » à côté)
    { id = 'v_unfake', label = 'Retirer la fausse plaque', icon = 'id', fake = true },
    { id = 'v_tow_load', label = 'Charger sur la dépanneuse', icon = 'engine', tow = 'load' },
    { id = 'v_tow_unload', label = 'Décharger le véhicule', icon = 'arrow', tow = 'unload' },
    { id = 'v_tow_drop', label = 'Déposer à la fourrière', icon = 'lock', tow = 'drop' },
    -- staff (en service) : n'apparaissent que pour le staff
    { id = 'sv_ids', label = 'Occupants (noms et ID)', icon = 'users', staff = 'staff.players' },
    { id = 'sv_eject', label = 'Faire descendre les occupants', icon = 'hand', staff = 'staff.freeze' },
    { id = 'sv_repair', label = 'Réparer', icon = 'engine', staff = 'staff.vehicle' },
    { id = 'sv_unlock', label = 'Déverrouiller (staff)', icon = 'key', staff = 'staff.vehicle' },
    { id = 'sv_freeze', label = 'Geler / libérer le véhicule', icon = 'lock', staff = 'staff.vehicle' },
    { id = 'sv_tyres', label = 'Crever les pneus (troll)', icon = 'alert', staff = 'staff.vehicle', danger = true },
    { id = 'sv_delete', label = 'Supprimer le véhicule (DV)', icon = 'trash', staff = 'staff.vehicle', danger = true },
}
local VBYID = {}
for _, e in ipairs(VCAT) do VBYID[e.id] = e end
C.VCatalog = VCAT
local OBJECTS = {
    { model = 'prop_atm_01', label = 'Distributeur', cmd = 'pb_bank', icon = 'card' },
    { model = 'prop_atm_02', label = 'Distributeur', cmd = 'pb_bank', icon = 'card' },
}

local defaults = { style = 'nova', enabled = true, key = 'LMENU', range = 15, lockpick_chance = 60, lockpick_break = 25, custom_anims = {}, act_dist = 3.5, show_self = true, show_others = true, show_vehicles = true, show_objects = true, walls = false, staff_extra = true, max_give = 5000, custom = {}, objects = OBJECTS }
for _, e in ipairs(CATALOG) do defaults['e_' .. e.id] = true end
for _, e in ipairs(VCAT) do defaults['e_' .. e.id] = true end
PB.Cfg.Define('ctx', defaults)
local function cfg(k, d) return PB.Cfg.Get('ctx', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n or 120)) end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »

local function display(src)
    local i = G.Identity(src)
    if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end
    return 'Joueur ' .. src
end
local function created(id) local p = G.Get(id) return p and PB.ToBool(p.row.created) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function dist(a, b) if a == b then return 0 end return G.DistBetween(a, b) or 1e9 end
local function isStaff(src) return cfg('staff_extra', true) ~= false and P.Has(src, 'staff.menu') end


-- Escorte : une personne menottée suit celui qui l'escorte (le serveur tient le registre, le client attache le personnage)
local escorts, escortOf, pendingVeh = {}, {}, {}    -- cible -> escorteur ; escorteur -> cible ; cible -> escorteur (mise en véhicule en cours)
function C.EscortedBy(t) return escorts[tonumber(t) or -1] end
local function stopEscort(t, why)
    local by = escorts[t]
    if not by then return end
    escorts[t] = nil
    if escortOf[by] == t then escortOf[by] = nil end
    TriggerClientEvent('pb:g:ctx:escort', t, PB.Json({ on = false }))
    TriggerEvent('pb_panel:gangBusy', by)
    if why then G.Notify(by, { type = 'info', title = 'Escorte', text = why }) end
end
C.StopEscort = stopEscort
function C.EscortTargetOf(by) return escortOf[tonumber(by) or -1] end   -- (v1.2.78) qui j'escorte (E pour lâcher)
AddEventHandler('playerDropped', function()
    local src = source
    if escorts[src] then stopEscort(src) end
    if escortOf[src] then stopEscort(escortOf[src]) end
    pendingVeh[src] = nil
end)
CreateThread(function()
    while true do
        Wait(1500)
        for t, by in pairs(escorts) do
            if not G.Get(t) or not G.Get(by) then stopEscort(t)
            elseif not (G.IsCuffed and G.IsCuffed(t)) then stopEscort(t, 'La personne n\'est plus menottée : escorte terminée.')
            elseif dist(by, t) > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 12 then stopEscort(t, 'Escorte interrompue : trop loin.') end
        end
    end
end)

-- entrées personnalisées « libellé|description|commande|self ou other »
local function customs()
    local out = {}
    for i, line in ipairs(cfg('custom', {}) or {}) do
        local l, d, cmd, sc = tostring(line):match('^([^|]+)|([^|]*)|([%w_:%-]+)|(%a+)$')
        if l and (sc == 'self' or sc == 'other') then out[#out + 1] = { id = 'custom_' .. i, scope = sc, cat = 'people', label = clean(l, 36), desc = clean(d, 100), icon = 'star', kind = 'cmd', cmd = cmd, custom = true } end
    end
    return out
end

local function quickEntry(src, id)
    local q = G.Quick and G.Quick.Spec and G.Quick.Spec(src)
    if not q then return nil end
    for _, x in ipairs(q.entries) do if x.id == id then return x, q end end
end

local function copCtx(src, perm)
    local c = G.Biz and G.Biz.Ctx(src)
    if c and c.biz.kind == 'police' and c.duty and G.Biz.Allowed(c, perm) then return c end
end
-- Police en service (droit cuff) ou staff : peuvent escorter, mettre dans un véhicule, sortir une personne menottée
local function canHandle(src) return (copCtx(src, 'cuff') ~= nil) or P.Has(src, 'staff.menu') end
local carrying, carriedBy = {}, {}   -- porteur -> porté ; porté -> porteur
-- Disponibilité d'une entrée pour (src -> t) : renvoie nil si elle est cachée, true si utilisable, false + raison si grisée
local function avail(src, t, e)
    if cfg('e_' .. e.id, true) == false and not e.custom then return nil end
    local self_ = src == t
    if (e.scope == 'self') ~= self_ then return nil end
    if e.staff then
        if not isStaff(src) or not P.Has(src, e.staff) then return nil end
        if e.kind == 'staff' and e.act ~= 'duty' and G.Staff and PB and PB.Cfg.Get('staff', 'require_duty', true) ~= false and not G.Staff.OnDuty(src) then return false, 'Passe en service staff.' end
        return true
    end
    if e.kind == 'quick' then
        local x = quickEntry(src, e.id)
        if not x then return nil end
        if e.id ~= 'duty' and not (G.Quick and x.needs == 'target') then return nil end
    end
    if e.id == 'quick' and (PB.Cfg.Get('quick', 'f2_menu', true) ~= true or not (G.Quick and G.Quick.Spec(src))) then return nil end
    if e.req == 'employed' and not (G.Biz and G.Biz.Ctx(src)) then return nil end
    if e.req == 'realtor' and (not (G.Realtor and G.Realtor.IsAgent(src)) or (G.NpcOnly and G.NpcOnly('realestate'))) then return nil end
    if e.req == 'dealer' and (not (G.DealerOf and G.DealerOf(src)) or (G.NpcOnly and G.NpcOnly('dealer'))) then return nil end
    if (e.req == 'gang' or e.req == 'gang_tied') and not (G.Tags and G.Tags.Gang and G.Tags.Gang(src)) then return nil end
    if e.req == 'gang_tied' and not (G.IsCuffed and G.IsCuffed(t)) then return nil end
    if e.req == 'bartender' and not (G.Bar and G.Bar.CanServe(src)) then return nil end
    if e.req == 'home' and not (G.Tenues and G.Tenues.InHome(src)) then return nil end
    if e.req == 'cuffed' then
        if not (G.IsCuffed and G.IsCuffed(t)) or not canHandle(src) then return nil end
    end
    if e.id == 'carry_stop' and not (carrying[src] or carriedBy[src]) then return nil end
    if (e.id == 'carry' or e.id == 'carried') and (carrying[src] or carriedBy[src] or carrying[t] or carriedBy[t]) then return nil end
    if e.near and not self_ and dist(src, t) > cfg('act_dist', 3.5) then return false, 'Trop loin.' end
    return true
end

function C.Spec(src, t)
    t = tonumber(t)
    if not t or not G.Get(t) or not created(t) then return nil, 'Personne introuvable.' end
    if t ~= src and dist(src, t) > (tonumber(cfg('range', 15)) or 12) + 4 then return nil, 'Trop loin.' end
    local list = {}
    for _, e in ipairs(CATALOG) do list[#list + 1] = e end
    for _, e in ipairs(customs()) do list[#list + 1] = e end
    local byCat = {}
    for _, e in ipairs(list) do
        local ok, why = avail(src, t, e)
        if ok ~= nil then
            local x = { id = e.id, label = e.label, desc = e.desc, icon = e.icon, danger = e.danger or nil, inputs = e.inputs, disabled = ok == false or nil, why = why }
            if e.id == 'escort' and C.EscortedBy(t) == src then x.label = 'Lâcher' x.desc = 'Relâche la personne escortée.' end
            if e.id == 'duty' then local q = quickEntry(src, 'duty') x.label = (q and q.on) and 'Quitter le service' or 'Prendre le service' end
            if e.id == 's_mute' and G.Staff and G.Staff.IsMuted and G.Staff.IsMuted(t) then x.label = 'Démuter' x.desc = nil x.inputs = nil x.danger = nil end
            byCat[e.cat] = byCat[e.cat] or {}
            table.insert(byCat[e.cat], x)
        end
    end
    local cats = {}
    for _, c in ipairs(CATS) do if byCat[c.id] then cats[#cats + 1] = { id = c.id, label = c.label, icon = c.icon, entries = byCat[c.id] } end end
    -- un joueur ne connaît pas le nom ni l'ID de l'inconnu qu'il vise : seul le staff les voit
    local staffView = P.Has(src, 'staff.menu')
    local head = { id = t, name = (t == src or staffView) and (display(t) .. (staffView and t ~= src and (' (' .. G.Tag(t) .. ')') or '')) or 'Une personne', me = t == src or nil, photo = G.Photos and G.Photos.Of(t) or nil }
    if t == src or staffView then head.uid = G.UidOf and G.UidOf(t) or t end   -- « Nom · ID » (style Nova)
    local j = G.Biz and G.Biz.Job and G.Biz.Job(t)
    if j then head.sub = j.label .. ' · ' .. j.gradeLabel end
    local g = G.Tags and G.Tags.Gang and G.Tags.Gang(t)
    if g then head.gang = g.label head.gc = g.color end
    if isStaff(src) then
        local p = G.Get(t)
        head.lines = { ('Espèces %s · Banque %s'):format(money(p.row.cash), money(p.row.bank)), ('Ping %d ms'):format(GetPlayerPing and GetPlayerPing(t) or 0) }
        if PB.ToBool(p.row.dead) then head.lines[#head.lines + 1] = 'Inconscient' end
    end
    return { target = head, cats = cats }
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

RegisterNetEvent('pb:g:ctx:open', function(t)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 250) then return end
    t = tonumber(t)
    if not t or (t == src and cfg('show_self', true) == false) or (t ~= src and cfg('show_others', true) == false) then return end
    local spec, err = C.Spec(src, t)
    if not spec then G.Notify(src, { type = 'warn', title = 'Menu ALT', text = err or 'Indisponible.' }) return end
    TriggerClientEvent('pb:g:ctx:ui', src, PB.Json({ ev = 'open', spec = spec }))
end)

-- Véhicules -----------------------------------------------------------------------------------------------------------------------------------
local function vehInfo(netId)
    netId = math.floor(tonumber(netId) or 0)
    if netId <= 0 then return nil end
    local ok, ent = pcall(function() return NetworkGetEntityFromNetworkId(netId) end)
    if not ok or not ent or ent == 0 then return nil end
    local ok2, ex = pcall(function() return DoesEntityExist(ent) end)
    if not ok2 or not ex then return nil end
    local plate = ''
    pcall(function() plate = tostring(GetVehicleNumberPlateText(ent) or ''):gsub('^%s+', ''):gsub('%s+$', '') end)
    local c = { x = 0, y = 0, z = 0 }
    pcall(function() c = GetEntityCoords(ent) end)
    return { ent = ent, net = netId, plate = plate, x = c.x, y = c.y, z = c.z }
end

-- Personnes menottées assises dans un véhicule (lecture serveur des sièges, OneSync)
local function cuffedInside(ent)
    local out = {}
    if not (GetPedInVehicleSeat and G.IsCuffed) then return out end
    for seat = -1, 6 do
        local ok, ped = pcall(GetPedInVehicleSeat, ent, seat)
        if ok and ped and ped ~= 0 then
            for id in pairs(G.Players()) do
                local pp = GetPlayerPed and GetPlayerPed(id)
                if pp == ped and G.IsCuffed(id) then out[#out + 1] = id end
            end
        end
    end
    return out
end
local function playerInside(ent)
    if not GetPedInVehicleSeat then return false end
    for seat = -1, 6 do
        local ok, ped = pcall(GetPedInVehicleSeat, ent, seat)
        if ok and ped and ped ~= 0 then for id in pairs(G.Players()) do if GetPlayerPed and GetPlayerPed(id) == ped then return true end end end
    end
    return false
end
-- Joueurs assis dans un véhicule : { id, seat } (siège -1 = conducteur)
function C.Occupants(ent)
    local out = {}
    if not GetPedInVehicleSeat then return out end
    local byPed = {}
    for id in pairs(G.Players()) do local pp = GetPlayerPed and GetPlayerPed(id) if pp and pp ~= 0 then byPed[pp] = id end end
    for seat = -1, 14 do
        local ok, ped = pcall(GetPedInVehicleSeat, ent, seat)
        if ok and ped and ped ~= 0 and byPed[ped] then out[#out + 1] = { id = byPed[ped], seat = seat } end
    end
    return out
end
-- effet sur le véhicule : envoyé au joueur qui le contrôle (sinon au staff, qui en prend le contrôle)
local function vehFx(src, v, act, extra)
    local owner = NetworkGetEntityOwner and NetworkGetEntityOwner(v.ent) or -1
    local d = { act = act, net = v.net }
    for k, val in pairs(extra or {}) do d[k] = val end
    TriggerClientEvent('pb:g:ctx:vehfx', (owner and owner > 0) and owner or src, PB.Json(d))
end
local frozenVeh = {}
local function isFlipped(ent)
    -- GetEntityRoll n'existe pas côté serveur : on lit la rotation (x = tangage, y = roulis)
    local ok, rot = pcall(GetEntityRotation, ent)
    local roll = ok and rot and (rot.y or rot[2]) or nil
    return type(roll) == 'number' and math.abs(roll) > 50
end
-- Dépanneuse : plateau (modèle « flatbed ») -> véhicule chargé dessus (identifiants réseau)
local TOW_MODEL = joaat and joaat('flatbed') or GetHashKey('flatbed')
local towing = {}
C.Towing = towing
local function isBed(ent) local ok, m = pcall(GetEntityModel, ent) return ok and m == TOW_MODEL end
local function coordsOf(ent) local ok, c = pcall(GetEntityCoords, ent) return ok and c or nil end
-- plateau le plus proche du joueur (15 m), libre ou non
local function nearBed(src)
    local ped = GetPlayerPed(src)
    local me = ped and ped ~= 0 and coordsOf(ped)
    if not me or not GetAllVehicles then return nil end
    local best, bd
    for _, e in ipairs(GetAllVehicles()) do
        if isBed(e) then
            local c = coordsOf(e)
            local d = c and #(c - me) or 1e9
            if d < 15.0 and (not bd or d < bd) then best, bd = e, d end
        end
    end
    return best
end
local function impoundNear(ent)
    local c = coordsOf(ent)
    if not c then return nil end
    for _, g in ipairs(DB.q("SELECT * FROM pb_garages WHERE kind = 'impound' AND enabled = 1") or {}) do
        if #(c - vector3(g.x, g.y, g.z)) < 35.0 then return g end
    end
end
PB.Cfg.Define('ctx', { tow_fee = 250, tow_fee_npc = 75 })
function C.VSpec(src, netId)
    local v = vehInfo(netId)
    if not v then return nil, 'Véhicule introuvable.' end
    local d = G.DistTo(src, v.x, v.y, v.z)
    if d > (tonumber(cfg('range', 15)) or 12) + 4 then return nil, 'Trop loin.' end
    local owned = G.Garage and G.Garage.Vehicle(v.plate)
    local lic = G.Get(src).license
    local entries = {}
    for _, e in ipairs(VCAT) do
        if cfg('e_' .. e.id, true) ~= false then
            local x = { id = e.id, label = e.label, icon = e.icon, danger = e.danger, inputs = e.inputs }
            local show = true
            if e.key then
                if not owned then show = false
                elseif not (G.Garage.HasKey(lic, v.plate) or (G.Garage.IsMechanic and G.Garage.IsMechanic(src))) then x.disabled = true x.why = 'Pas de clé.'
                elseif d > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 3 then x.disabled = true x.why = 'Trop loin.' end
            elseif e.escortOnly then
                if not canHandle(src) or #cuffedInside(v.ent) == 0 then show = false
                elseif d > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 3 then x.disabled = true x.why = 'Trop loin.' end
            elseif e.fake then
                local real = G.Garage and G.Garage.Fake and G.Garage.Fake[v.plate]
                if not real or not (G.Garage.HasKey(lic, real) or copCtx(src, 'seize')) then show = false
                elseif d > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 3 then x.disabled = true x.why = 'Trop loin.' end
            elseif e.tow then
                local mech = G.Garage and G.Garage.IsMechanic and G.Garage.IsMechanic(src)
                local bed = isBed(v.ent)
                if not mech then show = false
                elseif e.tow == 'load' then
                    if bed then show = false
                    else
                        local b = nearBed(src)
                        if not b then x.disabled = true x.why = 'Il te faut un plateau (flatbed) à côté.'
                        elseif towing[NetworkGetNetworkIdFromEntity(b)] then x.disabled = true x.why = 'Le plateau est déjà chargé.'
                        elseif #C.Occupants(v.ent) > 0 then x.disabled = true x.why = "Quelqu'un est à bord."
                        else local bc, vc = coordsOf(b), coordsOf(v.ent) if bc and vc and #(bc - vc) > 14.0 then x.disabled = true x.why = 'Approche le plateau du véhicule.' end end
                    end
                elseif e.tow == 'unload' then
                    if not bed or not towing[v.net] then show = false end
                elseif e.tow == 'drop' then
                    if not bed or not towing[v.net] then show = false
                    elseif not impoundNear(v.ent) then x.disabled = true x.why = 'Amène le plateau à la fourrière.' end
                end
            elseif e.flipped then
                if not isFlipped(v.ent) then show = false
                elseif d > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 3 then x.disabled = true x.why = 'Trop loin.' end
            elseif e.lockpick then
                if playerInside(v.ent) then show = false
                elseif d > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 3 then x.disabled = true x.why = 'Trop loin.'
                else
                    local owner = G.Inv and G.Inv.PlayerOwner and G.Inv.PlayerOwner(src)
                    if not owner or G.Inv.Count(owner, 'lockpick') < 1 then x.disabled = true x.why = 'Il te faut un crochet.' end
                end
            elseif e.staff then
                if not isStaff(src) or not P.Has(src, e.staff) then show = false
                elseif PB.Cfg.Get('staff', 'require_duty', true) ~= false and G.Staff and not G.Staff.OnDuty(src) then x.disabled = true x.why = 'Passe en service staff.' end
            elseif e.cop then
                if not copCtx(src, e.cop) then show = false
                elseif not owned then x.disabled = true x.why = 'Véhicule inconnu en ville.'
                elseif d > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 6 then x.disabled = true x.why = 'Trop loin.' end
            end
            if show then entries[#entries + 1] = x end
        end
    end
    local label = owned and owned.label or 'Véhicule'
    local head = { id = v.net, name = label, sub = v.plate ~= '' and v.plate or nil, vehicle = true }
    if owned and (owned.state or '') ~= '' then head.lines = { ({ out = 'Dehors', garage = 'Au garage', impound = 'En fourrière' })[owned.state] or owned.state } end
    -- le staff voit directement qui est dedans (nom + ID)
    if isStaff(src) then
        local occ = C.Occupants(v.ent)
        if #occ > 0 then
            head.lines = head.lines or {}
            local names = {}
            for _, o in ipairs(occ) do names[#names + 1] = display(o.id) .. ' ' .. G.Tag(o.id) end
            head.lines[#head.lines + 1] = 'À bord : ' .. table.concat(names, ', ')
        end
        if owned then
            local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { owned.license })
            if r then head.lines = head.lines or {} head.lines[#head.lines + 1] = 'Propriétaire : ' .. ((r.firstname or '') .. ' ' .. (r.lastname or '')) end
        end
    end
    return { target = head, cats = #entries > 0 and { { id = 'vehicle', label = 'Véhicule', icon = 'car', entries = entries } } or {} }, v
end
-- (v1.2.79) actions refusées aux nouveaux joueurs (server/game/newbie.lua)
local NEWBIE_DENY = { cuff = true, search = true, escort = true, put_veh = true, v_pull = true, v_picklock = true }
function C.VDo(src, netId, id, payload)
    id = tostring(id or '')
    local e = VBYID[id]
    if not e then return false, 'Action indisponible.' end
    local spec, v = C.VSpec(src, netId)
    if not spec then return false, v or 'Véhicule introuvable.' end
    local found
    for _, c in ipairs(spec.cats) do for _, x in ipairs(c.entries) do if x.id == id then found = x end end end
    if not found then return false, 'Action indisponible.' end
    if found.disabled then return false, found.why or 'Action indisponible.' end
    -- (v1.2.79) nouveaux joueurs : rien qui gêne le RP des autres pendant leurs premières minutes
    if G.Newbie and (NEWBIE_DENY[id] or id:sub(1, 4) == 'ill_') then local no, why = G.Newbie.Deny(src) if no then return false, why end end
    local p = type(payload) == 'table' and payload or {}
    if e.staff then
        local tag = v.plate ~= '' and v.plate or ('net ' .. v.net)
        if id == 'sv_ids' then
            local rows = {}
            for _, o in ipairs(C.Occupants(v.ent)) do rows[#rows + 1] = { o.seat == -1 and 'Conducteur' or ('Siège ' .. (o.seat + 2)), display(o.id) .. ' (' .. G.Tag(o.id) .. ')' } end
            if #rows == 0 then rows[1] = { 'À bord', 'Personne' } end
            G.Info(src, { title = 'Occupants · ' .. tag, rows = rows })
            return true
        elseif id == 'sv_eject' then
            local occ = C.Occupants(v.ent)
            if #occ == 0 then return false, 'Personne dans ce véhicule.' end
            for _, o in ipairs(occ) do TriggerClientEvent('pb:g:ctx:leaveveh', o.id) end
            PB.Audit.Log('staff', 'ctx.veh_eject', src, tag, nil, nil, { n = #occ })
            return true, #occ == 1 and 'Occupant sorti du véhicule.' or (#occ .. ' occupants sortis du véhicule.')
        elseif id == 'sv_delete' then
            for _, o in ipairs(C.Occupants(v.ent)) do TriggerClientEvent('pb:g:ctx:leaveveh', o.id) end
            PB.Audit.Log('staff', 'ctx.veh_delete', src, tag, nil, nil, nil)
            SetTimeout(900, function() if DoesEntityExist(v.ent) then DeleteEntity(v.ent) end end)
            return true, 'Véhicule supprimé.'
        elseif id == 'sv_tyres' then
            vehFx(src, v, 'tyres')
            PB.Audit.Log('staff', 'ctx.veh_tyres', src, tag, nil, nil, nil)
            return true, 'Pneus crevés.'
        elseif id == 'sv_repair' then vehFx(src, v, 'repair') return true, 'Véhicule réparé.'
        elseif id == 'sv_unlock' then vehFx(src, v, 'unlock') return true, 'Véhicule déverrouillé.'
        elseif id == 'sv_freeze' then
            frozenVeh[v.net] = not frozenVeh[v.net] or nil
            vehFx(src, v, 'freeze', { on = frozenVeh[v.net] == true })
            return true, frozenVeh[v.net] and 'Véhicule gelé.' or 'Véhicule libéré.'
        end
        return false, 'Action indisponible.'
    end
    if id == 'v_lock' then return G.Garage.ToggleLock(src, v.plate)
    elseif id == 'v_engine' or id == 'v_trunk' then
        TriggerClientEvent('pb:g:ctx:veh', src, PB.Json({ act = id == 'v_engine' and 'engine' or 'trunk', net = v.net }))
        return true
    elseif id == 'v_pull' then
        local list = cuffedInside(v.ent)
        if #list == 0 then return false, 'Personne de menotté dans ce véhicule.' end
        for _, t in ipairs(list) do TriggerClientEvent('pb:g:ctx:leaveveh', t, PB.Json({ net = v.net })) end
        PB.Audit.Log('police', 'ctx.pull', src, v.plate, nil, nil, { n = #list })
        return true, #list == 1 and 'Tu sors la personne menottée du véhicule.' or ('Tu sors %d personnes menottées du véhicule.'):format(#list)
    elseif id == 'v_flip' then
        if not isFlipped(v.ent) then return false, 'Le véhicule est déjà sur ses roues.' end
        TriggerClientEvent('pb:g:ctx:veh', src, PB.Json({ act = 'flip', net = v.net }))
        return true, 'Tu remets le véhicule sur ses roues.'
    elseif id == 'v_picklock' then
        local owner = G.Inv.PlayerOwner(src)
        if G.Inv.Count(owner, 'lockpick') < 1 then return false, 'Il te faut un crochet.' end
        -- (v1.2.59) mini-jeu des fils chez le joueur ; le serveur attend une durée crédible avant de déverrouiller
        local chance = tonumber(cfg('lockpick_chance', 60)) or 60
        C.picks[src] = { net = v.net, plate = v.plate, at = GetGameTimer() }
        TriggerClientEvent('pb:g:ctx:pickgame', src, v.net, chance >= 70 and 3 or (chance >= 40 and 4 or 5), 14)
        return true
    elseif id == 'v_unfake' then
        local ok, real = G.Garage.FakeOff(v.ent, v.plate)
        if not ok then return false, 'Pas de fausse plaque.' end
        local c = copCtx(src, 'seize')
        PB.Audit.Log(c and 'police' or 'crime', 'plate.unfake', src, real, nil, { fake = v.plate })
        if c and G.Biz.Record then
            local ow = G.Garage.Vehicle(real)
            if ow then G.Biz.Record(c, ow.license, '', 'seize', ('Fausse plaque %s retirée du véhicule %s'):format(v.plate, real), 0) end
        end
        return true, ('Vraie plaque remise : %s.'):format(real)
    elseif id == 'v_tow_load' then
        local b = nearBed(src)
        if not b then return false, 'Il te faut un plateau à côté.' end
        local bnet = NetworkGetNetworkIdFromEntity(b)
        towing[bnet] = v.net
        TriggerClientEvent('pb:g:tow', src, PB.Json({ act = 'load', bed = bnet, veh = v.net }))
        PB.Audit.Log('economy', 'tow.load', src, v.plate ~= '' and v.plate or ('net ' .. v.net), nil, nil, nil)
        return true, 'Véhicule chargé sur le plateau.'
    elseif id == 'v_tow_unload' then
        local load = towing[v.net]
        towing[v.net] = nil
        TriggerClientEvent('pb:g:tow', src, PB.Json({ act = 'unload', bed = v.net, veh = load }))
        return true, 'Véhicule déchargé.'
    elseif id == 'v_tow_drop' then
        local load = towing[v.net]
        local g = impoundNear(v.ent)
        if not load or not g then return false, 'Amène le plateau chargé à la fourrière.' end
        local ent = NetworkGetEntityFromNetworkId(load)
        local plate = ''
        pcall(function() plate = tostring(GetVehicleNumberPlateText(ent) or ''):gsub('^%s+', ''):gsub('%s+$', '') end)
        towing[v.net] = nil
        local c = G.Biz and G.Biz.Ctx(src)
        local owned = plate ~= '' and G.Garage.Vehicle(plate)
        local fee
        if owned and owned.state ~= 'impound' then
            G.Garage.Impound(plate, ('Remorqué par %s'):format(c and c.biz.label or 'un dépanneur'))
            fee = tonumber(cfg('tow_fee', 250)) or 0
        else
            if ent and ent ~= 0 and DoesEntityExist(ent) then DeleteEntity(ent) end
            fee = tonumber(cfg('tow_fee_npc', 75)) or 0
        end
        -- prime de remorquage versée par la ville à la caisse de l'entreprise du dépanneur
        if fee > 0 and c and G.Eco then G.Eco.Book('state', -fee, 'Remorquage ' .. (plate ~= '' and plate or 'épave'), G.Get(src).license) G.Eco.Book('biz:' .. c.biz.id, fee, 'Remorquage ' .. (plate ~= '' and plate or 'épave'), G.Get(src).license) end
        PB.Audit.Log('economy', 'tow.drop', src, plate ~= '' and plate or 'épave', nil, nil, { fee = fee })
        TriggerEvent('pb_panel:towed', src, plate, fee)
        return true, fee > 0 and ('Déposé à la fourrière : %s versés à la caisse de l\'entreprise.'):format(money(fee)) or 'Déposé à la fourrière.'
    elseif id == 'v_plate' then G.Info(src, { title = 'Véhicule', rows = { { 'Plaque', v.plate ~= '' and v.plate or 'illisible' } } }) return true
    elseif id == 'v_owner' then
        local ow = G.Garage.Vehicle(v.plate)
        local r = ow and DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { ow.license })
        local name = r and (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) or 'inconnu'
        G.Info(src, { title = 'Fichier véhicule', rows = { { 'Plaque', v.plate }, { 'Propriétaire', name } } }) return true
    elseif id == 'v_impound' then
        local reason = clean(p.reason, 70)
        if #reason < 3 then return false, 'Indique le motif de la saisie.' end
        local c = copCtx(src, 'seize')
        local ow = G.Garage.Vehicle(v.plate)
        if not c or not ow then return false, 'Action indisponible.' end
        if ow.state == 'impound' then return false, 'Ce véhicule est déjà en fourrière.' end
        local ok, err = G.Garage.Impound(v.plate, reason)
        if not ok then return false, err or 'Impossible.' end
        local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { ow.license })
        local name = r and (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) or ''
        if G.Biz.Record then G.Biz.Record(c, ow.license, name, 'seize', ('Véhicule %s saisi : %s'):format(v.plate, reason), 0) end
        for sid, pl in pairs(G.Players()) do if pl.license == ow.license then G.Notify(sid, { type = 'warn', title = c.biz.label, text = ('Ton véhicule %s a été mis en fourrière : %s.'):format(v.plate, reason) }) end end
        TriggerEvent('pb_panel:seized', src, v.plate, reason)
        return true, ('Véhicule %s mis en fourrière.'):format(v.plate)
    end
    return false, 'Action indisponible.'
end
RegisterNetEvent('pb:g:ctx:openv', function(netId)
    local src = source
    if not cfg('enabled', true) or cfg('show_vehicles', true) == false or not usable(src) or not throttle(src, 250) then return end
    local spec, err = C.VSpec(src, netId)
    if not spec then G.Notify(src, { type = 'warn', title = 'Menu ALT', text = err or 'Indisponible.' }) return end
    TriggerClientEvent('pb:g:ctx:ui', src, PB.Json({ ev = 'open', spec = spec, kind = 'v' }))
end)
C.picks = {}
AddEventHandler('playerDropped', function() C.picks[source] = nil end)
RegisterNetEvent('pb:g:ctx:pickdone', function(ok, cancelled)
    local src = source
    local p = C.picks[src]
    C.picks[src] = nil
    if not p or not usable(src) then return end
    local owner = G.Inv.PlayerOwner(src)
    local ent = NetworkGetEntityFromNetworkId(p.net)
    if cancelled or not ent or ent == 0 or not DoesEntityExist(ent) then return end
    local ec = GetEntityCoords(ent)
    if G.DistTo(src, ec.x, ec.y, ec.z) > 12.0 then return end
    -- moins de 2 s pour relier les fils : pas un joueur
    ok = ok == true and GetGameTimer() - p.at >= 2000 and G.Inv.Count(owner, 'lockpick') > 0
    local broke = false
    if not ok and math.random(100) <= (tonumber(cfg('lockpick_break', 25)) or 25) then G.Inv.Remove(owner, 'lockpick', 1) broke = true end
    PB.Audit.Log('crime', 'ctx.picklock', src, p.plate ~= '' and p.plate or ('net ' .. p.net), nil, nil, { ok = ok, broke = broke })
    if ok then
        TriggerClientEvent('pb:g:ctx:veh', src, PB.Json({ act = 'unlock', net = p.net }))
        if p.plate ~= '' and G.Garage and G.Garage.AllowStolen then G.Garage.AllowStolen(src, p.plate) end
        TriggerEvent('pb_panel:picklock', src, p.plate)
        G.Notify(src, { type = 'success', title = 'Crochetage', text = 'La serrure cède : le véhicule est ouvert et démarre sans clé.' })
    else
        G.Notify(src, { type = 'error', title = 'Crochetage', text = broke and 'Le crochet casse. La serrure tient bon.' or 'Raté. Réessaie.' })
    end
end)
PB.OnReady(function()
    -- le crochet s'utilise aussi depuis le sac, sur le véhicule le plus proche
    if G.Inv and G.Inv.RegisterUsable then G.Inv.RegisterUsable('lockpick', function(src) TriggerClientEvent('pb:g:ctx:pickuse', src) return true, nil, true end) end
end)
RegisterNetEvent('pb:g:ctx:actv', function(netId, id, payload)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 300) then return end
    local ok, msg = C.VDo(src, netId, id, payload)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Menu ALT', text = tostring(msg) }) end
    if ok and msg and PB.Cfg.Get('me3d', 'auto_ctx', true) and G.Me then G.Me(src, '** ' .. tostring(msg):gsub('%.$', '') .. ' **') end
    TriggerClientEvent('pb:g:ctx:ui', src, PB.Json({ ev = 'done', ok = ok and true or false }))
end)

-- Portes (staff) : le client ne voit les portes en ALT que si le serveur le dit ; le clic est relayé à wb_portes, qui vérifie sa permission
local function doorRes() return GetResourceState and GetResourceState('wb_portes') == 'started' end
RegisterNetEvent('pb:g:ctx:caps', function()
    local src = source
    if not throttle(src, 1000) then return end
    TriggerClientEvent('pb:g:ctx:caps', src, (doorRes() and isStaff(src) and P.Has(src, 'wb_portes.edit')) and true or false,
        (P.Has(src, 'staff.props') and (not (G.Staff and G.Staff.OnDuty) or PB.Cfg.Get('staff', 'require_duty', true) == false or G.Staff.OnDuty(src))) and true or false)
end)
RegisterNetEvent('pb:g:ctx:door', function(d)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 400) or type(d) ~= 'table' then return end
    if not (doorRes() and isStaff(src) and P.Has(src, 'wb_portes.edit')) then return end
    local x, y, z, model = tonumber(d.x), tonumber(d.y), tonumber(d.z), math.floor(tonumber(d.model) or 0)
    if not (x and y and z) or model == 0 or G.DistTo(src, x, y, z) > 32.0 then return end
    TriggerEvent('pb_panel:ctxDoor', src, { model = model, x = x, y = y, z = z })
end)

-- Objets du décor (distributeurs, etc.) : la liste vient du panel ; la position est celle que lit le client, donc seules des commandes sans risque sont proposées
function C.ObjSpec(idx)
    local o = (cfg('objects', {}) or {})[math.floor(tonumber(idx) or 0)]
    if not o then return nil, 'Objet inconnu.' end
    return { target = { id = idx, name = o.label, object = true }, cats = { { id = 'object', label = o.label, icon = o.icon or 'star', entries = { { id = 'o_use', label = 'Utiliser', icon = o.icon or 'star' } } } } }, o
end
RegisterNetEvent('pb:g:ctx:openo', function(idx)
    local src = source
    if not cfg('enabled', true) or cfg('show_objects', true) == false or not usable(src) or not throttle(src, 250) then return end
    local spec = C.ObjSpec(idx)
    if not spec then return end
    TriggerClientEvent('pb:g:ctx:ui', src, PB.Json({ ev = 'open', spec = spec, kind = 'o' }))
end)
RegisterNetEvent('pb:g:ctx:acto', function(idx, id)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 300) then return end
    local spec, o = C.ObjSpec(idx)
    if spec and id == 'o_use' and tostring(o.cmd):match('^[%w_:%-]+$') then TriggerClientEvent('pb:g:ctx:run', src, PB.Json({ kind = 'cmd', v = o.cmd })) end
    TriggerClientEvent('pb:g:ctx:ui', src, PB.Json({ ev = 'done', ok = spec ~= nil }))
end)

-- Liste des joueurs cliquables (distance seulement) : le client projette les positions ; ici on ne donne que ce qui est autorisé
function C.Hotspots(src)
    local out = {}
    for id, p in pairs(G.Players()) do
        if id ~= src and PB.ToBool(p.row.created) and dist(src, id) <= (tonumber(cfg('range', 15)) or 12) then out[#out + 1] = id end
    end
    return out
end

local reportLast = {}
local H = {}
C.H = H
H.re_list = function(src)
    if not G.Realtor.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    TriggerClientEvent('pb:g:realtor:menu', src, PB.Json(G.Realtor.Tiers()))
    return true
end
H.re_unlist = function(src) return G.Realtor.Unlist(src) end
H.re_visit = function(src, t) return G.Realtor.Visit(src, t) end
H.re_keys = function(src, t) return G.Realtor.KeysStart(src, t) end
H.dl_test = function(src, t) return G.DealerMenu(src, t, 'test') end
H.dl_sell = function(src, t) return G.DealerMenu(src, t, 'sell') end
for _, k in ipairs({ 'tie', 'untie', 'escort', 'put_veh', 'pull_veh', 'search', 'hood', 'handsup' }) do
    H['ill_' .. k] = function(src, t)
        if not G.GangMenu or not G.GangMenu.Do then return false, 'Indisponible.' end
        return G.GangMenu.Do(src, k, { id = t })
    end
end
for _, k in ipairs({ 'gps_hq', 'stash', 'vault_in' }) do
    H['org_' .. k] = function(src, _, p)
        if not G.GangMenu or not G.GangMenu.Do then return false, 'Indisponible.' end
        return G.GangMenu.Do(src, k, p or {})
    end
end
H.wallet = function(src) local p = G.Get(src) G.Info(src, { title = 'Mon argent', rows = { { 'Espèces', money(p.row.cash) }, { 'Banque', money(p.row.bank) } } }) return true end
-- Badge d'employé : carte aux couleurs de l'entreprise (nom, grade, matricule, en service ou non), vue par la personne en face
local function badgeOf(src)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c then return nil end
    local lic = tostring(c.license or '')
    local h = 0
    for i = 1, #lic do h = (h * 31 + lic:byte(i)) % 1000000 end
    local col = tostring(c.biz.color or '')
    return { biz = c.biz.label, color = col:match('^#%x%x%x%x%x%x$') and col or '#2f86f6', name = display(src), grade = c.grade and c.grade.label or '', boss = c.boss or nil,
        number = ('%s-%06d'):format(tostring(c.biz.id):upper():sub(1, 4), h), duty = c.duty == true, since = tonumber(c.member and c.member.hired_at) or 0 }
end
H.show_badge = function(src, t)
    local b = badgeOf(src)
    if not b then return false, 'Tu n\'as pas d\'emploi.' end
    TriggerClientEvent('pb:g:badge', t, PB.Json(b))
    PB.Audit.Log('police', 'ctx.badge', src, display(t) .. ' ' .. G.Tag(t), nil, nil, nil)
    return true, 'Tu montres ton badge à ' .. display(t) .. '.'
end
H.my_badge = function(src)
    local b = badgeOf(src)
    if not b then return false, 'Tu n\'as pas d\'emploi.' end
    TriggerClientEvent('pb:g:badge', src, PB.Json(b))
    return true
end
H.show_id = function(src, t)
    local i = G.Identity(src) or {}
    G.Info(t, { title = 'Papiers de ' .. display(src), rows = { { 'Nom', display(src) }, { 'Né(e) le', clean(i.dob, 12) }, { 'Nationalité', clean(i.nationality, 24) }, { 'Taille', tostring(tonumber(i.height) or '?') .. ' cm' } } })
    return true, 'Tu as montré tes papiers à ' .. display(t) .. '.'
end
H.bar_serve = function(src, t)
    if not G.Bar then return false, 'Indisponible.' end
    local ok, why = G.Bar.ServeMenu(src, t)
    if not ok then return false, why end
    return true
end
H.give_cash = function(src, t, p)
    local a = math.floor(tonumber(p.amount) or 0)
    local max = tonumber(cfg('max_give', 5000)) or 5000
    if a <= 0 then return false, 'Montant invalide.' end
    if a > max then return false, ('Maximum %s par don.'):format(money(max)) end
    if not G.RemoveMoney(src, 'cash', a) then return false, "Tu n'as pas assez d'espèces." end
    G.AddMoney(t, 'cash', a, 'Don entre joueurs')
    PB.Audit.Log('economie', 'ctx.give_cash', src, display(t) .. ' ' .. G.Tag(t), nil, nil, { amount = a })
    G.Notify(t, { type = 'success', title = 'Argent reçu', text = display(src) .. ' te donne ' .. money(a) .. '.' })
    return true, ('Tu as donné %s à %s.'):format(money(a), display(t))
end
H.report = function(src, t, p)
    local reason = clean(p.reason, 160)
    if #reason < 5 then return false, 'Décris le problème (5 caractères minimum).' end
    local now = os.time()
    if reportLast[src] and now - reportLast[src] < (PB.Cfg.Get('staff', 'report_cooldown', 60) or 60) then return false, 'Attends un peu avant un nouveau signalement.' end
    reportLast[src] = now
    local txt = ('Signalement de %s (%s) : %s'):format(display(t), G.Tag(t), reason)
    DB.insert('INSERT INTO pb_reports (license, name, text, status, created) VALUES (?, ?, ?, ?, ?)', { G.Get(src).license, display(src), txt, 'open', now })
    for s in pairs(G.Players()) do
        if G.Staff and G.Staff.OnDuty(s) and P.Has(s, 'staff.reports') then G.Notify(s, { type = 'warn', title = 'Nouveau signalement', text = display(src) .. ' (' .. G.Tag(src) .. ') : ' .. txt }) end
    end
    return true, "Ton signalement a été transmis à l'équipe."
end
H.escort = function(src, t)
    if escorts[t] == src then stopEscort(t) return true, 'Tu lâches ' .. display(t) .. '.' end
    if escorts[t] then return false, 'Cette personne est déjà escortée.' end
    if escortOf[src] then return false, 'Tu escortes déjà quelqu\'un : lâche-le d\'abord.' end
    if not (G.IsCuffed and G.IsCuffed(t)) then return false, "La personne n'est pas menottée." end
    escorts[t], escortOf[src] = src, t
    TriggerClientEvent('pb:g:ctx:escort', t, PB.Json({ on = true, by = src }))
    TriggerEvent('pb_panel:gangBusy', src)
    PB.Audit.Log('police', 'ctx.escort', src, display(t) .. ' ' .. G.Tag(t), nil, nil, nil)
    return true, 'Tu escortes ' .. display(t) .. '.'
end
H.put_veh = function(src, t)
    if not (G.IsCuffed and G.IsCuffed(t)) then return false, "La personne n'est pas menottée." end
    pendingVeh[t] = src
    TriggerClientEvent('pb:g:ctx:intoveh', t, PB.Json({ by = src }))
    PB.Audit.Log('police', 'ctx.put_veh', src, display(t) .. ' ' .. G.Tag(t), nil, nil, nil)
    return true, 'Tu mets ' .. display(t) .. ' dans le véhicule…'
end
-- aussi utilisés par le menu F6 de la police (server/game/police.lua)
C.Escort, C.PutVeh = H.escort, H.put_veh
RegisterNetEvent('pb:g:ctx:intovehres', function(ok)
    local t = source
    local by = pendingVeh[t]
    pendingVeh[t] = nil
    if not by then return end
    if ok == true then stopEscort(t) end
    G.Notify(by, { type = ok == true and 'success' or 'warn', title = 'Menu ALT', text = ok == true and (display(t) .. ' est dans le véhicule.') or 'Aucun véhicule libre à proximité.' })
end)
AddEventHandler('playerDropped', function() reportLast[source] = nil end)


-- Gestes à deux avec accord (Y / N) ------------------------------------------------------------------------------------------------------
local invites = {}
local PAIR = { check = 'Checker', handshake = 'Serrer la main', hug = 'Faire un câlin', carry = 'Te porter', carried = 'Se faire porter par toi' }
local PAIR_TXT = { check = 'veut te checker', handshake = 'veut te serrer la main', hug = 'veut te faire un câlin', carry = 'veut te porter', carried = 'te demande de le porter' }
PAIR.highfive, PAIR_TXT.highfive = "Taper dans la main", "veut taper dans ta main"
PAIR.brohug, PAIR_TXT.brohug = "Accolade", "veut te faire une accolade"
PAIR.backslap, PAIR_TXT.backslap = "Tape dans le dos", "veut te taper dans le dos"
PAIR.manlyshake, PAIR_TXT.manlyshake = "Poignée de main virile", "veut te serrer la main (virile)"
PAIR.kiss, PAIR_TXT.kiss = "Faire la bise", "veut te faire la bise"
PAIR.give, PAIR_TXT.give = "Remettre quelque chose", "veut te remettre quelque chose"
PAIR.slap, PAIR_TXT.slap = "Gifler (RP)", "veut te gifler (RP)"
PAIR.headbutt, PAIR_TXT.headbutt = "Coup de tête (RP)", "veut te mettre un coup de tête (RP)"

local function stopCarry(who, why)
    local a, b = carrying[who] and who or carriedBy[who], carrying[who] or who
    if not carrying[a or 0] then return end
    local carrier, carried = a, carrying[a]
    carrying[carrier], carriedBy[carried] = nil, nil
    for _, id in ipairs({ carrier, carried }) do
        if G.Get(id) then
            TriggerClientEvent('pb:g:ctx:carry', id, PB.Json({ on = false }))
            if why then G.Notify(id, { type = 'info', title = 'Portage', text = why }) end
        end
    end
end
C.StopCarry = stopCarry
local function startPair(kind, from, to)
    if kind == 'carry' or kind == 'carried' then
        local carrier, carried = from, to
        if kind == 'carried' then carrier, carried = to, from end
        if carrying[carrier] or carriedBy[carrier] or carrying[carried] or carriedBy[carried] then return end
        carrying[carrier], carriedBy[carried] = carried, carrier
        TriggerClientEvent('pb:g:ctx:carry', carrier, PB.Json({ on = true, carrier = true, other = carried }))
        TriggerClientEvent('pb:g:ctx:carry', carried, PB.Json({ on = true, carrier = false, other = carrier }))
        G.Notify(carrier, { type = 'info', title = 'Portage', text = 'Tu portes ' .. display(carried) .. '. Appuie sur X pour le lâcher.' })
        G.Notify(carried, { type = 'info', title = 'Portage', text = display(carrier) .. ' te porte. Appuie sur X pour descendre.' })
        return
    end
    TriggerClientEvent('pb:g:ctx:pair', from, PB.Json({ kind = kind, role = 'a', with = to }))
    TriggerClientEvent('pb:g:ctx:pair', to, PB.Json({ kind = kind, role = 'b', with = from }))
end
local function invite(src, t, kind)
    if src == t then return false, 'Choisis une autre personne.' end
    if invites[t] and invites[t].exp > os.time() and invites[t].from ~= src then return false, 'Cette personne a déjà une demande en attente.' end
    local secs = math.max(5, math.min(60, math.floor(tonumber(cfg('invite_secs', 15)) or 15)))
    invites[t] = { from = src, kind = kind, exp = os.time() + secs }
    local txt = PAIR_TXT[kind]
    TriggerClientEvent('pb:g:ctx:invite', t, PB.Json({ name = display(src), text = txt, secs = secs }))
    return true, 'Demande envoyée à ' .. display(t) .. '.'
end
RegisterNetEvent('pb:g:ctx:inviteans', function(yes)
    local t = source
    local iv = invites[t]
    invites[t] = nil
    if not iv or iv.exp < os.time() then return end
    local s = iv.from
    if not G.Get(s) or not usable(s) or not usable(t) then return end
    if yes ~= true then G.Notify(s, { type = 'warn', title = display(t), text = 'a refusé.' }) return end
    if dist(s, t) > (tonumber(cfg('act_dist', 3.5)) or 3.5) + 2 then G.Notify(s, { type = 'warn', title = 'Menu ALT', text = 'Vous êtes trop éloignés.' }) return end
    startPair(iv.kind, s, t)
end)
RegisterNetEvent('pb:g:ctx:carrystop', function() local src = source if carrying[src] or carriedBy[src] then stopCarry(src, 'Portage terminé.') end end)
for k in pairs(PAIR) do
    H[k] = function(src, t) return invite(src, t, k) end
end
C.PAIR = PAIR
H.carry_stop = function(src) stopCarry(src, 'Portage terminé.') return true end
local function copyId(src, id) TriggerClientEvent('pb:g:ctx:run', src, PB.Json({ kind = 'copy', v = tostring(id) })) end
H.copy_id = function(src, t) local u = G.UidOf(t) or t copyId(src, u) return true, ('ID de %s copié : %d.'):format(display(t), u) end
H.copy_my_id = function(src) local u = G.UidOf(src) or src copyId(src, u) return true, ('Ton ID est copié : %d.'):format(u) end
AddEventHandler('playerDropped', function() local s = source invites[s] = nil if carrying[s] or carriedBy[s] then stopCarry(s, 'La personne est partie.') end end)
CreateThread(function()
    while true do
        Wait(2000)
        for carrier, carried in pairs(carrying) do
            if not G.Get(carrier) or not G.Get(carried) or not usable(carrier) or not usable(carried) then stopCarry(carrier, 'Portage interrompu.') end
        end
    end
end)

function C.Do(src, t, id, payload)
    id = tostring(id or '')
    t = tonumber(t)
    local e = BYID[id]
    if not e then for _, c in ipairs(customs()) do if c.id == id then e = c end end end
    if not e or not t then return false, 'Action indisponible.' end
    local spec, err = C.Spec(src, t)
    if not spec then return false, err end
    local found
    for _, c in ipairs(spec.cats) do for _, x in ipairs(c.entries) do if x.id == id then found = x end end end
    if not found then return false, 'Action indisponible.' end
    if found.disabled then return false, found.why or 'Action indisponible.' end
    -- (v1.2.79) nouveaux joueurs : rien qui gêne le RP des autres pendant leurs premières minutes
    if G.Newbie and (NEWBIE_DENY[id] or id:sub(1, 4) == 'ill_') then local no, why = G.Newbie.Deny(src) if no then return false, why end end
    local p = type(payload) == 'table' and payload or {}
    local cp = { id = t, amount = tonumber(p.amount), reason = clean(p.reason, 160), text = clean(p.text, 250), minutes = tonumber(p.minutes), model = clean(p.model, 32) }
    for _, inp in ipairs(found.inputs or {}) do
        local v = cp[inp.k]
        if inp.number then if v == nil then return false, 'Valeur manquante.' end elseif v == nil or v == '' then return false, 'Valeur manquante.' end
    end
    if e.kind == 'cmd' then
        TriggerClientEvent('pb:g:ctx:run', src, PB.Json({ kind = 'cmd', v = e.cmd, target = e.scope == 'other' and t or nil }))
        return true
    elseif e.kind == 'anim' then
        TriggerClientEvent('pb:g:ctx:run', src, PB.Json({ kind = 'anim', v = e.v }))
        return true
    elseif e.kind == 'gest' then
        TriggerClientEvent('pb:g:ctx:run', src, PB.Json({ kind = 'gest', v = e.v }))
        return true
    elseif e.kind == 'quick' then
        local on
        if e.id == 'duty' then local q = quickEntry(src, 'duty') on = not (q and q.on) end
        cp.on = on
        return G.Quick.Do(src, e.id, cp)
    elseif e.kind == 'staff' then
        if e.act == 'duty' then cp.on = not G.Staff.OnDuty(src) end
        return G.Staff.Do(src, e.act, cp)
    end
    local fn = H[e.id]
    if not fn then return false, 'Action indisponible.' end
    return fn(src, t, cp)
end

RegisterNetEvent('pb:g:ctx:act', function(t, id, payload)
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 300) then return end
    local ok, msg = C.Do(src, t, id, payload)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Menu ALT', text = tostring(msg) }) end
    if ok and msg and cfg('auto_ctx_me', true) and PB.Cfg.Get('me3d', 'auto_ctx', true) and G.Me then G.Me(src, '** ' .. tostring(msg):gsub('%.$', '') .. ' **') end
    TriggerClientEvent('pb:g:ctx:ui', src, PB.Json({ ev = 'done', ok = ok and true or false }))
end)

-- Réglages ----------------------------------------------------------------------------------------------------------------------------------
local general = Form.Cfg({ ns = 'ctx', id = 'general', title = 'Menu ALT', perm = 'ctx.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Menu ALT actif', default = true },
    { k = 'style', type = 'select', label = 'Version du menu', default = 'nova', opts = { { 'nova', 'Shadow Studio V2 (Nom · ID, icônes fines)' } } },
    { k = 'invite_secs', type = 'number', label = 'Temps pour répondre Y / N à un geste à deux (s)', default = 15, min = 5, max = 60 },
    { k = 'key', type = 'text', label = 'Touche (maintenue)', default = 'LMENU', maxlen = 12, pattern = '^[%w_]+$', hint = 'LMENU = ALT gauche. Chaque joueur peut la changer dans les raccourcis de FiveM. Valable au prochain redémarrage.' },
    { k = 'show_self', type = 'toggle', label = 'Cliquer sur soi-même', default = true }, { k = 'show_others', type = 'toggle', label = 'Cliquer sur les autres', default = true },
    { k = 'range', type = 'number', label = 'Distance pour voir les personnes (m)', default = 15, min = 3, max = 40 },
    { k = 'act_dist', type = 'number', label = "Distance pour agir (m)", default = 3.5, min = 1, max = 10, hint = 'Donner, montrer ses papiers, menotter… exigent d’être à cette distance.' },
    { k = 'max_give', type = 'number', label = "Don d'argent maximum", default = 5000, min = 0, max = 1000000 },
    { k = 'staff_extra', type = 'toggle', label = 'Le staff voit plus (catégorie Staff et infos)', default = true },
    { k = 'walls', type = 'toggle', label = 'Points cliquables à travers les murs', default = false, hint = "Par défaut seules les personnes, véhicules et objets en vue sont cliquables. La portée reste limitée par la distance." },
} })

local styleForm = Form.Cfg({ ns = 'ctx', id = 'style', title = 'Menu contextuel (touche ALT)', perm = 'ctx.edit', fields = {
    { k = 'style', type = 'select', label = 'Version du menu', default = 'nova', opts = { { 'nova', 'Shadow Studio V2 (Nom · ID, icônes fines)' } },
      hint = "Un seul style pour le menu ALT : Shadow Studio V2." } } })
PB.Interface = PB.Interface or {}
PB.Interface.Versions = PB.Interface.Versions or {}
table.insert(PB.Interface.Versions, function(ctx)
    return { styleForm(ctx),
        { type = 'gpreview', kind = 'ctx', demo = 'person', style = 'nova', title = 'Shadow Studio V2', cfg = PB.Cfg.All('menus') } }
end)

local function toggles(scope, staff)
    local f = {}
    for _, e in ipairs(CATALOG) do
        if e.scope == scope and (e.staff ~= nil) == staff then f[#f + 1] = { k = 'e_' .. e.id, type = 'toggle', label = e.label .. (e.desc and (' — ' .. e.desc) or ''), default = true } end
    end
    return f
end
local selfForm = Form.Cfg({ ns = 'ctx', id = 'self', title = 'Quand je clique sur moi', perm = 'ctx.edit', cols = 2, fields = toggles('self', false) })
local otherForm = Form.Cfg({ ns = 'ctx', id = 'other', title = 'Quand je clique sur quelqu\'un', perm = 'ctx.edit', cols = 2, fields = toggles('other', false) })
local vehForm = Form.Cfg({ ns = 'ctx', id = 'vehicles', title = 'Quand je clique sur un véhicule', perm = 'ctx.edit', cols = 2, fields = (function()
    local f = { { k = 'show_vehicles', type = 'toggle', label = 'Véhicules cliquables', default = true } }
    for _, e in ipairs(VCAT) do f[#f + 1] = { k = 'e_' .. e.id, type = 'toggle', label = e.label .. (e.cop and ' (police en service)' or e.staff and ' (staff en service)' or ''), default = true } end
    return f
end)() })
local objForm = Form.Cfg({ ns = 'ctx', id = 'objects', title = 'Objets du décor cliquables', perm = 'ctx.edit', fields = {
    { k = 'show_objects', type = 'toggle', label = 'Objets du décor cliquables', default = true },
    { k = 'objects', type = 'rows', label = 'Objets', default = OBJECTS, wide = true, maxitems = 60,
      hint = "Modèle du jeu (ex. prop_atm_01), nom affiché et commande lancée par « Utiliser » (ex. pb_bank). L'objet est cherché autour du joueur ; le serveur ne peut pas vérifier sa position.",
      cols = { { k = 'model', label = 'Modèle', pattern = '^[%w_]+$', required = true, maxlen = 48, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 30 },
        { k = 'cmd', label = 'Commande', pattern = '^[%w_:%-]+$', required = true, maxlen = 32 }, { k = 'icon', label = 'Icône', pattern = '^[%w_]*$', maxlen = 16 } } } } })
local staffSelf = Form.Cfg({ ns = 'ctx', id = 'staff_self', title = 'Staff : sur soi', perm = 'ctx.edit', cols = 2, fields = toggles('self', true) })
local staffOther = Form.Cfg({ ns = 'ctx', id = 'staff_other', title = 'Staff : sur une autre personne', perm = 'ctx.edit', cols = 2, fields = toggles('other', true) })
local customForm = Form.Cfg({ ns = 'ctx', id = 'custom', title = 'Entrées personnalisées', perm = 'ctx.edit', fields = {
    { k = 'custom_anims', type = 'list', label = 'Animations du menu Animations : libellé|dictionnaire|clip|drapeau', default = {}, maxitems = 30, maxlen = 120, pattern = '^[^|]+|[%w_@%-%.]+|[%w_%-%.]+|%d+$', wide = true, hint = 'Exemple : Danse du robot|anim@amb@nightclub@mini@dance@dance_solo@male@var_a@|high_center|1. Le drapeau est celui de TaskPlayAnim (1 = boucle, 49 = haut du corps).' },
    { k = 'custom', type = 'list', label = 'Libellé|description|commande|self ou other', default = {}, maxitems = 10, maxlen = 200, pattern = '^[^|]+|[^|]*|[%w_:%-]+|%a+$', wide = true,
      hint = "Exemple : Danser|Lance une danse|e_dance|self. Avec « other », l'identifiant de la personne visée est ajouté à la commande." } } })

PB.Module({
    id = 'ctx', label = 'Menu ALT', icon = 'sliders', group = 'Serveur', order = 141, perm = 'ctx.edit', hint = 'Clic sur soi ou sur un joueur',
    caps = function()
        return PB.Capsify({
            { 'Clic sur soi-même et sur les autres', 'ok', 'Maintiens ALT, un point apparaît sur chaque personne proche ; clique pour ouvrir son menu.' },
            { 'Catégories et entrées réglables', 'ok', 'Chaque entrée peut être masquée ; tu peux en ajouter qui lancent une commande de ton serveur.' },
            { 'Staff : plus d\'informations et d\'actions', 'ok', "Catégorie Staff, argent, ping et état de la personne, selon les permissions et le service." },
            { 'Actions refusées côté serveur', 'ok', 'La liste est recomposée à chaque clic : distance, métier et permissions sont revérifiés.' },
            { 'Cliquer à travers les murs', 'ok', "Réglage « à travers les murs » : désactivé par défaut. Jamais testé dans un vrai FiveM ici." },
            { 'Cliquer sur un véhicule', 'ok', 'Verrouiller, moteur, coffre (avec la clé), lire la plaque, et pour la police en service : propriétaire et fourrière. Le serveur relit la plaque et la position du véhicule.' },
            { 'Cliquer sur un objet du décor', 'ok', 'Liste réglable (distributeurs…) qui lance une commande. Le serveur ne peut pas lire la position des objets du décor : ne propose que des commandes sans danger.' },
        })
    end,
    doc = "## Menu ALT\nLe joueur **maintient ALT** : la souris apparaît, un point s'affiche sur lui et sur les personnes proches. Un clic ouvre un petit menu à côté d'elle.\n\n- Sur soi : inventaire, téléphone, mon espace (finances, entreprise), animations, prise de service…\n- Sur quelqu'un : montrer ses papiers, donner de l'argent, signaler, et les actions du métier (menotter, fouiller, facturer, réanimer).\n- Sur un véhicule : verrouiller, moteur, coffre, plaque ; la police en service voit le propriétaire et peut mettre en fourrière.\n- Sur un objet du décor (distributeur…) : « Utiliser » lance la commande réglée.\n- Staff : une catégorie en plus, selon ses permissions et son service.\n\nLe style (couleurs, transparence, arrondi) reprend celui des **Menus**.",
    view = function(ctx)
        return { tabs = {
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return {
                { type = 'gpreview', kind = 'ctx', demo = 'person', style = 'nova', title = 'Sur une personne (exemple vu par le staff)', cfg = PB.Cfg.All('menus') },
                { type = 'gpreview', kind = 'ctx', demo = 'vehicle', style = 'nova', title = 'Sur un véhicule (exemple vu par un policier en service)', cfg = PB.Cfg.All('menus') },
                { type = 'gpreview', kind = 'ctx', demo = 'object', style = 'nova', title = 'Sur un objet du décor', cfg = PB.Cfg.All('menus') } } end },
            { id = 'general', label = 'Réglages', icon = 'sliders', build = function() return { general(ctx) } end },
            { id = 'self', label = 'Sur moi', icon = 'user', build = function() return { selfForm(ctx), staffSelf(ctx) } end },
            { id = 'other', label = 'Sur les autres', icon = 'users', build = function() return { otherForm(ctx), staffOther(ctx) } end },
            { id = 'vehicles', label = 'Véhicules', icon = 'car', build = function() return { vehForm(ctx) } end },
            { id = 'objects', label = 'Objets', icon = 'cube', build = function() return { objForm(ctx) } end },
            { id = 'custom', label = 'Personnalisé', icon = 'star', build = function() return { customForm(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('menu ALT', function(R)
    for _, g in ipairs(C.GEST) do R.check(g[2]:match('^[%w_]+$') ~= nil and g[3] ~= '', 'geste « ' .. g[2] .. ' »', 'clé ou libellé invalide') end
    for _, id in ipairs({ 'carry', 'carried', 'check', 'copy_id', 'copy_my_id', 'carry_stop', 'g_surrender', 'g_kneel', 'g_headhands' }) do R.check(BYID[id] ~= nil, 'entrée « ' .. id .. ' »', 'absente du catalogue') end
    for _, e in ipairs(CATALOG) do
        if e.kind == 'staff' then R.check(G.Staff and G.Staff.ActInfo and G.Staff.ActInfo(e.act) ~= nil, 'entrée staff « ' .. e.id .. ' »', "l'action n'existe plus dans le menu staff") end
        if e.kind == 'quick' and e.id ~= 'duty' and e.id ~= 'permit' and e.id ~= 'permit_revoke' then R.check(G.Quick and G.Quick.ALLOWED[e.id], 'entrée métier « ' .. e.id .. ' »', "l'action n'est plus autorisée dans le menu F2") end
        if e.kind == 'cmd' then R.check(tostring(e.cmd):match('^[%w_:%-]+$') ~= nil, 'commande « ' .. e.id .. ' »', 'commande invalide') end
    end
end)

-- 1.2.1 : une seule fois, le menu ALT passe au style « simple » (boîte bleu nuit) ; on peut revenir à un autre style dans le panel ensuite
PB.OnReady(function()
    -- v1.2.37 : le menu ALT n'a plus qu'un style (Shadow Studio V2)
    if tostring(PB.Cfg.Get('ctx', 'style', 'nova')) ~= 'nova' then PB.Cfg.Set('ctx', 'style', 'nova', nil, 'Menu ALT : Shadow Studio V2') end
    if PB.Cfg.Get('ctx', 'simple_v1', false) ~= true then PB.Cfg.Set('ctx', 'simple_v1', true, nil, 'Migration') end
end)
