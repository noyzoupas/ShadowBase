-- Menu de mon organisation (touche F7) : un menu « lib » pour les membres d'un gang ou d'une organisation illégale.
-- Ligoter, détacher, escorter, mettre dans un véhicule, fouiller, GPS du QG, coffre, caisse commune, membres en ligne.
-- En bas du menu : toutes les pages de gestion (crypto, classement, territoires, grades…), sans tablette.
-- Le serveur construit les entrées et revérifie chaque action (appartenance, distance, état de la personne).

local G, DB = PB.G, PB.DB
local GM = {}
G.GangMenu = GM
local hooded = {}   -- personnes ligotées qui portent une cagoule
GM.Hooded = hooded

PB.Cfg.Define('gangmenu', { enabled = true, near_dist = 6, tie_dist = 3, need_item = 'rope' })
-- (v1.2.43) la corde était vendue partout mais ne servait à rien : ligoter quelqu'un en utilise une (réglable, vide = aucune)
PB.OnReady(function()
    if PB.Cfg.Get('gangmenu', 'rope_v1', false) == true then return end
    if tostring(PB.Cfg.Get('gangmenu', 'need_item', '') or '') == '' then PB.Cfg.Set('gangmenu', 'need_item', 'rope', nil, 'Ligoter : une corde') end
    PB.Cfg.Set('gangmenu', 'rope_v1', true, nil, 'Migration')
end)
local function cfg(k, d) return PB.Cfg.Get('gangmenu', k, d) end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function display(src) local i = G.Identity and G.Identity(src) if i and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Personne #' .. tostring(src) end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »

-- points de l'organisation posés au Builder (QG, coffre…)
local function pointsOf(gid) return G.Points and G.Points.Of('gang', gid) or {} end
local function pointOf(gid, kind) for _, p in ipairs(pointsOf(gid)) do if p.kind == kind then return p end end end
-- au QG : à côté du QG (sans QG posé : partout)
function GM.AtHq(src)
    local g = gangOf(src)
    if not g then return false end
    local any = false
    for _, p in ipairs(pointsOf(g.id)) do
        if p.kind == 'hq' then
            any = true
            if G.DistTo(src, p.x, p.y, p.z) <= (tonumber(p.radius) or 2.0) + 8 then return true end
        end
    end
    return not any
end

-- personnes proches (nom de personnage : le membre les voit en face de lui)
local function nearby(src)
    local out = {}
    for id, pl in pairs(G.Players()) do
        if id ~= src and PB.ToBool(pl.row.created) and G.DistBetween(src, id) <= cfg('near_dist', 6) then out[#out + 1] = { id = id, name = display(id), tied = (G.IsCuffed and G.IsCuffed(id)) or nil } end
    end
    table.sort(out, function(a, b) return G.DistBetween(src, a.id) < G.DistBetween(src, b.id) end)
    return out
end

function GM.Spec(src)
    if cfg('enabled', true) == false then return nil, 'Le menu des organisations est désactivé.' end
    local g = gangOf(src)
    if not g then return nil, "Tu n'appartiens à aucune organisation." end
    local names = G.Orga and G.Orga.GradeNames and G.Orga.GradeNames(g.id) or {}
    local grade = G.Orga and G.Orga.Grade(src) or 1
    local boss = G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, g.id) == true
    local e = {}
    local function add(x) e[#e + 1] = x end
    add({ type = 'separator', label = 'Sur une personne' })
    add({ id = 'tie', needs = 'target', label = 'Ligoter', desc = 'Attache les mains de la personne choisie (elle doit être à côté de toi). Utilise une corde.', icon = 'lock' })
    add({ id = 'untie', needs = 'target', only = 'tied', label = 'Détacher', desc = 'Libère une personne ligotée.', icon = 'key' })
    add({ id = 'escort', needs = 'target', only = 'tied', label = 'Escorter / lâcher', desc = 'La personne ligotée te suit ; relance pour la lâcher.', icon = 'hand' })
    add({ id = 'put_veh', needs = 'target', only = 'tied', label = 'Mettre dans le véhicule', desc = "Assied la personne ligotée dans le véhicule le plus proche.", icon = 'car' })
    add({ id = 'search', needs = 'target', only = 'tied', label = 'Fouiller', desc = 'Ouvre les poches de la personne ligotée : prends ce que tu veux.', icon = 'search' })
    add({ id = 'pull_veh', needs = 'target', only = 'tied', label = 'Sortir du véhicule', desc = 'Fait descendre la personne ligotée du véhicule où elle est assise.', icon = 'car' })
    add({ id = 'hood', needs = 'target', only = 'tied', label = 'Cagoule : mettre / retirer', desc = "La personne ligotée ne voit plus rien tant qu'elle porte la cagoule.", icon = 'eye' })
    add({ id = 'handsup', needs = 'target', label = 'Braquer : mains en l\'air', desc = 'Arme en main : la personne en face lève les mains (20 s).', icon = 'crosshair' })
    add({ type = 'separator', label = 'Organisation' })
    local hq = pointOf(g.id, 'hq')
    add({ id = 'gps_hq', label = 'GPS : notre QG', desc = hq and 'Met le QG sur ta carte.' or "Le QG n'est pas encore posé (Builder du staff).", icon = 'gps', disabled = hq == nil })
    local st = pointOf(g.id, 'stash')
    add({ id = 'stash', label = "Coffre de l'organisation", desc = st and 'Au point coffre du QG.' or 'Aucun point coffre posé.', icon = 'box', disabled = st == nil })
    add({ id = 'vault_in', label = 'Verser à la caisse commune', desc = 'Tes espèces vont dans la caisse (le chef retire au QG).', icon = 'coins', inputs = { { k = 'amount', label = 'Montant ($)', number = true, maxlen = 8 } } })
    local mem = {}
    for s in pairs(G.Players()) do
        local og = gangOf(s)
        if og and og.id == g.id then mem[#mem + 1] = { label = display(s), right = names[G.Orga and G.Orga.Grade(s) or 1] or '' } end
    end
    table.sort(mem, function(a, b) return a.label < b.label end)
    -- (v1.2.42) véhicules de l'organisation : où ils sont, qui les a sortis, rappel au garage (chef)
    if boss and G.Garage and G.Garage.Fleet then
        local fleet = G.Garage.Fleet('gang', g.id)
        if #fleet > 0 then
            local out = 0 for _, f in ipairs(fleet) do if f.state == 'out' then out = out + 1 end end
            add({ id = 'fleet', type = 'fleet', label = "Véhicules de l'organisation", icon = 'car', right = out .. ' / ' .. #fleet .. ' sortis', items = fleet, desc = 'Où ils sont, qui les a sortis ; rappelle au garage ceux qui sont abandonnés.' })
        end
    end
    add({ id = 'members', type = 'info', label = 'Membres en ligne', right = tostring(#mem), items = mem, icon = 'users' })
    -- (patch 136) plus de pages de gestion dans le F7 : crypto, classement, territoires, grades, caisse… s'ouvrent au QG (Builder)
    local bp = hq
    add({ id = 'gps_boss', label = "Gestion de l'organisation", right = 'Au QG', desc = bp and "Crypto, classement, territoires, labos, contrats, grades, caisse : au QG. Entrée : GPS." or "Le QG n'est pas posé (Builder du staff).", icon = 'lock', disabled = bp == nil })
    return { gang = g.label, color = g.color, grade = names[grade] or '', boss = boss or nil, near = nearby(src), entries = e }
end

local function has(spec, id) for _, x in ipairs(spec.entries) do if x.id == id and not x.disabled then return x end end end
-- personne attachée par une organisation (pas un prisonnier menotté par la police)
local function tiedByGang(tid) return G.IsCuffed(tid) and (not (G.Police and G.Police.CuffKind) or G.Police.CuffKind(tid) == 'gang') end
local POLICE_TIED = 'Menottée par la police : seule la police peut s\'en occuper.'
local function target(src, id)
    local tid = tonumber(id)
    if not tid or tid == src or not G.Get(tid) then return nil, 'Choisis une personne à côté de toi.' end
    if G.DistBetween(src, tid) > cfg('tie_dist', 3) + 1.5 then return nil, 'Cette personne est trop loin.' end
    return tid
end

-- fouille par un membre : accès aux poches d'une personne ligotée, juste à côté
local searchOk = {}   -- membre -> { license, until }
if G.Inv then
    local prevExtra = G.Inv.ExtraAccess
    G.Inv.ExtraAccess = function(src, kind, id)
        if kind == 'p' then
            local s = searchOk[src]
            if s and s.license == id and s.untilT > os.time() then
                for sid, pl in pairs(G.Players()) do
                    if pl.license == id and G.IsCuffed and G.IsCuffed(sid) and G.DistBetween(src, sid) <= cfg('tie_dist', 3) + 2 then return true end
                end
            end
        end
        if prevExtra then return prevExtra(src, kind, id) end
        return false
    end
end
AddEventHandler('playerDropped', function() searchOk[source] = nil end)

local ACT = {}
ACT.fleet = function(src, p)
    local g = gangOf(src)
    if not g or not (G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, g.id)) then return false, 'Réservé au chef.' end
    return G.Garage.FleetAct(src, 'gang', g.id, p.plate, p.act == 'recall' and 'recall' or 'gps')
end
ACT.tie = function(src, p)
    local tid, err = target(src, p.id) if not tid then return false, err end
    if G.IsCuffed(tid) then return false, 'Cette personne est déjà ligotée.' end
    local tp = G.Get(tid)
    if PB.ToBool(tp.row.dead) then return false, 'Cette personne est inconsciente.' end
    local item = tostring(cfg('need_item', 'rope') or '')
    if item ~= '' and G.Inv then
        local o = 'p:' .. G.Get(src).license
        if (G.Inv.Count(o, item) or 0) < 1 or not G.Inv.Remove(o, item, 1) then local d = G.Inv.Def(item) return false, ('Il te faut : %s.'):format(d and d.label or item) end
    end
    G.Police.SetCuffed(tid, true, 'gang')
    G.Notify(tid, { type = 'warn', title = 'Ligoté(e)', text = 'Tu as les mains attachées.' })
    TriggerEvent('pb_panel:cuffed', src, tid, true)
    PB.Audit.Log('police', 'gang.tie', src, display(tid) .. ' ' .. G.Tag(tid), nil, nil, nil)
    return true, display(tid) .. ' est ligoté(e).'
end
ACT.untie = function(src, p)
    local tid, err = target(src, p.id) if not tid then return false, err end
    if not G.IsCuffed(tid) then return false, "Cette personne n'est pas ligotée." end
    if not tiedByGang(tid) then return false, POLICE_TIED end
    G.Police.SetCuffed(tid, false)
    if hooded[tid] then hooded[tid] = nil TriggerClientEvent('pb:g:gang:hood', tid, false) end
    G.Notify(tid, { type = 'info', title = 'Libéré(e)', text = 'Tes mains sont libres.' })
    TriggerEvent('pb_panel:cuffed', src, tid, false)
    return true, display(tid) .. ' est détaché(e).'
end
ACT.escort = function(src, p)
    local tid, err = target(src, p.id) if not tid then return false, err end
    if G.IsCuffed(tid) and not tiedByGang(tid) then return false, POLICE_TIED end
    if not (G.Ctx and G.Ctx.Escort) then return false, 'Escorte indisponible.' end
    return G.Ctx.Escort(src, tid)
end
ACT.put_veh = function(src, p)
    local tid = tonumber(p.id)
    if not tid or tid == src or not G.Get(tid) or G.DistBetween(src, tid) > cfg('tie_dist', 3) + 5 then return false, 'Cette personne est trop loin.' end
    if G.IsCuffed(tid) and not tiedByGang(tid) then return false, POLICE_TIED end
    if not (G.Ctx and G.Ctx.PutVeh) then return false, 'Indisponible.' end
    return G.Ctx.PutVeh(src, tid)
end
ACT.search = function(src, p)
    local tid, err = target(src, p.id) if not tid then return false, err end
    if not G.IsCuffed(tid) then return false, "Ligote la personne d'abord." end
    if not tiedByGang(tid) then return false, POLICE_TIED end
    local lic = G.Get(tid).license
    searchOk[src] = { license = lic, untilT = os.time() + 120 }
    G.Notify(tid, { type = 'warn', title = 'Fouille', text = 'On fouille tes poches.' })
    PB.Audit.Log('police', 'gang.search', src, display(tid) .. ' ' .. G.Tag(tid), nil, nil, nil)
    TriggerClientEvent('pb:g:police:search', src, 'p:' .. lic)
    return true, 'Fouille : prends ce que tu veux.'
end
ACT.gps_hq = function(src)
    local g = gangOf(src)
    local hq = g and pointOf(g.id, 'hq')
    if not hq then return false, "Le QG n'est pas posé." end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = hq.x, y = hq.y, label = 'QG' }))
    return true, 'Le QG est sur ta carte.'
end
ACT.stash = function(src)
    local g = gangOf(src)
    local st = g and pointOf(g.id, 'stash')
    if not st then return false, 'Aucun point coffre.' end
    if G.DistTo(src, st.x, st.y, st.z) > (tonumber(st.radius) or 2.0) + 6 then
        TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = st.x, y = st.y, label = 'Coffre' }))
        return false, "Le coffre est au QG : il est sur ta carte."
    end
    return G.Orga.OpenStash(src, false)
end
ACT.vault_in = function(src, p) return G.Orga.Act(src, 'vault_in', { amount = p.amount }) end
ACT.gps_boss = function(src)
    local g = gangOf(src)
    local bp = g and pointOf(g.id, 'hq')
    if not bp then return false, "Le QG n'est pas posé." end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = bp.x, y = bp.y, label = 'QG' }))
    return true, 'Le QG est sur ta carte.'
end
ACT.pull_veh = function(src, p)
    local tid = tonumber(p.id)
    if not tid or tid == src or not G.Get(tid) or G.DistBetween(src, tid) > cfg('tie_dist', 3) + 5 then return false, 'Cette personne est trop loin.' end
    if not G.IsCuffed(tid) then return false, "Ligote la personne d'abord." end
    if not tiedByGang(tid) then return false, POLICE_TIED end
    local veh = GetVehiclePedIsIn(GetPlayerPed(tid), false)
    if not veh or veh == 0 then return false, "Cette personne n'est pas dans un véhicule." end
    TriggerClientEvent('pb:g:ctx:leaveveh', tid, PB.Json({ net = NetworkGetNetworkIdFromEntity(veh) }))
    return true, display(tid) .. ' sort du véhicule.'
end
-- cagoule : la personne ligotée ne voit plus rien (retirée si on la détache)
ACT.hood = function(src, p)
    local tid, err = target(src, p.id) if not tid then return false, err end
    if not G.IsCuffed(tid) then return false, "Ligote la personne d'abord." end
    if not tiedByGang(tid) then return false, POLICE_TIED end
    hooded[tid] = not hooded[tid] or nil
    TriggerClientEvent('pb:g:gang:hood', tid, hooded[tid] == true)
    return true, hooded[tid] and ('Cagoule mise à ' .. display(tid) .. '.') or ('Cagoule retirée à ' .. display(tid) .. '.')
end
-- braquer : arme en main (vérifié par le serveur), la personne lève les mains 20 s
local held, heldBy = {}, {}
-- (v1.2.78) action en cours (braquage, escorte d'un otage) : celui qui la mène peut l'arrêter avec E
local function busyOf(src)
    local t, list = os.time(), {}
    for tid, by in pairs(heldBy) do if by == src and held[tid] and held[tid] > t and G.Get(tid) then list[#list + 1] = { kind = 'handsup', id = tid } end end
    local esc = G.Ctx and G.Ctx.EscortTargetOf and G.Ctx.EscortTargetOf(src)
    if esc then list[#list + 1] = { kind = 'escort', id = esc } end
    return list
end
function GM.PushBusy(src)
    local l = busyOf(src)
    local what = nil
    for _, b in ipairs(l) do if b.kind == 'escort' then what = 'Lâcher ' .. display(b.id) end end
    if not what and l[1] then what = 'Arrêter le braquage de ' .. display(l[1].id) end
    TriggerClientEvent('pb:g:gang:busy', src, PB.Json({ on = what ~= nil, text = what }))
end
function GM.Stop(src)
    local n = 0
    for _, b in ipairs(busyOf(src)) do
        if b.kind == 'handsup' then
            held[b.id], heldBy[b.id] = nil, nil
            TriggerClientEvent('pb:g:gang:handsup', b.id, 0)
            G.Notify(b.id, { type = 'info', title = 'Braquage', text = 'Tu peux baisser les mains.' })
        elseif b.kind == 'escort' and G.Ctx and G.Ctx.StopEscort then G.Ctx.StopEscort(b.id) end
        n = n + 1
    end
    GM.PushBusy(src)
    return n
end
AddEventHandler('pb_panel:gangBusy', function(by) if G.Get(by) then GM.PushBusy(by) end end)
RegisterNetEvent('pb:g:gang:stop', function()
    local src = source
    if not G.Get(src) then return end
    if GM.Stop(src) > 0 then G.Notify(src, { type = 'info', title = 'Organisation', text = 'Action arrêtée.' }) end
end)
CreateThread(function()   -- fin naturelle du braquage (20 s) : on retire l'invite « E »
    while true do
        Wait(2000)
        local t, seen = os.time(), {}
        for tid, by in pairs(heldBy) do if not held[tid] or held[tid] <= t or not G.Get(tid) then heldBy[tid] = nil held[tid] = nil seen[by] = true end end
        for by in pairs(seen) do if G.Get(by) then GM.PushBusy(by) end end
    end
end)
ACT.handsup = function(src, p)
    local tid, err = target(src, p.id) if not tid then return false, err end
    local w = GetSelectedPedWeapon(GetPlayerPed(src))
    if not w or w == 0 or w == GetHashKey('WEAPON_UNARMED') then return false, 'Il te faut une arme en main.' end
    if G.IsCuffed(tid) then return false, 'Cette personne est déjà attachée.' end
    local t = os.time()
    if held[tid] and held[tid] > t then return false, 'Elle a déjà les mains en l\'air.' end
    held[tid] = t + 20
    heldBy[tid] = src
    TriggerClientEvent('pb:g:gang:handsup', tid, 20)
    GM.PushBusy(src)
    G.Notify(tid, { type = 'warn', title = 'Braquage', text = 'On te braque : mains en l\'air !' })
    PB.Audit.Log('police', 'gang.handsup', src, display(tid) .. ' ' .. G.Tag(tid), nil, nil, nil)
    return true, display(tid) .. ' lève les mains.'
end
AddEventHandler('playerDropped', function() hooded[source] = nil held[source] = nil heldBy[source] = nil end)
AddEventHandler('pb_panel:cuffed', function(_, tid, on) if not on and hooded[tid] then hooded[tid] = nil TriggerClientEvent('pb:g:gang:hood', tid, false) end end)
GM.ACT = ACT

local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)
local function push(src, ev)
    local spec, err = GM.Spec(src)
    if not spec then if ev == 'open' then G.Notify(src, { type = 'warn', title = 'Organisation', text = err }) end return end
    TriggerClientEvent('pb:g:gang:ui', src, PB.Json({ ev = ev, spec = spec }))
end
RegisterNetEvent('pb:g:gang:open', function()
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    push(src, 'open')
end)
local NEWBIE_DENY = { tie = true, escort = true, put_veh = true, pull_veh = true, search = true, hood = true, handsup = true }
function GM.Do(src, id, payload)
    local spec, err = GM.Spec(src)
    if not spec then return false, err end
    id = tostring(id or '')
    local fn = ACT[id]
    if not fn or not has(spec, id) then return false, 'Action indisponible.' end
    if G.Newbie and NEWBIE_DENY[id] then local no, why = G.Newbie.Deny(src) if no then return false, why end end   -- (v1.2.79) nouveaux joueurs
    return fn(src, type(payload) == 'table' and payload or {})
end
RegisterNetEvent('pb:g:gang:act', function(id, payload)
    local src = source
    if not usable(src) or not throttle(src, 300) then return end
    local ok, msg = GM.Do(src, id, payload)
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = 'Organisation', text = tostring(msg) }) end
    push(src, 'update')
end)

G.GangMenuForm = PB.Form.Cfg({ ns = 'gangmenu', id = 'settings', title = 'Menu des organisations (F7)', perm = 'orga.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Menu F7 des organisations', default = true },
    { k = 'near_dist', type = 'number', label = 'Distance des personnes proposées (m)', default = 6, min = 2, max = 20 },
    { k = 'tie_dist', type = 'number', label = 'Distance pour ligoter / fouiller (m)', default = 3, min = 1, max = 8 },
    { k = 'need_item', type = 'text', label = 'Objet nécessaire pour ligoter (vide = aucun)', default = 'rope', maxlen = 40, pattern = '^[%w_]*$', hint = 'Ex. un objet « serflex » de ton inventaire : un exemplaire est utilisé à chaque fois.' },
} })

PB.SelfTest.Add('menu des organisations F7', function(R)
    R.check(G.Police and G.Police.SetCuffed ~= nil, 'menottes', 'police.lua doit être chargé avant')
    R.check(G.Orga and G.Orga.OpenStash ~= nil and G.Orga.Act ~= nil, 'organisation', 'orga.lua doit être chargé avant')
end)
