-- Builder du menu staff (F10 › Builder).
-- Chaque groupe / entreprise / drogue a sa liste de points : « ✔ Défini » ou « Aucune position ». On choisit un point, le menu se ferme,
-- on va à l'endroit voulu et Entrée le pose (ou le déplace) ; le menu revient tout seul. Le serveur vérifie les droits et lit la position.
local G = PBG

local GROUP_ORDER = { 'Commerces', 'Banque', 'Immobilier', 'Garages et coffres', 'Activités illégales', 'Entreprises', 'Gangs' }
local ICON = { Commerces = 'cart', Banque = 'coins', Immobilier = 'home', ['Garages et coffres'] = 'lock', ['Activités illégales'] = 'skull', Entreprises = 'building', Gangs = 'users' }
local STEP_ICON = { hq = 'users', boss = 'briefcase', stash = 'lock', garage = 'engine', garage_out = 'gps', duty = 'clock', wardrobe = 'hanger', harvest = 'paw', process = 'box', sell = 'coins' }
local COLORS = { { 'Rouge', '#e74c3c' }, { 'Violet', '#9b59b6' }, { 'Orange', '#f39c12' }, { 'Gris', '#7f8c8d' }, { 'Vert', '#2ecc71' }, { 'Bleu', '#3498db' }, { 'Jaune', '#f1c40f' }, { 'Rose', '#e84393' }, { 'Noir', '#2d3436' }, { 'Blanc', '#ecf0f1' } }

local placing = nil   -- { kind, owner, key, name, extra } : en attente d'Entrée sur place
local current = nil   -- dernière liste reçue (pour revenir au menu)

-- Le menu se ferme après l'envoi : on part poser le point
local function go(send, id, payload) G.Menu.Close() send(id, payload) end

local function iconOf(key)
    local t = tostring(key):match('^([%w_]+)')
    t = t and t:gsub('^gang_', ''):gsub('^biz_', ''):gsub('^drug_', '') or ''
    return STEP_ICON[t] or 'gps'
end

-- Liste des points d'une cible (écran 2 et 4 de la maquette)
local function openPoints(d)
    current = d
    local me = GetEntityCoords(PlayerPedId())
    local items = { { type = 'separator', label = ('Points %s « %s » — %d/%d définis'):format(d.what == 'Entreprise' and "de l'entreprise" or (d.what == 'Drogue' and 'de la drogue' or 'du ' .. d.what:lower()), d.label, d.done or 0, #d.steps) } }
    local sel = 2
    for i, st in ipairs(d.steps) do
        local defined = st.x ~= nil
        local desc
        if st.add then desc = st.hint .. ' Entrée : en ajouter un ici.'
        elseif defined then
            local dist = #(me - vector3(st.x + 0.0, st.y + 0.0, st.z + 0.0))
            desc = ('Défini ici : %d, %d (à %s de toi). Entrée : le déplacer.'):format(math.floor(st.x), math.floor(st.y), dist < 1000 and (math.floor(dist + 0.5) .. ' m') or (('%.1f km'):format(dist / 1000)))
        else desc = 'Aucune position définie. ' .. (st.hint or '') .. ' Entrée : choisir l\'emplacement.' end
        local function place()
            local extra = ''
            if st.ask then extra = G.Menu.Ask(st.ask, '', 40) if extra == nil then return end end
            placing = { kind = d.kind, owner = d.owner, key = st.key, name = st.name, extra = extra }
            G.Menu.Close()
        end
        local it = { label = st.name, icon = iconOf(st.key), right = st.add and 'Ajouter' or (defined and '✔ Défini' or 'Aucune position'), description = desc, onSelect = place }
        if defined and not st.add then
            -- point déjà posé : le déplacer ou le supprimer (son blip disparaît avec lui)
            it.type, it.onSelect = 'submenu', nil
            it.submenu = { id = 'builder.pt.' .. tostring(st.key), title = st.name, subtitle = d.label, items = {
                { label = 'Déplacer ici', icon = 'gps', description = "Va à l'endroit voulu puis Entrée.", onSelect = place },
                { label = 'Supprimer ce point', icon = 'x', description = 'Retire le point et son icône de la carte.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:builder:del', d.kind, d.owner, st.key) end },
            } }
        end
        items[#items + 1] = it
        if d.sel and i == d.sel then sel = i + 1 end
    end
    -- tous les points réellement posés (y compris d'anciennes versions) : chacun peut être supprimé
    if d.all and #d.all > 0 then
        items[#items + 1] = { type = 'separator', label = ('Tous les points posés (%d)'):format(#d.all) }
        for _, p in ipairs(d.all) do
            local dist = p.x and #(me - vector3(p.x + 0.0, p.y + 0.0, (p.z or 0) + 0.0)) or nil
            items[#items + 1] = { type = 'submenu', label = p.label, icon = 'pin', right = dist and (dist < 1000 and (math.floor(dist + 0.5) .. ' m') or ('%.1f km'):format(dist / 1000)) or nil,
                submenu = { id = 'builder.raw.' .. p.key, title = p.label, subtitle = d.label, items = {
                    { label = 'Mettre le GPS', icon = 'gps', onSelect = function() if p.x then SetNewWaypoint(p.x + 0.0, p.y + 0.0) end end },
                    { label = 'Supprimer ce point', icon = 'x', description = 'Retire le point et son icône de la carte.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:builder:del', d.kind, d.owner, p.key) end },
                } } }
        end
    end
    items[#items + 1] = { type = 'separator', label = '' }
    if (d.done or 0) > 0 and (d.kind == 'biz' or d.kind == 'gang' or d.kind == 'drug') then
        items[#items + 1] = { label = 'Supprimer tous les points', icon = 'trash', description = "Retire tous les points posés et leurs icônes (le groupe / l'entreprise reste). Confirmation demandée.", onSelect = function()
            local v = G.Menu.Ask('Tape OUI pour tout supprimer', '', 3)
            if v and v:upper() == 'OUI' then G.Menu.Close() TriggerServerEvent('pb:g:builder:del', d.kind, d.owner, '*') end
        end }
    end
    items[#items + 1] = { label = 'Terminer', icon = 'check', description = 'Les points posés restent en place ; tu peux revenir les modifier quand tu veux.', onSelect = function() current = nil G.Menu.Close() end }
    G.Menu.Close()
    G.Menu.Open({ id = 'builder.points', title = 'Builder', subtitle = d.what .. ' · ' .. d.label, items = items, banner = { text = 'Menu builder' }, sel = sel })
end
RegisterNetEvent('pb:g:builder:points', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' or type(d.steps) ~= 'table' then return end
    placing = nil
    G.send('prompt', { show = false })
    openPoints(d)
end)

-- Pose sur place : Entrée (ou E) pose, Retour arrière annule et rouvre la liste
CreateThread(function()
    local shown = false
    while true do
        if placing then
            if not shown then shown = true G.send('prompt', { show = true, key = '↵', text = 'placer « ' .. placing.name .. ' » ici  ·  Retour : annuler' }) end
            DisableControlAction(0, 200, true)   -- Échap / pause pendant la pose
            if IsControlJustPressed(0, 191) or IsControlJustPressed(0, 201) or IsControlJustPressed(0, 38) then
                local p = placing
                placing = nil shown = false G.send('prompt', { show = false })
                TriggerServerEvent('pb:g:builder:set', p.kind, p.owner, p.key, p.extra)
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                placing = nil shown = false G.send('prompt', { show = false })
                if current then openPoints(current) end
            end
            Wait(0)
        else
            if shown then shown = false G.send('prompt', { show = false }) end
            Wait(300)
        end
    end
end)

-- Poser un point isolé (magasin, banque, garage public…) : même pose sur place, via la Carte
local function placeItem(send, t, owner, ownerLabel)
    return { label = t.label, icon = 'gps', description = ownerLabel and ('Pour : ' .. ownerLabel) or 'Puis place-toi à l\'endroit voulu et appuie sur E.', onSelect = function()
        local name = G.Menu.Ask('Nom du point (vide = « ' .. t.label .. ' »)', '', 48)
        if name == nil then return end
        go(send, 'b_place', { type = t.id, name = name, owner = owner })
    end }
end
local function typeEntry(send, t, b)
    if t.needs then return nil end   -- points d'une entreprise / d'un groupe : passent par leur liste
    if t.id:sub(1, 5) == 'drug_' then return nil end   -- drogues : par « Drogues »
    if t.presets and #t.presets > 0 then
        local items = {}
        for _, pr in ipairs(t.presets) do items[#items + 1] = { label = pr[2], onSelect = function() go(send, 'b_place', { type = t.id, name = t.label .. ' : ' .. pr[2], preset = pr[1] }) end } end
        return { type = 'submenu', label = t.label, icon = 'gps', submenu = { id = 'b.pre.' .. t.id, title = t.label, items = items } }
    end
    return placeItem(send, t)
end

-- Formulaire de création d'un groupe (écran 1 de la maquette)
local function groupForm(send, b)
    local form = { name = '', type = 1, color = 1 }
    local gt = b.gtypes or {}
    local typeNames, colorNames = {}, {}
    for _, t in ipairs(gt) do typeNames[#typeNames + 1] = t.label end
    for _, c in ipairs(COLORS) do colorNames[#colorNames + 1] = c[1] end
    return { id = 'b.gform', title = 'Builder', subtitle = 'Créer · Groupe illégal', build = function()
        return {
            { type = 'separator', label = 'Nouveau groupe' },
            { type = 'input', label = 'Nom', icon = 'tag', value = form.name, description = 'Nom affiché du groupe (2 caractères au moins).', onChange = function(_, v) form.name = tostring(v or ''):sub(1, 24) end },
            { type = 'list', label = 'Type', icon = 'users', list = typeNames, index = form.type, description = 'Gang, organisation, cartel ou club de motards.', onChange = function(_, _, i) form.type = i end },
            { type = 'list', label = 'Couleur', icon = 'palette', list = colorNames, index = form.color, description = 'Couleur de la zone sur la carte et du drapeau.', onChange = function(_, _, i) form.color = i end },
            { type = 'separator', label = '' },
            { label = 'Créer et placer les points', icon = 'check', description = 'Le groupe est créé, puis tu choisis ses points un par un.', onSelect = function()
                if #form.name < 2 then G.send('notify', { type = 'error', title = 'Builder', text = 'Donne un nom au groupe.' }) return end
                send('b_group', { gtype = gt[form.type] and gt[form.type].id or 'gang', label = form.name, color = COLORS[form.color][2] })
                form.name = ''
            end },
        }
    end }
end

function G.BuilderItems(spec, send)
    local b = spec and spec.builder
    if not b then return { { label = 'Accès réservé (droit « placer des points »)', disabled = true } } end
    local items = {}

    -- 1. Groupes illégaux
    local gitems = { { type = 'submenu', label = 'Créer un groupe', icon = 'plus', description = 'Gang, organisation, cartel ou MC : nom, type, couleur, puis ses points.', submenu = groupForm(send, b) },
        { type = 'separator', label = 'Groupes existants' } }
    for _, g in ipairs(b.gangs or {}) do gitems[#gitems + 1] = { label = g[2], right = g[3], icon = 'users', description = 'Ouvrir la liste de ses points.', onSelect = function() send('b_pack', { kind = 'gang', owner = g[1] }) end } end
    if #b.gangs == 0 then gitems[#gitems + 1] = { label = 'Aucun groupe', disabled = true } end
    items[#items + 1] = { type = 'submenu', label = 'Gang · Organisation · Cartel · MC', icon = 'users', description = 'Créer un groupe illégal ou modifier ses points.', submenu = { id = 'b.groups', title = 'Groupes illégaux', items = gitems } }

    -- 2. Entreprises du catalogue
    local citems = {}
    for _, c in ipairs(b.cats or {}) do
        local sub = {}
        for _, e in ipairs(c.items) do
            sub[#sub + 1] = { label = e.label, right = e.made and 'existe' or 'nouvelle', description = e.made and 'Ouvrir la liste de ses points.' or 'Créer l\'entreprise puis choisir ses points.',
                onSelect = function() send('b_biz', { key = e.key }) end }
        end
        if #sub > 0 then citems[#citems + 1] = { type = 'submenu', label = c.label, badge = tostring(#sub), submenu = { id = 'b.cat.' .. c.id, title = c.label, items = sub } } end
    end
    if #citems == 0 then citems[1] = { label = 'Catalogue vide', disabled = true } end
    items[#items + 1] = { type = 'submenu', label = 'Entreprises', icon = 'building', description = 'Créer une entreprise du catalogue ou modifier ses points.', submenu = { id = 'b.biz', title = 'Entreprises', items = citems } }

    -- 3. Drogues
    local ditems = {}
    for _, d in ipairs(b.drugs or {}) do
        ditems[#ditems + 1] = { label = d[2], right = d[5] .. ' $', description = ('%s → %s. Récolte, labo, vente (drapeau).'):format(d[3], d[4]), onSelect = function() send('b_drug', { drug = d[1] }) end }
    end
    items[#items + 1] = { type = 'submenu', label = 'Drogues', icon = 'skull', description = '5 drogues prêtes : objets créés, puis récolte, labo et vente.', submenu = { id = 'b.drugs', title = 'Drogues', subtitle = 'Choisis la drogue', items = ditems } }

    -- 4. Points isolés, par catégorie
    for _, gname in ipairs(GROUP_ORDER) do
        local list = b.groups and b.groups[gname]
        local sub = {}
        for _, t in ipairs(list or {}) do local e = typeEntry(send, t, b) if e then sub[#sub + 1] = e end end
        if #sub > 0 then items[#items + 1] = { type = 'submenu', label = gname, icon = ICON[gname] or 'gps', badge = tostring(#sub), submenu = { id = 'b.g.' .. gname, title = gname, items = sub } } end
    end

    -- 5. Autres ressources (Burger Shot…)
    for _, e in ipairs(b.ext or {}) do
        items[#items + 1] = { label = e.label, icon = e.icon or 'box', badge = tostring(#(e.points or {})), description = 'Ouvrir la liste de ses points.', onSelect = function() send('b_pack', { kind = 'ext', owner = e.id }) end }
    end

    -- 6. Supprimer
    if b.canDelete then
        items[#items + 1] = { type = 'separator', label = 'Supprimer' }
        items[#items + 1] = { label = 'Point le plus proche (8 m)', icon = 'trash', description = 'Affiche le point qui serait supprimé.', onSelect = function() send('b_delete', {}) end }
        items[#items + 1] = { label = 'Confirmer la suppression', icon = 'trash', description = 'Supprime le point le plus proche pour tous les joueurs.', onSelect = function() send('b_delete', { confirm = true }) end }
    end
    return items
end
