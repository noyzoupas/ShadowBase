-- Points d'entreprise et de gang : siège, prise de service, coffre du patron, vestiaire, avec blip sur la carte.
-- Visibilité du blip : tous / membres / staff en service / aucun. Le staff en service voit tous les points (utile pour dépanner).
-- Le serveur envoie à chaque joueur uniquement ce qu'il a le droit de voir ; l'interaction « E » est revalidée côté serveur (distance, appartenance).

local P, DB = PB.Perm, PB.DB
local G = PB.G
local Pt = {}
G.Points = Pt

PB.Migrate('181_points', 'Points d\'entreprises et de gangs', {
    [[CREATE TABLE IF NOT EXISTS pb_points (
        id INT NOT NULL AUTO_INCREMENT, owner_kind VARCHAR(8) NOT NULL DEFAULT 'biz', owner VARCHAR(48) NOT NULL, kind VARCHAR(12) NOT NULL DEFAULT 'hq', label VARCHAR(48) NOT NULL DEFAULT '',
        x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, h DOUBLE NOT NULL DEFAULT 0, radius DOUBLE NOT NULL DEFAULT 2.0,
        sprite INT NOT NULL DEFAULT 0, bcolor INT NOT NULL DEFAULT 0, scale DOUBLE NOT NULL DEFAULT 0.8, vis VARCHAR(8) NOT NULL DEFAULT 'members', min_grade INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY k_owner (owner_kind, owner))]],
})

Pt.Kinds = {
    hq = { label = 'Siège', hint = 'Point principal : blip et accueil.' },
    duty = { label = 'Prise de service', hint = 'E : se mettre en / hors service.' },
    boss = { label = 'Bureau du patron', hint = 'E : ouvre la tablette de gestion (grade patron).' },
    stash = { label = 'Coffre', hint = 'Coffre partagé (créé aussi dans les coffres).' },
    wardrobe = { label = 'Vestiaire', hint = 'Tenues de l\'entreprise.' },
    garage = { label = 'Garage', hint = 'Sortie de véhicules.' },
}
Pt.Vis = { all = 'Tout le monde', members = 'Membres', staff = 'Staff en service', none = 'Aucun blip' }

local function num(v, d) v = tonumber(v) return v or d end

function Pt.Add(d)
    local kind = Pt.Kinds[d.kind] and d.kind or 'hq'
    local ok = DB.insert('INSERT INTO pb_points (owner_kind, owner, kind, label, x, y, z, h, radius, sprite, bcolor, scale, vis, min_grade) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { d.owner_kind == 'gang' and 'gang' or 'biz', tostring(d.owner), kind, tostring(d.label or ''):sub(1, 48), num(d.x, 0) + 0.0, num(d.y, 0) + 0.0, num(d.z, 0) + 0.0, num(d.h, 0) + 0.0, num(d.radius, 2.0) + 0.0,
            math.floor(num(d.sprite, 0)), math.floor(num(d.bcolor, 0)), num(d.scale, 0.8) + 0.0, Pt.Vis[d.vis] and d.vis or 'members', math.floor(num(d.min_grade, 0)) })
    Pt.PushAll()
    return ok
end
function Pt.Remove(id) DB.exec('DELETE FROM pb_points WHERE id = ?', { tonumber(id) or -1 }) Pt.PushAll() end
function Pt.Of(kind, owner) return DB.q('SELECT * FROM pb_points WHERE owner_kind = ? AND owner = ? ORDER BY id', { kind, tostring(owner) }) or {} end
-- Le joueur est-il au bureau du patron de son entreprise / organisation ? (gestion réservée à ce point, réglage tablets.boss_at_point)
-- Vrai aussi si le réglage est coupé ou si aucun bureau n'a encore été posé (pour ne bloquer personne).
function Pt.AtBoss(src, ownerKind, owner)
    if PB.Cfg.Get('tablets', 'boss_at_point', true) == false then return true end
    local list = {}
    for _, p in ipairs(Pt.Of(ownerKind, owner)) do if p.kind == 'boss' then list[#list + 1] = p end end
    if #list == 0 then return true end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c then return false end
    for _, p in ipairs(list) do
        local dx, dy, dz = c.x - p.x, c.y - p.y, c.z - p.z
        if math.sqrt(dx * dx + dy * dy + dz * dz) <= (tonumber(p.radius) or 2) + 6.0 then return true end
    end
    return false
end
function Pt.All() return DB.q('SELECT * FROM pb_points ORDER BY owner_kind, owner, id') or {} end

local function isMember(src, p)
    if p.owner_kind == 'biz' then
        local pl = G.Get(src)
        local m = pl and G.Biz.MemberOf(pl.license)
        return m and m.biz_id == p.owner and m.grade >= (p.min_grade or 0)
    end
    local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
    return g and g.id == p.owner or false
end
local function staffSeen(src) return P.Has(src, 'staff.menu') and G.Staff and G.Staff.OnDuty(src) end

-- Les points qu'un joueur peut voir (blip) et utiliser (marqueur).
function Pt.ViewFor(src)
    local out = {}
    local staff = staffSeen(src)
    for _, p in ipairs(Pt.All()) do
        local member = isMember(src, p)
        local showBlip = (p.sprite or 0) > 0 and (p.vis == 'all' or (p.vis == 'members' and member) or (p.vis == 'staff' and staff) or staff) and p.vis ~= 'none' or ((p.sprite or 0) > 0 and staff)
        local public = p.kind == 'desk'   -- l'accueil sert aux clients : visible et utilisable par tout le monde
        if member or staff or showBlip or public then
            out[#out + 1] = { id = p.id, kind = p.kind, label = p.label, x = p.x, y = p.y, z = p.z, r = p.radius, sp = showBlip and p.sprite or 0, bc = p.bcolor, sc = p.scale, use = (member or public) and true or false, og = p.owner_kind == 'gang' or nil }
        end
        -- Présence d'un groupe : tout le monde voit la zone où il est installé (autour du QG), sans le QG, le coffre ni le garage
        if p.owner_kind == 'gang' and p.kind == 'hq' and PB.Cfg.Get('tags', 'show_presence', true) ~= false then
            local d = G.Tags and G.Tags.GangDefs()[p.owner]
            if d then out[#out + 1] = { id = 'area_' .. p.id, kind = 'area', label = d.label, x = p.x, y = p.y, z = p.z, r = tonumber(PB.Cfg.Get('tags', 'presence_radius', 90)) or 90, col = d.color, sp = 0, use = false } end
        end
    end
    return out
end
function Pt.Push(src) TriggerClientEvent('pb:g:points', src, PB.Json(Pt.ViewFor(src))) end
function Pt.PushAll() for s in pairs(G.Players()) do Pt.Push(s) end end
table.insert(G.beginHooks, function(src) Pt.Push(src) end)
AddEventHandler('pb_panel:jobChanged', function(src) if G.Players()[src] then Pt.Push(src) end end)
AddEventHandler('pb_panel:gangChanged', function(src) if src and G.Players()[src] then Pt.Push(src) end end)

-- Interaction : le client dit « j'ai appuyé sur E près du point n°X », le serveur revérifie tout.
RegisterNetEvent('pb:g:points:use', function(id)
    local src = source
    local p = DB.one('SELECT * FROM pb_points WHERE id = ?', { tonumber(id) or -1 })
    if not p or not (isMember(src, p) or p.kind == 'desk') then return end
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local c = GetEntityCoords(ped)
        if c and not (c.x == 0 and c.y == 0) then
            local dx, dy, dz = c.x - p.x, c.y - p.y, c.z - p.z
            if math.sqrt(dx * dx + dy * dy + dz * dz) > (p.radius + 4.0) then return end
        end
    end
    if p.kind == 'duty' and p.owner_kind == 'biz' then
        local pl = G.Get(src)
        local m = pl and G.Biz.MemberOf(pl.license)
        if not m then return end
        local on = not PB.ToBool(m.on_duty)
        DB.exec('UPDATE pb_biz_members SET on_duty = ? WHERE license = ?', { on and 1 or 0, pl.license })
        TriggerEvent('pb_panel:duty', src, m.biz_id, on)
        G.Notify(src, { type = 'info', title = 'Service', text = on and 'Tu prends ton service.' or 'Tu quittes ton service.' })
    elseif p.kind == 'desk' and p.owner_kind == 'biz' then
        if isMember(src, p) then TriggerClientEvent('pb:g:biz:open', src) return end
        -- client : prévient les employés en service (une fois par minute)
        Pt.deskLast = Pt.deskLast or {}
        local t = os.time()
        if Pt.deskLast[src] and t - Pt.deskLast[src] < 60 then G.Notify(src, { type = 'info', title = p.label, text = "Les employés ont déjà été prévenus, patiente un instant." }) return end
        Pt.deskLast[src] = t
        local n = 0
        for s in pairs(G.Players()) do
            local j = G.Biz.Job(s)
            if j and j.biz == p.owner and j.onDuty then
                n = n + 1
                G.Notify(s, { type = 'info', title = p.label, text = "Un client attend à l'accueil." })
                TriggerClientEvent('pb:g:points:ping', s, PB.Json({ x = p.x, y = p.y, label = p.label }))
            end
        end
        G.Notify(src, { type = n > 0 and 'success' or 'warn', title = p.label, text = n > 0 and 'Un employé a été prévenu, il arrive.' or "Personne n'est en service pour le moment." })
    elseif p.kind == 'wardrobe' then
        if G.Wardrobe and G.Wardrobe.Open then G.Wardrobe.Open(src, p) end
    elseif p.kind == 'workshop' and p.owner_kind == 'biz' then
        if G.Mech and G.Mech.Open then G.Mech.Open(src) end
    elseif p.kind == 'kitchen' and p.owner_kind == 'biz' then
        local j = G.Biz.Job(src)
        if not (j and j.onDuty) then G.Notify(src, { type = 'warn', title = p.label, text = 'Prends ton service.' }) return end
        local b = G.Biz.Get(p.owner)
        if GetResourceState('wb_activites') ~= 'started' then G.Notify(src, { type = 'error', title = p.label, text = 'Les recettes demandent la ressource « wb_activites ».' }) return end
        TriggerEvent('pb_panel:bizCraft', src, p.owner, b and b.category or '', p.id, p.x, p.y, p.z, p.label)
    elseif p.kind == 'stash' and p.owner_kind == 'gang' then
        if G.Orga and G.Orga.OpenStash then G.Orga.OpenStash(src, false) end
    elseif p.kind == 'boss' or p.kind == 'hq' then
        TriggerClientEvent('pb:g:biz:open', src)
    end
end)

PB.SelfTest.Add('points', function(R)
    local id = Pt.Add({ owner_kind = 'biz', owner = 'zz_test', kind = 'hq', label = 'Test', x = 1, y = 2, z = 3, sprite = 60, bcolor = 3, vis = 'all' })
    R.check(id ~= nil, 'points', 'ajout impossible')
    R.check(#Pt.Of('biz', 'zz_test') == 1, 'points', 'lecture impossible')
    DB.exec("DELETE FROM pb_points WHERE owner = 'zz_test'")
    R.check(#Pt.Of('biz', 'zz_test') == 0, 'points', 'suppression impossible')
end)
