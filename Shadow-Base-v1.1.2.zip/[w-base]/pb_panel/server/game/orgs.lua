-- Organisations illégales : création guidée (infos → points posés en jeu), pack de départ dans le coffre, véhicules du gang.
-- Un gang = une ligne de pb_org_groups (kind 'gang') comme dans l'onglet Gangs ; ici on y ajoute coffre garni, véhicules et garage.
-- Les véhicules d'organisation sont dans pb_vehicles avec la colonne `gang` (licence vide = véhicule de départ, sinon = donateur).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('orgs.edit', 'Créer et gérer les organisations illégales (pack de départ, véhicules)', 'orgs', true)

PB.Migrate('197_org_vehicles', 'Organisations : véhicules de gang et suivi du pack de départ', {
    "ALTER TABLE pb_vehicles ADD COLUMN gang VARCHAR(32) NOT NULL DEFAULT ''",
    [[CREATE TABLE IF NOT EXISTS pb_orgs (id VARCHAR(32) NOT NULL, created_at INT NOT NULL DEFAULT 0, created_by VARCHAR(64) NOT NULL DEFAULT '', starter TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
})

local Orgs = {}
G.Orgs = Orgs
local function cfg(k, d) return PB.Cfg.Get('orgs', k, d) end
local function now() return os.time() end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>|]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, n)) end

local settings = Form.Cfg({ ns = 'orgs', id = 'settings', title = 'Réglages des organisations', perm = 'orgs.edit', cols = 2, fields = {
    { k = 'auto_starter', type = 'toggle', label = 'Donner le pack de départ à la création', default = true },
    { k = 'starter_cash', type = 'number', label = "Argent de départ dans la caisse de l'organisation ($)", default = 5000, min = 0, max = 10000000 },
    { k = 'starter_items', type = 'list', label = 'Objets du coffre de départ (objet:quantité)', default = { 'water:10', 'sandwich:10', 'bandage:10', 'medkit:2', 'lockpick:5', 'repair_kit:2', 'rope:3' }, maxitems = 30, maxlen = 40, pattern = '^[%w_]+:%d+$', wide = true,
        hint = "Le nom doit exister dans l'inventaire (onglet Objets). Un objet inconnu est ignoré et signalé." },
    { k = 'starter_vehicles', type = 'list', label = 'Véhicules de départ (modèle|nom affiché)', default = { 'sultan|Sultan', 'faggio|Faggio', 'burrito3|Burrito' }, maxitems = 10, maxlen = 48, pattern = '^[%w_]+|?[^|]*$', wide = true,
        hint = "Ils sont rangés au garage de l'organisation, avec une plaque unique, et appartiennent à l'organisation." },
    { k = 'max_vehicles', type = 'number', label = "Véhicules maximum par organisation", default = 10, min = 1, max = 100 },
    { k = 'take_grade', type = 'number', label = 'Grade minimum pour sortir un véhicule du gang (0 = tous)', default = 0, min = 0, max = 10 },
    { k = 'allow_donate', type = 'toggle', label = "Les membres peuvent donner leur véhicule à l'organisation", default = true },
} })

-- Plaques -----------------------------------------------------------------------------------------------------------------------------------
local function newPlate()
    local pre = tostring(PB.Cfg.Get('shops', 'plate_prefix', 'PB') or 'PB'):upper():gsub('[^A-Z0-9]', ''):sub(1, 3)
    for _ = 1, 40 do
        local pl = pre .. tostring(math.random(10 ^ (7 - #pre - 1), 10 ^ (7 - #pre) - 1))
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { pl }) then return pl end
    end
end

function Orgs.Def(gid) return G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[tostring(gid)] end
function Orgs.List()
    local out = {}
    for id, d in pairs(G.Tags.GangDefs()) do out[#out + 1] = d end
    table.sort(out, function(a, b) return a.label < b.label end)
    return out
end
function Orgs.Vehicles(gid) return DB.q('SELECT v.plate, v.model, v.label, v.license, COALESCE(s.state, ?) AS state FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.gang = ? ORDER BY v.label', { 'garage', tostring(gid) }) or {} end
function Orgs.Count(gid) return tonumber(DB.scalar('SELECT COUNT(*) FROM pb_vehicles WHERE gang = ?', { tostring(gid) })) or 0 end
function Orgs.Members(gid) return tonumber(DB.scalar('SELECT COUNT(*) FROM pb_tag_gang WHERE gang = ?', { tostring(gid) })) or 0 end
function Orgs.Vault(gid) return tonumber(DB.scalar('SELECT balance FROM pb_orga_vault WHERE gang = ?', { tostring(gid) })) or 0 end

-- Ajoute un véhicule à l'organisation (neuf, rangé au garage). Renvoie plaque | nil, message
function Orgs.AddVehicle(gid, model, label)
    gid = tostring(gid)
    if not Orgs.Def(gid) then return nil, 'Organisation introuvable.' end
    model = tostring(model or ''):lower()
    if not model:match('^[%w_]+$') or #model < 3 or #model > 32 then return nil, 'Modèle invalide.' end
    if Orgs.Count(gid) >= cfg('max_vehicles', 10) then return nil, ("L'organisation a déjà %d véhicules (maximum)."):format(cfg('max_vehicles', 10)) end
    local plate = newPlate()
    if not plate then return nil, 'Aucune plaque disponible.' end
    label = clean(label, 64)
    if label == '' then label = model:sub(1, 1):upper() .. model:sub(2) end
    DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price, gang) VALUES (?, ?, ?, ?, ?, ?, ?)', { '', plate, model, label, now(), 0, gid })
    return plate
end

-- Pack de départ : objets dans le coffre `o:<id>`, argent dans la caisse, véhicules au garage du gang. Une seule fois sauf `force`.
function Orgs.Starter(gid, force)
    gid = tostring(gid)
    if not Orgs.Def(gid) then return nil, 'Organisation introuvable.' end
    local r = DB.one('SELECT starter FROM pb_orgs WHERE id = ?', { gid })
    if r and tonumber(r.starter) == 1 and not force then return nil, 'Le pack de départ a déjà été donné.' end
    local sum = { items = 0, skipped = {}, cash = 0, cars = {} }
    for _, line in ipairs(cfg('starter_items', {}) or {}) do
        local item, qty = tostring(line):match('^([%w_]+):(%d+)$')
        qty = tonumber(qty)
        if item and qty and qty > 0 then
            if G.Inv and G.Inv.Def(item) then
                local ok = G.Inv.Add('o:' .. gid, item, qty)
                if ok then sum.items = sum.items + 1 else sum.skipped[#sum.skipped + 1] = item .. ' (coffre plein)' end
            else sum.skipped[#sum.skipped + 1] = item .. ' (inconnu)' end
        end
    end
    local cash = math.floor(tonumber(cfg('starter_cash', 0)) or 0)
    if cash > 0 then
        DB.exec('INSERT INTO pb_orga_vault (gang, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)', { gid, cash })
        sum.cash = cash
    end
    for _, line in ipairs(cfg('starter_vehicles', {}) or {}) do
        local model, label = tostring(line):match('^([%w_]+)|?(.*)$')
        if model then
            local plate, why = Orgs.AddVehicle(gid, model, label)
            if plate then sum.cars[#sum.cars + 1] = plate else sum.skipped[#sum.skipped + 1] = model .. ' (' .. tostring(why) .. ')' break end
        end
    end
    DB.exec('INSERT INTO pb_orgs (id, created_at, starter) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE starter = 1', { gid, now() })
    return sum
end

-- Création : une ligne de groupe (comme l'onglet Gangs) + suivi. Renvoie id | nil, message
function Orgs.Create(def, actor)
    local id = tostring(def.id or ''):lower():gsub('[^A-Za-z0-9_]', '')
    local label = clean(def.label, 24)
    if #label < 2 then return nil, 'Donne un nom à l\'organisation (2 caractères au moins).' end
    if id == '' then id = label:lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', '') end
    id = id:sub(1, 24)
    if #id < 2 then return nil, 'Identifiant invalide (lettres, chiffres, _).' end
    if id == 'none' then return nil, 'Identifiant réservé.' end
    if Orgs.Def(id) then return nil, 'Une organisation « ' .. id .. ' » existe déjà.' end
    local color = tostring(def.color or ''):match('^#%x%x%x%x%x%x$') or '#b58cff'
    local ok, e = PB.Fw.SaveGroup('gang', { name = id, label = label, color = color, grades = {
        { grade = 0, name = 'recrue', label = 'Recrue', salary = 0 }, { grade = 1, name = 'membre', label = 'Membre', salary = 0 },
        { grade = 2, name = 'lieutenant', label = 'Lieutenant', salary = 0 }, { grade = 3, name = 'chef', label = 'Chef', salary = 0, boss = true } } }, actor)
    if not ok then return nil, tostring(e or 'Création impossible.') end
    DB.exec('INSERT INTO pb_orgs (id, created_at, created_by, starter) VALUES (?, ?, ?, 0) ON DUPLICATE KEY UPDATE created_by = VALUES(created_by)', { id, now(), tostring(actor or '') })
    if G.Tags.RefreshNative then G.Tags.RefreshNative() end
    return id, label
end

PB.Action('orgs.create', 'orgs.edit', function(ctx, p)
    local v = p.values or p
    local id, label = Orgs.Create(v, ctx.actor)
    if not id then return false, label end
    local parts = { "Organisation « " .. label .. " » créée." }
    local bossId = tonumber(v.boss)
    if bossId and bossId > 0 then
        local ok, e = G.Tags.SetGang(bossId, id)
        if ok and G.Flags and G.Flags.SetBoss then ok, e = G.Flags.SetBoss(id, bossId) end
        parts[#parts + 1] = ok and 'Chef désigné.' or ('Chef non désigné : ' .. tostring(e))
        G.Tags.Push(true)
    end
    local sum
    if v.starter ~= false and cfg('auto_starter', true) then
        sum = Orgs.Starter(id, false)
        if sum then parts[#parts + 1] = ('Pack de départ : %d objets, %s $, %d véhicule(s).'):format(sum.items, tostring(sum.cash), #sum.cars) end
        if sum and #sum.skipped > 0 then parts[#parts + 1] = 'Ignorés : ' .. table.concat(sum.skipped, ', ') .. '.' end
    end
    ctx.audit('config', 'orgs.create', id, nil, { label = label, color = v.color, boss = bossId, starter = sum ~= nil })
    ctx.toast = table.concat(parts, ' ')
    if v.points ~= false and ctx.src and ctx.src > 0 and PB.Place and PB.Place.PackStart then
        local ok = PB.Place.PackStart(ctx.src, 'gang', id)
        if ok then ctx.close = true ctx.toast = ctx.toast .. ' Pose maintenant ses points en jeu (E pour poser, Retour arrière pour passer).' end
    end
    return true
end)

PB.Action('orgs.points', 'orgs.edit', function(ctx, p)
    if not ctx.src or ctx.src <= 0 then return false, 'Disponible seulement en jeu.' end
    local ok, err = PB.Place.PackStart(ctx.src, 'gang', tostring(p.gang or ''))
    if not ok then return false, err end
    ctx.audit('config', 'orgs.points', tostring(p.gang))
    ctx.close = true
    return true
end)

PB.Action('orgs.starter', 'orgs.edit', function(ctx, p)
    local sum, e = Orgs.Starter(p.gang, true)
    if not sum then return false, e end
    ctx.audit('economy', 'orgs.starter', tostring(p.gang), nil, { items = sum.items, cash = sum.cash, cars = #sum.cars })
    ctx.toast = ('Pack donné : %d objets, %s $, %d véhicule(s).'):format(sum.items, tostring(sum.cash), #sum.cars) .. (#sum.skipped > 0 and (' Ignorés : ' .. table.concat(sum.skipped, ', ') .. '.') or '')
    return true
end, { confirm = { title = 'Redonner le pack de départ ?', text = "Les objets, l'argent et les véhicules s'ajoutent à ce que l'organisation possède déjà." } })

PB.Action('orgs.vehicle.add', 'orgs.edit', function(ctx, p)
    local v = p.values or p
    local plate, e = Orgs.AddVehicle(v.gang, v.model, v.label)
    if not plate then return false, e end
    ctx.audit('economy', 'orgs.vehicle.add', plate, nil, { gang = v.gang, model = v.model })
    ctx.toast = 'Véhicule ' .. plate .. ' ajouté au garage de l\'organisation.'
    return true
end)

PB.Action('orgs.vehicle.assign', 'orgs.edit', function(ctx, p)
    local v = p.values or p
    local plate = tostring(v.plate or ''):upper():gsub('%s+$', '')
    local gid = tostring(v.gang or '')
    local veh = DB.one('SELECT plate, label, gang FROM pb_vehicles WHERE plate = ?', { plate })
    if not veh then return false, 'Plaque introuvable.' end
    if gid == '' then return false, "Choisis l'organisation." end
    if not Orgs.Def(gid) then return false, 'Organisation introuvable.' end
    if veh.gang == gid then return false, 'Ce véhicule appartient déjà à cette organisation.' end
    if Orgs.Count(gid) >= cfg('max_vehicles', 10) then return false, "L'organisation a atteint sa limite de véhicules." end
    DB.exec('UPDATE pb_vehicles SET gang = ? WHERE plate = ?', { gid, plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { plate })
    ctx.audit('economy', 'orgs.vehicle.assign', plate, { gang = veh.gang }, { gang = gid })
    ctx.toast = veh.label .. ' (' .. plate .. ') appartient maintenant à l\'organisation.'
    return true
end)

PB.Action('orgs.vehicle.release', 'orgs.edit', function(ctx, p)
    local plate = tostring(p.plate or '')
    local veh = DB.one('SELECT plate, license, gang FROM pb_vehicles WHERE plate = ?', { plate })
    if not veh or (veh.gang or '') == '' then return false, "Ce véhicule n'appartient à aucune organisation." end
    if veh.license == '' then return false, "C'est un véhicule de départ sans ancien propriétaire : supprime-le depuis Garages et véhicules." end
    DB.exec("UPDATE pb_vehicles SET gang = '' WHERE plate = ?", { plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { plate })
    ctx.audit('economy', 'orgs.vehicle.release', plate, { gang = veh.gang }, { license = veh.license })
    ctx.toast = 'Véhicule rendu à son ancien propriétaire.'
    return true
end, { confirm = { title = "Retirer à l'organisation ?", text = 'Le véhicule retourne dans le garage personnel de la personne qui l\'avait donné.' } })

-- Le client ne montre le garage de gang qu'aux membres : on lui dit son gang à l'arrivée et à chaque changement
local function tellGang(src)
    local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
    TriggerClientEvent('pb:g:mygang', src, g and g.id or '')
end
AddEventHandler('pb_panel:gangChanged', function(src) if src and G.Get(src) then tellGang(src) end end)
table.insert(G.beginHooks, function(src) SetTimeout(1500, function() if G.Get(src) then tellGang(src) end end) end)

local function money(n) return (tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) .. ' $' end

-- Formulaire de création (réutilisé par la Carte du jeu) ------------------------------------------------------------------------------
function Orgs.CreateForm()
    return { type = 'form', id = 'orgs.create', title = 'Ajouter une organisation illégale', desc = "Renseigne les infos : le coffre est garni et les véhicules de départ ajoutés, puis tu poses les points en jeu (coffre, bureau du chef, garage, sortie des véhicules).", cols = 2, fields = {
        { k = 'label', type = 'text', label = "Nom de l'organisation", required = true, maxlen = 24 },
        { k = 'color', type = 'color', label = 'Couleur' },
        { k = 'id', type = 'text', label = 'Identifiant (facultatif)', maxlen = 24, pattern = '^[%w_]*$', hint = 'Lettres, chiffres, _ : sert dans les scripts.' },
        { k = 'boss', type = 'number', label = 'ID du chef, en ligne (facultatif)', min = 0, max = 65535, hint = 'Il rejoint l\'organisation et en devient le chef.' },
        { k = 'starter', type = 'toggle', label = 'Garnir le coffre et ajouter les véhicules de départ' },
        { k = 'points', type = 'toggle', label = 'Poser tous les points maintenant (en jeu)', hint = 'Sinon : Carte du jeu › Configurer tout.' } },
        values = { label = '', color = '#b58cff', id = '', boss = 0, starter = true, points = true }, submit = { action = 'orgs.create', label = 'Créer' } }
end

PB.Module({
    id = 'orgs', label = 'Organisations', icon = 'users', group = 'Serveur', order = 91, perm = 'orgs.view', hint = 'Gangs : création guidée, pack de départ, véhicules',
    caps = function()
        return PB.Capsify({
            { 'Création guidée : infos puis points posés en jeu', 'ok', 'Quartier général, bureau du chef, coffre, garage (entrée + sortie des véhicules).' },
            { 'Pack de départ dans le coffre, argent et véhicules', 'ok', 'Contenu réglable ; donné une fois (redonnable depuis la liste).' },
            { 'Véhicules de gang : sortir, ranger, clés pour tous les membres', 'ok', "Décidé par le serveur ; grade minimum réglable." },
            { 'Donner / reprendre un véhicule, le chef attribue à un membre', 'ok', 'Depuis le menu du garage de gang, journalisé.' },
            { 'Attribuer un véhicule existant depuis le panel', 'ok', "Par plaque ; les doubles de clés sont retirés." },
            { 'Suppression d\'une organisation', 'off', "Passe par l'onglet Gangs (les véhicules et le coffre restent en base)." },
            { 'Tout est vérifié dans un vrai client FiveM', 'warn', "Testé par simulation côté serveur et navigateur sans jeu : à essayer en jeu." },
        })
    end,
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Organisations', icon = 'users', build = function()
                local rows = {}
                for _, d in ipairs(Orgs.List()) do
                    local acts = {}
                    if ctx.has('orgs.edit') then
                        acts[#acts + 1] = { action = 'orgs.points', label = 'Poser les points', icon = 'pin', payload = { gang = d.id } }
                        acts[#acts + 1] = { action = 'orgs.starter', label = 'Redonner le pack', icon = 'gift', payload = { gang = d.id } }
                    end
                    rows[#rows + 1] = { name = d.label, id = d.id, color = d.color or '', members = Orgs.Members(d.id), cars = Orgs.Count(d.id) .. ' / ' .. cfg('max_vehicles', 10), vault = money(Orgs.Vault(d.id)), actions = acts }
                end
                return { B.table({ id = 'orgl', title = 'Organisations (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'members', label = 'Membres' }, { k = 'cars', label = 'Véhicules' }, { k = 'vault', label = 'Caisse' } }, rows = rows, empty = "Aucune organisation : crée la première dans l'onglet suivant." }),
                    B.notice('info', "« Poser les points » te guide en jeu : coffre, bureau du chef, garage et sortie des véhicules. Les points déjà posés restent en place.") }
            end },
            { id = 'create', label = 'Créer', icon = 'plus', perm = 'orgs.edit', build = function() return { Orgs.CreateForm() } end },
            { id = 'vehicles', label = 'Véhicules', icon = 'car', build = function()
                local gopts, rows = {}, {}
                for _, d in ipairs(Orgs.List()) do
                    gopts[#gopts + 1] = { d.id, d.label }
                    for _, v in ipairs(Orgs.Vehicles(d.id)) do
                        rows[#rows + 1] = { org = d.label, plate = v.plate, label = v.label, state = ({ garage = 'Au garage', out = 'Dehors', impound = 'Fourrière' })[v.state] or v.state, from = v.license == '' and 'Pack de départ' or 'Donné par un membre',
                            actions = (ctx.has('orgs.edit') and v.license ~= '') and { { action = 'orgs.vehicle.release', label = 'Retirer', icon = 'undo', danger = true, payload = { plate = v.plate } } } or {} }
                    end
                end
                local blocks = { B.table({ id = 'orgv', title = "Véhicules des organisations (" .. #rows .. ")", search = true, columns = { { k = 'org', label = 'Organisation' }, { k = 'plate', label = 'Plaque', type = 'mono' }, { k = 'label', label = 'Modèle' }, { k = 'state', label = 'État' }, { k = 'from', label = 'Origine' } }, rows = rows, empty = 'Aucun véhicule d\'organisation.' }) }
                if ctx.has('orgs.edit') then
                    blocks[#blocks + 1] = { type = 'form', id = 'orgs.vehicle.add', title = 'Ajouter un véhicule neuf', cols = 2, fields = { { k = 'gang', type = 'select', label = 'Organisation', opts = gopts, required = true }, { k = 'model', type = 'text', label = 'Modèle (ex. sultan)', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom affiché (facultatif)', maxlen = 64 } },
                        values = { gang = gopts[1] and gopts[1][1] or '', model = '', label = '' }, submit = { action = 'orgs.vehicle.add', label = 'Ajouter' } }
                    blocks[#blocks + 1] = { type = 'form', id = 'orgs.vehicle.assign', title = 'Attribuer un véhicule existant', desc = 'Le véhicule d\'un joueur (par plaque) passe à l\'organisation ; tous ses membres ont la clé.', cols = 2, fields = { { k = 'plate', type = 'text', label = 'Plaque', required = true, maxlen = 8 }, { k = 'gang', type = 'select', label = 'Organisation', opts = gopts, required = true } },
                        values = { plate = '', gang = gopts[1] and gopts[1][1] or '' }, submit = { action = 'orgs.vehicle.assign', label = 'Attribuer' } }
                end
                return blocks
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'orgs.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('orgs', function(R)
    local id = Orgs.Create({ label = 'Test Orga', id = 'zz_selftest', color = '#112233' }, 'test')
    R.check(id == 'zz_selftest' and Orgs.Def('zz_selftest') ~= nil, 'orgs', 'création impossible')
    R.check(Orgs.Create({ label = 'Test Orga', id = 'zz_selftest' }, 'test') == nil, 'orgs', 'doublon accepté')
    local sum = Orgs.Starter('zz_selftest', false)
    R.check(sum ~= nil and sum.items >= 1, 'orgs', 'pack de départ vide')
    R.check(Orgs.Starter('zz_selftest', false) == nil, 'orgs', 'pack donné deux fois')
    R.check(Orgs.Count('zz_selftest') == #(cfg('starter_vehicles', {}) or {}) or Orgs.Count('zz_selftest') == cfg('max_vehicles', 10), 'orgs', 'véhicules de départ manquants')
    R.check(Orgs.Vault('zz_selftest') == (cfg('starter_cash', 0) or 0), 'orgs', 'argent de départ absent')
    local plate = Orgs.Count('zz_selftest') > 0 and Orgs.Vehicles('zz_selftest')[1].plate or nil
    R.check(plate ~= nil and G.Garage and not G.Garage.HasKey('lic-inconnue', plate), 'orgs', 'un inconnu a la clé du véhicule du gang')
    -- nettoyage
    DB.exec("DELETE FROM pb_vehicles WHERE gang = 'zz_selftest'")
    DB.exec("DELETE FROM pb_inv WHERE owner = 'o:zz_selftest'")
    DB.exec("DELETE FROM pb_orga_vault WHERE gang = 'zz_selftest'")
    DB.exec("DELETE FROM pb_orgs WHERE id = 'zz_selftest'")
    DB.exec("DELETE FROM pb_org_groups WHERE kind = 'gang' AND name = 'zz_selftest'")
    DB.exec("DELETE FROM pb_org_grades WHERE kind = 'gang' AND name = 'zz_selftest'")
    if G.Tags.RefreshNative then G.Tags.RefreshNative() end
    R.check(Orgs.Def('zz_selftest') == nil, 'orgs', 'nettoyage impossible')
end)
