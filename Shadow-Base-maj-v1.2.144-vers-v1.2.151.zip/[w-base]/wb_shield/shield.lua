-- wb_shield : script partagé, ajouté aux fxmanifest des ressources à protéger.
--  * côté client, avant chaque TriggerServerEvent, un jeton signé est envoyé dans un message séparé (wb_shield:tok) ; les arguments de l'évènement ne changent JAMAIS ;
--  * côté serveur, RegisterNetEvent / AddEventHandler vérifient qu'un jeton valide attendait cet évènement, puis appellent le script tel quel ;
--  * un jeton ne sert qu'une fois. Un évènement n'est « armé » (donc sanctionné quand il arrive sans jeton) qu'après avoir été vu des dizaines de fois avec un jeton valide.
-- Rien ici n'arrête un cheat qui lit la mémoire du jeu pour récupérer le secret de session : il bloque les menus qui déclenchent des évènements « à l'aveugle ».
local RES = GetCurrentResourceName()
if RES == 'wb_shield' then return end
local isServer = IsDuplicityVersion()

local function mix(s)
    local h = 0xcbf29ce484222325
    for i = 1, #s do h = (h ~ s:byte(i)) * 0x100000001b3 end
    h = h ~ (h >> 29); h = h * 0xbf58476d1ce4e5b9; h = h ~ (h >> 32)
    return string.format('%x', h)
end
local function ignored()
    local set = {}
    for n in tostring(GetConvar('wb_shield_ignore', '')):gmatch('[^,%s]+') do set[n] = true end
    return set
end
local SKIP = { '^__cfx', '^cfx', '^chat:', '^txAdmin', '^txsv:', '^wb_shield:', '^playerJoining$', '^playerDropped$', '^onResource', '^onClientResource', '^onServerResource', '^baseevents:', '^mapmanager', '^sessionmanager', '^hardcap', '^rconCommand$' }
local function skipName(name)
    if type(name) ~= 'string' then return true end
    for _, p in ipairs(SKIP) do if name:find(p) then return true end end
    return false
end

------------------------------------------------------------------------------------------------------------------------------------
if not isServer then
    local rawTrigger, rawLatent = TriggerServerEvent, TriggerLatentServerEvent
    local secret, protected, queue = nil, {}, {}
    local skip = ignored()
    math.randomseed(GetGameTimer() + math.floor(GetFrameTime() * 1000000))

    local function dispatch(latent, name, bps, args)
        if secret and secret ~= '' and protected[name] and not skip[name] then
            local r = math.random(1, 2147483647)
            rawTrigger('wb_shield:tok', name, r .. ':' .. mix(secret .. '|' .. name .. '|' .. r))
        end
        if latent then rawLatent(name, bps, table.unpack(args, 1, args.n)) else rawTrigger(name, table.unpack(args, 1, args.n)) end
    end
    local function flush()
        local q = queue
        queue = {}
        for _, e in ipairs(q) do dispatch(e[1], e[2], e[3], e[4]) end
    end
    TriggerServerEvent = function(name, ...)
        if not secret and not skipName(name) then
            if #queue < 300 then queue[#queue + 1] = { false, name, nil, table.pack(...) } return end
        end
        dispatch(false, name, nil, table.pack(...))
    end
    TriggerLatentServerEvent = function(name, bps, ...)
        if not secret and not skipName(name) then
            if #queue < 300 then queue[#queue + 1] = { true, name, bps, table.pack(...) } return end
        end
        dispatch(true, name, bps, table.pack(...))
    end

    RegisterNetEvent('wb_shield:init', function(sec, list)
        if type(sec) ~= 'string' then return end
        secret = sec                                   -- un nouveau secret remplace l'ancien (redémarrage du bouclier)
        for _, n in ipairs(type(list) == 'table' and list or {}) do protected[tostring(n)] = true end
        flush()
    end)
    RegisterNetEvent('wb_shield:add', function(list)
        for _, n in ipairs(type(list) == 'table' and list or {}) do protected[tostring(n)] = true end
    end)
    CreateThread(function()
        Wait(500)
        rawTrigger('wb_shield:hello', RES)
        Wait(15000)
        if not secret then secret = '' flush() end     -- serveur sans protection : on n'attend pas indéfiniment
    end)
    return
end

------------------------------------------------------------------------------------------------------------------------------------
local rawRegister, rawAdd = RegisterNetEvent, AddEventHandler
local netNames, pending, flushing = {}, {}, false
local skip = ignored()

local function declare(name, listener)
    if skip[name] or skipName(name) then return end
    if netNames[name] and not listener then return end
    netNames[name] = true
    pending[#pending + 1] = name                       -- un doublon par écouteur : le bouclier compte combien de scripts écoutent chaque évènement
    if not flushing then
        flushing = true
        SetTimeout(250, function()
            flushing = false
            local l = pending
            pending = {}
            pcall(function() exports['wb_shield']:Declare(l) end)
        end)
    end
end

local function guard(name, fn)
    declare(name, true)
    return function(...)
        local n = tonumber(source)
        if not n or n <= 0 or GetInvokingResource() then return fn(...) end          -- évènement local : rien à vérifier
        local ok, verdict = pcall(function() return exports['wb_shield']:Check(n, name, RES, false) end)
        if ok and verdict == 'retry' then                                             -- le jeton arrive parfois une poignée de ms après (évènement latent)
            pcall(Wait, 300)
            ok, verdict = pcall(function() return exports['wb_shield']:Check(n, name, RES, true) end)
        end
        if ok and verdict == false then return end                                    -- refusé : évènement armé sans jeton valide
        return fn(...)
    end
end

RegisterNetEvent = function(name, fn)
    local h = rawRegister(name)
    if type(name) == 'string' then
        if type(fn) == 'function' then
            if skip[name] or skipName(name) then return rawAdd(name, fn) end
            return rawAdd(name, guard(name, fn))
        end
        declare(name)
    end
    return h
end
RegisterServerEvent = RegisterNetEvent
-- un évènement réseau déclenché aussi en LOCAL par un script (TriggerEvent) n'est jamais exigé avec un jeton : impossible de distinguer les deux appels avec certitude
local rawTE, told = TriggerEvent, {}
TriggerEvent = function(name, ...)
    if type(name) == 'string' and not told[name] then
        told[name] = true
        pcall(function() exports['wb_shield']:Local(name) end)
    end
    return rawTE(name, ...)
end
AddEventHandler = function(name, fn)
    if netNames[name] and type(fn) == 'function' then return rawAdd(name, guard(name, fn)) end
    return rawAdd(name, fn)
end
