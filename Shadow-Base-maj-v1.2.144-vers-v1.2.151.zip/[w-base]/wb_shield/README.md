# wb_shield — protection contre le déclenchement d'évènements

Un menu de triche déclenche des évènements serveur « à l'aveugle » (donner de l'argent, un objet, une arme…). wb_shield exige un **jeton signé** sur les évènements protégés. Sans jeton valide, l'évènement est refusé et le joueur est signalé à l'anticheat (réglé sur **bannissement** dans le profil Strict).

## Comment ça marche
- Chaque joueur reçoit un secret de session. Avant chaque `TriggerServerEvent`, le client envoie un message `wb_shield:tok` (nom de l'évènement + jeton signé). **Les arguments de l'évènement ne changent jamais** : tes scripts ne voient aucune différence.
- Le serveur vérifie le jeton quand l'évènement arrive. Un jeton ne sert qu'une fois (anti-rejeu).
- **Apprentissage : un évènement n'est « armé » qu'après avoir été vu avec 30 jetons valides** (`wb_shield_arm`), et sans jeton chez 3 joueurs différents au plus. Tant qu'il n'est pas armé, un appel sans jeton est seulement compté : un script non protégé ou un cas oublié ne fait donc jamais sanctionner un joueur. L'apprentissage est sauvegardé dans `learned.json` (non versionné).
- Les évènements aussi déclenchés en local par un script (`TriggerEvent`) ne sont jamais exigés. Les évènements locaux ne sont jamais vérifiés.
- Garde-fous côté anticheat : **coupe-circuit** (3 joueurs différents détectés pour la même chose en 10 min = sanctions de ce type suspendues et alerte au staff) et **délai de 6 s avant un bannissement** pour laisser le coupe-circuit réagir.

## Installation
- Les ressources du dépôt (`pb_panel`, `wb_*`, etc.) chargent déjà le bouclier via `shared_script '@wb_shield/shield.lua'`. Mets `ensure wb_shield` avant elles dans `server.cfg`.
- Pour une ressource tierce, depuis la console du serveur : `shield_install <ressource|all> [dry]`, `shield_remove <ressource|all>`. Un `wupdate` remet les manifestes d'origine.
- `shield_status` (compteurs), `shield_events` (évènements non armés d'abord : ce sont ceux à surveiller).

## Réglages (server.cfg)
```
set wb_shield_mode "block"   # block (défaut) refuse les évènements armés sans jeton | log signale seulement
set wb_shield_rate 60        # appels / évènement / joueur / 10 s avant signalement (refus au-delà de 5x)
set wb_shield_arm 30         # jetons valides nécessaires pour armer un évènement
set wb_shield_ignore "evt:a,evt:b"   # évènements exclus
```

## Limites honnêtes
- Vérifié par simulation uniquement, pas dans un vrai client FiveM. Laisse tourner quelques jours en `log` (ou profil Prudent) puis regarde `shield_events` avant de passer en Strict.
- Un cheat qui lit la mémoire du client peut récupérer le secret et signer ses évènements : wb_shield bloque les menus « à l'aveugle », pas un attaquant qui connaît le système.
- Une ressource tierce non protégée qui déclenche un évènement protégé n'est jamais sanctionnée (évènement non armé, ou exclu par `wb_shield_ignore`).
