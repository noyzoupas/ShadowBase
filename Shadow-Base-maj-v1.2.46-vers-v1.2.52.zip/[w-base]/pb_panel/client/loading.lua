-- Écran de chargement entre le loading screen et l'écran d'entrée : le joueur ne voit plus son personnage tomber dans le vide.
-- L'écran est affiché d'office par la page (web/game/boot.js). Le personnage reste figé derrière jusqu'à G.LoadingDone,
-- appelé quand l'écran d'entrée, le créateur ou la reconnexion sont prêts. Sécurité : levé tout seul au bout de 60 s.
local G = PBG
local active = true

-- o.keep : le personnage reste figé (l'écran d'entrée ou le créateur s'en occupent) ; o.delay : attente avant de lever l'écran (ms)
function G.LoadingDone(o)
    if not active then return end
    active = false
    o = o or {}
    CreateThread(function()
        if not o.keep then
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            RequestCollisionAtCoord(c.x, c.y, c.z)
            local t = GetGameTimer()
            while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 4000 do Wait(50) ped = PlayerPedId() end
            FreezeEntityPosition(PlayerPedId(), false)
        end
        if o.delay then Wait(o.delay) end
        G.send('boot.done', {})
    end)
end

CreateThread(function()
    local started
    while active do
        Wait(200)
        FreezeEntityPosition(PlayerPedId(), true)
        if not started and NetworkIsPlayerActive(PlayerId()) and not (GetIsLoadingScreenActive and GetIsLoadingScreenActive()) then
            started = GetGameTimer()
            G.send('boot.ping', {})
        end
        if started and GetGameTimer() - started > 60000 then G.LoadingDone() end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and active then FreezeEntityPosition(PlayerPedId(), false) end end)
