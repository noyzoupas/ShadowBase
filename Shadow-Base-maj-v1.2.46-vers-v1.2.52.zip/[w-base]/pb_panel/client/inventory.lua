-- Inventaire : ouverture, coffres et objets au sol (marqueurs + invite « E »), raccourcis rapides, soin. Le serveur valide tout.
local G = PBG
local isOpen = false
local stashes, drops = {}, {}
local promptKey
local camInfo        -- positions de la caméra (pour placer les joueurs proches)
local clones = {}    -- joueurs proches clonés à droite de l'écran (décor de l'inventaire)
local nearSig, lastNear = '', nil
local cam            -- caméra de face : le vrai personnage reste visible au milieu de l'inventaire
local base = {}      -- apparence d'avant l'habillage (pour retirer un vêtement)

local sway = false   -- le personnage oscille lentement pendant que le sac est ouvert (« maquette » vivante)
local swayBase, platform = 0.0, nil
local function icfg() return (G.cfg and G.cfg.inv) or {} end

local function camOn()
    local ped = PlayerPedId()
    local c = icfg()
    if cam or IsPedInAnyVehicle(ped, false) then return end
    local e4 = c.style ~= 'classic'
    local mode = c.ped_mode or 'menu'
    if (e4 and mode ~= 'camera') or (not e4 and c.ped_view == false) then return end
    -- E4 « caméra » : seul le personnage est net (profondeur de champ courte), le décor derrière est flouté
    local dof = e4 and c.blur ~= false
    -- Ton personnage en entier, au centre, plus ou moins petit selon la distance réglée (6,5 m par défaut ≈ une maquette).
    -- Les panneaux de l'interface sont à gauche et à droite, le centre reste libre. Le personnage reste vivant : respiration, vêtements, armes.
    local dist = math.max(3.0, math.min(12.0, tonumber(e4 and c.ped_dist_e4 or c.ped_dist) or (e4 and 5.0 or 6.5))) + 0.0   -- E4 : le personnage tient entre les deux colonnes d'équipements
    local from = GetOffsetFromEntityInWorldCoords(ped, 0.0, dist, 0.3 + dist * 0.03)
    local to = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.0, 0.02)
    camInfo = { from = from, to = to }
    cam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', from.x, from.y, from.z, 0.0, 0.0, 0.0, 40.0, false, 2)
    PointCamAtCoord(cam, to.x, to.y, to.z)
    SetCamActive(cam, true)
    if dof then
        pcall(function() SetCamUseShallowDofMode(cam, true) SetCamNearDof(cam, dist - 0.8) SetCamFarDof(cam, dist + 0.9) SetCamDofStrength(cam, 1.0) end)
    else
        pcall(function() SetCamUseShallowDofMode(cam, true) SetCamNearDof(cam, 1.0) SetCamFarDof(cam, dist + 12.0) SetCamDofStrength(cam, 0.3) end)
    end
    RenderScriptCams(true, true, 450, true, true)
    swayBase = GetEntityHeading(ped)
    sway = c.ped_sway ~= false
    platform = c.ped_platform ~= false and not e4   -- la maquette E4 n'a pas de socle
    CreateThread(function()
        local t0 = GetGameTimer()
        while cam do
            if dof then SetUseHiDof() end   -- la profondeur de champ courte se redemande à chaque image
            local p = PlayerPedId()
            if platform then
                local pc = GetEntityCoords(p)
                DrawMarker(1, pc.x, pc.y, pc.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.5, 1.5, 0.06, 223, 226, 231, 70, false, false, 2, false, nil, nil, false)
            end
            if sway and not IsPedInAnyVehicle(p, false) then
                -- demi-tour lent d'un côté à l'autre (±35°), le personnage garde son animation d'attente
                local a = math.sin((GetGameTimer() - t0) / 2200.0) * 35.0
                SetEntityHeading(p, (swayBase + a) % 360.0)
            end
            Wait(0)
        end
        local p = PlayerPedId()
        if sway and DoesEntityExist(p) then SetEntityHeading(p, swayBase) end
    end)
end
local function camOff()
    if not cam then return end
    RenderScriptCams(false, true, 350, true, true)
    DestroyCam(cam, false)
    cam = nil
end

-- Maquette E4 : ton personnage seul au centre, net et en couleur (rendu de l'aperçu du menu pause, position « centre »),
-- et le jeu flouté derrière l'inventaire. La copie du personnage est invisible dans le monde et supprimée à la fermeture.
local menuPed, blurred = nil, false
local function menuPedGive()
    local c = ClonePed(PlayerPedId(), false, false, true)
    if not c or c == 0 then return end
    SetEntityVisible(c, false, false)
    SetEntityCollision(c, false, false)
    FreezeEntityPosition(c, true)
    SetEntityInvincible(c, true)
    SetBlockingOfNonTemporaryEvents(c, true)
    Wait(120)
    if not isOpen or not DoesEntityExist(c) then if DoesEntityExist(c) then DeleteEntity(c) end return end
    pcall(function()
        GivePedToPauseMenu(c, 1)          -- 0 = gauche, 1 = centre, 2 = droite
        SetPauseMenuPedLighting(true)
        SetPauseMenuPedSleepState(true)
    end)
    local old = menuPed
    menuPed = c
    if old and DoesEntityExist(old) then DeleteEntity(old) end
end
local function menuPedOn()
    if menuPed ~= nil then return end
    menuPed = false   -- en cours
    pcall(function()
        ReplaceHudColourWithRgba(117, 0, 0, 0, 0)   -- fond du menu pause transparent
        SetFrontendActive(true)
        ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_EMPTY_NO_BACKGROUND'), false, -1)
    end)
    -- voile noir dessiné par le jeu DERRIÈRE le menu pause : le décor s'assombrit partout de la même façon, le personnage reste net et clair
    CreateThread(function()
        local a = math.floor(math.max(0, math.min(255, (tonumber(icfg().ped_dim) or 12) * 2.55)))
        while menuPed ~= nil do
            SetScriptGfxDrawBehindPausemenu(true)
            DrawRect(0.5, 0.5, 1.0, 1.0, 0, 0, 0, a)
            SetScriptGfxDrawBehindPausemenu(false)
            Wait(0)
        end
    end)
    CreateThread(function()
        Wait(150)
        pcall(function() SetMouseCursorVisibleInMenus(false) end)
        if isOpen then menuPedGive() else menuPed = nil end
    end)
end
local function menuPedOff()
    if menuPed == nil then return end
    pcall(function() ClearPedInPauseMenu() end)
    if menuPed and DoesEntityExist(menuPed) then DeleteEntity(menuPed) end
    menuPed = nil
    pcall(function() SetFrontendActive(false) end)
end
local function e4On()
    local c = icfg()
    if c.style == 'classic' then return end
    local mode = c.ped_mode or 'menu'
    if mode == 'menu' then menuPedOn() end
    -- flou du jeu entier : pas en mode caméra (il flouterait aussi le personnage, qui a sa propre profondeur de champ)
    if mode ~= 'camera' and c.blur ~= false and not blurred then TriggerScreenblurFadeIn(250.0) blurred = true end
end
local function e4Off()
    menuPedOff()
    if blurred then TriggerScreenblurFadeOut(250.0) blurred = false end
end

-- Habillage envoyé par le serveur : composants (c) et accessoires (p). Le serveur décide, ici on applique.
RegisterNetEvent('pb:g:inv:wear', function(j)
    local d = G.decode(j)
    if not d or type(d.list) ~= 'table' then return end
    local ped = PlayerPedId()
    for _, w in ipairs(d.list) do
        local idx = math.floor(tonumber(w.idx) or -1)
        if idx >= 0 and idx <= 11 then
            if w.kind == 'p' then
                if w.on then
                    if base['p' .. idx] == nil then base['p' .. idx] = GetPedPropIndex(ped, idx) end
                    SetPedPropIndex(ped, idx, math.floor(tonumber(w.drawable) or 0), math.floor(tonumber(w.texture) or 0), true)
                else ClearPedProp(ped, idx) end
            else
                if w.on then
                    if base['c' .. idx] == nil then base['c' .. idx] = { GetPedDrawableVariation(ped, idx), GetPedTextureVariation(ped, idx) } end
                    SetPedComponentVariation(ped, idx, math.floor(tonumber(w.drawable) or 0), math.floor(tonumber(w.texture) or 0), 0)
                else
                    local b = base['c' .. idx]
                    SetPedComponentVariation(ped, idx, b and b[1] or math.floor(tonumber(w.none) or 0), b and b[2] or 0, 0)
                end
            end
        end
    end
    if menuPed then CreateThread(function() Wait(150) if isOpen and menuPed then menuPedGive() end end) end
end)


-- Joueurs à proximité : leur ped est copié et aligné à droite de l'écran, face à la caméra (comme sur la capture).
-- Le serveur décide qui est proche ; ici on ne fait que de l'affichage (copies sans collision, supprimées à la fermeture).
local function clearClones()
    for _, c in pairs(clones) do if c.ped and DoesEntityExist(c.ped) then DeleteEntity(c.ped) end end
    clones = {}
end
local function layoutClones(near, retry)
    clearClones()
    -- la maquette E4 a son coffre à droite : pas de copies des joueurs proches (ils apparaissent dans la zone de don)
    if not isOpen or not camInfo or type(near) ~= 'table' or icfg().style ~= 'classic' then G.send('inv.pos', { list = {} }) return end
    local from, to = camInfo.from, camInfo.to
    local fx, fy = to.x - from.x, to.y - from.y
    local len = math.sqrt(fx * fx + fy * fy)
    if len < 0.01 then G.send('inv.pos', { list = {} }) return end
    fx, fy = fx / len, fy / len
    local rx, ry = fy, -fx
    local heading = GetHeadingFromVector_2d(-fx, -fy)
    local list = {}
    local me = GetEntityCoords(PlayerPedId())
    local missing = false
    for i, n in ipairs(near) do
        if i > 8 then break end
        local pid = GetPlayerFromServerId(tonumber(n.id) or -1)
        local src = pid ~= -1 and GetPlayerPed(pid) or 0
        if src ~= 0 and DoesEntityExist(src) then
            local row, col = (i - 1) // 4, (i - 1) % 4
            local depth = row == 0 and 2.0 or 0.8
            local lat = (row == 0 and 1.4 or 1.1) + col * (row == 0 and 0.75 or 0.6)
            local x, y = to.x + rx * lat + fx * depth, to.y + ry * lat + fy * depth
            local z = me.z - 1.0
            local okg, gz = GetGroundZFor_3dCoord(x, y, me.z + 1.0, false)
            if okg then z = gz end
            local ped = ClonePed(src, false, false, true)
            if ped and ped ~= 0 then
                SetEntityCoordsNoOffset(ped, x, y, z + 1.0, false, false, false)
                SetEntityHeading(ped, heading)
                FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true) SetBlockingOfNonTemporaryEvents(ped, true) SetEntityCollision(ped, false, false)
                ClearPedTasksImmediately(ped)
                pcall(function() TaskLookAtCoord(ped, from.x, from.y, from.z, -1, 0, 2) end)   -- regarde la caméra
                local a = n.far and 130 or 255
                SetEntityAlpha(ped, 0, false)
                clones[#clones + 1] = { ped = ped, id = n.id, x = x, y = y, z = z, a = a, born = GetGameTimer() + (i - 1) * 90 }
            else missing = true end
        else missing = true end
    end
    if missing and not retry then    -- joueur pas encore chargé chez moi : on réessaie une fois
        CreateThread(function() Wait(1500) if isOpen and lastNear == near then layoutClones(near, true) end end)
    end
    -- apparition en fondu + lumière douce sur chaque copie tant que l'inventaire est ouvert
    CreateThread(function()
        local mine = clones
        while isOpen and clones == mine and #mine > 0 do
            local now = GetGameTimer()
            for _, c in ipairs(mine) do
                if c.ped and DoesEntityExist(c.ped) then
                    local k = math.max(0.0, math.min(1.0, (now - c.born) / 450.0))
                    SetEntityAlpha(c.ped, math.floor(c.a * k), false)
                    DrawLightWithRange(c.x, c.y, c.z + 2.2, 200, 215, 255, 4.5, 1.2 * k)
                end
            end
            Wait(0)
        end
    end)
    CreateThread(function()
        Wait(700)    -- le temps que la caméra arrive
        if not isOpen then return end
        for _, c in ipairs(clones) do
            local ok1, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z + 1.0)
            local ok2, hx, hy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z + 1.75)
            local ok3, fx2, fy2 = GetScreenCoordFromWorldCoord(c.x, c.y, c.z)
            if ok2 and ok3 then
                local hgt = math.max(0.05, fy2 - hy)
                local w = hgt * 0.42 * (9.0 / 16.0)
                list[#list + 1] = { id = c.id, x = math.max(0.0, math.min(1.0, hx - w / 2)), y = math.max(0.0, math.min(1.0, hy)), w = w, h = hgt }
            end
        end
        G.send('inv.pos', { list = list })
    end)
end

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if not isOpen then return end
    isOpen = false
    clearClones()
    camOff()
    e4Off()
    TriggerServerEvent('pb:g:inv:close')
    G.focus(false)
    G.send('inv.close', {})
end
G.invClose = close

local function open(container)
    if isOpen or busy() or not G.begun then return end
    TriggerServerEvent('pb:g:inv:open', container)
end

RegisterNetEvent('pb:g:inv:sync', function(j)
    local d = G.decode(j)
    if not d then return end
    G.send('inv.sync', d)
    if type(d.near) == 'table' then lastNear = d.near end
    if isOpen and type(d.near) == 'table' then
        local ids = {}
        for _, n in ipairs(d.near) do ids[#ids + 1] = tostring(n.id) .. (n.far and 'f' or '') end
        local sig = table.concat(ids, ',')
        if sig ~= nearSig then nearSig = sig layoutClones(d.near) end
    end
end)
RegisterNetEvent('pb:g:inv:opened', function()
    if isOpen or busy() then TriggerServerEvent('pb:g:inv:close') return end
    isOpen = true
    nearSig = ''
    camOn()
    e4On()
    G.focus(true)
    G.send('inv.open', {})
    if lastNear then local ids = {} for _, n in ipairs(lastNear) do ids[#ids + 1] = tostring(n.id) .. (n.far and 'f' or '') end nearSig = table.concat(ids, ',') layoutClones(lastNear) end
end)
RegisterNetEvent('pb:g:inv:drops', function(j) drops = G.decode(j) or {} end)
RegisterNetEvent('pb:g:inv:armor', function(amount)
    local ped = PlayerPedId()
    local n = math.max(0, math.min(100, (GetPedArmour(ped) or 0) + math.floor(tonumber(amount) or 0)))
    SetPedArmour(ped, n)
end)
RegisterNetEvent('pb:g:inv:heal', function(amount)
    local ped = PlayerPedId()
    local max = GetEntityMaxHealth(ped)
    SetEntityHealth(ped, math.max(1, math.min(max, GetEntityHealth(ped) + math.floor(tonumber(amount) or 0))))
end)

-- Manger / boire : animation de 4 s avec l'objet tenu dans la main (choisi d'après le nom de l'objet), visible par les autres joueurs
local EAT_PROPS = { { 'burger', 'prop_cs_burger_01' }, { 'sandwich', 'prop_sandwich_01' }, { 'chips', 'prop_food_chips' }, { 'fries', 'prop_food_bs_chips' },
    { 'donut', 'prop_donut_02' }, { 'pizza', 'prop_pizza_box_01' }, { 'bread', 'prop_sandwich_01' }, { 'orange', 'ng_proc_food_ornge1a' }, { 'apple', 'ng_proc_food_aple1a' } }
local DRINK_PROPS = { { 'coffee', 'p_amb_coffeecup_01' }, { 'cafe', 'p_amb_coffeecup_01' }, { 'soda', 'prop_ecola_can' }, { 'cola', 'prop_ecola_can' }, { 'sprunk', 'prop_ld_can_01' },
    { 'beer', 'prop_amb_beer_bottle' }, { 'biere', 'prop_amb_beer_bottle' }, { 'wine', 'prop_wine_bot_01' }, { 'vin', 'prop_wine_bot_01' }, { 'juice', 'prop_food_juice01' }, { 'jus', 'prop_food_juice01' } }
local CONSUME = {
    eat = { dict = 'mp_player_inteat@burger', clip = 'mp_player_int_eat_burger', prop = 'prop_cs_burger_01', list = EAT_PROPS, pos = { 0.13, 0.05, 0.02 }, rot = { -50.0, 16.0, 60.0 } },
    drink = { dict = 'mp_player_intdrink', clip = 'loop_bottle', prop = 'prop_ld_flow_bottle', list = DRINK_PROPS, pos = { 0.12, 0.008, 0.03 }, rot = { 240.0, -60.0, 0.0 } },
}
local eating = false
RegisterNetEvent('pb:g:inv:consume', function(kind, item)
    local a = CONSUME[kind]
    if not a or eating then return end
    eating = true
    CreateThread(function()
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) and kind == 'eat' then a = { dict = 'mp_player_inteat@burger', clip = 'mp_player_int_eat_burger_fp', prop = a.prop, list = a.list, pos = a.pos, rot = a.rot } end
        local model = a.prop
        local name = tostring(item or ''):lower()
        for _, p in ipairs(a.list) do if name:find(p[1], 1, true) then model = p[2] break end end
        local h = GetHashKey(model)
        if not IsModelInCdimage(h) then h = GetHashKey(a.prop) end   -- modèle absent du jeu : objet par défaut
        local obj
        if IsModelInCdimage(h) then
            RequestModel(h)
            local t = GetGameTimer() + 1500
            while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
            if HasModelLoaded(h) then
                local c = GetEntityCoords(ped)
                obj = CreateObject(h, c.x, c.y, c.z + 0.2, true, true, false)
                AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 18905), a.pos[1], a.pos[2], a.pos[3], a.rot[1], a.rot[2], a.rot[3], true, true, false, true, 1, true)
                SetModelAsNoLongerNeeded(h)
            end
        end
        RequestAnimDict(a.dict)
        local t = GetGameTimer() + 1500
        while not HasAnimDictLoaded(a.dict) and GetGameTimer() < t do Wait(10) end
        if HasAnimDictLoaded(a.dict) then TaskPlayAnim(ped, a.dict, a.clip, 8.0, -8.0, 4000, 49, 0, false, false, false) end
        Wait(4000)
        StopAnimTask(ped, a.dict, a.clip, 1.0)
        if obj and DoesEntityExist(obj) then DeleteEntity(obj) end
        RemoveAnimDict(a.dict)
        eating = false
    end)
end)

-- Kit de réparation : 8 s à genoux devant le véhicule (le serveur a choisi le véhicule et consommé le kit)
RegisterNetEvent('pb:g:inv:repairkit', function(netId)
    local veh = NetToVeh(tonumber(netId) or 0)
    if veh == 0 or not DoesEntityExist(veh) then return end
    local ped = PlayerPedId()
    TaskTurnPedToFaceEntity(ped, veh, 800) Wait(800)
    RequestAnimDict('mini@repair')
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded('mini@repair') and GetGameTimer() < t do Wait(10) end
    if HasAnimDictLoaded('mini@repair') then TaskPlayAnim(ped, 'mini@repair', 'fixing_a_ped', 8.0, -8.0, -1, 1, 0, false, false, false) end
    G.send('crime.progress', { label = 'Réparation du véhicule', secs = 8 })
    local stop, ok = GetGameTimer() + 8000, true
    while GetGameTimer() < stop do
        Wait(100)
        if IsEntityDead(ped) or #(GetEntityCoords(ped) - GetEntityCoords(veh)) > 7.0 then ok = false break end
    end
    StopAnimTask(ped, 'mini@repair', 'fixing_a_ped', 1.0)
    if not ok then G.send('crime.progress', { cancel = true }) G.send('notify', { type = 'warn', title = 'Réparation', text = 'Réparation interrompue.' }) return end
    NetworkRequestControlOfEntity(veh)
    local w = GetGameTimer() + 1000
    while not NetworkHasControlOfEntity(veh) and GetGameTimer() < w do Wait(10) NetworkRequestControlOfEntity(veh) end
    SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleUndriveable(veh, false)
    G.send('notify', { type = 'success', title = 'Réparation', text = 'Véhicule réparé.' })
end)

G.invIsOpen = function() return isOpen end
G.nui['inv.close'] = function() close() return {} end
G.nui['inv.sort'] = function() if isOpen then TriggerServerEvent('pb:g:inv:sort') end return {} end
G.nui['inv.outfit'] = function() if isOpen then TriggerServerEvent('pb:g:tenue:save', '') end return {} end
G.nui['inv.trunk'] = function() if isOpen and G.openTrunk then G.openTrunk(true) end return {} end
G.nui['inv.move'] = function(d) if isOpen then TriggerServerEvent('pb:g:inv:move', tostring(d.fo), tonumber(d.fs), tostring(d.to), tonumber(d.ts), tonumber(d.qty)) end return {} end
G.nui['inv.use'] = function(d) if isOpen then TriggerServerEvent('pb:g:inv:use', tonumber(d.slot)) end return {} end
G.nui['inv.unwear'] = function(d) if isOpen and type(d.slot) == 'string' then TriggerServerEvent('pb:g:inv:unwear', d.slot) end return {} end
G.nui['inv.give'] = function(d) if isOpen then TriggerServerEvent('pb:g:inv:give', tonumber(d.target), tonumber(d.slot), tonumber(d.qty)) end return {} end
G.nui['inv.drop'] = function(d) if isOpen then TriggerServerEvent('pb:g:inv:drop', tonumber(d.slot), tonumber(d.qty)) end return {} end

RegisterCommand('pb_inv', function() if isOpen then close() else open(nil) end end, false)

-- Molette d'armes supprimée (Tab, molette de la souris) ; Tab ouvre l'inventaire à la place (réglages Inventaire du panel)
local WHEEL = { 37, 14, 15, 16, 17, 99, 100, 261, 262 }
G.frameHooks = G.frameHooks or {}
G.frameHooks[#G.frameHooks + 1] = function()
    local c = G.cfg.inv
    if not (c and G.begun and c.no_weapon_wheel ~= false) then return false end
    BlockWeaponWheelThisFrame()
    for i = 1, #WHEEL do DisableControlAction(0, WHEEL[i], true) end
    HideHudComponentThisFrame(19) HideHudComponentThisFrame(20)
    if c.tab_opens ~= false and not isOpen and IsDisabledControlJustPressed(0, 37) and not IsNuiFocused() and not IsPauseMenuActive()
        and not busy() and not (G.Menu and G.Menu.IsOpen and G.Menu.IsOpen()) then
        open(nil)
    end
    return true
end
for i = 1, 9 do RegisterCommand('pb_hot' .. i, function() if not busy() and not isOpen and G.begun then TriggerServerEvent('pb:g:inv:use', i) end end, false) end

CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.inv and GetGameTimer() < t do Wait(250) end
    local c = G.cfg.inv or {}
    RegisterKeyMapping('pb_inv', "Ouvrir l'inventaire", 'keyboard', c.key or 'I')
    for i = 1, math.min(5, c.hotbar or 5) do RegisterKeyMapping('pb_hot' .. i, 'Raccourci objet ' .. i, 'keyboard', tostring(i)) end
end)

G.onCfgInv = function(c) stashes = c.stashes or {} if G.SetStashBlips then G.SetStashBlips(stashes) end end
local prevCfg = G.onCfg
G.onCfg = function(c) if prevCfg then prevCfg(c) end G.onCfgInv(c) end

CreateThread(function() while not G.begun do Wait(1000) end TriggerServerEvent('pb:g:inv:needDrops') end)

-- Surpoids : au pas, ni course, ni saut, ni combat, ni véhicule (le serveur prévient et refuse aussi d'utiliser des objets)
local overloaded = false
RegisterNetEvent('pb:g:inv:load', function(over) overloaded = over == true end)
-- (v1.2.45) objet reçu / perdu : carte « +2 / -1 » avec son image (web/game/itemfeed.js)
RegisterNetEvent('pb:g:inv:feed', function(j) local d = G.decode(j) if d then G.send('itemfeed', d) end end)
local HEAVY = { 21, 22, 23, 24, 25, 37, 44, 47, 58, 140, 141, 142, 143, 257, 263, 264 }
G.frameHooks = G.frameHooks or {}
G.frameHooks[#G.frameHooks + 1] = function()
    if not overloaded then return false end
    local ped = PlayerPedId()
    for i = 1, #HEAVY do DisableControlAction(0, HEAVY[i], true) end
    SetPedMoveRateOverride(ped, 0.75)
    SetPedMaxMoveBlendRatio(ped, 1.0)   -- marche, jamais de course
    return true
end

-- Objets jetés : un carton posé par terre (objet local, rien sur le réseau), supprimé quand le tas disparaît
local BAG_MODEL = GetHashKey('prop_cs_cardbox_01')
local bags = {}      -- id du tas -> objet
CreateThread(function()
    while true do
        local c = GetEntityCoords(PlayerPedId())
        local want = {}
        for _, d in ipairs(drops) do
            if #(c - vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)) < 60.0 then want[d.id] = d end
        end
        for id, o in pairs(bags) do
            if not want[id] then if DoesEntityExist(o) then DeleteObject(o) end bags[id] = nil end
        end
        for id, d in pairs(want) do
            if not bags[id] or not DoesEntityExist(bags[id]) then
                RequestModel(BAG_MODEL)
                local t = GetGameTimer() + 2000
                while not HasModelLoaded(BAG_MODEL) and GetGameTimer() < t do Wait(20) end
                if HasModelLoaded(BAG_MODEL) then
                    local o = CreateObject(BAG_MODEL, d.x + 0.0, d.y + 0.0, d.z + 0.1, false, false, false)
                    SetEntityHeading(o, (tonumber(id:match('%d+')) or 0) * 37.0 % 360.0)
                    PlaceObjectOnGroundProperly(o)
                    FreezeEntityPosition(o, true)
                    SetEntityCollision(o, false, false)
                    bags[id] = o
                    SetModelAsNoLongerNeeded(BAG_MODEL)
                end
            end
        end
        Wait(1000)
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then for _, o in pairs(bags) do if DoesEntityExist(o) then DeleteObject(o) end end end end)

-- Invite « E » près d'un coffre ou d'un tas d'objets
CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    while true do
        local ic = G.cfg.inv or {}
        if not G.begun or busy() or isOpen or (#stashes == 0 and #drops == 0) then hide() Wait(700)
        else
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd, label = nil, 1e9, nil
            for _, s in ipairs(stashes) do local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) if d < bd then best, bd, label = s, d, s.label end end
            for _, s in ipairs(drops) do local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) if d < bd then best, bd, label = s, d, 'Objets au sol' end end
            if best and bd <= 12.0 then
                local isDrop = best.id:sub(1, 2) == 'd:'
                if not isDrop then   -- carton au sol : seule l'invite en haut à gauche, pas de texte au-dessus
                    G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 0.8)
                end
                if bd <= (isDrop and (ic.drop_dist or 2.5) or (ic.stash_dist or 2.5)) and not IsPedInAnyVehicle(ped, false) then
                    if not shown or key ~= best.id then shown, key = true, best.id G.send('prompt', { show = true, key = 'E', text = isDrop and 'Ouvrir le carton' or ('Ouvrir : ' .. label) }) end
                    if IsControlJustPressed(0, 38) then open(best.id) end
                else hide() end
                Wait(0)
            else hide() Wait(500) end
        end
    end
end)

CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)

AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then clearClones() camOff() e4Off() end end)
G.onForceClose(function() close() end)
