-- Placement en jeu : ouvre l'éditeur par-dessus la vraie vue (cadres pointillés sur chaque élément), applique la mini-carte déplacée.
-- Le serveur décide des droits et valide chaque valeur ; ici on ne fait que relayer.

local G = PBG
local open = false

local function decode(j) local ok, t = pcall(json.decode, j) return ok and type(t) == 'table' and t or nil end

local function close()
    if not open then return end
    open = false
    G.send('layout.close', {})
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end

local function ask()
    if open then return end
    TriggerServerEvent('pb:g:layout:req')
end

RegisterNetEvent('pb:g:layout:open', function(j)
    local d = decode(j)
    if not d then return end
    if d.denied then
        G.send('notify', { type = 'error', text = "Tu n'as pas le droit de modifier le placement des interfaces." })
        return
    end
    if open then return end
    open = true
    G.send('layout.open', d)
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)
end)

RegisterNetEvent('pb:g:layout:done', function(ok, msg)
    G.send('layout.done', { ok = ok and true or false, msg = msg })
    if ok then G.send('notify', { type = 'success', text = tostring(msg or 'Positions enregistrées.') }) end
end)

G.nui['layout.save'] = function(d)
    if type(d) == 'table' and type(d.groups) == 'table' then TriggerServerEvent('pb:g:layout:save', json.encode(d.groups)) end
    return {}
end
G.nui['layout.reset'] = function() TriggerServerEvent('pb:g:layout:reset') return {} end
G.nui['layout.close'] = function() close() return {} end
G.nui['layout.reopen'] = function() SetTimeout(0, ask) return {} end

RegisterCommand('placement', function() ask() end, false)
exports('OpenLayoutEditor', ask)
RegisterNetEvent('pb:g:layout:ask', ask)

-- Mini-carte : décalage par rapport à l'emplacement d'origine du jeu (mm_x = bord gauche en %, mm_y = bord haut en % de l'écran).
-- Les valeurs de départ (0 ; 79,2) laissent la mini-carte d'origine intacte : rien n'est modifié tant qu'on n'y touche pas.
local appliedMM = false
local function applyMinimap(c)
    local p = c and c.place or {}
    local dx, dy = (tonumber(p.mm_x) or 0) / 100, ((tonumber(p.mm_y) or 79.2) - 79.2) / 100
    local moved = math.abs(dx) > 0.0005 or math.abs(dy) > 0.0005
    if not moved and not appliedMM then return end
    appliedMM = moved
    -- ancrage bas-gauche : y positif = vers le haut
    SetMinimapComponentPosition('minimap', 'L', 'B', -0.0045 + dx, -0.0188 - dy, 0.150, 0.1888)
    SetMinimapComponentPosition('minimap_mask', 'L', 'B', 0.020 + dx, 0.032 - dy, 0.111, 0.159)
    SetMinimapComponentPosition('minimap_blur', 'L', 'B', -0.03 + dx, 0.022 - dy, 0.266, 0.237)
    SetRadarBigmapEnabled(true, false)
    SetRadarBigmapEnabled(false, false)
end
local prevOnCfg = G.onCfg
G.onCfg = function(c)
    if prevOnCfg then prevOnCfg(c) end
    applyMinimap(c)
end
