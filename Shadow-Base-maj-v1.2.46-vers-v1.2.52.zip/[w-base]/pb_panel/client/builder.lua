-- Builder du menu staff (F10 › Builder).
-- Chaque groupe / entreprise / drogue a sa liste de points : « ✔ Défini » ou « Aucune position ». On choisit un point, le menu se ferme,
-- on va à l'endroit voulu et Entrée le pose (ou le déplace) ; le menu revient tout seul. Le serveur vérifie les droits et lit la position.
local G = PBG

local GROUP_ORDER = { 'Commerces', 'Banque', 'Immobilier', 'Garages et coffres', 'Activités illégales', 'Entreprises', 'Gangs' }
local ICON = { Commerces = 'cart', Banque = 'coins', Immobilier = 'home', ['Garages et coffres'] = 'lock', ['Activités illégales'] = 'skull', Entreprises = 'building', Gangs = 'users',
    ['Prison de la police'] = 'shield', ['Prison du staff'] = 'lock' }
local STEP_ICON = { hq = 'users', boss = 'briefcase', stash = 'lock', garage = 'engine', garage_out = 'gps', duty = 'clock', wardrobe = 'hanger', harvest = 'paw', process = 'box', sell = 'coins' }
local COLORS = { { 'Rouge', '#e74c3c' }, { 'Violet', '#9b59b6' }, { 'Orange', '#f39c12' }, { 'Gris', '#7f8c8d' }, { 'Vert', '#2ecc71' }, { 'Bleu', '#3498db' }, { 'Jaune', '#f1c40f' }, { 'Rose', '#e84393' }, { 'Noir', '#2d3436' }, { 'Blanc', '#ecf0f1' } }

local placing = nil   -- { kind, owner, key, name, extra } : en attente d'Entrée sur place
-- Icônes de carte les plus utiles (numéros de blips GTA) et couleurs
local BLIPS = { { 0, 'Aucune icône' }, { 475, 'Immeuble / bureau' }, { 98, 'Burger Shot' }, { 93, 'Bar' }, { 121, 'Club de strip' }, { 60, 'Police' }, { 61, 'Hôpital' },
    { 72, 'Garage / mécano' }, { 357, 'Garage' }, { 198, 'Taxi' }, { 225, 'Voiture' }, { 52, 'Magasin' }, { 73, 'Vêtements' }, { 71, 'Coiffeur' }, { 75, 'Tatoueur' },
    { 110, 'Armurerie' }, { 108, 'Banque' }, { 477, 'Camion' }, { 615, 'QG de gang' }, { 855, 'Chef de gang' }, { 492, 'Club de motards' }, { 779, 'Garage auto' }, { 446, "Benny's" }, { 587, 'Coffre' } }
local BCOLORS = { { 0, 'Blanc' }, { 1, 'Rouge' }, { 2, 'Vert' }, { 3, 'Bleu' }, { 5, 'Jaune' }, { 17, 'Orange' }, { 27, 'Violet' }, { 8, 'Rose' }, { 46, 'Or' }, { 40, 'Gris foncé' }, { 25, 'Vert foncé' }, { 38, 'Bleu foncé' } }
for _, c in ipairs({ { 29, 'Bleu foncé' }, { 47, 'Orange vif' }, { 21, 'Marron' }, { 83, 'Violet foncé' }, { 4, 'Gris clair' } }) do
    local has = false
    for _, x in ipairs(BCOLORS) do if x[1] == c[1] then has = true end end
    if not has then BCOLORS[#BCOLORS + 1] = c end
end
-- Sélecteur visuel de toutes les icônes du jeu (interface) : cb({ sprite, color }) ou cb(nil)
local blipCb
function G.BlipPick(opts, cb)
    if blipCb then return end
    blipCb = cb
    G.focus(true)
    G.send('blippick.open', opts or {})
end
G.nui['blippick.done'] = function(d)
    local cb = blipCb
    blipCb = nil
    G.focus(false)
    if cb then cb((type(d) == 'table' and not d.cancel and tonumber(d.sprite)) and { sprite = math.floor(tonumber(d.sprite)), color = math.floor(tonumber(d.color) or 3) } or nil) end
    return {}
end
local function idxOf(list, v) for i, x in ipairs(list) do if x[1] == v then return i end end return 1 end
local function names(list) local o = {} for _, x in ipairs(list) do o[#o + 1] = x[2] .. (x[1] > 0 and (' (' .. x[1] .. ')') or '') end return o end
local current = nil   -- dernière liste reçue (pour revenir au menu)

-- Le menu est mis de côté pendant la pose (aperçu, E pour poser) puis revient d'une étape, là où on l'avait laissé
local function go(send, id, payload)
    G.Menu.Suspend()
    send(id, payload)
    SetTimeout(3000, function() if G.Menu.IsSuspended() and not (G.PlaceArmed and G.PlaceArmed()) then G.Menu.Resume() end end)   -- pose refusée : le menu revient
end

local function iconOf(key)
    local t = tostring(key):match('^([%w_]+)')
    t = t and t:gsub('^gang_', ''):gsub('^biz_', ''):gsub('^drug_', '') or ''
    return STEP_ICON[t] or 'gps'
end

-- Liste des points d'une cible (écran 2 et 4 de la maquette)
local function openPoints(d)
    current = d
    local me = GetEntityCoords(PlayerPedId())
    local items = { { type = 'separator', label = ('Points %s « %s » — %d/%d définis'):format(d.what == 'Entreprise' and "de l'entreprise" or ((d.what == 'Drogue' or d.what == 'Fourrière') and ('de la ' .. d.what:lower()) or 'du ' .. d.what:lower()), d.label, d.done or 0, #d.steps) } }
    local sel = 2
    for i, st in ipairs(d.steps) do
        local defined = st.x ~= nil
        local desc
        if st.add then desc = st.hint .. ' Entrée : en ajouter un à ta position.'
        elseif defined then
            local dist = #(me - vector3(st.x + 0.0, st.y + 0.0, st.z + 0.0))
            desc = ('Défini ici : %d, %d (à %s de toi). Entrée : le déplacer à ta position, ou le supprimer.'):format(math.floor(st.x), math.floor(st.y), dist < 1000 and (math.floor(dist + 0.5) .. ' m') or (('%.1f km'):format(dist / 1000)))
        else desc = 'Aucune position définie. ' .. (st.hint or '') .. " Place-toi au bon endroit puis Entrée : il est posé ici." end
        local function place()
            local extra = ''
            if st.ask then extra = G.Menu.Ask(st.ask, '', 40) if extra == nil then return end end
            -- posé tout de suite à ta position : le serveur lit où tu te tiens et renvoie la liste (le menu se rouvre)
            TriggerServerEvent('pb:g:builder:set', d.kind, d.owner, st.key, extra)
        end
        local it = { label = st.name, icon = iconOf(st.key), right = st.add and ((st.count and st.count > 0) and (st.count .. ' posé' .. (st.count > 1 and 's' or '') .. ' · + Ajouter') or 'Ajouter') or (defined and ((st.count and st.count > 1) and ('✔ ' .. st.count .. ' posés') or '✔ Défini') or 'Aucune position'), description = desc, onSelect = place }
        local isHq = tostring(st.key):match('^biz_hq|') or tostring(st.key):match('^gang_hq|')
        local blipItems
        if isHq and d.blip then
            local bl = {}
            for _, x in ipairs(BLIPS) do bl[#bl + 1] = x end
            if bl[idxOf(bl, d.blip[1])][1] ~= d.blip[1] then table.insert(bl, 2, { d.blip[1], 'Icône actuelle' }) end
            local pick = { s = idxOf(bl, d.blip[1]), c = idxOf(BCOLORS, d.blip[2]) }
            local applyBlip
            blipItems = {
                { type = 'list', label = 'Icône sur la carte', icon = 'map', list = names(bl), index = pick.s, onChange = function(_, _, i) pick.s, pick.custom = i, nil end },
                { type = 'list', label = "Couleur de l'icône", icon = 'palette', list = names(BCOLORS), index = pick.c, onChange = function(_, _, i) pick.c = i end },
                { label = 'Voir toutes les icônes du jeu', icon = 'map', right = pick.custom and ('n°' .. pick.custom) or nil, description = 'Les 965 icônes de GTA avec leur image, recherche par nom ou numéro, et la couleur.', onSelect = function()
                    G.BlipPick({ sprite = pick.custom or bl[pick.s][1], color = BCOLORS[pick.c][1], title = 'Icône de « ' .. tostring(d.label) .. ' »' }, function(r)
                        if not r then return end
                        pick.custom = r.sprite
                        local ci = idxOf(BCOLORS, r.color)
                        if BCOLORS[ci][1] == r.color then pick.c = ci end
                        if defined then applyBlip() else G.send('notify', { type = 'info', title = 'Builder', text = ('Icône n°%d choisie : pose le point avec « Poser ici avec cette icône ».'):format(r.sprite) }) end
                    end)
                end },
                { label = 'Numéro d\'icône personnalisé', icon = 'edit', description = 'Un numéro de blip GTA (0 à 965).', onSelect = function()
                    local v = tonumber(G.Menu.Ask('Numéro de blip (0 = aucun)', tostring(pick.custom or bl[pick.s][1]), 3))
                    if v then pick.custom = math.floor(v) G.send('notify', { type = 'info', title = 'Builder', text = ('Icône n°%d choisie : applique-la ou pose le point.'):format(pick.custom) }) end
                end },
            }
            applyBlip = function() TriggerServerEvent('pb:g:builder:blip', d.kind, d.owner, pick.custom or bl[pick.s][1], BCOLORS[pick.c][1]) end
            if not defined then
                -- première pose : on choisit l'icône, puis « Poser ici »
                it.type, it.onSelect = 'submenu', nil
                local items2 = {}
                for _, x in ipairs(blipItems) do items2[#items2 + 1] = x end
                items2[#items2 + 1] = { label = 'Poser ici avec cette icône', icon = 'check', description = 'Pose le point à ta position.', onSelect = function()
                    place()
                    SetTimeout(900, applyBlip)
                end }
                it.submenu = { id = 'builder.hq.' .. tostring(st.key), title = st.name, subtitle = d.label, items = items2 }
            else
                blipItems[#blipItems + 1] = { label = "Appliquer l'icône", icon = 'check', onSelect = applyBlip }
            end
        end
        if defined and not st.add then
            -- point déjà posé : le déplacer ou le supprimer (son blip disparaît avec lui)
            it.type, it.onSelect = 'submenu', nil
            local sub = {
                { label = 'Déplacer ici', icon = 'gps', description = 'Déplace le point à ta position actuelle.', onSelect = place },
                st.more and { label = 'Poser un autre ici', icon = 'gps', description = 'Garde celui-ci et en ajoute un à ta position (un nouveau coffre est vide). Tous les points sont listés plus bas, dans « Tous les points posés ».', onSelect = function()
                    TriggerServerEvent('pb:g:builder:set', d.kind, d.owner, st.key, '', true)
                end } or nil,
                { label = 'Supprimer ce point', icon = 'x', description = 'Retire le point et son icône de la carte.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:builder:del', d.kind, d.owner, st.raw or st.key) end },
            }
            if blipItems then sub[#sub + 1] = { type = 'separator', label = 'Icône sur la carte' } for _, x in ipairs(blipItems) do sub[#sub + 1] = x end end
            it.submenu = { id = 'builder.pt.' .. tostring(st.key), title = st.name, subtitle = d.label, items = sub }
        end
        items[#items + 1] = it
        if d.sel and i == d.sel then sel = i + 1 end
    end
    -- tous les points réellement posés (y compris d'anciennes versions) : chacun peut être supprimé
    if d.all and #d.all > 0 then
        items[#items + 1] = { type = 'separator', label = ('Tous les points posés (%d)'):format(#d.all) }
        for _, p in ipairs(d.all) do
            local dist = p.x and #(me - vector3(p.x + 0.0, p.y + 0.0, (p.z or 0) + 0.0)) or nil
            items[#items + 1] = { type = 'submenu', label = p.label, icon = 'pin', right = dist and (dist < 1000 and (math.floor(dist + 0.5) .. ' m') or ('%.1f km'):format(dist / 1000)) or nil,
                submenu = { id = 'builder.raw.' .. p.key, title = p.label, subtitle = d.label, items = {
                    { label = 'Mettre le GPS', icon = 'gps', onSelect = function() if p.x then SetNewWaypoint(p.x + 0.0, p.y + 0.0) end end },
                    { label = 'Y aller et vérifier le sol', icon = 'pin', description = 'Téléportation sur le point ; un message dit si le point est sous le sol ou dans le vide.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:builder:goto', d.kind, d.owner, p.key) end },
                    { label = 'Dupliquer ici', icon = 'copy', description = 'Crée une copie de ce point à ta position (un coffre copié est vide).', onSelect = function() TriggerServerEvent('pb:g:builder:dup', d.kind, d.owner, p.key) end },
                    { label = 'Tout déplacer : ce point vient ici', icon = 'route', description = 'Tous les points suivent avec le même décalage (pratique pour changer de bâtiment). Confirmation demandée.', onSelect = function()
                        local v = G.Menu.Ask('Tape OUI pour déplacer tous les points', '', 3)
                        if v and v:upper() == 'OUI' then TriggerServerEvent('pb:g:builder:shift', d.kind, d.owner, p.key) end
                    end },
                    { label = 'Supprimer ce point', icon = 'x', description = 'Retire le point et son icône de la carte.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:builder:del', d.kind, d.owner, p.key) end },
                } } }
        end
    end
    items[#items + 1] = { type = 'separator', label = '' }
    if (d.done or 0) > 0 and (d.kind == 'biz' or d.kind == 'gang' or d.kind == 'drug') then
        items[#items + 1] = { label = 'Supprimer tous les points', icon = 'trash', description = "Retire tous les points posés et leurs icônes (le groupe / l'entreprise reste). Confirmation demandée.", onSelect = function()
            local v = G.Menu.Ask('Tape OUI pour tout supprimer', '', 3)
            if v and v:upper() == 'OUI' then G.Menu.Close() TriggerServerEvent('pb:g:builder:del', d.kind, d.owner, '*') end
        end }
    end
    if (d.kind == 'biz' or d.kind == 'gang') and d.players and #d.players > 0 then
        local ps = {}
        for _, p in ipairs(d.players) do
            ps[#ps + 1] = { label = p.name, icon = 'user', right = '#' .. p.id, description = d.kind == 'biz' and 'Le nommer patron (grade le plus haut).' or 'Le nommer chef du groupe.',
                onSelect = function() TriggerServerEvent('pb:g:builder:boss', d.kind, d.owner, p.id) end }
        end
        items[#items + 1] = { type = 'submenu', label = d.kind == 'biz' and 'Choisir le patron' or 'Choisir le chef', icon = 'crown', description = 'Parmi les joueurs connectés.',
            submenu = { id = 'builder.boss', title = d.kind == 'biz' and 'Patron' or 'Chef', subtitle = d.label, items = ps } }
    end
    if d.kind == 'biz' then
        items[#items + 1] = { label = "Véhicules de l'entreprise", icon = 'car', description = 'Tous les véhicules du jeu par catégorie : ceux choisis deviennent des véhicules de service (employés en service).',
            onSelect = function() TriggerServerEvent('pb:g:builder:fleet', d.owner) end }
    end
    items[#items + 1] = { label = 'Annuler le dernier point (Ctrl+Z)', icon = 'undo', description = 'Retire le dernier point posé, ou remet à sa place le dernier point déplacé.', onSelect = function() TriggerServerEvent('pb:g:builder:undo') end }
    items[#items + 1] = { label = 'Terminer', icon = 'check', description = 'Les points posés restent en place ; tu peux revenir les modifier quand tu veux.', onSelect = function() current = nil G.Menu.Close() end }
    -- la liste revient au même niveau du menu (Retour remonte au Builder) au lieu de tout refermer
    local def = { id = 'builder.points', title = 'Builder', subtitle = d.what .. ' · ' .. d.label, items = items, banner = { text = 'Menu builder' }, sel = sel }
    if G.Menu.IsSuspended and G.Menu.IsSuspended() then G.Menu.Resume() end
    local st = G.Menu.Stack
    local at
    if G.Menu.IsOpen() then for i, m in ipairs(st.menus) do if m.def and m.def.id == 'builder.points' then at = i end end end
    if at then
        while st:Depth() > at do table.remove(st.menus) end
        G.Menu.Replace(def)
    elseif G.Menu.IsOpen() then G.Menu.Push(def)
    else G.Menu.Open(def) end
end
-- Fantôme : tant que la liste des points est ouverte, l'endroit où le point sera posé (ta position) et son orientation sont dessinés au sol.
-- Ctrl+Z annule le dernier point posé.
CreateThread(function()
    while true do
        local inBuilder = false
        if current and G.Menu.IsOpen() then
            local ok, m = pcall(function() return G.Menu.Stack.menus[1] end)
            inBuilder = ok and m and m.def and tostring(m.def.id or ''):sub(1, 7) == 'builder' or false
        end
        if inBuilder then
            Wait(0)
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local h = math.rad(GetEntityHeading(ped))
            local t = GetGameTimer() / 1000.0
            DrawMarker(1, c.x, c.y, c.z - 0.98, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.4, 1.4, 0.35, 120, 200, 255, 90, false, false, 2, false, nil, nil, false)
            DrawMarker(28, c.x, c.y, c.z + 0.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.09, 0.09, 0.09, 120, 200, 255, 230, false, false, 2, false, nil, nil, false)   -- fantôme : point bleu
            DrawLine(c.x, c.y, c.z - 0.9, c.x - math.sin(h) * 1.6, c.y + math.cos(h) * 1.6, c.z - 0.9, 120, 200, 255, 220)
            if IsControlPressed(0, 36) and IsControlJustPressed(0, 20) then TriggerServerEvent('pb:g:builder:undo') end
        else
            Wait(400)
        end
    end
end)

RegisterNetEvent('pb:g:builder:points', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' or type(d.steps) ~= 'table' then return end
    placing = nil
    G.send('prompt', { show = false })
    openPoints(d)
end)

-- Pose sur place : Entrée (ou E) pose, Retour arrière annule et rouvre la liste
CreateThread(function()
    local shown = false
    while true do
        if placing then
            if not shown then shown = true G.send('prompt', { show = true, free = true, key = '↵', text = 'placer « ' .. placing.name .. ' » ici  ·  Retour : annuler' }) end
            DisableControlAction(0, 200, true)   -- Échap / pause pendant la pose
            if IsControlJustPressed(0, 191) or IsControlJustPressed(0, 201) or IsControlJustPressed(0, 38) then
                local p = placing
                placing = nil shown = false G.send('prompt', { show = false })
                TriggerServerEvent('pb:g:builder:set', p.kind, p.owner, p.key, p.extra)
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                placing = nil shown = false G.send('prompt', { show = false })
                if current then openPoints(current) end
            end
            Wait(0)
        else
            if shown then shown = false G.send('prompt', { show = false }) end
            Wait(300)
        end
    end
end)

-- Poser un point isolé (magasin, banque, garage public…) : même pose sur place, via la Carte
local function placeItem(send, t, owner, ownerLabel)
    return { label = t.label, icon = 'gps', description = ownerLabel and ('Pour : ' .. ownerLabel) or 'Puis place-toi à l\'endroit voulu et appuie sur E.', onSelect = function()
        local name = G.Menu.Ask('Nom du point (vide = « ' .. t.label .. ' »)', '', 48)
        if name == nil then return end
        go(send, 'b_place', { type = t.id, name = name, owner = owner })
    end }
end
-- Ce qu'on peut faire d'un point déjà posé : y aller, le supprimer
local function pointActs(send, b, typeId, r)
    local acts = { { label = 'Y aller', icon = 'gps', description = 'Te téléporte sur ce point.', onSelect = function() send('b_tp', { type = typeId, id = r.id }) end } }
    if b.canDelete then acts[#acts + 1] = { label = 'Supprimer', icon = 'trash', description = 'Supprime ce point pour tout le monde.', onSelect = function()
        local v = G.Menu.Ask('Tape OUI pour supprimer « ' .. tostring(r.label) .. ' »', '', 3)
        if v and v:upper() == 'OUI' then send('b_remove', { type = typeId, id = r.id }) G.Menu.Stack:Back() end
    end } end
    return acts
end
local function pointRow(send, b, typeId, r)
    return { type = 'submenu', label = tostring(r.label), icon = 'pin', right = r.dist and (r.dist .. ' m') or nil, submenu = { id = 'b.pl.' .. typeId .. '.' .. tostring(r.id), title = tostring(r.label), items = pointActs(send, b, typeId, r) } }
end
local function typeEntry(send, t, b)
    if t.needs then return nil end   -- points d'une entreprise / d'un groupe : passent par leur liste
    if t.id:sub(1, 5) == 'drug_' then return nil end   -- drogues : par « Drogues »
    local e
    if t.presets and #t.presets > 0 then
        local items = {}
        for _, pr in ipairs(t.presets) do items[#items + 1] = { label = pr[2], onSelect = function() go(send, 'b_place', { type = t.id, name = t.label .. ' : ' .. pr[2], preset = pr[1] }) end } end
        e = { type = 'submenu', label = t.label, icon = 'gps', submenu = { id = 'b.pre.' .. t.id, title = t.label, items = items } }
    else
        e = placeItem(send, t)
    end
    -- (v1.2.46) déjà posé : en poser un autre, ou choisir celui à supprimer
    local placed
    for _, pl in ipairs(b and b.placed or {}) do if pl.type == t.id then placed = pl.items end end
    if not placed or #placed == 0 then return e end
    local label = e.label
    e.label, e.description = 'Poser un autre', 'Puis place-toi à l\'endroit voulu et appuie sur E.'
    local items = { e, { type = 'separator', label = ('Déjà posés (%d) : y aller ou supprimer'):format(#placed) } }
    for _, r in ipairs(placed) do items[#items + 1] = pointRow(send, b, t.id, r) end
    return { type = 'submenu', label = label, icon = 'gps', right = #placed .. ' posé' .. (#placed > 1 and 's' or ''), description = 'Poser un autre, ou choisir celui à supprimer.',
        submenu = { id = 'b.type.' .. t.id, title = label, subtitle = #placed .. ' posé' .. (#placed > 1 and 's' or ''), items = items } }
end

-- Formulaire de création d'un groupe (écran 1 de la maquette)
local function groupForm(send, b)
    local form = { name = '', type = 1, color = 1, pack = 3 }   -- pack : 1 = aucun, puis les 3 packs
    local gt = b.gtypes or {}
    local typeNames, colorNames = {}, {}
    for _, t in ipairs(gt) do typeNames[#typeNames + 1] = t.label end
    for _, c in ipairs(COLORS) do colorNames[#colorNames + 1] = c[1] end
    return { id = 'b.gform', title = 'Builder', subtitle = 'Créer · Groupe illégal', build = function()
        return {
            { type = 'separator', label = 'Nouveau groupe' },
            { type = 'input', label = 'Nom', icon = 'tag', value = form.name, description = 'Nom affiché du groupe (2 caractères au moins).', onChange = function(_, v) form.name = tostring(v or ''):sub(1, 24) end },
            { type = 'list', label = 'Type', icon = 'users', list = typeNames, index = form.type, description = 'Gang, organisation, cartel ou club de motards.', onChange = function(_, _, i) form.type = i end },
            { type = 'list', label = 'Couleur', icon = 'palette', list = colorNames, index = form.color, description = 'Couleur de la zone sur la carte et du drapeau.', onChange = function(_, _, i) form.color = i end },
            (function()
                local names, descs = { 'Aucun' }, { 'Le groupe démarre sans rien.' }
                for _, pk in ipairs(b.packs or {}) do names[#names + 1] = pk.name descs[#descs + 1] = ('%s en caisse, %d objets au coffre, %d véhicule(s).'):format(PB.Money(pk.cash), pk.items, pk.cars) end
                return { type = 'list', label = 'Pack de départ', icon = 'gift', list = names, index = math.min(form.pack, #names), description = 'Donné tout de suite à la création. ' .. (descs[math.min(form.pack, #names)] or ''),
                    onChange = function(it, _, i) form.pack = i it.description = 'Donné tout de suite à la création. ' .. (descs[i] or '') end }
            end)(),
            { type = 'separator', label = '' },
            { label = 'Créer et placer les points', icon = 'check', description = 'Le groupe est créé, puis tu choisis ses points un par un.', onSelect = function()
                if #form.name < 2 then G.send('notify', { type = 'error', title = 'Builder', text = 'Donne un nom au groupe.' }) return end
                send('b_group', { gtype = gt[form.type] and gt[form.type].id or 'gang', label = form.name, color = COLORS[form.color][2], pack = form.pack - 1 })
                form.name = ''
            end },
        }
    end }
end

-- Entreprise sur mesure : nom libre, fonctionnement d'un type du catalogue (mécano, café, bar…), icône choisie parmi toutes celles du jeu
local function customBizForm(send, b)
    local form = { name = '', key = nil, klabel = nil, blip = -1, color = -1 }
    local function modelsMenu()
        local cats = {}
        for _, c in ipairs(b.models or {}) do
            local sub = {}
            for _, m in ipairs(c.items) do
                sub[#sub + 1] = { label = m[2], right = form.key == m[1] and 'Choisi' or nil, description = "Elle fonctionnera comme « " .. m[2] .. " » (droits, points, cuisine ou atelier, petits jobs).",
                    onSelect = function() form.key, form.klabel = m[1], m[2] G.Menu.Stack:Back() G.Menu.Stack:Back() G.Menu.Refresh() end }
            end
            cats[#cats + 1] = { type = 'submenu', label = c.label, badge = tostring(#sub), submenu = { id = 'b.bizm.' .. c.id, title = c.label, subtitle = 'Fonctionne comme', items = sub } }
        end
        return { id = 'b.bizm', title = 'Fonctionne comme', subtitle = 'Choisis le type', items = cats }
    end
    return { id = 'b.biz.new', title = 'Entreprise sur mesure', subtitle = 'Nom libre, fonctionnement au choix', refreshOnReturn = true, build = function()
        return {
            { type = 'input', label = 'Nom', icon = 'edit', right = form.name ~= '' and form.name or nil, maxlen = 48, description = "Ex. Benny's Motorworks, Le Petit Café, Garage du Port.", onSelect = function(_, t) form.name = tostring(t or '') G.Menu.Refresh() end },
            { type = 'submenu', label = 'Fonctionne comme', icon = 'building', right = form.klabel or 'À choisir', description = 'Mécano, café, restaurant, bar, taxi, supérette… Elle garde tout ce que fait ce type.', submenu = function() return modelsMenu() end },
            { label = 'Icône sur la carte', icon = 'map', right = form.blip >= 0 and ('n°' .. form.blip) or 'Celle du type', description = "Ouvre les 965 icônes du jeu avec leur image (recherche par nom ou numéro) et la couleur.",
              onSelect = function() G.BlipPick({ sprite = form.blip >= 0 and form.blip or 475, color = form.color >= 0 and form.color or 3, title = form.name ~= '' and ('Icône de « ' .. form.name .. ' »') or 'Icône sur la carte' }, function(r) if r then form.blip, form.color = r.sprite, r.color G.Menu.Refresh() end end) end },
            { type = 'separator', label = '' },
            { label = 'Créer et placer les points', icon = 'check', description = 'Grades, salaires et droits sont générés ; puis tu poses ses points un par un.', onSelect = function()
                if #form.name < 2 then G.send('notify', { type = 'error', title = 'Builder', text = "Donne un nom à l'entreprise." }) return end
                if not form.key then G.send('notify', { type = 'error', title = 'Builder', text = "Choisis comment elle fonctionne." }) return end
                send('b_bizcustom', { key = form.key, label = form.name, blip = form.blip, bcolor = form.color })
                form.name, form.key, form.klabel, form.blip, form.color = '', nil, nil, -1, -1
            end },
        }
    end }
end

-- Menu principal du Builder : 6 sections fixes (rien n'est jamais caché : un type inconnu va dans « Autres »), et une recherche
local SECTIONS = {
    { id = 'biz', label = 'Entreprises', icon = 'building', desc = 'Créer une entreprise (catalogue ou sur mesure) ou modifier ses points.' },
    { id = 'illegal', label = 'Illégal', icon = 'skull', desc = 'Gangs et organisations, drogues, braquages, blanchiment, atelier d\'armes.' },
    { id = 'prison', label = 'Prison', icon = 'lock', desc = 'Prison de la police et prison du staff, chacune à part : lieu du détenu, sortie, limite de la zone.' },
    { id = 'shops', label = 'Commerces et services', icon = 'cart', desc = 'Magasins, banques, casino, location de véhicules.' },
    { id = 'garages', label = 'Garages et véhicules', icon = 'car', desc = 'Garages voitures, hangars aériens, ports, fourrières : entrée, sortie et gardien.' },
    { id = 'housing', label = 'Immobilier et coffres', icon = 'home', desc = 'Logements à vendre ou à louer, coffres publics.' },
    { id = 'activities', label = 'Activités et extensions', icon = 'paw', desc = 'Pêche, chasse, récolte, animaux, petits jobs, portes, Burger Shot…' },
    { id = 'elev', label = 'Ascenseurs', icon = 'building', desc = 'Ascenseurs à plusieurs étages : E à un étage, choix de la destination.' },
    { id = 'other', label = 'Autres', icon = 'gps', desc = 'Points des autres ressources.' },
}
local GROUP_SECTION = { Commerces = 'shops', Banque = 'shops', Casino = 'shops', Immobilier = 'housing', ['Activités illégales'] = 'illegal', Gangs = 'illegal', Entreprises = 'biz', ['Garages et coffres'] = 'housing',
    ['Prison de la police'] = 'prison', ['Prison du staff'] = 'prison' }
local EXT_SECTION = { wb_braquages = 'illegal', wb_armes = 'illegal', wb_peche = 'activities', wb_chasse = 'activities', wb_activites = 'activities', wb_animaux = 'activities', wb_jobs = 'activities', wb_portes = 'activities', burgershot = 'activities' }
local TYPE_SECTION = { rental = 'garages', stash = 'housing' }
local HIDDEN_TYPES = { garage = true }   -- remplacé par la création guidée (entrée, sortie, gardien)
local VT_LABEL = { car = 'Voitures', air = 'Aérien', boat = 'Naval' }

local function garageCreate(send)
    local function create(kind, vtype, what)
        return { label = what, icon = kind == 'impound' and 'lock' or (vtype == 'air' and 'sparkle' or (vtype == 'boat' and 'drop' or 'car')),
            description = 'Place-toi à l\'entrée (là où l\'on appuie sur E), puis Entrée. Ensuite : la sortie des véhicules et le gardien.',
            onSelect = function()
                local name = G.Menu.Ask('Nom (vide = « ' .. what .. ' »)', '', 48)
                if name == nil then return end
                send('b_garage', { kind = kind, vtype = vtype, name = name })
            end }
    end
    return { id = 'b.c.garages', title = 'Créer un garage', subtitle = 'Un type de véhicules par garage', items = {
        { type = 'separator', label = 'Garages' },
        create('public', 'car', 'Garage voitures et motos'), create('public', 'air', 'Hangar aérien (hélicoptères, avions)'), create('public', 'boat', 'Port (bateaux)'),
        { type = 'separator', label = 'Fourrières' },
        create('impound', 'car', 'Fourrière voitures'), create('impound', 'air', 'Fourrière aérienne'), create('impound', 'boat', 'Fourrière navale'),
    } }
end
local function garageExisting(send, b)
    local items = {}
    for _, gr in ipairs({ { 'public', 'Garages' }, { 'impound', 'Fourrières' } }) do
        local first = true
        for _, g in ipairs(b.garages or {}) do
            if g[3] == gr[1] then
                if first then items[#items + 1] = { type = 'separator', label = gr[2] } first = false end
                items[#items + 1] = { label = g[2], right = VT_LABEL[g[4]] or g[4], icon = 'pin', description = 'Entrée, sortie et gardien : déplacer, poser ou supprimer.', onSelect = function() send('b_pack', { kind = 'garage', owner = g[1] }) end }
            end
        end
    end
    if #items == 0 then items[1] = { label = 'Aucun garage public ni fourrière', disabled = true } end
    return { id = 'b.e.garages', title = 'Garages existants', items = items }
end

-- (v1.2.43) Builder en deux onglets : « Créer » (tout ce qui est nouveau) et « Existant » (modifier, déplacer, supprimer)
function G.BuilderItems(spec, send)
    local b = spec and spec.builder
    if not b then return { { label = 'Accès réservé (droit « placer des points »)', disabled = true } } end
    local C, E = {}, {}   -- sections : id -> liste
    for _, s in ipairs(SECTIONS) do C[s.id] = {} E[s.id] = {} end
    local function addC(id, it) table.insert(C[C[id] and id or 'other'], it) end
    local function addE(id, it) table.insert(E[E[id] and id or 'other'], it) end

    -- Entreprises
    addC('biz', { type = 'submenu', label = 'Entreprise sur mesure', icon = 'plus', description = "Nom libre (ex. Benny's), fonctionnement d'un type au choix (mécano, café, bar…) et icône parmi toutes celles du jeu.", submenu = customBizForm(send, b) })
    local catNew, made = {}, {}
    for _, c in ipairs(b.cats or {}) do
        local sub = {}
        for _, e in ipairs(c.items) do
            if e.made then made[#made + 1] = { label = e.label, right = c.label, icon = 'building', description = 'Ouvrir la liste de ses points (poser, déplacer, supprimer).', onSelect = function() send('b_biz', { key = e.key }) end }
            else sub[#sub + 1] = { label = e.label, right = 'nouvelle', description = "Créer l'entreprise puis poser ses points.", onSelect = function() send('b_biz', { key = e.key }) end } end
        end
        if #sub > 0 then catNew[#catNew + 1] = { type = 'submenu', label = c.label, badge = tostring(#sub), submenu = { id = 'b.cat.' .. c.id, title = c.label, items = sub } } end
    end
    addC('biz', { type = 'submenu', label = 'Entreprise du catalogue', icon = 'list', badge = tostring(#catNew), description = 'Entreprises prêtes à l\'emploi, par catégorie.', submenu = { id = 'b.biz', title = 'Catalogue des entreprises', items = #catNew > 0 and catNew or { { label = 'Tout le catalogue est déjà créé', disabled = true } } } })
    for _, c in ipairs(b.custom or {}) do made[#made + 1] = { label = c[2], right = c[3], icon = 'building', description = 'Entreprise sur mesure : ouvrir la liste de ses points.', onSelect = function() send('b_pack', { kind = 'biz', owner = c[1] }) end } end
    table.sort(made, function(x, y) return tostring(x.label) < tostring(y.label) end)
    if #made > 0 then addE('biz', { type = 'submenu', label = 'Entreprises', icon = 'building', badge = tostring(#made), description = 'Ses points : poser, déplacer, aller voir, supprimer. Patron, icône.', submenu = { id = 'b.e.biz', title = 'Entreprises existantes', items = made } }) end

    -- Illégal
    addC('illegal', { type = 'submenu', label = 'Gang, organisation, cartel, MC', icon = 'plus', description = 'Nom, type, couleur, pack de départ, puis ses points.', submenu = groupForm(send, b) })
    local gitems = {}
    for _, g in ipairs(b.gangs or {}) do gitems[#gitems + 1] = { label = g[2], right = g[3], icon = 'users', description = 'Ouvrir la liste de ses points.', onSelect = function() send('b_pack', { kind = 'gang', owner = g[1] }) end } end
    if #gitems > 0 then addE('illegal', { type = 'submenu', label = 'Groupes illégaux', icon = 'users', badge = tostring(#gitems), submenu = { id = 'b.e.groups', title = 'Groupes existants', items = gitems } }) end
    local ditems = {}
    for _, d in ipairs(b.drugs or {}) do ditems[#ditems + 1] = { label = d[2], right = PB.Money(d[5]), description = ('%s → %s. Récolte, labo, vente (drapeau).'):format(d[3], d[4]), onSelect = function() send('b_drug', { drug = d[1] }) end } end
    local drugs = { type = 'submenu', label = 'Drogues', icon = 'skull', badge = tostring(#ditems), description = 'Récolte, laboratoire et point de vente de chaque drogue.', submenu = { id = 'b.drugs', title = 'Drogues', subtitle = 'Choisis la drogue', items = ditems } }
    addC('illegal', drugs) addE('illegal', drugs)
    -- (patch 136) territoires dessinés coin par coin
    addC('illegal', { label = 'Territoire de gang (tracer la zone)', icon = 'flag', description = "Marche jusqu'à chaque coin et appuie sur Entrée : la zone se dessine au fur et à mesure. E pour terminer, puis le nom et l'objet offert toutes les 5 h.",
        onSelect = function() if G.TerrDraw then G.TerrDraw(send, b.rewards) end end })
    if #(b.terr or {}) > 0 then
        local tz = {}
        for _, z in ipairs(b.terr) do
            local st = { qty = tonumber(z[5]) or 1, hours = tonumber(z[6]) or 5 }
            for _, it in ipairs(b.rewards or {}) do if it[1] == z[3] then st.item = it end end
            st.onSave = function() send('b_terrreward', { id = z[1], item = st.item and st.item[1] or '', qty = st.qty, hours = st.hours }) end
            tz[#tz + 1] = { type = 'submenu', label = z[2], right = (z[4] ~= nil and z[4] ~= '') and z[4] or nil, icon = 'flag', submenu = { id = 'b.terr.' .. z[1], title = z[2], refreshOnReturn = true, build = function() return {
                G.TerrRewardItem and G.TerrRewardItem(b.rewards, 'b.terr.' .. z[1], st) or { label = 'Objet offert', disabled = true },
                { label = 'Supprimer cette zone', icon = 'x', description = 'La zone et son propriétaire sont effacés.', onSelect = function()
                    local v = G.Menu.Ask('Tape OUI pour supprimer « ' .. z[2] .. ' »', '', 3)
                    if v and v:upper() == 'OUI' then send('b_terrdel', { id = z[1] }) G.Menu.Stack:Back() end
                end } } end } }
        end
        addE('illegal', { type = 'submenu', label = 'Territoires', icon = 'flag', badge = tostring(#tz), submenu = { id = 'b.e.terr', title = 'Territoires', items = tz } })
    end

    -- Garages
    addC('garages', { type = 'submenu', label = 'Garage, hangar, port, fourrière', icon = 'car', submenu = garageCreate(send) })
    if #(b.garages or {}) > 0 then addE('garages', { type = 'submenu', label = 'Garages et fourrières', icon = 'car', badge = tostring(#b.garages), submenu = garageExisting(send, b) }) end

    -- Points isolés : « Créer » (poser un nouveau) et « Existant » (ceux déjà posés : y aller, supprimer)
    local all = {}
    for gname, list in pairs(b.groups or {}) do
        local per = {}
        for _, t in ipairs(list) do
            if not HIDDEN_TYPES[t.id] then
                local e = typeEntry(send, t, b)
                if e then
                    all[#all + 1] = { e = e, label = t.label }
                    local sid = TYPE_SECTION[t.id] or GROUP_SECTION[gname] or 'other'
                    per[sid] = per[sid] or {}
                    table.insert(per[sid], e)
                end
            end
        end
        for sid, sub in pairs(per) do
            table.sort(sub, function(x, y) return tostring(x.label) < tostring(y.label) end)
            if sid == 'prison' then addC(sid, { type = 'submenu', label = gname, icon = ICON[gname] or 'lock', badge = tostring(#sub), submenu = { id = 'b.g.prison.' .. gname, title = gname, items = sub } })
            elseif #sub == 1 then addC(sid, sub[1]) else addC(sid, { type = 'submenu', label = gname, icon = ICON[gname] or 'gps', badge = tostring(#sub), submenu = { id = 'b.g.' .. sid .. '.' .. gname, title = gname, items = sub } }) end
        end
    end
    local jails = {}
    for _, pl in ipairs(b.placed or {}) do
        local sub = {}
        for _, r in ipairs(pl.items or {}) do
            local acts = pointActs(send, b, pl.type, r)
            sub[#sub + 1] = { type = 'submenu', label = tostring(r.label), icon = 'pin', right = r.dist and (r.dist .. ' m') or nil, submenu = { id = 'b.pl.' .. pl.type .. '.' .. tostring(r.id), title = tostring(r.label), subtitle = pl.label, items = acts } }
        end
        local sid = TYPE_SECTION[pl.type] or GROUP_SECTION[pl.group or ''] or 'other'
        if sid == 'prison' then
            if not jails[pl.group] then jails[pl.group] = {} addE(sid, { type = 'submenu', label = pl.group, icon = ICON[pl.group] or 'lock', submenu = { id = 'b.e.prison.' .. pl.group, title = pl.group, items = jails[pl.group] } }) end
            sid = nil
            for _, r in ipairs(sub) do table.insert(jails[pl.group], r) end
        end
        if sid then addE(sid, { type = 'submenu', label = pl.label, icon = 'pin', badge = tostring(#sub), description = 'Les points déjà posés (le plus proche en premier) : y aller ou supprimer.', submenu = { id = 'b.pl.' .. pl.type, title = pl.label, items = sub } }) end
    end

    -- Ressources (extensions) : leurs points se posent et se modifient dans la même liste
    for _, e in ipairs(b.ext or {}) do
        local it = { label = e.label, icon = e.icon or 'box', badge = tostring(#(e.points or {})), description = 'Ouvrir la liste de ses points.', onSelect = function() send('b_pack', { kind = 'ext', owner = e.id }) end }
        addC(EXT_SECTION[e.id] or 'activities', it) addE(EXT_SECTION[e.id] or 'activities', it)
    end
    -- Ascenseurs
    if G.ElevatorItems then
        local cr, ex = G.ElevatorItems(function() return (G.StaffSpec and G.StaffSpec()) or spec end, send)
        addC('elev', cr) if ex then addE('elev', ex) end
    end

    local function tab(id, title, sec, empty)
        local items = {}
        for _, s in ipairs(SECTIONS) do
            local list = sec[s.id]
            if #list > 0 then items[#items + 1] = { type = 'submenu', label = s.label, icon = s.icon, badge = tostring(#list), description = s.desc, submenu = { id = 'b.' .. id .. '.' .. s.id, title = s.label, subtitle = title, items = list } } end
        end
        if #items == 0 then items[1] = { label = empty, disabled = true } end
        return items
    end
    local createItems = tab('c', 'Créer', C, 'Rien à créer')
    local existItems = tab('e', 'Existant', E, 'Rien n\'est encore posé')
    if b.canDelete then
        existItems[#existItems + 1] = { type = 'separator', label = 'Supprimer sur place' }
        existItems[#existItems + 1] = { label = 'Point le plus proche (8 m)', icon = 'trash', description = 'Affiche le point qui serait supprimé.', onSelect = function() send('b_delete', {}) end }
        existItems[#existItems + 1] = { label = 'Confirmer la suppression', icon = 'trash', description = 'Supprime le point le plus proche pour tout le monde.', onSelect = function() send('b_delete', { confirm = true }) end }
    end
    local items = {}
    items[#items + 1] = { type = 'input', label = 'Rechercher un type de point', icon = 'search', maxlen = 30, description = 'Ex. : supérette, banque, casino, coffre…', onSelect = function(_, q)
        q = tostring(q or ''):lower()
        if q == '' then return end
        local res = {}
        for _, x in ipairs(all) do if tostring(x.label):lower():find(q, 1, true) then res[#res + 1] = x.e end end
        G.Menu.Open({ id = 'b.search', title = 'Builder', subtitle = 'Recherche : ' .. q, items = #res > 0 and res or { { label = 'Aucun résultat', disabled = true } } })
    end }
    items[#items + 1] = { type = 'submenu', label = 'Créer', icon = 'plus', description = 'Nouvelle entreprise, groupe, garage, magasin, ascenseur… puis ses points.', submenu = { id = 'b.create', title = 'Builder', subtitle = 'Créer', items = createItems } }
    items[#items + 1] = { type = 'submenu', label = 'Existant', icon = 'edit', description = 'Tout ce qui est déjà posé : modifier, déplacer, aller voir, supprimer.', submenu = { id = 'b.exist', title = 'Builder', subtitle = 'Existant', items = existItems } }
    return items
end

-- Vérification du sol après « Y aller » (Builder ou panel › Points posés) : sous le sol, dans le vide, en l'air ?
RegisterNetEvent('pb:g:points:check', function(j)
    local p = G.decode(j)
    if not p or not p.x then return end
    CreateThread(function()
        Wait(1800)
        local x, y, z = p.x + 0.0, p.y + 0.0, (p.z or 0) + 0.0
        local found, gz = GetGroundZFor_3dCoord(x, y, z + 3.0, false)
        local txt, kind
        if not found then txt, kind = "Aucun sol sous ce point : il est dans le vide, ou dans un intérieur pas encore chargé.", 'warn'
        elseif gz > z + 0.6 then txt, kind = ('Le point est %.1f m SOUS le sol : repose-le au Builder.'):format(gz - z), 'error'
        elseif z - gz > 3.0 then txt, kind = ('Le point flotte %.1f m au-dessus du sol.'):format(z - gz), 'warn'
        else txt, kind = 'Point bien placé : au niveau du sol.', 'success' end
        G.send('notify', { type = kind, title = tostring(p.label or 'Point'), text = txt })
    end)
end)

-- Véhicules de l'entreprise : liste actuelle (Entrée : retirer) et ajout depuis tout le catalogue, par catégorie.
-- Après un ajout on reste dans la catégorie (plusieurs ajouts d'affilée) ; la liste se met à jour au retour.
local fleetD
local function fleetCats()
    local cats = {}
    for _, c in ipairs(fleetD.classes or {}) do
        local list = {}
        for _, m in ipairs(c.items) do list[#list + 1] = { label = m[2], right = m[1], description = "Entrée : ajouter à l'entreprise.", onSelect = function() TriggerServerEvent('pb:g:builder:fleetadd', fleetD.biz, m[1]) end } end
        cats[#cats + 1] = { type = 'submenu', label = c.id, right = tostring(#list), submenu = { id = 'b.fleet.c', title = c.id, subtitle = 'Ajouter à ' .. fleetD.label, items = list } }
    end
    return { id = 'b.fleet.cats', title = 'Catégories', subtitle = fleetD.label, items = cats }
end
local fleetDef = { id = 'b.fleet', title = "Véhicules de l'entreprise", refreshOnReturn = true, build = function()
    local d = fleetD
    local items = { { type = 'separator', label = ('Véhicules de service · %d'):format(#d.fleet) } }
    for _, v in ipairs(d.fleet) do
        items[#items + 1] = { type = 'submenu', label = v.label, right = v.plate, submenu = { id = 'b.fleet.v', title = v.label, subtitle = v.plate, items = {
            { label = 'Retirer ce véhicule', icon = 'x', description = "Il n'appartient plus à l'entreprise.", onSelect = function() TriggerServerEvent('pb:g:builder:fleetdel', d.biz, v.plate) G.Menu.Stack:Back() end } } } }
    end
    if #d.fleet == 0 then items[#items + 1] = { label = 'Aucun véhicule pour le moment', disabled = true } end
    items[#items + 1] = { type = 'separator', label = 'Ajouter' }
    items[#items + 1] = { type = 'submenu', label = 'Ajouter un véhicule', icon = 'plus', description = 'Toutes les catégories du jeu (voitures, motos, utilitaires, hélicoptères, bateaux…).', submenu = function() return fleetCats() end }
    return items
end }
RegisterNetEvent('pb:g:builder:fleet', function(j)
    local d = G.decode(j)
    if not d then return end
    fleetD = d
    fleetDef.subtitle = d.label
    local inFleet = false
    for _, m in ipairs(G.Menu.Stack.menus) do if m.def == fleetDef then inFleet = true end end
    if inFleet then G.Menu.Refresh() else G.Menu.Push(fleetDef) end
end)
