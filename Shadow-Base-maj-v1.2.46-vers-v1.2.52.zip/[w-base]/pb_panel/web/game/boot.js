/* Écran de chargement entre le loading screen et l'écran d'entrée (client/loading.lua) : logo du serveur, lumière qui file, sur fond noir.
   Affiché dès le chargement de la page, en jeu seulement. Le logo et la couleur sont gardés sur le poste : la configuration du serveur
   n'arrive qu'à la fin de la connexion. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, guard = null;
const read = (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* rien */ } };

function show() {
  if (el) return;
  const logo = read('pb_boot_logo'), rgb = read('pb_boot_rgb');
  el = h('div', { id: 'g-boot', style: rgb ? { '--sv-rgb': rgb, '--sv': 'rgb(' + rgb + ')' } : {} },
    logo ? h('img', { src: logo, alt: '' }) : null,
    h('div', { class: 'gb-bar' }, h('i')),
    h('small', null, 'Arrivée en ville…'));
  document.body.appendChild(el);
}
function hide() {
  clearTimeout(guard); guard = null;
  if (!el) return;
  const e = el; el = null;
  e.classList.add('bye');
  setTimeout(() => e.remove(), 500);
}
G.on('boot.show', show);
G.on('boot.done', hide);
G.on('boot.ping', () => { clearTimeout(guard); guard = setTimeout(hide, 90000); });   // sécurité si le jeu ne répond plus
G.on('cfg', () => {
  const b = G.cfg && G.cfg.brand;
  if (b && b.logo && G.logoUrl) save('pb_boot_logo', G.logoUrl());
  const rgb = getComputedStyle(document.body).getPropertyValue('--sv-rgb').trim();
  if (rgb) save('pb_boot_rgb', rgb);
});
if (typeof window.GetParentResourceName === 'function') show();
})();
