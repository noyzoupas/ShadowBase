/* Objets reçus / perdus : petite carte avec l'image de l'objet, son nom et « +2 » ou « -1 » (ramassé, acheté, reçu, utilisé, retiré…).
   Une carte par objet : si le même objet bouge encore pendant qu'elle est affichée, le nombre s'additionne et elle reste un peu plus. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const LIFE = 3800, MAX = 5;
const cards = new Map();   // clé objet + sens -> { el, n, t }
let box = null;
const host = () => box || (box = (function () { const e = h('div', { id: 'g-itemfeed' }); G.root.appendChild(e); return e; })());

function fmt(n) { return (n > 0 ? '+' : '−') + Math.abs(n).toLocaleString('fr-FR'); }
function card(d, n) {
  const img = h('img', { src: String(d.image || 'img/items/_item.svg'), alt: '' });
  img.onerror = () => { img.onerror = null; img.src = 'img/items/_item.svg'; };
  const badge = h('em', null, fmt(n));
  const bar = h('i', { class: 'if-bar', style: { animationDuration: LIFE + 'ms' } });   // temps qu'il reste à la carte
  const el = h('div', { class: 'if-card ' + (n > 0 ? 'in' : 'out') }, bar, h('div', { class: 'if-img' }, img), h('b', null, String(d.label || d.item || '')), badge);
  return { el, badge, bar };
}
function drop(key) {
  const c = cards.get(key);
  if (!c) return;
  cards.delete(key);
  c.el.classList.add('bye');
  setTimeout(() => c.el.remove(), 260);
}
function push(d) {
  const n = Math.trunc(Number(d && d.n) || 0);
  if (!n) return;
  const key = String(d.item) + (n > 0 ? '+' : '-');
  const c = cards.get(key);
  if (c) {
    c.n += n; c.badge.textContent = fmt(c.n);
    c.el.classList.remove('bump'); c.bar.style.animation = 'none'; void c.el.offsetWidth; c.el.classList.add('bump'); c.bar.style.animation = 'ifTime ' + LIFE + 'ms linear forwards';
    clearTimeout(c.t); c.t = setTimeout(() => drop(key), LIFE);
    return;
  }
  if (cards.size >= MAX) drop(cards.keys().next().value);   // la plus ancienne laisse sa place
  const nc = card(d, n);
  const entry = { el: nc.el, badge: nc.badge, bar: nc.bar, n, t: setTimeout(() => drop(key), LIFE) };
  cards.set(key, entry);
  host().appendChild(nc.el);
}
G.on('itemfeed', push);

// Aperçu du panel (HUD) : une caisse reçue, des munitions utilisées
const prev = G.preview.hud;
G.preview.hud = function (b, cfg) {
  if (prev) prev(b, cfg);
  const stage = b.querySelector && b.querySelector('.gstage');
  if (!stage) return;
  const row = h('div', { id: 'g-itemfeed', class: 'pv' });
  row.appendChild(card({ label: 'Caisse Halloween', image: 'img/items/_item.svg' }, 1).el);
  row.appendChild(card({ label: 'Munitions 9 mm', image: 'img/ox/ammo-9.png' }, -12).el);
  stage.appendChild(row);
};
})();
