-- Musique mobile : boombox équipée en main (objet VIP du sac) et CarPlay des véhicules. Une seule musique par boombox ou par véhicule.
-- Le serveur décide : il vérifie où est le joueur, n'accepte que les radios du réglage et les liens autorisés des télévisions (G.TV.Parse).
-- Dans un véhicule, tous les occupants peuvent changer la musique. Le son est calculé par chaque client (client/music.lua, web/game/music.js).
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('music.manage', 'Gérer la musique (boombox, CarPlay, radios)', 'world')
local STATIONS = { 'Skyrock|https://icecast.skyrock.net/s/natio_mp3_128k', "Mouv'|https://icecast.radiofrance.fr/mouv-midfi.mp3", 'FIP|https://icecast.radiofrance.fr/fip-midfi.mp3',
    'FIP Groove|https://icecast.radiofrance.fr/fipgroove-midfi.mp3', 'FIP Rock|https://icecast.radiofrance.fr/fiprock-midfi.mp3', 'FIP Electro|https://icecast.radiofrance.fr/fipelectro-midfi.mp3',
    'Radio Classique|https://radioclassique.ice.infomaniak.ch/radioclassique-high.mp3' }
PB.Cfg.Define('music', { enabled = true, car = true, box_range = 30, car_range = 16, volume = 70, max_mins = 240, stations = STATIONS, box_pos = { 0.15, 0.0, 0.0, 90.0, 252.5, 0.0 } })
local function cfg(k, d) return PB.Cfg.Get('music', k, d) end

local M = { sources = {}, boxes = {} }
G.Music = M
local ITEM = 'boombox'

PB.Migrate('527_boombox_item', 'Inventaire : boombox', function()
    DB.exec("INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, hunger, thirst, stress, health, usable, description) VALUES (?, 'Boombox', 3000, 1, 'tool', 0, 0, 0, 0, 1, 'Utilise-la pour la prendre en main et choisir la musique.')", { ITEM })
end)

function M.Stations()
    local out = {}
    for _, line in ipairs(cfg('stations', {}) or {}) do
        local n, u = tostring(line):match('^%s*([^|]-)%s*|%s*(https://%S+)%s*$')
        if n and n ~= '' then out[#out + 1] = { n = n:sub(1, 30), url = u } end
    end
    return out
end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 40) end return GetPlayerName(src) or ('Joueur ' .. src) end

function M.Push(target)
    local list, st = {}, {}
    for _, s in pairs(M.sources) do list[#list + 1] = { k = s.k, t = s.t, o = s.o, net = s.net, kind = s.kind, id = s.id, url = s.url, title = s.title, by = s.by, at = s.at } end
    for i, s in ipairs(M.Stations()) do st[i] = { i = i, n = s.n } end
    TriggerClientEvent('pb:g:music:list', target or -1, PB.Json({ sources = list, stations = st, box_range = tonumber(cfg('box_range', 30)) or 30, car_range = tonumber(cfg('car_range', 16)) or 16, volume = tonumber(cfg('volume', 70)) or 70, box_pos = cfg('box_pos') }))
end

local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function vehOf(src)
    local ped = GetPlayerPed(src)
    local v = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
    return v ~= 0 and v or nil
end
-- Où ce joueur peut mettre de la musique : son véhicule, sinon sa boombox en main
local function context(src)
    local veh = vehOf(src)
    if veh then
        if cfg('car', true) == false then return nil, 'Le CarPlay est désactivé.' end
        local net = NetworkGetNetworkIdFromEntity(veh)
        if not net or net == 0 then return nil, 'Véhicule introuvable.' end
        return { k = 'car:' .. net, t = 'car', net = net, veh = veh }
    end
    if M.boxes[src] then return { k = 'box:' .. src, t = 'box', o = src } end
    return nil, 'Monte dans un véhicule ou équipe ta boombox.'
end

-- Titre d'un lien : demandé au site après coup (sans clé), la musique part sans l'attendre
local function fetchTitle(s)
    local url = s.kind == 'yt' and ('https://www.youtube.com/oembed?format=json&url=https://www.youtube.com/watch?v=' .. s.id)
        or (s.kind == 'vimeo' and ('https://vimeo.com/api/oembed.json?url=https://vimeo.com/' .. s.id))
    if not url or not PerformHttpRequest then return end
    PerformHttpRequest(url, function(code, body)
        if code ~= 200 or M.sources[s.k] ~= s then return end
        local d = PB.FromJson(body or '', nil)
        if type(d) == 'table' and type(d.title) == 'string' and d.title ~= '' then s.title = d.title:gsub('%c', ' '):sub(1, 90) M.Push() end
    end, 'GET')
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
local function say(src, kind, text) G.Notify(src, { type = kind, title = 'Musique', text = text }) end
-- les autres occupants voient qui a changé la musique
local function tellCar(src, veh, text)
    for t in pairs(G.Players()) do if t ~= src and vehOf(t) == veh then G.Notify(t, { type = 'info', title = 'CarPlay', text = text }) end end
end

RegisterNetEvent('pb:g:music:play', function(station, url)
    local src = source
    if not throttle(src, 1200) or not usable(src) then return end
    if cfg('enabled', true) == false then say(src, 'warn', 'La musique est désactivée.') return end
    local c, why = context(src)
    if not c then say(src, 'warn', why) return end
    local s = { k = c.k, t = c.t, o = c.o, net = c.net, by = display(src), at = os.time() }
    local i = tonumber(station)
    if i then
        local st = M.Stations()[math.floor(i)]
        if not st then say(src, 'error', 'Cette radio n\'existe plus.') return end
        s.kind, s.url, s.title = 'stream', st.url, st.n
    else
        local v, msg = G.TV.Parse(url)
        if not v then say(src, 'error', msg or 'Lien illisible.') return end
        s.kind, s.id, s.title = v.kind, v.id, ''
    end
    M.sources[c.k] = s
    if c.veh then tellCar(src, c.veh, s.by .. ' a changé la musique.') end
    M.Push()
    fetchTitle(s)
end)
RegisterNetEvent('pb:g:music:stop', function()
    local src = source
    if not throttle(src, 500) or not usable(src) then return end
    local c = context(src)
    if not c or not M.sources[c.k] then return end
    M.sources[c.k] = nil
    if c.veh then tellCar(src, c.veh, display(src) .. ' a coupé la musique.') end
    M.Push()
end)

-- Boombox : un objet du sac qu'on équipe et qu'on range --------------------------------------------------------------------------------
local function owner(src) local p = G.Get(src) return p and ('p:' .. p.license) or nil end
function M.Holster(src, why)
    if not M.boxes[src] then return false end
    M.boxes[src] = nil
    TriggerClientEvent('pb:g:music:box', src, false)
    if M.sources['box:' .. src] then M.sources['box:' .. src] = nil M.Push() end
    if why then say(src, 'info', why) end
    return true
end
local function allowed(src) return G.Vip and G.Vip.Is(src) and PB.Cfg.Get('vip', 'boombox', true) ~= false end
function M.Equip(src)
    if M.boxes[src] then M.Holster(src) return true, 'Boombox rangée.' end
    if cfg('enabled', true) == false then return false, 'La musique est désactivée.' end
    if not allowed(src) then return false, 'Réservé aux VIP.' end
    if not usable(src) then return false, 'Pas maintenant.' end
    if vehOf(src) then return false, 'Descends du véhicule : ici, utilise le CarPlay.' end
    M.boxes[src] = true
    TriggerClientEvent('pb:g:music:box', src, true)
    return true, 'Boombox en main.'
end
RegisterNetEvent('pb:g:music:holster', function() M.Holster(source) end)
-- Position de la boombox dans la main : réglée en jeu par le staff (/boombox_regler), valable pour tout le monde
RegisterNetEvent('pb:g:music:adjust', function()
    local src = source
    if not P.Has(src, 'music.manage') then say(src, 'error', "Tu n'as pas le droit de régler la boombox.") return end
    if not M.boxes[src] then say(src, 'warn', 'Prends d\'abord la boombox en main.') return end
    TriggerClientEvent('pb:g:music:adjust', src)
end)
RegisterNetEvent('pb:g:music:savepos', function(pos)
    local src = source
    if not P.Has(src, 'music.manage') or type(pos) ~= 'table' then return end
    local out = {}
    for i = 1, 6 do
        local n = tonumber(pos[i])
        if not n or n ~= n then return end
        if i <= 3 and math.abs(n) > 1.5 then say(src, 'error', 'Position trop éloignée de la main.') return end
        out[i] = i <= 3 and n or (n % 360)
    end
    PB.Cfg.Set('music', 'box_pos', out, src, 'Position de la boombox dans la main', true)
    say(src, 'success', 'Position de la boombox enregistrée.')
    M.Push()
end)
-- Les VIP la reçoivent dans leur sac ; le VIP terminé, elle est reprise. Objet lié : ni donné, ni jeté, ni perdu à la mort.
function M.SyncItem(src)
    local o = owner(src)
    if not o or not (G.Inv and G.Inv.Count) then return end
    local n = tonumber(G.Inv.Count(o, ITEM)) or 0
    if allowed(src) then
        if n == 0 then G.Inv.Add(o, ITEM, 1) end
    elseif n > 0 then
        M.Holster(src)
        G.Inv.Remove(o, ITEM, n)
    end
end
PB.OnReady(function()
    if G.Inv then
        if G.Inv.Bind then G.Inv.Bind(ITEM) end
        if G.Inv.RegisterUsable then G.Inv.RegisterUsable(ITEM, function(src) local ok, msg = M.Equip(src) return ok, msg, true end) end
    end
end)
table.insert(G.beginHooks, function(src) M.SyncItem(src) M.Push(src) end)
AddEventHandler('pb_panel:vipChanged', function(src) if G.Get(src) then M.SyncItem(src) end end)
AddEventHandler('playerDropped', function()
    local s = source
    last[s] = nil
    M.boxes[s] = nil
    if M.sources['box:' .. s] then M.sources['box:' .. s] = nil M.Push() end
end)

-- Vérifications régulières : boombox encore tenue, véhicule encore là et occupé, durée maximale
local emptySince = {}
function M.Tick()
    for src in pairs(M.boxes) do
        local o = owner(src)
        if not usable(src) or not o or not allowed(src) or (tonumber(G.Inv.Count(o, ITEM)) or 0) < 1 then M.Holster(src)
        elseif vehOf(src) then M.Holster(src, 'Boombox rangée : dans un véhicule, utilise le CarPlay.') end
    end
    local changed, n = false, os.time()
    local max = (tonumber(cfg('max_mins', 240)) or 0) * 60
    for k, s in pairs(M.sources) do
        local gone = max > 0 and n - s.at > max
        if s.t == 'car' and not gone then
            local v = NetworkGetEntityFromNetworkId(s.net)
            if not v or v == 0 or not DoesEntityExist(v) then gone = true
            else
                local occupied = false
                for t in pairs(G.Players()) do if vehOf(t) == v then occupied = true break end end
                if occupied then emptySince[k] = nil
                else
                    emptySince[k] = emptySince[k] or n
                    if n - emptySince[k] >= 60 then gone = true end   -- véhicule laissé vide : la musique s'arrête toute seule
                end
            end
        end
        if gone then M.sources[k] = nil emptySince[k] = nil changed = true end
    end
    if changed then M.Push() end
end
CreateThread(function()
    while true do
        Wait(3000)
        pcall(M.Tick)
    end
end)

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
PB.Action('music.stop', 'music.manage', function(ctx, p)
    local s = M.sources[tostring(p.k)]
    if not s then return false, 'Plus de musique ici.' end
    M.sources[s.k] = nil
    M.Push()
    ctx.toast = 'Musique coupée.'
    return true
end)
local form = PB.Form.Cfg({ ns = 'music', id = 'settings', title = 'Musique', perm = 'music.manage', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Musique (boombox et CarPlay)', default = true },
    { k = 'car', type = 'toggle', label = 'CarPlay dans les véhicules', default = true, hint = 'Tous les occupants peuvent changer la musique.' },
    { k = 'box_range', type = 'number', label = 'Boombox : distance où l\'on entend (m)', default = 30, min = 5, max = 100 },
    { k = 'car_range', type = 'number', label = 'Véhicule : distance où l\'on entend dehors (m)', default = 16, min = 0, max = 60 },
    { k = 'volume', type = 'number', label = 'Volume maximal (%)', default = 70, min = 5, max = 100 },
    { k = 'max_mins', type = 'number', label = 'Arrêt automatique après (minutes, 0 = jamais)', default = 240, min = 0, max = 1440 },
    { k = 'stations', type = 'list', label = 'Radios : Nom|https://adresse-du-flux', default = STATIONS, maxitems = 24, maxlen = 200, wide = true,
      hint = 'Un flux audio direct en https. Il est chargé chez tous les joueurs proches : n\'ajoute que des radios connues.' },
} })
PB.Module({
    id = 'music', label = 'Musique', icon = 'music', group = 'Serveur', order = 85, perm = 'music.manage', hint = 'Boombox et CarPlay',
    caps = function()
        return PB.Capsify({
            { 'Radios en un clic', 'ok', 'Flux audio directs, réglables ici.' },
            { 'Liens YouTube et Vimeo', 'ok', 'Mêmes sites autorisés que les télévisions.' },
            { 'Son qui suit la boombox et le véhicule', 'ok', 'Plus fort en s\'approchant, plein son à bord.' },
            { 'Testé dans un vrai client FiveM', 'warn', 'Non. Certaines vidéos YouTube refusent d\'être lues hors du site ; les radios ne dépendent pas de YouTube.' },
        })
    end,
    doc = "## Musique\n**Boombox** : les VIP la reçoivent dans leur sac. Utilisée, elle passe en main et ouvre le mini CarPlay ; utilisée à nouveau, elle se range. **CarPlay** : dans un véhicule, touche **O** (modifiable dans les réglages FiveM). Tous les occupants peuvent changer la musique. Sans occupant pendant une minute, elle s'arrête. **Position dans la main** : boombox en main, tape **/boombox_regler**, ajuste avec les flèches et enregistre avec Entrée.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'En cours', icon = 'music', build = function()
                local rows = {}
                for _, s in pairs(M.sources) do rows[#rows + 1] = { where = s.t == 'car' and 'Véhicule' or 'Boombox', title = s.title ~= '' and s.title or s.id, by = s.by, at = s.at, actions = { { action = 'music.stop', label = 'Couper', icon = 'x', payload = { k = s.k }, danger = true } } } end
                return { B.table({ id = 'mul', title = 'Musiques en cours', columns = { { k = 'where', label = 'Où' }, { k = 'title', label = 'Titre' }, { k = 'by', label = 'Mis par' }, { k = 'at', label = 'Depuis', type = 'ago' }, { k = 'actions', label = '', type = 'actions' } }, rows = rows, empty = 'Aucune musique en cours.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
