-- Repos après une réapparition (« ATA ») : pendant quelques minutes après être revenu de l'hôpital, le joueur ne peut ni sortir d'arme,
-- ni tirer, ni courir. Le staff peut en mettre ou en retirer à un joueur (menu staff › un joueur). Options globales du menu staff :
-- réanimer tout le monde, lever tous les repos, démenotter tout le monde.
local G, P = PB.G, PB.Perm
local A = {}
G.Ata = A
PB.Cfg.Define('ata', { enabled = true, respawn_mins = 3 })
local function cfg(k, d) return PB.Cfg.Get('ata', k, d) end
local until_ = {}

function A.Set(src, secs)
    secs = math.max(0, math.floor(tonumber(secs) or 0))
    until_[src] = secs > 0 and (os.time() + secs) or nil
    TriggerClientEvent('pb:g:ata', src, PB.Json({ left = secs }))
end
function A.Left(src) local u = until_[src] return u and math.max(0, u - os.time()) or 0 end
AddEventHandler('pb_panel:playerRespawned', function(src)
    if cfg('enabled', true) == false then return end
    local secs = (tonumber(cfg('respawn_mins', 3)) or 3) * 60
    if G.Vip and G.Vip.Is(src) then secs = math.floor(secs * (100 - math.max(0, math.min(100, tonumber(PB.Cfg.Get('vip', 'rest_pct', 50)) or 0))) / 100) end
    A.Set(src, secs)
end)
AddEventHandler('playerDropped', function() until_[source] = nil end)
-- reconnexion pendant le repos : il reprend où il en était
table.insert(G.beginHooks, function(src) local l = A.Left(src) if l > 0 then A.Set(src, l) end end)

-- Menu staff ------------------------------------------------------------------------------------------------------------------------------
local S = G.Staff
local function name(t) local i = G.Identity(t) return (i and (i.firstname or '') ~= '') and (i.firstname .. ' ' .. (i.lastname or '')) or ('Joueur ' .. t) end
if S and S.Def then
    S.Def('ata_give', 'staff.heal', { target = true, inputs = { { k = 'minutes', label = 'Minutes de repos (sans arme ni course)', number = true, maxlen = 3 } }, run = function(src, t, p)
        local m = math.floor(tonumber(p.minutes) or 0)
        if m < 1 or m > 120 then return false, 'Entre 1 et 120 minutes.' end
        A.Set(t, m * 60)
        G.Notify(t, { type = 'warn', title = 'Repos', text = ('Un membre du staff t\'impose %d min de repos : ni arme, ni course.'):format(m) })
        return true, ('%s : %d min de repos.'):format(name(t), m)
    end, log = true })
    S.Def('ata_remove', 'staff.heal', { target = true, run = function(src, t)
        if A.Left(t) <= 0 then return false, "Cette personne n'est pas au repos." end
        A.Set(t, 0)
        G.Notify(t, { type = 'success', title = 'Repos', text = 'Ton repos est levé.' })
        return true, name(t) .. ' : repos levé.'
    end, log = true })
    S.Def('revive_all', 'staff.heal', { run = function()
        local n = 0
        for t in pairs(G.Players()) do
            local pl = G.Get(t)
            if pl and PB.ToBool(pl.row.dead) then G.Revive(t) n = n + 1 end
        end
        return true, n .. ' joueur(s) réanimé(s).'
    end, log = true })
    S.Def('ata_clear_all', 'staff.heal', { run = function()
        local n = 0
        for t in pairs(G.Players()) do if A.Left(t) > 0 then A.Set(t, 0) n = n + 1 end end
        return true, n .. ' repos levé(s).'
    end, log = true })
    S.Def('uncuff_all', 'staff.freeze', { run = function()
        local n = 0
        for t in pairs(G.Players()) do
            if G.IsCuffed and G.IsCuffed(t) and G.Police and G.Police.SetCuffed then G.Police.SetCuffed(t, false) n = n + 1 end
        end
        return true, n .. ' joueur(s) démenotté(s).'
    end, log = true })
end
