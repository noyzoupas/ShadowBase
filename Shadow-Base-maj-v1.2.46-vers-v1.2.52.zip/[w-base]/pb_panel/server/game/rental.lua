-- Location de véhicules : des points posés avec le Builder du menu staff (ou la Carte), une liste de véhicules et de prix réglable.
-- Le serveur encaisse, le client fait apparaître le véhicule loué ; il est rendu au point de location ou disparaît à la fin de la durée.

local P, Form = PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local R = {}
G.Rental = R

P.Register('rental.edit', 'Modifier la location de véhicules (véhicules, prix, durée)', 'rental', false)
local VEHICLES = { 'faggio|Scooter Faggio|150', 'bmx|Vélo BMX|50', 'panto|Panto|300', 'blista|Blista|350', 'asea|Asea|400', 'bison|Pick-up Bison|600' }
-- Location VIP (Cayo Perico) : modèle|nom|prix|coffre en kg — un véhicule en plus de la location normale, avec un grand coffre
local VIP_VEHICLES = { 'slamtruck|Slamtruck (import)|400|300', 'verus|Verus (import)|250|120', 'manchez2|Manchez Scout (import)|250|80' }
local VIP_POINT = { { id = 'vip_cayo', label = 'Location VIP · Cayo Perico', x = 4500.6, y = -4523.4, z = 4.2, sx = 4507.8, sy = -4530.5, sz = 4.2, sh = 110.0 } }
PB.Cfg.Define('rental', { vip_enabled = true, vip_minutes = 120, vip_vehicles = VIP_VEHICLES, vip_points = VIP_POINT })
R.form = Form.Cfg({ ns = 'rental', id = 'settings', title = 'Location de véhicules', perm = 'rental.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Location active', default = true },
    { k = 'minutes', type = 'number', label = 'Durée d\'une location (minutes)', default = 30, min = 5, max = 600 },
    { k = 'vehicles', type = 'list', label = 'Véhicules : modèle|nom|prix', default = VEHICLES, maxitems = 40, maxlen = 64, wide = true, hint = 'Un véhicule par ligne, ex. faggio|Scooter Faggio|150.' },
    { k = 'refund', type = 'number', label = 'Remboursé si rendu au point (%)', default = 30, min = 0, max = 100 },
    { k = 'points', type = 'rows', label = 'Points de location', default = {}, wide = true, maxitems = 40, unique = 'id', hint = 'Posés avec le Builder du menu staff (F10) ou la Carte.',
      cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 32 }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false },
        { k = 'sx', label = 'Sortie X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'sy', label = 'Sortie Y', type = 'number', min = -10000, max = 10000, int = false },
        { k = 'sz', label = 'Sortie Z', type = 'number', min = -500, max = 3000, int = false }, { k = 'sh', label = 'Sortie cap', type = 'number', min = 0, max = 360, int = false } } },
} })
R.vipForm = Form.Cfg({ ns = 'rental', id = 'vip', title = 'Location VIP (Cayo Perico)', perm = 'rental.edit', cols = 2, fields = {
    { k = 'vip_enabled', type = 'toggle', label = 'Location VIP active', default = true, hint = 'Réservée aux VIP, en plus de leur location normale : véhicules importés avec un grand coffre.' },
    { k = 'vip_minutes', type = 'number', label = "Durée d'une location VIP (minutes)", default = 120, min = 5, max = 1440 },
    { k = 'vip_vehicles', type = 'list', label = 'Véhicules VIP : modèle|nom|prix|coffre (kg)', default = VIP_VEHICLES, maxitems = 20, maxlen = 64, wide = true, hint = 'Ex. slamtruck|Slamtruck (import)|400|300. Prix 0 = gratuit pour les VIP.' },
    { k = 'vip_points', type = 'rows', label = 'Comptoirs VIP', default = VIP_POINT, wide = true, maxitems = 10, unique = 'id', hint = 'Par défaut : la piste de Cayo Perico.',
      cols = { { k = 'id', label = 'Identifiant', pattern = '^vip_[%w_]+$', required = true, maxlen = 32 }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false },
        { k = 'sx', label = 'Sortie X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'sy', label = 'Sortie Y', type = 'number', min = -10000, max = 10000, int = false },
        { k = 'sz', label = 'Sortie Z', type = 'number', min = -500, max = 3000, int = false }, { k = 'sh', label = 'Sortie cap', type = 'number', min = 0, max = 360, int = false } } },
} })
local function cfg(k, d) return PB.Cfg.Get('rental', k, d) end

function R.Vehicles()
    local out = {}
    for _, line in ipairs(cfg('vehicles', VEHICLES) or {}) do
        local m, l, p = tostring(line):match('^([%w_]+)|([^|]+)|(%d+)$')
        if m then out[#out + 1] = { model = m:lower(), label = l:sub(1, 40), price = tonumber(p) } end
    end
    return out
end
function R.Point(id) for _, p in ipairs(cfg('points', {}) or {}) do if tostring(p.id) == tostring(id) then return p end end end
function R.VipVehicles()
    local out = {}
    for _, line in ipairs(cfg('vip_vehicles', VIP_VEHICLES) or {}) do
        local m, l, p, kg = tostring(line):match('^([%w_]+)|([^|]+)|(%d+)|?(%d*)$')
        if m then out[#out + 1] = { model = m:lower(), label = l:sub(1, 40), price = tonumber(p), kg = tonumber(kg) or 150 } end
    end
    return out
end
function R.VipPoint(id) for _, p in ipairs(cfg('vip_points', VIP_POINT) or {}) do if tostring(p.id) == tostring(id) then return p end end end

local rented = {}   -- src -> { net, plate, point, until }
local rentedVip = {}   -- src -> idem, location VIP (en plus de la normale)
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
local function despawn(r) if r and r.net then local e = NetworkGetEntityFromNetworkId(r.net) if e and e ~= 0 and DoesEntityExist(e) then DeleteEntity(e) end end end

RegisterNetEvent('pb:g:rent:take', function(pointId, idx, account)
    local src = source
    if not G.Get(src) or not throttle(src, 1500) or not cfg('enabled', true) then return end
    local vip = R.VipPoint(pointId) ~= nil
    local pt, v = (vip and R.VipPoint or R.Point)(pointId), (vip and R.VipVehicles() or R.Vehicles())[math.floor(tonumber(idx) or 0)]
    if not pt or not v then return end
    if vip and (cfg('vip_enabled', true) == false or not (G.Vip and G.Vip.Is(src))) then G.Notify(src, { type = 'error', title = 'Location VIP', text = 'Réservé aux VIP.' }) return end
    if G.DistTo(src, pt.x, pt.y, pt.z) > 6.0 then G.Notify(src, { type = 'error', title = 'Location', text = 'Tu es trop loin du comptoir.' }) return end
    local book = vip and rentedVip or rented
    if book[src] then G.Notify(src, { type = 'error', title = 'Location', text = 'Rends d\'abord ton véhicule de location' .. (vip and ' VIP.' or '.') }) return end
    account = account == 'bank' and 'bank' or 'cash'
    v = { model = v.model, label = v.label, kg = v.kg, price = G.Eco and G.Eco.Final and G.Eco.Final(v.price or 0) or (v.price or 0) }   -- onglet Économie
    if v.price > 0 and not G.RemoveMoney(src, account, v.price, 'Location ' .. v.label) then G.Notify(src, { type = 'error', title = 'Location', text = ('Il te faut %s (%s).'):format(PB.Money(v.price), account == 'bank' and 'banque' or 'espèces') }) return end
    local plate = (vip and 'VIP%05d' or 'LOC%05d'):format(math.random(0, 99999))
    local mins = math.floor(tonumber(cfg(vip and 'vip_minutes' or 'minutes', vip and 120 or 30)) or 30)
    book[src] = { plate = plate, point = pt.id, price = v.price, untilT = os.time() + mins * 60, vip = vip or nil }
    if vip and G.VehTrunk and G.VehTrunk.Override then G.VehTrunk.Override[plate] = { 60, math.floor(v.kg * 1000) } end   -- grand coffre
    TriggerClientEvent('pb:g:rent:spawn', src, PB.Json({ model = v.model, plate = plate, spawn = { x = pt.sx or pt.x, y = pt.sy or pt.y, z = pt.sz or pt.z, h = pt.sh or 0 } }))
    G.Notify(src, { type = 'success', title = vip and 'Location VIP' or 'Location', text = ('%s loué pour %d minutes (%s)%s.'):format(v.label, mins, v.price > 0 and PB.Money(v.price) or 'offert', vip and (', coffre de ' .. v.kg .. ' kg') or '') })
end)
RegisterNetEvent('pb:g:rent:spawned', function(plate, net)
    local src = source
    for _, book in ipairs({ rented, rentedVip }) do
        local r = book[src]
        if r and r.plate == plate then r.net = math.floor(tonumber(net) or 0) end
    end
end)
RegisterNetEvent('pb:g:rent:back', function(pointId)
    local src = source
    local vip = R.VipPoint(pointId) ~= nil
    local book = vip and rentedVip or rented
    local r, pt = book[src], (vip and R.VipPoint or R.Point)(pointId)
    if not r or not pt or not throttle(src, 1500) then return end
    if G.DistTo(src, pt.x, pt.y, pt.z) > 25.0 then return end
    -- remboursement seulement si le véhicule est rapporté en état (sinon : location close sans remboursement)
    local e = r.net and r.net > 0 and NetworkGetEntityFromNetworkId(r.net) or 0
    local here = e ~= 0 and DoesEntityExist(e)
    if here then
        local c = GetEntityCoords(e)
        if #(c - vector3(pt.x, pt.y, pt.z)) > 40.0 then G.Notify(src, { type = 'error', title = 'Location', text = 'Ramène le véhicule au comptoir pour le rendre.' }) return end
    end
    local intact = here and GetEntityHealth(e) > 0 and GetVehicleEngineHealth(e) > 100
    despawn(r)
    book[src] = nil
    if vip and G.VehTrunk and G.VehTrunk.Override then G.VehTrunk.Override[r.plate] = nil end
    local back = intact and math.floor(r.price * (tonumber(cfg('refund', 30)) or 0) / 100) or 0
    if not intact then G.Notify(src, { type = 'warn', title = 'Location', text = 'Véhicule absent ou détruit : pas de remboursement.' }) return end
    if back > 0 then G.AddMoney(src, 'cash', back, 'Retour de location') end
    G.Notify(src, { type = 'success', title = 'Location', text = 'Véhicule rendu' .. (back > 0 and (' : ' .. PB.Money(back) .. ' remboursés.') or '.') })
end)
local function endVip(r) if r and G.VehTrunk and G.VehTrunk.Override then G.VehTrunk.Override[r.plate] = nil end despawn(r) end
AddEventHandler('playerDropped', function() local src = source despawn(rented[src]) endVip(rentedVip[src]) rented[src], rentedVip[src] = nil, nil last[src] = nil end)
CreateThread(function()
    Wait(math.random(0, 30000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(30000)
        local now = os.time()
        for src, r in pairs(rented) do
            if now >= r.untilT then despawn(r) rented[src] = nil G.Notify(src, { type = 'info', title = 'Location', text = 'Ta location est terminée : le véhicule a été repris.' }) end
        end
        for src, r in pairs(rentedVip) do
            -- fin de la durée, ou fin du VIP : le véhicule VIP est repris
            if now >= r.untilT or not (G.Vip and G.Vip.Is(src)) then endVip(r) rentedVip[src] = nil G.Notify(src, { type = 'info', title = 'Location VIP', text = 'Ta location VIP est terminée : le véhicule a été repris.' }) end
        end
    end
end)
function R.ClientList()
    local out = {}
    for _, p in ipairs(cfg('points', {}) or {}) do out[#out + 1] = { id = p.id, label = p.label, x = p.x, y = p.y, z = p.z } end
    return out
end

-- Point posé avec le Builder / la Carte : le comptoir est où tu te tiens, les véhicules sortent 5 m devant toi
local function ahead(pos, d) local r = math.rad(pos.h or 0) return { x = pos.x - math.sin(r) * d, y = pos.y + math.cos(r) * d, z = pos.z + 0.0, h = pos.h or 0 } end
PB.Place.Register({ id = 'rental', label = 'Location de véhicules', group = 'Commerces', icon = 'engine',
    create = function(pos, name)
        local sp = ahead(pos, 5.0)
        local list = {}
        for _, r in ipairs(cfg('points', {}) or {}) do list[#list + 1] = r end
        list[#list + 1] = { id = 'rent_' .. tostring(os.time() % 1000000) .. math.random(10, 99), label = tostring(name):sub(1, 40), x = pos.x + 0.0, y = pos.y + 0.0, z = pos.z + 0.0,
            sx = sp.x + 0.0, sy = sp.y + 0.0, sz = sp.z + 0.0, sh = (pos.h or 0) + 0.0 }
        PB.Cfg.Set('rental', 'points', list, 0, 'Location : ' .. tostring(name))
        G.PushConfig()
        return true, name .. ' créé : les véhicules sortent 5 m devant toi. Véhicules et prix dans Location de véhicules.'
    end,
    list = function() local out = {} for _, r in ipairs(cfg('points', {}) or {}) do out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y } end return out end,
    remove = function(rid)
        local out = {}
        for _, r in ipairs(cfg('points', {}) or {}) do if tostring(r.id) ~= tostring(rid) then out[#out + 1] = r end end
        PB.Cfg.Set('rental', 'points', out, 0, 'Location : suppression') G.PushConfig() return true
    end })

PB.Module({
    id = 'rental', label = 'Location de véhicules', icon = 'engine', group = 'Serveur', order = 150, perm = 'rental.edit', hint = 'Points de location, véhicules, prix',
    doc = "## Location de véhicules\nPose un point avec le **Builder** du menu staff (F10 › Builder › Commerces › Location de véhicules) : le comptoir est où tu te tiens, les véhicules sortent 5 m devant toi.\n\nLe joueur appuie sur **E** au comptoir, choisit un véhicule et paie (espèces ou banque). Il le rend au même point (**E** dans le véhicule) pour être remboursé d'une partie ; sinon le véhicule est repris à la fin de la durée.\n\n**Location VIP** : un comptoir à Cayo Perico (onglet Location VIP), réservé aux VIP, en plus de leur location normale : véhicules importés avec un grand coffre.",
    view = function(ctx) return { tabs = { { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { R.form(ctx) } end },
        { id = 'vip', label = 'Location VIP', icon = 'crown', build = function() return { R.vipForm(ctx) } end } } } end,
})

-- (v1.2.45) plus de véhicules militaires à louer : retirés une fois des listes déjà enregistrées (remplacés s'il ne reste rien)
PB.OnReady(function()
    if PB.Cfg.Get('rental', 'nomil_v166', false) == true then return end
    if PB.Cfg.Has('rental', 'vip_vehicles') then
        local out = {}
        for _, l in ipairs(PB.Cfg.Get('rental', 'vip_vehicles', {}) or {}) do
            local m = tostring(l):match('^([^|]+)')
            if m and m:lower() ~= 'squaddie' and m:lower() ~= 'winky' then out[#out + 1] = l end
        end
        if #out == 0 then out = VIP_VEHICLES end
        PB.Cfg.Set('rental', 'vip_vehicles', out, nil, 'Plus de véhicules militaires')
    end
    PB.Cfg.Set('rental', 'nomil_v166', true, nil, 'Migration')
end)
