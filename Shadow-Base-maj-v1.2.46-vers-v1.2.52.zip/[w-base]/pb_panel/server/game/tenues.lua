-- Tenues enregistrées (v1.2.42) : « Enregistrer ma tenue » range la tenue portée dans un sac de vêtements (objet « tenue_<n> »)
-- avec la photo du haut. Utiliser le sac (inventaire, n'importe où) ou « Mes tenues » dans un logement remet toute la tenue.
-- Seuls les vêtements et accessoires changent : visage, cheveux et tatouages restent ceux du personnage.

local G, DB = PB.G, PB.DB
local T = {}
G.Tenues = T

PB.Migrate('395_saved_outfits', 'Tenues enregistrées (sacs de vêtements)', {
    [[CREATE TABLE IF NOT EXISTS pb_saved_outfits (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, label VARCHAR(40) NOT NULL,
        sex VARCHAR(1) NOT NULL DEFAULT 'm', data TEXT NOT NULL, at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_so_lic (license))]],
})
PB.Cfg.Define('tenues', { enabled = true, max = 10 })
local function cfg(k, d) return PB.Cfg.Get('tenues', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):gsub('%s+', ' '):gsub('^ ', ''):sub(1, n)) end
local function owner(src) local p = G.Get(src) return p and ('p:' .. p.license) or nil end
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

local function itemOf(id) return 'tenue_' .. tostring(id) end
local function sexOf(p) return p.row.sex == 'f' and 'f' or 'm' end

-- objet « sac de vêtements » d'une tenue (créé une fois)
local function ensureItem(row)
    local data = PB.FromJson(row.data, {}) or {}
    local top = data.comps and data.comps[12] and tonumber(data.comps[12].d) or nil
    local img = top and ('img/clothes/%s_c11_%d.webp'):format(row.sex == 'f' and 'female' or 'male', top) or ''
    return G.Inv.EnsureCloth({ name = itemOf(row.id), label = 'Tenue : ' .. row.label, weight = 800, cloth = '', image = img,
        description = 'Sac de vêtements : utilise-le pour enfiler toute la tenue (visage et cheveux ne changent pas).' })
end

function T.List(license) return DB.q('SELECT id, label, sex, at FROM pb_saved_outfits WHERE license = ? ORDER BY id', { license }) or {} end

function T.Save(src, label)
    if cfg('enabled', true) == false then return false, 'Les tenues enregistrées sont désactivées.' end
    local p = G.Get(src)
    if not p or not G.Inv then return false, 'Joueur introuvable.' end
    local app = PB.FromJson(p.row.appearance, nil)
    if type(app) ~= 'table' or type(app.comps) ~= 'table' then return false, "Crée d'abord ton personnage." end
    local n = #T.List(p.license)
    if n >= (G.Vip and G.Vip.OutfitsMax(p.license) or tonumber(cfg('max', 10)) or 10) then return false, ('Tu as déjà %d tenues enregistrées : supprimes-en une (Mes tenues).'):format(n) end
    label = clean(label, 32)
    if #label < 2 then label = 'Tenue ' .. (n + 1) end
    local data = { comps = app.comps, props = app.props or {} }
    local id = DB.insert('INSERT INTO pb_saved_outfits (license, label, sex, data, at) VALUES (?, ?, ?, ?, ?)', { p.license, label, sexOf(p), PB.Json(data), os.time() })
    if not id then return false, "Enregistrement impossible." end
    local row = { id = id, label = label, sex = sexOf(p), data = PB.Json(data) }
    if not ensureItem(row) then DB.exec('DELETE FROM pb_saved_outfits WHERE id = ?', { id }) return false, 'Enregistrement impossible.' end
    local o = owner(src)
    local can = true
    if G.Inv.CanCarry then can = G.Inv.CanCarry(o, itemOf(id), 1) end
    if not can or not G.Inv.Add(o, itemOf(id), 1) then
        DB.exec('DELETE FROM pb_saved_outfits WHERE id = ?', { id })
        return false, 'Ton sac est plein : fais de la place pour ranger la tenue.'
    end
    if G.Inv.Push then pcall(G.Inv.Push, src) end
    return true, ('« %s » rangée dans ton sac.'):format(label)
end

-- Enfiler une tenue enregistrée (le sac reste dans l'inventaire)
function T.Wear(src, id)
    local p = G.Get(src)
    local row = p and DB.one('SELECT * FROM pb_saved_outfits WHERE id = ?', { tonumber(id) or -1 })
    if not row then return false, 'Cette tenue n\'existe plus.' end
    if row.sex ~= sexOf(p) then return false, "Cette tenue n'est pas à ta taille (modèle homme / femme différent)." end
    local stored = PB.FromJson(p.row.appearance, nil)
    local data = PB.FromJson(row.data, nil)
    if type(stored) ~= 'table' or type(data) ~= 'table' then return false, 'Tenue illisible.' end
    local merged = PB.DeepCopy(stored)
    merged.comps, merged.props = data.comps, data.props or {}
    local v, err = G.ValidAppearance(merged, p.row.sex)
    if not v then return false, err or 'Tenue invalide.' end
    G.SaveAppearance(src, v)
    if G.Inv.ResetWorn then G.Inv.ResetWorn(src) end
    TriggerClientEvent('pb:g:tenue:apply', src, PB.Json(v))
    if G.Inv.Push then pcall(G.Inv.Push, src) end
    return true, ('Tu as enfilé « %s ».'):format(row.label)
end

function T.Delete(src, id)
    local p = G.Get(src)
    local row = p and DB.one('SELECT * FROM pb_saved_outfits WHERE id = ? AND license = ?', { tonumber(id) or -1, p.license })
    if not row then return false, 'Tenue introuvable.' end
    DB.exec('DELETE FROM pb_saved_outfits WHERE id = ?', { row.id })
    local o = owner(src)
    local n = G.Inv.Count(o, itemOf(row.id))
    if n > 0 then G.Inv.Remove(o, itemOf(row.id), n) end
    if G.Inv.Push then pcall(G.Inv.Push, src) end
    return true, ('« %s » supprimée.'):format(row.label)
end

-- Utiliser le sac de vêtements depuis l'inventaire
CreateThread(function()
    while not (G.Inv and G.Inv.RegisterUsablePrefix) do Wait(200) end
    G.Inv.RegisterUsablePrefix('tenue_', function(src, item)
        local ok, msg = T.Wear(src, tostring(item):match('^tenue_(%d+)$'))
        if ok then return true, msg, true end   -- le sac reste dans l'inventaire
        return false, msg
    end)
end)

-- Bouton « Tenue » de l'inventaire et entrée du menu ALT
RegisterNetEvent('pb:g:tenue:save', function(label)
    local src = source
    if not throttle(src, 1500) then return end
    local ok, msg = T.Save(src, label)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Tenues', text = msg })
end)
-- « Mes tenues » (dans un logement) : liste, enfiler, supprimer
local function inHome(src) return G.Housing and G.Housing.Inside and G.Housing.Inside[src] ~= nil end
T.InHome = inHome
RegisterNetEvent('pb:g:tenue:list', function()
    local src = source
    if not throttle(src, 500) then return end
    local p = G.Get(src)
    if not p then return end
    if not inHome(src) then G.Notify(src, { type = 'warn', title = 'Tenues', text = 'Ta garde-robe est chez toi : entre dans un logement.' }) return end
    TriggerClientEvent('pb:g:tenue:list', src, PB.Json(T.List(p.license)))
end)
RegisterNetEvent('pb:g:tenue:wear', function(id)
    local src = source
    if not throttle(src, 800) then return end
    if not inHome(src) then return end
    local p = G.Get(src)
    if not p or not DB.one('SELECT id FROM pb_saved_outfits WHERE id = ? AND license = ?', { tonumber(id) or -1, p.license }) then return end
    local ok, msg = T.Wear(src, id)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Tenues', text = msg })
end)
RegisterNetEvent('pb:g:tenue:delete', function(id)
    local src = source
    if not throttle(src, 800) then return end
    local ok, msg = T.Delete(src, id)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Tenues', text = msg })
    local p = G.Get(src)
    if p and inHome(src) then TriggerClientEvent('pb:g:tenue:list', src, PB.Json(T.List(p.license))) end
end)

-- Menu ALT
CreateThread(function()
    while not (G.Ctx and G.Ctx.H) do Wait(200) end
    G.Ctx.H.outfit_save = function(src, _, p) return T.Save(src, p.text) end
    G.Ctx.H.outfits = function(src)
        local p = G.Get(src)
        if not p or not inHome(src) then return false, 'Ta garde-robe est chez toi : entre dans un logement.' end
        TriggerClientEvent('pb:g:tenue:list', src, PB.Json(T.List(p.license)))
        return true
    end
end)
