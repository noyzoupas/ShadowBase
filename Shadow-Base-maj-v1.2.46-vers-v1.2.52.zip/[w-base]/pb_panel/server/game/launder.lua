-- Blanchiment avec un contact (PNJ) aux points de blanchiment (Builder › Activités illégales › Point de blanchiment).
-- On confie son argent sale au contact : plus la mise est petite, plus il prend un gros pourcentage. Ça dure longtemps (1 h minimum
-- par défaut) ; à la fin, une notification prévient et l'argent propre se récupère chez le contact. Un seul blanchiment à la fois par joueur.
-- Le temps restant se voit au point ; les VIP le voient de partout (/blanchiment).

local G, DB = PB.G, PB.DB
local W = {}
G.Launder = W

PB.Migrate('400_launder_jobs', 'Blanchiment : argent confié au contact', {
    [[CREATE TABLE IF NOT EXISTS pb_launder_jobs (license VARCHAR(64) NOT NULL, spot VARCHAR(32) NOT NULL DEFAULT '', dirty INT NOT NULL DEFAULT 0, clean INT NOT NULL DEFAULT 0,
        cut INT NOT NULL DEFAULT 0, started INT NOT NULL DEFAULT 0, ends INT NOT NULL DEFAULT 0, paid INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
})
-- tiers : « mise minimale|commission % » ; durée = base_min minutes + per_1000 minutes par tranche de 1 000 $, au plus max_hours heures
PB.Cfg.Define('launder', { enabled = true, min = 1000, max = 500000, tiers = { '1000|45', '5000|38', '20000|30', '50000|24', '100000|18', '250000|14' },
    base_min = 60, per_1000 = 3, max_hours = 24, pay_to = 'cash', vip_remote = true, ped = 'g_m_m_armboss_01' })
local function cfg(k, d) return PB.Cfg.Get('launder', k, d) end
local function money(n) return PB.Money(n) end
local function dirtyItem() return PB.Cfg.Get('crime', 'dirty_item', 'black_money') end
local function spots() return PB.Cfg.Get('crime', 'launder', {}) or {} end
local function spot(id) for _, s in ipairs(spots()) do if tostring(s.id) == tostring(id) then return s end end end
local function near(src, s) return s and G.DistTo(src, s.x, s.y, s.z) <= 4.0 end

-- commission selon la mise (palier le plus haut atteint)
function W.CutFor(amount)
    local cut = 50
    local list = {}
    for _, line in ipairs(cfg('tiers', {}) or {}) do
        local m, c = tostring(line):match('^(%d+)|(%d+)$')
        if m then list[#list + 1] = { tonumber(m), tonumber(c) } end
    end
    table.sort(list, function(a, b) return a[1] < b[1] end)
    for _, t in ipairs(list) do if amount >= t[1] then cut = t[2] end end
    return math.max(0, math.min(95, cut))
end
function W.DurationFor(amount)
    local mins = (tonumber(cfg('base_min', 60)) or 60) + math.floor(amount / 1000) * (tonumber(cfg('per_1000', 3)) or 3)
    return math.min(mins, (tonumber(cfg('max_hours', 24)) or 24) * 60) * 60
end
local function fmtDur(secs)
    secs = math.max(0, math.floor(secs))
    local h, m = math.floor(secs / 3600), math.floor((secs % 3600) / 60)
    if h > 0 then return ('%d h %02d'):format(h, m) end
    return ('%d min'):format(math.max(1, m))
end
W.FmtDur = fmtDur

local function jobOf(license) return DB.one('SELECT * FROM pb_launder_jobs WHERE license = ?', { license }) end
local function state(j)
    if not j then return nil end
    local now = os.time()
    local f = math.max(0, math.min(1, (now - j.started) / math.max(1, j.ends - j.started)))
    local sp = spot(j.spot)
    return { spot = j.spot, spotLabel = sp and sp.label or nil, dirty = j.dirty, clean = j.clean, cut = j.cut, paid = j.paid, left = math.max(0, j.ends - now), pct = math.floor(f * 100),
        total = math.max(1, j.ends - j.started), done = f >= 1 or nil }
end

-- (v1.2.45) l'argent propre reste chez le contact : quand c'est fini, le joueur est prévenu et va le récupérer (bouton dans la fenêtre)
local told = {}   -- licence -> déjà prévenu que c'est prêt
local function payOut(src, j)
    local f = (os.time() - j.started) / math.max(1, j.ends - j.started)
    if f >= 1 and not told[j.license] then
        told[j.license] = true
        local sp = spot(j.spot)
        G.Notify(src, { type = 'success', title = 'Blanchiment terminé', text = ('Ton argent propre est prêt (%s) : va le récupérer chez ton contact%s.'):format(money(math.max(0, j.clean - j.paid)), sp and (' (' .. sp.label .. ')') or ''), duration = 14000 })
    end
end
function W.Collect(src, id)
    local p = G.Get(src)
    local j = p and jobOf(p.license)
    if not j then return false, "Rien à récupérer." end
    -- le contact d'origine a été supprimé (point reposé au Builder…) : n'importe quel contact rend l'argent, il ne reste jamais bloqué
    if tostring(j.spot) ~= tostring(id) and spot(j.spot) then return false, "Ton argent n'est pas chez ce contact." end
    if os.time() < j.ends then return false, 'Pas encore prêt : encore ' .. fmtDur(j.ends - os.time()) .. '.' end
    local due = math.max(0, j.clean - j.paid)
    if (tonumber(DB.exec('DELETE FROM pb_launder_jobs WHERE license = ?', { p.license })) or 0) < 1 then return false, 'Déjà récupéré.' end
    told[p.license] = nil
    if due > 0 then G.AddMoney(src, cfg('pay_to', 'cash') == 'bank' and 'bank' or 'cash', due, 'Blanchiment') end
    PB.Audit.Log('economie', 'launder.done', src, j.spot, nil, nil, { dirty = j.dirty, clean = j.clean, paid = due })
    return true, ('Tu récupères %s propres.'):format(money(due))
end
RegisterNetEvent('pb:g:wash:collect', function(id)
    local src = source
    local s = spot(id)
    if not s or not near(src, s) then return end
    local ok, msg = W.Collect(src, id)
    G.Notify(src, { type = ok and 'success' or 'warn', title = 'Blanchiment', text = msg })
    if ok then W.Menu(src, id) end
end)
local function tick()
    for src, p in pairs(G.Players()) do
        local j = jobOf(p.license)
        if j then pcall(payOut, src, j) end
    end
end
CreateThread(function()
    Wait(math.random(5000, 60000))
    while true do Wait(60000) if cfg('enabled', true) ~= false then tick() end end
end)
table.insert(G.beginHooks, function(src) SetTimeout(15000, function() local p = G.Get(src) local j = p and jobOf(p.license) if j then pcall(payOut, src, j) end end) end)

-- Ouverture du menu au PNJ
local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
function W.Menu(src, id)
    local p = G.Get(src)
    local s = spot(id)
    if not p or not near(src, s) then return end
    local inv = G.Inv
    local have = inv and inv.Count and inv.Count('p:' .. p.license, dirtyItem()) or 0
    local offers = {}
    for _, a in ipairs({ 1000, 2500, 5000, 10000, 20000, 50000, 100000, 250000, 500000 }) do
        if a >= (tonumber(cfg('min', 1000)) or 1000) and a <= math.min(have, tonumber(cfg('max', 500000)) or 500000) then offers[#offers + 1] = a end
    end
    if have >= (tonumber(cfg('min', 1000)) or 1000) and have <= (tonumber(cfg('max', 500000)) or 500000) and offers[#offers] ~= have then offers[#offers + 1] = have end
    local list = {}
    for _, a in ipairs(offers) do
        local cut = W.CutFor(a)
        list[#list + 1] = { amount = a, cut = cut, clean = math.floor(a * (100 - cut) / 100), dur = fmtDur(W.DurationFor(a)) }
    end
    TriggerClientEvent('pb:g:wash:menu', src, PB.Json({ id = s.id, label = s.label, have = have, offers = list, job = state(jobOf(p.license)), min = cfg('min', 1000) }))
end
RegisterNetEvent('pb:g:wash:open', function(id)
    local src = source
    if not throttle(src, 600) or cfg('enabled', true) == false then return end
    W.Menu(src, id)
end)
RegisterNetEvent('pb:g:wash:start', function(id, amount)
    local src = source
    if not throttle(src, 1000) or cfg('enabled', true) == false then return end
    local p = G.Get(src)
    local s = spot(id)
    if not p or PB.ToBool(p.row.dead) or not near(src, s) then return end
    local function say(kind, text) G.Notify(src, { type = kind, title = 'Blanchiment', text = text }) end
    if jobOf(p.license) then say('error', 'Ton contact blanchit déjà de l\'argent pour toi : attends la fin.') return end
    amount = math.floor(tonumber(amount) or 0)
    local mn, mx = tonumber(cfg('min', 1000)) or 1000, tonumber(cfg('max', 500000)) or 500000
    if amount < mn or amount > mx then say('error', ('Mise : %s à %s.'):format(money(mn), money(mx))) return end
    local o = 'p:' .. p.license
    if (G.Inv.Count(o, dirtyItem()) or 0) < amount or not G.Inv.Remove(o, dirtyItem(), amount) then say('error', "Tu n'as pas assez d'argent sale sur toi.") return end
    local cut = W.CutFor(amount)
    local clean = math.floor(amount * (100 - cut) / 100)
    local dur = W.DurationFor(amount)
    local now = os.time()
    DB.exec('REPLACE INTO pb_launder_jobs (license, spot, dirty, clean, cut, started, ends, paid) VALUES (?, ?, ?, ?, ?, ?, ?, 0)', { p.license, s.id, amount, clean, cut, now, now + dur })
    PB.Audit.Log('economie', 'launder.start', src, s.id, nil, nil, { dirty = amount, clean = clean, cut = cut, secs = dur })
    say('success', ('%s confiés (commission %d %%). %s propres à récupérer ici dans %s.'):format(money(amount), cut, money(clean), fmtDur(dur)))
    W.Menu(src, id)
end)

-- Suivi à distance : réservé aux VIP (sinon il faut passer voir le contact)
RegisterCommand('blanchiment', function(src)
    local p = src > 0 and G.Get(src)
    if not p then return end
    local j = state(jobOf(p.license))
    local function say(kind, text) G.Notify(src, { type = kind, title = 'Blanchiment', text = text }) end
    if not j then say('info', "Aucun blanchiment en cours.") return end
    local vip = G.Vip and G.Vip.Is and G.Vip.Is(src)
    local s = spot(j.spot)
    if not (vip and cfg('vip_remote', true) ~= false) and not near(src, s) then say('warn', 'Va voir ton contact pour connaître l\'avancement (les VIP le voient de partout).') return end
    say('info', j.done and ('Terminé : %s propres à récupérer chez ton contact.'):format(money(j.clean - j.paid)) or ('%d %% · %s propres à récupérer dans %s.'):format(j.pct, money(j.clean - j.paid), fmtDur(j.left)))
end, false)

-- Panel
G.LaunderForm = PB.Form.Cfg({ ns = 'launder', id = 'settings', title = 'Blanchiment avec contact (PNJ)', perm = 'crime.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Blanchiment avec contact', default = true },
    { k = 'min', type = 'number', label = 'Mise minimale', default = 1000, min = 100, max = 1000000 },
    { k = 'max', type = 'number', label = 'Mise maximale', default = 500000, min = 1000, max = 100000000 },
    { k = 'base_min', type = 'number', label = 'Durée de base (minutes)', default = 60, min = 1, max = 1440 },
    { k = 'per_1000', type = 'number', label = 'Minutes en plus par tranche de 1 000 $', default = 3, min = 0, max = 120 },
    { k = 'max_hours', type = 'number', label = 'Durée maximale (heures)', default = 24, min = 1, max = 168 },
    { k = 'pay_to', type = 'select', label = 'Argent propre versé en', default = 'cash', opts = { { 'cash', 'Espèces' }, { 'bank', 'Banque' } } },
    { k = 'vip_remote', type = 'toggle', label = 'Les VIP voient l\'avancement de partout (/blanchiment)', default = true },
    { k = 'ped', type = 'text', label = 'Modèle du contact (PNJ)', default = 'g_m_m_armboss_01', maxlen = 40, pattern = '^[%w_]+$' },
    { k = 'tiers', type = 'list', label = 'Commission selon la mise (« mise|% »)', default = { '1000|45', '5000|38', '20000|30', '50000|24', '100000|18', '250000|14' }, hint = 'Plus la mise est grosse, plus la commission baisse.' },
} })

PB.SelfTest.Add('blanchiment', function(R)
    R.check(W.CutFor(1000) >= W.CutFor(250000), 'blanchiment : commission', 'une grosse mise doit coûter moins cher en %')
end)
