-- Placement en jeu : le joueur déplace les éléments directement sur la vraie vue (cadres pointillés), puis valide.
-- Les droits sont ceux du placement du panel (un groupe par permission) ; l'enregistrement passe par la même action validée et journalisée.

local G = PB.G

local function layoutBlock(src)
    local ctx = PB.MakeCtx(src)
    local can = {}
    for ns, g in pairs(PB.Interface and PB.Interface.Place or {}) do can[ns] = ctx.has(g.perm) and true or false end
    local any = false
    for _, v in pairs(can) do if v then any = true end end
    return ctx, can, any
end

local cooldown = {}
RegisterNetEvent('pb:g:layout:req', function()
    local src = source
    local t = GetGameTimer()
    if cooldown[src] and t - cooldown[src] < 1500 then return end
    cooldown[src] = t
    local ctx, can, any = layoutBlock(src)
    if not ctx.has('panel.open') or not any then
        TriggerClientEvent('pb:g:layout:open', src, PB.Json({ denied = true }))
        return
    end
    local cfg = G.ClientConfig()
    TriggerClientEvent('pb:g:layout:open', src, PB.Json({ can = can, cfg = {
        hud = cfg.hud, staff = cfg.staff, notify = cfg.notify, menus = cfg.menus, place = cfg.place, staffmenu = cfg.staffmenu } }))
end)

RegisterNetEvent('pb:g:layout:save', function(j)
    local src = source
    local ok, groups = pcall(json.decode, tostring(j or ''))
    if not ok or type(groups) ~= 'table' then return end
    local ctx = PB.MakeCtx(src)
    if not ctx.has('panel.open') then return end
    local act = PB.ActionList and PB.ActionList()['interface.place.save']
    if not act or not act.fn then return end
    local okc, res, msg = pcall(act.fn, ctx, { groups = groups })
    local good = okc and res ~= false
    TriggerClientEvent('pb:g:layout:done', src, good, good and (ctx.toast or 'Positions enregistrées.') or (okc and msg or 'Erreur'))
end)

-- remise à zéro de tous les groupes autorisés (bouton « Réinitialiser » : valeurs par défaut, enregistrées à la validation)
RegisterNetEvent('pb:g:layout:reset', function()
    local src = source
    local ctx = PB.MakeCtx(src)
    local act = PB.ActionList and PB.ActionList()['placement.reset']
    if not act or not act.fn then return end
    for ns, g in pairs(PB.Interface and PB.Interface.Place or {}) do
        if ctx.has(g.perm) then pcall(act.fn, ctx, { group = ns }) end
    end
    TriggerClientEvent('pb:g:layout:done', src, true, 'Positions par défaut rétablies.')
end)

AddEventHandler('playerDropped', function() cooldown[source] = nil end)

PB.OnReady(function() PB.SelfTest.Add('placement en jeu', function(R)
    R.check(PB.Interface and PB.Interface.Place and PB.Interface.Place.notify ~= nil, 'Placement en jeu', 'groupes de placement manquants')
    R.check(PB.Interface.Place.place.keys.mm_x ~= nil and PB.Interface.Place.notify.keys.x ~= nil, 'Placement en jeu', 'mini-carte ou notifications libres manquantes')
    R.check(PB.Cfg.Get('place', 'mm_y') ~= nil, 'Placement en jeu', 'position par défaut de la mini-carte manquante')
end) end)
