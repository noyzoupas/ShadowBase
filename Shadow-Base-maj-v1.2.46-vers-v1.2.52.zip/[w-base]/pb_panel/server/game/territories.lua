-- Territoires de gangs : zones à prendre. Un gang prend une zone en restant dedans pendant la durée de capture ; le serveur vérifie tout.
-- Les gangs viennent du module Gamertags (natifs ou lus depuis une autre ressource). Revenus versés aux membres connectés du gang propriétaire.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Tr = {}
G.Territories = Tr

P.Register('territories.edit', 'Modifier les territoires de gangs', 'territories', true)
PB.Migrate('078_territories', 'Territoires de gangs', {
    [[CREATE TABLE IF NOT EXISTS pb_territories (zone VARCHAR(32) NOT NULL PRIMARY KEY, gang VARCHAR(32) NOT NULL DEFAULT '', since INT NOT NULL DEFAULT 0, lastcap INT NOT NULL DEFAULT 0)]],
})
PB.Migrate('097_terr_influence', 'Territoires : influence des gangs', {
    [[CREATE TABLE IF NOT EXISTS pb_terr_influence (zone VARCHAR(32) NOT NULL, gang VARCHAR(32) NOT NULL, points INT NOT NULL DEFAULT 0, day INT NOT NULL DEFAULT 0, today INT NOT NULL DEFAULT 0, PRIMARY KEY (zone, gang))]],
})
PB.Migrate('196_terr_reward', 'Territoires : récompenses périodiques', {
    [[CREATE TABLE IF NOT EXISTS pb_terr_reward (zone VARCHAR(32) NOT NULL PRIMARY KEY, last INT NOT NULL DEFAULT 0)]],
})
PB.Migrate('139_terr_battles', 'Territoires : batailles persistantes et historique des guerres', {
    [[CREATE TABLE IF NOT EXISTS pb_terr_battles (zone VARCHAR(32) NOT NULL PRIMARY KEY, data MEDIUMTEXT NOT NULL, saved INT NOT NULL DEFAULT 0)]],
    [[CREATE TABLE IF NOT EXISTS pb_terr_history (id INT AUTO_INCREMENT PRIMARY KEY, zone VARCHAR(32) NOT NULL, label VARCHAR(60) NOT NULL DEFAULT '', started INT NOT NULL DEFAULT 0, ended INT NOT NULL DEFAULT 0, attacker VARCHAR(32) NOT NULL DEFAULT '', owner VARCHAR(32) NOT NULL DEFAULT '', winner VARCHAR(32) NOT NULL DEFAULT '', why VARCHAR(120) NOT NULL DEFAULT '', scores TEXT NOT NULL, KEY (zone), KEY (ended))]],
})
PB.Migrate('137_terr_control', 'Territoires : points de contrôle', {
    [[CREATE TABLE IF NOT EXISTS pb_terr_control (zone VARCHAR(32) NOT NULL, gang VARCHAR(32) NOT NULL, points INT NOT NULL DEFAULT 0, day INT NOT NULL DEFAULT 0, today INT NOT NULL DEFAULT 0, PRIMARY KEY (zone, gang))]],
})
local ZONES = {
    { id = 'grove', label = 'Grove Street', x = 114.0, y = -1944.0, z = 20.8, radius = 40, income = 400, time = 90, cooldown = 60, min = 1 },
    { id = 'vespucci', label = 'Canaux de Vespucci', x = -1157.0, y = -1520.0, z = 4.4, radius = 40, income = 300, time = 90, cooldown = 60, min = 1 },
    { id = 'mirror_park', label = 'Mirror Park', x = 1090.0, y = -645.0, z = 56.5, radius = 45, income = 300, time = 90, cooldown = 60, min = 1, reward_item = 'armor', reward_qty = 1, reward_hours = 10 },
}
-- polys : contour dessiné au Builder pour une zone ({ [id] = { {x, y}, … } }) ; reward_items : objets proposés à la création
PB.Cfg.Define('territories', { enabled = true, income_min = 30, show_blips = true, show_all = true, zones = ZONES, polys = {},
    bat_on = true, bat_hours_on = true, bat_tz = 'paris', peace_on = true, peace_police = true, peace_staff = true, bat_hours = { 'ven|20:00-23:00', 'sam|20:00-23:00', 'dim|20:00-23:00' }, bat_warn = 15, bat_target = 100, bat_secs = 20, bat_cps = 3, bat_kill = 5, bat_hold = 1, bat_duration = 15, bat_rest = 10, bat_max = 2, bat_head = 20, bat_idle = 180, bat_cp_radius = 6,
    reward_items = { 'armor', 'lockpick', 'bandage', 'medkit', 'rope', 'repairkit', 'black_money', 'ammo_pistol', 'ammo_smg', 'ammo_rifle', 'weed_pouch', 'coke_pouch' }, reward_hours_default = 5 })
local function cfg(k, d) return PB.Cfg.Get('territories', k, d) end
local function nowS() return os.time() end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function zone(id) for _, z in ipairs(cfg('zones', {}) or {}) do if z.id == id then return z end end end
function Tr.Zone(id) return zone(id) end
function Tr.Owner(id) local r = DB.one('SELECT gang, since, lastcap FROM pb_territories WHERE zone = ?', { id }) return r and r.gang ~= '' and r.gang or nil, r end
function Tr.Owners()
    local out = {}
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local gid = Tr.Owner(z.id)
        local d = gid and G.Tags and G.Tags.GangDefs()[gid]
        out[z.id] = gid and { gang = gid, label = d and d.label or gid, color = d and d.color or '#dfe2e7' } or false
    end
    return out
end
-- Influence : points gagnés par un gang dans une zone (graffitis non effacés, par exemple). Elle raccourcit la capture de cette zone par ce gang.
function Tr.Influence(zoneId, gangId)
    local r = DB.one('SELECT points FROM pb_terr_influence WHERE zone = ? AND gang = ?', { tostring(zoneId), tostring(gangId) })
    return r and tonumber(r.points) or 0
end
-- `cap` limite ce qu'un gang peut gagner dans une zone en une journée ; renvoie les points réellement ajoutés
function Tr.AddInfluence(zoneId, gangId, n, cap)
    n = math.floor(tonumber(n) or 0)
    if n <= 0 or not zone(zoneId) then return 0 end
    local day = math.floor(nowS() / 86400)
    local r = DB.one('SELECT points, day, today FROM pb_terr_influence WHERE zone = ? AND gang = ?', { zoneId, gangId })
    local today = (r and tonumber(r.day) == day) and tonumber(r.today) or 0
    if cap and cap > 0 then n = math.min(n, math.max(0, cap - today)) end
    if n <= 0 then return 0 end
    DB.exec('REPLACE INTO pb_terr_influence (zone, gang, points, day, today) VALUES (?, ?, ?, ?, ?)', { zoneId, gangId, (r and tonumber(r.points) or 0) + n, day, today + n })
    return n
end
function Tr.InfluenceRows()
    return DB.q('SELECT zone, gang, points FROM pb_terr_influence WHERE points > 0 ORDER BY points DESC LIMIT 100') or {}
end
-- point dans un polygone (contour dessiné au Builder), sinon le cercle de la zone
local function inPoly(x, y, poly)
    local inside, j = false, #poly
    for i = 1, #poly do
        local xi, yi, xj, yj = poly[i][1], poly[i][2], poly[j][1], poly[j][2]
        if ((yi > y) ~= (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1e-9) + xi) then inside = not inside end
        j = i
    end
    return inside
end
Tr.InPoly = inPoly
local function polyOf(z) local p = (cfg('polys', {}) or {})[z.id] return type(p) == 'table' and #p >= 3 and p or nil end
local function inZone(src, z, extra)
    local poly = polyOf(z)
    if poly then
        local ped = GetPlayerPed(src)
        if not ped or ped == 0 then return false end
        local c = GetEntityCoords(ped)
        return inPoly(c.x, c.y, poly)
    end
    return G.DistTo(src, z.x, z.y, z.z) <= (tonumber(z.radius) or 30) + (extra or 0)
end
Tr.InZone = inZone
local function gangsInZone(z)
    local out = {}
    for src in pairs(G.Players()) do
        local g = gangOf(src)
        if g and usable(src) and inZone(src, z) then out[g.id] = (out[g.id] or 0) + 1 end
    end
    return out
end

-- Batailles de zone -------------------------------------------------------------------------------------------------------------------------
-- Prendre une zone = gagner une bataille. Quand un gang attaque (E dans la zone), la zone s'ouvre : plusieurs points de contrôle apparaissent
-- à l'intérieur. Un point passe au gang qui reste SEUL dessus assez longtemps ; chaque point tenu rapporte du score toutes les 5 s, chaque
-- élimination d'un rival dans la zone aussi. Le premier gang au score cible prend la zone ; au bout de la durée, le meilleur score l'emporte
-- (égalité = le propriétaire garde). Les graffitis donnent une avance de départ. Tout est calculé et vérifié côté serveur.
-- Heure réelle (pas l'heure du jeu) : fuseau de Paris par défaut, avec heure d'été européenne ; « utc » ou « machine » au choix.
local function daysFromCivil(y, m, d)
    y = m <= 2 and y - 1 or y
    local era = math.floor(y / 400)
    local yoe = y - era * 400
    local doy = math.floor((153 * (m + (m > 2 and -3 or 9)) + 2) / 5) + d - 1
    local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
    return era * 146097 + doe - 719468
end
local function lastSundayUtc(y, m)      -- 01:00 UTC du dernier dimanche du mois
    local days = daysFromCivil(y, m, 31)
    local wd = (days + 4) % 7           -- 0 = dimanche
    return (days - wd) * 86400 + 3600
end
function Tr.Off(t)
    local mode = tostring(cfg('bat_tz', 'paris'))
    if mode == 'utc' then return 0 end
    if mode == 'machine' then
        local sg, hh, mm = tostring(os.date('%z', t)):match('^([+-])(%d%d)(%d%d)$')
        if not sg then return 0 end
        return (sg == '-' and -1 or 1) * (tonumber(hh) * 3600 + tonumber(mm) * 60)
    end
    local y = os.date('!*t', t).year
    return (t >= lastSundayUtc(y, 3) and t < lastSundayUtc(y, 10)) and 7200 or 3600
end
function Tr.LocalFmt(t, fmt) return os.date('!' .. fmt, t + Tr.Off(t)) end
-- Fenêtres de guerre : on ne peut attaquer qu'à des heures précises (« jour|HH:MM-HH:MM », jour = lun…dim ou tous), globales ou propres à une zone.
local DAYN = { dim = 1, lun = 2, mar = 3, mer = 4, jeu = 5, ven = 6, sam = 7 }
local function parseWindows(list)
    local out = {}
    for _, line in ipairs(list) do
        local d, h1, m1, h2, m2 = tostring(line):lower():match('^%s*(%a+)%s*|%s*(%d+):(%d+)%s*%-%s*(%d+):(%d+)%s*$')
        local day = d and (d == 'tous' and 0 or DAYN[d:sub(1, 3)])
        if day and tonumber(h1) < 24 and tonumber(h2) <= 24 then out[#out + 1] = { day = day, s = tonumber(h1) * 60 + tonumber(m1), e = tonumber(h2) * 60 + tonumber(m2), label = tostring(line) } end
    end
    return out
end
function Tr.Windows(z)
    local raw = tostring(z and z.hours or '')
    local list = {}
    if raw:gsub('%s', '') ~= '' then for part in raw:gmatch('[^;]+') do list[#list + 1] = part end
    else list = cfg('bat_hours', {}) or {} end
    return parseWindows(list)
end
-- ouvert maintenant ? renvoie (true, fin de la fenêtre) ou (false, début de la prochaine fenêtre, texte)
function Tr.WindowState(z, t)
    t = t or nowS()
    if cfg('bat_hours_on', true) == false then return true, t + 86400 end
    local ws = Tr.Windows(z)
    if #ws == 0 then return true, t + 86400 end
    local off = Tr.Off(t)
    local lt = t + off
    local d = os.date('!*t', lt)
    local mins = d.hour * 60 + d.min
    for _, w in ipairs(ws) do
        local today = (w.day == 0 or w.day == d.wday)
        local yest = (w.day == 0 or w.day == (d.wday + 5) % 7 + 1)
        if w.e > w.s then
            if today and mins >= w.s and mins < w.e then return true, t + (w.e - mins) * 60 - d.sec end
        else
            if today and mins >= w.s then return true, t + (1440 - mins + w.e) * 60 - d.sec end
            if yest and mins < w.e then return true, t + (w.e - mins) * 60 - d.sec end
        end
    end
    local midnight = lt - (d.hour * 3600 + d.min * 60 + d.sec)
    local best, bw
    for k = 0, 7 do
        for _, w in ipairs(ws) do
            local ts = midnight + k * 86400 + w.s * 60 - off
            local wd = os.date('!*t', ts + off).wday
            if ts > t and (w.day == 0 or w.day == wd) and (not best or ts < best) then best, bw = ts, w end
        end
    end
    return false, best, best and Tr.LocalFmt(best, '%d/%m à %Hh%M') or nil
end
local function bon() return cfg('bat_on', true) ~= false end
local function bnum(k, d) return tonumber(cfg(k, d)) or d end
local battles, cool = {}, {}      -- battles[zone] = bataille en cours ; cool[zone] = fin du repos après une bataille ratée
Tr.Battles = battles
local function dist2(src, x, y)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return 1e9 end
    local c = GetEntityCoords(ped)
    return math.sqrt((c.x - x) ^ 2 + (c.y - y) ^ 2)
end
local function gdef(id) local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id] return { label = d and d.label or id, color = d and d.color or '#dfe2e7' } end
local function gangSrcs(gid)
    local out = {}
    for s in pairs(G.Players()) do local g = gangOf(s) if g and g.id == gid then out[#out + 1] = s end end
    return out
end
local function tellGang(gid, kind, text)
    for _, s in ipairs(gangSrcs(gid)) do G.Notify(s, { type = kind, title = 'Territoire', text = text }) end
end
-- points de contrôle : placés en anneau autour du centre (dans le contour dessiné s'il y en a un)
function Tr.ControlPoints(z)
    local n = math.max(1, math.min(6, math.floor(tonumber(z.cps) or bnum('bat_cps', 3))))
    local r = (tonumber(z.radius) or 30) * (n == 1 and 0 or 0.55)
    local poly, out = polyOf(z), {}
    for i = 1, n do
        local a = (i - 1) * 2 * math.pi / n
        local x, y = z.x + math.cos(a) * r, z.y + math.sin(a) * r
        if poly then
            for _, f in ipairs({ 0.4, 0.25, 0.12, 0 }) do
                if inPoly(x, y, poly) then break end
                x, y = z.x + math.cos(a) * r * f / 0.55, z.y + math.sin(a) * r * f / 0.55
            end
        end
        out[#out + 1] = { x = x, y = y, z = z.z }
    end
    return out
end
function Tr.Board(b)
    local rows, cps = {}, {}
    for gid, s in pairs(b.score) do local d = gdef(gid) rows[#rows + 1] = { id = gid, label = d.label, color = d.color, pts = s, kills = b.kills[gid] or 0 } end
    table.sort(rows, function(x, y) return x.pts > y.pts end)
    for _, c in ipairs(b.cps) do
        local pr, by = 0, nil
        for gid, v in pairs(c.prog) do if v > pr then pr, by = v, gid end end
        cps[#cps + 1] = { x = c.x, y = c.y, z = c.z, color = c.holder and gdef(c.holder).color or '#dfe2e7', by = by and gdef(by).color or nil, p = pr / b.secs }
    end
    return { on = true, zone = b.label, zid = b.zone, dur = math.max(1, b.ends - b.started), owner = b.owner and gdef(b.owner).label or nil, x = b.x, y = b.y, r = b.r, ends = b.ends, left = math.max(0, b.ends - nowS()), target = b.target, rows = rows, cps = cps }
end
local function watchers(b)
    local out, seen = {}, {}
    for s in pairs(G.Players()) do
        local g = gangOf(s)
        if (g and (b.score[g.id] or g.id == b.owner)) or dist2(s, b.x, b.y) <= b.r + 80 then out[#out + 1] = s end
    end
    return out
end
local function pushBattle(b, off)
    TriggerClientEvent('pb:g:terr:bat', -1, PB.Json(off and { on = false, zid = b.zone } or Tr.Board(b)))
end
Tr.Watchers = watchers
local function addScore(b, gid, n)
    b.score[gid] = (b.score[gid] or 0) + n
end
-- prise effective de la zone par un gang (fin de bataille gagnée)
function Tr.Take(z, gid, srcOrNil, by)
    local owner = Tr.Owner(z.id)
    DB.exec('REPLACE INTO pb_territories (zone, gang, since, lastcap) VALUES (?, ?, ?, ?)', { z.id, gid, nowS(), nowS() })
    DB.exec('REPLACE INTO pb_terr_reward (zone, last) VALUES (?, ?)', { z.id, nowS() })
    PB.Audit.Log('serveur', 'territory.capture', srcOrNil or 'bataille', z.id, owner, gid, { by = by or 'bataille' })
    TriggerEvent('pb_panel:territoryTaken', srcOrNil or 0, z.id, gid)
    Tr.Push()
    TriggerClientEvent('pb:g:zone:banner', -1, PB.Json({ title = 'Zone capturée', sub = gdef(gid).label, zone = z.label, color = gdef(gid).color }))
end
-- Une bataille est sauvegardée en base toutes les 10 s : un redémarrage ne l'interrompt pas (le temps d'arrêt n'est pas décompté).
local function saveBattle(b)
    DB.exec('REPLACE INTO pb_terr_battles (zone, data, saved) VALUES (?, ?, ?)', { b.zone, PB.Json(b), nowS() })
end
local function recordHistory(b, why, winner)
    local sc = {}
    for gid, v in pairs(b.score) do sc[#sc + 1] = { gang = gid, label = gdef(gid).label, pts = v, kills = b.kills[gid] or 0 } end
    table.sort(sc, function(x, y) return x.pts > y.pts end)
    DB.exec('INSERT INTO pb_terr_history (zone, label, started, ended, attacker, owner, winner, why, scores) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { b.zone, b.label, b.started, nowS(), b.attacker or '', b.owner or '', winner or '', tostring(why or ''):sub(1, 120), PB.Json(sc) })
    DB.exec('DELETE FROM pb_terr_history WHERE ended < ?', { nowS() - 180 * 86400 })
end
function Tr.History(n)
    return DB.q('SELECT id, zone, label, started, ended, attacker, owner, winner, why, scores FROM pb_terr_history ORDER BY id DESC LIMIT ?', { n or 80 }) or {}
end
local function endBattle(b, why, winner)
    battles[b.zone] = nil
    DB.exec('DELETE FROM pb_terr_battles WHERE zone = ?', { b.zone })
    recordHistory(b, why, winner)
    pushBattle(b, true)
    local z = zone(b.zone)
    if winner and z then
        Tr.Take(z, winner, nil, why)
        PB.Announce(('FIN DE LA GUERRE : %s remporte %s ! Les tirs y sont désormais interdits, sauf pour ce gang.'):format(gdef(winner).label, b.label), 'all')
        tellGang(winner, 'success', ('%s est à vous.'):format(b.label))
        if b.owner and b.owner ~= winner then tellGang(b.owner, 'error', ('%s est perdue.'):format(b.label)) end
    else
        cool[b.zone] = nowS() + bnum('bat_rest', 10) * 60
        PB.Announce(b.owner and ('FIN DE LA GUERRE : %s garde %s (%s).'):format(gdef(b.owner).label, b.label, why) or ('FIN DE LA GUERRE sur %s : aucun vainqueur (%s).'):format(b.label, why), 'all')
        for gid in pairs(b.score) do tellGang(gid, 'info', ('Bataille de %s terminée : %s'):format(b.label, why)) end
        if b.owner then tellGang(b.owner, 'success', ('%s : défense réussie (%s).'):format(b.label, why)) end
    end
end
function Tr.Battle(zid) return battles[tostring(zid)] end
-- bataille en cours dans la zone où se trouve ce joueur (nil sinon) : sert à bloquer l'appel des secours
function Tr.WarAt(src)
    for zid, b in pairs(battles) do
        local z = zone(zid)
        if z and inZone(src, z, 5) then return b end
    end
    local w = G.Wars and G.Wars.cur
    local z = w and zone(w.zone)
    if z and inZone(src, z, 15) then return w end
    return nil
end
function Tr.Abort(zid, why) local b = battles[tostring(zid)] if b then endBattle(b, why or 'annulée par le staff') return true end return false end

-- annonces : ouverture, fermeture et préavis des fenêtres de prise (une fois par fenêtre et par zone)
local wstate = {}
function Tr.WindowTick()
    if not cfg('enabled', true) or not bon() or cfg('bat_hours_on', true) == false then return end
    local t = nowS()
    local warn = bnum('bat_warn', 15) * 60
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local open, ref = Tr.WindowState(z, t)
        local st = wstate[z.id]
        if st == nil then wstate[z.id] = { open = open } st = wstate[z.id] else
            if open and not st.open then
                PB.Announce(('Territoire %s : la prise est OUVERTE jusqu\'à %s. Gangs, c\'est le moment !'):format(z.label, Tr.LocalFmt(ref, '%Hh%M')), 'all')
                st.warned = nil
            elseif not open and st.open then
                PB.Announce(('Territoire %s : la fenêtre de prise est terminée.'):format(z.label), 'all')
            end
            st.open = open
        end
        if not open and ref and ref - t <= warn and st.warned ~= ref then
            st.warned = ref
            local msg = ('%s : la prise ouvre dans %d min.'):format(z.label, math.max(1, math.ceil((ref - t) / 60)))
            for s in pairs(G.Players()) do if gangOf(s) then G.Notify(s, { type = 'warn', title = 'Territoire', text = msg }) end end
        end
    end
end
CreateThread(function()
    Wait(15000)
    while true do
        local ok, e = pcall(Tr.WindowTick)
        if not ok then PB.Warn('territoires', tostring(e)) end
        Wait(30000)
    end
end)

-- une seconde de bataille
function Tr.BattleTick()
    local t = nowS()
    for zid, b in pairs(battles) do
        local z = zone(zid)
        if not z or not bon() then endBattle(b, 'zone retirée') else
            b.n = b.n + 1
            -- qui est sur quel point
            local at, hereAny = {}, false
            for s in pairs(G.Players()) do
                local g = gangOf(s)
                if g and usable(s) then
                    if inZone(s, z, 5) then
                        if g.id ~= b.owner then hereAny = true end
                        if not b.score[g.id] then b.score[g.id] = 0 end
                    end
                    for i, c in ipairs(b.cps) do
                        if dist2(s, c.x, c.y) <= b.cpr then at[i] = at[i] or {} at[i][g.id] = (at[i][g.id] or 0) + 1 end
                    end
                end
            end
            for i, c in ipairs(b.cps) do
                local who, n = nil, 0
                for gid in pairs(at[i] or {}) do n = n + 1 who = gid end
                if n == 1 then
                    if who ~= c.holder then
                        for gid in pairs(c.prog) do if gid ~= who then c.prog[gid] = nil end end
                        c.prog[who] = (c.prog[who] or 0) + 1
                        if c.prog[who] >= b.secs then
                            local prev = c.holder
                            c.holder, c.prog = who, {}
                            tellGang(who, 'success', ('Point %d de %s pris.'):format(i, b.label))
                            if prev then tellGang(prev, 'warn', ('Point %d de %s perdu !'):format(i, b.label)) end
                        end
                    else c.prog = {} end
                elseif n == 0 then
                    for gid in pairs(c.prog) do c.prog[gid] = math.max(0, c.prog[gid] - 1) if c.prog[gid] == 0 then c.prog[gid] = nil end end   -- le point se « refroidit »
                end   -- n >= 2 : contesté, rien ne bouge
            end
            if b.n % 5 == 0 then
                for _, c in ipairs(b.cps) do if c.holder then addScore(b, c.holder, bnum('bat_hold', 1)) end end
            end
            -- abandon : plus aucun attaquant sur place depuis trop longtemps
            if hereAny then b.idle = 0 else b.idle = b.idle + 1 end
            local top, topS, second = nil, -1, -1
            for gid, s in pairs(b.score) do
                if s > topS then second = topS top, topS = gid, s elseif s > second then second = s end
            end
            if top and topS >= b.target then endBattle(b, 'score atteint', top)
            elseif b.idle >= bnum('bat_idle', 180) then endBattle(b, "les attaquants sont partis")
            elseif t >= b.ends then
                if top and top ~= b.owner and topS > (b.score[b.owner or ''] or 0) and topS > 0 then endBattle(b, 'temps écoulé', top)
                else endBattle(b, 'temps écoulé, pas de vainqueur') end
            else
                if b.n % 3 == 0 then pushBattle(b) end
                if b.n % 10 == 0 then saveBattle(b) end
            end
        end
    end
end
CreateThread(function()
    while true do
        Wait(1000)
        local any = false
        for _ in pairs(battles) do any = true break end
        if any then local ok, e = pcall(Tr.BattleTick) if not ok then PB.Warn('territoires', tostring(e)) end end
    end
end)
table.insert(G.beginHooks, function(src) for _, b in pairs(battles) do pushBattle(b) end end)
-- reprise après un redémarrage : on recharge les batailles sauvegardées et on décale leur fin du temps d'arrêt
function Tr.Restore()
    local t = nowS()
    for _, r in ipairs(DB.q('SELECT zone, data, saved FROM pb_terr_battles') or {}) do
        local b = PB.FromJson(r.data, nil)
        local z = b and zone(r.zone)
        if z and type(b.score) == 'table' and type(b.cps) == 'table' and not battles[r.zone] then
            local down = math.max(0, t - (tonumber(r.saved) or t))
            b.ends = (tonumber(b.ends) or t) + down
            b.idle, b.kills, b.n = 0, type(b.kills) == 'table' and b.kills or {}, tonumber(b.n) or 0
            for _, c in ipairs(b.cps) do c.prog = type(c.prog) == 'table' and c.prog or {} end
            battles[r.zone] = b
        else DB.exec('DELETE FROM pb_terr_battles WHERE zone = ?', { r.zone }) end
    end
    return next(battles) ~= nil
end
PB.OnReady(function() local ok, e = pcall(Tr.Restore) if not ok then PB.Warn('territoires', 'reprise des batailles : ' .. tostring(e)) end end)

-- éliminations : un rival tué dans la zone rapporte du score (annonce vérifiée : tueur connecté, à moins de 400 m, pas de farm de la même paire)
local lastKill = {}
AddEventHandler('pb_panel:killReport', function(victim, killer, weapon)
    killer = math.floor(tonumber(killer) or 0)
    if not next(battles) or killer <= 0 or killer == victim or not G.Get(killer) or not G.Get(victim) then return end
    local kg, vg = gangOf(killer), gangOf(victim)
    if not kg or not vg or kg.id == vg.id then return end
    local vped = GetPlayerPed(victim)
    if not vped or vped == 0 then return end
    local vc = GetEntityCoords(vped)
    if G.DistTo(killer, vc.x, vc.y, vc.z) > 400 then return end
    local key, t = killer .. ':' .. victim, nowS()
    if lastKill[key] and t - lastKill[key] < 120 then return end
    lastKill[key] = t
    for zid, b in pairs(battles) do
        local z = zone(zid)
        if z and inZone(victim, z, 5) then
            addScore(b, kg.id, math.floor(bnum('bat_kill', 5)))
            b.kills[kg.id] = (b.kills[kg.id] or 0) + 1
        end
    end
end)
AddEventHandler('pb_panel:playerDied', function(src)
    local b = Tr.WarAt(src)
    if b then G.Notify(src, { type = 'warn', title = 'Zone en guerre', text = "Pas de secours pendant une guerre de territoire : attends la fin ou réapparais à l'hôpital.", duration = 9000 }) end
end)

local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if last[src] and t - last[src] < ms then return false end last[src] = t return true end

-- Police et staff peuvent tirer partout (réglable) : le blocage des tirs ne les concerne pas.
function Tr.Exempt(src)
    if cfg('peace_police', true) ~= false then
        local c = G.Biz and G.Biz.Ctx and G.Biz.Ctx(src)
        if c and c.biz and c.biz.kind == 'police' then return true end
    end
    if cfg('peace_staff', true) ~= false and PB.Perm.Has(src, 'staff.menu') then return true end
    return false
end
function Tr.Push(src)
    local gs = src and { [src] = true } or G.Players()
    local owners = PB.Json(Tr.Owners())
    for s in pairs(gs) do
        local g = gangOf(s)
        TriggerClientEvent('pb:g:terr:owners', s, PB.Json({ owners = Tr.Owners(), me = g and g.id or nil, peace = cfg('peace_on', true) ~= false, exempt = Tr.Exempt(s), staff = PB.Perm.Has(s, 'territories.edit') }))
    end
end
table.insert(G.beginHooks, function(src) Tr.Push(src) end)
AddEventHandler('pb_panel:jobChanged', function(src) src = tonumber(src) if src and G.Players()[src] then Tr.Push(src) end end)

function Tr.Start(src, id)
    if not cfg('enabled', true) then return false, 'Territoires désactivés.' end
    if not bon() then return false, 'Les batailles de zone sont désactivées.' end
    local z = zone(id)
    if not z then return false, 'Zone inconnue.' end
    local g = gangOf(src)
    if not g then return false, "Tu n'appartiens à aucun gang." end
    if not inZone(src, z) then return false, 'Tu es hors de la zone.' end
    local owner, row = Tr.Owner(z.id)
    if owner == g.id then return false, 'Ton gang tient déjà cette zone.' end
    if battles[z.id] then return false, 'Une bataille est déjà en cours ici : rejoins-la et prends les points.' end
    if G.Wars and G.Wars.cur and G.Wars.cur.zone == z.id then return false, 'Une guerre de territoire est déjà en cours ici : marque des points dans la zone.' end
    local lastcap = row and tonumber(row.lastcap) or 0
    if lastcap + (tonumber(z.cooldown) or 60) * 60 > nowS() then return false, ('Zone protégée encore %d min.'):format(math.ceil((lastcap + z.cooldown * 60 - nowS()) / 60)) end
    if cool[z.id] and cool[z.id] > nowS() then return false, ('Zone au repos après une bataille : encore %d min.'):format(math.ceil((cool[z.id] - nowS()) / 60)) end
    local open, wend, nextTxt = Tr.WindowState(z)
    if not open then return false, nextTxt and ('Zone fermée à la prise. Prochaine fenêtre : %s.'):format(nextTxt) or 'Aucune fenêtre de prise programmée.' end
    local n = 0 for _ in pairs(battles) do n = n + 1 end
    if n >= bnum('bat_max', 2) then return false, 'Trop de batailles en cours en ville. Réessaie plus tard.' end
    local here = gangsInZone(z)
    if (here[g.id] or 0) < (tonumber(z.min) or 1) then return false, ('Il faut au moins %d membre(s) de ton gang dans la zone.'):format(z.min) end
    local t = nowS()
    local head = math.min(bnum('bat_head', 20), math.floor(Tr.Influence(z.id, g.id) / 5))     -- avance : 5 points d'influence = 1 point de score
    local cps = {}
    for _, c in ipairs(Tr.ControlPoints(z)) do cps[#cps + 1] = { x = c.x, y = c.y, z = c.z, holder = owner, prog = {} } end
    local b = { zone = z.id, label = z.label, x = z.x, y = z.y, z = z.z, r = tonumber(z.radius) or 30, owner = owner, started = t, ends = math.min(t + math.max(2, bnum('bat_duration', 15)) * 60, math.max(t + 120, wend)),
        target = math.max(10, math.floor(bnum('bat_target', 100))), secs = math.max(3, math.floor(bnum('bat_secs', 20))), cpr = bnum('bat_cp_radius', 6),
        score = { [g.id] = head }, kills = {}, cps = cps, n = 0, idle = 0, attacker = g.id }
    if owner then b.score[owner] = 0 end
    battles[z.id] = b
    saveBattle(b)
    PB.Audit.Log('serveur', 'territory.battle', src, z.id, owner, g.id, { head = head })
    if owner then tellGang(owner, 'error', ('%s attaque %s ! Défendez vos points.'):format(g.label, z.label)) end
    PB.Announce(('GUERRE DE TERRITOIRE : %s attaque %s ! Appel des secours coupé dans la zone, tirs autorisés.'):format(g.label, z.label), 'all')
    TriggerClientEvent('pb:g:zone:banner', -1, PB.Json({ title = 'Bataille de zone', sub = g.label .. ' attaque', zone = z.label, color = gdef(g.id).color }))
    pushBattle(b)
    return true, ('Bataille lancée sur %s : tenez les points seuls, éliminez les rivaux (%d points pour gagner).'):format(z.label, b.target)
end
function Tr.Release(id) DB.exec('DELETE FROM pb_territories WHERE zone = ?', { tostring(id) }) Tr.Push() end

-- (v1.2.45) objets proposés au Builder pour la récompense : tous les objets de l'inventaire, y compris les objets personnalisés
-- ({ nom technique, nom simplifié, catégorie, description }, comme « Donner un objet » du staff)
function Tr.RewardChoices()
    if G.Staff and G.Staff.ItemList then return G.Staff.ItemList() end
    local out = {}
    for name, d in pairs(G.Inv and G.Inv.Defs and G.Inv.Defs() or {}) do out[#out + 1] = { name, tostring(d.label or name), 'Objets', '' } end
    table.sort(out, function(a, b) return a[2]:lower() < b[2]:lower() end)
    return out
end
local function rewardOk(item) return item == '' or (G.Inv and G.Inv.Def and G.Inv.Def(item) ~= nil) end
-- objet offert d'une zone existante (Builder › Existant › Territoires)
function Tr.SetReward(src, id, item, qty, hours)
    item = tostring(item or ''):lower()
    if not rewardOk(item) then return false, 'Objet inconnu.' end
    local zones, found = {}, nil
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local c = PB.DeepCopy(z)
        if c.id == id then
            c.reward_item = item
            c.reward_qty = math.max(1, math.min(50, math.floor(tonumber(qty) or 1)))
            c.reward_hours = math.max(1, math.min(168, math.floor(tonumber(hours) or 5)))
            found = c
        end
        zones[#zones + 1] = c
    end
    if not found then return false, 'Zone introuvable.' end
    PB.Cfg.Set('territories', 'zones', zones, src, 'Builder : objet offert par ' .. tostring(found.label))
    if item == '' then return true, found.label .. ' : plus aucun objet offert.' end
    local d = G.Inv.Def(item)
    return true, ('%s : %d × %s toutes les %d h.'):format(found.label, found.reward_qty, d and d.label or item, found.reward_hours)
end
-- Création d'une zone dessinée au Builder : coins posés un par un (3 à 40), objet offert toutes les 5 h au groupe qui la tient
function Tr.CreateDrawn(src, label, poly, item, qty, hours)
    label = tostring(label or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    if #label < 2 then return false, 'Donne un nom à la zone.' end
    if type(poly) ~= 'table' or #poly < 3 or #poly > 40 then return false, 'Il faut entre 3 et 40 coins.' end
    local pts, sx, sy, sz = {}, 0, 0, 0
    for _, p in ipairs(poly) do
        local x, y, z = tonumber(type(p) == 'table' and (p.x or p[1]) or nil), tonumber(type(p) == 'table' and (p.y or p[2]) or nil), tonumber(type(p) == 'table' and (p.z or p[3]) or 0)
        if not x or not y or math.abs(x) > 10000 or math.abs(y) > 10000 then return false, 'Coin invalide.' end
        if G.DistTo(src, x, y, z or 0) > 1500 then return false, 'Un coin est trop loin de toi.' end
        pts[#pts + 1] = { math.floor(x * 10 + 0.5) / 10, math.floor(y * 10 + 0.5) / 10, math.floor((z or 0) * 10 + 0.5) / 10 }
        sx, sy, sz = sx + x, sy + y, sz + (z or 0)
    end
    local cx, cy, cz = sx / #pts, sy / #pts, sz / #pts
    local r = 0
    for _, p in ipairs(pts) do r = math.max(r, math.sqrt((p[1] - cx) ^ 2 + (p[2] - cy) ^ 2)) end
    if r < 8 then return false, 'Zone trop petite.' end
    item = tostring(item or ''):lower()
    if not rewardOk(item) then return false, 'Objet de récompense inconnu.' end
    local zones = {}
    for _, z in ipairs(cfg('zones', {}) or {}) do zones[#zones + 1] = z end
    local base = label:lower():gsub('[^%w]+', '_'):gsub('^_+', ''):gsub('_+$', ''):sub(1, 18)
    if base == '' then base = 'zone' end
    local id, n = base, 1
    local function taken(x) for _, z in ipairs(zones) do if z.id == x then return true end end return false end
    while taken(id) do n = n + 1 id = base .. '_' .. n end
    zones[#zones + 1] = { id = id, label = label, x = math.floor(cx * 10) / 10, y = math.floor(cy * 10) / 10, z = math.floor(cz * 10) / 10, radius = math.floor(r + 0.5),
        income = 300, time = 90, cooldown = 60, min = 1, reward_item = item, reward_qty = math.max(1, math.min(50, math.floor(tonumber(qty) or 1))),
        reward_hours = math.max(1, math.min(168, math.floor(tonumber(hours) or tonumber(cfg('reward_hours_default', 5)) or 5))) }
    local polys = {}
    for k, v in pairs(cfg('polys', {}) or {}) do polys[k] = v end
    polys[id] = pts
    PB.Cfg.Set('territories', 'polys', polys, src, 'Builder : zone ' .. label)
    PB.Cfg.Set('territories', 'zones', zones, src, 'Builder : zone ' .. label)
    PB.Audit.Log('config', 'territory.create', src, id, nil, { corners = #pts, item = item })
    G.PushConfig()
    Tr.Push()
    local d = item ~= '' and G.Inv.Def(item)
    return true, ('Zone « %s » créée (%d coins)%s.'):format(label, #pts, d and (' : ' .. d.label .. ' toutes les 5 h au groupe qui la tient') or '')
end
function Tr.Delete(id)
    local zones, found = {}, false
    for _, z in ipairs(cfg('zones', {}) or {}) do if z.id ~= id then zones[#zones + 1] = z else found = true end end
    if not found then return false end
    local polys = {}
    for k, v in pairs(cfg('polys', {}) or {}) do if k ~= id then polys[k] = v end end
    PB.Cfg.Set('territories', 'zones', zones, 0, 'Zone supprimée')
    PB.Cfg.Set('territories', 'polys', polys, 0, 'Zone supprimée')
    DB.exec('DELETE FROM pb_territories WHERE zone = ?', { id })
    G.PushConfig()
    Tr.Push()
    return true
end

RegisterNetEvent('pb:g:terr:start', function(id)
    local src = source
    if not usable(src) or not throttle(src, 800) then return end
    local ok, msg = Tr.Start(src, tostring(id))
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Territoire', text = msg })
end)

-- Revenus : à intervalle fixe, la somme de la zone est partagée entre les membres connectés du gang propriétaire
function Tr.PayOut()
    local n = 0
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local owner = Tr.Owner(z.id)
        if owner and (tonumber(z.income) or 0) > 0 then
            local members = {}
            for s in pairs(G.Players()) do local g = gangOf(s) if g and g.id == owner and usable(s) then members[#members + 1] = s end end
            if #members > 0 then
                local inc = G.Eco and G.Eco.Income and G.Eco.Income(z.income, 'illegal') or z.income   -- onglet Économie
                local share = math.floor(inc / #members)
                for _, s in ipairs(members) do if share > 0 then G.AddMoney(s, 'cash', share, 'Revenus du territoire ' .. z.label) G.Notify(s, { type = 'success', title = z.label, text = ('+%s de revenus de territoire.'):format(PB.Money(share)) }) n = n + share end end
            end
        end
    end
    return n
end
-- Récompenses : un objet déposé dans le coffre de l'organisation propriétaire, toutes les N heures (une seule remise même si le serveur a été éteint longtemps)
function Tr.RewardOf(z)
    local item = tostring(z.reward_item or '')
    if item == '' then return nil end
    return { item = item, qty = math.max(1, math.min(50, math.floor(tonumber(z.reward_qty) or 1))), hours = math.max(1, math.min(168, tonumber(z.reward_hours) or 10)) }
end
function Tr.RewardLast(z, row)
    local r = DB.scalar('SELECT last FROM pb_terr_reward WHERE zone = ?', { z.id })
    return tonumber(r) or (row and tonumber(row.since)) or nowS()
end
function Tr.NextReward(z)
    local rw = Tr.RewardOf(z); if not rw then return nil end
    local owner, row = Tr.Owner(z.id); if not owner then return nil end
    return math.max(0, Tr.RewardLast(z, row) + rw.hours * 3600 - nowS())
end
function Tr.RewardTick()
    local given = 0
    for _, z in ipairs(cfg('zones', {}) or {}) do
        local rw = Tr.RewardOf(z)
        local owner, row = Tr.Owner(z.id)
        if rw and owner and Tr.RewardLast(z, row) + rw.hours * 3600 <= nowS() then
            local o = 'o:' .. owner
            if G.Inv and G.Inv.Def(rw.item) and select(1, G.Inv.CanCarry(o, rw.item, rw.qty)) and G.Inv.Add(o, rw.item, rw.qty) then
                DB.exec('REPLACE INTO pb_terr_reward (zone, last) VALUES (?, ?)', { z.id, nowS() })
                PB.Audit.Log('serveur', 'territory.reward', 0, z.id, owner, rw.item, rw.qty)
                if G.Inv.PushOwners then G.Inv.PushOwners(o) end
                for s in pairs(G.Players()) do
                    local g = gangOf(s)
                    if g and g.id == owner then G.Notify(s, { type = 'success', title = z.label, text = ('%d× %s livré(s) dans le coffre de l\'organisation.'):format(rw.qty, (G.Inv.Def(rw.item) or {}).label or rw.item) }) end
                end
                given = given + 1
            end
        end
    end
    return given
end
CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        if cfg('enabled', true) then Tr.RewardTick() end
    end
end)
CreateThread(function()
    while true do
        Wait(math.max(5, tonumber(cfg('income_min', 30)) or 30) * 60000)
        if cfg('enabled', true) then Tr.PayOut() end
    end
end)
PB.Cfg.OnChange('territories', function() Tr.Push() end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------------
local settings = Form.Cfg({ ns = 'territories', id = 'settings', title = 'Territoires', perm = 'territories.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Territoires actifs', default = true },
    { k = 'income_min', type = 'number', label = 'Intervalle des revenus (minutes)', default = 30, min = 5, max = 1440 },
    { k = 'show_blips', type = 'toggle', label = 'Zones visibles sur la carte (couleur du gang propriétaire)', default = true },
    { k = 'show_all', type = 'toggle', label = "Zones visibles par tous les joueurs (sinon : membres d'un gang et staff)", default = true },
    { k = 'bat_on', type = 'toggle', label = 'Batailles de zone actives (sinon aucune prise possible)', default = true },
    { k = 'bat_tz', type = 'select', label = 'Fuseau des horaires (heure réelle)', default = 'paris', opts = { { 'paris', 'Paris (heure réelle, heure d\'été automatique)' }, { 'utc', 'UTC' }, { 'machine', 'Horloge de la machine du serveur' } } },
    { k = 'peace_on', type = 'toggle', label = 'Tirs interdits dans une zone possédée (sauf son gang) hors guerre', default = true },
    { k = 'peace_police', type = 'toggle', label = 'La police peut toujours tirer dans les zones', default = true },
    { k = 'peace_staff', type = 'toggle', label = 'Le staff peut toujours tirer dans les zones', default = true },
    { k = 'bat_hours_on', type = 'toggle', label = 'Prise possible seulement pendant les fenêtres horaires', default = true },
    { k = 'bat_hours', type = 'list', label = 'Fenêtres de prise (jour|HH:MM-HH:MM, jour = lun…dim ou tous)', default = { 'ven|20:00-23:00', 'sam|20:00-23:00', 'dim|20:00-23:00' }, maxitems = 30, maxlen = 24, wide = true, hint = "Heure réelle (fuseau ci-dessus). Une zone peut avoir ses propres horaires dans l'onglet Zones." },
    { k = 'bat_warn', type = 'number', label = "Préavis avant l'ouverture (minutes)", default = 15, min = 0, max = 120 },
    { k = 'bat_target', type = 'number', label = 'Score pour gagner la bataille', default = 100, min = 10, max = 10000 },
    { k = 'bat_duration', type = 'number', label = 'Durée maximale (minutes)', default = 15, min = 2, max = 120 },
    { k = 'bat_cps', type = 'number', label = 'Points de contrôle par zone (défaut)', default = 3, min = 1, max = 6 },
    { k = 'bat_secs', type = 'number', label = "Secondes à tenir un point seul pour le prendre", default = 20, min = 3, max = 300 },
    { k = 'bat_cp_radius', type = 'number', label = "Rayon d'un point de contrôle (m)", default = 6, min = 2, max = 30, int = false },
    { k = 'bat_hold', type = 'number', label = 'Score par point tenu, toutes les 5 s', default = 1, min = 0, max = 100 },
    { k = 'bat_kill', type = 'number', label = "Score par élimination d'un rival dans la zone", default = 5, min = 0, max = 100 },
    { k = 'bat_head', type = 'number', label = "Avance maximale donnée par l'influence (graffitis)", default = 20, min = 0, max = 100 },
    { k = 'bat_rest', type = 'number', label = 'Repos de la zone après une bataille sans vainqueur (min)', default = 10, min = 0, max = 1440 },
    { k = 'bat_max', type = 'number', label = 'Batailles simultanées en ville', default = 2, min = 1, max = 20 },
    { k = 'bat_idle', type = 'number', label = "Abandon si aucun attaquant sur place (s)", default = 180, min = 30, max = 1800 },
} })
-- (v1.2.45) objet offert : liste de tous les objets de l'inventaire (objets personnalisés compris), rafraîchie à l'ouverture de l'onglet
local REWARD_COL = { k = 'reward_item', label = 'Objet offert', type = 'select', opts = { { '', 'Aucun objet' } } }
local function rewardOpts()
    local o = { { '', 'Aucun objet' } }
    for _, it in ipairs(Tr.RewardChoices()) do o[#o + 1] = { it[1], it[2] .. ' (' .. it[1] .. ')' } end
    -- une zone qui offre un objet supprimé depuis : on le garde dans la liste pour pouvoir enregistrer
    local have = {}
    for _, x in ipairs(o) do have[x[1]] = true end
    for _, z in ipairs(cfg('zones', {}) or {}) do local n = tostring(z.reward_item or '') if not have[n] then have[n] = true o[#o + 1] = { n, n .. ' (objet introuvable)' } end end
    REWARD_COL.opts = o
end
PB.OnReady(function() pcall(rewardOpts) end)
local zonesForm = Form.Cfg({ ns = 'territories', id = 'zones', title = 'Zones', perm = 'territories.edit', fields = {
    { k = 'zones', type = 'rows', label = 'Zones à prendre', default = ZONES, wide = true, maxitems = 40, unique = 'id',
      hint = "Revenu = somme versée à chaque intervalle, partagée entre les membres connectés du gang propriétaire. Durée = secondes à rester dans la zone. Protection = minutes pendant lesquelles on ne peut pas la reprendre. Membres = nombre minimal de ton gang dans la zone.",
      cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 24, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
        { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false },
        { k = 'radius', label = 'Rayon', type = 'number', min = 5, max = 300 }, { k = 'income', label = 'Revenu', type = 'number', min = 0, max = 1000000 }, { k = 'time', label = 'Durée (s)', type = 'number', min = 5, max = 1800 },
        { k = 'cooldown', label = 'Protection (min)', type = 'number', min = 0, max = 10080 }, { k = 'min', label = 'Membres', type = 'number', min = 1, max = 30 }, { k = 'cps', label = 'Points', type = 'number', min = 0, max = 6 }, { k = 'hours', label = 'Horaires propres (ven|20:00-23:00;sam|…)', maxlen = 120 }, REWARD_COL, { k = 'reward_qty', label = 'Quantité', type = 'number', min = 1, max = 50 }, { k = 'reward_hours', label = 'Toutes les (h)', type = 'number', min = 1, max = 168 } } } } })
PB.Module({
    id = 'territories', label = 'Zones de gangs', icon = 'flag', group = 'Serveur', order = 146, perm = 'territories.edit', hint = 'Zones de gangs, revenus',
    caps = function() return PB.Capsify({
        { 'Bataille de zone', 'ok', 'Attaque avec E : points de contrôle à tenir seul, score par point tenu et par élimination, premier au score cible ou meilleur score au temps. Avance donnée par les graffitis.' },
        { 'Revenus', 'ok', 'Versés aux membres connectés du gang propriétaire, partagés à parts égales.' },
        { 'Gangs', 'ok', 'Gangs natifs (Gamertags) ou lus depuis une autre ressource (voir Gamertags › Source des gangs).' },
        { 'Guerre de gangs avec points de contrôle multiples', 'off', 'Une seule zone circulaire à la fois ; pas de score ni de saisons.' },
    }) end,
    doc = "## Territoires\nChaque zone a un rayon, un revenu et une durée de capture. Un joueur de gang appuie sur **E** dans la zone et reste sur place ; si un membre du gang propriétaire est encore dans la zone, la capture échoue.",
    view = function(ctx) return { tabs = {
        { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
        { id = 'zones', label = 'Zones', icon = 'map', build = function() pcall(rewardOpts) return { zonesForm(ctx) } end },
        { id = 'owners', label = 'Propriétaires', icon = 'users', build = function()
            local rows = {}
            for _, z in ipairs(cfg('zones', {}) or {}) do
                local gid, r = Tr.Owner(z.id)
                rows[#rows + 1] = { id = z.id, zone = z.label, gang = gid or '—', since = r and r.since or 0, actions = (gid and ctx.has('territories.edit')) and { { action = 'territories.release', label = 'Libérer', payload = { id = z.id }, confirm = 'Libérer cette zone ?' } } or nil }
            end
            return { B.table({ id = 'own', title = 'Qui tient quoi', columns = { { k = 'zone', label = 'Zone' }, { k = 'gang', label = 'Gang', type = 'badge' }, { k = 'since', label = 'Depuis', type = 'date' } }, rows = rows, empty = 'Aucune zone.' }) }
        end },
        { id = 'battles', label = 'Batailles', icon = 'flag', build = function()
            local rows = {}
            for zid, b in pairs(battles) do
                local sc = {}
                for _, r in ipairs(Tr.Board(b).rows) do sc[#sc + 1] = r.label .. ' ' .. r.pts end
                rows[#rows + 1] = { id = zid, zone = b.label, score = table.concat(sc, ' · '), left = ('%d min'):format(math.ceil(math.max(0, b.ends - nowS()) / 60)),
                    actions = ctx.has('territories.edit') and { { action = 'territories.bat.stop', label = 'Arrêter', icon = 'trash', payload = { id = zid }, confirm = 'Arrêter cette bataille sans vainqueur ?' } } or nil }
            end
            local wl = {} for _, w in ipairs(Tr.Windows(nil)) do wl[#wl + 1] = w.label end
            return { B.notice('info', cfg('bat_hours_on', true) == false and 'Fenêtres horaires désactivées : prise possible à toute heure.' or ('Fenêtres de prise : ' .. (#wl > 0 and table.concat(wl, ' · ') or 'aucune') .. '.')), B.notice('info', "Un gang attaque avec E dans la zone : des points de contrôle apparaissent, on les prend en restant seul dessus, chaque point tenu et chaque élimination rapporte du score. Premier au score cible = zone prise."),
                B.table({ id = 'bat', title = 'Batailles en cours', columns = { { k = 'zone', label = 'Zone' }, { k = 'score', label = 'Score' }, { k = 'left', label = 'Reste' } }, rows = rows, empty = 'Aucune bataille en cours.' }) }
        end },
        { id = 'history', label = 'Historique', icon = 'clock', build = function()
            local rows = {}
            for _, r in ipairs(Tr.History(100)) do
                local sc = PB.FromJson(r.scores, {}) or {}
                local parts = {}
                for _, x in ipairs(sc) do parts[#parts + 1] = ('%s %d'):format(x.label, x.pts) end
                rows[#rows + 1] = { at = r.ended, zone = r.label, attacker = r.attacker ~= '' and gdef(r.attacker).label or '—', owner = r.owner ~= '' and gdef(r.owner).label or 'libre',
                    winner = r.winner ~= '' and gdef(r.winner).label or 'personne', mins = math.max(1, math.floor((r.ended - r.started) / 60)), why = r.why, score = table.concat(parts, ' · ') }
            end
            return { B.notice('info', 'Les 180 derniers jours de guerres : qui attaquait, qui défendait, qui a gagné et les scores finaux.'),
                B.table({ id = 'thist', title = 'Historique des guerres', search = true, columns = { { k = 'at', label = 'Fin', type = 'date' }, { k = 'zone', label = 'Zone' }, { k = 'attacker', label = 'Attaquant' }, { k = 'owner', label = 'Défenseur' },
                    { k = 'winner', label = 'Vainqueur', type = 'badge' }, { k = 'mins', label = 'Durée (min)' }, { k = 'score', label = 'Scores' }, { k = 'why', label = 'Fin' } }, rows = rows, empty = 'Aucune guerre pour le moment.' }) }
        end },
        { id = 'influence', label = 'Influence', icon = 'flag', build = function()
            local rows = {}
            for _, r in ipairs(Tr.InfluenceRows()) do local z = zone(r.zone) rows[#rows + 1] = { zone = z and z.label or r.zone, gang = r.gang, points = r.points } end
            return { B.notice('info', "L'influence vient des graffitis d'organisation non effacés. 100 points raccourcissent de 40 % la capture de la zone par ce gang."),
                B.table({ id = 'infl', title = 'Influence par zone', columns = { { k = 'zone', label = 'Zone' }, { k = 'gang', label = 'Gang', type = 'badge' }, { k = 'points', label = 'Points' } }, rows = rows }) }
        end },
        { id = 'map', label = 'Carte', icon = 'map', build = function()
            local pts = {}
            for _, z in ipairs(cfg('zones', {}) or {}) do
                local gid = Tr.Owner(z.id)
                local d = gid and G.Tags and G.Tags.GangDefs()[gid]
                pts[#pts + 1] = { id = z.id, x = z.x, y = z.y, r = tonumber(z.radius) or 30, color = d and d.color or '#dfe2e7', label = z.label, sub = gid and (d and d.label or gid) or 'libre' }
            end
            return { { type = 'map', id = 'zmap', title = 'Zones de gangs', points = pts } }
        end },
        { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return {
            { type = 'gpreview', kind = 'territory', title = 'Territoire en jeu', desc = "Le bandeau dans la zone (hors guerre, puis en guerre avec les scores de chaque gang en bas à droite)." },
            { type = 'gpreview', kind = 'announce', title = 'Annonce plein écran (début et fin de guerre)', cfg = { style = 'alert', title = 'Zone en guerre', text = 'FIN DE LA GUERRE : Ballas remporte Grove Street !', secs = 12 } } } end },
    } } end,
})
PB.Action('territories.bat.stop', 'territories.edit', function(ctx, p) local ok = Tr.Abort(p.id) ctx.audit('serveur', 'territory.battle.stop', tostring(p.id or '')) ctx.toast = ok and 'Bataille arrêtée.' or 'Aucune bataille ici.' return true end)
PB.Action('territories.release', 'territories.edit', function(ctx, p) Tr.Release(p.id) ctx.audit('serveur', 'territory.release', tostring(p.id or '')) ctx.toast = 'Zone libérée.' return true end)
PB.SelfTest.Add('territoires', function(R)
    local seen = {}
    for _, z in ipairs(cfg('zones', {}) or {}) do R.check(not seen[z.id], 'zone « ' .. tostring(z.id) .. ' »', 'identifiant en double') seen[z.id] = true end
    R.check(G.Tags ~= nil, 'gangs disponibles', 'le module Gamertags manque')
    R.check(Tr.BattleTick ~= nil and Tr.ControlPoints ~= nil, 'batailles de zone', 'la logique de bataille manque')
    for _, z in ipairs(cfg('zones', {}) or {}) do R.check(#Tr.ControlPoints(z) >= 1, 'points de « ' .. tostring(z.id) .. ' »', 'aucun point de contrôle') end
end)
