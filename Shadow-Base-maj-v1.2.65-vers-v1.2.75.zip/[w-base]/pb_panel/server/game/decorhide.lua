-- Objets du décor retirés (Builder › Existant) : distributeurs, poubelles, barrières… tout objet de la carte qui n'a pas été posé au Builder.
-- La carte reste intacte : chaque joueur masque ces objets de son côté. Le serveur garde la liste, vérifie le droit et la distance.
local G, DB, P = PB.G, PB.DB, PB.Perm
local D = {}
G.DecorHide = D

PB.Migrate('544_decor_hidden', 'Objets du décor retirés', {
    [[CREATE TABLE IF NOT EXISTS pb_decor_hidden (id INT NOT NULL AUTO_INCREMENT, model BIGINT NOT NULL, label VARCHAR(64) NOT NULL DEFAULT '', x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
        by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
})
local MAX, RANGE = 500, 60
local function num(v, lo, hi) v = tonumber(v) if not v or v ~= v then return nil end return math.max(lo, math.min(hi, v)) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

local cache = nil
function D.List()
    if cache then return cache end
    cache = {}
    for _, r in ipairs(DB.q('SELECT id, model, label, x, y, z FROM pb_decor_hidden ORDER BY id') or {}) do
        cache[#cache + 1] = { id = tonumber(r.id), m = tonumber(r.model), l = r.label, x = tonumber(r.x), y = tonumber(r.y), z = tonumber(r.z) }
    end
    return cache
end
local function push(target) TriggerClientEvent('pb:g:decor:all', target or -1, PB.Json(D.List())) end
table.insert(G.beginHooks, function(src) push(src) end)

-- Distributeur retiré : son point de banque au même endroit partirait sinon en laissant un E dans le vide
local function isAtm(model)
    for m in tostring(PB.Cfg.Get('bank', 'atm_models', '') or ''):gmatch('[%w_]+') do
        if (math.floor(GetHashKey(m)) & 0xFFFFFFFF) == (model & 0xFFFFFFFF) then return true end
    end
    return false
end
local function dropAtmPoints(src, x, y, z)
    local n = 0
    for _, r in ipairs(DB.q("SELECT id, label, x, y, z FROM pb_bank_points WHERE kind = 'atm'") or {}) do
        if math.abs(tonumber(r.x) - x) < 3.0 and math.abs(tonumber(r.y) - y) < 3.0 and math.abs(tonumber(r.z) - z) < 3.0 then
            DB.exec("DELETE FROM pb_bank_points WHERE id = ? AND kind = 'atm'", { r.id })
            PB.Audit.Log('staff', 'decor.atm_point', src, tostring(r.label), nil, nil, { id = r.id })
            n = n + 1
        end
    end
    if n > 0 and G.PushConfig then G.PushConfig() end
end

function D.Hide(src, d)
    if not P.Has(src, 'carte.delete') then return false, 'Droit manquant.' end
    if type(d) ~= 'table' then return false, 'Données invalides.' end
    local model = math.floor(tonumber(d.model) or 0)
    local x, y, z = num(d.x, -10000, 10000), num(d.y, -10000, 10000), num(d.z, -500, 3000)
    if model == 0 or not x or not y or not z then return false, 'Objet invalide.' end
    if G.DistTo(src, x, y, z) > RANGE then return false, 'Trop loin de toi.' end
    if #D.List() >= MAX then return false, ('Maximum atteint (%d objets retirés).'):format(MAX) end
    for _, r in ipairs(D.List()) do
        if r.m == model and math.abs(r.x - x) < 0.5 and math.abs(r.y - y) < 0.5 and math.abs(r.z - z) < 0.5 then return false, 'Cet objet est déjà retiré.' end
    end
    local who = PB.Actor and PB.Actor(src).name or ('#' .. src)
    local label = clean(d.label, 64)
    DB.insert('INSERT INTO pb_decor_hidden (model, label, x, y, z, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { model, label, x, y, z, tostring(who):sub(1, 64), os.time() })
    cache = nil
    PB.Audit.Log('staff', 'decor.hide', src, label ~= '' and label or tostring(model), nil, nil, { x = math.floor(x), y = math.floor(y), z = math.floor(z) })
    if isAtm(model) then dropAtmPoints(src, x, y, z) end
    push()
    return true, 'Objet retiré pour tout le monde.'
end
function D.Show(src, id)
    if not P.Has(src, 'carte.delete') then return false, 'Droit manquant.' end
    id = math.floor(tonumber(id) or 0)
    local row
    for _, r in ipairs(D.List()) do if r.id == id then row = r end end
    if not row then return false, 'Objet introuvable.' end
    DB.exec('DELETE FROM pb_decor_hidden WHERE id = ?', { id })
    cache = nil
    PB.Audit.Log('staff', 'decor.show', src, row.l ~= '' and row.l or tostring(row.m), nil, nil, { id = id })
    push()
    return true, 'Objet remis.'
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)
RegisterNetEvent('pb:g:decor:hide', function(d)
    local src = source
    if not throttle(src, 400) then return end
    local ok, msg = D.Hide(src, d)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Décor', text = msg })
end)
RegisterNetEvent('pb:g:decor:show', function(id)
    local src = source
    if not throttle(src, 400) then return end
    local ok, msg = D.Show(src, id)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Décor', text = msg })
end)
