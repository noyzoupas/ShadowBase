-- Shadow Base — Zones safe (client) : dans une zone, pas de tirs, pas de coups, invincible (chaque règle est réglable).
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, zones = {} }
local blips, inside, duty = {}, nil, false

local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
-- Sur la grande carte seulement : ni mini-carte, ni trait dans le monde
local function mapBlip(b)
    SetBlipColour(b, 2) SetBlipAlpha(b, 90) SetBlipDisplay(b, 3)
    blips[#blips + 1] = b
end
local function inPoly(x, y, p)
    local inside, j = false, #p
    for i = 1, #p do
        if (p[i][2] > y) ~= (p[j][2] > y) and x < (p[j][1] - p[i][1]) * (y - p[i][2]) / (p[j][2] - p[i][2]) + p[i][1] then inside = not inside end
        j = i
    end
    return inside
end
-- La carte du jeu ne sait pas dessiner une forme libre : la zone est remplie de bandes
local function polyStrips(p)
    local x0, y0, x1, y1 = 1e9, 1e9, -1e9, -1e9
    for _, q in ipairs(p) do x0, y0, x1, y1 = math.min(x0, q[1]), math.min(y0, q[2]), math.max(x1, q[1]), math.max(y1, q[2]) end
    local step = math.max(3.0, math.max(x1 - x0, y1 - y0) / 60)
    local out
    repeat
        out = {}
        for yy = y0 + step / 2, y1, step do
            local run
            for xx = x0 + step / 2, x1 + step, step do
                if xx <= x1 and inPoly(xx, yy, p) then run = run or xx
                elseif run then out[#out + 1] = { (run + xx - step) / 2, yy, xx - run, step } run = nil end
            end
        end
        step = step * 1.4
    until #out <= 220
    return out
end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    for _, z in ipairs(C.polys or {}) do
        z.p = {}
        for x, y in tostring(z.pts or ''):gmatch('(-?[%d%.]+),(-?[%d%.]+)') do z.p[#z.p + 1] = { tonumber(x), tonumber(y) } end
    end
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, z in ipairs(C.zones or {}) do mapBlip(AddBlipForRadius(z.x + 0.0, z.y + 0.0, z.z + 0.0, (tonumber(z.r) or 50) + 0.0)) end
    for _, z in ipairs(C.polys or {}) do
        if #z.p >= 3 then
            for _, s in ipairs(polyStrips(z.p)) do
                local b = AddBlipForArea(s[1] + 0.0, s[2] + 0.0, 0.0, s[3] + 0.0, s[4] + 0.0)
                SetBlipRotation(b, 0)
                mapBlip(b)
            end
        end
    end
end)
RegisterNetEvent(RES .. ':dutyIs', function(on) duty = on == true end)
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
    while true do Wait(15000) if C.bypass then TriggerServerEvent(RES .. ':duty') end end
end)

local function zoneAt(c)
    for _, z in ipairs(C.zones or {}) do
        if #(vector3(c.x, c.y, c.z) - vector3(z.x + 0.0, z.y + 0.0, z.z + 0.0)) <= (tonumber(z.r) or 50) + 0.0 then return z end
    end
    for _, z in ipairs(C.polys or {}) do
        local h = tonumber(z.z) or 0
        if c.z > h - 40.0 and c.z < h + 150.0 and #z.p >= 3 and inPoly(c.x, c.y, z.p) then return z end
    end
end

-- Tracé coin par coin : les traits ne sont dessinés que pour le staff qui trace, et disparaissent à la fin. Noclip possible.
local drawing = false
RegisterNetEvent(RES .. ':draw', function(label)
    if drawing then return end
    drawing = true
    -- (Shadow Base 1.2.84) le Builder rouvre sa liste juste après le choix : on attend qu'elle revienne avant de la mettre de côté,
    -- sinon Entrée cliquait dans le menu au lieu de poser les coins
    Wait(700)
    pcall(function() W:MenuSuspend() end)
    local pts = {}
    local function help()
        W:Prompt(('Coin %d : Entrée pour le poser  ·  Retour arrière : retirer  ·  Y : terminer (3 coins min.)  ·  X : annuler'):format(#pts + 1), '↵')
    end
    help()
    CreateThread(function()
        local finished = false
        local ready, nextMenuCheck = false, 0
        while drawing do
            Wait(0)
            DisableControlAction(0, 200, true) DisableControlAction(0, 199, true) DisableControlAction(0, 177, true)
            DisableControlAction(0, 191, true) DisableControlAction(0, 246, true) DisableControlAction(0, 73, true)   -- Entrée, Y, X : rien d'autre ne s'ouvre
            if GetGameTimer() > nextMenuCheck then   -- un menu rouvert pendant le tracé est remis de côté
                nextMenuCheck = GetGameTimer() + 250
                local okm, open = pcall(function() return W:MenuIsOpen() end)
                if okm and open then pcall(function() W:MenuSuspend() end) end
            end
            if not ready then ready = not IsDisabledControlPressed(0, 191) end   -- l'Entrée qui a validé le nom ne pose pas de coin
            local c = GetEntityCoords(PlayerPedId())
            local found, ground = GetGroundZFor_3dCoord(c.x, c.y, c.z + 2.0, false)
            local gz = found and ground or (c.z - 0.9)
            for i = 1, #pts - 1 do DrawLine(pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z, 90, 230, 130, 230) end
            for _, q in ipairs(pts) do DrawMarker(28, q.x, q.y, q.z, 0, 0, 0, 0, 0, 0, 0.35, 0.35, 0.35, 90, 230, 130, 200, false, false, 2, false, nil, nil, false) end
            if #pts > 0 then
                local l = pts[#pts]
                DrawLine(l.x, l.y, l.z, c.x, c.y, gz, 255, 255, 255, 140)
                if #pts >= 2 then DrawLine(c.x, c.y, gz, pts[1].x, pts[1].y, pts[1].z, 255, 255, 255, 70) end
            end
            if ready and IsDisabledControlJustPressed(0, 191) then
                pts[#pts + 1] = { x = c.x, y = c.y, z = gz }
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if #pts >= 40 then finished = true drawing = false else help() end
            elseif IsDisabledControlJustPressed(0, 177) then
                if #pts > 0 then table.remove(pts) help() end
            elseif IsDisabledControlJustPressed(0, 246) then
                if #pts >= 3 then finished = true drawing = false
                else W:Notify({ type = 'warn', title = 'Zone safe', text = 'Pose au moins 3 coins.' }) end
            elseif IsDisabledControlJustPressed(0, 73) then
                drawing = false
            end
        end
        W:HidePrompt()
        if finished then TriggerServerEvent(RES .. ':poly', label, pts) end
        pcall(function() W:MenuResume() end)
    end)
end)

CreateThread(function()
    local wasGod = false
    while true do
        local ped = PlayerPedId()
        local z = (C.enabled and not (C.bypass and duty)) and zoneAt(GetEntityCoords(ped)) or nil
        if z ~= inside and (z and z.id) ~= (inside and inside.id) then
            pcall(function() exports.pb_panel:SafeZone(z ~= nil) end)   -- bandeau « Zone sécurisée » (vert, bouclier)
            if C.msg then W:Notify({ type = z and 'success' or 'info', title = 'Zone safe', text = z and ('Tu entres dans « ' .. z.label .. ' » : pas de violence ici.') or 'Tu quittes la zone safe.' }) end
            if z and C.unarm then SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true) end
            if not z and wasGod then SetEntityInvincible(ped, false) SetPlayerInvincible(PlayerId(), false) wasGod = false end
            inside = z
        end
        if z then
            if C.god then SetEntityInvincible(ped, true) SetPlayerInvincible(PlayerId(), true) wasGod = true end
            Wait(0)
            if C.nofire then
                DisablePlayerFiring(PlayerId(), true)
                DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 47, true) DisableControlAction(0, 58, true)
                DisableControlAction(0, 69, true) DisableControlAction(0, 70, true) DisableControlAction(0, 92, true) DisableControlAction(0, 257, true)
            end
            if C.nomelee then
                DisableControlAction(0, 140, true) DisableControlAction(0, 141, true) DisableControlAction(0, 142, true) DisableControlAction(0, 143, true) DisableControlAction(0, 263, true) DisableControlAction(0, 264, true)
            end
        else
            if wasGod then SetEntityInvincible(ped, false) SetPlayerInvincible(PlayerId(), false) wasGod = false end
            Wait(C.enabled and (#(C.zones or {}) + #(C.polys or {})) > 0 and 500 or 2000)   -- (1.2.84) les zones tracées comptent aussi
        end
    end
end)
