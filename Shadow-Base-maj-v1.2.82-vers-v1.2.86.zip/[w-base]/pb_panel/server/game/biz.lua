-- Entreprises (police, EMS, garage, générique) : grades, employés, paie, caisse, factures, amendes, dossiers et tablette de gestion en jeu.
-- Autonome (tables pb_biz*). Tout ce que le client demande est revérifié ici : appartenance, grade, service, distance, montants.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('biz.edit', 'Créer, modifier et supprimer les entreprises', 'biz', true)
P.Register('biz.members', 'Engager et renvoyer des employés depuis le panel', 'biz', true)
P.Register('biz.ledger', 'Voir les caisses des entreprises', 'biz')

PB.Migrate('044_game_biz', 'Entreprises, grades, employés, factures, dossiers', {
    [[CREATE TABLE IF NOT EXISTS pb_biz (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, kind VARCHAR(16) NOT NULL DEFAULT 'generic', color VARCHAR(7) NOT NULL DEFAULT '#dfe2e7', icon VARCHAR(24) NOT NULL DEFAULT 'building',
        pay_from VARCHAR(8) NOT NULL DEFAULT 'free', enabled TINYINT(1) NOT NULL DEFAULT 1, hx DOUBLE NULL, hy DOUBLE NULL, hz DOUBLE NULL, hiring TINYINT(1) NOT NULL DEFAULT 0,
        description VARCHAR(160) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_grades (
        biz_id VARCHAR(32) NOT NULL, grade INT NOT NULL, label VARCHAR(40) NOT NULL, salary INT NOT NULL DEFAULT 0, boss TINYINT(1) NOT NULL DEFAULT 0, perms VARCHAR(160) NOT NULL DEFAULT '',
        PRIMARY KEY (biz_id, grade))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_members (
        license VARCHAR(64) NOT NULL, biz_id VARCHAR(32) NOT NULL, grade INT NOT NULL DEFAULT 0, name VARCHAR(64) NOT NULL DEFAULT '', hired_at INT NOT NULL DEFAULT 0, on_duty TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (license), KEY k_biz (biz_id))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_invoices (
        id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', amount BIGINT NOT NULL, reason VARCHAR(120) NOT NULL DEFAULT '',
        kind VARCHAR(8) NOT NULL DEFAULT 'invoice', status VARCHAR(10) NOT NULL DEFAULT 'pending', by_name VARCHAR(64) NOT NULL DEFAULT '', by_license VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, paid_at INT NULL,
        PRIMARY KEY (id), KEY k_lic (license, status), KEY k_biz (biz_id, status))]],
    [[CREATE TABLE IF NOT EXISTS pb_biz_records (
        id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', kind VARCHAR(10) NOT NULL, text VARCHAR(240) NOT NULL DEFAULT '',
        amount BIGINT NOT NULL DEFAULT 0, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_lic (license), KEY k_biz (biz_id))]],
})

PB.Cfg.Define('tablets', { hq_only = true, img_home = '', img_finance = '', img_invoices = '', img_directory = '', img_profile = '', img_biz = '', img_staff = '', img_grades = '', img_vault = '', img_bills = '', img_citizens = '', img_patients = '', img_team = '', img_news = '', img_journal = '', img_stats = '', img_payroll = '', img_rules = '', img_places = '', img_territories = '', img_roster = '', img_orgnews = '', img_orgvault = '', img_activity = '', img_crypto = '', img_gestion = '', img_leaderboard = '', img_crews = '', img_orgagrades = '', img_labs = '', img_contracts = '', orga_key = 'F7', crypto_fee = 2, invite_secs = 60, grade_names = { 'Recrue', 'Membre', 'Lieutenant', 'Chef' } })
PB.Cfg.Define('biz', { max_invoice = 50000, max_fine = 25000, fine_to = 'state', pay_off_duty = false, max_members = 60, allow_transfers = true, transfer_fee = 0, transfer_max = 100000, tablet_key = 'F6', near_dist = 8, full_catalog = false, trimmed_v1 = false })

local Biz = {}
G.Biz = Biz
local ALL_PERMS = { 'hire', 'fire', 'promote', 'vault', 'invoice', 'fine', 'revive', 'repair', 'records', 'cuff', 'search', 'seize', 'jail', 'dispatch', 'security' }
local PERM_LABEL = { hire = 'Engager', fire = 'Renvoyer', promote = 'Promouvoir', vault = 'Caisse', invoice = 'Facturer', fine = 'Amendes', revive = 'Réanimer', repair = 'Réparer', records = 'Dossiers', cuff = 'Menotter', search = 'Fouiller', seize = 'Saisir un véhicule', jail = 'Prison et TIG', dispatch = 'Répartiteur (appels)', security = 'Sécurité (palpation, entrée, expulsion)' }
local KIND_PERMS = { police = { 'fine', 'records', 'cuff', 'search', 'seize', 'jail', 'dispatch' }, ems = { 'revive', 'records', 'dispatch' }, garage = { 'repair' }, generic = {} }
local KIND_LABEL = { police = 'Police', ems = 'Secours (EMS)', garage = 'Garage', generic = 'Entreprise' }

local TEMPLATES = {
    police = { label = 'Police', kind = 'police', color = '#6fb4ff', icon = 'shield', description = "Maintien de l'ordre : amendes, dossiers, caisse du commissariat.", grades = {
        { 0, 'Cadet', 250, false, 'records' }, { 1, 'Officier', 350, false, 'fine,records,cuff,search,jail' }, { 2, 'Sergent', 450, false, 'fine,records,invoice,cuff,search,seize,jail,dispatch' }, { 3, 'Lieutenant', 600, false, 'fine,records,invoice,cuff,search,seize,jail,dispatch,hire' },
        { 4, 'Capitaine', 800, false, 'fine,records,invoice,cuff,search,seize,jail,dispatch,hire,fire,promote,vault' }, { 5, 'Chef de la police', 1100, true, '' } } },
    ems = { label = 'Secours (EMS)', kind = 'ems', color = '#ff6b7d', icon = 'heart', description = 'Soins, réanimation et facturation des interventions.', grades = {
        { 0, 'Stagiaire', 230, false, 'records' }, { 1, 'Ambulancier', 330, false, 'revive,records,invoice' }, { 2, 'Infirmier', 430, false, 'revive,records,invoice,dispatch' }, { 3, 'Médecin', 580, false, 'revive,records,invoice,dispatch' },
        { 4, 'Chef de service', 780, false, 'revive,records,invoice,dispatch,hire,fire,promote,vault' }, { 5, 'Directeur', 1000, true, '' } } },
    garage = { label = 'Garage', kind = 'garage', color = '#ffb457', icon = 'engine', description = 'Réparations, dépannage et facturation des clients.', grades = {
        { 0, 'Apprenti', 200, false, 'repair' }, { 1, 'Mécanicien', 300, false, 'repair,invoice' }, { 2, "Chef d'atelier", 420, false, 'repair,invoice,hire,vault' }, { 3, 'Patron', 700, true, '' } } },
    generic = { label = 'Entreprise', kind = 'generic', color = '#dfe2e7', icon = 'building', description = 'Une entreprise simple avec caisse et factures.', grades = {
        { 0, 'Employé', 200, false, 'invoice' }, { 1, 'Gérant', 400, false, 'invoice,hire,fire,promote,vault' }, { 2, 'Patron', 600, true, '' } } },
}
Biz.Templates = TEMPLATES

local function now() return os.time() end
local function acct(id) return 'biz:' .. id end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function setOf(csv) local t = {} for w in tostring(csv or ''):gmatch('[%a_]+') do t[w] = true end return t end

-- Données ---------------------------------------------------------------------------------------------------------------------------
function Biz.Get(id) return DB.one('SELECT * FROM pb_biz WHERE id = ?', { tostring(id) }) end
function Biz.List() return DB.q('SELECT * FROM pb_biz ORDER BY label') or {} end
function Biz.Grades(id) return DB.q('SELECT * FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade', { tostring(id) }) or {} end
function Biz.Grade(id, n) return DB.one('SELECT * FROM pb_biz_grades WHERE biz_id = ? AND grade = ?', { tostring(id), tonumber(n) or -1 }) end
function Biz.Members(id) return DB.q('SELECT * FROM pb_biz_members WHERE biz_id = ? ORDER BY grade DESC, name', { tostring(id) }) or {} end
-- (v1.2.78) temps de service : chaque minute passée en service est comptée (par jour), sans rien montrer à l'employé.
-- Le patron le voit dans la tablette (Employés) : 7 derniers jours et total depuis l'embauche ou la dernière remise à zéro.
PB.Migrate('560_biz_duty_time', 'Entreprises : temps de service des employés', {
    [[CREATE TABLE IF NOT EXISTS pb_biz_duty (license VARCHAR(64) NOT NULL, biz_id VARCHAR(32) NOT NULL, day INT NOT NULL, secs INT NOT NULL DEFAULT 0,
        PRIMARY KEY (license, biz_id, day), KEY k_biz (biz_id))]],
})
local function dayOf(t) return tonumber(os.date('%Y%m%d', t or os.time())) end
function Biz.DutyAdd(license, bizId, secs)
    DB.exec('INSERT INTO pb_biz_duty (license, biz_id, day, secs) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE secs = secs + VALUES(secs)', { tostring(license), tostring(bizId), dayOf(), math.floor(secs) })
end
-- { [license] = { week = s, total = s } } pour une entreprise
function Biz.DutyTimes(bizId)
    local out = {}
    local from = dayOf(os.time() - 6 * 86400)
    for _, r in ipairs(DB.q('SELECT license, SUM(secs) AS total, SUM(CASE WHEN day >= ? THEN secs ELSE 0 END) AS week FROM pb_biz_duty WHERE biz_id = ? GROUP BY license', { from, tostring(bizId) }) or {}) do
        out[r.license] = { week = tonumber(r.week) or 0, total = tonumber(r.total) or 0 }
    end
    return out
end
function Biz.FmtDuty(secs)
    secs = math.floor(tonumber(secs) or 0)
    if secs < 60 then return '0 min' end
    local h, m = math.floor(secs / 3600), math.floor((secs % 3600) / 60)
    return h > 0 and ('%d h %02d'):format(h, m) or (m .. ' min')
end
CreateThread(function()
    while true do
        Wait(60000)
        pcall(function()
            for src, pl in pairs(G.Players()) do
                if PB.ToBool(pl.row.created) then
                    local m = Biz.MemberOf(pl.license)
                    if m and PB.ToBool(m.on_duty) then Biz.DutyAdd(pl.license, m.biz_id, 60) end
                end
            end
        end)
    end
end)
function Biz.MemberOf(license) return DB.one('SELECT * FROM pb_biz_members WHERE license = ?', { tostring(license) }) end

-- Contexte d'un joueur en ligne : { member, biz, grade, boss, perms }
function Biz.Ctx(src)
    local p = G.Get(src)
    if not p then return nil end
    local m = Biz.MemberOf(p.license)
    if not m then return nil end
    local b = Biz.Get(m.biz_id)
    if not b or not PB.ToBool(b.enabled) then return nil end
    local g = Biz.Grade(m.biz_id, m.grade)
    if not g then return nil end
    local boss = PB.ToBool(g.boss)
    return { member = m, biz = b, grade = g, boss = boss, perms = setOf(g.perms), license = p.license, src = src, duty = PB.ToBool(m.on_duty) }
end
function Biz.Can(c, perm) return c and (c.boss or c.perms[perm]) and true or false end
local PERM_DESC = { hire = 'Recruter une personne proche dans l\'entreprise.', fire = 'Renvoyer un employé d\'un grade inférieur au sien.', promote = 'Monter ou descendre le grade des employés, publier des annonces.',
    vault = 'Déposer et retirer de l\'argent de la caisse.', invoice = 'Envoyer des factures aux clients.', fine = 'Donner des amendes aux citoyens.', revive = 'Soigner et réanimer les personnes à terre.',
    repair = 'Réparer et nettoyer les véhicules.', records = 'Consulter et compléter les dossiers.', cuff = 'Menotter et escorter une personne.', search = 'Fouiller une personne et saisir ses objets.',
    seize = 'Envoyer un véhicule à la fourrière.', jail = 'Envoyer en prison ou aux travaux d\'intérêt général.', dispatch = 'Recevoir et prendre les appels du central.', security = 'Palper, contrôler l\'entrée et expulser les clients.' }
local function kindAllows(c, perm) local ok = false for _, k in ipairs(KIND_PERMS[c.biz.kind] or {}) do if k == perm then ok = true end end return ok or perm == 'invoice' or perm == 'hire' or perm == 'fire' or perm == 'promote' or perm == 'vault' end
-- un droit propre à un métier n'a d'effet que dans ce métier, même pour le patron
-- Sécurité de club (palpation, bracelets, interdits, expulsion) : seulement les entreprises qui s'en servent vraiment
-- (boîte de nuit, sécurité privée, ou un grade qui a reçu ce droit) ; un patron d'une autre entreprise ne la voit plus.
local SECURITY_MODELS = { galaxy = true, nightclub = true, security = true, bahamas = true, unicorn = true, tequilala = true }
local function usesSecurity(c)
    local k = G.BizCat and G.BizCat.ModelKey and G.BizCat.ModelKey(c.biz) or c.biz.id
    if SECURITY_MODELS[k] or SECURITY_MODELS[c.biz.id] then return true end
    for _, g in ipairs(Biz.Grades(c.biz.id)) do if setOf(g.perms).security then return true end end
    return false
end
function Biz.Allowed(c, perm)
    if not c then return false end
    if perm == 'security' then return (c.perms.security or (c.boss and usesSecurity(c))) and true or false end
    if perm == 'fine' or perm == 'revive' or perm == 'repair' or perm == 'records' or perm == 'cuff' or perm == 'search' or perm == 'seize' or perm == 'jail' or perm == 'dispatch' then if not kindAllows(c, perm) then return false end end
    return Biz.Can(c, perm)
end

function Biz.Job(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    return { biz = c.biz.id, label = c.biz.label, kind = c.biz.kind, grade = c.grade.grade, gradeLabel = c.grade.label, boss = c.boss, onDuty = c.duty, salary = c.grade.salary }
end
exports('GetJob', function(src) return Biz.Job(tonumber(src)) end)
-- (v1.2.84) le client reçoit son entreprise : garages, gardiens, coffres et points d'entreprise ne s'affichaient chez personne
-- (l'événement n'envoyait jamais que « null »)
function Biz.PushJob(src)
    src = tonumber(src)
    if not src or not G.Get(src) then return end
    local j = Biz.Job(src)
    TriggerClientEvent('pb:g:biz:job', src, j and PB.Json({ biz = j.biz, label = j.label, kind = j.kind, grade = j.grade, boss = j.boss or nil }) or 'null')
end
table.insert(G.beginHooks, function(src) SetTimeout(1200, function() Biz.PushJob(src) end) end)
AddEventHandler('pb_panel:jobChanged', function(src) SetTimeout(200, function() Biz.PushJob(src) end) end)
exports('IsOnDuty', function(src, bizId) local j = Biz.Job(tonumber(src)) return j ~= nil and j.onDuty and (bizId == nil or j.biz == bizId) end)
exports('GetBusinessBalance', function(id) return G.Eco and G.Eco.Balance(acct(id)) or 0 end)
exports('AddBusinessMoney', function(id, amount, reason) if not Biz.Get(id) then return false end return G.Eco.Book(acct(id), amount, reason or 'Script', '') end)

local function display(src) local i = G.Identity(src) if i and i.created and i.firstname ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return (GetPlayerName and GetPlayerName(src)) or ('Joueur ' .. src) end

function Biz.SetJob(src, bizId, gradeNo, actorName)
    local p = G.Get(tonumber(src))
    if not p then return false, 'Joueur introuvable.' end
    if bizId == nil or bizId == '' then
        DB.exec('DELETE FROM pb_biz_members WHERE license = ?', { p.license })
        TriggerClientEvent('pb:g:biz:job', src, 'null')
        TriggerEvent('pb_panel:jobChanged', tonumber(src), nil, nil)
        return true
    end
    local b = Biz.Get(bizId)
    if not b then return false, 'Entreprise introuvable.' end
    local g = Biz.Grade(bizId, gradeNo or 0)
    if not g then return false, 'Grade introuvable.' end
    local count = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { bizId })
    local old = Biz.MemberOf(p.license)
    if (not old or old.biz_id ~= bizId) and count and count.n >= PB.Cfg.Get('biz', 'max_members', 60) then return false, 'Cette entreprise a atteint son nombre maximal d\'employés.' end
    DB.exec('INSERT INTO pb_biz_members (license, biz_id, grade, name, hired_at, on_duty) VALUES (?, ?, ?, ?, ?, 0) ON DUPLICATE KEY UPDATE biz_id = VALUES(biz_id), grade = VALUES(grade), name = VALUES(name), on_duty = 0' ..
        ((old and old.biz_id == bizId) and '' or ', hired_at = VALUES(hired_at)'), { p.license, bizId, g.grade, display(src), now() })
    TriggerEvent('pb_panel:jobChanged', src, bizId, g.grade)
    G.Notify(src, { type = 'info', title = b.label, text = 'Ton poste : ' .. g.label .. '.' })
    return true
end
exports('SetJob', function(src, bizId, grade) return Biz.SetJob(tonumber(src), bizId, grade) end)

-- Proximité ---------------------------------------------------------------------------------------------------------------------------
local function coordsOf(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0 and c.z == 0) then return nil end
    return c
end
local function distance(a, b)
    local ca, cb = coordsOf(a), coordsOf(b)
    if not ca or not cb then return 0 end   -- lecture impossible (tests / hors jeu)
    local dx, dy, dz = ca.x - cb.x, ca.y - cb.y, ca.z - cb.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end
function Biz.Nearby(src, radius)
    local out = {}
    radius = radius or PB.Cfg.Get('biz', 'near_dist', 8)
    for id, p in pairs(G.Players()) do
        if id ~= src and PB.ToBool(p.row.created) and distance(src, id) <= radius then out[#out + 1] = { id = id, name = display(id), license = p.license } end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end
-- cible choisie par identifiant : doit être en ligne, créée, et proche
local function target(src, id, selfOk)
    id = tonumber(id)
    if not id then return nil, 'Choisis un joueur dans la liste.' end
    if id == src and not selfOk then return nil, 'Tu ne peux pas faire ça sur toi-même.' end
    local p = G.Get(id)
    if not p or not PB.ToBool(p.row.created) then return nil, "Ce joueur n'est pas disponible." end
    if id ~= src and distance(src, id) > PB.Cfg.Get('biz', 'near_dist', 8) + 2 then return nil, "Ce joueur est trop loin." end
    return p, nil, id
end

-- Dossiers, factures ----------------------------------------------------------------------------------------------------------------
local function record(c, lic, name, kind, text, amount)
    DB.exec('INSERT INTO pb_biz_records (biz_id, license, name, kind, text, amount, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', { c.biz.id, lic, name, kind, tostring(text):sub(1, 240), amount or 0, display(c.src), now() })
end
Biz.Record = record   -- aussi utilisé par le menu ALT (saisie d'un véhicule : inscrite au casier)
local function cleanText(s, n) return PB.Trim(PB.Sanitize(tostring(s or ''), n)) end

local function chargeInvoice(inv, payerSrc)
    local p = G.Get(payerSrc)
    if not p or p.license ~= inv.license then return false, 'Cette facture ne te concerne pas.' end
    if inv.status ~= 'pending' then return false, 'Facture déjà réglée ou annulée.' end
    local acc = G.Pay(payerSrc, inv.amount, 'bank')
    if not acc then return false, "Tu n'as pas assez d'argent." end
    DB.exec("UPDATE pb_biz_invoices SET status = 'paid', paid_at = ? WHERE id = ? AND status = 'pending'", { now(), inv.id })
    if inv.kind == 'fine' and PB.Cfg.Get('biz', 'fine_to', 'state') == 'state' then
        G.Eco.Book('state', inv.amount, 'Amende #' .. inv.id, p.license)
    else
        G.Eco.Book(acct(inv.biz_id), inv.amount, (inv.kind == 'fine' and 'Amende #' or 'Facture #') .. inv.id, p.license)
    end
    TriggerEvent('pb_panel:invoicePaid', inv.id, payerSrc, inv.biz_id, inv.amount, inv.kind)
    return true
end

function Biz.PayInvoice(src, id)
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { tonumber(id) or -1 })
    if not inv then return false, 'Facture introuvable.' end
    local ok, err = chargeInvoice(inv, src)
    if not ok then return false, err end
    G.PushState(src)
    return true, inv
end

-- Facture reçue : le client la voit tout de suite (menu) et la paie, ou la garde pour plus tard (tablette / téléphone › Factures)
local billLast = {}
AddEventHandler('playerDropped', function() billLast[source] = nil end)
RegisterNetEvent('pb:g:bill:answer', function(id, pay)
    local src = source
    if pay ~= true then return end
    local t = GetGameTimer()
    if billLast[src] and t - billLast[src] < 1500 then return end
    billLast[src] = t
    local ok, r = Biz.PayInvoice(src, id)
    if ok then G.Notify(src, { type = 'success', title = 'Facture', text = ('Facture réglée : %s.'):format(money(r.amount)) })
    else G.Notify(src, { type = 'error', title = 'Facture', text = tostring(r) }) end
end)

-- Actions de la tablette --------------------------------------------------------------------------------------------------------------
local ACT = {}

ACT.duty = function(c, src, p)
    local on = p.on == true
    DB.exec('UPDATE pb_biz_members SET on_duty = ? WHERE license = ?', { on and 1 or 0, c.license })
    TriggerEvent('pb_panel:duty', src, c.biz.id, on)
    return true, on and 'Tu prends ton service.' or 'Tu quittes ton service.'
end

ACT.duty_reset = function(c, src)
    if not c.boss then return false, 'Réservé au patron.' end
    DB.exec('DELETE FROM pb_biz_duty WHERE biz_id = ?', { c.biz.id })
    PB.Audit.Log('serveur', 'biz.duty_reset', src, c.biz.id)
    return true, 'Compteurs de service remis à zéro.'
end

ACT.pay_invoice = function(_, src, p)
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { tonumber(p.id) or -1 })
    if not inv then return false, 'Facture introuvable.' end
    local ok, err = chargeInvoice(inv, src)
    if not ok then return false, err end
    G.PushState(src)
    return true, ('Facture réglée : %s.'):format(money(inv.amount))
end

ACT.transfer = function(_, src, p)
    local cfg = PB.Cfg.All('biz')
    if not cfg.allow_transfers then return false, 'Les virements sont désactivés.' end
    local amount = math.floor(tonumber(p.amount) or 0)
    if amount < 1 or amount > cfg.transfer_max then return false, ('Montant : 1 à %s.'):format(money(cfg.transfer_max)) end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local fee = math.floor(amount * (cfg.transfer_fee or 0) / 100 + 0.5)
    if G.GetMoney(src, 'bank') < amount + fee then return false, 'Solde bancaire insuffisant.' end
    if tid == src then return false, 'Tu ne peux pas te virer de l\'argent à toi-même.' end
    if not G.RemoveMoney(src, 'bank', amount + fee) then return false, 'Solde bancaire insuffisant.' end
    G.AddMoney(tid, 'bank', amount)
    if fee > 0 then G.Eco.Book('state', fee, 'Frais de virement', G.Get(src).license) end
    G.Notify(tid, { type = 'success', title = 'Virement reçu', text = ('%s de %s'):format(money(amount), display(src)) })
    G.PushState(src)
    return true, ('Virement de %s envoyé à %s.'):format(money(amount), display(tid))
end

-- Engager : la personne reçoit une proposition (Y / N), tout est revérifié quand elle accepte
local function hireNow(c, src, id)
    local tp, err, tid = target(src, id)
    if not tp then return false, err end
    local first = DB.one('SELECT grade FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade LIMIT 1', { c.biz.id })
    local cur = Biz.MemberOf(tp.license)
    if cur then
        -- (v1.2.43) déjà employé ailleurs : un VIP peut être engagé en second emploi
        if cur.biz_id == c.biz.id then return false, 'Cette personne travaille déjà ici.' end
        local BC = G.BizCat
        if not (BC and BC.Job2Allowed and BC.Job2Allowed(tid)) then return false, 'Cette personne a déjà un emploi (le double emploi est réservé aux VIP).' end
        if BC.Job2(tp.license) then return false, 'Cette personne a déjà deux emplois.' end
        local ok2, e2 = BC.SetJob2(tid, c.biz.id, first and first.grade or 0)
        if not ok2 then return false, e2 end
        G.Notify(tid, { type = 'success', title = c.biz.label, text = 'Engagé(e) en second emploi. Change d\'emploi dans F5 › Mon entreprise.' })
        return true, display(tid) .. ' est engagé(e) en second emploi (VIP).'
    end
    local ok, e = Biz.SetJob(tid, c.biz.id, first and first.grade or 0)
    if not ok then return false, e end
    return true, display(tid) .. ' est engagé(e).'
end
ACT.hire = function(c, src, p)
    if not Biz.Can(c, 'hire') then return false, "Tu n'as pas le droit d'engager." end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local cur = Biz.MemberOf(tp.license)
    local BC = G.BizCat
    if cur then
        if cur.biz_id == c.biz.id then return false, 'Cette personne travaille déjà ici.' end
        if not (BC and BC.Job2Allowed and BC.Job2Allowed(tid)) then return false, 'Cette personne a déjà un emploi (le double emploi est réservé aux VIP).' end
        if BC.Job2(tp.license) then return false, 'Cette personne a déjà deux emplois.' end
    end
    local first = DB.one('SELECT label, salary FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade LIMIT 1', { c.biz.id })
    local bizId = c.biz.id
    local ok, why = G.Recruit.Offer(tid, { kind = 'biz', org = c.biz.label, from = src, fromName = display(src), grade = first and first.label, salary = first and tonumber(first.salary), second = cur ~= nil or nil, secs = 60,
        accept = function()
            local c2 = Biz.Ctx(src)
            if not c2 or c2.biz.id ~= bizId or not Biz.Can(c2, 'hire') then return false, "La personne qui t'a proposé ce poste ne peut plus engager." end
            return hireNow(c2, src, tid)
        end })
    if not ok then return false, why end
    return true, ('Proposition envoyée à %s.'):format(display(tid))
end

local function memberAction(c, p, need)
    if not Biz.Can(c, need) then return nil, "Tu n'as pas ce droit." end
    local m = DB.one('SELECT * FROM pb_biz_members WHERE license = ? AND biz_id = ?', { tostring(p.license or ''), c.biz.id })
    if not m then return nil, 'Employé introuvable.' end
    if m.license == c.license then return nil, 'Tu ne peux pas le faire sur toi-même.' end
    local mg = Biz.Grade(c.biz.id, m.grade)
    if mg and PB.ToBool(mg.boss) and not c.boss then return nil, 'Seul un patron peut agir sur un patron.' end
    if mg and not c.boss and mg.grade >= c.grade.grade then return nil, 'Tu ne peux agir que sur un grade inférieur au tien.' end
    return m, nil, mg
end

ACT.fire = function(c, src, p)
    local m, err = memberAction(c, p, 'fire')
    if not m then return false, err end
    DB.exec('DELETE FROM pb_biz_members WHERE license = ?', { m.license })
    for id, pl in pairs(G.Players()) do if pl.license == m.license then TriggerClientEvent('pb:g:biz:job', id, 'null') G.Notify(id, { type = 'warn', title = c.biz.label, text = 'Tu as été renvoyé(e).' }) end end
    return true, m.name .. ' est renvoyé(e).'
end

local function shift(c, p, delta)
    local m, err, mg = memberAction(c, p, 'promote')
    if not m then return false, err end
    local ng = Biz.Grade(c.biz.id, m.grade + delta)
    if not ng then return false, delta > 0 and 'Déjà au grade maximum.' or 'Déjà au grade minimum.' end
    if delta > 0 and PB.ToBool(ng.boss) and not c.boss then return false, 'Seul un patron peut nommer un patron.' end
    if delta > 0 and not c.boss and ng.grade >= c.grade.grade then return false, 'Tu ne peux pas promouvoir au-delà de ton propre grade.' end
    DB.exec('UPDATE pb_biz_members SET grade = ? WHERE license = ?', { ng.grade, m.license })
    for id, pl in pairs(G.Players()) do if pl.license == m.license then G.Notify(id, { type = delta > 0 and 'success' or 'warn', title = c.biz.label, text = 'Nouveau grade : ' .. ng.label .. '.' }) end end
    return true, ('%s : %s.'):format(m.name, ng.label)
end
ACT.promote = function(c, _, p) return shift(c, p, 1) end
ACT.demote = function(c, _, p) return shift(c, p, -1) end

-- (v1.2.43) salaire maximum qu'un patron peut fixer : quand l'État paie (« free »), l'argent est créé à chaque paie. Sans plafond,
-- un patron mettait 20 000 $ par quart d'heure à ses amis. Payé par la caisse de l'entreprise : jusqu'à 20 000 $.
local function salaryMax(c)
    if c.biz.pay_from == 'society' then return 20000 end
    return math.max(0, math.floor(tonumber(PB.Cfg.Get('biz', 'boss_salary_max', 1500)) or 1500))
end
Biz.SalaryMax = salaryMax
ACT.set_salary = function(c, _, p)
    if not c.boss then return false, 'Réservé au patron.' end
    local g = Biz.Grade(c.biz.id, p.grade)
    if not g then return false, 'Grade introuvable.' end
    local s = math.floor(tonumber(p.salary) or -1)
    local mx = salaryMax(c)
    if s < 0 or s > mx then return false, ('Salaire : 0 à %s%s.'):format(money(mx), c.biz.pay_from ~= 'society' and " (payé par l'État)" or '') end
    DB.exec('UPDATE pb_biz_grades SET salary = ? WHERE biz_id = ? AND grade = ?', { s, c.biz.id, g.grade })
    return true, ('Salaire de « %s » : %s.'):format(g.label, money(s))
end

-- (v1.2.43) Le patron crée, renomme et supprime ses grades, et règle leurs droits (au bureau du patron)
local MAX_GRADES = 12   -- même limite que le panel (validGrades)
local function bizPerms(c)
    local list, seen = {}, {}
    local function add(k) if not seen[k] and PERM_LABEL[k] then seen[k] = true list[#list + 1] = k end end
    for _, k in ipairs({ 'hire', 'fire', 'promote', 'vault', 'invoice' }) do add(k) end
    for _, k in ipairs(KIND_PERMS[c.biz.kind] or {}) do add(k) end
    for _, g in ipairs(Biz.Grades(c.biz.id)) do for k in tostring(g.perms or ''):gmatch('[%a_]+') do add(k) end end
    return list
end
Biz.BossPerms = bizPerms
local function gradeText(v) return (tostring(v or ''):gsub('[%c<>|]', ''):gsub('^%s+', ''):gsub('%s+$', ''):sub(1, 40)) end
local function shiftGrades(bizId, from, d)
    -- décale les grades >= from (et les employés, seconds emplois) ; dans l'ordre qui évite les doublons de clé
    local gs = DB.q('SELECT grade FROM pb_biz_grades WHERE biz_id = ? AND grade >= ? ORDER BY grade ' .. (d > 0 and 'DESC' or 'ASC'), { bizId, from }) or {}
    for _, r in ipairs(gs) do DB.exec('UPDATE pb_biz_grades SET grade = ? WHERE biz_id = ? AND grade = ?', { r.grade + d, bizId, r.grade }) end
    DB.exec('UPDATE pb_biz_members SET grade = grade + ? WHERE biz_id = ? AND grade >= ?', { d, bizId, from })
    DB.exec('UPDATE pb_biz_job2 SET grade = grade + ? WHERE biz_id = ? AND grade >= ?', { d, bizId, from })
end
ACT.grade_add = function(c, src, p)
    if not c.boss then return false, 'Réservé au patron.' end
    local gs = Biz.Grades(c.biz.id)
    if #gs >= MAX_GRADES then return false, MAX_GRADES .. ' grades au maximum.' end
    local label = gradeText(p.label)
    if label == '' then return false, 'Donne un nom au grade.' end
    for _, g in ipairs(gs) do if tostring(g.label):lower() == label:lower() then return false, 'Ce grade existe déjà.' end end
    local sal = math.floor(tonumber(p.salary) or 0)
    local mx = salaryMax(c)
    if sal < 0 or sal > mx then return false, ('Salaire : 0 à %s%s.'):format(money(mx), c.biz.pay_from ~= 'society' and " (payé par l'État)" or '') end
    local after = tostring(p.after or 'bottom')
    local at
    if after == 'bottom' then at = gs[1] and gs[1].grade or 0
    else
        local ref = Biz.Grade(c.biz.id, after)
        if not ref or PB.ToBool(ref.boss) then return false, 'Position invalide (un grade ne peut pas dépasser le patron).' end
        at = ref.grade + 1
    end
    shiftGrades(c.biz.id, at, 1)
    DB.exec('INSERT INTO pb_biz_grades (biz_id, grade, label, salary, boss, perms) VALUES (?, ?, ?, ?, 0, ?)', { c.biz.id, at, label, sal, '' })
    PB.Audit.Log('serveur', 'biz.grade_add', src, c.biz.id, nil, label, { grade = at })
    return true, ('Grade « %s » créé. Règle ses droits juste en dessous.'):format(label)
end
ACT.grade_rename = function(c, src, p)
    if not c.boss then return false, 'Réservé au patron.' end
    local g = Biz.Grade(c.biz.id, p.grade)
    if not g then return false, 'Grade introuvable.' end
    local label = gradeText(p.label)
    if label == '' then return false, 'Donne un nom au grade.' end
    for _, o in ipairs(Biz.Grades(c.biz.id)) do if o.grade ~= g.grade and tostring(o.label):lower() == label:lower() then return false, 'Ce grade existe déjà.' end end
    DB.exec('UPDATE pb_biz_grades SET label = ? WHERE biz_id = ? AND grade = ?', { label, c.biz.id, g.grade })
    PB.Audit.Log('serveur', 'biz.grade_rename', src, c.biz.id, g.label, label)
    return true, ('« %s » devient « %s ».'):format(g.label, label)
end
ACT.grade_del = function(c, src, p)
    if not c.boss then return false, 'Réservé au patron.' end
    local g = Biz.Grade(c.biz.id, p.grade)
    if not g then return false, 'Grade introuvable.' end
    if PB.ToBool(g.boss) then return false, 'Un grade patron ne se supprime pas ici (panel › Entreprises).' end
    local gs = Biz.Grades(c.biz.id)
    if #gs <= 2 then return false, 'Il faut au moins deux grades.' end
    -- les employés de ce grade passent au grade du dessous (ou du dessus s'il n'y en a pas)
    local below, above
    for _, o in ipairs(gs) do
        if o.grade < g.grade then below = o end
        if o.grade > g.grade and not above then above = o end
    end
    local dest = below or above
    if not dest then return false, 'Impossible.' end
    DB.exec('UPDATE pb_biz_members SET grade = ? WHERE biz_id = ? AND grade = ?', { dest.grade, c.biz.id, g.grade })
    DB.exec('UPDATE pb_biz_job2 SET grade = ? WHERE biz_id = ? AND grade = ?', { dest.grade, c.biz.id, g.grade })
    DB.exec('DELETE FROM pb_biz_grades WHERE biz_id = ? AND grade = ?', { c.biz.id, g.grade })
    shiftGrades(c.biz.id, g.grade + 1, -1)
    PB.Audit.Log('serveur', 'biz.grade_del', src, c.biz.id, g.label, nil)
    return true, ('Grade « %s » supprimé, ses employés passent « %s ».'):format(g.label, dest.label)
end
ACT.grade_perm = function(c, src, p)
    if not c.boss then return false, 'Réservé au patron.' end
    local g = Biz.Grade(c.biz.id, p.grade)
    if not g then return false, 'Grade introuvable.' end
    if PB.ToBool(g.boss) then return false, 'Le patron a déjà tous les droits.' end
    local k = tostring(p.perm or '')
    local okPerm = false
    for _, x in ipairs(bizPerms(c)) do if x == k then okPerm = true end end
    if not okPerm then return false, 'Droit inconnu.' end
    local on = tostring(p.on) == '1' or p.on == true
    local cur, out = {}, {}
    for t in tostring(g.perms or ''):gmatch('[%a_]+') do cur[t] = true end
    cur[k] = on or nil
    for _, x in ipairs(ALL_PERMS) do if cur[x] then out[#out + 1] = x end end
    DB.exec('UPDATE pb_biz_grades SET perms = ? WHERE biz_id = ? AND grade = ?', { table.concat(out, ','), c.biz.id, g.grade })
    PB.Audit.Log('serveur', 'biz.grade_perm', src, c.biz.id, nil, k .. '=' .. tostring(on), { grade = g.grade })
    return true, ('%s : %s %s.'):format(g.label, on and 'peut maintenant' or 'ne peut plus', (PERM_LABEL[k] or k):lower())
end

ACT.deposit = function(c, src, p)
    if not Biz.Can(c, 'vault') then return false, "Tu n'as pas accès à la caisse." end
    local a = math.floor(tonumber(p.amount) or 0)
    if a < 1 or a > 10000000 then return false, 'Montant invalide.' end
    if not G.RemoveMoney(src, 'cash', a) then return false, "Tu n'as pas assez d'espèces." end
    G.Eco.Book(acct(c.biz.id), a, 'Dépôt', c.license)
    G.PushState(src)
    return true, ('%s déposés dans la caisse.'):format(money(a))
end

ACT.withdraw = function(c, src, p)
    if not Biz.Can(c, 'vault') then return false, "Tu n'as pas accès à la caisse." end
    local a = math.floor(tonumber(p.amount) or 0)
    if a < 1 or a > 10000000 then return false, 'Montant invalide.' end
    if not G.Eco.Take(acct(c.biz.id), a, 'Retrait', c.license) then return false, 'La caisse ne contient pas autant.' end
    G.AddMoney(src, 'cash', a)
    G.PushState(src)
    return true, ('%s retirés de la caisse.'):format(money(a))
end

ACT.invoice = function(c, src, p)
    if not Biz.Allowed(c, 'invoice') then return false, "Tu n'as pas le droit de facturer." end
    if not c.duty then return false, 'Prends ton service pour facturer.' end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local a = math.floor(tonumber(p.amount) or 0)
    local max = PB.Cfg.Get('biz', 'max_invoice', 50000)
    if a < 1 or a > max then return false, ('Montant : 1 à %s.'):format(money(max)) end
    local reason = cleanText(p.reason, 120)
    if reason == '' then return false, 'Indique le motif de la facture.' end
    local off = 0
    if G.Vip and G.Vip.Discount then a, off = G.Vip.Discount(tid, c.biz.kind, a) end   -- VIP : factures LSPD / EMS réduites
    if off > 0 then reason = (reason .. (' (VIP -%s)'):format(money(off))):sub(1, 120) end
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { c.biz.id, tp.license, display(tid), a, reason, 'invoice', 'pending', display(src), c.license, now() })
    TriggerClientEvent('pb:g:bill:offer', tid, PB.Json({ id = id, biz = c.biz.label, from = display(src), amount = a, reason = reason }))
    TriggerEvent('pb_panel:invoice', src, tid, c.biz.id, a, reason)
    return true, ('Facture de %s envoyée à %s%s.'):format(money(a), display(tid), off > 0 and (' (VIP : -' .. money(off) .. ')') or '')
end

ACT.cancel_invoice = function(c, _, p)
    if not Biz.Can(c, 'invoice') then return false, "Tu n'as pas le droit." end
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ? AND biz_id = ?', { tonumber(p.id) or -1, c.biz.id })
    if not inv or inv.status ~= 'pending' then return false, 'Facture introuvable ou déjà réglée.' end
    if not c.boss and inv.by_license ~= c.license then return false, "Seul l'émetteur ou un patron peut annuler." end
    DB.exec("UPDATE pb_biz_invoices SET status = 'cancelled' WHERE id = ?", { inv.id })
    return true, 'Facture annulée.'
end

-- Police : amende (immédiate si le citoyen peut payer, sinon facture en attente) et notes au dossier
ACT.fine = function(c, src, p)
    if not Biz.Allowed(c, 'fine') then return false, "Tu n'as pas le droit d'infliger une amende." end
    if not c.duty then return false, 'Prends ton service pour verbaliser.' end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    local amount, reason
    if p.code and tostring(p.code) ~= '' and tostring(p.code) ~= 'custom' then
        local f = DB.one('SELECT * FROM pb_fines WHERE code = ?', { tostring(p.code) })
        if not f then return false, "Cette infraction n'existe pas dans le catalogue." end
        amount, reason = G.Eco.Fine(f.amount), f.label
    else
        amount = math.floor(tonumber(p.amount) or 0)
        reason = cleanText(p.reason, 120)
        if reason == '' then return false, "Indique le motif de l'amende." end
    end
    local max = PB.Cfg.Get('biz', 'max_fine', 25000)
    if amount < 1 or amount > max then return false, ('Amende : 1 à %s.'):format(money(max)) end
    local off = 0
    if G.Vip and G.Vip.Discount then amount, off = G.Vip.Discount(tid, c.biz.kind, amount) end
    if off > 0 then reason = (reason .. (' (VIP -%s)'):format(money(off))):sub(1, 120) end
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { c.biz.id, tp.license, display(tid), amount, reason, 'fine', 'pending', display(src), c.license, now() })
    record(c, tp.license, display(tid), 'fine', reason, amount)
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { id })
    local ok = chargeInvoice(inv, tid)
    G.Notify(tid, { type = 'warn', title = 'Amende', text = ('%s : %s%s'):format(reason, money(amount), ok and ' (prélevée sur ton compte)' or ' — à régler dans F6 › Factures ou dans ton téléphone'), duration = 9000 })
    G.PushState(tid)
    TriggerEvent('pb_panel:fine', src, tid, amount, reason)
    return true, ok and ('Amende de %s prélevée sur %s.'):format(money(amount), display(tid)) or ('Amende de %s enregistrée : %s doit la régler.'):format(money(amount), display(tid))
end

ACT.note = function(c, src, p)
    if not Biz.Allowed(c, 'records') then return false, "Tu n'as pas accès aux dossiers." end
    local tp, err, tid = target(src, p.id, true)
    if not tp then return false, err end
    local text = cleanText(p.text, 240)
    if text == '' then return false, 'La note est vide.' end
    record(c, tp.license, display(tid), 'note', text, 0)
    return true, 'Note ajoutée au dossier.'
end

-- EMS : réanimation d'un patient à proximité
ACT.revive = function(c, src, p)
    if not Biz.Allowed(c, 'revive') then return false, "Tu n'as pas le droit de réanimer." end
    if not c.duty then return false, 'Prends ton service pour intervenir.' end
    local tp, err, tid = target(src, p.id)
    if not tp then return false, err end
    if not PB.ToBool(tp.row.dead) then return false, "Cette personne n'a pas besoin de réanimation." end
    G.Revive(tid)
    record(c, tp.license, display(tid), 'care', 'Réanimation', 0)
    G.Notify(tid, { type = 'success', title = c.biz.label, text = 'Tu as été réanimé(e) par ' .. display(src) .. '.' })
    TriggerEvent('pb_panel:revivedBy', src, tid)
    return true, display(tid) .. ' est réanimé(e).'
end

-- Garage : réparer le véhicule du client à proximité (le client du mécanicien exécute la réparation sur le véhicule le plus proche)
local lastRepair = {}
ACT.repair = function(c, src, p)
    if not Biz.Allowed(c, 'repair') then return false, "Tu n'as pas le droit de réparer." end
    if not c.duty then return false, 'Prends ton service pour réparer.' end
    local t = now()
    if lastRepair[src] and t - lastRepair[src] < 8 then return false, 'Attends quelques secondes entre deux réparations.' end
    lastRepair[src] = t
    TriggerClientEvent('pb:g:biz:repair', src)
    return true, 'Réparation du véhicule le plus proche en cours.'
end

-- Pages -------------------------------------------------------------------------------------------------------------------------------
local PAGES = {}
Biz.PAGES, Biz.ACT, Biz.Target, Biz.Record, Biz.Display, Biz.Clean = PAGES, ACT, target, record, display, cleanText
Biz.ExtraSettings = {}   -- formulaires de réglages ajoutés par d'autres modules (police, métiers civils…)
Biz.NavAllow = {}   -- id de page -> function(c) : peut-on voir cette page ? (pour les modules qui ajoutent des pages)
Biz.NavLabel = {}   -- id de page -> function(c) : libellé, icône propres à l'entreprise (ex. « Concession », « Soirées et bar »)
local function stat(title, value, icon, tone, sub, extra) local t = { title = title, value = value, icon = icon, tone = tone, sub = sub } for k, v in pairs(extra or {}) do t[k] = v end return t end

local function nearOptions(src, withSelf)
    local opts = {}
    for _, n in ipairs(Biz.Nearby(src)) do opts[#opts + 1] = { tostring(n.id), n.name .. ' (' .. n.id .. ')' } end
    if withSelf then opts[#opts + 1] = { tostring(src), 'Moi-même (' .. src .. ')' } end
    return opts
end

local bizHome, newsBlocks
PAGES.home = function(src)
    local p = G.Get(src)
    local r = p.row
    local c = Biz.Ctx(src)
    if c then return bizHome(src) end   -- employé : uniquement l'entreprise (rien de perso)
    local unpaid = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE license = ? AND status = 'pending'", { p.license })
    local name = display(src)
    local job = c and (c.biz.label .. ' · ' .. c.grade.label) or 'Sans emploi'
    local cards = {
        stat('Compte bancaire', money(r.bank), 'card', '#6fb4ff', 'Solde disponible'),
        stat('Argent liquide', money(r.cash), 'coins', '#7be0a4', 'Espèces sur toi'),
        stat('Factures', tostring(unpaid and unpaid.n or 0), 'file', '#ffb457', (unpaid and unpaid.n or 0) > 0 and (money(unpaid.s) .. ' à régler') or 'Aucune facture en attente'),
        stat('Emploi actuel', c and c.biz.label or 'Sans emploi', 'briefcase', c and c.biz.color or '#9aa3b2', c and (c.grade.label .. (c.duty and ' · en service' or ' · hors service')) or ("Allocation : " .. money(math.floor((G.Eco.Get('unemployed_allowance') or 0) * 1)))),
    }
    local blocks = { { type = 'hero', eyebrow = 'Espace ' .. (c and 'professionnel' or 'citoyen') .. ' · accès sécurisé', title = 'Tableau de bord citoyen', sub = "Retrouve en un coup d'œil ta situation, tes finances, tes factures et les services disponibles en ville.", chips = { { 'Statut', 'Actif' }, { 'ID', tostring(src) }, { 'Emploi', c and c.biz.label or 'aucun' } } },
        { type = 'cards', items = cards },
        { type = 'tiles', title = 'Accès rapides', tag = 'Services citoyens', items = {
            { title = 'Finances', sub = 'Comptes et soldes', icon = 'card', page = 'finance' }, { title = 'Factures', sub = 'Paiements en attente', icon = 'file', page = 'invoices' } } } }
    if c then
        local d = 'Prendre mon service'
        blocks[#blocks + 1] = { type = 'actions', title = 'Mon poste', items = { { act = 'duty', label = c.duty and 'Quitter le service' or 'Prendre mon service', payload = { on = not c.duty }, icon = 'power', primary = not c.duty } } }
    end
    return blocks, 'Bonjour, ' .. name .. '.'
end

PAGES.finance = function(src)
    local p = G.Get(src)
    local cfg = PB.Cfg.All('biz')
    local blocks = { { type = 'cards', items = { stat('Compte bancaire', money(p.row.bank), 'card', '#6fb4ff', 'Solde disponible'), stat('Argent liquide', money(p.row.cash), 'coins', '#7be0a4', 'Espèces sur toi') } } }
    if cfg.allow_transfers then
        blocks[#blocks + 1] = { type = 'form', id = 'transfer', title = 'Virement bancaire', desc = (cfg.transfer_fee or 0) > 0 and ('Frais : ' .. cfg.transfer_fee .. ' %') or 'Sans frais.', fields = {
            { k = 'id', type = 'select', label = 'Destinataire (à proximité)', opts = nearOptions(src) }, { k = 'amount', type = 'number', label = 'Montant', min = 1, max = cfg.transfer_max } },
            submit = { act = 'transfer', label = 'Envoyer' } }
    end
    return blocks, 'Finances'
end

PAGES.invoices = function(src)
    local p = G.Get(src)
    local rows = {}
    for _, i in ipairs(DB.q('SELECT i.*, b.label AS blabel FROM pb_biz_invoices i LEFT JOIN pb_biz b ON b.id = i.biz_id WHERE i.license = ? ORDER BY i.id DESC LIMIT 40', { p.license }) or {}) do
        rows[#rows + 1] = { from = i.blabel or i.biz_id, reason = i.reason, amount = money(i.amount), kind = i.kind == 'fine' and 'Amende' or 'Facture', status = ({ pending = 'À régler', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status,
            actions = i.status == 'pending' and { { act = 'pay_invoice', label = 'Payer', payload = { id = i.id }, primary = true } } or nil }
    end
    return { { type = 'table', title = 'Mes factures et amendes', columns = { { k = 'from', label = 'Émetteur' }, { k = 'kind', label = 'Type' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant' }, { k = 'status', label = 'Statut' } }, rows = rows, empty = 'Aucune facture. Profites-en !' } }, 'Factures'
end

PAGES.directory = function(src)
    local items = {}
    for _, b in ipairs(Biz.List()) do
        if PB.ToBool(b.enabled) then
            local n = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { b.id })
            items[#items + 1] = { title = b.label, sub = KIND_LABEL[b.kind] or 'Entreprise', icon = b.icon, tone = b.color, badge = (G.BizMenu and G.BizMenu.IsOpen(b.id) and 'Ouvert') or (PB.ToBool(b.hiring) and 'Recrute') or nil, text = b.description, stats = { { label = 'Employés', value = tostring(n and n.n or 0) } } }
        end
    end
    return { { type = 'cards', big = true, items = items }, #items == 0 and { type = 'notice', text = "Aucune entreprise pour le moment." } or nil }, 'Entreprises'
end

PAGES.profile = function(src)
    local i = G.Identity(src) or {}
    return { { type = 'hero', title = display(src), sub = 'Carte d\'identité', chips = { { 'Naissance', tostring(i.dob or '—') }, { 'Taille', tostring(i.height or '—') .. ' cm' }, { 'Nationalité', tostring(i.nationality or '—') }, { 'Sexe', i.sex == 'f' and 'Femme' or 'Homme' } } } }, 'Mon profil'
end

-- Pages d'entreprise
function bizHome(src)
    local c = Biz.Ctx(src)
    local acc = acct(c.biz.id)
    local members = Biz.Members(c.biz.id)
    local online, duty = 0, 0
    for _, m in ipairs(members) do for _, pl in pairs(G.Players()) do if pl.license == m.license then online = online + 1 if PB.ToBool(m.on_duty) then duty = duty + 1 end end end end
    local pend = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'pending'", { c.biz.id })
    local week = DB.one("SELECT COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'paid' AND paid_at >= ?", { c.biz.id, now() - 7 * 86400 })
    local bal = G.Eco.Balance(acc)
    local cards = {
        stat('Caisse', money(bal), 'coins', c.biz.color, 'Compte de l\'entreprise'),
        stat('Employés', tostring(#members), 'users', '#6fb4ff', ('%d en ligne · %d en service'):format(online, duty)),
        stat('Factures en attente', tostring(pend and pend.n or 0), 'file', '#ffb457', money(pend and pend.s or 0) .. ' à encaisser'),
        stat('Encaissé (7 jours)', money(week and week.s or 0), 'chart', '#7be0a4', 'Factures et amendes réglées'),
    }
    if c.biz.kind == 'police' or c.biz.kind == 'ems' then
        local calls = DB.one("SELECT COUNT(*) AS n FROM pb_calls WHERE status <> 'closed'")
        cards[#cards + 1] = stat('Appels ouverts', tostring(calls and calls.n or 0), 'siren', '#ffb457', 'À traiter par les unités')
        if c.biz.kind == 'police' then
            local jl = DB.one('SELECT COUNT(*) AS n FROM pb_jail')
            local fines = DB.one("SELECT COUNT(*) AS n FROM pb_biz_records WHERE biz_id = ? AND kind = 'fine' AND at >= ?", { c.biz.id, now() - 7 * 86400 })
            cards[#cards + 1] = stat('Détenus', tostring(jl and jl.n or 0), 'shield', '#ff6b7d', 'Prison et TIG')
            cards[#cards + 1] = stat('Amendes (7 jours)', tostring(fines and fines.n or 0), 'file', '#6fb4ff', 'Verbalisations du service')
        end
    end
    local mine = c.grade.salary * (G.Eco.Get('income_mult') or 1)
    local tax = mine * (G.Eco.Get('tax_income') or 0) / 100
    local blocks = { { type = 'hero', title = c.biz.label, sub = c.biz.description ~= '' and c.biz.description or (KIND_LABEL[c.biz.kind] or ''), chips = { { 'Mon grade', c.grade.label }, { 'Service', c.duty and 'En service' or 'Hors service' }, { 'Paie nette', money(mine - tax) .. ' / ' .. (G.Eco.Get('paycheck_interval') or 15) .. ' min' } }, tone = c.biz.color },
        { type = 'cards', items = cards },
        { type = 'actions', title = 'Mon service', items = { { act = 'duty', label = c.duty and 'Quitter le service' or 'Prendre mon service', payload = { on = not c.duty }, icon = 'power', primary = not c.duty } } } }
    for _, b in ipairs(newsBlocks(c)) do blocks[#blocks + 1] = b end
    if Biz.Allowed(c, 'repair') then blocks[#blocks + 1] = { type = 'actions', title = 'Atelier', items = { { act = 'repair', label = 'Réparer le véhicule le plus proche', icon = 'engine', primary = true } } } end
    return blocks, c.biz.label
end
PAGES.biz = function(src) if not Biz.Ctx(src) then return nil end return bizHome(src) end

PAGES.staff = function(src)
    local c = Biz.Ctx(src)
    if not c or not (Biz.Can(c, 'hire') or Biz.Can(c, 'fire') or Biz.Can(c, 'promote')) then return nil end
    local rows = {}
    local online = {}
    for id, pl in pairs(G.Players()) do online[pl.license] = id end
    local dt = Biz.DutyTimes(c.biz.id)
    for _, m in ipairs(Biz.Members(c.biz.id)) do
        local g = Biz.Grade(c.biz.id, m.grade)
        local acts = {}
        local d = dt[m.license] or {}
        if m.license ~= c.license then
            if Biz.Can(c, 'promote') then acts[#acts + 1] = { act = 'promote', label = 'Promouvoir', payload = { license = m.license } } acts[#acts + 1] = { act = 'demote', label = 'Rétrograder', payload = { license = m.license } } end
            if Biz.Can(c, 'fire') then acts[#acts + 1] = { act = 'fire', label = 'Renvoyer', payload = { license = m.license }, danger = true, confirm = 'Renvoyer ' .. m.name .. ' ?' } end
        end
        rows[#rows + 1] = { name = m.name, grade = g and g.label or m.grade, state = online[m.license] and (PB.ToBool(m.on_duty) and 'En service' or 'En ligne') or 'Hors ligne', salary = g and money(g.salary) or '—',
            week = Biz.FmtDuty(d.week), total = Biz.FmtDuty(d.total), actions = acts }
    end
    local blocks = { { type = 'table', title = 'Employés', columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'state', label = 'Statut' }, { k = 'week', label = 'Service (7 j)' }, { k = 'total', label = 'Service (total)' }, { k = 'salary', label = 'Salaire' } }, rows = rows, empty = 'Aucun employé.' } }
    if c.boss then blocks[#blocks + 1] = { type = 'actions', title = 'Temps de service', items = { { act = 'duty_reset', label = 'Remettre les compteurs à zéro', icon = 'refresh', danger = true, confirm = 'Remettre à zéro le temps de service de toute l\'équipe ?' } } } end
    if Biz.Can(c, 'hire') then
        local opts = {}
        for _, n in ipairs(Biz.Nearby(src)) do if not Biz.MemberOf(n.license) then opts[#opts + 1] = { tostring(n.id), n.name .. ' (' .. n.id .. ')' } end end
        blocks[#blocks + 1] = { type = 'form', id = 'hire', title = 'Engager quelqu\'un', desc = 'Seules les personnes sans emploi, à proximité, apparaissent ici.', fields = { { k = 'id', type = 'select', label = 'Personne', opts = opts } }, submit = { act = 'hire', label = 'Engager', disabled = #opts == 0 } }
    end
    return blocks, 'Employés'
end

PAGES.grades = function(src)
    local c = Biz.Ctx(src)
    if not c or not c.boss then return nil end
    local items = {}
    local gs = Biz.Grades(c.biz.id)
    for _, g in ipairs(gs) do
        local names = {}
        for k in tostring(g.perms or ''):gmatch('[%a_]+') do names[#names + 1] = PERM_LABEL[k] or k end
        items[#items + 1] = { title = g.label, sub = 'Grade ' .. g.grade .. (PB.ToBool(g.boss) and ' · patron' or ''), icon = PB.ToBool(g.boss) and 'crown' or 'user', tone = c.biz.color, value = money(g.salary), text = 'Droits : ' .. (PB.ToBool(g.boss) and 'tous' or (#names > 0 and table.concat(names, ', ') or 'aucun')) }
    end
    local opts, plain, pos = {}, {}, { { 'bottom', 'Tout en bas (nouvelles recrues)' } }
    for _, g in ipairs(gs) do
        opts[#opts + 1] = { tostring(g.grade), g.label }
        if not PB.ToBool(g.boss) then plain[#plain + 1] = { tostring(g.grade), g.label } pos[#pos + 1] = { tostring(g.grade), 'Au-dessus de « ' .. g.label .. ' »' } end
    end
    local permItems, permGrades = {}, {}
    for _, k in ipairs(bizPerms(c)) do permItems[#permItems + 1] = { k = k, label = PERM_LABEL[k] or k, desc = PERM_DESC[k] } end
    for _, g in ipairs(gs) do
        local on = {}
        for k in tostring(g.perms or ''):gmatch('[%a_]+') do on[k] = true end
        permGrades[#permGrades + 1] = { id = tostring(g.grade), label = g.label, locked = PB.ToBool(g.boss) or nil, perms = on }
    end
    local permsBlock = { type = 'perms', id = 'biz', title = "Droits des grades", desc = 'Choisis un grade, puis coche ce qu\'il a le droit de faire.', act = 'grade_perm', lockedText = 'Le patron a tous les droits.', grades = permGrades, items = permItems }
    return { { type = 'cards', items = items },
        { type = 'form', id = 'g_add', title = 'Créer un grade', desc = ('%d / %d grades. Il démarre sans droit : règle-les ensuite.'):format(#gs, MAX_GRADES),
            fields = { { k = 'label', type = 'text', label = 'Nom du grade', maxlen = 40 }, { k = 'salary', type = 'number', label = 'Salaire', min = 0, max = salaryMax(c) }, { k = 'after', type = 'select', label = 'Position', opts = pos } },
            submit = { act = 'grade_add', label = 'Créer le grade', disabled = #gs >= MAX_GRADES } },
        permsBlock,
        { type = 'form', id = 'salary', title = 'Modifier un salaire', desc = ("Salaire de base par paie, avant le multiplicateur de l'économie (×%s) et l'impôt."):format(tostring(G.Eco.Get('income_mult'))),
            fields = { { k = 'grade', type = 'select', label = 'Grade', opts = opts }, { k = 'salary', type = 'number', label = 'Salaire', min = 0, max = salaryMax(c) } }, submit = { act = 'set_salary', label = 'Enregistrer' } },
        { type = 'form', id = 'g_ren', title = 'Renommer un grade', fields = { { k = 'grade', type = 'select', label = 'Grade', opts = opts }, { k = 'label', type = 'text', label = 'Nouveau nom', maxlen = 40 } }, submit = { act = 'grade_rename', label = 'Renommer' } },
        { type = 'form', id = 'g_del', title = 'Supprimer un grade', desc = 'Ses employés passent au grade du dessous.', fields = { { k = 'grade', type = 'select', label = 'Grade', opts = plain } }, submit = { act = 'grade_del', label = 'Supprimer', disabled = #gs <= 2 or #plain == 0 } } }, 'Grades et salaires'
end

PAGES.vault = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'vault') then return nil end
    local rows = {}
    for _, r in ipairs(DB.q('SELECT at, delta, reason FROM pb_ledger WHERE account = ? ORDER BY id DESC LIMIT 30', { acct(c.biz.id) }) or {}) do rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at), delta = (r.delta > 0 and '+' or '') .. money(r.delta), reason = r.reason } end
    return { { type = 'cards', items = { stat('Caisse', money(G.Eco.Balance(acct(c.biz.id))), 'coins', c.biz.color, 'Compte de l\'entreprise') } },
        { type = 'form', id = 'dep', title = 'Déposer des espèces', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 10000000 } }, submit = { act = 'deposit', label = 'Déposer' } },
        { type = 'form', id = 'wd', title = 'Retirer des espèces', fields = { { k = 'amount', type = 'number', label = 'Montant', min = 1, max = 10000000 } }, submit = { act = 'withdraw', label = 'Retirer' } },
        { type = 'table', title = 'Mouvements récents', columns = { { k = 'at', label = 'Date' }, { k = 'delta', label = 'Montant' }, { k = 'reason', label = 'Motif' } }, rows = rows, empty = 'Aucun mouvement.' } }, 'Caisse'
end

PAGES.bills = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'invoice') then return nil end
    local rows = {}
    for _, i in ipairs(DB.q('SELECT * FROM pb_biz_invoices WHERE biz_id = ? ORDER BY id DESC LIMIT 40', { c.biz.id }) or {}) do
        rows[#rows + 1] = { who = i.name, reason = i.reason, amount = money(i.amount), by = i.by_name, status = ({ pending = 'En attente', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status,
            actions = i.status == 'pending' and { { act = 'cancel_invoice', label = 'Annuler', payload = { id = i.id }, danger = true } } or nil }
    end
    local blocks = {}
    if Biz.Allowed(c, 'invoice') then
        blocks[#blocks + 1] = { type = 'form', id = 'inv', title = 'Nouvelle facture', desc = c.duty and 'Choisis un client à proximité.' or 'Prends ton service pour facturer.', fields = {
            { k = 'id', type = 'select', label = 'Client (à proximité)', opts = nearOptions(src) }, { k = 'amount', type = 'number', label = 'Montant', min = 1, max = PB.Cfg.Get('biz', 'max_invoice', 50000) }, { k = 'reason', type = 'text', label = 'Motif', maxlen = 120 } },
            submit = { act = 'invoice', label = 'Envoyer la facture' } }
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Factures émises', columns = { { k = 'who', label = 'Client' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant' }, { k = 'by', label = 'Par' }, { k = 'status', label = 'Statut' } }, rows = rows, empty = 'Aucune facture émise.' }
    return blocks, 'Factures émises'
end

PAGES.citizens = function(src)
    local c = Biz.Ctx(src)
    if not c or not (Biz.Allowed(c, 'fine') or Biz.Allowed(c, 'records')) then return nil end
    local blocks = {}
    if Biz.Allowed(c, 'fine') then
        local codes = { { 'custom', 'Autre (montant libre)' } }
        for _, f in ipairs(DB.q('SELECT code, label, amount FROM pb_fines ORDER BY category, label') or {}) do codes[#codes + 1] = { f.code, ('%s — %s'):format(f.label, money(G.Eco.Fine(f.amount))) } end
        blocks[#blocks + 1] = { type = 'form', id = 'fine', title = 'Infliger une amende', desc = c.duty and "Le montant du catalogue tient compte du multiplicateur d'amendes de l'économie." or 'Prends ton service pour verbaliser.', fields = {
            { k = 'id', type = 'select', label = 'Citoyen (à proximité)', opts = nearOptions(src) }, { k = 'code', type = 'select', label = 'Infraction', opts = codes },
            { k = 'amount', type = 'number', label = 'Montant (si libre)', min = 0, max = PB.Cfg.Get('biz', 'max_fine', 25000) }, { k = 'reason', type = 'text', label = 'Motif (si libre)', maxlen = 120 } },
            submit = { act = 'fine', label = 'Verbaliser' } }
    end
    if Biz.Allowed(c, 'records') then
        blocks[#blocks + 1] = { type = 'form', id = 'note', title = 'Ajouter une note au dossier', fields = { { k = 'id', type = 'select', label = 'Citoyen (à proximité)', opts = nearOptions(src, true) }, { k = 'text', type = 'text', label = 'Note', maxlen = 240 } }, submit = { act = 'note', label = 'Ajouter' } }
        local rows = {}
        for _, r in ipairs(DB.q('SELECT * FROM pb_biz_records WHERE biz_id = ? ORDER BY id DESC LIMIT 40', { c.biz.id }) or {}) do
            rows[#rows + 1] = { who = r.name, kind = ({ fine = 'Amende', note = 'Note', care = 'Soin', repair = 'Réparation', cuff = 'Arrestation', search = 'Fouille', seize = 'Saisie' })[r.kind] or r.kind, text = r.text, amount = r.amount > 0 and money(r.amount) or '', by = r.by_name, at = os.date('%d/%m %H:%M', r.at) }
        end
        blocks[#blocks + 1] = { type = 'table', title = 'Dossiers récents', columns = { { k = 'at', label = 'Date' }, { k = 'who', label = 'Citoyen' }, { k = 'kind', label = 'Type' }, { k = 'text', label = 'Détail' }, { k = 'amount', label = 'Montant' }, { k = 'by', label = 'Par' } }, rows = rows, empty = 'Aucun dossier.' }
    end
    return blocks, c.biz.kind == 'police' and 'Citoyens et amendes' or 'Dossiers'
end
PAGES.patients = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Allowed(c, 'revive') then return nil end
    local rows = {}
    for _, n in ipairs(Biz.Nearby(src, 30)) do
        local pl = G.Get(n.id)
        local dead = pl and PB.ToBool(pl.row.dead)
        rows[#rows + 1] = { name = n.name, state = dead and 'À terre' or 'Conscient', dist = math.floor(distance(src, n.id)) .. ' m', actions = dead and { { act = 'revive', label = 'Réanimer', payload = { id = n.id }, primary = true } } or nil }
    end
    local dead = 0
    for _, pl in pairs(G.Players()) do if PB.ToBool(pl.row.dead) then dead = dead + 1 end end
    return { { type = 'cards', items = { stat('Patients à terre', tostring(dead), 'heart', '#ff6b7d', 'Sur tout le serveur') } },
        { type = 'table', title = 'Personnes à proximité (30 m)', columns = { { k = 'name', label = 'Nom' }, { k = 'state', label = 'État' }, { k = 'dist', label = 'Distance' } }, rows = rows, empty = 'Personne à proximité.' } }, 'Patients'
end

-- Pages complémentaires : équipe, journal, statistiques, annonces, paie, règlement, lieux ------------------------------------------------
PB.Migrate('190_biz_news', 'Annonces internes des entreprises', {
    [[CREATE TABLE IF NOT EXISTS pb_biz_news (id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, text VARCHAR(240) NOT NULL, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_biz (biz_id))]],
})
local function isOnline(license) for src, pl in pairs(G.Players()) do if pl.license == license then return src end end end
Biz.NavAllow.team = function(c) return true end
Biz.NavAllow.news = function(c) return true end
Biz.NavAllow.rules = function(c) return true end
Biz.NavAllow.places = function(c) return true end
Biz.NavAllow.journal = function(c) return Biz.Can(c, 'vault') end
Biz.NavAllow.stats = function(c) return Biz.Can(c, 'vault') end
Biz.NavAllow.payroll = function(c) return c.boss == true end

PAGES.team = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local rows, online, duty = {}, 0, 0
    for _, m in ipairs(Biz.Members(c.biz.id)) do
        local on = isOnline(m.license)
        if on then online = online + 1 end
        if PB.ToBool(m.on_duty) then duty = duty + 1 end
        local g = Biz.Grade(c.biz.id, m.grade)
        rows[#rows + 1] = { name = m.name, grade = g and g.label or tostring(m.grade), state = PB.ToBool(m.on_duty) and 'En service' or (on and 'En ligne' or 'Hors ligne'), since = os.date('%d/%m/%Y', m.hired_at or 0) }
    end
    return { { type = 'cards', items = { stat('Effectif', tostring(#rows), 'users', c.biz.color, 'Employés au total'), stat('En ligne', tostring(online), 'user', '#6fb4ff', 'Connectés maintenant'), stat('En service', tostring(duty), 'power', '#7be0a4', 'Services pris') } },
        { type = 'table', title = "Équipe de l'entreprise", search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'grade', label = 'Grade' }, { k = 'state', label = 'État', type = 'badge' }, { k = 'since', label = 'Embauché le' } }, rows = rows, empty = 'Aucun employé.' } }, 'Équipe'
end

PAGES.journal = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'vault') then return nil end
    local rows = {}
    for _, i in ipairs(DB.q('SELECT * FROM pb_biz_invoices WHERE biz_id = ? ORDER BY id DESC LIMIT 40', { c.biz.id }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', i.at or 0), kind = i.kind == 'fine' and 'Amende' or 'Facture', who = i.name, by = i.by_name, amount = money(i.amount), status = ({ pending = 'En attente', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status, t = i.at or 0 }
    end
    for _, r in ipairs(DB.q('SELECT * FROM pb_biz_records WHERE biz_id = ? ORDER BY id DESC LIMIT 20', { c.biz.id }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', r.at or 0), kind = 'Dossier', who = r.name, by = r.by_name, amount = r.amount > 0 and money(r.amount) or '', status = r.text, t = r.at or 0 }
    end
    table.sort(rows, function(a, b) return a.t > b.t end)
    return { { type = 'table', title = "Journal d'activité", search = true, columns = { { k = 'at', label = 'Date' }, { k = 'kind', label = 'Type' }, { k = 'who', label = 'Client' }, { k = 'by', label = 'Par' }, { k = 'amount', label = 'Montant' }, { k = 'status', label = 'Détail' } }, rows = rows, empty = 'Aucune activité.' } }, 'Journal'
end

PAGES.stats = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'vault') then return nil end
    local day = 86400
    local rows, total = {}, 0
    for d = 0, 6 do
        local from, to = now() - (d + 1) * day, now() - d * day
        local r = DB.one("SELECT COALESCE(SUM(amount), 0) AS s, COUNT(*) AS n FROM pb_biz_invoices WHERE biz_id = ? AND status = 'paid' AND paid_at >= ? AND paid_at < ?", { c.biz.id, from, to })
        total = total + (r and tonumber(r.s) or 0)
        rows[#rows + 1] = { day = d == 0 and "Dernières 24 h" or ('Il y a ' .. d .. ' j'), n = tostring(r and r.n or 0), amount = money(r and r.s or 0) }
    end
    local top = {}
    for _, r in ipairs(DB.q("SELECT by_name, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'paid' GROUP BY by_name ORDER BY s DESC LIMIT 10", { c.biz.id }) or {}) do
        top[#top + 1] = { name = r.by_name, n = tostring(r.n), amount = money(r.s) }
    end
    local pend = DB.one("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM pb_biz_invoices WHERE biz_id = ? AND status = 'pending'", { c.biz.id })
    return { { type = 'cards', items = { stat('Encaissé (7 jours)', money(total), 'chart', '#7be0a4', 'Factures et amendes réglées'), stat('En attente', money(pend and pend.s or 0), 'file', '#ffb457', (pend and pend.n or 0) .. ' facture(s)'), stat('Caisse', money(G.Eco.Balance(acct(c.biz.id))), 'coins', c.biz.color, 'Compte de l\'entreprise') } },
        { type = 'table', title = 'Encaissements par jour', columns = { { k = 'day', label = 'Période' }, { k = 'n', label = 'Paiements' }, { k = 'amount', label = 'Montant' } }, rows = rows },
        { type = 'table', title = 'Meilleurs employés (encaissé)', columns = { { k = 'name', label = 'Employé' }, { k = 'n', label = 'Paiements' }, { k = 'amount', label = 'Montant' } }, rows = top, empty = 'Aucun paiement.' } }, 'Statistiques'
end

function newsBlocks(c)
    local rows = {}
    for _, n in ipairs(DB.q('SELECT * FROM pb_biz_news WHERE biz_id = ? ORDER BY id DESC LIMIT 8', { c.biz.id }) or {}) do rows[#rows + 1] = { at = os.date('%d/%m %H:%M', n.at or 0), by = n.by_name, text = n.text } end
    local blocks = {}
    if Biz.Can(c, 'promote') then
        blocks[#blocks + 1] = { type = 'form', id = 'news', title = 'Publier une annonce', desc = "Elle s'affiche à tous les employés connectés et reste dans la liste.", fields = { { k = 'text', type = 'text', label = 'Message', maxlen = 240 } }, submit = { act = 'announce', label = 'Publier' } }
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Annonces', columns = { { k = 'at', label = 'Date' }, { k = 'by', label = 'Par' }, { k = 'text', label = 'Message' } }, rows = rows, empty = 'Aucune annonce.' }
    return blocks
end
PAGES.news = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    return newsBlocks(c), 'Annonces'
end
ACT.announce = function(c, src, p)
    if not Biz.Can(c, 'promote') then return false, 'Réservé à la direction.' end
    local text = tostring(p.text or ''):gsub('[%c<>]', ''):sub(1, 240)
    if #text < 3 then return false, 'Message trop court.' end
    DB.exec('INSERT INTO pb_biz_news (biz_id, text, by_name, at) VALUES (?, ?, ?, ?)', { c.biz.id, text, display(src), now() })
    for _, m in ipairs(Biz.Members(c.biz.id)) do
        local on = isOnline(m.license)
        if on then G.Notify(on, { type = 'info', title = c.biz.label, text = text, duration = 9000 }) end
    end
    PB.Audit.Log('serveur', 'biz.announce', src, c.biz.id, nil, nil, { text = text })
    return true, 'Annonce publiée.'
end

PAGES.payroll = function(src)
    local c = Biz.Ctx(src)
    if not c or not c.boss then return nil end
    local mult = G.Eco.Get('income_mult') or 1
    local members = Biz.Members(c.biz.id)
    local per, rows, total = {}, {}, 0
    for _, m in ipairs(members) do per[m.grade] = (per[m.grade] or 0) + 1 end
    for _, g in ipairs(Biz.Grades(c.biz.id)) do
        local n = per[g.grade] or 0
        local sub = n * g.salary * mult
        total = total + sub
        rows[#rows + 1] = { grade = g.label, n = tostring(n), salary = money(g.salary * mult), total = money(sub) }
    end
    local interval = G.Eco.Get('paycheck_interval') or 15
    return { { type = 'cards', items = { stat('Masse salariale', money(total), 'coins', c.biz.color, ('par paie, toutes les %s min'):format(tostring(interval))), stat('Caisse', money(G.Eco.Balance(acct(c.biz.id))), 'bank', '#7be0a4', c.biz.pay_from == 'society' and "Paie prélevée sur la caisse" or "Paie versée par l'État"),
            stat('Employés', tostring(#members), 'users', '#6fb4ff', 'Payés selon leur grade') } },
        { type = 'table', title = 'Paie par grade (avant impôt)', columns = { { k = 'grade', label = 'Grade' }, { k = 'n', label = 'Employés' }, { k = 'salary', label = 'Salaire' }, { k = 'total', label = 'Total' } }, rows = rows } }, 'Paie'
end

PAGES.rules = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local PERM = { hire = 'Engager', fire = 'Renvoyer', promote = 'Promouvoir', vault = 'Caisse', invoice = 'Facturer', fine = 'Amendes', revive = 'Réanimer', repair = 'Réparer', records = 'Dossiers', cuff = 'Menotter', search = 'Fouiller', seize = 'Saisir', jail = 'Prison', dispatch = 'Appels' }
    local rows = {}
    for _, g in ipairs(Biz.Grades(c.biz.id)) do
        local list = {}
        if g.boss then list[1] = 'Tous les droits' else for _, k in ipairs(ALL_PERMS) do if g.perms and tostring(g.perms):find(k, 1, true) then list[#list + 1] = PERM[k] end end end
        rows[#rows + 1] = { grade = g.label, salary = money(g.salary), perms = #list > 0 and table.concat(list, ', ') or 'Service de base' }
    end
    local kind = c.biz.kind
    local TIPS = { police = "Prends ton service avant d'agir. Toute amende, fouille ou saisie est consignée dans les dossiers.", ems = 'Prends ton service. Réanime les patients à terre, tout soin est consigné dans les dossiers.', garage = 'Prends ton service pour facturer. Répare les véhicules à proximité.', generic = "Prends ton service pour facturer tes clients. Le patron gère les grades et la caisse." }
    return { { type = 'notice', text = TIPS[kind] or TIPS.generic }, { type = 'table', title = 'Grades, salaires et droits', columns = { { k = 'grade', label = 'Grade' }, { k = 'salary', label = 'Salaire' }, { k = 'perms', label = 'Droits' } }, rows = rows } }, 'Règlement'
end

PAGES.places = function(src)
    local c = Biz.Ctx(src)
    if not c then return nil end
    local KIND = { hq = 'Siège', duty = 'Prise de service', boss = 'Bureau du patron', stash = 'Coffre', garage = 'Garage', wardrobe = 'Vestiaire' }
    local rows = {}
    for _, pt in ipairs(G.Points and G.Points.Of('biz', c.biz.id) or {}) do
        rows[#rows + 1] = { name = pt.label ~= '' and pt.label or (KIND[pt.kind] or pt.kind), kind = KIND[pt.kind] or pt.kind, actions = { { label = 'GPS', act = 'gps', payload = { id = pt.id }, icon = 'pin' } } }
    end
    return { { type = 'table', title = "Lieux de l'entreprise", columns = { { k = 'name', label = 'Lieu' }, { k = 'kind', label = 'Type' } }, rows = rows, empty = "Aucun lieu n'est placé (Carte du jeu, dans le panel)." } }, 'Lieux'
end
ACT.gps = function(c, src, p)
    local pt = DB.one("SELECT x, y, label, owner FROM pb_points WHERE id = ? AND owner_kind = 'biz'", { math.floor(tonumber(p.id) or 0) })
    if not pt or pt.owner ~= c.biz.id then return false, 'Lieu inconnu.' end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = pt.x, y = pt.y, label = pt.label }))
    return true, 'Position marquée sur ta carte.'
end

local PAGE_META = {
    home = { label = 'Accueil', icon = 'home', group = 'Citoyen' }, finance = { label = 'Finances', icon = 'card', group = 'Citoyen' }, invoices = { label = 'Factures', icon = 'file', group = 'Citoyen' },
    directory = { label = 'Entreprises', icon = 'building', group = 'Citoyen' }, profile = { label = 'Mon profil', icon = 'user', group = 'Citoyen' },
    biz = { label = 'Mon entreprise', icon = 'briefcase', group = 'Entreprise' }, staff = { label = 'Employés', icon = 'users', group = 'Entreprise' }, grades = { label = 'Grades et salaires', icon = 'crown', group = 'Entreprise' },
    vault = { label = 'Caisse', icon = 'coins', group = 'Entreprise' }, bills = { label = 'Factures émises', icon = 'file', group = 'Entreprise' },
    citizens = { label = 'Citoyens', icon = 'shield', group = 'Entreprise' }, patients = { label = 'Patients', icon = 'heart', group = 'Entreprise' },
    team = { label = 'Équipe', icon = 'users', group = 'Entreprise' }, news = { label = 'Annonces', icon = 'chat', group = 'Entreprise' }, journal = { label = 'Journal', icon = 'file', group = 'Entreprise' },
    stats = { label = 'Statistiques', icon = 'chart', group = 'Entreprise' }, payroll = { label = 'Paie', icon = 'coins', group = 'Entreprise' }, rules = { label = 'Règlement', icon = 'book', group = 'Entreprise' }, places = { label = 'Lieux', icon = 'pin', group = 'Entreprise' },
}
local ORDER = { 'home', 'finance', 'invoices', 'biz', 'staff', 'grades', 'vault', 'bills', 'citizens', 'patients', 'team', 'stats', 'journal', 'payroll', 'rules', 'places' }
Biz.PAGE_META, Biz.ORDER = PAGE_META, ORDER

-- Gestion (menu boss) : seulement au bureau du patron (point « boss » posé au Builder), plus depuis la tablette n'importe où
local BOSS_PAGES = { staff = true, grades = true, vault = true, payroll = true, journal = true, stats = true }
local BOSS_ACTS = { duty_reset = true, hire = true, fire = true, promote = true, demote = true, set_salary = true, deposit = true, withdraw = true, grade_add = true, grade_rename = true, grade_del = true, grade_perm = true }
Biz.BOSS_PAGES, Biz.BOSS_ACTS = BOSS_PAGES, BOSS_ACTS
function Biz.AtBoss(src, c)
    c = c or Biz.Ctx(src)
    if not c then return false end
    return not (G.Points and G.Points.AtBoss) or G.Points.AtBoss(src, 'biz', c.biz.id)
end
local BOSS_MSG = "Gestion de l'entreprise : rends-toi au bureau du patron."

local function navFor(src)
    local c = Biz.Ctx(src)
    local atBoss = c and Biz.AtBoss(src, c)
    local nav = {}
    for _, id in ipairs(ORDER) do
        local m = PAGE_META[id]
        local ok = true
        local grp = m.group
        if c and id == 'biz' then ok = false   -- doublon du tableau de bord
        elseif c and (id == 'finance' or id == 'invoices') then grp = 'Mon espace'   -- un employé garde ses pages perso (factures à payer, virement…)
        elseif id == 'home' and c then grp = 'Entreprise'
        elseif id == 'biz' then ok = c ~= nil
        elseif id == 'staff' then ok = c ~= nil and (Biz.Can(c, 'hire') or Biz.Can(c, 'fire') or Biz.Can(c, 'promote'))
        elseif id == 'grades' then ok = c ~= nil and c.boss
        elseif id == 'vault' then ok = c ~= nil and Biz.Can(c, 'vault')
        elseif id == 'bills' then ok = c ~= nil and Biz.Can(c, 'invoice')
        elseif id == 'citizens' then ok = c ~= nil and (Biz.Allowed(c, 'fine') or Biz.Allowed(c, 'records'))
        elseif id == 'patients' then ok = c ~= nil and Biz.Allowed(c, 'revive')
        elseif Biz.NavAllow[id] then ok = c ~= nil and Biz.NavAllow[id](c) == true
        elseif PAGE_META[id].group == 'Entreprise' then ok = c ~= nil end   -- équipe, annonces, règlement, lieux… : pas pour un citoyen sans entreprise
        if ok and BOSS_PAGES[id] and not atBoss then ok = false end
        if ok then
            local label = m.label
            if id == 'home' and c then label = 'Accueil' end
            if id == 'citizens' and c and c.biz.kind ~= 'police' then label = 'Dossiers' end
            local icon = m.icon
            if c and Biz.NavLabel[id] then local l, i = Biz.NavLabel[id](c) label, icon = l or label, i or icon end
            nav[#nav + 1] = { id = id, label = label, icon = icon, group = grp, img = PB.Cfg.Get('tablets', 'img_' .. id, '') }
        end
    end
    return nav
end

function Biz.Page(src, page)
    local fn = PAGES[page or 'home']
    if not fn then return nil, 'Page inconnue.' end
    if BOSS_PAGES[page] and not Biz.AtBoss(src) then return nil, BOSS_MSG end
    local blocks, title = fn(src)
    if not blocks then return nil, 'Accès refusé.' end
    local clean = {}
    for _, b in ipairs(blocks) do if b then clean[#clean + 1] = b end end
    return { page = page or 'home', title = title, blocks = clean }
end

function Biz.Frame(src)
    local c = Biz.Ctx(src)
    local p = G.Get(src)
    return { name = display(src), id = (G.UidOf(src) or src), nav = navFor(src), tone = c and c.biz.color or '#dfe2e7', biz = c and { label = c.biz.label, kind = c.biz.kind, grade = c.grade.label, duty = c.duty, boss = c.boss } or nil,
        brand = PB.Cfg.Get('general', 'server_name', ''), title = PB.Cfg.Get('general', 'server_name', ''), subtitle = c and ('Espace entreprise · ' .. c.biz.label) or 'Espace citoyen', icon = 'briefcase', cash = p and p.row.cash or 0, bank = p and p.row.bank or 0 }
end

-- Réseau --------------------------------------------------------------------------------------------------------------------------------
local lastReq = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 if lastReq[src] and t - lastReq[src] < ms then return false end lastReq[src] = t return true end

local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end

-- (v1.2.43) chaque point ouvre sa propre page par-dessus le menu : bureau du patron -> gestion, accueil -> factures, siège -> tableau de bord
local FOCUS = { boss = { { 'staff', 'Employés' }, { 'grades', 'Grades et salaires' }, { 'vault', 'Caisse' } }, desk = { { 'bills', 'Factures émises' } } }
function Biz.FocusFor(src, where)
    for _, f in ipairs(FOCUS[tostring(where or '')] or {}) do
        local pg = Biz.Page(src, f[1])
        if pg then return { page = pg, label = f[2] } end
    end
    return nil
end
-- Tablette de l'entreprise (même fenêtre que la banque) : ouverte seulement depuis un point du siège / bureau du patron (server/game/points.lua)
function Biz.OpenTablet(src, where)
    if G.DutyGate and G.DutyGate(src) then return end
    if not usable(src) or not throttle(src, 400) then return end
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'open', tablet = true, frame = Biz.Frame(src), page = Biz.Page(src, 'home'), focus = Biz.FocusFor(src, where) }))
end
RegisterNetEvent('pb:g:biz:open', function(where)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    if PB.Cfg.Get('tablets', 'hq_only', true) ~= false and Biz.Ctx(src) then
        G.Notify(src, { type = 'info', title = 'Entreprise', text = "La tablette de l'entreprise s'ouvre au siège : va au point de ton entreprise et appuie sur E." })
        return
    end
    local page = Biz.Page(src, 'home')
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'open', frame = Biz.Frame(src), page = page, focus = Biz.FocusFor(src, where) }))
end)

RegisterNetEvent('pb:g:biz:page', function(page)
    local src = source
    if not usable(src) or not throttle(src, 150) then return end
    local data, err = Biz.Page(src, tostring(page))
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'page', frame = Biz.Frame(src), page = data, err = err }))
end)

function Biz.Act(src, name, payload, page)
    local fn = ACT[tostring(name)]
    if not fn then return false, 'Action inconnue.' end
    if type(payload) ~= 'table' then payload = {} end
    local citizen = (name == 'pay_invoice' or name == 'transfer')
    local c = Biz.Ctx(src)
    if not citizen and not c then return false, "Tu n'as pas d'entreprise." end
    if BOSS_ACTS[name] and not Biz.AtBoss(src, c) then return false, BOSS_MSG end
    local ok, msg = fn(c, src, payload)
    return ok, msg
end

RegisterNetEvent('pb:g:biz:act', function(name, payload, page)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usable(src) or not throttle(src, 250) then return end
    local ok, msg = Biz.Act(src, name, payload, page)
    local data = Biz.Page(src, tostring(page or 'home'))
    TriggerClientEvent('pb:g:biz:ui', src, PB.Json({ ev = 'result', ok = ok and true or false, msg = msg, frame = Biz.Frame(src), page = data }))
end)

-- Paie ---------------------------------------------------------------------------------------------------------------------------------------
local lastPay = os.time()
-- (v1.2.43) une paie demande d'avoir été là au moins la moitié de la période : se connecter une minute avant la paie ne rapporte plus un salaire entier
local joinedAt = {}
Biz._joined = joinedAt
table.insert(G.beginHooks, function(src) joinedAt[src] = os.time() end)
AddEventHandler('playerDropped', function() joinedAt[source] = nil end)
function Biz.PayTick()
    local eco = G.Eco
    local paid, skipped = 0, 0
    local offDuty = PB.Cfg.Get('biz', 'pay_off_duty', false)
    local half = (tonumber(eco.Get('paycheck_interval')) or 15) * 30
    for src, p in pairs(G.Players()) do
        if PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and os.time() - (joinedAt[src] or 0) >= half then
            local c = Biz.Ctx(src)
            local gross, source
            if c then
                if c.duty or offDuty then
                    gross = math.floor(c.grade.salary * eco.Get('income_mult') * (G.PayMult and G.PayMult() or 1) + 0.5)   -- bonus de paie (événement)
                    source = c.biz.pay_from or 'free'
                end
            else
                gross = math.floor(eco.Get('unemployed_allowance') + 0.5)
                source = 'state_allow'
            end
            if gross and gross > 0 then
                local tax = c and math.floor(gross * eco.Get('tax_income') / 100 + 0.5) or 0
                local net = gross - tax
                local ok = true
                if source == 'society' then
                    if eco.Balance(acct(c.biz.id)) < gross then ok = false else eco.Book(acct(c.biz.id), -gross, 'Salaire ' .. display(src), p.license) end
                elseif source == 'free' then
                    eco.Book('salaires', -gross, 'Salaire ' .. c.biz.id, p.license)
                else
                    eco.Book('state', -gross, 'Allocation', p.license)
                end
                if ok then
                    if tax > 0 then eco.Book('state', tax, 'Impôt sur le revenu', p.license) end
                    G.AddMoney(src, 'bank', net)
                    G.Notify(src, { type = 'success', title = c and c.biz.label or 'Allocation', text = ('Paie reçue : %s%s'):format(money(net), tax > 0 and (' (impôt ' .. money(tax) .. ')') or '') })
                    if G.Premium and G.Premium.Boost then G.Premium.Boost(src, 'pay', net) end   -- boost de paie acheté à la boutique
                    paid = paid + 1
                else
                    G.Notify(src, { type = 'warn', title = c.biz.label, text = "La caisse de l'entreprise est vide : ta paie n'a pas pu être versée." })
                    skipped = skipped + 1
                end
            end
            -- second emploi : un pourcentage du salaire du grade, versé à chaque paie
            local j2 = G.BizCat and G.BizCat.Job2 and (not G.BizCat.Job2Allowed or G.BizCat.Job2Allowed(src)) and G.BizCat.Job2(p.license)   -- VIP seulement
            local pct = tonumber(PB.Cfg.Get('biz', 'job2_pct', 50)) or 0
            -- (v1.2.43) versé seulement en travaillant (en service dans l'emploi principal) : avant, il tombait même sans rien faire
            if j2 and pct > 0 and (j2.salary or 0) > 0 and c and (c.duty or offDuty) then
                local g2 = math.floor(j2.salary * eco.Get('income_mult') * pct / 100 + 0.5)
                local b2 = Biz.Get(j2.biz)
                local src2 = b2 and b2.pay_from or 'free'
                local ok2 = true
                if g2 > 0 then
                    if src2 == 'society' then
                        if eco.Balance(acct(j2.biz)) < g2 then ok2 = false else eco.Book(acct(j2.biz), -g2, 'Salaire (second emploi) ' .. display(src), p.license) end
                    else eco.Book('salaires', -g2, 'Salaire second emploi ' .. j2.biz, p.license) end
                    if ok2 then
                        local tax2 = math.floor(g2 * eco.Get('tax_income') / 100 + 0.5)
                        if tax2 > 0 then eco.Book('state', tax2, 'Impôt sur le revenu', p.license) end
                        G.AddMoney(src, 'bank', g2 - tax2)
                        G.Notify(src, { type = 'success', title = j2.label, text = ('Second emploi : %s reçus'):format(money(g2 - tax2)) })
                        paid = paid + 1
                    else skipped = skipped + 1 end
                end
            end
        end
    end
    return paid, skipped
end
CreateThread(function()
    Wait(math.random(0, 30000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(30000)
        local interval = (G.Eco and G.Eco.Get('paycheck_interval') or 15) * 60
        if os.time() - lastPay >= interval then lastPay = os.time() Biz.PayTick() end
    end
end)

-- Panel ------------------------------------------------------------------------------------------------------------------------------------
local function validGrades(rows, kind)
    if type(rows) ~= 'table' or #rows < 1 then return nil, 'Il faut au moins un grade.' end
    if #rows > 12 then return nil, 'Au plus 12 grades.' end
    local out, seen, boss = {}, {}, false
    for _, r in ipairs(rows) do
        local n = math.floor(tonumber(r.grade) or -1)
        if n < 0 or n > 50 or seen[n] then return nil, 'Numéros de grade : uniques, de 0 à 50.' end
        seen[n] = true
        local label = cleanText(r.label, 40)
        if label == '' then return nil, 'Chaque grade a un nom.' end
        local sal = math.floor(tonumber(r.salary) or -1)
        if sal < 0 or sal > 20000 then return nil, 'Salaire de « ' .. label .. ' » : 0 à 20 000.' end
        local perms = {}
        for tok in tostring(r.perms or ''):gmatch('[%a_]+') do
            local ok = false
            for _, a in ipairs(ALL_PERMS) do if a == tok then ok = true end end
            if not ok then return nil, 'Droit inconnu : « ' .. tok .. ' » (' .. table.concat(ALL_PERMS, ', ') .. ').' end
            perms[#perms + 1] = tok
        end
        local isBoss = PB.ToBool(r.boss)
        if isBoss then boss = true end
        out[#out + 1] = { grade = n, label = label, salary = sal, boss = isBoss, perms = table.concat(perms, ',') }
    end
    if not boss then return nil, "Au moins un grade doit être « patron »." end
    table.sort(out, function(a, b) return a.grade < b.grade end)
    return out
end

local function saveGrades(id, grades)
    DB.exec('DELETE FROM pb_biz_grades WHERE biz_id = ?', { id })
    for _, g in ipairs(grades) do DB.exec('INSERT INTO pb_biz_grades (biz_id, grade, label, salary, boss, perms) VALUES (?, ?, ?, ?, ?, ?)', { id, g.grade, g.label, g.salary, g.boss and 1 or 0, g.perms }) end
end

PB.Action('biz.create', 'biz.edit', function(ctx, p)
    local v = p.values or {}
    -- à partir d'un modèle du catalogue (garde son fonctionnement : cuisine, comptoir, missions, droits du métier)
    local model = G.BizCat and G.BizCat.ByKey[tostring(v.model or '')]
    if model then
        local label = cleanText(v.label, 48)
        if #label < 2 then return false, "Donne un nom à l'entreprise." end
        local id = tostring(v.id or ''):lower():gsub('[^A-Za-z0-9_]', '')
        if id == '' then id = label:lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', '') end
        id = id:sub(1, 32)
        if id == '' then id = model.key end
        if Biz.Get(id) then return false, 'Une entreprise « ' .. id .. ' » existe déjà : choisis un autre identifiant.' end
        local copy = {}
        for k, x in pairs(model) do copy[k] = x end
        local ok, e = G.BizCat.Create(copy, { id = id, label = label, nopos = true, blip = tonumber(v.blip), bcolor = tonumber(v.bcolor) })
        if not ok then return false, tostring(e) end
        ctx.audit('config', 'biz.create', id, nil, { model = model.key, label = label })
        ctx.toast = ('Entreprise « %s » créée (fonctionne comme : %s).'):format(label, model.label)
        local packSum = (tonumber(v.pack) or 0) > 0 and Biz.Starter(id, false, v.pack) or nil
        if packSum then ctx.toast = ctx.toast .. ' ' .. Biz.StarterText(packSum) end
        G.PushConfig()
        if v.points ~= false and ctx.src and ctx.src > 0 and PB.Place and PB.Place.PackStart then
            local okp = PB.Place.PackStart(ctx.src, 'biz', id)
            if okp then ctx.close = true ctx.toast = ctx.toast .. ' Pose maintenant ses points en jeu (E pour poser, Retour arrière pour passer).' end
        end
        return true
    end
    local t = TEMPLATES[tostring(v.template or '')]
    if not t then return false, 'Modèle inconnu.' end
    local label = cleanText(v.label, 48)
    if label == '' then label = t.label end
    local id = tostring(v.id or ''):lower():gsub('[^A-Za-z0-9_]', '')
    if id == '' then id = label:lower():gsub('[^A-Za-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', '') end
    id = id:sub(1, 32)
    if id == '' then return false, 'Identifiant invalide.' end
    if Biz.Get(id) then return false, 'Une entreprise « ' .. id .. ' » existe déjà.' end
    local cat = tostring(v.category or 'services')
    if not (G.BizCat and G.BizCat.CatBy[cat]) then cat = 'services' end
    DB.exec('INSERT INTO pb_biz (id, label, kind, color, icon, pay_from, enabled, hiring, description, created_at, category) VALUES (?, ?, ?, ?, ?, ?, 1, 0, ?, ?, ?)', { id, label, t.kind, t.color, t.icon, 'free', t.description, now(), cat })
    local grades = {}
    for _, g in ipairs(t.grades) do grades[#grades + 1] = { grade = g[1], label = g[2], salary = g[3], boss = g[4], perms = g[5] } end
    saveGrades(id, grades)
    ctx.audit('config', 'biz.create', id, nil, { template = v.template, label = label })
    ctx.toast = 'Entreprise « ' .. label .. ' » créée avec ses grades. Ajuste-la dans « Modifier ».'
    if v.points ~= false and ctx.src and ctx.src > 0 and PB.Place and PB.Place.PackStart then
        local ok = PB.Place.PackStart(ctx.src, 'biz', id)
        if ok then ctx.close = true ctx.toast = 'Entreprise créée. Pose maintenant ses points en jeu (E pour poser, Retour arrière pour passer).' end
    end
    return true
end)

PB.Action('biz.save', 'biz.edit', function(ctx, p)
    local v = p.values or {}
    local b = Biz.Get(p.id)
    if not b then return false, 'Entreprise introuvable.' end
    local c, err = PB.Validate({
        { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'color', type = 'color', label = 'Couleur' },
        { k = 'pay_from', type = 'select', label = 'Salaires payés par', opts = { { 'free', 'Création monétaire' }, { 'society', "La caisse de l'entreprise" } } },
        { k = 'enabled', type = 'toggle', label = 'Active' }, { k = 'hiring', type = 'toggle', label = 'Recrute' }, { k = 'description', type = 'text', label = 'Description', maxlen = 160 },
    }, { label = v.label, color = v.color, pay_from = v.pay_from, enabled = v.enabled, hiring = v.hiring, description = v.description or '' })
    if not c then return false, err end
    local grades, gerr = validGrades(v.grades, b.kind)
    if not grades then return false, gerr end
    -- on ne supprime pas un grade qui a encore des employés
    local have = {}
    for _, g in ipairs(grades) do have[g.grade] = true end
    for _, m in ipairs(Biz.Members(b.id)) do if not have[m.grade] then return false, ('Le grade %d a encore des employés (%s) : déplace-les avant de le supprimer.'):format(m.grade, m.name) end end
    local hx, hy, hz
    if type(v.hq) == 'table' and v.hq.x and (tonumber(v.hq.x) ~= 0 or tonumber(v.hq.y) ~= 0) then
        local cc = PB.Validate({ { k = 'hq', type = 'coords', label = 'Siège' } }, { hq = v.hq })
        if not cc then return false, 'Position du siège invalide.' end
        hx, hy, hz = cc.hq.x, cc.hq.y, cc.hq.z
    end
    local before = { b = b, grades = Biz.Grades(b.id) }
    local cat = tostring(v.category or b.category or 'services')
    if not (G.BizCat and G.BizCat.CatBy[cat]) then cat = b.category or 'services' end
    DB.exec('UPDATE pb_biz SET label = ?, color = ?, pay_from = ?, enabled = ?, hiring = ?, description = ?, hx = ?, hy = ?, hz = ?, category = ? WHERE id = ?', { c.label, c.color, c.pay_from, c.enabled and 1 or 0, c.hiring and 1 or 0, c.description, hx, hy, hz, cat, b.id })
    saveGrades(b.id, grades)
    -- type d'activité et icône (le siège déjà posé prend la nouvelle icône)
    local mk = tostring(v.model or b.activity or '')
    if mk ~= '' and not G.BizCat.ByKey[mk] then mk = tostring(b.activity or '') end
    local bs, bc = math.floor(tonumber(v.blip) or tonumber(b.blip) or -1), math.floor(tonumber(v.bcolor) or tonumber(b.bcolor) or -1)
    if bs < -1 or bs > 999 then bs = -1 end
    if bc < -1 or bc > 85 then bc = -1 end
    DB.exec('UPDATE pb_biz SET activity = ?, blip = ?, bcolor = ? WHERE id = ?', { mk, bs, bc, b.id })
    local bl = G.BizCat.BlipOf(b.id)
    DB.exec("UPDATE pb_points SET sprite = ?, bcolor = ? WHERE owner_kind = 'biz' AND owner = ? AND kind = 'hq'", { bl[1], bl[2], b.id })
    if G.Points and G.Points.PushAll then G.Points.PushAll() end
    ctx.audit('config', 'biz.save', b.id, before, { c = c, grades = grades })
    G.PushConfig()
    ctx.toast = 'Entreprise enregistrée.'
    return true
end)

PB.Action('biz.delete', 'biz.edit', function(ctx, p)
    local b = Biz.Get(p.id)
    if not b then return false, 'Introuvable.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { b.id })
    if n and n.n > 0 then return false, ('Cette entreprise a encore %d employé(s) : renvoie-les d\'abord.'):format(n.n) end
    local bal = G.Eco.Balance(acct(b.id))
    if bal ~= 0 then return false, ('La caisse contient %s : vide-la avant de supprimer.'):format(money(bal)) end
    DB.exec('DELETE FROM pb_biz WHERE id = ?', { b.id }) DB.exec('DELETE FROM pb_biz_grades WHERE biz_id = ?', { b.id }) DB.exec("DELETE FROM pb_points WHERE owner_kind = 'biz' AND owner = ?", { b.id })
    ctx.audit('config', 'biz.delete', b.id, b, nil)
    G.PushConfig()
    ctx.toast = 'Entreprise supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette entreprise ?', text = "Ses grades disparaissent. Les factures et dossiers déjà émis sont conservés.", danger = true } })

PB.Action('biz.member.set', 'biz.members', function(ctx, p)
    local b = Biz.Get(p.biz)
    if not b then return false, 'Entreprise introuvable.' end
    local lic = tostring(p.license or '')
    local pl = DB.one('SELECT license, firstname, lastname FROM pb_players WHERE license = ?', { lic })
    if not pl then return false, 'Aucun personnage pour cette licence.' end
    local g = Biz.Grade(b.id, p.grade or 0)
    if not g then return false, 'Grade introuvable.' end
    DB.exec('INSERT INTO pb_biz_members (license, biz_id, grade, name, hired_at, on_duty) VALUES (?, ?, ?, ?, ?, 0) ON DUPLICATE KEY UPDATE biz_id = VALUES(biz_id), grade = VALUES(grade), name = VALUES(name), on_duty = 0',
        { lic, b.id, g.grade, ((pl.firstname or '') .. ' ' .. (pl.lastname or '')):gsub('^%s+', ''), now() })
    ctx.audit('config', 'biz.member.set', lic, nil, { biz = b.id, grade = g.grade })
    ctx.toast = 'Employé enregistré.'
    return true
end)

PB.Action('biz.member.remove', 'biz.members', function(ctx, p)
    local m = Biz.MemberOf(tostring(p.license or ''))
    if not m then return false, 'Employé introuvable.' end
    DB.exec('DELETE FROM pb_biz_members WHERE license = ?', { m.license })
    for id, pl in pairs(G.Players()) do if pl.license == m.license then TriggerClientEvent('pb:g:biz:job', id, 'null') end end
    ctx.audit('config', 'biz.member.remove', m.license, m, nil)
    ctx.toast = m.name .. ' n\'a plus d\'emploi.'
    return true
end, { critical = true, confirm = { title = "Retirer cet employé ?", text = "Il perd son poste immédiatement." } })

local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end

-- Pack de départ des entreprises légales : 3 packs réglables. Argent dans la caisse, véhicules à la flotte, objets dans le coffre de l'équipe.
-- Pas encore de coffre posé : les objets attendent et arrivent dès que le coffre est posé au Builder.
PB.Migrate('540_biz_starter', 'Entreprises : pack de départ', {
    [[CREATE TABLE IF NOT EXISTS pb_biz_starter (id VARCHAR(32) NOT NULL, at INT NOT NULL DEFAULT 0, pack VARCHAR(32) NOT NULL DEFAULT '', pending TEXT NULL, PRIMARY KEY (id))]],
})
local PACK_DEF = {
    { 'Pack Démarrage', 2500, { 'water:5', 'sandwich:5', 'radio:1' }, {} },
    { 'Pack Standard', 10000, { 'water:10', 'sandwich:10', 'bandage:5', 'radio:2' }, { 'speedo|Utilitaire' } },
    { 'Pack Complet', 25000, { 'water:20', 'sandwich:20', 'bandage:10', 'medkit:2', 'radio:5' }, { 'speedo|Utilitaire', 'sultan|Voiture de société' } },
}
local packDefaults = { pack_default = 2, pack_kind_vehicle = true }
for i, p in ipairs(PACK_DEF) do packDefaults['bpack' .. i .. '_name'], packDefaults['bpack' .. i .. '_cash'], packDefaults['bpack' .. i .. '_items'], packDefaults['bpack' .. i .. '_vehicles'] = p[1], p[2], p[3], p[4] end
PB.Cfg.Define('biz', packDefaults)
local function pcfg(k, d) return PB.Cfg.Get('biz', k, d) end
function Biz.Pack(n)
    n = math.floor(tonumber(n) or 2)
    if n < 1 or n > 3 then return nil end
    return { n = n, name = pcfg('bpack' .. n .. '_name', PACK_DEF[n][1]), cash = tonumber(pcfg('bpack' .. n .. '_cash', PACK_DEF[n][2])) or 0, items = pcfg('bpack' .. n .. '_items', PACK_DEF[n][3]) or {}, vehicles = pcfg('bpack' .. n .. '_vehicles', PACK_DEF[n][4]) or {} }
end
function Biz.Packs()
    local out = {}
    for i = 1, 3 do local p = Biz.Pack(i) out[i] = { n = i, name = p.name, cash = p.cash, items = #p.items, cars = #p.vehicles } end
    return out
end
-- véhicule du métier, ajouté aux packs qui ont déjà des véhicules
local function kindVehicle(b)
    if b.kind == 'police' then return 'police', 'Voiture de patrouille' elseif b.kind == 'ems' then return 'ambulance', 'Ambulance' elseif b.kind == 'garage' then return 'towtruck', 'Dépanneuse' end
    if G.BizCat and G.BizCat.ModelKey and G.BizCat.ModelKey(b) == 'taxi' then return 'taxi', 'Taxi' end
end
local function teamStash(id) return DB.one('SELECT id FROM pb_inv_stashes WHERE biz = ? ORDER BY id LIMIT 1', { tostring(id) }) end
local function giveItems(stash, lines, sum)
    for _, line in ipairs(lines or {}) do
        local item, qty = tostring(line):match('^([%w_]+):(%d+)$')
        qty = tonumber(qty)
        if item and qty and qty > 0 then
            if not (G.Inv and G.Inv.Def(item)) then sum.skipped[#sum.skipped + 1] = item .. ' (inconnu)'
            elseif G.Inv.Add('s:' .. tostring(stash.id), item, qty) then sum.items = sum.items + 1
            else sum.skipped[#sum.skipped + 1] = item .. ' (coffre plein)' end
        end
    end
end
-- Appelé quand un coffre d'entreprise est posé : les objets du pack qui attendaient y arrivent
function Biz.StarterFlush(id)
    local r = DB.one('SELECT pending FROM pb_biz_starter WHERE id = ?', { tostring(id) })
    local st = r and tostring(r.pending or '') ~= '' and teamStash(id)
    if not st then return 0 end
    local sum = { items = 0, skipped = {} }
    giveItems(st, PB.FromJson(r.pending, {}) or {}, sum)
    DB.exec("UPDATE pb_biz_starter SET pending = '' WHERE id = ?", { tostring(id) })
    return sum.items
end
-- Une seule fois par entreprise, sauf `force`. Renvoie le résumé, ou nil + message.
function Biz.Starter(id, force, packN)
    local b = Biz.Get(id)
    if not b then return nil, 'Entreprise introuvable.' end
    local pack = type(packN) == 'table' and packN or Biz.Pack(packN)   -- table = pack sur mesure (G.PackCustom)
    if not pack then return nil, 'Pack inconnu.' end
    local had = DB.one('SELECT pack FROM pb_biz_starter WHERE id = ?', { b.id })
    if had and not force then return nil, 'Cette entreprise a déjà reçu son pack (' .. tostring(had.pack) .. ').' end
    local sum = { pack = pack.name, items = 0, waiting = false, skipped = pack.skipped or {}, cash = 0, cars = {} }
    if pack.cash > 0 and G.Eco then G.Eco.Book(acct(b.id), math.floor(pack.cash), 'Pack de départ', '') sum.cash = math.floor(pack.cash) end
    local list = {}
    for _, v in ipairs(pack.vehicles) do list[#list + 1] = v end
    if #list > 0 and not pack.custom and pcfg('pack_kind_vehicle', true) ~= false then local m, l = kindVehicle(b) if m then table.insert(list, 1, m .. '|' .. l) end end
    for _, line in ipairs(list) do
        local model, label = tostring(line):match('^([%w_]+)|?(.*)$')
        if model and G.Garage and G.Garage.AddFleet then
            local ok, plate = G.Garage.AddFleet(b.id, model, label ~= '' and label or model)
            if ok then sum.cars[#sum.cars + 1] = plate else sum.skipped[#sum.skipped + 1] = model .. ' (' .. tostring(plate) .. ')' end
        end
    end
    local st, pending = teamStash(b.id), ''
    if st then giveItems(st, pack.items, sum)
    elseif #pack.items > 0 then pending, sum.waiting = PB.Json(pack.items), true end
    DB.exec('DELETE FROM pb_biz_starter WHERE id = ?', { b.id })
    DB.exec('INSERT INTO pb_biz_starter (id, at, pack, pending) VALUES (?, ?, ?, ?)', { b.id, now(), pack.name, pending })
    return sum
end
function Biz.StarterText(sum)
    return ('%s : %s en caisse, %d véhicule(s) à la flotte, %s.'):format(sum.pack, PB.Money(sum.cash), #sum.cars, sum.waiting and 'objets livrés dès que le coffre sera posé' or (sum.items .. ' objet(s) au coffre'))
end
PB.Action('biz.starter', 'biz.edit', function(ctx, p)
    local sum, err = Biz.Starter(tostring(p.id or ''), true, p.pack)
    if not sum then return false, err end
    ctx.audit('economy', 'biz.starter', tostring(p.id), nil, { pack = sum.pack, cash = sum.cash, cars = #sum.cars })
    G.PushConfig()
    ctx.toast = Biz.StarterText(sum)
    return true
end, { confirm = { title = 'Donner ce pack de départ ?', text = "L'argent, les véhicules et les objets s'ajoutent à ce que l'entreprise possède déjà." } })
PB.Action('biz.starter.custom', 'biz.edit', function(ctx, p)
    local v = p.values or p
    local pack, e = G.PackCustom.Parse(v)
    if not pack then return false, e end
    local sum, err = Biz.Starter(tostring(v.target or ''), true, pack)
    if not sum then return false, err end
    ctx.audit('economy', 'biz.starter.custom', tostring(v.target), nil, { items = pack.items, cash = sum.cash, vehicles = pack.vehicles })
    G.PushConfig()
    ctx.toast = G.PackCustom.Text(sum)
    return true
end, { confirm = { title = 'Donner ce pack ?', text = "L'argent, les véhicules et les objets s'ajoutent à ce que l'entreprise possède déjà." } })
local function packFields()
    local f = { { k = 'pack_default', type = 'select', label = 'Pack donné aux entreprises du catalogue créées au Builder', opts = { { '0', 'Aucun' }, { '1', 'Pack 1' }, { '2', 'Pack 2' }, { '3', 'Pack 3' } }, default = '2' },
        { k = 'pack_kind_vehicle', type = 'toggle', label = 'Ajouter le véhicule du métier (dépanneuse, ambulance, patrouille, taxi) aux packs qui ont des véhicules', default = true } }
    for i, d in ipairs(PACK_DEF) do
        f[#f + 1] = { k = 'bpack' .. i .. '_name', type = 'text', label = 'Pack ' .. i .. ' : nom', default = d[1], maxlen = 24 }
        f[#f + 1] = { k = 'bpack' .. i .. '_cash', type = 'number', label = 'Pack ' .. i .. ' : argent dans la caisse ($)', default = d[2], min = 0, max = 10000000 }
        f[#f + 1] = { k = 'bpack' .. i .. '_items', type = 'list', label = 'Pack ' .. i .. ' : objets du coffre (objet:quantité)', default = d[3], maxitems = 30, maxlen = 48, pattern = '^[%w_]+:%d+$', wide = true }
        f[#f + 1] = { k = 'bpack' .. i .. '_vehicles', type = 'list', label = 'Pack ' .. i .. ' : véhicules (modèle|nom affiché)', default = d[4], maxitems = 10, maxlen = 48, pattern = '^[%w_]+|?[^|]*$', wide = true }
    end
    return f
end
local packsForm = Form.Cfg({ ns = 'biz', id = 'packs', title = 'Packs de départ des entreprises', perm = 'biz.edit', cols = 2, fields = packFields() })

local settingsForm = Form.Cfg({
    ns = 'biz', id = 'settings', title = 'Réglages des entreprises', perm = 'biz.edit', cols = 2,
    desc = "S'appliquent à toutes les entreprises. Les limites sont vérifiées par le serveur à chaque action.",
    fields = {
        { k = 'tablet_key', type = 'text', label = "Touche supplémentaire de l'espace citoyen / entreprise (vide ou F6 = aucune)", default = 'F6', maxlen = 12, pattern = '^[%w_]*$', hint = "Tout est déjà dans le menu F6 (et au siège, au bureau du patron, /tablette). Une autre touche ouvre directement l'espace citoyen / entreprise." },
        { k = 'near_dist', type = 'number', label = 'Distance maximale pour agir sur un joueur (m)', default = 8, min = 2, max = 30 },
        { k = 'max_invoice', type = 'number', label = 'Facture maximale', default = 50000, min = 1, max = 10000000 },
        { k = 'max_fine', type = 'number', label = 'Amende maximale', default = 25000, min = 1, max = 10000000 },
        { k = 'fine_to', type = 'select', label = 'Les amendes vont à', opts = { { 'state', "Au compte « État »" }, { 'biz', "À la caisse de l'entreprise émettrice" } }, default = 'state' },
        { k = 'pay_off_duty', type = 'toggle', label = 'Payer aussi les employés hors service', default = false },
        { k = 'job2_vip_only', type = 'toggle', label = 'Double emploi réservé aux VIP', default = true, hint = "Sans VIP : impossible d'avoir un second emploi ; un VIP expiré garde le poste mais n'est plus payé ni ne peut changer avec /jobswap." },
        { k = 'boss_salary_max', type = 'number', label = "Salaire maximum fixé par un patron (paie versée par l'État)", default = 1500, min = 0, max = 20000, hint = "L'État crée cet argent à chaque paie : sans plafond, un patron pouvait se verser 20 000 $ par paie. Les entreprises payées par leur caisse vont jusqu'à 20 000 $." },
        { k = 'job2_pct', type = 'number', label = 'Salaire du second emploi (% du salaire du grade)', default = 50, min = 0, max = 100, hint = '0 = le second emploi ne rapporte rien.' },
        { k = 'max_members', type = 'number', label = "Employés maximum par entreprise", default = 60, min = 1, max = 500 },
        { k = 'allow_transfers', type = 'toggle', label = 'Virements entre joueurs (F6 › Finances)', default = true },
        { k = 'transfer_fee', type = 'number', label = 'Frais de virement (%)', default = 0, min = 0, max = 50, int = false, step = 0.5 },
        { k = 'transfer_max', type = 'number', label = 'Virement maximal', default = 100000, min = 1, max = 100000000 },
        { k = 'full_catalog', type = 'toggle', label = 'Catalogue complet (120 métiers)', default = false, hint = "Désactivé : seules les entreprises essentielles sont proposées (police, EMS, justice, mécanos, taxi, concession, Burger Shot, cafés et bars, immobilier, Weazel News, livraison)." },
    },
})

PB.Module({
    id = 'biz', label = 'Entreprises', icon = 'briefcase', group = 'Serveur', order = 92, perm = 'biz.view', hint = 'Police, EMS, garage, grades, paie, menu F6',
    caps = function()
        return PB.Capsify({
            { 'Entreprises avec grades, employés, caisse, paie', 'ok', 'Autonomes : tables pb_biz*. Salaires versés selon les réglages de l\'économie (multiplicateur, impôt, intervalle).' },
            { 'Menu F6 : espace citoyen et gestion', 'ok', 'Menu lib (plus de tablette) : finances, factures, entreprises, profil ; pour les employés tableau de bord, équipe, dossiers, factures ; employés, grades et caisse au bureau du patron.' },
            { 'Police : amendes, dossiers', 'ok', "Amendes du catalogue de l'économie, prélevées ou mises en facture." },
            { 'EMS : réanimation, dossiers de soins', 'ok', 'Réanime un patient à proximité (agit sur la mort du panel).' },
            { 'Garage : réparation, facturation', 'ok', 'Répare le véhicule le plus proche côté client du mécanicien.' },
            { 'Menottes, fouille, coffre d\'objets, saisie de véhicule', 'ok', "Menu F6 de la police et menu ALT ; coffres au Builder ; fourrière." },
            { 'Jobs ESX / QBCore existants', 'off', "Les emplois du framework restent séparés : n'utilise pas les deux en même temps." },
        })
    end,
    doc = "## Entreprises\nCrée une entreprise à partir d'un **modèle** (police, EMS, garage, générique) puis ajuste ses grades, couleurs et droits. Chaque grade a un **salaire** et des **droits** : `hire, fire, promote, vault, invoice, fine, revive, repair, records` ; le grade « patron » a tous les droits.\n\n- **Menu F6** (menu lib, plus de tablette) : actions du métier, puis toutes les pages de gestion. Les patrons gèrent employés, grades et caisse au bureau du patron. Sans entreprise, F6 ouvre l'espace citoyen.\n- **Droits propres à un métier** (`fine`, `revive`, `repair`) n'agissent que dans leur métier.\n- **Pour tes scripts** : `exports.pb_panel:GetJob(source)`, `SetJob(source, 'police', 2)`, `IsOnDuty(source)`, `AddBusinessMoney('garage', 500, 'raison')`.",
    view = function(ctx)
        return { tabs = {
            tab('list', 'Entreprises', 'briefcase', function()
                local items = {}
                for _, b in ipairs(Biz.List()) do
                    local n = DB.one('SELECT COUNT(*) AS n FROM pb_biz_members WHERE biz_id = ?', { b.id })
                    local pend = DB.one("SELECT COUNT(*) AS n FROM pb_biz_invoices WHERE biz_id = ? AND status = 'pending'", { b.id })
                    items[#items + 1] = { title = b.label, sub = (KIND_LABEL[b.kind] or b.kind) .. ' · ' .. b.id, icon = b.icon, tone = b.color, badge = PB.ToBool(b.enabled) and nil or 'Désactivée',
                        value = money(G.Eco.Balance(acct(b.id))), text = b.description, stats = { { label = 'Employés', value = tostring(n and n.n or 0) }, { label = 'Factures', value = tostring(pend and pend.n or 0) }, { label = 'Salaires', value = b.pay_from == 'society' and 'Caisse' or 'Libre' } },
                        action = ctx.has('biz.edit') and { nav = { tab = 'edit', params = { id = b.id } }, label = 'Modifier', icon = 'sliders' } or nil }
                end
                local blocks = { { type = 'cards', big = true, items = items } }
                if #items == 0 then blocks[#blocks + 1] = B.notice('info', "Aucune entreprise : crée la première depuis l'onglet « Nouvelle entreprise ».") end
                return blocks
            end),
            tab('new', 'Nouvelle entreprise', 'plus', function(_, params)
                local C = G.BizCat
                local cat = tostring(params and params.cat or 'public')
                if not C.CatBy[cat] then cat = 'public' end
                local cards = {}
                for _, c in ipairs(C.Cats) do
                    local total, have = 0, 0
                    for _, t in ipairs(C.List) do if t.cat == c.id and C.Visible(t) then total = total + 1 if Biz.Get(t.key) then have = have + 1 end end end
                    cards[#cards + 1] = { title = c.label, sub = have .. ' / ' .. total .. ' installées', icon = c.icon, tone = c.color, text = c.desc, badge = c.id == cat and 'Affichée' or nil,
                        action = { nav = { tab = 'new', params = { cat = c.id } }, label = 'Voir', icon = 'eye' } }
                end
                local rows = {}
                for _, t in ipairs(C.List) do
                    if t.cat == cat and C.Visible(t) then
                        local g1, gN = t.grades[1], t.grades[#t.grades]
                        local done = Biz.Get(t.key) ~= nil
                        rows[#rows + 1] = { name = t.label, grades = #t.grades .. ' grades (' .. g1 .. ' → ' .. gN .. ')', pay = money(t.pay[1]) .. ' → ' .. money(t.pay[2]), kind = KIND_LABEL[t.kind] or t.kind, pos = t.pos and 'Siège + blip' or 'À placer (carte)',
                            state = done and { text = 'Installée', tone = 'ok' } or { text = 'Disponible', tone = 'off' },
                            actions = done and { { nav = { tab = 'edit', params = { id = t.key } }, label = 'Modifier', icon = 'sliders' } } or { { action = 'biz.cat.create', label = 'Installer', icon = 'plus', payload = { key = t.key } } } }
                    end
                end
                local kinds = {}
                for _, k in ipairs({ 'generic', 'police', 'ems', 'garage' }) do kinds[#kinds + 1] = { k, KIND_LABEL[k] } end
                local copts = {}
                for _, c in ipairs(C.Cats) do copts[#copts + 1] = { c.id, c.label } end
                -- tous les modèles, classés par catégorie (celle de l'onglet en premier)
                local mopts, mdef = {}, nil
                local order = { cat }
                for _, c in ipairs(C.Cats) do if c.id ~= cat then order[#order + 1] = c.id end end
                for _, cid in ipairs(order) do
                    for _, t in ipairs(C.List) do if t.cat == cid then mopts[#mopts + 1] = { t.key, C.CatBy[cid].label .. ' · ' .. t.label } mdef = mdef or t.key end end
                end
                return {
                    { type = 'cards', items = cards },
                    B.table({ id = 'bizcat', title = C.CatBy[cat].label .. ' : modèles prêts à installer', search = true, columns = { { k = 'name', label = 'Entreprise' }, { k = 'kind', label = 'Type' }, { k = 'grades', label = 'Grades' }, { k = 'pay', label = 'Salaires' }, { k = 'pos', label = 'Position' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows, empty = 'Aucun modèle.' }),
                    B.actions({ { action = 'biz.cat.install', label = 'Installer toute la catégorie', icon = 'plus', payload = { cat = cat } }, { action = 'biz.cat.install', label = 'Tout installer (' .. #C.List .. ' entreprises)', icon = 'plus', payload = { cat = 'all' } } }),
                    { type = 'form', id = 'biz.new', title = 'Créer une entreprise sur mesure', desc = "Donne-lui le nom que tu veux et choisis comment elle fonctionne : elle garde tout ce que fait ce type (mécano : atelier et réparations ; café, restaurant, bar : cuisine et comptoir ; taxi : courses…). Grades, salaires et droits sont générés, tu les ajustes ensuite dans « Modifier ».", cols = 2, fields = {
                        { k = 'label', type = 'text', label = "Nom de l'entreprise", required = true, maxlen = 48, hint = "Ex. Benny's Motorworks, Le Petit Café, Garage du Port." },
                        { k = 'model', type = 'select', label = 'Fonctionne comme', opts = mopts, hint = 'Tous les types du catalogue, classés par catégorie.' },
                        { k = 'blip', type = 'number', label = 'Icône sur la carte (blip GTA)', min = -1, max = 999, picker = 'blip', pickerColor = 'bcolor', hint = '-1 = icône du type choisi. Le bouton ouvre toutes les icônes du jeu.' },
                        { k = 'bcolor', type = 'number', label = "Couleur de l'icône", min = -1, max = 85, hint = '-1 = couleur du type. Se choisit aussi dans le sélecteur.' },
                        { k = 'id', type = 'text', label = 'Identifiant (facultatif)', maxlen = 32, pattern = '^[%w_]*$', hint = 'Lettres, chiffres, _ : sert dans les scripts.' },
                        { k = 'pack', type = 'select', label = 'Pack de départ', opts = (function() local o = { { '0', 'Aucun' } } for _, pk in ipairs(Biz.Packs()) do o[#o + 1] = { tostring(pk.n), pk.name .. ' (' .. PB.Money(pk.cash) .. ', ' .. pk.items .. ' objets, ' .. pk.cars .. ' véhicules)' } end return o end)(), hint = 'Argent, objets et véhicules de départ. Réglables dans l\'onglet Packs de départ.' },
                        { k = 'points', type = 'toggle', label = 'Poser tous les points maintenant (en jeu)', hint = 'Siège, service, patron, coffre, garage (entrée et sortie), vestiaire, atelier, cuisine, comptoir, selon le type. Sinon : Carte du jeu › Configurer tout.' } },
                        values = { model = mdef, label = '', id = '', blip = -1, bcolor = -1, pack = '2', points = true }, submit = { action = 'biz.create', label = "Créer l'entreprise" } } }
            end, 'biz.edit'),
            tab('edit', 'Modifier', 'sliders', function(_, params)
                local list = Biz.List()
                local opts = {}
                for _, b in ipairs(list) do opts[#opts + 1] = { b.id, b.label } end
                if #opts == 0 then return { B.notice('info', "Aucune entreprise à modifier.") } end
                local id = tostring(params.id or opts[1][1])
                local b = Biz.Get(id) or Biz.Get(opts[1][1])
                local g = {}
                for _, r in ipairs(Biz.Grades(b.id)) do g[#g + 1] = { grade = r.grade, label = r.label, salary = r.salary, boss = PB.ToBool(r.boss), perms = r.perms } end
                local hq = (b.hx and b.hy) and { x = b.hx, y = b.hy, z = b.hz or 0, h = 0 } or { x = 0, y = 0, z = 0, h = 0 }
                local sub = ctx.has('biz.edit')
                local blocks = { { type = 'picker', id = 'id', label = 'Entreprise', options = opts, value = b.id },
                    { type = 'form', id = 'biz.edit', title = 'Modifier « ' .. b.label .. ' »', cols = 2, fields = {
                        { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 }, { k = 'color', type = 'color', label = 'Couleur' },
                        { k = 'category', type = 'select', label = 'Catégorie', opts = (function() local o = {} for _, c in ipairs(G.BizCat.Cats) do o[#o + 1] = { c.id, c.label } end return o end)() },
                        { k = 'pay_from', type = 'select', label = 'Salaires payés par', opts = { { 'free', 'Création monétaire (sans limite)' }, { 'society', "La caisse de l'entreprise" } } },
                        { k = 'description', type = 'text', label = 'Description', maxlen = 160 }, { k = 'enabled', type = 'toggle', label = 'Active' }, { k = 'hiring', type = 'toggle', label = 'Affichée comme « Recrute »' },
                        { k = 'model', type = 'select', label = 'Fonctionne comme', opts = (function() local o = { { '', '(identique à son identifiant)' } } for _, t in ipairs(G.BizCat.List) do o[#o + 1] = { t.key, G.BizCat.CatBy[t.cat].label .. ' · ' .. t.label } end return o end)(), hint = 'Décide de la cuisine, du comptoir, de l\'atelier et des petits jobs.' },
                        { k = 'blip', type = 'number', label = 'Icône sur la carte (blip GTA)', min = -1, max = 999, picker = 'blip', pickerColor = 'bcolor', hint = '-1 = icône du type.' },
                        { k = 'bcolor', type = 'number', label = "Couleur de l'icône", min = -1, max = 85 },
                        { k = 'hq', type = 'coords', label = 'Siège (facultatif)', wide = true, hint = 'Laisse 0, 0 pour ne pas en définir.' },
                        { k = 'grades', type = 'rows', label = 'Grades', wide = true, cols = { { k = 'grade', label = 'N°', type = 'number' }, { k = 'label', label = 'Nom' }, { k = 'salary', label = 'Salaire', type = 'number' }, { k = 'boss', label = 'Patron', type = 'toggle' },
                            { k = 'perms', label = 'Droits (séparés par des virgules)' } } } },
                        values = { label = b.label, color = b.color, model = tostring(b.activity or ''), blip = tonumber(b.blip) or -1, bcolor = tonumber(b.bcolor) or -1, category = b.category or 'services', pay_from = b.pay_from, description = b.description, enabled = PB.ToBool(b.enabled), hiring = PB.ToBool(b.hiring), hq = hq, grades = g },
                        submit = sub and { action = 'biz.save', label = 'Enregistrer', payload = { id = b.id } } or nil },
                    B.notice('info', 'Droits disponibles : ' .. table.concat(ALL_PERMS, ', ') .. '. Le grade « patron » a tous les droits. Les droits `fine`, `revive`, `repair`, `cuff`, `search` et `seize` n\'agissent que dans une entreprise du métier correspondant.') }
                if sub then
                    local had = DB.one('SELECT pack FROM pb_biz_starter WHERE id = ?', { b.id })
                    local acts = {}
                    for _, pk in ipairs(Biz.Packs()) do acts[#acts + 1] = { action = 'biz.starter', label = 'Donner : ' .. pk.name, icon = 'gift', payload = { id = b.id, pack = pk.n } } end
                    blocks[#blocks + 1] = B.notice('info', had and ('Pack de départ déjà reçu : ' .. tostring(had.pack) .. '. En redonner un ajoute à ce que possède l\'entreprise.') or "Cette entreprise n'a pas encore reçu de pack de départ.")
                    blocks[#blocks + 1] = B.actions(acts)
                end
                if sub then blocks[#blocks + 1] = B.actions({ { action = 'biz.delete', label = "Supprimer l'entreprise", icon = 'trash', danger = true, payload = { id = b.id } } }) end
                return blocks
            end, 'biz.edit'),
            tab('members', 'Employés', 'users', function()
                local rows = {}
                for _, m in ipairs(DB.q('SELECT m.*, b.label AS blabel, g.label AS glabel FROM pb_biz_members m LEFT JOIN pb_biz b ON b.id = m.biz_id LEFT JOIN pb_biz_grades g ON g.biz_id = m.biz_id AND g.grade = m.grade ORDER BY b.label, m.grade DESC LIMIT 300') or {}) do
                    rows[#rows + 1] = { name = m.name, biz = m.blabel or m.biz_id, grade = m.glabel or m.grade, duty = PB.ToBool(m.on_duty) and { text = 'En service', tone = 'ok' } or { text = 'Hors service', tone = 'off' }, lic = m.license,
                        actions = ctx.has('biz.members') and { { action = 'biz.member.remove', label = 'Retirer', icon = 'trash', danger = true, payload = { license = m.license } } } or {} }
                end
                local blocks = { B.table({ id = 'mem', title = 'Tous les employés', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'biz', label = 'Entreprise' }, { k = 'grade', label = 'Grade' }, { k = 'duty', label = 'Service', type = 'badge' }, { k = 'lic', label = 'Licence', type = 'mono' } }, rows = rows, empty = 'Aucun employé.' }) }
                if ctx.has('biz.members') then
                    local opts = {}
                    for _, b in ipairs(Biz.List()) do opts[#opts + 1] = { b.id, b.label } end
                    if #opts > 0 then blocks[#blocks + 1] = { type = 'form', id = 'mem.set', title = 'Affecter une personne', desc = 'Par licence Rockstar (visible dans Créateur > Joueurs).', cols = 3, fields = {
                        { k = 'license', type = 'text', label = 'Licence', required = true, maxlen = 64 }, { k = 'biz', type = 'select', label = 'Entreprise', opts = opts }, { k = 'grade', type = 'number', label = 'Grade', min = 0, max = 50 } },
                        values = { license = '', biz = opts[1][1], grade = 0 }, submit = { action = 'biz.member.set', label = 'Affecter' } } end
                end
                return blocks
            end),
            tab('ledger', 'Caisses et factures', 'coins', function()
                local items, rows = {}, {}
                for _, b in ipairs(Biz.List()) do items[#items + 1] = { title = b.label, sub = 'Caisse', icon = b.icon, tone = b.color, value = money(G.Eco.Balance(acct(b.id))) } end
                if ctx.has('biz.ledger') then
                    for _, i in ipairs(DB.q('SELECT * FROM pb_biz_invoices ORDER BY id DESC LIMIT 100') or {}) do
                        rows[#rows + 1] = { at = i.at, biz = i.biz_id, who = i.name, reason = i.reason, amount = i.amount, kind = i.kind == 'fine' and 'Amende' or 'Facture', status = ({ pending = 'En attente', paid = 'Réglée', cancelled = 'Annulée' })[i.status] or i.status }
                    end
                end
                return { { type = 'cards', items = items }, ctx.has('biz.ledger') and B.table({ id = 'inv', title = 'Dernières factures et amendes', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'biz', label = 'Entreprise' }, { k = 'kind', label = 'Type' },
                    { k = 'who', label = 'Client' }, { k = 'reason', label = 'Motif' }, { k = 'amount', label = 'Montant', type = 'num' }, { k = 'status', label = 'Statut' } }, rows = rows, empty = 'Aucune facture.' }) or nil }
            end, 'biz.ledger'),
            tab('tablet', 'Aperçu du menu F6', 'grid', function()
                return { { type = 'gpreview', kind = 'quick', title = 'Menu F6 vu par un employé', cfg = PB.Cfg.All('menus') } }
            end),
            tab('packs', 'Packs de départ', 'gift', function()
                local opts = {}
                for _, b in ipairs(Biz.List()) do opts[#opts + 1] = { b.id, b.label } end
                local blocks = { packsForm(ctx) }
                if #opts > 0 then blocks[#blocks + 1] = G.PackCustom.Form({ id = 'biz.starter.custom', action = 'biz.starter.custom', target = 'Entreprise', owner = "l'entreprise", opts = opts }) end
                return blocks
            end, 'biz.edit'),
            tab('settings', 'Réglages', 'sliders', function() local out = { settingsForm(ctx) } for _, f in ipairs(Biz.ExtraSettings) do out[#out + 1] = f(ctx) end return out end, 'biz.edit'),
        } }
    end,
})

-- Auto-test : modèles valides, grades cohérents, paie sans erreur ------------------------------------------------------------------------
PB.SelfTest.Add('entreprises', function(R)
    for k, t in pairs(TEMPLATES) do
        local rows = {}
        for _, g in ipairs(t.grades) do rows[#rows + 1] = { grade = g[1], label = g[2], salary = g[3], boss = g[4], perms = g[5] } end
        local ok, err = validGrades(rows, t.kind)
        R.check(ok, 'modèle ' .. k, 'grades invalides', err)
    end
    for _, b in ipairs(Biz.List()) do
        local grades = Biz.Grades(b.id)
        local boss = false
        for _, g in ipairs(grades) do if PB.ToBool(g.boss) then boss = true end end
        R.check(boss, 'entreprise ' .. b.id, 'aucun grade patron')
        R.check(#grades > 0, 'entreprise ' .. b.id, 'aucun grade')
    end
    R.check(pcall(Biz.PayTick), 'entreprises', 'la paie plante')
end)

-- nettoyage des tables par joueur (évite qu'elles grossissent sans fin)
AddEventHandler('playerDropped', function() local s = source lastRepair[s] = nil lastReq[s] = nil end)
