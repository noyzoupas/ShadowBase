-- Anticheat (suite) : dégâts truqués, tirs impossibles, projectiles, armes retirées, entités et chat en rafale, pseudos, et rapports du client recoupés par le serveur.
-- Même philosophie que anticheat.lua : le serveur décide, les détections de comportement sont réglées sur « Journaliser » tant qu'elles ne sont pas éprouvées, et `anticheat.bypass` n'est jamais sanctionné.
local G = PB.G
local AC = PB.AC
if not AC then return end
local cfg, Flag, tracked, bump, cancel = AC.Cfg, AC.Flag, AC.Tracked, AC.bump, AC.Cancel
local function on(src) return src and cfg('enabled') ~= false and not AC.Bypass(src) end
local function lowerSet(l) local t = {} for _, v in ipairs(l or {}) do t[GetHashKey(tostring(v):lower())] = tostring(v):lower() end return t end

-- Dégâts truqués et tirs impossibles ---------------------------------------------------------------------------------------------------------
local MELEE, TASER = {}, {}
for _, n in ipairs({ 'weapon_unarmed', 'weapon_knife', 'weapon_nightstick', 'weapon_hammer', 'weapon_bat', 'weapon_crowbar', 'weapon_golfclub', 'weapon_bottle', 'weapon_dagger', 'weapon_hatchet', 'weapon_knuckle', 'weapon_machete', 'weapon_flashlight', 'weapon_switchblade', 'weapon_poolcue', 'weapon_wrench', 'weapon_battleaxe', 'weapon_stone_hatchet' }) do MELEE[GetHashKey(n)] = true end
for _, n in ipairs({ 'weapon_stungun', 'weapon_stungun_mp' }) do TASER[GetHashKey(n)] = true end
AddEventHandler('weaponDamageEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    -- cadence
    local rate = bump(src, 'dmgrate', 1)
    if rate > (tonumber(cfg('fire_rate')) or 30) then
        if rate == (tonumber(cfg('fire_rate')) or 30) + 1 then Flag(src, 'rapid_fire', ('%d coups en 1 s'):format(rate)) end
        if AC.ModeOf('rapid_fire') ~= 'log' then cancel() return end
    end
    local dmg = tonumber(d.weaponDamage) or 0
    if d.overrideDefaultDamage and dmg > (tonumber(cfg('dmg_max')) or 400) then
        if AC.ModeOf('damage_mod') ~= 'log' then cancel() end
        Flag(src, 'damage_mod', ('%d dégâts en un coup (arme %s)'):format(dmg, tostring(d.weaponType)))
        return
    end
    local gid = tonumber(d.hitGlobalId)
    if gid and gid ~= 0 and NetworkGetEntityFromNetworkId then
        local tgt = NetworkGetEntityFromNetworkId(gid)
        local ped = GetPlayerPed(src)
        if tgt and tgt ~= 0 and ped and ped ~= 0 then
            local a, b = GetEntityCoords(ped), GetEntityCoords(tgt)
            local dist = #(a - b)
            if dist > (tonumber(cfg('hit_range')) or 900) then
                if AC.ModeOf('hit_far') ~= 'log' then cancel() end
                Flag(src, 'hit_far', ('cible touchée à %d m'):format(math.floor(dist)))
            elseif MELEE[d.weaponType] and dist > (tonumber(cfg('melee_range')) or 9) then
                if AC.ModeOf('melee_far') ~= 'log' then cancel() end
                Flag(src, 'melee_far', ('coup de mêlée à %d m'):format(math.floor(dist)))
            elseif TASER[d.weaponType] and dist > (tonumber(cfg('taser_range')) or 22) then
                if AC.ModeOf('melee_far') ~= 'log' then cancel() end
                Flag(src, 'melee_far', ('taser à %d m'):format(math.floor(dist)))
            end
            -- précision : part de tirs à la tête sur des joueurs/peds
            if GetEntityType and GetEntityType(tgt) == 1 then
                local t = AC.track[src]
                t.aim = t.aim or { n = 0, h = 0 }
                t.aim.n = t.aim.n + 1
                if tonumber(d.hitComponent) == 20 then t.aim.h = t.aim.h + 1 end
                local need = tonumber(cfg('aim_min_hits')) or 25
                if t.aim.n >= need then
                    local pct = t.aim.h * 100 / t.aim.n
                    if pct >= (tonumber(cfg('aim_ratio_pct')) or 80) then Flag(src, 'aim_ratio', ('%d têtes sur %d touches (%.0f %%)'):format(t.aim.h, t.aim.n, pct)) end
                    t.aim = nil
                end
            end
        end
    end
end)

-- Projectiles ---------------------------------------------------------------------------------------------------------------------------------
local bp
AddEventHandler('startProjectileEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    bp = bp or lowerSet(cfg('projectiles'))
    local name = bp[d.weaponHash] or bp[d.projectileHash]
    local n = bump(src, 'projectile', 10)
    if name then cancel() Flag(src, 'projectile', 'projectile interdit : ' .. name)
    elseif n > (tonumber(cfg('proj_max')) or 8) then cancel() if n == (tonumber(cfg('proj_max')) or 8) + 1 then Flag(src, 'projectile', ('%d projectiles en 10 s'):format(n)) end end
end)
PB.Cfg.OnChange('anticheat', function() bp = nil end)

-- Désarmer un autre joueur --------------------------------------------------------------------------------------------------------------------
AddEventHandler('removeAllWeaponsEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    local e = d.pedId and NetworkGetEntityFromNetworkId and NetworkGetEntityFromNetworkId(d.pedId)
    local owner = e and e ~= 0 and NetworkGetEntityOwner and NetworkGetEntityOwner(e) or nil
    if owner and owner ~= src and tracked(owner) then cancel() Flag(src, 'remove_weapons', 'armes retirées à #' .. tostring(owner)) end
end)

-- Entités créées en rafale (en plus de la liste noire déjà gérée) ------------------------------------------------------------------------------
AddEventHandler('entityCreating', function(ent)
    if cfg('enabled') == false or not ent or ent == 0 then return end
    local owner = NetworkGetEntityOwner and NetworkGetEntityOwner(ent) or nil
    local src = tracked(owner)
    if not src or not on(src) then return end
    local ty = GetEntityType and GetEntityType(ent) or 0
    local key, lim, lbl = nil, nil, nil
    if ty == 2 then key, lim, lbl = 'ent_veh', tonumber(cfg('ent_veh_max')) or 4, 'véhicules'
    elseif ty == 1 then key, lim, lbl = 'ent_ped', tonumber(cfg('ent_ped_max')) or 8, 'peds'
    elseif ty == 3 then key, lim, lbl = 'ent_obj', tonumber(cfg('ent_obj_max')) or 30, 'objets' end
    if not key then return end
    local n = bump(src, key, 10)
    if n > lim then
        cancel()
        if n == lim + 1 then Flag(src, 'entity_spam', ('%d %s en 10 s'):format(n, lbl)) end
    end
end)

-- Chat ----------------------------------------------------------------------------------------------------------------------------------------
local function hasWord(text, list)
    text = tostring(text or ''):lower()
    for _, w in ipairs(list or {}) do w = tostring(w):lower() if w ~= '' and text:find(w, 1, true) then return w end end
end
AddEventHandler('chatMessage', function(src, _, msg)
    src = tonumber(src)
    if not tracked(src) or not on(src) then return end
    local n = bump(src, 'chat', 10)
    local w = hasWord(msg, cfg('chat_words'))
    if w then if AC.ModeOf('chat_spam') ~= 'log' then cancel() end Flag(src, 'chat_spam', 'mot interdit : ' .. w) return end
    if n > (tonumber(cfg('chat_burst')) or 6) then cancel() if n == (tonumber(cfg('chat_burst')) or 6) + 1 then Flag(src, 'chat_spam', ('%d messages en 10 s'):format(n)) end end
end)

-- Pseudo à la connexion -----------------------------------------------------------------------------------------------------------------------
AddEventHandler('playerConnecting', function(name, setKickReason)
    if cfg('enabled') == false or AC.ModeOf('name') == 'off' then return end
    local src = source
    local okb, ex = pcall(AC.Bypass, src)
    if okb and ex then return end
    local why
    name = tostring(name or '')
    if #name:gsub('%s', '') < 2 then why = 'pseudo trop court ou vide'
    elseif #name > 40 then why = 'pseudo trop long'
    elseif name:find('[%z\1-\31\127]') or name:find('\226\128[\139-\143]') or name:find('\226\128[\168-\175]') or name:find('\239\187\191') then why = 'caractères invisibles ou de contrôle'
    else local w = hasWord(name, cfg('name_words')) if w then why = 'mot interdit : ' .. w end end
    if why then
        pcall(function() PB.Audit.Log('securite', 'anticheat.name', 0, name:sub(1, 40) .. ' — ' .. why) end)
        if AC.ModeOf('name') ~= 'log' then
            if CancelEvent then CancelEvent() end
            if setKickReason then setKickReason('Pseudo refusé (' .. why .. '). Change de pseudo FiveM puis reconnecte-toi.') end
        end
    end
end)

-- Rapports du client : signés avec le code de session, plausibles, puis recoupés par le serveur ------------------------------------------------
local function tok(sec, kind, val) return AC.Hash(sec .. '|' .. kind .. '|' .. tostring(math.floor(tonumber(val) or 0))) end
local LIMITS = { devtools = true, vehmod = true, dmgmod = true, god = true, vehboost = true, vehgod = true, hp = true, armor = true, noclip = true, speed = true, invisible = true, freecam = true, spectate = true, ammo = true, jump = true, tiny = true, vision = true, stamina = true, ragdoll = true }
RegisterNetEvent('pb:ac:rep', function(kind, val, proof)
    local src = source
    local t = AC.track[src]
    if not t or not on(src) then return end
    kind = tostring(kind or '')
    if not LIMITS[kind] or tonumber(proof) ~= tok(t.sec, kind, val) then return end   -- jeton faux : ignoré (un code périmé n'est jamais sanctionné)
    if (t.grace or 0) > os.time() then return end
    if bump(src, 'rep_' .. kind, 60) > 6 then return end                              -- un client ne peut pas inonder le serveur
    local S = G.Staff
    if S and S.OnDuty and S.OnDuty(src) then return end                               -- le staff en service peut être invisible, invincible…
    local ped = GetPlayerPed(src)
    local pl = G.Get and G.Get(src)
    local dead = pl and PB.ToBool(pl.row and pl.row.dead)
    local v = tonumber(val) or 0
    local msg
    if kind == 'hp' then
        if v > (tonumber(cfg('hp_max')) or 200) then msg = ('santé %d (max plausible %d)'):format(v, tonumber(cfg('hp_max')) or 200) end
    elseif kind == 'armor' then
        if v > (tonumber(cfg('armor_max')) or 100) then msg = ('armure %d'):format(v) end
    elseif kind == 'noclip' then
        local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
        if not dead and veh == 0 then msg = 'collisions désactivées et déplacement libre' end
    elseif kind == 'speed' then msg = ('vitesse à pied %.0f m/s'):format(v)
    elseif kind == 'invisible' then if not dead then msg = 'joueur invisible' end
    elseif kind == 'freecam' then msg = 'caméra libre'
    elseif kind == 'spectate' then msg = 'mode spectateur réseau'
    elseif kind == 'ammo' then msg = 'munitions infinies (aucune consommée)'
    elseif kind == 'jump' then msg = 'super saut'
    elseif kind == 'tiny' then msg = 'ped minuscule'
    elseif kind == 'vision' then msg = 'vision nocturne ou thermique'
    elseif kind == 'god' then if not dead and (pl and PB.ToBool(pl.row and pl.row.created)) then msg = 'invincibilité (le client ne peut pas être blessé)' end
    elseif kind == 'vehboost' then
        local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
        if veh ~= 0 then
            local vel = GetEntityVelocity(veh)
            local sp = math.sqrt(vel.x ^ 2 + vel.y ^ 2 + vel.z ^ 2)
            if v > (tonumber(cfg('veh_boost_pct')) or 190) and sp > 25 then msg = ('véhicule à %d %% du maximum de son modèle (%.0f m/s mesurés)'):format(v, sp) end
        end
    elseif kind == 'devtools' then msg = 'outils de développement de l\'interface ouverts'
    elseif kind == 'vehmod' then msg = ('modificateur de puissance ou de vitesse du véhicule à %d %%'):format(v)
    elseif kind == 'dmgmod' then msg = ('modificateur de dégâts/défense/régénération à %d %%'):format(v)
    elseif kind == 'vehgod' then msg = 'véhicule indestructible ou santé hors limites'
    elseif kind == 'stamina' then msg = 'endurance infinie'
    elseif kind == 'ragdoll' then msg = 'ragdoll désactivé' end
    if msg then t.rep = (t.rep or {}) t.rep[kind] = (t.rep[kind] or 0) + 1
        if t.rep[kind] >= ((kind == 'devtools' or v >= 2) and 1 or (tonumber(cfg('noclip_hits')) or 3)) then t.rep[kind] = 0 Flag(src, (kind == 'vehboost' and 'veh_boost') or (kind == 'vehgod' and 'veh_god') or (kind == 'dmgmod' and 'dmg_modifier') or (kind == 'devtools' and 'nui_devtools') or (kind == 'noclip' and 'noclip') or (kind == 'freecam' and 'freecam') or (kind == 'vehmod' and 'veh_boost') or 'client_report', msg) end
    else if t.rep then t.rep[kind] = 0 end end
end)

-- Ressources connues côté client : tout ce qui n'existe pas côté serveur est suspect -----------------------------------------------
local function serverRes()
    local s = {}
    for i = 0, (GetNumResources and GetNumResources() or 0) - 1 do local n = GetResourceByFindIndex(i) if n then s[n] = true end end
    return s
end
RegisterNetEvent('pb:ac:res', function(list, proof)
    local src = source
    local t = AC.track[src]
    if not t or not on(src) or type(list) ~= 'table' or #list > 600 then return end
    if tonumber(proof) ~= tok(t.sec, 'res', #list) then return end
    if (t.grace or 0) > os.time() or bump(src, 'res', 120) > 3 then return end
    local sr, bad = serverRes(), {}
    for _, n in ipairs(list) do n = tostring(n) if not sr[n] and #bad < 5 then bad[#bad + 1] = n:sub(1, 40) end end
    if #bad > 0 then Flag(src, 'resource_inject', 'ressources côté client inconnues du serveur : ' .. table.concat(bad, ', ')) end
end)

-- Changement de modèle de joueur (ped changer) : lu côté serveur, sans rien demander au client -----------------------------------------------
local allowedPed
PB.Cfg.OnChange('anticheat', function() allowedPed = nil end)
CreateThread(function()
    while true do
        Wait(5000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('ped_change') == 'off' then return end
            if not allowedPed then allowedPed = {} for _, m in ipairs(cfg('peds') or {}) do allowedPed[GetHashKey(tostring(m):lower())] = tostring(m):lower() end end
            local S = G.Staff
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 and (t.grace or 0) <= os.time() and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) then
                    local pl = G.Get and G.Get(src)
                    if pl and PB.ToBool(pl.row and pl.row.created) then
                        local m = GetEntityModel(ped)
                        if m ~= 0 and not allowedPed[m] then
                            t.pedBad = (t.pedBad or 0) + 1
                            if t.pedBad >= 3 then t.pedBad = 0 Flag(src, 'ped_change', ('modèle %s non autorisé'):format(tostring(m))) end
                        else t.pedBad = 0 end
                    end
                end
            end
        end)
    end
end)

-- Explosion loin de son auteur ----------------------------------------------------------------------------------------------------------------
AddEventHandler('explosionEvent', function(sender, ev)
    local src = tracked(sender)
    if not src or not on(src) or type(ev) ~= 'table' then return end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 or ev.posX == nil then return end
    local c = GetEntityCoords(ped)
    local dist = #(c - vector3(ev.posX + 0.0, ev.posY + 0.0, (ev.posZ or c.z) + 0.0))
    if dist > (tonumber(cfg('hit_range')) or 900) then
        if AC.ModeOf('hit_far') ~= 'log' then cancel() end
        Flag(src, 'hit_far', ('explosion à %d m de son auteur'):format(math.floor(dist)))
    end
end)

-- Contrôles lus par le SERVEUR (non falsifiables par le client) : santé, armure, vitesse à pied, arme en main ------------------------------------
local heldBad
PB.Cfg.OnChange('anticheat', function() heldBad = nil end)
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            if cfg('enabled') == false then return end
            heldBad = heldBad or lowerSet(cfg('weapons'))
            local S, n = G.Staff, os.time()
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                local pl = G.Get and G.Get(src)
                if ped and ped ~= 0 and (t.grace or 0) <= n and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) and pl and PB.ToBool(pl.row and pl.row.created) then
                    local hp, arm = GetEntityHealth(ped), GetPedArmour(ped)
                    if hp > (tonumber(cfg('hp_max')) or 200) or arm > (tonumber(cfg('armor_max')) or 100) then
                        t.hpBad = (t.hpBad or 0) + 1
                        if t.hpBad >= 3 then t.hpBad = 0 Flag(src, 'health_hack', ('santé %d, armure %d'):format(hp, arm)) end
                    else t.hpBad = 0 end
                    local w = GetSelectedPedWeapon(ped)
                    if heldBad[w] then
                        t.wBad = (t.wBad or 0) + 1
                        if t.wBad >= 2 then t.wBad = 0 Flag(src, 'weapon_held', 'arme en main : ' .. heldBad[w]) end
                    else t.wBad = 0 end
                    local c = GetEntityCoords(ped)
                    local veh = GetVehiclePedIsIn(ped, false)
                    local f = t.fs
                    if veh == 0 and not PB.ToBool(pl.row.dead) and f and n > f.t then
                        local dt = n - f.t
                        local dxy = math.sqrt((c.x - f.x) ^ 2 + (c.y - f.y) ^ 2)
                        local dz = math.abs(c.z - f.z)
                        if dxy / dt > (tonumber(cfg('foot_speed')) or 12) and dz / dt < 8 and dxy < (tonumber(cfg('tp_distance')) or 400) then
                            t.fsN = (t.fsN or 0) + 1
                            if t.fsN >= 4 then t.fsN = 0 Flag(src, 'speed_hack', ('%.1f m/s à pied'):format(dxy / dt)) end
                        else t.fsN = 0 end
                    else t.fsN = 0 end
                    t.fs = veh == 0 and { x = c.x, y = c.y, z = c.z, t = n } or nil
                end
            end
        end)
    end
end)

-- Identifiants exigés à la connexion ----------------------------------------------------------------------------------------------------------
AddEventHandler('playerConnecting', function(_, setKickReason)
    if cfg('enabled') == false or AC.ModeOf('ident') == 'off' then return end
    local src = source
    local okb, ex = pcall(AC.Bypass, src)
    if okb and ex then return end
    local have = {}
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do have[(id:match('^(%a+):') or ''):lower()] = true end
    for _, need in ipairs(cfg('require_idents') or {}) do
        need = tostring(need):lower()
        if need ~= '' and not have[need] then
            pcall(function() PB.Audit.Log('securite', 'anticheat.ident', 0, 'identifiant manquant : ' .. need) end)
            if AC.ModeOf('ident') ~= 'log' then
                if CancelEvent then CancelEvent() end
                if setKickReason then setKickReason(('Connexion refusée : ton compte %s doit être lié à FiveM (identifiant manquant).'):format(need)) end
            end
            return
        end
    end
end)

-- Captures d'écran (ressource screenshot-basic) envoyées sur un webhook Discord à chaque sanction --------------------------------------------
local B64 = {}
do local a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' for i = 1, #a do B64[a:byte(i)] = i - 1 end end
local function b64dec(d)
    d = d:gsub('^data:[^,]*,', ''):gsub('[^%w%+/]', '')
    local out, n = {}, #d
    for i = 1, n - n % 4, 4 do
        local a, b, c, e = d:byte(i, i + 3)
        local v = (B64[a] << 18) | (B64[b] << 12) | (B64[c] << 6) | B64[e]
        out[#out + 1] = string.char((v >> 16) & 255, (v >> 8) & 255, v & 255)
    end
    local r = n % 4
    if r >= 2 then
        local a, b, c = d:byte(n - r + 1, n - r + 3)
        local v = (B64[a] << 18) | (B64[b] << 12) | ((c and B64[c] or 0) << 6)
        out[#out + 1] = string.char((v >> 16) & 255) .. (r == 3 and string.char((v >> 8) & 255) or '')
    end
    return table.concat(out)
end
local lastShot, shotOff, shotFails, shotAvg = {}, 0, 0, nil
function AC.Shot(src, kind, detail, mode, act)
    local url = tostring(cfg('shot_webhook') or '')
    local severe = mode == 'kick' or mode == 'ban'
    if url == '' or not url:match('^https://') or kind == 'heartbeat' or kind == 'resource_stop' or (not severe and cfg('shot_on') ~= 'all')
        or GetResourceState('screenshot-basic') ~= 'started' or (lastShot[src] or 0) > os.time() - 60 or not PerformHttpRequest then
        act() return
    end
    if shotOff > os.time() then act() return end   -- les captures n'aboutissent plus (client sans réponse) : le ban n’attend rien
    lastShot[src] = os.time()
    local done = false
    local t0 = GetGameTimer()
    local function go() if not done then done = true act() end end
    -- attente adaptative : le double du temps de capture habituel (entre 350 et 900 ms) ; 3 échecs de suite coupent les captures 5 minutes
    local wait = shotAvg and math.max(350, math.min(900, math.floor(shotAvg * 2))) or 900
    if severe then SetTimeout(wait, function() if not done then shotFails = shotFails + 1 if shotFails >= 3 then shotOff = os.time() + 300 shotFails = 0 end end go() end) else go() end
    local name = GetPlayerName(src) or ('#' .. src)
    local ok = pcall(function()
        exports['screenshot-basic']:requestClientScreenshot(src, { encoding = 'jpg', quality = 0.6 }, function(err, data)
            if err or type(data) ~= 'string' or #data < 100 then go() return end
            if not done then shotFails = 0 local dt = GetGameTimer() - t0 shotAvg = shotAvg and (shotAvg * 0.7 + dt * 0.3) or dt end
            local okd, bin = pcall(b64dec, data)
            if not okd or #bin < 100 then go() return end
            local bd = 'wbshot' .. math.random(100000, 999999)
            local content = ('Anticheat — %s (%s) : %s · %s · %s'):format(name, G.Tag(src), kind, (detail or ''):sub(1, 150), mode)
            local js = '{"content":' .. json.encode(content) .. '}'
            local body = '--' .. bd .. '\r\nContent-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json\r\n\r\n' .. js
                .. '\r\n--' .. bd .. '\r\nContent-Disposition: form-data; name="files[0]"; filename="capture.jpg"\r\nContent-Type: image/jpeg\r\n\r\n' .. bin .. '\r\n--' .. bd .. '--\r\n'
            PerformHttpRequest(url, function() end, 'POST', body, { ['Content-Type'] = 'multipart/form-data; boundary=' .. bd })
            go()
        end)
    end)
    if not ok then go() end
end

-- Types d'explosion impossibles en RP (liste réglable) -----------------------------------------------------------------------------------------
local badExp
PB.Cfg.OnChange('anticheat', function() badExp = nil end)
AddEventHandler('explosionEvent', function(sender, ev)
    local src = tracked(sender)
    if not src or not on(src) or type(ev) ~= 'table' then return end
    if not badExp then badExp = {} for _, n in ipairs(cfg('explosion_types') or {}) do badExp[tonumber(n) or -1] = true end end
    if badExp[tonumber(ev.explosionType) or -2] then cancel() Flag(src, 'explosion_type', 'type d\'explosion ' .. tostring(ev.explosionType)) end
end)

-- Une arme retirée à un autre joueur (évènement distinct de « toutes les armes ») ------------------------------------------------------------------
AddEventHandler('removeWeaponEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    local e = d.pedId and NetworkGetEntityFromNetworkId and NetworkGetEntityFromNetworkId(d.pedId)
    local owner = e and e ~= 0 and NetworkGetEntityOwner and NetworkGetEntityOwner(e) or nil
    if owner and owner ~= src and tracked(owner) then cancel() Flag(src, 'remove_weapons', 'arme retirée à #' .. tostring(owner)) end
end)

-- Super saut lu par le serveur -------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('super_jump') == 'off' or not IsPlayerUsingSuperJump then return end
            local S = G.Staff
            for src, t in pairs(AC.track) do
                if (t.grace or 0) <= os.time() and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) then
                    if IsPlayerUsingSuperJump(src) then
                        t.sj = (t.sj or 0) + 1
                        if t.sj >= 3 then t.sj = 0 Flag(src, 'super_jump', 'super saut lu par le serveur') end
                    else t.sj = 0 end
                end
            end
        end)
    end
end)

-- Noclip lu par le serveur : joueur FIGÉ qui se déplace, ou qui se déplace vite sans AUCUNE vitesse (position réécrite à chaque image) -----------
-- Autocalibration : la règle « position sans vitesse » ne s'applique que si, sur CE serveur, la vitesse lue colle à la position chez les joueurs normaux.
local calib = { good = 0, bad = 0 }
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('noclip') == 'off' then return end
            local S, n = G.Staff, os.time()
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                local pl = G.Get and G.Get(src)
                if ped and ped ~= 0 and (t.grace or 0) <= n and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) and pl and PB.ToBool(pl.row and pl.row.created) and not PB.ToBool(pl.row.dead) then
                    local c = GetEntityCoords(ped)
                    local prev = t.nc
                    local veh = GetVehiclePedIsIn(ped, false)
                    t.nc = veh == 0 and { x = c.x, y = c.y, z = c.z, t = n } or nil
                    if prev and veh == 0 and n > prev.t then
                        local dt = n - prev.t
                        local dist = math.sqrt((c.x - prev.x) ^ 2 + (c.y - prev.y) ^ 2 + (c.z - prev.z) ^ 2)
                        local sp = dist / dt
                        if dist < (tonumber(cfg('tp_distance')) or 400) and sp > 3 and sp < 150 then
                            local frozen = IsEntityPositionFrozen and IsEntityPositionFrozen(ped)
                            local v = GetEntityVelocity(ped)
                            local sv = math.sqrt(v.x ^ 2 + v.y ^ 2 + v.z ^ 2)
                            local mismatch = sp > 6 and sv < sp * 0.25
                            if sp > 6 then if mismatch then calib.bad = calib.bad + 1 else calib.good = calib.good + 1 end end
                            local trusted = calib.good >= 200 and calib.bad < calib.good * 0.02
                            if frozen then
                                t.ncF = (t.ncF or 0) + 1
                                if t.ncF >= 4 then t.ncF = 0 Flag(src, 'noclip', ('déplacé à %.1f m/s alors que le joueur est figé'):format(sp)) end
                            else t.ncF = 0 end
                            if mismatch and trusted then
                                t.ncV = (t.ncV or 0) + 1
                                if t.ncV >= 5 then t.ncV = 0 Flag(src, 'noclip', ('déplacé à %.1f m/s pour une vitesse lue de %.1f m/s'):format(sp, sv)) end
                            elseif not mismatch then t.ncV = 0 end
                        else t.ncF, t.ncV = 0, 0 end
                    end
                else t.nc = nil end
            end
        end)
    end
end)

-- Commandes de l'anticheat ------------------------------------------------------------------------------------------------------------------------
-- Console (txAdmin) ou en jeu pour qui a la permission « anticheat.edit » (lecture seule : « anticheat.view »). Tape « achelp » pour la liste.
local P, DB = PB.Perm, PB.DB
local function say(src, msg)
    msg = tostring(msg)
    if src and src > 0 then TriggerClientEvent('chat:addMessage', src, { color = { 155, 140, 255 }, args = { 'Anticheat', msg } }) end
    print('^3[Anticheat]^7 ' .. msg:gsub('%^%d', ''))
end
local function allowed(src, edit)
    if not src or src == 0 then return true end
    return P.Has(src, edit and 'anticheat.edit' or 'anticheat.view') and true or false
end
local function fdate(t) return t and t > 0 and os.date('%d/%m %H:%M', t) or '—' end
local function joined(args, from) local t = {} for i = from, #args do t[#t + 1] = args[i] end return table.concat(t, ' ') end
local function target(src, a)
    local id = tonumber(a)
    if not id or id <= 0 or not GetPlayerName(id) then say(src, "Joueur introuvable : donne l'ID de serveur d'un joueur connecté.") return nil end
    return id
end
local function cmd(name, edit, fn)
    RegisterCommand(name, function(src, args)
        if not allowed(src, edit) then say(src, "Tu n'as pas la permission pour cette commande.") return end
        local ok, err = pcall(fn, src, args)
        if not ok then say(src, 'Erreur : ' .. tostring(err)) end
    end, false)
end
local function actorName(src) return src == 0 and 'Console' or ((PB.Actor and PB.Actor(src).name) or GetPlayerName(src) or ('#' .. src)) end
local function audit(src, what, detail) pcall(function() PB.Audit.Log('securite', 'anticheat.cmd.' .. what, src, tostring(detail or ''), nil, { by = actorName(src) }) end) end
local function banRows(where, params, limit)
    return DB.q("SELECT id, name, license, reason, by_name, created, expires FROM pb_sanctions WHERE kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?) " .. where .. ' ORDER BY id DESC LIMIT ' .. (limit or 10), params) or {}
end

cmd('achelp', false, function(src)
    for _, l in ipairs({
        'achelp · acstatus · acmodes · acalertes [n] · acinfo <id> · acbans [page] [texte] · acshield · acdisjoncteur [reset [détection]]',
        'acban <id> [motif] · ackick <id> [motif] · acbanoff <licence> [motif] · acunban (liste les bans, puis acunban <n°> [n° …] ou acunban <pseudo|licence>) · acdebannir (= acunban)',
        'acmode <détection> <off|log|kick|ban> · acpreset <safe|strict|max> · acon · acoff · acshieldmode <log|block>',
        'acquarantaine <id> · acliberer <id> · acgrace <id> [secondes] · acattendre <ressource> [secondes] · acreset <id> · acrecherche <texte>',
    }) do say(src, l) end
end)

cmd('acstatus', false, function(src)
    local modes = { ban = 0, kick = 0, log = 0, off = 0 }
    for _, k in ipairs(AC.Kinds or {}) do local m = AC.ModeOf(k[1]) modes[m] = (modes[m] or 0) + 1 end
    local sh = 'absent'
    if GetResourceState('wb_shield') == 'started' then
        local ok, st = pcall(function() return exports.wb_shield:Stats() end)
        sh = ok and st and (('%s, %d évènements dont %d armés, %d refusés'):format(st.mode, st.events, st.armed, st.bad or 0)) or 'démarré'
    end
    local n = 0 for _ in pairs(AC.track or {}) do n = n + 1 end
    say(src, ('Anticheat %s · %d joueur(s) suivi(s) · alertes en mémoire : %d · expulsions %d, bans %d'):format(cfg('enabled') ~= false and 'ACTIF' or 'ÉTEINT', n, #AC.alerts, AC.counts.kick or 0, AC.counts.ban or 0))
    say(src, ('Détections : %d en ban, %d en kick, %d en journal, %d coupées · bouclier : %s'):format(modes.ban, modes.kick, modes.log, modes.off, sh))
    local tr = {}
    for k, b in pairs(AC.breaker or {}) do if (b.untilT or 0) > os.time() then tr[#tr + 1] = k .. ' (' .. (b.untilT - os.time()) .. ' s)' end end
    say(src, 'Coupe-circuit en pause : ' .. (#tr > 0 and table.concat(tr, ', ') or 'aucun'))
end)

cmd('acmodes', false, function(src)
    for _, m in ipairs({ 'ban', 'kick', 'log', 'off' }) do
        local l = {}
        for _, k in ipairs(AC.Kinds or {}) do if AC.ModeOf(k[1]) == m then l[#l + 1] = k[1] end end
        say(src, ('%s (%d) : %s'):format(m, #l, #l > 0 and table.concat(l, ', ') or '—'))
    end
end)

cmd('acmode', true, function(src, a)
    local k, m = tostring(a[1] or ''), tostring(a[2] or ''):lower()
    if not (AC.KindMap and AC.KindMap[k]) then say(src, "Détection inconnue. « acmodes » donne la liste.") return end
    if m ~= 'off' and m ~= 'log' and m ~= 'kick' and m ~= 'ban' then say(src, 'Mode : off, log, kick ou ban.') return end
    PB.Cfg.Set('anticheat', 'mode_' .. k, m, PB.Actor and PB.Actor(src) or nil, 'Commande acmode')
    audit(src, 'mode', k .. ' -> ' .. m)
    say(src, ('« %s » est maintenant en « %s ».'):format(k, m))
end)

cmd('acpreset', true, function(src, a)
    local id = tostring(a[1] or ''):lower()
    if not (AC.Presets and AC.Presets[id]) then say(src, 'Profil : safe, strict ou max.') return end
    AC.ApplyPreset(id, PB.Actor and PB.Actor(src) or nil)
    audit(src, 'profil', id)
    say(src, ('Profil « %s » appliqué à toutes les détections.'):format(AC.Presets[id].label))
end)

for _, v in ipairs({ { 'acon', true }, { 'acoff', false } }) do
    cmd(v[1], true, function(src)
        PB.Cfg.Set('anticheat', 'enabled', v[2], PB.Actor and PB.Actor(src) or nil, 'Commande ' .. v[1])
        audit(src, v[1], '')
        say(src, v[2] and 'Anticheat ACTIVÉ.' or 'Anticheat ÉTEINT (rien ne sera détecté ni sanctionné).')
    end)
end

cmd('acalertes', false, function(src, a)
    local n = math.max(1, math.min(30, tonumber(a[1]) or 10))
    if #AC.alerts == 0 then say(src, 'Aucune alerte depuis le démarrage.') return end
    for i = 1, math.min(n, #AC.alerts) do
        local x = AC.alerts[i]
        say(src, ('%s · %s%s · %s · %s · %s'):format(fdate(x.at), x.src > 0 and ('[' .. x.src .. '] ') or '', x.name, x.kind, x.mode, x.detail ~= '' and x.detail or '—'))
    end
end)

cmd('acrecherche', false, function(src, a)
    local q = joined(a, 1):lower()
    if q == '' then say(src, 'Donne un texte (pseudo, détection ou détail).') return end
    local c = 0
    for _, x in ipairs(AC.alerts) do
        if (tostring(x.name) .. ' ' .. x.kind .. ' ' .. tostring(x.detail)):lower():find(q, 1, true) then
            c = c + 1
            if c <= 15 then say(src, ('%s · [%s] %s · %s · %s · %s'):format(fdate(x.at), x.src, x.name, x.kind, x.mode, x.detail)) end
        end
    end
    say(src, c .. ' résultat(s) dans les alertes en mémoire.')
end)

cmd('acinfo', false, function(src, a)
    local id = target(src, a[1]) if not id then return end
    local t = AC.track[id]
    say(src, ('[%d] %s · licence %s · exempté : %s · suivi : %s · détections : %d'):format(id, GetPlayerName(id), tostring((GetPlayerIdentifierByType and GetPlayerIdentifierByType(id, 'license')) or '?'), AC.Bypass(id) and 'oui' or 'non', t and 'oui' or 'non', t and t.flags or 0))
    local r = AC.recent[id]
    if r then say(src, ('Dernier signal fort : %s à %s'):format(r.kind, fdate(r.at))) end
    local c = 0
    for _, x in ipairs(AC.alerts) do
        if x.src == id then c = c + 1 if c <= 6 then say(src, ('  %s · %s · %s · %s'):format(fdate(x.at), x.kind, x.mode, x.detail)) end end
    end
    if c == 0 then say(src, "  Aucune alerte en mémoire pour ce joueur.") end
    local lic = (GetPlayerIdentifierByType and GetPlayerIdentifierByType(id, 'license')) or ''
    local b = lic ~= '' and banRows('AND (license = ? OR license LIKE ?)', { os.time(), lic, lic .. '%' }, 1)[1]
    if b then say(src, ('Ban actif n°%d : %s'):format(b.id, b.reason)) end
end)

cmd('acreset', true, function(src, a)
    local id = target(src, a[1]) if not id then return end
    local t = AC.track[id]
    if t then t.hist, t.flags, t.rate, t.ncF, t.ncV = {}, 0, {}, 0, 0 end
    AC.recent[id] = nil
    for i = #AC.alerts, 1, -1 do if AC.alerts[i].src == id then table.remove(AC.alerts, i) end end
    audit(src, 'reset', GetPlayerName(id))
    say(src, ('Compteurs de %s remis à zéro.'):format(GetPlayerName(id)))
end)

cmd('acgrace', true, function(src, a)
    local id = target(src, a[1]) if not id then return end
    local s = math.max(1, math.min(600, tonumber(a[2]) or 60))
    AC.Grace(id, s)
    say(src, ('%s est ignoré par les détections statistiques pendant %d s.'):format(GetPlayerName(id), s))
end)

cmd('acattendre', true, function(src, a)
    local r = tostring(a[1] or '')
    if r == '' then say(src, 'Usage : acattendre <ressource> [secondes] (annonce un arrêt ou redémarrage voulu).') return end
    local s = math.max(5, math.min(900, tonumber(a[2]) or 60))
    AC.Expect(r, s)
    say(src, ('L\'arrêt de « %s » est attendu pendant %d s (pas d\'alerte).'):format(r, s))
end)

cmd('acquarantaine', true, function(src, a)
    local id = target(src, a[1]) if not id then return end
    AC.Quarantine(id, true)
    audit(src, 'quarantaine', GetPlayerName(id))
    say(src, ('%s est isolé dans un monde privé et ses évènements protégés sont refusés. « acliberer %d » pour le remettre.'):format(GetPlayerName(id), id))
end)
cmd('acliberer', true, function(src, a)
    local id = target(src, a[1]) if not id then return end
    AC.Quarantine(id, false)
    audit(src, 'liberer', GetPlayerName(id))
    say(src, GetPlayerName(id) .. ' est sorti de quarantaine.')
end)

local function doBan(src, id, reason)
    local S = G.Staff
    if not (S and S.AddSanction) then say(src, 'Le module staff est indisponible.') return end
    local pl = G.Get and G.Get(id)
    local lic = pl and pl.license or (GetPlayerIdentifiers(id) or {})[1] or ''
    local ids = {}
    for _, x in ipairs(GetPlayerIdentifiers(id) or {}) do if not x:match('^ip:') then ids[#ids + 1] = x end end
    local name = GetPlayerName(id) or 'Inconnu'
    local sid = S.AddSanction('ban', lic, name, reason, src, 0, ids)
    local row = sid and DB.one('SELECT reason, expires FROM pb_sanctions WHERE id = ?', { sid })
    PB.Drop(id, 'ban', 'anticheat', 'Banni : ' .. reason, ('Ban par commande (%s).'):format(actorName(src)), actorName(src), (S.BanText and row) and S.BanText(row) or nil)
    return sid, name
end
cmd('acban', true, function(src, a)
    local id = target(src, a[1]) if not id then return end
    if id ~= src and AC.Bypass(id) and src ~= 0 then say(src, "Ce joueur est exempté de l'anticheat (staff) : utilise la console.") return end
    local r = joined(a, 2) if r == '' then r = 'Triche (commande anticheat)' end
    local sid, name = doBan(src, id, r)
    audit(src, 'ban', ('%s : %s'):format(tostring(name), r))
    say(src, ('%s est banni (ban n°%s).'):format(tostring(name), tostring(sid)))
end)
cmd('ackick', true, function(src, a)
    local id = target(src, a[1]) if not id then return end
    local r = joined(a, 2) if r == '' then r = 'Expulsé par le staff (commande anticheat)' end
    local name = GetPlayerName(id)
    PB.Drop(id, 'kick', 'anticheat', r, ('Expulsion par commande (%s).'):format(actorName(src)), actorName(src))
    audit(src, 'kick', ('%s : %s'):format(name, r))
    say(src, name .. ' est expulsé.')
end)
cmd('acbanoff', true, function(src, a)
    local lic = tostring(a[1] or ''):gsub('^license:', ''):gsub('[^%w]', '')
    if #lic < 6 then say(src, 'Usage : acbanoff <licence ou fin de licence (6 caractères mini)> [motif].') return end
    local rows = DB.q('SELECT license, firstname, lastname FROM pb_players WHERE license LIKE ? LIMIT 3', { '%' .. lic .. '%' }) or {}
    if #rows == 0 then say(src, 'Aucun joueur connu avec cette licence.') return end
    if #rows > 1 then say(src, 'Plusieurs joueurs correspondent : précise la licence.') return end
    local row = rows[1]
    local r = joined(a, 2) if r == '' then r = 'Triche (commande anticheat)' end
    local name = ((row.firstname or '') .. ' ' .. (row.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    local sid = G.Staff.AddSanction('ban', row.license, name ~= '' and name or 'Inconnu', r, src, 0, { row.license })
    for t, pl in pairs(G.Players()) do if pl.license == row.license then PB.Drop(t, 'ban', 'anticheat', 'Banni : ' .. r, 'Ban hors ligne appliqué au joueur connecté.', actorName(src)) end end
    audit(src, 'banoff', row.license .. ' : ' .. r)
    say(src, ('%s est banni (ban n°%s).'):format(name ~= '' and name or row.license, tostring(sid)))
end)

local function listBans(src, filter, page, onlyAc)
    local where, prm = '', { os.time() }
    if onlyAc then where = " AND reason LIKE 'Anticheat%'" end
    if filter and filter ~= '' then where = where .. ' AND (name LIKE ? OR license LIKE ? OR reason LIKE ?)' local l = '%' .. filter .. '%' prm[#prm + 1] = l prm[#prm + 1] = l prm[#prm + 1] = l end
    local per, off = 12, ((page or 1) - 1) * 12
    local all = DB.q("SELECT id, name, license, reason, by_name, created, expires FROM pb_sanctions WHERE kind = 'ban' AND revoked = 0 AND (expires = 0 OR expires > ?)" .. where .. ' ORDER BY id DESC LIMIT ' .. per .. ' OFFSET ' .. off, prm) or {}
    if #all == 0 then say(src, page and page > 1 and 'Plus de résultats.' or 'Aucun ban actif.') return end
    say(src, ('--- Bans actifs, page %d%s ---'):format(page or 1, filter and filter ~= '' and (' · filtre « ' .. filter .. ' »') or ''))
    for _, r in ipairs(all) do say(src, ('n°%d · %s · %s · %s · %s'):format(r.id, fdate(r.created), tostring(r.name), tostring(r.reason):sub(1, 70), tostring(r.license):sub(-12))) end
    say(src, 'Lever : acunban <n°> [n° n° …]  ·  page suivante : ' .. 'acbans ' .. ((page or 1) + 1) .. (filter and filter ~= '' and (' ' .. filter) or ''))
end
local function unban(src, a)
    local q = tostring(a[1] or '')
    if q == '' then listBans(src) return end
    local rows = {}
    local allnum = #a > 0
    for _, x in ipairs(a) do if not tonumber(x) then allnum = false end end
    if allnum then
        -- un ou plusieurs numéros de ban : acunban 12 15 18
        for _, x in ipairs(a) do for _, r in ipairs(banRows('AND id = ?', { os.time(), tonumber(x) }, 1)) do rows[#rows + 1] = r end end
        if #rows == 0 and #a == 1 and GetPlayerName(tonumber(a[1])) then
            -- aucun ban de ce numéro, mais un joueur connecté avec cet ID : ses bans
            local lic = (GetPlayerIdentifierByType and GetPlayerIdentifierByType(tonumber(a[1]), 'license')) or ''
            rows = banRows('AND (license = ? OR license LIKE ?)', { os.time(), lic, lic .. '%' }, 5)
        end
    else
        local lic = q:gsub('^license:', ''):gsub('[^%w]', '')
        if #lic < 3 then say(src, 'Recherche trop courte (3 caractères mini).') return end
        rows = banRows('AND (license LIKE ? OR name LIKE ?)', { os.time(), '%' .. lic .. '%', '%' .. q .. '%' }, 12)
        if #rows > 1 then listBans(src, q) return end   -- plusieurs correspondances : on affiche la liste, tu choisis le n°
    end
    if #rows == 0 then say(src, 'Aucun ban actif trouvé. « acunban » seul affiche la liste.') return end
    for _, r in ipairs(rows) do
        DB.exec('UPDATE pb_sanctions SET revoked = 1, revoked_by = ? WHERE id = ?', { actorName(src):sub(1, 64), r.id })
        audit(src, 'unban', ('n°%d %s'):format(r.id, tostring(r.name)))
        say(src, ('Ban n°%d levé : %s (%s).'):format(r.id, tostring(r.name), tostring(r.reason)))
    end
end
cmd('acunban', true, unban)
cmd('acdebannir', true, unban)

cmd('acbans', false, function(src, a)
    local page = tonumber(a[1])
    local filter = joined(a, page and 2 or 1)
    listBans(src, filter, page or 1, false)
end)

cmd('acshield', false, function(src)
    if GetResourceState('wb_shield') ~= 'started' then say(src, 'wb_shield n\'est pas démarré (état : ' .. GetResourceState('wb_shield') .. ').') return end
    local ok, st = pcall(function() return exports.wb_shield:Stats() end)
    if not ok or not st then say(src, 'wb_shield ne répond pas.') return end
    say(src, ('Bouclier : mode %s · %d évènements surveillés, %d armés · jetons valides %d, refusés %d, sans jeton %d, rafales %d'):format(st.mode, st.events, st.armed, st.ok or 0, st.bad or 0, st.notoken or 0, st.flood or 0))
end)
cmd('acshieldmode', true, function(src, a)
    local m = tostring(a[1] or ''):lower()
    if m ~= 'log' and m ~= 'block' then say(src, 'Mode : log (observe seulement) ou block (refuse).') return end
    SetConvar('wb_shield_mode', m)
    audit(src, 'shieldmode', m)
    say(src, 'wb_shield en mode « ' .. m .. ' » (jusqu\'au redémarrage : mets « set wb_shield_mode ' .. m .. ' » dans server.cfg pour le garder).')
end)

cmd('acdisjoncteur', true, function(src, a)
    if tostring(a[1] or '') == 'reset' then
        local k = a[2]
        if k then AC.breaker[k] = nil else AC.breaker = {} end
        audit(src, 'disjoncteur', tostring(k or 'tout'))
        say(src, k and ('Coupe-circuit de « ' .. k .. ' » réarmé.') or 'Tous les coupe-circuits sont réarmés.')
        return
    end
    local c = 0
    for k, b in pairs(AC.breaker) do
        if (b.untilT or 0) > os.time() then c = c + 1 say(src, ('« %s » suspendu encore %d s (« acdisjoncteur reset %s » pour réarmer).'):format(k, b.untilT - os.time(), k)) end
    end
    if c == 0 then say(src, 'Aucun coupe-circuit déclenché.') end
end)

-- Rappel au démarrage : captures d'écran avant chaque bannissement (staff, commandes et anticheat)
CreateThread(function()
    Wait(25000)
    local url = tostring(cfg('shot_webhook') or '')
    local why
    if GetResourceState('screenshot-basic') ~= 'started' then why = "la ressource « screenshot-basic » n'est pas démarrée (ajoute « ensure screenshot-basic » dans server.cfg)"
    elseif not url:match('^https://') then why = "aucun webhook Discord réglé (panel › Anticheat › Listes noires › Webhook Discord pour les captures d'écran)" end
    if why then print('^3[Anticheat]^7 Captures avant bannissement INACTIVES : ' .. why .. '.')
    else print('^2[Anticheat]^7 Captures avant bannissement actives : envoyées sur ton webhook Discord.') end
end)

-- Catalogue : liste des véhicules et des armes, « tout bloquer » / « tout débloquer » ---------------------------------------------------------------
local B = PB.B
local WEAPON_LIST = {
    'weapon_dagger', 'weapon_bat', 'weapon_bottle', 'weapon_crowbar', 'weapon_flashlight', 'weapon_golfclub', 'weapon_hammer', 'weapon_hatchet', 'weapon_knuckle', 'weapon_knife', 'weapon_machete', 'weapon_switchblade', 'weapon_nightstick', 'weapon_wrench', 'weapon_battleaxe', 'weapon_poolcue', 'weapon_stone_hatchet',
    'weapon_pistol', 'weapon_pistol_mk2', 'weapon_combatpistol', 'weapon_appistol', 'weapon_stungun', 'weapon_pistol50', 'weapon_snspistol', 'weapon_snspistol_mk2', 'weapon_heavypistol', 'weapon_vintagepistol', 'weapon_flaregun', 'weapon_marksmanpistol', 'weapon_revolver', 'weapon_revolver_mk2', 'weapon_doubleaction', 'weapon_raypistol', 'weapon_ceramicpistol', 'weapon_navyrevolver', 'weapon_gadgetpistol',
    'weapon_microsmg', 'weapon_smg', 'weapon_smg_mk2', 'weapon_assaultsmg', 'weapon_combatpdw', 'weapon_machinepistol', 'weapon_minismg', 'weapon_raycarbine',
    'weapon_pumpshotgun', 'weapon_pumpshotgun_mk2', 'weapon_sawnoffshotgun', 'weapon_assaultshotgun', 'weapon_bullpupshotgun', 'weapon_musket', 'weapon_heavyshotgun', 'weapon_dbshotgun', 'weapon_autoshotgun', 'weapon_combatshotgun',
    'weapon_assaultrifle', 'weapon_assaultrifle_mk2', 'weapon_carbinerifle', 'weapon_carbinerifle_mk2', 'weapon_advancedrifle', 'weapon_specialcarbine', 'weapon_specialcarbine_mk2', 'weapon_bullpuprifle', 'weapon_bullpuprifle_mk2', 'weapon_compactrifle', 'weapon_militaryrifle', 'weapon_heavyrifle', 'weapon_tacticalrifle',
    'weapon_mg', 'weapon_combatmg', 'weapon_combatmg_mk2', 'weapon_gusenberg',
    'weapon_sniperrifle', 'weapon_heavysniper', 'weapon_heavysniper_mk2', 'weapon_marksmanrifle', 'weapon_marksmanrifle_mk2', 'weapon_precisionrifle',
    'weapon_rpg', 'weapon_grenadelauncher', 'weapon_grenadelauncher_smoke', 'weapon_minigun', 'weapon_firework', 'weapon_railgun', 'weapon_hominglauncher', 'weapon_compactlauncher', 'weapon_rayminigun', 'weapon_emplauncher',
    'weapon_grenade', 'weapon_bzgas', 'weapon_molotov', 'weapon_stickybomb', 'weapon_proxmine', 'weapon_snowball', 'weapon_pipebomb', 'weapon_ball', 'weapon_smokegrenade', 'weapon_flare',
    'weapon_petrolcan', 'weapon_fireextinguisher', 'weapon_hazardcan', 'weapon_fertilizercan',
}
local function nice(n) return (tostring(n):gsub('^weapon_', ''):gsub('_', ' ')) end
local function inList(l, v) v = tostring(v):lower() for _, x in ipairs(l or {}) do if tostring(x):lower() == v then return true end end return false end
local function setList(ctx, key, list, why) return PB.Cfg.Set('anticheat', key, list, ctx.actor, why) end

PB.Action('anticheat.block_toggle', 'anticheat.edit', function(ctx, p)
    local key = p.kind == 'weapons' and 'weapons' or 'models'
    local name = tostring(p.name or ''):lower()
    if not name:match('^[%w_]+$') then return false, 'Nom invalide.' end
    local cur, out, had = cfg(key) or {}, {}, false
    for _, x in ipairs(cur) do if tostring(x):lower() == name then had = true else out[#out + 1] = x end end
    if not had then out[#out + 1] = name end
    setList(ctx, key, out, (had and 'Débloqué : ' or 'Bloqué : ') .. name)
    ctx.audit('securite', 'anticheat.' .. (had and 'debloque' or 'bloque'), name)
    ctx.toast = name .. (had and ' est débloqué.' or ' est bloqué.')
    return true
end)
for _, w in ipairs({ { 'vehicles', 'block_all_vehicles', 'les véhicules' }, { 'objects', 'block_all_objects', 'les objets (props)' } }) do
    for _, on in ipairs({ true, false }) do
        PB.Action('anticheat.all_' .. w[1] .. (on and '_on' or '_off'), 'anticheat.edit', function(ctx)
            PB.Cfg.Set('anticheat', w[2], on, ctx.actor, on and ('Tout bloquer : ' .. w[3]) or ('Tout débloquer : ' .. w[3]))
            ctx.audit('securite', 'anticheat.' .. w[2], tostring(on))
            ctx.toast = on and ('Tous ' .. w[3] .. ' créés par les joueurs sont bloqués.') or ('Blocage de ' .. w[3] .. ' retiré.')
            return true
        end, on and { critical = true, confirm = { title = 'Bloquer ' .. w[3] .. ' ?', text = "Toute création par un joueur est annulée (les ressources déclarées au bouclier restent permises). Teste d'abord avec le mode « Journaliser » de la détection « Création bloquée par tout bloquer »." } } or nil)
    end
end
PB.Action('anticheat.unblock_all', 'anticheat.edit', function(ctx)
    PB.Cfg.Set('anticheat', 'block_all_vehicles', false, ctx.actor, 'Tout débloquer')
    PB.Cfg.Set('anticheat', 'block_all_objects', false, ctx.actor, 'Tout débloquer')
    setList(ctx, 'models', {}, 'Tout débloquer')
    setList(ctx, 'weapons', {}, 'Tout débloquer')
    setList(ctx, 'projectiles', {}, 'Tout débloquer')
    ctx.audit('securite', 'anticheat.tout_debloquer', '')
    ctx.toast = 'Tout est débloqué : plus aucun véhicule, objet, arme ni projectile interdit.'
    return true
end, { critical = true, confirm = { title = 'Tout débloquer ?', text = 'Vide les listes noires (modèles, armes, projectiles) et retire « tout bloquer ». Tu pourras remettre les listes par défaut ensuite.' } })
PB.Action('anticheat.reset_lists', 'anticheat.edit', function(ctx)
    local d = AC.Defaults or {}
    PB.Cfg.Set('anticheat', 'block_all_vehicles', false, ctx.actor, 'Listes par défaut')
    PB.Cfg.Set('anticheat', 'block_all_objects', false, ctx.actor, 'Listes par défaut')
    for _, k in ipairs({ 'models', 'weapons', 'projectiles' }) do setList(ctx, k, d[k] or {}, 'Listes par défaut') end
    ctx.audit('securite', 'anticheat.listes_defaut', '')
    ctx.toast = 'Listes noires remises à leurs valeurs par défaut.'
    return true
end, { critical = true, confirm = { title = 'Remettre les listes par défaut ?', text = 'Les armes, modèles et projectiles interdits reviennent à la liste d\'origine ; tes ajouts sont perdus.' } })

PB.Action('anticheat.spectate', 'staff.spectate', function(ctx, p)
    if ctx.web or not ctx.src or ctx.src <= 0 then return false, "L'observation se lance depuis le panel en jeu (pas depuis le navigateur)." end
    local id = math.floor(tonumber(p.sid) or 0)
    if not GetPlayerName(id) then return false, "Ce joueur n'est plus connecté." end
    local S = G.Staff
    if not (S and S.SpectateFull) then return false, 'Observation indisponible.' end
    local ok, msg = S.SpectateFull(ctx.src, id)
    ctx.toast = msg
    return ok
end)

function AC.CatalogTab(ctx)
    local edit = ctx.has('anticheat.edit')
    local blockV, blockO = cfg('block_all_vehicles') == true, cfg('block_all_objects') == true
    local models, weapons = cfg('models') or {}, cfg('weapons') or {}
    local out = {
        B.notice((blockV or blockO) and 'warn' or 'info', ('Tout bloquer — véhicules : %s · objets : %s. %d modèle(s) et %d arme(s) interdits individuellement.'):format(blockV and 'OUI' or 'non', blockO and 'OUI' or 'non', #models, #weapons)),
        edit and B.actions({
            { action = blockV and 'anticheat.all_vehicles_off' or 'anticheat.all_vehicles_on', label = blockV and 'Débloquer tous les véhicules' or 'Bloquer tous les véhicules', icon = 'car', danger = not blockV },
            { action = blockO and 'anticheat.all_objects_off' or 'anticheat.all_objects_on', label = blockO and 'Débloquer tous les objets' or 'Bloquer tous les objets (props)', icon = 'box', danger = not blockO },
            { action = 'anticheat.unblock_all', label = 'Tout débloquer', icon = 'check' },
            { action = 'anticheat.reset_lists', label = 'Listes par défaut', icon = 'refresh' } }, 'Actions rapides') or nil,
    }
    local vrows, seen = {}, {}
    local okc, cat = pcall(function() return G.VehCat and G.VehCat.Effective and G.VehCat.Effective() or {} end)
    for _, v in ipairs(okc and cat or {}) do
        seen[v.model] = true
        local b = inList(models, v.model)
        vrows[#vrows + 1] = { model = v.model, label = v.label, class = v.class or '', state = b and 'Bloqué' or 'Autorisé',
            actions = edit and { { action = 'anticheat.block_toggle', label = b and 'Débloquer' or 'Bloquer', icon = b and 'check' or 'x', payload = { kind = 'models', name = v.model } } } or {} }
    end
    for _, m in ipairs(models) do   -- interdits mais absents du catalogue (objets, peds, véhicules ajoutés à la main)
        if not seen[tostring(m)] then vrows[#vrows + 1] = { model = tostring(m), label = '—', class = 'Hors catalogue', state = 'Bloqué', actions = edit and { { action = 'anticheat.block_toggle', label = 'Débloquer', icon = 'check', payload = { kind = 'models', name = tostring(m) } } } or {} } end
    end
    table.sort(vrows, function(a, b) if a.state ~= b.state then return a.state == 'Bloqué' end return a.model < b.model end)
    out[#out + 1] = B.table({ id = 'acveh', title = 'Véhicules et modèles (' .. #vrows .. ') — les bloqués en premier', search = true, columns = { { k = 'model', label = 'Modèle' }, { k = 'label', label = 'Nom' }, { k = 'class', label = 'Catégorie' }, { k = 'state', label = 'État', type = 'badge' } }, rows = vrows, empty = 'Catalogue vide.' })
    local wrows = {}
    for _, w in ipairs(WEAPON_LIST) do
        local b = inList(weapons, w)
        wrows[#wrows + 1] = { model = w, label = nice(w), state = b and 'Bloquée' or 'Autorisée',
            actions = edit and { { action = 'anticheat.block_toggle', label = b and 'Débloquer' or 'Bloquer', icon = b and 'check' or 'x', payload = { kind = 'weapons', name = w } } } or {} }
    end
    table.sort(wrows, function(a, b) if a.state ~= b.state then return a.state == 'Bloquée' end return a.model < b.model end)
    out[#out + 1] = B.table({ id = 'acweap', title = 'Armes (' .. #wrows .. ') — les bloquées en premier', search = true, columns = { { k = 'model', label = 'Arme' }, { k = 'label', label = 'Nom' }, { k = 'state', label = 'État', type = 'badge' } }, rows = wrows, empty = 'Aucune arme.' })
    return out
end
