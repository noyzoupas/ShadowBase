-- (v1.2.79) Menu staff › Organisations et entreprises (server/game/orgadmin.lua) : coffre et véhicules de chaque groupe.
local G = PBG
local sendFn
local function pick(kind, id) return { kind = kind, org = id } end

function G.StaffOrgItems(spec, send)
    sendFn = send
    local d = spec and spec.orgadmin
    if not d then return { { label = 'Accès réservé (droit « coffres et véhicules des organisations »)', disabled = true } } end
    local function list(rows, kind, icon)
        local out = {}
        for _, r in ipairs(rows or {}) do
            out[#out + 1] = { label = r.label, icon = icon, right = r.id, description = 'Coffre et véhicules.', onSelect = function() send('org_view', pick(kind, r.id)) end }
        end
        if #out == 0 then out[1] = { label = 'Aucune pour le moment', disabled = true } end
        return out
    end
    return {
        { type = 'submenu', label = 'Organisations (gangs)', icon = 'users', badge = tostring(#(d.gangs or {})), description = 'Coffre, caisse et véhicules de chaque organisation.',
            submenu = { id = 'staff.orgs.gangs', title = 'Organisations', items = list(d.gangs, 'gang', 'users') } },
        { type = 'submenu', label = 'Entreprises', icon = 'building', badge = tostring(#(d.bizs or {})), description = 'Coffres et véhicules de service de chaque entreprise.',
            submenu = { id = 'staff.orgs.biz', title = 'Entreprises', items = list(d.bizs, 'biz', 'building') } },
    }
end

local function money(n)
    local s = tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')
    return s .. ' $'
end

-- Fiche reçue du serveur : rouverte à chaque mise à jour (après un ajout ou une suppression)
RegisterNetEvent('pb:g:staff:org', function(j)
    local o = G.decode(j)
    if not o or not sendFn then return end
    local send = sendFn
    local function with(t) local p = { kind = o.kind, org = o.id } for k, v in pairs(t or {}) do p[k] = v end return p end
    local items = {}
    if o.money then items[#items + 1] = { label = "Caisse de l'organisation", right = money(o.money), icon = 'coins', disabled = true } end

    items[#items + 1] = { type = 'separator', label = 'Coffre' }
    if #o.stashes == 0 then items[#items + 1] = { label = 'Aucun coffre posé', disabled = true, description = 'Pose-le au Builder.' } end
    for _, s in ipairs(o.stashes) do
        items[#items + 1] = { type = 'submenu', label = s.label, icon = 'lock', right = s.count .. ' objet(s)', submenu = { id = 'staff.org.st.' .. s.owner, title = s.label, subtitle = o.label, items = {
            { label = 'Ouvrir le coffre', icon = 'bag', description = 'À distance : prends des objets, ou dépose ceux de ton sac.', onSelect = function()
                G.Menu.Close()
                send('org_stash', with({ stash = s.owner }))
            end },
            { label = 'Ajouter un objet', icon = 'plus', description = "Directement dans le coffre (nom exact de l'objet, ex. water).", onSelect = function()
                local item = G.Menu.Ask("Nom de l'objet (ex. water, bandage)", '', 48)
                if not item or item == '' then return end
                local q = tonumber(G.Menu.Ask('Quantité', '1', 4) or '')
                if not q then return end
                send('org_item', with({ stash = s.owner, item = item, qty = q }))
            end },
        } } }
    end

    items[#items + 1] = { type = 'separator', label = ('Véhicules (%d)'):format(#o.vehicles) }
    items[#items + 1] = { type = 'submenu', label = 'Ajouter un véhicule', icon = 'plus', description = 'Neuf, rangé dans son garage : tous les véhicules du serveur par catégorie, ou un nom tapé à la main avec son type.', submenu = function()
        return G.VehPick.Menu({ id = 'staff.org.vehpick', title = 'Ajouter un véhicule', subtitle = o.label,
            onPick = function(model, label, vt) send('org_veh_add', with({ model = model, label = label or '', vtype = vt })) end })
    end }
    local given = 0
    for _, v in ipairs(o.vehicles) do
        if v.given then given = given + 1 end
        local sub = {
            { label = 'Plaque', right = v.plate, disabled = true },
            { label = 'État', right = v.state, disabled = true },
            { label = 'Origine', right = v.given and ('Donné par ' .. v.donor) or (o.kind == 'gang' and "Véhicule de l'organisation" or "Véhicule de l'entreprise"), disabled = true },
        }
        if v.given then sub[#sub + 1] = { label = 'Rendre à ' .. v.donor, icon = 'undo', description = 'Le véhicule retourne dans son garage personnel.', onSelect = function()
            G.Menu.ConfirmTwice(v.label, 'Rendre ce véhicule à ' .. v.donor .. ' ?', function() send('org_veh_back', with({ plate = v.plate })) end)
        end } end
        sub[#sub + 1] = { label = 'Supprimer définitivement', icon = 'trash', description = 'Le véhicule et le contenu de son coffre disparaissent. Impossible à annuler.', onSelect = function()
            G.Menu.ConfirmTwice(v.label .. ' · ' .. v.plate, 'Supprimer définitivement ce véhicule ?', function() send('org_veh_del', with({ plate = v.plate })) end)
        end }
        items[#items + 1] = { type = 'submenu', label = v.label, icon = 'engine', right = v.plate, badge = v.given and 'DON' or nil,
            description = v.state .. (v.given and (' · donné par ' .. v.donor) or ''), submenu = { id = 'staff.org.v.' .. v.plate, title = v.label, subtitle = v.plate, items = sub } }
    end
    if #o.vehicles == 0 then items[#items + 1] = { label = 'Aucun véhicule', disabled = true } end
    G.Menu.Open({ id = 'staff.org.' .. o.kind .. '.' .. o.id, title = o.label, subtitle = (o.kind == 'gang' and 'Organisation' or 'Entreprise') .. (given > 0 and (' · ' .. given .. ' véhicule(s) donné(s)') or ''), items = items })
end)
