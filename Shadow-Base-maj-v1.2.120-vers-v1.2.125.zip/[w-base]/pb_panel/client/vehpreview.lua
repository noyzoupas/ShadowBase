-- (v1.2.85) Aperçu des véhicules dans les listes du Builder (véhicules d'une entreprise, pack de départ d'une entreprise ou d'un gang) :
-- en défilant, le véhicule survolé apparaît devant toi (local : personne d'autre ne le voit), il tourne lentement et une caméra le cadre.
-- G.VehPreview.Wrap(def) branche l'aperçu sur une liste dont les lignes portent « model ».
local G = PBG
local VP = {}
G.VehPreview = VP
local veh, cam, want, spot = nil, nil, nil, nil

local function clear()
    if veh and DoesEntityExist(veh) then DeleteEntity(veh) end
    veh = nil
end
function VP.Stop()
    want, spot = nil, nil
    clear()
    if cam then RenderScriptCams(false, true, 350, true, true) DestroyCam(cam, false) cam = nil end
end

-- endroit fixe pour toute la séance : 7 m devant le joueur, au sol
local function place()
    if spot then return spot end
    local ped = PlayerPedId()
    local c, h = GetEntityCoords(ped), GetEntityHeading(ped)
    local r = math.rad(h)
    local x, y = c.x - math.sin(r) * 7.0, c.y + math.cos(r) * 7.0
    local ok, gz = GetGroundZFor_3dCoord(x, y, c.z + 2.0, false)
    spot = { x = x, y = y, z = (ok and math.abs(gz - c.z) < 6.0) and gz or (c.z - 1.0), h = (h + 180.0) % 360.0, ph = h }
    return spot
end

function VP.Show(model)
    model = tostring(model or ''):lower()
    if model == '' then VP.Stop() return end
    if want == model then return end
    want = model
    CreateThread(function()
        Wait(120)   -- défilement rapide : seul le dernier véhicule survolé se charge
        if want ~= model then return end
        local hash = joaat(model)
        if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then clear() return end
        RequestModel(hash)
        local t = GetGameTimer() + 4000
        while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
        if want ~= model or not HasModelLoaded(hash) then return end
        local s = place()
        clear()
        local v = CreateVehicle(hash, s.x, s.y, s.z + 0.5, s.h, false, false)
        SetModelAsNoLongerNeeded(hash)
        if want ~= model then DeleteEntity(v) return end
        veh = v
        SetVehicleOnGroundProperly(v)
        SetEntityCollision(v, false, false)
        SetEntityAlpha(v, 150, false)   -- (patch 325) aperçu transparent
        FreezeEntityPosition(v, true)
        SetVehicleDoorsLocked(v, 2)
        SetVehicleDirtLevel(v, 0.0)
        SetVehicleLights(v, 2)
        if not cam then
            local r = math.rad(s.ph + 25.0)
            cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
            SetCamCoord(cam, s.x + math.sin(r) * 5.5, s.y - math.cos(r) * 5.5, s.z + 2.0)
            PointCamAtCoord(cam, s.x, s.y, s.z + 0.5)
            SetCamFov(cam, 55.0)
            RenderScriptCams(true, true, 450, true, true)
        end
    end)
end

-- rotation lente, et arrêt si le menu se ferme autrement (Échap, mort, téléportation…)
CreateThread(function()
    local closedSince
    while true do
        if veh or want then
            Wait(0)
            if veh and DoesEntityExist(veh) then SetEntityHeading(veh, (GetEntityHeading(veh) + 0.35) % 360.0) end
            if not (G.Menu and G.Menu.IsOpen()) then
                closedSince = closedSince or GetGameTimer()
                if GetGameTimer() - closedSince > 600 then VP.Stop() closedSince = nil end
            else closedSince = nil end
        else
            Wait(400)
        end
    end
end)

-- Branche l'aperçu sur une liste : survol d'une ligne avec « model » = aperçu ; fermeture ou retour = fin
function VP.Wrap(def)
    local hov, cls, opn = def.onHover, def.onClose, def.onOpen
    def.onHover = function(it, m) if it and it.model then VP.Show(it.model) else VP.Stop() end if hov then hov(it, m) end end
    def.onOpen = function(m) local it = m and m.items and m.items[m.sel] if it and it.model then VP.Show(it.model) end if opn then opn(m) end end
    def.onClose = function(m) VP.Stop() if cls then cls(m) end end
    return def
end
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then VP.Stop() end end)
