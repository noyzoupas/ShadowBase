-- (patch 325) Choisir un véhicule : toutes les catégories du serveur (aperçu transparent en survolant), les autres modèles installés sur le
-- serveur, et la saisie à la main d'un nom de modèle avec son type (voiture, naval, aérien).
-- G.VehPick.Menu({ id, title, subtitle, onPick = function(model, label, vtype) end, noType = false, extra = { items… } }) renvoie un menu à ouvrir.
local G = PBG
local VK = {}
G.VehPick = VK
local classes, asked = nil, false

RegisterNetEvent('pb:g:vehlist', function(j)
    local d = G.decode(j)
    classes = d and d.classes or {}
    if G.Menu and G.Menu.IsOpen and G.Menu.IsOpen() then G.Menu.Refresh() end
end)
function VK.Prefetch() if not classes and not asked then asked = true TriggerServerEvent('pb:g:vehlist') end end

-- type réel d'un modèle installé : naval, aérien ou voiture (nil si le modèle n'existe pas sur ce serveur)
function VK.Detect(model)
    local h = joaat(tostring(model or ''):lower())
    if not IsModelInCdimage(h) or not IsModelAVehicle(h) then return nil end
    local ok, c = pcall(GetVehicleClassFromName, h)
    if not ok then return 'car' end
    if c == 14 then return 'boat' elseif c == 15 or c == 16 then return 'air' end
    return 'car'
end
local TYPE_NAME = { car = 'Voiture / moto / utilitaire', boat = 'Bateau (naval)', air = 'Hélicoptère / avion (aérien)' }
VK.TypeName = TYPE_NAME

local function installedOthers(known)
    local out = {}
    local ok, all = pcall(GetAllVehicleModels)
    if not ok or type(all) ~= 'table' then return out end
    for _, m in ipairs(all) do
        if type(m) == 'string' then
            local k = m:lower()
            if not known[k] and VK.Detect(k) then out[#out + 1] = k end
        end
    end
    table.sort(out)
    return out
end

function VK.Menu(o)
    local function pick(model, label, vt)
        if o.onPick then o.onPick(model, label, vt) end
    end
    local function row(model, label, vt)
        return { label = label or model, right = model, model = model, description = o.hint or 'Entrée : choisir. Le véhicule s\'affiche devant toi en transparence.',
            onSelect = function() pick(model, label or model, vt or VK.Detect(model) or 'car') end }
    end
    return { id = o.id, title = o.title or 'Véhicules', subtitle = o.subtitle, refreshOnReturn = o.refreshOnReturn, build = function()
        local items = {}
        for _, it in ipairs(o.extra or {}) do items[#items + 1] = it end
        VK.Prefetch()
        if not classes then
            items[#items + 1] = { label = 'Chargement de la liste des véhicules…', disabled = true }
            return items
        end
        local known = {}
        items[#items + 1] = { type = 'separator', label = 'Tous les véhicules du serveur' }
        for _, c in ipairs(classes) do
            local rows = {}
            for _, m in ipairs(c.items) do
                known[m[1]] = true
                if IsModelInCdimage(joaat(m[1])) then rows[#rows + 1] = row(m[1], m[2]) end
            end
            if #rows > 0 then
                items[#items + 1] = { type = 'submenu', label = c.id, right = tostring(#rows), submenu = G.VehPreview.Wrap({ id = o.id .. '.' .. c.id, title = c.id, subtitle = o.subtitle, items = rows }) }
            end
        end
        items[#items + 1] = { type = 'submenu', label = 'Autres véhicules installés', description = 'Les modèles ajoutés au serveur qui ne sont dans aucune catégorie ci-dessus.', submenu = function()
            local rows = {}
            for _, m in ipairs(installedOthers(known)) do rows[#rows + 1] = row(m, m) end
            if #rows == 0 then rows[1] = { label = 'Aucun autre modèle', disabled = true } end
            return G.VehPreview.Wrap({ id = o.id .. '.others', title = 'Autres véhicules', subtitle = o.subtitle, items = rows })
        end }
        items[#items + 1] = { type = 'separator', label = 'Ajout manuel' }
        items[#items + 1] = { label = 'Taper le nom d\'un véhicule…', icon = 'edit', description = o.noType and 'Le nom exact du modèle (ex. sultan).' or 'Le nom exact du modèle, puis son type : voiture, naval ou aérien.', onSelect = function()
            local m = G.Menu.Ask('Nom du modèle (ex. sultan, polmav, dinghy)', '', 32)
            m = m and m:lower():gsub('%s+', '') or ''
            if m == '' then return end
            if not m:match('^[%w_]+$') then G.send('notify', { type = 'error', title = 'Véhicule', text = 'Lettres, chiffres et _ seulement.' }) return end
            local det = VK.Detect(m)
            if not det then G.send('notify', { type = 'warn', title = 'Véhicule', text = "Ce modèle n'est pas chargé sur le serveur : il ne pourra pas apparaître tant qu'il ne l'est pas." }) end
            local label = o.noLabel and '' or (G.Menu.Ask('Nom affiché (vide = le modèle)', '', 40) or '')
            if o.noType then pick(m, label, det or 'car') return end
            local function choose(vt) G.Menu.Back() pick(m, label, vt) end
            local tl = {}
            for _, vt in ipairs({ 'car', 'boat', 'air' }) do
                tl[#tl + 1] = { label = TYPE_NAME[vt], right = det == vt and 'détecté' or nil, icon = vt == 'car' and 'car' or (vt == 'boat' and 'drop' or 'sparkle'),
                    description = vt == 'car' and 'Se range dans un garage.' or (vt == 'boat' and 'Se range dans un port.' or 'Se range dans un hangar aérien.'), onSelect = function() choose(vt) end }
            end
            G.Menu.Push({ id = o.id .. '.type', title = 'Type du véhicule', subtitle = m, items = tl })
        end }
        return items
    end }
end
