/* Menu ALT : points cliquables sur les personnes (positions écran envoyées par le jeu) et petit menu à côté de la personne choisie.
   Le jeu n'envoie que des identifiants ; le serveur compose la liste des entrées. Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

let keyH = null, layer = null, spotsEl = null, menuEl = null, spec = null, anchor = { x: 0, y: 0 }, spotMap = {};
const root = () => layer || (layer = (function () { const e = h('div', { id: 'g-ctx', class: 'hidden' }); G.root.appendChild(e); return e; })());

function themeVars(t) {
  const th = G.rmenu.themeOf(t);
  return { '--ac': th.accent, '--acr': G.hexToRgb(th.accent), '--bg': th.bg, '--bgr': G.hexToRgb(th.bg), '--tx': th.text, '--mu': th.muted, '--op': String(th.opacity / 100), '--rd': Math.min(14, th.radius) + 'px', '--bl': th.blur + 'px', '--fs': String(th.font_scale / 100) };
}

// menu : { target:{...}, cats:[{id,label,icon,entries:[{id,label,desc,icon,danger,inputs,disabled,why}]}] }
const STYLES = ['simple', 'cascade', 'glass', 'v2', 'clean', 'nova'];
G.ctxStyles = STYLES;
// Quatre présentations : « cascade » (épurée en cascade, par défaut), « glass » (Verre : liste + sous-menu à côté), « v2 » (deux colonnes, touches 1-9), « clean » (épurée, couleurs du serveur).
// Présentation « simple » (par défaut) : une petite boîte bleu nuit, du texte seul, une barre bleue à gauche de la ligne survolée,
// les catégories s'ouvrent dans la même boîte et « Retour » remonte d'un cran (ou ferme le menu).
function simpleView(sp, o) {
  const cats = sp.cats || [];
  const box = h('div', { class: 'sx-menu sx-simple' });
  let cur = cats.length === 1 ? cats[0] : null, form = null;
  const item = (label, fn, cls, why) => h('button', { type: 'button', class: 'sm-i' + (cls ? ' ' + cls : ''), onclick: fn }, h('span', null, label), why ? h('small', null, why) : null);
  function back() {
    if (form) { form = null; render(); return; }
    if (cur && cats.length > 1) { cur = null; render(); return; }
    if (o.onClose) o.onClose();
  }
  function pick(e) {
    if (e.disabled) return;
    if ((e.inputs || []).length) { form = e; render(); } else if (o.onAct) o.onAct(e.id, {});
  }
  function render() {
    G.clear(box);
    box.classList.remove('in'); void box.offsetWidth; box.classList.add('in');
    if (form) {
      const vals = {};
      box.appendChild(h('div', { class: 'sm-t' }, form.label));
      (form.inputs || []).forEach((f, i) => {
        const inp = h('input', { type: f.number ? 'number' : 'text', maxlength: String(f.maxlen || 60), placeholder: f.label, class: 'sm-in' });
        inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') go(); else if (ev.key === 'Escape') back(); });
        vals[f.k] = [inp, f];
        if (i === 0 && !o.static) setTimeout(() => inp.focus(), 20);
        box.appendChild(inp);
      });
      const go = () => {
        const p = {};
        Object.keys(vals).forEach((k) => { const [inp, f] = vals[k]; p[k] = f.number ? (inp.value === '' ? null : Number(inp.value)) : inp.value; });
        if (o.onAct) o.onAct(form.id, p);
      };
      box.appendChild(item('Valider', go, 'ok'));
    } else if (cur) {
      cur.entries.forEach((e) => box.appendChild(item(e.label, () => pick(e), (e.danger ? 'bad' : '') + (e.disabled ? ' off' : ''), e.disabled && e.why ? e.why : null)));
      if (!cur.entries.length) box.appendChild(h('div', { class: 'sm-none' }, 'Aucune action disponible.'));
    } else {
      cats.forEach((c) => box.appendChild(item(c.label, () => { cur = c; render(); })));
      if (!cats.length) box.appendChild(h('div', { class: 'sm-none' }, 'Aucune action disponible.'));
    }
    box.appendChild(item('Retour', back, 'back'));
    const first = box.querySelector('.sm-i');
    if (first) first.classList.add('on');
  }
  // survol : la barre bleue suit la souris (la première ligne est marquée à l'ouverture)
  box.addEventListener('mouseover', (ev) => {
    const b = ev.target.closest && ev.target.closest('.sm-i');
    if (!b) return;
    box.querySelectorAll('.sm-i.on').forEach((x) => x.classList.remove('on'));
    b.classList.add('on');
  });
  // clavier : haut / bas / Entrée / Retour arrière
  box.__keys = (ev) => {
    if (ev.target && /^(INPUT|TEXTAREA)$/.test(ev.target.tagName)) return false;
    const list = Array.from(box.querySelectorAll('.sm-i'));
    let i = list.findIndex((x) => x.classList.contains('on'));
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
      if (i >= 0) list[i].classList.remove('on');
      i = ev.key === 'ArrowDown' ? (i + 1) % list.length : (i - 1 + list.length) % list.length;
      list[i].classList.add('on');
      return true;
    }
    if ((ev.key === 'Enter' || ev.key === 'ArrowRight') && i >= 0) { if (ev.key === 'Enter' || list[i].__cat) list[i].click(); return true; }
    if (ev.key === 'Backspace' || ev.key === 'ArrowLeft') { back(); return true; }
    return false;
  };
  box.__layout = () => {};
  box.__first = () => {};
  render();
  return box;
}

function menuView(sp, o) {
  o = o || {};
  if (!o.style || o.style === 'simple') return simpleView(sp || {}, o);
  if (o.style === 'nova') return novaView(sp || {}, o);
  sp = sp || {};
  const cats = sp.cats || [];
  const tg = sp.target || {};
  const style = STYLES.indexOf(o.style) >= 0 ? o.style : 'cascade';
  const v2 = style === 'v2';
  const box = h('div', { class: 'sx-menu sx-' + style, style: themeVars(o.theme) });
  let cur = null, form = null, subEl = null, colR = null, colL = null;
  const row = (label, cls, fn, opt) => {
    opt = opt || {};
    const b = h('button', { type: 'button', class: 'sx-i' + (cls ? ' ' + cls : ''), onclick: fn },
      opt.key ? h('kbd', { class: 'sx-k' }, String(opt.key)) : null,
      h('span', { class: 'sx-ic' }, ico(opt.icon || 'chevron')),
      h('span', { class: 'sx-tx' }, h('b', null, label), opt.why ? h('small', null, opt.why) : null),
      opt.more ? h('span', { class: 'sx-go' }, ico('chevron')) : null);
    if (opt.hover) b.addEventListener('mouseenter', opt.hover);
    return b;
  };
  const head = (title, sub) => h('div', { class: 'sx-h' }, h('b', null, title), sub ? h('small', null, sub) : null);
  const none = () => h('div', { class: 'sx-none' }, 'Aucune action disponible.');

  function entryList(c, keyed) {
    const list = h('div', { class: 'sx-l' });
    c.entries.forEach((e, i) => list.appendChild(row(e.label, (e.danger ? 'bad' : '') + (e.disabled ? ' off' : ''), () => pickEntry(e), { icon: e.icon, why: e.disabled && e.why ? e.why : null, more: !e.disabled && (e.inputs || []).length > 0, key: keyed && i < 9 ? i + 1 : null })));
    return list;
  }
  function formView(e) {
    const vals = {};
    const fm = h('div', { class: 'sx-f' });
    (e.inputs || []).forEach((f, i) => {
      const inp = h('input', { type: f.number ? 'number' : 'text', maxlength: String(f.maxlen || 60), placeholder: f.label, class: 'sx-in' });
      inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') go(); else if (ev.key === 'Escape') { form = null; render(); } });
      vals[f.k] = [inp, f]; if (i === 0 && !o.static) setTimeout(() => inp.focus(), 20);
      fm.appendChild(inp);
    });
    const go = () => {
      const p = {};
      Object.keys(vals).forEach((k) => { const [inp, f] = vals[k]; p[k] = f.number ? (inp.value === '' ? null : Number(inp.value)) : inp.value; });
      o.onAct && o.onAct(e.id, p);
    };
    fm.appendChild(h('button', { type: 'button', class: 'sx-ok', onclick: go }, 'Valider'));
    return h('div', { class: 'sx-fw' }, head(e.label, tg.name), fm, row('Retour', 'back', () => { form = null; render(); }, { icon: 'undo' }));
  }
  function pickEntry(e) {
    if (e.disabled) return;
    if ((e.inputs || []).length) { form = e; render(); } else o.onAct && o.onAct(e.id, {});
  }
  // Place le sous-menu à côté de la ligne choisie : à droite, sinon à gauche, sinon par-dessus ; toujours entièrement dans l'écran.
  function layoutSub(rowBtn) {
    if (!subEl || !subEl.isConnected) return;
    subEl.classList.remove('left', 'over');
    subEl.style.top = '0px'; subEl.style.left = ''; subEl.style.right = '';
    const bx = box.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
    const sw = subEl.offsetWidth || 250, sh = Math.min(subEl.offsetHeight || 200, vh - 16);
    if (bx.right + 6 + sw > vw - 8) {
      if (bx.left - 6 - sw >= 8) subEl.classList.add('left'); else subEl.classList.add('over');
    }
    let t = (rowBtn && rowBtn.isConnected ? rowBtn.getBoundingClientRect().top : bx.top) - bx.top;
    t = Math.min(t, vh - 8 - sh - bx.top); t = Math.max(t, 8 - bx.top);
    subEl.style.top = t + 'px';
  }
  function openCat(c, rowBtn) {
    cur = c; form = null;
    if (v2) { render(); return; }
    box.querySelectorAll('.sx-cats .sx-i').forEach((b) => b.classList.toggle('on', b.__c === c));
    if (subEl) subEl.remove();
    subEl = h('div', { class: 'sx-sub' }, head(c.label, tg.name), entryList(c, false));
    box.appendChild(subEl); layoutSub(rowBtn);
  }
  function catRow(c, i) {
    const b = row(c.label, cur === c ? 'on' : '', () => openCat(c, b), { icon: c.icon, more: true, key: v2 && !cur && i < 9 ? i + 1 : null, hover: v2 || o.static ? null : () => { if (cur !== c) openCat(c, b); } });
    b.__c = c; return b;
  }
  // Après un changement de contenu, la boîte remonte si elle dépasse en bas de l'écran.
  function clampBox() {
    if (o.static || !box.isConnected) return;
    const r = box.getBoundingClientRect(), vh = window.innerHeight;
    let dy = Math.min(0, vh - 8 - r.bottom);
    if (r.top + dy < 8) dy = 8 - r.top;
    if (dy) box.style.top = ((parseFloat(box.style.top) || 0) + dy) + 'px';
  }
  function render() {
    G.clear(box); subEl = null;
    box.classList.remove('in'); void box.offsetWidth; box.classList.add('in');
    if (!cats.length) { box.appendChild(none()); return; }
    if (v2) {
      if (!cur && cats.length === 1) cur = cats[0];
      colL = h('div', { class: 'sx-c1' }, head(tg.name || 'Interactions', tg.sub), h('div', { class: 'sx-l sx-cats' }, ...cats.map(catRow)));
      colR = h('div', { class: 'sx-c2' });
      if (form) colR.appendChild(formView(form));
      else if (cur) { colR.appendChild(head(cur.label, 'Touches 1 à 9 · Retour arrière = catégories')); colR.appendChild(entryList(cur, true)); }
      else colR.appendChild(h('div', { class: 'sx-none' }, 'Choisis une catégorie (touche 1 à 9).'));
      box.appendChild(colL); box.appendChild(colR);
      clampBox();
      return;
    }
    if (cats.length === 1) {       // une seule catégorie : les entrées sont directement dans la boîte
      const c = cats[0];
      if (form) { box.appendChild(formView(form)); return; }
      box.appendChild(head(tg.name || c.label, tg.sub));
      box.appendChild(entryList(c, false));
      return;
    }
    box.appendChild(head(tg.name || 'Interactions', tg.sub));
    box.appendChild(h('div', { class: 'sx-l sx-cats' }, ...cats.map(catRow)));
    if (cur) {
      if (form) { subEl = h('div', { class: 'sx-sub' }, formView(form)); box.appendChild(subEl); layoutSub(box.querySelector('.sx-cats .sx-i.on')); }
      else openCat(cur, box.querySelector('.sx-cats .sx-i.on'));
    }
  }
  // Touches 1-9 (version 2) et Retour arrière ; renvoie true si la touche a été utilisée.
  box.__keys = (ev) => {
    if (!v2 || form || (ev.target && /^(INPUT|TEXTAREA)$/.test(ev.target.tagName))) return false;
    if (ev.key === 'Backspace' && cur && cats.length > 1) { cur = null; render(); return true; }
    const n = /^[1-9]$/.test(ev.key) ? Number(ev.key) : 0;
    if (!n) return false;
    if (!cur) { if (cats[n - 1]) { openCat(cats[n - 1]); return true; } return false; }
    const e = cur.entries[n - 1];
    if (e) { pickEntry(e); return true; }
    return false;
  };
  box.__layout = () => layoutSub(box.querySelector('.sx-cats .sx-i.on'));
  box.__first = () => {};
  render();
  return box;
}
// Présentation « Nova » : en-tête « Nom · ID » à part, puis toutes les actions à la suite (un espace entre les catégories), icônes fines,
// légèrement transparent. Une action à saisir (montant, motif…) s'ouvre dans la même boîte. Flèches, Entrée, Retour arrière.
function novaView(sp, o) {
  const cats = sp.cats || [];
  const tg = sp.target || {};
  const box = h('div', { class: 'sx-menu sxn' });
  // (v1.2.37) même taille que la lib Nova : ~300 px de large, texte 17 px, lignes de 38 px en 1080p (la maquette 496 était affichée telle quelle : énorme)
  if (!o.static) box.style.setProperty('--k', String(0.46 * Math.max(0.6, Math.min(window.innerWidth / 1920, window.innerHeight / 1080) || 1)));
  // (v1.2.38) deux niveaux : d'abord les catégories (Métier, Mon personnage, Gestes…), puis leurs actions.
  // Une seule catégorie, ou très peu d'actions : la liste s'affiche directement, avec un titre par catégorie.
  let form = null, cat = null;
  const total = cats.reduce((n, c) => n + (c.entries || []).length, 0);
  const flat = cats.length <= 1 || total <= 7;
  const who = String(tg.name || 'Interactions') + (tg.uid != null && !tg.vehicle && !tg.object ? ' · ID ' + tg.uid : '');
  const headIcon = tg.vehicle ? 'car' : tg.object ? 'box' : 'user';
  function item(label, icon, fn, opt) {
    opt = opt || {};
    return h('button', { type: 'button', class: 'sxn-i' + (opt.cls ? ' ' + opt.cls : ''), onclick: fn },
      h('span', { class: 'sxn-ic' }, ico(icon || 'chevron')),
      h('span', { class: 'sxn-l' }, label, opt.why ? h('small', null, opt.why) : null),
      opt.right ? h('span', { class: 'sxn-rt' }, String(opt.right)) : null,
      opt.more ? h('span', { class: 'sxn-go' }, ico('chevron')) : null);
  }
  function entry(e) { return item(e.label, e.icon, () => pick(e), { cls: (e.danger ? 'bad' : '') + (e.disabled ? ' off' : ''), why: e.disabled && e.why ? e.why : null, right: e.right, more: !e.disabled && (e.inputs || []).length > 0 }); }
  function pick(e) { if (e.disabled) return; if ((e.inputs || []).length) { form = e; render(); } else if (o.onAct) o.onAct(e.id, {}); }
  function back() {
    if (form) { form = null; render(); return; }
    if (cat && !flat) { const was = cat; cat = null; render(was); return; }
    if (o.onClose) o.onClose();
  }
  function render(focusCat) {
    G.clear(box);
    box.classList.remove('in'); void box.offsetWidth; box.classList.add('in');
    const sub = form ? (tg.sub ? String(tg.sub) : null) : cat && !flat ? String(cat.label) : tg.sub ? String(tg.sub) : null;   // (v1.2.43) le titre du formulaire n'est plus répété
    box.appendChild(h('div', { class: 'sxn-h' }, ico(headIcon), h('div', { style: { minWidth: 0 } }, h('b', null, who), sub ? h('small', null, sub) : null)));
    const body = h('div', { class: 'sxn-b' });
    if (form) {
      const vals = {};
      const fm = h('div', { class: 'sxn-f' }, h('div', { class: 'sxn-t' }, String(form.label)));
      const go = () => { const p = {}; Object.keys(vals).forEach((k) => { const [inp, f] = vals[k]; p[k] = f.number ? (inp.value === '' ? null : Number(inp.value)) : inp.value; }); if (o.onAct) o.onAct(form.id, p); };
      (form.inputs || []).forEach((f, i) => {
        // (v1.2.43) champ texte (même pour un nombre : pas de flèches du navigateur), libellé au-dessus, chiffres seulement si besoin
        const inp = h('input', { type: 'text', inputmode: f.number ? 'numeric' : 'text', maxlength: String(f.maxlen || 60), placeholder: f.number ? '0' : String(f.label || ''), class: 'sxn-in', autocomplete: 'off', spellcheck: 'false' });
        if (f.number) inp.addEventListener('input', () => { const v = inp.value.replace(/[^0-9]/g, ''); if (v !== inp.value) inp.value = v; });
        inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') go(); else if (ev.key === 'Escape') back(); });
        vals[f.k] = [inp, f]; if (i === 0 && !o.static) setTimeout(() => inp.focus(), 20);
        fm.appendChild(h('label', { class: 'sxn-lb' }, String(f.label || '')));
        fm.appendChild(inp);
      });
      fm.appendChild(h('button', { type: 'button', class: 'sxn-ok', onclick: go }, 'Valider'));
      body.appendChild(fm);
      body.appendChild(item('Retour', 'undo', back));
    } else if (!total) {
      body.appendChild(h('div', { class: 'sxn-none' }, 'Aucune action disponible.'));
    } else if (flat) {
      cats.forEach((c) => {
        if (!(c.entries || []).length) return;
        if (cats.length > 1) body.appendChild(h('div', { class: 'sxn-sec' }, String(c.label)));
        c.entries.forEach((e) => body.appendChild(entry(e)));
      });
    } else if (cat) {
      (cat.entries || []).forEach((e) => body.appendChild(entry(e)));
      body.appendChild(h('div', { class: 'sxn-gap' }));
      body.appendChild(item('Retour', 'undo', back, { cls: 'back' }));
    } else {
      cats.forEach((c) => {
        const n = (c.entries || []).filter((e) => !e.disabled).length;
        const b = item(c.label, c.icon, () => { cat = c; render(); }, { right: n || null, more: true, cls: n ? '' : 'off' });
        b.__cat = c; body.appendChild(b);
      });
    }
    box.appendChild(body);
    if (o.static) return;
    if (box.__reflow) box.__reflow();   // (v1.2.43) la boîte change de hauteur : on la garde entière à l'écran
    if (form) return;                   // en saisie, aucune ligne n'est surlignée (Retour ne doit pas avoir l'air sélectionné)
    let first = null;
    if (focusCat) first = Array.from(body.querySelectorAll('.sxn-i')).find((b) => b.__cat === focusCat) || null;
    if (!first) first = body.querySelector('.sxn-i:not(.off)');
    if (first) first.classList.add('on');
  }
  box.addEventListener('mouseover', (ev) => {
    const b = ev.target.closest && ev.target.closest('.sxn-i');
    if (!b || b.classList.contains('off')) return;
    box.querySelectorAll('.sxn-i.on').forEach((x) => x.classList.remove('on'));
    b.classList.add('on');
  });
  box.__keys = (ev) => {
    if (ev.target && /^(INPUT|TEXTAREA)$/.test(ev.target.tagName)) return false;
    const list = Array.from(box.querySelectorAll('.sxn-i:not(.off)'));
    if (!list.length) { if (ev.key === 'Backspace') { back(); return true; } return false; }
    let i = list.findIndex((x) => x.classList.contains('on'));
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
      if (i >= 0) list[i].classList.remove('on');
      i = ev.key === 'ArrowDown' ? (i + 1) % list.length : (i - 1 + list.length) % list.length;
      list[i].classList.add('on'); list[i].scrollIntoView({ block: 'nearest' });
      return true;
    }
    if ((ev.key === 'Enter' || ev.key === 'ArrowRight') && i >= 0) { if (ev.key === 'Enter' || list[i].__cat) list[i].click(); return true; }
    if (ev.key === 'Backspace' || ev.key === 'ArrowLeft') { back(); return true; }
    return false;
  };
  box.__layout = () => {};
  box.__first = () => {};
  render();
  return box;
}
G.ctxMenuView = menuView;

function place(el, x, y) {
  const vw = window.innerWidth, vh = window.innerHeight;
  el.style.left = '0px'; el.style.top = '0px';
  const w = el.offsetWidth || 272, hh = Math.min(el.offsetHeight || 160, vh - 20);
  let lx = x + 24; if (lx + w > vw - 10) { lx = Math.max(10, x - 24 - w); el.classList.add('flip'); } else el.classList.remove('flip');
  lx = Math.max(10, Math.min(lx, vw - w - 10));
  let ty = Math.max(10, Math.min(y + 10, vh - hh - 10));
  el.style.left = lx + 'px'; el.style.top = ty + 'px';
  if (el.__layout) el.__layout();
}

function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } if (keyH) { document.removeEventListener('keydown', keyH, true); keyH = null; } spec = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'ctx'); }
// Les points sont réutilisés d'une image à l'autre (seule la position change) : recréer les boutons ~30 fois par seconde
// annulait le survol et le clic en permanence.
function drawSpots(list) {
  const r = root();
  if (!spotsEl) { spotsEl = h('div', { class: 'cx-spots' }); r.appendChild(spotsEl); }
  const seen = {};
  (list || []).forEach((s) => {
    const key = (s.k || 'p') + s.i;
    seen[key] = true;
    let b = spotMap[key];
    if (!b) {
      const nm = s.me ? 'Moi' : s.k === 'v' ? 'Véhicule' : s.k === 'o' ? 'Objet' : s.k === 'd' ? 'Porte ou prop (staff)' : s.k === 'r' ? 'Prop (staff)' : s.k === 'f' ? 'Drapeau' : 'Personne';
      b = h('button', { type: 'button', class: 'cx-hit' + (s.me ? ' me' : '') + (s.k === 'v' ? ' veh' : s.k === 'o' ? ' obj' : s.k === 'd' ? ' obj door' : s.k === 'r' || s.k === 'f' ? ' obj' : ''), 'aria-label': nm },
        h('span', { class: 'cx-hl' }, nm));   // pas d'ID visible pour les joueurs
      b.addEventListener('click', () => {
        const rc = b.getBoundingClientRect(); anchor = { x: rc.left + rc.width / 2, y: rc.top + rc.height / 2 };
        G.post('ctx.pick', { i: b.__s.i, k: b.__s.k || 'p' });
      });
      b.addEventListener('mouseenter', () => G.post('ctx.hover', { i: b.__s.i, k: b.__s.k || 'p' }));
      b.addEventListener('mouseleave', () => G.post('ctx.hover', {}));
      spotMap[key] = b; spotsEl.appendChild(b);
    }
    b.__s = s;
    // zone cliquable = rectangle autour de la cible (taille minimale si le jeu n'a pas pu la mesurer)
    const w = Math.max(0.045, Number(s.w) || 0.07), hh = Math.max(0.09, Number(s.h) || 0.18);
    b.style.left = (s.x * 100) + '%'; b.style.top = (s.y * 100) + '%'; b.style.width = (w * 100) + '%'; b.style.height = (hh * 100) + '%';
  });
  Object.keys(spotMap).forEach((k) => { if (!seen[k]) { spotMap[k].remove(); delete spotMap[k]; } });
}
function clearSpots() { if (spotsEl) G.clear(spotsEl); spotMap = {}; G.post('ctx.hover', {}); }
G.on('ctx.spots', (d) => { const r = root(); if (menuEl) return; r.classList.remove('hidden'); r.classList.add('hold'); G.root.classList.add('alt-hold'); drawSpots(d.p || []); });
G.on('ctx.hide', () => { G.root.classList.remove('alt-hold'); if (menuEl) return; const r = root(); r.classList.add('hidden'); r.classList.remove('hold'); clearSpots(); });
G.on('ctx.open', (d) => {
  const r = root(); r.classList.remove('hidden');
  closeMenu(); spec = d.spec;
  menuEl = menuView(spec, { theme: G.cfg && G.cfg.menus, style: 'nova',   // v1.2.37 : un seul style, Shadow Studio V2
    onAct: (id, p) => G.post('ctx.act', { t: spec.target.id, id, payload: p || {} }), onClose: () => G.post('ctx.close', {}) });
  r.appendChild(menuEl); place(menuEl, anchor.x, anchor.y); menuEl.__first();
  menuEl.__reflow = () => { if (menuEl) place(menuEl, anchor.x, anchor.y); };
  keyH = (ev) => { if (menuEl && menuEl.__keys && menuEl.__keys(ev)) { ev.preventDefault(); ev.stopPropagation(); } };
  document.addEventListener('keydown', keyH, true);
  G.uiStack.push({ id: 'ctx', onEscape: () => G.post('ctx.close', {}) });
});
G.on('ctx.close', () => { G.root.classList.remove('alt-hold'); closeMenu(); const r = root(); r.classList.add('hidden'); r.classList.remove('hold'); clearSpots(); });
document.addEventListener('mousedown', (e) => { if (menuEl && !menuEl.contains(e.target)) G.post('ctx.close', {}); }, true);


// Demande de geste à deux : Y accepte, N refuse (la réponse est lue par le jeu, la fenêtre ne fait qu'afficher)
let invEl = null, invT = 0;
function dropInvite() { clearTimeout(invT); if (invEl) { invEl.remove(); invEl = null; } }
G.on('ctx.invite', (d) => {
  dropInvite();
  if (d.stop) return;
  invEl = h('div', { id: 'g-ctxinv' },
    h('div', { class: 'ci-t' }, h('b', null, String(d.name || '').slice(0, 40)), h('span', null, String(d.text || '').slice(0, 80))),
    h('div', { class: 'ci-k' }, h('span', null, h('kbd', null, 'Y'), 'Accepter'), h('span', null, h('kbd', null, 'N'), 'Refuser')));
  G.root.appendChild(invEl);
  invT = setTimeout(dropInvite, Math.max(5, Math.min(60, Number(d.secs) || 15)) * 1000 + 500);
});
G.on('ctx.copy', (d) => {
  const t = String(d.text || '').slice(0, 24);
  const fallback = () => { const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); };
  try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).catch(fallback); else fallback(); } catch (e) { fallback(); }
});

// Badge d'employé : carte aux couleurs de l'entreprise, à droite de l'écran, 8 secondes
let badgeT = 0;
function badgeCard(d) {
  const col = /^#[0-9a-fA-F]{6}$/.test(d.color || '') ? d.color : '#2f86f6';
  const ini = String(d.biz || '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '★';
  const since = Number(d.since) > 0 ? new Date(Number(d.since) * 1000).toLocaleDateString('fr-FR') : null;
  const el = h('div', { class: 'bdg' }, h('div', { class: 'bdg-top' }, h('div', { class: 'bdg-logo' }, ini), h('div', null, h('small', null, 'BADGE PROFESSIONNEL'), h('b', null, String(d.biz || '').slice(0, 40)))),
    h('div', { class: 'bdg-body' },
      h('div', { class: 'bdg-photo' }, String(d.name || '?').slice(0, 1).toUpperCase()),
      h('div', { class: 'bdg-info' }, h('b', null, String(d.name || '').slice(0, 48)), h('span', null, String(d.grade || '').slice(0, 40) + (d.boss ? ' · Direction' : '')),
        h('em', null, 'Matricule ' + String(d.number || '').slice(0, 16)), since ? h('em', null, 'Depuis le ' + since) : null)),
    h('div', { class: 'bdg-foot ' + (d.duty ? 'on' : 'off') }, d.duty ? 'EN SERVICE' : 'HORS SERVICE'));
  el.style.setProperty('--bc', col);
  return el;
}
G.on('badge.show', (d) => {
  const old = document.getElementById('g-badge'); if (old) old.remove();
  const el = badgeCard(d); el.id = 'g-badge';
  G.root.appendChild(el);
  clearTimeout(badgeT); badgeT = setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 400); }, 8000);
});
G.preview.badge = function (box) { G.clear(box); const c = badgeCard({ biz: 'Los Santos Police Dept', color: '#2f6fe0', name: 'Camille Durand', grade: 'Sergent', number: 'LSPD-482913', duty: true, since: 1759000000 }); c.style.position = 'relative'; box.appendChild(c); };

const DEMO = { target: { id: 12, uid: 12, name: 'Camille Durand', sub: 'Police · Officier', gang: 'Ballas', gc: '#a56bff', lines: ['Espèces $640 · Banque $18 250', 'Ping 34 ms'] }, cats: [
  { id: 'people', label: 'Interactions', icon: 'users', entries: [{ id: 'show_id', label: 'Montrer mes papiers', icon: 'id' }, { id: 'give_cash', label: "Donner de l'argent", icon: 'coins', inputs: [{ k: 'amount', label: 'Montant', number: true }] }, { id: 'report', label: 'Signaler cette personne', icon: 'alert', inputs: [{ k: 'reason', label: 'Motif' }] }] },
  { id: 'job', label: 'Métier', icon: 'briefcase', entries: [{ id: 'cuff', label: 'Menotter', icon: 'lock' }, { id: 'search', label: 'Fouiller', icon: 'search', disabled: true, why: 'Trop loin.' }, { id: 'invoice', label: 'Facturer', icon: 'card' }] },
  { id: 'staff', label: 'Staff', icon: 'shield', entries: [{ id: 's_info', label: 'Informations', icon: 'info' }, { id: 's_goto', label: 'Aller vers elle', icon: 'gps' }, { id: 's_warn', label: 'Avertir', icon: 'alert', danger: true }] }] };
const DEMO_V = { target: { id: 77, name: 'Sultan', sub: 'PB 1111', vehicle: true, lines: ['Dehors'] }, cats: [{ id: 'vehicle', label: 'Véhicule', icon: 'car', entries: [
  { id: 'v_lock', label: 'Verrouiller / déverrouiller', icon: 'lock' }, { id: 'v_engine', label: 'Moteur : démarrer / couper', icon: 'bolt' }, { id: 'v_trunk', label: 'Coffre : ouvrir / fermer', icon: 'bag' }, { id: 'v_plate', label: 'Lire la plaque', icon: 'id' },
  { id: 'v_owner', label: 'Propriétaire (fichier)', icon: 'search' }, { id: 'v_impound', label: 'Mettre en fourrière', icon: 'x', danger: true, inputs: [{ k: 'reason', label: 'Motif' }] }] }] };
const DEMO_O = { target: { id: 1, name: 'Distributeur', object: true }, cats: [{ id: 'object', label: 'Distributeur', icon: 'card', entries: [{ id: 'o_use', label: 'Utiliser', icon: 'card' }] }] };
G.preview.ctx = function (box, cfg, blk) {
  G.clear(box);
  const demo = (blk && blk.demo) || 'person';
  const sp = demo === 'vehicle' ? DEMO_V : demo === 'object' ? DEMO_O : DEMO;
  const m = menuView(sp, { theme: cfg, style: (blk && blk.style) || 'simple', static: true, onAct() {} });
  m.style.position = 'absolute'; m.style.left = '108px'; m.style.top = '70px';
  if (m.classList.contains('sxn')) m.style.setProperty('--k', '0.62');
  const who = demo === 'vehicle' ? 'Sultan · PB 1111' : demo === 'object' ? 'Distributeur' : 'Camille Durand';
  const stage = h('div', { class: 'cx-stage' }, h('div', { class: 'cx-person' }, h('b', null, who), h('button', { type: 'button', class: 'cx-hit' + (demo === 'vehicle' ? ' veh' : demo === 'object' ? ' obj' : ''), style: { left: '0', top: '0', position: 'relative', transform: 'none', width: demo === 'vehicle' ? '150px' : '84px', height: demo === 'vehicle' ? '70px' : '190px' } }, h('span', { class: 'cx-hl' }, who))), m);
  box.appendChild(stage); m.__first();
};
})();
