-- PNJ d'un point : à chaque point posé, le staff choisit « sans PNJ » ou un style, puis le place lui-même (aperçu en jeu).
-- Magasins : le PNJ est leur vendeur (options et position du magasin). Autres points : table pb_point_npc, liée au point par sa position.
local P, DB = PB.Perm, PB.DB
local G = PB.G
local Place = PB.Place
local N = {}
G.PointNpc = N

PB.Migrate('545_point_npc', 'PNJ des points posés au Builder', {
    [[CREATE TABLE IF NOT EXISTS pb_point_npc (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, ptype VARCHAR(48) NOT NULL, ax DOUBLE NOT NULL, ay DOUBLE NOT NULL, model VARCHAR(48) NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, h DOUBLE NOT NULL DEFAULT 0)]],
})

-- points où un PNJ n'a pas de sens, ou qui ont déjà le leur (banquier, gardien, médecin, caissier…)
local NO_NPC = { '_out$', '_npc$', 'clerk', 'jail', '^casino', '^bank_', '^ems_', 'garage', 'helipad', '^heist', 'launder', '^property$', '^any_point$', '^barber_all$', 'stash', '^drug_harvest$' }
local function allowed(t)
    if not t or t.nonpc then return false end
    for _, p in ipairs(NO_NPC) do if t.id:find(p) then return false end end
    return true
end

local function styleOk(m) for _, s in ipairs(G.NpcStyles) do if s[1] == m then return true end end return false end
local function near2(ax, ay, bx, by, d) return (ax - bx) ^ 2 + (ay - by) ^ 2 <= d * d end

function N.Rows() return DB.q('SELECT id, model, x, y, z, h FROM pb_point_npc') or {} end
function N.Push(src) TriggerClientEvent('pb:g:pnpc:list', src or -1, PB.Json(N.Rows())) end
table.insert(G.beginHooks, function(src) N.Push(src) end)

-- retire le PNJ lié à cet endroit (point supprimé, ou PNJ remplacé)
function N.ClearAt(x, y)
    x, y = tonumber(x), tonumber(y)
    if not x or not y then return end
    local n = 0
    for _, r in ipairs(DB.q('SELECT id, ax, ay FROM pb_point_npc') or {}) do
        if near2(tonumber(r.ax), tonumber(r.ay), x, y, 1.0) then DB.exec('DELETE FROM pb_point_npc WHERE id = ?', { r.id }) n = n + 1 end
    end
    if n > 0 then N.Push() end
end

local offers = {}   -- src -> { type, label, x, y, shop }
AddEventHandler('playerDropped', function() offers[source] = nil end)
function N.Offer(src, o)
    offers[src] = o
    TriggerClientEvent('pb:g:pnpc:offer', src, PB.Json({ label = o.label, styles = G.NpcStyles }))
end
-- juste après la pose d'un point
function N.OfferNew(src, t, made)
    if not made or made.many or not allowed(t) then return end
    N.Offer(src, { type = t.id, label = tostring(made.name or t.label), x = made.x, y = made.y, shop = made.shop })
end
-- depuis la liste des points déjà posés
function N.OfferExisting(src, typeId, row)
    local t = Place.types[typeId]
    if not allowed(t) then return false, "Ce point ne prend pas de PNJ." end
    local id = tonumber(row.id)
    local s = id and DB.one('SELECT id FROM pb_shops WHERE id = ? AND ABS(x - ?) < 2 AND ABS(y - ?) < 2', { id, tonumber(row.x) or 0, tonumber(row.y) or 0 })
    N.Offer(src, { type = typeId, label = tostring(row.label or t.label), x = tonumber(row.x), y = tonumber(row.y), shop = s and s.id or nil })
    return true
end

local function shopOpts(id, fn)
    local r = DB.one('SELECT opts FROM pb_shops WHERE id = ?', { id })
    if not r then return false end
    local ok, o = pcall(json.decode, r.opts or '{}')
    o = ok and type(o) == 'table' and o or {}
    fn(o)
    DB.exec('UPDATE pb_shops SET opts = ? WHERE id = ?', { PB.Json(o), id })
    return true
end

local function take(src)
    if not P.Has(src, 'carte.place') then return nil end
    local o = offers[src]
    offers[src] = nil
    return o
end
RegisterNetEvent('pb:g:pnpc:none', function()
    local src = source
    local o = take(src)
    if not o then return end
    if o.shop then
        shopOpts(o.shop, function(v) v.npc_on, v.npc_off = false, true end)
        G.PushConfig()
    else N.ClearAt(o.x, o.y) end
    PB.Audit.Log('config', 'pnpc.none', src, o.type, nil, { label = o.label })
end)
RegisterNetEvent('pb:g:pnpc:set', function(model, x, y, z, h)
    local src = source
    local o = take(src)
    if not o then return end
    model, x, y, z, h = tostring(model), tonumber(x), tonumber(y), tonumber(z), tonumber(h) or 0.0
    if not styleOk(model) or not x or not y or not z then return end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c or not near2(c.x, c.y, x, y, 40.0) or not o.x or not near2(o.x, o.y, x, y, 300.0) then
        G.Notify(src, { type = 'error', title = 'Builder', text = 'PNJ trop loin du point.' })
        return
    end
    if o.shop then
        shopOpts(o.shop, function(v) v.npc_on, v.npc_off, v.npc_model = true, false, model end)
        DB.exec('REPLACE INTO pb_clerk_pos (shop_id, x, y, z, h) VALUES (?, ?, ?, ?, ?)', { o.shop, x, y, z, math.floor(h) })
        G.PushConfig()
    else
        N.ClearAt(o.x, o.y)
        DB.insert('INSERT INTO pb_point_npc (ptype, ax, ay, model, x, y, z, h) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', { o.type, o.x, o.y, model, x, y, z, h })
        N.Push()
    end
    PB.Audit.Log('config', 'pnpc.set', src, o.type, nil, { label = o.label, model = model })
    G.Notify(src, { type = 'success', title = 'Builder', text = ('PNJ posé pour « %s ».'):format(o.label) })
end)
