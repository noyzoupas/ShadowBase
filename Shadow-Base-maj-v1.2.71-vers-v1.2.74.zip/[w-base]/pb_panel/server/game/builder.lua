-- Builder du menu staff (F10 › Builder) : tout créer et placer en jeu, à pied, avec E.
-- Groupes illégaux (gang, organisation, cartel, MC), entreprises du catalogue, drogues prêtes à l'emploi, magasins, location, banques,
-- garages, coffres, braquages, blanchiment, points de vente / drapeaux, points des autres ressources (ex. Burger Shot)…
-- Tout passe par la Carte (PB.Place) : la position est toujours lue côté serveur sur le joueur au moment où il appuie sur E.

local P = PB.Perm
local G, DB = PB.G, PB.DB
local S = G.Staff
local Place = PB.Place

-- Types de groupes illégaux : même fonctionnement (membres, grades, QG, coffre, garage, drapeaux), nom et couleur par défaut différents
local GROUP_TYPES = {
    { id = 'gang', label = 'Gang', color = '#e74c3c' },
    { id = 'orga', label = 'Organisation', color = '#9b59b6' },
    { id = 'cartel', label = 'Cartel', color = '#f39c12' },
    { id = 'mc', label = 'MC (club de motards)', color = '#7f8c8d' },
}
local GT = {}
for _, t in ipairs(GROUP_TYPES) do GT[t.id] = t end

local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):sub(1, n)) end
-- lance ces lectures en même temps : chacune attend sa réponse, et l'une après l'autre elles retardaient l'ouverture du menu
local function together(jobs)
    if #jobs == 0 then return end
    local left, p = #jobs, promise.new()
    for _, fn in ipairs(jobs) do
        CreateThread(function()
            pcall(fn)
            left = left - 1
            if left == 0 then p:resolve(true) end
        end)
    end
    Citizen.Await(p)
end

-- Ce que le menu affiche (seulement pour qui peut placer des points)
table.insert(S.SpecExtra, function(src, spec)
    if not P.Has(src, 'carte.place') then return end
    local groups = {}
    for _, t in ipairs(Place.Types()) do
        groups[t.group] = groups[t.group] or {}
        local g = groups[t.group]
        g[#g + 1] = { id = t.id, label = t.label, needs = t.needs, presets = t.presets }
    end
    local cats = {}
    for _, c in ipairs(G.BizCat and G.BizCat.Cats or {}) do cats[#cats + 1] = { id = c.id, label = c.label, items = {} } end
    local catBy = {}
    for _, c in ipairs(cats) do catBy[c.id] = c end
    local made = {}
    for _, b in ipairs(G.Biz.List()) do made[b.id] = true end
    for _, t in ipairs(G.BizCat and G.BizCat.List or {}) do
        local c = catBy[t.cat]
        if c and G.BizCat.Visible(t, made) then c.items[#c.items + 1] = { key = t.key, label = t.label, made = made[t.key] == true } end
    end
    local gangs = {}
    for gid, d in pairs(G.Tags.GangDefs()) do gangs[#gangs + 1] = { gid, d.label, d.type or 'gang' } end
    table.sort(gangs, function(a, b) return a[2] < b[2] end)
    local bizs, custom = {}, {}
    for _, b in ipairs(G.Biz.List()) do
        bizs[#bizs + 1] = { b.id, b.label }
        if not (G.BizCat.ByKey[b.id]) then local t = G.BizCat.ModelOf(b) custom[#custom + 1] = { b.id, b.label, t and t.label or 'Entreprise' } end
    end
    -- tous les modèles (même ceux masqués du catalogue) pour créer une entreprise sur mesure
    local models = {}
    for _, c in ipairs(G.BizCat.Cats) do
        local l = {}
        for _, t in ipairs(G.BizCat.List) do if t.cat == c.id then l[#l + 1] = { t.key, t.label, t.blip and t.blip[1] or 475, t.blip and t.blip[2] or 3 } end end
        if #l > 0 then models[#models + 1] = { id = c.id, label = c.label, items = l } end
    end
    local drugs = {}
    for _, k in ipairs(G.Crime.DRUG_ORDER) do local d = G.Crime.DRUGS[k] drugs[#drugs + 1] = { k, d.label, d.raw[2], d.pouch[2], d.price } end
    local ext = {}
    -- une ressource qui porte le nom d'une entreprise du catalogue (ex. burgershot) est rangée avec cette entreprise, pas dans « Ressources »
    for _, e in pairs(Place.ext or {}) do if not (G.BizCat and G.BizCat.ByKey and G.BizCat.ByKey[e.id]) then ext[#ext + 1] = e end end
    table.sort(ext, function(a, b) return a.label < b.label end)
    -- garages publics et fourrières (les garages d'entreprise / de gang se règlent avec leur entreprise ou leur groupe)
    local garages = {}
    for _, g in ipairs(DB.q("SELECT id, label, kind, vtype FROM pb_garages WHERE kind IN ('public', 'impound') ORDER BY kind, label") or {}) do garages[#garages + 1] = { g.id, g.label, g.kind, g.vtype or 'car' } end
    -- (v1.2.43) Builder › Existant : les points isolés déjà posés, par type (le plus proche en premier)
    local placed = {}
    local ped = GetPlayerPed(src)
    local me = ped and ped ~= 0 and GetEntityCoords(ped) or nil
    local listed, extListed, jobs = {}, {}, {}
    for _, t in ipairs(Place.Types()) do
        local def = Place.types[t.id]
        if not t.needs and t.id:sub(1, 5) ~= 'drug_' and t.id ~= 'garage' and def and def.list then jobs[#jobs + 1] = function() listed[t.id] = def.list() end end
    end
    for id, e in pairs(Place.ext or {}) do
        if e.listable and e.cb then jobs[#jobs + 1] = function() extListed[id] = e.cb(src, '__list', '') end end
    end
    together(jobs)
    for _, t in ipairs(Place.Types()) do
        do
            local rows = listed[t.id]
            if type(rows) == 'table' and #rows > 0 then
                local items = {}
                for _, r in ipairs(rows) do
                    local d = (me and tonumber(r.x) and tonumber(r.y)) and math.floor(math.sqrt((me.x - r.x) ^ 2 + (me.y - r.y) ^ 2) + 0.5) or nil
                    items[#items + 1] = { id = tostring(r.id), label = clean(r.label, 48), dist = d, x = tonumber(r.x) and math.floor(r.x), y = tonumber(r.y) and math.floor(r.y), z = tonumber(r.z) and math.floor(r.z) }
                end
                table.sort(items, function(a, b) return (a.dist or 1e9) < (b.dist or 1e9) end)
                while #items > 80 do table.remove(items) end
                placed[#placed + 1] = { type = t.id, label = t.label, group = t.group, items = items }
            end
        end
    end
    -- points des extensions (pêche, chasse, activités, braquages…) : ils se suppriment ici un par un
    for id, e in pairs(Place.ext or {}) do
        if e.listable and e.cb then
            local rows = extListed[id]
            if type(rows) == 'table' and #rows > 0 then
                local items = {}
                for _, r in ipairs(rows) do
                    if type(r) == 'table' and r.key ~= nil then
                        local d = (me and tonumber(r.x) and tonumber(r.y)) and math.floor(math.sqrt((me.x - r.x) ^ 2 + (me.y - r.y) ^ 2) + 0.5) or nil
                        items[#items + 1] = { id = tostring(r.key), label = clean(r.label or r.key, 48), dist = d, x = tonumber(r.x) and math.floor(r.x), y = tonumber(r.y) and math.floor(r.y), z = tonumber(r.z) and math.floor(r.z) }
                    end
                end
                table.sort(items, function(a, b) return (a.dist or 1e9) < (b.dist or 1e9) end)
                while #items > 80 do table.remove(items) end
                placed[#placed + 1] = { type = 'ext:' .. id, label = e.label, group = 'Extensions', items = items }
            end
        end
    end
    table.sort(placed, function(a, b) return a.label < b.label end)
    local terr = {}
    for _, z in ipairs(PB.Cfg.Get('territories', 'zones', {}) or {}) do
        local d = (z.reward_item or '') ~= '' and G.Inv and G.Inv.Def and G.Inv.Def(z.reward_item)
        terr[#terr + 1] = { z.id, z.label, z.reward_item or '', d and ((tonumber(z.reward_qty) or 1) .. ' × ' .. (d.label or z.reward_item)) or '', tonumber(z.reward_qty) or 1, tonumber(z.reward_hours) or 5 }
    end
    spec.builder = { canpack = P.Has(src, 'staff.items'), packcash = P.Has(src, 'staff.money'), bizpacks = G.Biz.Packs(), terr = terr, rewards = G.Territories and G.Territories.RewardChoices and G.Territories.RewardChoices() or {}, garages = garages, groups = groups, gtypes = GROUP_TYPES, packs = G.Orgs and G.Orgs.Packs and G.Orgs.Packs() or nil, cats = cats, gangs = gangs, bizs = bizs, custom = custom, models = models, drugs = drugs, ext = ext, placed = placed, canDelete = P.Has(src, 'carte.delete') or nil }
end)

local function staffName(src) local p = G.Get(src) return p and p.license or ('#' .. tostring(src)) end

-- Poser un point de n'importe quel type : E pour placer, Retour arrière pour annuler
S.Def('b_place', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local ok, err = Place.Arm(src, tostring(p.type or ''), clean(p.name, 48), tostring(p.owner or ''), clean(p.preset, 48))
    if not ok then return false, err end
    return true, 'Va à l\'endroit voulu puis appuie sur E (Retour arrière : annuler).'
end })

-- Liste des points d'une cible ----------------------------------------------------------------------------------------------------------------
-- Cible = un groupe (gang), une entreprise (biz), une drogue (drug) ou une autre ressource (ext). Chaque point est « défini » (position connue)
-- ou non ; Entrée sur place le pose ou le DÉPLACE (un coffre déplacé garde son contenu, un garage ses véhicules). « Poser un autre » en ajoute un.
local function f(v) return (tonumber(v) or 0) + 0.0 end
local function cfgList(ns, key) local out = {} for _, r in ipairs(PB.Cfg.Get(ns, key, {}) or {}) do out[#out + 1] = r end return out end

local function stepsOf(kind, owner)
    if kind == 'gang' or kind == 'biz' then
        local out = {}
        for _, st in ipairs(Place.PackSteps(kind, owner)) do
            out[#out + 1] = { key = st.type .. '|' .. st.name, type = st.type, name = st.name, hint = st.hint, add = st.add, ask = st.ask }
            -- gardien du garage de l'entreprise / du groupe, juste après sa sortie
            if st.type == 'biz_garage_out' or st.type == 'gang_garage_out' then out[#out + 1] = { key = kind .. '_garage_npc|Gardien du garage', type = kind .. '_garage_npc', name = 'Gardien du garage (PNJ)', hint = 'Facultatif : place-toi où le gardien doit se tenir.' } end
        end
        -- hélipad (facultatif) : hélicoptères de service de l'entreprise (police, secours, presse…)
        if kind == 'biz' then
            out[#out + 1] = { key = 'biz_helipad|Hélipad', type = 'biz_helipad', name = 'Hélipad (facultatif)', hint = "Entrée de l'hélipad : E pour sortir ou ranger les hélicoptères de l'entreprise." }
            out[#out + 1] = { key = 'biz_helipad_out|Hélipad : posé', type = 'biz_helipad_out', name = "Hélipad : où l'hélicoptère apparaît", hint = 'Place-toi au centre de la plateforme, dans le sens du décollage.' }
            out[#out + 1] = { key = 'biz_helipad_npc|Hélipad : gardien', type = 'biz_helipad_npc', name = 'Hélipad : gardien (PNJ)', hint = 'Facultatif.' }
        end
        -- points de la ressource du même nom (ex. Burger Shot : bornes, postes de cuisine, comptoir, adresses de livraison)
        local e = kind == 'biz' and Place.ext and Place.ext[owner]
        for _, pt in ipairs(e and e.points or {}) do out[#out + 1] = { key = pt.id, type = pt.id, name = pt.label, ask = pt.ask, add = pt.multi or nil, ext = owner, pid = pt.pid, hint = pt.multi and ('Ajouté à ta position (géré par la ressource « ' .. e.res .. ' »).') or 'Un seul point : Entrée le place ou le déplace ici.' } end
        return out
    elseif kind == 'garage' then
        local g = DB.one('SELECT kind, vtype FROM pb_garages WHERE id = ?', { owner })
        local where = g and (g.vtype == 'boat' and 'sur l\'eau, face au large' or (g.vtype == 'air' and 'sur l\'héliport ou la piste' or 'sur la route, dans le sens de sortie')) or ''
        return { { key = 'garage_entry', type = 'garage_entry', name = 'Entrée (menu du garage)', hint = 'Là où le joueur appuie sur E pour sortir ou ranger un véhicule.' },
            { key = 'garage_exit', type = 'garage_exit', name = 'Sortie des véhicules', hint = 'Place-toi ' .. where .. ' : le véhicule apparaît là, dans ton sens.' },
            { key = 'garage_npc', type = 'garage_npc', name = 'Gardien (PNJ)', hint = 'Place-toi où le gardien se tient, tourné vers les clients. Sans gardien posé, il se tient sur l\'entrée.' } }
    elseif kind == 'drug' then
        local d = G.Crime.DRUGS[owner]
        if not d then return {} end
        return { { key = 'drug_harvest', type = 'drug_harvest', name = 'Récolte', hint = 'Zone où l\'on ramasse ' .. d.raw[2]:lower() .. ' (2 s, penché).' },
            { key = 'drug_process', type = 'drug_process', name = 'Laboratoire', hint = '2 × ' .. d.raw[2]:lower() .. ' → 1 × ' .. d.pouch[2]:lower() .. '.' },
            { key = 'drug_sell', type = 'drug_sell', name = 'Vente et drapeau', hint = '3 pochons max par passage ; brut x0,2 ; drapeau x1,7.' } }
    elseif kind == 'ext' then
        local e = Place.ext and Place.ext[owner]
        local out = {}
        for _, pt in ipairs(e and e.points or {}) do out[#out + 1] = { key = pt.id, type = pt.id, name = pt.label, ask = pt.ask, add = pt.multi or nil, ext = owner, pid = pt.pid, hint = pt.multi and 'Ajoute un point à ta position (la ressource gère la liste).' or 'Un seul point : Entrée le place ou le déplace ici.' } end
        return out
    end
    return {}
end

-- Garage d'une entreprise / d'un groupe : le garage des véhicules terrestres ou l'hélipad (vt = 'air')
local function garageOf(gk, owner, vt)
    if vt == 'air' then return DB.one("SELECT * FROM pb_garages WHERE kind = ? AND biz = ? AND vtype = 'air' ORDER BY id LIMIT 1", { gk, owner }) end
    return DB.one("SELECT * FROM pb_garages WHERE kind = ? AND biz = ? AND vtype <> 'air' ORDER BY id LIMIT 1", { gk, owner })
end
-- étapes d'un garage d'entreprise / de groupe : { genre, type de véhicule, partie }
local GAR = { biz_garage = { 'biz', 'car', 'entry' }, biz_garage_out = { 'biz', 'car', 'out' }, biz_garage_npc = { 'biz', 'car', 'npc' },
    gang_garage = { 'gang', 'car', 'entry' }, gang_garage_out = { 'gang', 'car', 'out' }, gang_garage_npc = { 'gang', 'car', 'npc' },
    biz_helipad = { 'biz', 'air', 'entry' }, biz_helipad_out = { 'biz', 'air', 'out' }, biz_helipad_npc = { 'biz', 'air', 'npc' } }
local function garOf(t, owner) local g = GAR[t] return g and garageOf(g[1], owner, g[2]) end
local function set0(v) return (tonumber(v) or 0) ~= 0 end
local PT_KIND = { gang_hq = { 'gang', 'hq' }, gang_stash = { 'gang', 'stash' }, biz_hq = { 'biz', 'hq' }, biz_duty = { 'biz', 'duty' }, biz_boss = { 'biz', 'boss' },
    biz_desk = { 'biz', 'desk' }, biz_workshop = { 'biz', 'workshop' }, biz_kitchen = { 'biz', 'kitchen' }, biz_wardrobe = { 'biz', 'wardrobe' }, gang_wardrobe = { 'gang', 'wardrobe' } }

-- Où est le point (nil = aucune position) : { x, y, z, ref }
local function locate(kind, owner, st)
    local t = st.type
    local pk = PT_KIND[t]
    if pk then
        local r = DB.one('SELECT id, x, y, z FROM pb_points WHERE owner_kind = ? AND owner = ? AND kind = ? ORDER BY id LIMIT 1', { pk[1], owner, pk[2] })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t == 'biz_stash' then
        local r = DB.one('SELECT id, x, y, z FROM pb_inv_stashes WHERE biz = ? AND label = ? ORDER BY id LIMIT 1', { owner, st.name })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif GAR[t] then
        local g, part = garOf(t, owner), GAR[t][3]
        if not g then return nil end
        if part == 'entry' then return { x = g.x, y = g.y, z = g.z, ref = g.id } end
        if part == 'out' then return (set0(g.sx) or set0(g.sy)) and { x = g.sx, y = g.sy, z = g.sz, ref = g.id } or nil end
        return (set0(g.nx) or set0(g.ny)) and { x = g.nx, y = g.ny, z = g.nz, ref = g.id } or nil
    elseif kind == 'garage' then
        local g = DB.one('SELECT * FROM pb_garages WHERE id = ?', { owner })
        if not g then return nil end
        if t == 'garage_entry' then return { x = g.x, y = g.y, z = g.z, ref = g.id } end
        if t == 'garage_exit' then return ((tonumber(g.sx) or 0) ~= 0 or (tonumber(g.sy) or 0) ~= 0) and { x = g.sx, y = g.sy, z = g.sz, ref = g.id } or nil end
        if t == 'garage_npc' then return ((tonumber(g.nx) or 0) ~= 0 or (tonumber(g.ny) or 0) ~= 0) and { x = g.nx, y = g.ny, z = g.nz, ref = g.id } or nil end
        return nil
    elseif t == 'biz_wardrobe' then
        local r = DB.one("SELECT id, x, y, z FROM pb_shops WHERE kind = 'clothes' AND opts LIKE ? ORDER BY id LIMIT 1", { '%"biz_owner":"' .. owner .. '"%' })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t == 'biz_shop' then
        local r = DB.one("SELECT id, x, y, z FROM pb_shops WHERE kind = 'store' AND opts LIKE ? ORDER BY id LIMIT 1", { '%"biz_counter":"' .. owner .. '"%' })
        return r and { x = r.x, y = r.y, z = r.z, ref = r.id } or nil
    elseif t:sub(1, 5) == 'drug_' then
        local k = t:sub(6)
        for _, r in ipairs(PB.Cfg.Get('crime', 'chain', {}) or {}) do if r.drug == owner and r.kind == k then return { x = r.x, y = r.y, z = r.z, ref = r.id } end end
    end
    return nil
end

-- (v1.2.46) Peut-on en poser un deuxième ? Pas les garages : entrée, sortie et gardien forment un seul garage, chacun a sa ligne.
local function canMore(kind, st) return not st.add and not st.ext and not GAR[st.type] and kind ~= 'garage' end
local function countOf(kind, owner, st)
    local t = st.type
    if PT_KIND[t] then return tonumber(DB.scalar('SELECT COUNT(*) FROM pb_points WHERE owner_kind = ? AND owner = ? AND kind = ?', { PT_KIND[t][1], owner, PT_KIND[t][2] })) or 0 end
    if t == 'biz_stash' then return tonumber(DB.scalar('SELECT COUNT(*) FROM pb_inv_stashes WHERE biz = ? AND label = ?', { owner, st.name })) or 0 end
    if t == 'biz_wardrobe' then return tonumber(DB.scalar("SELECT COUNT(*) FROM pb_shops WHERE kind = 'clothes' AND opts LIKE ?", { '%"biz_owner":"' .. owner .. '"%' })) or 0 end
    if t == 'biz_shop' then return tonumber(DB.scalar("SELECT COUNT(*) FROM pb_shops WHERE kind = 'store' AND opts LIKE ?", { '%"biz_counter":"' .. owner .. '"%' })) or 0 end
    if t:sub(1, 5) == 'drug_' then
        local n = 0
        for _, r in ipairs(PB.Cfg.Get('crime', 'chain', {}) or {}) do if r.drug == owner and r.kind == t:sub(6) then n = n + 1 end end
        return n
    end
    return 0
end

-- Déplace un point existant à la position du joueur
local function move(kind, owner, st, at, pos)
    local t = st.type
    if PT_KIND[t] then
        DB.exec('UPDATE pb_points SET x = ?, y = ?, z = ?, h = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
        if t == 'biz_hq' then DB.exec('UPDATE pb_biz SET hx = ?, hy = ?, hz = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), owner }) end
        G.Points.PushAll()
    elseif t == 'biz_stash' then DB.exec('UPDATE pb_inv_stashes SET x = ?, y = ?, z = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), at.ref })
    elseif GAR[t] and GAR[t][3] == 'entry' then DB.exec('UPDATE pb_garages SET x = ?, y = ?, z = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), at.ref })
    elseif GAR[t] and GAR[t][3] == 'out' then DB.exec('UPDATE pb_garages SET sx = ?, sy = ?, sz = ?, sh = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
    elseif t == 'biz_wardrobe' or t == 'biz_shop' then DB.exec('UPDATE pb_shops SET x = ?, y = ?, z = ?, h = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
    elseif t == 'garage_entry' then DB.exec('UPDATE pb_garages SET x = ?, y = ?, z = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), at.ref })
    elseif t == 'garage_exit' then DB.exec('UPDATE pb_garages SET sx = ?, sy = ?, sz = ?, sh = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
    elseif t == 'garage_npc' or (GAR[t] and GAR[t][3] == 'npc') then DB.exec('UPDATE pb_garages SET nx = ?, ny = ?, nz = ?, nh = ? WHERE id = ?', { f(pos.x), f(pos.y), f(pos.z), f(pos.h), at.ref })
    elseif t:sub(1, 5) == 'drug_' then
        local list = cfgList('crime', 'chain')
        for _, r in ipairs(list) do if r.id == at.ref then
            local p = G.Crime.PolyOf(r.id)
            if p then
                local dx, dy, dz = f(pos.x) - r.x, f(pos.y) - r.y, f(pos.z) - r.z
                for _, q in ipairs(p) do q[1], q[2], q[3] = q[1] + dx, q[2] + dy, q[3] + dz end
                G.Crime.SetPoly(r.id, p)
            end
            r.x, r.y, r.z = f(pos.x), f(pos.y), f(pos.z)
        end end
        PB.Cfg.Set('crime', 'chain', list, 0, 'Builder : déplacement')
    else return false end
    G.PushConfig()
    return true
end

-- Supprime un point posé (et son blip). Les véhicules rangés dans un garage supprimé se sortent ensuite dans n'importe quel garage public.
local function remove(kind, owner, st, at)
    local t = st.type
    if PT_KIND[t] then G.Points.Remove(at.ref) G.Points.PushAll()
        if t == 'biz_hq' then DB.exec('UPDATE pb_biz SET hx = 0, hy = 0, hz = 0 WHERE id = ?', { owner }) end
    elseif t == 'biz_stash' then DB.exec('DELETE FROM pb_inv_stashes WHERE id = ?', { at.ref }) DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. tostring(at.ref) })
    elseif GAR[t] and GAR[t][3] == 'entry' then DB.exec('DELETE FROM pb_garages WHERE id = ?', { at.ref }) DB.exec("UPDATE pb_vehicle_state SET garage = '' WHERE garage = ?", { at.ref })
    elseif GAR[t] and GAR[t][3] == 'out' then DB.exec('UPDATE pb_garages SET sx = 0, sy = 0, sz = 0, sh = 0 WHERE id = ?', { at.ref })
    elseif t == 'biz_wardrobe' or t == 'biz_shop' then DB.exec('DELETE FROM pb_shops WHERE id = ?', { at.ref }) DB.exec('DELETE FROM pb_shop_stock WHERE shop = ?', { at.ref })
    elseif t == 'garage_entry' then DB.exec('DELETE FROM pb_garages WHERE id = ?', { at.ref }) DB.exec("UPDATE pb_vehicle_state SET garage = '' WHERE garage = ?", { at.ref })
    elseif t == 'garage_exit' then DB.exec('UPDATE pb_garages SET sx = 0, sy = 0, sz = 0, sh = 0 WHERE id = ?', { at.ref })
    elseif t == 'garage_npc' or (GAR[t] and GAR[t][3] == 'npc') then DB.exec('UPDATE pb_garages SET nx = 0, ny = 0, nz = 0, nh = 0 WHERE id = ?', { at.ref })
    elseif t:sub(1, 5) == 'drug_' then
        local list, out = cfgList('crime', 'chain'), {}
        for _, r in ipairs(list) do if r.id ~= at.ref then out[#out + 1] = r end end
        PB.Cfg.Set('crime', 'chain', out, 0, 'Builder : suppression')
        G.Crime.SetPoly(at.ref, nil)
    else return false end
    G.PushConfig()
    return true
end

local function targetLabel(kind, owner)
    if kind == 'gang' then local d = G.Tags.GangDefs()[owner] return d and d.label, d and (GT[d.type or 'gang'] or GT.gang).label or 'Groupe' end
    if kind == 'biz' then local b = G.Biz.Get(owner) return b and b.label, 'Entreprise' end
    if kind == 'drug' then local d = G.Crime.DRUGS[owner] return d and d.label, 'Drogue' end
    if kind == 'ext' then local e = Place.ext and Place.ext[owner] return e and e.label, 'Ressource' end
    if kind == 'garage' then local g = DB.one('SELECT label, kind, vtype FROM pb_garages WHERE id = ?', { owner }) return g and g.label, g and (g.kind == 'impound' and 'Fourrière' or ({ air = 'Hangar', boat = 'Port' })[g.vtype] or 'Garage') end
end

-- TOUS les points d'une entreprise / d'un gang, quel que soit leur format (y compris ceux posés par d'anciennes versions) :
-- points (pb_points, toutes sortes), coffres, garages, vestiaires et boutiques. Chacun a une clé « table:id » pour le supprimer.
local KIND_FR = { hq = 'Siège / QG', duty = 'Prise de service', boss = 'Bureau du patron', stash = 'Coffre', wardrobe = 'Vestiaire', garage = 'Garage',
    desk = 'Accueil', workshop = 'Pont (atelier)', kitchen = 'Cuisine / bar' }
local function extList(id, src)
    local e = Place.ext and Place.ext[id]
    if not e or not e.cb or not e.listable then return {} end
    local ok, list = pcall(e.cb, src or 0, '__list', '')
    return (ok and type(list) == 'table') and list or {}
end
local function allPoints(kind, owner, src)
    local out = {}
    if (kind == 'biz' or kind == 'ext') and Place.ext and Place.ext[owner] then
        for _, p in ipairs(extList(owner, src)) do
            if type(p) == 'table' and p.key then out[#out + 1] = { key = 'ex:' .. tostring(p.key), label = Place.ext[owner].label .. ' — ' .. tostring(p.label or p.key), x = tonumber(p.x), y = tonumber(p.y), z = tonumber(p.z) } end
        end
    end
    if kind ~= 'biz' and kind ~= 'gang' then return out end
    for _, r in ipairs(DB.q('SELECT id, kind, label, x, y, z FROM pb_points WHERE owner_kind = ? AND owner = ? ORDER BY id', { kind, owner }) or {}) do
        out[#out + 1] = { key = 'pt:' .. r.id, label = (KIND_FR[r.kind] or r.kind) .. (r.label ~= '' and (' — ' .. r.label) or ''), x = r.x, y = r.y, z = r.z }
    end
    if kind == 'biz' then
        for _, r in ipairs(DB.q('SELECT id, label, x, y, z FROM pb_inv_stashes WHERE biz = ?', { owner }) or {}) do out[#out + 1] = { key = 'st:' .. r.id, label = 'Coffre — ' .. r.label, x = r.x, y = r.y, z = r.z } end
        for _, r in ipairs(DB.q("SELECT id, label, kind, x, y, z, opts FROM pb_shops WHERE opts LIKE ? OR opts LIKE ? OR opts LIKE ?", { '%"biz_owner":"' .. owner .. '"%', '%"biz_counter":"' .. owner .. '"%', '%"biz":"' .. owner .. '"%' }) or {}) do
            out[#out + 1] = { key = 'sh:' .. r.id, label = (r.kind == 'clothes' and 'Vestiaire — ' or 'Boutique — ') .. r.label, x = r.x, y = r.y, z = r.z }
        end
    end
    for _, r in ipairs(DB.q('SELECT id, label, x, y, z, vtype FROM pb_garages WHERE kind = ? AND biz = ?', { kind, owner }) or {}) do out[#out + 1] = { key = 'ga:' .. r.id, label = (r.vtype == 'air' and 'Hélipad — ' or 'Garage — ') .. r.label, x = r.x, y = r.y, z = r.z } end
    return out
end
G.BuilderAllPoints = allPoints
-- supprime un élément de allPoints (vérifie qu'il appartient bien à cette cible)
local function removeRaw(kind, owner, key, src)
    local t, id = tostring(key):match('^(%a%a):(.+)$')
    if not t then return false end
    for _, p in ipairs(allPoints(kind, owner, src)) do
        if p.key == key then
            if t == 'ex' then
                local e = Place.ext and Place.ext[owner]
                local ok, r = pcall(e.cb, src or 0, '__delete', id)
                return ok and r ~= false
            elseif t == 'pt' then G.Points.Remove(tonumber(id))
            elseif t == 'st' then DB.exec('DELETE FROM pb_inv_stashes WHERE id = ?', { id }) DB.exec('DELETE FROM pb_inv WHERE owner = ?', { 's:' .. id })
            elseif t == 'sh' then DB.exec('DELETE FROM pb_shops WHERE id = ?', { tonumber(id) }) DB.exec('DELETE FROM pb_shop_stock WHERE shop = ?', { tonumber(id) })
            elseif t == 'ga' then DB.exec('DELETE FROM pb_garages WHERE id = ?', { id }) end
            if kind == 'biz' and t == 'pt' then DB.exec("UPDATE pb_biz SET hx = 0, hy = 0, hz = 0 WHERE id = ? AND NOT EXISTS (SELECT 1 FROM pb_points WHERE owner_kind = 'biz' AND owner = ? AND kind = 'hq')", { owner, owner }) end
            return true
        end
    end
    return false
end

-- Envoie la liste des points au client (le menu s'ouvre ou se met à jour)
local function sendPoints(src, kind, owner, sel)
    local label, what = targetLabel(kind, owner)
    if not label then return false, 'Introuvable.' end
    local list, n = {}, 0
    local ext = {}
    for _, p in ipairs((kind == 'biz' or kind == 'ext') and extList(owner, src) or {}) do if type(p) == 'table' and p.key then ext[tostring(p.key)] = p end end
    for _, st in ipairs(stepsOf(kind, owner)) do
        -- (v1.2.59) point d'une ressource : ses lignes s'appellent souvent « zone_1 », « school_2 »…, pas comme le point du Builder (« zone ») :
        -- il restait marqué « Aucune position » alors qu'il était bien posé. Une ligne au nom exact du point reste un point unique.
        local extCount = 0
        if st.ext then
            local pid = tostring(st.pid)
            for key in pairs(ext) do if key:sub(1, #pid + 1) == pid .. '_' then extCount = extCount + 1 end end
        end
        local at = not st.add and (st.ext and ext[tostring(st.pid)] or (not st.ext and locate(kind, owner, st))) or nil
        if at or extCount > 0 then n = n + 1 end
        local cnt = extCount > 0 and extCount or nil
        if st.add and PT_KIND[st.type] then
            cnt = tonumber(DB.scalar('SELECT COUNT(*) FROM pb_points WHERE owner_kind = ? AND owner = ? AND kind = ?', { PT_KIND[st.type][1], owner, PT_KIND[st.type][2] })) or 0
            if cnt > 0 then n = n + 1 end
        end
        local more = at and canMore(kind, st) or nil
        if more then cnt = countOf(kind, owner, st) end
        list[#list + 1] = { key = st.key, name = st.name, hint = st.hint or '', ask = st.ask, add = st.add or extCount > 0 or nil, more = more, count = cnt, raw = st.ext and ('ex:' .. tostring(st.pid)) or nil, x = at and tonumber(at.x), y = at and tonumber(at.y), z = at and tonumber(at.z) }
    end
    local all = allPoints(kind, owner, src)
    -- joueurs connectés (choix du patron / chef) et icône actuelle du siège
    local players = {}
    if kind == 'biz' or kind == 'gang' then
        for id in pairs(G.Players()) do
            local i = G.Identity(id)
            players[#players + 1] = { id = id, name = (i and i.created and (i.firstname or '') ~= '') and ((i.firstname .. ' ' .. (i.lastname or '')):sub(1, 40)) or (GetPlayerName(id) or ('Joueur ' .. id)) }
        end
        table.sort(players, function(a, b) return a.name < b.name end)
    end
    local hq = (kind == 'biz' or kind == 'gang') and DB.one("SELECT sprite, bcolor FROM pb_points WHERE owner_kind = ? AND owner = ? AND kind = 'hq' ORDER BY id LIMIT 1", { kind, owner }) or nil
    local blip = hq and { tonumber(hq.sprite) or 0, tonumber(hq.bcolor) or 0 } or (kind == 'biz' and G.BizCat.BlipOf(owner)) or (kind == 'gang' and { 615, 1 }) or nil
    TriggerClientEvent('pb:g:builder:points', src, PB.Json({ kind = kind, owner = owner, label = label, what = what, steps = list, done = math.max(n, #all), sel = sel, all = all, players = players, blip = blip, bizpacks = kind == 'biz' and G.Biz.Packs() or nil }))
    return true
end
local function canTarget(kind, owner) return targetLabel(kind, owner) ~= nil end

RegisterNetEvent('pb:g:builder:list', function(kind, owner)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    sendPoints(src, tostring(kind), tostring(owner))
end)

-- Entrée sur place : pose le point, ou le déplace s'il existe déjà
local lastSet = {}
local undoStack = {}   -- src -> { { kind, owner, key, prev = { x, y, z, h } | nil } } (10 dernières poses)
RegisterNetEvent('pb:g:builder:set', function(kind, owner, key, extra, more, rawPoly)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    kind, owner, key = tostring(kind), tostring(owner), tostring(key)
    if not canTarget(kind, owner) then return end
    local st
    for i, s in ipairs(stepsOf(kind, owner)) do if s.key == key then st = s st.i = i end end
    if not st then return end
    more = more == true
    if more and not canMore(kind, st) then return end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0) then G.Notify(src, { type = 'error', title = 'Builder', text = 'Position illisible.' }) return end
    local pos = { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped) or 0.0 }
    -- zone tracée coin par coin : le point se place au centre du contour
    local poly, polyRadius
    if kind == 'drug' and extra == 'poly' then
        local center, r
        poly, center, r = G.Crime.CleanPoly(rawPoly)
        if not poly then G.Notify(src, { type = 'error', title = 'Builder', text = tostring(center) }) sendPoints(src, kind, owner, st.i) return end
        if math.sqrt((center.x - c.x) ^ 2 + (center.y - c.y) ^ 2) > 320.0 then return end
        pos.x, pos.y, pos.z, polyRadius = center.x, center.y, center.z, r
    end
    local at = not more and not st.add and not st.ext and locate(kind, owner, st) or nil
    local prevPos = at and { x = at.x, y = at.y, z = at.z, h = 0.0 } or nil
    -- sortie et gardien d'un garage : des colonnes de la ligne du garage (rien à créer)
    local isNpc = GAR[st.type] and GAR[st.type][3] == 'npc'
    local gk = (st.type == 'garage_exit' or st.type == 'garage_npc') and owner or (isNpc and (garOf(st.type, owner) or {}).id)
    if not at and isNpc and not gk then G.Notify(src, { type = 'error', title = 'Builder', text = "Pose d'abord le garage (rangement)." }) sendPoints(src, kind, owner, st.i) return end
    if not at and gk then at = { ref = gk } end
    local ok, msg
    if at then
        ok = move(kind, owner, st, at, pos)
        msg = ok and (st.name .. ' déplacé ici.') or 'Déplacement impossible.'
    else
        local pt = Place.types[st.type]
        if not pt then return end
        local preset = ''
        if GAR[st.type] and GAR[st.type][3] == 'out' then
            local g = garOf(st.type, owner)
            if not g then G.Notify(src, { type = 'error', title = 'Builder', text = 'Pose d\'abord le garage (rangement).' }) sendPoints(src, kind, owner, st.i) return end
            preset = g.id
        elseif kind == 'drug' then preset = owner
        elseif kind == 'ext' or st.add or st.ext then preset = clean(extra, 40) end
        local name = kind == 'drug' and (st.name .. ' : ' .. (G.Crime.DRUGS[owner].label)) or st.name
        ok, msg = Place.CreateAt(src, pt, name, (kind == 'gang' or kind == 'biz') and owner or '', preset)
        if ok then G.PointNpc.OfferNew(src, pt, Place.TakeCreated(src)) end
        if ok and msg == '__silent' then return end
        if ok then msg = st.name .. (more and ' : un autre posé ici.' or ' placé ici.') end
    end
    -- récolte, labo, vente : point (E à 2,5 m) ou zone (E partout dans le rayon choisi)
    if ok and kind == 'drug' then
        local mode, rr = tostring(extra or ''):match('^(%a+):?(%d*)$')
        if mode == 'point' or mode == 'zone' or (mode == 'poly' and poly) then
            local radius = polyRadius or (mode == 'zone' and math.max(4, math.min(50, tonumber(rr) or 8)) or 2.5)
            local list = cfgList('crime', 'chain')
            for i = #list, 1, -1 do
                local r = list[i]
                if (at and r.id == at.ref) or (not at and r.drug == owner and r.kind == st.type:sub(6)) then
                    r.radius = radius
                    if poly then r.x, r.y, r.z = pos.x, pos.y, pos.z end
                    G.Crime.SetPoly(r.id, poly)
                    break
                end
            end
            PB.Cfg.Set('crime', 'chain', list, 0, 'Builder : point ou zone')
            G.PushConfig()
            msg = st.name .. (poly and (' : zone de ' .. #poly .. ' coins posée.') or (mode == 'zone' and (' : zone de ' .. radius .. ' m posée ici.') or ' : point posé ici.'))
        end
    end
    PB.Audit.Log('config', ok and 'builder.set' or 'builder.fail', src, kind .. ':' .. owner, nil, { point = st.key, moved = at ~= nil })
    if ok and not more and not st.add and not st.ext then
        undoStack[src] = undoStack[src] or {}
        table.insert(undoStack[src], { kind = kind, owner = owner, key = st.key, prev = prevPos })
        if #undoStack[src] > 10 then table.remove(undoStack[src], 1) end
    end
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Builder', text = tostring(msg or '') })
    sendPoints(src, kind, owner, st.i)
end)
AddEventHandler('playerDropped', function() lastSet[source] = nil undoStack[source] = nil end)

-- Ctrl+Z : annule la dernière pose (point créé -> supprimé ; point déplacé -> remis à son ancienne place)
RegisterNetEvent('pb:g:builder:undo', function()
    local src = source
    if not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    local u = undoStack[src] and table.remove(undoStack[src])
    if not u then G.Notify(src, { type = 'warn', title = 'Builder', text = 'Rien à annuler.' }) return end
    local st
    for i, s in ipairs(stepsOf(u.kind, u.owner)) do if s.key == u.key then st = s st.i = i end end
    local at = st and locate(u.kind, u.owner, st)
    local ok = false
    if st and at then
        if u.prev then ok = move(u.kind, u.owner, st, at, u.prev) else ok = remove(u.kind, u.owner, st, at) end
    end
    PB.Audit.Log('config', 'builder.undo', src, u.kind .. ':' .. u.owner, nil, { point = u.key })
    G.Notify(src, { type = ok and 'success' or 'warn', title = 'Builder', text = ok and ((st and st.name or 'Point') .. (u.prev and ' remis à sa place.' or ' retiré.')) or 'Impossible d\'annuler ce point.' })
    sendPoints(src, u.kind, u.owner, st and st.i)
end)

-- Icône du siège / QG sur la carte (à la pose ou après) : numéro et couleur de blip GTA
RegisterNetEvent('pb:g:builder:blip', function(kind, owner, sprite, color)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    kind, owner = tostring(kind), tostring(owner)
    if (kind ~= 'biz' and kind ~= 'gang') or not canTarget(kind, owner) then return end
    sprite, color = math.floor(tonumber(sprite) or -1), math.floor(tonumber(color) or -1)
    if sprite < 0 or sprite > 965 or color < 0 or color > 85 then return end
    DB.exec("UPDATE pb_points SET sprite = ?, bcolor = ? WHERE owner_kind = ? AND owner = ? AND kind = 'hq'", { sprite, color, kind, owner })
    if kind == 'biz' then DB.exec('UPDATE pb_biz SET blip = ?, bcolor = ? WHERE id = ?', { sprite, color, owner }) end
    G.Points.PushAll()
    G.Notify(src, { type = 'success', title = 'Builder', text = sprite == 0 and 'Icône retirée de la carte.' or ('Icône %d (couleur %d) appliquée.'):format(sprite, color) })
    sendPoints(src, kind, owner)
end)

-- Patron de l'entreprise / chef du groupe : un joueur connecté, choisi à la fin de la pose des points
-- Véhicules de l'entreprise (Builder) : tout le catalogue du jeu par catégorie ; les véhicules ajoutés sont des véhicules de service
local function sendFleet(src, bid)
    local b = G.Biz.Get(bid)
    if not b then return end
    local fleet = {}
    for _, v in ipairs(G.Garage.OfBiz(bid)) do fleet[#fleet + 1] = { plate = v.plate, label = v.label, state = v.state } end
    local by, order = {}, {}
    for _, c in ipairs(G.VehCat and G.VehCat.Classes() or {}) do by[c.id] = {} order[#order + 1] = c.id end
    for _, v in ipairs(G.VehCat and G.VehCat.Effective() or {}) do if by[v.class] then local l = by[v.class] l[#l + 1] = { v.model, v.label } end end
    local classes = {}
    for _, id in ipairs(order) do if #by[id] > 0 then classes[#classes + 1] = { id = id, items = by[id] } end end
    TriggerClientEvent('pb:g:builder:fleet', src, PB.Json({ biz = bid, label = b.label, fleet = fleet, classes = classes }))
end
RegisterNetEvent('pb:g:builder:fleet', function(bid)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    sendFleet(src, tostring(bid))
end)
RegisterNetEvent('pb:g:builder:fleetadd', function(bid, model)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    bid = tostring(bid)
    local v = G.VehCat and G.VehCat.Find(tostring(model or ''))
    if not v then G.Notify(src, { type = 'error', title = 'Builder', text = 'Modèle inconnu.' }) return end
    local ok, r = G.Garage.AddFleet(bid, v.model, v.label)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Builder', text = ok and (v.label .. " ajouté aux véhicules de l'entreprise (plaque " .. r .. ').') or r })
    if ok then PB.Audit.Log('config', 'builder.fleet.add', src, bid, nil, { model = v.model, plate = r }) end
    sendFleet(src, bid)
end)
RegisterNetEvent('pb:g:builder:fleetdel', function(bid, plate)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    bid = tostring(bid)
    local ok, err = G.Garage.RemoveFleet(bid, plate)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Builder', text = ok and 'Véhicule retiré.' or err })
    if ok then PB.Audit.Log('config', 'builder.fleet.del', src, bid, nil, { plate = plate }) end
    sendFleet(src, bid)
end)

RegisterNetEvent('pb:g:builder:boss', function(kind, owner, target)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    kind, owner, target = tostring(kind), tostring(owner), tonumber(target)
    if not target or not G.Get(target) or not canTarget(kind, owner) then return end
    local ok, err
    if kind == 'biz' then
        local top
        for _, g in ipairs(G.Biz.Grades(owner)) do if PB.ToBool(g.boss) and (not top or g.grade > top) then top = g.grade end end
        if not top then for _, g in ipairs(G.Biz.Grades(owner)) do if not top or g.grade > top then top = g.grade end end end
        if not top then G.Notify(src, { type = 'error', title = 'Builder', text = "Cette entreprise n'a aucun grade." }) return end
        ok, err = G.Biz.SetJob(target, owner, top, 'Builder')
    elseif kind == 'gang' then
        ok, err = G.Tags.SetGang(target, owner)
        if ok ~= false and G.Flags and G.Flags.SetBoss then ok, err = G.Flags.SetBoss(owner, target) end
    else return end
    local name = (G.Identity(target) or {}).firstname or GetPlayerName(target) or ('#' .. target)
    PB.Audit.Log('config', 'builder.boss', src, kind .. ':' .. owner, nil, { joueur = name })
    G.Notify(src, { type = ok ~= false and 'success' or 'error', title = 'Builder', text = ok ~= false and (name .. (kind == 'biz' and ' est le patron.' or ' est le chef.')) or tostring(err or 'Impossible.') })
    if ok ~= false then G.Notify(target, { type = 'success', title = select(1, targetLabel(kind, owner)) or 'Builder', text = kind == 'biz' and 'Tu es nommé patron de cette entreprise.' or 'Tu es nommé chef de ce groupe.' }) end
    sendPoints(src, kind, owner)
end)

-- Supprimer un point (key) ou tous les points d'une cible (key = '*')
RegisterNetEvent('pb:g:builder:del', function(kind, owner, key)
    local src = source
    if not P.Has(src, 'carte.delete') and not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    kind, owner, key = tostring(kind), tostring(owner), tostring(key)
    if not canTarget(kind, owner) then return end
    if kind == 'ext' and not key:match('^ex:') then return end
    local n = 0
    if key:match('^%a%a:') then
        if removeRaw(kind, owner, key, src) then n = 1 end
        G.PushConfig() if G.Points and G.Points.PushAll then G.Points.PushAll() end
        PB.Audit.Log('config', 'builder.delete', src, kind .. ':' .. owner, nil, { point = key })
        G.Notify(src, { type = n > 0 and 'success' or 'warn', title = 'Builder', text = n > 0 and 'Point supprimé.' or 'Point introuvable.' })
        sendPoints(src, kind, owner)
        return
    end
    if key == '*' then
        for _, p in ipairs(allPoints(kind, owner, src)) do if removeRaw(kind, owner, p.key, src) then n = n + 1 end end
    end
    -- plusieurs passes : un même type peut avoir plusieurs points (ex. deux coffres), locate() renvoie le premier à chaque fois
    for _ = 1, 20 do
        local did = false
        for _, st in ipairs(stepsOf(kind, owner)) do
            if not st.add and (key == '*' or st.key == key) then
                local at = locate(kind, owner, st)
                if at and remove(kind, owner, st, at) then n = n + 1 did = true end
            end
        end
        if not did or key ~= '*' then break end
    end
    PB.Audit.Log('config', 'builder.delete', src, kind .. ':' .. owner, nil, { point = key, count = n })
    G.Notify(src, { type = n > 0 and 'success' or 'warn', title = 'Builder', text = n > 0 and (key == '*' and (n .. ' point(s) supprimé(s).') or 'Point supprimé.') or 'Rien à supprimer.' })
    sendPoints(src, kind, owner)
end)


-- Dupliquer un point (copie à ta position) et déplacer TOUS les points d'une cible d'un coup ----------------------------------------------------
local RAW_TABLE = { pt = 'pb_points', st = 'pb_inv_stashes', sh = 'pb_shops', ga = 'pb_garages' }
local RAW_AUTO = { pt = true, sh = true }   -- identifiant numérique automatique ; sinon on en fabrique un
local function rawRow(t, id) local tb = RAW_TABLE[t] return tb and DB.one('SELECT * FROM ' .. tb .. ' WHERE id = ?', { RAW_AUTO[t] and tonumber(id) or id }) or nil end
local function insertRow(tb, row)
    local cols, qs, vals = {}, {}, {}
    for k, v in pairs(row) do cols[#cols + 1] = k qs[#qs + 1] = '?' vals[#vals + 1] = v end
    return DB.insert(('INSERT INTO %s (%s) VALUES (%s)'):format(tb, table.concat(cols, ', '), table.concat(qs, ', ')), vals)
end
local function playerPos(src)
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0) then return nil end
    return { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped) or 0.0 }
end
local function ownsRaw(kind, owner, key, src) for _, p in ipairs(allPoints(kind, owner, src)) do if p.key == key then return p end end end

function G.BuilderDuplicate(src, kind, owner, key)
    local t, id = tostring(key):match('^(%a%a):(.+)$')
    if not t or not RAW_TABLE[t] then return false, "Ce point ne peut pas être dupliqué (il appartient à une autre ressource)." end
    if not ownsRaw(kind, owner, key, src) then return false, 'Point introuvable.' end
    local row = rawRow(t, id)
    local pos = playerPos(src)
    if not row or not pos then return false, 'Position illisible.' end
    if RAW_AUTO[t] then row.id = nil else row.id = (tostring(row.id):sub(1, 26) .. '_' .. ('%04x'):format(math.random(0, 0xffff))) end
    row.x, row.y, row.z = f(pos.x), f(pos.y), f(pos.z)
    if row.h ~= nil then row.h = f(pos.h) end
    if t == 'ga' then row.sx, row.sy, row.sz = 0.0, 0.0, 0.0 end   -- la sortie du nouveau garage se pose ensuite
    insertRow(RAW_TABLE[t], row)
    if t == 'pt' and G.Points.Reload then G.Points.Reload() end
    G.PushConfig() if G.Points and G.Points.PushAll then G.Points.PushAll() end
    return true, t == 'st' and 'Coffre dupliqué ici (vide).' or t == 'ga' and 'Garage dupliqué ici : pose sa sortie de véhicules.' or 'Point dupliqué ici.'
end

-- Déplace toute la cible : le point choisi arrive à ta position, tous les autres suivent avec le même décalage
function G.BuilderShift(src, kind, owner, key)
    local ref = ownsRaw(kind, owner, key, src)
    local pos = playerPos(src)
    if not ref or not ref.x or not pos then return false, 'Point de référence introuvable.' end
    local dx, dy, dz = pos.x - ref.x, pos.y - ref.y, pos.z - (ref.z or pos.z)
    local n, skipped = 0, 0
    for _, p in ipairs(allPoints(kind, owner, src)) do
        local t, id = p.key:match('^(%a%a):(.+)$')
        if RAW_TABLE[t] then
            local q = RAW_AUTO[t] and tonumber(id) or id
            DB.exec(('UPDATE %s SET x = x + ?, y = y + ?, z = z + ? WHERE id = ?'):format(RAW_TABLE[t]), { dx, dy, dz, q })
            if t == 'ga' then DB.exec('UPDATE pb_garages SET sx = sx + ?, sy = sy + ?, sz = sz + ? WHERE id = ? AND sx <> 0', { dx, dy, dz, q }) end
            n = n + 1
        else skipped = skipped + 1 end
    end
    if kind == 'biz' then DB.exec('UPDATE pb_biz SET hx = hx + ?, hy = hy + ?, hz = hz + ? WHERE id = ? AND hx <> 0', { dx, dy, dz, owner }) end
    if G.Points.Reload then G.Points.Reload() end
    G.PushConfig() if G.Points and G.Points.PushAll then G.Points.PushAll() end
    return true, ('%d point(s) déplacé(s) de %d m.%s'):format(n, math.floor(math.sqrt(dx * dx + dy * dy) + 0.5), skipped > 0 and (' ' .. skipped .. ' point(s) d\'une autre ressource à reposer à la main.') or '')
end

RegisterNetEvent('pb:g:builder:dup', function(kind, owner, key)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    kind, owner = tostring(kind), tostring(owner)
    if not canTarget(kind, owner) then return end
    local ok, msg = G.BuilderDuplicate(src, kind, owner, tostring(key))
    PB.Audit.Log('config', 'builder.dup', src, kind .. ':' .. owner, nil, { point = tostring(key), ok = ok })
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Builder', text = msg })
    sendPoints(src, kind, owner)
end)
RegisterNetEvent('pb:g:builder:shift', function(kind, owner, key)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    local t0 = GetGameTimer()
    if lastSet[src] and t0 - lastSet[src] < 600 then return end
    lastSet[src] = t0
    kind, owner = tostring(kind), tostring(owner)
    if not canTarget(kind, owner) then return end
    local ok, msg = G.BuilderShift(src, kind, owner, tostring(key))
    PB.Audit.Log('config', 'builder.shift', src, kind .. ':' .. owner, nil, { ref = tostring(key), ok = ok })
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Builder', text = msg })
    sendPoints(src, kind, owner)
end)

-- Aller voir un point (téléportation du staff, puis le client vérifie le sol sous le point)
RegisterNetEvent('pb:g:builder:goto', function(kind, owner, key)
    local src = source
    if not P.Has(src, 'carte.place') then return end
    kind, owner = tostring(kind), tostring(owner)
    if not canTarget(kind, owner) then return end
    local p = ownsRaw(kind, owner, tostring(key), src)
    if not p or not p.x then G.Notify(src, { type = 'error', title = 'Builder', text = 'Point introuvable.' }) return end
    TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = p.x, y = p.y, z = p.z }))
    TriggerClientEvent('pb:g:points:check', src, PB.Json({ x = p.x, y = p.y, z = p.z, label = p.label }))
end)

-- (v1.2.43) Builder › Existant : aller sur un point isolé déjà posé, ou le supprimer
local function placedRow(p)
    local ext = tostring(p.type or ''):match('^ext:([%w_]+)$')
    if ext then
        local e = Place.ext and Place.ext[ext]
        if not e or not e.cb or not e.listable then return nil end
        local okl, rows = pcall(e.cb, 0, '__list', '')
        for _, r in ipairs(okl and type(rows) == 'table' and rows or {}) do
            if type(r) == 'table' and tostring(r.key) == tostring(p.id) then
                return { id = r.key, label = r.label, x = r.x, y = r.y, z = r.z }, { list = true, remove = function(id, src) local okd, res = pcall(e.cb, src, '__delete', id) return okd and res ~= false end }
            end
        end
        return nil
    end
    local def = Place.types[tostring(p.type or '')]
    if not def or not def.list or def.needs then return nil end
    local ok, rows = pcall(def.list)
    for _, r in ipairs(ok and rows or {}) do if tostring(r.id) == tostring(p.id) then return r, def end end
    return nil
end
S.Def('b_tp', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local r = placedRow(p)
    if not r or not tonumber(r.x) then return false, 'Point introuvable.' end
    TriggerClientEvent('pb:g:staff:fx', src, 'tpxy', PB.Json({ x = tonumber(r.x), y = tonumber(r.y), z = tonumber(r.z) }))
    return true
end })
S.Def('b_npc', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local r = placedRow(p)
    if not r or not tonumber(r.x) then return false, 'Point introuvable.' end
    return G.PointNpc.OfferExisting(src, tostring(p.type), r)
end })
S.Def('b_remove', 'carte.delete', { noduty = true, run = function(src, _, p)
    local r, def = placedRow(p)
    if not r then return false, 'Point introuvable.' end
    local okc, res, why = false, nil, nil
    if def.remove then okc, res, why = pcall(def.remove, tostring(p.id), src) end
    if not okc or res == false then return false, (type(why) == 'string' and why) or 'Suppression impossible.' end
    PB.Audit.Log('config', 'builder.remove', src, tostring(p.type), nil, { id = tostring(p.id), label = r.label })
    G.PushConfig()
    if G.Points and G.Points.PushAll then G.Points.PushAll() end
    return true, ('« %s » supprimé.'):format(tostring(r.label))
end, log = true })

-- (patch 136) Territoire dessiné : les coins posés au clavier, puis le nom et l'objet offert toutes les 5 h
S.Def('b_terr', 'carte.place', { noduty = true, run = function(src, _, p)
    if not (G.Territories and G.Territories.CreateDrawn) then return false, 'Territoires indisponibles.' end
    return G.Territories.CreateDrawn(src, p.label, p.poly, p.item, p.qty, p.hours)
end })
S.Def('b_terrreward', 'carte.place', { noduty = true, run = function(src, _, p)
    if not (G.Territories and G.Territories.SetReward) then return false, 'Territoires indisponibles.' end
    return G.Territories.SetReward(src, tostring(p.id or ''), p.item, p.qty, p.hours)
end, log = true })
S.Def('b_terrdel', 'carte.delete', { noduty = true, run = function(src, _, p)
    if not (G.Territories and G.Territories.Delete) then return false, 'Territoires indisponibles.' end
    local ok = G.Territories.Delete(tostring(p.id or ''))
    return ok, ok and 'Zone supprimée.' or 'Zone introuvable.'
end, log = true })

-- Groupe illégal : créé, puis la liste de ses points s'ouvre
-- Liste complète des véhicules pour le pack sur mesure : envoyée à la demande (elle est longue, inutile de la joindre à chaque mise à jour du menu)
RegisterNetEvent('pb:g:builder:packvehs', function()
    local src = source
    if not P.Has(src, 'carte.place') or not P.Has(src, 'staff.items') then return end
    TriggerClientEvent('pb:g:builder:packvehs', src, PB.Json(G.PackCustom.VehRows()))
end)
-- Pack sur mesure donné à une entreprise ou une organisation déjà créée
S.Def('b_packgive', 'carte.place', { noduty = true, run = function(src, _, p)
    local pack, e = G.PackCustom.ForStaff(src, p.custom)
    if not pack then return false, e end
    local sum, err
    if p.kind == 'gang' then sum, err = G.Orgs.Starter(tostring(p.owner or ''), true, pack)
    elseif p.kind == 'biz' then sum, err = G.Biz.Starter(tostring(p.owner or ''), true, pack) G.PushConfig()
    else return false, 'Cible inconnue.' end
    if not sum then return false, err end
    return true, G.PackCustom.Text(sum)
end, log = true })
S.Def('b_group', 'carte.place', { noduty = true, run = function(src, _, p)
    local custom, customErr
    if type(p.custom) == 'table' then
        custom, customErr = G.PackCustom.ForStaff(src, p.custom)
        if not custom then return false, customErr end
    end
    local t = GT[tostring(p.gtype or '')] or GT.gang
    local label = clean(p.label, 24)
    if #label < 2 then return false, 'Donne un nom (2 caractères au moins).' end
    local color = tostring(p.color or ''):match('^#%x%x%x%x%x%x$') or t.color
    local id, msg = G.Orgs.Create({ label = label, color = color }, staffName(src))
    if not id then return false, msg end
    DB.exec("UPDATE pb_org_groups SET otype = ? WHERE kind = 'gang' AND name = ?", { t.id, id })
    if G.Tags.RefreshNative then G.Tags.RefreshNative() end
    if G.Tags.Push then pcall(G.Tags.Push, true) end
    local extra = ''
    local packN = math.floor(tonumber(p.pack) or 0)   -- 0 = aucun pack (le menu envoie toujours le choix)
    if custom then
        local sum = G.Orgs.Starter(id, false, custom)
        if sum then extra = ' ' .. G.PackCustom.Text(sum) end
    elseif packN >= 1 and packN <= 3 and PB.Cfg.Get('orgs', 'auto_starter', true) ~= false then
        local sum = G.Orgs.Starter(id, false, packN)
        if sum then extra = (' %s donné : %d objets au coffre, %s en caisse, %d véhicule(s) au garage.'):format(sum.pack, sum.items, PB.Money(sum.cash), #sum.cars) end
    end
    sendPoints(src, 'gang', id)
    return true, t.label .. ' « ' .. label .. ' » créé(e).' .. extra .. ' Pose ses points un par un.'
end })

-- Points d'une cible existante (groupe, entreprise, drogue, ressource)
S.Def('b_pack', 'carte.place', { noduty = true, quiet = true, run = function(src, _, p)
    local kind = tostring(p.kind or '')
    local ok, e = sendPoints(src, kind == 'gang' and 'gang' or (kind == 'drug' and 'drug' or (kind == 'ext' and 'ext' or (kind == 'garage' and 'garage' or 'biz'))), tostring(p.owner or ''))
    if not ok then return false, e end
    return true
end })

-- Nouveau garage (voitures, hangar aérien, port) ou fourrière : l'entrée est posée à ta position, puis la liste s'ouvre
-- pour poser la sortie (dans le bon sens) et le gardien
S.Def('b_garage', 'carte.place', { noduty = true, run = function(src, _, p)
    local kind = p.kind == 'impound' and 'impound' or 'public'
    local vt = ({ car = 'car', air = 'air', boat = 'boat' })[tostring(p.vtype or '')] or 'car'
    local label = clean(p.name, 48)
    if #label < 2 then label = (kind == 'impound' and 'Fourrière' or ({ car = 'Garage', air = 'Hangar', boat = 'Port' })[vt]) end
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c or (c.x == 0 and c.y == 0) then return false, 'Position illisible.' end
    local h = math.rad(GetEntityHeading(ped) or 0.0)
    local id = ('gar_%d%d'):format(os.time() % 1000000, math.random(10, 99))
    local ahead = vt == 'car' and 4.0 or 8.0
    DB.exec("INSERT INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh, biz, enabled, vtype) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', 1, ?)",
        { id, label, kind, f(c.x), f(c.y), f(c.z), f(c.x - math.sin(h) * ahead), f(c.y + math.cos(h) * ahead), f(c.z), f(GetEntityHeading(ped) or 0.0), vt })
    PB.Audit.Log('config', 'builder.garage', src, id, nil, { label = label, kind = kind, vtype = vt })
    G.PushConfig()
    sendPoints(src, 'garage', id, 2)
    return true, label .. ' créé : pose maintenant la sortie des véhicules et le gardien.'
end })

-- Entreprise du catalogue : créée si besoin (grades et métier prêts), puis la liste de ses points s'ouvre
S.Def('b_biz', 'carte.place', { noduty = true, run = function(src, _, p)
    local t = G.BizCat and G.BizCat.ByKey and G.BizCat.ByKey[tostring(p.key or '')]
    if not t then return false, 'Entreprise inconnue.' end
    local made = false
    if not G.Biz.Get(t.key) then
        local copy = {}
        for k, v in pairs(t) do copy[k] = v end
        copy.pos = nil   -- le siège sera posé en jeu
        local ok, e = G.BizCat.Create(copy, {})
        if not ok then return false, 'Création impossible : ' .. tostring(e) end
        made = true
    end
    local extra = ''
    if made then
        local sum = G.Biz.Starter(t.key, false, tonumber(PB.Cfg.Get('biz', 'pack_default', 2)) or 0)
        if sum then extra = ' ' .. G.Biz.StarterText(sum) end
    end
    sendPoints(src, 'biz', t.key)
    return true, made and ('« ' .. t.label .. ' » créée. Choisis ses points un par un.' .. extra) or nil
end, quiet = true })

-- Entreprise sur mesure : nom libre, fonctionnement d'un modèle (mécano, café, bar…), icône choisie parmi celles du jeu
S.Def('b_bizcustom', 'carte.place', { noduty = true, run = function(src, _, p)
    local custom, customErr
    if type(p.custom) == 'table' then
        custom, customErr = G.PackCustom.ForStaff(src, p.custom)
        if not custom then return false, customErr end
    end
    local t = G.BizCat and G.BizCat.ByKey[tostring(p.key or '')]
    if not t then return false, "Choisis le type d'entreprise." end
    local label = clean(p.label, 48)
    if #label < 2 then return false, "Donne un nom à l'entreprise." end
    local base = label:lower():gsub('[àâä]', 'a'):gsub('[éèêë]', 'e'):gsub('[îï]', 'i'):gsub('[ôö]', 'o'):gsub('[ùûü]', 'u'):gsub('ç', 'c'):gsub('[^a-z0-9]+', '_'):gsub('^_+', ''):gsub('_+$', ''):sub(1, 28)
    if base == '' then base = t.key end
    local id, n = base, 1
    while G.Biz.Get(id) do n = n + 1 id = base .. '_' .. n end
    local copy = {}
    for k, v in pairs(t) do copy[k] = v end
    local ok, e = G.BizCat.Create(copy, { id = id, label = label, nopos = true, blip = tonumber(p.blip), bcolor = tonumber(p.bcolor) })
    if not ok then return false, 'Création impossible : ' .. tostring(e) end
    local extra = ''
    if custom then
        local sum = G.Biz.Starter(id, false, custom)
        if sum then extra = ' ' .. G.PackCustom.Text(sum) end
    elseif (tonumber(p.pack) or 0) > 0 then
        local sum = G.Biz.Starter(id, false, p.pack)
        if sum then extra = ' ' .. G.Biz.StarterText(sum) end
    end
    G.PushConfig()
    sendPoints(src, 'biz', id)
    return true, ('« %s » créée (fonctionne comme : %s). Pose ses points un par un.'):format(label, t.label) .. extra
end })

-- Pack de départ d'une entreprise déjà créée (une seule fois ; le panel permet d'en redonner)
S.Def('b_bizstart', 'carte.place', { noduty = true, run = function(src, _, p)
    local sum, err = G.Biz.Starter(tostring(p.owner or ''), false, p.pack)
    if not sum then return false, err end
    G.PushConfig()
    return true, G.Biz.StarterText(sum)
end, log = true })

-- Drogue : objets créés, puis la liste récolte / labo / vente s'ouvre
S.Def('b_drug', 'carte.place', { noduty = true, run = function(src, _, p)
    local key = tostring(p.drug or '')
    local d = G.Crime.EnsureDrug(key)
    if not d then return false, 'Drogue inconnue.' end
    sendPoints(src, 'drug', key)
    return true, d.label .. ' : objets prêts. Choisis la récolte, le labo et la vente.'
end })

-- Supprimer le point le plus proche (tous types confondus, 8 m maximum)
S.Def('b_delete', 'carte.delete', { noduty = true, run = function(src, _, p)
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if not c then return false, 'Position illisible.' end
    local best, bd, bt
    for _, id in ipairs(Place.order) do
        local t = Place.types[id]
        if t.list and t.remove then
            for _, r in ipairs(t.list() or {}) do
                local x, y = tonumber(r.x), tonumber(r.y)
                if x and y then
                    local d = math.sqrt((c.x - x) ^ 2 + (c.y - y) ^ 2)
                    if d < 8.0 and (not bd or d < bd) then best, bd, bt = r, d, t end
                end
            end
        end
    end
    if not best then return false, 'Aucun point à moins de 8 m.' end
    if p.confirm ~= true then return false, ('Le plus proche : %s « %s » à %.1f m. Choisis « Confirmer la suppression ».'):format(bt.label, tostring(best.label), bd) end
    bt.remove(tostring(best.id))
    PB.Audit.Log('config', 'carte.delete', src, bt.id, nil, { id = best.id, label = best.label })
    return true, bt.label .. ' « ' .. tostring(best.label) .. ' » supprimé.'
end })

PB.SelfTest.Add('builder', function(R)
    R.check(S.ACT.b_place and S.ACT.b_group and S.ACT.b_biz and S.ACT.b_drug and S.ACT.b_pack and S.ACT.b_delete, 'builder', 'actions manquantes')
    R.check(#G.Crime.DRUG_ORDER == 5, 'builder', 'il faut 5 drogues prêtes')
end)
