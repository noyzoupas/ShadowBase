-- Parcours du joueur, de la connexion à la déconnexion : liste blanche, file d'attente, écran d'accueil et règlement,
-- sessions et temps de jeu, annonces de redémarrage. La maintenance reste dans le module « Serveur » (général).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('flow.edit', 'Modifier le parcours de connexion', 'flow', true)
P.Register('flow.whitelist', 'Gérer la liste blanche et les priorités', 'flow', true)
P.Register('flow.bypass', 'Passer devant la file et la liste blanche', 'flow')

PB.Migrate('045_game_flow', 'Parcours serveur : liste blanche, règlement accepté, sessions', {
    [[CREATE TABLE IF NOT EXISTS pb_flow_wl (
        license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', note VARCHAR(80) NOT NULL DEFAULT '', priority INT NOT NULL DEFAULT 0,
        added_at INT NOT NULL DEFAULT 0, added_by VARCHAR(64) NOT NULL DEFAULT '', PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_flow_accept (license VARCHAR(64) NOT NULL, version INT NOT NULL DEFAULT 0, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
    [[CREATE TABLE IF NOT EXISTS pb_flow_sessions (
        id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', joined INT NOT NULL, left_at INT NOT NULL DEFAULT 0, secs INT NOT NULL DEFAULT 0, reason VARCHAR(80) NOT NULL DEFAULT '',
        PRIMARY KEY (id), KEY k_lic (license), KEY k_joined (joined))]],
})

local DEF = {
    whitelist_on = false, whitelist_msg = "Tu n'es pas sur la liste blanche. Candidate sur notre Discord.",
    queue_on = true, max_slots = 0, queue_timeout = 20, queue_card = true, connect_title = 'Bienvenue',
    welcome_on = true, rules_version = 1, welcome_style = 'hero', welcome_hl = 'serveur', welcome_text = '', welcome_bg = '', welcome_blur = true, welcome_rules = true, welcome_title = 'Bienvenue sur le', welcome_sub = "Avant d'entrer, prends une minute pour lire le règlement.",
    welcome_intro = { 'Ce serveur est un serveur de jeu de rôle : tu incarnes un personnage et tu respectes celui des autres.' },
    rules = { 'Reste dans ton rôle : pas de propos hors-jeu (HRP) en public.', "Pas de meurtre sans raison valable (RDM) ni de conduite volontairement dangereuse (VDM).", 'Respecte les autres joueurs et le staff.', 'Aucune triche, aucun abus de bug.' },
    news = { 'Nouvelle économie équilibrée : prix, salaires et amendes réglés pour une progression régulière.' },
    accept_label = "J'accepte et j'entre", decline_label = 'Quitter', decline_msg = 'Tu as refusé le règlement du serveur.', min_read = 5, links = {},
    restart_on = false, restart_times = {}, restart_warn = { '30', '15', '10', '5', '1' }, restart_msg = 'Redémarrage du serveur dans {min} minute(s). Pense à te mettre en sécurité.', restart_kick = false, restart_kick_msg = 'Le serveur redémarre. À tout de suite !',
    leave_msg_on = false,
}
PB.Cfg.Define('flow', DEF)

local Flow = {}
G.Flow = Flow
local function now() return os.time() end
local function cfg(k, d) return PB.Cfg.Get('flow', k, d) end

-- Liste blanche ----------------------------------------------------------------------------------------------------------------------
function Flow.WL(license) return DB.one('SELECT * FROM pb_flow_wl WHERE license = ?', { tostring(license) }) end
local function validLicense(s) s = PB.Trim(tostring(s or '')) if not s:find('^license:%x+$') then s = 'license:' .. s end return s:find('^license:%x+$') and #s <= 64 and s or nil end
-- La liste blanche ne s'applique que si elle est active, non coupée par la convar `set pb_whitelist off` et non vide
-- (une liste blanche vide enfermerait tout le monde dehors, y compris toi).
local wlWarned
function Flow.WLActive()
    if not cfg('whitelist_on', false) then return false end
    if Config and Config.DisableWhitelist then return false end
    if tostring(GetConvar('pb_whitelist', 'on')):lower() == 'off' then return false end
    local n = tonumber(DB.scalar('SELECT COUNT(*) FROM pb_flow_wl')) or 0
    if n == 0 then
        if not wlWarned then wlWarned = true PB.Warn("Liste blanche activée mais vide : elle est ignorée pour ne pas bloquer tout le monde. Ajoute des licences (Parcours › Liste blanche) puis elle s'appliquera.") end
        return false
    end
    return true
end
-- Ne sont jamais bloqués par la liste blanche : propriétaires, membres de l'équipe (n'importe quel grade), porteurs de la permission flow.bypass,
-- et les joueurs ayant l'ACE « pb_panel.owner » ou « command » (admins du server.cfg).
local function bypass(src)
    if P.IsOwner(src) or P.Has(src, 'flow.bypass') then return true end
    local lic = P.GetLicense(src)
    if lic and P.GradeOf and P.GradeOf(lic) then return true end
    if IsPlayerAceAllowed and (IsPlayerAceAllowed(tostring(src), 'command') or IsPlayerAceAllowed(tostring(src), 'pb_panel.owner')) then return true end
    return false
end
exports('IsWhitelisted', function(license) return Flow.WL(validLicense(license) or '') ~= nil end)

function Flow.MaxSlots()
    local n = math.floor(tonumber(cfg('max_slots', 0)) or 0)
    if n > 0 then return n end
    return tonumber(GetConvar('sv_maxclients', '48')) or 48
end

-- File d'attente -----------------------------------------------------------------------------------------------------------------------
local queue, admitted = {}, {}
local stats = { queued = 0, refused = 0, peak = 0, peakDay = os.date('%Y-%m-%d') }
Flow.queue = queue

local function sortQueue() table.sort(queue, function(a, b) if a.prio ~= b.prio then return a.prio > b.prio end return a.t < b.t end) end
local function posOf(src) for i, q in ipairs(queue) do if q.src == src then return i end end end
local function removeQ(src) local i = posOf(src) if i then table.remove(queue, i) end end
local function playerCount()
    local n = #GetPlayers()
    local t = now()
    for s, at in pairs(admitted) do if t - at > 90 then admitted[s] = nil else n = n + 1 end end
    return n
end
function Flow.Free() return Flow.MaxSlots() - playerCount() end

local function card(title, text, wait)
    return {
        type = 'AdaptiveCard', version = '1.3',
        body = { { type = 'TextBlock', size = 'Large', weight = 'Bolder', text = title }, { type = 'TextBlock', wrap = true, text = text }, wait and { type = 'TextBlock', isSubtle = true, wrap = true, text = wait } or nil },
    }
end

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    local lic = P.GetLicense(src)
    local function handover() if G.LoadscreenData and deferrals.handover then pcall(deferrals.handover, G.LoadscreenData()) end end
    print(('[pb_panel] connexion de %s · %s'):format(tostring(name), tostring(lic)))   -- ta licence apparaît ici dans la console
    local ban = G.Staff and G.Staff.BanOf(src)
    if ban then
        if PB.LogRefusal then PB.LogRefusal(src, 'ban', 'Connexion refusée : joueur banni', ('Ban n°%s : %s'):format(tostring(ban.id or '?'), tostring(ban.reason or ''))) end
        deferrals.defer() Wait(0) deferrals.done(G.Staff.BanText(ban)) return
    end   -- banni : refusé avant toute admission
    -- ces messages disent pourquoi personne n'est refusé : le staff passe toujours, et sans jeton du bot l'adhésion n'est pas vérifiée
    if G.DiscordLink and bypass(src) then print(('[pb_panel] Discord : %s passe sans vérification (équipe ou propriétaire).'):format(tostring(name)))
    elseif G.DiscordLink and G.DiscordLink.MemberAsked and G.DiscordLink.MemberAsked() and not G.DiscordLink.MemberReady() then print("[pb_panel] Discord : adhésion NON vérifiée, il manque le jeton du bot ou l'identifiant du serveur (module Discord).") end
    if G.DiscordLink and G.DiscordLink.Blocked(src) and not bypass(src) then   -- (v1.2.46) Discord obligatoire : même en maintenance, avant la file
        stats.refused = stats.refused + 1
        PB.LogRefusal(src, 'discord', 'Discord non ouvert', table.concat(GetPlayerIdentifiers(src) or {}, ', '))
        deferrals.defer() Wait(0) deferrals.done(G.DiscordLink.RefusalText()) return
    end
    if PB.Cfg.Get('general', 'maintenance_on', false) then return end   -- le module Serveur gère la maintenance
    local wl = lic and Flow.WL(lic)
    local byp = bypass(src)
    local needWl = Flow.WLActive() and not byp and not wl
    if cfg('whitelist_on', false) then
        print(('[pb_panel] connexion %s (%s) : liste blanche active=%s · dans la liste=%s · équipe/propriétaire=%s → %s'):format(tostring(name), tostring(lic), tostring(Flow.WLActive()), tostring(wl ~= nil), tostring(byp), needWl and 'REFUSÉ' or 'accepté'))
    end
    -- (v1.2.46) membre du serveur Discord : refus seulement si Discord le dit clairement
    local checked = false
    if not byp and G.DiscordLink and G.DiscordLink.MemberOn() then
        deferrals.defer() Wait(0)
        handover()
        deferrals.update('Vérification de ton compte Discord…')
        checked = true
        if G.DiscordLink.IsMember(src) == false then
            stats.refused = stats.refused + 1
            PB.LogRefusal(src, 'discord', "Pas membre du serveur Discord", table.concat(GetPlayerIdentifiers(src) or {}, ', '))
            deferrals.done(G.DiscordLink.NotMemberText()) return
        end
    end
    if not (needWl or cfg('queue_on', true)) then
        if not checked then deferrals.defer() Wait(0) handover() end
        deferrals.done()
        return
    end
    deferrals.defer()
    Wait(0)
    handover()
    if not lic then PB.LogRefusal(src, 'connexion', 'Identifiant Rockstar introuvable', table.concat(GetPlayerIdentifiers(src) or {}, ', ')) deferrals.done('Identifiant Rockstar introuvable : lance bien le jeu avec Rockstar Games Launcher.') return end
    if needWl then PB.LogRefusal(src, 'liste_blanche', 'Pas dans la liste blanche', 'Licence ' .. tostring(lic)) end
    if needWl then stats.refused = stats.refused + 1 deferrals.done(cfg('whitelist_msg', '') .. '\n\nTa licence : ' .. tostring(lic) .. '\n(à donner au staff pour être ajouté)') return end
    if not cfg('queue_on', true) or Flow.Free() > 0 and #queue == 0 then admitted[src] = now() deferrals.done() return end
    local q = { src = src, lic = lic, prio = byp and 1000000 or math.max(wl and wl.priority or 0, G.Vip and G.Vip.QueuePrio(lic) or 0), t = now() }
    queue[#queue + 1] = q
    sortQueue()
    stats.queued = stats.queued + 1
    local timeout = (cfg('queue_timeout', 20)) * 60
    while true do
        if GetPlayerEndpoint and GetPlayerEndpoint(src) == nil then removeQ(src) return end   -- le joueur a annulé
        local pos = posOf(src)
        if not pos then deferrals.done('Tu as été retiré de la file.') return end
        if pos == 1 and Flow.Free() > 0 then removeQ(src) admitted[src] = now() deferrals.done() return end
        if now() - q.t > timeout then removeQ(src) PB.LogRefusal(src, 'file_attente', "Temps d'attente dépassé", ('%d min dans la file'):format(math.floor((now() - q.t) / 60))) deferrals.done("Temps d'attente dépassé. Réessaie dans quelques minutes.") return end
        local txt = ('Position %d sur %d · attente %d s'):format(pos, #queue, now() - q.t)
        if cfg('queue_card', true) then deferrals.presentCard(card(cfg('connect_title', 'Bienvenue'), 'Le serveur est plein, tu es dans la file d\'attente.', txt), function() end) else deferrals.update(txt) end
        Wait(2000)
    end
end)

-- Filet de sécurité : si une autre ressource a déjà laissé entrer le joueur, Discord est revérifié à l'arrivée
AddEventHandler('playerJoining', function()
    local src = source
    if G.DiscordLink and G.DiscordLink.Blocked(src) and not bypass(src) then
        PB.Drop(src, 'kick', 'discord', G.DiscordLink.RefusalText(), "Discord obligatoire : pas d'identifiant Discord à l'arrivée en jeu.")
    elseif G.DiscordLink and G.DiscordLink.MemberOn() and not bypass(src) and G.DiscordLink.IsMember(src) == false then
        PB.Drop(src, 'kick', 'discord', G.DiscordLink.NotMemberText(), "Pas membre du serveur Discord à l'arrivée en jeu.")
    end
end)

-- Écran d'accueil et règlement ---------------------------------------------------------------------------------------------------------
local pending = {}

function Flow.Accepted(license)
    local r = DB.one('SELECT version FROM pb_flow_accept WHERE license = ?', { license })
    return r ~= nil and r.version >= cfg('rules_version', 1)
end

function Flow.WelcomeData()
    local c = PB.Cfg.All('flow')
    return { style = c.welcome_style, hl = c.welcome_hl, text = c.welcome_text, bg = c.welcome_bg, blur = c.welcome_blur, show_rules = c.welcome_rules, title = c.welcome_title, sub = c.welcome_sub, intro = c.welcome_intro, rules = c.rules, news = c.news, accept = c.accept_label, decline = c.decline_label, min_read = c.min_read, links = c.links,
        version = c.rules_version, brand = PB.Cfg.Get('general', 'server_name', ''), logo = G.MainLogo(), banner = PB.Cfg.Get('general', 'server_banner', ''), color = PB.Cfg.Get('general', 'color_primary', '#dfe2e7') }
end

-- Règlement : affiché APRÈS la création du personnage (ou à l'arrivée d'un joueur qui a déjà son personnage), une fois par version.
-- Renvoie true si l'écran vient d'être envoyé.
function G.ShowWelcome(src)
    if not cfg('welcome_on', true) then return false end
    local lic = P.GetLicense(src)
    if not lic or Flow.Accepted(lic) then pending[src] = nil return false end
    if pending[src] then return true end
    pending[src] = { t = now(), license = lic }
    TriggerClientEvent('pb:g:flow:welcome', src, PB.Json(Flow.WelcomeData()))
    return true
end

RegisterNetEvent('pb:g:flow:accept', function()
    local src = source
    local p = pending[src]
    if not p then return end
    local need = math.max(0, math.floor(tonumber(cfg('min_read', 5)) or 0))
    if now() - p.t < need - 1 then return end   -- le bouton n'est actif qu'après la lecture minimale ; on ne fait pas confiance au client
    DB.exec('INSERT INTO pb_flow_accept (license, version, at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE version = VALUES(version), at = VALUES(at)', { p.license, cfg('rules_version', 1), now() })
    pending[src] = nil
    TriggerClientEvent('pb:g:flow:welcomeClose', src)
end)
RegisterNetEvent('pb:g:flow:decline', function()
    local src = source
    if pending[src] then pending[src] = nil PB.Drop(src, 'kick', 'reglement', cfg('decline_msg', 'Règlement refusé.'), 'Le joueur a cliqué sur « Refuser » le règlement.') end
end)

-- Sessions ---------------------------------------------------------------------------------------------------------------------------
local open = {}   -- src -> id de session
table.insert(G.beginHooks, function(src, p)
    if PB.ToBool(p.row.created) then SetTimeout(1500, function() G.ShowWelcome(src) end) end
    if open[src] then return end
    local name = GetPlayerName and GetPlayerName(src) or ('Joueur ' .. src)
    local id = DB.insert('INSERT INTO pb_flow_sessions (license, name, joined) VALUES (?, ?, ?)', { p.license, tostring(name):sub(1, 64), now() })
    open[src] = { id = id, t = now() }
    local n = #GetPlayers()
    local day = os.date('%Y-%m-%d')
    if day ~= stats.peakDay then stats.peak, stats.peakDay = 0, day end
    if n > stats.peak then stats.peak = n end
end)

local function closeSession(src, reason)
    local s = open[src]
    if not s then return end
    open[src] = nil
    local t = now()
    DB.exec('UPDATE pb_flow_sessions SET left_at = ?, secs = ?, reason = ? WHERE id = ?', { t, math.max(0, t - s.t), tostring(reason or ''):sub(1, 80), s.id })
end

-- à l'arrivée en jeu l'identifiant provisoire de la connexion est remplacé : on libère le slot réservé
AddEventHandler('playerJoining', function(oldId) admitted[tonumber(oldId) or -1] = nil admitted[source] = nil end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    pending[src] = nil admitted[src] = nil removeQ(src)
    closeSession(src, reason)
end)
-- sessions restées ouvertes après un arrêt brutal : on les clôt à leur ouverture
DB.exec('UPDATE pb_flow_sessions SET left_at = joined, reason = ? WHERE left_at = 0', { 'serveur arrêté' })

function Flow.PlaytimeHours(license)
    local r = DB.one('SELECT COALESCE(SUM(secs), 0) AS s FROM pb_flow_sessions WHERE license = ?', { tostring(license) })
    local extra = 0
    for src, s in pairs(open) do local pl = G.Get(src) if pl and pl.license == license then extra = now() - s.t end end
    return ((r and r.s or 0) + extra) / 3600
end
exports('GetPlaytime', function(license) return Flow.PlaytimeHours(license) end)

-- Redémarrages -------------------------------------------------------------------------------------------------------------------------
local announced = {}
local function toMinutes(hhmm) local h, m = tostring(hhmm):match('^(%d%d?):(%d%d)$') if not h then return nil end h, m = tonumber(h), tonumber(m) if h > 23 or m > 59 then return nil end return h * 60 + m end

local function tellAll(text)
    for _, id in ipairs(GetPlayers()) do G.Notify(tonumber(id), { type = 'warn', title = 'Redémarrage', text = text, duration = 12000 }) end
    if PB.Announce then PB.Announce(text, 'chat') end
end

-- Le module Monitoring a son propre redémarrage (compte à rebours, sauvegarde, arrêt) : quand il couvre la même heure, ou qu'un compte
-- à rebours est en cours, on n'annonce rien ici (sinon les joueurs reçoivent chaque annonce en double)
local function monitorHandles(hhmm)
    if PB.Restart and PB.Restart.State and PB.Restart.State() then return true end
    if not PB.Cfg.Get('monitor', 'restart_enabled', false) then return false end
    for _, t in ipairs(PB.Cfg.Get('monitor', 'restart_times', {}) or {}) do if t == hhmm then return true end end
    return false
end
Flow.MonitorHandles = monitorHandles
-- nowMin : minutes écoulées depuis minuit (injectable pour les tests). Renvoie le nombre d'annonces faites.
function Flow.RestartCheck(nowMin, day)
    if not cfg('restart_on', false) then return 0 end
    day = day or os.date('%Y-%m-%d')
    local sent = 0
    local warns = cfg('restart_warn', {})
    for _, hhmm in ipairs(cfg('restart_times', {})) do
        local at = toMinutes(hhmm)
        if at and not monitorHandles(hhmm) then
            local left = (at - nowMin) % 1440
            for _, w in ipairs(warns) do
                local key = day .. hhmm .. ':' .. w
                if left == tonumber(w) and not announced[key] then
                    announced[key] = true
                    tellAll((cfg('restart_msg', ''):gsub('{min}', tostring(w))))
                    sent = sent + 1
                end
            end
            local zk = day .. hhmm .. ':0'
            if left == 0 and not announced[zk] then
                announced[zk] = true
                G.SaveAll()
                if cfg('restart_kick', false) then
                    for _, id in ipairs(GetPlayers()) do PB.Drop(tonumber(id), 'kick', 'redemarrage', cfg('restart_kick_msg', 'Redémarrage.'), 'Redémarrage programmé (parcours serveur)') end
                end
                sent = sent + 1
            end
        end
    end
    return sent
end
CreateThread(function()
    Wait(math.random(0, 20000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(20000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if PB.IsReady then local t = os.date('*t') Flow.RestartCheck(t.hour * 60 + t.min) end
        end)
        if not ok then PB.Warn('flow', 'boucle : ' .. tostring(err)) end
    end
end)
-- txAdmin prévient lui-même avant ses redémarrages planifiés : on relaie aux joueurs et on sauvegarde avant l'arrêt
AddEventHandler('txAdmin:events:scheduledRestart', function(ev)
    if type(ev) ~= 'table' or not cfg('restart_on', false) or (PB.Restart and PB.Restart.State and PB.Restart.State()) then return end
    local m = math.ceil((tonumber(ev.secondsRemaining) or 0) / 60)
    if m > 0 and m <= 30 then tellAll((cfg('restart_msg', ''):gsub('{min}', tostring(m)))) end
end)
AddEventHandler('txAdmin:events:serverShuttingDown', function() G.SaveAll() end)
AddEventHandler('onResourceStop', function(res) if res == GetCurrentResourceName() then G.SaveAll() end end)

-- Panel ------------------------------------------------------------------------------------------------------------------------------
local function trimList(v) return v end

PB.Action('flow.wl.add', 'flow.whitelist', function(ctx, p)
    local v = p.values or {}
    local lic = validLicense(v.license)
    if not lic then return false, 'Licence invalide (40 caractères hexadécimaux, avec ou sans « license: »).' end
    local prio = math.floor(tonumber(v.priority) or 0)
    if prio < 0 or prio > 1000 then return false, 'Priorité : 0 à 1000.' end
    local name = PB.Trim(PB.Sanitize(tostring(v.name or ''), 64))
    local note = PB.Trim(PB.Sanitize(tostring(v.note or ''), 80))
    DB.exec('INSERT INTO pb_flow_wl (license, name, note, priority, added_at, added_by) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), note = VALUES(note), priority = VALUES(priority)',
        { lic, name, note, prio, now(), tostring(ctx.actor and ctx.actor.name or ''):sub(1, 64) })
    ctx.audit('config', 'flow.wl.add', lic, nil, { name = name, priority = prio })
    ctx.toast = 'Ajouté à la liste blanche.'
    return true
end)
PB.Action('flow.wl.remove', 'flow.whitelist', function(ctx, p)
    local lic = validLicense(p.license)
    local r = lic and Flow.WL(lic)
    if not r then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_flow_wl WHERE license = ?', { lic })
    ctx.audit('config', 'flow.wl.remove', lic, r, nil)
    ctx.toast = 'Retiré de la liste blanche.'
    return true
end, { critical = true, confirm = { title = 'Retirer cette personne ?', text = 'Si la liste blanche est active, elle ne pourra plus se connecter.' } })

PB.Action('flow.rules.bump', 'flow.edit', function(ctx)
    local v = cfg('rules_version', 1) + 1
    PB.Cfg.Set('flow', 'rules_version', v, ctx.actor and ctx.actor.id or 0, 'panel')
    ctx.audit('config', 'flow.rules.bump', tostring(v), nil, nil)
    ctx.toast = 'Tous les joueurs devront accepter à nouveau le règlement (version ' .. v .. ').'
    return true
end, { critical = true, confirm = { title = 'Exiger une nouvelle acceptation ?', text = 'Chaque joueur reverra l\'écran de règlement à sa prochaine connexion.' } })

PB.Action('flow.queue.kick', 'flow.edit', function(ctx, p)
    local i = posOf(tonumber(p.src) or -1)
    if not i then return false, 'Ce joueur a quitté la file.' end
    table.remove(queue, i)
    ctx.audit('serveur', 'flow.queue.kick', tostring(p.src), nil, nil)
    ctx.toast = 'Retiré de la file.'
    return true
end)

local function listCheck(v, maxn, maxlen) return v end

local function connexionForm(ctx)
    return Form.Cfg({ ns = 'flow', id = 'connexion', title = 'Connexion, liste blanche et file d\'attente', perm = 'flow.edit', cols = 2,
        desc = 'La maintenance se règle dans Serveur > Maintenance. Les membres du staff passent toujours devant.',
        fields = {
            { k = 'whitelist_on', type = 'toggle', label = 'Liste blanche active', default = DEF.whitelist_on },
            { k = 'queue_on', type = 'toggle', label = "File d'attente quand le serveur est plein", default = DEF.queue_on },
            { k = 'whitelist_msg', type = 'area', label = 'Message aux personnes refusées', default = DEF.whitelist_msg, maxlen = 300, wide = true },
            { k = 'max_slots', type = 'number', label = 'Slots avant la file (0 = ceux du server.cfg)', default = DEF.max_slots, min = 0, max = 2048 },
            { k = 'queue_timeout', type = 'number', label = "Attente maximale (minutes)", default = DEF.queue_timeout, min = 1, max = 240 },
            { k = 'queue_card', type = 'toggle', label = 'Afficher une carte pendant l\'attente', default = DEF.queue_card },
            { k = 'connect_title', type = 'text', label = 'Titre de la carte', default = DEF.connect_title, maxlen = 40 },
        } })(ctx)
end

local function welcomeForm(ctx)
    return Form.Cfg({ ns = 'flow', id = 'welcome', title = "Écran d'accueil et règlement", perm = 'flow.edit', cols = 2,
        desc = "Affiché à chaque joueur qui n'a pas encore accepté la version actuelle du règlement. L'acceptation est enregistrée par licence.",
        fields = {
            { k = 'welcome_on', type = 'toggle', label = "Afficher l'écran d'accueil", default = DEF.welcome_on },
            { k = 'min_read', type = 'number', label = "Lecture minimale avant d'accepter (secondes)", default = DEF.min_read, min = 0, max = 120, hint = 'Vérifié côté serveur.' },
            { k = 'welcome_style', type = 'select', label = 'Présentation', default = DEF.welcome_style, opts = { { 'hero', 'Plein écran (logo, titre, texte)' }, { 'card', 'Carte classique' } } },
            { k = 'welcome_blur', type = 'toggle', label = "Flouter la scène derrière (flou natif du jeu)", default = DEF.welcome_blur },
            { k = 'welcome_title', type = 'text', label = 'Titre — début (ex. Bienvenue sur le)', default = DEF.welcome_title, maxlen = 60 },
            { k = 'welcome_hl', type = 'text', label = 'Titre — mots mis en couleur (couleur principale du serveur)', default = DEF.welcome_hl, maxlen = 40 },
            { k = 'welcome_text', type = 'area', label = 'Paragraphe sous le titre (laisse vide pour utiliser le sous-titre)', default = DEF.welcome_text, maxlen = 500, wide = true },
            { k = 'welcome_bg', type = 'text', label = "Image de fond (fichier ou lien, vide = la scène du jeu)", default = DEF.welcome_bg, maxlen = 200, wide = true },
            { k = 'welcome_rules', type = 'toggle', label = 'Afficher le règlement sous le texte', default = DEF.welcome_rules },
            { k = 'welcome_sub', type = 'text', label = 'Sous-titre', default = DEF.welcome_sub, maxlen = 140 },
            { k = 'welcome_intro', type = 'list', label = "Présentation (un paragraphe par ligne)", default = DEF.welcome_intro, maxitems = 6, maxlen = 300, wide = true },
            { k = 'rules', type = 'list', label = 'Règlement (une règle par ligne)', default = DEF.rules, maxitems = 30, maxlen = 200, wide = true },
            { k = 'news', type = 'list', label = 'Nouveautés (une par ligne)', default = DEF.news, maxitems = 8, maxlen = 200, wide = true },
            { k = 'links', type = 'list', label = 'Liens utiles (ex. Discord : discord.gg/xxxx)', default = DEF.links, maxitems = 6, maxlen = 100, wide = true },
            { k = 'accept_label', type = 'text', label = 'Bouton « accepter »', default = DEF.accept_label, maxlen = 30 },
            { k = 'decline_label', type = 'text', label = 'Bouton « refuser »', default = DEF.decline_label, maxlen = 30 },
            { k = 'decline_msg', type = 'text', label = 'Message à celui qui refuse', default = DEF.decline_msg, maxlen = 120, wide = true },
        } })(ctx)
end

local function restartNotice()
    local dup = {}
    for _, t in ipairs(cfg('restart_times', {}) or {}) do if monitorHandles(t) then dup[#dup + 1] = t end end
    if #dup == 0 then return nil end
    return B.notice('warn', ('Le module Monitoring redémarre déjà le serveur à %s (avec sauvegarde) : les annonces ci-dessous sont ignorées à ces heures pour éviter les doublons.'):format(table.concat(dup, ', ')))
end
local function restartForm(ctx)
    return Form.Cfg({ ns = 'flow', id = 'restart', title = 'Redémarrages et annonces', perm = 'flow.edit', cols = 2,
        desc = "Le panel ne redémarre pas le serveur : c'est txAdmin (ou ton hébergeur) qui le fait. Ici tu prévois les annonces, la sauvegarde des joueurs et, au choix, leur déconnexion propre juste avant.",
        fields = {
            { k = 'restart_on', type = 'toggle', label = 'Annoncer les redémarrages', default = DEF.restart_on },
            { k = 'restart_kick', type = 'toggle', label = "Déconnecter les joueurs à l'heure dite", default = DEF.restart_kick },
            { k = 'restart_times', type = 'list', label = 'Heures de redémarrage (HH:MM, une par ligne, heure du serveur)', default = DEF.restart_times, maxitems = 12, maxlen = 5, pattern = '^[0-2]%d:[0-5]%d$', wide = true },
            { k = 'restart_warn', type = 'list', label = 'Annoncer à (minutes avant, une valeur par ligne)', default = DEF.restart_warn, maxlen = 3, pattern = '^%d+$', maxitems = 8, wide = true },
            { k = 'restart_msg', type = 'area', label = "Message ({min} = minutes restantes)", default = DEF.restart_msg, maxlen = 200, wide = true },
            { k = 'restart_kick_msg', type = 'text', label = 'Message de déconnexion', default = DEF.restart_kick_msg, maxlen = 120, wide = true },
        } })(ctx)
end

local function fmtDur(s) s = math.floor(s or 0) if s < 3600 then return math.floor(s / 60) .. ' min' end return ('%dh%02d'):format(math.floor(s / 3600), math.floor(s % 3600 / 60)) end
local function journey()
    local c = PB.Cfg.All('flow')
    local maint = PB.Cfg.Get('general', 'maintenance_on', false)
    local function step(title, icon, tone, on, text, sub) return { title = title, icon = icon, tone = on and tone or '#7a7388', badge = on and 'Actif' or 'Désactivé', text = text, sub = sub } end
    return {
        step('Connexion', 'lock', '#6fb4ff', true, maint and 'Maintenance en cours : seul le staff entre.' or 'Ouverte à tous.', 'Maintenance : Serveur > Maintenance'),
        step('Liste blanche', 'shield', '#ffb457', c.whitelist_on, c.whitelist_on and 'Seules les licences autorisées entrent.' or 'Tout le monde peut se connecter.', ''),
        step("File d'attente", 'clock', '#dfe2e7', c.queue_on, c.queue_on and ('Au-delà de %d joueurs, par priorité puis par ordre d\'arrivée.'):format(Flow.MaxSlots()) or 'Le serveur refuse quand il est plein.', ''),
        step('Règlement', 'book', '#7be0a4', c.welcome_on, c.welcome_on and ('Version %d, lecture minimale %d s.'):format(c.rules_version, c.min_read) or 'Les joueurs entrent sans écran d\'accueil.', ''),
        step('Création du personnage', 'face', '#ff6b7d', PB.Cfg.Get('character', 'enabled', true), 'Identité, apparence, point d\'arrivée.', 'Module Personnage'),
        step('En jeu', 'bolt', '#6fb4ff', true, 'HUD, économie, entreprises, chat, menus F5 / F6 / F7.', ''),
        step('Redémarrage', 'power', '#ffb457', c.restart_on, c.restart_on and (#c.restart_times .. ' heure(s) planifiée(s) avec annonces.') or 'Aucune annonce planifiée.', ''),
    }
end

PB.Module({
    id = 'flow', label = 'Parcours serveur', icon = 'route', group = 'Serveur', order = 18, perm = 'flow.view', hint = 'Connexion, file, règlement, sessions, redémarrages',
    caps = function()
        return PB.Capsify({
            { 'Liste blanche par licence, priorités', 'ok', 'Contrôlée à la connexion, avant que le joueur ne charge le serveur.' },
            { "File d'attente avec position en direct", 'ok', "Carte d'attente dans la fenêtre de connexion de FiveM ; le staff passe devant." },
            { 'Écran de règlement avec acceptation enregistrée', 'ok', 'Version du règlement : un changement force tout le monde à relire.' },
            { 'Sessions et temps de jeu', 'ok', 'Chaque connexion est journalisée (durée, raison du départ).' },
            { 'Annonces de redémarrage + sauvegarde des joueurs', 'ok', "Relais des redémarrages planifiés de txAdmin (via ses événements) ou de tes propres heures." },
            { 'Redémarrer le serveur depuis le panel', 'off', "Impossible depuis une ressource : utilise txAdmin ou ton hébergeur." },
            { 'Écran de chargement (loadingscreen) personnalisé', 'off', "Retiré (v1.2.43) : FiveM affiche son écran par défaut. Ici : carte de connexion et règlement en jeu." },
        })
    end,
    doc = "## Parcours serveur\nDe la connexion à la déconnexion, tout se règle ici.\n\n1. **Connexion** : maintenance (module Serveur), liste blanche, file d'attente.\n2. **Règlement** : écran affiché une fois par version.\n3. **Création** puis **jeu**.\n4. **Redémarrages** : annonces et sauvegarde.\n\n`exports.pb_panel:IsWhitelisted(licence)` et `GetPlaytime(licence)` sont disponibles pour tes scripts.",
    view = function(ctx)
        return { tabs = {
            { id = 'overview', label = "Vue d'ensemble", icon = 'route', build = function()
                local online = #GetPlayers()
                local today = DB.one('SELECT COUNT(*) AS n FROM pb_flow_sessions WHERE joined >= ?', { now() - 86400 })
                local avg = DB.one('SELECT COALESCE(AVG(secs), 0) AS s FROM pb_flow_sessions WHERE left_at > 0 AND secs > 60')
                local wl = DB.one('SELECT COUNT(*) AS n FROM pb_flow_wl')
                local acc = DB.one('SELECT COUNT(*) AS n FROM pb_flow_accept WHERE version >= ?', { cfg('rules_version', 1) })
                return { { type = 'cards', items = {
                    { title = 'En ligne', value = tostring(online) .. ' / ' .. Flow.MaxSlots(), icon = 'users', tone = '#6fb4ff', sub = ('Pic du jour : %d'):format(stats.peak) },
                    { title = "File d'attente", value = tostring(#queue), icon = 'clock', tone = '#dfe2e7', sub = ('%d passés par la file depuis le démarrage'):format(stats.queued) },
                    { title = 'Connexions (24 h)', value = tostring(today and today.n or 0), icon = 'bolt', tone = '#7be0a4', sub = 'Durée moyenne : ' .. fmtDur(avg and avg.s or 0) },
                    { title = 'Règlement accepté', value = tostring(acc and acc.n or 0), icon = 'book', tone = '#ffb457', sub = ('Version %d · liste blanche : %d'):format(cfg('rules_version', 1), wl and wl.n or 0) } } },
                    { type = 'cards', big = true, items = journey() } }
            end },
            { id = 'connexion', label = 'Connexion et file', icon = 'lock', build = function()
                local rows = {}
                for i, q in ipairs(queue) do rows[#rows + 1] = { pos = i, name = tostring(GetPlayerName(q.src) or q.src), prio = q.prio >= 1000000 and 'Staff' or q.prio, wait = (now() - q.t) .. ' s', actions = ctx.has('flow.edit') and { { action = 'flow.queue.kick', label = 'Retirer', icon = 'x', payload = { src = q.src } } } or {} } end
                return { connexionForm(ctx), B.table({ id = 'q', title = "File d'attente en direct", columns = { { k = 'pos', label = '#', type = 'num' }, { k = 'name', label = 'Joueur' }, { k = 'prio', label = 'Priorité' }, { k = 'wait', label = 'Attente' } }, rows = rows, empty = "Personne n'attend." }) }
            end },
            { id = 'whitelist', label = 'Liste blanche', icon = 'shield', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_flow_wl ORDER BY priority DESC, name LIMIT 500') or {}) do
                    rows[#rows + 1] = { name = r.name ~= '' and r.name or '—', lic = r.license, prio = r.priority, note = r.note, at = r.added_at, actions = ctx.has('flow.whitelist') and { { action = 'flow.wl.remove', label = 'Retirer', icon = 'trash', danger = true, payload = { license = r.license } } } or {} }
                end
                local blocks = { B.table({ id = 'wl', title = 'Personnes autorisées (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'lic', label = 'Licence', type = 'mono' }, { k = 'prio', label = 'Priorité', type = 'num' }, { k = 'note', label = 'Note' }, { k = 'at', label = 'Ajouté', type = 'date' } }, rows = rows, empty = 'Liste vide.' }) }
                if ctx.has('flow.whitelist') then blocks[#blocks + 1] = { type = 'form', id = 'wl.add', title = 'Ajouter ou modifier', desc = "Une priorité plus haute passe devant dans la file (0 à 1000). Elle s'applique même si la liste blanche est désactivée.", cols = 2, fields = {
                    { k = 'license', type = 'text', label = 'Licence Rockstar', required = true, maxlen = 64 }, { k = 'name', type = 'text', label = 'Nom (pour te repérer)', maxlen = 64 },
                    { k = 'priority', type = 'number', label = 'Priorité', min = 0, max = 1000 }, { k = 'note', type = 'text', label = 'Note', maxlen = 80 } },
                    values = { license = '', name = '', priority = 0, note = '' }, submit = { action = 'flow.wl.add', label = 'Enregistrer' } } end
                return blocks
            end },
            { id = 'welcome', label = 'Accueil et règlement', icon = 'book', perm = 'flow.edit', build = function()
                return { welcomeForm(ctx), B.actions({ { action = 'flow.rules.bump', label = 'Exiger une nouvelle acceptation', icon = 'refresh', danger = true } }),
                    { type = 'gpreview', kind = 'welcome', title = 'Écran vu par le joueur', cfg = {} } }
            end },
            { id = 'restart', label = 'Redémarrages', icon = 'power', perm = 'flow.edit', build = function() local n = restartNotice() if n then return { n, restartForm(ctx) } end return { restartForm(ctx) } end },
            { id = 'sessions', label = 'Sessions', icon = 'clock', build = function()
                local rows, labels, vals = {}, {}, {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_flow_sessions ORDER BY id DESC LIMIT 80') or {}) do
                    rows[#rows + 1] = { name = r.name, lic = r.license, joined = r.joined, dur = r.left_at > 0 and fmtDur(r.secs) or 'En ligne', reason = r.reason }
                end
                for d = 13, 0, -1 do
                    local from = os.time({ year = tonumber(os.date('%Y')), month = tonumber(os.date('%m')), day = tonumber(os.date('%d')), hour = 0 }) - d * 86400
                    local n = DB.one('SELECT COUNT(*) AS n FROM pb_flow_sessions WHERE joined >= ? AND joined < ?', { from, from + 86400 })
                    labels[#labels + 1] = os.date('%d/%m', from) vals[#vals + 1] = n and n.n or 0
                end
                local top = {}
                for _, r in ipairs(DB.q('SELECT name, SUM(secs) AS s, COUNT(*) AS n FROM pb_flow_sessions GROUP BY license, name ORDER BY s DESC LIMIT 10') or {}) do top[#top + 1] = { name = r.name, time = fmtDur(r.s), n = r.n } end
                return { { type = 'chart', id = 'joins', title = 'Connexions par jour (14 jours)', labels = labels, series = { { name = 'Connexions', values = vals } } },
                    B.table({ id = 'top', title = 'Temps de jeu (top 10)', columns = { { k = 'name', label = 'Joueur' }, { k = 'time', label = 'Temps' }, { k = 'n', label = 'Connexions', type = 'num' } }, rows = top, empty = 'Aucune session.' }),
                    B.table({ id = 'sess', title = 'Dernières sessions', search = true, columns = { { k = 'name', label = 'Joueur' }, { k = 'joined', label = 'Arrivée', type = 'date' }, { k = 'dur', label = 'Durée' }, { k = 'reason', label = 'Départ' }, { k = 'lic', label = 'Licence', type = 'mono' } }, rows = rows, empty = 'Aucune session.' }) }
            end },
        } }
    end,
})

PB.SelfTest.Add('parcours', function(R)
    R.check(type(cfg('rules_version', 1)) == 'number' and cfg('rules_version', 1) >= 1, 'règlement', 'version invalide')
    for _, t in ipairs(cfg('restart_times', {})) do R.check(toMinutes(t) ~= nil, 'redémarrage ' .. tostring(t), 'heure invalide') end
    R.check(Flow.MaxSlots() >= 1, 'slots', 'nombre de slots invalide')
    R.check(pcall(Flow.WelcomeData), 'écran d\'accueil', 'données impossibles à construire')
end)

-- Dépannage depuis la console du serveur (pas en jeu) : pb_whitelist off | on | status
RegisterCommand('pb_whitelist', function(src, args)
    if src ~= 0 then return end
    local a = tostring(args[1] or 'status'):lower()
    if a == 'off' then PB.Cfg.Set('flow', 'whitelist_on', false, 0, 'console') print('[pb_panel] Liste blanche désactivée.')
    elseif a == 'on' then PB.Cfg.Set('flow', 'whitelist_on', true, 0, 'console') print('[pb_panel] Liste blanche activée.')
    else print(('[pb_panel] Liste blanche : %s · %s licence(s) · active en pratique : %s'):format(cfg('whitelist_on', false) and 'activée' or 'désactivée', tostring(DB.scalar('SELECT COUNT(*) FROM pb_flow_wl')), tostring(Flow.WLActive()))) end
end, true)
PB.SelfTest.Add('liste blanche', function(R)
    if cfg('whitelist_on', false) then
        local n = tonumber(DB.scalar('SELECT COUNT(*) FROM pb_flow_wl')) or 0
        if n == 0 then R.warn('liste blanche', 'activée mais vide', "Elle est ignorée tant qu'aucune licence n'est ajoutée (Parcours › Liste blanche).") end
        if tostring(GetConvar('pb_whitelist', 'on')):lower() == 'off' then R.warn('liste blanche', 'coupée par convar', 'set pb_whitelist off est présent dans le server.cfg : la liste blanche est ignorée.') end
    end
end)
