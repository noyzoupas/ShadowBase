-- Logements : achat / location, accès partagés, coffre du logement (inventaire 'h:<id>'), loyers, porte verrouillable, entrée/sortie optionnelle.
-- Le serveur décide (propriété, loyer, droits, distance). Le client affiche l'invite et téléporte seulement sur ordre du serveur.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('housing.edit', 'Créer, modifier ou supprimer des logements et leurs réglages', 'housing', true)
P.Register('housing.manage', 'Attribuer, reprendre ou libérer un logement depuis le panel', 'housing', true)

local HOUSING_SQL = {
    [[CREATE TABLE IF NOT EXISTS pb_properties (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, kind VARCHAR(8) NOT NULL DEFAULT 'buy', price INT NOT NULL DEFAULT 0, rent INT NOT NULL DEFAULT 0,
        x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, ix DOUBLE NOT NULL DEFAULT 0, iy DOUBLE NOT NULL DEFAULT 0, iz DOUBLE NOT NULL DEFAULT 0, ih DOUBLE NOT NULL DEFAULT 0,
        owner VARCHAR(64) NOT NULL DEFAULT '', since INT NOT NULL DEFAULT 0, paid_until INT NOT NULL DEFAULT 0, arrears INT NOT NULL DEFAULT 0, locked TINYINT(1) NOT NULL DEFAULT 1, enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_property_access (prop VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, by_license VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (prop, license))]],
}
local DEFAULT_PROPS = {
    { 'tinsel', 'Appartement — Tinsel Towers', 'buy', 85000, 0, -621.0, 46.0, 43.6 },
    { 'integrity', 'Appartement — Integrity Way', 'rent', 0, 650, -47.2, -585.8, 37.9 },
    { 'alta', 'Studio — Alta Street', 'rent', 0, 420, -270.0, -962.0, 31.2 },
    { 'vinewood', 'Maison — Vinewood Hills', 'buy', 240000, 0, -174.0, 502.0, 137.4 },
}
PB.Migrate('049_game_housing', 'Logements, accès, loyers', function()
    for _, sql in ipairs(HOUSING_SQL) do DB.exec(PB.Table(sql)) end
    for _, d in ipairs(DEFAULT_PROPS) do DB.exec('INSERT IGNORE INTO pb_properties (id, label, kind, price, rent, x, y, z) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', d) end
end)

PB.Cfg.Define('housing', { evict = true, realtor_biz = 'realestate', realtor_pct = 5, enabled = true, max_owned = 2, rent_days = 7, grace_periods = 3, sell_ratio = 70, use_distance = 2.5, blips = true, guests_max = 6, enter_cooldown = 2,
    tax_pct = 1, furniture_max = 60, furniture_vip = true, interior_vip = true, furniture_mode = 'items',
    realtor_studio = 45000, realtor_studio_rent = 350, realtor_appart = 95000, realtor_appart_rent = 750,
    realtor_luxe = 320000, realtor_luxe_rent = 2200, realtor_villa = 750000, realtor_villa_rent = 4800 })
-- villa de la boutique (coins) : pas d'impôt foncier, pas de revente contre de l'argent, intérieur et meubles libres même sans VIP
PB.Migrate('378_housing_premium', 'Logements : villas de la boutique', { "ALTER TABLE pb_properties ADD COLUMN premium TINYINT(1) NOT NULL DEFAULT 0" })
local function isPremium(h) return h and PB.ToBool(h.premium) end
PB.Migrate('216_housing_plus', 'Logements : impôt foncier, meubles, aquarium', {
    "ALTER TABLE pb_properties ADD COLUMN tax_until INT NOT NULL DEFAULT 0",
    [[CREATE TABLE IF NOT EXISTS pb_property_furniture (id INT NOT NULL AUTO_INCREMENT, prop VARCHAR(32) NOT NULL, model VARCHAR(48) NOT NULL,
        x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, h DOUBLE NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_prop (prop))]],
    [[CREATE TABLE IF NOT EXISTS pb_property_aquarium (id INT NOT NULL AUTO_INCREMENT, prop VARCHAR(32) NOT NULL, item VARCHAR(40) NOT NULL, label VARCHAR(48) NOT NULL DEFAULT '',
        at INT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_prop (prop))]],
})
-- Intérieurs prédéfinis (intérieurs du jeu ; à vérifier en jeu) et meubles posables (VIP)
local INTERIORS = {
    { id = 'studio', label = 'Studio', x = 266.06, y = -1007.31, z = -101.01, h = 0.0 },
    { id = 'appart', label = 'Appartement', x = 346.55, y = -1012.92, z = -99.20, h = 357.0 },
    { id = 'luxe', label = 'Appartement de luxe', x = -786.87, y = 315.76, z = 217.64, h = 270.0 },
    { id = 'villa', label = 'Villa', x = -174.73, y = 497.69, z = 137.67, h = 190.0 },
}
-- Meubles : en mode « objets » (par défaut), chaque meuble est un objet de l'inventaire (meuble_…) acheté au Magasin de meubles,
-- posé chez soi (l'objet est consommé) et rendu dans le sac quand on le retire : on peut donc les donner, les vendre (app Contrats), les ranger.
local FURNITURE = {
    { model = 'prop_couch_01', label = 'Canapé', price = 1800 }, { model = 'prop_t_sofa', label = 'Canapé d\'angle', price = 3200 }, { model = 'prop_chair_01a', label = 'Chaise', price = 250 },
    { model = 'prop_table_03', label = 'Table basse', price = 450 }, { model = 'prop_table_04', label = 'Table', price = 700 }, { model = 'prop_tv_flat_01', label = 'Télévision', price = 2500 },
    { model = 'prop_tv_06', label = 'Vieille télévision', price = 600 }, { model = 'prop_plant_int_01a', label = 'Plante', price = 150 }, { model = 'prop_plant_int_02a', label = 'Grande plante', price = 300 },
    { model = 'prop_rub_couch04', label = 'Vieux canapé', price = 400 }, { model = 'prop_bar_fridge_01', label = 'Mini-frigo', price = 1200 }, { model = 'prop_speaker_06', label = 'Enceinte', price = 900 },
    { model = 'prop_bar_stool_01', label = 'Tabouret de bar', price = 300 }, { model = 'prop_laptop_01a', label = 'Ordinateur portable', price = 1500 }, { model = 'prop_bin_01a', label = 'Poubelle', price = 80 },
    { model = 'prop_rug_01', label = 'Tapis', fallback = true, price = 350 }, { model = 'prop_aquarium_01', label = 'Aquarium', aquarium = true, price = 6000 },
}
local FURN_BY, FURN_ITEM = {}, {}
for _, f in ipairs(FURNITURE) do
    f.item = ('meuble_' .. f.model:gsub('^prop_', '')):sub(1, 32)
    FURN_BY[f.model], FURN_ITEM[f.item] = f, f
end
PB.OnReady(function()
    local added = 0
    for _, f in ipairs(FURNITURE) do
        if not DB.one('SELECT name FROM pb_inv_items WHERE name = ?', { f.item }) then
            DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, 4000, 5, ?, 0, ?)', { f.item, 'Meuble : ' .. f.label, 'misc', 'À poser chez soi : dans ton logement, E › Poser un meuble.' })
            added = added + 1
        end
    end
    if added > 0 and G.Inv and G.Inv.Reload then G.Inv.Reload() end
end)
local insideOf = {}   -- src -> logement où le joueur se trouve (intérieur instancié)
local function bucketOf(id) local n = 0 for i = 1, #id do n = (n * 31 + id:byte(i)) % 40000 end return 1000 + n end

local Hs = {}
G.Housing = Hs
Hs.FURNITURE = FURNITURE
Hs.Inside = insideOf
local function cfg(k, d) return PB.Cfg.Get('housing', k, d) end
local function itemsMode() return cfg('furniture_mode', 'items') == 'items' end
local function now() return os.time() end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function period() return cfg('rent_days', 7) * 86400 end

-- Données --------------------------------------------------------------------------------------------------------------------------------
-- Prix des logements du serveur (posés par le staff) : prix du panel × multiplicateur de l'économie × TVA.
-- Les biens mis en vente par un agent immobilier gardent le prix choisi par l'agent.
local function eco(h)
    if type(h) ~= 'table' or (h.listed_by or '') ~= '' or not (G.Eco and G.Eco.Final) then return h end
    h.price, h.rent = G.Eco.Final(tonumber(h.price) or 0), G.Eco.Final(tonumber(h.rent) or 0)
    return h
end
local function ecoAll(list) for _, h in ipairs(list or {}) do eco(h) end return list or {} end
Hs.Eco = eco
function Hs.All() return ecoAll(DB.q('SELECT * FROM pb_properties ORDER BY label')) end
function Hs.Get(id) return eco(DB.one('SELECT * FROM pb_properties WHERE id = ?', { tostring(id) })) end
function Hs.OwnedBy(license) return ecoAll(DB.q('SELECT * FROM pb_properties WHERE owner = ? ORDER BY label', { license })) end
function Hs.Guests(id) return DB.q('SELECT a.license, a.at, p.firstname, p.lastname FROM pb_property_access a LEFT JOIN pb_players p ON p.license = a.license WHERE a.prop = ? ORDER BY a.at', { tostring(id) }) or {} end
function Hs.StashOwner(id) return 'h:' .. tostring(id) end
function Hs.StashEmpty(id)
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { Hs.StashOwner(id) })
    return not n or n.n == 0
end
local function inArrears(h) return h.owner ~= '' and (h.arrears or 0) > 0 end

-- A-t-on le droit d'entrer / utiliser le coffre ?
function Hs.HasAccess(license, h)
    if not h or h.owner == '' or inArrears(h) then return false end
    if h.owner == license then return true end
    return DB.one('SELECT prop FROM pb_property_access WHERE prop = ? AND license = ?', { h.id, license }) ~= nil
end


-- Agence immobilière : ses agents en service mettent des logements en vente / en location à leur position, règlent le prix et l'intérieur,
-- et font visiter (accès de 15 minutes à un logement libre). Menu ALT › Métier. L'agence touche une commission sur chaque vente.
PB.Migrate('200_realtor', "Logements : agence immobilière", { "ALTER TABLE pb_properties ADD COLUMN listed_by VARCHAR(32) NOT NULL DEFAULT ''" })
local Re = {}
G.Realtor = Re
local visits = {}   -- licence -> { [logement] = fin de la visite }
function Re.Biz() local b = tostring(cfg('realtor_biz', 'realestate') or '') return b ~= '' and b or nil end
function Re.IsAgent(src)
    local b = Re.Biz()
    local j = b and G.Biz and G.Biz.Job(tonumber(src))
    return j ~= nil and j.biz == b and j.onDuty == true
end
function Re.Visiting(license, id) local v = visits[license] return v ~= nil and (v[id] or 0) > os.time() end
-- (v1.2.78) visite ouverte par l'agence PNJ (mode « ventes par PNJ uniquement »)
function Re.GrantVisit(license, id, secs) visits[license] = visits[license] or {} visits[license][id] = os.time() + (tonumber(secs) or 900) end
local function posOf(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped), GetEntityHeading(ped) end
-- logement le plus proche de l'agent (porte), libre, mis en vente par l'agence
local function nearestListed(src, maxd)
    local c = posOf(src)
    if not c then return nil, 'Position illisible.' end
    local best, bd
    for _, h in ipairs(ecoAll(DB.q("SELECT * FROM pb_properties WHERE owner = '' AND listed_by = ?", { Re.Biz() or '' }))) do
        local d = #(c - vector3(h.x, h.y, h.z))
        if d <= maxd and (not bd or d < bd) then best, bd = h, d end
    end
    if not best then return nil, ("Aucun logement libre de l'agence à moins de %d m."):format(maxd) end
    return best
end
local function rid() return ('re_' .. tostring(os.time() % 1000000) .. tostring(math.random(100, 999))):sub(1, 32) end
-- Gammes de l'agence : prix fixés par le serveur (pas de prix libre : pas d'abus), intérieur posé automatiquement
function Re.Tiers()
    local out = {}
    for _, it in ipairs(INTERIORS) do
        out[#out + 1] = { id = it.id, label = it.label, price = math.floor(tonumber(cfg('realtor_' .. it.id, 0)) or 0), rent = math.floor(tonumber(cfg('realtor_' .. it.id .. '_rent', 0)) or 0) }
    end
    return out
end
function Re.ListTier(src, kind, tierId, name)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    if kind ~= 'buy' and kind ~= 'rent' then return false, 'Choisis vente ou location.' end
    local tier, pre
    for _, t in ipairs(Re.Tiers()) do if t.id == tostring(tierId) then tier = t end end
    for _, it in ipairs(INTERIORS) do if it.id == tostring(tierId) then pre = it end end
    if not tier or not pre then return false, 'Gamme inconnue.' end
    local amount = kind == 'buy' and tier.price or tier.rent
    if amount < 1 then return false, 'Cette gamme n\'a pas de prix réglé (panel › Logements).' end
    local ok, msg = Re.List(src, kind, name, amount, true)
    if not ok then return false, msg end
    local last = Re.lastId
    if last then DB.exec('UPDATE pb_properties SET ix = ?, iy = ?, iz = ?, ih = ? WHERE id = ?', { pre.x, pre.y, pre.z, pre.h, last }) end
    G.PushConfig()
    return true, ('« %s » (%s) %s pour %s, intérieur compris.'):format(tostring(name), tier.label, kind == 'buy' and 'mis en vente' or 'mis en location', money(amount))
end
RegisterNetEvent('pb:g:realtor:list', function(kind, tierId, name)
    local src = source
    if not G.Get(src) then return end
    local ok, msg = Re.ListTier(src, tostring(kind or ''), tostring(tierId or ''), name)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Agence immobilière', text = msg })
end)
function Re.List(src, kind, name, amount, fromTier)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    if not fromTier then return false, 'Choisis une gamme : les prix sont fixés par le serveur.' end
    name = tostring(name or ''):gsub('[%c<>"\\]', ''):sub(1, 48)
    amount = math.floor(tonumber(amount) or 0)
    if #name < 3 then return false, 'Donne un nom au logement (3 caractères au moins).' end
    if amount < 1 or amount > 100000000 then return false, 'Prix invalide.' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_properties WHERE listed_by = ?', { Re.Biz() })
    if n and tonumber(n.n) >= (tonumber(cfg('realtor_max', 40)) or 40) then return false, "L'agence a atteint son nombre maximum d'annonces." end
    local c, hd = posOf(src)
    if not c then return false, 'Position illisible.' end
    local newId = rid()
    Re.lastId = newId
    DB.exec('INSERT INTO pb_properties (id, label, kind, price, rent, x, y, z, enabled, listed_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
        { newId, name, kind, kind == 'buy' and amount or 0, kind == 'rent' and amount or 0, c.x, c.y, c.z, Re.Biz() })
    PB.Audit.Log('serveur', 'realtor.list', src, name, nil, { kind = kind, amount = amount })
    G.PushConfig()
    return true, ('« %s » %s pour %s. La porte est ici ; ajoute un intérieur avec « Définir l\'intérieur ».'):format(name, kind == 'buy' and 'mis en vente' or 'mis en location', money(amount))
end
function Re.Price(src, amount)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    do return false, 'Les prix sont fixés par le serveur (gammes de l\'agence).' end
    amount = math.floor(tonumber(amount) or 0)
    if amount < 1 or amount > 100000000 then return false, 'Prix invalide.' end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    DB.exec(h.kind == 'buy' and 'UPDATE pb_properties SET price = ? WHERE id = ?' or 'UPDATE pb_properties SET rent = ? WHERE id = ?', { amount, h.id })
    G.PushConfig()
    return true, ('%s : %s.'):format(h.label, money(amount))
end
function Re.Unlist(src)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    DB.exec("DELETE FROM pb_properties WHERE id = ? AND owner = ''", { h.id })
    PB.Audit.Log('serveur', 'realtor.unlist', src, h.label)
    G.PushConfig()
    return true, h.label .. ' retiré des annonces.'
end
function Re.Interior(src)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 120) if not h then return false, err end
    local c, hd = posOf(src)
    DB.exec('UPDATE pb_properties SET ix = ?, iy = ?, iz = ?, ih = ? WHERE id = ?', { c.x, c.y, c.z, hd or 0.0, h.id })
    G.PushConfig()
    return true, ("Intérieur de « %s » placé ici : on y arrive en entrant par la porte."):format(h.label)
end
function Re.Visit(src, t)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    if h.ix == 0 and h.iy == 0 then return false, "Ce logement n'a pas encore d'intérieur." end
    local tp = G.Get(t)
    if not tp then return false, 'Personne introuvable.' end
    visits[tp.license] = visits[tp.license] or {}
    visits[tp.license][h.id] = os.time() + 900
    G.Notify(t, { type = 'info', title = 'Visite', text = ("Tu peux visiter « %s » pendant 15 minutes : entre par la porte."):format(h.label) })
    return true, ('Visite de « %s » ouverte pour 15 minutes.'):format(h.label)
end

local function nameOf(license)
    local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { license })
    if not r then return '—' end
    local n = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    return n ~= '' and n or '—'
end

exports('HasHousingAccess', function(src, id) local p = G.Get(tonumber(src)) return p ~= nil and Hs.HasAccess(p.license, Hs.Get(id)) end)
exports('GetProperties', function(src) local p = G.Get(tonumber(src)) local out = {} if p then for _, h in ipairs(Hs.OwnedBy(p.license)) do out[#out + 1] = { id = h.id, label = h.label, kind = h.kind } end end return out end)

-- Coffre du logement : branché sur l'inventaire (Inv.ExtraAccess)
local Inv = G.Inv
local prevExtra = Inv and Inv.ExtraAccess
if Inv then
    Inv.ExtraAccess = function(src, kind, id)
        if kind == 'h' then
            local p = G.Get(src)
            local h = p and Hs.Get(id)
            if not h or not PB.ToBool(h.enabled) or not Hs.HasAccess(p.license, h) then return false end
            return G.DistTo(src, h.x, h.y, h.z) <= cfg('use_distance', 2.5) + 6
        end
        if prevExtra then return prevExtra(src, kind, id) end
        return false
    end
end

-- Sessions de menu -----------------------------------------------------------------------------------------------------------------------
local sessions = {}
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function near(src, h, extra) return G.DistTo(src, h.x, h.y, h.z) <= (extra or cfg('use_distance', 2.5) + 5) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end

local function rentDue(h)
    if h.kind ~= 'rent' or h.owner == '' then return 0 end
    return math.max(0, (h.arrears or 0)) * h.rent
end

-- Pages ---------------------------------------------------------------------------------------------------------------------------------
local PAGES = {}
local function statusOf(src, h)
    local p = G.Get(src)
    if h.owner == '' then return 'free' end
    if h.owner == p.license then return inArrears(h) and 'arrears' or 'mine' end
    if Hs.HasAccess(p.license, h) then return 'guest' end
    return 'taken'
end
PAGES.home = function(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    local st = statusOf(src, h)
    local acts, blocks = {}, {}
    local owned = #Hs.OwnedBy(p.license)
    if st == 'free' and isPremium(h) then
        blocks[#blocks + 1] = { type = 'notice', tone = 'info', text = 'Villa de la boutique du serveur : elle se prend avec des coins (commande /boutique).' }
    elseif st == 'free' then
        if owned >= cfg('max_owned', 2) then
            blocks[#blocks + 1] = { type = 'notice', tone = 'warn', text = ('Tu possèdes déjà %d logement(s) : c\'est le maximum autorisé.'):format(cfg('max_owned', 2)) }
        elseif h.kind == 'buy' then
            acts[#acts + 1] = { act = 'buy', label = 'Acheter pour ' .. money(h.price), primary = true }
        else
            acts[#acts + 1] = { act = 'rent', label = ('Louer : %s par période de %d j'):format(money(h.rent), cfg('rent_days', 7)), primary = true }
        end
        -- visite (accordée par un agent) ou agent de l'agence : on peut entrer dans le logement libre
        if (h.ix ~= 0 or h.iy ~= 0) and (Re.Visiting(p.license, h.id) or (Re.IsAgent(src) and h.listed_by == Re.Biz())) then acts[#acts + 1] = { act = 'enter', label = 'Visiter' } end
    elseif st == 'mine' or st == 'arrears' then
        if st == 'arrears' then
            local due = h.kind == 'buy' and (math.max(1, h.arrears or 0) * math.floor(h.price * (tonumber(cfg('tax_pct', 1)) or 0) / 100)) or rentDue(h)
            blocks[#blocks + 1] = { type = 'notice', tone = 'warn', text = ('%s impayé : %s. Tant que tu ne régularises pas, l\'accès et le coffre sont suspendus (rien n\'est supprimé).'):format(h.kind == 'buy' and 'Impôt foncier' or 'Loyer', money(due)) }
            acts[#acts + 1] = { act = 'pay', label = 'Régler ' .. money(due), primary = true }
        end
        if st == 'mine' and h.kind == 'rent' then acts[#acts + 1] = { act = 'pay', label = 'Payer d\'avance une période (' .. money(h.rent) .. ')' } end
        acts[#acts + 1] = { act = 'lock', label = PB.ToBool(h.locked) and 'Déverrouiller la porte' or 'Verrouiller la porte' }
        if st == 'arrears' and h.kind == 'buy' then acts[#acts] = nil end
        if st == 'mine' then acts[#acts + 1] = { act = 'interior', label = 'Changer d\'intérieur' .. ((cfg('interior_vip', true) ~= false and not isPremium(h)) and ' (VIP)' or '') } end
        if isPremium(h) then blocks[#blocks + 1] = { type = 'notice', tone = 'info', text = 'Villa de la boutique : à toi pour toujours, sans impôt foncier. Choisis ton intérieur et pose tes meubles librement.' }
        else acts[#acts + 1] = { act = 'leave', label = h.kind == 'buy' and ('Vendre (%s)'):format(money(math.floor(h.price * cfg('sell_ratio', 70) / 100))) or 'Résilier la location', danger = true } end
    elseif st == 'guest' then
        blocks[#blocks + 1] = { type = 'notice', tone = 'info', text = 'Tu es colocataire : tu as les clés et accès au coffre commun.' }
        acts[#acts + 1] = { act = 'lock', label = PB.ToBool(h.locked) and 'Déverrouiller la porte' or 'Verrouiller la porte' }
        if h.kind == 'rent' then acts[#acts + 1] = { act = 'pay', label = 'Payer une période de loyer (' .. money(h.rent) .. ')' } end
    else
        blocks[#blocks + 1] = { type = 'notice', tone = 'info', text = 'Ce logement est occupé.' }
        acts[#acts + 1] = { act = 'ring', label = 'Sonner', primary = true }
    end
    if Hs.ConsigneCount(p.license) > 0 then acts[#acts + 1] = { act = 'consigne', label = ('Récupérer mes affaires à la consigne (%d)'):format(Hs.ConsigneCount(p.license)) } end
    local access = st == 'mine' or st == 'guest'
    if access then
        if not PB.ToBool(h.locked) or st == 'mine' or st == 'guest' then
            acts[#acts + 1] = { act = 'stash', label = 'Ouvrir le coffre', primary = st == 'guest' }
            if h.ix ~= 0 or h.iy ~= 0 then acts[#acts + 1] = { act = 'enter', label = 'Entrer' } end
        end
    elseif st == 'taken' and h.ix ~= 0 and not PB.ToBool(h.locked) then
        acts[#acts + 1] = { act = 'enter', label = 'Entrer (porte ouverte)' }
    end
    local info = { { 'Type', h.kind == 'buy' and 'À vendre' or 'À louer' }, { 'Prix', h.kind == 'buy' and money(h.price) or (money(h.rent) .. ' / ' .. cfg('rent_days', 7) .. ' jours') },
        { 'Occupant', h.owner == '' and 'Libre' or (st == 'mine' and 'Toi' or nameOf(h.owner)) },
        { 'Porte', PB.ToBool(h.locked) and 'Verrouillée' or 'Ouverte' } }
    if st == 'mine' and h.kind == 'rent' then info[#info + 1] = { 'Loyer payé jusqu\'au', os.date('%d/%m/%Y', h.paid_until) } end
    if st == 'mine' and h.kind == 'buy' and (tonumber(cfg('tax_pct', 1)) or 0) > 0 then info[#info + 1] = { 'Impôt foncier', ('%s toutes les %d jours'):format(money(math.floor(h.price * cfg('tax_pct', 1) / 100)), cfg('rent_days', 7)) } end
    table.insert(blocks, 1, { type = 'cards', items = {
        { title = 'Statut', value = ({ free = 'Libre', mine = 'Chez toi', arrears = 'Impayé', guest = 'Invité', taken = 'Occupé' })[st], icon = 'home', tone = st == 'arrears' and '#ffb457' or '#7be0a4', sub = h.kind == 'buy' and 'Achat' or 'Location' },
        { title = h.kind == 'buy' and 'Prix' or 'Loyer', value = h.kind == 'buy' and money(h.price) or money(h.rent), icon = 'card', tone = '#6fb4ff', sub = h.kind == 'buy' and '' or ('toutes les ' .. cfg('rent_days', 7) .. ' jours') } } })
    blocks[#blocks + 1] = { type = 'actions', items = acts }
    blocks[#blocks + 1] = { type = 'table', title = 'Informations', columns = { { k = 'k', label = '' }, { k = 'v', label = '' } }, rows = (function() local r = {} for _, i in ipairs(info) do r[#r + 1] = { k = i[1], v = i[2] } end return r end)() }
    return blocks, h.label
end
PAGES.access = function(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= p.license then return { { type = 'notice', tone = 'info', text = 'Seul le propriétaire gère les accès.' } }, 'Accès' end
    local rows, opts = {}, {}
    for _, g in ipairs(Hs.Guests(h.id)) do
        rows[#rows + 1] = { who = ((g.firstname or '') .. ' ' .. (g.lastname or '')):gsub('^%s+', ''), since = os.date('%d/%m/%Y', g.at), actions = { { act = 'revoke', label = 'Retirer', danger = true, payload = { license = g.license } } } }
    end
    for id, pl in pairs(G.Players()) do if id ~= src and PB.ToBool(pl.row.created) and G.DistBetween(src, id) <= 8 then opts[#opts + 1] = { tostring(id), display(id) .. ' (' .. id .. ')' } end end
    return { { type = 'form', id = 'invite', title = 'Ajouter un colocataire (personne proche)', desc = 'Il reçoit les clés : il entre, ferme ou ouvre la porte, utilise le coffre commun et peut payer le loyer.', fields = { { k = 'id', type = 'select', label = 'Personne', opts = opts } }, submit = { act = 'invite', label = 'Donner l\'accès', disabled = #opts == 0 } },
        { type = 'table', title = 'Colocataires', columns = { { k = 'who', label = 'Personne' }, { k = 'since', label = 'Depuis le' } }, rows = rows, empty = 'Personne d\'autre n\'a accès à ce logement.' } }, 'Accès'
end

PAGES.interior = function(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= p.license then return { { type = 'notice', tone = 'info', text = 'Seul le propriétaire choisit l\'intérieur.' } }, 'Intérieur' end
    local vip = (G.Vip and G.Vip.Is(src)) or isPremium(h)
    if cfg('interior_vip', true) ~= false and not vip then return { { type = 'notice', tone = 'warn', text = 'Changer d\'intérieur et poser des meubles est réservé aux VIP.' } }, 'Intérieur' end
    local items = {}
    for _, it in ipairs(INTERIORS) do items[#items + 1] = { act = 'interior', label = it.label .. ((math.abs((h.ix or 0) - it.x) < 1 and math.abs((h.iy or 0) - it.y) < 1) and ' (actuel)' or ''), payload = { preset = it.id } } end
    return { { type = 'notice', tone = 'info', text = "Chaque logement est instancié : tu es seul chez toi (avec tes invités). Les meubles se posent à l'intérieur : E › Meubles." },
        { type = 'actions', items = items } }, 'Intérieur'
end

local function frame(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    local nav = { { id = 'home', label = 'Logement', icon = 'home', group = 'Logement' } }
    if h and h.owner == p.license then nav[#nav + 1] = { id = 'access', label = 'Colocation', icon = 'lock', group = 'Logement' } end
    if h and h.owner == p.license then nav[#nav + 1] = { id = 'interior', label = 'Intérieur', icon = 'home', group = 'Logement' } end
    return { name = display(src), id = (G.UidOf(src) or src), nav = nav, tone = '#dfe2e7', brand = h and h.label or 'Logement', cash = p.row.cash, bank = p.row.bank }
end
local function page(src, name)
    local s = sessions[src]
    local fn = s and PAGES[name or 'home']
    if not fn or not Hs.Get(s.id) then return nil end
    local blocks, title = fn(src, s)
    local clean = {}
    for _, b in ipairs(blocks) do if b then clean[#clean + 1] = b end end
    return { page = name or 'home', title = title, blocks = clean }
end
local function ui(src, ev, extra)
    local s = sessions[src]
    local msg = { ev = ev, frame = frame(src, s) }
    for k, v in pairs(extra or {}) do msg[k] = v end
    TriggerClientEvent('pb:g:housing:ui', src, PB.Json(msg))
end

RegisterNetEvent('pb:g:housing:open', function(id)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not cfg('enabled', true) or not usable(src) or not throttle(src, 400) then return end
    local h = Hs.Get(id)
    if not h or not PB.ToBool(h.enabled) or not near(src, h) then return end
    sessions[src] = { id = h.id }
    ui(src, 'open', { page = page(src, 'home') })
end)
RegisterNetEvent('pb:g:housing:page', function(name)
    local src = source
    if not sessions[src] or not throttle(src, 150) then return end
    local pg = page(src, tostring(name))
    ui(src, 'page', { page = pg, err = pg == nil and 'Page indisponible.' or nil })
end)
RegisterNetEvent('pb:g:housing:close', function() sessions[source] = nil end)
AddEventHandler('playerDropped', function() sessions[source] = nil last[tostring(source)] = nil end)

-- Actions --------------------------------------------------------------------------------------------------------------------------------
local ACT = {}
local function mine(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if not h or h.owner ~= p.license then return nil end
    return h, p
end

-- Commission de l'agence immobilière (entreprise réglable) sur chaque achat et chaque première location
local function realtorCommission(amount, what, license)
    local biz = tostring(cfg('realtor_biz', 'realestate') or '')
    local pct = tonumber(cfg('realtor_pct', 5)) or 0
    if biz == '' or pct <= 0 or not G.Eco or not (G.Biz and G.Biz.Get(biz)) then return end
    local c = math.floor(amount * pct / 100)
    if c <= 0 then return end
    G.Eco.Book('state', -c, 'Commission agence : ' .. what, license)
    G.Eco.Book('biz:' .. biz, c, 'Commission : ' .. what, license)
    for s in pairs(G.Players()) do
        local j = G.Biz.Job(s)
        if j and j.biz == biz and j.onDuty then G.Notify(s, { type = 'success', title = 'Agence immobilière', text = ('Commission de %s : %s.'):format(money(c), what) }) end
    end
end

local function keyHolder(src, s)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if not h or h.owner == '' then return nil end
    if h.owner == p.license then return h, p, true end
    if DB.one('SELECT prop FROM pb_property_access WHERE prop = ? AND license = ?', { h.id, p.license }) then return h, p, false end
end
ACT.buy = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= '' then return false, 'Ce logement est déjà pris.' end
    if isPremium(h) then return false, 'Cette villa se prend avec des coins dans la boutique du serveur (/boutique).' end
    if h.kind ~= 'buy' then return false, 'Ce logement est à louer.' end
    if #Hs.OwnedBy(p.license) >= cfg('max_owned', 2) then return false, 'Tu as atteint le maximum de logements.' end
    local acc = G.Pay(src, h.price, 'bank')
    if not acc then return false, ('Il te faut %s.'):format(money(h.price)) end
    local ok = DB.exec("UPDATE pb_properties SET owner = ?, since = ?, paid_until = 0, arrears = 0, locked = 1 WHERE id = ? AND owner = ''", { p.license, now(), h.id })
    if (tonumber(ok) or 0) == 0 then G.AddMoney(src, acc, h.price, 'Remboursement logement') return false, 'Un autre joueur vient de le prendre.' end
    if G.Eco then G.Eco.Book('state', h.price, 'Achat logement ' .. h.id, p.license) end
    realtorCommission(h.price, 'vente de ' .. h.label, p.license)
    TriggerEvent('pb_panel:propertyBought', src, h.id, h.price)
    G.PushConfig()   -- le point n'est plus « à vendre » pour personne
    return true, ('Bienvenue chez toi ! %s acheté.'):format(h.label)
end
ACT.rent = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.owner ~= '' then return false, 'Ce logement est déjà pris.' end
    if h.kind ~= 'rent' then return false, 'Ce logement est à vendre.' end
    if #Hs.OwnedBy(p.license) >= cfg('max_owned', 2) then return false, 'Tu as atteint le maximum de logements.' end
    local acc = G.Pay(src, h.rent, 'bank')
    if not acc then return false, ('Il te faut %s pour la première période.'):format(money(h.rent)) end
    local ok = DB.exec("UPDATE pb_properties SET owner = ?, since = ?, paid_until = ?, arrears = 0, locked = 1 WHERE id = ? AND owner = ''", { p.license, now(), now() + period(), h.id })
    if (tonumber(ok) or 0) == 0 then G.AddMoney(src, acc, h.rent, 'Remboursement loyer') return false, 'Un autre joueur vient de le prendre.' end
    if G.Eco then G.Eco.Book('state', h.rent, 'Loyer ' .. h.id, p.license) end
    realtorCommission(h.rent, 'location de ' .. h.label, p.license)
    G.PushConfig()
    return true, ('Location commencée : %s.'):format(h.label)
end
-- Remise des clés par un agent immobilier (menu ALT › une personne › Remettre les clés) ------------------------------------------------------
-- Logement libre de l'agence devant l'agent : à vendre -> clé définitive au prix de l'annonce ; à louer -> l'agent choisit la durée (jours),
-- le client paie le loyer de cette durée. Le client accepte ou refuse (60 s) ; le serveur revérifie tout au moment où il accepte.
local offers = {}   -- src du client -> offre en attente
AddEventHandler('playerDropped', function() offers[source] = nil end)
local function rentFor(h, days) return math.max(1, math.ceil((tonumber(h.rent) or 0) * days / math.max(1, tonumber(cfg('rent_days', 7)) or 7))) end
function Re.KeysStart(src, t)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h, err = nearestListed(src, 6) if not h then return false, err end
    local tp = G.Get(tonumber(t) or -1)
    if not tp or tonumber(t) == src then return false, 'Personne introuvable.' end
    if G.DistBetween(src, t) > 5 then return false, 'Le client doit être à côté de toi.' end
    if h.kind == 'rent' then
        TriggerClientEvent('pb:g:realtor:days', src, PB.Json({ t = tonumber(t), id = h.id, label = h.label, rent = h.rent, period = tonumber(cfg('rent_days', 7)) or 7 }))
        return true, nil
    end
    return Re.KeysOffer(src, t, h.id, 0)
end
function Re.KeysOffer(src, t, id, days)
    if not Re.IsAgent(src) then return false, "Réservé aux agents immobiliers en service." end
    local h = Hs.Get(id)
    if not h or h.owner ~= '' or h.listed_by ~= (Re.Biz() or '') then return false, "Ce logement n'est plus libre." end
    local tp = G.Get(tonumber(t) or -1)
    if not tp then return false, 'Personne introuvable.' end
    if G.DistBetween(src, t) > 5 then return false, 'Le client doit être à côté de toi.' end
    local rent = h.kind == 'rent'
    days = rent and math.max(1, math.min(30, math.floor(tonumber(days) or 0))) or 0
    if rent and days < 1 then return false, 'Durée invalide.' end
    local price = rent and rentFor(h, days) or math.floor(tonumber(h.price) or 0)
    local token = tostring(math.random(100000, 999999))
    offers[tonumber(t)] = { token = token, agent = src, id = h.id, days = days, price = price, rent = rent, at = os.time() }
    TriggerClientEvent('pb:g:realtor:offer', t, PB.Json({ token = token, label = h.label, rent = rent, days = days, price = price, agent = nameOf(G.Get(src).license) }))
    return true, rent and ('Offre envoyée : location de « %s » pour %d jour(s), %s.'):format(h.label, days, money(price)) or ('Offre envoyée : vente de « %s » pour %s.'):format(h.label, money(price))
end
RegisterNetEvent('pb:g:realtor:days', function(t, id, days)
    local src = source
    local ok, msg = Re.KeysOffer(src, t, tostring(id or ''), days)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Agence immobilière', text = msg })
end)
RegisterNetEvent('pb:g:realtor:answer', function(token, accept)
    local src = source
    local o = offers[src]
    if not o or o.token ~= tostring(token or '') then return end
    offers[src] = nil
    local agent = o.agent
    local function both(kind, text) G.Notify(src, { type = kind, title = 'Agence immobilière', text = text }) if G.Get(agent) then G.Notify(agent, { type = kind, title = 'Agence immobilière', text = text }) end end
    if accept ~= true then both('warn', "Offre refusée.") return end
    if os.time() - o.at > 60 then both('error', "L'offre a expiré.") return end
    if not G.Get(agent) or not Re.IsAgent(agent) or G.DistBetween(src, agent) > 8 then both('error', "L'agent n'est plus là.") return end
    local p = G.Get(src)
    local h = Hs.Get(o.id)
    if not p or not h or h.owner ~= '' then both('error', "Ce logement n'est plus libre.") return end
    if #Hs.OwnedBy(p.license) >= cfg('max_owned', 2) then both('error', 'Le client a atteint le maximum de logements.') return end
    local acc = G.Pay(src, o.price, 'bank')
    if not acc then both('error', ('Il faut %s sur le compte du client.'):format(money(o.price))) return end
    local until_ = o.rent and (now() + o.days * 86400) or 0
    local ok = DB.exec("UPDATE pb_properties SET owner = ?, since = ?, paid_until = ?, arrears = 0, locked = 1 WHERE id = ? AND owner = ''", { p.license, now(), until_, h.id })
    if (tonumber(ok) or 0) == 0 then G.AddMoney(src, acc, o.price, 'Remboursement logement') both('error', 'Un autre joueur vient de le prendre.') return end
    if G.Eco then G.Eco.Book('state', o.price, (o.rent and 'Loyer ' or 'Achat logement ') .. h.id, p.license) end
    realtorCommission(o.price, (o.rent and 'location de ' or 'vente de ') .. h.label, p.license)
    PB.Audit.Log('serveur', o.rent and 'realtor.keys.rent' or 'realtor.keys.sale', agent, h.label, nil, nil, { client = p.license, price = o.price, days = o.days })
    if not o.rent then TriggerEvent('pb_panel:propertyBought', src, h.id, o.price) end
    G.PushConfig()
    if Hs.PushMine then Hs.PushMine(src) end
    both('success', o.rent and ('Clés remises : « %s » loué %d jour(s) (jusqu\'au %s).'):format(h.label, o.days, os.date('%d/%m', until_)) or ('Clés remises : « %s » vendu, il est à son nouveau propriétaire.'):format(h.label))
end)
ACT.pay = function(s, src)
    local h, p = keyHolder(src, s)
    if not h then return false, 'Rien à payer.' end
    if h.kind == 'buy' then
        -- impôt foncier en retard
        local tax = math.floor(h.price * (tonumber(cfg('tax_pct', 1)) or 0) / 100)
        local total = math.max(1, h.arrears or 0) * tax
        if (h.arrears or 0) <= 0 or total <= 0 then return false, 'Rien à payer.' end
        if not G.Pay(src, total, 'bank') then return false, ('Il te faut %s.'):format(money(total)) end
        DB.exec('UPDATE pb_properties SET arrears = 0, tax_until = ? WHERE id = ?', { now() + period(), h.id })
        if G.Eco then G.Eco.Book('state', total, 'Impôt foncier ' .. h.id, p.license) end
        return true, ('Impôt foncier réglé (%s).'):format(money(total))
    end
    local periods = math.max(1, h.arrears or 0)
    local total = periods * h.rent
    local acc = G.Pay(src, total, 'bank')
    if not acc then return false, ('Il te faut %s.'):format(money(total)) end
    -- impayé : la période repart d'aujourd'hui ; sinon on prolonge d'une période
    local newUntil = (h.arrears or 0) > 0 and (now() + period()) or (math.max(h.paid_until, now()) + period())
    DB.exec('UPDATE pb_properties SET arrears = 0, paid_until = ? WHERE id = ?', { newUntil, h.id })
    if G.Eco then G.Eco.Book('state', total, 'Loyer ' .. h.id, p.license) end
    return true, ('Loyer réglé (%s).'):format(money(total))
end
ACT.lock = function(s, src)
    local h = keyHolder(src, s)
    if not h then return false, 'Il te faut les clés de ce logement.' end
    if inArrears(h) then return false, 'Accès suspendu : règle ton loyer.' end
    local l = PB.ToBool(h.locked) and 0 or 1
    DB.exec('UPDATE pb_properties SET locked = ? WHERE id = ?', { l, h.id })
    return true, l == 1 and 'Porte verrouillée.' or 'Porte déverrouillée.'
end
ACT.leave = function(s, src)
    local h, p = mine(src, s)
    if not h then return false, 'Ce logement n\'est pas à toi.' end
    if isPremium(h) then return false, 'Une villa de la boutique ne se revend pas : elle reste à toi.' end
    if inArrears(h) then return false, 'Règle d\'abord ton loyer impayé.' end
    if not Hs.StashEmpty(h.id) then return false, 'Vide d\'abord le coffre du logement.' end
    local refund = 0
    if h.kind == 'buy' then
        refund = math.floor(h.price * cfg('sell_ratio', 70) / 100)
        if G.Eco and G.Eco.Balance('state') < refund then return false, "La banque d'État n'a pas les fonds pour te racheter ce logement." end
    end
    DB.exec("UPDATE pb_properties SET owner = '', since = 0, paid_until = 0, arrears = 0, locked = 1 WHERE id = ?", { h.id })
    DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    if refund > 0 then G.AddMoney(src, 'bank', refund, 'Vente logement') if G.Eco then G.Eco.Book('state', -refund, 'Rachat logement ' .. h.id, p.license) end end
    return true, h.kind == 'buy' and ('Logement vendu : %s reçus en banque.'):format(money(refund)) or 'Location résiliée.'
end
ACT.invite = function(s, src, p)
    local h, me = mine(src, s)
    if not h then return false, 'Seul le propriétaire donne un accès.' end
    if inArrears(h) then return false, 'Accès suspendu : règle ton loyer.' end
    local id = tonumber(p.id)
    local tp = id and G.Get(id)
    if not tp or id == src or not PB.ToBool(tp.row.created) then return false, 'Choisis une personne proche.' end
    if G.DistBetween(src, id) > 10 then return false, 'Cette personne est trop loin.' end
    if #Hs.Guests(h.id) >= cfg('guests_max', 6) then return false, ('Maximum %d personnes avec accès.'):format(cfg('guests_max', 6)) end
    DB.exec('INSERT IGNORE INTO pb_property_access (prop, license, by_license, at) VALUES (?, ?, ?, ?)', { h.id, tp.license, me.license, now() })
    G.Notify(id, { type = 'info', title = 'Accès reçu', text = ('Tu as maintenant accès à « %s ».'):format(h.label) })
    return true, ('Accès donné à %s.'):format(display(id))
end
ACT.revoke = function(s, src, p)
    local h = mine(src, s)
    if not h then return false, 'Seul le propriétaire retire un accès.' end
    DB.exec('DELETE FROM pb_property_access WHERE prop = ? AND license = ?', { h.id, tostring(p.license or '') })
    return true, 'Accès retiré.'
end
ACT.consigne = function(s, src)
    local p = G.Get(src)
    local cons = Hs.ConsigneOwner(p.license)
    local mine = G.Inv.PlayerOwner(src)
    local got, left = 0, 0
    for _, r in ipairs(DB.q('SELECT slot, item, qty FROM pb_inv WHERE owner = ? ORDER BY slot', { cons }) or {}) do
        -- retrait d'abord (une seule suppression réussit, même en double-clic), puis ajout ; remis en place si l'ajout échoue
        if G.Inv.CanCarry(mine, r.item, r.qty) and (tonumber(DB.exec('DELETE FROM pb_inv WHERE owner = ? AND slot = ?', { cons, r.slot })) or 0) > 0 then
            if G.Inv.Add(mine, r.item, r.qty) then got = got + 1
            else DB.insert('INSERT INTO pb_inv (owner, slot, item, qty) VALUES (?, ?, ?, ?)', { cons, r.slot, r.item, r.qty }) left = left + 1 end
        else left = left + 1 end
    end
    if G.Inv.Push then pcall(G.Inv.Push, src) end
    if got == 0 and left == 0 then return false, 'Rien à la consigne.' end
    if left > 0 then return true, ('%d objet(s) récupéré(s) ; %d ne rentrent pas dans ton sac : fais de la place et reviens.'):format(got, left) end
    return true, 'Toutes tes affaires sont récupérées.'
end
ACT.stash = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if not Hs.HasAccess(p.license, h) then return false, 'Tu n\'as pas accès au coffre.' end
    TriggerClientEvent('pb:g:housing:stash', src, Hs.StashOwner(h.id))
    return true, 'Coffre ouvert.'
end
ACT.interior = function(s, src, payload)
    local h = mine(src, s)
    if not h then return false, 'Ce logement n\'est pas à toi.' end
    if cfg('interior_vip', true) ~= false and not (G.Vip and G.Vip.Is(src)) and not isPremium(h) then return false, 'Réservé aux VIP.' end
    local pick
    for _, it in ipairs(INTERIORS) do if it.id == tostring(payload and payload.preset or '') then pick = it end end
    if not pick then return false, 'Choisis un intérieur dans l\'onglet « Intérieur ».' end
    DB.exec('UPDATE pb_properties SET ix = ?, iy = ?, iz = ?, ih = ? WHERE id = ?', { pick.x, pick.y, pick.z, pick.h, h.id })
    -- les meubles de l'ancien intérieur reviennent : dans le sac, ou à la consigne s'il n'y a plus de place
    if itemsMode() then
        local me = G.Inv.PlayerOwner(src)
        for _, r in ipairs(DB.q('SELECT model FROM pb_property_furniture WHERE prop = ?', { h.id }) or {}) do
            local f = FURN_BY[r.model]
            if f and not G.Inv.Add(me, f.item, 1) then G.Inv.Add(Hs.ConsigneOwner(h.owner), f.item, 1) end
        end
        if G.Inv.Push then pcall(G.Inv.Push, src) end
    end
    DB.exec('DELETE FROM pb_property_furniture WHERE prop = ?', { h.id })
    return true, ('Intérieur : %s. Les meubles de l\'ancien intérieur ont été rangés%s.'):format(pick.label, itemsMode() and ' dans ton sac' or '')
end
local rings = {}   -- logement -> { src, exp }
ACT.ring = function(s, src)
    local h = Hs.Get(s.id)
    if not h or h.owner == '' then return false, 'Personne n\'habite ici.' end
    if rings[h.id] and rings[h.id].exp > now() and rings[h.id].src == src then return false, 'Tu as déjà sonné : patiente.' end
    rings[h.id] = { src = src, exp = now() + 60 }
    local n = 0
    for id, pl in pairs(G.Players()) do
        if id ~= src and Hs.HasAccess(pl.license, h) then
            n = n + 1
            G.Notify(id, { type = 'info', title = 'Ça sonne !', text = ('%s sonne à « %s ». Tape /ouvrir pour lui ouvrir (1 minute).'):format(display(src), h.label), duration = 12000 })
        end
    end
    return true, n > 0 and 'Tu as sonné. Attends qu\'on t\'ouvre.' or 'Tu as sonné… personne ne répond.'
end
-- /ouvrir : laisse entrer la dernière personne qui a sonné à un de tes logements
RegisterCommand('ouvrir', function(src)
    if src == 0 then return end
    local p = G.Get(src)
    if not p then return end
    for id, r in pairs(rings) do
        local h = Hs.Get(id)
        if h and r.exp > now() and Hs.HasAccess(p.license, h) and G.Get(r.src) then
            rings[id] = nil
            if h.ix ~= 0 or h.iy ~= 0 then
                insideOf[r.src] = h.id
                SetPlayerRoutingBucket(r.src, bucketOf(h.id))
                TriggerClientEvent('pb:g:housing:teleport', r.src, PB.Json({ x = h.ix, y = h.iy, z = h.iz, h = h.ih, id = h.id, label = h.label, furn = Hs.Furniture(h.id) }))
            else
                DB.exec('UPDATE pb_properties SET locked = 0 WHERE id = ?', { h.id })
                SetTimeout(60000, function() DB.exec('UPDATE pb_properties SET locked = 1 WHERE id = ?', { h.id }) end)
                G.Notify(r.src, { type = 'success', title = h.label, text = 'La porte est ouverte (1 minute).' })
            end
            G.Notify(src, { type = 'success', title = h.label, text = display(r.src) .. ' entre.' })
            return
        end
    end
    G.Notify(src, { type = 'warn', title = 'Logement', text = 'Personne ne sonne chez toi en ce moment.' })
end, false)
function Hs.Furniture(id)
    local out = {}
    for _, r in ipairs(DB.q('SELECT id, model, x, y, z, h FROM pb_property_furniture WHERE prop = ?', { tostring(id) }) or {}) do out[#out + 1] = { id = r.id, m = r.model, x = r.x, y = r.y, z = r.z, h = r.h } end
    return out
end
ACT.enter = function(s, src)
    local p = G.Get(src)
    local h = Hs.Get(s.id)
    if h.ix == 0 and h.iy == 0 then return false, 'Pas d\'intérieur configuré : entre par la porte du bâtiment.' end
    local visit = h.owner == '' and (Re.Visiting(p.license, h.id) or (Re.IsAgent(src) and h.listed_by == Re.Biz()))
    if not (visit or Hs.HasAccess(p.license, h) or (h.owner ~= '' and not PB.ToBool(h.locked))) then return false, 'La porte est verrouillée.' end
    insideOf[src] = h.id
    SetPlayerRoutingBucket(src, bucketOf(h.id))   -- intérieur instancié : chacun chez soi
    TriggerClientEvent('pb:g:housing:teleport', src, PB.Json({ x = h.ix, y = h.iy, z = h.iz, h = h.ih, id = h.id, label = h.label, furn = Hs.Furniture(h.id) }))
    return true, 'Entrée.'
end

RegisterNetEvent('pb:g:housing:act', function(name, payload, pgname)
    local src = source
    local s = sessions[src]
    if not s or not usable(src) or not throttle(src, 400) then return end
    local fn = ACT[tostring(name)]
    local ok, msg = false, 'Action inconnue.'
    local h = Hs.Get(s.id)
    if fn and h then
        if not near(src, h, cfg('use_distance', 2.5) + 8) then ok, msg = false, 'Tu es trop loin.'
        else ok, msg = fn(s, src, type(payload) == 'table' and payload or {}) end
    end
    ui(src, 'result', { ok = ok and true or false, msg = msg, page = page(src, tostring(pgname or 'home')) })
end)

-- Sortie de l'intérieur : retour devant la porte
RegisterNetEvent('pb:g:housing:exit', function(id)
    local src = source
    local h = usable(src) and Hs.Get(id)
    if not h or not throttle(src, 800) then return end
    local p = G.Get(src)
    if not (Hs.HasAccess(p.license, h) or h.ix ~= 0) then return end
    if h.ix ~= 0 and G.DistTo(src, h.ix, h.iy, h.iz) > 60 then return end
    insideOf[src] = nil
    SetPlayerRoutingBucket(src, 0)
    TriggerClientEvent('pb:g:housing:teleport', src, PB.Json({ x = h.x, y = h.y, z = h.z, h = 0, exit = true }))
end)
AddEventHandler('playerDropped', function() insideOf[source] = nil end)

-- Meubles (VIP) et aquarium : posés dans l'intérieur, visibles par tous ceux qui sont dans le même logement
local function canDecorate(src, id)
    local p = G.Get(src)
    local h = Hs.Get(id)
    if not h or insideOf[src] ~= h.id then return nil, 'Entre dans le logement.' end
    if not Hs.HasAccess(p.license, h) then return nil, 'Il te faut les clés de ce logement.' end
    if cfg('furniture_vip', true) ~= false and not itemsMode() and not (G.Vip and G.Vip.Is(src)) and not isPremium(h) then return nil, 'Les meubles sont réservés aux VIP.' end
    return h
end
local function pushFurniture(id) local list = PB.Json(Hs.Furniture(id)) for s, pid in pairs(insideOf) do if pid == id then TriggerClientEvent('pb:g:housing:furn', s, list) end end end
RegisterNetEvent('pb:g:housing:furncat', function()
    local src = source
    local h, why = canDecorate(src, insideOf[src])
    if not h then G.Notify(src, { type = 'warn', title = 'Meubles', text = why }) return end
    if not itemsMode() then TriggerClientEvent('pb:g:housing:furncat', src, PB.Json(FURNITURE)) return end
    -- mode objets : seulement les meubles qu'on a dans le sac
    local me, list = G.Inv.PlayerOwner(src), {}
    for _, f in ipairs(FURNITURE) do
        local n = G.Inv.Count(me, f.item)
        if n > 0 then list[#list + 1] = { model = f.model, label = f.label, aquarium = f.aquarium, qty = n } end
    end
    if #list == 0 then G.Notify(src, { type = 'info', title = 'Meubles', text = "Tu n'as aucun meuble dans ton sac : achète-en au Magasin de meubles." }) return end
    TriggerClientEvent('pb:g:housing:furncat', src, PB.Json(list))
end)
RegisterNetEvent('pb:g:housing:furnadd', function(model, x, y, z, hd)
    local src = source
    if not throttle(src, 500) then return end
    local h, why = canDecorate(src, insideOf[src])
    if not h then G.Notify(src, { type = 'warn', title = 'Meubles', text = why }) return end
    if not FURN_BY[tostring(model)] then return end
    x, y, z, hd = tonumber(x), tonumber(y), tonumber(z), tonumber(hd) or 0
    if not x or not y or not z or #(vector3(x, y, z) - vector3(h.ix, h.iy, h.iz)) > 40 or G.DistTo(src, x, y, z) > 12 then return end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_property_furniture WHERE prop = ?', { h.id })
    if n and tonumber(n.n) >= (tonumber(cfg('furniture_max', 60)) or 60) then G.Notify(src, { type = 'error', title = 'Meubles', text = 'Nombre maximum de meubles atteint.' }) return end
    if itemsMode() then
        local f = FURN_BY[tostring(model)]
        if not G.Inv.Remove(G.Inv.PlayerOwner(src), f.item, 1) then G.Notify(src, { type = 'error', title = 'Meubles', text = "Ce meuble n'est plus dans ton sac." }) return end
        if G.Inv.Push then pcall(G.Inv.Push, src) end
    end
    DB.insert('INSERT INTO pb_property_furniture (prop, model, x, y, z, h) VALUES (?, ?, ?, ?, ?, ?)', { h.id, tostring(model), x, y, z, hd })
    pushFurniture(h.id)
end)
RegisterNetEvent('pb:g:housing:furndel', function(fid)
    local src = source
    if not throttle(src, 500) then return end
    local h, why = canDecorate(src, insideOf[src])
    if not h then G.Notify(src, { type = 'warn', title = 'Meubles', text = why }) return end
    local r = DB.one('SELECT model FROM pb_property_furniture WHERE id = ? AND prop = ?', { tonumber(fid) or -1, h.id })
    if not r then return end
    local f = itemsMode() and FURN_BY[r.model]
    if f and G.Inv.CanCarry and not G.Inv.CanCarry(G.Inv.PlayerOwner(src), f.item, 1) then G.Notify(src, { type = 'error', title = 'Meubles', text = 'Ton sac est plein.' }) return end
    if (tonumber(DB.exec('DELETE FROM pb_property_furniture WHERE id = ? AND prop = ?', { tonumber(fid) or -1, h.id })) or 0) < 1 then return end
    if f then
        G.Inv.Add(G.Inv.PlayerOwner(src), f.item, 1)
        if G.Inv.Push then pcall(G.Inv.Push, src) end
        G.Notify(src, { type = 'success', title = 'Meubles', text = f.label .. ' rangé dans ton sac.' })
    end
    pushFurniture(h.id)
end)
-- Aquarium : on y dépose les poissons pêchés (objets « fish_… »), qu'on peut admirer ou reprendre
RegisterNetEvent('pb:g:housing:aquarium', function(action, arg)
    local src = source
    if not throttle(src, 600) then return end
    local p = G.Get(src)
    local id = insideOf[src]
    local h = id and Hs.Get(id)
    if not h or not Hs.HasAccess(p.license, h) then return end
    if not DB.one("SELECT id FROM pb_property_furniture WHERE prop = ? AND model = 'prop_aquarium_01'", { h.id }) then G.Notify(src, { type = 'warn', title = 'Aquarium', text = 'Pose d\'abord un aquarium (meubles VIP).' }) return end
    local owner = 'p:' .. p.license
    if action == 'put' then
        local item = tostring(arg or '')
        if not item:match('^fish_[%w_]+$') or G.Inv.Count(owner, item) < 1 then return end
        local n = DB.one('SELECT COUNT(*) AS n FROM pb_property_aquarium WHERE prop = ?', { h.id })
        if n and tonumber(n.n) >= 12 then G.Notify(src, { type = 'warn', title = 'Aquarium', text = 'L\'aquarium est plein (12 poissons).' }) return end
        if not G.Inv.Remove(owner, item, 1) then return end
        local d = G.Inv.Def(item)
        DB.insert('INSERT INTO pb_property_aquarium (prop, item, label, at) VALUES (?, ?, ?, ?)', { h.id, item, d and d.label or item, now() })
        if G.Inv.Push then G.Inv.Push(src) end
    elseif action == 'take' then
        local r = DB.one('SELECT * FROM pb_property_aquarium WHERE id = ? AND prop = ?', { tonumber(arg) or -1, h.id })
        if not r then return end
        -- on retire d'abord (une seule suppression réussit), puis on donne ; si le sac est plein, le poisson retourne dans l'aquarium
        if (tonumber(DB.exec('DELETE FROM pb_property_aquarium WHERE id = ?', { r.id })) or 0) < 1 then return end
        if not G.Inv.Add(owner, r.item, 1) then
            DB.insert('INSERT INTO pb_property_aquarium (prop, item, label, at) VALUES (?, ?, ?, ?)', { h.id, r.item, r.label, r.at or now() })
            G.Notify(src, { type = 'warn', title = 'Aquarium', text = 'Ton sac est plein.' })
            return
        end
        if G.Inv.Push then G.Inv.Push(src) end
    end
    local fish, mineFish = {}, {}
    for _, r in ipairs(DB.q('SELECT id, item, label FROM pb_property_aquarium WHERE prop = ? ORDER BY id', { h.id }) or {}) do fish[#fish + 1] = { id = r.id, label = r.label } end
    for slot, it in pairs(G.Inv.Contents(owner)) do if tostring(it.item):match('^fish_') then local d = G.Inv.Def(it.item) mineFish[#mineFish + 1] = { item = it.item, label = d and d.label or it.item, qty = it.qty } end end
    TriggerClientEvent('pb:g:housing:aquarium', src, PB.Json({ fish = fish, mine = mineFish }))
end)

-- Expulsion et consigne -------------------------------------------------------------------------------------------------------------
-- Consigne : affaires d'un locataire expulsé (inventaire 'e:<licence>'), rendues à la demande à n'importe quel logement
function Hs.ConsigneOwner(license) return 'e:' .. tostring(license) end
function Hs.ConsigneCount(license)
    local r = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { Hs.ConsigneOwner(license) })
    return r and tonumber(r.n) or 0
end
local function sms(license, body) if G.Phone and G.Phone.Notice then pcall(G.Phone.Notice, license, 'logement', body) end end
function Hs.Evict(h, why)
    if not h or h.owner == '' then return false end
    local license = h.owner
    local cons = Hs.ConsigneOwner(license)
    local top = DB.one('SELECT COALESCE(MAX(slot), 0) AS m FROM pb_inv WHERE owner = ?', { cons })
    DB.exec('UPDATE pb_inv SET owner = ?, slot = slot + ? WHERE owner = ?', { cons, (top and tonumber(top.m) or 0), Hs.StashOwner(h.id) })
    local debt = math.max(0, h.arrears or 0) * (h.rent or 0)
    local agency = Re.Biz() and G.Biz and G.Biz.Get(Re.Biz())
    if debt > 0 and agency then
        DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            { agency.id, license, nameOf(license), debt, ('Loyers impayés : %s'):format(h.label):sub(1, 120), 'invoice', 'pending', agency.label, '', now() })
    end
    DB.exec("UPDATE pb_properties SET owner = '', since = 0, paid_until = 0, arrears = 0, locked = 1 WHERE id = ?", { h.id })
    DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    sms(license, ('Vous êtes expulsé(e) de « %s » (%s).%s Vos affaires sont à la consigne : récupérez-les à la porte de n\'importe quel logement.'):format(h.label, why or 'loyers impayés',
        (debt > 0 and agency) and (' Dette transmise à %s : %s.'):format(agency.label, money(debt)) or ''))
    if G.Timeline then G.Timeline.Add(license, 'house', ('Expulsé(e) de « %s » (%s)'):format(h.label, why or 'loyers impayés'), 'bad') end
    PB.Audit.Log('serveur', 'housing.evict', 'système', h.id, { owner = license, arrears = h.arrears }, { owner = '' }, { dette = debt })
    G.PushConfig()
    return true
end
local function maybeEvict(id)
    if cfg('evict', true) == false then return end
    local h = Hs.Get(id)
    if h and h.kind == 'rent' and h.owner ~= '' and (h.arrears or 0) >= (tonumber(cfg('grace_periods', 3)) or 3) then Hs.Evict(h, ('%d loyers impayés'):format(h.arrears)) end
end
Hs.MaybeEvict = maybeEvict
-- Locataires hors ligne : le loyer est prélevé sur leur compte en banque (base de données), sinon l'impayé s'accumule
function Hs.SettleOffline()
    local online = {}
    for _, p in pairs(G.Players()) do online[p.license] = true end
    for _, h in ipairs(ecoAll(DB.q("SELECT * FROM pb_properties WHERE owner <> '' AND kind = 'rent' AND paid_until > 0 AND paid_until <= ?", { now() }))) do
        if not online[h.owner] then
            local due = math.floor((now() - h.paid_until) / period()) + 1
            local arrears, paid = h.arrears or 0, 0
            for _ = 1, due do
                if h.rent > 0 and DB.exec('UPDATE pb_players SET bank = bank - ? WHERE license = ? AND bank >= ?', { h.rent, h.owner, h.rent }) > 0 then
                    paid = paid + 1
                    if G.Eco then G.Eco.Book('state', h.rent, 'Loyer ' .. h.id, h.owner) end
                else arrears = arrears + 1 end
            end
            DB.exec('UPDATE pb_properties SET paid_until = ?, arrears = ? WHERE id = ?', { h.paid_until + due * period(), arrears, h.id })
            if arrears > (h.arrears or 0) then sms(h.owner, ('Loyer impayé pour « %s » : %s dus. Au-delà de %d loyers impayés, c\'est l\'expulsion.'):format(h.label, money(arrears * h.rent), tonumber(cfg('grace_periods', 3)) or 3)) end
            maybeEvict(h.id)
        end
    end
end
CreateThread(function() Wait(math.random(0, 600000)) while true do Wait(600000) pcall(Hs.SettleOffline) end end)

-- Loyers : toutes les minutes, pour les locataires en ligne ----------------------------------------------------------------------------
function Hs.Settle(src)
    local p = G.Get(src)
    if not p then return end
    for _, h in ipairs(ecoAll(DB.q("SELECT * FROM pb_properties WHERE owner = ? AND kind = 'rent' AND paid_until > 0 AND paid_until <= ?", { p.license, now() }))) do
        local due = math.floor((now() - h.paid_until) / period()) + 1
        local arrears = h.arrears or 0
        local paidPeriods = 0
        for _ = 1, due do
            if G.Pay(src, h.rent, 'bank') then
                paidPeriods = paidPeriods + 1
                if G.Eco then G.Eco.Book('state', h.rent, 'Loyer ' .. h.id, p.license) end
            else arrears = arrears + 1 end
        end
        DB.exec('UPDATE pb_properties SET paid_until = ?, arrears = ? WHERE id = ?', { h.paid_until + due * period(), math.min(arrears, cfg('grace_periods', 3) * 99), h.id })
        if arrears > (h.arrears or 0) then G.Notify(src, { type = 'error', title = 'Loyer impayé', text = ('%s : %s à régler. L\'accès est suspendu jusqu\'au paiement (expulsion au-delà de %d loyers impayés).'):format(h.label, money(arrears * h.rent), tonumber(cfg('grace_periods', 3)) or 3) })
        elseif paidPeriods > 0 then G.Notify(src, { type = 'info', title = 'Loyer prélevé', text = ('%s : %s prélevés.'):format(h.label, money(paidPeriods * h.rent)) }) end
        maybeEvict(h.id)
    end
end
-- Impôt foncier des logements achetés : un pourcentage du prix, à chaque période (comme le loyer)
function Hs.SettleTax(src)
    local p = G.Get(src)
    local pct = tonumber(cfg('tax_pct', 1)) or 0
    if not p or pct <= 0 then return end
    for _, h in ipairs(ecoAll(DB.q("SELECT * FROM pb_properties WHERE owner = ? AND kind = 'buy' AND premium = 0", { p.license }))) do
        local tax = math.floor(h.price * pct / 100)
        if (tonumber(h.tax_until) or 0) == 0 then DB.exec('UPDATE pb_properties SET tax_until = ? WHERE id = ?', { now() + period(), h.id })
        elseif tax > 0 and h.tax_until <= now() then
            local due = math.floor((now() - h.tax_until) / period()) + 1
            local arrears, paid = h.arrears or 0, 0
            for _ = 1, due do
                if G.Pay(src, tax, 'bank') then paid = paid + 1 if G.Eco then G.Eco.Book('state', tax, 'Impôt foncier ' .. h.id, p.license) end
                else arrears = arrears + 1 end
            end
            DB.exec('UPDATE pb_properties SET tax_until = ?, arrears = ? WHERE id = ?', { h.tax_until + due * period(), arrears, h.id })
            if arrears > (h.arrears or 0) then G.Notify(src, { type = 'error', title = 'Impôt foncier impayé', text = ('%s : %s à régler à la porte. L\'accès est suspendu jusqu\'au paiement.'):format(h.label, money(arrears * tax)) })
            elseif paid > 0 then G.Notify(src, { type = 'info', title = 'Impôt foncier', text = ('%s : %s prélevés.'):format(h.label, money(paid * tax)) }) end
        end
    end
end
CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            for src in pairs(G.Players()) do pcall(Hs.Settle, src) pcall(Hs.SettleTax, src) end
        end)
        if not ok then PB.Warn('housing', 'boucle : ' .. tostring(err)) end
    end
end)

function Hs.PushMine(src)
    local p = G.Get(src)
    if not p then return end
    local ids = {}
    for _, h in ipairs(Hs.OwnedBy(p.license)) do ids[#ids + 1] = h.id end
    for _, r in ipairs(DB.q('SELECT prop FROM pb_property_access WHERE license = ?', { p.license }) or {}) do ids[#ids + 1] = r.prop end
    TriggerClientEvent('pb:g:housing:mine', src, PB.Json(ids))
end
table.insert(G.beginHooks, function(src) Hs.PushMine(src) end)
local mineQueued = false
function G.HousingPoints()
    -- chaque envoi de la configuration (achat, vente, expulsion…) remet aussi à jour « mes logements » de chacun
    if not mineQueued then
        mineQueued = true
        SetTimeout(800, function() mineQueued = false for s in pairs(G.Players()) do pcall(Hs.PushMine, s) end end)
    end
    local out = {}
    for _, h in ipairs(Hs.All()) do
        if PB.ToBool(h.enabled) then out[#out + 1] = { id = h.id, label = h.label, kind = h.kind, x = h.x, y = h.y, z = h.z, free = h.owner == '' } end
    end
    return out
end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
PB.Action('housing.save', 'housing.edit', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
        { k = 'kind', type = 'select', label = 'Type', opts = { { 'buy', 'À vendre' }, { 'rent', 'À louer' } } },
        { k = 'price', type = 'number', label = 'Prix', min = 0, max = 100000000 }, { k = 'rent', type = 'number', label = 'Loyer', min = 0, max = 10000000 },
        { k = 'coords', type = 'coords', label = 'Porte' }, { k = 'inside', type = 'coords', label = 'Intérieur' }, { k = 'enabled', type = 'toggle', label = 'Actif' },
    }, { id = v.id, label = v.label, kind = v.kind or 'buy', price = v.price or 0, rent = v.rent or 0, coords = v.coords or { x = 0, y = 0, z = 0, h = 0 }, inside = v.inside or { x = 0, y = 0, z = 0, h = 0 }, enabled = v.enabled ~= false })
    if not c then return false, err end
    if c.coords.x == 0 and c.coords.y == 0 then return false, 'Place la porte sur la carte.' end
    if c.kind == 'buy' and c.price <= 0 then return false, 'Indique un prix de vente.' end
    if c.kind == 'rent' and c.rent <= 0 then return false, 'Indique un loyer.' end
    local before = Hs.Get(c.id)
    if before and before.owner ~= '' and before.kind ~= c.kind then return false, 'Libère le logement avant de changer son type.' end
    DB.exec('INSERT INTO pb_properties (id, label, kind, price, rent, x, y, z, ix, iy, iz, ih, enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), kind = VALUES(kind), price = VALUES(price), rent = VALUES(rent), x = VALUES(x), y = VALUES(y), z = VALUES(z), ix = VALUES(ix), iy = VALUES(iy), iz = VALUES(iz), ih = VALUES(ih), enabled = VALUES(enabled)',
        { c.id, c.label, c.kind, c.price, c.rent, c.coords.x, c.coords.y, c.coords.z, c.inside.x, c.inside.y, c.inside.z, c.inside.h, c.enabled and 1 or 0 })
    ctx.audit('config', before and 'housing.edit' or 'housing.create', c.id, before, c)
    G.PushConfig()
    ctx.toast = 'Logement enregistré.'
    return true
end)
PB.Action('housing.delete', 'housing.edit', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h then return false, 'Introuvable.' end
    if h.owner ~= '' then return false, 'Un joueur y vit : libère-le avant de le supprimer.' end
    if not Hs.StashEmpty(h.id) then return false, 'Le coffre contient des objets.' end
    DB.exec('DELETE FROM pb_properties WHERE id = ?', { h.id }) DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    ctx.audit('config', 'housing.delete', h.id, h, nil)
    G.PushConfig()
    ctx.toast = 'Logement supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce logement ?', text = 'Il disparaît de la carte.', danger = true } })
PB.Action('housing.release', 'housing.manage', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h or h.owner == '' then return false, 'Ce logement est déjà libre.' end
    DB.exec("UPDATE pb_properties SET owner = '', since = 0, paid_until = 0, arrears = 0, locked = 1 WHERE id = ?", { h.id })
    DB.exec('DELETE FROM pb_property_access WHERE prop = ?', { h.id })
    ctx.audit('serveur', 'housing.release', h.id, { owner = h.owner }, { owner = '' })
    ctx.toast = Hs.StashEmpty(h.id) and 'Logement libéré.' or 'Logement libéré. Attention : son coffre contient encore des objets.'
    return true
end, { critical = true, confirm = { title = 'Libérer ce logement ?', text = "L'occupant perd l'accès. Aucun remboursement n'est fait.", danger = true } })
PB.Action('housing.clear_stash', 'housing.manage', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h then return false, 'Introuvable.' end
    if h.owner ~= '' then return false, "Le logement est occupé : le contenu appartient à l'occupant." end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_inv WHERE owner = ?', { Hs.StashOwner(h.id) })
    DB.exec('DELETE FROM pb_inv WHERE owner = ?', { Hs.StashOwner(h.id) })
    ctx.audit('serveur', 'housing.clear_stash', h.id, { stacks = n and n.n or 0 }, nil)
    ctx.toast = 'Coffre vidé.'
    return true
end, { critical = true, confirm = { title = 'Vider le coffre ?', text = 'Les objets sont supprimés définitivement.', danger = true } })
PB.Action('housing.forgive', 'housing.manage', function(ctx, p)
    local h = Hs.Get(p.id)
    if not h or (h.arrears or 0) == 0 then return false, 'Pas de loyer impayé.' end
    DB.exec('UPDATE pb_properties SET arrears = 0, paid_until = ? WHERE id = ?', { now() + period(), h.id })
    ctx.audit('serveur', 'housing.forgive', h.id, { arrears = h.arrears }, { arrears = 0 })
    ctx.toast = 'Dette effacée.'
    return true
end)

local settings = Form.Cfg({ ns = 'housing', id = 'settings', title = 'Réglages des logements', perm = 'housing.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Logements actifs', default = true }, { k = 'blips', type = 'toggle', label = 'Afficher les logements sur la carte', default = true },
    { k = 'realtor_biz', type = 'text', label = "Agence immobilière (identifiant de l'entreprise)", default = 'realestate', maxlen = 32, pattern = '^[%w_]*$', hint = 'Elle touche une commission sur chaque vente et chaque première location. Vide = aucune.' },
    { k = 'realtor_pct', type = 'number', label = "Commission de l'agence (%)", default = 5, min = 0, max = 50 },
    { k = 'realtor_studio', type = 'number', label = 'Agence : prix d\'un studio', default = 45000, min = 0, max = 100000000 }, { k = 'realtor_studio_rent', type = 'number', label = 'Agence : loyer d\'un studio', default = 350, min = 0, max = 10000000 },
    { k = 'realtor_appart', type = 'number', label = 'Agence : prix d\'un appartement', default = 95000, min = 0, max = 100000000 }, { k = 'realtor_appart_rent', type = 'number', label = 'Agence : loyer d\'un appartement', default = 750, min = 0, max = 10000000 },
    { k = 'realtor_luxe', type = 'number', label = 'Agence : prix d\'un appartement de luxe', default = 320000, min = 0, max = 100000000 }, { k = 'realtor_luxe_rent', type = 'number', label = 'Agence : loyer d\'un appartement de luxe', default = 2200, min = 0, max = 10000000 },
    { k = 'realtor_villa', type = 'number', label = 'Agence : prix d\'une villa', default = 750000, min = 0, max = 100000000 }, { k = 'realtor_villa_rent', type = 'number', label = 'Agence : loyer d\'une villa', default = 4800, min = 0, max = 10000000 },
    { k = 'realtor_max', type = 'number', label = "Annonces maximum de l'agence", default = 40, min = 1, max = 500, hint = 'Logements mis en vente / en location par les agents (menu ALT).' },
    { k = 'max_owned', type = 'number', label = 'Logements maximum par joueur', default = 2, min = 1, max = 20 }, { k = 'rent_days', type = 'number', label = 'Durée d\'une période de loyer (jours)', default = 7, min = 1, max = 60 },
    { k = 'grace_periods', type = 'number', label = 'Périodes d\'impayé tolérées avant expulsion', default = 3, min = 1, max = 20, hint = "Un impayé suspend l'accès et le coffre. Au-delà : expulsion (si activée) ; rien n'est supprimé, les affaires du coffre vont à la consigne." },
    { k = 'evict', type = 'toggle', label = 'Expulser après les impayés tolérés (location)', default = true, hint = "Les affaires du coffre partent à la consigne (récupérables à n'importe quel logement), la dette devient une facture de l'agence immobilière." },
    { k = 'sell_ratio', type = 'number', label = 'Revente : % du prix remboursé', default = 70, min = 0, max = 100 }, { k = 'guests_max', type = 'number', label = 'Personnes avec accès par logement', default = 6, min = 0, max = 30 },
    { k = 'furniture_mode', type = 'select', label = 'Meubles', default = 'items', opts = { { 'items', 'Achetés au Magasin de meubles (objets, revendables)' }, { 'free', 'Gratuits (catalogue, VIP selon le réglage)' } } },
    { k = 'furniture_vip', type = 'toggle', label = 'Meubles gratuits réservés aux VIP', default = true }, { k = 'furniture_max', type = 'number', label = 'Meubles maximum par logement', default = 60, min = 1, max = 300 },
    { k = 'use_distance', type = 'number', label = 'Distance pour ouvrir le menu (m)', default = 2.5, min = 1, max = 10, int = false, step = 0.5 },
} })

PB.Module({
    id = 'housing', label = 'Logements', icon = 'home', group = 'Serveur', order = 97, perm = 'housing.view', hint = 'Achat, location, accès, coffre',
    caps = function()
        return PB.Capsify({
            { 'Achat et location de logements', 'ok', 'Paiement par la banque en priorité ; l\'argent va au compte « État ».' },
            { 'Loyers automatiques', 'ok', 'Prélevés par période pour les locataires en ligne ; impayé = accès suspendu, jamais de suppression.' },
            { 'Accès partagés et porte verrouillable', 'ok', 'Invités à proximité, retirables à tout moment.' },
            { 'Coffre du logement', 'ok', "Branché sur l'inventaire (contenu protégé : on ne peut pas vendre un coffre plein)." },
            { 'Intérieurs (IPL / MLO)', 'off', "Aucun intérieur n'est fourni : place les coordonnées d'un intérieur existant ou utilise l'entrée du bâtiment." },
            { 'Garde-robe, décoration, cambriolage', 'off', 'Non prévus. Pour changer de tenue, utilise une boutique de vêtements.' },
        })
    end,
    doc = "## Logements\nChaque logement a une **porte** sur la carte. Le joueur appuie sur E, puis achète ou loue. Le propriétaire peut verrouiller, donner un accès à des proches et utiliser le **coffre** (dans l'inventaire).\n\nUn **intérieur** est facultatif : indique ses coordonnées pour que « Entrer » y téléporte. Sans intérieur, le logement sert de point de coffre et de droits d'accès pour un bâtiment que tu as déjà cartographié.\n\nPour tes scripts : `HasHousingAccess(source, id)`, `GetProperties(source)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                for _, p in ipairs(Hs.All()) do pts[#pts + 1] = { id = p.id, x = p.x, y = p.y, on = PB.ToBool(p.enabled), color = (p.owner or '') ~= '' and '#ff7a7a' or '#7bd88f', label = p.label, sub = (p.owner or '') ~= '' and 'occupé' or 'libre' } end
                return { { type = 'map', id = 'hmap', title = 'Logements', points = pts, legend = { { color = '#7bd88f', label = 'Libre' }, { color = '#ff7a7a', label = 'Occupé' } } } }
            end },
            { id = 'overview', label = "Vue d'ensemble", icon = 'chart', build = function()
                local all = Hs.All()
                local taken, arrears = 0, 0
                for _, h in ipairs(all) do if h.owner ~= '' then taken = taken + 1 end if inArrears(h) then arrears = arrears + 1 end end
                return { { type = 'cards', items = {
                    { title = 'Logements', value = tostring(#all), icon = 'home', tone = '#6fb4ff', sub = 'Sur la carte' }, { title = 'Occupés', value = tostring(taken), icon = 'user', tone = '#7be0a4', sub = ('%d libres'):format(#all - taken) },
                    { title = 'Loyers impayés', value = tostring(arrears), icon = 'card', tone = arrears > 0 and '#ffb457' or '#7be0a4', sub = 'Accès suspendus' } } } }
            end },
            { id = 'list', label = 'Logements', icon = 'building', build = function()
                local rows = {}
                for _, h in ipairs(Hs.All()) do
                    local acts = {}
                    if ctx.has('housing.manage') and h.owner ~= '' then
                        if (h.arrears or 0) > 0 then acts[#acts + 1] = { action = 'housing.forgive', label = 'Effacer la dette', icon = 'check', payload = { id = h.id } } end
                        acts[#acts + 1] = { action = 'housing.release', label = 'Libérer', icon = 'refresh', danger = true, payload = { id = h.id } }
                    elseif ctx.has('housing.manage') and not Hs.StashEmpty(h.id) then acts[#acts + 1] = { action = 'housing.clear_stash', label = 'Vider le coffre', icon = 'trash', danger = true, payload = { id = h.id } } end
                    if ctx.has('housing.edit') and h.owner == '' then acts[#acts + 1] = { action = 'housing.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = h.id } } end
                    rows[#rows + 1] = { label = h.label, id = h.id, kind = h.kind == 'buy' and 'Vente' or 'Location', price = h.kind == 'buy' and money(h.price) or (money(h.rent) .. '/' .. cfg('rent_days', 7) .. 'j'),
                        who = h.owner == '' and 'Libre' or nameOf(h.owner), state = h.owner == '' and { text = 'Libre', tone = 'ok' } or (inArrears(h) and { text = 'Impayé', tone = 'warn' } or { text = 'Occupé', tone = 'off' }), actions = acts }
                end
                local blocks = { B.table({ id = 'hl', title = 'Logements (' .. #rows .. ')', search = true, columns = { { k = 'label', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'kind', label = 'Type' }, { k = 'price', label = 'Prix' }, { k = 'who', label = 'Occupant' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows }),
                    B.notice('info', "Coordonnées par défaut : des lieux connus de Los Santos, sans intérieur. Vérifie chaque porte en jeu avant d'ouvrir.") }
                if ctx.has('housing.edit') then blocks[#blocks + 1] = { type = 'form', id = 'housing.form', title = 'Ajouter ou modifier un logement', desc = 'Même identifiant = modification. « Intérieur » est facultatif.', cols = 2, fields = {
                    { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
                    { k = 'kind', type = 'select', label = 'Type', opts = { { 'buy', 'À vendre' }, { 'rent', 'À louer' } } }, { k = 'price', type = 'number', label = 'Prix de vente', min = 0, max = 100000000 }, { k = 'rent', type = 'number', label = 'Loyer par période', min = 0, max = 10000000 },
                    { k = 'coords', type = 'coords', label = 'Porte (menu)', wide = true }, { k = 'inside', type = 'coords', label = 'Intérieur (facultatif)', wide = true }, { k = 'enabled', type = 'toggle', label = 'Actif' } },
                    values = { id = '', label = '', kind = 'buy', price = 100000, rent = 500, coords = { x = 0, y = 0, z = 0, h = 0 }, inside = { x = 0, y = 0, z = 0, h = 0 }, enabled = true }, submit = { action = 'housing.save', label = 'Enregistrer' } } end
                return blocks
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'housing', title = 'Logement vu par le joueur', cfg = {} } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'housing.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('logements', function(R)
    for _, h in ipairs(Hs.All()) do
        R.check(h.x ~= 0 or h.y ~= 0, 'logement ' .. h.id, 'porte non définie')
        R.check(h.kind == 'buy' and h.price > 0 or h.kind == 'rent' and h.rent > 0, 'logement ' .. h.id, h.kind == 'buy' and 'prix de vente nul' or 'loyer nul')
        R.check(h.owner == '' or DB.one('SELECT license FROM pb_players WHERE license = ?', { h.owner }) ~= nil, 'logement ' .. h.id, "le propriétaire n'existe plus")
    end
    local orphan = DB.one('SELECT COUNT(*) AS n FROM pb_property_access a LEFT JOIN pb_properties p ON p.id = a.prop WHERE p.id IS NULL')
    R.check(not orphan or orphan.n == 0, 'accès aux logements', 'des accès référencent un logement supprimé')
    R.check(Inv ~= nil and Inv.ExtraAccess ~= nil, 'coffre du logement', "l'inventaire n'est pas chargé : les coffres de logement sont inutilisables")
end)
