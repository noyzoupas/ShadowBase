-- Module 20 : Automatisation. Tâches planifiées (intervalle, heure du jour, démarrage) qui exécutent UNE action parmi une liste fermée.
-- Aucune commande libre : on ne peut pas planifier d'exécuter du code ou une commande console arbitraire.

local B, P, DB = PB.B, PB.Perm, PB.DB

P.Register('automation.edit', 'Créer et modifier des tâches automatiques', 'automation')
P.Register('automation.run', 'Lancer une tâche manuellement', 'automation')
P.Register('automation.delete', 'Supprimer des tâches', 'automation', true)

PB.Migrate('024_tasks', 'Tâches automatiques', {
    [[CREATE TABLE IF NOT EXISTS pb_tasks (
        id INT NOT NULL AUTO_INCREMENT, name VARCHAR(64) NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1,
        trigger_kind VARCHAR(12) NOT NULL DEFAULT 'interval', trigger_value VARCHAR(16) NOT NULL DEFAULT '60',
        action_kind VARCHAR(24) NOT NULL, params TEXT NULL, owner_license VARCHAR(80) NOT NULL DEFAULT '',
        last_run INT NOT NULL DEFAULT 0, last_status VARCHAR(160) NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id))]],
})

local LIMIT = 40

-- Actions possibles : permission exigée pour créer la tâche, champs, exécution.
local KINDS = {
    announce = { label = 'Annonce aux joueurs', perm = 'general.announce', fields = {
        { k = 'text', type = 'text', label = 'Message', required = true, maxlen = 300 }, { k = 'mode', type = 'select', label = 'Où', opts = { { 'both', 'Écran et chat' }, { 'ticker', 'Écran' }, { 'chat', 'Chat' } } } },
        run = function(p) return PB.Announce(p.text, p.mode or 'both'), 'Annonce envoyée' end },
    backup = { label = 'Sauvegarde', perm = 'backups.create', fields = { { k = 'kind', type = 'select', label = 'Type', opts = { { 'config', 'Configuration du panel' }, { 'files', 'Fichiers' }, { 'database', 'Base de données' } } } },
        run = function(p) local id, err = PB.CreateBackup(p.kind, 'automatisation', true) if not id then return false, err end return true, 'Sauvegarde #' .. id end },
    restart_resource = { label = 'Redémarrer une ressource', perm = 'resources.control', fields = { { k = 'res', type = 'text', label = 'Ressource', required = true, maxlen = 64, pattern = '^[%w_%-%.]+$' } },
        run = function(p) local ok, err = PB.Res.Do('restart', p.res) return ok, ok and ('Redémarrage de ' .. p.res) or err end },
    purge_logs = { label = 'Purger le journal', perm = 'logs.purge', fields = { { k = 'days', type = 'number', label = 'Conserver (jours)', min = 7, max = 3650 } },
        run = function(p) local n = PB.Audit.Prune(PB.ToInt(p.days, 90)) return true, n .. ' entrée(s) supprimée(s)' end },
    discord_report = { label = 'Rapport Discord', perm = 'discord.test', fields = { { k = 'key', type = 'select', label = 'Canal', opts = (function() local o = {} for _, c in ipairs(PB.Discord.Channels) do o[#o + 1] = { c.key, c.label } end return o end)() } },
        run = function(p)
            local n = tonumber(DB.scalar("SELECT COUNT(*) FROM pb_audit WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")) or 0
            local started = 0
            for _, r in ipairs(PB.Res.All()) do if GetResourceState(r) == 'started' then started = started + 1 end end
            local sent = PB.Discord.Send(p.key, { title = 'Rapport quotidien', fields = { { name = 'Joueurs', value = tostring(#GetPlayers()), inline = true }, { name = 'Ressources démarrées', value = tostring(started), inline = true }, { name = 'Actions du panel (24 h)', value = tostring(n), inline = true } } })
            return sent, sent and 'Rapport envoyé' or 'Webhook absent ou canal désactivé' end },
    weather = { label = 'Changer la météo', perm = 'world.edit', fields = { { k = 'weather', type = 'select', label = 'Météo', opts = { 'EXTRASUNNY', 'CLEAR', 'CLOUDS', 'OVERCAST', 'RAIN', 'THUNDER', 'FOGGY', 'SNOW' } } },
        run = function(p) PB.Cfg.Set('world', 'weather', p.weather, 'automatisation', 'Tâche automatique') PB.World.Push() return true, 'Météo : ' .. p.weather end },
}
local KIND_OPTS = {}
for k, v in pairs(KINDS) do KIND_OPTS[#KIND_OPTS + 1] = { k, v.label } end
table.sort(KIND_OPTS, function(a, b) return a[2] < b[2] end)

local function runTask(t, who)
    local k = KINDS[t.action_kind]
    if not k then return false, 'Action inconnue.' end
    local params = PB.FromJson(t.params, {}) or {}
    local clean, err = PB.Validate(k.fields, params)
    if not clean then return false, err end
    local ok, a, b = pcall(k.run, clean)
    local success, msg = false, ''
    if not ok then msg = 'Erreur : ' .. tostring(a):sub(1, 120) PB.Err('tâche ' .. t.name .. ' : ' .. tostring(a))
    else success, msg = a and true or false, tostring(b or '') end
    DB.exec('UPDATE pb_tasks SET last_run = ?, last_status = ? WHERE id = ?', { os.time(), ((success and 'OK — ' or 'Échec — ') .. msg):sub(1, 160), t.id })
    PB.Audit.Log('automatisation', 'tache.executer', who or 'planification', t.name, nil, { ok = success, message = msg })
    return success, msg
end

local function minutesOfDay(v) local h, m = v:match('^(%d%d):(%d%d)$') if not h then return nil end return tonumber(h) * 60 + tonumber(m) end

local ranToday = {}
CreateThread(function()
    local startup = true
    while true do
        Wait(30000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if PB.IsReady then
                local now = os.time()
                local d = os.date('*t')
                local cur = d.hour * 60 + d.min
                for _, t in ipairs(DB.q('SELECT * FROM pb_tasks WHERE enabled = 1') or {}) do
                    local due = false
                    if t.trigger_kind == 'interval' then
                        local mins = tonumber(t.trigger_value) or 60
                        due = (now - (t.last_run or 0)) >= mins * 60
                    elseif t.trigger_kind == 'daily' then
                        local key = t.id .. ':' .. os.date('%Y%m%d')
                        if minutesOfDay(t.trigger_value) == cur and not ranToday[key] then ranToday[key] = true due = true end
                    elseif t.trigger_kind == 'startup' then
                        due = startup and (now - (t.last_run or 0)) > 120
                    end
                    if due then runTask(t) end
                end
                startup = false
            end
        end)
        if not ok then PB.Warn('automation', 'boucle : ' .. tostring(err)) end
    end
end)

local function cleanTask(ctx, p)
    local v = p.values or {}
    local kind = tostring(v.action_kind or '')
    local k = KINDS[kind]
    if not k then return nil, 'Action inconnue.' end
    if not ctx.has(k.perm) then return nil, "Tu n'as pas la permission d'automatiser cette action (" .. k.perm .. ')' end
    local name = PB.Sanitize(PB.Trim(tostring(v.name or '')), 64)
    if name == '' then return nil, 'Nom obligatoire.' end
    local tk = tostring(v.trigger_kind or 'interval')
    local tv = PB.Trim(tostring(v.trigger_value or ''))
    if tk == 'interval' then
        local n = tonumber(tv)
        if not n or n < 5 or n > 10080 then return nil, 'Intervalle : 5 à 10080 minutes.' end
        tv = tostring(math.floor(n))
    elseif tk == 'daily' then
        if not minutesOfDay(tv) or minutesOfDay(tv) > 1439 then return nil, 'Heure au format HH:MM.' end
    elseif tk == 'startup' then tv = ''
    else return nil, 'Déclencheur inconnu.' end
    local params = {}
    for _, f in ipairs(k.fields) do params[f.k] = (v.params and v.params[f.k]) end
    local clean, err = PB.Validate(k.fields, params)
    if not clean then return nil, err end
    return { name = name, kind = kind, tk = tk, tv = tv, params = clean, enabled = PB.ToBool(v.enabled) }
end

PB.Action('automation.save', 'automation.edit', function(ctx, p)
    local t, err = cleanTask(ctx, p)
    if not t then return false, err end
    local id = PB.ToInt(p.id, 0)
    if id == 0 and (tonumber(DB.scalar('SELECT COUNT(*) FROM pb_tasks')) or 0) >= LIMIT then return false, 'Limite de ' .. LIMIT .. ' tâches atteinte.' end
    if id > 0 then
        if not DB.one('SELECT id FROM pb_tasks WHERE id = ?', { id }) then return false, 'Tâche introuvable.' end
        DB.exec('UPDATE pb_tasks SET name=?, enabled=?, trigger_kind=?, trigger_value=?, action_kind=?, params=? WHERE id=?', { t.name, t.enabled and 1 or 0, t.tk, t.tv, t.kind, PB.Json(t.params), id })
    else
        id = DB.insert('INSERT INTO pb_tasks (name, enabled, trigger_kind, trigger_value, action_kind, params, owner_license) VALUES (?,?,?,?,?,?,?)', { t.name, t.enabled and 1 or 0, t.tk, t.tv, t.kind, PB.Json(t.params), ctx.license or '' })
    end
    ctx.audit('automatisation', p.id and 'tache.modifier' or 'tache.creer', t.name, nil, { action = t.kind, trigger = t.tk .. ' ' .. t.tv })
    ctx.toast = 'Tâche enregistrée.'
    return true, { open = { tab = 'edit', params = { id = id } } }
end)

PB.Action('automation.run', 'automation.run', function(ctx, p)
    local t = DB.one('SELECT * FROM pb_tasks WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not t then return false, 'Tâche introuvable.' end
    local k = KINDS[t.action_kind]
    if k and not ctx.has(k.perm) then return false, "Tu n'as pas la permission pour cette action (" .. k.perm .. ')' end
    local ok, msg = runTask(t, ctx.actor.name)
    if not ok then return false, msg end
    ctx.audited = true
    ctx.toast = msg
    return true
end, { critical = true, confirm = { title = 'Lancer cette tâche maintenant ?', text = "Elle s'exécute immédiatement avec ses réglages.", danger = false } })

PB.Action('automation.toggle', 'automation.edit', function(ctx, p)
    local t = DB.one('SELECT id, enabled, name FROM pb_tasks WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not t then return false, 'Introuvable.' end
    DB.exec('UPDATE pb_tasks SET enabled = ? WHERE id = ?', { PB.ToBool(t.enabled) and 0 or 1, t.id })
    ctx.audit('automatisation', 'tache.activer', t.name, { enabled = t.enabled }, { enabled = PB.ToBool(t.enabled) and 0 or 1 })
    ctx.toast = PB.ToBool(t.enabled) and 'Désactivée.' or 'Activée.'
    return true
end)

PB.Action('automation.delete', 'automation.delete', function(ctx, p)
    local t = DB.one('SELECT * FROM pb_tasks WHERE id = ?', { PB.ToInt(p.id, 0) })
    if not t then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_tasks WHERE id = ?', { t.id })
    ctx.audit('automatisation', 'tache.supprimer', t.name, t)
    ctx.toast = 'Tâche supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette tâche ?', text = 'Elle ne sera plus exécutée.' } })

local TRIG = { interval = "Toutes les N minutes", daily = 'Chaque jour à HH:MM', startup = 'Au démarrage du serveur' }

PB.Module({
    id = 'automation', label = 'Automatisation', icon = 'zap', group = 'Système', order = 190, perm = 'automation.view', hint = 'Tâches planifiées, rapports',
    caps = function()
        return PB.Capsify({
            { 'Tâches : intervalle, heure du jour, démarrage', 'ok', 'Vérifiées toutes les 30 secondes.' },
            { 'Actions disponibles', 'ok', 'Annonce, sauvegarde, redémarrage de ressource, purge du journal, rapport Discord, météo.' },
            { "Droits à la création", 'ok', "Tu ne peux planifier qu'une action pour laquelle tu as la permission." },
            { 'Commande console ou code libre', 'off', 'Volontairement impossible : ce serait une porte dérobée.' },
            { 'Déclencheurs sur évènement de jeu', 'off', 'Non fournis (utilise un script dédié).' },
        })
    end,
    doc = "## Automatisation\nChaque exécution est journalisée. Une tâche ne peut faire que ce que ton grade autorise à l'instant où tu la crées.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        local id = PB.ToInt(params and params.id, 0)
        return { tabs = {
            tab('list', 'Tâches', 'list', function()
                local rows = {}
                for _, t in ipairs(DB.q('SELECT * FROM pb_tasks ORDER BY name') or {}) do
                    local k = KINDS[t.action_kind]
                    local acts = {}
                    if ctx.has('automation.edit') then acts[#acts + 1] = { nav = { tab = 'edit', params = { id = t.id } }, label = 'Modifier', icon = 'edit' } acts[#acts + 1] = { action = 'automation.toggle', label = PB.ToBool(t.enabled) and 'Désactiver' or 'Activer', icon = 'power', payload = { id = t.id } } end
                    if ctx.has('automation.run') then acts[#acts + 1] = { action = 'automation.run', label = 'Lancer', icon = 'play', payload = { id = t.id } } end
                    rows[#rows + 1] = { name = t.name, what = k and k.label or t.action_kind, when = (TRIG[t.trigger_kind] or t.trigger_kind) .. (t.trigger_value ~= '' and (' : ' .. t.trigger_value) or ''), on = PB.ToBool(t.enabled),
                        last = t.last_run > 0 and t.last_run or '', status = t.last_status, actions = acts }
                end
                return { B.table({ id = 'tasks', columns = { { k = 'name', label = 'Nom' }, { k = 'what', label = 'Action' }, { k = 'when', label = 'Quand' }, { k = 'on', label = 'Active', type = 'bool' }, { k = 'last', label = 'Dernière exécution', type = 'date' }, { k = 'status', label = 'Résultat' } }, rows = rows, empty = 'Aucune tâche.' }) }
            end),
            tab('edit', 'Éditeur', 'edit', function()
                local t = id > 0 and DB.one('SELECT * FROM pb_tasks WHERE id = ?', { id }) or nil
                local kind = t and t.action_kind or tostring(params and params.kind or 'announce')
                local k = KINDS[kind] or KINDS.announce
                local tparams = t and PB.FromJson(t.params, {}) or {}
                local fields = {
                    { k = 'name', type = 'text', label = 'Nom', required = true, maxlen = 64 },
                    { k = 'trigger_kind', type = 'select', label = 'Déclencheur', options = { { 'interval', 'Toutes les N minutes' }, { 'daily', 'Chaque jour à une heure' }, { 'startup', 'Au démarrage' } } },
                    { k = 'trigger_value', type = 'text', label = 'Valeur (minutes ou HH:MM)', maxlen = 8 },
                    { k = 'action_kind', type = 'select', label = 'Action', options = KIND_OPTS, readonly = t ~= nil },
                    { k = 'params', type = 'group', label = 'Réglages de l\'action', fields = k.fields },
                    { k = 'enabled', type = 'toggle', label = 'Active' },
                }
                local blocks = {}
                if not t then blocks[#blocks + 1] = { type = 'picker', id = 'kind', label = 'Type d\'action', options = KIND_OPTS, value = kind } end
                blocks[#blocks + 1] = { type = 'form', id = 'task.form', title = t and ('Modifier ' .. t.name) or 'Créer une tâche', cols = 2, fields = fields,
                    values = t and { name = t.name, trigger_kind = t.trigger_kind, trigger_value = t.trigger_value, action_kind = t.action_kind, params = tparams, enabled = PB.ToBool(t.enabled) }
                        or { name = '', trigger_kind = 'interval', trigger_value = '60', action_kind = kind, params = {}, enabled = true },
                    submit = { action = 'automation.save', label = t and 'Enregistrer' or 'Créer', payload = { id = t and t.id or nil } } }
                if t and ctx.has('automation.delete') then blocks[#blocks + 1] = B.actions({ { action = 'automation.delete', label = 'Supprimer la tâche', icon = 'trash', danger = true, payload = { id = t.id } } }) end
                return blocks
            end, 'automation.edit'),
            tab('history', 'Exécutions', 'clock', function()
                local rows = PB.Audit.Search({ cat = 'automatisation', per = 40 })
                local out = {}
                for _, r in ipairs(rows) do out[#out + 1] = { at = r.created_at, what = r.action, target = r.target, actor = r.actor } end
                return { B.table({ id = 'autoh', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'what', label = 'Évènement', type = 'mono' }, { k = 'target', label = 'Tâche' }, { k = 'actor', label = 'Par' } }, rows = out, empty = 'Aucune exécution.' }) }
            end, 'logs.view'),
        } }
    end,
})
