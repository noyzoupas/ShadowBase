-- Module 17 : Monitoring et maintenance (état du serveur, joueurs, historique, alertes, arrêt non propre, redémarrage planifié, rapport de diagnostic).

local B, P, Form, DB = PB.B, PB.Perm, PB.Form, PB.DB

P.Register('monitor.restart', 'Planifier ou lancer un redémarrage du serveur', 'monitor', true)
P.Register('monitor.settings', "Régler les seuils d'alerte", 'monitor')
P.Register('monitor.report', 'Générer un rapport de diagnostic', 'monitor')

local settings = Form.Cfg({
    ns = 'monitor', id = 'settings', title = "Seuils d'alerte", perm = 'monitor.settings', cols = 2,
    desc = "Le panel prévient les personnes qui ont la permission de voir le monitoring (notification dans le panel et Discord).",
    fields = {
        { k = 'alerts', type = 'toggle', label = 'Activer les alertes', default = true },
        { k = 'lua_mb_warn', type = 'number', label = 'Mémoire Lua du panel (Mo)', default = 400, min = 50, max = 8000 },
        { k = 'ping_warn', type = 'number', label = 'Latence moyenne des joueurs (ms)', default = 150, min = 50, max = 1000 },
        { k = 'load_warn', type = 'number', label = 'Charge CPU du serveur (1 min, par cœur)', default = 1.5, min = 0.5, max = 10, int = false, step = 0.1 },
    },
})

local restartCfg = Form.Cfg({
    ns = 'monitor', id = 'restart', title = 'Redémarrage planifié', perm = 'monitor.restart', cols = 2,
    desc = "Le panel prévient les joueurs puis arrête le serveur (commande `quit`). Il faut un superviseur (txAdmin, systemd, pm2...) qui le relance.",
    fields = {
        { k = 'restart_enabled', type = 'toggle', label = 'Redémarrage quotidien', default = false },
        { k = 'restart_times', type = 'tags', label = 'Heures (HH:MM, heure du serveur)', default = { '05:00' }, pattern = '^%d%d:%d%d$', maxitems = 6 },
        { k = 'restart_warn', type = 'tags', label = 'Avertissements (minutes avant)', default = { '15', '5', '1' }, pattern = '^%d+$', maxitems = 6 },
        { k = 'restart_message', type = 'text', label = "Message d'avertissement", default = 'Redémarrage du serveur dans {min} minute(s).', maxlen = 160 },
    },
})

-- Échantillons --------------------------------------------------------------------------------------------------------------------------
local history = {}
local HIST = 180

PB.Monitor = { History = function() return history end }

local function readFile(p) local f = io.open(p, 'rb') if not f then return nil end local d = f:read('*a') f:close() return d end

local function host()
    local out = {}
    local la = readFile('/proc/loadavg')
    if la then out.load1 = tonumber(la:match('^(%S+)')) end
    local mi = readFile('/proc/meminfo')
    if mi then
        local total, avail = tonumber(mi:match('MemTotal:%s+(%d+)')), tonumber(mi:match('MemAvailable:%s+(%d+)'))
        if total and avail then out.mem_total, out.mem_used = total * 1024, (total - avail) * 1024 end
    end
    local cpus = readFile('/proc/cpuinfo')
    if cpus then local n = 0 for _ in cpus:gmatch('\nprocessor') do n = n + 1 end if cpus:sub(1, 9) == 'processor' then n = n + 1 end out.cores = math.max(n, 1) end
    return out
end

local function sample()
    local players = GetPlayers()
    local ping, n = 0, 0
    for _, id in ipairs(players) do local p = GetPlayerPing(id) if p and p > 0 then ping = ping + p n = n + 1 end end
    local h = host()
    return { at = os.time(), players = #players, ping = n > 0 and PB.Round(ping / n, 0) or 0, lua_mb = PB.Round(collectgarbage('count') / 1024, 1), load1 = h.load1, mem_used = h.mem_used, mem_total = h.mem_total, cores = h.cores }
end

local lastAlert = {}
local function alert(key, title, text)
    if os.time() - (lastAlert[key] or 0) < 1800 then return end
    lastAlert[key] = os.time()
    PB.Notify('warn', title, text, 'monitor.view')
    if PB.Discord then PB.Discord.Send('crash', { title = title, description = text }) end
end

CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if PB.IsReady then
                local s = sample()
                table.insert(history, s)
                if #history > HIST then table.remove(history, 1) end
                PB.Cfg.Set('monitor', 'heartbeat', s.at, 'système', nil, true)
                if PB.Cfg.Get('monitor', 'alerts', true) then
                    if s.lua_mb >= PB.Cfg.Get('monitor', 'lua_mb_warn', 400) then alert('lua', 'Mémoire Lua élevée', s.lua_mb .. ' Mo utilisés par le panel.') end
                    if s.ping >= PB.Cfg.Get('monitor', 'ping_warn', 150) then alert('ping', 'Latence élevée', 'Latence moyenne : ' .. s.ping .. ' ms.') end
                    if s.load1 and s.cores and s.load1 / s.cores >= PB.Cfg.Get('monitor', 'load_warn', 1.5) then alert('load', 'Charge CPU élevée', 'Charge : ' .. s.load1 .. ' sur ' .. s.cores .. ' cœur(s).') end
                end
            end
        end)
        if not ok then PB.Warn('monitor', 'boucle : ' .. tostring(err)) end
    end
end)

-- Arrêt non propre : le dernier battement est récent mais aucun arrêt propre n'a été enregistré
PB.OnReady(function()
    local hb = PB.Cfg.Get('monitor', 'heartbeat', 0)
    local clean = PB.Cfg.Get('monitor', 'clean_stop', true)
    if hb > 0 and not clean then
        PB.Audit.Log('serveur', 'arret.non.propre', 'système', os.date('!%Y-%m-%d %H:%M:%S', hb), nil, nil, { last_heartbeat = hb })
        PB.Notify('warn', 'Arrêt non propre détecté', "Le serveur ne s'est pas arrêté normalement (dernier signal : " .. os.date('%d/%m %H:%M', hb) .. ').', 'monitor.view')
    end
    PB.Cfg.Set('monitor', 'clean_stop', false, 'système', nil, true)
end)
AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then PB.Cfg.Set('monitor', 'clean_stop', true, 'système', nil, true) end
end)

-- Redémarrage planifié -------------------------------------------------------------------------------------------------------------------------
local function minutesUntil(t)
    local h, m = t:match('^(%d%d):(%d%d)$')
    if not h then return nil end
    local now = os.date('*t')
    local diff = (tonumber(h) * 60 + tonumber(m)) - (now.hour * 60 + now.min)
    if diff < 0 then diff = diff + 1440 end
    return diff
end

-- Redémarrage : un seul mécanisme (planifié, lancé depuis le panel ou depuis le menu staff) -----------------------------------------------
-- Compte à rebours réel : annonces à l'écran et dans le chat aux minutes choisies puis à 30 s, 10 s, 5 s ; à zéro on sauvegarde les joueurs,
-- on les déconnecte proprement avec un message puis on envoie « quit ». Un superviseur (txAdmin, systemd, pm2…) doit relancer le serveur.
PB.Restart = PB.Restart or {}
local R = PB.Restart
local rs = nil   -- { at = os.time() de l'arrêt, token, by, said = { [secondes] = true } }

function R.Supervised()
    if (Config.Supervisor or 'aucun') ~= 'aucun' then return true end
    return GetConvar('txAdmin-version', '') ~= '' or GetConvar('txAdminServerMode', '') == 'true'
end
function R.State() return rs and { left = math.max(0, rs.at - os.time()), by = rs.by } or nil end

-- (v1.2.80) Arrêt du serveur. « quit » demande le droit command.quit à la ressource : sans la ligne
-- « add_ace resource.pb_panel command.quit allow » dans server.cfg, FiveM répond « Access denied for command quit » et rien ne
-- s'arrête. Dans ce cas on arrête le processus directement (même effet : txAdmin voit l'arrêt et relance le serveur).
R.ACE_LINE = 'add_ace resource.' .. GetCurrentResourceName() .. ' command.quit allow'
-- (v1.2.83) le droit se lit sur la ressource elle-même ; « os.exit » n'existe pas dans FiveM : sans le droit, on ne déconnecte
-- personne et le redémarrage est annulé avec la marche à suivre (taper la ligne dans la console suffit, sans redémarrer).
function R.CanQuit()
    local okp, v = pcall(IsPrincipalAceAllowed, 'resource.' .. GetCurrentResourceName(), 'command.quit')
    if okp and v == true then return true end
    local oka, w = pcall(IsAceAllowed, 'command.quit')
    return oka and w == true
end
local function quitHelp()
    print(('^1[Shadow Base]^7 Redémarrage impossible : la ressource n\'a pas le droit « quit ». Tape dans la console txAdmin (effet immédiat) puis garde-la dans server.cfg :^7'))
    print('^3    ' .. R.ACE_LINE .. '^7')
end
function R.Quit() ExecuteCommand('quit') end
CreateThread(function()
    Wait(8000)
    if not R.CanQuit() then print(('^3[Shadow Base]^7 Pour les redémarrages et mises à jour automatiques, tape dans la console puis ajoute dans server.cfg : %s'):format(R.ACE_LINE)) end
end)

local function say(text)
    PB.Announce(text, 'both')
end
local function msgFor(sec)
    local tpl = tostring(PB.Cfg.Get('monitor', 'restart_message', 'Redémarrage du serveur dans {min} minute(s).') or '')
    if sec >= 60 then return (tpl:gsub('{min}', tostring(math.floor(sec / 60 + 0.5)))) end
    return ('Redémarrage du serveur dans %d seconde(s). Reste où tu es, tu pourras te reconnecter dans un instant.'):format(sec)
end

local function finish(token)
    if not rs or rs.token ~= token then return end
    if not R.CanQuit() then   -- on essaie quand même ; si le serveur tourne encore, personne n'est déconnecté
        ExecuteCommand('quit')
        Wait(2000)
        rs = nil
        quitHelp()
        say('Redémarrage annulé : il reprendra plus tard.')
        PB.Audit.Log('serveur', 'redemarrage.impossible', 'système', 'droit command.quit absent')
        return
    end
    PB.Audit.Log('serveur', 'redemarrage.execute', rs.by or 'système', '')
    say('Le serveur redémarre maintenant.')
    if PB.G and PB.G.SaveAll then pcall(PB.G.SaveAll) end
    Wait(1500)
    for _, id in ipairs(GetPlayers()) do PB.Drop(tonumber(id), 'kick', 'redemarrage', 'Redémarrage du serveur : reconnecte-toi dans une minute.', 'Redémarrage programmé par ' .. tostring(rs.by or 'système')) end
    Wait(1500)
    rs = nil
    R.Quit()
end

-- seconds : délai avant l'arrêt. Renvoie ok, message.
function R.Start(seconds, by)
    seconds = math.floor(tonumber(seconds) or 0)
    if seconds < 5 or seconds > 3600 then return false, 'Délai : de 5 secondes à 60 minutes.' end
    if rs then return false, 'Un redémarrage est déjà programmé (dans ' .. math.max(0, rs.at - os.time()) .. ' s). Annule-le d\'abord.' end
    local token = tostring(os.time()) .. tostring(math.random(1000, 9999))
    rs = { at = os.time() + seconds, token = token, by = by or 'système', said = {} }
    PB.Audit.Log('serveur', 'redemarrage.demande', by or 'système', 'dans ' .. seconds .. ' s')
    say(msgFor(seconds))
    CreateThread(function()
        while rs and rs.token == token do
            local left = rs.at - os.time()
            if left <= 0 then finish(token) return end
            local marks = { 30, 10, 5 }
            for _, w in ipairs(PB.Cfg.Get('monitor', 'restart_warn', { '15', '5', '1' }) or {}) do marks[#marks + 1] = (tonumber(w) or 0) * 60 end
            for _, m in ipairs(marks) do
                if m > 0 and left <= m and left > m - 2 and not rs.said[m] and m < seconds then rs.said[m] = true say(msgFor(m)) end
            end
            Wait(1000)
        end
    end)
    return true, R.Supervised() and ('Redémarrage dans ' .. seconds .. ' s.') or ('Arrêt dans ' .. seconds .. " s. Aucun superviseur détecté : le serveur ne repartira pas seul (règle Config.Supervisor).")
end
function R.Cancel(by)
    if not rs then return false, 'Aucun redémarrage programmé.' end
    rs = nil
    PB.Audit.Log('serveur', 'redemarrage.annule', by or 'système', '')
    say('Le redémarrage du serveur est annulé.')
    return true, 'Redémarrage annulé.'
end

-- redémarrage quotidien aux heures choisies
local warned = {}
CreateThread(function()
    Wait(math.random(0, 20000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(20000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if PB.IsReady and PB.Cfg.Get('monitor', 'restart_enabled', false) and not rs then
                for _, t in ipairs(PB.Cfg.Get('monitor', 'restart_times', {})) do
                    local left = minutesUntil(t)
                    local maxw = 0
                    for _, w in ipairs(PB.Cfg.Get('monitor', 'restart_warn', { '15', '5', '1' }) or {}) do maxw = math.max(maxw, tonumber(w) or 0) end
                    local key = t .. ':' .. os.date('%Y%m%d')
                    -- on lance le compte à rebours au début de la plus grande fenêtre d'avertissement
                    if left and left <= maxw and left >= 0 and not warned[key] then
                        warned[key] = true
                        R.Start(math.max(5, left * 60 - (os.date('*t').sec or 0)), 'planification ' .. t)
                    end
                end
            end
        end)
        if not ok then PB.Warn('monitor', 'boucle : ' .. tostring(err)) end
    end
end)

PB.Action('monitor.restart.now', 'monitor.restart', function(ctx, p)
    local minutes = PB.Clamp(PB.ToInt(p.values and p.values.minutes, 5), 0, 60)
    local ok, why = R.Start(math.max(5, minutes * 60), ctx.actor and ctx.actor.name or 'panel')
    if not ok then return false, why end
    ctx.audit('serveur', 'redemarrage.demande', 'dans ' .. minutes .. ' min')
    ctx.toast = why
    return true
end, { critical = true, pin = true, confirm = { title = 'Redémarrer le serveur ?', text = 'Annonce à tous les joueurs, sauvegarde, puis arrêt. Tous seront déconnectés.' } })

PB.Action('monitor.restart.cancel', 'monitor.restart', function(ctx)
    local ok, why = R.Cancel(ctx.actor and ctx.actor.name or 'panel')
    if not ok then return false, why end
    ctx.toast = why
    return true
end)

PB.Action('monitor.report', 'monitor.report', function(ctx)
    local lines = { '# Rapport de diagnostic — ' .. os.date('!%Y-%m-%d %H:%M:%SZ') }
    lines[#lines + 1] = 'panel: ' .. PB.Info.version .. ' | framework: ' .. 'wframework' .. ' | inventaire: ' .. tostring(PB.Inv.Detect())
    lines[#lines + 1] = 'joueurs: ' .. #GetPlayers() .. ' | lua_mb: ' .. PB.Round(collectgarbage('count') / 1024, 1)
    local s = DB.Stats
    lines[#lines + 1] = ('sql: %d requêtes, %d erreurs, %d ms cumulées'):format(s.queries, s.errors, s.totalMs)
    lines[#lines + 1] = '\n## Ressources'
    for _, n in ipairs(PB.Res.All()) do lines[#lines + 1] = ('- %s : %s %s'):format(n, GetResourceState(n), GetResourceMetadata(n, 'version', 0) or '') end
    lines[#lines + 1] = '\n## Erreurs SQL récentes'
    for i, e in ipairs(DB.Errors) do if i > 20 then break end lines[#lines + 1] = ('- %s : %s'):format(e.sql, e.error) end
    lines[#lines + 1] = '\n## Erreurs de scripts récentes'
    local errs = PB.ScriptErrors or {}
    for i = #errs, math.max(1, #errs - 19), -1 do lines[#lines + 1] = '- ' .. errs[i].text end
    ctx.audit('panel', 'rapport.diagnostic', 'téléchargé')
    return true, { download = { name = 'diagnostic.txt', text = table.concat(lines, '\n'), mime = 'text/plain' } }
end, { read = true, rate = 4 })

PB.Module({
    id = 'monitor', label = 'Monitoring', icon = 'activity', group = 'Système', order = 180, perm = 'monitor.view', hint = 'Santé, joueurs, alertes, redémarrage',
    caps = function()
        local h = host()
        return PB.Capsify({
            { 'Joueurs, latence, mémoire Lua', 'ok', 'Échantillon chaque minute (180 dernières minutes en mémoire).' },
            { 'CPU et mémoire de la machine', h.load1 and 'partial' or 'off', h.load1 and 'Lecture de /proc (Linux uniquement).' or "Indisponible : /proc absent (Windows ?)." },
            { 'Espace disque', 'off', "Un script Lua ne peut pas lire l'espace disque. Surveille-le avec txAdmin ou ton hébergeur." },
            { 'Détection des arrêts non propres', 'ok', 'Comparaison du dernier signal de vie au démarrage suivant.' },
            { 'Redémarrage planifié', 'partial', 'Avertit puis envoie `quit` : nécessite un superviseur qui relance le serveur.' },
            { 'Alertes', 'ok', 'Notification dans le panel et message Discord (canal crash).' },
        })
    end,
    doc = "## Monitoring\nLes courbes sont conservées en mémoire : elles repartent de zéro à chaque redémarrage du serveur.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('overview', "Vue d'ensemble", 'home', function()
                local s = sample()
                local items = {
                    { label = 'Joueurs', value = s.players, icon = 'users' }, { label = 'Latence moyenne', value = s.ping .. ' ms', icon = 'activity' }, { label = 'Mémoire Lua', value = s.lua_mb .. ' Mo', icon = 'cpu' },
                    { label = 'Ressources démarrées', value = (function() local n = 0 for _, r in ipairs(PB.Res.All()) do if GetResourceState(r) == 'started' then n = n + 1 end end return n end)(), icon = 'box' },
                    { label = 'Panel actif depuis', value = PB.FormatDuration(os.time() - PB.Info.startedAt), icon = 'clock' },
                }
                if s.load1 then items[#items + 1] = { label = 'Charge (1 min)', value = s.load1, icon = 'cpu' } end
                if s.mem_total then items[#items + 1] = { label = 'Mémoire machine', value = PB.FormatBytes(s.mem_used) .. ' / ' .. PB.FormatBytes(s.mem_total), icon = 'hard-drive' } end
                local labels, pl, pg = {}, {}, {}
                for _, h in ipairs(history) do labels[#labels + 1] = os.date('%H:%M', h.at) pl[#pl + 1] = h.players pg[#pg + 1] = h.ping end
                return { B.stats(items),
                    #history > 1 and { type = 'chart', id = 'players', title = 'Joueurs connectés', labels = labels, series = { { name = 'Joueurs', values = pl } } } or B.notice('info', 'Les courbes apparaissent après quelques minutes de collecte.'),
                    #history > 1 and { type = 'chart', id = 'ping', title = 'Latence moyenne (ms)', labels = labels, series = { { name = 'Latence', values = pg } } } or nil }
            end),
            tab('players', 'Joueurs', 'users', function()
                local rows = {}
                for _, id in ipairs(GetPlayers()) do rows[#rows + 1] = { id = (PB.G and PB.G.UidOf and PB.G.UidOf(id)) or tonumber(id), name = GetPlayerName(id) or '?', ping = GetPlayerPing(id) or 0 } end
                table.sort(rows, function(a, b) return a.ping > b.ping end)
                return { B.table({ id = 'mplayers', search = true, columns = { { k = 'id', label = 'ID', type = 'num' }, { k = 'name', label = 'Nom' }, { k = 'ping', label = 'Latence (ms)', type = 'num' } }, rows = rows, empty = 'Aucun joueur.' }) }
            end),
            tab('alerts', 'Alertes', 'bell', function() return { settings(ctx) } end),
            tab('restart', 'Redémarrage', 'power', function()
                local blocks = { restartCfg(ctx) }
                if ctx.has('monitor.restart') then
                    blocks[#blocks + 1] = { type = 'form', id = 'mon.now', title = 'Redémarrer maintenant', cols = 2, fields = { { k = 'minutes', type = 'number', label = 'Dans (minutes)', min = 0, max = 60 } }, values = { minutes = 5 },
                        submit = { action = 'monitor.restart.now', label = 'Programmer l\'arrêt', danger = true } }
                    local st = PB.Restart.State()
                    blocks[#blocks + 1] = B.notice(st and 'warn' or 'info', st and ('Redémarrage en cours : arrêt dans ' .. st.left .. ' s (demandé par ' .. tostring(st.by) .. ').') or (PB.Restart.Supervised() and 'Superviseur détecté : le serveur repartira seul après l\'arrêt.' or "Aucun superviseur détecté : après l'arrêt le serveur ne repartira pas seul. Règle Config.Supervisor ou lance-le avec txAdmin."), 'État')
                    if st then blocks[#blocks + 1] = B.actions({ { action = 'monitor.restart.cancel', label = 'Annuler le redémarrage', icon = 'x', danger = true } }) end
                end
                return blocks
            end, 'monitor.restart'),
            tab('report', 'Diagnostic', 'file', function()
                return { B.notice('info', "Le rapport contient les versions, l'état des ressources et les erreurs récentes. Il ne contient ni secret ni donnée de joueur.", 'Rapport'),
                    B.actions({ { action = 'monitor.report', label = 'Télécharger le rapport', icon = 'download' } }) }
            end, 'monitor.report'),
        } }
    end,
})
