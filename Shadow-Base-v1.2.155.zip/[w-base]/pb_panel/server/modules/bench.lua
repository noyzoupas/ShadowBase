-- (v1.2.98) Banc d'essai : mesure ce qui ralentit le serveur, sans faux joueurs (FiveM ne permet pas d'en créer).
--   · cadence du serveur : retard des tâches (Wait(0)) sur 3 secondes — au-dessus de 50 ms, les joueurs le sentent ;
--   · base de données : temps moyen et maximum d'une requête simple, et des recherches les plus fréquentes du jeu ;
--   · charge simulée : les opérations que le jeu fait le plus (inventaire, menu staff, identité, métier), répétées comme pour 50 joueurs ;
--   · mémoire Lua du panel et plus grosses tables de la base.
-- Le test dure une dizaine de secondes ; les joueurs peuvent sentir un petit à-coup pendant la charge simulée.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G
P.Register('bench.run', "Lancer le banc d'essai du serveur", 'serveur', true)
local last, running = nil, false

local function ms() return GetGameTimer() end
local function timeit(n, fn)
    local worst, total, fails = 0, 0, 0
    for i = 1, n do
        local t = os.clock()
        local ok = pcall(fn, i)
        local d = (os.clock() - t) * 1000
        if not ok then fails = fails + 1 end
        total = total + d
        if d > worst then worst = d end
        if i % 25 == 0 then Wait(0) end
    end
    return { avg = total / n, max = worst, total = total, fails = fails }
end
local function dbTime(n, sql, params)
    local worst, total = 0, 0
    for _ = 1, n do
        local t = ms()
        pcall(DB.q, sql, params or {})
        local d = ms() - t
        total = total + d
        if d > worst then worst = d end
    end
    return { avg = total / n, max = worst }
end

local function run()
    G = PB.G
    local r = { at = os.time(), rows = {}, tables = {} }
    local function add(group, label, value, note, bad) r.rows[#r.rows + 1] = { group = group, label = label, value = value, note = note or '', bad = bad or nil } end
    -- 1. cadence
    local lagMax, lagSum, n = 0, 0, 0
    local stop = ms() + 3000
    while ms() < stop do
        local t = ms()
        Wait(0)
        local d = ms() - t
        lagSum, n = lagSum + d, n + 1
        if d > lagMax then lagMax = d end
    end
    local avg = lagSum / math.max(1, n)
    add('Cadence du serveur', 'Temps entre deux tours (moyenne)', ('%.1f ms'):format(avg), avg > 50 and 'Lent : un script bloque le serveur.' or 'Normal (moins de 50 ms).', avg > 50)
    add('Cadence du serveur', 'Pire retard sur 3 s', ('%d ms'):format(lagMax), lagMax > 150 and 'À-coups visibles par les joueurs.' or 'Correct.', lagMax > 150)
    -- 2. base de données
    local q1 = dbTime(20, 'SELECT 1')
    add('Base de données', 'Requête vide (moyenne / pire)', ('%.1f / %d ms'):format(q1.avg, q1.max), q1.avg > 15 and 'Base lente ou éloignée du serveur.' or 'Normal.', q1.avg > 15)
    local lic = 'license:bench'
    for _, x in ipairs({
        { 'Fiche joueur', 'SELECT * FROM pb_players WHERE license = ?', { lic } },
        { 'Véhicules d\'un joueur (garage)', 'SELECT * FROM pb_vehicles WHERE license = ?', { lic } },
        { 'Inventaire', 'SELECT * FROM pb_inv WHERE owner = ?', { 'p:' .. lic } },
        { 'Sanctions (connexion)', "SELECT id FROM pb_sanctions WHERE kind = 'ban' AND revoked = 0 AND license = ?", { lic } },
        { 'Journal (dernières entrées)', 'SELECT id FROM pb_audit ORDER BY id DESC LIMIT 50', {} },
    }) do
        local t = dbTime(10, x[2], x[3])
        add('Base de données', x[1], ('%.1f / %d ms'):format(t.avg, t.max), t.avg > 25 and 'Lent : la table manque peut-être d\'index (module Performances).' or '', t.avg > 25)
    end
    -- 3. charge simulée : 50 joueurs
    local online = {}
    for src in pairs(G.Players()) do online[#online + 1] = src end
    local function pick(i) return online[((i - 1) % math.max(1, #online)) + 1] end
    if #online > 0 then
        local t = timeit(50, function(i) local s = pick(i) if G.Inv and G.Inv.Contents then G.Inv.Contents('p:' .. tostring(G.Get(s) and G.Get(s).license)) end end)
        add('Charge simulée (50 joueurs)', 'Lecture d\'inventaire', ('%.2f ms (pire %.1f)'):format(t.avg, t.max), '')
        t = timeit(50, function(i) local s = pick(i) if G.Biz and G.Biz.Job then G.Biz.Job(s) end if G.Identity then G.Identity(s) end end)
        add('Charge simulée (50 joueurs)', 'Métier et identité', ('%.2f ms (pire %.1f)'):format(t.avg, t.max), '')
        t = timeit(10, function(i) local s = pick(i) if G.Staff and G.Staff.Spec and P.Has(s, 'staff.menu') then G.Staff.Spec(s, true) end end)
        add('Charge simulée (50 joueurs)', 'Ouverture du menu staff', ('%.1f ms (pire %.1f)'):format(t.avg, t.max), t.avg > 30 and 'Lourd : beaucoup de joueurs ou de reports ?' or '', t.avg > 30)
    else
        add('Charge simulée (50 joueurs)', 'Personne en ligne', '—', 'Connecte-toi et relance pour tester le jeu lui-même.')
    end
    -- 4. mémoire et tables
    add('Mémoire', 'Mémoire Lua de pb_panel', ('%.1f Mo'):format(collectgarbage('count') / 1024), collectgarbage('count') > 400 * 1024 and 'Élevée.' or '', collectgarbage('count') > 400 * 1024)
    local okT, rows = pcall(DB.q, "SELECT table_name AS t, table_rows AS n, ROUND((data_length + index_length) / 1048576, 1) AS mb FROM information_schema.tables WHERE table_schema = DATABASE() ORDER BY (data_length + index_length) DESC LIMIT 10", {})
    for _, x in ipairs(okT and rows or {}) do r.tables[#r.tables + 1] = { t = x.t or x.TABLE_NAME, n = tonumber(x.n) or 0, mb = tostring(x.mb or '?') .. ' Mo' } end
    return r
end

PB.Action('bench.run', 'bench.run', function(ctx)
    if running then return false, 'Un test est déjà en cours.' end
    running = true
    CreateThread(function()
        local ok, r = pcall(run)
        running = false
        if ok then last = r PB.Notify('success', "Banc d'essai", 'Terminé : rouvre le module pour voir les résultats.', 'bench.run')
        else PB.Warn('banc d\'essai : ' .. tostring(r)) end
    end)
    ctx.toast = 'Test lancé (environ 10 secondes).'
    return true
end, { rate = 3 })

PB.Module({
    id = 'bench', label = "Banc d'essai", icon = 'gauge', group = 'Serveur', order = 145, perm = 'bench.run', hint = 'Ce qui ralentit le serveur',
    doc = "## Banc d'essai\nMesure la cadence du serveur, la vitesse de la base et les opérations les plus fréquentes du jeu répétées comme pour 50 joueurs. Lance-le quand le serveur rame pour savoir où chercher.",
    view = function(ctx)
        return { tabs = { { id = 'main', label = 'Résultats', icon = 'gauge', build = function()
            local blocks = { B.actions({ { action = 'bench.run', label = running and 'Test en cours…' or "Lancer le banc d'essai", icon = 'play' } }) }
            if not last then blocks[#blocks + 1] = B.notice('info', 'Aucun test encore. Il dure une dizaine de secondes.') return blocks end
            local rows = {}
            for _, x in ipairs(last.rows) do rows[#rows + 1] = { group = x.group, label = x.label, value = x.value, note = (x.bad and '⚠ ' or '') .. x.note } end
            blocks[#blocks + 1] = B.table({ id = 'bench', title = 'Test du ' .. os.date('%d/%m %H:%M', last.at), columns = { { k = 'group', label = 'Partie' }, { k = 'label', label = 'Mesure' }, { k = 'value', label = 'Résultat' }, { k = 'note', label = 'Avis' } }, rows = rows })
            if #last.tables > 0 then blocks[#blocks + 1] = B.table({ id = 'bt', title = 'Plus grosses tables', columns = { { k = 't', label = 'Table' }, { k = 'n', label = 'Lignes (environ)', type = 'num' }, { k = 'mb', label = 'Taille' } }, rows = last.tables }) end
            return blocks
        end } } }
    end,
})
