-- Module Licence : état de la licence de Shadow Base, empreinte du serveur, activation d'une nouvelle licence.
-- La vérification elle-même (signature Ed25519, expiration, révocation) est dans server/core/license.lua.

local B, P = PB.B, PB.Perm
local L = PB.License

P.Register('license.view', 'Voir la licence du serveur', 'license')
P.Register('license.edit', 'Changer la licence du serveur', 'license', true)

PB.Action('license.activate', 'license.edit', function(ctx, p)
    local token = PB.Trim(tostring((p.values or {}).token or ''))
    if token == '' then return false, 'Colle la licence reçue (elle commence par WB1.).' end
    local ok, info = L.Check(token)
    if not ok then return false, info end
    if not SaveResourceFile(GetCurrentResourceName(), 'license.key', token, -1) then return false, "Écriture de license.key refusée par le serveur : mets la licence à la main dans ce fichier." end
    local before = L.Info and { id = L.Info.id, exp = L.Info.exp } or nil
    L.Locked, L.Reason, L.Info, L.Source = false, 'Licence valide', info, 'license.key'
    ctx.audit('config', 'licence.activer', info.id, before, { id = info.id, customer = info.customer, exp = info.exp })
    ctx.toast = 'Licence valide. Shadow Base redémarre pour se charger complètement…'
    -- Les modules n'ont pas démarré en mode verrouillé (base coupée) : on redémarre la ressource pour tout charger proprement.
    SetTimeout(1500, function() ExecuteCommand('restart ' .. GetCurrentResourceName()) end)
    return true
end, { critical = true, pin = true })

local function when(t) return t and t > 0 and os.date('%d/%m/%Y', t) or 'Jamais' end

PB.Module({
    id = 'license', label = 'Licence', icon = 'key', group = 'Pilotage', order = 5, perm = 'license.view', hint = 'Licence de Shadow Base, empreinte du serveur',
    caps = function()
        return PB.Capsify({
            { 'Vérification de la signature (Ed25519)', 'ok', 'Faite au démarrage puis toutes les minutes pour l\'expiration. Sans licence valide, le panel est verrouillé (seuls les propriétaires voient le module Licence).' },
            { 'Révocation en ligne', L.RevocationUrl and L.RevocationUrl() ~= '' and 'ok' or 'off', "Liste signée (revoked.json) publiée sur le site des mises à jour, relue toutes les heures et gardée sur le serveur : une licence révoquée le reste même hors ligne." },
            { 'Clé publique épinglée', 'ok', 'Remplacer license_pub.lua pour signer de fausses licences verrouille tout le serveur.' },
            { 'Activités des ressources liées', 'ok', 'Sans licence valide, les ressources wb_* refusent toute action (export CanAct).' },
            { 'Protection contre la modification du code', 'off', "Le code Lua reste lisible : une personne qui a les fichiers peut retirer le contrôle. Pour l'empêcher, il faut l'escrow Cfx.re ou ne pas distribuer le code." },
        })
    end,
    doc = "## Licence\nL'**empreinte** identifie ce serveur : donne-la pour obtenir une licence liée à lui. La licence se met dans `license.key` (racine de la ressource) ou dans `server.cfg` : `set wbase_license \"WB1…\"`.",
    view = function(ctx)
        return { tabs = {
            { id = 'status', label = 'Statut', icon = 'shield', build = function()
                local i = L.Info
                local blocks = {}
                if L.Locked or not i then
                    blocks[#blocks + 1] = B.notice('error', L.Reason or 'Licence invalide.')
                else
                    local left = i.exp > 0 and math.max(0, math.floor((i.exp - os.time()) / 86400)) or nil
                    blocks[#blocks + 1] = B.stats({ { label = 'Licence', value = 'Valide', icon = 'check' }, { label = 'Client', value = i.customer ~= '' and i.customer or '—', icon = 'user' },
                        { label = 'Expire', value = when(i.exp), icon = 'clock' }, { label = 'Joueurs maximum', value = i.max > 0 and i.max or 'Illimité', icon = 'users' } })
                    if left and left <= 14 then blocks[#blocks + 1] = B.notice('warn', 'La licence expire dans ' .. left .. ' jour(s) : demande son renouvellement.') end
                    blocks[#blocks + 1] = B.table({ id = 'lic', title = 'Détails', columns = { { k = 'k', label = 'Information' }, { k = 'v', label = 'Valeur', type = 'mono' } }, rows = {
                        { k = 'Identifiant', v = i.id }, { k = 'Liée à', v = i.fp == '*' and 'Tout serveur' or 'Ce serveur (empreinte)' }, { k = 'Source', v = L.Source or '' },
                        { k = 'Fonctions', v = #i.feat == 0 and 'Toutes' or table.concat(i.feat, ', ') },
                        { k = 'Révocation en ligne', v = L.revokedChecked and ('vérifiée le ' .. os.date('%d/%m %H:%M', L.revokedChecked)) or 'pas encore vérifiée' } } })
                end
                blocks[#blocks + 1] = B.notice('info', 'Empreinte de ce serveur : ' .. L.Fingerprint() .. ' — à donner pour obtenir une licence liée à ce serveur.')
                return blocks
            end },
            { id = 'activate', label = 'Activer', icon = 'key', perm = 'license.edit', build = function()
                return { { type = 'form', id = 'license.form', title = 'Coller une licence', desc = "La licence est vérifiée avant d'être enregistrée dans license.key.", cols = 1,
                    fields = { { k = 'token', type = 'area', label = 'Licence (WB1.…)', required = true, maxlen = 4000 } }, values = { token = '' },
                    submit = { action = 'license.activate', label = 'Activer' } } }
            end },
        } }
    end,
})

PB.OnReady(function() PB.SelfTest.Add('licence: signature vérifiée, clé publique seule', function(R)
    local L = PB.License
    R.check(L and not L.Locked and L.Info ~= nil, 'licence', 'licence valide au démarrage', tostring(L and L.Reason))
    R.check(#(PB.LicensePub or '') == 64, 'licence', 'clé publique de 32 octets')
    local ok = L.Check('WB1.00.00')
    R.check(ok == false, 'licence', 'une licence falsifiée est refusée')
end) end)
