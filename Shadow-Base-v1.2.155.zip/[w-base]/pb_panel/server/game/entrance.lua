-- Écran d'entrée : à la connexion, le joueur arrive dans la boîte de nuit du jeu (After Hours). Vue d'ensemble, « Appuyez sur E »,
-- zoom sur son personnage accoudé à la rambarde de la mezzanine ; changer de personnage déplace la caméra vers l'autre.
-- « Entrer en ville » : transition du jeu (dézoom vers le ciel puis trois zooms jusqu'au point d'apparition).
-- Les positions (caméra, emplacements des personnages, piste de danse) se règlent en jeu par le staff : /entree.

local G, P = PB.G, PB.Perm
local E = {}
G.Entrance = E

P.Register('entrance.edit', "Régler l'écran d'entrée (boîte de nuit, caméra, emplacements)", 'character', true)

-- Positions par défaut dans la boîte de nuit d'After Hours (intérieur -1604.7, -3012.6, -78.0). Mezzanine au niveau de l'entrée (z ≈ -74.4),
-- piste en contrebas (z ≈ -79.7). À ajuster en jeu avec /entree si besoin : chaque intérieur peut différer selon les mods de carte.
local DEFAULTS = {
    enabled = true, intro_style = 'club', slogan = '', show_locked = 3, dancers = 14, radio = 'RADIO_22_DLC_BATTLE_MIX1_CLUB', title = '', sub = 'Appuyez sur E pour commencer.',
    interior = { x = -1604.664, y = -3012.583, z = -78.0, h = 0.0 },
    cam_pos = { x = -1599.5, y = -3021.5, z = -72.6, h = 0.0 }, cam_look = { x = -1585.5, y = -3011.0, z = -75.5, h = 0.0 }, cam_fov = 50,
    dance = { x = -1595.0, y = -3011.5, z = -79.7, h = 0.0 }, dance_r = 4.5,
    spot1 = { x = -1583.9, y = -3013.6, z = -74.4, h = 90.0 }, spot2 = { x = -1583.9, y = -3010.6, z = -74.4, h = 90.0 }, spot3 = { x = -1583.9, y = -3007.6, z = -74.4, h = 90.0 },
    spot4 = { x = -1583.9, y = -3016.6, z = -74.4, h = 90.0 }, spot5 = { x = -1583.9, y = -3004.6, z = -74.4, h = 90.0 },
}
PB.Cfg.Define('entrance', DEFAULTS)
local function cfg(k) local v = PB.Cfg.Get('entrance', k, DEFAULTS[k]) if v == nil then return DEFAULTS[k] end return v end
local function pt(v, d) v = type(v) == 'table' and v or d return { x = tonumber(v.x) or d.x, y = tonumber(v.y) or d.y, z = tonumber(v.z) or d.z, h = tonumber(v.h) or d.h or 0 } end

function E.On() return cfg('enabled') ~= false end
-- tout ce que le client doit savoir pour monter la scène
function E.Scene()
    local spots = {}
    for i = 1, 5 do spots[i] = pt(cfg('spot' .. i), DEFAULTS['spot' .. i]) end
    return {
        interior = pt(cfg('interior'), DEFAULTS.interior), cam = pt(cfg('cam_pos'), DEFAULTS.cam_pos), look = pt(cfg('cam_look'), DEFAULTS.cam_look),
        fov = math.max(20, math.min(90, tonumber(cfg('cam_fov')) or 50)), spots = spots, dance = pt(cfg('dance'), DEFAULTS.dance),
        dance_r = math.max(1, math.min(15, tonumber(cfg('dance_r')) or 4.5)), dancers = math.max(0, math.min(30, math.floor(tonumber(cfg('dancers')) or 14))),
        radio = tostring(cfg('radio') or ''), title = tostring(cfg('title') ~= '' and cfg('title') or PB.Cfg.Get('general', 'server_name', '') or ''), sub = tostring(cfg('sub') or ''),
        spawn = pt(PB.Cfg.Get('character', 'spawn', nil), { x = -269.4, y = -955.3, z = 31.2, h = 205.0 }),
        -- accueil : « club » = titre et touche E de la boîte de nuit, « intro » = intro animée (bandes de cinéma, logo, nom du serveur, joueurs en ligne, Discord)
        intro = cfg('intro_style') == 'intro' and 'intro' or 'club', slogan = tostring(cfg('slogan') or ''):sub(1, 60),
        discord = tostring(PB.Cfg.Get('menus', 'discord', '') or ''):sub(1, 48), online = #GetPlayers(), maxp = GetConvarInt('sv_maxclients', 48),
    }
end

-- Réglage en jeu par le staff (/entree) : le client envoie sa position ou celle de sa caméra
local KEYS = { cam = 'cam', look = 'cam_look', dance = 'dance', spot1 = 'spot1', spot2 = 'spot2', spot3 = 'spot3', spot4 = 'spot4', spot5 = 'spot5' }
RegisterNetEvent('pb:g:entrance:set', function(what, d)
    local src = source
    if not P.Has(src, 'entrance.edit') or type(d) ~= 'table' then return end
    local key = KEYS[tostring(what)]
    if not key then return end
    local x, y, z = tonumber(d.x), tonumber(d.y), tonumber(d.z)
    if not x or not y or not z or math.abs(x) > 10000 or math.abs(y) > 10000 or math.abs(z) > 3000 then return end
    local v = { x = math.floor(x * 100 + 0.5) / 100, y = math.floor(y * 100 + 0.5) / 100, z = math.floor(z * 100 + 0.5) / 100, h = math.floor((tonumber(d.h) or 0) * 10 + 0.5) / 10 }
    if key == 'cam' then
        PB.Cfg.Set('entrance', 'cam_pos', v, src, "Écran d'entrée : caméra")
        local lx, ly, lz = tonumber(d.lx), tonumber(d.ly), tonumber(d.lz)
        if lx and ly and lz then PB.Cfg.Set('entrance', 'cam_look', { x = lx, y = ly, z = lz, h = 0 }, src, "Écran d'entrée : visée de la caméra") end
    else
        PB.Cfg.Set('entrance', key, v, src, "Écran d'entrée : " .. key)
    end
    PB.Audit.Log('config', 'entrance.set', src, key, nil, v)
    G.Notify(src, { type = 'success', title = "Écran d'entrée", text = ({ cam = 'Caméra d\'ensemble enregistrée (position et visée).', dance = 'Centre de la piste enregistré.' })[key]
        or ('Emplacement %s enregistré à ta position.'):format(key:gsub('spot', '')) })
end)
-- /entree test : revoir la scène sans se déconnecter
RegisterNetEvent('pb:g:entrance:test', function()
    local src = source
    if not P.Has(src, 'entrance.edit') then return end
    local base = P.GetLicense(src)
    if not base then return end
    TriggerClientEvent('pb:g:brand', src, PB.Json(G.ClientConfig().brand))
    TriggerClientEvent('pb:g:charselect', src, PB.Json({ list = G.CharList(tostring(base):gsub('#%d+$', ''), true), scene = E.Scene(), test = true }))
end)

local form = PB.Form.Cfg({ ns = 'entrance', id = 'settings', title = "Écran d'entrée (boîte de nuit)", perm = 'entrance.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = "Écran d'entrée dans la boîte de nuit", default = true, hint = 'Désactivé : connexion directe (et menu simple pour les VIP à plusieurs personnages).' },
    { k = 'intro_style', type = 'select', label = "Style de l'accueil", default = 'club', opts = { { 'club', 'Boîte de nuit : logo et nom en haut à gauche, touche E' }, { 'intro', 'Intro animée : bandes de cinéma, logo au centre, nom du serveur, joueurs en ligne et Discord' } }, hint = "Dans les deux cas, la boîte de nuit reste derrière et le choix du personnage est le même. L'intro reprend le Discord réglé dans Menus › Apparence." },
    { k = 'slogan', type = 'text', label = "Slogan sous le nom du serveur (intro animée)", default = '', maxlen = 60 },
    { k = 'show_locked', type = 'number', label = 'Emplacements affichés (les autres sont « réservés VIP »)', default = 3, min = 1, max = 5 },
    { k = 'title', type = 'text', label = 'Nom affiché à côté du logo (vide = nom du serveur)', default = '', maxlen = 40 },
    { k = 'dancers', type = 'number', label = 'Danseurs sur la piste', default = 14, min = 0, max = 30 },
    { k = 'radio', type = 'text', label = 'Musique (station radio du jeu, vide = aucune)', default = 'RADIO_22_DLC_BATTLE_MIX1_CLUB', maxlen = 48, pattern = '^[%w_]*$' },
    { k = 'cam_pos', type = 'coords', label = "Caméra d'ensemble : position", default = DEFAULTS.cam_pos, wide = true, hint = 'Le plus simple : en jeu, place ta caméra et tape /entree camera.' },
    { k = 'cam_look', type = 'coords', label = "Caméra d'ensemble : point visé", default = DEFAULTS.cam_look, wide = true },
    { k = 'cam_fov', type = 'number', label = 'Champ de vision (degrés)', default = 50, min = 20, max = 90 },
    { k = 'dance', type = 'coords', label = 'Centre de la piste de danse', default = DEFAULTS.dance, wide = true },
    { k = 'dance_r', type = 'number', label = 'Rayon de la piste (m)', default = 4.5, min = 1, max = 15, step = 0.5, int = false },
    { k = 'spot1', type = 'coords', label = 'Personnage 1 (accoudé, face à la piste)', default = DEFAULTS.spot1, wide = true, hint = 'En jeu : place-toi contre la rambarde, tourné vers la piste, puis /entree place 1.' },
    { k = 'spot2', type = 'coords', label = 'Personnage 2', default = DEFAULTS.spot2, wide = true },
    { k = 'spot3', type = 'coords', label = 'Personnage 3', default = DEFAULTS.spot3, wide = true },
    { k = 'spot4', type = 'coords', label = 'Personnage 4', default = DEFAULTS.spot4, wide = true },
    { k = 'spot5', type = 'coords', label = 'Personnage 5', default = DEFAULTS.spot5, wide = true },
} })
PB.Module({
    id = 'entrance', label = "Écran d'entrée", icon = 'user', group = 'Départ et mort', order = 9, perm = 'entrance.edit', hint = 'Boîte de nuit, choix du personnage, arrivée en ville',
    doc = "## Écran d'entrée\nÀ la connexion, le joueur arrive dans la **boîte de nuit** : vue d'ensemble, « Appuyez sur E ». La caméra zoome sur son personnage, accoudé à la rambarde ; ← → passe d'un personnage à l'autre (la caméra se déplace). **Entrer en ville** lance la transition du jeu : dézoom vers le ciel, puis trois zooms jusqu'au point d'apparition.\n\n" ..
        "### Régler les positions en jeu (staff)\n- `/entree camera` : la caméra d'ensemble prend la position et la direction de ta caméra.\n- `/entree place 1` (à 5) : l'emplacement d'un personnage prend ta position et ton orientation (contre la rambarde, tourné vers la piste).\n- `/entree piste` : centre de la piste de danse.\n- `/entree test` : revoir l'écran d'entrée sans te déconnecter.\n\nLes VIP voient tous leurs personnages ; les autres voient leurs emplacements verrouillés « Réservé VIP ».",
    view = function(ctx) return { tabs = { { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end } } } end,
})
