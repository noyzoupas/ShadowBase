-- (v1.2.99) Carte d'identité RP : une vraie carte à l'écran, avec la photo du personnage (prise par le jeu de celui qui regarde),
-- nom, date de naissance, sexe, taille, nationalité, numéro de carte et date de délivrance (création du personnage).
-- ALT › Montrer mes papiers (à quelqu'un) · objet « Carte d'identité » du sac : la regarder soi-même (et la montrer à la personne en face).
local G, DB = PB.G, PB.DB
local C = {}
G.IdCard = C
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n or 40)) end
local function cardOf(src)
    local i = G.Identity(src) or {}
    local p = G.Get(src)
    local uid = G.UidOf and G.UidOf(src) or src
    local fs = p and DB.one('SELECT at FROM pb_first_seen WHERE license = ?', { (tostring(p.license):gsub('#%d+$', '')) })
    local created = fs and tonumber(fs.at) or nil
    local num = ('%s-%06d'):format(string.char(65 + (uid % 26)) .. string.char(65 + ((uid // 26) % 26)), (uid * 7919) % 1000000)
    return { from = src, first = clean(i.firstname, 24), last = clean(i.lastname, 24), dob = clean(i.dob, 12), sex = (i.sex == 'f' or i.sex == 'F' or i.sex == 1) and 'F' or 'M',
        height = tonumber(i.height) or nil, nat = clean(i.nationality, 24), num = num, issued = created and os.date('%d/%m/%Y', created) or nil,
        city = PB.Cfg.Get('general', 'server_name', 'Los Santos') }
end
function C.Show(src, t)
    TriggerClientEvent('pb:g:idcard', t, PB.Json(cardOf(src)))
    if t ~= src and G.Me3D then pcall(G.Me3D, src, "montre sa carte d'identité") end
end
CreateThread(function()
    while not (G.Inv and G.Inv.RegisterUsable) do Wait(200) end
    for _, name in ipairs({ 'id_card', 'card_id' }) do
        G.Inv.RegisterUsable(name, function(src)
            C.Show(src, src)
            -- la personne la plus proche (1,5 m) la voit aussi : on tend la carte
            local best, bd
            for s2 in pairs(G.Players()) do if s2 ~= src then local d = G.DistBetween(src, s2) if d <= 1.8 and (not bd or d < bd) then best, bd = s2, d end end end
            if best then C.Show(src, best) end
            return true, best and "Tu montres ta carte d'identité." or "Ta carte d'identité.", true   -- la carte reste dans le sac
        end)
    end
end)
