-- Anticheat (suite) : dégâts truqués, tirs impossibles, projectiles, armes retirées, entités et chat en rafale, pseudos, et rapports du client recoupés par le serveur.
-- Même philosophie que anticheat.lua : le serveur décide, les détections de comportement sont réglées sur « Journaliser » tant qu'elles ne sont pas éprouvées, et `anticheat.bypass` n'est jamais sanctionné.
local G = PB.G
local AC = PB.AC
if not AC then return end
local cfg, Flag, tracked, bump, cancel = AC.Cfg, AC.Flag, AC.Tracked, AC.bump, AC.Cancel
local function on(src) return src and cfg('enabled') ~= false and not AC.Bypass(src) end
local function lowerSet(l) local t = {} for _, v in ipairs(l or {}) do t[GetHashKey(tostring(v):lower())] = tostring(v):lower() end return t end

-- Dégâts truqués et tirs impossibles ---------------------------------------------------------------------------------------------------------
local MELEE, TASER = {}, {}
for _, n in ipairs({ 'weapon_unarmed', 'weapon_knife', 'weapon_nightstick', 'weapon_hammer', 'weapon_bat', 'weapon_crowbar', 'weapon_golfclub', 'weapon_bottle', 'weapon_dagger', 'weapon_hatchet', 'weapon_knuckle', 'weapon_machete', 'weapon_flashlight', 'weapon_switchblade', 'weapon_poolcue', 'weapon_wrench', 'weapon_battleaxe', 'weapon_stone_hatchet' }) do MELEE[GetHashKey(n)] = true end
for _, n in ipairs({ 'weapon_stungun', 'weapon_stungun_mp' }) do TASER[GetHashKey(n)] = true end
AddEventHandler('weaponDamageEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    -- cadence
    local rate = bump(src, 'dmgrate', 1)
    if rate > (tonumber(cfg('fire_rate')) or 30) then
        if rate == (tonumber(cfg('fire_rate')) or 30) + 1 then Flag(src, 'rapid_fire', ('%d coups en 1 s'):format(rate)) end
        if AC.ModeOf('rapid_fire') ~= 'log' then cancel() return end
    end
    local dmg = tonumber(d.weaponDamage) or 0
    if d.overrideDefaultDamage and dmg > (tonumber(cfg('dmg_max')) or 400) then
        if AC.ModeOf('damage_mod') ~= 'log' then cancel() end
        Flag(src, 'damage_mod', ('%d dégâts en un coup (arme %s)'):format(dmg, tostring(d.weaponType)))
        return
    end
    local gid = tonumber(d.hitGlobalId)
    if gid and gid ~= 0 and NetworkGetEntityFromNetworkId then
        local tgt = NetworkGetEntityFromNetworkId(gid)
        local ped = GetPlayerPed(src)
        if tgt and tgt ~= 0 and ped and ped ~= 0 then
            local a, b = GetEntityCoords(ped), GetEntityCoords(tgt)
            local dist = #(a - b)
            if dist > (tonumber(cfg('hit_range')) or 900) then
                if AC.ModeOf('hit_far') ~= 'log' then cancel() end
                Flag(src, 'hit_far', ('cible touchée à %d m'):format(math.floor(dist)))
            elseif MELEE[d.weaponType] and dist > (tonumber(cfg('melee_range')) or 9) then
                if AC.ModeOf('melee_far') ~= 'log' then cancel() end
                Flag(src, 'melee_far', ('coup de mêlée à %d m'):format(math.floor(dist)))
            elseif TASER[d.weaponType] and dist > (tonumber(cfg('taser_range')) or 22) then
                if AC.ModeOf('melee_far') ~= 'log' then cancel() end
                Flag(src, 'melee_far', ('taser à %d m'):format(math.floor(dist)))
            end
            -- précision : part de tirs à la tête sur des joueurs/peds
            if GetEntityType and GetEntityType(tgt) == 1 then
                local t = AC.track[src]
                t.aim = t.aim or { n = 0, h = 0 }
                t.aim.n = t.aim.n + 1
                if tonumber(d.hitComponent) == 20 then t.aim.h = t.aim.h + 1 end
                local need = tonumber(cfg('aim_min_hits')) or 25
                if t.aim.n >= need then
                    local pct = t.aim.h * 100 / t.aim.n
                    if pct >= (tonumber(cfg('aim_ratio_pct')) or 80) then Flag(src, 'aim_ratio', ('%d têtes sur %d touches (%.0f %%)'):format(t.aim.h, t.aim.n, pct)) end
                    t.aim = nil
                end
            end
        end
    end
end)

-- Projectiles ---------------------------------------------------------------------------------------------------------------------------------
local bp
AddEventHandler('startProjectileEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    bp = bp or lowerSet(cfg('projectiles'))
    local name = bp[d.weaponHash] or bp[d.projectileHash]
    local n = bump(src, 'projectile', 10)
    if name then cancel() Flag(src, 'projectile', 'projectile interdit : ' .. name)
    elseif n > (tonumber(cfg('proj_max')) or 8) then cancel() if n == (tonumber(cfg('proj_max')) or 8) + 1 then Flag(src, 'projectile', ('%d projectiles en 10 s'):format(n)) end end
end)
PB.Cfg.OnChange('anticheat', function() bp = nil end)

-- Désarmer un autre joueur --------------------------------------------------------------------------------------------------------------------
AddEventHandler('removeAllWeaponsEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    local e = d.pedId and NetworkGetEntityFromNetworkId and NetworkGetEntityFromNetworkId(d.pedId)
    local owner = e and e ~= 0 and NetworkGetEntityOwner and NetworkGetEntityOwner(e) or nil
    if owner and owner ~= src and tracked(owner) then cancel() Flag(src, 'remove_weapons', 'armes retirées à #' .. tostring(owner)) end
end)

-- Entités créées en rafale (en plus de la liste noire déjà gérée) ------------------------------------------------------------------------------
AddEventHandler('entityCreating', function(ent)
    if cfg('enabled') == false or not ent or ent == 0 then return end
    local owner = NetworkGetEntityOwner and NetworkGetEntityOwner(ent) or nil
    local src = tracked(owner)
    if not src or not on(src) then return end
    local ty = GetEntityType and GetEntityType(ent) or 0
    local key, lim, lbl = nil, nil, nil
    if ty == 2 then key, lim, lbl = 'ent_veh', tonumber(cfg('ent_veh_max')) or 4, 'véhicules'
    elseif ty == 1 then key, lim, lbl = 'ent_ped', tonumber(cfg('ent_ped_max')) or 8, 'peds'
    elseif ty == 3 then key, lim, lbl = 'ent_obj', tonumber(cfg('ent_obj_max')) or 30, 'objets' end
    if not key then return end
    local n = bump(src, key, 10)
    if n > lim then
        cancel()
        if n == lim + 1 then Flag(src, 'entity_spam', ('%d %s en 10 s'):format(n, lbl)) end
    end
end)

-- Chat ----------------------------------------------------------------------------------------------------------------------------------------
local function hasWord(text, list)
    text = tostring(text or ''):lower()
    for _, w in ipairs(list or {}) do w = tostring(w):lower() if w ~= '' and text:find(w, 1, true) then return w end end
end
AddEventHandler('chatMessage', function(src, _, msg)
    src = tonumber(src)
    if not tracked(src) or not on(src) then return end
    local n = bump(src, 'chat', 10)
    local w = hasWord(msg, cfg('chat_words'))
    if w then if AC.ModeOf('chat_spam') ~= 'log' then cancel() end Flag(src, 'chat_spam', 'mot interdit : ' .. w) return end
    if n > (tonumber(cfg('chat_burst')) or 6) then cancel() if n == (tonumber(cfg('chat_burst')) or 6) + 1 then Flag(src, 'chat_spam', ('%d messages en 10 s'):format(n)) end end
end)

-- Pseudo à la connexion -----------------------------------------------------------------------------------------------------------------------
AddEventHandler('playerConnecting', function(name, setKickReason)
    if cfg('enabled') == false or AC.ModeOf('name') == 'off' then return end
    local src = source
    local okb, ex = pcall(AC.Bypass, src)
    if okb and ex then return end
    local why
    name = tostring(name or '')
    if #name:gsub('%s', '') < 2 then why = 'pseudo trop court ou vide'
    elseif #name > 40 then why = 'pseudo trop long'
    elseif name:find('[%z\1-\31\127]') or name:find('\226\128[\139-\143]') or name:find('\226\128[\168-\175]') or name:find('\239\187\191') then why = 'caractères invisibles ou de contrôle'
    else local w = hasWord(name, cfg('name_words')) if w then why = 'mot interdit : ' .. w end end
    if why then
        pcall(function() PB.Audit.Log('securite', 'anticheat.name', 0, name:sub(1, 40) .. ' — ' .. why) end)
        if AC.ModeOf('name') ~= 'log' then
            if CancelEvent then CancelEvent() end
            if setKickReason then setKickReason('Pseudo refusé (' .. why .. '). Change de pseudo FiveM puis reconnecte-toi.') end
        end
    end
end)

-- Rapports du client : signés avec le code de session, plausibles, puis recoupés par le serveur ------------------------------------------------
local function tok(sec, kind, val) return AC.Hash(sec .. '|' .. kind .. '|' .. tostring(math.floor(tonumber(val) or 0))) end
local LIMITS = { devtools = true, vehmod = true, dmgmod = true, god = true, vehboost = true, vehgod = true, hp = true, armor = true, noclip = true, speed = true, invisible = true, freecam = true, spectate = true, ammo = true, jump = true, tiny = true, vision = true, stamina = true, ragdoll = true }
RegisterNetEvent('pb:ac:rep', function(kind, val, proof)
    local src = source
    local t = AC.track[src]
    if not t or not on(src) then return end
    kind = tostring(kind or '')
    if not LIMITS[kind] or tonumber(proof) ~= tok(t.sec, kind, val) then return end   -- jeton faux : ignoré (un code périmé n'est jamais sanctionné)
    if (t.grace or 0) > os.time() then return end
    if bump(src, 'rep_' .. kind, 60) > 6 then return end                              -- un client ne peut pas inonder le serveur
    local S = G.Staff
    if S and S.OnDuty and S.OnDuty(src) then return end                               -- le staff en service peut être invisible, invincible…
    local ped = GetPlayerPed(src)
    local pl = G.Get and G.Get(src)
    local dead = pl and PB.ToBool(pl.row and pl.row.dead)
    local v = tonumber(val) or 0
    local msg
    if kind == 'hp' then
        if v > (tonumber(cfg('hp_max')) or 200) then msg = ('santé %d (max plausible %d)'):format(v, tonumber(cfg('hp_max')) or 200) end
    elseif kind == 'armor' then
        if v > (tonumber(cfg('armor_max')) or 100) then msg = ('armure %d'):format(v) end
    elseif kind == 'noclip' then
        local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
        if not dead and veh == 0 then msg = 'collisions désactivées et déplacement libre' end
    elseif kind == 'speed' then msg = ('vitesse à pied %.0f m/s'):format(v)
    elseif kind == 'invisible' then if not dead then msg = 'joueur invisible' end
    elseif kind == 'freecam' then msg = 'caméra libre'
    elseif kind == 'spectate' then msg = 'mode spectateur réseau'
    elseif kind == 'ammo' then msg = 'munitions infinies (aucune consommée)'
    elseif kind == 'jump' then msg = 'super saut'
    elseif kind == 'tiny' then msg = 'ped minuscule'
    elseif kind == 'vision' then msg = 'vision nocturne ou thermique'
    elseif kind == 'god' then if not dead and (pl and PB.ToBool(pl.row and pl.row.created)) then msg = 'invincibilité (le client ne peut pas être blessé)' end
    elseif kind == 'vehboost' then
        local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
        if veh ~= 0 then
            local vel = GetEntityVelocity(veh)
            local sp = math.sqrt(vel.x ^ 2 + vel.y ^ 2 + vel.z ^ 2)
            if v > (tonumber(cfg('veh_boost_pct')) or 190) and sp > 25 then msg = ('véhicule à %d %% du maximum de son modèle (%.0f m/s mesurés)'):format(v, sp) end
        end
    elseif kind == 'devtools' then msg = 'outils de développement de l\'interface ouverts'
    elseif kind == 'vehmod' then msg = ('modificateur de puissance ou de vitesse du véhicule à %d %%'):format(v)
    elseif kind == 'dmgmod' then msg = ('modificateur de dégâts/défense/régénération à %d %%'):format(v)
    elseif kind == 'vehgod' then msg = 'véhicule indestructible ou santé hors limites'
    elseif kind == 'stamina' then msg = 'endurance infinie'
    elseif kind == 'ragdoll' then msg = 'ragdoll désactivé' end
    if msg then t.rep = (t.rep or {}) t.rep[kind] = (t.rep[kind] or 0) + 1
        if t.rep[kind] >= ((kind == 'devtools' or v >= 2) and 1 or (tonumber(cfg('noclip_hits')) or 3)) then t.rep[kind] = 0 Flag(src, (kind == 'vehboost' and 'veh_boost') or (kind == 'vehgod' and 'veh_god') or (kind == 'dmgmod' and 'dmg_modifier') or (kind == 'devtools' and 'nui_devtools') or (kind == 'noclip' and 'noclip') or (kind == 'freecam' and 'freecam') or (kind == 'vehmod' and 'veh_boost') or 'client_report', msg) end
    else if t.rep then t.rep[kind] = 0 end end
end)

-- Ressources connues côté client : tout ce qui n'existe pas côté serveur est suspect -----------------------------------------------
local function serverRes()
    local s = {}
    for i = 0, (GetNumResources and GetNumResources() or 0) - 1 do local n = GetResourceByFindIndex(i) if n then s[n] = true end end
    return s
end
RegisterNetEvent('pb:ac:res', function(list, proof)
    local src = source
    local t = AC.track[src]
    if not t or not on(src) or type(list) ~= 'table' or #list > 600 then return end
    if tonumber(proof) ~= tok(t.sec, 'res', #list) then return end
    if (t.grace or 0) > os.time() or bump(src, 'res', 120) > 3 then return end
    local sr, bad = serverRes(), {}
    for _, n in ipairs(list) do n = tostring(n) if not sr[n] and #bad < 5 then bad[#bad + 1] = n:sub(1, 40) end end
    if #bad > 0 then Flag(src, 'resource_inject', 'ressources côté client inconnues du serveur : ' .. table.concat(bad, ', ')) end
end)

-- Changement de modèle de joueur (ped changer) : lu côté serveur, sans rien demander au client -----------------------------------------------
local allowedPed
PB.Cfg.OnChange('anticheat', function() allowedPed = nil end)
CreateThread(function()
    while true do
        Wait(5000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('ped_change') == 'off' then return end
            if not allowedPed then allowedPed = {} for _, m in ipairs(cfg('peds') or {}) do allowedPed[GetHashKey(tostring(m):lower())] = tostring(m):lower() end end
            local S = G.Staff
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 and (t.grace or 0) <= os.time() and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) then
                    local pl = G.Get and G.Get(src)
                    if pl and PB.ToBool(pl.row and pl.row.created) then
                        local m = GetEntityModel(ped)
                        if m ~= 0 and not allowedPed[m] then
                            t.pedBad = (t.pedBad or 0) + 1
                            if t.pedBad >= 3 then t.pedBad = 0 Flag(src, 'ped_change', ('modèle %s non autorisé'):format(tostring(m))) end
                        else t.pedBad = 0 end
                    end
                end
            end
        end)
    end
end)

-- Explosion loin de son auteur ----------------------------------------------------------------------------------------------------------------
AddEventHandler('explosionEvent', function(sender, ev)
    local src = tracked(sender)
    if not src or not on(src) or type(ev) ~= 'table' then return end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 or ev.posX == nil then return end
    local c = GetEntityCoords(ped)
    local dist = #(c - vector3(ev.posX + 0.0, ev.posY + 0.0, (ev.posZ or c.z) + 0.0))
    if dist > (tonumber(cfg('hit_range')) or 900) then
        if AC.ModeOf('hit_far') ~= 'log' then cancel() end
        Flag(src, 'hit_far', ('explosion à %d m de son auteur'):format(math.floor(dist)))
    end
end)

-- Contrôles lus par le SERVEUR (non falsifiables par le client) : santé, armure, vitesse à pied, arme en main ------------------------------------
local heldBad
PB.Cfg.OnChange('anticheat', function() heldBad = nil end)
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            if cfg('enabled') == false then return end
            heldBad = heldBad or lowerSet(cfg('weapons'))
            local S, n = G.Staff, os.time()
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                local pl = G.Get and G.Get(src)
                if ped and ped ~= 0 and (t.grace or 0) <= n and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) and pl and PB.ToBool(pl.row and pl.row.created) then
                    local hp, arm = GetEntityHealth(ped), GetPedArmour(ped)
                    if hp > (tonumber(cfg('hp_max')) or 200) or arm > (tonumber(cfg('armor_max')) or 100) then
                        t.hpBad = (t.hpBad or 0) + 1
                        if t.hpBad >= 3 then t.hpBad = 0 Flag(src, 'health_hack', ('santé %d, armure %d'):format(hp, arm)) end
                    else t.hpBad = 0 end
                    local w = GetSelectedPedWeapon(ped)
                    if heldBad[w] then
                        t.wBad = (t.wBad or 0) + 1
                        if t.wBad >= 2 then t.wBad = 0 Flag(src, 'weapon_held', 'arme en main : ' .. heldBad[w]) end
                    else t.wBad = 0 end
                    local c = GetEntityCoords(ped)
                    local veh = GetVehiclePedIsIn(ped, false)
                    local f = t.fs
                    if veh == 0 and not PB.ToBool(pl.row.dead) and f and n > f.t then
                        local dt = n - f.t
                        local dxy = math.sqrt((c.x - f.x) ^ 2 + (c.y - f.y) ^ 2)
                        local dz = math.abs(c.z - f.z)
                        if dxy / dt > (tonumber(cfg('foot_speed')) or 12) and dz / dt < 8 and dxy < (tonumber(cfg('tp_distance')) or 400) then
                            t.fsN = (t.fsN or 0) + 1
                            if t.fsN >= 4 then t.fsN = 0 Flag(src, 'speed_hack', ('%.1f m/s à pied'):format(dxy / dt)) end
                        else t.fsN = 0 end
                    else t.fsN = 0 end
                    t.fs = veh == 0 and { x = c.x, y = c.y, z = c.z, t = n } or nil
                end
            end
        end)
    end
end)

-- Identifiants exigés à la connexion ----------------------------------------------------------------------------------------------------------
AddEventHandler('playerConnecting', function(_, setKickReason)
    if cfg('enabled') == false or AC.ModeOf('ident') == 'off' then return end
    local src = source
    local okb, ex = pcall(AC.Bypass, src)
    if okb and ex then return end
    local have = {}
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do have[(id:match('^(%a+):') or ''):lower()] = true end
    for _, need in ipairs(cfg('require_idents') or {}) do
        need = tostring(need):lower()
        if need ~= '' and not have[need] then
            pcall(function() PB.Audit.Log('securite', 'anticheat.ident', 0, 'identifiant manquant : ' .. need) end)
            if AC.ModeOf('ident') ~= 'log' then
                if CancelEvent then CancelEvent() end
                if setKickReason then setKickReason(('Connexion refusée : ton compte %s doit être lié à FiveM (identifiant manquant).'):format(need)) end
            end
            return
        end
    end
end)

-- Captures d'écran (ressource screenshot-basic) envoyées sur un webhook Discord à chaque sanction --------------------------------------------
local B64 = {}
do local a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' for i = 1, #a do B64[a:byte(i)] = i - 1 end end
local function b64dec(d)
    d = d:gsub('^data:[^,]*,', ''):gsub('[^%w%+/]', '')
    local out, n = {}, #d
    for i = 1, n - n % 4, 4 do
        local a, b, c, e = d:byte(i, i + 3)
        local v = (B64[a] << 18) | (B64[b] << 12) | (B64[c] << 6) | B64[e]
        out[#out + 1] = string.char((v >> 16) & 255, (v >> 8) & 255, v & 255)
    end
    local r = n % 4
    if r >= 2 then
        local a, b, c = d:byte(n - r + 1, n - r + 3)
        local v = (B64[a] << 18) | (B64[b] << 12) | ((c and B64[c] or 0) << 6)
        out[#out + 1] = string.char((v >> 16) & 255) .. (r == 3 and string.char((v >> 8) & 255) or '')
    end
    return table.concat(out)
end
local lastShot = {}
function AC.Shot(src, kind, detail, mode, act)
    local url = tostring(cfg('shot_webhook') or '')
    local severe = mode == 'kick' or mode == 'ban'
    if url == '' or not url:match('^https://') or kind == 'heartbeat' or kind == 'resource_stop' or (not severe and cfg('shot_on') ~= 'all')
        or GetResourceState('screenshot-basic') ~= 'started' or (lastShot[src] or 0) > os.time() - 60 or not PerformHttpRequest then
        act() return
    end
    lastShot[src] = os.time()
    local done = false
    local function go() if not done then done = true act() end end
    if severe then SetTimeout(5000, go) else go() end
    local name = GetPlayerName(src) or ('#' .. src)
    local ok = pcall(function()
        exports['screenshot-basic']:requestClientScreenshot(src, { encoding = 'jpg', quality = 0.6 }, function(err, data)
            if err or type(data) ~= 'string' or #data < 100 then go() return end
            local okd, bin = pcall(b64dec, data)
            if not okd or #bin < 100 then go() return end
            local bd = 'wbshot' .. math.random(100000, 999999)
            local content = ('Anticheat — %s (%s) : %s · %s · %s'):format(name, G.Tag(src), kind, (detail or ''):sub(1, 150), mode)
            local js = '{"content":' .. json.encode(content) .. '}'
            local body = '--' .. bd .. '\r\nContent-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json\r\n\r\n' .. js
                .. '\r\n--' .. bd .. '\r\nContent-Disposition: form-data; name="files[0]"; filename="capture.jpg"\r\nContent-Type: image/jpeg\r\n\r\n' .. bin .. '\r\n--' .. bd .. '--\r\n'
            PerformHttpRequest(url, function() end, 'POST', body, { ['Content-Type'] = 'multipart/form-data; boundary=' .. bd })
            go()
        end)
    end)
    if not ok then go() end
end

-- Types d'explosion impossibles en RP (liste réglable) -----------------------------------------------------------------------------------------
local badExp
PB.Cfg.OnChange('anticheat', function() badExp = nil end)
AddEventHandler('explosionEvent', function(sender, ev)
    local src = tracked(sender)
    if not src or not on(src) or type(ev) ~= 'table' then return end
    if not badExp then badExp = {} for _, n in ipairs(cfg('explosion_types') or {}) do badExp[tonumber(n) or -1] = true end end
    if badExp[tonumber(ev.explosionType) or -2] then cancel() Flag(src, 'explosion_type', 'type d\'explosion ' .. tostring(ev.explosionType)) end
end)

-- Une arme retirée à un autre joueur (évènement distinct de « toutes les armes ») ------------------------------------------------------------------
AddEventHandler('removeWeaponEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    local e = d.pedId and NetworkGetEntityFromNetworkId and NetworkGetEntityFromNetworkId(d.pedId)
    local owner = e and e ~= 0 and NetworkGetEntityOwner and NetworkGetEntityOwner(e) or nil
    if owner and owner ~= src and tracked(owner) then cancel() Flag(src, 'remove_weapons', 'arme retirée à #' .. tostring(owner)) end
end)

-- Super saut lu par le serveur -------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('super_jump') == 'off' or not IsPlayerUsingSuperJump then return end
            local S = G.Staff
            for src, t in pairs(AC.track) do
                if (t.grace or 0) <= os.time() and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) then
                    if IsPlayerUsingSuperJump(src) then
                        t.sj = (t.sj or 0) + 1
                        if t.sj >= 3 then t.sj = 0 Flag(src, 'super_jump', 'super saut lu par le serveur') end
                    else t.sj = 0 end
                end
            end
        end)
    end
end)

-- Noclip lu par le serveur : joueur FIGÉ qui se déplace, ou qui se déplace vite sans AUCUNE vitesse (position réécrite à chaque image) -----------
-- Autocalibration : la règle « position sans vitesse » ne s'applique que si, sur CE serveur, la vitesse lue colle à la position chez les joueurs normaux.
local calib = { good = 0, bad = 0 }
CreateThread(function()
    while true do
        Wait(2000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('noclip') == 'off' then return end
            local S, n = G.Staff, os.time()
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                local pl = G.Get and G.Get(src)
                if ped and ped ~= 0 and (t.grace or 0) <= n and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) and pl and PB.ToBool(pl.row and pl.row.created) and not PB.ToBool(pl.row.dead) then
                    local c = GetEntityCoords(ped)
                    local prev = t.nc
                    local veh = GetVehiclePedIsIn(ped, false)
                    t.nc = veh == 0 and { x = c.x, y = c.y, z = c.z, t = n } or nil
                    if prev and veh == 0 and n > prev.t then
                        local dt = n - prev.t
                        local dist = math.sqrt((c.x - prev.x) ^ 2 + (c.y - prev.y) ^ 2 + (c.z - prev.z) ^ 2)
                        local sp = dist / dt
                        if dist < (tonumber(cfg('tp_distance')) or 400) and sp > 3 and sp < 150 then
                            local frozen = IsEntityPositionFrozen and IsEntityPositionFrozen(ped)
                            local v = GetEntityVelocity(ped)
                            local sv = math.sqrt(v.x ^ 2 + v.y ^ 2 + v.z ^ 2)
                            local mismatch = sp > 6 and sv < sp * 0.25
                            if sp > 6 then if mismatch then calib.bad = calib.bad + 1 else calib.good = calib.good + 1 end end
                            local trusted = calib.good >= 200 and calib.bad < calib.good * 0.02
                            if frozen then
                                t.ncF = (t.ncF or 0) + 1
                                if t.ncF >= 4 then t.ncF = 0 Flag(src, 'noclip', ('déplacé à %.1f m/s alors que le joueur est figé'):format(sp)) end
                            else t.ncF = 0 end
                            if mismatch and trusted then
                                t.ncV = (t.ncV or 0) + 1
                                if t.ncV >= 5 then t.ncV = 0 Flag(src, 'noclip', ('déplacé à %.1f m/s pour une vitesse lue de %.1f m/s'):format(sp, sv)) end
                            elseif not mismatch then t.ncV = 0 end
                        else t.ncF, t.ncV = 0, 0 end
                    end
                else t.nc = nil end
            end
        end)
    end
end)
