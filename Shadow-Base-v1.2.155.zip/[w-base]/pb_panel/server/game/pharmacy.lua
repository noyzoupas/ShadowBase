-- (v1.2.99) Pharmacie : point posé au Builder (Commerces › Pharmacie) avec un PNJ, qui vend des soins légers aux joueurs.
-- Volontairement moins efficaces que les secours (EMS) :
--   · ils ne soignent que jusqu'à un plafond (70 % de la vie par défaut) : au-delà, il faut un soignant ;
--   · le soin arrive petit à petit (quelques secondes), pas d'un coup, et rien ne marche à terre (il faut être réanimé) ;
--   · un délai entre deux produits (45 s par défaut) ;
--   · réglages : panel › Entreprises › Réglages › Pharmacie.
local G, DB = PB.G, PB.DB
PB.Cfg.Define('pharmacy', { cap = 70, cooldown = 45 })
local function cfg(k, d) return PB.Cfg.Get('pharmacy', k, d) end
-- nom, libellé, poids, pile, soin total, durée (s), stress, prix de départ, description
local ITEMS = {
    { 'pharma_pansement', 'Pansement', 40, 20, 10, 4, 0, 25, 'Petite blessure : +10 de vie, en 4 s. Pas au-delà de 70 %.' },
    { 'pharma_desinfectant', 'Désinfectant', 120, 10, 6, 3, -5, 20, 'Nettoie une plaie : +6 de vie, un peu moins de stress.' },
    { 'pharma_antidouleur', 'Antidouleur', 30, 20, 18, 12, -15, 60, 'Calme la douleur : +18 de vie en 12 s, moins de stress.' },
    { 'pharma_trousse', 'Petite trousse de secours', 400, 5, 30, 10, 0, 180, "+30 de vie en 10 s. Ne remplace pas les secours : plafond à 70 %." },
}
G.Pharmacy = { ITEMS = ITEMS }
PB.Migrate('592_pharmacy_items', 'Pharmacie : produits de soins légers', function()
    for _, it in ipairs(ITEMS) do
        if G.Inv and G.Inv.EnsureItem then G.Inv.EnsureItem({ name = it[1], label = it[2], weight = it[3], stack = it[4], kind = 'medical', health = 0, stress = 0, usable = true, description = it[9], image = 'img/items/_medic.svg' }) end
    end
end)

local last = {}   -- src -> dernière utilisation (os.time)
AddEventHandler('playerDropped', function() last[source] = nil end)
for _, it in ipairs(ITEMS) do
    local name, label, heal, secs, stress = it[1], it[2], it[5], it[6], it[7]
    CreateThread(function()
        while not (G.Inv and G.Inv.RegisterUsable) do Wait(200) end
        G.Inv.RegisterUsable(name, function(src)
            local p = G.Get(src)
            if not p then return false end
            if PB.ToBool(p.row.dead) then return false, "À terre, seuls les secours peuvent t'aider." end
            local cd = math.max(0, tonumber(cfg('cooldown', 45)) or 45)
            if last[src] and os.time() - last[src] < cd then return false, ('Attends encore %d s avant un autre produit.'):format(cd - (os.time() - last[src])) end
            last[src] = os.time()
            if stress ~= 0 and G.AddStatus then G.AddStatus(src, 'stress', stress) end
            TriggerClientEvent('pb:g:pharma:heal', src, PB.Json({ amount = heal, secs = secs, cap = math.max(10, math.min(100, tonumber(cfg('cap', 70)) or 70)), label = label }))
            return true, label .. ' utilisé.'   -- l'objet est retiré ensuite par l'inventaire
        end)
    end)
end

G.PharmacyForm = PB.Form.Cfg({ ns = 'pharmacy', id = 'settings', title = 'Pharmacie (soins légers)', perm = 'biz.edit', cols = 2,
    desc = "Les produits de la pharmacie soignent moins que les secours : plafond de vie, soin progressif, délai entre deux produits, inutilisables à terre.", fields = {
    { k = 'cap', type = 'number', label = 'Plafond de vie atteint avec les produits (%)', default = 70, min = 10, max = 100 },
    { k = 'cooldown', type = 'number', label = 'Délai entre deux produits (secondes)', default = 45, min = 0, max = 600 },
} })
if G.Biz and G.Biz.ExtraSettings then table.insert(G.Biz.ExtraSettings, function(ctx) return G.PharmacyForm(ctx) end) end
