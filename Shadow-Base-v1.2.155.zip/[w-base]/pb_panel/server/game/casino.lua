-- Casino : posé au Builder (F10 › Builder › Casino). Une caisse (achat / revente de jetons, loterie) et des jeux : machine à sous,
-- roulette, blackjack, roue de la fortune, dés, plus haut / plus bas, tickets à gratter. On joue avec des JETONS (objet de l'inventaire :
-- ils se donnent, se volent, se rangent dans un coffre). Le serveur fait TOUS les tirages : l'interface ne fait qu'animer le résultat.
-- Casino de l'État (par défaut) ou d'une entreprise : la caisse de l'entreprise encaisse les jetons achetés et paie ceux revendus.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G
local Place = PB.Place

P.Register('casino.manage', 'Gérer le casino (jeux, mises, loterie, statistiques)', 'world')
PB.Migrate('529_casino_bans', 'Casino : joueurs interdits', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_casino_bans (license VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', reason VARCHAR(120) NOT NULL DEFAULT '', by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]]))
end)
PB.Migrate('340_casino', 'Casino : parties et loterie', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_casino_log (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', game VARCHAR(12) NOT NULL, bet INT NOT NULL DEFAULT 0, win INT NOT NULL DEFAULT 0, at INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license, at), KEY k_at (at))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_casino_lotto (id INT NOT NULL AUTO_INCREMENT, draw INT NOT NULL, license VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', nums VARCHAR(40) NOT NULL, at INT NOT NULL, matched INT NOT NULL DEFAULT -1, prize INT NOT NULL DEFAULT 0, paid TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY k_draw (draw), KEY k_lic (license, paid))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_casino_draws (id INT NOT NULL, at INT NOT NULL, nums VARCHAR(40) NOT NULL, pot INT NOT NULL DEFAULT 0, tickets INT NOT NULL DEFAULT 0, winners VARCHAR(255) NOT NULL DEFAULT '', PRIMARY KEY (id))]]))
end)

local Ca = {}
G.Casino = Ca
local CHIP = 'jeton_casino'
Ca.CHIP = CHIP
PB.Cfg.Define('casino', {
    enabled = true, closed = false, gift_max = 1000, biz_max_bet = 100000, owner_biz = '', chip_value = 1, sell_fee = 0, min_bet = 10, max_bet = 5000, loss_limit = 0, big_win = 25000, announce = true, props = true, blips = true,
    g_slots = true, g_roulette = true, g_blackjack = true, g_wheel = true, g_dice = true, g_hilo = true, g_scratch = true, g_poker = true,
    poker_sb = 10, poker_bb = 20, poker_min_buy = 20, poker_max_buy = 100, poker_rake = 5, poker_rake_cap = 500, poker_turn = 25, poker_seats = 6,
    bj_soft17 = false, bj_payout = 1.5, dice_side = 2.3, dice_seven = 5.7, hilo_edge = 97, hilo_max = 500, scratch_price = 50,
    lotto = true, lotto_price = 20, lotto_day = 0, lotto_hour = 21, lotto_share = 60, lotto_p4 = 1500, lotto_p3 = 100, lotto_seed = 25000,
    points = {}, lotto_draw = 1, lotto_pot = 0, lotto_last = 0,
})
local function cfg(k, d) return PB.Cfg.Get('casino', k, d) end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function now() return os.time() end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function chipsTxt(n) return tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') .. ' jetons' end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return GetPlayerName(src) or ('Joueur ' .. src) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):sub(1, n)) end
local rnd = math.random

-- Jeux ------------------------------------------------------------------------------------------------------------------------------------
Ca.GAMES = {
    { id = 'slots', label = 'Machine à sous', icon = 'star', prop = 'vw_prop_casino_slot_01a' },
    { id = 'roulette', label = 'Roulette', icon = 'globe', prop = 'vw_prop_casino_roulette_01' },
    { id = 'blackjack', label = 'Blackjack', icon = 'card', prop = 'vw_prop_casino_blckjack_01' },
    { id = 'wheel', label = 'Roue de la fortune', icon = 'sparkle', prop = 'vw_prop_vw_luckywheel_02a' },
    { id = 'dice', label = 'Dés', icon = 'dice', prop = 'vw_prop_casino_3cardpoker_01' },
    { id = 'hilo', label = 'Plus haut / plus bas', icon = 'chart', prop = 'vw_prop_casino_blckjack_01b' },
    { id = 'scratch', label = 'Tickets à gratter', icon = 'gift', prop = 'prop_till_01' },
    { id = 'poker', label = 'Poker', icon = 'user', prop = 'vw_prop_casino_3cardpoker_01' },
}
local GAME = {}
for _, g in ipairs(Ca.GAMES) do GAME[g.id] = g end
local function gameOn(id) return GAME[id] and cfg('g_' .. id, true) ~= false and not Ca.Molo() end   -- tables de Molo : nos jeux se retirent

-- Machine à sous : 3 rouleaux, ligne du milieu. Poids des symboles et gains (fois la mise) ; taux de redistribution calculé exactement.
Ca.SLOT = {
    { id = 'cerise', w = 4, three = 20 }, { id = 'citron', w = 8, three = 9 }, { id = 'raisin', w = 7, three = 10 }, { id = 'cloche', w = 5, three = 25 },
    { id = 'bar', w = 4, three = 50 }, { id = 'sept', w = 2, three = 120 }, { id = 'diamant', w = 1, three = 400 },
}
Ca.SLOT_ONE, Ca.SLOT_TWO = 1, 2   -- une cerise sur la ligne : mise rendue ; deux cerises : mise × 2
local SLOT_TOTAL = 0
for _, s in ipairs(Ca.SLOT) do SLOT_TOTAL = SLOT_TOTAL + s.w end
local function slotPick()
    local r = rnd(1, SLOT_TOTAL)
    for i, s in ipairs(Ca.SLOT) do r = r - s.w if r <= 0 then return i end end
    return #Ca.SLOT
end
function Ca.SlotPay(a, b, c)
    if a == b and b == c then return Ca.SLOT[a].three end
    local n = 0
    for _, i in ipairs({ a, b, c }) do if Ca.SLOT[i].id == 'cerise' then n = n + 1 end end
    return n == 2 and Ca.SLOT_TWO or (n == 1 and Ca.SLOT_ONE or 0)
end
function Ca.SlotRtp()
    local r = 0
    for a, sa in ipairs(Ca.SLOT) do for b, sb in ipairs(Ca.SLOT) do for c, sc in ipairs(Ca.SLOT) do
        r = r + (sa.w * sb.w * sc.w) / SLOT_TOTAL ^ 3 * Ca.SlotPay(a, b, c)
    end end end
    return r
end

-- Roue de la fortune : 40 cases (fois la mise, mise comprise). Ordre fixe, les gros gains éloignés les uns des autres.
Ca.WHEEL = { 0, 1.5, 0, 2, 0, 0, 3, 0, 1.5, 0, 0, 2, 0, 10, 0, 1.5, 0, 0, 2, 0, 5, 0, 1.5, 0, 0, 3, 0, 2, 0, 1.5, 0, 0, 0, 1.5, 0, 0, 0, 0, 0, 0 }
function Ca.WheelRtp() local s = 0 for _, m in ipairs(Ca.WHEEL) do s = s + m end return s / #Ca.WHEEL end

-- Roulette européenne (un seul zéro)
local RED = {}
for _, n in ipairs({ 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36 }) do RED[n] = true end
Ca.RED = RED
-- gain (mise comprise) d'une mise t / v quand la bille tombe sur n ; 0 si perdu
function Ca.RouletteWin(t, v, n)
    v = tonumber(v)
    if t == 'n' then return v == n and 36 or 0 end
    if n == 0 then return 0 end
    if t == 'red' then return RED[n] and 2 or 0 end
    if t == 'black' then return (not RED[n]) and 2 or 0 end
    if t == 'even' then return n % 2 == 0 and 2 or 0 end
    if t == 'odd' then return n % 2 == 1 and 2 or 0 end
    if t == 'low' then return n <= 18 and 2 or 0 end
    if t == 'high' then return n >= 19 and 2 or 0 end
    if t == 'dozen' then return (v and n > (v - 1) * 12 and n <= v * 12) and 3 or 0 end
    if t == 'col' then return (v and ((n - 1) % 3) + 1 == v) and 3 or 0 end
    return 0
end
local BET_T = { n = true, red = true, black = true, even = true, odd = true, low = true, high = true, dozen = true, col = true }

-- Cartes : 0..51, rang = c % 13 (0 = 2 … 8 = 10, 9 = V, 10 = D, 11 = R, 12 = As), couleur = c // 13
local function card(c) return { r = c % 13, s = c // 13 } end
local function shoe(decks)
    local s = {}
    for _ = 1, decks do for c = 0, 51 do s[#s + 1] = c end end
    for i = #s, 2, -1 do local j = rnd(1, i) s[i], s[j] = s[j], s[i] end
    return s
end
function Ca.BjTotal(cards)
    local t, aces = 0, 0
    for _, c in ipairs(cards) do
        local r = c % 13
        if r == 12 then t, aces = t + 11, aces + 1 elseif r >= 8 then t = t + 10 else t = t + r + 2 end
    end
    while t > 21 and aces > 0 do t, aces = t - 10, aces - 1 end
    return t, aces > 0
end
local function bjValue(c) local r = c % 13 return r == 12 and 11 or (r >= 8 and 10 or r + 2) end

-- Tickets à gratter : 9 cases, 3 symboles identiques = gain (fois le prix du ticket)
Ca.SCRATCH = { { id = 'citron', p = 0.12, mult = 1 }, { id = 'cerise', p = 0.08, mult = 2 }, { id = 'cloche', p = 0.04, mult = 5 }, { id = 'bar', p = 0.015, mult = 10 }, { id = 'sept', p = 0.002, mult = 50 }, { id = 'diamant', p = 0.0003, mult = 200 } }
function Ca.ScratchRtp() local s = 0 for _, x in ipairs(Ca.SCRATCH) do s = s + x.p * x.mult end return s end
function Ca.ScratchGrid()
    local roll, win = math.random(), nil
    for _, x in ipairs(Ca.SCRATCH) do if roll < x.p then win = x break end roll = roll - x.p end
    local cells, used = {}, {}
    if win then
        local pos = {}
        for i = 1, 9 do pos[i] = i end
        for i = 9, 2, -1 do local j = rnd(1, i) pos[i], pos[j] = pos[j], pos[i] end
        for i = 1, 3 do cells[pos[i]] = win.id end
        used[win.id] = 3
    end
    for i = 1, 9 do
        if not cells[i] then
            local opts = {}
            for _, x in ipairs(Ca.SCRATCH) do if x ~= win and (used[x.id] or 0) < 2 then opts[#opts + 1] = x.id end end
            local s = opts[rnd(1, #opts)]
            cells[i], used[s] = s, (used[s] or 0) + 1
        end
    end
    return cells, win
end

-- Jetons et caisse ----------------------------------------------------------------------------------------------------------------------
local function owner(src) return G.Inv and G.Inv.PlayerOwner(src) end
-- (v1.2.46) Scripts Molo (molo_casino_core) : ses tables utilisent son solde de jetons. La caisse, le job et l'argent restent ici.
-- Son code est chiffré : chaque ajout et retrait est relu pour vérifier qu'il a bien eu lieu.
local MOLO = 'molo_casino_core'
function Ca.Molo() return cfg('use_molo', true) ~= false and GetResourceState(MOLO) == 'started' end
local function moloChips(src)
    local ok, v = pcall(function() return exports[MOLO]:GetChips(tonumber(src)) end)
    return ok and tonumber(v) or nil
end
local function moloChange(src, fn, n, want)
    local before = moloChips(src)
    if not before or before + want < 0 then return false end
    local ok, err = pcall(function() return exports[MOLO][fn](exports[MOLO], tonumber(src), n) end)
    if not ok then print(('[pb_panel] casino : %s a échoué : %s'):format(fn, tostring(err))) return false end
    for _ = 1, 5 do
        if moloChips(src) == before + want then return true end
        Wait(100)
    end
    print(('[pb_panel] casino : %s sans effet sur le joueur %s (%d jetons demandés)'):format(fn, tostring(src), n))
    return false
end
local function moloAdd(src, n) return moloChange(src, 'AddChips', n, n) end
local function moloTake(src, n) return moloChange(src, 'RemoveChips', n, -n) end
-- Avec Molo, le journal du casino suit la caisse : ce qui entre (jetons vendus) et ce qui sort (jetons rachetés, cadeaux)
function Ca.LogCash(src, kind, paidIn, paidOut)
    if not Ca.Molo() then return end
    local p = G.Get(src)
    if p then DB.insert('INSERT INTO pb_casino_log (license, name, game, bet, win, at) VALUES (?, ?, ?, ?, ?, ?)', { p.license, display(src), kind, paidIn, paidOut, now() }) end
end
function Ca.Chips(src)
    if Ca.Molo() then return moloChips(src) or 0 end
    local o = owner(src)
    return o and G.Inv.Count(o, CHIP) or 0
end
local function push(src) if G.Inv and G.Inv.Push then pcall(G.Inv.Push, src) end end
local function take(src, n)
    if Ca.Molo() then return n >= 1 and moloTake(src, n) end
    local o = owner(src)
    if not o or n < 1 or not G.Inv.Remove(o, CHIP, n) then return false end
    push(src)
    return true
end
-- Les jetons gagnés vont dans le sac ; s'il est plein, leur valeur part à la banque (rien n'est perdu)
local function give(src, n, why)
    if n < 1 then return true end
    local o = owner(src)
    if Ca.Molo() then if moloAdd(src, n) then return true end
    elseif o and G.Inv.Add(o, CHIP, n) then push(src) return true end
    G.AddMoney(src, 'bank', math.floor(n * num('chip_value', 1)), 'Casino : ' .. tostring(why or 'gain') .. ' (sac plein)')
    G.Notify(src, { type = 'warn', title = 'Casino', text = 'Sac plein : ' .. chipsTxt(n) .. ' versés sur ton compte en banque.' })
    return true
end
function Ca.Account() local b = tostring(cfg('owner_biz', '') or '') return b ~= '' and ('biz:' .. b) or 'casino', b ~= '' end
local function canCover(chips)
    local acc, limited = Ca.Account()
    if not limited then return true end
    return G.Eco.Balance(acc) >= math.floor(chips * num('chip_value', 1))
end

-- Pertes sur 24 h (jeu responsable) : lues une fois en base, tenues à jour en mémoire
local losses = {}
local function lossToday(src)
    local p = G.Get(src)
    if not p then return 0 end
    local l = losses[src]
    if not l or now() - l.at > 600 then
        local r = DB.one('SELECT COALESCE(SUM(bet - win), 0) AS n FROM pb_casino_log WHERE license = ? AND at > ?', { p.license, now() - 86400 })
        l = { n = tonumber(r and r.n) or 0, at = now() }
        losses[src] = l
    end
    return l.n
end

-- Trace d'une partie : journal, statistiques, chronologie du joueur, annonce des gros gains
local function record(src, game, bet, win)
    local p = G.Get(src)
    if not p then return end
    DB.insert('INSERT INTO pb_casino_log (license, name, game, bet, win, at) VALUES (?, ?, ?, ?, ?, ?)', { p.license, display(src), game, bet, win, now() })
    if losses[src] then losses[src].n = losses[src].n + bet - win end
    local net = win - bet
    if net ~= 0 and G.Vigil then
        pcall(G.Vigil.Money, src, 'jetons', net, 'Casino : ' .. GAME[game].label)
        if net > 0 then pcall(G.Vigil.Source, p.license, math.floor(net * num('chip_value', 1)), nil, 'casino') end
    end
    if net >= num('big_win', 25000) and net > 0 then
        PB.Audit.Log('casino', 'casino.bigwin', display(src), GAME[game].label, nil, nil, { mise = bet, gain = win })
        if cfg('announce', true) then
            for s in pairs(G.Players()) do G.Notify(s, { type = 'success', title = 'Casino', text = ('%s vient de gagner %s à la %s !'):format(display(src), chipsTxt(win), GAME[game].label:lower()), duration = 8000 }) end
        end
    end
end

-- Points ------------------------------------------------------------------------------------------------------------------------------------
local function points() return cfg('points', {}) or {} end
function Ca.Near(src, kind, radius)
    local best, bd
    local molo = Ca.Molo()
    for _, pt in ipairs(points()) do
        if (not molo or pt.kind == 'cashier') and (not kind or pt.kind == kind or (pt.kind == 'all' and kind ~= 'cashier' and kind ~= 'poker')) then
            local d = G.DistTo(src, pt.x, pt.y, pt.z)
            if d <= (radius or 3.5) and (not bd or d < bd) then best, bd = pt, d end
        end
    end
    return best
end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
-- geste du croupier d'une table : seulement les joueurs à moins de 40 m le reçoivent
function Ca.Dealer(pt)
    if not pt then return end
    for s in pairs(G.Players()) do if G.DistTo(s, pt.x, pt.y, pt.z) < 40.0 then TriggerClientEvent('pb:g:casino:dealer', s, pt.id) end end
end
local DEALS = { blackjack = { deal = true, hit = true, double = true, split = true }, roulette = true, dice = true, hilo = { start = true, guess = true } }
-- pour le poker (server/game/poker.lua) et les autres fichiers du casino
Ca.Take, Ca.Give, Ca.Record, Ca.LossToday, Ca.Usable, Ca.GameOn, Ca.Display = take, give, record, lossToday, usable, gameOn, display

-- Contrôle commun d'une mise : jeu actif, au bon endroit, montant, jetons, limite de pertes, caisse
-- fixed = true : prix imposé (ticket à gratter), les mises minimale et maximale ne s'appliquent pas
local function checkBet(src, game, bet, maxWinMult, fixed)
    if cfg('enabled', true) == false then return false, 'Le casino est fermé.' end
    if not gameOn(game) then return false, 'Ce jeu est fermé.' end
    if not Ca.Near(src, game) then return false, 'Approche-toi du jeu.' end
    bet = math.floor(tonumber(bet) or 0)
    local mn, mx = num('min_bet', 10), num('max_bet', 5000)
    if bet < 1 then return false, 'Mise invalide.' end
    if not fixed and bet < mn then return false, ('Mise minimale : %s.'):format(chipsTxt(mn)) end
    if not fixed and bet > mx then return false, ('Mise maximale : %s.'):format(chipsTxt(mx)) end
    if Ca.Chips(src) < bet then return false, "Tu n'as pas assez de jetons : passe à la caisse." end
    local lim = num('loss_limit', 0)
    if lim > 0 and lossToday(src) + bet > lim then return false, ('Limite de pertes atteinte (%s sur 24 h). Reviens demain.'):format(chipsTxt(lim)) end
    if maxWinMult and not canCover(bet * maxWinMult) then return false, 'La caisse du casino ne peut pas couvrir cette mise : mise moins.' end
    return true, bet
end

-- États des parties en cours (blackjack, plus haut / plus bas)
local bj, hl = {}, {}
local shoes = {}
local function drawCard(src)
    local s = shoes[src]
    if not s or #s < 52 then s = shoe(6) shoes[src] = s end
    return table.remove(s)
end

-- Blackjack ----------------------------------------------------------------------------------------------------------------------------------
local function bjView(st, reveal)
    local hands = {}
    for i, h in ipairs(st.hands) do
        local cs = {}
        for _, c in ipairs(h.cards) do cs[#cs + 1] = card(c) end
        hands[#hands + 1] = { cards = cs, total = (Ca.BjTotal(h.cards)), bet = h.bet, done = h.done, result = h.result, win = h.win, active = (i == st.active and not st.over) or nil }
    end
    local dc = {}
    for i, c in ipairs(st.dealer) do if reveal or i == 1 then dc[#dc + 1] = card(c) else dc[#dc + 1] = { hidden = true } end end
    local h = st.hands[st.active]
    local acts = {}
    if not st.over and h and not h.done then
        acts = { 'hit', 'stand' }
        if #h.cards == 2 then
            acts[#acts + 1] = 'double'
            if #st.hands == 1 and bjValue(h.cards[1]) == bjValue(h.cards[2]) then acts[#acts + 1] = 'split' end
        end
    end
    return { hands = hands, dealer = dc, dealerTotal = reveal and (Ca.BjTotal(st.dealer)) or bjValue(st.dealer[1]), over = st.over or nil, actions = acts, total = st.totalWin }
end
local function bjSettle(src, st)
    local soft17 = cfg('bj_soft17', false) == true
    local live = false
    for _, h in ipairs(st.hands) do if Ca.BjTotal(h.cards) <= 21 then live = true end end
    if live then
        while true do
            local t, soft = Ca.BjTotal(st.dealer)
            if t < 17 or (soft17 and t == 17 and soft) then st.dealer[#st.dealer + 1] = drawCard(src) else break end
        end
    end
    local dt = Ca.BjTotal(st.dealer)
    local dealerBj = dt == 21 and #st.dealer == 2
    local bet, win = 0, 0
    for _, h in ipairs(st.hands) do
        local t = Ca.BjTotal(h.cards)
        local natural = t == 21 and #h.cards == 2 and #st.hands == 1
        bet = bet + h.bet
        if t > 21 then h.result, h.win = 'bust', 0
        elseif natural and not dealerBj then h.result, h.win = 'blackjack', math.floor(h.bet * (1 + num('bj_payout', 1.5)))
        elseif dealerBj and not natural then h.result, h.win = 'lose', 0
        elseif dt > 21 or t > dt then h.result, h.win = 'win', h.bet * 2
        elseif t == dt then h.result, h.win = 'push', h.bet
        else h.result, h.win = 'lose', 0 end
        win = win + h.win
    end
    st.over, st.totalWin = true, win
    give(src, win, 'blackjack')
    record(src, 'blackjack', bet, win)
    bj[src] = nil
    return bjView(st, true)
end
local function bjNext(src, st)
    local h = st.hands[st.active]
    if h and not h.done then return bjView(st, false) end
    if st.active < #st.hands then
        st.active = st.active + 1
        local n = st.hands[st.active]
        if #n.cards < 2 then n.cards[#n.cards + 1] = drawCard(src) end
        if n.splitAce or Ca.BjTotal(n.cards) >= 21 then n.done = true return bjNext(src, st) end
        return bjView(st, false)
    end
    return bjSettle(src, st)
end
function Ca.Blackjack(src, action, p)
    local st = bj[src]
    if action == 'deal' then
        if st then return false, 'Termine la main en cours.' end
        local ok, bet = checkBet(src, 'blackjack', p.bet, 5)
        if not ok then return false, bet end
        if not take(src, bet) then return false, "Tu n'as pas assez de jetons." end
        st = { hands = { { cards = { drawCard(src), drawCard(src) }, bet = bet } }, dealer = { drawCard(src), drawCard(src) }, active = 1, at = now() }
        bj[src] = st
        local pt = Ca.BjTotal(st.hands[1].cards)
        local up = bjValue(st.dealer[1])
        if pt == 21 or ((up == 11 or up == 10) and Ca.BjTotal(st.dealer) == 21) then st.hands[1].done = true return true, bjSettle(src, st) end
        return true, bjView(st, false)
    end
    if not st then return false, 'Aucune main en cours.' end
    if not Ca.Near(src, 'blackjack') then return false, 'Approche-toi de la table.' end
    local h = st.hands[st.active]
    if action == 'hit' then
        h.cards[#h.cards + 1] = drawCard(src)
        if Ca.BjTotal(h.cards) >= 21 then h.done = true end
    elseif action == 'stand' then
        h.done = true
    elseif action == 'double' then
        if #h.cards ~= 2 then return false, 'Doubler : seulement sur les deux premières cartes.' end
        if not canCover(h.bet * 4) then return false, 'La caisse du casino ne peut pas couvrir.' end
        if not take(src, h.bet) then return false, "Pas assez de jetons pour doubler." end
        h.bet = h.bet * 2
        h.cards[#h.cards + 1] = drawCard(src)
        h.done = true
    elseif action == 'split' then
        if #st.hands ~= 1 or #h.cards ~= 2 or bjValue(h.cards[1]) ~= bjValue(h.cards[2]) then return false, 'Partager : deux cartes de même valeur, une seule fois.' end
        if not canCover(h.bet * 5) then return false, 'La caisse du casino ne peut pas couvrir.' end
        if not take(src, h.bet) then return false, "Pas assez de jetons pour partager." end
        local aces = h.cards[1] % 13 == 12
        local second = { cards = { h.cards[2] }, bet = h.bet, splitAce = aces or nil }
        h.cards = { h.cards[1], drawCard(src) }
        h.splitAce = aces or nil
        st.hands[2] = second
        if aces or Ca.BjTotal(h.cards) >= 21 then h.done = true end
    else
        return false, 'Action inconnue.'
    end
    return true, bjNext(src, st)
end

-- Plus haut / plus bas ------------------------------------------------------------------------------------------------------------------------
local function hlStep(cur, dir)
    local wins = dir == 'hi' and (12 - cur) or cur
    if wins <= 0 then return nil end
    return 12 / wins * num('hilo_edge', 97) / 100
end
local function hlView(st)
    return { card = card(st.card), mult = math.floor(st.mult * 100 + 0.5) / 100, bet = st.bet, cash = math.floor(st.bet * st.mult), steps = st.steps,
        hi = hlStep(st.card % 13, 'hi') and math.floor(hlStep(st.card % 13, 'hi') * 100 + 0.5) / 100 or nil, lo = hlStep(st.card % 13, 'lo') and math.floor(hlStep(st.card % 13, 'lo') * 100 + 0.5) / 100 or nil, history = st.history }
end
function Ca.HiLo(src, action, p)
    local st = hl[src]
    if action == 'start' then
        if st then return false, 'Encaisse ou termine la partie en cours.' end
        local ok, bet = checkBet(src, 'hilo', p.bet, num('hilo_max', 500))
        if not ok then return false, bet end
        if not take(src, bet) then return false, "Tu n'as pas assez de jetons." end
        local c = rnd(0, 51)
        st = { bet = bet, card = c, mult = 1, steps = 0, history = { card(c) } }
        hl[src] = st
        return true, hlView(st)
    end
    if not st then return false, 'Aucune partie en cours.' end
    if action == 'guess' then
        local dir = p.dir == 'lo' and 'lo' or 'hi'
        local step = hlStep(st.card % 13, dir)
        if not step then return false, 'Impossible : choisis l\'autre sens.' end
        local nxt = rnd(0, 51)
        local a, b = st.card % 13, nxt % 13
        st.card = nxt
        st.history[#st.history + 1] = card(nxt)
        if #st.history > 14 then table.remove(st.history, 1) end
        if a == b then local v = hlView(st) v.result = 'push' return true, v end   -- égalité : rien ne change
        if (dir == 'hi' and b > a) or (dir == 'lo' and b < a) then
            st.mult = math.min(num('hilo_max', 500), st.mult * step)
            st.steps = st.steps + 1
            local v = hlView(st)
            v.result = 'win'
            if st.mult >= num('hilo_max', 500) or st.steps >= 12 then return Ca.HiLo(src, 'cash', {}) end
            return true, v
        end
        hl[src] = nil
        record(src, 'hilo', st.bet, 0)
        local v = hlView(st)
        v.result, v.over, v.cash = 'lose', true, 0
        return true, v
    elseif action == 'cash' then
        if st.steps < 1 then return false, 'Gagne au moins un coup avant d\'encaisser.' end
        local win = math.floor(st.bet * st.mult)
        hl[src] = nil
        give(src, win, 'plus haut / plus bas')
        record(src, 'hilo', st.bet, win)
        local v = hlView(st)
        v.result, v.over, v.cash = 'cash', true, win
        return true, v
    end
    return false, 'Action inconnue.'
end

-- Jeux en un coup ----------------------------------------------------------------------------------------------------------------------------
function Ca.Slots(src, p)
    local ok, bet = checkBet(src, 'slots', p.bet, Ca.SLOT[#Ca.SLOT].three)
    if not ok then return false, bet end
    if not take(src, bet) then return false, "Tu n'as pas assez de jetons." end
    local line = { slotPick(), slotPick(), slotPick() }
    local mult = Ca.SlotPay(line[1], line[2], line[3])
    local win = bet * mult
    give(src, win, 'machine à sous')
    record(src, 'slots', bet, win)
    local reels = {}
    for i = 1, 3 do reels[i] = { Ca.SLOT[slotPick()].id, Ca.SLOT[line[i]].id, Ca.SLOT[slotPick()].id } end
    return true, { reels = reels, mult = mult, win = win, bet = bet }
end
function Ca.Roulette(src, p)
    local list, total = {}, 0
    for _, b in ipairs(type(p.bets) == 'table' and p.bets or {}) do
        if #list >= 40 then break end
        local t, v, a = tostring(b.t or ''), tonumber(b.v), math.floor(tonumber(b.a) or 0)
        local valid = BET_T[t] and a > 0 and ((t == 'n' and v and v >= 0 and v <= 36 and v == math.floor(v)) or ((t == 'dozen' or t == 'col') and (v == 1 or v == 2 or v == 3)) or (t ~= 'n' and t ~= 'dozen' and t ~= 'col'))
        if not valid then return false, 'Mise invalide.' end
        list[#list + 1] = { t = t, v = v, a = a }
        total = total + a
    end
    if #list == 0 then return false, 'Pose au moins un jeton sur le tapis.' end
    local maxWin = 0
    for _, b in ipairs(list) do maxWin = maxWin + b.a * (b.t == 'n' and 36 or ((b.t == 'dozen' or b.t == 'col') and 3 or 2)) end
    local ok, err = checkBet(src, 'roulette', total, nil)
    if not ok then return false, err end
    if not canCover(maxWin) then return false, 'La caisse du casino ne peut pas couvrir ces mises.' end
    if not take(src, total) then return false, "Tu n'as pas assez de jetons." end
    local n = rnd(0, 36)
    local win = 0
    for _, b in ipairs(list) do b.win = b.a * Ca.RouletteWin(b.t, b.v, n) win = win + b.win end
    give(src, win, 'roulette')
    record(src, 'roulette', total, win)
    return true, { n = n, red = RED[n] or false, win = win, bet = total, bets = list }
end
function Ca.Wheel(src, p)
    local top = 0
    for _, m in ipairs(Ca.WHEEL) do if m > top then top = m end end
    local ok, bet = checkBet(src, 'wheel', p.bet, top)
    if not ok then return false, bet end
    if not take(src, bet) then return false, "Tu n'as pas assez de jetons." end
    local i = rnd(1, #Ca.WHEEL)
    local mult = Ca.WHEEL[i]
    local win = math.floor(bet * mult)
    give(src, win, 'roue de la fortune')
    record(src, 'wheel', bet, win)
    return true, { index = i, mult = mult, win = win, bet = bet }
end
function Ca.Dice(src, p)
    local pick = ({ under = 'under', seven = 'seven', over = 'over' })[tostring(p.pick)]
    if not pick then return false, 'Choisis : moins de 7, 7 ou plus de 7.' end
    local mult = pick == 'seven' and num('dice_seven', 5.7) or num('dice_side', 2.3)
    local ok, bet = checkBet(src, 'dice', p.bet, mult)
    if not ok then return false, bet end
    if not take(src, bet) then return false, "Tu n'as pas assez de jetons." end
    local a, b = rnd(1, 6), rnd(1, 6)
    local s = a + b
    local won = (pick == 'under' and s < 7) or (pick == 'seven' and s == 7) or (pick == 'over' and s > 7)
    local win = won and math.floor(bet * mult) or 0
    give(src, win, 'dés')
    record(src, 'dice', bet, win)
    return true, { d = { a, b }, sum = s, pick = pick, win = win, bet = bet, mult = mult }
end
function Ca.Scratch(src)
    local price = math.floor(num('scratch_price', 50))
    local ok, err = checkBet(src, 'scratch', price, Ca.SCRATCH[#Ca.SCRATCH].mult, true)
    if not ok then return false, err end
    if not take(src, price) then return false, "Tu n'as pas assez de jetons." end
    local cells, w = Ca.ScratchGrid()
    local win = w and price * w.mult or 0
    give(src, win, 'ticket à gratter')
    record(src, 'scratch', price, win)
    return true, { cells = cells, win = win, symbol = w and w.id or nil, price = price }
end

-- Caisse : achat et revente de jetons --------------------------------------------------------------------------------------------------------
function Ca.Buy(src, n, acc)
    n = math.floor(tonumber(n) or 0)
    if n < 1 or n > 1000000 then return false, 'Quantité invalide.' end
    if not Ca.Near(src, 'cashier') then return false, 'Approche-toi de la caisse.' end
    local cost = math.floor(n * num('chip_value', 1) + 0.5)
    acc = acc == 'bank' and 'bank' or 'cash'
    if not G.RemoveMoney(src, acc, cost, 'Casino : achat de jetons') then return false, acc == 'bank' and "Pas assez d'argent en banque." or "Pas assez d'espèces." end
    local o = owner(src)
    local added
    if Ca.Molo() then added = moloAdd(src, n) else added = o and G.Inv.Add(o, CHIP, n) end
    if not added then G.AddMoney(src, acc, cost, 'Casino : achat annulé') return false, Ca.Molo() and "Les jetons n'ont pas pu être ajoutés : tu as été remboursé." or 'Ton sac est plein.' end
    push(src)
    local account = Ca.Account()
    G.Eco.Book(account, cost, 'Casino : vente de jetons', G.Get(src).license)
    Ca.LogCash(src, 'buy', cost, 0)
    return true, ('%s achetés pour %s.'):format(chipsTxt(n), money(cost))
end
function Ca.Sell(src, n)
    n = math.floor(tonumber(n) or 0)
    if n < 1 then return false, 'Quantité invalide.' end
    if not Ca.Near(src, 'cashier') then return false, 'Approche-toi de la caisse.' end
    if Ca.Chips(src) < n then return false, "Tu n'as pas autant de jetons." end
    local pay = math.floor(n * num('chip_value', 1) * (100 - num('sell_fee', 0)) / 100)
    local account, limited = Ca.Account()
    if not take(src, n) then return false, "Tu n'as pas autant de jetons." end
    if limited then
        if not G.Eco.Take(account, pay, 'Casino : rachat de jetons', G.Get(src).license) then give(src, n) return false, "La caisse du casino n'a plus assez d'argent : reviens plus tard." end
    else G.Eco.Book(account, -pay, 'Casino : rachat de jetons', G.Get(src).license) end
    G.AddMoney(src, 'cash', pay, 'Casino : jetons revendus')
    Ca.LogCash(src, 'sell', 0, pay)
    return true, ('%s revendus : %s en espèces.'):format(chipsTxt(n), money(pay))
end

-- Loterie hebdomadaire ----------------------------------------------------------------------------------------------------------------------
local LOTTO_MAX, LOTTO_PICK = 30, 5
local DAYS = { [0] = 'dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi' }
local function parseNums(list)
    local seen, out = {}, {}
    for _, v in ipairs(type(list) == 'table' and list or {}) do
        local n = math.floor(tonumber(v) or 0)
        if n < 1 or n > LOTTO_MAX or seen[n] then return nil end
        seen[n] = true
        out[#out + 1] = n
    end
    if #out ~= LOTTO_PICK then return nil end
    table.sort(out)
    return out
end
function Ca.QuickPick()
    local pool = {}
    for i = 1, LOTTO_MAX do pool[i] = i end
    for i = LOTTO_MAX, 2, -1 do local j = rnd(1, i) pool[i], pool[j] = pool[j], pool[i] end
    local out = { table.unpack(pool, 1, LOTTO_PICK) }
    table.sort(out)
    return out
end
function Ca.Pot() return math.max(math.floor(num('lotto_pot', 0)), math.floor(num('lotto_seed', 25000))) end
-- prochain tirage (horodatage) : jour et heure réglés, au plus tôt après le dernier tirage
function Ca.NextDraw(from)
    from = from or now()
    local d = os.date('*t', from)
    local day, hour = math.floor(num('lotto_day', 0)), math.floor(num('lotto_hour', 21))
    -- on ajoute des JOURS au calendrier (pas des secondes) : l'heure reste juste les semaines de changement d'heure
    local add = (day - (d.wday - 1)) % 7
    local t = os.time({ year = d.year, month = d.month, day = d.day + add, hour = hour, min = 0, sec = 0, isdst = nil })
    if t <= from then t = os.time({ year = d.year, month = d.month, day = d.day + add + 7, hour = hour, min = 0, sec = 0 }) end
    return t
end
function Ca.LottoBuy(src, nums, quick)
    if cfg('lotto', true) == false then return false, 'La loterie est fermée.' end
    if not Ca.Near(src, 'cashier') then return false, 'Approche-toi de la caisse.' end
    local list = quick and Ca.QuickPick() or parseNums(nums)
    if not list then return false, ('Choisis %d numéros différents entre 1 et %d.'):format(LOTTO_PICK, LOTTO_MAX) end
    local p = G.Get(src)
    local draw = math.floor(num('lotto_draw', 1))
    local mine = DB.one('SELECT COUNT(*) AS n FROM pb_casino_lotto WHERE draw = ? AND license = ?', { draw, p.license })
    if mine and (tonumber(mine.n) or 0) >= 20 then return false, '20 tickets maximum par tirage.' end
    local price = math.floor(num('lotto_price', 20))
    if not G.Pay(src, price) then return false, "Tu n'as pas assez d'argent." end
    DB.insert('INSERT INTO pb_casino_lotto (draw, license, name, nums, at) VALUES (?, ?, ?, ?, ?)', { draw, p.license, display(src), table.concat(list, ','), now() })
    local share = math.floor(price * num('lotto_share', 60) / 100)
    PB.Cfg.Set('casino', 'lotto_pot', Ca.Pot() + share, 0, 'Loterie : ticket vendu', true)
    G.Eco.Book((Ca.Account()), price - share, 'Loterie : ticket', p.license)
    return true, ('Ticket enregistré : %s. Tirage %s à %dh.'):format(table.concat(list, ' - '), DAYS[math.floor(num('lotto_day', 0))] or '', math.floor(num('lotto_hour', 21))), list
end
local function payLotto(src)
    local p = G.Get(src)
    if not p then return end
    local rows = DB.q('SELECT id, prize, draw FROM pb_casino_lotto WHERE license = ? AND prize > 0 AND paid = 0', { p.license }) or {}
    for _, r in ipairs(rows) do
        if DB.exec('UPDATE pb_casino_lotto SET paid = 1 WHERE id = ? AND paid = 0', { r.id }) > 0 then
            G.AddMoney(src, 'bank', r.prize, 'Loterie : gain du tirage n°' .. r.draw)
            G.Notify(src, { type = 'success', title = 'Loterie', text = ('Tu as gagné %s au tirage n°%d ! Versé sur ton compte.'):format(money(r.prize), r.draw), duration = 12000 })
        end
    end
end
function Ca.Draw(forced)
    local draw = math.floor(num('lotto_draw', 1))
    local nums = Ca.QuickPick()
    local set = {}
    for _, n in ipairs(nums) do set[n] = true end
    local tickets = DB.q('SELECT id, license, name, nums FROM pb_casino_lotto WHERE draw = ?', { draw }) or {}
    local by = { [5] = {}, [4] = {}, [3] = {} }
    for _, t in ipairs(tickets) do
        local m = 0
        for v in tostring(t.nums):gmatch('%d+') do if set[tonumber(v)] then m = m + 1 end end
        t.m = m
        if by[m] then table.insert(by[m], t) end
    end
    local pot = Ca.Pot()
    local acc = Ca.Account()
    local prizes = {}
    local jack = #by[5] > 0 and math.floor(pot / #by[5]) or 0
    for _, t in ipairs(tickets) do
        local prize = t.m == 5 and jack or (t.m == 4 and math.floor(num('lotto_p4', 1500)) or (t.m == 3 and math.floor(num('lotto_p3', 100)) or 0))
        DB.exec('UPDATE pb_casino_lotto SET matched = ?, prize = ? WHERE id = ?', { t.m, prize, t.id })
        if prize > 0 then
            prizes[#prizes + 1] = ('%s (%d bons, %s)'):format(t.name, t.m, money(prize))
            if t.m < 5 then G.Eco.Book(acc, -prize, 'Loterie : gain', t.license) end
        end
    end
    local newPot = #by[5] > 0 and math.floor(num('lotto_seed', 25000)) or pot
    DB.exec('INSERT INTO pb_casino_draws (id, at, nums, pot, tickets, winners) VALUES (?, ?, ?, ?, ?, ?)', { draw, now(), table.concat(nums, ','), pot, #tickets, table.concat(prizes, ' · '):sub(1, 255) })
    PB.Cfg.SetMany('casino', { lotto_draw = draw + 1, lotto_pot = newPot, lotto_last = now() }, 'système', 'Loterie : tirage n°' .. draw)
    PB.Audit.Log('casino', 'lotto.draw', forced and 'staff' or 'système', 'Tirage n°' .. draw, nil, nil, { numeros = nums, cagnotte = pot, tickets = #tickets, gagnants = #prizes })
    local text = ('Tirage n°%d : %s. %s'):format(draw, table.concat(nums, ' - '), #by[5] > 0 and ('Cagnotte de %s remportée !'):format(money(pot)) or ('Pas de grand gagnant : la cagnotte passe à %s.'):format(money(newPot)))
    for s in pairs(G.Players()) do G.Notify(s, { type = 'info', title = 'Loterie', text = text, duration = 12000 }) payLotto(s) end
    return true, text, nums
end
CreateThread(function()
    while not PB.IsReady do Wait(1000) end
    while true do
        Wait(60000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if cfg('lotto', true) ~= false and cfg('enabled', true) ~= false then
                local last = math.floor(num('lotto_last', 0))
                if last == 0 then PB.Cfg.Set('casino', 'lotto_last', now(), 0, 'Loterie : ouverture', true)
                elseif now() >= Ca.NextDraw(last) then pcall(Ca.Draw, false) end
            end
        end)
        if not ok then PB.Warn('casino', 'boucle : ' .. tostring(err)) end
    end
end)
table.insert(G.beginHooks, function(src) SetTimeout(8000, function() if G.Get(src) then payLotto(src) end end) end)

-- Ce que le joueur voit à l'ouverture
function Ca.Info(src, pt)
    local games = {}
    for _, g in ipairs(Ca.GAMES) do
        if gameOn(g.id) and ((pt.kind == 'all' and g.id ~= 'poker') or pt.kind == g.id) then games[#games + 1] = { id = g.id, label = g.label, icon = g.icon } end
    end
    local slots = {}
    for _, s in ipairs(Ca.SLOT) do slots[#slots + 1] = { id = s.id, three = s.three } end
    local scratch = {}
    for _, s in ipairs(Ca.SCRATCH) do scratch[#scratch + 1] = { id = s.id, mult = s.mult } end
    local p = G.Get(src)
    local draw = math.floor(num('lotto_draw', 1))
    local tickets = {}
    if pt.kind == 'cashier' and p then
        for _, r in ipairs(DB.q('SELECT nums FROM pb_casino_lotto WHERE draw = ? AND license = ? ORDER BY id', { draw, p.license }) or {}) do tickets[#tickets + 1] = r.nums end
    end
    local last = pt.kind == 'cashier' and DB.one('SELECT id, nums, pot FROM pb_casino_draws ORDER BY id DESC LIMIT 1') or nil
    return {
        point = { id = pt.id, kind = pt.kind, label = pt.label }, games = games, chips = Ca.Chips(src), value = num('chip_value', 1), fee = num('sell_fee', 0),
        min = num('min_bet', 10), max = num('max_bet', 5000), cash = G.GetMoney(src, 'cash') or 0, bank = G.GetMoney(src, 'bank') or 0,
        slots = slots, wheel = Ca.WHEEL, scratch = scratch, scratchPrice = math.floor(num('scratch_price', 50)), bjPayout = num('bj_payout', 1.5),
        dice = { side = num('dice_side', 2.3), seven = num('dice_seven', 5.7) },
        lotto = (pt.kind == 'cashier' and cfg('lotto', true) ~= false) and { price = math.floor(num('lotto_price', 20)), pot = Ca.Pot(), draw = draw, next = Ca.NextDraw(math.floor(num('lotto_last', 0)) > 0 and math.floor(num('lotto_last', 0)) or now()),
            max = LOTTO_MAX, pick = LOTTO_PICK, mine = tickets, last = last and { id = last.id, nums = last.nums, pot = last.pot } or nil, p4 = math.floor(num('lotto_p4', 1500)), p3 = math.floor(num('lotto_p3', 100)) } or nil,
        poker = { sb = math.floor(num('poker_sb', 10)), bb = math.floor(num('poker_bb', 20)), minBuy = math.floor(num('poker_min_buy', 20) * num('poker_bb', 20)), maxBuy = math.floor(num('poker_max_buy', 100) * num('poker_bb', 20)), rake = num('poker_rake', 5) },
        bj = bj[src] and bjView(bj[src], false) or nil, hilo = hl[src] and hlView(hl[src]) or nil,
    }
end

-- Historique d'un joueur : dernières parties, bilans du jour, de la semaine et depuis toujours, jeu préféré, plus gros gain
function Ca.History(src)
    local p = G.Get(src)
    if not p then return false, 'Joueur introuvable.' end
    local function sum(since)
        local r = DB.one('SELECT COUNT(*) AS n, COALESCE(SUM(bet), 0) AS b, COALESCE(SUM(win), 0) AS w FROM pb_casino_log WHERE license = ? AND at > ?', { p.license, since })
        return { n = tonumber(r and r.n) or 0, bet = tonumber(r and r.b) or 0, win = tonumber(r and r.w) or 0 }
    end
    local rows = {}
    for _, r in ipairs(DB.q('SELECT game, bet, win, at FROM pb_casino_log WHERE license = ? ORDER BY id DESC LIMIT 40', { p.license }) or {}) do
        rows[#rows + 1] = { game = GAME[r.game] and GAME[r.game].label or r.game, bet = tonumber(r.bet) or 0, win = tonumber(r.win) or 0, at = r.at }
    end
    local fav = DB.one('SELECT game, COUNT(*) AS n FROM pb_casino_log WHERE license = ? GROUP BY game ORDER BY n DESC LIMIT 1', { p.license })
    local best = DB.one('SELECT game, bet, win, at FROM pb_casino_log WHERE license = ? AND win > bet ORDER BY (win - bet) DESC LIMIT 1', { p.license })
    local day0 = os.time({ year = tonumber(os.date('%Y', now())), month = tonumber(os.date('%m', now())), day = tonumber(os.date('%d', now())), hour = 0 })
    return true, { rows = rows, today = sum(day0), week = sum(now() - 7 * 86400), all = sum(0),
        fav = fav and (GAME[fav.game] and GAME[fav.game].label or fav.game) or nil,
        best = best and { game = GAME[best.game] and GAME[best.game].label or best.game, net = (tonumber(best.win) or 0) - (tonumber(best.bet) or 0), at = best.at } or nil,
        limit = num('loss_limit', 0), lossToday = lossToday(src) }
end

-- Événements --------------------------------------------------------------------------------------------------------------------------------
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
local function reply(src, d) TriggerClientEvent('pb:g:casino:res', src, PB.Json(d)) end

-- (v1.2.46) Job casino : salle fermée par la direction, joueurs interdits. La revente de jetons à la caisse reste toujours possible.
local bans
local function bansMap()
    if not bans then
        bans = {}
        for _, r in ipairs(DB.q('SELECT license FROM pb_casino_bans') or {}) do bans[r.license] = true end
    end
    return bans
end
function Ca.Barred(src)
    if cfg('closed', false) == true then return 'Le casino est fermé pour le moment. La caisse reste ouverte pour revendre tes jetons.' end
    local p = G.Get(src)
    if p and bansMap()[p.license] then return 'Tu es interdit de casino. Tu peux seulement revendre tes jetons à la caisse.' end
end
function Ca.Ban(license, name, reason, by)
    DB.exec('REPLACE INTO pb_casino_bans (license, name, reason, by_name, at) VALUES (?, ?, ?, ?, ?)', { license, tostring(name):sub(1, 64), tostring(reason):sub(1, 120), tostring(by):sub(1, 64), now() })
    bansMap()[license] = true
end
function Ca.Unban(license)
    DB.exec('DELETE FROM pb_casino_bans WHERE license = ?', { tostring(license) })
    bansMap()[tostring(license)] = nil
end
function Ca.Bans() return DB.q('SELECT license, name, reason, by_name, at FROM pb_casino_bans ORDER BY at DESC LIMIT 100') or {} end
function Ca.Stats(since)
    local r = DB.one('SELECT COUNT(*) AS n, COALESCE(SUM(bet), 0) AS b, COALESCE(SUM(win), 0) AS w, COUNT(DISTINCT license) AS p FROM pb_casino_log WHERE at >= ?', { since })
    return { n = tonumber(r and r.n) or 0, bet = tonumber(r and r.b) or 0, win = tonumber(r and r.w) or 0, players = tonumber(r and r.p) or 0 }
end
function Ca.ByGame(since)
    local out = {}
    for _, r in ipairs(DB.q('SELECT game, COUNT(*) AS n, COALESCE(SUM(bet), 0) AS b, COALESCE(SUM(win), 0) AS w FROM pb_casino_log WHERE at >= ? GROUP BY game', { since }) or {}) do
        out[#out + 1] = { label = Ca.GameLabel(r.game), n = tonumber(r.n) or 0, bet = tonumber(r.b) or 0, win = tonumber(r.w) or 0 }
    end
    table.sort(out, function(a, b) return (a.bet - a.win) > (b.bet - b.win) end)
    return out
end
function Ca.BigWins(since, n)
    return DB.q('SELECT name, game, bet, win, at FROM pb_casino_log WHERE at >= ? AND win > bet ORDER BY win - bet DESC LIMIT ?', { since, n or 8 }) or {}
end
local CASH_LABEL = { buy = 'Jetons vendus', sell = 'Jetons rachetés', gift = 'Jetons offerts' }
function Ca.GameLabel(id) return GAME[id] and GAME[id].label or CASH_LABEL[id] or tostring(id) end
function Ca.HasCashier() for _, pt in ipairs(points()) do if pt.kind == 'cashier' then return true end end return false end
function Ca.PointCount() return #points() end
function Ca.IsManager(c) return c.boss or G.Biz.Can(c, 'vault') or G.Biz.Can(c, 'hire') end

-- Gestes du croupier (menu F6, en service, entreprise reliée au casino)
function Ca.Job(src, c, a, p, tp, tid, name)
    if tostring(cfg('owner_biz', '') or '') ~= c.biz.id then return false, "Le casino n'est pas relié à ton entreprise : la direction le fait depuis la tablette, page Salle de jeux." end
    if tid == src then return false, 'Choisis un client.' end
    local account = Ca.Account()
    if a.id == 'job_cas_sell' or a.id == 'job_cas_gift' then
        local n = math.floor(tonumber(p.amount) or 0)
        if n < 1 or n > 1000000 then return false, 'Nombre de jetons invalide.' end
        local barred = Ca.Barred(tid)
        if barred then return false, name .. ' ne peut pas jouer : ' .. (cfg('closed', false) == true and 'le casino est fermé.' or 'interdit de casino.') end
        local cost = math.floor(n * num('chip_value', 1) + 0.5)
        if a.id == 'job_cas_gift' then
            if not Ca.IsManager(c) then return false, 'Réservé à la direction.' end
            local max = num('gift_max', 1000)
            if n > max then return false, ('Geste commercial limité à %s.'):format(chipsTxt(max)) end
            if not G.Eco.Take(account, cost, 'Geste commercial : jetons', tp.license) then return false, "La caisse de l'entreprise n'a pas assez d'argent." end
            give(tid, n, 'cadeau')
            Ca.LogCash(tid, 'gift', 0, cost)
            PB.Audit.Log('casino', 'casino.gift', display(src), name, nil, nil, { jetons = n, cout = cost })
            G.Notify(tid, { type = 'success', title = c.biz.label, text = chipsTxt(n) .. ' offerts par la maison.' })
            return true, chipsTxt(n) .. ' offerts à ' .. name .. '.'
        end
        local D = G.Deals
        if not D then return false, 'Indisponible.' end
        local wait = tonumber(PB.Cfg.Get('deals', 'offer_secs', 60)) or 60
        if D.offers[tid] and now() - D.offers[tid].at < wait then return false, 'Cette personne a déjà une proposition en attente.' end
        local sp = G.Get(src)
        D.offers[tid] = { seller = src, sellerLic = sp.license, kind = 'chips', ref = CHIP, label = chipsTxt(n), price = cost, at = now(), accept = function()
            if G.DistBetween(src, tid) > 8 then return false, 'Le croupier doit être à côté de toi.' end
            if not G.Pay(tid, cost, 'cash') then return false, ('Il te faut %s.'):format(money(cost)) end
            give(tid, n, 'achat')
            G.Eco.Book(account, cost, 'Vente jetons · ' .. chipsTxt(n), tp.license)
            Ca.LogCash(tid, 'buy', cost, 0)
            G.Notify(src, { type = 'success', title = 'Casino', text = ('%s : %s vendus pour %s.'):format(name, chipsTxt(n), money(cost)) })
            return true, chipsTxt(n) .. ' achetés pour ' .. money(cost) .. '.'
        end }
        TriggerClientEvent('pb:g:deal:offer', tid, PB.Json({ from = c.biz.label .. ' · ' .. display(src), what = chipsTxt(n), price = cost, tax = 0, secs = wait }))
        return true, ('Proposition envoyée à %s : %s pour %s.'):format(name, chipsTxt(n), money(cost))
    end
    if a.id == 'job_cas_ban' then
        if not Ca.IsManager(c) then return false, 'Réservé à la direction.' end
        local why = tostring(p.reason or ''):gsub('[%c<>]', ''):sub(1, 120)
        if #why < 3 then return false, 'Indique le motif.' end
        Ca.Ban(tp.license, name, why, display(src))
        PB.Audit.Log('casino', 'casino.ban', display(src), name, nil, nil, { motif = why })
        G.Notify(tid, { type = 'warn', title = c.biz.label, text = 'Tu es interdit de casino : ' .. why })
        return true, name .. ' est interdit de casino.'
    end
    return false, 'Action inconnue.'
end
-- Surveillance : qui joue en salle, avec combien de jetons, et ce qu'il a perdu ou gagné sur 24 h
function Ca.Floor(src)
    local rows = {}
    for id, pl in pairs(G.Players()) do
        local inRoom = false
        if Ca.Molo() then inRoom = G.DistTo(id, 958.0, 33.0, 78.0) <= 75   -- zone du casino (Config.CasinoZone de Molo)
        else for _, pt in ipairs(points()) do if G.DistTo(id, pt.x, pt.y, pt.z) <= 40 then inRoom = true break end end end
        if inRoom and id ~= src then
            local l = lossToday(id)
            rows[#rows + 1] = { display(id), ('%s · %s 24 h : %s%s'):format(chipsTxt(Ca.Chips(id)), l >= 0 and 'perdu' or 'gagné', chipsTxt(math.abs(l)), bansMap()[pl.license] and ' · INTERDIT' or '') }
        end
    end
    if #rows == 0 then return true, "Personne n'est en salle pour le moment." end
    G.Info(src, { title = 'Joueurs en salle', rows = rows, secs = 20 })
    return true
end

RegisterNetEvent('pb:g:casino:open', function()
    local src = source
    if not throttle(src, 800) or not usable(src) then return end
    if cfg('enabled', true) == false then G.Notify(src, { type = 'error', title = 'Casino', text = 'Le casino est fermé.' }) return end
    local pt = Ca.Near(src, nil, 3.0)
    if not pt then return end
    local barred = Ca.Barred(src)
    if barred and pt.kind ~= 'cashier' then G.Notify(src, { type = 'warn', title = 'Casino', text = barred }) return end
    TriggerClientEvent('pb:g:casino:ui', src, PB.Json(Ca.Info(src, pt)))
end)

RegisterNetEvent('pb:g:casino:act', function(game, action, j)
    local src = source
    if not throttle(src, 450) or not usable(src) then return end
    local p = type(j) == 'string' and (PB.FromJson(j, {}) or {}) or (type(j) == 'table' and j or {})
    game, action = tostring(game or ''), tostring(action or '')
    local barred = Ca.Barred(src)
    -- une main déjà en cours se termine, et le poker garde sa propre sortie de table : les jetons misés ne sont jamais perdus par une fermeture
    if barred and ((game == 'cashier' and action ~= 'sell') or (GAME[game] and game ~= 'poker' and not bj[src] and not hl[src])) then
        reply(src, { game = game, action = action, ok = false, msg = barred, chips = Ca.Chips(src) })
        return
    end
    local ok, res, extra
    if game == 'cashier' then
        if action == 'buy' then ok, res = Ca.Buy(src, p.n, p.acc)
        elseif action == 'sell' then ok, res = Ca.Sell(src, p.n)
        elseif action == 'lotto' then ok, res, extra = Ca.LottoBuy(src, p.nums, p.quick == true)
        else ok, res = false, 'Action inconnue.' end
        local pt = Ca.Near(src, 'cashier')
        reply(src, { game = game, action = action, ok = ok, msg = res, info = pt and Ca.Info(src, pt) or nil, nums = extra })
        return
    end
    if game == 'history' then
        local okh, data = Ca.History(src)
        reply(src, { game = 'history', action = action, ok = okh, data = okh and data or nil, msg = (not okh) and data or nil, chips = Ca.Chips(src) })
        return
    end
    if not GAME[game] then return end
    local okc, a, b = pcall(function()
        if game == 'slots' then return Ca.Slots(src, p)
        elseif game == 'roulette' then return Ca.Roulette(src, p)
        elseif game == 'blackjack' then return Ca.Blackjack(src, action, p)
        elseif game == 'wheel' then return Ca.Wheel(src, p)
        elseif game == 'dice' then return Ca.Dice(src, p)
        elseif game == 'hilo' then return Ca.HiLo(src, action, p)
        elseif game == 'scratch' then return Ca.Scratch(src)
        elseif game == 'poker' and Ca.Poker then return Ca.Poker(src, action, p) end
    end)
    if not okc then PB.Err('casino ' .. game .. ' : ' .. tostring(a)) ok, res = false, 'Erreur du jeu, réessaie.' else ok, res = a, b end
    local dl = DEALS[game]
    if ok and dl and (dl == true or dl[action]) then Ca.Dealer(Ca.Near(src, game)) end
    reply(src, { game = game, action = action, ok = ok and true or false, msg = (not ok) and res or nil, data = ok and res or nil, chips = Ca.Chips(src) })
end)

-- On s'éloigne ou on ferme : une partie de plus haut / plus bas gagnante est encaissée, une main de blackjack est jouée (on reste)
RegisterNetEvent('pb:g:casino:close', function()
    local src = source
    if hl[src] and hl[src].steps > 0 then Ca.HiLo(src, 'cash', {}) elseif hl[src] then record(src, 'hilo', hl[src].bet, 0) hl[src] = nil end
    if bj[src] then local st = bj[src] for _, h in ipairs(st.hands) do h.done = true end st.active = #st.hands pcall(bjSettle, src, st) end
    if Ca.PokerLeave then pcall(Ca.PokerLeave, src, 'fenêtre fermée') end
end)
AddEventHandler('playerDropped', function()
    local src = source
    last[src], losses[src], shoes[src] = nil, nil, nil
    if hl[src] then hl[src] = nil end
    bj[src] = nil
end)

-- Builder -----------------------------------------------------------------------------------------------------------------------------------
local function uid() return ('cas_%d%d'):format(os.time() % 1000000, math.random(10, 99)) end
local function addPoint(row)
    local list = {}
    for _, r in ipairs(points()) do list[#list + 1] = r end
    list[#list + 1] = row
    PB.Cfg.Set('casino', 'points', list, 0, 'Casino : ' .. row.label)
    G.PushConfig()
end
local function listKind(kind)
    local out = {}
    for _, r in ipairs(points()) do if (kind == 'cashier') == (r.kind == 'cashier') then out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y } end end
    return out
end
local function removePoint(id)
    local out = {}
    for _, r in ipairs(points()) do if tostring(r.id) ~= tostring(id) then out[#out + 1] = r end end
    PB.Cfg.Set('casino', 'points', out, 0, 'Casino : suppression ' .. tostring(id))
    G.PushConfig()
    return true
end
local function f(v) return math.floor((tonumber(v) or 0) * 100 + 0.5) / 100 end
Place.Register({ id = 'casino_cashier', label = 'Casino : caisse (jetons et loterie)', group = 'Casino', icon = 'coins',
    create = function(pos, name)
        addPoint({ id = uid(), kind = 'cashier', label = clean(name ~= '' and name or 'Casino', 40), x = f(pos.x), y = f(pos.y), z = f(pos.z), h = f(pos.h) })
        return true, 'Caisse du casino posée : achat et revente de jetons, loterie. Place maintenant les jeux (Casino : jeu).'
    end,
    list = function() return listKind('cashier') end, remove = removePoint })
local presets = { { 'all', 'Borne : tous les jeux' } }
for _, g in ipairs(Ca.GAMES) do presets[#presets + 1] = { g.id, g.label } end
Place.Register({ id = 'casino_game', label = 'Casino : jeu (machine à sous, roulette, blackjack…)', group = 'Casino', icon = 'dice', presets = presets,
    create = function(pos, name, _, preset)
        if Ca.Molo() then return false, "Les jeux viennent des scripts Molo, déjà dans la salle : rien à poser ici." end
        local kind = (GAME[preset or ''] or preset == 'all') and preset or 'slots'
        local label = clean(tostring(name or ''):match('.* : (.-)$') or name, 40)   -- « Casino : jeu … : Roulette » (Builder) -> « Roulette »
        if label == '' or label:find('Casino : jeu', 1, true) then label = kind == 'all' and 'Borne de jeux' or GAME[kind].label end
        addPoint({ id = uid(), kind = kind, label = label, x = f(pos.x), y = f(pos.y), z = f(pos.z), h = f(pos.h) })
        return true, label .. ' posé(e). Les joueurs y jouent avec E.'
    end,
    list = function() return listKind('game') end, remove = removePoint })

-- Repères du mapping molo_casino (positions tirées des réglages du pack) : F10 › Téléportation › Casino. Rien à poser, rien à montrer au Builder.
local MAP_SPOTS = {
    { 'caisse', 'Caisse', 972.464, 17.394, 80.901 }, { 'salle', 'Salle de jeux', 925.86, 46.23, 81.02 }, { 'roue', 'Roue de la fortune', 915.99, 20.30, 79.89 },
    { 'podium', 'Voiture du podium', 918.743, 14.116, 81.145 }, { 'bar', 'Bar', 927.99, 7.98, 75.899 }, { 'hotel', 'Hôtel : couloir des chambres', 996.37, 55.79, 76.05 },
    { 'hall', 'Ascenseur : hall', 1002.89, 74.22, 70.22 }, { 'resto', 'Ascenseur : restaurant', 977.52, 52.87, 16.21 },
}
Place.Register({ id = 'casino_map', label = 'Casino : repère du mapping', group = 'Casino', icon = 'pin', hidden = true, tp = true,
    create = function() return false, 'Ces repères viennent du mapping.' end,
    list = function()
        if GetResourceState('molo_casino') == 'missing' then return {} end
        local out = {}
        for _, s in ipairs(MAP_SPOTS) do out[#out + 1] = { id = s[1], label = s[2], x = s[3], y = s[4], z = s[5] } end
        return out
    end, remove = function() return false end })

-- Configuration envoyée aux joueurs : points, décor
local oldCC = G.ClientConfig
function G.ClientConfig()
    local c = oldCC()
    local props = {}
    for _, g in ipairs(Ca.GAMES) do props[g.id] = g.prop end
    local pts = points()
    if Ca.Molo() then
        pts = {}
        for _, pt in ipairs(points()) do if pt.kind == 'cashier' then pts[#pts + 1] = pt end end
    end
    c.casino = { enabled = cfg('enabled', true) ~= false, points = pts, props = cfg('props', true) ~= false and props or nil, blips = cfg('blips', true) ~= false }
    return c
end
PB.Cfg.OnChange('casino', function(k) if k ~= 'lotto_pot' and k ~= 'lotto_last' and k ~= 'lotto_draw' then G.PushConfig() end end)

-- Scripts Molo : leurs tables (stockage mysql), et la caisse à l'endroit prévu par le pack si aucune n'est posée
local function moloSetup()
    if not Ca.Molo() then return end
    local has = false
    for _, pt in ipairs(points()) do if pt.kind == 'cashier' then has = true end end
    if not has then addPoint({ id = uid(), kind = 'cashier', label = 'Caisse du casino', x = 972.464, y = 17.394, z = 80.901, h = 60.32 }) end
    G.PushConfig()
end
PB.OnReady(function()
    if GetResourceState(MOLO) == 'missing' then return end
    DB.exec([[CREATE TABLE IF NOT EXISTS molo_casino_chips (identifier VARCHAR(64) NOT NULL, chips INT UNSIGNED NOT NULL DEFAULT 0, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (identifier)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
    DB.exec([[CREATE TABLE IF NOT EXISTS molo_casino_wheel (identifier VARCHAR(64) NOT NULL, last_spin TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (identifier)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
    DB.exec([[CREATE TABLE IF NOT EXISTS molo_casino_logs (id INT UNSIGNED NOT NULL AUTO_INCREMENT, identifier VARCHAR(64) NOT NULL, action VARCHAR(32) NOT NULL, amount INT NOT NULL DEFAULT 0, balance_after INT UNSIGNED NOT NULL DEFAULT 0, meta VARCHAR(191) DEFAULT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_identifier (identifier), KEY idx_action_date (action, created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
    DB.exec([[CREATE TABLE IF NOT EXISTS molo_casino_hotel (room_id VARCHAR(48) NOT NULL, identifier VARCHAR(64) NOT NULL, expires_at TIMESTAMP NOT NULL, guests TEXT DEFAULT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (room_id), KEY idx_identifier (identifier), KEY idx_expires (expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
    moloSetup()
end)
AddEventHandler('onServerResourceStart', function(r) if r == MOLO then moloSetup() end end)
AddEventHandler('onServerResourceStop', function(r) if r == MOLO then G.PushConfig() end end)
-- Anciens jetons du sac : passés sur le solde Molo à la connexion
table.insert(G.beginHooks, function(src)
    if not Ca.Molo() then return end
    local o = owner(src)
    local n = o and G.Inv.Count(o, CHIP) or 0
    if n > 0 and G.Inv.Remove(o, CHIP, n) then
        if moloAdd(src, n) then G.Notify(src, { type = 'info', title = 'Casino', text = chipsTxt(n) .. ' de ton sac sont passés sur ton solde du casino.' })
        else G.Inv.Add(o, CHIP, n) end
        push(src)
    end
end)

-- Objet « jeton » (poids nul, grosses piles)
PB.OnReady(function()
    if not DB.one('SELECT name FROM pb_inv_items WHERE name = ?', { CHIP }) then
        DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, 0, 1000000, ?, 0, ?)', { CHIP, 'Jeton de casino', 'misc', 'Se joue au casino, se revend à la caisse.' })
        if G.Inv and G.Inv.Reload then G.Inv.Reload() end
    end
end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------------
PB.Action('casino.draw', 'casino.manage', function(ctx)
    local ok, text = Ca.Draw(true)
    ctx.audit('casino', 'lotto.draw.now', 'tirage')
    ctx.toast = text
    return ok
end, { confirm = { title = 'Faire le tirage maintenant ?', text = 'Les tickets du tirage en cours sont comparés aux numéros tirés et les gagnants payés.' } })
PB.Action('casino.point.del', 'casino.manage', function(ctx, p)
    removePoint(p.id)
    ctx.audit('casino', 'casino.point.del', tostring(p.id))
    ctx.toast = 'Point supprimé.'
    return true
end)
-- liste des entreprises du choix « Propriétaire » : remise à jour à chaque affichage du module (le formulaire valide avec la même liste)
local ownerField = { k = 'owner_biz', type = 'select', label = 'Propriétaire (caisse qui encaisse et paie)', default = '', opts = { { '', "Casino de l'État (aucune entreprise)" } },
    hint = "Une entreprise : la vente de jetons remplit sa caisse, le rachat la vide (refusé si la caisse est vide), et les grosses mises sont refusées si elle ne peut pas les couvrir." }
local function refreshOwners()
    local o = { { '', "Casino de l'État (aucune entreprise)" } }
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do o[#o + 1] = { b.id, b.label } end
    local cur = tostring(cfg('owner_biz', '') or '')
    local found = cur == ''
    for _, x in ipairs(o) do if x[1] == cur then found = true end end
    if not found then o[#o + 1] = { cur, cur .. ' (entreprise supprimée)' } end
    ownerField.opts = o
end
PB.OnReady(refreshOwners)
local form = PB.Form.Cfg({ ns = 'casino', id = 'settings', title = 'Casino', perm = 'casino.manage', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Casino ouvert', default = true },
    ownerField,
    { k = 'chip_value', type = 'number', label = 'Prix d\'un jeton ($)', default = 1, min = 1, max = 1000 },
    { k = 'sell_fee', type = 'number', label = 'Commission au rachat des jetons (%)', default = 0, min = 0, max = 50 },
    { k = 'min_bet', type = 'number', label = 'Mise minimale (jetons)', default = 10, min = 1, max = 100000 },
    { k = 'max_bet', type = 'number', label = 'Mise maximale (jetons)', default = 5000, min = 1, max = 10000000 },
    { k = 'loss_limit', type = 'number', label = 'Pertes maximales par joueur sur 24 h (jetons, 0 = sans limite)', default = 0, min = 0, max = 100000000 },
    { k = 'big_win', type = 'number', label = 'Gros gain : journal et annonce à partir de (jetons)', default = 25000, min = 100, max = 100000000 },
    { k = 'announce', type = 'toggle', label = 'Annoncer les gros gains à tout le serveur', default = true },
    { k = 'props', type = 'toggle', label = 'Poser le décor (machines, tables) sur les points', default = true, hint = 'Modèles du casino de GTA : il faut un serveur en version de jeu 2060 ou plus (sv_enforceGameBuild).' },
    { k = 'blips', type = 'toggle', label = 'Repère du casino sur la carte', default = true },
    { k = 'g_slots', type = 'toggle', label = 'Machine à sous', default = true }, { k = 'g_roulette', type = 'toggle', label = 'Roulette', default = true },
    { k = 'g_blackjack', type = 'toggle', label = 'Blackjack', default = true }, { k = 'g_wheel', type = 'toggle', label = 'Roue de la fortune', default = true },
    { k = 'g_dice', type = 'toggle', label = 'Dés', default = true }, { k = 'g_hilo', type = 'toggle', label = 'Plus haut / plus bas', default = true },
    { k = 'g_scratch', type = 'toggle', label = 'Tickets à gratter', default = true }, { k = 'g_poker', type = 'toggle', label = 'Poker entre joueurs', default = true },
    { k = 'poker_sb', type = 'number', label = 'Poker : petite blinde (jetons)', default = 10, min = 1, max = 100000 },
    { k = 'poker_bb', type = 'number', label = 'Poker : grosse blinde (jetons)', default = 20, min = 2, max = 200000 },
    { k = 'poker_min_buy', type = 'number', label = 'Poker : cave minimale (en grosses blindes)', default = 20, min = 5, max = 500 },
    { k = 'poker_max_buy', type = 'number', label = 'Poker : cave maximale (en grosses blindes)', default = 100, min = 10, max = 1000 },
    { k = 'poker_rake', type = 'number', label = 'Poker : commission du casino sur le pot (%, dès le flop)', default = 5, min = 0, max = 20 },
    { k = 'poker_rake_cap', type = 'number', label = 'Poker : commission maximale par main (jetons)', default = 500, min = 0, max = 1000000 },
    { k = 'poker_turn', type = 'number', label = 'Poker : temps pour jouer (secondes)', default = 25, min = 10, max = 120 },
    { k = 'poker_seats', type = 'number', label = 'Poker : places par table', default = 6, min = 2, max = 6 },
    { k = 'tourney_min', type = 'number', label = "Tournoi : droit d'entrée minimum (jetons)", default = 100, min = 1, max = 10000000 },
    { k = 'tourney_max', type = 'number', label = "Tournoi : droit d'entrée maximum (jetons)", default = 50000, min = 1, max = 100000000 },
    { k = 'tourney_stack', type = 'number', label = 'Tournoi : jetons de départ de chaque joueur', default = 1500, min = 100, max = 1000000 },
    { k = 'tourney_sb', type = 'number', label = 'Tournoi : petite blinde au niveau 1', default = 10, min = 1, max = 100000 },
    { k = 'tourney_level_min', type = 'number', label = 'Tournoi : les blindes doublent toutes les (minutes)', default = 5, min = 1, max = 60 },
    { k = 'tourney_fee', type = 'number', label = 'Tournoi : part de la cagnotte gardée par le casino (%)', default = 10, min = 0, max = 50 },
    { k = 'bj_payout', type = 'number', label = 'Blackjack naturel : paie (× la mise)', default = 1.5, min = 1, max = 3, int = false, step = 0.1 },
    { k = 'bj_soft17', type = 'toggle', label = 'Blackjack : le croupier tire sur 17 souple', default = false },
    { k = 'dice_side', type = 'number', label = 'Dés « moins / plus de 7 » : gain (× la mise)', default = 2.3, min = 1.1, max = 3, int = false, step = 0.05 },
    { k = 'dice_seven', type = 'number', label = 'Dés « 7 exact » : gain (× la mise)', default = 5.7, min = 2, max = 8, int = false, step = 0.05 },
    { k = 'hilo_edge', type = 'number', label = 'Plus haut / plus bas : redistribution (%)', default = 97, min = 80, max = 100 },
    { k = 'hilo_max', type = 'number', label = 'Plus haut / plus bas : multiplicateur maximal', default = 500, min = 10, max = 10000 },
    { k = 'scratch_price', type = 'number', label = 'Prix d\'un ticket à gratter (jetons)', default = 50, min = 1, max = 100000 },
    { k = 'lotto', type = 'toggle', label = 'Loterie hebdomadaire (à la caisse)', default = true },
    { k = 'lotto_price', type = 'number', label = 'Loterie : prix du ticket ($)', default = 20, min = 1, max = 100000 },
    { k = 'lotto_day', type = 'select', label = 'Loterie : jour du tirage', default = 0, opts = { { 0, 'Dimanche' }, { 1, 'Lundi' }, { 2, 'Mardi' }, { 3, 'Mercredi' }, { 4, 'Jeudi' }, { 5, 'Vendredi' }, { 6, 'Samedi' } } },
    { k = 'lotto_hour', type = 'number', label = 'Loterie : heure du tirage', default = 21, min = 0, max = 23 },
    { k = 'lotto_share', type = 'number', label = 'Loterie : part du ticket versée dans la cagnotte (%)', default = 60, min = 0, max = 100 },
    { k = 'lotto_seed', type = 'number', label = 'Loterie : cagnotte de départ ($)', default = 25000, min = 0, max = 100000000 },
    { k = 'lotto_p4', type = 'number', label = 'Loterie : gain pour 4 bons numéros ($)', default = 1500, min = 0, max = 10000000 },
    { k = 'lotto_p3', type = 'number', label = 'Loterie : gain pour 3 bons numéros ($)', default = 100, min = 0, max = 10000000 },
} })
local function pct(x) return ('%.1f %%'):format(x * 100) end
PB.Module({
    id = 'casino', label = 'Casino', icon = 'dice', group = 'Serveur', order = 85, perm = 'casino.manage', hint = 'Jeux, mises, loterie, statistiques',
    caps = function()
        return PB.Capsify({
            { 'Sept jeux : machine à sous, roulette, blackjack, roue, dés, plus haut / plus bas, grattage', 'ok', 'Tous les tirages sont faits par le serveur ; l\'interface anime seulement le résultat.' },
            { 'Poker entre joueurs (Texas Hold\'em)', 'ok', 'Tables de 2 à 6 places, blindes, pots secondaires, commission du casino dès le flop, temps de parole.' },
            { 'Historique des joueurs', 'ok', 'Chaque joueur voit ses parties et ses bilans (Mes parties) ; classement des joueurs dans l\'onglet Joueurs.' },
            { 'Jetons dans l\'inventaire', 'ok', 'Objet « Jeton de casino » : se donne, se range, se vole. Achetés et revendus à la caisse.' },
            { 'Loterie hebdomadaire', 'ok', '5 numéros sur 30, tirage automatique au jour et à l\'heure réglés, cagnotte qui grossit, gains versés même hors ligne (à la connexion).' },
            { 'Décor du casino de GTA', 'warn', 'Machines et tables posées seulement si le serveur tourne en version de jeu 2060 ou plus ; sinon le point lumineux suffit.' },
            { 'Testé dans un vrai client FiveM', 'warn', 'Non : calculs vérifiés hors jeu, interface vérifiée dans un navigateur.' },
        })
    end,
    doc = "## Casino\n1. **F10 › Builder › Casino › Caisse** : là où l'on achète et revend les jetons, et où l'on joue à la loterie.\n2. **Casino › Jeu** : choisis le jeu (ou « Borne : tous les jeux »), place-toi devant, **E**.\n3. Les joueurs viennent avec **E** : la caisse vend les jetons, chaque jeu se joue avec.\n\nLes taux de redistribution sont affichés dans *Jeux* : ce que le casino rend en moyenne sur 100 jetons misés.",
    view = function(ctx)
        return { tabs = {
            { id = 'stats', label = 'Statistiques', icon = 'chart', build = function()
                local since = now() - 7 * 86400
                local rows, tb, tw = {}, 0, 0
                for _, r in ipairs(DB.q('SELECT game, COUNT(*) AS n, SUM(bet) AS b, SUM(win) AS w FROM pb_casino_log WHERE at > ? GROUP BY game', { since }) or {}) do
                    local b, w = tonumber(r.b) or 0, tonumber(r.w) or 0
                    tb, tw = tb + b, tw + w
                    rows[#rows + 1] = { game = GAME[r.game] and GAME[r.game].label or r.game, n = tonumber(r.n) or 0, bet = chipsTxt(b), win = chipsTxt(w), net = { text = chipsTxt(b - w), tone = b - w >= 0 and 'ok' or 'warn' }, rtp = b > 0 and pct(w / b) or '—' }
                end
                local big = {}
                for _, r in ipairs(DB.q('SELECT name, game, bet, win, at FROM pb_casino_log WHERE at > ? AND win > bet ORDER BY (win - bet) DESC LIMIT 15', { since }) or {}) do
                    big[#big + 1] = { who = r.name, game = GAME[r.game] and GAME[r.game].label or r.game, bet = chipsTxt(r.bet), win = chipsTxt(r.win), at = r.at }
                end
                local acc, limited = Ca.Account()
                return { B.stats({ { label = 'Misé sur 7 jours', value = chipsTxt(tb), icon = 'coins' }, { label = 'Rendu aux joueurs', value = chipsTxt(tw), icon = 'gift' },
                        { label = 'Bénéfice du casino', value = chipsTxt(tb - tw), icon = 'chart' }, { label = limited and 'Caisse de l\'entreprise' or 'Compte du casino (État)', value = money(G.Eco.Balance(acc)), icon = 'wallet' } }),
                    B.table({ id = 'cst', title = 'Par jeu (7 jours)', columns = { { k = 'game', label = 'Jeu' }, { k = 'n', label = 'Parties' }, { k = 'bet', label = 'Misé' }, { k = 'win', label = 'Rendu' }, { k = 'net', label = 'Bénéfice', type = 'badge' }, { k = 'rtp', label = 'Redistribution' } }, rows = rows, empty = 'Aucune partie cette semaine.' }),
                    B.table({ id = 'cbig', title = 'Plus gros gains (7 jours)', columns = { { k = 'who', label = 'Joueur' }, { k = 'game', label = 'Jeu' }, { k = 'bet', label = 'Mise' }, { k = 'win', label = 'Gain' }, { k = 'at', label = 'Quand', type = 'date' } }, rows = big, empty = 'Aucun gain.' }) }
            end },
            { id = 'players', label = 'Joueurs', icon = 'users', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT license, MAX(name) AS name, COUNT(*) AS n, SUM(bet) AS b, SUM(win) AS w, MAX(at) AS last FROM pb_casino_log WHERE at > ? GROUP BY license ORDER BY SUM(win - bet) DESC LIMIT 200', { now() - 30 * 86400 }) or {}) do
                    local b, w = tonumber(r.b) or 0, tonumber(r.w) or 0
                    rows[#rows + 1] = { who = r.name, n = tonumber(r.n) or 0, bet = chipsTxt(b), win = chipsTxt(w), net = { text = (w - b >= 0 and '+' or '') .. chipsTxt(w - b), tone = w - b >= 0 and 'ok' or 'warn' }, last = r.last }
                end
                return { B.notice('info', 'Bilan de chaque joueur sur 30 jours : du plus gros gagnant au plus gros perdant. Les joueurs voient leur propre historique au casino (Mes parties).'),
                    B.table({ id = 'cpl', title = 'Joueurs (30 jours)', search = true, columns = { { k = 'who', label = 'Joueur' }, { k = 'n', label = 'Parties' }, { k = 'bet', label = 'Misé' }, { k = 'win', label = 'Rendu' }, { k = 'net', label = 'Bilan', type = 'badge' }, { k = 'last', label = 'Dernière partie', type = 'date' } }, rows = rows, empty = 'Aucune partie.' }) }
            end },
            { id = 'tourneys', label = 'Tournois', icon = 'star', build = function()
                local rows, board = {}, {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_poker_tourneys ORDER BY id DESC LIMIT 200') or {}) do
                    if #rows < 50 then rows[#rows + 1] = { at = r.at, tbl = r.tbl, players = r.players, buyin = chipsTxt(r.buyin), pot = chipsTxt(r.pot), winner = r.winner ~= '' and r.winner or '—' } end
                    for _, x in ipairs(PB.FromJson(r.results or '[]', {}) or {}) do
                        local b = board[x.lic or x.name] or { name = x.name, wins = 0, top3 = 0, won = 0, played = 0 }
                        b.played, b.won = b.played + 1, b.won + (tonumber(x.prize) or 0) - (tonumber(r.buyin) or 0)
                        if x.place == 1 then b.wins = b.wins + 1 end
                        if (tonumber(x.place) or 9) <= 3 then b.top3 = b.top3 + 1 end
                        board[x.lic or x.name] = b
                    end
                end
                local lb = {}
                for _, b in pairs(board) do lb[#lb + 1] = b end
                table.sort(lb, function(a, b) if a.wins ~= b.wins then return a.wins > b.wins end return a.won > b.won end)
                local lrows = {}
                for i, b in ipairs(lb) do if i > 30 then break end lrows[#lrows + 1] = { rank = i, name = b.name, wins = b.wins, top3 = b.top3, played = b.played, net = { text = (b.won >= 0 and '+' or '') .. chipsTxt(b.won), tone = b.won >= 0 and 'ok' or 'warn' } } end
                return { B.notice('info', "Les joueurs créent un tournoi à une table de poker vide (droit d'entrée, mot de passe facultatif) ; il démarre quand le créateur le lance ou quand la table est complète."),
                    B.table({ id = 'tlb', title = 'Classement (200 derniers tournois)', columns = { { k = 'rank', label = '#' }, { k = 'name', label = 'Joueur' }, { k = 'wins', label = 'Victoires' }, { k = 'top3', label = 'Podiums' }, { k = 'played', label = 'Tournois' }, { k = 'net', label = 'Bilan', type = 'badge' } }, rows = lrows, empty = 'Aucun tournoi joué.' }),
                    B.table({ id = 'thist', title = 'Derniers tournois', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'tbl', label = 'Table' }, { k = 'players', label = 'Joueurs' }, { k = 'buyin', label = 'Entrée' }, { k = 'pot', label = 'Cagnotte' }, { k = 'winner', label = 'Vainqueur' } }, rows = rows, empty = 'Aucun tournoi joué.' }) }
            end },
            { id = 'games', label = 'Jeux', icon = 'dice', build = function()
                local th = function(rtp) return { text = pct(rtp), tone = rtp <= 1 and 'ok' or 'warn' } end
                local rows = {
                    { game = 'Machine à sous', rtp = th(Ca.SlotRtp()), how = 'Cerise seule : mise rendue · 2 cerises : × 2 · 3 identiques : de × 9 (citron) à × 400 (diamant)' },
                    { game = 'Roulette', rtp = th(36 / 37), how = 'Européenne (un zéro) : numéro × 36, couleur / pair / manque × 2, douzaine / colonne × 3' },
                    { game = 'Blackjack', rtp = { text = '≈ 99,5 %', tone = 'ok' }, how = ('Naturel payé %s × la mise, doubler, partager une fois, croupier %s'):format(tostring(num('bj_payout', 1.5)), cfg('bj_soft17', false) and 'tire sur 17 souple' or 'reste sur tout 17') },
                    { game = 'Roue de la fortune', rtp = th(Ca.WheelRtp()), how = '40 cases : × 1,5 à × 10' },
                    { game = 'Dés', rtp = th(15 / 36 * num('dice_side', 2.3)), how = ('Moins / plus de 7 : × %s · 7 exact : × %s (%s)'):format(num('dice_side', 2.3), num('dice_seven', 5.7), pct(6 / 36 * num('dice_seven', 5.7))) },
                    { game = 'Plus haut / plus bas', rtp = th(num('hilo_edge', 97) / 100), how = 'Chaque bonne réponse multiplie le gain ; encaisser quand on veut' },
                    { game = 'Tickets à gratter', rtp = th(Ca.ScratchRtp()), how = ('3 symboles identiques : × 1 à × 200 le prix du ticket (%s)'):format(chipsTxt(num('scratch_price', 50))) },
                }
                local pts = {}
                for _, r in ipairs(points()) do
                    pts[#pts + 1] = { label = r.label, kind = r.kind == 'cashier' and 'Caisse' or (r.kind == 'all' and 'Borne : tous les jeux' or (GAME[r.kind] and GAME[r.kind].label or r.kind)), pos = ('%.0f, %.0f'):format(r.x, r.y),
                        actions = { { action = 'casino.point.del', label = 'Supprimer', icon = 'trash', danger = true, confirm = 'Supprimer « ' .. r.label .. ' » ?', payload = { id = r.id } } } }
                end
                return { B.notice('info', 'Redistribution : ce que le jeu rend en moyenne sur 100 jetons misés. Au-dessus de 100 %, le casino perd de l\'argent sur la durée.'),
                    B.table({ id = 'cgm', title = 'Jeux', columns = { { k = 'game', label = 'Jeu' }, { k = 'rtp', label = 'Redistribution', type = 'badge' }, { k = 'how', label = 'Gains' } }, rows = rows }),
                    B.table({ id = 'cpt', title = 'Points posés (F10 › Builder › Casino)', columns = { { k = 'label', label = 'Nom' }, { k = 'kind', label = 'Type' }, { k = 'pos', label = 'Position', type = 'mono' } }, rows = pts, empty = 'Aucun point : pose une caisse et des jeux au Builder.' }) }
            end },
            { id = 'lotto', label = 'Loterie', icon = 'gift', build = function()
                local draw = math.floor(num('lotto_draw', 1))
                local n = DB.one('SELECT COUNT(*) AS n FROM pb_casino_lotto WHERE draw = ?', { draw })
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_casino_draws ORDER BY id DESC LIMIT 20') or {}) do rows[#rows + 1] = { id = '#' .. r.id, at = r.at, nums = tostring(r.nums):gsub(',', ' - '), pot = money(r.pot), tickets = r.tickets, winners = r.winners ~= '' and r.winners or 'Aucun' } end
                local nextAt = Ca.NextDraw(math.floor(num('lotto_last', 0)) > 0 and math.floor(num('lotto_last', 0)) or now())
                return { B.stats({ { label = 'Tirage en cours', value = 'n°' .. draw, icon = 'gift' }, { label = 'Tickets vendus', value = tostring(n and n.n or 0), icon = 'note' }, { label = 'Cagnotte', value = money(Ca.Pot()), icon = 'coins' }, { label = 'Prochain tirage', value = os.date('%d/%m %Hh', nextAt), icon = 'clock' } }),
                    B.actions({ { action = 'casino.draw', label = 'Faire le tirage maintenant', icon = 'refresh', danger = true } }, 'Tirage'),
                    B.table({ id = 'cdr', title = 'Derniers tirages', columns = { { k = 'id', label = 'Tirage' }, { k = 'at', label = 'Date', type = 'date' }, { k = 'nums', label = 'Numéros', type = 'mono' }, { k = 'pot', label = 'Cagnotte' }, { k = 'tickets', label = 'Tickets' }, { k = 'winners', label = 'Gagnants' } }, rows = rows, empty = 'Aucun tirage pour l\'instant.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() refreshOwners() return { form(ctx) } end },
        } }
    end,
})
