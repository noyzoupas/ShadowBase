-- (v1.2.78) Ventes par PNJ uniquement : trois bascules (menu staff › Gestion du serveur, ou panel) qui retirent les vendeurs joueurs.
--   Concessions : on achète seul à la vitrine (plus de « Faire essayer / Vendre un véhicule » des vendeurs).
--   Immobilier  : l'agence est un PNJ (posé au Builder › Immobilier) ; les agents joueurs n'ont plus d'actions.
--   Supérettes  : on paie seul, même si l'épicerie appartient à une entreprise.
-- Rien n'est supprimé : rebasculer remet les vendeurs joueurs.

local G, DB = PB.G, PB.DB
local S = G.Staff
local Place = PB.Place

PB.Cfg.Define('npcsales', { dealer = false, realestate = false, store = false, agency_ped = 'a_m_y_business_03', agency_points = {} })
local function cfg(k, d) return PB.Cfg.Get('npcsales', k, d) end
local KIND = { dealer = 'dealer', store = 'store', realestate = 'realestate' }
local LABEL = { dealer = 'Concessions', realestate = 'Immobilier', store = 'Supérettes' }
function G.NpcOnly(kind) local k = KIND[tostring(kind or '')] return k ~= nil and cfg(k, false) == true end

-- Menu staff : les trois bascules
if S then
    table.insert(S.SpecExtra, function(src, spec)
        if not PB.Perm.Has(src, 'shops.edit') then return end
        spec.npcsales = { dealer = cfg('dealer', false) == true, realestate = cfg('realestate', false) == true, store = cfg('store', false) == true }
    end)
    S.Def('npc_sales', 'shops.edit', { noduty = false, run = function(src, _, p)
        local k = KIND[tostring(p.kind or '')]
        if not k then return false, 'Catégorie inconnue.' end
        local on = p.on == true
        PB.Cfg.Set('npcsales', k, on, PB.Actor and PB.Actor(src).name or tostring(src), 'Menu staff : ventes par PNJ')
        G.PushConfig()
        return true, ('%s : %s.'):format(LABEL[k], on and 'ventes par PNJ uniquement' or 'vendeurs joueurs de retour')
    end, log = true })
end

-- Agence immobilière PNJ ------------------------------------------------------------------------------------------------------------------------
local function money(n) return PB.Money(n) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)
local function nearAgency(src)
    for _, a in ipairs(cfg('agency_points', {}) or {}) do if G.DistTo(src, a.x, a.y, a.z) <= 6.0 then return a end end
end
local function freeHomes(src)
    local c = GetEntityCoords(GetPlayerPed(src))
    local out = {}
    for _, h in ipairs(DB.q("SELECT id, label, kind, price, rent, x, y, z, ix, iy, premium FROM pb_properties WHERE owner = '' AND enabled = 1") or {}) do
        if not PB.ToBool(h.premium) then
            local d = math.sqrt((c.x - h.x) ^ 2 + (c.y - h.y) ^ 2)
            local hh = G.Housing and G.Housing.Get and G.Housing.Get(h.id) or h   -- prix avec l'économie
            out[#out + 1] = { id = h.id, label = h.label, kind = h.kind, price = hh.price or h.price, rent = hh.rent or h.rent, dist = math.floor(d), inside = (tonumber(h.ix) or 0) ~= 0 or (tonumber(h.iy) or 0) ~= 0 }
        end
    end
    table.sort(out, function(a, b) return a.dist < b.dist end)
    while #out > 40 do table.remove(out) end
    return out
end
RegisterNetEvent('pb:g:npcre:open', function()
    local src = source
    if not usable(src) or not throttle(src, 600) or not nearAgency(src) then return end
    TriggerClientEvent('pb:g:npcre:menu', src, PB.Json({ homes = freeHomes(src), days = tonumber(PB.Cfg.Get('housing', 'rent_days', 7)) or 7 }))
end)
RegisterNetEvent('pb:g:npcre:act', function(id, what)
    local src = source
    if not usable(src) or not throttle(src, 800) or not nearAgency(src) then return end
    local h = DB.one("SELECT id, label, x, y, z, ix, iy FROM pb_properties WHERE id = ? AND owner = ''", { tostring(id) })
    if not h then G.Notify(src, { type = 'error', title = 'Agence', text = "Ce logement n'est plus libre." }) return end
    if what == 'visit' then
        if (tonumber(h.ix) or 0) == 0 and (tonumber(h.iy) or 0) == 0 then G.Notify(src, { type = 'warn', title = 'Agence', text = "Ce logement n'a pas d'intérieur à visiter." }) return end
        if G.Realtor and G.Realtor.GrantVisit then G.Realtor.GrantVisit(G.Get(src).license, h.id, 900) end
        G.Notify(src, { type = 'success', title = 'Agence', text = ('Visite de « %s » ouverte 15 minutes : la porte est sur ta carte. Tu peux l\'acheter ou le louer sur place.'):format(h.label) })
    else
        G.Notify(src, { type = 'info', title = 'Agence', text = ('« %s » est sur ta carte : achète ou loue-le à la porte (E).'):format(h.label) })
    end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = h.x, y = h.y, label = h.label }))
end)

local function uid() return ('ag_%d%d'):format(os.time() % 1000000, math.random(100, 999)) end
Place.Register({ id = 'realtor_npc', label = 'Agence immobilière (PNJ : logements libres, visites)', group = 'Immobilier', icon = 'home',
    create = function(pos, name)
        local pts = cfg('agency_points', {}) or {}
        pts[#pts + 1] = { id = uid(), label = (tostring(name or ''):gsub('[%c<>"\\]', ''):sub(1, 40) ~= '' and tostring(name):sub(1, 40)) or 'Agence immobilière', x = pos.x + 0.0, y = pos.y + 0.0, z = pos.z + 0.0, h = (pos.h or 0) + 0.0 }
        PB.Cfg.Set('npcsales', 'agency_points', pts, nil, 'Builder : agence PNJ')
        return true, "Agence immobilière posée : le PNJ montre les logements libres et ouvre les visites."
    end,
    list = function() local out = {} for _, p in ipairs(cfg('agency_points', {}) or {}) do out[#out + 1] = { id = p.id, label = p.label, x = p.x, y = p.y, z = p.z } end return out end,
    remove = function(rid)
        local keep = {}
        for _, p in ipairs(cfg('agency_points', {}) or {}) do if tostring(p.id) ~= tostring(rid) then keep[#keep + 1] = p end end
        PB.Cfg.Set('npcsales', 'agency_points', keep, nil, 'Builder : agence PNJ supprimée')
        return true
    end })

local prevCfg = G.ClientConfig
G.ClientConfig = function()
    local c = prevCfg()
    c.npcsales = { dealer = cfg('dealer', false) == true, realestate = cfg('realestate', false) == true, store = cfg('store', false) == true,
        ped = tostring(cfg('agency_ped', 'a_m_y_business_03')), agency = cfg('agency_points', {}) or {} }
    return c
end
PB.Cfg.OnChange('npcsales', function() G.PushConfig() end)

G.NpcSalesForm = PB.Form.Cfg({ ns = 'npcsales', id = 'settings', title = 'Ventes par PNJ uniquement', perm = 'shops.edit', cols = 2, fields = {
    { k = 'dealer', type = 'toggle', label = 'Concessions : PNJ uniquement', default = false, hint = 'On achète seul à la vitrine ; les vendeurs joueurs ne vendent plus.' },
    { k = 'realestate', type = 'toggle', label = 'Immobilier : PNJ uniquement', default = false, hint = "L'agence PNJ (Builder › Immobilier) montre les logements libres ; achat ou location à la porte." },
    { k = 'store', type = 'toggle', label = 'Supérettes : PNJ uniquement', default = false, hint = "On paie seul, même si l'épicerie appartient à une entreprise." },
    { k = 'agency_ped', type = 'text', label = "Modèle du PNJ de l'agence", default = 'a_m_y_business_03', maxlen = 40 },
} })
