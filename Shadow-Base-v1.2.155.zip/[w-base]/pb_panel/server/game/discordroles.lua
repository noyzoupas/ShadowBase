-- (v1.2.98) Rôles Discord → avantages en jeu (il faut le jeton du bot et l'identifiant du serveur, module Discord) :
--   · priorité dans la file d'attente par rôle (le plus haut gagne), plus un bonus d'ancienneté (jours depuis la première venue) ;
--   · liste blanche : un rôle Discord suffit pour entrer quand la liste blanche est active ;
--   · VIP : avoir le rôle donne le VIP tant qu'on l'a (en plus du VIP acheté ou donné).
-- Les rôles sont lus par Discord à la connexion (vérification d'adhésion) puis toutes les 10 minutes pour les joueurs en ligne,
-- et gardés en base : une panne de Discord ne retire rien à personne.
local G, P, DB = PB.G, PB.Perm, PB.DB
PB.Cfg.Define('discordroles', { prio = {}, wl_roles = {}, vip_roles = {}, prio_per_day = 0, prio_day_max = 50 })
local function cfg(k, d) return PB.Cfg.Get('discordroles', k, d) end
PB.Migrate('581_discord_roles', 'Rôles Discord gardés (file, liste blanche, VIP)', {
    [[CREATE TABLE IF NOT EXISTS pb_discord_roles (discord VARCHAR(32) NOT NULL, roles TEXT NOT NULL, at INT NOT NULL, PRIMARY KEY (discord))]],
})
local cache = {}   -- discord -> { set = { id = true }, at }
local function discordOf(src) for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if id:sub(1, 8) == 'discord:' then return id:sub(9) end end end
local function discordOfLicense(license)
    local r = DB.one('SELECT discord FROM pb_discord_link WHERE license = ? OR license LIKE ? LIMIT 1', { license, tostring(license) .. '#%' })
    return r and r.discord or nil
end
function G.DiscordRolesSeen(dc, roles)
    local set = {}
    for _, r in ipairs(roles or {}) do set[tostring(r)] = true end
    cache[dc] = { set = set, at = os.time() }
    DB.exec('REPLACE INTO pb_discord_roles (discord, roles, at) VALUES (?, ?, ?)', { dc, PB.Json(roles or {}), os.time() })
end
local function rolesOf(dc)
    if not dc then return nil end
    local c = cache[dc]
    if c then return c.set end
    local r = DB.one('SELECT roles FROM pb_discord_roles WHERE discord = ?', { dc })
    if not r then return nil end
    local set = {}
    for _, x in ipairs(PB.FromJson(r.roles, {}) or {}) do set[tostring(x)] = true end
    cache[dc] = { set = set, at = 0 }
    return set
end
local function hasAny(set, list)
    if not set then return false end
    for _, line in ipairs(list or {}) do local id = tostring(line):match('^(%d+)') if id and set[id] then return true end end
    return false
end

function G.DiscordWL(src) return hasAny(rolesOf(discordOf(src)), cfg('wl_roles', {})) end
function G.QueuePrioExtra(src, license)
    local best = 0
    local set = rolesOf(discordOf(src))
    if set then
        for _, line in ipairs(cfg('prio', {}) or {}) do
            local id, n = tostring(line):match('^(%d+)|(%d+)$')
            if id and set[id] then best = math.max(best, tonumber(n) or 0) end
        end
    end
    local per = tonumber(cfg('prio_per_day', 0)) or 0
    if per > 0 and license then
        local fs = DB.one('SELECT at FROM pb_first_seen WHERE license = ?', { license })
        if fs then best = best + math.min(tonumber(cfg('prio_day_max', 50)) or 50, math.floor((os.time() - (tonumber(fs.at) or os.time())) / 86400 * per)) end
    end
    return best
end
-- VIP par rôle : ajouté au VIP habituel
CreateThread(function()
    while not (G.Vip and G.Vip.IsLicense) do Wait(500) end
    local orig = G.Vip.IsLicense
    G.Vip.IsLicense = function(license)
        if orig(license) then return true end
        local list = cfg('vip_roles', {}) or {}
        if #list == 0 or PB.Cfg.Get('vip', 'enabled', true) == false then return false end
        return hasAny(rolesOf(discordOfLicense(tostring(license or ''):gsub('#%d+$', ''))), list)
    end
end)

-- en ligne : rôles relus toutes les 10 minutes (un rôle retiré sur Discord retire l'avantage)
CreateThread(function()
    while true do
        Wait(600000)
        local ok, err = pcall(function()
            if not (PB.Discord and PB.Discord.BotToken() and PB.Discord.MemberRoles) then return end
            local any = #(cfg('vip_roles', {}) or {}) > 0 or #(cfg('prio', {}) or {}) > 0 or #(cfg('wl_roles', {}) or {}) > 0
            if not any then return end
            for src in pairs(G.Players()) do
                local dc = discordOf(src)
                if dc then
                    local roles = PB.Discord.MemberRoles(dc)
                    if roles then local was = G.Vip and G.Vip.Is(src) G.DiscordRolesSeen(dc, roles) if G.Vip and G.Vip.Is(src) ~= was then TriggerEvent('pb_panel:vipChanged', src) end end
                    Wait(1500)   -- limite de débit de Discord
                end
            end
        end)
        if not ok then PB.Warn('discordroles', tostring(err)) end
    end
end)

G.DiscordRolesForm = PB.Form.Cfg({ ns = 'discordroles', id = 'settings', title = 'Rôles Discord → avantages en jeu', perm = 'discordlink.edit', cols = 2,
    desc = "Identifiants de rôles : mode développeur Discord, clic droit sur le rôle › Copier l'identifiant. Il faut le jeton du bot et l'identifiant du serveur (module Discord).", fields = {
    { k = 'prio', type = 'list', label = "Priorité dans la file d'attente (identifiant du rôle|points)", default = {}, maxitems = 20, maxlen = 40, pattern = '^%d+|%d+$', wide = true, hint = 'Ex. 123456789012345678|50. Le staff passe toujours devant ; le VIP compte aussi (réglage VIP).' },
    { k = 'wl_roles', type = 'list', label = 'Rôles qui donnent la liste blanche', default = {}, maxitems = 10, maxlen = 24, pattern = '^%d+$', wide = true },
    { k = 'vip_roles', type = 'list', label = 'Rôles qui donnent le VIP (tant qu\'on les a)', default = {}, maxitems = 10, maxlen = 24, pattern = '^%d+$', wide = true },
    { k = 'prio_per_day', type = 'number', label = "Priorité d'ancienneté : points par jour depuis la première venue", default = 0, min = 0, max = 10, int = false, hint = '0 = coupé.' },
    { k = 'prio_day_max', type = 'number', label = "Priorité d'ancienneté : maximum", default = 50, min = 0, max = 1000 },
} })
