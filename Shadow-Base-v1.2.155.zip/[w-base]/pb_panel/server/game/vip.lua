-- VIP : statut donné par le staff (menu staff F10 sur un joueur, commande /vip, panel), avec durée ou permanent.
-- Avantages (lus par les autres modules et ressources via G.Vip.Is / exports.pb_panel:IsVip) : multi-personnages, animal de compagnie,
-- meubles dans les logements, canne et leurre VIP, bonus de vente (pêche, chasse), paie VIP toutes les 15 min, pêche automatique,
-- mode drift, contrats de vente sans taxe, location VIP à Cayo Perico, récoltes triplées (activités, drogues), sac plus grand,
-- Tec-9 et fusil à pompe le temps de l'abonnement, factures LSPD / EMS réduites, objets gardés à l'hôpital, reports prioritaires,
-- repos réduit, fourrière gratuite, carburant moins cher, places de véhicules, coffres agrandis, réduction en magasin, tenues en plus,
-- plaque gratuite, priorité dans la file d'attente, peinture caméléon (menu F5), boombox dans le sac (server/game/music.lua).

local G, DB, P, B = PB.G, PB.DB, PB.Perm, PB.B
local V = {}
G.Vip = V

P.Register('staff.vip', 'Donner ou retirer le VIP (menu staff, commande /vip)', 'staff', true)
P.Register('vip.view', 'Voir la liste des VIP', 'game')

PB.Migrate('214_vip', 'VIP : statut des joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_vip (license VARCHAR(64) NOT NULL, until_at INT NOT NULL DEFAULT 0, name VARCHAR(64) NOT NULL DEFAULT '', given_by VARCHAR(64) NOT NULL DEFAULT '',
        at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
})
PB.Cfg.Define('vip', { enabled = true, sell_bonus = 15, chars = 3, label = 'VIP', pay_amount = 300, pay_minutes = 15, pay_to = 'bank', pay_afk = false, fish_auto = true,
    drift = true, deal_notax = true, harvest_mult = 3, drug_mult = 3, inv_kg = 20, weapons = true, weapon_list = { 'WEAPON_MACHINEPISTOL|Tec-9', 'WEAPON_PUMPSHOTGUN|Fusil à pompe' },
    bill_pct = 40, bill_kinds = 'police_ems', keep_items = true, report_prio = true, rest_pct = 50, impound_free = true, fuel_pct = 20, garage_extra = 5,
    trunk_kg = 50, trunk_slots = 15, shop_pct = 10, outfits_extra = 10, plate_free = true, queue_prio = 100, chameleon = true, boombox = true })

-- cache : licence -> fin (0 = permanent) | false ; relu au plus toutes les 60 s
local cache = {}
local function now() return os.time() end
local function untilOf(license)
    if not license then return false end
    local c = cache[license]
    if c and now() - c.t < 60 then return c.v end
    local r = DB.one('SELECT until_at FROM pb_vip WHERE license = ?', { license })
    local v = r and tonumber(r.until_at) or false
    cache[license] = { t = now(), v = v }
    return v
end
function V.IsLicense(license)
    if PB.Cfg.Get('vip', 'enabled', true) == false then return false end
    local u = untilOf(license)
    return u ~= false and (u == 0 or u > now())
end
local function account(src) return P.GetLicense(tonumber(src) or -1) end   -- le VIP est celui du compte, quel que soit le personnage
function V.Is(src) local lic = account(src) return lic ~= nil and V.IsLicense(lic) end
-- (v1.2.45) véhicules maximum d'un personnage : le maximum du serveur, plus les places des VIP
-- (v1.2.45) le VIP d'une licence de personnage (« license:x#2 ») est celui de son compte
local function licVip(license) return V.IsLicense((tostring(license or ''):gsub('#%d+$', ''))) end
function V.OutfitsMax(license)
    local mx = tonumber(PB.Cfg.Get('tenues', 'max', 10)) or 10
    if licVip(license) then mx = mx + math.max(0, tonumber(PB.Cfg.Get('vip', 'outfits_extra', 10)) or 0) end
    return mx
end
function V.QueuePrio(license) return licVip(license) and math.max(0, tonumber(PB.Cfg.Get('vip', 'queue_prio', 100)) or 0) or 0 end
-- coffre d'un véhicule : place en plus si son propriétaire est VIP (emplacements, grammes)
function V.TrunkBonus(ownerLicense)
    if not licVip(ownerLicense) then return 0, 0 end
    return math.max(0, tonumber(PB.Cfg.Get('vip', 'trunk_slots', 15)) or 0), math.max(0, tonumber(PB.Cfg.Get('vip', 'trunk_kg', 50)) or 0) * 1000
end
function V.MaxVehicles(license)
    local mx = tonumber(PB.Cfg.Get('garage', 'max_vehicles', 12)) or 12
    if V.IsLicense((tostring(license or ''):gsub('#%d+$', ''))) then mx = mx + math.max(0, tonumber(PB.Cfg.Get('vip', 'garage_extra', 5)) or 0) end
    return mx
end
function V.Until(src) local lic = account(src) return lic and untilOf(lic) or false end

local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 64) end return (GetPlayerName(src) or ('Joueur ' .. src)):sub(1, 64) end
local function push(src) TriggerClientEvent('pb:g:vip', src, V.Is(src) and true or false, { drift = PB.Cfg.Get('vip', 'drift', true) ~= false, weapon_tint = PB.Cfg.Get('vip', 'weapon_tint', true) ~= false }) end

-- days : nombre de jours (0 ou nil = permanent). Prolonge un VIP en cours.
function V.Give(src, days, by)
    local p = G.Get(tonumber(src) or -1)
    if not p then return false, 'Joueur introuvable.' end
    p = { license = account(src) }
    days = math.floor(tonumber(days) or 0)
    if days < 0 or days > 3650 then return false, 'Durée invalide (0 = permanent, sinon 1 à 3650 jours).' end
    local cur = untilOf(p.license)
    local base = (cur and cur > now()) and cur or now()
    local u = days == 0 and 0 or (cur == 0 and 0 or base + days * 86400)
    DB.exec('REPLACE INTO pb_vip (license, until_at, name, given_by, at) VALUES (?, ?, ?, ?, ?)', { p.license, u, display(src), tostring(by or 'système'):sub(1, 64), now() })
    cache[p.license] = nil
    PB.Audit.Log('staff', 'vip.give', by or 0, display(src) .. ' ' .. G.Tag(src), nil, { jours = days, jusque = u })
    push(src)
    G.Notify(src, { type = 'success', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = u == 0 and 'Tu es VIP à vie. Merci !' or ('Tu es VIP jusqu\'au %s. Merci !'):format(os.date('%d/%m/%Y', u)) })
    TriggerEvent('pb_panel:vipChanged', src, true)
    return true, u == 0 and (display(src) .. ' est VIP à vie.') or (display(src) .. (' est VIP jusqu\'au %s.'):format(os.date('%d/%m/%Y', u)))
end
function V.RemoveLicense(license, by)
    DB.exec('DELETE FROM pb_vip WHERE license = ?', { tostring(license) })
    cache[tostring(license)] = nil
    PB.Audit.Log('staff', 'vip.remove', by or 0, tostring(license), nil, nil)
    for src in pairs(G.Players()) do
        if account(src) == license then push(src) G.Notify(src, { type = 'info', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = 'Ton statut VIP a pris fin.' }) TriggerEvent('pb_panel:vipChanged', src, false) end
    end
    return true
end
function V.Remove(src, by)
    local p = G.Get(tonumber(src) or -1)
    if not p then return false, 'Joueur introuvable.' end
    p = { license = account(src) }
    if not V.IsLicense(p.license) then return false, display(src) .. " n'est pas VIP." end
    V.RemoveLicense(p.license, by)
    return true, display(src) .. " n'est plus VIP."
end

exports('IsVip', function(src) return V.Is(src) end)
exports('SetVip', function(src, days) return V.Give(src, days, GetInvokingResource() or 'script') end)
exports('RemoveVip', function(src) return V.Remove(src, GetInvokingResource() or 'script') end)

table.insert(G.beginHooks, function(src) push(src) end)
-- fin d'un VIP à durée : on prévient le joueur (vérifié toutes les 5 min)
CreateThread(function()
    Wait(math.random(0, 300000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(300000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            for src in pairs(G.Players()) do
                local lic = account(src)
                local c = lic and cache[lic]
                if c and c.v and c.v > 0 and c.v <= now() then cache[lic] = nil push(src) G.Notify(src, { type = 'info', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = 'Ton statut VIP a pris fin.' }) TriggerEvent('pb_panel:vipChanged', src, false) end
            end
        end)
        if not ok then PB.Warn('vip', 'boucle : ' .. tostring(err)) end
    end
end)

-- Paie VIP : une somme toutes les X minutes de présence (réglable). Le temps compte par compte (se reconnecter ne remet pas
-- le compteur à zéro, ni ne paie deux fois) ; un joueur immobile (AFK) n'avance pas, sauf si le panel l'autorise.
local presence, lastPos = {}, {}
function V.PayTick()
    local amount = math.floor(tonumber(PB.Cfg.Get('vip', 'pay_amount', 300)) or 0)
    local every = math.max(1, math.floor(tonumber(PB.Cfg.Get('vip', 'pay_minutes', 15)) or 15))
    if PB.Cfg.Get('vip', 'enabled', true) == false or amount <= 0 then return end
    local afkOk = PB.Cfg.Get('vip', 'pay_afk', false) == true
    for src, pl in pairs(G.Players()) do
        local lic = account(src)
        if lic and PB.ToBool(pl.row.created) and not PB.ToBool(pl.row.dead) and V.IsLicense(lic) then
            local ped = GetPlayerPed(src)
            local c = ped and ped ~= 0 and GetEntityCoords(ped)
            local moved = true
            if c then
                local o = lastPos[src]
                moved = not o or math.sqrt((c.x - o.x) ^ 2 + (c.y - o.y) ^ 2) > 3.0
                lastPos[src] = { x = c.x, y = c.y }
            end
            if moved or afkOk then
                presence[lic] = (presence[lic] or 0) + 1
                if presence[lic] >= every then
                    presence[lic] = 0
                    local to = PB.Cfg.Get('vip', 'pay_to', 'bank') == 'cash' and 'cash' or 'bank'
                    G.AddMoney(src, to, amount, 'Paie VIP')
                    G.Notify(src, { type = 'success', title = PB.Cfg.Get('vip', 'label', 'VIP'), text = ('Paie VIP : %s %s. Prochaine dans %d min.'):format(
                        tostring(amount):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') .. ' $', to == 'cash' and 'en espèces' or 'sur ton compte', every) })
                    PB.Audit.Log('economie', 'vip.pay', 0, display(src) .. ' ' .. G.Tag(src), nil, nil, { amount = amount })
                end
            end
        end
    end
end
AddEventHandler('playerDropped', function() lastPos[source] = nil end)
CreateThread(function() Wait(math.random(0, 60000)) while true do Wait(60000) pcall(V.PayTick) end end)
function V.Presence(lic) return presence[lic] or 0 end

-- Avantages lus par les autres modules ----------------------------------------------------------------------------------------------------
local function perk(k, d) local v = PB.Cfg.Get('vip', k, d) if v == nil then return d end return v end
function V.Perk(src, k, d) if not V.Is(src) then return nil end return perk(k, d) end
-- multiplicateur de récolte : kind = 'harvest' (activités, fermes des entreprises) ou 'drug' (drogues)
function V.HarvestMult(src, kind)
    if not V.Is(src) then return 1 end
    return math.max(1, math.min(10, math.floor(tonumber(perk(kind == 'drug' and 'drug_mult' or 'harvest_mult', 3)) or 1)))
end
-- réduction (%) d'une facture ou amende émise par une entreprise de ce type pour ce joueur
function V.BillPct(src, bizKind)
    if not V.Is(src) then return 0 end
    local k = tostring(perk('bill_kinds', 'police_ems'))
    local ok = (bizKind == 'police' and (k == 'police_ems' or k == 'police')) or (bizKind == 'ems' and (k == 'police_ems' or k == 'ems')) or k == 'all'
    return ok and math.max(0, math.min(90, math.floor(tonumber(perk('bill_pct', 40)) or 0))) or 0
end
function V.Discount(src, bizKind, amount)
    local pct = V.BillPct(src, bizKind)
    if pct <= 0 then return amount, 0 end
    local a = math.max(1, math.floor(amount * (100 - pct) / 100 + 0.5))
    return a, amount - a
end
-- poids en plus dans le sac (grammes) pour une licence de personnage
function V.InvBonus(charLicense)
    for src, pl in pairs(G.Players()) do
        if pl.license == charLicense then return V.Is(src) and math.max(0, math.floor((tonumber(perk('inv_kg', 20)) or 0) * 1000)) or 0 end
    end
    return 0
end
exports('VipHarvestMult', function(src, kind) return V.HarvestMult(src, kind) end)

-- Armes de l'abonnement : un objet à part (weapon_xxx_vip), lié au joueur, donné tant qu'il est VIP et repris à la fin
local function vipWeapons()
    local out = {}
    for _, line in ipairs(perk('weapon_list', {}) or {}) do
        local h, l = tostring(line):match('^(WEAPON_[%w_]+)|?(.*)$')
        if h then out[#out + 1] = { hash = h:upper(), label = (l ~= '' and l or h), item = ('weapon_' .. h:lower():gsub('^weapon_', '') .. '_vip'):sub(1, 40) } end
    end
    return out
end
V.WeaponList = vipWeapons
local AMMO = { WEAPON_PUMPSHOTGUN = 'ammo_shotgun', WEAPON_SAWNOFFSHOTGUN = 'ammo_shotgun', WEAPON_MACHINEPISTOL = 'ammo_smg', WEAPON_MICROSMG = 'ammo_smg', WEAPON_SMG = 'ammo_smg', WEAPON_MINISMG = 'ammo_smg' }
local function ensureItem(w)
    if not (G.Weapons and G.Weapons.EnsureWeapon and G.Inv) then return false end
    if not (G.Inv.Def(w.item) and G.Weapons.ByItem and G.Weapons.ByItem(w.item)) then
        G.Weapons.EnsureWeapon({ item = w.item, label = (tostring(w.label):sub(1, 30) .. ' VIP'), hash = w.hash, ammo_item = AMMO[w.hash] or '', weight = 1000, permit = false,
            image = G.OxImage and G.OxImage(w.hash:lower()) or '', description = 'Arme de l\'abonnement VIP : elle reste dans ton sac tant que tu es VIP.' })
    end
    if G.Inv.Bind then G.Inv.Bind(w.item) end
    return true
end
function V.SyncWeapons(src)
    if not G.Inv or not G.Get(src) then return end
    local o = G.Inv.PlayerOwner(src)
    if not o then return end
    local on = V.Is(src) and perk('weapons', true) ~= false
    local keep = {}
    for _, w in ipairs(vipWeapons()) do
        if on and ensureItem(w) then
            keep[w.item] = true
            if G.Inv.Count(o, w.item) < 1 then G.Inv.Add(o, w.item, 1) end
        end
    end
    -- fin de l'abonnement (ou arme retirée de la liste) : les armes VIP disparaissent de partout chez ce personnage
    for _, r in ipairs(DB.q("SELECT DISTINCT item FROM pb_inv WHERE owner = ? AND item LIKE 'weapon\\_%\\_vip'", { o }) or {}) do
        if not keep[r.item] then G.Inv.Remove(o, r.item, G.Inv.Count(o, r.item)) end
    end
    if G.Inv.Push then pcall(G.Inv.Push, src) end
end
PB.OnReady(function() for _, w in ipairs(vipWeapons()) do pcall(ensureItem, w) end end)
table.insert(G.beginHooks, function(src) SetTimeout(3000, function() if G.Get(src) then pcall(V.SyncWeapons, src) end end) end)
AddEventHandler('pb_panel:vipChanged', function(src) pcall(V.SyncWeapons, src) end)

-- Commandes : /vip <id> [jours] (0 = permanent) et /unvip <id>. Console ou staff avec le droit « staff.vip ».
local function can(src) return src == 0 or P.Has(src, 'staff.vip') end
local function reply(src, ok, msg) if src == 0 then print(('[VIP] %s'):format(tostring(msg))) else G.Notify(src, { type = ok and 'success' or 'error', title = 'VIP', text = tostring(msg) }) end end
RegisterCommand('vip', function(src, args)
    if not can(src) then return end
    local t = G.SrcOfUid(args[1])
    if not t then reply(src, false, 'Usage : /vip <id du joueur> [jours, 0 = permanent]') return end
    reply(src, V.Give(t, tonumber(args[2]) or 0, src == 0 and 'console' or display(src)))
end, false)
RegisterCommand('unvip', function(src, args)
    if not can(src) then return end
    local t = G.SrcOfUid(args[1])
    if not t then reply(src, false, 'Usage : /unvip <id du joueur>') return end
    reply(src, V.Remove(t, src == 0 and 'console' or display(src)))
end, false)

-- Menu staff (F10) : actions sur un joueur
PB.OnReady(function()
    if not (G.Staff and G.Staff.Def) then return end
    G.Staff.Def('vip_give', 'staff.vip', { target = true, inputs = { { k = 'days', label = 'Durée en jours (0 = permanent)', number = true, maxlen = 4 } }, run = function(src, t, p)
        return V.Give(t, tonumber(p.days) or 0, display(src))
    end })
    G.Staff.Def('vip_remove', 'staff.vip', { target = true, run = function(src, t) return V.Remove(t, display(src)) end })
end)

-- Panel : liste, ajout par licence, retrait
PB.Action('vip.remove', 'staff.vip', function(ctx, p)
    local lic = tostring(p.license or '')
    if lic == '' then return false, 'Licence manquante.' end
    V.RemoveLicense(lic, ctx.actor)
    ctx.toast = 'VIP retiré.'
    return true
end, { confirm = { title = 'Retirer le VIP ?', text = 'Le joueur perd ses avantages tout de suite.' } })
PB.Action('vip.add', 'staff.vip', function(ctx, p)
    local v = p.values or p
    local id = G.SrcOfUid(v.id)
    if not id then return false, 'Joueur introuvable (ID permanent d\'un joueur connecté).' end
    local ok, msg = V.Give(id, tonumber(v.days) or 0, ctx.actor)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
G.VipForm = PB.Form.Cfg({ ns = 'vip', id = 'perks', title = 'Avantages VIP', perm = 'staff.vip', cols = 2, fields = {
    { k = 'pay_amount', type = 'number', label = 'Paie VIP : montant ($, 0 = désactivée)', default = 300, min = 0, max = 1000000, hint = 'Versée en plus de la paie normale, à chaque période de présence.' },
    { k = 'pay_minutes', type = 'number', label = 'Paie VIP : toutes les (minutes de présence)', default = 15, min = 1, max = 240 },
    { k = 'pay_to', type = 'select', label = 'Paie VIP : versée', opts = { { 'bank', 'Sur le compte en banque' }, { 'cash', 'En espèces' } }, default = 'bank' },
    { k = 'pay_afk', type = 'toggle', label = 'Payer aussi les VIP immobiles (AFK)', default = false, hint = 'Désactivé : le temps ne compte que si le joueur bouge (au moins 3 m par minute).' },
    { k = 'fish_auto', type = 'toggle', label = 'Pêche automatique pour les VIP', default = true, hint = 'Le VIP lance sa canne : chaque touche est ferrée automatiquement et la ligne est relancée toute seule (X pour arrêter).' },
    { k = 'sell_bonus', type = 'number', label = 'Bonus de revente (%)', default = 15, min = 0, max = 200 },
    { k = 'drift', type = 'toggle', label = 'Mode drift (/drift ou F5 › Véhicule)', default = true, hint = 'Le VIP active le mode drift : en maintenant Maj gauche au volant, les roues arrière décrochent.' },
    { k = 'deal_notax', type = 'toggle', label = 'Ventes entre joueurs sans taxe', default = true, hint = 'Contrats du téléphone : le VIP vendeur ne paie pas la taxe de mutation (5 % par défaut).' },
    { k = 'harvest_mult', type = 'number', label = 'Récoltes des activités et fermes (×)', default = 3, min = 1, max = 10, hint = 'Points de récolte des activités (wb_activites), y compris ceux des entreprises.' },
    { k = 'drug_mult', type = 'number', label = 'Récoltes de drogue (×)', default = 3, min = 1, max = 10, hint = 'Champs des filières illégales.' },
    { k = 'inv_kg', type = 'number', label = 'Poids en plus dans le sac (kg)', default = 20, min = 0, max = 500 },
    { k = 'bill_pct', type = 'number', label = 'Réduction des factures et amendes (%)', default = 40, min = 0, max = 90 },
    { k = 'bill_kinds', type = 'select', label = 'Réduction appliquée aux', opts = { { 'police_ems', 'Police (LSPD) et EMS' }, { 'police', 'Police seulement' }, { 'ems', 'EMS seulement' }, { 'all', 'Toutes les entreprises' } }, default = 'police_ems' },
    { k = 'keep_items', type = 'toggle', label = "Garder ses objets et armes à l'hôpital", default = true, hint = 'Si « Écran de mort › Objets perdus à la réapparition » est actif, le VIP ne perd rien.' },
    { k = 'boombox', type = 'toggle', label = 'Boombox dans le sac', default = true, hint = 'Elle se prend en main depuis l\'inventaire et ouvre le mini CarPlay : tout le monde autour entend la musique.' },
    { k = 'weapon_tint', type = 'toggle', label = "Teinture d'armes (menu F5 ou /teinture)", default = true, hint = 'Or, platine, rose… sur l\'arme en main. Choisie par arme, mémorisée sur le poste du joueur.' },
    { k = 'chameleon', type = 'toggle', label = 'Peinture caméléon (menu F5)', default = true, hint = 'La couleur change selon l\'angle de vue. Sur ses propres véhicules, gratuite.' },
    { k = 'trunk_kg', type = 'number', label = 'Coffre de ses véhicules : poids en plus (kg)', default = 50, min = 0, max = 1000 },
    { k = 'trunk_slots', type = 'number', label = 'Coffre de ses véhicules : emplacements en plus', default = 15, min = 0, max = 100 },
    { k = 'shop_pct', type = 'number', label = 'Réduction en magasin (%)', default = 10, min = 0, max = 90, hint = 'Supérettes, vêtements, coiffeurs, tatoueurs ; remboursée au paiement. Pas sur les véhicules ni les armes.' },
    { k = 'outfits_extra', type = 'number', label = 'Tenues enregistrées en plus', default = 10, min = 0, max = 100 },
    { k = 'plate_free', type = 'toggle', label = 'Plaque personnalisée gratuite', default = true },
    { k = 'queue_prio', type = 'number', label = "Priorité dans la file d'attente (0 = aucune)", default = 100, min = 0, max = 100000, hint = 'Quand le serveur est plein : les VIP passent devant les autres joueurs (le staff reste devant).' },
    { k = 'rest_pct', type = 'number', label = 'Repos après réapparition réduit (%)', default = 50, min = 0, max = 100 },
    { k = 'impound_free', type = 'toggle', label = 'Fourrière gratuite', default = true },
    { k = 'fuel_pct', type = 'number', label = 'Carburant moins cher (%)', default = 20, min = 0, max = 100 },
    { k = 'garage_extra', type = 'number', label = 'Places de véhicules en plus', default = 5, min = 0, max = 100 },
    { k = 'report_prio', type = 'toggle', label = 'Reports prioritaires', default = true, hint = 'Les tickets des VIP passent en tête de liste du staff, avec la mention ★ VIP.' },
    { k = 'weapons', type = 'toggle', label = "Armes de l'abonnement", default = true, hint = 'Données tant que le joueur est VIP (liées : ni données, ni jetées), reprises à la fin.' },
    { k = 'weapon_list', type = 'list', label = 'Armes VIP : HASH|nom', default = { 'WEAPON_MACHINEPISTOL|Tec-9', 'WEAPON_PUMPSHOTGUN|Fusil à pompe' }, maxitems = 6, maxlen = 64, wide = true },
} })

PB.Module({
    id = 'vip', label = 'VIP', icon = 'crown', group = 'Serveur', order = 139, perm = 'vip.view', hint = 'Joueurs VIP et leurs avantages',
    doc = "## VIP\nDonne le VIP en jeu : **menu staff (F10) › Joueurs › un joueur › Donner le VIP** (durée en jours, 0 = permanent), ou la commande **/vip <id> [jours]** (et **/unvip <id>**), utilisable aussi depuis la console.\n\nAvantages : plusieurs personnages, animal de compagnie, meubles dans les logements, canne et leurre VIP, bonus de revente (pêche, chasse), **paie VIP** toutes les 15 min de présence (montant et durée dans « Avantages »), **pêche automatique** (chaque touche ferrée, ligne relancée toute seule), **mode drift**, **ventes sans taxe** (contrats), **location VIP à Cayo Perico** (Location de véhicules), **récoltes ×3** (activités, fermes, drogues), **sac plus grand**, **Tec-9 et fusil à pompe** pendant l'abonnement, **factures LSPD / EMS réduites de 40 %**, **objets gardés à l'hôpital**, **reports prioritaires**, **rôles Discord VIP + Gold** (Lien Discord), **repos réduit**, **fourrière gratuite**, **carburant moins cher**, **places de véhicules en plus**, **coffres agrandis**, **réduction en magasin**, **tenues en plus**, **plaque gratuite**, **priorité dans la file d'attente**, **peinture caméléon** (menu F5), **boombox** (objet du sac).",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Joueurs VIP', icon = 'crown', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_vip ORDER BY at DESC') or {}) do
                    local u = tonumber(r.until_at) or 0
                    rows[#rows + 1] = { name = r.name, license = '…' .. tostring(r.license):sub(-8), till = u == 0 and 'Permanent' or os.date('%d/%m/%Y %H:%M', u), state = (u == 0 or u > now()) and { text = 'Actif', tone = 'ok' } or { text = 'Expiré', tone = 'off' },
                        by = r.given_by, actions = ctx.has('staff.vip') and { { action = 'vip.remove', label = 'Retirer', icon = 'x', danger = true, payload = { license = r.license } } } or {} }
                end
                local blocks = { B.table({ id = 'vipl', title = 'VIP (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Joueur' }, { k = 'license', label = 'Licence', type = 'mono' }, { k = 'till', label = "Jusqu'au" }, { k = 'state', label = 'État', type = 'badge' }, { k = 'by', label = 'Donné par' } }, rows = rows, empty = 'Aucun VIP pour le moment.' }) }
                if ctx.has('staff.vip') then
                    blocks[#blocks + 1] = { type = 'form', id = 'vip.add', title = 'Donner le VIP à un joueur connecté', cols = 2, fields = { { k = 'id', type = 'number', label = 'ID du joueur', required = true, min = 1, max = 999999 }, { k = 'days', type = 'number', label = 'Jours (0 = permanent)', min = 0, max = 3650 } },
                        values = { id = '', days = 30 }, submit = { action = 'vip.add', label = 'Donner' } }
                end
                return blocks
            end },
            { id = 'perks', label = 'Avantages', icon = 'sliders', perm = 'staff.vip', build = function() return { G.VipForm(ctx) } end },
        } }
    end,
})

-- (v1.2.43) la paie VIP (2 500 $ par quart d'heure) rapportait plus que le chef de la police : 300 $ par défaut, une fois, si l'ancien défaut n'avait pas été modifié
PB.OnReady(function()
    if PB.Cfg.Get('vip', 'pay_fix_v1', false) == true then return end
    if tonumber(PB.Cfg.Get('vip', 'pay_amount', 300)) == 2500 then PB.Cfg.Set('vip', 'pay_amount', 300, nil, 'VIP : paie rééquilibrée') end
    PB.Cfg.Set('vip', 'pay_fix_v1', true, nil, 'Migration')
end)

-- Peinture caméléon : marque le véhicule (les joueurs proches calculent l'effet, client/vipextras.lua) et l'enregistre avec ses améliorations
local CHAM_MAX = 8
local chamAt = {}
RegisterNetEvent('pb:g:vip:cham', function(netId, idx)
    local src = source
    local t = GetGameTimer()
    if chamAt[src] and t - chamAt[src] < 800 then return end
    chamAt[src] = t
    local function say(kind, text) G.Notify(src, { type = kind, title = 'Caméléon', text = text }) end
    if not V.Is(src) or PB.Cfg.Get('vip', 'chameleon', true) == false then say('warn', 'Réservé aux VIP.') return end
    idx = math.floor(tonumber(idx) or -1)
    if idx < 0 or idx > CHAM_MAX then return end
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, math.floor(tonumber(netId) or 0))
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) or GetVehiclePedIsIn(GetPlayerPed(src), false) ~= ent then say('error', 'Monte dans ton véhicule.') return end
    local plate = tostring(GetVehicleNumberPlateText(ent) or ''):gsub('^%s+', ''):gsub('%s+$', ''):upper()
    local p = G.Get(src)
    local row = DB.one('SELECT license FROM pb_vehicles WHERE plate = ?', { plate })
    if not p or not row or row.license ~= p.license then say('error', 'Seulement sur tes propres véhicules.') return end
    Entity(ent).state:set('pb_cham', idx, true)
    if G.Garage and G.Garage.SetMod then G.Garage.SetMod(plate, 'cham', idx) if idx > 0 then G.Garage.SetMod(plate, 'champ', 0) end end
    PB.Audit.Log('serveur', 'vip.cham', src, plate, nil, nil, { idx = idx })
    say('success', idx > 0 and 'Peinture caméléon posée : tourne autour de ton véhicule !' or 'Peinture caméléon retirée.')
end)

-- Vraie peinture caméléon (ressource spchameleon) : même contrôle, puis le client du conducteur l'applique ; le jeu la synchronise
RegisterNetEvent('pb:g:vip:paint', function(netId, idx)
    local src = source
    local t = GetGameTimer()
    if chamAt[src] and t - chamAt[src] < 800 then return end
    chamAt[src] = t
    local function say(kind, text) G.Notify(src, { type = kind, title = 'Caméléon', text = text }) end
    if not V.Is(src) or PB.Cfg.Get('vip', 'chameleon', true) == false then say('warn', 'Réservé aux VIP.') return end
    idx = math.floor(tonumber(idx) or -1)
    if idx < 161 or idx > 242 then return end
    if idx > 222 and GetResourceState('spchameleon') ~= 'started' then say('error', "Ces peintures ne sont pas installées sur le serveur.") return end
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, math.floor(tonumber(netId) or 0))
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) or GetVehiclePedIsIn(GetPlayerPed(src), false) ~= ent then say('error', 'Monte dans ton véhicule.') return end
    local plate = tostring(GetVehicleNumberPlateText(ent) or ''):gsub('^%s+', ''):gsub('%s+$', ''):upper()
    local p = G.Get(src)
    local row = DB.one('SELECT license FROM pb_vehicles WHERE plate = ?', { plate })
    if not p or not row or row.license ~= p.license then say('error', 'Seulement sur tes propres véhicules.') return end
    Entity(ent).state:set('pb_cham', 0, true)
    if G.Garage and G.Garage.SetMod then G.Garage.SetMod(plate, 'cham', 0) G.Garage.SetMod(plate, 'champ', idx) end
    TriggerClientEvent('pb:g:vip:paint', src, netId, idx)
    PB.Audit.Log('serveur', 'vip.paint', src, plate, nil, nil, { idx = idx })
    say('success', 'Peinture caméléon posée.')
end)

AddEventHandler('playerDropped', function() chamAt[source] = nil end)

-- (v1.2.46) Changement de plaque depuis le menu F5, gratuit pour les VIP. Mêmes règles que le garage (véhicule rangé, plaque libre) :
-- le coffre, les clés et le compteur suivent.
local plateAt = {}
local function plateAllowed(src) return V.Is(src) and PB.Cfg.Get('vip', 'plate_free', true) ~= false end
local function sendPlates(src)
    local p = G.Get(src)
    if not p then return end
    local rows = {}
    for _, v in ipairs(DB.q("SELECT v.plate, v.label, v.model, s.state FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.license = ? AND v.gang = '' AND v.biz = '' ORDER BY v.id LIMIT 40", { p.license }) or {}) do
        rows[#rows + 1] = { plate = v.plate, label = (v.label and v.label ~= '') and v.label or v.model, ready = (v.state or 'garage') == 'garage' }
    end
    TriggerClientEvent('pb:g:vip:plates', src, PB.Json({ rows = rows }))
end
RegisterNetEvent('pb:g:vip:plates', function()
    local src = source
    if not plateAllowed(src) then G.Notify(src, { type = 'warn', title = 'Plaque', text = 'Réservé aux VIP.' }) return end
    sendPlates(src)
end)
RegisterNetEvent('pb:g:vip:plate', function(plate, text)
    local src = source
    local t = GetGameTimer()
    if plateAt[src] and t - plateAt[src] < 1500 then return end
    plateAt[src] = t
    local function say(kind, msg) G.Notify(src, { type = kind, title = 'Plaque', text = msg }) end
    local p = G.Get(src)
    if not p or not plateAllowed(src) then say('warn', 'Réservé aux VIP.') return end
    local Gr = G.Garage
    local v = Gr and Gr.Vehicle(tostring(plate or ''))
    if not v or v.license ~= p.license or (v.gang or '') ~= '' or (v.biz or '') ~= '' then say('error', 'Choisis un de tes véhicules.') return end
    if v.state ~= 'garage' then say('warn', "Range d'abord ce véhicule au garage.") return end
    local new, err = Gr.PlateOk(text)
    if not new then say('error', err) return end
    if not Gr.Rename(v.plate, new) then say('error', 'Changement impossible.') return end
    PB.Audit.Log('economy', 'vip.plate', src, v.plate, { plate = v.plate }, { plate = new })
    if G.Timeline then G.Timeline.Add(p.license, 'plate', ('Plaque %s remplacée par %s'):format(v.plate, new), 'info') end
    say('success', 'Nouvelle plaque : ' .. new .. '.')
end)
AddEventHandler('playerDropped', function() plateAt[source] = nil end)
