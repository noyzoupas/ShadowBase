-- Drapeaux de territoire : chaque point de vente (Activités illégales › filière › vente) a un drapeau.
-- ALT sur le drapeau : un membre d'un gang lance la capture. Si son gang reste seul `secs` secondes dans le cercle avec au moins `min_members` membres,
-- son chef peut récupérer le drapeau : le point lui appartient `hours` heures et ses ventes y sont multipliées (x1,7 par défaut).
-- Tout est décidé par le serveur (positions, effectifs, durées, chef) ; le client ne fait que dessiner et demander.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local F = {}
G.Flags = F

P.Register('flags.edit', 'Modifier les drapeaux de territoire', 'territories', true)
PB.Migrate('085_flags', 'Drapeaux de territoire', {
    [[CREATE TABLE IF NOT EXISTS pb_flags (spot VARCHAR(32) NOT NULL PRIMARY KEY, gang VARCHAR(32) NOT NULL, since INT NOT NULL DEFAULT 0, expires INT NOT NULL DEFAULT 0, claimed_by VARCHAR(64) NOT NULL DEFAULT '')]],
    [[CREATE TABLE IF NOT EXISTS pb_gang_boss (gang VARCHAR(32) NOT NULL PRIMARY KEY, license VARCHAR(64) NOT NULL)]],
})
PB.Cfg.Define('flags', { enabled = true, radius = 25, min_members = 5, secs = 60, hours = 5, mult = 1.7, ready_secs = 300, boss_only = true, show = true, warn_owner = true, pole_model = 'prop_flagpole_2a' })
local function cfg(k, d) return PB.Cfg.Get('flags', k, d) end
-- (patch 136) remise à zéro : tous les points de vente (et leurs drapeaux) d'avant sont retirés ; on les repose depuis Builder › Drogues
PB.OnReady(function()
    if PB.Cfg.Get('flags', 'reset_v136', false) == true then return end
    local keep, removed = {}, 0
    -- seulement une liste déjà modifiée sur ce serveur (une installation neuve garde ses points d'exemple)
    if PB.Cfg.Has('crime', 'chain') then
        for _, s in ipairs(PB.Cfg.Get('crime', 'chain', {}) or {}) do if s.kind == 'sell' then removed = removed + 1 else keep[#keep + 1] = s end end
        if removed > 0 then PB.Cfg.Set('crime', 'chain', keep, nil, 'Drapeaux : remise à zéro (patch 136)') end
        DB.exec('DELETE FROM pb_flags')
    end
    PB.Cfg.Set('flags', 'reset_v136', true, nil, 'Migration')
    PB.Audit.Log('config', 'flags.reset', 0, tostring(removed) .. ' point(s) de vente retirés', nil, nil, nil)
end)
local function nowS() return os.time() end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function hex(c) return (type(c) == 'string' and c:match('^#%x%x%x%x%x%x$')) or '#dfe2e7' end
local function gdef(id) local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[id] return d or { id = id, label = id, color = '#dfe2e7' } end

-- points de vente : toutes les ventes de la filière
function F.Spots()
    local out = {}
    for _, s in ipairs(PB.Cfg.Get('crime', 'chain', {}) or {}) do
        if s.kind == 'sell' then out[#out + 1] = { id = s.id, label = s.label, x = tonumber(s.x) or 0, y = tonumber(s.y) or 0, z = tonumber(s.z) or 0 } end
    end
    return out
end
function F.Spot(id) for _, s in ipairs(F.Spots()) do if s.id == id then return s end end end
local function radius() return math.max(5, tonumber(cfg('radius', 25)) or 25) end

-- propriétaires gardés en mémoire : la table n'est lue qu'une fois (la boucle de chaque seconde ne touche plus la base)
local owners = nil      -- spot -> { gang, since, expires, claimed_by }
local function ownersLoad()
    if owners then return owners end
    local rows = DB.q('SELECT spot, gang, since, expires, claimed_by FROM pb_flags')
    if not rows then return {} end      -- base pas encore prête : on réessaiera
    owners = {}
    for _, r in ipairs(rows) do owners[tostring(r.spot)] = r end
    return owners
end
-- propriétaire valide (non expiré)
function F.Owner(id)
    local r = ownersLoad()[tostring(id)]
    if not r then return nil end
    if tonumber(r.expires) <= nowS() then
        owners[tostring(id)] = nil
        DB.exec('DELETE FROM pb_flags WHERE spot = ?', { tostring(id) })
        return nil
    end
    return r.gang, r
end

-- chef d'un gang : désigné dans le panel, sinon le membre le plus ancien dans la base
function F.BossLicense(gid)
    local r = DB.one('SELECT license FROM pb_gang_boss WHERE gang = ?', { gid })
    if r then return r.license end
    local m = DB.one('SELECT license FROM pb_tag_gang WHERE gang = ? ORDER BY since ASC LIMIT 1', { gid })
    return m and m.license or nil
end
function F.IsBoss(src, gid)
    local p = G.Get(src)
    return p ~= nil and F.BossLicense(gid) == p.license
end
function F.SetBoss(gid, src)
    local p = G.Get(src)
    if not p then return false, 'Joueur hors ligne.' end
    local g = gangOf(src)
    if not g or g.id ~= gid then return false, "Ce joueur n'est pas dans ce gang." end
    DB.exec('REPLACE INTO pb_gang_boss (gang, license) VALUES (?, ?)', { gid, p.license })
    return true
end
exports('SetGangBoss', function(src, gid) return F.SetBoss(tostring(gid), tonumber(src) or -1) end)

-- multiplicateur de vente appliqué par Activités illégales
function F.Mult(spotId, src)
    if not cfg('enabled', true) then return 1 end
    local owner = F.Owner(spotId)
    if not owner then return 1 end
    local g = gangOf(src)
    if g and g.id == owner then return math.max(1, tonumber(cfg('mult', 1.7)) or 1.7) end
    return 1
end

-- état en mémoire : progression et « prêt »
local st = {}           -- spot -> { gang, p, ready = { gang, t }, warned }
local function S(id) st[id] = st[id] or { p = 0 } return st[id] end
local function presence(sp)
    local by, total = {}, 0
    local r = radius()
    for src in pairs(G.Players()) do
        local g = gangOf(src)
        if g and usable(src) and G.DistTo(src, sp.x, sp.y, sp.z) <= r then by[g.id] = (by[g.id] or 0) + 1 total = total + 1 end
    end
    return by, total
end
local function gangMembers(gid, fn)
    for src in pairs(G.Players()) do local g = gangOf(src) if g and g.id == gid then fn(src) end end
end
local function notifyGang(gid, kind, text) gangMembers(gid, function(s) G.Notify(s, { type = kind, title = 'Territoire', text = text }) end) end

function F.View()
    local out = {}
    local need = math.max(5, tonumber(cfg('secs', 60)) or 60)
    for _, sp in ipairs(F.Spots()) do
        local gid, row = F.Owner(sp.id)
        local d = gid and gdef(gid)
        local s = st[sp.id]
        local ch = s and s.gang and gdef(s.gang)
        -- organisations présentes dans le cercle et leur nombre (le propriétaire et l'attaquant apparaissent même à 0)
        local by = presence(sp)
        if gid and not by[gid] then by[gid] = 0 end
        if s and s.gang and not by[s.gang] then by[s.gang] = 0 end
        local pres = {}
        for g, n in pairs(by) do local dd = gdef(g) pres[#pres + 1] = { label = dd.label, color = hex(dd.color), n = n } end
        table.sort(pres, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.label < b.label end)
        out[#out + 1] = { id = sp.id, label = sp.label, x = sp.x, y = sp.y, z = sp.z, pres = pres,
            owner = gid and { gang = gid, label = d.label, color = hex(d.color), left = math.max(0, tonumber(row.expires) - nowS()) } or false,
            prog = s and math.floor((s.p or 0) / need * 100) or 0, by = ch and { gang = ch.id, label = ch.label, color = hex(ch.color) } or false,
            ready = s and s.ready and { gang = s.ready.gang, label = gdef(s.ready.gang).label, color = hex(gdef(s.ready.gang).color) } or false }
    end
    return out
end
local lastHash = {}
function F.Push(src, force)
    if src then
        local g = gangOf(src)
        TriggerClientEvent('pb:g:flag:state', src, PB.Json({ spots = F.View(), me = g and g.id or nil, boss = g and F.IsBoss(src, g.id) or false, cfg = { radius = radius(), model = tostring(cfg('pole_model', '')), secs = math.max(5, tonumber(cfg('secs', 60)) or 60), hours = math.max(1, tonumber(cfg('hours', 5)) or 5), mult = tonumber(cfg('mult', 1.7)) or 1, min = math.max(1, tonumber(cfg('min_members', 5)) or 5) } }))
        return
    end
    -- le compte à rebours du propriétaire change chaque seconde : il est décompté côté client, on ne renvoie l'état
    -- que si autre chose a changé (capture, propriétaire, drapeau prêt) ou au plus toutes les 60 s
    local v = F.View()
    for _, x in ipairs(v) do if x.owner then x.owner = { gang = x.owner.gang, label = x.owner.label, color = x.owner.color, m = math.floor(x.owner.left / 60) } end end
    local view = PB.Json(v)
    if not force and lastHash.v == view then return end
    lastHash.v = view
    for s in pairs(G.Players()) do F.Push(s) end
end
table.insert(G.beginHooks, function(src) F.Push(src) end)

-- tick : une seconde de présence
function F.Tick(dt)
    if not cfg('enabled', true) then return end
    dt = dt or 1
    local need, minM = math.max(5, tonumber(cfg('secs', 60)) or 60), math.max(1, tonumber(cfg('min_members', 5)) or 5)
    local ttl = math.max(30, tonumber(cfg('ready_secs', 300)) or 300)
    for _, sp in ipairs(F.Spots()) do
        local s = S(sp.id)
        local owner = F.Owner(sp.id)
        local by = presence(sp)
        local n, only = 0, nil
        for g in pairs(by) do n = n + 1 only = g end
        if s.ready then
            if n > 1 or (n == 1 and only ~= s.ready.gang) or nowS() - s.ready.t > ttl then
                notifyGang(s.ready.gang, 'warn', 'Le drapeau de ' .. sp.label .. ' est perdu : zone contestée ou délai dépassé.')
                s.ready, s.p, s.gang = nil, 0, nil
            end
        elseif s.gang then
            -- capture lancée au drapeau : seul le gang qui l'a lancée, assez nombreux ; sinon elle s'arrête et il faut la relancer
            if n == 1 and only == s.gang and only ~= owner and (by[only] or 0) >= minM then
                s.p = s.p + dt
                if s.p >= need then
                    s.ready = { gang = only, t = nowS() }
                    notifyGang(only, 'success', ('Drapeau de %s prêt : le chef doit le récupérer (E ou ALT) dans le cercle.'):format(sp.label))
                end
            else
                notifyGang(s.gang, 'warn', ('Capture de %s annulée : zone contestée ou pas assez de membres.'):format(sp.label))
                s.p, s.gang = 0, nil
            end
        end
    end
end
-- ALT sur le drapeau › Commencer la capture
function F.Start(src, id)
    if not cfg('enabled', true) then return false, 'Drapeaux désactivés.' end
    local sp = F.Spot(id)
    if not sp then return false, 'Point inconnu.' end
    local g = gangOf(src)
    if not g then return false, "Tu n'appartiens à aucun gang." end
    if G.DistTo(src, sp.x, sp.y, sp.z) > radius() then return false, 'Tu dois être dans le cercle.' end
    local owner = F.Owner(sp.id)
    if owner == g.id then return false, 'Ton groupe tient déjà ce point.' end
    local s = S(sp.id)
    if s.ready then return false, 'Ce drapeau attend déjà son chef.' end
    if s.gang then return false, 'Une capture est déjà en cours.' end
    local by = presence(sp)
    for other in pairs(by) do if other ~= g.id then return false, 'Un autre groupe est dans le cercle.' end end
    local minM = math.max(1, tonumber(cfg('min_members', 5)) or 5)
    if (by[g.id] or 0) < minM then return false, ('Il faut %d membres de ton groupe dans le cercle (%d ici).'):format(minM, by[g.id] or 0) end
    s.gang, s.p = g.id, 0
    if owner and cfg('warn_owner', true) and (not s.warned or nowS() - s.warned > 300) then
        s.warned = nowS()
        notifyGang(owner, 'error', ('%s attaque ton point : %s !'):format(g.label or gdef(g.id).label, sp.label))
    end
    F.Push(nil, true)
    PB.Audit.Log('serveur', 'flag.start', src, sp.id, nil, g.id)
    return true, ('Capture de %s lancée : restez dans le cercle.'):format(sp.label)
end
function F.Cleanup()
    for _, sp in ipairs(F.Spots()) do
        local before = ownersLoad()[tostring(sp.id)]
        if before and not F.Owner(sp.id) then notifyGang(before.gang, 'warn', ('Ton drapeau de %s a expiré.'):format(sp.label)) end
    end
end
CreateThread(function()
    local n = 0
    while true do
        Wait(1000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            F.Tick(1)
            n = n + 1
            if n % 30 == 0 then F.Cleanup() end
            F.Push()
        end)
        if not ok then PB.Warn('flags', 'boucle : ' .. tostring(err)) end
    end
end)

-- récupération du drapeau
local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
function F.Claim(src, id)
    if not cfg('enabled', true) then return false, 'Drapeaux désactivés.' end
    local sp = F.Spot(id)
    if not sp then return false, 'Point inconnu.' end
    local g = gangOf(src)
    if not g then return false, "Tu n'appartiens à aucun gang." end
    local s = st[sp.id]
    if not s or not s.ready or s.ready.gang ~= g.id then return false, "Le drapeau n'est pas prêt pour ton gang." end
    if G.DistTo(src, sp.x, sp.y, sp.z) > radius() then return false, 'Tu dois être dans le cercle.' end
    if cfg('boss_only', true) and not F.IsBoss(src, g.id) then return false, 'Seul le chef du gang peut récupérer le drapeau.' end
    local hours = math.max(1, tonumber(cfg('hours', 5)) or 5)
    local prev = F.Owner(sp.id)
    local row = { spot = sp.id, gang = g.id, since = nowS(), expires = nowS() + hours * 3600, claimed_by = G.Get(src).license }
    DB.exec('REPLACE INTO pb_flags (spot, gang, since, expires, claimed_by) VALUES (?, ?, ?, ?, ?)', { row.spot, row.gang, row.since, row.expires, row.claimed_by })
    ownersLoad()[tostring(sp.id)] = row
    st[sp.id] = { p = 0 }
    PB.Audit.Log('serveur', 'flag.claim', src, sp.id, prev, g.id, { hours = hours })
    F.Push(nil, true)
    for s2 in pairs(G.Players()) do G.Notify(s2, { type = 'info', title = 'Territoire', text = ('%s tient désormais %s pour %d h.'):format(g.label, sp.label, hours) }) end
    return true, ('%s est à toi pour %d h : ventes x%s.'):format(sp.label, hours, tostring(cfg('mult', 1.7)))
end
RegisterNetEvent('pb:g:flag:claim', function(id)
    local src = source
    if not usable(src) then return end
    local t = GetGameTimer and GetGameTimer() or os.time() * 1000
    if last[src] and t - last[src] < 800 then return end
    last[src] = t
    local ok, msg = F.Claim(src, tostring(id))
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Territoire', text = msg })
end)
RegisterNetEvent('pb:g:flag:start', function(id)
    local src = source
    if not usable(src) then return end
    local t = GetGameTimer and GetGameTimer() or os.time() * 1000
    if last[src] and t - last[src] < 800 then return end
    last[src] = t
    local ok, msg = F.Start(src, tostring(id))
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Territoire', text = msg })
end)
function F.Release(id) DB.exec('DELETE FROM pb_flags WHERE spot = ?', { tostring(id) }) ownersLoad()[tostring(id)] = nil st[tostring(id)] = nil F.Push(nil, true) end
PB.Cfg.OnChange('flags', function() F.Push(nil, true) end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------
local settings = Form.Cfg({ ns = 'flags', id = 'settings', title = 'Réglages des drapeaux', perm = 'flags.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Drapeaux actifs', default = true },
    { k = 'show', type = 'toggle', label = 'Dessiner les drapeaux et cercles en jeu', default = true },
    { k = 'radius', type = 'number', label = 'Rayon du cercle (m)', default = 25, min = 5, max = 200 },
    { k = 'min_members', type = 'number', label = 'Membres minimum dans le cercle', default = 5, min = 1, max = 50 },
    { k = 'secs', type = 'number', label = 'Secondes à tenir le point', default = 60, min = 5, max = 1800 },
    { k = 'hours', type = 'number', label = 'Durée de possession (heures)', default = 5, min = 1, max = 168 },
    { k = 'mult', type = 'number', label = 'Multiplicateur des ventes du gang qui tient le drapeau', default = 1.7, min = 1, max = 10, step = 0.1, int = false },
    { k = 'ready_secs', type = 'number', label = 'Délai pour que le chef récupère le drapeau (s)', default = 300, min = 30, max = 3600 },
    { k = 'pole_model', type = 'text', label = 'Drapeau (nom de l\'objet du jeu)', default = 'prop_flagpole_2a', maxlen = 48, pattern = '^[%w_]*$' },
    { k = 'boss_only', type = 'toggle', label = 'Seul le chef peut récupérer le drapeau', default = true },
    { k = 'warn_owner', type = 'toggle', label = "Prévenir le gang propriétaire quand on l'attaque", default = true },
} })
local function fmtLeft(sec) sec = math.max(0, sec) return ('%d h %02d min'):format(math.floor(sec / 3600), math.floor(sec % 3600 / 60)) end
PB.Module({
    id = 'flags', label = 'Territoires', icon = 'flag', group = 'Serveur', order = 145, perm = 'flags.edit', hint = 'Drapeaux des points de vente, carte, chefs',
    caps = function() return PB.Capsify({
        { 'Drapeau par point de vente', 'ok', 'Chaque vente de Activités illégales › filière a son drapeau et son cercle.' },
        { 'Prise du point', 'ok', "ALT sur le drapeau pour lancer la capture. Un seul gang dans le cercle, effectif minimum, durée à tenir ; le chef récupère le drapeau (E ou ALT). Vérifié par le serveur." },
        { 'Ventes multipliées', 'ok', 'Le gang propriétaire vend x1,7 (réglable) sur ce point pendant la durée de possession ; les autres vendent au prix normal.' },
        { 'Chef de gang', 'partial', "Désigné dans l'onglet Chefs, sinon le membre le plus ancien." },
        { 'Drapeau en 3D', 'ok', "Objet du jeu (réglable), avec un halo à la couleur du groupe qui tient le point." },
        { 'Carte', 'partial', 'Image satellite calibrée sur quelques repères : position à environ 100 m près.' },
    }) end,
    doc = "## Territoires\nALT sur le drapeau montre le bonus de vente, la durée de possession et le temps de capture, et permet de lancer la capture. Un gang seul dans le cercle, avec l'effectif minimum, tient le temps demandé : son chef récupère alors le drapeau. Le point est ensuite à lui pendant la durée réglée : ses ventes y sont multipliées.",
    view = function(ctx) return { tabs = {
        { id = 'map', label = 'Carte', icon = 'map', build = function()
            local pts, rows = {}, {}
            for _, v in ipairs(F.View()) do
                local col = v.owner and v.owner.color or '#111111'
                pts[#pts + 1] = { id = v.id, x = v.x, y = v.y, r = radius(), color = col, label = v.label, sub = v.owner and (v.owner.label .. ' · ' .. fmtLeft(v.owner.left)) or 'neutre' }
                rows[#rows + 1] = { id = v.id, spot = v.label, owner = v.owner and v.owner.label or 'Neutre', left = v.owner and fmtLeft(v.owner.left) or '—',
                    prog = v.ready and 'Prêt (chef)' or (v.by and (v.by.label .. ' ' .. v.prog .. ' %') or '—'),
                    actions = (v.owner and ctx.has('flags.edit')) and { { action = 'flags.release', label = 'Libérer', icon = 'flag', payload = { id = v.id } } } or nil }
            end
            return { { type = 'map', id = 'fmap', title = 'Points de vente et drapeaux', points = pts, legend = { { color = '#111111', label = 'Neutre (drapeau noir)' }, { color = '#dfe2e7', label = 'Tenu par un gang' } } },
                B.table({ id = 'flagt', title = 'Qui tient quoi', columns = { { k = 'spot', label = 'Point de vente' }, { k = 'owner', label = 'Propriétaire', type = 'badge' }, { k = 'left', label = 'Reste' }, { k = 'prog', label = 'Prise en cours' } }, rows = rows, empty = "Aucun point de vente : ajoute une filière de type « vente » dans Activités illégales." }) }
        end },
        { id = 'boss', label = 'Chefs', icon = 'users', build = function()
            local opts = {}
            for id, d in pairs(G.Tags and G.Tags.GangDefs and G.Tags.GangDefs() or {}) do opts[#opts + 1] = { id, d.label } end
            table.sort(opts, function(a, b) return a[1] < b[1] end)
            local names = {}
            for src, pl in pairs(G.Players()) do names[pl.license] = (GetPlayerName and GetPlayerName(src)) or G.Tag(src) end
            local rows = {}
            for _, d in ipairs(opts) do
                local lic = F.BossLicense(d[1])
                rows[#rows + 1] = { id = d[1], gang = d[2], who = lic and (names[lic] or lic) or '—', actions = ctx.has('flags.edit') and lic and { { action = 'flags.boss.clear', label = 'Retirer', icon = 'trash', payload = { gang = d[1] } } } or nil }
            end
            local out = {}
            if ctx.has('flags.edit') then
                out[#out + 1] = { type = 'form', id = 'flags.boss', title = 'Désigner un chef', desc = "Le chef récupère le drapeau. Sans chef désigné, c'est le membre le plus ancien du gang.", cols = 2, fields = {
                    { k = 'player', type = 'number', label = 'ID du joueur en ligne', min = 1, max = 999999, required = true },
                    { k = 'gang', type = 'select', label = 'Gang', options = opts, opts = opts, required = true } }, values = {}, submit = { action = 'flags.boss.set', label = 'Désigner' } }
            end
            out[#out + 1] = B.table({ id = 'bosst', title = 'Chefs de gang', columns = { { k = 'gang', label = 'Gang' }, { k = 'who', label = 'Chef' } }, rows = rows, empty = 'Aucun gang défini (Gamertags › Gangs).' })
            return out
        end },
        { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
    } } end,
})
PB.Action('flags.release', 'flags.edit', function(ctx, p) F.Release(p.id) ctx.audit('serveur', 'flag.release', tostring(p.id or '')) ctx.toast = 'Point libéré.' return true end)
PB.Action('flags.boss.set', 'flags.edit', function(ctx, p)
    local v = p.values or p
    local ok, e = F.SetBoss(tostring(v.gang or ''), G.SrcOfUid(v.player) or -1)
    if not ok then return false, e end
    ctx.audit('serveur', 'flag.boss', tostring(v.gang), tostring(v.player))
    ctx.toast = 'Chef désigné.'
    return true
end)
PB.Action('flags.boss.clear', 'flags.edit', function(ctx, p) DB.exec('DELETE FROM pb_gang_boss WHERE gang = ?', { tostring(p.gang or '') }) ctx.audit('serveur', 'flag.boss.clear', tostring(p.gang or '')) ctx.toast = 'Chef retiré.' return true end)
PB.SelfTest.Add('drapeaux', function(R)
    R.check(G.Crime ~= nil and G.Tags ~= nil, 'dépendances', 'Activités illégales ou Gamertags manquent')
    R.check(radius() >= 5 and (tonumber(cfg('mult', 1.7)) or 0) >= 1, 'rayon et multiplicateur valides', 'rayon < 5 ou multiplicateur < 1')
    if #F.Spots() == 0 then R.warn('points de vente', "aucun point de vente : pose-les depuis Builder › Drogues (le drapeau vient avec)") end
end)

-- Une seule fois : le drapeau devient le flag pole 2 du jeu (un objet choisi à la main dans les réglages est gardé).
PB.OnReady(function()
    if PB.Cfg.Get('flags', 'pole_v4', false) == true then return end
    local m = tostring(PB.Cfg.Get('flags', 'pole_model', ''))
    if m == '' or m == 'prop_pole_01a' or m == 'stt_prop_flagpole_2a' then PB.Cfg.Set('flags', 'pole_model', 'prop_flagpole_2a', nil, 'Drapeau : flag pole 2') end
    PB.Cfg.Set('flags', 'pole_v4', true, nil, 'Migration')
end)
