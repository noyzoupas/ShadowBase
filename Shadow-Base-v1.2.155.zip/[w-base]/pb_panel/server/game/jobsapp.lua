-- (v1.2.99) Recrutement par le téléphone : application « Emplois ».
--   · Le patron (ou un grade qui peut engager) ouvre le recrutement dans la tablette (F6 › Candidatures) avec un petit texte.
--   · Les joueurs voient les entreprises qui recrutent dans le téléphone et envoient une candidature (un message, leur numéro).
--   · Les recruteurs en ligne sont prévenus ; dans la tablette : Accepter (le candidat reçoit la proposition d'embauche, où qu'il soit)
--     ou Refuser (il reçoit un SMS). Hors ligne, le candidat est prévenu par SMS et l'embauche se fait à son retour (un recruteur relance).
local G, DB = PB.G, PB.DB
local Biz, Ph = G.Biz, G.Phone
if not (Biz and Biz.PAGES and Biz.ACT and Ph and Ph.ACT) then return end
local function now() return os.time() end
local function clean(s, n) return PB.Trim(PB.Sanitize(tostring(s or ''), n)) end
PB.Migrate('590_jobs_app', "Téléphone : application Emplois (offres et candidatures)", {
    [[CREATE TABLE IF NOT EXISTS pb_job_offers (biz_id VARCHAR(32) NOT NULL, open TINYINT NOT NULL DEFAULT 0, text VARCHAR(300) NOT NULL DEFAULT '', by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (biz_id))]],
    [[CREATE TABLE IF NOT EXISTS pb_job_apps (id INT NOT NULL AUTO_INCREMENT, biz_id VARCHAR(32) NOT NULL, license VARCHAR(64) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', number VARCHAR(16) NOT NULL DEFAULT '',
        text VARCHAR(500) NOT NULL DEFAULT '', status VARCHAR(10) NOT NULL DEFAULT 'pending', by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, done_at INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY k_biz (biz_id, status), KEY k_lic (license))]],
})
Ph.SYS.emploi = Ph.SYS.emploi or 'Emplois'
local function onlineOf(license) for src, pl in pairs(G.Players()) do if pl.license == license then return src end end end
local function recruiters(bizId)
    local out = {}
    for src in pairs(G.Players()) do local c = Biz.Ctx(src) if c and c.biz.id == bizId and Biz.Can(c, 'hire') then out[#out + 1] = src end end
    return out
end

-- Téléphone ----------------------------------------------------------------------------------------------------------------------------------
local DATA = Ph.DATA
local function jobsData(src)
    local p = G.Get(src)
    local mine = {}
    for _, a in ipairs(DB.q('SELECT a.id, a.biz_id, a.status, a.at, b.label FROM pb_job_apps a LEFT JOIN pb_biz b ON b.id = a.biz_id WHERE a.license = ? ORDER BY a.id DESC LIMIT 10', { p.license }) or {}) do
        mine[a.biz_id] = mine[a.biz_id] or { status = a.status, at = a.at }
    end
    local list = {}
    for _, o in ipairs(DB.q('SELECT b.id, b.label, b.description, o.text, o.at FROM pb_biz b LEFT JOIN pb_job_offers o ON o.biz_id = b.id WHERE b.hiring = 1 AND b.enabled = 1 ORDER BY o.at DESC LIMIT 60') or {}) do
        local m = mine[o.id]
        list[#list + 1] = { id = o.id, name = o.label, text = (o.text and o.text ~= '') and o.text or (o.description or ''), at = o.at and Ph.Stamp(o.at) or '', status = m and m.status or nil }
    end
    local cur = Biz.MemberOf(p.license)
    return { list = list, job = cur and (DB.one('SELECT label FROM pb_biz WHERE id = ?', { cur.biz_id }) or {}).label or nil }
end
G.JobsData = jobsData
DATA.jobs = jobsData
Ph.ACT.job_apply = function(_, src, p)
    local pl = G.Get(src)
    local bizId = tostring(p.biz or '')
    local o = DB.one('SELECT hiring AS open, label FROM pb_biz WHERE id = ? AND enabled = 1', { bizId })
    if not o or not PB.ToBool(o.open) then return false, "Cette entreprise ne recrute plus.", 'jobs' end
    local cur = Biz.MemberOf(pl.license)
    if cur and cur.biz_id == bizId then return false, 'Tu travailles déjà ici.', 'jobs' end
    local text = clean(p.text, 500)
    if #text < 10 then return false, 'Écris quelques mots sur toi (10 caractères au moins).', 'jobs' end
    if DB.one("SELECT id FROM pb_job_apps WHERE biz_id = ? AND license = ? AND status = 'pending'", { bizId, pl.license }) then return false, 'Ta candidature est déjà en attente.', 'jobs' end
    local n = DB.one("SELECT COUNT(*) AS n FROM pb_job_apps WHERE license = ? AND status = 'pending'", { pl.license })
    if n and (tonumber(n.n) or 0) >= 3 then return false, 'Tu as déjà 3 candidatures en attente.', 'jobs' end
    local name = Biz.Display(src)
    DB.insert('INSERT INTO pb_job_apps (biz_id, license, name, number, text, at) VALUES (?, ?, ?, ?, ?, ?)', { bizId, pl.license, name:sub(1, 64), Ph.Number(pl.license) or '', text, now() })
    for _, r in ipairs(recruiters(bizId)) do G.Notify(r, { type = 'info', title = o.label .. ' · candidature', text = name .. ' veut travailler chez vous. Tablette (F6) › Candidatures.', duration = 10000 }) end
    return true, 'Candidature envoyée à ' .. o.label .. '.', 'jobs'
end
Ph.ACT.job_cancel = function(_, src, p)
    local pl = G.Get(src)
    DB.exec("UPDATE pb_job_apps SET status = 'cancelled', done_at = ? WHERE biz_id = ? AND license = ? AND status = 'pending'", { now(), tostring(p.biz or ''), pl.license })
    return true, 'Candidature retirée.', 'jobs'
end

-- Tablette (F6) › Candidatures ----------------------------------------------------------------------------------------------------------------
table.insert(Biz.ORDER, 'apps')
Biz.PAGE_META.apps = { label = 'Candidatures', icon = 'users', group = 'Entreprise' }
Biz.NavAllow.apps = function(c) return Biz.Can(c, 'hire') end
Biz.PAGES.apps = function(src)
    local c = Biz.Ctx(src)
    if not c or not Biz.Can(c, 'hire') then return nil end
    local o = DB.one('SELECT text FROM pb_job_offers WHERE biz_id = ?', { c.biz.id }) or { text = '' }
    o.open = PB.ToBool((DB.one('SELECT hiring FROM pb_biz WHERE id = ?', { c.biz.id }) or {}).hiring)
    local rows = {}
    for _, a in ipairs(DB.q("SELECT * FROM pb_job_apps WHERE biz_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 40", { c.biz.id }) or {}) do
        rows[#rows + 1] = { at = os.date('%d/%m %H:%M', a.at), name = a.name, number = a.number, text = a.text, state = onlineOf(a.license) and 'En ligne' or 'Hors ligne',
            actions = { { label = 'Accepter', act = 'app_accept', payload = { id = a.id }, icon = 'check' }, { label = 'Refuser', act = 'app_refuse', payload = { id = a.id }, icon = 'x' } } }
    end
    local past = {}
    for _, a in ipairs(DB.q("SELECT * FROM pb_job_apps WHERE biz_id = ? AND status IN ('accepted', 'refused', 'hired') ORDER BY done_at DESC LIMIT 15", { c.biz.id }) or {}) do
        past[#past + 1] = { at = os.date('%d/%m %H:%M', a.done_at), name = a.name, state = ({ accepted = 'Acceptée (à embaucher)', refused = 'Refusée', hired = 'Embauché(e)' })[a.status] or a.status, by = a.by_name }
    end
    return {
        { type = 'form', id = 'jobs_offer', title = 'Recrutement', desc = "Ouvert : ton entreprise apparaît dans l'application Emplois du téléphone de tous les joueurs.", cols = 1, fields = {
            { k = 'open', type = 'toggle', label = 'Nous recrutons', default = PB.ToBool(o.open) },
            { k = 'text', type = 'text', label = 'Annonce (poste, horaires, ce que vous cherchez)', maxlen = 300, default = o.text } },
            values = { open = PB.ToBool(o.open), text = o.text }, submit = { act = 'jobs_offer', label = 'Enregistrer' } },
        { type = 'table', title = 'Candidatures en attente', columns = { { k = 'at', label = 'Reçue' }, { k = 'name', label = 'Candidat' }, { k = 'number', label = 'Téléphone' }, { k = 'state', label = 'État', type = 'badge' }, { k = 'text', label = 'Message' } }, rows = rows, empty = 'Aucune candidature en attente.' },
        { type = 'table', title = 'Dernières réponses', columns = { { k = 'at', label = 'Date' }, { k = 'name', label = 'Candidat' }, { k = 'state', label = 'Réponse' }, { k = 'by', label = 'Par' } }, rows = past, empty = '—' },
    }, 'Candidatures'
end
Biz.ACT.jobs_offer = function(c, src, p)
    if not Biz.Can(c, 'hire') then return false, "Tu n'as pas le droit d'engager." end
    local v = type(p.values) == 'table' and p.values or p
    local open = v.open == true or v.open == 1 or v.open == '1'
    local text = clean(v.text, 300)
    if open and #text < 5 then return false, "Écris une petite annonce (5 caractères au moins)." end
    DB.exec('REPLACE INTO pb_job_offers (biz_id, open, text, by_name, at) VALUES (?, ?, ?, ?, ?)', { c.biz.id, open and 1 or 0, text, Biz.Display(src):sub(1, 64), now() })
    DB.exec('UPDATE pb_biz SET hiring = ? WHERE id = ?', { open and 1 or 0, c.biz.id })
    return true, open and "Recrutement ouvert : visible dans l'application Emplois." or 'Recrutement fermé.'
end
local function hireRemote(c, src, tid)
    local tp = G.Get(tid)
    if not tp then return false, "Le candidat s'est déconnecté." end
    local first = DB.one('SELECT grade FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade LIMIT 1', { c.biz.id })
    local cur = Biz.MemberOf(tp.license)
    if cur then
        if cur.biz_id == c.biz.id then return false, 'Cette personne travaille déjà ici.' end
        local BC = G.BizCat
        if not (BC and BC.Job2Allowed and BC.Job2Allowed(tid)) or BC.Job2(tp.license) then return false, 'Cette personne a déjà un emploi : elle doit démissionner avant.' end
        local ok2, e2 = BC.SetJob2(tid, c.biz.id, first and first.grade or 0)
        if not ok2 then return false, e2 end
        return true, Biz.Display(tid) .. ' est engagé(e) en second emploi (VIP).'
    end
    return Biz.SetJob(tid, c.biz.id, first and first.grade or 0)
end
Biz.ACT.app_accept = function(c, src, p)
    if not Biz.Can(c, 'hire') then return false, "Tu n'as pas le droit d'engager." end
    local a = DB.one("SELECT * FROM pb_job_apps WHERE id = ? AND biz_id = ? AND status IN ('pending', 'accepted')", { math.floor(tonumber(p.id) or 0), c.biz.id })
    if not a then return false, 'Candidature introuvable.' end
    DB.exec("UPDATE pb_job_apps SET status = 'accepted', by_name = ?, done_at = ? WHERE id = ?", { Biz.Display(src):sub(1, 64), now(), a.id })
    local t = onlineOf(a.license)
    if not t then
        Ph.Notice(a.license, 'emploi', ('%s a accepté ta candidature ! Reviens en ville : un recruteur te proposera le poste.'):format(c.biz.label))
        return true, a.name .. " est hors ligne : il est prévenu par SMS. Accepte de nouveau à son retour pour lui envoyer le poste."
    end
    local first = DB.one('SELECT label, salary FROM pb_biz_grades WHERE biz_id = ? ORDER BY grade LIMIT 1', { c.biz.id })
    local bizId = c.biz.id
    local ok, why = G.Recruit.Offer(t, { kind = 'biz', org = c.biz.label, from = src, fromName = Biz.Display(src), grade = first and first.label, salary = first and tonumber(first.salary), secs = 120,
        accept = function()
            local c2 = Biz.Ctx(src)
            if not c2 or c2.biz.id ~= bizId or not Biz.Can(c2, 'hire') then return false, "La personne qui t'a proposé ce poste ne peut plus engager." end
            local okH, msg = hireRemote(c2, src, t)
            if okH then DB.exec("UPDATE pb_job_apps SET status = 'hired', done_at = ? WHERE id = ?", { now(), a.id }) end
            return okH, msg
        end })
    if not ok then return false, why end
    Ph.Notice(a.license, 'emploi', ('%s accepte ta candidature : réponds à la proposition à l\'écran (Y / N).'):format(c.biz.label))
    return true, 'Proposition envoyée à ' .. a.name .. ' (il répond à l\'écran).'
end
Biz.ACT.app_refuse = function(c, src, p)
    if not Biz.Can(c, 'hire') then return false, "Tu n'as pas le droit d'engager." end
    local a = DB.one("SELECT * FROM pb_job_apps WHERE id = ? AND biz_id = ? AND status = 'pending'", { math.floor(tonumber(p.id) or 0), c.biz.id })
    if not a then return false, 'Candidature introuvable.' end
    DB.exec("UPDATE pb_job_apps SET status = 'refused', by_name = ?, done_at = ? WHERE id = ?", { Biz.Display(src):sub(1, 64), now(), a.id })
    Ph.Notice(a.license, 'emploi', ("%s n'a pas retenu ta candidature cette fois. Bonne chance pour la suite !"):format(c.biz.label))
    return true, 'Candidature refusée : ' .. a.name .. ' est prévenu par SMS.'
end
