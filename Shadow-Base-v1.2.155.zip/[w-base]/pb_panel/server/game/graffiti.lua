-- Graffitis : chaque joueur choisit un tag (image envoyée depuis le panel, ou texte stylisé), le prévisualise en transparence sur le mur, puis le pose.
-- Les graffitis d'organisation donnent de l'influence chaque jour dans un territoire, tant qu'ils ne sont pas effacés.
-- Le client ne décide de rien : le serveur relit la position du joueur, borne la taille, filtre le texte et refuse les tags qui ne sont pas à lui.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Gf = {}
G.Graffiti = Gf

P.Register('graffiti.edit', 'Modifier les graffitis (bibliothèque, limites, suppression)', 'graffiti', true)
PB.Migrate('098_graffiti', 'Graffitis posés sur les murs', {
    [[CREATE TABLE IF NOT EXISTS pb_graffiti (id INT AUTO_INCREMENT PRIMARY KEY, license VARCHAR(64) NOT NULL, gang VARCHAR(32) NOT NULL DEFAULT '', author VARCHAR(60) NOT NULL DEFAULT '', kind VARCHAR(4) NOT NULL, ref VARCHAR(40) NOT NULL DEFAULT '', txt VARCHAR(40) NOT NULL DEFAULT '', font VARCHAR(10) NOT NULL DEFAULT '', color VARCHAR(7) NOT NULL DEFAULT '#ffffff', outline VARCHAR(7) NOT NULL DEFAULT '#000000', x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, nx DOUBLE NOT NULL, ny DOUBLE NOT NULL, nz DOUBLE NOT NULL, w DOUBLE NOT NULL, rot DOUBLE NOT NULL DEFAULT 0, created INT NOT NULL DEFAULT 0, last_inf INT NOT NULL DEFAULT 0, KEY k_lic (license), KEY k_gang (gang))]],
})
local SLOTS = 16
local DEF = { enabled = true, max_per_player = 5, max_per_gang = 30, cooldown = 45, place_dist = 6, erase_dist = 4, erase_secs = 8, w_min = 0.6, w_max = 2.5, min_gap = 1.2,
    allow_text = true, spray_item = '', influence_per_day = 5, influence_cap = 30, key = '' }
for i = 1, SLOTS do DEF['t' .. i .. '_name'] = '' DEF['t' .. i .. '_img'] = '' DEF['t' .. i .. '_gang'] = '' end
PB.Cfg.Define('graffiti', DEF)
local function cfg(k, d) return PB.Cfg.Get('graffiti', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function gangOf(src) return G.Tags and G.Tags.Gang and G.Tags.Gang(src) end
local function nameOf(src) local i = G.Identity(src) or {} local n = ((i.firstname or '') .. ' ' .. (i.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') return n ~= '' and n or ('Joueur ' .. src) end

local FONTS = { street = 'Rue', bold = 'Gras', script = 'Italique', stencil = 'Pochoir' }
local COLORS = { '#ffffff', '#ff3b4e', '#ff9f1a', '#ffe14d', '#3ddc84', '#35c4ff', '#6a7bff', '#c05cff', '#ff6bd6', '#111111' }
Gf.Fonts, Gf.Colors = FONTS, COLORS
local function okColor(c) return type(c) == 'string' and c:match('^#%x%x%x%x%x%x$') ~= nil and c:lower() or nil end

-- Bibliothèque : seize emplacements (nom, image, gang réservé) --------------------------------------------------------------------------------
function Gf.Library(src)
    local g = src and gangOf(src)
    local out = {}
    for i = 1, SLOTS do
        local img, name, only = cfg('t' .. i .. '_img', ''), cfg('t' .. i .. '_name', ''), cfg('t' .. i .. '_gang', '')
        if type(img) == 'string' and img ~= '' and PB.Asset and PB.Asset.Valid(img) then
            only = tostring(only or '')
            if only == '' or (g and g.id == only) then out[#out + 1] = { id = 't' .. i, name = clean(name ~= '' and name or ('Tag ' .. i), 30), img = img, gang = only ~= '' and only or nil } end
        end
    end
    return out
end
local function slotOf(src, ref)
    for _, t in ipairs(Gf.Library(src)) do if t.id == ref then return t end end
end

-- Données --------------------------------------------------------------------------------------------------------------------------------
local function row2g(r)
    return { id = r.id, kind = r.kind, ref = r.ref ~= '' and r.ref or nil, img = (r.kind == 'img') and cfg(r.ref .. '_img', '') or nil, text = r.txt ~= '' and r.txt or nil, font = r.font ~= '' and r.font or nil,
        color = r.color, outline = r.outline, x = r.x, y = r.y, z = r.z, nx = r.nx, ny = r.ny, nz = r.nz, w = r.w, rot = r.rot, gang = r.gang ~= '' and r.gang or nil }
end
function Gf.All()
    local out = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_graffiti ORDER BY id DESC LIMIT 600') or {}) do out[#out + 1] = row2g(r) end
    return out
end
function Gf.Count(license) local r = DB.one('SELECT COUNT(*) AS n FROM pb_graffiti WHERE license = ?', { license }) return r and tonumber(r.n) or 0 end
table.insert(G.beginHooks, function(src) TriggerClientEvent('pb:g:gfx:all', src, PB.Json({ list = Gf.All() })) end)

local last, sessions, placedAt = {}, {}, {}   -- placedAt : délai entre deux tags, à part (le menu et l'effacement ont leur propre anti-répétition)
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end
AddEventHandler('playerDropped', function() last[tostring(source)] = nil sessions[source] = nil placedAt[source] = nil end)

local function menuData(src)
    local p = G.Get(src)
    local g = gangOf(src)
    return { tags = Gf.Library(src), fonts = (function() local o = {} for _, k in ipairs({ 'street', 'bold', 'script', 'stencil' }) do o[#o + 1] = { id = k, label = FONTS[k] } end return o end)(), colors = COLORS,
        allowText = cfg('allow_text', true) ~= false, wMin = tonumber(cfg('w_min', 0.6)), wMax = tonumber(cfg('w_max', 2.5)), mine = p and Gf.Count(p.license) or 0, max = tonumber(cfg('max_per_player', 5)),
        gang = g and { id = g.id, label = g.label, color = g.color } or nil, item = cfg('spray_item', '') ~= '' and cfg('spray_item', '') or nil }
end
RegisterNetEvent('pb:g:gfx:menu', function()
    local src = source
    if cfg('enabled', true) == false or not usable(src) or not throttle(src, 600) then return end
    TriggerClientEvent('pb:g:gfx:ui', src, PB.Json({ ev = 'open', data = menuData(src) }))
end)

-- Pose ----------------------------------------------------------------------------------------------------------------------------------
local function num(v, lo, hi) v = tonumber(v) if not v or v ~= v or v < lo or v > hi then return nil end return v end
function Gf.Place(src, d)
    if cfg('enabled', true) == false then return false, 'Les graffitis sont désactivés.' end
    if not usable(src) then return false, 'Impossible maintenant.' end
    if type(d) ~= 'table' then return false, 'Demande invalide.' end
    local p = G.Get(src)
    local x, y, z = num(d.x, -10000, 10000), num(d.y, -10000, 10000), num(d.z, -1000, 3000)
    local nx, ny, nz = num(d.nx, -1, 1), num(d.ny, -1, 1), num(d.nz, -1, 1)
    if not (x and y and z and nx and ny and nz) then return false, 'Position invalide.' end
    local len = math.sqrt(nx * nx + ny * ny + nz * nz)
    if len < 0.9 or len > 1.1 then return false, 'Surface invalide.' end
    nx, ny, nz = nx / len, ny / len, nz / len
    if math.abs(nz) > 0.5 then return false, 'Pose le tag sur un mur, pas au sol ni au plafond.' end
    if G.DistTo(src, x, y, z) > (tonumber(cfg('place_dist', 6)) or 6) + 3 then return false, 'Tu es trop loin du mur.' end
    local w = num(d.w, tonumber(cfg('w_min', 0.6)) - 1e-6, tonumber(cfg('w_max', 2.5)) + 1e-6)
    if not w then return false, 'Taille invalide.' end
    local rot = num(d.rot, -180, 180) or 0
    local g = gangOf(src)
    local kind, ref, txt, font, color, outline = d.kind, '', '', '', '#ffffff', '#000000'
    if kind == 'img' then
        local t = slotOf(src, tostring(d.ref or ''))
        if not t then return false, "Ce tag n'est pas disponible pour toi." end
        ref = t.id
    elseif kind == 'txt' then
        if cfg('allow_text', true) == false then return false, 'Les tags en texte sont désactivés.' end
        txt = clean(d.text, 20):gsub('^%s+', ''):gsub('%s+$', ''):gsub('%s+', ' ')
        txt = txt:gsub("[^%w%s'!?%.%-éèêëàâäîïôöùûüçÉÈÀÇ]", '')
        if #txt < 2 then return false, 'Écris au moins 2 caractères.' end
        font = FONTS[d.font] and d.font or 'street'
        color = okColor(d.color) or '#ffffff'
        outline = okColor(d.outline) or '#000000'
    else return false, 'Type de tag inconnu.' end
    local tnow = GetGameTimer and GetGameTimer() or os.time() * 1000
    local wait = math.max(2, tonumber(cfg('cooldown', 45)) or 45) * 1000
    if placedAt[src] and tnow - placedAt[src] < wait then return false, ('Attends encore %d s avant le prochain tag.'):format(math.ceil((wait - (tnow - placedAt[src])) / 1000)) end
    local mine = Gf.Count(p.license)
    if mine >= (tonumber(cfg('max_per_player', 5)) or 5) then return false, ('Tu as déjà %d tags posés : efface-en un.'):format(mine) end
    if g then
        local gn = DB.one('SELECT COUNT(*) AS n FROM pb_graffiti WHERE gang = ?', { g.id })
        if gn and tonumber(gn.n) >= (tonumber(cfg('max_per_gang', 30)) or 30) then return false, 'Ton organisation a atteint sa limite de tags.' end
    end
    local gap = tonumber(cfg('min_gap', 1.2)) or 1.2
    for _, r in ipairs(DB.q('SELECT x, y, z FROM pb_graffiti WHERE ABS(x - ?) < 3 AND ABS(y - ?) < 3 AND ABS(z - ?) < 3', { x, y, z }) or {}) do
        local dx, dy, dz = r.x - x, r.y - y, r.z - z
        if math.sqrt(dx * dx + dy * dy + dz * dz) < gap then return false, 'Il y a déjà un tag ici.' end
    end
    local item = cfg('spray_item', '')
    if item ~= '' and G.Inv then
        local o = G.Inv.PlayerOwner(src)
        if not o or G.Inv.Count(o, item) < 1 then return false, ("Il te faut « %s »."):format(item) end
        if not G.Inv.Remove(o, item, 1) then return false, "L'objet n'est plus là, réessaie." end
    end
    local id = DB.insert('INSERT INTO pb_graffiti (license, gang, author, kind, ref, txt, font, color, outline, x, y, z, nx, ny, nz, w, rot, created, last_inf) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { p.license, g and g.id or '', nameOf(src), kind, ref, txt, font, color, outline, x, y, z, nx, ny, nz, w, rot, os.time(), os.time() })
    placedAt[src] = tnow   -- seulement pour un tag vraiment posé
    local row = DB.one('SELECT * FROM pb_graffiti WHERE id = ?', { id })
    if row then TriggerClientEvent('pb:g:gfx:add', -1, PB.Json({ g = row2g(row) })) end
    PB.Audit.Log('serveur', 'graffiti.place', src, tostring(id), nil, nil, { gang = g and g.id or nil, kind = kind })
    return true, 'Ton tag est posé.'
end
RegisterNetEvent('pb:g:gfx:place', function(d)
    local src = source
    local ok, msg = Gf.Place(src, d)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Graffiti', text = msg })
    TriggerClientEvent('pb:g:gfx:ui', src, PB.Json({ ev = 'placed', ok = ok }))
end)

-- Effacer : on se place devant, on frotte quelques secondes (durée vérifiée par le serveur) ------------------------------------------------------
RegisterNetEvent('pb:g:gfx:erase:start', function(id)
    local src = source
    if cfg('enabled', true) == false or not usable(src) or not throttle(src, 700) then return end
    id = math.floor(tonumber(id) or 0)
    local r = DB.one('SELECT * FROM pb_graffiti WHERE id = ?', { id })
    if not r then return end
    if G.DistTo(src, r.x, r.y, r.z) > (tonumber(cfg('erase_dist', 4)) or 4) + 2 then G.Notify(src, { type = 'warn', title = 'Graffiti', text = 'Rapproche-toi du tag.' }) return end
    local secs = math.max(2, tonumber(cfg('erase_secs', 8)) or 8)
    sessions[src] = { id = id, t = os.time(), secs = secs }
    TriggerClientEvent('pb:g:gfx:erase:go', src, PB.Json({ id = id, secs = secs }))
end)
RegisterNetEvent('pb:g:gfx:erase:end', function(done)
    local src = source
    local se = sessions[src]
    sessions[src] = nil
    if not se or done ~= true then return end
    if os.time() - se.t < se.secs - 1 then G.Notify(src, { type = 'warn', title = 'Graffiti', text = "Tu n'as pas frotté assez longtemps." }) return end
    local r = DB.one('SELECT * FROM pb_graffiti WHERE id = ?', { se.id })
    if not r or not usable(src) or G.DistTo(src, r.x, r.y, r.z) > (tonumber(cfg('erase_dist', 4)) or 4) + 3 then return end
    DB.exec('DELETE FROM pb_graffiti WHERE id = ?', { se.id })
    TriggerClientEvent('pb:g:gfx:del', -1, PB.Json({ id = se.id }))
    PB.Audit.Log('serveur', 'graffiti.erase', src, tostring(se.id), r.gang ~= '' and r.gang or nil, nil, { author = r.author })
    G.Notify(src, { type = 'success', title = 'Graffiti', text = 'Tag effacé.' })
    -- (v1.2.99) le gang du tag est prévenu : son territoire est attaqué
    if r.gang and r.gang ~= '' and G.Tags and G.Tags.Gang then
        local mine = G.Tags.Gang(src)
        local who = (mine and mine.id ~= r.gang and mine.label) and ('le gang ' .. mine.label) or "quelqu'un"
        for s2 in pairs(G.Players()) do
            local g = s2 ~= src and G.Tags.Gang(s2)
            if g and g.id == r.gang then G.Notify(s2, { type = 'warn', title = 'Tag effacé', text = ('Un de vos tags a été effacé par %s : votre influence sur le territoire baisse.'):format(who), duration = 9000 }) end
        end
    end
end)
function Gf.Delete(id)
    id = math.floor(tonumber(id) or 0)
    DB.exec('DELETE FROM pb_graffiti WHERE id = ?', { id })
    TriggerClientEvent('pb:g:gfx:del', -1, PB.Json({ id = id }))
end

-- Influence : une fois par jour et par tag, tant qu'il existe, dans la zone où il se trouve ---------------------------------------------------------
function Gf.DailyInfluence()
    local now, gained = os.time(), 0
    local T = G.Territories
    if not T then return 0 end
    local zones = PB.Cfg.Get('territories', 'zones', {}) or {}
    for _, r in ipairs(DB.q("SELECT id, gang, x, y, z FROM pb_graffiti WHERE gang <> '' AND last_inf + 86400 <= ?", { now }) or {}) do
        for _, z in ipairs(zones) do
            local dx, dy = r.x - z.x, r.y - z.y
            if math.sqrt(dx * dx + dy * dy) <= (tonumber(z.radius) or 30) then
                gained = gained + T.AddInfluence(z.id, r.gang, tonumber(cfg('influence_per_day', 5)) or 5, tonumber(cfg('influence_cap', 30)) or 30)
                break
            end
        end
        DB.exec('UPDATE pb_graffiti SET last_inf = ? WHERE id = ?', { now, r.id })
    end
    return gained
end
CreateThread(function()
    while true do
        Wait(10 * 60000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if cfg('enabled', true) ~= false then Gf.DailyInfluence() end
        end)
        if not ok then PB.Warn('graffiti', 'boucle : ' .. tostring(err)) end
    end
end)

-- Panel ------------------------------------------------------------------------------------------------------------------------------------
local fields = {
    { k = 'enabled', type = 'toggle', label = 'Graffitis actifs', default = true },
    { k = 'allow_text', type = 'toggle', label = 'Tags en texte stylisé autorisés', default = true },
    { k = 'max_per_player', type = 'number', label = 'Tags par joueur', default = 5, min = 1, max = 50 },
    { k = 'max_per_gang', type = 'number', label = "Tags par organisation", default = 30, min = 1, max = 300 },
    { k = 'cooldown', type = 'number', label = 'Délai entre deux tags (s)', default = 45, min = 2, max = 3600 },
    { k = 'erase_secs', type = 'number', label = "Durée pour effacer (s)", default = 8, min = 2, max = 120 },
    { k = 'w_min', type = 'number', label = 'Largeur minimale (m)', default = 0.6, min = 0.2, max = 3, int = false },
    { k = 'w_max', type = 'number', label = 'Largeur maximale (m)', default = 2.5, min = 0.5, max = 6, int = false },
    { k = 'min_gap', type = 'number', label = 'Distance minimale entre deux tags (m)', default = 1.2, min = 0.3, max = 10, int = false },
    { k = 'spray_item', type = 'text', label = 'Objet consommé par tag (vide = aucun)', default = '', maxlen = 40, pattern = '^[%w_%-]*$', hint = "Nom d'un objet de l'inventaire, par exemple spray." },
    { k = 'influence_per_day', type = 'number', label = 'Influence par tag et par jour (dans un territoire)', default = 5, min = 0, max = 100 },
    { k = 'influence_cap', type = 'number', label = 'Influence maximale par jour, par organisation et par zone', default = 30, min = 1, max = 1000 },
}
local libFields = {}
for i = 1, SLOTS do
    libFields[#libFields + 1] = { k = 't' .. i .. '_name', type = 'text', label = ('Tag %d : nom'):format(i), default = '', maxlen = 30 }
    libFields[#libFields + 1] = { k = 't' .. i .. '_img', type = 'asset', label = ('Tag %d : image (depuis mon PC)'):format(i), default = '', maxw = 512, maxh = 256 }
    libFields[#libFields + 1] = { k = 't' .. i .. '_gang', type = 'text', label = ('Tag %d : réservé au gang (identifiant, vide = tous)'):format(i), default = '', maxlen = 32, pattern = '^[%w_%-]*$' }
end
local general = Form.Cfg({ ns = 'graffiti', id = 'general', title = 'Graffitis', perm = 'graffiti.edit', cols = 2, fields = fields })
local library = Form.Cfg({ ns = 'graffiti', id = 'library', title = 'Bibliothèque de tags', perm = 'graffiti.edit', cols = 3,
    desc = "Les images viennent de ton PC (PNG, JPEG, WebP, fond transparent conseillé). Un tag réservé à un gang est le logo de ce groupe : seuls ses membres le voient dans le menu.", fields = libFields })

PB.Module({
    id = 'graffiti', label = 'Graffitis', icon = 'palette', group = 'Serveur', order = 148, perm = 'graffiti.edit', hint = 'Tags sur les murs, logos de groupes, influence',
    caps = function() return PB.Capsify({
        { 'Tags en image (bibliothèque) et en texte stylisé', 'ok', "Les images sont envoyées depuis le PC dans le panel ; le texte a 4 styles et 10 couleurs." },
        { 'Prévisualisation transparente avant la pose', 'ok', 'Le tag suit le mur visé ; molette pour la taille, Q et E pour tourner, clic pour poser.' },
        { 'Logo de groupe', 'ok', "Un tag de la bibliothèque réservé à un gang : seuls ses membres peuvent le poser." },
        { 'Influence quotidienne dans un territoire', 'ok', "Chaque tag d'organisation non effacé rapporte des points par jour dans la zone où il se trouve ; 100 points raccourcissent la capture de 40 %." },
        { 'Choisir un fichier directement sur son PC en jeu', 'off', "Impossible : l'interface du jeu ne peut pas ouvrir l'explorateur de fichiers. Les images passent par le panel (bibliothèque), le joueur choisit dans la liste." },
        { 'Affichage sur les murs', 'partial', "Dessiné par le jeu à partir d'une page interne (DUI) projetée sur le mur ; rendu et performances jamais vérifiés dans un vrai client ici. Une surface très courbe peut déformer le tag." },
    }) end,
    doc = "## Graffitis\nLe joueur ouvre le menu des tags (commande `/tag`, ou **ALT** sur soi > Faire un tag), choisit un tag de la bibliothèque ou écrit un texte, règle la taille, puis vise un mur : un aperçu **transparent** suit son regard. Clic gauche pour poser, clic droit pour annuler.\n\n- La bibliothèque se remplit ici (images depuis ton PC). Un tag réservé à un gang sert de logo de groupe.\n- Les tags d'une organisation donnent de l'**influence** chaque jour dans le territoire où ils se trouvent, tant qu'ils ne sont pas effacés.\n- `/tagerase` : efface le tag le plus proche (quelques secondes de frottement). Le staff peut supprimer depuis l'onglet Posés.",
    view = function(ctx)
        return { tabs = {
            { id = 'general', label = 'Réglages', icon = 'sliders', build = function() return { general(ctx) } end },
            { id = 'library', label = 'Bibliothèque', icon = 'image', build = function() return { library(ctx) } end },
            { id = 'placed', label = 'Posés', icon = 'map', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT id, author, gang, kind, txt, ref, created FROM pb_graffiti ORDER BY id DESC LIMIT 200') or {}) do
                    rows[#rows + 1] = { id = r.id, author = r.author, gang = r.gang ~= '' and r.gang or '—', what = r.kind == 'txt' and ('« ' .. r.txt .. ' »') or ('Image ' .. r.ref), at = r.created,
                        actions = ctx.has('graffiti.edit') and { { action = 'graffiti.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = r.id } } } or nil }
                end
                return { B.table({ id = 'gf', title = 'Graffitis posés (' .. #rows .. ')', search = true, columns = { { k = 'author', label = 'Auteur' }, { k = 'gang', label = 'Organisation', type = 'badge' }, { k = 'what', label = 'Tag' }, { k = 'at', label = 'Posé', type = 'date' } }, rows = rows }) }
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'graffiti', title = 'Menu des tags', cfg = {} } } end },
        } }
    end,
})
PB.Action('graffiti.delete', 'graffiti.edit', function(ctx, p)
    Gf.Delete(p.id)
    ctx.audit('serveur', 'graffiti.delete', tostring(p.id or ''))
    ctx.toast = 'Graffiti supprimé.'
    return true
end)

PB.SelfTest.Add('graffitis', function(R)
    R.check(#COLORS == 10 and FONTS.street ~= nil, 'styles', 'palette ou polices manquantes')
    R.check(type(Gf.Place) == 'function' and type(Gf.DailyInfluence) == 'function', 'fonctions', 'manquantes')
    R.check(G.Territories ~= nil and G.Territories.AddInfluence ~= nil, 'influence', "les territoires n'exposent pas l'influence")
end)
