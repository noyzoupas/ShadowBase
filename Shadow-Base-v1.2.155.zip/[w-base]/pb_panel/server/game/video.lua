-- (v1.2.78) Diffusion vidéo (fondateur uniquement) : une vidéo YouTube jouée en même temps sur l'écran de TOUS les joueurs connectés.
-- L'écran est bloqué pendant la diffusion ; chacun règle seulement son volume. Ceux qui se connectent pendant la diffusion la
-- rejoignent au bon moment. Seul un fondateur (propriétaire du panel) peut lancer ou arrêter.

local G = PB.G
local S = G.Staff
local P = PB.Perm
local V = {}
G.Video = V

P.Register('staff.video', 'Diffuser une vidéo YouTube à tous les joueurs (fondateur)', 'staff', true)
local cur = nil   -- { id, title, start, by, src }

local function ytId(url)
    url = tostring(url or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if url:match('^[%w_%-]+$') and #url == 11 then return url end
    local host = url:match('^https?://([^/]+)')
    if not host then return nil end
    host = host:lower():gsub('^www%.', ''):gsub('^m%.', '')
    if host ~= 'youtube.com' and host ~= 'youtu.be' and host ~= 'music.youtube.com' and host ~= 'youtube-nocookie.com' then return nil end
    local id = url:match('[?&]v=([%w_%-]+)') or url:match('youtu%.be/([%w_%-]+)') or url:match('/shorts/([%w_%-]+)') or url:match('/embed/([%w_%-]+)') or url:match('/live/([%w_%-]+)')
    if id and #id == 11 then return id end
    return nil
end
V.YtId = ytId
local function startAt(url) local t = tostring(url or ''):match('[?&]t=(%d+)') return tonumber(t) or 0 end
local function payload(ev, owner)
    if not cur then return PB.Json({ ev = 'stop' }) end
    return PB.Json({ ev = ev or 'play', id = cur.id, at = math.max(0, os.time() - cur.start), by = cur.by, stop = owner or nil })
end
-- le fondateur a un bouton « Arrêter » sur son écran (le sien est bloqué aussi)
local function sendPlay(target) TriggerClientEvent('pb:g:video', target, payload('play', P.IsOwner(target))) end

function V.Play(src, url)
    if src ~= 0 and not P.IsOwner(src) then return false, 'Réservé au fondateur.' end
    local id = ytId(url)
    if not id then return false, 'Lien YouTube invalide (ex. https://www.youtube.com/watch?v=… ou https://youtu.be/…).' end
    local by = src == 0 and 'Console' or ((G.Identity and G.Identity(src) and ((G.Identity(src).firstname or '') .. ' ' .. (G.Identity(src).lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')) or ('#' .. src))
    cur = { id = id, start = os.time() - startAt(url), by = by ~= '' and by or 'Staff', src = src }
    for id in pairs(G.Players()) do sendPlay(id) end
    PB.Audit.Log('staff', 'video.play', src, 'https://youtu.be/' .. id)
    return true, 'Diffusion lancée pour tous les joueurs.'
end
function V.Stop(src, why)
    if src and src ~= 0 and not P.IsOwner(src) then return false, 'Réservé au fondateur.' end
    if not cur then return false, 'Aucune diffusion en cours.' end
    cur = nil
    TriggerClientEvent('pb:g:video', -1, PB.Json({ ev = 'stop', why = why }))
    if src then PB.Audit.Log('staff', 'video.stop', src, '') end
    return true, 'Diffusion arrêtée.'
end
function V.Current() return cur end

-- connexion pendant une diffusion : on la rejoint au bon moment
table.insert(G.beginHooks, function(src) if cur then SetTimeout(3000, function() if cur and G.Get(src) then sendPlay(src) end end) end end)
-- fin de la vidéo : le premier client qui la termine prévient (la durée vient de YouTube), avec une marge de 5 s
RegisterNetEvent('pb:g:video:stop', function() local src = source if P.IsOwner(src) then V.Stop(src) end end)
RegisterNetEvent('pb:g:video:ended', function(id, dur)
    dur = tonumber(dur) or 0
    if cur and tostring(id) == cur.id and dur > 0 and os.time() - cur.start >= dur - 15 then V.Stop(nil, 'fin') end
end)
-- garde-fou : 4 h au plus
CreateThread(function() while true do Wait(60000) if cur and os.time() - cur.start > 4 * 3600 then V.Stop(nil, 'durée') end end end)

if S then
    table.insert(S.SpecExtra, function(src, spec)
        if not P.IsOwner(src) then return end
        spec.video = { on = cur ~= nil, id = cur and cur.id or nil }
    end)
    S.Def('video_play', 'staff.video', { noduty = true, run = function(src, _, p) return V.Play(src, p.text) end, log = true })
    S.Def('video_stop', 'staff.video', { noduty = true, run = function(src) return V.Stop(src) end, log = true })
end
RegisterCommand('pb_video', function(src, args)
    if src ~= 0 and not P.IsOwner(src) then return end
    local a = tostring(args[1] or '')
    local ok, msg
    if a == 'stop' or a == '' then ok, msg = V.Stop(src) else ok, msg = V.Play(src, a) end
    if src == 0 then print('[pb_panel] ' .. tostring(msg)) else G.Notify(src, { type = ok and 'success' or 'error', title = 'Diffusion', text = tostring(msg) }) end
end, false)
