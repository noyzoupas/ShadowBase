-- Fumer : cigarette, vapoteuse et joint, nature ou chargés avec une drogue. Le serveur retire les objets, compte les bouffées et applique les besoins ;
-- le client fait le geste, la fumée et les effets à l'écran.
local G, DB = PB.G, PB.DB
local Sm = {}
G.Smoke = Sm

PB.Cfg.Define('smoke', { enabled = true, puffs_cigarette = 6, puffs_vape = 12, puffs_joint = 8 })
local function cfg(k, d) return PB.Cfg.Get('smoke', k, d) end
local function Inv() return G.Inv end

local ITEMS = {
    { 'cigarette', 'Cigarette', 10, 20, "Se fume nature, ou roulée avec de la drogue." },
    { 'vape', 'Vapoteuse', 150, 1, "Se recharge : nature, ou avec un pochon de drogue. Elle ne s'use pas." },
}
PB.Migrate('548_smoke_items', 'Cigarette et vapoteuse', function()
    for _, it in ipairs(ITEMS) do
        DB.exec("INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, ?, ?, 'misc', 1, ?)", { it[1], it[2], it[3], it[4], it[5] })
    end
    DB.exec("UPDATE pb_inv_items SET usable = 1 WHERE name = 'joint'")
    if G.Inv and G.Inv.Reload then G.Inv.Reload() end
end)
PB.Migrate('550_smoke_pack', 'Paquet de cigarettes', function()
    DB.exec("INSERT IGNORE INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES ('cigarettes', 'Paquet de cigarettes', 100, 10, 'misc', 1, 'Donne 10 cigarettes.')")
    DB.exec("UPDATE pb_inv_items SET usable = 1 WHERE name = 'cigarettes'")
    if G.Inv and G.Inv.Reload then G.Inv.Reload() end
end)
-- en vente seulement au bureau de tabac : retirés des supérettes où ils auraient été ajoutés
PB.Migrate('551_smoke_tabac_only', 'Cigarette et vapoteuse : bureau de tabac seulement', function()
    for _, r in ipairs(DB.q("SELECT id, catalog FROM pb_shops WHERE kind = 'store' AND (opts IS NULL OR opts NOT LIKE '%shop_smoke%')") or {}) do
        local cat, out = PB.FromJson(r.catalog, {}) or {}, {}
        for _, it in ipairs(cat) do if it.name ~= 'cigarette' and it.name ~= 'vape' then out[#out + 1] = it end end
        if #out ~= #cat then DB.exec('UPDATE pb_shops SET catalog = ? WHERE id = ?', { PB.Json(out), r.id }) end
    end
end)

-- ce qu'on peut charger : objet -> drogue
local LOAD = { weed_pouch = 'weed', weed = 'weed', coke_pouch = 'coke', meth_pouch = 'meth', ecstasy_pouch = 'ecstasy', heroin_pouch = 'heroin' }
local ORDER = { 'weed_pouch', 'weed', 'coke_pouch', 'meth_pouch', 'ecstasy_pouch', 'heroin_pouch' }
-- effet d'une bouffée sur les besoins (le reste est à l'écran : client/smoke.lua)
local PUFF = {
    nature = { stress = -3 },
    weed = { stress = -8, hunger = -2 },
    coke = { stress = -2, thirst = -2 },
    meth = { stress = 1, thirst = -3, hunger = -1 },
    ecstasy = { stress = -6, thirst = -3 },
    heroin = { stress = -6, health = 3 },
}
local DESC = { weed = 'Détente, tu as faim ensuite.', coke = 'Tu cours plus vite et plus longtemps.', meth = 'Tu cours plus vite, la vue tremble.', ecstasy = 'Couleurs, plus de stress, endurance.', heroin = 'Tu te soignes un peu, mais tu marches mal.' }

local sessions, vapeLoad, last = {}, {}, {}
AddEventHandler('playerDropped', function() local s = source sessions[s], vapeLoad[s], last[s] = nil, nil, nil end)
local function owner(src) local p = G.Get(src) return p and ('p:' .. p.license) end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function throttle(src, ms)
    local t = GetGameTimer()
    if last[src] and t - last[src] < ms then return false end
    last[src] = t
    return true
end
local function start(src, device, drug, left)
    sessions[src] = { device = device, drug = drug, left = left }
    TriggerClientEvent('pb:g:smoke:start', src, PB.Json({ device = device, drug = drug, left = left }))
end
function Sm.Puffs(device) return math.max(1, math.floor(tonumber(cfg('puffs_' .. device, 6)) or 6)) end
function Sm.Session(src) return sessions[src] end

-- Objet utilisé : on propose ce qu'on peut mettre dedans
function Sm.Offer(src, device)
    if not cfg('enabled', true) then return false, 'Désactivé.' end
    if sessions[src] then return false, 'Tu fumes déjà.' end
    if device == 'vape' and vapeLoad[src] then
        local v = vapeLoad[src]
        vapeLoad[src] = nil
        start(src, 'vape', v.drug, v.left)
        return true
    end
    local ow = owner(src)
    local opts = {}
    for _, item in ipairs(ORDER) do
        local n = Inv().Count(ow, item)
        local d = n > 0 and Inv().Def(item)
        if d then opts[#opts + 1] = { item = item, label = d.label, n = n, desc = DESC[LOAD[item]] } end
    end
    TriggerClientEvent('pb:g:smoke:menu', src, PB.Json({ device = device, label = Inv().Def(device) and Inv().Def(device).label or device, options = opts }))
    return true
end
-- Chargement : item vide = nature. La cigarette part dans tous les cas, la vapoteuse reste.
function Sm.Load(src, device, item)
    if not cfg('enabled', true) or sessions[src] then return false end
    if device ~= 'vape' and device ~= 'cigarette' then return false end
    local ow = owner(src)
    if not ow or Inv().Count(ow, device) < 1 then return false, "Tu n'as plus cet objet." end
    item = tostring(item or '')
    local drug = 'nature'
    if item ~= '' then
        drug = LOAD[item]
        if not drug then return false end
        if Inv().Count(ow, item) < 1 or not Inv().Remove(ow, item, 1) then return false, "Tu n'en as plus." end
    end
    if device == 'cigarette' and not Inv().Remove(ow, 'cigarette', 1) then return false, "Tu n'as plus de cigarette." end
    start(src, device, drug, Sm.Puffs(device))
    return true
end
function Sm.Puff(src)
    local s = sessions[src]
    if not s then return false end
    s.left = s.left - 1
    local e = PUFF[s.drug] or PUFF.nature
    for _, k in ipairs({ 'stress', 'hunger', 'thirst' }) do if e[k] then G.AddStatus(src, k, e[k]) end end
    if e.health then TriggerClientEvent('pb:g:inv:heal', src, e.health) end
    -- la fumée se voit aussi par les joueurs proches
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if c then
        for other in pairs(G.Players()) do
            if other == src or G.DistTo(other, c.x, c.y, c.z) < 60.0 then TriggerClientEvent('pb:g:smoke:fx', other, src, s.device) end
        end
    end
    TriggerClientEvent('pb:g:smoke:effect', src, s.drug)
    if s.left <= 0 then
        sessions[src] = nil
        TriggerClientEvent('pb:g:smoke:stop', src, s.device == 'vape' and 'La vapoteuse est vide.' or 'Terminé.')
    end
    return true
end
function Sm.Stop(src)
    local s = sessions[src]
    if not s then return end
    sessions[src] = nil
    if s.device == 'vape' and s.left > 0 then vapeLoad[src] = { drug = s.drug, left = s.left } end   -- rangée : elle garde sa charge
end

RegisterNetEvent('pb:g:smoke:load', function(device, item)
    local src = source
    if not usable(src) or not throttle(src, 500) then return end
    local ok, msg = Sm.Load(src, tostring(device), item)
    if not ok and msg then G.Notify(src, { type = 'error', title = 'Fumer', text = msg }) end
end)
RegisterNetEvent('pb:g:smoke:puff', function()
    local src = source
    if not usable(src) or not throttle(src, 1500) then return end
    Sm.Puff(src)
end)
RegisterNetEvent('pb:g:smoke:stopped', function() Sm.Stop(source) end)

CreateThread(function()
    while not (G.Inv and G.Inv.RegisterUsable) do Wait(200) end
    local function device(name) G.Inv.RegisterUsable(name, function(src)
        local ok, msg = Sm.Offer(src, name)
        return ok, msg, true
    end) end
    device('cigarette') device('vape')
    -- un joint est déjà roulé
    G.Inv.RegisterUsable('joint', function(src)
        if sessions[src] then return false, 'Tu fumes déjà.' end
        if not Inv().Remove(owner(src), 'joint', 1) then return false end
        start(src, 'joint', 'weed', Sm.Puffs('joint'))
        return true, nil, true
    end)
    -- un paquet donne ses cigarettes
    G.Inv.RegisterUsable('cigarettes', function(src)
        local ow = owner(src)
        if not Inv().CanCarry(ow, 'cigarette', 10) then return false, 'Fais de la place.' end
        Inv().Add(ow, 'cigarette', 10)
        return true
    end)
end)
