-- Lien Discord ↔ personnage : chaque joueur connecté avec Discord ouvert est relié à son compte. Le bot (module Discord) peut alors
-- lui donner automatiquement des rôles selon le jeu (VIP, métier, groupe illégal) et renommer son pseudo avec le nom du personnage.
-- Seuls les rôles listés ici sont gérés : les autres rôles du membre ne sont jamais touchés.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('discordlink.edit', 'Régler le lien Discord ↔ personnage (rôles automatiques)', 'discord', true)
PB.Migrate('348_discord_link', 'Lien Discord ↔ personnage', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_discord_link (license VARCHAR(80) NOT NULL, discord VARCHAR(32) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, synced INT NOT NULL DEFAULT 0, PRIMARY KEY (license), KEY k_dc (discord))]]))
end)
local REQUIRE_MSG = "Discord est obligatoire sur ce serveur.\n\n1. Ouvre l'application Discord sur ton PC (pas le site) et connecte-toi.\n2. Ferme complètement FiveM, puis relance-le avec Discord déjà ouvert.\n3. Si FiveM te le demande, autorise Discord, puis reconnecte-toi."
local MEMBER_MSG = "Tu dois être sur notre Discord pour jouer sur ce serveur.\n\nRejoins-le avec le compte Discord ouvert sur ton PC, puis reconnecte-toi."
PB.Cfg.Define('discordlink', { enabled = false, nick = false, require = true, require_msg = REQUIRE_MSG, require_member = true, member_msg = MEMBER_MSG, vip_role = '', vip_role2 = '', job_roles = {}, gang_role = '', duty_only = false })
local L = {}
G.DiscordLink = L
local function cfg(k, d) return PB.Cfg.Get('discordlink', k, d) end
local function now() return os.time() end
local function discordOf(src) for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if id:sub(1, 8) == 'discord:' then return id:sub(9) end end end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 32) end return nil end

-- rôles voulus pour ce joueur (parmi les rôles gérés)
function L.Wanted(src)
    local want, managed = {}, {}
    local function m(r) r = tostring(r or '') if r:match('^%d+$') then managed[r] = true return r end end
    local vip = m(cfg('vip_role', ''))
    local gold = m(cfg('vip_role2', ''))
    if G.Vip and G.Vip.Is(src) then if vip then want[vip] = true end if gold then want[gold] = true end end
    local c = G.Biz and G.Biz.Ctx(src)
    for _, row in ipairs(cfg('job_roles', {}) or {}) do
        local r = m(row.role)
        if r and c and c.biz.id == row.biz and (not cfg('duty_only', false) or c.duty) then want[r] = true end
    end
    local gr = m(cfg('gang_role', ''))
    if gr and G.Tags and G.Tags.Gang and G.Tags.Gang(src) then want[gr] = true end
    return want, managed
end
local lastNick = {}
function L.Sync(src)
    if cfg('enabled', false) ~= true or not PB.Discord or not PB.Discord.BotToken() then return false end
    local p = G.Get(src)
    local dc = discordOf(src)
    if not p or not dc then return false end
    local gid = PB.Cfg.Get('discord', 'guild_id', '')
    if gid == '' then return false end
    local have = PB.Discord.MemberRoles(dc)
    if not have then return false end
    local hasSet = {}
    for _, r in ipairs(have) do hasSet[tostring(r)] = true end
    local want, managed = L.Wanted(src)
    for r in pairs(managed) do
        if want[r] and not hasSet[r] then PB.Discord.Api('PUT', ('/guilds/%s/members/%s/roles/%s'):format(gid, dc, r))
        elseif not want[r] and hasSet[r] then PB.Discord.Api('DELETE', ('/guilds/%s/members/%s/roles/%s'):format(gid, dc, r)) end
    end
    if cfg('nick', false) == true then
        local n = display(src)
        if n and lastNick[dc] ~= n then lastNick[dc] = n PB.Discord.Api('PATCH', ('/guilds/%s/members/%s'):format(gid, dc), { nick = n }) end
    end
    DB.exec('UPDATE pb_discord_link SET synced = ? WHERE license = ?', { now(), p.license })
    return true
end
-- une seule synchronisation en attente par joueur (plusieurs changements rapprochés = un seul appel à Discord)
local queued = {}
local function later(src, ms)
    if queued[src] then return end
    queued[src] = true
    SetTimeout(ms or 2000, function() queued[src] = nil if G.Get(src) then pcall(L.Sync, src) end end)
end
AddEventHandler('playerDropped', function() queued[source] = nil end)
table.insert(G.beginHooks, function(src, p)
    local dc = discordOf(src)
    if dc then DB.exec('INSERT INTO pb_discord_link (license, discord, name, at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE discord = VALUES(discord), name = VALUES(name), at = VALUES(at)', { p.license, dc, display(src) or GetPlayerName(src) or '', now() }) end
    later(src, 5000)
end)
AddEventHandler('pb_panel:jobChanged', function(src) later(src) end)
AddEventHandler('pb_panel:duty', function(src) if cfg('duty_only', false) then later(src) end end)
AddEventHandler('pb_panel:vipChanged', function(src) later(src) end)
AddEventHandler('pb_panel:gangChanged', function(src) if src then later(src) end end)
-- Discord obligatoire : le refus est fait par la file d'attente (server/game/flow.lua), avant toute admission
PB.Migrate('528_discord_required', 'Connexion : Discord obligatoire', function() PB.Cfg.Set('discordlink', 'require', true, 0, 'Discord obligatoire pour se connecter', true) end)
function L.Blocked(src) return cfg('require', true) == true and not discordOf(src) end
local function withLink(msg)
    local link = tostring(PB.Cfg.Get('menus', 'discord', '') or '')
    if link ~= '' and link ~= 'discord.gg/monserveur' then msg = msg .. '\n\nNotre Discord : ' .. link end
    return msg
end
function L.RefusalText() return withLink(tostring(cfg('require_msg', REQUIRE_MSG) or '')) end
function L.NotMemberText() return withLink(tostring(cfg('member_msg', MEMBER_MSG) or '')) end

-- (v1.2.46) Être membre du serveur Discord : il faut le jeton du bot et l'identifiant du serveur (module Discord), sinon rien n'est vérifié.
function L.MemberReady()
    return PB.Discord ~= nil and PB.Discord.BotToken() ~= nil and tostring(PB.Cfg.Get('discord', 'guild_id', '')):match('^%d+$') ~= nil
end
function L.MemberAsked() return cfg('require_member', true) == true end
function L.MemberOn() return L.MemberAsked() and L.MemberReady() end
-- true : membre · false : Discord dit qu'il ne l'est pas · nil : pas de réponse claire (panne, jeton refusé, bot absent du serveur).
-- Sans réponse claire, le joueur entre : une panne de Discord ne doit pas fermer le serveur. Membre confirmé : gardé 5 min en mémoire.
local memberAt = {}
-- Demande à Discord. Renvoie true / false / nil (voir plus haut), puis le code de réponse.
function L.Ask(dc)
    local status, body
    local sent = PB.Discord.Api('GET', ('/guilds/%s/members/%s'):format(tostring(PB.Cfg.Get('discord', 'guild_id', '')), dc), nil, function(s, t) status, body = tonumber(s) or 0, t end)
    if not sent then return nil, nil end
    local limit = GetGameTimer() + 5000
    while not status and GetGameTimer() < limit do Wait(100) end
    if status == 200 then   -- (v1.2.98) rôles du membre gardés pour la file d'attente, la liste blanche et le VIP (server/game/discordroles.lua)
        local d = PB.FromJson(body or '', nil)
        if type(d) == 'table' and type(d.roles) == 'table' and G.DiscordRolesSeen then pcall(G.DiscordRolesSeen, dc, d.roles) end
        return true, status
    end
    if status == 404 then
        local d = PB.FromJson(body or '', nil)
        local code = type(d) == 'table' and tonumber(d.code) or nil
        if code == 10007 or code == 10013 then return false, status end   -- membre ou utilisateur inconnu ; 10004 = serveur introuvable, donc notre réglage
    end
    return nil, status
end
function L.IsMember(src)
    local dc = discordOf(src)
    if not dc or not dc:match('^%d+$') then return nil end
    if memberAt[dc] and now() - memberAt[dc] < 300 then return true end
    local member, status = L.Ask(dc)
    if member == true then memberAt[dc] = now() return true end
    if member == false then return false end
    print(('[pb_panel] Discord : adhésion non vérifiée (réponse %s). Vérifie le jeton du bot, l\'identifiant du serveur et que le bot est bien sur le serveur.'):format(tostring(status or 'aucune')))
    return nil
end
PB.OnReady(function()
    if cfg('require_member', true) == true and not L.MemberReady() then
        print("[pb_panel] Discord : l'adhésion obligatoire n'est PAS appliquée : renseigne le jeton du bot et l'identifiant du serveur dans le module Discord.")
    end
end)

-- Test depuis le panel : le staff n'est jamais vérifié à la connexion, c'est le seul moyen pour lui de voir le résultat
PB.Action('discordlink.test', 'discordlink.edit', function(ctx, p)
    if not L.MemberReady() then return false, "Vérification impossible : renseigne le jeton du bot et l'identifiant du serveur (module Discord)." end
    local v = p.values or p
    local dc = tostring(v.id or ''):match('^%d+$') or (ctx.src and ctx.src > 0 and discordOf(ctx.src)) or nil
    if not dc then return false, "Écris un identifiant Discord, ou ouvre le panel en jeu avec Discord lancé." end
    local member, status = L.Ask(dc)
    if member == true then ctx.toast = 'Ce compte est membre du serveur Discord : il peut se connecter.'
    elseif member == false then ctx.toast = "Ce compte n'est pas membre : il sera refusé à la connexion."
    elseif status == 401 then return false, 'Discord refuse le jeton du bot (401) : recopie-le dans le module Discord.'
    elseif status == 403 then return false, "Discord refuse l'accès (403) : le bot n'est pas sur ce serveur, ou l'identifiant du serveur est faux."
    elseif status == 404 then return false, "Serveur Discord introuvable (404) : vérifie l'identifiant du serveur et invite le bot."
    else return false, 'Pas de réponse claire de Discord (' .. tostring(status or 'aucune') .. ').' end
    return true
end)
local function statusBlocks()
    local req, mem, ready = cfg('require', true) == true, cfg('require_member', true) == true, L.MemberReady()
    local token = PB.Discord ~= nil and PB.Discord.BotToken() ~= nil
    local guild = tostring(PB.Cfg.Get('discord', 'guild_id', '')):match('^%d+$') ~= nil
    local out = {
        B.notice('warn', "Ton équipe et toi passez toujours sans vérification (grade staff, propriétaire, droit « flow.bypass »), pour ne jamais vous enfermer dehors. Tu ne verras donc jamais le refus avec ton compte : teste avec un compte sans grade, ou avec le bouton ci-dessous."),
        B.notice(req and 'info' or 'warn', 'Application Discord ouverte obligatoire : ' .. (req and 'active.' or 'désactivée.')),
    }
    if not mem then out[#out + 1] = B.notice('warn', 'Être membre du serveur Discord : désactivé.')
    elseif ready then out[#out + 1] = B.notice('info', 'Être membre du serveur Discord : active.')
    else out[#out + 1] = B.notice('warn', "Être membre du serveur Discord : activé mais PAS appliqué, tout le monde entre. Il manque : " .. (token and '' or 'le jeton du bot ') .. (guild and '' or "l'identifiant du serveur") .. ' (module Discord).') end
    out[#out + 1] = { type = 'form', id = 'discordlink.test', title = 'Tester un compte', cols = 2, desc = "Vide : ton propre compte, si tu es en jeu avec Discord ouvert.",
        fields = { { k = 'id', type = 'text', label = 'Identifiant Discord', maxlen = 24, pattern = '^%d*$' } }, values = { id = '' }, submit = { action = 'discordlink.test', label = 'Tester' } }
    return out
end
PB.Action('discordlink.syncall', 'discordlink.edit', function(ctx)
    local n = 0
    for src in pairs(G.Players()) do n = n + 1 later(src, n * 1500) end   -- étalé : pas de limite de débit Discord
    ctx.toast = n .. ' joueur(s) en cours de synchronisation (environ ' .. math.ceil(n * 1.5) .. ' s).'
    return true
end)
local form = PB.Form.Cfg({ ns = 'discordlink', id = 'settings', title = 'Rôles Discord automatiques', perm = 'discordlink.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Donner les rôles Discord selon le jeu', default = false, hint = 'Il faut le jeton du bot et l\'identifiant du serveur Discord (module Discord).' },
    { k = 'nick', type = 'toggle', label = 'Pseudo Discord = nom du personnage', default = false },
    { k = 'require', type = 'toggle', label = 'Discord obligatoire pour se connecter', default = true, hint = "Application Discord ouverte sur le PC du joueur. L'équipe du serveur et le propriétaire passent toujours, pour ne jamais se retrouver bloqué dehors." },
    { k = 'require_msg', type = 'area', label = 'Message aux joueurs refusés', default = REQUIRE_MSG, maxlen = 500, wide = true },
    { k = 'require_member', type = 'toggle', label = 'Être membre du serveur Discord pour se connecter', default = true, hint = "Il faut le jeton du bot et l'identifiant du serveur (module Discord), avec le bot sur ton serveur. Si Discord ne répond pas, le joueur entre : une panne ne ferme pas ton serveur." },
    { k = 'member_msg', type = 'area', label = 'Message aux joueurs qui ne sont pas membres', default = MEMBER_MSG, maxlen = 500, wide = true, hint = 'Le lien « Discord affiché en haut des menus » (Interface) est ajouté à la fin.' },
    { k = 'duty_only', type = 'toggle', label = 'Rôle de métier seulement en service', default = false },
    { k = 'vip_role', type = 'text', label = 'Rôle des VIP (identifiant)', default = '', maxlen = 24, pattern = '^%d*$', hint = 'Donne à ce rôle l\'accès aux salons vocaux VIP et au salon textuel VIP (enchères) dans les réglages de ton serveur Discord.' },
    { k = 'vip_role2', type = 'text', label = 'Second rôle des VIP : Gold (identifiant)', default = '', maxlen = 24, pattern = '^%d*$', hint = 'Donné et retiré en même temps que le rôle VIP.' },
    { k = 'gang_role', type = 'text', label = 'Rôle des membres de groupes illégaux (identifiant)', default = '', maxlen = 24, pattern = '^%d*$' },
    { k = 'job_roles', type = 'rows', label = 'Métier → rôle Discord', default = {}, wide = true, maxitems = 40,
      cols = { { k = 'biz', label = "Identifiant de l'entreprise", type = 'text', maxlen = 32, pattern = '^[%w_]+$' }, { k = 'role', label = 'Identifiant du rôle', type = 'text', maxlen = 24, pattern = '^%d+$' } } },
} })
PB.Module({
    id = 'discordlink', label = 'Discord ↔ personnage', icon = 'link', group = 'Système', order = 161, perm = 'discordlink.edit', hint = 'Rôles automatiques, pseudo, Discord obligatoire',
    caps = function() return PB.Capsify({
        { 'Lien compte Discord ↔ personnage', 'ok', 'Enregistré à chaque connexion (Discord ouvert sur le PC du joueur).' },
        { 'Rôles automatiques', PB.Discord and PB.Discord.BotToken() and 'ok' or 'warn', PB.Discord and PB.Discord.BotToken() and 'VIP, métier, groupe : ajoutés et retirés selon le jeu.' or 'Jeton du bot à renseigner dans le module Discord.' },
        { 'Rôles non listés', 'ok', 'Jamais touchés.' },
        { 'Adhésion au serveur Discord', cfg('require_member', true) ~= true and 'off' or (L.MemberReady() and 'ok' or 'warn'), cfg('require_member', true) ~= true and 'Désactivée.' or (L.MemberReady() and 'Connexion refusée aux non-membres (équipe exemptée).' or "PAS appliquée : renseigne le jeton du bot et l'identifiant du serveur dans le module Discord.") },
        { 'Discord obligatoire', cfg('require', true) == true and 'ok' or 'off', cfg('require', true) == true and "Connexion refusée sans l'application Discord ouverte (équipe exemptée)." or 'Désactivé : tout le monde peut se connecter.' },
    }) end,
    doc = "## Discord ↔ personnage\nLe bot doit être sur ton serveur Discord avec la permission **Gérer les rôles** (et **Gérer les pseudos** pour renommer), et son rôle placé au-dessus des rôles qu'il donne.",
    view = function(ctx)
        return { tabs = {
            { id = 'check', label = 'Vérification', icon = 'check', build = statusBlocks },
            { id = 'links', label = 'Comptes reliés', icon = 'link', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_discord_link ORDER BY at DESC LIMIT 200') or {}) do rows[#rows + 1] = { name = r.name, discord = r.discord, at = r.at, synced = r.synced > 0 and r.synced or nil } end
                return { B.actions({ { action = 'discordlink.syncall', label = 'Synchroniser les joueurs connectés', icon = 'refresh', primary = true } }),
                    B.table({ id = 'dll', title = 'Comptes reliés', search = true, columns = { { k = 'name', label = 'Personnage' }, { k = 'discord', label = 'Discord', type = 'mono' }, { k = 'at', label = 'Dernière connexion', type = 'date' }, { k = 'synced', label = 'Rôles mis à jour', type = 'date' } }, rows = rows, empty = 'Aucun compte relié.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
            { id = 'roles', label = 'Rôles → avantages', icon = 'star', build = function() return { G.DiscordRolesForm and G.DiscordRolesForm(ctx) or PB.B.notice('info', 'Indisponible.') } end },
        } }
    end,
})
