-- EMS : réanimation avec animation (massage cardiaque), puis choix de la personne à qui envoyer la facture (comme les autres menus
-- de sélection : les personnes autour sont mises en surbrillance). Soins (F6) : même principe, plus court.
-- Médecin (PNJ posé au Builder) : soins complets payants, chers exprès, pour ne pas remplacer les EMS.

local G, DB = PB.G, PB.DB
local Biz, Q = G.Biz, G.Quick
local E = {}
G.Ems = E

PB.Cfg.Define('ems', { auto_bill = true, revive_secs = 8, revive_price = 500, heal_secs = 4, heal_price = 150, doctor_price = 2500, doctor_secs = 10, doctors = {} })
local function cfg(k, d) return PB.Cfg.Get('ems', k, d) end
local function display(src) return Biz and Biz.Display and Biz.Display(src) or ('Personne #' .. tostring(src)) end
local function money(n) return PB.Money(n) end
-- prix payés au serveur (médecin) : multiplicateur et TVA de l'onglet Économie ; factures EMS : montant réglé tel quel
local function price(n) return (G.Eco and G.Eco.Final) and G.Eco.Final(n) or math.floor(tonumber(n) or 0) end

-- personnes autour du soignant pour la facture (le patient en premier)
local function nearList(src, first)
    local out = {}
    if first and G.Get(first) then out[1] = { id = first, name = display(first) .. ' (patient)' } end
    for id, pl in pairs(G.Players()) do
        if id ~= src and id ~= first and PB.ToBool(pl.row.created) and G.DistBetween(src, id) <= 10 then out[#out + 1] = { id = id, name = display(id) } end
    end
    return out
end
-- facture préparée par le serveur (montant fixe) : le client choisit seulement la personne
local pendingBill = {}
local function offerBill(src, patient, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount < 1 then return end
    -- (v1.2.99) facture automatique : envoyée tout de suite au patient (il la paie à l'écran ou plus tard, téléphone › Factures)
    if cfg('auto_bill', true) ~= false and patient and G.Get(patient) then
        local c = Biz and Biz.Ctx(src)
        if c and Biz.ACT and Biz.ACT.invoice then
            local ok, msg = Biz.ACT.invoice(c, src, { id = patient, amount = amount, reason = reason })
            if ok then G.Notify(src, { type = 'success', title = c.biz.label, text = ('Facture de %s envoyée à %s (%s).'):format(money(amount), display(patient), reason) }) return end
            if msg then G.Notify(src, { type = 'warn', title = c.biz.label, text = tostring(msg) .. ' Choisis à qui l\'envoyer.' }) end
        end
    end
    pendingBill[src] = { amount = amount, reason = reason, untilT = os.time() + 120 }
    TriggerClientEvent('pb:g:ems:bill', src, PB.Json({ amount = amount, reason = reason, near = nearList(src, patient) }))
end
RegisterNetEvent('pb:g:ems:bill', function(tid)
    local src = source
    local b = pendingBill[src]
    pendingBill[src] = nil
    if not b or b.untilT < os.time() then return end
    local c = Biz and Biz.Ctx(src)
    if not c or not Biz.ACT or not Biz.ACT.invoice then return end
    local ok, msg = Biz.ACT.invoice(c, src, { id = tonumber(tid), amount = b.amount, reason = b.reason })
    if msg then G.Notify(src, { type = ok and 'success' or 'error', title = c.biz.label, text = msg }) end
end)

-- Réanimation : animation pendant quelques secondes (rester à côté), puis la personne se relève ; ensuite la facture
local busy = {}
function E.Revive(c, src, p)
    if not Biz.Allowed(c, 'revive') then return false, "Tu n'as pas le droit de réanimer." end
    if not c.duty then return false, 'Prends ton service pour intervenir.' end
    local tp, err, tid = Biz.Target(src, p.id)
    if not tp then return false, err end
    if not PB.ToBool(tp.row.dead) then return false, "Cette personne n'a pas besoin de réanimation." end
    if busy[src] then return false, 'Tu es déjà en train de soigner quelqu\'un.' end
    local secs = math.max(3, math.min(30, math.floor(tonumber(cfg('revive_secs', 8)) or 8)))
    busy[src] = tid
    TriggerClientEvent('pb:g:ems:anim', src, PB.Json({ kind = 'cpr', secs = secs, target = tid }))
    SetTimeout(secs * 1000, function()
        busy[src] = nil
        local tp2 = G.Get(tid)
        if not G.Get(src) or not tp2 then return end
        if not PB.ToBool(tp2.row.dead) then return end
        if G.DistBetween(src, tid) > 4.0 then G.Notify(src, { type = 'error', title = c.biz.label, text = 'Tu t\'es éloigné(e) : réanimation interrompue.' }) return end
        G.Revive(tid)
        if Biz.Record then Biz.Record(c, tp2.license, display(tid), 'care', 'Réanimation', 0) end
        G.Notify(tid, { type = 'success', title = c.biz.label, text = 'Tu as été réanimé(e) par ' .. display(src) .. '.' })
        G.Notify(src, { type = 'success', title = c.biz.label, text = display(tid) .. ' est réanimé(e).' })
        TriggerEvent('pb_panel:revivedBy', src, tid)
        offerBill(src, tid, cfg('revive_price', 500), 'Réanimation')
    end)
    return true, 'Réanimation en cours… reste à côté (' .. secs .. ' s).'
end
local lastHeal = {}
function E.Heal(src, c, p)
    if not c or not c.duty or not Biz.Allowed(c, 'revive') then return false, 'Réservé aux soignants en service.' end
    local tp, err, tid = Biz.Target(src, p.id)
    if not tp then return false, err end
    if PB.ToBool(tp.row.dead) then return false, 'Cette personne est inconsciente : utilise « Réanimer ».' end
    if lastHeal[tid] and os.time() - lastHeal[tid] < 20 then return false, ('Cette personne vient d\'être soignée (%d s).'):format(20 - (os.time() - lastHeal[tid])) end
    if busy[src] then return false, 'Tu es déjà en train de soigner quelqu\'un.' end
    lastHeal[tid] = os.time()
    local secs = math.max(2, math.min(20, math.floor(tonumber(cfg('heal_secs', 4)) or 4)))
    busy[src] = tid
    TriggerClientEvent('pb:g:ems:anim', src, PB.Json({ kind = 'heal', secs = secs, target = tid }))
    SetTimeout(secs * 1000, function()
        busy[src] = nil
        if not G.Get(src) or not G.Get(tid) or G.DistBetween(src, tid) > 4.0 then return end
        TriggerClientEvent('pb:g:staff:fx', tid, 'heal', PB.Json({}))
        if Biz.Record then Biz.Record(c, G.Get(tid).license, display(tid), 'care', 'Soins', 0) end
        G.Notify(tid, { type = 'success', title = c.biz.label, text = 'Tu as été soigné(e) par ' .. display(src) .. '.' })
        offerBill(src, tid, cfg('heal_price', 150), 'Soins')
    end)
    return true, 'Soins en cours… (' .. secs .. ' s).'
end
-- on remplace la réanimation et les soins immédiats du menu F6
if Biz and Biz.ACT then Biz.ACT.revive = function(c, src, p) return E.Revive(c, src, p) end end
if Q and Q.Handlers then Q.Handlers.biz_heal = function(src, c, p) return E.Heal(src, c, p) end end
AddEventHandler('playerDropped', function() local s = source busy[s] = nil pendingBill[s] = nil lastHeal[s] = nil end)

-- Médecin (PNJ) : soins complets payants -------------------------------------------------------------------------------------------
local function doctors() return cfg('doctors', {}) or {} end
local function pushDoctors(target)
    local list = {}
    for _, d in ipairs(doctors()) do list[#list + 1] = { id = d.id, label = d.label, x = d.x, y = d.y, z = d.z, h = d.h } end
    TriggerClientEvent('pb:g:ems:doctors', target or -1, PB.Json({ list = list, price = price(cfg('doctor_price', 2500)) }))
end
E.PushDoctors = pushDoctors
table.insert(G.beginHooks, function(src) pushDoctors(src) end)
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == 'ems' then pushDoctors() end end)
local docLast = {}
RegisterNetEvent('pb:g:ems:doctor', function(id)
    local src = source
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) then return end
    local t = os.time()
    if docLast[src] and t - docLast[src] < 15 then return end
    local d
    for _, x in ipairs(doctors()) do if tostring(x.id) == tostring(id) then d = x end end
    if not d or G.DistTo(src, d.x, d.y, d.z) > 4.0 then return end
    docLast[src] = t
    local price = price(cfg('doctor_price', 2500))
    local acc = G.Pay(src, price, 'bank')
    if not acc then G.Notify(src, { type = 'error', title = d.label, text = ('Les soins coûtent %s.'):format(money(price)) }) return end
    if G.Eco and G.Eco.Book then G.Eco.Book('state', price, 'Soins médecin', p.license) end
    local secs = math.max(3, math.min(60, math.floor(tonumber(cfg('doctor_secs', 10)) or 10)))
    TriggerClientEvent('pb:g:ems:doctorfx', src, secs)
    SetTimeout(secs * 1000, function()
        if not G.Get(src) then return end
        G.Revive(src)
        G.AddStatus(src, 'stress', -100)
        TriggerClientEvent('pb:g:staff:fx', src, 'heal', PB.Json({}))
        G.Notify(src, { type = 'success', title = d.label, text = ('Tu es entièrement soigné(e) (%s).'):format(money(price)) })
    end)
end)
AddEventHandler('playerDropped', function() docLast[source] = nil end)

PB.Place.Register({ id = 'ems_doctor', label = 'Médecin : soins complets payants (PNJ)', group = 'Commerces', icon = 'heart',
    create = function(pos, name)
        local list = {}
        for _, r in ipairs(doctors()) do list[#list + 1] = r end
        list[#list + 1] = { id = 'doc_' .. tostring(os.time() % 1000000) .. math.random(10, 99), label = (tostring(name or '') ~= '' and tostring(name) or 'Médecin'):sub(1, 40),
            x = pos.x + 0.0, y = pos.y + 0.0, z = pos.z + 0.0, h = (pos.h or 0) + 0.0 }
        PB.Cfg.Set('ems', 'doctors', list, 0, 'Médecin : ' .. tostring(name))
        pushDoctors()
        return true, ('Médecin posé ici : soins complets pour %s (réglable : Entreprises › EMS).'):format(money(cfg('doctor_price', 2500)))
    end,
    list = function() local out = {} for _, r in ipairs(doctors()) do out[#out + 1] = { id = r.id, label = r.label, x = r.x, y = r.y, z = r.z } end return out end,
    remove = function(rid)
        local out, found = {}, false
        for _, r in ipairs(doctors()) do if tostring(r.id) ~= tostring(rid) then out[#out + 1] = r else found = true end end
        if not found then return false end
        PB.Cfg.Set('ems', 'doctors', out, 0, 'Médecin supprimé')
        pushDoctors()
        return true
    end })

G.EmsForm = PB.Form.Cfg({ ns = 'ems', id = 'settings', title = 'Soins et réanimation', perm = 'biz.edit', cols = 2, fields = {
    { k = 'revive_secs', type = 'number', label = 'Durée de la réanimation (s)', default = 8, min = 3, max = 30 },
    { k = 'auto_bill', type = 'toggle', label = 'Facture envoyée tout de suite au patient (sinon : choisir la personne)', default = true },
    { k = 'revive_price', type = 'number', label = 'Facture d\'une réanimation', default = 500, min = 0, max = 100000 },
    { k = 'heal_secs', type = 'number', label = 'Durée des soins (s)', default = 4, min = 2, max = 20 },
    { k = 'heal_price', type = 'number', label = 'Facture des soins', default = 150, min = 0, max = 100000 },
    { k = 'doctor_price', type = 'number', label = 'Médecin (PNJ) : prix des soins complets', default = 2500, min = 0, max = 1000000, hint = 'Volontairement cher : les EMS restent la vraie solution.' },
    { k = 'doctor_secs', type = 'number', label = 'Médecin (PNJ) : durée des soins (s)', default = 10, min = 3, max = 60 },
} })

PB.SelfTest.Add('ems', function(R)
    R.check(Biz and Biz.ACT and Biz.ACT.invoice ~= nil, 'EMS : facture', 'biz.lua doit être chargé avant ems.lua')
    R.check(Q and Q.Handlers ~= nil, 'EMS : menu F6', 'bizmenu.lua doit être chargé avant ems.lua')
end)
