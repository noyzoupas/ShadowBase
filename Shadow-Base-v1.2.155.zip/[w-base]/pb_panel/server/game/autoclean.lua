-- (v1.2.98) Nettoyage automatique :
--   · Véhicules vides sans propriétaire (sortis par le staff, véhicules de mission, épaves) : retirés quand personne n'y est monté
--     depuis X minutes et qu'aucun joueur n'est tout près. Annonce aux joueurs avant (réglable). Les véhicules des joueurs, d'entreprise
--     ou de gang ne sont jamais touchés ici : ils partent à la fourrière (server/game/coherence.lua), avec un SMS au propriétaire.
--     Les locations en cours non plus. Un script peut protéger un véhicule : Entity(veh).state.pbKeep = true.
--   · Base de données : vieux messages de reports, expulsions, empreintes de comptes, services du staff, historique des notes.
-- Panel › Nettoyage automatique : réglages, dernier passage et « Nettoyer maintenant ».
local G, P, DB = PB.G, PB.Perm, PB.DB
PB.Cfg.Define('autoclean', { veh_on = true, veh_idle_min = 30, veh_near_m = 60, veh_announce = true, db_on = true, db_days = 90 })
local function cfg(k, d) return PB.Cfg.Get('autoclean', k, d) end
local C = { last = nil, lastDb = nil }
G.AutoClean = C
local idle = {}   -- entité -> dernière fois occupée (os.time)

local function playerNear(c, r)
    for src in pairs(G.Players()) do
        local ped = GetPlayerPed(src)
        if ped and ped ~= 0 then local p = GetEntityCoords(ped) if p and ((p.x - c.x) ^ 2 + (p.y - c.y) ^ 2 + (p.z - c.z) ^ 2) < r * r then return true end end
    end
    return false
end
local function occupied(veh)
    for seat = -1, 8 do local ped = GetPedInVehicleSeat(veh, seat) if ped and ped ~= 0 then return true end end
    return false
end
local function trim(p) return (tostring(p or ''):gsub('^%s+', ''):gsub('%s+$', '')) end

-- candidats : vides, sans propriétaire, inutilisés depuis assez longtemps, personne autour
function C.Candidates()
    local t = os.time()
    local limit = math.max(5, tonumber(cfg('veh_idle_min', 30)) or 30) * 60
    local near = math.max(0, tonumber(cfg('veh_near_m', 60)) or 60)
    local seen, list, plates = {}, {}, {}
    for _, veh in ipairs(GetAllVehicles() or {}) do
        if DoesEntityExist(veh) then
            seen[veh] = true
            if occupied(veh) then idle[veh] = t
            else
                idle[veh] = idle[veh] or t
                local keep = false
                pcall(function() keep = Entity(veh).state.pbKeep == true end)
                local pop = GetEntityPopulationType and GetEntityPopulationType(veh) or 7
                if not keep and pop == 7 and t - idle[veh] >= limit then
                    local plate = trim(GetVehicleNumberPlateText(veh))
                    if not plate:match('^LOC%d+$') and not plate:match('^VIP%d+$') then
                        list[#list + 1] = { veh = veh, plate = plate }
                        if plate ~= '' then plates[#plates + 1] = plate end
                    end
                end
            end
        end
    end
    for e in pairs(idle) do if not seen[e] then idle[e] = nil end end
    -- véhicules possédés (joueur, entreprise, gang) : jamais ici
    local owned = {}
    for i = 1, #plates, 50 do
        local chunk, q = {}, {}
        for j = i, math.min(#plates, i + 49) do chunk[#chunk + 1] = plates[j] q[#q + 1] = '?' end
        for _, r in ipairs(DB.q('SELECT plate FROM pb_vehicles WHERE plate IN (' .. table.concat(q, ',') .. ')', chunk) or {}) do owned[trim(r.plate)] = true end
    end
    local out = {}
    for _, c in ipairs(list) do
        if not owned[c.plate] then
            local pos = GetEntityCoords(c.veh)
            if near == 0 or not playerNear(pos, near) then out[#out + 1] = c end
        end
    end
    return out
end

function C.Vehicles(by)
    local n = 0
    for _, c in ipairs(C.Candidates()) do
        if DoesEntityExist(c.veh) and not occupied(c.veh) then DeleteEntity(c.veh) idle[c.veh] = nil n = n + 1 end
    end
    C.last = { at = os.time(), n = n, by = by or 'automatique' }
    if n > 0 then PB.Audit.Log('serveur', 'nettoyage.vehicules', by or 'automatique', tostring(n)) end
    return n
end

-- tables qui grossissent : on garde db_days jours (90 par défaut). Jamais les sanctions, les véhicules, l'argent ni les inventaires.
local PRUNE = {
    { 'pb_report_msgs', 'DELETE FROM pb_report_msgs WHERE at < ?' },
    { 'pb_reports', "DELETE FROM pb_reports WHERE status = 'closed' AND closed_at > 0 AND closed_at < ?" },
    { 'pb_kicks', 'DELETE FROM pb_kicks WHERE at < ?' },
    { 'pb_idents', 'DELETE FROM pb_idents WHERE last < ?', 3 },   -- empreintes : 3 fois plus longtemps (anti-contournement de ban)
    { 'pb_staff_duty', 'DELETE FROM pb_staff_duty WHERE stop > 0 AND stop < ?', 2 },
    { 'pb_report_claims', 'DELETE FROM pb_report_claims WHERE at < ?', 2 },
    { 'pb_report_ratings', 'DELETE FROM pb_report_ratings WHERE at < ?', 2 },
}
function C.Database(by)
    local days = math.max(7, tonumber(cfg('db_days', 90)) or 90)
    local total, detail = 0, {}
    for _, x in ipairs(PRUNE) do
        local ok, n = pcall(DB.exec, x[2], { os.time() - days * (x[3] or 1) * 86400 })
        n = ok and (tonumber(n) or 0) or 0
        if n > 0 then total = total + n detail[#detail + 1] = x[1] .. ' : ' .. n end
    end
    C.lastDb = { at = os.time(), n = total, detail = table.concat(detail, ', '), by = by or 'automatique' }
    if total > 0 then PB.Audit.Log('serveur', 'nettoyage.base', by or 'automatique', tostring(total), nil, nil, { detail = C.lastDb.detail }) end
    return total
end

local function announce(text)
    if G.Announce and G.Announce.Send then pcall(G.Announce.Send, { title = 'Nettoyage', text = text, style = 'info', secs = 8, sound = false })
    else for src in pairs(G.Players()) do G.Notify(src, { type = 'info', title = 'Nettoyage', text = text }) end end
end
CreateThread(function()
    while not PB.IsReady do Wait(1000) end
    Wait(math.random(60000, 180000))
    local lastDbDay
    while true do
        local ok, err = pcall(function()
            if cfg('veh_on', true) ~= false and #C.Candidates() > 0 then
                if cfg('veh_announce', true) ~= false then announce('Les véhicules abandonnés sans propriétaire seront retirés dans 60 secondes. Monte dans le tien pour le garder.') Wait(60000) end
                local n = C.Vehicles()
                if n > 0 and cfg('veh_announce', true) ~= false then announce(n .. ' véhicule(s) abandonné(s) retiré(s).') end
            end
            local day = os.date('%Y%m%d')
            if cfg('db_on', true) ~= false and lastDbDay ~= day and tonumber(os.date('%H')) == 5 then lastDbDay = day C.Database() end
        end)
        if not ok then PB.Warn('autoclean', tostring(err)) end
        Wait(5 * 60000)
    end
end)

P.Register('autoclean.run', 'Lancer le nettoyage automatique à la main', 'serveur')
PB.Action('autoclean.veh', 'autoclean.run', function(ctx) local n = C.Vehicles(ctx.actor) ctx.toast = n .. ' véhicule(s) retiré(s).' return true end, { rate = 4 })
PB.Action('autoclean.db', 'autoclean.run', function(ctx) local n = C.Database(ctx.actor) ctx.toast = n .. ' ligne(s) ancienne(s) supprimée(s).' return true end, { rate = 2, critical = true, confirm = { title = 'Nettoyer la base ?', text = 'Les vieux messages de reports, expulsions et journaux du staff plus anciens que la durée réglée sont supprimés. Jamais les sanctions, véhicules, argent ou inventaires.' } })
local form = PB.Form.Cfg({ ns = 'autoclean', id = 'settings', title = 'Nettoyage automatique', perm = 'autoclean.run', cols = 2, fields = {
    { k = 'veh_on', type = 'toggle', label = 'Retirer les véhicules abandonnés sans propriétaire', default = true },
    { k = 'veh_idle_min', type = 'number', label = 'Inutilisé depuis (minutes)', default = 30, min = 5, max = 600 },
    { k = 'veh_near_m', type = 'number', label = 'Pas de joueur à moins de (mètres)', default = 60, min = 0, max = 500 },
    { k = 'veh_announce', type = 'toggle', label = 'Prévenir les joueurs 60 s avant', default = true },
    { k = 'db_on', type = 'toggle', label = 'Nettoyer la base chaque nuit (5 h)', default = true },
    { k = 'db_days', type = 'number', label = 'Garder (jours)', default = 90, min = 7, max = 3650 },
} })
PB.Module({
    id = 'autoclean', label = 'Nettoyage automatique', icon = 'trash', group = 'Serveur', order = 146, perm = 'autoclean.run', hint = 'Véhicules abandonnés, vieilles données',
    view = function(ctx)
        return { tabs = { { id = 'main', label = 'Nettoyage', icon = 'trash', build = function()
            local cand = #C.Candidates()
            return {
                PB.B.stats({ { label = 'Véhicules à retirer maintenant', value = cand, icon = 'car' },
                    { label = 'Dernier passage (véhicules)', value = C.last and (os.date('%d/%m %H:%M', C.last.at) .. ' · ' .. C.last.n) or 'jamais', icon = 'clock' },
                    { label = 'Dernier passage (base)', value = C.lastDb and (os.date('%d/%m %H:%M', C.lastDb.at) .. ' · ' .. C.lastDb.n) or 'jamais', icon = 'database' } }),
                PB.B.actions({ { action = 'autoclean.veh', label = 'Retirer les véhicules abandonnés maintenant', icon = 'car' }, { action = 'autoclean.db', label = 'Nettoyer la base maintenant', icon = 'database' } }),
                PB.B.notice('info', "Jamais touchés : les véhicules des joueurs, entreprises et gangs (fourrière automatique à la place), les locations, les véhicules occupés, et ceux marqués Entity(veh).state.pbKeep = true par un script."),
                form(ctx),
            }
        end } } }
    end,
})
