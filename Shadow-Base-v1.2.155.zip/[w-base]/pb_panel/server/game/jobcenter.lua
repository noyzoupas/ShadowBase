-- (v1.2.78) Pôle emploi : un PNJ posé au Builder (F10 › Builder › Créer › Services publics › Pôle emploi).
-- E devant lui : la liste des emplois SANS métier (bûcheron, minage, chasse, pêche, activités libres) avec leur description,
-- et les entreprises qui recrutent. Choisir un emploi pose le GPS sur le guide le plus proche (là où l'on récupère l'outil).
-- Les emplois viennent des extensions installées (wb_bucheron, wb_minage, wb_chasse, wb_peche, wb_activites) : rien n'est dupliqué.

local G, DB = PB.G, PB.DB
local Place = PB.Place
local JC = {}
G.JobCenter = JC

PB.Cfg.Define('jobcenter', { enabled = true, points = {}, ped = 'a_f_y_business_02', show_hiring = true, blip = true })
local function cfg(k, d) return PB.Cfg.Get('jobcenter', k, d) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):sub(1, n)) end

-- Emplois libres : ressource, libellé, description, icône, type du point « guide » dans ses points posés
JC.JOBS = {
    { id = 'bucheron', res = 'wb_bucheron', label = 'Bûcheron', icon = 'leaf', guide = 'shop', who = 'Chef de chantier forestier',
      desc = "Le chef de chantier te prête une hache. Coupe des arbres dans les zones de coupe et revends le bois à la scierie." },
    { id = 'minage', res = 'wb_minage', label = 'Mineur', icon = 'tool', guide = 'shop', who = 'Chef de mine',
      desc = "Le chef de mine te prête une pioche. Extrais pierre, charbon, fer, or ou diamant et revends-les au comptoir des minerais." },
    { id = 'chasse', res = 'wb_chasse', label = 'Chasseur', icon = 'crosshair', guide = 'shop', who = 'Guide de chasse',
      desc = "Le guide te prête un fusil de chasse et un couteau. Chasse le gibier, dépèce-le et revends viande et peaux au marché." },
    { id = 'peche', res = 'wb_peche', label = 'Pêcheur', icon = 'drop', guide = 'shop', who = 'Magasin de pêche',
      desc = "Achète une canne et des appâts, pêche face à l'eau ou en bateau, puis revends tes prises au marché aux poissons." },
    { id = 'activites', res = 'wb_activites', label = 'Activités libres', icon = 'leaf', guide = nil, who = "Point d'activité",
      desc = "Récolte (champs, vignes, vergers), cueillette, décharge, transformation et revente : ouvert à tous, sans métier." },
}

local function started(res) return GetResourceState and GetResourceState(res) == 'started' end
local function spotsOf(res) local s = PB.Cfg.Get(res, 'spots', {}) return type(s) == 'table' and s or {} end
local function d2(a, x, y) return math.sqrt(((tonumber(a.x) or 0) - x) ^ 2 + ((tonumber(a.y) or 0) - y) ^ 2) end

-- point le plus proche pour un emploi (guide d'abord, sinon n'importe quel point de l'extension)
function JC.Nearest(job, x, y)
    local best, bd
    for _, s in ipairs(spotsOf(job.res)) do
        if type(s) == 'table' and tonumber(s.x) and (not job.guide or s.kind == job.guide) then
            local d = d2(s, x, y)
            if not bd or d < bd then best, bd = s, d end
        end
    end
    return best, bd
end

function JC.List(src)
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped) or { x = 0.0, y = 0.0 }
    local out = {}
    for _, j in ipairs(JC.JOBS) do
        if started(j.res) then
            local s, d = JC.Nearest(j, c.x, c.y)
            out[#out + 1] = { id = j.id, label = j.label, icon = j.icon, desc = j.desc, who = j.who, ok = s ~= nil, dist = d and math.floor(d) or nil }
        end
    end
    local hiring = {}
    if cfg('show_hiring', true) ~= false and G.Biz then
        for _, b in ipairs(G.Biz.List()) do
            if PB.ToBool(b.hiring) and PB.ToBool(b.enabled) then hiring[#hiring + 1] = { id = b.id, label = b.label, ok = tonumber(b.hx) ~= nil } end
        end
    end
    return { jobs = out, hiring = hiring }
end

local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)
local function near(src, id)
    for _, p in ipairs(cfg('points', {}) or {}) do
        if tostring(p.id) == tostring(id) and G.DistTo(src, p.x, p.y, p.z) <= 6.0 then return p end
    end
end
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) end

RegisterNetEvent('pb:g:jobc:open', function(id)
    local src = source
    if cfg('enabled', true) == false or not usable(src) or not throttle(src, 600) or not near(src, id) then return end
    TriggerClientEvent('pb:g:jobc:menu', src, PB.Json(JC.List(src)))
end)
RegisterNetEvent('pb:g:jobc:pick', function(kind, id)
    local src = source
    if not usable(src) or not throttle(src, 600) then return end
    local x, y, label
    if kind == 'biz' then
        local b = G.Biz and G.Biz.Get(tostring(id))
        if not b or not PB.ToBool(b.hiring) or not tonumber(b.hx) then G.Notify(src, { type = 'error', title = 'Pôle emploi', text = "Cette entreprise n'a pas d'adresse." }) return end
        x, y, label = tonumber(b.hx), tonumber(b.hy), b.label
        G.Notify(src, { type = 'success', title = 'Pôle emploi', text = ('%s recrute : son siège est sur ta carte. Présente-toi au patron.'):format(b.label) })
    else
        local job
        for _, j in ipairs(JC.JOBS) do if j.id == tostring(id) then job = j end end
        if not job or not started(job.res) then return end
        local c = GetEntityCoords(GetPlayerPed(src))
        local s = JC.Nearest(job, c.x, c.y)
        if not s then G.Notify(src, { type = 'warn', title = 'Pôle emploi', text = job.label .. " : pas encore de point sur le serveur (le staff doit le poser au Builder)." }) return end
        x, y, label = tonumber(s.x), tonumber(s.y), s.label or job.who
        G.Notify(src, { type = 'success', title = 'Pôle emploi', text = ('%s : va voir « %s », il est sur ta carte.'):format(job.label, tostring(label)) })
    end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = x, y = y, label = label }))
end)

-- Builder ----------------------------------------------------------------------------------------------------------------------------------
local function uid() return ('jc_%d%d'):format(os.time() % 1000000, math.random(100, 999)) end
Place.Register({ id = 'jobcenter', label = 'Pôle emploi (PNJ : emplois sans métier)', group = 'Services publics', icon = 'briefcase',
    create = function(pos, name)
        local pts = cfg('points', {}) or {}
        pts[#pts + 1] = { id = uid(), label = clean(name ~= '' and name or 'Pôle emploi', 40), x = pos.x + 0.0, y = pos.y + 0.0, z = pos.z + 0.0, h = (pos.h or 0) + 0.0 }
        PB.Cfg.Set('jobcenter', 'points', pts, nil, 'Builder : pôle emploi')
        return true, 'Pôle emploi posé : le PNJ se tient ici, tourné comme toi.'
    end,
    list = function() local out = {} for _, p in ipairs(cfg('points', {}) or {}) do out[#out + 1] = { id = p.id, label = p.label, x = p.x, y = p.y, z = p.z } end return out end,
    remove = function(rid)
        local pts, keep = cfg('points', {}) or {}, {}
        for _, p in ipairs(pts) do if tostring(p.id) ~= tostring(rid) then keep[#keep + 1] = p end end
        PB.Cfg.Set('jobcenter', 'points', keep, nil, 'Builder : pôle emploi supprimé')
        return true
    end })

-- envoyé aux clients avec la configuration du jeu
local prevCfg = G.ClientConfig
G.ClientConfig = function()
    local c = prevCfg()
    c.jobcenter = { enabled = cfg('enabled', true) ~= false, ped = tostring(cfg('ped', 'a_f_y_business_02')), blip = cfg('blip', true) ~= false, points = cfg('points', {}) or {} }
    return c
end
PB.Cfg.OnChange('jobcenter', function() G.PushConfig() end)

G.JobCenterForm = PB.Form.Cfg({ ns = 'jobcenter', id = 'settings', title = 'Pôle emploi', perm = 'carte.place', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Pôle emploi actif', default = true },
    { k = 'blip', type = 'toggle', label = 'Repère sur la carte', default = true },
    { k = 'show_hiring', type = 'toggle', label = 'Afficher les entreprises qui recrutent', default = true },
    { k = 'ped', type = 'text', label = 'Modèle du PNJ', default = 'a_f_y_business_02', maxlen = 40 },
} })
