-- Tablette de l'entreprise : une page propre à son métier (comme le panneau d'une vraie entreprise).
-- Concession : ventes, catalogue et prix, promotion, vitrine. Boîte de nuit / bar / DJ : soirées, happy hour, musique des platines, carte du bar.
-- Café et restauration : menu du jour, happy hour, stock et réapprovisionnement du comptoir, carte. Commerce : stock, prix, promotion.
-- Partout : ouvrir / fermer l'établissement, annonce publique, chiffre d'affaires et dernières ventes (lus dans les comptes de l'économie).
-- Les essais et les ventes de véhicules restent en ville (ALT sur le client à la concession) : la tablette les suit et règle la boutique.

local G, DB = PB.G, PB.DB
local Biz, Q = G.Biz, G.Quick
local A = { party = {}, special = {} }
G.BizActivity = A

PB.Cfg.Define('bizactivity', { enabled = true, party_min = 30, party_max = 360, hh_max_pct = 50, hh_max_min = 120, music_radius = 150 })
local function cfg(k, d) return PB.Cfg.Get('bizactivity', k, d) end
local function now() return os.time() end
local function money(n) return PB.Money(n) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):gsub('%s+', ' '):gsub('^ ', ''):sub(1, n)) end
local function int(v, lo, hi, d) v = math.floor(tonumber(v) or d or 0) return math.max(lo, math.min(hi, v)) end
local function everyone(n) for s in pairs(G.Players()) do G.Notify(s, n) end end
local function display(src) return Biz.Display and Biz.Display(src) or ('#' .. tostring(src)) end

-- Métier de l'entreprise -----------------------------------------------------------------------------------------------------------------
local KIND = { cardealer = 'dealer', luxurycars = 'dealer', bikes = 'dealer',
    nightclub = 'club', galaxy = 'club', bahamas = 'club', unicorn = 'club', tequilala = 'club', pub = 'club', nightcover = 'club', motorclub = 'club',
    cafe = 'cafe', bean = 'cafe', bakery = 'cafe', icecream = 'cafe', casino = 'casino' }
local PROFILE = {
    casino = { label = 'Salle de jeux', icon = 'star' }, dealer = { label = 'Concession', icon = 'engine' }, club = { label = 'Soirées et bar', icon = 'star' }, cafe = { label = 'Comptoir', icon = 'food' },
    resto = { label = 'Service', icon = 'food' }, shop = { label = 'Boutique', icon = 'bag' } }
function A.Profile(c)
    if not c then return nil end
    local C = G.BizCat
    local k = C and C.ModelKey and C.ModelKey(c.biz) or nil
    if KIND[k or ''] then return KIND[k] end
    if G.BizShops and #G.BizShops(c.biz.id, 'dealer') > 0 then return 'dealer' end
    local m = C and C.ModelOf and C.ModelOf(c.biz) or nil
    if m and m.cat == 'resto' then return 'resto' end
    if (m and m.cat == 'commerce') or (G.BizShops and #G.BizShops(c.biz.id, 'store') > 0) then return 'shop' end
    return nil
end
local function manager(c) return c.boss or Biz.Can(c, 'vault') or Biz.Can(c, 'hire') end

-- Ventes : lignes « Vente … » créditées sur le compte de l'entreprise
local function sales(bizId, since, limit)
    return DB.q("SELECT at, delta, reason FROM pb_ledger WHERE account = ? AND delta > 0 AND reason LIKE 'Vente %' AND at >= ? ORDER BY id DESC LIMIT ?",
        { 'biz:' .. bizId, since, limit or 200 }) or {}
end
local function salesSum(rows, since) local n, s = 0, 0 for _, r in ipairs(rows) do if (tonumber(r.at) or 0) >= since then n = n + 1 s = s + (tonumber(r.delta) or 0) end end return s, n end
local function what(reason, label) local w = tostring(reason or ''):gsub('^Vente ', '') if label then w = w:gsub('^' .. label:gsub('%p', '%%%0') .. ' · ', '') end return w end
local function todayStart() local t = os.date('*t') t.hour, t.min, t.sec = 0, 0, 0 return os.time(t) end

-- Lieux de l'entreprise (points posés au Builder) : GPS et platines à proximité
local function places(bizId)
    return DB.q("SELECT id, x, y, z, label, kind FROM pb_points WHERE owner_kind = 'biz' AND owner = ?", { bizId }) or {}
end
local function nearBiz(bizId, x, y, shops)
    local r2 = (tonumber(cfg('music_radius', 150)) or 150) ^ 2
    for _, p in ipairs(places(bizId)) do if (p.x - x) ^ 2 + (p.y - y) ^ 2 <= r2 then return true end end
    for _, s in ipairs(shops or {}) do if (s.x - x) ^ 2 + (s.y - y) ^ 2 <= r2 then return true end end
    return false
end

-- Blocs communs ----------------------------------------------------------------------------------------------------------------------------
local function header(src, c, prof, shops)
    local open = G.BizMenu and G.BizMenu.IsOpen(c.biz.id)
    local duty = G.BizMenu and #G.BizMenu.OnDuty(c.biz.id) or 0
    local rows = sales(c.biz.id, now() - 7 * 86400)
    local day, nDay = salesSum(rows, todayStart())
    local week, nWeek = salesSum(rows, 0)
    local chips = { { 'Statut', open and 'Ouvert' or 'Fermé' }, { 'En service', tostring(duty) } }
    if Biz.Can(c, 'vault') and G.Eco then chips[#chips + 1] = { 'Caisse', money(G.Eco.Balance('biz:' .. c.biz.id)) } end
    local sub = ({ dealer = 'Vitrine, essais et ventes de véhicules.', club = 'Soirées, bar et platines.', casino = 'Jeux, jetons, mises et clients de la salle.', cafe = 'Comptoir, menu du jour et réapprovisionnement.',
        resto = 'Service, carte et stock du comptoir.', shop = 'Rayons, prix et promotions.' })[prof]
    local party = A.party[c.biz.id]
    if party then sub = 'Soirée en cours : « ' .. party.name .. ' » jusqu\'à ' .. os.date('%H:%M', party.ends) .. '.' end
    local sp = A.special[c.biz.id]
    if sp and not party then sub = 'Menu du jour : ' .. sp.text .. '.' end
    local blocks = {
        { type = 'hero', eyebrow = PROFILE[prof].label, title = c.biz.label, sub = sub, chips = chips },
        { type = 'cards', items = {
            { title = "Ventes aujourd'hui", value = money(day), icon = 'coins', sub = nDay .. ' vente(s)' },
            { title = 'Ventes sur 7 jours', value = money(week), icon = 'chart', sub = nWeek .. ' vente(s)' },
            prof == 'casino' and { title = 'Caisse et jeux posés', value = tostring(G.Casino and G.Casino.PointCount() or 0), icon = 'star', sub = 'Builder › Casino' }
                or { title = 'Points de vente', value = tostring(#shops), icon = prof == 'dealer' and 'engine' or 'cart', sub = #shops > 0 and 'posés au Builder' or 'aucun : Builder › Entreprises' } } },
    }
    local acts = {}
    if c.duty and manager(c) and PB.Cfg.Get('bizmenu', 'open_status', true) then
        acts[#acts + 1] = { act = 'ba_open', label = open and "Fermer l'établissement" or "Ouvrir l'établissement", icon = open and 'lock' or 'key', primary = not open, confirm = open }
    end
    for _, s in ipairs(shops) do acts[#acts + 1] = { act = 'ba_gps', label = 'GPS : ' .. s.label, icon = 'pin', payload = { shop = s.id } } end
    if #acts > 0 then blocks[#blocks + 1] = { type = 'actions', title = "L'établissement", items = acts } end
    if not c.duty then blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = 'Prends ton service pour faire des annonces, lancer une soirée ou une happy hour.' } end
    return blocks, rows
end
local function adForm(c)
    if not c.duty or PB.Cfg.Get('bizmenu', 'ads', true) == false then return nil end
    return { type = 'form', title = 'Annonce publique', desc = 'Un message de ' .. c.biz.label .. ' envoyé à toute la ville.',
        fields = { { k = 'text', type = 'text', label = 'Annonce', maxlen = tonumber(PB.Cfg.Get('bizmenu', 'ad_maxlen', 120)) or 120 } }, submit = { act = 'ba_ad', label = 'Envoyer' } }
end
local function lastSales(rows, label, n)
    local out = {}
    for i = 1, math.min(n or 12, #rows) do local r = rows[i] out[#out + 1] = { at = os.date('%d/%m %H:%M', r.at), what = what(r.reason, label), net = money(r.delta) } end
    return { type = 'table', title = 'Dernières ventes', columns = { { k = 'at', label = 'Date' }, { k = 'what', label = 'Vente' }, { k = 'net', label = 'Encaissé' } }, rows = out, empty = 'Aucune vente sur les 7 derniers jours.' }
end

-- Comptoir : stock, prix, réapprovisionnement, promotion ---------------------------------------------------------------------------------
local function counterBlocks(c, counters, title)
    local blocks = {}
    for _, s in ipairs(counters) do
        local rows, opts = {}, {}
        for _, it in ipairs(s.catalog or {}) do
            local st = G.ShopStock and G.ShopStock(s, it.name)
            local acts = {}
            if manager(c) and st and st < (tonumber(s.opts.stock_max) or 50) then acts[1] = { label = '+10', act = 'ba_restock', payload = { shop = s.id, item = it.name, qty = 10 }, icon = 'plus' } end
            rows[#rows + 1] = { item = it.label or it.name, price = money(G.ShopFinal(s, it.price)), stock = st and (st .. ' / ' .. (tonumber(s.opts.stock_max) or 50)) or 'illimité', actions = acts }
            opts[#opts + 1] = { it.name, (it.label or it.name) .. ' · ' .. money(it.price) }
        end
        local hh = type(s.opts.hh) == 'table' and s.opts.hh or nil
        local tag = hh and (' · happy hour -' .. (tonumber(s.opts.discount) or 0) .. ' % jusqu\'à ' .. os.date('%H:%M', hh['until'] or 0)) or ((tonumber(s.opts.discount) or 0) > 0 and (' · promotion -' .. s.opts.discount .. ' %') or '')
        blocks[#blocks + 1] = { type = 'table', title = (title or 'Carte') .. ' : ' .. s.label .. tag, columns = { { k = 'item', label = 'Article' }, { k = 'price', label = 'Prix client' }, { k = 'stock', label = 'En rayon' } },
            rows = rows, empty = 'Catalogue vide : remplis-le dans le panel (Magasins › Modifier).' }
        if manager(c) and #opts > 0 then
            blocks[#blocks + 1] = { type = 'form', title = 'Changer un prix', desc = 'Prix de base, avant les taxes de la ville (le prix client est recalculé).',
                fields = { { k = 'shop', type = 'select', label = 'Comptoir', opts = { { tostring(s.id), s.label } } }, { k = 'item', type = 'select', label = 'Article', opts = opts }, { k = 'price', type = 'number', label = 'Nouveau prix', min = 1, max = 100000 } },
                submit = { act = 'ba_price', label = 'Enregistrer' } }
        end
    end
    return blocks
end
local function happyBlocks(c, counters)
    if #counters == 0 then return {} end
    local on
    for _, s in ipairs(counters) do if type(s.opts.hh) == 'table' then on = s end end
    if on then return { { type = 'actions', title = 'Happy hour', items = { { act = 'ba_hh_stop', label = "Arrêter l'happy hour (jusqu'à " .. os.date('%H:%M', on.opts.hh['until'] or 0) .. ')', icon = 'clock', danger = true } } } } end
    if not c.duty or not manager(c) then return {} end
    return { { type = 'form', title = 'Happy hour', desc = 'Remise sur toute la carte pendant un moment ; la ville est prévenue. Les prix reviennent tout seuls à la fin.',
        fields = { { k = 'pct', type = 'number', label = 'Remise (%)', min = 5, max = tonumber(cfg('hh_max_pct', 50)) or 50, value = 20 }, { k = 'mins', type = 'number', label = 'Durée (min)', min = 10, max = tonumber(cfg('hh_max_min', 120)) or 120, value = 30 } },
        submit = { act = 'ba_hh', label = "Lancer l'happy hour" } } }
end

-- Pages par métier --------------------------------------------------------------------------------------------------------------------------
local BUILD = {}
BUILD.dealer = function(src, c, shops, rows)
    local dealers = {}
    for _, s in ipairs(shops) do if s.kind == 'dealer' then dealers[#dealers + 1] = s end end
    local blocks = {}
    if #dealers == 0 then
        blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = "Aucune concession n'est posée pour l'entreprise : Builder › Existant › Entreprises › ses points › « Catalogue véhicules » et « Poste du vendeur »." }
        return blocks
    end
    blocks[#blocks + 1] = { type = 'notice', text = "En ville : le client choisit un véhicule à la vitrine et demande un essai. Un vendeur en service accepte (ALT sur le client), lui fait essayer puis valide la vente. L'argent va dans la caisse." }
    local inStock = 0
    for _, s in ipairs(dealers) do inStock = inStock + #(G.DealerList and G.DealerList(s) or s.catalog or {}) end
    blocks[#blocks + 1] = lastSales(rows, nil, 10)
    for _, s in ipairs(dealers) do
        local list = G.DealerList and G.DealerList(s) or s.catalog or {}
        local cards = { { title = 'Véhicules proposés', value = tostring(#list), icon = 'engine', sub = s.opts.gta_all and 'catalogue complet de GTA inclus' or 'catalogue de la concession' },
            { title = 'Vitrine', value = s.opts.showroom ~= false and 'Active' or 'Coupée', icon = 'eye', sub = s.opts.showroom ~= false and 'essais par les vendeurs' or 'le client achète seul' },
            { title = 'Promotion', value = (tonumber(s.opts.discount) or 0) > 0 and ('-' .. s.opts.discount .. ' %') or 'Aucune', icon = 'coins', sub = 'sur tous les véhicules' } }
        blocks[#blocks + 1] = { type = 'cards', items = cards }
        local own = {}
        for i, v in ipairs(s.catalog or {}) do
            if i > 60 then break end
            own[#own + 1] = { name = v.label or v.model, cat = v.category or '', price = money(G.ShopFinal(s, v.price)) }
        end
        blocks[#blocks + 1] = { type = 'table', title = 'Catalogue de ' .. s.label .. (#(s.catalog or {}) > 60 and ' (60 premiers)' or ''), columns = { { k = 'name', label = 'Véhicule' }, { k = 'cat', label = 'Catégorie' }, { k = 'price', label = 'Prix client' } }, rows = own,
            empty = 'Pas de véhicule à part : la vitrine montre le catalogue de GTA.' }
        if manager(c) then
            local opts = {}
            for i, v in ipairs(list) do if i > 250 then break end opts[#opts + 1] = { v.model, (v.label or v.model) .. ' · ' .. money(v.price) } end
            blocks[#blocks + 1] = { type = 'form', title = 'Changer le prix d\'un véhicule', desc = 'Prix de base, avant les taxes de la ville.',
                fields = { { k = 'shop', type = 'select', label = 'Concession', opts = { { tostring(s.id), s.label } } }, { k = 'model', type = 'select', label = 'Véhicule', opts = opts }, { k = 'price', type = 'number', label = 'Nouveau prix', min = 100, max = 50000000 } },
                submit = { act = 'ba_vprice', label = 'Enregistrer' } }
            blocks[#blocks + 1] = { type = 'form', title = 'Réglages de la vitrine', fields = {
                    { k = 'shop', type = 'select', label = 'Concession', opts = { { tostring(s.id), s.label } } },
                    { k = 'discount', type = 'number', label = 'Promotion sur tout (%)', min = 0, max = 50, value = tonumber(s.opts.discount) or 0 },
                    { k = 'showroom', type = 'toggle', label = 'Vitrine : essais et ventes par les vendeurs', value = s.opts.showroom ~= false },
                    { k = 'gta_all', type = 'toggle', label = 'Proposer aussi tout le catalogue de GTA', value = s.opts.gta_all and true or false } },
                submit = { act = 'ba_dealer_opts', label = 'Enregistrer' } }
        end
    end
    return blocks
end
BUILD.club = function(src, c, shops, rows)
    local counters = {}
    for _, s in ipairs(shops) do if s.kind == 'store' then counters[#counters + 1] = s end end
    local blocks = {}
    local party = A.party[c.biz.id]
    if party then
        blocks[#blocks + 1] = { type = 'cards', items = { { title = 'Soirée en cours', value = party.name, icon = 'star', sub = 'Lancée par ' .. party.by .. ' · fin à ' .. os.date('%H:%M', party.ends) } } }
        if c.duty and manager(c) then blocks[#blocks + 1] = { type = 'actions', items = { { act = 'ba_party_stop', label = 'Terminer la soirée', icon = 'power', danger = true, confirm = true } } } end
    elseif c.duty and manager(c) then
        blocks[#blocks + 1] = { type = 'form', title = 'Lancer une soirée', desc = 'Toute la ville est prévenue ; la soirée apparaît ici et dans les annonces jusqu\'à la fin.',
            fields = { { k = 'name', type = 'text', label = 'Nom de la soirée', maxlen = 48 }, { k = 'mins', type = 'number', label = 'Durée (min)', min = tonumber(cfg('party_min', 30)) or 30, max = tonumber(cfg('party_max', 360)) or 360, value = 120 } },
            submit = { act = 'ba_party', label = 'Lancer la soirée' } }
    end
    -- platines : ce qui passe sur les tables de mixage et écrans près de l'établissement
    local music = {}
    for _, s in pairs(G.TV and G.TV.screens or {}) do
        if nearBiz(c.biz.id, s.x, s.y, shops) then
            music[#music + 1] = { what = s.title or 'Écran', by = s.byName or '', since = os.date('%H:%M', s.at or 0),
                actions = (c.duty and manager(c)) and { { label = 'Couper', act = 'ba_music_stop', payload = { id = s.id }, icon = 'power', danger = true } } or {} }
        end
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Platines et écrans', columns = { { k = 'what', label = 'Source' }, { k = 'by', label = 'Lancé par' }, { k = 'since', label = 'Depuis' } }, rows = music,
        empty = 'Rien ne passe. Le DJ lance la musique en ville : ALT sur la table de mixage › Diffuser (lien YouTube).' }
    for _, b in ipairs(happyBlocks(c, counters)) do blocks[#blocks + 1] = b end
    for _, b in ipairs(counterBlocks(c, counters, 'Carte du bar')) do blocks[#blocks + 1] = b end
    blocks[#blocks + 1] = lastSales(rows, nil, 10)
    return blocks
end
local function foodPage(menuTitle)
    return function(src, c, shops, rows)
        local counters = {}
        for _, s in ipairs(shops) do if s.kind == 'store' then counters[#counters + 1] = s end end
        local blocks = {}
        if #counters == 0 then blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = "Aucun comptoir n'est posé : Builder › Entreprises › « Entreprise : comptoir de vente »." } end
        local sp = A.special[c.biz.id]
        if c.duty and manager(c) and #counters > 0 then
            local opts = {}
            for _, it in ipairs(counters[1].catalog or {}) do opts[#opts + 1] = { it.name, it.label or it.name } end
            blocks[#blocks + 1] = { type = 'form', title = 'Menu du jour', desc = sp and ('En ce moment : ' .. sp.text .. '.') or "Annonce à la ville ce que vous mettez en avant aujourd'hui.",
                fields = { { k = 'item', type = 'select', label = 'Article', opts = opts }, { k = 'note', type = 'text', label = 'Petit mot (facultatif)', maxlen = 60 } },
                submit = { act = 'ba_special', label = 'Annoncer le menu du jour' } }
        end
        for _, b in ipairs(happyBlocks(c, counters)) do blocks[#blocks + 1] = b end
        for _, b in ipairs(counterBlocks(c, counters, menuTitle)) do blocks[#blocks + 1] = b end
        blocks[#blocks + 1] = lastSales(rows, nil, 10)
        return blocks
    end
end
BUILD.cafe = foodPage('Carte du comptoir')
BUILD.resto = foodPage('Carte')
BUILD.shop = function(src, c, shops, rows)
    local counters = {}
    for _, s in ipairs(shops) do if s.kind == 'store' then counters[#counters + 1] = s end end
    local blocks = {}
    if #counters == 0 then blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = "Aucun comptoir n'est posé : Builder › Entreprises › « Entreprise : comptoir de vente »." } end
    for _, b in ipairs(happyBlocks(c, counters)) do blocks[#blocks + 1] = b end
    for _, b in ipairs(counterBlocks(c, counters, 'Rayons')) do blocks[#blocks + 1] = b end
    blocks[#blocks + 1] = lastSales(rows, nil, 10)
    return blocks
end

-- Salle de jeux : résultats lus dans le journal du casino, la caisse de l'entreprise encaisse et paie (server/game/casino.lua)
BUILD.casino = function(src, c)
    local Ca = G.Casino
    if not Ca then return {} end
    local blocks = {}
    local owner = tostring(PB.Cfg.Get('casino', 'owner_biz', '') or '')
    local mine = owner == c.biz.id
    if owner == '' then
        blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = "Le casino appartient encore à l'État. Relié à ton entreprise, sa caisse encaisse les jetons vendus et paie les jetons rachetés : garde de l'argent dedans." }
        if manager(c) then blocks[#blocks + 1] = { type = 'actions', title = 'Reprendre le casino', items = { { act = 'ba_cas_link', label = 'Relier le casino à mon entreprise', icon = 'key', primary = true, confirm = true } } } end
    elseif not mine then
        blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = 'Le casino est relié à une autre entreprise : seul le staff peut le changer (Panel › Casino).' }
    end
    if not Ca.HasCashier() then blocks[#blocks + 1] = { type = 'notice', kind = 'warn', text = "Aucune caisse n'est posée : F10 › Builder › Casino, puis les jeux dans la salle." } end
    local molo = Ca.Molo()
    if molo then blocks[#blocks + 1] = { type = 'notice', kind = 'info', text = "Les tables, la roue, les paris et l'hôtel tournent avec les scripts Molo. Ici, tu suis la caisse : jetons vendus moins jetons rachetés. Fermer la salle ou interdire un joueur arrête la vente de jetons, pas les tables : un joueur peut miser les jetons qu'il a déjà." } end
    local unit = molo and ' opération(s) · ' or ' partie(s) · '
    local day, week = Ca.Stats(todayStart()), Ca.Stats(now() - 7 * 86400)
    blocks[#blocks + 1] = { type = 'cards', items = {
        { title = "Bénéfice aujourd'hui", value = money(day.bet - day.win), icon = 'coins', sub = day.n .. unit .. day.players .. ' joueur(s)' },
        { title = 'Bénéfice sur 7 jours', value = money(week.bet - week.win), icon = 'chart', sub = week.n .. unit .. week.players .. ' joueur(s)' },
        { title = 'Salle', value = PB.Cfg.Get('casino', 'closed', false) == true and 'Fermée' or 'Ouverte', icon = 'key', sub = molo and 'Vente de jetons' or ('Mises de ' .. tostring(PB.Cfg.Get('casino', 'min_bet', 10)) .. ' à ' .. tostring(PB.Cfg.Get('casino', 'max_bet', 5000)) .. ' jetons') } } }
    if mine and c.duty and manager(c) then
        local closed = PB.Cfg.Get('casino', 'closed', false) == true
        blocks[#blocks + 1] = { type = 'actions', title = 'La salle', items = { { act = 'ba_cas_close', label = closed and 'Ouvrir la salle de jeux' or 'Fermer la salle de jeux', icon = closed and 'key' or 'lock', primary = closed, confirm = not closed } } }
        if not molo then blocks[#blocks + 1] = { type = 'form', title = 'Mises', desc = 'En jetons, pour tous les jeux. Une mise maximale élevée demande plus d\'argent dans la caisse.', cols = 2,
            values = { min = PB.Cfg.Get('casino', 'min_bet', 10), max = PB.Cfg.Get('casino', 'max_bet', 5000) },
            fields = { { k = 'min', type = 'number', label = 'Mise minimale', min = 1 }, { k = 'max', type = 'number', label = 'Mise maximale', min = 1, max = tonumber(PB.Cfg.Get('casino', 'biz_max_bet', 100000)) or 100000 } },
            submit = { act = 'ba_cas_bets', label = 'Enregistrer' } } end
    end
    local games = {}
    for _, g in ipairs(Ca.ByGame(now() - 7 * 86400)) do games[#games + 1] = { game = g.label, n = tostring(g.n), bet = tostring(g.bet), net = money(g.bet - g.win) } end
    blocks[#blocks + 1] = { type = 'table', title = molo and 'Caisse sur 7 jours' or 'Jeux sur 7 jours', columns = { { k = 'game', label = molo and 'Opération' or 'Jeu' }, { k = 'n', label = molo and 'Nombre' or 'Parties' }, { k = 'bet', label = molo and 'Encaissé' or 'Misé' }, { k = 'net', label = 'Bénéfice' } }, rows = games, empty = 'Rien sur les 7 derniers jours.' }
    local wins = {}
    for _, w in ipairs(Ca.BigWins(now() - 7 * 86400, 8)) do wins[#wins + 1] = { at = os.date('%d/%m %H:%M', w.at), who = w.name, game = Ca.GameLabel(w.game), net = tostring(w.win - w.bet) } end
    blocks[#blocks + 1] = { type = 'table', title = molo and 'Plus gros rachats' or 'Plus gros gains des joueurs', columns = { { k = 'at', label = 'Date' }, { k = 'who', label = 'Joueur' }, { k = 'game', label = molo and 'Opération' or 'Jeu' }, { k = 'net', label = molo and 'Montant' or 'Jetons gagnés' } }, rows = wins, empty = 'Aucun gain sur les 7 derniers jours.' }
    local bans = {}
    for _, b in ipairs(Ca.Bans()) do
        bans[#bans + 1] = { who = b.name, why = b.reason, by = b.by_name, at = os.date('%d/%m %H:%M', b.at),
            actions = (mine and manager(c)) and { { label = 'Lever', act = 'ba_cas_unban', payload = { license = b.license }, icon = 'check', confirm = true } } or {} }
    end
    blocks[#blocks + 1] = { type = 'table', title = 'Interdits de casino', columns = { { k = 'who', label = 'Joueur' }, { k = 'why', label = 'Motif' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Date' } }, rows = bans, empty = 'Personne. Interdiction : menu F6, sur le joueur.' }
    return blocks
end

Biz.PAGES.activity = function(src)
    local c = Biz.Ctx(src)
    local prof = A.Profile(c)
    if not prof or cfg('enabled', true) == false then return nil end
    local shops = G.BizShops and G.BizShops(c.biz.id) or {}
    local blocks, rows = header(src, c, prof, shops)
    local ad = adForm(c)
    for _, b in ipairs(BUILD[prof](src, c, shops, rows)) do blocks[#blocks + 1] = b end
    if ad then blocks[#blocks + 1] = ad end
    return blocks, PROFILE[prof].label
end
Biz.PAGE_META.activity = { label = 'Mon activité', icon = 'briefcase', group = 'Entreprise' }
table.insert(Biz.ORDER, 2, 'activity')
Biz.NavAllow.activity = function(c) return cfg('enabled', true) ~= false and A.Profile(c) ~= nil end
Biz.NavLabel.activity = function(c) local p = PROFILE[A.Profile(c) or ''] if p then return p.label, p.icon end end

-- Actions ------------------------------------------------------------------------------------------------------------------------------------
local ACT = Biz.ACT
local function myShop(c, id)
    local s = G.GetShop and G.GetShop(id)
    if not s or ((s.opts.biz or '') ~= c.biz.id and (s.opts.biz_counter or '') ~= c.biz.id) then return nil end
    return s
end
local function needManager(c, duty)
    if not manager(c) then return 'Réservé à la direction.' end
    if duty and not c.duty then return 'Prends ton service.' end
end

ACT.ba_open = function(c, src) return Q.Handlers.biz_open(src, c) end
-- Salle de jeux
local function casinoBoss(c)
    if A.Profile(c) ~= 'casino' or not G.Casino then return 'Réservé au casino.' end
    return needManager(c)
end
local function casinoMine(c)
    local e = casinoBoss(c)
    if e then return e end
    if not c.duty then return 'Prends ton service.' end
    if tostring(PB.Cfg.Get('casino', 'owner_biz', '') or '') ~= c.biz.id then return "Le casino n'est pas relié à ton entreprise." end
end
ACT.ba_cas_link = function(c, src)
    local e = casinoBoss(c) if e then return false, e end
    if tostring(PB.Cfg.Get('casino', 'owner_biz', '') or '') ~= '' then return false, 'Le casino a déjà un propriétaire.' end
    PB.Cfg.Set('casino', 'owner_biz', c.biz.id, src, 'Casino relié à ' .. c.biz.label, true)
    PB.Audit.Log('casino', 'casino.link', src, c.biz.label)
    return true, 'Le casino est maintenant relié à ' .. c.biz.label .. '.'
end
ACT.ba_cas_close = function(c, src)
    local e = casinoMine(c) if e then return false, e end
    local closed = PB.Cfg.Get('casino', 'closed', false) ~= true
    PB.Cfg.Set('casino', 'closed', closed, src, closed and 'Casino fermé' or 'Casino ouvert', true)
    PB.Audit.Log('casino', closed and 'casino.close' or 'casino.open', src, c.biz.label)
    return true, closed and 'Salle fermée : plus de nouvelles parties. La caisse rachète toujours les jetons.' or 'Salle ouverte.'
end
ACT.ba_cas_bets = function(c, src, p)
    local e = casinoMine(c) if e then return false, e end
    local cap = tonumber(PB.Cfg.Get('casino', 'biz_max_bet', 100000)) or 100000
    local mn, mx = math.floor(tonumber(p.min) or 0), math.floor(tonumber(p.max) or 0)
    if mn < 1 or mx < mn then return false, 'La mise maximale doit être au moins égale à la minimale.' end
    if mx > cap then return false, ('Mise maximale autorisée par le serveur : %d jetons.'):format(cap) end
    PB.Cfg.Set('casino', 'min_bet', mn, src, 'Mise minimale du casino', true)
    PB.Cfg.Set('casino', 'max_bet', mx, src, 'Mise maximale du casino', true)
    PB.Audit.Log('casino', 'casino.bets', src, c.biz.label, nil, nil, { min = mn, max = mx })
    return true, ('Mises : de %d à %d jetons.'):format(mn, mx)
end
ACT.ba_cas_unban = function(c, src, p)
    local e = casinoMine(c) if e then return false, e end
    G.Casino.Unban(p.license)
    PB.Audit.Log('casino', 'casino.unban', src, tostring(p.license))
    return true, 'Interdiction levée.'
end
ACT.ba_ad = function(c, src, p) return Q.Handlers.biz_ad(src, c, { text = p.text }) end
ACT.ba_gps = function(c, src, p)
    local s = myShop(c, p.shop)
    if not s then return false, 'Lieu inconnu.' end
    TriggerClientEvent('pb:g:orga:gps', src, PB.Json({ x = s.x, y = s.y, label = s.label }))
    return true, 'Position marquée sur ta carte.'
end
ACT.ba_price = function(c, src, p)
    local e = needManager(c) if e then return false, e end
    local s = myShop(c, p.shop)
    if not s then return false, 'Comptoir inconnu.' end
    local price = int(p.price, 1, 100000, 0)
    if price < 1 then return false, 'Prix invalide.' end
    for _, it in ipairs(s.catalog) do
        if it.name == p.item then
            local old = it.price
            it.price = price
            G.ShopSaveCatalog(s.id, s.catalog)
            PB.Audit.Log('economie', 'biz.price', src, s.label, it.name, old, { price = price })
            return true, (it.label or it.name) .. ' : ' .. money(price) .. ' (prix client ' .. money(G.ShopFinal(s, price)) .. ').'
        end
    end
    return false, 'Article introuvable.'
end
ACT.ba_restock = function(c, src, p)
    local e = needManager(c) if e then return false, e end
    local s = myShop(c, p.shop)
    if not s or not s.opts.stock_on then return false, 'Ce comptoir ne gère pas de stock.' end
    local item
    for _, it in ipairs(s.catalog) do if it.name == p.item then item = it end end
    if not item then return false, 'Article introuvable.' end
    local have = G.ShopStock(s, item.name) or 0
    local qty = math.min(int(p.qty, 1, 50, 10), (tonumber(s.opts.stock_max) or 50) - have)
    if qty <= 0 then return false, 'Le rayon est plein.' end
    local cost = math.floor(G.ShopFinal(s, item.price) * qty * (tonumber(s.opts.wholesale) or 50) / 100 + 0.5)
    if cost > 0 and not G.Eco.Take('biz:' .. c.biz.id, cost, 'Réapprovisionnement ' .. s.label .. ' · ' .. item.name, G.Get(src).license) then
        return false, "La caisse de l'entreprise ne couvre pas " .. money(cost) .. '.'
    end
    G.ShopStockSet(s, item.name, have + qty)
    PB.Audit.Log('economie', 'shop.restock', src, s.label, item.name, nil, { qty = qty, cost = cost })
    return true, ('+%d × %s (coût %s).'):format(qty, item.label or item.name, money(cost))
end
ACT.ba_vprice = function(c, src, p)
    local e = needManager(c) if e then return false, e end
    local s = myShop(c, p.shop)
    if not s or s.kind ~= 'dealer' then return false, 'Concession inconnue.' end
    local price = int(p.price, 100, 50000000, 0)
    if price < 100 then return false, 'Prix invalide.' end
    local model = tostring(p.model or '')
    for _, v in ipairs(s.catalog) do
        if v.model == model then v.price = price G.ShopSaveCatalog(s.id, s.catalog) PB.Audit.Log('economie', 'biz.vprice', src, s.label, model, nil, { price = price }) return true, (v.label or model) .. ' : ' .. money(price) .. '.' end
    end
    -- véhicule du catalogue de GTA : on l'ajoute au catalogue de la concession avec son nouveau prix
    for _, v in ipairs(G.DealerList and G.DealerList(s) or {}) do
        if v.model == model then
            local row = PB.DeepCopy(v)
            row.price = price
            s.catalog[#s.catalog + 1] = row
            G.ShopSaveCatalog(s.id, s.catalog)
            PB.Audit.Log('economie', 'biz.vprice', src, s.label, model, nil, { price = price })
            return true, (v.label or model) .. ' : ' .. money(price) .. '.'
        end
    end
    return false, 'Véhicule introuvable.'
end
ACT.ba_dealer_opts = function(c, src, p)
    local e = needManager(c) if e then return false, e end
    local s = myShop(c, p.shop)
    if not s or s.kind ~= 'dealer' then return false, 'Concession inconnue.' end
    G.ShopPatchOpts(s.id, { discount = int(p.discount, 0, 50, 0), showroom = p.showroom == true, gta_all = p.gta_all == true })
    PB.Audit.Log('economie', 'biz.dealer', src, s.label, nil, nil, { discount = p.discount, showroom = p.showroom, gta_all = p.gta_all })
    return true, 'Réglages de la concession enregistrés.'
end

-- Soirées
ACT.ba_party = function(c, src, p)
    local e = needManager(c, true) if e then return false, e end
    if A.party[c.biz.id] then return false, 'Une soirée est déjà en cours.' end
    local name = clean(p.name, 48)
    if #name < 3 then return false, 'Donne un nom à la soirée.' end
    local mins = int(p.mins, tonumber(cfg('party_min', 30)) or 30, tonumber(cfg('party_max', 360)) or 360, 120)
    A.party[c.biz.id] = { name = name, at = now(), ends = now() + mins * 60, by = display(src) }
    everyone({ type = 'info', title = c.biz.label, text = 'Soirée « ' .. name .. ' » : on vous attend jusqu\'à ' .. os.date('%H:%M', now() + mins * 60) .. ' !', duration = 12000 })
    PB.Audit.Log('serveur', 'biz.party', src, c.biz.id, nil, nil, { name = name, mins = mins })
    return true, 'Soirée lancée : la ville est prévenue.'
end
ACT.ba_party_stop = function(c, src)
    local e = needManager(c, true) if e then return false, e end
    if not A.party[c.biz.id] then return false, 'Aucune soirée en cours.' end
    A.party[c.biz.id] = nil
    everyone({ type = 'info', title = c.biz.label, text = 'La soirée est terminée, merci à tous !', duration = 8000 })
    return true, 'Soirée terminée.'
end
ACT.ba_music_stop = function(c, src, p)
    local e = needManager(c, true) if e then return false, e end
    local s = G.TV and G.TV.screens[tostring(p.id or '')]
    if not s or not nearBiz(c.biz.id, s.x, s.y, G.BizShops(c.biz.id)) then return false, 'Rien ne passe ici.' end
    PB.Audit.Log('monde', 'tv.stop', src, s.id)
    return G.TV.Stop(src, s.id, true)
end

-- Menu du jour
ACT.ba_special = function(c, src, p)
    local e = needManager(c, true) if e then return false, e end
    local counters = G.BizShops(c.biz.id, 'store')
    local item
    for _, s in ipairs(counters) do for _, it in ipairs(s.catalog or {}) do if it.name == p.item then item = { it = it, s = s } end end end
    if not item then return false, 'Choisis un article de la carte.' end
    local note = clean(p.note, 60)
    local text = (item.it.label or item.it.name) .. ' à ' .. money(G.ShopFinal(item.s, item.it.price)) .. (note ~= '' and (' · ' .. note) or '')
    local w = G.BizMenu and G.BizMenu.lastAd[c.biz.id] and (G.BizMenu.lastAd[c.biz.id] + (tonumber(PB.Cfg.Get('bizmenu', 'ad_cooldown', 300)) or 300) - now())
    A.special[c.biz.id] = { text = text, at = now() }
    if w and w > 0 then return true, "Menu du jour enregistré ; l'annonce à la ville attendra (une annonce vient de passer)." end
    if G.BizMenu then G.BizMenu.lastAd[c.biz.id] = now() end
    everyone({ type = 'info', title = c.biz.label, text = 'Menu du jour : ' .. text, duration = 12000 })
    return true, 'Menu du jour annoncé.'
end

-- Happy hour : remise du comptoir (option « discount » des magasins), remise d'avant rétablie à la fin, même après un redémarrage
local function hhEnd(s, silent, label)
    local hh = type(s.opts.hh) == 'table' and s.opts.hh or {}
    G.ShopPatchOpts(s.id, { discount = tonumber(hh.prev) or 0, hh = false })
    if not silent then everyone({ type = 'info', title = label or s.label, text = "Fin de l'happy hour, merci d'être passés !", duration = 7000 }) end
end
ACT.ba_hh = function(c, src, p)
    local e = needManager(c, true) if e then return false, e end
    local counters = G.BizShops(c.biz.id, 'store')
    if #counters == 0 then return false, "Aucun comptoir n'est posé." end
    for _, s in ipairs(counters) do if type(s.opts.hh) == 'table' then return false, "L'happy hour est déjà lancée." end end
    local pct = int(p.pct, 5, tonumber(cfg('hh_max_pct', 50)) or 50, 20)
    local mins = int(p.mins, 10, tonumber(cfg('hh_max_min', 120)) or 120, 30)
    local untilAt = now() + mins * 60
    for _, s in ipairs(counters) do G.ShopPatchOpts(s.id, { discount = pct, hh = { ['until'] = untilAt, prev = tonumber(s.opts.discount) or 0, biz = c.biz.id } }) end
    everyone({ type = 'info', title = c.biz.label, text = ('Happy hour : -%d %% sur toute la carte jusqu\'à %s !'):format(pct, os.date('%H:%M', untilAt)), duration = 12000 })
    PB.Audit.Log('economie', 'biz.happyhour', src, c.biz.id, nil, nil, { pct = pct, mins = mins })
    return true, 'Happy hour lancée.'
end
ACT.ba_hh_stop = function(c, src)
    local e = needManager(c, true) if e then return false, e end
    local n = 0
    for _, s in ipairs(G.BizShops(c.biz.id, 'store')) do if type(s.opts.hh) == 'table' then hhEnd(s, n > 0, c.biz.label) n = n + 1 end end
    if n == 0 then return false, "Pas d'happy hour en cours." end
    return true, 'Happy hour arrêtée.'
end

-- Fin automatique des soirées et des happy hours
function A.Tick()
    local t = now()
    for id, pt in pairs(A.party) do if t >= pt.ends then A.party[id] = nil end end
    for id, sp in pairs(A.special) do if t - sp.at > 6 * 3600 then A.special[id] = nil end end
    for _, r in ipairs(DB.q("SELECT id FROM pb_shops WHERE opts LIKE '%\"hh\":%'") or {}) do
        local s = G.GetShop(r.id)
        if s and type(s.opts.hh) == 'table' and t >= (tonumber(s.opts.hh['until']) or 0) then
            local b = Biz.Get(tostring(s.opts.hh.biz or s.opts.biz_counter or s.opts.biz or ''))
            hhEnd(s, false, b and b.label or nil)
        end
    end
end
CreateThread(function()
    Wait(math.random(5000, 20000))
    while true do pcall(A.Tick) Wait(30000) end
end)

G.BizActivityForm = PB.Form.Cfg({ ns = 'bizactivity', id = 'settings', title = "Tablette : page du métier (concession, soirées, comptoir…)", perm = 'quick.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Page du métier dans la tablette des entreprises', default = true },
    { k = 'party_min', type = 'number', label = "Durée minimale d'une soirée (min)", default = 30, min = 10, max = 240 },
    { k = 'party_max', type = 'number', label = "Durée maximale d'une soirée (min)", default = 360, min = 30, max = 720 },
    { k = 'hh_max_pct', type = 'number', label = "Remise maximale d'une happy hour (%)", default = 50, min = 5, max = 90 },
    { k = 'hh_max_min', type = 'number', label = "Durée maximale d'une happy hour (min)", default = 120, min = 10, max = 360 },
    { k = 'music_radius', type = 'number', label = "Rayon autour de l'établissement pour les platines (m)", default = 150, min = 30, max = 500 },
} })
