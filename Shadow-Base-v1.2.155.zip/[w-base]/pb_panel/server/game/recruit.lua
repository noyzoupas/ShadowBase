-- Proposition de recrutement (entreprise ou organisation) : la personne voit une carte et répond Y ou N. Le serveur garde l'offre et revérifie tout à l'acceptation.
local G = PB.G
local R = {}
G.Recruit = R

local offers = {}   -- cible -> { token, exp, from, org, accept }
AddEventHandler('playerDropped', function() offers[source] = nil end)

-- o : kind ('biz' / 'orga'), org, from (source), fromName, grade, salary, second, secs, accept() -> ok, message
function R.Offer(t, o)
    local cur = offers[t]
    if cur and cur.exp > os.time() then return false, 'Cette personne a déjà une proposition en attente.' end
    local secs = math.max(10, math.min(600, math.floor(tonumber(o.secs) or 60)))
    local token = tostring(math.random(100000, 999999))
    offers[t] = { token = token, exp = os.time() + secs, from = o.from, org = o.org, accept = o.accept }
    TriggerClientEvent('pb:g:recruit:offer', t, PB.Json({ token = token, kind = o.kind, org = o.org, from = o.fromName, grade = o.grade, salary = o.salary, second = o.second, secs = secs }))
    SetTimeout((secs + 1) * 1000, function()
        local c = offers[t]
        if c and c.token == token then
            offers[t] = nil
            if G.Get(o.from) then G.Notify(o.from, { type = 'warn', title = o.org, text = 'Pas de réponse à ta proposition.' }) end
        end
    end)
    return true
end

function R.Answer(t, yes)
    local o = offers[t]
    if not o then return false end
    offers[t] = nil
    local fromOk = G.Get(o.from) ~= nil
    if not yes then
        if fromOk then G.Notify(o.from, { type = 'warn', title = o.org, text = 'Proposition refusée.' }) end
        return true
    end
    if o.exp < os.time() then G.Notify(t, { type = 'error', title = o.org, text = 'Cette proposition a expiré.' }) return false end
    local ok, msg = o.accept()
    G.Notify(t, { type = ok and 'success' or 'error', title = o.org, text = ok and ('Bienvenue : tu as rejoint %s.'):format(o.org) or tostring(msg or 'Impossible.') })
    if fromOk then G.Notify(o.from, { type = ok and 'success' or 'error', title = o.org, text = ok and tostring(msg or 'Proposition acceptée.') or tostring(msg or 'Impossible.') }) end
    return ok
end

RegisterNetEvent('pb:g:recruit:answer', function(token, yes)
    local src = source
    local o = offers[src]
    if not o or o.token ~= tostring(token or '') then return end
    R.Answer(src, yes == true)
end)
