-- (v1.2.98) Statut du serveur sur Discord : UN message, modifié toutes les minutes (pas un nouveau message à chaque fois).
-- Joueurs en ligne, file d'attente, staff, police et secours en service, temps depuis le démarrage, prochain redémarrage, adresse.
-- Panel › Discord › canal « Statut du serveur » : colle l'adresse d'un webhook du salon voulu. À l'arrêt du serveur, le message passe en rouge.
local G = PB.G
PB.Cfg.Define('statusbot', { enabled = true, every = 60, connect = '', title = '' })
local function cfg(k, d) return PB.Cfg.Get('statusbot', k, d) end
local started = os.time()
local function hookUrl() return PB.Secret and PB.Secret.Get('dc_wh_status') end
local function msgId() return GetResourceKvpString and GetResourceKvpString('pb_status_msg') or nil end
local function setMsgId(id) if SetResourceKvp then if id then SetResourceKvp('pb_status_msg', id) elseif DeleteResourceKvp then DeleteResourceKvp('pb_status_msg') end end end

local function nextRestart()
    local times = {}
    if PB.Cfg.Get('monitor', 'restart_enabled', false) then for _, t in ipairs(PB.Cfg.Get('monitor', 'restart_times', {}) or {}) do times[#times + 1] = t end end
    if PB.Cfg.Get('flow', 'restart_on', false) then for _, t in ipairs(PB.Cfg.Get('flow', 'restart_times', {}) or {}) do times[#times + 1] = t end end
    local nowMin = tonumber(os.date('%H')) * 60 + tonumber(os.date('%M'))
    local best
    for _, t in ipairs(times) do
        local h, m = tostring(t):match('^(%d%d?):(%d%d)$')
        if h then local left = ((tonumber(h) * 60 + tonumber(m)) - nowMin) % 1440 if not best or left < best.left then best = { left = left, at = t } end end
    end
    if PB.Restart and PB.Restart.State then local st = PB.Restart.State() if st then return ('dans %d min (en cours)'):format(math.ceil(st.left / 60)) end end
    return best and ('%s (dans %d h %02d)'):format(best.at, best.left // 60, best.left % 60) or 'non planifié'
end
local function embed(online)
    local n, staff, police, ems = 0, 0, 0, 0
    for src in pairs(G.Players()) do
        n = n + 1
        if G.Staff and G.Staff.OnDuty(src) then staff = staff + 1 end
        local j = G.Biz and G.Biz.Job and G.Biz.Job(src)
        if j and j.onDuty then if j.kind == 'police' then police = police + 1 elseif j.kind == 'ems' then ems = ems + 1 end end
    end
    local max = (G.Flow and G.Flow.MaxSlots and G.Flow.MaxSlots()) or GetConvarInt('sv_maxclients', 48)
    local up = os.time() - started
    local name = cfg('title', '') ~= '' and cfg('title', '') or PB.Cfg.Get('general', 'server_name', 'Serveur')
    local fields = online and {
        { name = 'Joueurs', value = ('%d / %d'):format(n, max), inline = true },
        { name = "File d'attente", value = tostring(G.Flow and G.Flow.QueueLen and G.Flow.QueueLen() or 0), inline = true },
        { name = 'Staff en service', value = tostring(staff), inline = true },
        { name = 'Police', value = tostring(police), inline = true },
        { name = 'Secours', value = tostring(ems), inline = true },
        { name = 'En ligne depuis', value = ('%d h %02d'):format(up // 3600, (up % 3600) // 60), inline = true },
        { name = 'Prochain redémarrage', value = nextRestart(), inline = false },
    } or { { name = 'État', value = 'Serveur arrêté ou en redémarrage.', inline = false } }
    if cfg('connect', '') ~= '' then fields[#fields + 1] = { name = 'Se connecter', value = tostring(cfg('connect', '')):sub(1, 200), inline = false } end
    return { title = (online and '🟢 ' or '🔴 ') .. name, color = online and 0x4fd18b or 0xff5c6c, fields = fields,
        footer = { text = 'Mis à jour' }, timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ') }
end
local function body(online)
    local u = PB.Cfg.Get('discord', 'username', 'Panel')
    if u == '' or u == 'Panel' then u = PB.Cfg.Get('general', 'server_name', 'Panel') end
    return PB.Json({ username = u, embeds = { embed(online) }, allowed_mentions = { parse = {} } })
end
local busy = false
local function push(online)
    local url = hookUrl()
    if busy or not url or not url:match('^https://') or PB.Cfg.Get('discord', 'enabled', true) == false then return end
    busy = true
    local id = msgId()
    local H = { ['Content-Type'] = 'application/json' }
    if id then
        PerformHttpRequest(url .. '/messages/' .. id, function(status)
            busy = false
            if status == 404 then setMsgId(nil) end   -- message supprimé à la main : on en repostera un
        end, 'PATCH', body(online), H)
    else
        PerformHttpRequest(url .. (url:find('?', 1, true) and '&' or '?') .. 'wait=true', function(status, text)
            busy = false
            local d = status == 200 and PB.FromJson(text or '', nil)
            if type(d) == 'table' and d.id then setMsgId(tostring(d.id)) end
        end, 'POST', body(online), H)
    end
end
G.StatusPush = push
CreateThread(function()
    while not PB.IsReady do Wait(1000) end
    Wait(10000)
    while true do
        local ok, err = pcall(function() if cfg('enabled', true) ~= false then push(true) end end)
        if not ok then PB.Warn('statut discord : ' .. tostring(err)) end
        Wait(math.max(30, math.min(600, tonumber(cfg('every', 60)) or 60)) * 1000)
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and cfg('enabled', true) ~= false then busy = false pcall(push, false) end end)
G.StatusForm = PB.Form.Cfg({ ns = 'statusbot', id = 'settings', title = 'Statut du serveur sur Discord', perm = 'discord.edit', cols = 2,
    desc = "Un seul message, modifié toutes les minutes, dans le salon du webhook « Statut du serveur » (onglet Canaux).", fields = {
    { k = 'enabled', type = 'toggle', label = 'Tenir le message à jour', default = true },
    { k = 'every', type = 'number', label = 'Toutes les (secondes)', default = 60, min = 30, max = 600 },
    { k = 'title', type = 'text', label = 'Titre (vide = nom du serveur)', default = '', maxlen = 60 },
    { k = 'connect', type = 'text', label = 'Comment se connecter (affiché en bas)', default = '', maxlen = 200, hint = 'Ex. F8 › connect monserveur.fr  ou le lien cfx.re/join/xxxx' },
} })
