-- Discord : envoi par webhooks (file d'attente, limites de débit, nouvelles tentatives) et appels API du bot.
-- Les webhooks et le jeton du bot sont des SECRETS : stockés côté serveur, jamais envoyés à l'interface.

PB.Discord = PB.Discord or {}
local D = PB.Discord

PB.Cfg.Define('discord', {
    enabled = true,
    guild_id = '',
    username = 'Panel',
    avatar = '',
    channels = {},       -- [clé] = { enabled = true, mention = '' }
    role_map = {},       -- [idRôleDiscord] = nomDuGrade
    role_sync = false,
    alert_crash = true, alert_backup = true, alert_security = true,
})

-- Canaux connus : clé -> libellé, catégories d'audit qui y sont envoyées, couleur de l'embed.
D.Channels = {
    { key = 'logs_config', label = 'Modifications de configuration', cats = { 'config', 'ressource', 'sql', 'automatisation', 'serveur', 'panel' }, color = 0x9b8cff },
    { key = 'logs_grades', label = 'Grades et permissions', cats = { 'grade', 'permission' }, color = 0xff6aa8 },
    { key = 'logs_sanctions', label = 'Sanctions', cats = { 'sanction' }, color = 0xffd166 },
    { key = 'logs_kicks', label = 'Expulsions, bans et déconnexions', cats = { 'expulsion' }, color = 0xff8f5c },
    { key = 'logs_transactions', label = 'Transactions', cats = { 'transaction' }, color = 0x7be0a4 },
    { key = 'logs_connexions', label = 'Connexions', cats = { 'connexion' }, color = 0x5ad1ff },
    { key = 'logs_commands', label = 'Commandes', cats = { 'commande' }, color = 0x8e8aa6 },
    { key = 'crash', label = 'Crashs et erreurs Lua', cats = { 'erreur_lua' }, color = 0xff5c6c },
    { key = 'backup', label = 'Sauvegardes', cats = { 'sauvegarde' }, color = 0x7be0a4 },
    { key = 'security', label = 'Sécurité du panel', cats = { 'securite' }, color = 0xff5c6c },
    { key = 'restart', label = 'Redémarrages et maintenance', cats = {}, color = 0xffd166 },
    { key = 'alerts', label = 'Alertes anti-duplication', cats = {}, color = 0xff5c6c },
    { key = 'tickets', label = 'Tickets des joueurs', cats = {}, color = 0x6fb4ff },
    { key = 'shop', label = 'Boutique (coins)', cats = { 'boutique' }, color = 0xf5c542 },
    { key = 'status', label = 'Statut du serveur (un message tenu à jour)', cats = {}, color = 0x4fd18b },
}
local byKey, byCat = {}, {}
for _, c in ipairs(D.Channels) do
    byKey[c.key] = c
    for _, cat in ipairs(c.cats) do byCat[cat] = c.key end
end
function D.ChannelFor(cat) return byCat[cat] end
function D.Channel(key) return byKey[key] end

local function secretName(key) return 'dc_wh_' .. key end
function D.WebhookSource(key) return PB.Secret.Source(secretName(key)) end
function D.WebhookMask(key) return PB.Secret.Mask(secretName(key)) end

function D.SetWebhook(key, url, actor)
    if not byKey[key] then return false, 'Canal inconnu.' end
    if url ~= nil and url ~= '' and not url:match('^https://[%w%.]*discord%.com/api/webhooks/%d+/[%w_%-]+$') and not url:match('^https://[%w%.]*discordapp%.com/api/webhooks/%d+/[%w_%-]+$') then
        return false, "URL de webhook Discord invalide (https://discord.com/api/webhooks/ID/JETON)."
    end
    return PB.Secret.Set(secretName(key), url, actor)
end

-- File d'attente ------------------------------------------------------------------------------------------------------
local queues, running = {}, {}
D.Stats = { sent = 0, failed = 0, dropped = 0, lastError = nil }

local function post(url, body, cb)
    if not PerformHttpRequest then if cb then cb(0, 'HTTP indisponible') end return end
    PerformHttpRequest(url, function(status, text, headers)
        if cb then cb(status, text, headers) end
    end, 'POST', PB.Json(body), { ['Content-Type'] = 'application/json' })
end

local function pump(key)
    if running[key] then return end
    running[key] = true
    CreateThread(function()
        while queues[key] and #queues[key] > 0 do
            local job = table.remove(queues[key], 1)
            local url = PB.Secret.Get(secretName(key))
            if url then
                local done, status, text, headers = false, 0, '', nil
                post(url, job.body, function(s, t, h) done = true status, text, headers = s, t, h end)
                local waited = 0
                while not done and waited < 15000 do Wait(100) waited = waited + 100 end
                if status == 429 then
                    local retry = tonumber((PB.FromJson(text, {}) or {}).retry_after) or 2
                    job.tries = (job.tries or 0) + 1
                    if job.tries < 4 then table.insert(queues[key], 1, job) end
                    Wait(math.floor(retry * 1000) + 200)
                elseif status >= 200 and status < 300 then
                    D.Stats.sent = D.Stats.sent + 1
                    if job.cb then pcall(job.cb, true, status) end
                    Wait(1100)
                else
                    D.Stats.failed = D.Stats.failed + 1
                    D.Stats.lastError = { at = os.time(), key = key, status = status }
                    if job.cb then pcall(job.cb, false, status, text) end
                    if status >= 500 or status == 0 then
                        job.tries = (job.tries or 0) + 1
                        if job.tries < 3 then table.insert(queues[key], 1, job) Wait(3000) end
                    end
                    Wait(1100)
                end
            else
                if job.cb then pcall(job.cb, false, 0, 'Aucun webhook configuré.') end
            end
        end
        running[key] = nil
    end)
end

-- embed : { title, description, color, fields = { {name,value,inline} }, footer }
function D.Send(key, embed, cb)
    local ch = byKey[key]
    if not ch then if cb then cb(false, 0, 'Canal inconnu.') end return false end
    if not PB.Cfg.Get('discord', 'enabled', true) then if cb then cb(false, 0, 'Discord désactivé.') end return false end
    local cfg = PB.Cfg.Get('discord', 'channels', {})[key] or {}
    if cfg.enabled == false then if cb then cb(false, 0, 'Canal désactivé.') end return false end
    if not PB.Secret.Get(secretName(key)) then if cb then cb(false, 0, 'Aucun webhook configuré.') end return false end
    embed = embed or {}
    embed.color = embed.color or ch.color
    embed.timestamp = embed.timestamp or os.date('!%Y-%m-%dT%H:%M:%SZ')
    embed.footer = embed.footer or { text = PB.Cfg.Get('general', 'server_name', 'Panel') }
    if embed.description and #embed.description > 3800 then embed.description = embed.description:sub(1, 3800) .. '…' end
    for _, f in ipairs(embed.fields or {}) do
        f.name = tostring(f.name):sub(1, 250) f.value = tostring(f.value):sub(1, 1000)
        if f.value == '' then f.value = '—' end
    end
    local body = {
        username = (function() local u = PB.Cfg.Get('discord', 'username', 'Panel') if u == '' or u == 'Panel' then u = PB.Cfg.Get('general', 'server_name', 'Panel') end return u end)(),
        embeds = { embed },
        allowed_mentions = { parse = {} },
    }
    local av = PB.Cfg.Get('discord', 'avatar', '')
    if av ~= '' then body.avatar_url = av end
    if cfg.mention and cfg.mention ~= '' and cfg.mention:match('^[%d]+$') then
        body.content = '<@&' .. cfg.mention .. '>'
        body.allowed_mentions = { roles = { cfg.mention } }
    end
    queues[key] = queues[key] or {}
    if #queues[key] >= 200 then table.remove(queues[key], 1) D.Stats.dropped = D.Stats.dropped + 1 end
    queues[key][#queues[key] + 1] = { body = body, cb = cb }
    pump(key)
    return true
end

function D.QueueSize()
    local n = 0
    for _, q in pairs(queues) do n = n + #q end
    return n
end

-- Envoi de test synchrone (retourne ok, message).
function D.Test(key)
    local p = promise.new()
    local sent = D.Send(key, { title = 'Test du panel', description = 'Si tu vois ce message, le webhook fonctionne.' }, function(ok, status, text) p:resolve({ ok, status, text }) end)
    if not sent then return false, 'Envoi impossible : webhook absent ou canal désactivé.' end
    local r = Citizen.Await(p)
    if r[1] then return true end
    return false, 'Discord a répondu ' .. tostring(r[2]) .. (r[2] == 404 and ' (webhook supprimé ?)' or (r[2] == 401 and ' (jeton invalide)' or ''))
end

-- Journal d'audit -> Discord -----------------------------------------------------------------------------------------------
local function short(v)
    if v == nil or v == '' then return nil end
    local s = type(v) == 'string' and v or PB.Json(v)
    if #s > 400 then s = s:sub(1, 400) .. '…' end
    return '```' .. s:gsub('```', "'''") .. '```'
end

PB.Audit.OnEntry(function(row)
    local key = byCat[row.cat]
    if not key then return end
    if (key == 'crash' and not PB.Cfg.Get('discord', 'alert_crash', true))
        or (key == 'security' and not PB.Cfg.Get('discord', 'alert_security', true))
        or (key == 'backup' and not PB.Cfg.Get('discord', 'alert_backup', true)) then return end
    local fields = {
        { name = 'Auteur', value = row.actor or '—', inline = true },
        { name = 'Cible', value = row.target ~= '' and row.target or '—', inline = true },
    }
    if row.before then fields[#fields + 1] = { name = 'Avant', value = short(row.before) or '—' } end
    if row.after then fields[#fields + 1] = { name = 'Après', value = short(row.after) or '—' } end
    D.Send(key, { title = row.action, fields = fields })
end)

-- API du bot ---------------------------------------------------------------------------------------------------------------------
function D.BotToken() return PB.Secret.Get('discord_bot_token') end

function D.Api(method, path, body, cb)
    local token = D.BotToken()
    if not token then if cb then cb(0, 'Jeton du bot absent.') end return false end
    PerformHttpRequest('https://discord.com/api/v10' .. path, function(status, text) if cb then cb(status, text) end end, method,
        body and PB.Json(body) or '', { ['Content-Type'] = 'application/json', ['Authorization'] = 'Bot ' .. token })
    return true
end

function D.ApiSync(method, path, body)
    local p = promise.new()
    if not D.Api(method, path, body, function(s, t) p:resolve({ s, t }) end) then return nil, 'Jeton du bot absent.' end
    local r = Citizen.Await(p)
    if r[1] < 200 or r[1] >= 300 then return nil, 'Discord a répondu ' .. tostring(r[1]) end
    return PB.FromJson(r[2], nil) or {}
end

function D.GuildRoles()
    local gid = PB.Cfg.Get('discord', 'guild_id', '')
    if gid == '' or not gid:match('^%d+$') then return nil, 'Identifiant du serveur Discord non renseigné.' end
    return D.ApiSync('GET', '/guilds/' .. gid .. '/roles')
end

function D.MemberRoles(discordId)
    local gid = PB.Cfg.Get('discord', 'guild_id', '')
    if gid == '' or not tostring(discordId):match('^%d+$') then return nil end
    local m = D.ApiSync('GET', '/guilds/' .. gid .. '/members/' .. discordId)
    return m and m.roles or nil
end

-- Synchronisation des rôles Discord -> grades (à la connexion, si activée) ----------------------------------------------------------
function D.SyncPlayer(src)
    if not PB.Cfg.Get('discord', 'role_sync', false) or not D.BotToken() then return end
    local license, discord
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
        if id:sub(1, 8) == 'license:' then license = id elseif id:sub(1, 8) == 'discord:' then discord = id:sub(9) end
    end
    if not license or not discord or PB.Perm.IsOwner(src) then return end
    local roles = D.MemberRoles(discord)
    if not roles then return end
    local map = PB.Cfg.Get('discord', 'role_map', {})
    local best, bestLevel
    for _, r in ipairs(roles) do
        local g = map[r] and PB.Perm.Grade(map[r])
        if g and (not bestLevel or g.level > bestLevel) then best, bestLevel = g.name, g.level end
    end
    local cur = PB.Perm.GradeOf(license)
    if best and best ~= cur then
        PB.Perm.SetStaff(0, license, GetPlayerName(src), best)
        PB.DB.exec("UPDATE pb_staff SET added_by = 'discord' WHERE identifier = ?", { license })
    elseif not best and cur then
        local row = PB.DB.one('SELECT added_by FROM pb_staff WHERE identifier = ?', { license })
        if row and row.added_by == 'discord' then PB.Perm.SetStaff(0, license, GetPlayerName(src), nil) end
    end
end

AddEventHandler('playerJoining', function()
    local src = source
    CreateThread(function() Wait(4000) pcall(D.SyncPlayer, src) end)
end)

function D.Caps()
    local hasBot = D.BotToken() ~= nil
    return PB.Capsify({
        { 'Webhooks (envoi de messages)', PB.Env.http and 'ok' or 'off', PB.Env.http and nil or 'PerformHttpRequest indisponible.' },
        { 'File d\'attente et nouvelles tentatives', 'ok', 'Une requête par seconde et par webhook, reprise après limite de débit.' },
        { 'Rôles Discord → grades', hasBot and 'ok' or 'partial', hasBot and 'Appliqué à la connexion du joueur si activé.' or 'Nécessite le jeton du bot et l\'identifiant du serveur Discord.' },
        { 'Whitelist par rôle Discord', 'off', "Non fourni : la whitelist dépend de ton framework ou d'une ressource dédiée." },
        { 'Commandes slash du bot', 'off', "Le panel ne lance pas de bot permanent : il utilise l'API Discord à la demande." },
    })
end
