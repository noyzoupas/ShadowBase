-- Redémarrer pb_panel seul : le serveur arrête d'abord les ressources qui en dépendent (portes, activités…) mais ne les relance jamais.
-- On note celles qui viennent de s'arrêter avec nous, et on les relance une fois le panel prêt.
-- Une ressource arrêtée à la main plus tôt reste arrêtée ; après un arrêt complet du serveur, c'est server.cfg qui décide.
local SELF = GetCurrentResourceName()
local KEY = 'pb_relaunch'
local WINDOW_MS, MAX_AGE_S = 3000, 30
local stoppedAt = {}
local R = {}
PB.Relaunch = R

local function dependsOnMe(name)
    for i = 0, (GetNumResourceMetadata(name, 'dependency') or 0) - 1 do
        if GetResourceMetadata(name, 'dependency', i) == SELF then return true end
    end
    return false
end

function R.Noted(name, now) stoppedAt[name] = now end
function R.Save(now, at)
    local list = {}
    for name, t in pairs(stoppedAt) do
        if now - t < WINDOW_MS and dependsOnMe(name) then list[#list + 1] = name end
    end
    table.sort(list)
    if #list > 0 then SetResourceKvp(KEY, json.encode({ at = at, list = list })) end
    return list
end
function R.Pending(at)
    local raw = GetResourceKvpString(KEY)
    if not raw or raw == '' then return {} end
    DeleteResourceKvp(KEY)
    local ok, d = pcall(json.decode, raw)
    if not ok or type(d) ~= 'table' or type(d.list) ~= 'table' or at - (tonumber(d.at) or 0) > MAX_AGE_S then return {} end
    return d.list
end
function R.Start(list)
    local n = 0
    for _, name in ipairs(list) do
        if GetResourceState(name) == 'stopped' then
            if not StartResource(name) then ExecuteCommand('ensure ' .. name) end
            n = n + 1
        end
    end
    return n
end

AddEventHandler('onResourceStop', function(res)
    if res ~= SELF then R.Noted(res, GetGameTimer()) return end
    R.Save(GetGameTimer(), os.time())
end)
PB.OnReady(function()
    local list = R.Pending(os.time())
    if #list == 0 then return end
    SetTimeout(1500, function()
        local n = R.Start(list)
        if n > 0 then print(('[pb_panel] %d ressource(s) relancée(s) après le redémarrage du panel.'):format(n)) end
    end)
end)
