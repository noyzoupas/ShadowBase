-- Extensions : API pour brancher une AUTRE ressource sur Shadow Base (pages du panel, réglages, actions, permissions, tables SQL).
-- Chaque ressource FiveM a sa propre mémoire Lua : une extension ne voit pas les tables PB.* ; elle passe par ces exports.
-- Les fonctions données par l'extension (build, action, after) sont appelées à travers les ressources : elles reçoivent des copies,
-- donc elles RENVOIENT leurs résultats au lieu de modifier ctx. Quand l'extension s'arrête, tout ce qu'elle a enregistré est retiré.
--
-- Dans le fxmanifest de l'extension :  dependency 'pb_panel'
-- Puis côté serveur (exemple complet : resources/[w-base]/wb_metiers) :
--   local W = exports.pb_panel
--   W:ExtRegister({ label = 'Métiers de récolte', version = '1.0.0' })
--   W:ExtPerm('wb_metiers.edit', 'Modifier les métiers de récolte', true)
--   local form = W:ExtSettings({ ns = 'wb_metiers', id = 'main', title = 'Réglages', perm = 'wb_metiers.edit', fields = { ... } })
--   W:ExtModule({ id = 'wb_metiers', label = 'Métiers', icon = 'tool', perm = 'wb_metiers.edit', tabs = { { id = 'main', label = 'Réglages', form = form } } })
--   W:ExtAction('wb_metiers.reset', 'wb_metiers.edit', function(actor, payload) return true, nil, { toast = 'Fait.' } end)

PB.Ext = PB.Ext or { list = {}, byRes = {} }
local X = PB.Ext
local P = PB.Perm

P.Register('ext.view', 'Voir les extensions installées', 'panel')

-- La ressource qui appelle l'export (nil si appel interne) ---------------------------------------------------------------------------------------
local function caller()
    local r = GetInvokingResource and GetInvokingResource() or nil
    if not r or r == GetCurrentResourceName() then return nil end
    return r
end
local function entry(res)
    local e = X.byRes[res]
    if not e then
        e = { res = res, label = res, version = '', modules = {}, actions = {}, forms = {}, ns = {}, migrations = {}, perms = {}, at = os.time() }
        X.byRes[res] = e
        X.list[#X.list + 1] = e
    end
    return e
end
-- une extension ne peut écrire que dans ses propres espaces : son nom de ressource, ou « nom.quelquechose »
local function owns(res, name)
    name = tostring(name or '')
    return name == res or name:sub(1, #res + 1) == res .. '.' or name:sub(1, #res + 1) == res .. '_'
end
local function info(ctx)
    return { src = ctx.src, name = ctx.actor and ctx.actor.name or '?', license = ctx.license, grade = ctx.grade, gradeLabel = ctx.gradeLabel, level = ctx.level }
end
-- Form.Cfg et PB.Module réenregistrent la permission avec leur propre libellé : on remet celui déclaré par l'extension (et son caractère sensible)
local function keepPerms(e) for perm, d in pairs(e.perms) do P.Register(perm, d.label, e.res, d.danger) end end
local function fail(res, what, err) PB.Warn(('extension %s : %s — %s'):format(tostring(res), what, tostring(err))) return false, err end

-- Déclaration ---------------------------------------------------------------------------------------------------------------------------------------
exports('ExtRegister', function(meta)
    local res = caller()
    if not res then return false end
    local e = entry(res)
    meta = type(meta) == 'table' and meta or {}
    e.label = tostring(meta.label or res):sub(1, 48)
    e.version = tostring(meta.version or GetResourceMetadata(res, 'version', 0) or ''):sub(1, 16)
    e.at = os.time()
    PB.Log(('extension branchée : %s (%s %s)'):format(e.label, res, e.version))
    return true
end)

exports('ExtReady', function() return PB.IsReady == true end)

exports('ExtPerm', function(perm, label, danger)
    local res = caller()
    if not res then return false end
    if not owns(res, perm) then return fail(res, 'permission ' .. tostring(perm), 'doit commencer par « ' .. res .. '. »') end
    local e = entry(res)
    e.perms[perm] = { label = tostring(label or perm):sub(1, 120), danger = danger and true or false }
    keepPerms(e)
    return true
end)

-- Réglages : formulaire du panel, stocké en base, historisé et annulable comme ceux du cœur -----------------------------------------------------
exports('ExtSettings', function(def)
    local res = caller()
    if not res or type(def) ~= 'table' or type(def.fields) ~= 'table' then return false end
    if not owns(res, def.ns) then return fail(res, 'réglages ' .. tostring(def.ns), 'l\'espace doit être « ' .. res .. ' » ou commencer par « ' .. res .. '. »') end
    local id = tostring(def.id or 'main')
    if not id:match('^[%w_]+$') then return fail(res, 'réglages', 'identifiant invalide') end
    local e = entry(res)
    local userAfter = def.after
    local fdef = { ns = def.ns, id = id, title = def.title, desc = def.desc, perm = def.perm, cols = def.cols, restart = def.restart, fields = def.fields }
    if userAfter then
        fdef.after = function(changed, values, ctx)
            local ok, r = pcall(userAfter, changed, values, info(ctx))
            if ok then return r end
        end
    end
    local key = def.ns .. '.' .. id
    if e.forms[key] then PB.ActionRemove('cfg.' .. key) end
    e.forms[key] = PB.Form.Cfg(fdef)
    keepPerms(e)
    -- les changements sont annoncés à toutes les ressources : AddEventHandler('pb_panel:cfgChanged', function(ns, key) ... end)
    if not e.ns[def.ns] then
        e.ns[def.ns] = true
        PB.Cfg.OnChange(def.ns, function(k) TriggerEvent('pb_panel:cfgChanged', def.ns, k) end)
    end
    return key
end)

-- Lecture de la configuration : tout espace (ex. 'menus' pour reprendre les couleurs) ; écriture : seulement les siens
exports('CfgGet', function(ns, k, default) return PB.Cfg.Get(tostring(ns), tostring(k), default) end)
exports('CfgAll', function(ns) return PB.Cfg.All(tostring(ns)) or {} end)
exports('CfgSet', function(ns, k, v, actor, reason)
    local res = caller()
    if res and not owns(res, ns) then return fail(res, 'CfgSet ' .. tostring(ns), 'espace d\'une autre ressource') end
    return PB.Cfg.Set(tostring(ns), tostring(k), v, actor or res or 'script', reason or 'Extension')
end)

-- Actions : boutons du panel (ou formulaires) -> fonction de l'extension. Droits, limite de débit, confirmation et journal : comme le cœur.
-- fn(actor, payload) -> ok, data_ou_erreur, { toast =, refresh =, close = }
exports('ExtAction', function(name, perm, fn, opts)
    local res = caller()
    if not res or type(name) ~= 'string' then return false end
    if not owns(res, name) then return fail(res, 'action ' .. name, 'doit commencer par « ' .. res .. '. »') end
    if fn == nil then return fail(res, 'action ' .. name, 'fonction manquante') end
    local e = entry(res)
    opts = type(opts) == 'table' and opts or {}
    PB.Action(name, type(perm) == 'string' and perm or nil, function(ctx, p)
        local ok, a, b = fn(info(ctx), p)
        if type(b) == 'table' then
            if b.toast ~= nil then ctx.toast = tostring(b.toast) end
            if b.refresh ~= nil then ctx.refresh = b.refresh and true or false end
            if b.close then ctx.close = true end
        end
        return ok, a
    end, { critical = opts.critical, pin = opts.pin, read = opts.read, rate = tonumber(opts.rate), audit = opts.audit or res,
        confirm = type(opts.confirm) == 'table' and { title = tostring(opts.confirm.title or ''), text = tostring(opts.confirm.text or '') } or nil })
    e.actions[name] = true
    return true
end)

-- Pages du panel ------------------------------------------------------------------------------------------------------------------------------------
-- def : id, label, icon, group, order, perm, hint, doc, caps = { { 'libellé', 'ok'|'partial'|'off', 'texte' } },
--       tabs = { { id, label, icon, form = <clé renvoyée par ExtSettings> } | { id, label, icon, build = function(actor) return { blocs } end } }
exports('ExtModule', function(def)
    local res = caller()
    if not res or type(def) ~= 'table' or type(def.tabs) ~= 'table' then return false end
    if not owns(res, def.id) then return fail(res, 'page ' .. tostring(def.id), 'doit être « ' .. res .. ' » ou commencer par « ' .. res .. '. »') end
    local e = entry(res)
    if PB.Modules.byId[def.id] then X.RemoveModule(def.id) end
    local tabs = def.tabs
    local caps = type(def.caps) == 'table' and def.caps or nil
    PB.Module({
        id = def.id, label = tostring(def.label or def.id), icon = def.icon or 'puzzle', group = def.group or 'Extensions', order = tonumber(def.order) or 500,
        perm = def.perm, hint = def.hint, doc = def.doc, ext = res,
        caps = caps and function() return PB.Capsify(caps) end or nil,
        view = function(ctx)
            local out = {}
            for _, t in ipairs(tabs) do
                local tab = { id = t.id, label = t.label, icon = t.icon }
                tab.build = function()
                    if t.form then
                        local f = e.forms[t.form]
                        if not f then return { PB.B.notice('warn', 'Formulaire introuvable : ' .. tostring(t.form)) } end
                        return { f(ctx) }
                    end
                    if t.build then
                        local ok, blocks = pcall(t.build, info(ctx))
                        if not ok then
                            PB.Err(('extension %s, onglet %s : %s'):format(res, tostring(t.id), tostring(blocks)))
                            return { PB.B.notice('error', "Cet onglet a planté (voir la console du serveur).", 'Extension ' .. res) }
                        end
                        return type(blocks) == 'table' and blocks or {}
                    end
                    return type(t.blocks) == 'table' and t.blocks or {}
                end
                out[#out + 1] = tab
            end
            return { tabs = out }
        end,
    })
    e.modules[def.id] = true
    keepPerms(e)
    return true
end)

-- Tables SQL de l'extension : appliquées une seule fois (comme les migrations du cœur), même après le démarrage --------------------------------------
exports('ExtMigrate', function(id, label, steps)
    local res = caller()
    if not res or type(id) ~= 'string' or type(steps) ~= 'table' then return false end
    if not owns(res, id) then return fail(res, 'migration ' .. id, 'doit commencer par « ' .. res .. '_ » ou « ' .. res .. '. »') end
    if not PB.IsReady then return fail(res, 'migration ' .. id, 'base pas encore prête : attends ExtReady() ou l\'évènement pb_panel:ready') end
    entry(res).migrations[id] = true
    if PB.DB.one('SELECT id FROM pb_migrations WHERE id = ?', { id }) then return true end
    for _, sql in ipairs(steps) do
        local _, err = PB.DB.exec(tostring(sql):find('^%s*CREATE TABLE') and PB.Table(tostring(sql)) or tostring(sql))
        if err then return fail(res, 'migration ' .. id, err) end
    end
    PB.DB.exec('INSERT INTO pb_migrations (id, name) VALUES (?, ?)', { id, tostring(label or id):sub(1, 128) })
    PB.Log(('migration %s appliquée (%s)'):format(id, res))
    return true
end)

-- Petites aides de jeu absentes des exports historiques ------------------------------------------------------------------------------------------------
exports('NotifyPlayer', function(src, kind, title, text)
    if not PB.G or not PB.G.Notify then return false end
    PB.G.Notify(tonumber(src), { type = tostring(kind or 'info'), title = tostring(title or ''), text = tostring(text or '') })
    return true
end)
-- Paiement : renvoie le compte débité ('cash' | 'bank') ou false. prefer = 'cash' | 'bank'
exports('Pay', function(src, amount, prefer, reason)
    if not PB.G or not PB.G.Pay then return false end
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false end
    local acc = PB.G.Pay(tonumber(src), amount, prefer == 'bank' and 'bank' or 'cash')
    if acc and PB.G.Eco and PB.G.Eco.Book then
        local p = PB.G.Get(tonumber(src))
        pcall(PB.G.Eco.Book, 'state', amount, tostring(reason or caller() or 'Extension'):sub(1, 60), p and p.license)
    end
    return acc or false
end)
exports('DistTo', function(src, x, y, z) return PB.G and PB.G.DistTo and PB.G.DistTo(tonumber(src), tonumber(x), tonumber(y), tonumber(z)) or 99999 end)
-- Le joueur peut-il faire une activité ? (personnage créé, vivant, pas menotté, pas en prison)
exports('CanAct', function(src)
    src = tonumber(src)
    if PB.License and PB.License.Locked then return false end   -- (v1.2.82) sans licence valide, aucune activité des ressources liées
    local G = PB.G
    local p = G and G.Get and G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) then return false end
    if G.IsCuffed and G.IsCuffed(src) then return false end
    if G.IsJailed and G.IsJailed(src) then return false end
    return true
end)
exports('GetLicense', function(src) return P.GetLicense(tonumber(src)) end)
-- Entreprises et groupes illégaux existants : { biz = { { id, label } }, gangs = { { id, label } } }
exports('ListOrgs', function()
    local out = { biz = {}, gangs = {} }
    for _, b in ipairs(PB.G and PB.G.Biz and PB.G.Biz.List() or {}) do out.biz[#out.biz + 1] = { id = b.id, label = b.label } end
    for id, d in pairs(PB.G and PB.G.Tags and PB.G.Tags.GangDefs() or {}) do out.gangs[#out.gangs + 1] = { id = id, label = d.label or id } end
    table.sort(out.gangs, function(a, b) return a.label < b.label end)
    return out
end)
-- Fiche d'un objet de l'inventaire : { name, label, weight, image } ou nil
exports('ItemInfo', function(name)
    local d = PB.G and PB.G.Inv and PB.G.Inv.Def(tostring(name or ''))
    if not d then return nil end
    return { name = d.name or name, label = d.label or name, weight = tonumber(d.weight) or 0, image = d.image or '' }
end)

-- Nettoyage quand une extension s'arrête (ses fonctions n'existent plus) ------------------------------------------------------------------------------
function X.RemoveModule(id)
    local m = PB.Modules.byId[id]
    if not m then return end
    PB.Modules.byId[id] = nil
    for i = #PB.Modules.list, 1, -1 do if PB.Modules.list[i].id == id then table.remove(PB.Modules.list, i) end end
end
AddEventHandler('onResourceStop', function(res)
    local e = X.byRes[res]
    if not e then return end
    for id in pairs(e.modules) do X.RemoveModule(id) end
    for name in pairs(e.actions) do PB.ActionRemove(name) end
    for key in pairs(e.forms) do PB.ActionRemove('cfg.' .. key) end
    e.modules, e.actions, e.forms = {}, {}, {}
    e.stopped = os.time()
    PB.Log('extension débranchée : ' .. res)
end)

-- Page « Extensions » ---------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'extensions', label = 'Extensions', icon = 'puzzle', group = 'Serveur', order = 152, perm = 'ext.view', hint = 'Ressources branchées sur Shadow Base',
    doc = "## Extensions\nUne extension est une ressource à part (ex. `wb_metiers`) qui se branche sur Shadow Base : elle ajoute ses pages au panel, ses réglages et ses actions. Elle se redémarre seule (`restart wb_metiers`) sans toucher au reste.\n\nPour en écrire une : voir `server/core/ext.lua` (exemple en tête du fichier) et la ressource `wb_metiers`.",
    view = function()
        return { tabs = { { id = 'list', label = 'Installées', icon = 'puzzle', build = function()
            local rows = {}
            for _, e in ipairs(X.list) do
                local n = function(t) local c = 0 for _ in pairs(t) do c = c + 1 end return c end
                local state = GetResourceState(e.res)
                rows[#rows + 1] = { label = e.label, res = e.res, version = e.version, state = state == 'started' and 'Démarrée' or state, pages = n(e.modules), actions = n(e.actions) + n(e.forms), at = e.at }
            end
            return { PB.B.notice('info', "Les extensions apparaissent ici dès qu'elles démarrent (ensure dans server.cfg, après pb_panel)."),
                PB.B.table({ id = 'exts', title = 'Extensions (' .. #rows .. ')', columns = { { k = 'label', label = 'Nom' }, { k = 'res', label = 'Ressource' }, { k = 'version', label = 'Version' }, { k = 'state', label = 'État' },
                    { k = 'pages', label = 'Pages' }, { k = 'actions', label = 'Actions' }, { k = 'at', label = 'Branchée', type = 'date' } }, rows = rows, empty = 'Aucune extension.' }) }
        end } } }
    end,
})
