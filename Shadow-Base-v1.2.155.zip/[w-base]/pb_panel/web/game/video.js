/* (v1.2.78) Diffusion vidéo du fondateur : une vidéo YouTube en plein écran, la même pour tout le monde au même moment.
   Rien ne la ferme côté joueur (Échap ne fait rien) : seul le fondateur l'arrête, ou la fin de la vidéo. Chacun règle son volume.
   Envois : video.vol { v }, video.ended { id }. Le lecteur YouTube (iframe_api) est chargé à la première diffusion. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
let box = null, player = null, curId = null, apiReady = null, vol = 50;
const STACK = { id: 'video', onEscape: () => {} };

function api() {
  if (apiReady) return apiReady;
  apiReady = new Promise((ok) => {
    if (window.YT && window.YT.Player) { ok(); return; }
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => { if (prev) try { prev(); } catch (e) { /* rien */ } ok(); };
    const s = document.createElement('script');
    s.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(s);
  });
  return apiReady;
}
function host() {
  if (box) return box;
  box = h('div', { id: 'g-video', class: 'hidden' });
  G.root.appendChild(box);
  return box;
}
function close() {
  try { if (player && player.destroy) player.destroy(); } catch (e) { /* rien */ }
  player = null; curId = null;
  if (box) { G.clear(box); box.classList.add('hidden'); }
  G.uiStack = G.uiStack.filter((u) => u !== STACK);
}
function setVol(v, save) {
  vol = Math.max(0, Math.min(100, Math.round(Number(v) || 0)));
  try { if (player && player.setVolume) { player.setVolume(vol); if (vol === 0) player.mute(); else player.unMute(); } } catch (e) { /* rien */ }
  if (save) G.post('video.vol', { v: vol });
}

G.on('video.open', (d) => {
  if (!d || !/^[A-Za-z0-9_-]{11}$/.test(d.id || '')) return;
  if (Number(d.vol) > 0) vol = Math.max(0, Math.min(100, Number(d.vol) - 1));
  const b = host();
  const at = Math.max(0, Math.floor(Number(d.at) || 0));
  if (curId === d.id && player) { try { player.seekTo(at, true); } catch (e) { /* rien */ } return; }
  close();
  curId = d.id;
  b.classList.remove('hidden');
  G.uiStack.push(STACK);
  const frame = h('div', { id: 'g-video-yt' });
  const lab = h('b', null, vol + ' %');
  const range = h('input', { type: 'range', min: '0', max: '100', step: '1', value: String(vol), class: 'gvd-range' });
  range.addEventListener('input', () => { lab.textContent = range.value + ' %'; setVol(range.value, false); });
  range.addEventListener('change', () => setVol(range.value, true));
  const bar = h('div', { class: 'gvd-bar' },
    h('span', { class: 'gvd-live' }, h('i'), 'Diffusion du staff'), d.by ? h('small', null, 'par ' + String(d.by).slice(0, 40)) : null,
    h('div', { class: 'gvd-vol' }, ico('music'), range, lab),
    d.stop ? h('button', { type: 'button', class: 'gvd-stop', onclick: () => G.post('video.stop', {}) }, ico('x'), 'Arrêter pour tout le monde') : null);
  b.appendChild(h('div', { class: 'gvd' }, h('div', { class: 'gvd-screen' }, frame), bar));
  api().then(() => {
    if (curId !== d.id) return;
    player = new window.YT.Player('g-video-yt', {
      videoId: d.id, width: '100%', height: '100%',
      playerVars: { autoplay: 1, controls: 0, disablekb: 1, fs: 0, rel: 0, modestbranding: 1, playsinline: 1, iv_load_policy: 3, start: at, origin: location.origin },
      events: {
        onReady: (e) => { setVol(vol, false); try { e.target.seekTo(at, true); e.target.playVideo(); } catch (x) { /* rien */ } },
        onStateChange: (e) => { if (e.data === 0) { const id = curId; let dur = 0; try { dur = Math.floor(e.target.getDuration() || 0); } catch (x) { /* rien */ } G.post('video.ended', { id, dur }); } },
        onError: () => { const id = curId; G.post('video.ended', { id, err: true }); },
      },
    });
  });
});
G.on('video.close', close);
})();
