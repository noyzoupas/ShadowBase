/* Boutiques à cartes (supérette, armurerie, concession) : catégories en cartes → produits en cartes avec image → confirmation → panier
   → « Envoyer au vendeur » (ou sonnette, puis paiement seul après le délai) → paiement → ticket. Le vendeur a un onglet « Caisse ».
   Le serveur décide de tout (prix, stock, droits, paiement) ; ici on affiche et on relaie. Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const EFFECTS = [['hunger', 'Faim'], ['thirst', 'Soif'], ['stress', 'Stress']];
const good = (k, v) => (k === 'stress' ? v < 0 : v > 0);
const FALLBACK = { dealer: 'img/cards/veh.jpg', store: 'img/items/_item.svg', weapons: 'img/items/_item.svg' };
// Icône d'un article ou d'une catégorie : d'après son type (food, drink…) puis des mots de son nom. Toujours une icône, même sans image.
const KIND_IC = { food: 'food', drink: 'drop', medical: 'heart', tool: 'engine', doc: 'id', weapon: 'gun', ammo: 'ammo', clothes: 'hanger', misc: 'tag' };
const WORD_IC = [[/nourr|manger|food|snack|sandw|burger|repas|boulang|frais|épic/i, 'food'], [/boiss|drink|eau|soda|café|cafe|jus|bière|biere|alcool|vin\b|spirit/i, 'drop'], [/soin|médic|medic|pharm|santé|sante|bandage|trousse/i, 'heart'],
  [/outil|tool|bricol|répar|repar|garage|pièce|piece|kit/i, 'engine'], [/vêt|vet|cloth|habit|mode/i, 'hanger'], [/munit|ammo|cartouche/i, 'ammo'], [/arme|gun|pistol|fusil|couteau|melee|mêlée/i, 'gun'],
  [/véhic|vehic|voiture|auto|moto|bateau|vélo|velo|avion|heli/i, 'car'], [/clé|cle\b|key|serrur/i, 'key'], [/tabac|cigar|fume|vape|briquet/i, 'stress'], [/téléph|telephone|phone|électro|electro|tech|batter/i, 'phone'],
  [/papier|doc|carte|licence|permis/i, 'id'], [/cadeau|gift|loisir|jeu|casino/i, 'gift'], [/animal|croquette|chien|chat\b/i, 'paw']];
function iconFor(kind, cat, label) {
  if (kind && KIND_IC[kind]) return KIND_IC[kind];
  const t = String(cat || '') + ' ' + String(label || '');
  for (let i = 0; i < WORD_IC.length; i++) if (WORD_IC[i][0].test(t)) return WORD_IC[i][1];
  return 'tag';
}
const STATE_L = { sent: 'À encaisser', billed: 'Facturée', paid: 'Payée', refunded: 'Remboursée', cancelled: 'Annulée' };

function shopFlowView(data, opt) {
  opt = opt || {};
  const over = (o) => !!o && (o.state === 'paid' || o.state === 'refunded');   // commande terminée : le serveur la renvoie encore à la réouverture
  const st = { data, view: 'shop', cat: '', q: '', targets: [], target: null, pending: null, cart: [], order: over(data.order) ? null : (data.order || null), orders: data.orders || [], modal: null, cache: {}, waitAt: 0, wait: null, autopay: false, loadingCat: '' };
  const dealer = () => st.data.kind === 'dealer';
  const cash = h('b', null, ''), bank = h('b', null, '');
  const body = h('div', { class: 'sf-body' }), bar = h('div', { class: 'mk-bar sf-bar' }), toast = h('div', { class: 'mk-toast hidden' }), modalBox = h('div', { class: 'sf-modal hidden' });
  const tgLayer = h('div', { class: 'sf-tgl' });
  const cartBtn = h('button', { class: 'sf-cartbtn', title: 'Panier', onclick: () => go('cart') });
  const search = h('input', { class: 'mk-s', type: 'text', placeholder: 'Rechercher…', oninput: (e) => { st.q = e.target.value.trim().toLowerCase(); if (ph) drawPhotoGrid(); else draw(); } });
  search.addEventListener('keydown', (e) => e.stopPropagation());
  const ownLogo = G.assetUrl(st.data.logo || ''), logoUrl = ownLogo || (G.nova && G.nova() ? G.logoUrl() : '');
  const br = (G.cfg && G.cfg.brand) || {};
  const el = h('div', { class: 'mk sf', style: G.season() && /^#[0-9a-fA-F]{6}$/.test(br.color || '') ? { '--acc': br.color } : {} },
    h('header', { class: 'mk-top' },
      h('div', { class: 'mk-ttl' }, logoUrl ? h('img', { src: logoUrl, alt: '', 'data-pblogo': ownLogo ? null : '1' }) : null, h('div', null, G.brandName() ? h('small', { class: 'mk-eb' }, G.brandName()) : null, h('b', null, st.data.label || ''), h('small', null, st.data.tagline || (dealer() ? 'Concession' : 'Boutique')))),
      h('div', { class: 'mk-tr' }, h('span', { class: 'mk-m' }, ico('coins'), cash), h('span', { class: 'mk-m' }, ico('card'), bank), search, cartBtn,
        opt.onClose ? h('button', { class: 'sf-closeb', title: 'Fermer (Échap)', onclick: opt.onClose }, 'Fermer') : null)),
    bar, toast, body, modalBox, tgLayer, G.festEl());

  const say = (ok, msg) => { toast.textContent = msg || ''; toast.className = 'mk-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(say.t); say.t = setTimeout(() => toast.classList.add('hidden'), 3500); };
  const cartCount = () => st.cart.reduce((n, l) => n + l.qty, 0);
  const cartTotal = () => st.cart.reduce((n, l) => n + l.qty * l.price, 0);
  const fallbackOf = (it) => FALLBACK[st.data.kind] || FALLBACK.store;

  // image obligatoire : l'image de l'article, sinon l'illustration par défaut
  function pic(it, cls) {
    const src = G.assetUrl(it.image || '') || fallbackOf(it);
    const im = h('img', { class: 'sf-pic' + (/\.svg(\?|$)/i.test(src) ? ' ill' : ''), alt: '', src, loading: 'lazy' });
    im.addEventListener('error', () => { const f = fallbackOf(it); if (im.getAttribute('src') !== f) { im.setAttribute('src', f); im.classList.toggle('ill', /\.svg$/i.test(f)); } });
    return h('div', { class: 'sf-img' + (cls ? ' ' + cls : '') }, im);
  }
  function tile(o) {
    const out = o.stock !== undefined && o.stock !== null && o.stock <= 0;
    const it = o.item || {};
    return h('button', { class: 'sf-card' + (out ? ' out' : ''), onclick: () => o.onclick && o.onclick(), 'data-id': o.id },
      pic(it), h('span', { class: 'sf-shade' }),
      h('span', { class: 'sf-ic' }, ico(o.icon || iconFor(it.kind || it.type, it.category, it.label || o.title))),
      o.badge ? h('span', { class: 'sf-badge' }, o.badge) : null,
      h('span', { class: 'sf-tx' }, h('b', null, o.title), o.sub ? h('small', null, o.sub) : null, o.price != null ? h('em', null, G.money(o.price)) : null));
  }

  // ---- données ----
  function items() { return dealer() ? (st.cache[st.cat] || (st.data.vehicles ? st.data.vehicles.filter((v) => (v.category || 'Autres') === st.cat) : null)) : (st.data.items || []).filter((it) => st.cat === '' || (it.category || '') === st.cat); }
  function catsList() {
    if (dealer()) return (st.data.cats || []).map((c) => ({ id: c.id, count: c.count, image: c.image }));
    const m = {}, order = [];
    (st.data.items || []).forEach((it) => { const c = it.category || ''; if (!m[c]) { m[c] = { id: c, count: 0, image: it.image }; order.push(c); } m[c].count++; });
    return order.map((c) => m[c]);
  }

  // ---- affichage ----
  function go(v) { st.view = v; st.modal = null; draw(); }
  function drawCartBtn() {
    G.clear(cartBtn);
    cartBtn.appendChild(ico('cart'));
    if (cartCount()) cartBtn.appendChild(h('span', { class: 'sf-n' }, String(cartCount())));
    cartBtn.appendChild(h('b', null, cartCount() ? G.money(cartTotal()) : 'Panier'));
    cartBtn.classList.toggle('on', st.view === 'cart');
  }
  function drawBar() {
    G.clear(bar);
    if (photoMode() && !st.data.clerk) { bar.classList.add('hidden'); return; }
    bar.classList.remove('hidden');
    const tabs = h('div', { class: 'mk-tabs' },
      h('button', { class: 'mk-tab' + (st.view === 'shop' ? ' on' : ''), onclick: () => go('shop') }, ico(dealer() ? 'car' : 'tag'), dealer() ? 'Véhicules' : 'Boutique'));
    if (st.data.clerk) {
      const n = st.orders.filter((o) => o.state === 'sent' || o.state === 'billed').length;
      tabs.appendChild(h('button', { class: 'mk-tab' + (st.view === 'caisse' ? ' on' : ''), onclick: () => go('caisse') }, ico('file'), 'Caisse' + (n ? ' (' + n + ')' : '')));
    }
    bar.appendChild(tabs);
    if (st.view === 'shop' && (st.cat !== '' || (catsList().length < 2 && catsList().length))) {
      const multi = catsList().length >= 2;
      bar.appendChild(h('div', { class: 'sf-crumb' }, multi ? h('button', { class: 'mk-chip', onclick: () => { st.cat = ''; st.q = ''; search.value = ''; draw(); } }, '‹ Catégories') : null, h('b', null, st.cat || (dealer() ? 'Tous les véhicules' : 'Tous les articles'))));
    }
  }
  function drawShop() {
    const cats = catsList();
    if (!cats.length) { body.appendChild(h('div', { class: 'mk-empty' }, 'Ce magasin est vide pour le moment.')); return; }
    const flat = cats.length < 2;
    if (flat && dealer() && st.cat === '') { openCat(cats[0].id); return; }
    if (!flat && st.cat === '' && !st.q) {
      const grid = h('div', { class: 'sf-grid sf-cats' });
      cats.forEach((c) => grid.appendChild(tile({ id: 'cat:' + c.id, item: { image: c.image }, icon: dealer() ? 'car' : iconFor('', c.id, ''), title: c.id || 'Divers', sub: c.count + (dealer() ? ' véhicule' : ' article') + (c.count > 1 ? 's' : ''), onclick: () => openCat(c.id) })));
      body.appendChild(grid);
      return;
    }
    let list = items();
    if (st.q && st.cat === '' && !flat) { list = dealer() ? Object.keys(st.cache).reduce((a, k) => a.concat(st.cache[k]), []) : (st.data.items || []); }
    if (!list) { body.appendChild(h('div', { class: 'mk-empty' }, 'Chargement…')); return; }
    list = list.filter((it) => !st.q || String(it.label).toLowerCase().indexOf(st.q) >= 0 || String(it.desc || '').toLowerCase().indexOf(st.q) >= 0 || String(it.model || it.name || '').toLowerCase().indexOf(st.q) >= 0);
    if (!list.length) { body.appendChild(h('div', { class: 'mk-empty' }, 'Aucun résultat.')); return; }
    const grid = h('div', { class: 'sf-grid' });
    list.forEach((it) => grid.appendChild(tile({ id: it.model || it.name, item: it, title: it.label, price: it.price, stock: it.stock,
      sub: dealer() ? null : (it.stock != null ? (it.stock <= 0 ? 'Épuisé' : 'En stock : ' + it.stock) : null), badge: dealer() ? null : (it.stock != null && it.stock <= 0 ? 'Épuisé' : null),
      onclick: () => { st.modal = { it }; drawModal(); } })));
    body.appendChild(grid);
  }
  function openCat(c) {
    st.cat = c; st.q = ''; search.value = '';
    if (dealer() && !st.data.vehicles && !st.cache[c]) { st.loadingCat = c; G.post('shop.cat', { cat: c }); }
    draw();
  }

  // ---- fiche véhicule (concession) : vitesse, accélération, freinage, adhérence, places, coffre ----
  function vehSheet(it) {
    const bars = [['spd', 'Vitesse max', 'km/h', 300], ['acc', 'Accélération', '', 100], ['brk', 'Freinage', '', 100], ['trc', 'Adhérence', '', 100]];
    const fills = {}, vals = {};
    const barEls = bars.map(([k, l, u, max]) => {
      const f = h('u', { style: { width: '0%' } }), v = h('b', null, '—');
      fills[k] = f; vals[k] = v;
      return h('div', { class: 'vs-bar' }, h('span', null, l), h('i', null, f), v);
    });
    const setBar = (k, val, max, unit) => { if (val == null) return; fills[k].style.width = Math.max(4, Math.min(100, (val / max) * 100)) + '%'; vals[k].textContent = Math.round(val) + (unit ? ' ' + unit : (max === 100 ? '' : '')); };
    setBar('spd', it.spd, 300, 'km/h');
    const real = h('small', { class: 'vs-note' }, it.spd ? 'Valeurs estimées pour la catégorie' : '');
    G.post('shop.vstat', { model: it.model }).then((r) => {
      if (!r || !r.ok || !el.isConnected) return;
      setBar('spd', r.spd, 300, 'km/h'); setBar('acc', r.acc, 100); setBar('brk', r.brk, 100); setBar('trc', r.trc, 100);
      if (r.seats) seatsEl.textContent = String(r.seats);
      real.textContent = 'Valeurs lues dans le jeu';
    }).catch(() => {});
    const seatsEl = h('b', null, it.seats ? String(it.seats) : '—');
    const tile = (icon, label, node, sub) => h('div', { class: 'vs-t' }, ico(icon), h('div', null, h('small', null, label), node, sub ? h('small', null, sub) : null));
    const acts = [h('button', { class: 'mk-b ghost', onclick: () => { G.post('shop.vview', { model: it.model, mode: 'view' }); } }, ico('eye'), 'Visionner')];
    // concession tenue par des joueurs : on regarde et on demande un essai (alerte aux vendeurs) ; la vente se fait avec le vendeur
    if (st.data.showroom) acts.push(h('button', { class: 'mk-b pri', onclick: () => { G.post('shop.testreq', { model: it.model }); } }, ico('car'), 'Demander un essai'));
    else if (st.data.drive_sec) acts.push(h('button', { class: 'mk-b ghost', onclick: () => { G.post('shop.vview', { model: it.model, mode: 'test' }); } }, ico('car'), 'Essayer (' + st.data.drive_sec + ' s)'));
    if (!st.data.showroom) acts.push(h('button', { class: 'mk-b pri', onclick: () => { st.cart = [{ k: it.model, label: it.label, price: it.price, qty: 1, image: it.image, max: 1 }]; st.modal = null; go('cart'); } }, ico('cart'), "Demander l'achat"));
    return h('div', { class: 'sf-dlg vs', role: 'dialog' },
      h('button', { class: 'sf-closeb sf-dx', title: 'Fermer', onclick: () => { st.modal = null; drawModal(); } }, 'Fermer'),
      pic(it, 'sf-big vs-pic'),
      h('div', { class: 'vs-body' },
        h('div', { class: 'vs-head' }, h('div', null, h('small', null, it.category || 'Véhicule'), h('h3', null, it.label)), h('em', null, G.money(it.price))),
        h('div', { class: 'vs-bars' }, barEls),
        real,
        h('div', { class: 'vs-tiles' },
          tile('user', 'Places', seatsEl),
          tile('bag', 'Coffre', h('b', null, it.slots ? it.slots + ' emplacements' : '—'), it.kg ? 'jusqu\'à ' + it.kg + ' kg' : null),
          tile('car', 'Modèle', h('b', null, it.model))),
        h('div', { class: 'sf-acts' }, acts)));
  }

  // ---- fenêtre de confirmation ----
  function drawModal() {
    G.clear(modalBox);
    const m = st.modal;
    modalBox.classList.toggle('hidden', !m);
    if (!m) return;
    if (m.ticket) { modalBox.appendChild(ticketEl(m.ticket)); return; }
    if (dealer()) { modalBox.appendChild(vehSheet(m.it)); return; }
    const it = m.it, out = it.stock != null && it.stock <= 0;
    const maxQ = Math.max(1, Math.min(10, Number(st.data.max_qty) || 10, it.stock == null ? 99 : Math.max(1, it.stock)));
    let q = 1;
    const qEl = h('b', null, '1'), pEl = h('b', { class: 'sf-mp' }, G.money(it.price));
    const upd = () => { qEl.textContent = String(q); pEl.textContent = G.money(it.price * q); };
    const chips = EFFECTS.filter(([k]) => it[k]).map(([k, l]) => h('span', { class: 'sh-chip ' + (good(k, it[k]) ? 'up' : 'bad') }, (it[k] > 0 ? '+' : '') + it[k] + ' ' + l));
    const stats = it.type === 'weapon' ? [['dmg', 'Dégâts'], ['range', 'Portée'], ['rate', 'Cadence'], ['mag', 'Chargeur']].map(([k, l]) => h('div', { class: 'mk-st' }, h('span', null, l), h('i', null, h('u', { style: { width: Math.max(4, Math.min(100, it[k] || 0)) + '%' } })))) : [];
    const acts = [];
    if (dealer()) {
      acts.push(h('button', { class: 'mk-b ghost', onclick: () => { G.post('shop.vview', { model: it.model, mode: 'view' }); } }, ico('eye'), 'Visionner'));
      if (st.data.drive_sec) acts.push(h('button', { class: 'mk-b ghost', onclick: () => { G.post('shop.vview', { model: it.model, mode: 'test' }); } }, ico('car'), 'Essayer (' + st.data.drive_sec + ' s)'));
      acts.push(h('button', { class: 'mk-b pri', onclick: () => { st.cart = [{ k: it.model, label: it.label, price: it.price, qty: 1, image: it.image, max: 1 }]; st.modal = null; go('cart'); } }, ico('cart'), "Demander l'achat"));
    } else {
      if (!(it.vip && st.data.is_vip === false) && it.type === 'weapon' && st.data.test_sec && it.test !== false) acts.push(h('button', { class: 'mk-b ghost', onclick: () => opt.onTest && opt.onTest(it) }, 'Tester (' + st.data.test_sec + ' s)'));
      if (st.data.restock && opt.onRestock) acts.push(h('button', { class: 'mk-b ghost', onclick: () => opt.onRestock(it, 10) }, '+10 en stock'));
      acts.push(h('button', { class: 'mk-b pri', disabled: out || null, onclick: () => addToCart(it, q) }, ico('cart'), out ? 'Épuisé' : 'Ajouter au panier'));
    }
    modalBox.appendChild(h('div', { class: 'sf-dlg', role: 'dialog' },
      h('button', { class: 'sf-closeb sf-dx', title: 'Fermer', onclick: () => { st.modal = null; drawModal(); } }, 'Fermer'),
      pic(it, 'sf-big'),
      h('div', { class: 'sf-dt' }, h('b', null, it.label), dealer() ? h('small', null, [it.category, it.model].filter(Boolean).join(' · ')) : (it.desc ? h('small', null, it.desc) : null),
        chips.length ? h('div', { class: 'mk-chips' }, chips) : null, stats.length ? h('div', { class: 'mk-stats' }, stats) : null,
        it.stock != null ? h('small', { class: 'mk-sk' + (out ? ' bad' : '') }, out ? 'Épuisé' : 'En stock : ' + it.stock) : null,
        h('div', { class: 'sf-row' }, dealer() ? null : h('div', { class: 'sf-step' }, h('button', { type: 'button', title: 'Moins', onclick: () => { q = Math.max(1, q - 1); upd(); } }, '−'), qEl, h('button', { type: 'button', title: 'Plus', onclick: () => { q = Math.min(maxQ, q + 1); upd(); } }, '+')), pEl),
        h('div', { class: 'sf-acts' }, acts))));
  }
  function addToCart(it, q) {
    const maxQ = Math.min(10, Number(st.data.max_qty) || 10);
    const l = st.cart.find((x) => x.k === it.name);
    if (l) l.qty = Math.min(maxQ, l.qty + q); else st.cart.push({ k: it.name, label: it.label, price: it.price, qty: Math.min(maxQ, q), image: it.image, max: maxQ, stock: it.stock });
    st.modal = null; drawModal(); drawCartBtn(); refreshCart();
    say(true, it.label + ' ajouté au panier.');
  }

  // ---- panier / commande ----
  function waitLeft() { return st.wait == null ? null : Math.max(0, st.wait - Math.floor((Date.now() - st.waitAt) / 1000)); }
  let tick = null;
  function ensureTick() {
    clearInterval(tick); tick = null;
    if (st.order && st.order.state === 'sent' && st.order.wait != null) {
      tick = setInterval(() => {
        if (!el.isConnected) { clearInterval(tick); return; }
        const w = waitLeft();
        if (w === 0) { clearInterval(tick); tick = null; G.post('shop.ostate', { id: st.order.id }); }
        if (st.view === 'cart') drawCart();
      }, 1000);
    }
  }
  function lineRow(l, editable) {
    return h('div', { class: 'sf-line' }, pic(l, 'sf-thumb'), h('div', { class: 'sf-lt' }, h('b', null, l.label), h('small', null, G.money(l.price) + (l.qty > 1 || editable ? ' l\'unité' : ''))),
      editable && !dealer() ? h('div', { class: 'sf-step' }, h('button', { type: 'button', title: 'Moins', onclick: () => chg(l, -1) }, '−'), h('b', null, String(l.qty)), h('button', { type: 'button', title: 'Plus', onclick: () => chg(l, 1) }, '+')) : h('b', { class: 'sf-x' }, 'Quantité : ' + l.qty),
      h('b', { class: 'sf-sum' }, G.money(l.price * l.qty)),
      editable ? h('button', { type: 'button', class: 'sf-rmb', onclick: () => { st.cart = st.cart.filter((x) => x !== l); if (ph) refreshCart(); else draw(); } }, 'Retirer') : null);
  }
  function chg(l, d) { l.qty = Math.max(0, Math.min(l.max || 10, l.qty + d)); if (l.qty === 0) st.cart = st.cart.filter((x) => x !== l); if (ph) refreshCart(); else draw(); }
  function drawCart() {
    G.clear(body);
    const o = st.order, locked = o && (o.state === 'sent' || o.state === 'billed');
    const seller = st.data.flow === 'seller';
    if (o && (o.state === 'paid' || o.state === 'refunded')) { body.appendChild(receipt(o)); return; }
    const lines = locked ? o.lines : st.cart;
    if (!lines.length) { body.appendChild(h('div', { class: 'mk-empty' }, 'Ton panier est vide. Choisis un produit, confirme, et il apparaît ici.')); return; }
    const total = locked ? o.total : cartTotal();
    const box = h('div', { class: 'sf-cart' });
    const list = h('div', { class: 'sf-lines' }, lines.map((l) => lineRow(l, !locked)));
    const side = h('aside', { class: 'sf-sum-box' });
    side.appendChild(h('div', { class: 'sf-tot' }, h('span', null, 'Total'), h('b', null, G.money(total))));
    const status = h('div', { class: 'sf-status' });
    let primary, payBtn;
    const payLabel = 'Payer ' + G.money(total);
    if (!o || o.state === 'cancelled' || o.state === undefined) {
      if (seller) {
        status.appendChild(h('p', null, dealer() ? "Envoie ta demande au vendeur : il te présente la facture, tu paies, puis tu repars avec ton véhicule." : "Envoie ton panier au vendeur : il l'encaisse, tu paies, puis tu récupères tes articles."));
        primary = h('button', { class: 'mk-b pri', onclick: () => { st.autopay = false; G.post('shop.send', { cart: st.cart.map((l) => ({ k: l.k, qty: l.qty })) }); } }, ico('arrow'), 'Envoyer au vendeur');
        payBtn = h('button', { class: 'mk-b', disabled: true, title: "Disponible quand le vendeur t'a facturé" }, ico('card'), payLabel);
      } else {
        status.appendChild(h('p', null, 'Paiement immédiat en espèces ou par carte selon le magasin.'));
        payBtn = h('button', { class: 'mk-b pri', onclick: () => { st.autopay = true; G.post('shop.send', { cart: st.cart.map((l) => ({ k: l.k, qty: l.qty })) }); } }, ico('card'), payLabel);
      }
    } else if (o.state === 'sent') {
      const w = waitLeft();
      if (o.clerks > 0) status.appendChild(h('p', { class: 'ok' }, 'Commande envoyée : un vendeur est en service, il va te servir.'));
      else if (!o.rung) status.appendChild(h('p', { class: 'warn' }, 'Aucun vendeur en service. Sonne pour appeler : si personne ne vient, tu pourras payer toi-même après ' + o.bell_secs + ' secondes.'));
      else status.appendChild(h('p', { class: 'warn' }, w > 0 ? 'Tu as sonné. Paiement libre dans ' + w + ' s si personne ne vient.' : 'Personne n\'est venu : tu peux payer ton panier toi-même.'));
      if (o.clerks === 0 && !o.rung) primary = h('button', { class: 'mk-b pri', onclick: () => G.post('shop.bell', { id: o.id }) }, ico('siren'), 'Sonner');
      const free = o.clerks === 0 && o.rung && w === 0;
      payBtn = h('button', { class: 'mk-b' + (free ? ' pri' : ''), disabled: !free || null, onclick: () => G.post('shop.opay', { id: o.id }) }, ico('card'), free ? payLabel : (o.rung && w > 0 ? 'Payer (' + w + ' s)' : payLabel));
    } else if (o.state === 'billed') {
      status.appendChild(h('p', { class: 'ok' }, seller ? 'Le vendeur a validé ta commande. Tu peux payer.' : 'Prêt à payer.'));
      payBtn = h('button', { class: 'mk-b pri', onclick: () => G.post('shop.opay', { id: o.id }) }, ico('card'), payLabel);
    }
    side.appendChild(status);
    if (primary) side.appendChild(primary);
    if (payBtn) side.appendChild(payBtn);
    if (locked && o.state !== 'billed' || (locked && seller)) side.appendChild(h('button', { class: 'mk-b ghost', onclick: () => G.post('shop.ocancel', { id: o.id }) }, 'Annuler la commande'));
    else if (!locked && st.cart.length) side.appendChild(h('button', { class: 'mk-b ghost', onclick: () => { st.cart = []; draw(); } }, 'Vider le panier'));
    box.appendChild(list); box.appendChild(side);
    body.appendChild(box);
  }
  function receipt(o) {
    const t = o.ticket || {};
    return h('div', { class: 'sf-done' }, h('div', { class: 'sf-ok' }, ico('check')), h('h2', null, o.state === 'refunded' ? 'Commande remboursée' : (dealer() ? 'Merci, ton véhicule t\'attend !' : 'Merci, tes articles sont dans ton sac !')),
      ticketEl(t, true), h('button', { class: 'mk-b pri', onclick: () => { st.order = null; st.cart = []; go('shop'); } }, 'Continuer mes achats'));
  }
  function ticketEl(t, flat) {
    const rows = (t.lines || []).map((l) => h('div', { class: 'tk-l' }, h('span', null, l.qty + ' × ' + l.label), h('b', null, G.money(l.price * l.qty))));
    const c = h('div', { class: 'sf-ticket' + (flat ? ' flat' : '') },
      h('b', { class: 'tk-h' }, t.shop || ''), h('small', null, 'Ticket ' + (t.no || '') + ' · ' + (t.date || '')), h('small', null, t.who || ''), h('div', { class: 'tk-sep' }), rows,
      h('div', { class: 'tk-sep' }), h('div', { class: 'tk-l tot' }, h('span', null, t.state === 'refunded' ? 'Remboursé' : 'Total'), h('b', null, G.money(t.total || 0))),
      t.acc ? h('small', null, 'Payé ' + (t.acc === 'bank' ? 'par carte' : 'en espèces')) : null);
    if (flat) return c;
    return h('div', { class: 'sf-dlg sf-tkd' }, h('button', { class: 'sf-closeb sf-dx', onclick: () => { st.modal = null; drawModal(); } }, 'Fermer'), c);
  }

  // ---- caisse (vendeur) ----
  function drawCaisse() {
    if (!st.orders.length) { body.appendChild(h('div', { class: 'mk-empty' }, 'Aucune commande pour le moment. Les paniers envoyés par les clients arrivent ici.')); return; }
    const list = h('div', { class: 'sf-orders' });
    st.orders.forEach((o) => {
      const acts = [];
      const post = (act) => G.post('shop.oclerk', { id: o.id, act });
      if (o.state === 'sent') acts.push(h('button', { class: 'mk-b pri', onclick: () => post('bill') }, ico('check'), 'Encaisser'));
      if (o.state === 'sent' || o.state === 'billed') acts.push(h('button', { class: 'mk-b ghost', onclick: () => post('refuse') }, 'Refuser'));
      if (o.state === 'paid' && o.can_refund) acts.push(h('button', { class: 'mk-b ghost', onclick: () => post('refund') }, 'Rembourser'));
      if (o.state === 'paid' || o.state === 'refunded') acts.push(h('button', { class: 'mk-b ghost', onclick: () => post('ticket') }, ico('file'), 'Donner un ticket'));
      list.appendChild(h('article', { class: 'sf-ord ' + o.state }, h('div', { class: 'sf-ot' }, h('b', null, '#' + o.id + ' · ' + (o.who || '')), h('small', null, o.items || '')),
        h('span', { class: 'sf-os' }, STATE_L[o.state] || o.state), h('b', { class: 'sf-sum' }, G.money(o.total)), h('div', { class: 'sf-oa' }, acts)));
    });
    body.appendChild(list);
  }

  // ---- disposition « boutique » (option layout = 'photo') : produits à gauche, panier à droite. Par défaut : catégories en cartes → produits → panier (présentation d'origine) ----
  const photoMode = () => (st.data.layout === 'photo' || (G.nova && G.nova())) && st.view !== 'caisse' && !(st.view === 'cart' && over(st.order));   // seul le reçu garde l'écran du panier
  let ph = null;
  function drawPhotoGrid() {
    if (!ph) return;
    G.clear(ph.grid);
    if (dealer()) { drawPhotoCars(); return; }
    const list = (st.data.items || []).filter((it) => (!st.cat || (it.category || '') === st.cat) && (!st.q || String(it.label).toLowerCase().indexOf(st.q) >= 0 || String(it.desc || '').toLowerCase().indexOf(st.q) >= 0));
    if (!(st.data.items || []).length) { ph.grid.appendChild(h('div', { class: 'mk-empty' }, 'Ce magasin est vide pour le moment.')); return; }
    if (!list.length) { ph.grid.appendChild(h('div', { class: 'mk-empty' }, 'Aucun résultat.')); return; }
    list.forEach((it) => {
      const out = it.stock != null && it.stock <= 0;
      const vipLock = it.vip && st.data.is_vip === false;
      const extra = [];
      if (!vipLock && it.type === 'weapon' && st.data.test_sec && it.test !== false && opt.onTest) extra.push(h('button', { type: 'button', class: 'sf-mini', onclick: () => opt.onTest(it) }, 'Tester (' + st.data.test_sec + ' s)'));
      if (st.data.restock && opt.onRestock) extra.push(h('button', { type: 'button', class: 'sf-mini', onclick: () => opt.onRestock(it, 10) }, '+10 en stock'));
      ph.grid.appendChild(h('article', { class: 'sf-pc' + (out ? ' out' : '') + (vipLock ? ' vipl' : ''), 'data-id': it.name, title: it.desc || '' },
        h('span', { class: 'sf-ptag' }, G.money(it.price)), pic(it, 'sf-pimg'), h('b', null, it.label),
        it.stock != null ? h('small', null, out ? 'Épuisé' : 'Stock : ' + it.stock) : null,
        h('button', { type: 'button', class: 'sf-add', disabled: (out || vipLock) || null, onclick: () => addToCart(it, 1) }, vipLock ? ico('lock') : ico('cart'), vipLock ? 'Réservé VIP' : (out ? 'Épuisé' : 'Ajouter')), extra.length ? h('div', { class: 'sf-ex' }, extra) : null));
    });
  }
  // concession : tous les véhicules arrivent d'un coup (recherche sur tout le catalogue) ; un clic ouvre la fiche
  function drawPhotoCars() {
    const all = st.data.vehicles;
    if (!all) {
      if (!st.allAsked) { st.allAsked = true; G.post('shop.cat', { cat: '' }); }
      ph.grid.appendChild(h('div', { class: 'mk-empty' }, 'Chargement…'));
      return;
    }
    const list = all.filter((v) => (!st.cat || (v.category || 'Autres') === st.cat) && (!st.q || String(v.label).toLowerCase().indexOf(st.q) >= 0 || String(v.model || '').toLowerCase().indexOf(st.q) >= 0));
    if (!all.length) { ph.grid.appendChild(h('div', { class: 'mk-empty' }, 'Aucun véhicule au catalogue.')); return; }
    if (!list.length) { ph.grid.appendChild(h('div', { class: 'mk-empty' }, 'Aucun résultat.')); return; }
    list.forEach((it) => {
      const open = () => { st.modal = { it }; drawModal(); };
      ph.grid.appendChild(h('article', { class: 'sf-pc', 'data-id': it.model, onclick: open },
        h('span', { class: 'sf-ptag' }, G.money(it.price)), pic(it, 'sf-pimg'), h('b', null, it.label),
        h('button', { type: 'button', class: 'sf-add', onclick: (e) => { e.stopPropagation(); open(); } }, ico('eye'), 'Voir')));
    });
  }
  function drawPhoto() {
    const cats = catsList().map((c) => c.id).filter(Boolean);
    const sel = h('select', { class: 'sf-sel', 'aria-label': 'Catégorie', onchange: (e) => { st.cat = e.target.value; drawPhotoGrid(); } }, h('option', { value: '' }, 'Tout'), cats.map((c) => h('option', { value: c, selected: st.cat === c || null }, c)));
    sel.classList.toggle('hidden', cats.length < 2);
    const grid = h('div', { class: 'sf-pgrid' });
    ph = { grid };
    // style Nova : catégories en liste à gauche (au lieu du menu déroulant), comme la maquette
    let nav = null;
    if (G.nova && G.nova() && cats.length >= 2) {
      sel.classList.add('hidden');
      const all = st.data.items || [];
      const count = (id) => {
        if (dealer()) return id ? (catsList().find((c) => c.id === id) || {}).count || 0 : catsList().reduce((n, c) => n + (c.count || 0), 0);
        return id ? all.filter((it) => (it.category || '') === id).length : all.length;
      };
      const navBtn = (id, label) => h('button', { type: 'button', class: 'sf-nc' + (st.cat === id ? ' on' : ''), onclick: (e) => { st.cat = id; nav.querySelectorAll('.sf-nc').forEach((b) => b.classList.toggle('on', b === e.currentTarget)); drawPhotoGrid(); } },
        ico(dealer() ? 'car' : (id ? iconFor('', id, '') : 'tag')), h('span', null, label), h('small', null, String(count(id))));
      nav = h('nav', { class: 'sf-ncats' }, navBtn('', 'Tout'), cats.map((c) => navBtn(c, c)));
    }
    body.appendChild(h('div', { class: 'sf-pl' }, nav, h('div', { class: 'sf-pmain' }, h('div', { class: 'sf-ptop' }, search, sel), grid), dealer() && st.data.showroom ? null : cartPanel()));
    drawPhotoGrid();
  }
  // panier de droite : lignes, total, puis les boutons selon le rôle (vendeur / client avec vendeur / libre-service)
  function cartPanel() {
    const o = st.order, locked = o && (o.state === 'sent' || o.state === 'billed');
    const lines = locked ? o.lines : st.cart;
    const total = locked ? o.total : cartTotal();
    const seller = st.data.flow === 'seller', clerk = !!st.data.clerk;
    const side = h('aside', { class: 'sf-pcart' }, h('h3', null, ico('cart'), 'Panier'));
    side.appendChild(lines.length ? h('div', { class: 'sf-lines' }, lines.map((l) => lineRow(l, !locked))) : h('p', { class: 'sf-pe' }, 'Aucun article dans le panier'));
    if (locked && o.assigned && st.data.clerk) side.appendChild(h('p', { class: 'sf-st ok' }, 'En attente de la réponse du client.'));
    side.appendChild(h('div', { class: 'sf-ptot' }, h('span', null, 'Total'), h('b', null, G.money(total))));
    const btn = (cls, label, fn, disabled, title) => h('button', { type: 'button', class: 'sf-bt ' + cls, disabled: disabled || null, title: title || '', onclick: fn }, label);
    const cartMsg = () => st.cart.map((l) => ({ k: l.k, qty: l.qty }));
    if (!o || o.state === 'cancelled') {
      if (clerk) {
        side.appendChild(tgBox());
        side.appendChild(btn('green', 'Attribuer au joueur le plus proche', () => { st.pending = { max: Math.max(0, ...st.orders.map((x) => x.id)) }; G.post('shop.assign', { cart: cartMsg(), target: st.target }); }, !st.cart.length || !st.target, st.target ? '' : 'Aucun client à proximité'));
        side.appendChild(btn('blue', 'Acheter pour moi', () => { st.autopay = true; G.post('shop.send', { cart: cartMsg() }); }, !st.cart.length));
      } else if (seller) {
        side.appendChild(h('p', { class: 'sf-st' }, "Envoie ton panier au vendeur : il l'encaisse, puis tu paies."));
        side.appendChild(btn('blue', 'Envoyer au vendeur', () => { st.autopay = false; G.post('shop.send', { cart: cartMsg() }); }, !st.cart.length));
      } else side.appendChild(btn('blue', 'Acheter pour moi', () => { st.autopay = true; G.post('shop.send', { cart: cartMsg() }); }, !st.cart.length));
      side.appendChild(btn('red', 'Vider', () => { st.cart = []; refreshCart(); drawCartBtn(); }, !st.cart.length));
    } else if (o.state === 'sent') {
      const w = waitLeft();
      if (o.clerks > 0) side.appendChild(h('p', { class: 'sf-st ok' }, 'Commande envoyée : un vendeur va te servir.'));
      else if (!o.rung) side.appendChild(h('p', { class: 'sf-st warn' }, 'Aucun vendeur en service. Sonne : si personne ne vient, tu pourras payer toi-même après ' + o.bell_secs + ' secondes.'));
      else side.appendChild(h('p', { class: 'sf-st warn' }, w > 0 ? 'Tu as sonné. Paiement libre dans ' + w + ' s.' : "Personne n'est venu : tu peux payer toi-même."));
      if (o.clerks === 0 && !o.rung) side.appendChild(btn('blue', 'Sonner', () => G.post('shop.bell', { id: o.id })));
      const free = o.clerks === 0 && o.rung && w === 0;
      side.appendChild(btn(free ? 'green' : 'blue', 'Payer ' + G.money(total), () => G.post('shop.opay', { id: o.id }), !free));
      side.appendChild(btn('red', 'Annuler la commande', () => G.post('shop.ocancel', { id: o.id })));
    } else if (o.state === 'billed') {
      side.appendChild(h('p', { class: 'sf-st ok' }, o.assigned && clerk ? 'Le client doit confirmer.' : 'Prêt à payer.'));
      if (!(o.assigned && clerk)) side.appendChild(btn('green', 'Payer ' + G.money(total), () => G.post('shop.opay', { id: o.id })));
      side.appendChild(btn('red', 'Annuler la commande', () => G.post('shop.ocancel', { id: o.id })));
    }
    return side;
  }
  function refreshCart() {
    if (!ph) return;
    const old = body.querySelector('.sf-pcart');
    if (old) old.replaceWith(cartPanel());
  }
  // destinataire : les joueurs proches sont repérés au-dessus de leur tête (calque cliquable), ici on voit celui qui est choisi
  let tgInfo = null;
  function tgBox() {
    tgInfo = h('div', { class: 'sf-tgb' });
    drawTgInfo();
    return tgInfo;
  }
  function drawTgInfo() {
    if (!tgInfo) return;
    G.clear(tgInfo);
    const list = st.targets || [], i = list.findIndex((n) => n.id === st.target);
    const cyc = (d) => { if (!list.length) return; const j = ((i < 0 ? 0 : i) + d + list.length) % list.length; st.target = list[j].id; drawTargets(); };
    tgInfo.appendChild(h('button', { type: 'button', class: 'sf-tn', 'aria-label': 'Joueur précédent', disabled: list.length < 2 || null, onclick: () => cyc(-1) }, '‹'));
    tgInfo.appendChild(h('span', { class: 'sf-tt' }, list.length ? [h('small', null, 'Destinataire'), h('b', null, (list[i < 0 ? 0 : i] || {}).name || '')] : h('small', null, 'Personne à proximité')));
    tgInfo.appendChild(h('button', { type: 'button', class: 'sf-tn', 'aria-label': 'Joueur suivant', disabled: list.length < 2 || null, onclick: () => cyc(1) }, '›'));
  }
  function drawTargets() {
    G.clear(tgLayer);
    (st.targets || []).forEach((n) => {
      if (n.x == null || n.y == null) return;
      tgLayer.appendChild(h('button', { type: 'button', class: 'sf-tc' + (n.id === st.target ? ' on' : ''), style: { left: (n.x * 100) + '%', top: (n.y * 100) + '%' }, title: 'Choisir ' + n.name, onclick: () => { st.target = n.id; drawTargets(); } },
        h('i', null), h('b', null, n.name)));
    });
    drawTgInfo();
  }

  function draw() {
    G.clear(body); ph = null; tgInfo = null;
    const pm = photoMode();
    el.classList.toggle('shpl', pm);
    drawBar(); drawCartBtn();
    search.classList.toggle('hidden', st.view !== 'shop' && !pm);
    if (!pm) { const tr = el.querySelector('.mk-tr'); if (tr && search.parentNode !== tr) tr.insertBefore(search, cartBtn); }
    if (pm) { if (st.view === 'cart') st.view = 'shop'; drawPhoto(); }
    else if (st.view === 'cart') drawCart();
    else if (st.view === 'caisse') drawCaisse();
    else drawShop();
    drawModal();
  }

  const api = {
    el,
    setMoney: (m) => { if (!m) return; cash.textContent = G.money(m.cash); bank.textContent = G.money(m.bank); },
    onOrder(o) {
      if (!o) return;
      if (o.state === 'cancelled') { st.order = null; st.autopay = false; }
      else {
        st.order = o; st.wait = o.wait == null ? null : o.wait; st.waitAt = Date.now();
        if (o.state === 'billed' && st.autopay) { st.autopay = false; G.post('shop.opay', { id: o.id }); }
        if (o.state === 'paid') { st.cart = []; if (st.view !== 'cart') st.view = 'cart'; }
      }
      ensureTick(); draw();
    },
    onOrders(list) {
      st.orders = list || [];
      if (st.pending && st.orders.some((x) => x.id > st.pending.max && x.state === 'billed')) { st.pending = null; st.cart = []; say(true, 'Panier attribué : en attente du client.'); }
      if (st.view === 'caisse' || st.data.clerk) draw();
    },
    setTargets(list) {
      st.targets = Array.isArray(list) ? list.slice(0, 12) : [];
      if (!st.targets.some((n) => n.id === st.target)) st.target = st.targets.length ? st.targets[0].id : null;   // par défaut : le plus proche
      drawTargets();
      const b = body.querySelector('.sf-bt.green'); if (b && st.data.clerk) b.disabled = !st.cart.length || !st.target;
    },
    onTicket(t) { st.modal = { ticket: t }; drawModal(); },
    onCat(d) {
      if (!d) return;
      if (d.cat === '') { st.data.vehicles = d.vehicles || []; if (ph) drawPhotoGrid(); return; }
      st.cache[d.cat] = d.vehicles || []; if (st.cat === d.cat) draw();
    },
    // données rafraîchies par le serveur (stock, prix) : on garde le panier et la page
    update(d) {
      const oldCars = st.data.vehicles;
      st.data = d; if (d.order) st.order = d.order; if (d.orders) st.orders = d.orders;
      st.cart.forEach((l) => { const it = (d.items || []).find((x) => x.name === l.k); if (it) { l.price = it.price; l.stock = it.stock; } });
      st.cart = st.cart.filter((l) => dealer() || (d.items || []).some((x) => x.name === l.k));
      st.cache = {};
      if (dealer() && !d.vehicles) {
        if (photoMode()) { d.vehicles = oldCars; if (!oldCars) st.allAsked = false; else G.post('shop.cat', { cat: '' }); }   // prix à jour, sans repasser par « Chargement »
        else if (st.cat) G.post('shop.cat', { cat: st.cat });
      }
      api.setMoney({ cash: d.cash, bank: d.bank }); draw();
    },
    say,
    escape() {
      if (st.modal) { st.modal = null; drawModal(); return true; }
      if (st.view !== 'shop') { go('shop'); return true; }
      if (st.cat !== '' && catsList().length >= 2) { st.cat = ''; draw(); return true; }
      return false;
    },
    state: st,
  };
  api.setMoney({ cash: data.cash, bank: data.bank });
  if (data.order) { st.wait = data.order.wait == null ? null : data.order.wait; st.waitAt = Date.now(); ensureTick(); if (data.order.state !== 'paid') st.view = 'cart'; }
  draw();
  if (data.discount) { const n = h('div', { class: 'mk-note' }, ico('tag'), ' ' + data.discount + ' % de remise sur tous les prix'); el.insertBefore(n, body); }
  return api;
}
G.shopFlowView = shopFlowView;
})();
