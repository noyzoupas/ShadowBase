/* Créateur de personnage : choix homme/femme dans la salle d'identité, puis panneau à 10 étapes (hérédité, visage, peau, cheveux, pilosité, maquillage, tenue, identité, arrivée).
   Souris : glisser pour tourner, molette pour zoomer. Clavier : A / E, R, Ctrl+Z, Tab, Entrée. Tout texte est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const add = (el, ...k) => el.append(...k.filter((x) => x != null));   // append(null) écrirait « null »

const MALE = ['Benjamin', 'Daniel', 'Joshua', 'Noah', 'Andrew', 'Juan', 'Alex', 'Isaac', 'Evan', 'Ethan', 'Vincent', 'Angel', 'Diego', 'Adrian', 'Gabriel', 'Michael', 'Santiago', 'Kevin', 'Louis', 'Samuel', 'Anthony'];
const FEMALE = ['Hannah', 'Aubrey', 'Jasmine', 'Gisele', 'Amelia', 'Isabella', 'Zoe', 'Ava', 'Camila', 'Violet', 'Sophia', 'Evelyn', 'Nicole', 'Ashley', 'Gracie', 'Brianna', 'Natalie', 'Olivia', 'Elizabeth', 'Charlotte', 'Emma'];
const SPECIAL = ['Claude', 'Niko', 'John', 'Misty'];
const PARENTS = MALE.concat(FEMALE, SPECIAL);   // index = identifiant du jeu (0 à 45)
// Portrait du parent tel que dans GTA Online (texture du jeu « char_creator_portraits », chargée par client/character.lua)
const portrait = (i) => 'https://nui-img/char_creator_portraits/' + (i <= 20 ? 'male_' + i : i <= 41 ? 'female_' + (i - 21) : i <= 44 ? 'special_male_' + (i - 42) : 'special_female_0');

const FACE_GROUPS = [
  ['Nez', [0, 1, 2, 3, 4, 5]], ['Sourcils et yeux', [6, 7, 11]], ['Joues et pommettes', [8, 9, 10]], ['Lèvres et menton', [12, 15, 16, 17, 18]], ['Mâchoire et cou', [13, 14, 19]],
];
const FACE = ['Largeur du nez', 'Hauteur de la pointe du nez', 'Longueur du nez', 'Hauteur du pont du nez', 'Affaissement du nez', 'Torsion du nez', 'Hauteur des sourcils', 'Avancée des sourcils',
  'Hauteur des pommettes', 'Largeur des pommettes', 'Largeur des joues', 'Ouverture des yeux', 'Épaisseur des lèvres', 'Largeur de la mâchoire', 'Longueur de la mâchoire', 'Hauteur du menton',
  'Longueur du menton', 'Largeur du menton', 'Fossette du menton', 'Épaisseur du cou'];
const OV_BEARD = [['Barbe', 1, true], ['Sourcils', 2, true], ['Poils du torse', 10, true]];
const OV_SKIN = [['Imperfections', 0], ['Vieillissement', 3], ['Teint du visage', 6], ['Dommages du soleil', 7], ['Grains de beauté', 9], ['Taches du corps', 11]];
const OV_MAKEUP = [['Maquillage', 4, true], ['Blush', 5, true], ['Rouge à lèvres', 8, true]];
const COMPS = [['Haut', 11], ['Sous-haut', 8], ['Bras / torse', 3], ['Pantalon', 4], ['Chaussures', 6], ['Accessoires', 7], ['Masque', 1], ['Sac', 5], ['Gilet', 9], ['Écusson', 10]];
const PROPS = [['Chapeau', 0], ['Lunettes', 1], ['Oreilles', 2], ['Montre', 6], ['Bracelet', 7]];
const hairHue = (i) => 'hsl(' + ((i * 37) % 360) + ',' + (i < 8 ? 6 : 45) + '%,' + (i < 8 ? 10 + i * 8 : 38) + '%)';
const rnd = (a, b) => a + Math.random() * (b - a), rndi = (a, b) => Math.floor(rnd(a, b + 1));

const STEP_DEFS = {
  perso: { label: 'Personnage', sub: 'Cliquez sur un personnage', cam: null },
  hered: { label: 'Hérédité', sub: 'Parents et ressemblance', cam: 'face' },
  face: { label: 'Visage', sub: 'Affinez chaque trait du visage', cam: 'face' },
  skin: { label: 'Peau', sub: 'Teint et marques du visage', cam: 'face' },
  hair: { label: 'Cheveux', sub: 'Coupe, couleur et mèches', cam: 'face' },
  beard: { label: 'Pilosité', sub: 'Barbe, sourcils et poils', cam: 'face' },
  makeup: { label: 'Maquillage', sub: 'Maquillage, blush et rouge à lèvres', cam: 'face' },
  outfit: { label: 'Tenue', sub: 'Vous pourrez en changer dans les magasins', cam: 'body' },
  ident: { label: 'Identité', sub: 'Définitive : choisissez avec soin', cam: 'body' },
  final: { label: 'Arrivée', sub: 'Où commence votre histoire', cam: 'body' },
};

function defaults() {
  return { model: 'mp_m_freemode_01', head: { mother: 21, father: 0, third: 0, shape: 0.5, skin: 0.5, mix: 0 }, face: Array(20).fill(0), hair: { style: 0, color: 0, highlight: 0 }, eye: 0,
    ov: Array.from({ length: 13 }, () => ({ s: 255, o: 1, c: 0 })), comps: Array.from({ length: 12 }, () => ({ d: 0, t: 0 })), props: [] };
}

const MCAL = { ax: -5206.4, bx: 11493.2, ay: 8271.8, by: 12556 };   // même calibrage que la carte du panel : x = u*bx + ax ; y = ay - v*by

// Carte : satellite (avec les noms des lieux) ou plan (routes) — même cadrage, même calibrage ; choix gardé sur le poste
const MAPSTYLE = { sat: 'img/map.jpg', plan: 'img/map-plan.jpg' };
function mapStyle() { try { return localStorage.getItem('pb_map_style') === 'plan' ? 'plan' : 'sat'; } catch (e) { return 'sat'; } }
function mapToggle(img) {
  const seg = h('div', { class: 'map-seg' });
  const draw = () => { G.clear(seg); [['sat', 'Satellite'], ['plan', 'Plan']].forEach(([k, l]) => seg.appendChild(h('button', { type: 'button', class: mapStyle() === k ? 'on' : '', onclick: (e) => { e.stopPropagation(); try { localStorage.setItem('pb_map_style', k); } catch (er) { /* rien */ } img.src = MAPSTYLE[k]; draw(); } }, l))); };
  draw();
  return seg;
}
function spawnMap(points, selected, onPick, acc) {
  const box = h('div', { class: 'gk-map gk-map2', style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } });
  const mimg = h('img', { class: 'gk-mimg', src: MAPSTYLE[mapStyle()], alt: '', draggable: false });
  const inner = h('div', { class: 'gk-mi' }, mimg);
  const dots = [];
  points.forEach((p) => {
    const u = (p.x - MCAL.ax) / MCAL.bx, v = (MCAL.ay - p.y) / MCAL.by;
    const d = h('button', { type: 'button', class: 'gk-pt2' + (p.id === selected ? ' on' : ''), style: { left: (u * 100) + '%', top: (v * 100) + '%' }, title: p.label, onclick: () => onPick(p) },
      h('i', { class: 'gk-halo2' }), h('b', { class: 'gk-dot2' }), h('span', { class: 'gk-lab2' }, p.label));
    inner.appendChild(d); dots.push([p, d]);
  });
  box.appendChild(inner);
  box.appendChild(h('span', { class: 'gk-map-note' }, 'Carte de Los Santos'));
  box.appendChild(mapToggle(mimg));
  box.select = (id) => dots.forEach(([p, d]) => d.classList.toggle('on', p.id === id));
  return box;
}
// Petite carte numérotée et ses boutons : choix du point d'arrivée (ici et sur l'écran de choix du personnage)
function spawnPicker(points, selected, onPick) {
  const inner = h('div', { class: 'da-mi' }, h('img', { src: 'img/map-plan.jpg', alt: '', draggable: false }));
  const marks = [], chips = [];
  let cur = selected;
  const sel = (id) => { cur = id; marks.forEach(([p, m]) => m.classList.toggle('on', p.id === id)); chips.forEach(([p, c]) => c.classList.toggle('on', p.id === id)); };
  const choose = (p) => { sel(p.id); onPick(p); };
  points.forEach((p, i) => {
    const m = h('button', { type: 'button', class: 'da-mk', title: p.label, style: { left: ((p.x - MCAL.ax) / MCAL.bx * 100) + '%', top: ((MCAL.ay - p.y) / MCAL.by * 100) + '%' }, onclick: () => choose(p) }, String(i + 1));
    inner.appendChild(m); marks.push([p, m]);
    chips.push([p, h('button', { type: 'button', class: 'da-chip', onclick: () => choose(p) }, h('b', null, String(i + 1)), h('span', null, p.label))]);
  });
  sel(selected);
  return h('div', { class: 'da-sp' }, h('div', { class: 'da-mapb' }, inner), h('div', { class: 'da-chips' }, chips.map((c) => c[1])));
}
G.spawnPicker = spawnPicker;

// creatorView(cfg, { preview, only, appearance, limits, spawn, ... })
function creatorView(cfg, opt) {
  opt = opt || {};
  cfg = cfg || {};
  const preview = !!opt.preview;
  const acc = G.accentHex();
  const points = (cfg.spawn_points || []).filter((p) => p.enabled !== false);
  const S = { step: 0, sex: cfg.allow_male === false ? 'f' : 'm', first: '', last: '', dob: '1999-10-02', height: 175, nat: '', bio: '', accept: false, tagc: ((G.cfg && G.cfg.tags) || {}).name_color_default || '#d9cb8f',
    spawn: (opt.spawn && points.some((p) => p.id === opt.spawn)) ? opt.spawn : (points.length ? points[0].id : ''), app: opt.appearance ? JSON.parse(JSON.stringify(opt.appearance)) : defaults(), limits: opt.limits || null, target: 'mother', open: {} };
  const both = cfg.allow_male !== false && cfg.allow_female !== false;
  let order = ['hered', 'face', 'skin', 'hair', 'beard', 'makeup'];
  if (both && !preview) order.unshift('perso');
  if (cfg.show_clothes !== false) order.push('outfit');
  order.push('ident', 'final');
  if (opt.only) order = ['outfit'];
  const root = h('div', { class: 'gk gk4' + (preview ? ' gk-prev' : '') + (opt.only ? ' gk-only' : ''), style: { '--acc': acc, '--acc-rgb': G.hexToRgb(acc) } });
  const fit = () => root.style.setProperty('--k', preview ? '0.62' : String(Math.min(window.innerWidth / 1920, window.innerHeight / 1080)));
  fit();
  window.addEventListener('resize', fit);
  const drag = h('div', { class: 'gk-drag' });
  const rail = h('div', { class: 'gk-tabs' }), head = h('div', { class: 'gk-top' }), bar = h('i'), sub = h('div', { class: 'gk-subt' }), body = h('div', { class: 'gk-body' }), err = h('div', { class: 'gk-err hidden' }), tools = h('div', { class: 'gk-tools' }), nav = h('div', { class: 'gk-nav' });
  const panel = h('div', { class: 'gk-panel' }, head, rail, h('div', { class: 'gk-prog' }, bar), sub, body, err, tools, nav);
  const hints = h('div', { class: 'gk-hbar' });
  const pickUi = h('div', { class: 'gk-pick' });
  add(root, drag, panel, hints, pickUi);

  // ---------- souris sur le personnage ----------
  if (!preview) {
    let down = null;
    drag.addEventListener('mousedown', (e) => { down = e.clientX; drag.classList.add('on'); });
    const move = (e) => { if (down === null) return; const dx = e.clientX - down; if (Math.abs(dx) >= 3) { G.post('creator.rotate', { delta: dx * 0.45 }); down = e.clientX; } };
    const up = () => { down = null; drag.classList.remove('on'); };
    document.addEventListener('mousemove', move); document.addEventListener('mouseup', up);
    drag.addEventListener('wheel', (e) => G.post('creator.zoom', { d: e.deltaY > 0 ? 1 : -1 }));
    root.unbind = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); };
  }

  // ---------- aperçu et retour en arrière ----------
  let timer = null, lastSnap = JSON.stringify(S.app);
  const undo = [];
  const flush = (sexChanged) => {
    S.app.model = S.sex === 'f' ? 'mp_f_freemode_01' : 'mp_m_freemode_01';
    G.post('creator.preview', { appearance: S.app, sexChanged: !!sexChanged }).then((r) => { if (r && r.comps) S.limits = r; });
  };
  function sendPreview(sexChanged) {
    const now = JSON.stringify(S.app);
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (now !== lastSnap) { undo.push(lastSnap); if (undo.length > 60) undo.shift(); lastSnap = now; drawTools(); }
      if (!preview) flush(sexChanged);
    }, 70);
  }
  function doUndo() {
    if (!undo.length) return;
    lastSnap = undo.pop(); S.app = JSON.parse(lastSnap);
    if (!preview) flush(false);
    render();
  }

  const L = () => S.limits || { comps: Array(12).fill(60), props: { 0: 60, 1: 30, 2: 20, 6: 20, 7: 20 }, overlays: Array(13).fill(12), hairColors: 64, makeupColors: 64 };
  const field = (label, el, hint) => h('div', { class: 'gkf' }, h('label', null, label), el, hint ? h('small', null, hint) : null);
  // section repliable : l'état reste pendant toute la création
  const sec = (title, note, ...kids) => {
    const k = title, rightTools = kids.length && kids[0] && kids[0].isTool ? kids.shift() : null;
    const box = h('div', { class: 'gk-box' }, ...kids);
    const t = h('div', { class: 'gk-boxt', onclick: (e) => { if (e.target.closest('.gk-tool')) return; S.open[k] = S.open[k] === false; box.classList.toggle('hidden', S.open[k] === false); t.classList.toggle('shut', S.open[k] === false); } },
      h('b', null, title), note != null ? h('span', { class: 'gk-boxn' }, note) : null, h('em'), rightTools, h('i', { class: 'gk-chev' }));
    if (S.open[k] === false) { box.classList.add('hidden'); t.classList.add('shut'); }
    t.note = (v) => { const n = t.querySelector('.gk-boxn'); if (n) n.textContent = v; };
    const w = h('section', { class: 'gk-sec2' }, t, box);
    w.title2 = t;
    return w;
  };
  const paint = (i, mid) => {
    const min = Number(i.min), max = Number(i.max), p = (Number(i.value) - min) / (max - min) * 100;
    i.style.setProperty('--a', (mid ? Math.min(p, 50) : 0) + '%'); i.style.setProperty('--b', (mid ? Math.max(p, 50) : p) + '%');
  };
  const slider = (label, min, max, step, get, set, fmt, mid) => {
    const out = h('output', null, fmt ? fmt(get()) : String(get()));
    const i = h('input', { type: 'range', min, max, step, value: get() });
    i.addEventListener('input', () => { set(Number(i.value)); out.textContent = fmt ? fmt(Number(i.value)) : i.value; paint(i, mid); sendPreview(); });
    paint(i, mid);
    return h('div', { class: 'gkf' }, h('label', null, label, out), i);
  };
  // curseur entre deux extrêmes : « Traits du visage  0 · 100 »
  const dual = (label, left, right, get, set, after) => {
    const fmt = (v) => Math.round((1 - v) * 100) + ' · ' + Math.round(v * 100);
    const out = h('output', null, fmt(get()));
    const i = h('input', { type: 'range', min: 0, max: 1, step: 0.01, value: get() });
    i.addEventListener('input', () => { set(Number(i.value)); out.textContent = fmt(Number(i.value)); paint(i, true); sendPreview(); if (after) after(); });
    paint(i, true);
    return h('div', { class: 'gkf gk-dual' }, h('label', null, label, out), h('div', { class: 'gk-dr' }, h('span', null, left), i, h('span', null, right)));
  };
  const pick = (label, get, set, max, afterChange) => {
    const out = h('b', null, '');
    const upd = () => { out.textContent = (get() + 1) + ' / ' + Math.max(1, max()); };
    const mv = (d) => { const m = Math.max(1, max()); set(((get() + d) % m + m) % m); upd(); sendPreview(); if (afterChange) afterChange(); };
    upd();
    const w = h('div', { class: 'gkf row' }, h('label', null, label), h('div', { class: 'gks' }, h('button', { onclick: () => mv(-1) }, '‹'), out, h('button', { onclick: () => mv(1) }, '›')));
    w.refresh = upd;
    return w;
  };
  // (v1.2.60) liste déroulante maison : même style partout (la liste du navigateur ne se règle pas), recherche si elle est longue
  function pickList(items, value, onchange) {
    const lbl = h('span');
    const box = h('div', { class: 'gkp', tabindex: '-1' }, lbl, h('i'));
    let cur = value, pop = null;
    const labelOf = (v) => { const f = items.find((x) => String(x[0]) === String(v)); return f ? f[1] : ''; };
    const close = () => { if (pop) { pop.remove(); pop = null; document.removeEventListener('mousedown', outside, true); } };
    const outside = (e) => { if (pop && !pop.contains(e.target) && !box.contains(e.target)) close(); };
    Object.defineProperty(box, 'value', { get: () => cur, set: (v) => { cur = v; lbl.textContent = labelOf(v); } });
    box.value = value;
    box.addEventListener('click', () => {
      if (pop) { close(); return; }
      const r = box.getBoundingClientRect();
      const list = h('div', { class: 'gkp-l' });
      const fill = (q) => {
        G.clear(list);
        items.filter((x) => !q || String(x[1]).toLowerCase().indexOf(q) >= 0).forEach((x) => list.appendChild(h('button', { type: 'button', class: String(x[0]) === String(cur) ? 'on' : '', onclick: () => {
          box.value = x[0]; close(); if (onchange) onchange(x[0]); box.dispatchEvent(new Event('change')); } }, String(x[1]))));
      };
      fill('');
      const q = items.length > 12 ? h('input', { type: 'text', class: 'gkp-q', placeholder: 'Rechercher…', oninput: (e) => fill(e.target.value.trim().toLowerCase()) }) : null;
      pop = h('div', { class: 'gkp-p', style: { left: r.left + 'px', width: Math.max(r.width, 150) + 'px' } }, q, list);
      document.body.appendChild(pop);
      const below = window.innerHeight - r.bottom;
      if (below < 220 && r.top > below) pop.style.bottom = (window.innerHeight - r.top + 4) + 'px'; else pop.style.top = (r.bottom + 4) + 'px';
      pop.style.maxHeight = Math.max(160, Math.min(300, (below < 220 && r.top > below ? r.top : below) - 16)) + 'px';
      const on = list.querySelector('.on'); if (on) on.scrollIntoView({ block: 'center' });
      if (q) setTimeout(() => q.focus(), 20);
      document.addEventListener('mousedown', outside, true);
    });
    return box;
  }
  function colorGrid(get, set, n, makeup, onPick) {
    const pal = (makeup ? L().makeupRgb : L().hairRgb) || null;
    if (pal && pal.length) n = pal.length;
    const g = h('div', { class: 'gkc' });
    const mark = () => Array.from(g.children).forEach((c, k) => c.classList.toggle('on', k === get()));
    for (let i = 0; i < n; i++) {
      g.appendChild(h('button', { title: 'Teinte ' + (i + 1), style: { background: (pal && pal[i]) || hairHue(i) }, onclick: () => { set(i); mark(); sendPreview(); if (onPick) onPick(i); } }));
    }
    mark();
    g.mark = mark; g.total = n;
    return g;
  }
  const overlayCtl = (name, idx, col) => {
    const o = S.app.ov[idx];
    const max = () => (L().overlays[idx] || 1) + 1;
    const txt = () => (o.s === 255 ? 'Aucun' : (o.s + 1) + ' / ' + (max() - 1));
    const out = h('b', null, txt());
    const mv = (d) => { const cur = o.s === 255 ? 0 : o.s + 1; const m = max(); const nx = ((cur + d) % m + m) % m; o.s = nx === 0 ? 255 : nx - 1; out.textContent = txt(); sendPreview(); };
    const kids = [h('div', { class: 'gkf row' }, h('label', null, 'Style'), h('div', { class: 'gks' }, h('button', { onclick: () => mv(-1) }, '‹'), out, h('button', { onclick: () => mv(1) }, '›'))),
      slider('Intensité', 0, 1, 0.05, () => o.o, (v) => { o.o = v; }, (v) => Math.round(v * 100) + ' %')];
    if (col) kids.push(field('Couleur', colorGrid(() => o.c, (v) => { o.c = v; }, 64, idx === 5 || idx === 8)));
    return sec(name, null, ...kids);
  };

  // --- « Aléatoire » selon l'étape ---
  const ovRand = (list) => list.forEach(([, i, col]) => { S.app.ov[i] = Math.random() < 0.5 ? { s: rndi(0, Math.max(0, (L().overlays[i] || 1) - 1)), o: +rnd(0.3, 1).toFixed(2), c: col ? rndi(0, 63) : 0 } : { s: 255, o: 1, c: 0 }; });
  const actions = {
    hered: () => { S.app.head = { mother: rndi(21, 41), father: rndi(0, 20), third: rndi(0, 45), shape: +rnd(0.1, 0.9).toFixed(2), skin: +rnd(0.1, 0.9).toFixed(2), mix: 0 }; },
    face: () => { S.app.face = S.app.face.map(() => +rnd(-0.6, 0.6).toFixed(2)); S.app.eye = rndi(0, 31); },
    skin: () => { ovRand(OV_SKIN); S.app.head.skin = +rnd(0, 1).toFixed(2); },
    hair: () => { S.app.hair = { style: rndi(0, Math.max(0, L().comps[2] - 1)), color: rndi(0, 63), highlight: rndi(0, 63) }; },
    beard: () => ovRand(OV_BEARD),
    makeup: () => ovRand(OV_MAKEUP),
    outfit: () => { [11, 8, 4, 6].forEach((id) => { S.app.comps[id] = { d: rndi(0, Math.max(0, L().comps[id] - 1)), t: 0 }; }); },
  };

  // ---------- pages ----------
  const pages = {
    perso: () => [],
    hered: () => {
      const headOf = () => S.app.head;
      if (headOf().third == null) headOf().third = 0;
      if (headOf().mix == null) headOf().mix = 0;
      const allowed = (key) => PARENTS.map((_, i) => i).filter((i) => key === 'mother' ? ((i >= 21 && i <= 41) || i === 45) : key === 'father' ? (i <= 20 || (i >= 42 && i <= 44)) : true);
      const KEYS = [['mother', 'Mère'], ['father', 'Père'], ['third', 'Vous-même']];
      const img = (i) => { const m = h('img', { src: preview ? '' : portrait(i), alt: '', draggable: false }); m.addEventListener('error', () => m.remove()); if (preview) m.remove(); return m; };
      const cards = h('div', { class: 'gk-parents' });
      const names = () => PARENTS[headOf().mother] + ' et ' + PARENTS[headOf().father];
      let parSec = null;
      const drawCards = () => {
        G.clear(cards);
        KEYS.forEach(([k, l]) => {
          const ids = allowed(k), id = headOf()[k], step = (d) => { const c = ids.indexOf(id); headOf()[k] = ids[(c + d + ids.length) % ids.length]; S.target = k; sendPreview(); drawCards(); drawGrid(); if (parSec) parSec.title2.note(names()); };
          cards.appendChild(h('div', { class: 'gk-par' + (S.target === k ? ' on' : ''), onclick: () => { S.target = k; drawCards(); drawGrid(); } },
            h('span', { class: 'gk-part' }, l), h('div', { class: 'gk-parp' }, img(id)),
            h('div', { class: 'gk-parn' }, h('button', { onclick: (e) => { e.stopPropagation(); step(-1); } }, '‹'), h('b', null, PARENTS[id]), h('button', { onclick: (e) => { e.stopPropagation(); step(1); } }, '›'))));
        });
      };
      const grid = h('div', { class: 'gk-faces' });
      const tabs = h('div', { class: 'gk-tool gk-mini' });
      tabs.isTool = true;
      let faceSec = null;
      const drawGrid = () => {
        G.clear(grid); G.clear(tabs);
        KEYS.forEach(([k, l]) => tabs.appendChild(h('button', { type: 'button', class: S.target === k ? 'on' : '', onclick: () => { S.target = k; drawCards(); drawGrid(); } }, l)));
        const ids = allowed(S.target);
        ids.forEach((i) => grid.appendChild(h('button', { class: headOf()[S.target] === i ? 'on' : '', onclick: () => { headOf()[S.target] = i; sendPreview(); drawCards(); drawGrid(); if (parSec) parSec.title2.note(names()); } },
          h('span', null, PARENTS[i].slice(0, 2)), img(i), h('small', null, PARENTS[i]))));
        if (faceSec) { faceSec.title2.querySelector('b').textContent = 'Visage : ' + KEYS.find((x) => x[0] === S.target)[1].toLowerCase(); faceSec.title2.note(ids.length + ' visages'); }
      };
      parSec = sec('Parents', names(), cards);
      const note = () => (headOf().shape >= 0.5 ? 'Plus proche du père (' + Math.round(headOf().shape * 100) + ' %)' : 'Plus proche de la mère (' + Math.round((1 - headOf().shape) * 100) + ' %)');
      let resSec = null;
      const resKids = [dual('Traits du visage', 'Mère', 'Père', () => headOf().shape, (v) => { headOf().shape = v; }, () => resSec.title2.note(note())),
        dual('Votre propre trait', 'Parents', 'Vous-même', () => headOf().mix, (v) => { headOf().mix = v; }),
        h('div', { class: 'gk-info' }, ico('alert'), 'Votre propre trait mêle « Vous-même » aux deux parents.')];
      resSec = sec('Ressemblance', note(), ...resKids);
      faceSec = sec('Visage', '', tabs, grid);
      drawCards(); drawGrid();
      return [parSec, resSec, faceSec];
    },
    face: () => [sec('Yeux', null, slider('Couleur des yeux', 0, 31, 1, () => S.app.eye, (v) => { S.app.eye = v; }, (v) => (v + 1) + ' / 32'))].concat(
      FACE_GROUPS.map(([t, idx]) => sec(t, null, ...idx.map((i) => slider(FACE[i], -1, 1, 0.05, () => S.app.face[i], (v) => { S.app.face[i] = v; }, (v) => v.toFixed(2), true))))),
    skin: () => [sec('Teint', null, dual('Couleur de peau', 'Mère', 'Père', () => S.app.head.skin, (v) => { S.app.head.skin = v; }))].concat(OV_SKIN.map(([n, i, c]) => overlayCtl(n, i, c))),
    hair: () => {
      const cnt1 = h('span', null, ''), cnt2 = h('span', null, '');
      const upd = () => { cnt1.textContent = (S.app.hair.color + 1) + ' / ' + g1.total; cnt2.textContent = (S.app.hair.highlight + 1) + ' / ' + g2.total; };
      const g1 = colorGrid(() => S.app.hair.color, (v) => { S.app.hair.color = v; }, 64, false, () => upd());
      const g2 = colorGrid(() => S.app.hair.highlight, (v) => { S.app.hair.highlight = v; }, 64, false, () => upd());
      upd();
      const col = sec('Couleurs', 'Teinte et mèches', h('div', { class: 'gkf' }, h('label', null, 'Couleur', cnt1), g1), h('div', { class: 'gkf' }, h('label', null, 'Mèches', cnt2), g2),
        h('button', { class: 'gk-same', onclick: () => { S.app.hair.highlight = S.app.hair.color; g2.mark(); upd(); sendPreview(); } }, ico('hanger'), 'Mèches de la même couleur'));
      const n = Math.max(1, L().comps[2]);
      const grid = h('div', { class: 'gk-cuts' });
      const fill = (q) => {
        G.clear(grid); let shown = 0;
        for (let i = 0; i < n; i++) {
          if (q && String(i + 1).indexOf(q) !== 0) continue;
          shown++;
          grid.appendChild(h('button', { class: S.app.hair.style === i ? 'on' : '', onclick: (e) => { S.app.hair.style = i; Array.from(grid.children).forEach((c) => c.classList.toggle('on', c === e.currentTarget)); sendPreview(); } }, h('b', null, String(i + 1)), h('small', null, 'Coupe ' + (i + 1))));
        }
        cut.title2.note(shown + ' / ' + n + ' coiffures');
      };
      const search = h('div', { class: 'gk-find' }, ico('calc'), h('input', { type: 'text', maxlength: 4, placeholder: 'Chercher une coupe par numéro', oninput: (e) => fill(e.target.value.replace(/\D/g, '')) }));
      const cut = sec('Coupe', '', search, grid);
      fill('');
      return [col, cut];
    },
    beard: () => OV_BEARD.map(([n, i, c]) => overlayCtl(n, i, c)),
    makeup: () => OV_MAKEUP.map(([n, i, c]) => overlayCtl(n, i, c)),
    outfit: () => {
      const items = COMPS.map(([name, id]) => {
        const c = S.app.comps[id]; let tex = 1;
        const texOut = h('b', null, '');
        const upT = () => { texOut.textContent = (c.t + 1) + ' / ' + tex; };
        const loadTex = () => {
          if (preview) { tex = 4; c.t = Math.min(c.t, tex - 1); upT(); return; }
          G.post('creator.textures', { kind: 'comp', id, drawable: c.d }).then((r) => { tex = (r && r.n) || 1; c.t = Math.min(c.t, tex - 1); upT(); });
        };
        loadTex();
        const sTex = h('div', { class: 'gks' }, h('button', { onclick: () => { c.t = ((c.t - 1) % tex + tex) % tex; upT(); sendPreview(); } }, '‹'), texOut, h('button', { onclick: () => { c.t = (c.t + 1) % tex; upT(); sendPreview(); } }, '›'));
        return h('div', { class: 'gk-card' }, pick(name, () => c.d, (v) => { c.d = v; c.t = 0; }, () => L().comps[id], loadTex), h('div', { class: 'gkf row' }, h('label', null, 'Variante'), sTex));
      });
      const props = PROPS.map(([name, id]) => {
        let pr = S.app.props.find((p) => p.id === id); if (!pr) { pr = { id, d: -1, t: 0 }; S.app.props.push(pr); }
        const maxP = () => (L().props[id] || 1);
        let tex = 1;
        const out = h('b', null, ''); const upd = () => { out.textContent = pr.d < 0 ? 'Aucun' : (pr.d + 1) + ' / ' + maxP(); };
        const texOut = h('b', null, '');
        const upT = () => { texOut.textContent = pr.d < 0 ? '—' : (pr.t + 1) + ' / ' + tex; };
        const loadTex = () => {
          if (pr.d < 0) { tex = 1; pr.t = 0; upT(); return; }
          if (preview) { tex = 4; pr.t = Math.min(pr.t, tex - 1); upT(); return; }
          const asked = pr.d;
          G.post('creator.textures', { kind: 'prop', id, drawable: asked }).then((r) => { if (pr.d !== asked) return; tex = (r && r.n) || 1; pr.t = Math.min(pr.t, tex - 1); upT(); });
        };
        const mv = (d) => { const m = maxP() + 1; const nx = (((pr.d + 1) + d) % m + m) % m; pr.d = nx - 1; pr.t = 0; upd(); loadTex(); sendPreview(); };
        const mvT = (d) => { if (pr.d < 0) return; pr.t = ((pr.t + d) % tex + tex) % tex; upT(); sendPreview(); };
        upd(); loadTex();
        return h('div', { class: 'gk-card' }, h('div', { class: 'gkf row' }, h('label', null, name), h('div', { class: 'gks' }, h('button', { onclick: () => mv(-1) }, '‹'), out, h('button', { onclick: () => mv(1) }, '›'))),
          h('div', { class: 'gkf row' }, h('label', null, 'Variante'), h('div', { class: 'gks' }, h('button', { onclick: () => mvT(-1) }, '‹'), texOut, h('button', { onclick: () => mvT(1) }, '›'))));
      });
      return [sec('Vêtements', 'Pièce par pièce', ...items), sec('Accessoires', null, ...props)];
    },
    ident: () => {
      const mn = cfg.name_min || 2, mxn = cfg.name_max || 20;
      const nameT = h('b', null, ''), natT = h('b', null, ''), dobT = h('b', null, ''), ageT = h('b', null, '');
      const age = () => { const d = new Date(S.dob); if (isNaN(d)) return '—'; const n = new Date(); let a = n.getFullYear() - d.getFullYear(); if (n < new Date(n.getFullYear(), d.getMonth(), d.getDate())) a--; return a + ' ans'; };
      const redraw = () => { nameT.textContent = (S.first.trim() || 'Prénom') + ' ' + (S.last.trim() || 'Nom'); natT.textContent = S.nat || 'Non choisie'; dobT.textContent = S.dob.split('-').reverse().join('/'); ageT.textContent = age(); };
      const fiche = h('div', { class: 'gk-fiche' }, h('div', { class: 'gk-fph' }, ico('user')), h('div', null, h('small', null, S.sex === 'f' ? 'Femme' : 'Homme'), h('div', { class: 'gk-fn' }, nameT),
        h('div', { class: 'gk-fr' }, h('span', null, 'Nationalité ', natT), h('span', null, 'Naissance ', dobT), h('span', null, 'Âge ', ageT))));
      const f1 = h('input', { type: 'text', maxlength: mxn, value: S.first, placeholder: mn + ' à ' + mxn + ' lettres', oninput: (e) => { S.first = e.target.value; redraw(); } });
      const f2 = h('input', { type: 'text', maxlength: mxn, value: S.last, placeholder: mn + ' à ' + mxn + ' lettres', oninput: (e) => { S.last = e.target.value; redraw(); } });
      // date en jour / mois / année (le champ date du navigateur du jeu s'affiche à l'américaine)
      const MOIS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
      const [y0, m0, d0] = S.dob.split('-').map(Number);
      const yNow = new Date().getFullYear(), yMax = yNow - (cfg.age_min || 18), yMin = yNow - (cfg.age_max || 80);
      const pad = (n) => String(n).padStart(2, '0');
      const sd = pickList(Array.from({ length: 31 }, (_, i) => [i + 1, String(i + 1)]), d0);
      const sm = pickList(MOIS.map((m, i) => [i + 1, m]), m0);
      const sy = pickList(Array.from({ length: yMax - yMin + 1 }, (_, i) => yMax - i).map((y) => [y, String(y)]), Math.max(yMin, Math.min(yMax, y0)));
      const setDob = () => { const y = Number(sy.value), m = Number(sm.value), dim = new Date(y, m, 0).getDate(); if (Number(sd.value) > dim) sd.value = dim; S.dob = y + '-' + pad(m) + '-' + pad(Number(sd.value)); redraw(); };
      [sd, sm, sy].forEach((x) => x.addEventListener('change', setDob));
      setDob();
      const nats = cfg.nationalities || [];
      const nat = nats.length ? pickList([['', 'Choisir une nationalité']].concat(nats.map((n) => [n, n])), S.nat, (v) => { S.nat = v; redraw(); }) : h('input', { type: 'text', maxlength: 32, value: S.nat, oninput: (e) => { S.nat = e.target.value; redraw(); } });
      const hv = h('output', null, S.height + ' cm');
      const hs = h('input', { type: 'range', min: cfg.height_min || 150, max: cfg.height_max || 205, value: S.height });
      paint(hs);
      hs.addEventListener('input', () => { S.height = Number(hs.value); hv.textContent = S.height + ' cm'; paint(hs); });
      redraw();
      const out = [sec("Fiche d'identité", 'Aperçu', fiche, h('div', { class: 'gk-info' }, ico('user'), 'La photo est prise juste avant votre arrivée en ville.')),
        sec('Informations', 'Définitives', h('div', { class: 'gk-warn' }, ico('alert'), h('b', null, 'Choix définitif.'), " L'identité ne pourra plus être modifiée ensuite."),
          h('div', { class: 'gk-two' }, field('Prénom', f1), field('Nom', f2)), field('Nationalité', nat), field('Date de naissance', h('div', { class: 'gk-dob' }, sd, sm, sy)), h('div', { class: 'gkf' }, h('label', null, 'Taille', hv), hs))];
      if (cfg.ask_bio !== false) {
        const max = cfg.bio_max || 240;
        const cnt = h('small', null, S.bio.length + ' / ' + max);
        out.push(sec('Histoire', 'Facultatif', h('textarea', { maxlength: max, rows: 4, placeholder: "D'où venez-vous ? Pourquoi êtes-vous à Los Santos ?", oninput: (e) => { S.bio = e.target.value; cnt.textContent = S.bio.length + ' / ' + max; } }, S.bio), cnt));
      }
      return out;
    },
    final: () => {
      const out = [];
      const sp = () => points.find((x) => x.id === S.spawn);
      if (cfg.allow_spawn_choice !== false && points.length) {
        const info = h('p', { class: 'gk-spd' }, (sp() && sp().desc) || '');
        out.push(sec('Point de départ', null, spawnPicker(points, S.spawn, (p) => { S.spawn = p.id; info.textContent = p.desc || ''; }), info));
      }
      out.push(sec('Votre personnage', null, h('div', { class: 'gk-sum' }, h('div', { class: 'gk-sum-n' }, (S.first || '—') + ' ' + (S.last || '—')),
        h('div', { class: 'gk-sum-r' }, h('span', null, S.sex === 'f' ? 'Femme' : 'Homme'), h('span', null, S.dob.split('-').reverse().join('/')), h('span', null, S.height + ' cm'), h('span', null, S.nat || '—')), S.bio ? h('p', null, S.bio) : null)));
      if (cfg.rules_required) out.push(h('label', { class: 'gk-acc' }, h('input', { type: 'checkbox', checked: S.accept, onchange: (e) => { S.accept = e.target.checked; } }), h('span', null, cfg.rules_text || 'J\'accepte le règlement.')));
      return out;
    },
  };

  // ---------- choix homme / femme ----------
  function setSex(v, then) {
    const changed = S.sex !== v;
    S.sex = v;
    if (preview) return;
    S.app.model = v === 'f' ? 'mp_f_freemode_01' : 'mp_m_freemode_01';
    G.post('creator.room', { on: false, appearance: S.app }).then((r) => { if (r && r.comps) S.limits = r; if (then) then(); });
    if (changed) { undo.length = 0; lastSnap = JSON.stringify(S.app); }
  }
  function drawPick() {
    G.clear(pickUi);
    let hover = S.sex;
    const labels = {}, btns = {};
    const mark = () => ['m', 'f'].forEach((k) => { labels[k].classList.toggle('on', hover === k); btns[k].classList.toggle('on', hover === k); });
    const choose = (k) => setSex(k, () => { S.step = order.indexOf('perso') + 1; render(); });
    const zone = (k) => h('div', { class: 'gk-z ' + k, onmouseenter: () => { hover = k; mark(); }, onclick: () => choose(k) });
    labels.m = h('div', { class: 'gk-lab m' }, h('small', null, 'Personnage masculin'), h('b', null, 'Homme'));
    labels.f = h('div', { class: 'gk-lab f' }, h('small', null, 'Personnage féminin'), h('b', null, 'Femme'));
    btns.m = h('button', { onmouseenter: () => { hover = 'm'; mark(); }, onclick: () => choose('m') }, 'Homme');
    btns.f = h('button', { onmouseenter: () => { hover = 'f'; mark(); }, onclick: () => choose('f') }, 'Femme');
    add(pickUi, zone('m'), zone('f'), h('div', { class: 'gk-pt' }, h('b', null, 'Choisissez votre personnage'), h('small', null, 'Cliquez sur un personnage')), labels.m, labels.f,
      h('div', { class: 'gk-pb' }, btns.m, btns.f), h('div', { class: 'gk-pk' }, kb('H', 'Homme'), kb('F', 'Femme'), kb('Clic', 'Choisir')));
    mark();
    pickUi.choose = choose;
  }
  const kb = (k, t) => h('span', { class: 'gk-hk' }, [].concat(k).map((x, i) => (x === '+' ? h('i', { key: i }, '+') : h('kbd', null, x))), h('em', null, t));

  // ---------- rendu ----------
  const cur = () => order[S.step];
  function showError(t) { err.textContent = t || ''; err.classList.toggle('hidden', !t); }
  function drawTools() {
    G.clear(tools);
    const id = cur();
    add(tools, h('button', { class: 'gk-t', disabled: !actions[id] || cfg.allow_random === false, onclick: () => { actions[id](); sendPreview(); render(); } }, ico('sparkle'), 'Aléatoire'),
      h('button', { class: 'gk-t', disabled: !undo.length, onclick: doUndo }, ico('back'), 'Défaire', h('kbd', null, 'Ctrl Z')));
  }
  function render() {
    G.clear(body); G.clear(nav); G.clear(rail); G.clear(head); G.clear(hints); showError('');
    const id = cur(), def = id === 'outfit' && opt.only ? { label: opt.title || 'Tenue', sub: opt.subtitle || '', cam: 'body' } : STEP_DEFS[id];
    const room = id === 'perso';
    root.classList.toggle('gk-room', room);
    if (room) { drawPick(); if (!preview) G.post('creator.room', { on: true, sex: S.sex }); return; }
    add(head, h('div', null, h('small', null, opt.only ? '' : 'Création du personnage'), h('b', null, def.label)),
      opt.only ? null : h('div', { class: 'gk-count' }, h('b', null, String(S.step + 1).padStart(2, '0')), ' / ' + String(order.length).padStart(2, '0')));
    if (!opt.only) order.forEach((sid, i) => rail.appendChild(h('button', { class: 'gk-tab' + (i === S.step ? ' on' : (i < S.step ? ' done' : '')), onclick: () => { if (i < S.step || validateUpTo(i)) { S.step = i; render(); } } },
      i < S.step ? ico('check') : h('b', null, String(i + 1)), h('small', null, STEP_DEFS[sid].label))));
    bar.style.width = ((S.step + 1) / order.length * 100) + '%';
    sub.textContent = def.sub;
    if (!preview && def.cam) G.post('creator.cam', { mode: def.cam });
    (pages[id]() || []).forEach((e) => body.appendChild(e));
    body.scrollTop = 0;
    add(hints, kb(['A', 'E'], 'Tourner'), kb('Molette', 'Zoom'), kb('R', 'Recentrer'), kb(['Ctrl', '+', 'Z'], 'Défaire'), kb('Tab', 'Étape suivante'));
    if (opt.only) {
      add(nav, h('button', { class: 'gb', onclick: () => { if (opt.onCancel) opt.onCancel(); } }, 'Annuler'), h('button', { class: 'gb pri', onclick: () => { if (opt.onSubmit) opt.onSubmit(S.app); else showError("Aperçu : rien n'est envoyé."); } }, opt.submitLabel || 'Valider'));
      return;
    }
    drawTools();
    const last = S.step === order.length - 1;
    add(nav, h('button', { class: 'gb', disabled: S.step === 0, onclick: () => { S.step--; render(); } }, ico('back'), 'Précédent'),
      h('button', { class: 'gb pri', onclick: next }, last ? 'Créer mon personnage' : 'Suivant : ' + STEP_DEFS[order[S.step + 1]].label, ico(last ? 'check' : 'chevron')));
  }
  function next() { const last = S.step === order.length - 1; if (last) submit(); else if (validateStep(true)) { S.step++; render(); } }
  function onKey(e) {
    if (!root.isConnected || opt.only) return;
    const typing = e.target && /^(INPUT|TEXTAREA)$/.test(e.target.tagName) && e.target.type !== 'range';
    if (e.key === 'Enter' && !(e.target && e.target.tagName === 'TEXTAREA')) { e.preventDefault(); if (cur() !== 'perso') next(); return; }
    if (e.key === 'Tab') { e.preventDefault(); if (cur() !== 'perso') next(); return; }
    if ((e.key === 'z' || e.key === 'Z') && e.ctrlKey) { e.preventDefault(); doUndo(); return; }
    if (typing) return;
    const k = e.key.toLowerCase();
    if (cur() === 'perso') { if (k === 'h') pickUi.choose('m'); else if (k === 'f') pickUi.choose('f'); return; }
    if (k === 'a') G.post('creator.rotate', { delta: -12 });
    else if (k === 'e') G.post('creator.rotate', { delta: 12 });
    else if (k === 'r') G.post('creator.recenter', {});
  }
  if (!preview) document.addEventListener('keydown', onKey);
  function validateStep(show) {
    if (cur() !== 'ident') return true;
    const re = /^[A-Za-zÀ-ÖØ-öø-ÿ' -]+$/, mn = cfg.name_min || 2, mx = cfg.name_max || 20;
    for (const [v, l] of [[S.first.trim(), 'Prénom'], [S.last.trim(), 'Nom']]) {
      if (v.length < mn || v.length > mx || !re.test(v)) { if (show) showError(l + ' : ' + mn + ' à ' + mx + ' lettres (accents, espace, tiret et apostrophe autorisés).'); return false; }
    }
    if ((cfg.nationalities || []).length && !S.nat) { if (show) showError('Choisissez une nationalité.'); return false; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(S.dob)) { if (show) showError('Date de naissance invalide.'); return false; }
    return true;
  }
  function validateUpTo(i) { const keep = S.step; for (let k = S.step; k < i; k++) { S.step = k; if (!validateStep(true)) { S.step = keep; return false; } } S.step = keep; return true; }
  function submit() {
    if (preview) { showError("Aperçu : rien n'est envoyé."); return; }
    const ident = order.indexOf('ident');
    S.step = ident; if (!validateStep(false)) { render(); validateStep(true); return; }
    S.step = order.length - 1;
    if (cfg.rules_required && !S.accept) { showError('Acceptez le règlement pour continuer.'); return; }
    S.app.model = S.sex === 'f' ? 'mp_f_freemode_01' : 'mp_m_freemode_01';
    G.post('creator.submit', { data: { firstname: S.first.trim(), lastname: S.last.trim(), dob: S.dob, sex: S.sex, height: S.height, nationality: S.nat, appearance: S.app, bio: S.bio.trim(), spawn_id: S.spawn, accept: !!S.accept } });
  }
  render();
  return { el: root, showError, setLimits: (l) => { S.limits = l; }, render, destroy: () => { document.removeEventListener('keydown', onKey); window.removeEventListener('resize', fit); if (root.unbind) root.unbind(); } };
}
G.creatorView = creatorView;
G.spawnMap = spawnMap;

let view = null;
G.on('creator.open', (d) => {
  const r = document.getElementById('g-creator') || (function () { const e = h('div', { id: 'g-creator' }); G.root.appendChild(e); return e; })();
  G.clear(r); r.classList.remove('hidden');
  view = creatorView(d.cfg || {}, { limits: d.limits, spawn: d.spawn });
  r.appendChild(view.el);
});
G.on('creator.error', (d) => { if (view) view.showError(d.text); });
G.on('creator.close', () => { const r = document.getElementById('g-creator'); if (view && view.destroy) view.destroy(); if (r) { G.clear(r); r.classList.add('hidden'); } view = null; });

G.preview.creator = function (box, cfg) {
  G.clear(box);
  const v = creatorView(cfg, { preview: true });
  box.appendChild(h('div', { class: 'gstage tall gk-stage' }, v.el));
};
G.preview.spawnmap = function (box, cfg) {
  G.clear(box);
  const pts = (cfg.spawn_points || []).filter((p) => p.enabled !== false);
  const info = h('div', { class: 'gk-spinfo' }, pts.length ? h('p', null, 'Clique un point pour voir sa fiche.') : h('p', null, 'Aucun point actif : les joueurs apparaîtront à la position par défaut.'));
  let m;
  m = spawnMap(pts, '', (p) => { m.select(p.id); G.clear(info); add(info, h('b', null, p.label), h('p', null, p.desc || '')); }, cfg.c_accent || '#dfe2e7');
  box.appendChild(h('div', { class: 'gk-spprev' }, m, info));
};

})();
