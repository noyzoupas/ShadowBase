/* Tablette citoyen / patron : navigation latérale, cartes à dégradés, tableaux, formulaires. Le serveur décide des pages et des actions ; ici on ne fait qu'afficher. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

function tone(el, t) { const c = t || '#dfe2e7'; el.style.setProperty('--tone', c); el.style.setProperty('--tone-rgb', G.hexToRgb(c)); return el; }

function tabletView(opt) {
  opt = opt || {};
  let frame = opt.frame || { nav: [], name: '' }, page = opt.page || null, cur = (opt.page && opt.page.page) || 'home';
  const nav = h('nav', { class: 'gt-nav' }), body = h('div', { class: 'gt-body' }), toast = h('div', { class: 'gt-toast hidden' }), menu = h('div', { class: 'gt-menu' });
  let showMenu = !opt.compact;   // tablette : on arrive sur les cartes (catégories + sous-catégories) ; téléphone : barre du bas
  let q = '';
  const brand = h('div', { class: 'gt-brand' }), money = h('div', { class: 'gt-money' }), foot = h('div', { class: 'gt-foot' }), topbar = h('header', { class: 'gt-bar' + (opt.compact ? '' : ' gt-hd') });
  const el = h('div', { class: 'gt' + (opt.compact ? ' gt-ph' : ' gt-m') }, topbar, h('div', { class: 'gt-wrap' }, h('aside', { class: 'gt-side' }, brand, nav, foot), h('main', { class: 'gt-main' }, menu, body, toast)), G.festEl());
  let tt = null;
  const say = (ok, msg) => { if (!msg) return; toast.textContent = msg; toast.className = 'gt-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(tt); tt = setTimeout(() => toast.classList.add('hidden'), 4200); };

  function act(name, payload) { opt.onAct && opt.onAct(name, payload || {}, cur); }

  function btn(a) {
    let armed = false;
    const b = h('button', { class: 'gt-btn' + (a.primary ? ' pri' : '') + (a.danger ? ' dng' : ''), disabled: a.disabled || null }, a.icon ? ico(a.icon) : null, a.label);
    b.addEventListener('click', () => {
      if (a.confirm && !armed) { armed = true; b.textContent = 'Confirmer ?'; b.classList.add('arm'); setTimeout(() => { armed = false; b.classList.remove('arm'); b.textContent = a.label; }, 3000); return; }
      act(a.act, a.payload);
    });
    return b;
  }

  const B = {
    hero(b) {
      return null;
      return tone(h('section', { class: 'gt-hero' }, h('div', { class: 'gt-hero-t' }, b.eyebrow ? h('small', { class: 'gt-eb' }, b.eyebrow) : null, h('h2', null, b.title), b.sub ? h('p', null, b.sub) : null),
        b.chips ? h('div', { class: 'gt-chips' }, b.chips.map((c) => h('span', null, h('small', null, c[0]), h('b', null, c[1])))) : null), b.tone);
    },
    tiles(b) {
      return h('section', { class: 'gt-sec gt-qa' }, h('div', { class: 'gt-qh' }, h('h3', null, b.title || 'Accès rapides'), b.tag ? h('small', null, b.tag) : null),
        h('div', { class: 'gt-tiles' }, (b.items || []).map((it) => h('button', { type: 'button', class: 'gt-tile', onclick: () => { if (it.page) { cur = it.page; showMenu = false; renderNav(); renderMenu(); renderPage(); opt.onPage && opt.onPage(it.page); } else if (it.act) act(it.act, it.payload); } },
          h('span', { class: 'gt-ti' }, ico(it.icon || 'info')), h('b', null, it.title), it.sub ? h('small', null, it.sub) : null))));
    },
    cards(b) {
      return h('section', { class: 'gt-cards' + (b.big ? ' big' : '') }, (b.items || []).map((it) => {
        const c = tone(h('article', { class: 'gt-card' },
          h('div', { class: 'gt-card-h' }, h('span', { class: 'gt-ic' }, ico(it.icon || 'info')), it.badge ? h('em', null, it.badge) : null),
          h('small', null, it.title), it.value ? h('strong', null, it.value) : null, it.sub ? h('p', null, it.sub) : null, it.text ? h('p', { class: 'dim' }, it.text) : null,
          it.stats ? h('div', { class: 'gt-cs' }, it.stats.map((s) => h('span', null, h('b', null, s.value), h('small', null, s.label)))) : null), it.tone);
        return c;
      }));
    },
    actions(b) { return h('section', { class: 'gt-sec' }, b.title ? h('h3', null, b.title) : null, h('div', { class: 'gt-row' }, (b.items || []).map(btn))); },
    notice(b) { return h('div', { class: 'gt-note' }, b.text); },
    terrmap(b) {
      // Carte des territoires : pastilles colorées par propriétaire, liste à droite avec la récompense de chaque zone
      const CAL = { ax: -5206.4, bx: 11493.2, ay: 8271.8, by: 12556 };
      const uv = (x, y) => [(x - CAL.ax) / CAL.bx, (CAL.ay - y) / CAL.by];
      const zs = Array.isArray(b.zones) ? b.zones.slice(0, 60) : [];
      const safeCol = (c) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : '#8e95a1');
      const map = h('div', { class: 'tm-map' }), inn = h('div', { class: 'tm-in' }, h('img', { src: 'img/map.jpg', alt: '', draggable: false }));
      const tip = h('div', { class: 'tm-tip hidden' }), list = h('div', { class: 'tm-list' });
      let selId = null;
      const rows = {}, dots = {};
      const pick = (id) => { selId = id; Object.keys(rows).forEach((k) => rows[k].classList.toggle('on', k === id)); Object.keys(dots).forEach((k) => dots[k].classList.toggle('on', k === id)); };
      zs.forEach((z) => {
        const p = uv(Number(z.x) || 0, Number(z.y) || 0), col = safeCol(z.color), id = String(z.id);
        const d = h('b', { class: 'tm-p' + (z.mine ? ' mine' : '') + (z.owner ? '' : ' free'), style: { left: (p[0] * 100) + '%', top: (p[1] * 100) + '%', background: z.owner ? col : 'transparent', borderColor: col } });
        d.addEventListener('mouseenter', () => { tip.textContent = String(z.label || '') + ' · ' + (z.owner ? String(z.owner) : 'Libre'); tip.style.left = (p[0] * 100) + '%'; tip.style.top = (p[1] * 100) + '%'; tip.classList.remove('hidden'); });
        d.addEventListener('mouseleave', () => tip.classList.add('hidden'));
        d.addEventListener('click', () => pick(id));
        dots[id] = d; inn.appendChild(d);
        const r = h('button', { type: 'button', class: 'tm-row' + (z.mine ? ' mine' : ''), onclick: () => pick(id) },
          h('i', { style: { background: z.owner ? col : 'transparent', borderColor: col } }),
          h('span', null, h('b', null, String(z.label || id)), h('small', null, z.owner ? 'Tenue par ' + z.owner : 'Libre')),
          z.reward ? h('em', null, String(z.reward)) : null);
        if (z.reward && z.next) r.appendChild(h('small', { class: 'tm-nx' }, String(z.next)));
        if (z.gps) r.appendChild(h('u', { onclick: (e) => { e.stopPropagation(); act('gps_zone', { id: z.id }); } }, 'GPS'));
        rows[id] = r; list.appendChild(r);
      });
      inn.appendChild(tip); map.appendChild(inn);
      if (!zs.length) list.appendChild(h('div', { class: 'gt-empty' }, 'Aucun territoire défini.'));
      return h('section', { class: 'gt-sec tm' }, b.title ? h('h3', null, b.title) : null, h('div', { class: 'tm-wrap' }, map, list));
    },
    table(b) {
      const cols = b.columns || [];
      const t = h('table', null, h('thead', null, h('tr', null, cols.map((c) => h('th', null, c.label)), h('th'))));
      const tb = h('tbody');
      (b.rows || []).forEach((r) => tb.appendChild(h('tr', null, cols.map((c) => h('td', null, r[c.k] == null ? '' : String(r[c.k]))), h('td', { class: 'gt-ra' }, (r.actions || []).map(btn)))));
      t.appendChild(tb);
      return h('section', { class: 'gt-sec' }, b.title ? h('h3', null, b.title) : null, (b.rows || []).length ? h('div', { class: 'gt-tw' }, t) : h('div', { class: 'gt-empty' }, b.empty || 'Rien à afficher.'));
    },
    form(b) {
      const vals = {}, inputs = [];
      const fields = (b.fields || []).map((f) => {
        let inp;
        if (f.type === 'select') {
          inp = h('select', null, (f.opts || []).map((o) => h('option', { value: o[0] }, o[1])));
          if (!(f.opts || []).length) { inp.appendChild(h('option', { value: '' }, 'Personne à proximité')); inp.disabled = true; }
        } else if (f.type === 'number') inp = h('input', { type: 'number', min: f.min, max: f.max, placeholder: f.label });
        else inp = h('input', { type: 'text', maxlength: f.maxlen || 120, placeholder: f.label });
        inputs.push([f, inp]);
        return h('label', { class: 'gt-f' }, h('small', null, f.label), inp);
      });
      const sb = (b.submit || {});
      const go = h('button', { class: 'gt-btn pri', disabled: sb.disabled || null }, sb.label || 'Valider');
      go.addEventListener('click', () => { const p = {}; inputs.forEach(([f, i]) => { p[f.k] = f.type === 'number' ? (i.value === '' ? null : Number(i.value)) : i.value; }); act(sb.act, p); });
      return h('section', { class: 'gt-sec gt-form' }, h('h3', null, b.title), b.desc ? h('p', { class: 'dim' }, b.desc) : null, h('div', { class: 'gt-fg' }, fields), h('div', { class: 'gt-row' }, go));
    },
  };

  function renderNav() {
    G.clear(nav);
    let last = null;
    (frame.nav || []).forEach((n) => {
      if (n.group !== last) { last = n.group; nav.appendChild(h('small', { class: 'gt-grp' }, n.group)); }
      nav.appendChild(h('button', { class: 'gt-nv' + (n.id === cur ? ' on' : ''), onclick: () => { cur = n.id; showMenu = false; renderNav(); renderMenu(); renderPage(); opt.onPage && opt.onPage(n.id); } }, ico(n.icon || 'info'), h('span', { class: 'gt-nl' }, n.label), n.count != null ? h('em', null, String(n.count)) : null));
    });
    nav.appendChild(h('small', { class: 'gt-grp' }, 'Système'));
    nav.appendChild(h('button', { class: 'gt-nv', onclick: () => opt.onPage && opt.onPage(cur) }, ico('refresh'), h('span', { class: 'gt-nl' }, 'Actualiser')));
    const role = frame.role || (frame.biz && (frame.biz.grade || frame.biz.label)) || 'Citoyen';
    G.clear(brand);
    brand.appendChild(h('span', { class: 'gt-av' }, ico('user')));
    brand.appendChild(h('small', { class: 'gt-eb' }, frame.space || (frame.biz ? 'Espace professionnel' : 'Espace citoyen')));
    brand.appendChild(h('b', null, frame.name || ''));
    brand.appendChild(h('small', { class: 'gt-role' }, role));
    G.clear(foot);
    foot.appendChild(h('span', { class: 'gt-fa' }, ico('user')));
    foot.appendChild(h('div', { class: 'gt-fn' }, h('b', null, String(frame.name || '').toUpperCase()), h('small', null, 'ID ' + (frame.id != null ? frame.id : '—'))));
    if (opt.onClose) foot.appendChild(h('button', { class: 'gt-pw', type: 'button', 'aria-label': 'Fermer', onclick: opt.onClose }, ico('power')));
    G.clear(topbar);
    if (!opt.compact) { renderHead(); tone(el, frame.tone); return; }
    topbar.appendChild(h('div', { class: 'gt-tl' }, (function () { const u = G.assetUrl((G.cfg.brand && G.cfg.brand.logo) || ''); return u ? h('img', { class: 'gt-logo', src: u, alt: '' }) : null; })(), h('b', null, String(frame.brand || 'Tablette').toUpperCase())));
    topbar.appendChild(h('div', { class: 'gt-tr' }, !opt.compact ? h('button', { class: 'gt-hm' + (showMenu ? ' on' : ''), type: 'button', onclick: () => { showMenu = true; renderMenu(); renderPage(); renderNav(); } }, ico('sliders'), 'Menu') : null, opt.onClose ? h('button', { class: 'gt-pw gt-pwt', type: 'button', 'aria-label': 'Fermer', onclick: opt.onClose }, ico('power')) : null));
    tone(el, frame.tone);
  }
  // --- habillage « tablette à tuiles » : en-tête (logo, recherche, boutons ronds, XP) et mosaïque de grandes tuiles-photo ---
  const dest = (id) => { cur = id; showMenu = false; q = ''; renderHead(); renderMenu(); renderPage(); opt.onPage && opt.onPage(id); };
  function roundBtn(icon, title, on, fn) { return h('button', { class: 'gt-rb' + (on ? ' on' : ''), type: 'button', title, 'aria-label': title, onclick: fn }, ico(icon)); }
  function renderHead() {
    G.clear(topbar);
    const logo = G.assetUrl(frame.logo || (G.cfg.brand && G.cfg.brand.logo) || '');
    const search = h('input', { class: 'gt-q', type: 'text', placeholder: 'Tapez ici pour effectuer une recherche…', maxlength: 40, value: q });
    search.addEventListener('input', () => { q = search.value; showMenu = true; renderMenu(); body.classList.toggle('hidden', true); menu.classList.remove('hidden'); });
    const tools = (frame.tools || []).map((t) => roundBtn(t.icon, t.label, cur === t.page && !showMenu, () => dest(t.page)));
    topbar.appendChild(h('div', { class: 'gt-hl' }, logo ? h('img', { class: 'gt-logo', src: logo, alt: '' }) : h('span', { class: 'gt-lg' }, ico(frame.icon || 'shield')),
      h('div', null, h('b', null, String(frame.title || frame.brand || 'Tablette')), h('small', null, frame.subtitle || 'Accueil'))));
    topbar.appendChild(h('label', { class: 'gt-sr' }, ico('search'), search));
    topbar.appendChild(h('div', { class: 'gt-rr' },
      roundBtn('home', 'Accueil', showMenu, () => { showMenu = true; q = ''; renderHead(); renderMenu(); renderPage(); }), tools,
      roundBtn('refresh', 'Actualiser', false, () => opt.onPage && opt.onPage(cur)),
      (frame.xp || []).map((x) => h('span', { class: 'gt-xp' }, ico(x.icon || 'star'), h('b', null, x.value), x.rank ? h('small', null, x.rank) : null)),
      opt.onClose ? roundBtn('power', 'Fermer', false, opt.onClose) : null));
  }
  function spansFor(n) {
    const pat = [3, 3, 2, 2, 2, 3, 3], out = []; let row = 0;
    for (let i = 0; i < n; i++) {
      let sp = pat[i % pat.length];
      if (row + sp > 6) sp = 6 - row;
      const left = n - i - 1, remainRow = 6 - row - sp;
      if (left === 0 && remainRow > 0) sp += remainRow;   // la dernière tuile remplit la ligne
      out.push(sp); row = (row + sp) % 6;
    }
    return out;
  }
  function renderMenu() {
    G.clear(menu);
    menu.classList.toggle('hidden', !showMenu || !!opt.compact);
    body.classList.toggle('hidden', showMenu && !opt.compact);
    if (!showMenu || opt.compact) return;
    let items = (frame.tiles && frame.tiles.length ? frame.tiles : (frame.nav || []).map((n) => ({ id: n.id, page: n.id, title: n.label, icon: n.icon, tone: frame.tone, img: n.img })));
    if (q.trim()) { const k = q.trim().toLowerCase(); items = items.filter((t) => String(t.title || '').toLowerCase().includes(k)); }
    if (!items.length) { menu.appendChild(h('div', { class: 'gt-empty' }, 'Aucun résultat.')); return; }
    // Même présentation que le menu personnel F5 : en-tête (titre, espèces, banque) et grandes cartes avec photo du jeu teintée.
    const KEYS = ['city', 'inv', 'sea', 'sky', 'veh', 'wallet'];
    const brandC = G.accentHex();
    const tn = /^#[0-9a-f]{6}$/i.test(frame.tone || '') ? frame.tone : brandC;
    const root = h('div', { class: 'mc gt-mc', style: { '--srv': tn, '--srvr': G.hexToRgb(tn), '--srv2': '#8e95a1' } });
    root.appendChild(h('div', { class: 'mc-head' },
      h('div', { class: 'mc-hl' }, h('h1', null, String(frame.title || frame.brand || 'Tablette')), h('p', null, String(frame.subtitle || '') + (frame.name ? ' · ' + frame.name : ''))),
      h('div', { class: 'mc-hr' },
        frame.cash != null ? h('span', { class: 'mc-pill' }, ico('wallet', 'mc-pi'), h('b', null, G.money(frame.cash)), h('small', null, 'Espèces')) : null,
        frame.bank != null ? h('span', { class: 'mc-pill' }, ico('card', 'mc-pi'), h('b', null, G.money(frame.bank)), h('small', null, 'Banque')) : null,
        opt.onClose ? h('button', { class: 'mc-x', type: 'button', 'aria-label': 'Fermer', onclick: opt.onClose }, ico('close')) : null)));
    const grid = h('div', { class: 'mc-grid' });
    items.forEach((t, i) => {
      const tc = /^#[0-9a-f]{6}$/i.test(t.tone || '') ? t.tone : tn;
      const u = t.img ? G.assetUrl(t.img) : '';
      const src = u || ('img/cards/' + KEYS[i % KEYS.length] + '.jpg');
      grid.appendChild(h('button', { type: 'button', class: 'mc-card', style: { '--tone': tc, '--tr': G.hexToRgb(tc), '--is': 0.55 }, onclick: () => dest(t.page || t.id) },
        h('i', { class: 'mc-img', style: { backgroundImage: 'url("' + src + '")' } }), h('i', { class: 'mc-shade' }),
        h('span', { class: 'mc-ic' }, ico(t.icon || 'info')),
        t.badge ? h('span', { class: 'mc-bd' }, h('i'), String(t.badge)) : null,
        h('span', { class: 'mc-tx' }, h('small', null, String(t.sub || '')), h('b', null, String(t.title || '')))));
    });
    root.appendChild(grid);
    menu.appendChild(root);
  }
  function renderPage() {
    G.clear(body);
    if (!page) { body.appendChild(h('div', { class: 'gt-empty' }, 'Chargement…')); return; }
    body.appendChild(h('header', { class: 'gt-top' }, h('div', { class: 'gt-th' }, h('h1', null, page.title || ''), page.sub ? h('p', null, page.sub) : null),
      h('button', { class: 'gt-rf', type: 'button', onclick: () => opt.onPage && opt.onPage(cur) }, ico('refresh'), 'Actualiser')));
    (page.blocks || []).forEach((b) => { const f = B[b.type]; const n = f ? f(b) : null; if (n) body.appendChild(n); });
  }
  renderNav(); renderMenu(); renderPage();
  return { el, set(d) { if (d.frame) frame = d.frame; if (d.page) { page = d.page; cur = d.page.page || cur; } renderNav(); renderMenu(); renderPage(); if (d.err) say(false, d.err); }, say };
}
G.tabletView = tabletView;

const live = {};   // 'tablet' (citoyen/entreprise) et 'orga' (tablette des organisations) : même rendu, autres événements
function host(pre) { const id = pre === 'tablet' ? 'g-tablet' : 'g-' + pre; return document.getElementById(id) || (function () { const e = h('div', { id, class: 'hidden' }); G.root.appendChild(e); return e; })(); }
['tablet', 'orga'].forEach((pre) => {
  G.on(pre + '.open', (d) => {
    const r = host(pre); G.clear(r); r.classList.remove('hidden');
    live[pre] = tabletView({ frame: d.frame, page: d.page, onClose: () => G.post(pre + '.close', {}), onPage: (p) => G.post(pre + '.page', { page: p }), onAct: (n, pl, p) => G.post(pre + '.act', { name: n, payload: pl, page: p }) });
    r.appendChild(live[pre].el);
    G.uiStack = G.uiStack.filter((u) => u.id !== pre); G.uiStack.push({ id: pre, onEscape: () => G.post(pre + '.close', {}) });
  });
  G.on(pre + '.page', (d) => { if (live[pre]) live[pre].set(d); });
  G.on(pre + '.result', (d) => { if (!live[pre]) return; live[pre].set(d); live[pre].say(d.ok, d.msg); });
  G.on(pre + '.close', () => { const r = host(pre); G.clear(r); r.classList.add('hidden'); live[pre] = null; G.uiStack = G.uiStack.filter((u) => u.id !== pre); });
});

// Aperçu pour le panel : espace citoyen d'exemple
G.preview.tablet = function (box, cfg) {
  G.clear(box);
  const brandC = G.accentHex();
  const frame = { name: 'Karim Benzema', id: 1, role: 'Police', brand: (cfg && cfg.server) || (G.cfg.brand && G.cfg.brand.name) || 'Ma ville', tone: brandC, cash: 25000, bank: 24750,
    nav: [{ id: 'home', label: 'Accueil', icon: 'home', group: 'Citoyen' }, { id: 'finance', label: 'Finances', icon: 'card', group: 'Citoyen' }, { id: 'invoices', label: 'Factures', icon: 'file', group: 'Citoyen', count: 0 },
      { id: 'biz', label: 'Entreprises', icon: 'building', group: 'Citoyen' }, { id: 'mine', label: 'Mon entreprise', icon: 'briefcase', group: 'Citoyen', count: 'Chef' }, { id: 'profile', label: 'Mon profil', icon: 'user', group: 'Citoyen' }] };
  const page = { page: 'home', title: 'Bonjour, Karim Benzema.', sub: 'Bienvenue dans ton espace citoyen. Consulte tes informations et gère tes démarches depuis ta tablette.', blocks: [
    { type: 'hero', eyebrow: 'Espace citoyen · accès sécurisé', title: 'Tableau de bord citoyen', sub: "Retrouve en un coup d'œil ta situation, tes finances, tes factures et les services disponibles en ville.", chips: [['Statut', 'ACTIF'], ['ID', '1'], ['Emploi', 'police']] },
    { type: 'cards', items: [{ title: 'Compte bancaire', value: '24 750 $', icon: 'bank', sub: 'Solde disponible' }, { title: 'Argent liquide', value: '25 000 $', icon: 'wallet', sub: 'Espèces disponibles' },
      { title: 'Factures', value: '0', icon: 'file', sub: 'Factures en attente' }, { title: 'Emploi actuel', value: 'police', icon: 'briefcase', sub: 'Situation professionnelle' }] },
    { type: 'tiles', title: 'Accès rapides', tag: 'Services citoyens', items: [{ title: 'Finances', sub: 'Comptes & soldes', icon: 'bank', page: 'finance' }, { title: 'Factures', sub: 'Paiements en attente', icon: 'file', page: 'invoices' }, { title: 'Entreprises', sub: 'Services disponibles', icon: 'building', page: 'biz' }, { title: 'Profil', sub: 'Informations personnelles', icon: 'user', page: 'profile' }] }] };
  box.appendChild(G.fitStage(tabletView({ frame, page, onPage: () => {}, onAct: () => {} }).el));
};

})();
