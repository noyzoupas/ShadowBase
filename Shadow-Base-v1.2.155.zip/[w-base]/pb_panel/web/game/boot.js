/* Écran de chargement entre le loading screen et la ville (client/loading.lua) : fond et textes du panel, étape, grand pourcentage, barre.
   Affiché dès le chargement de la page, en jeu seulement. Logo et réglages sont gardés sur le poste : la configuration du serveur
   n'arrive qu'à la fin de la connexion. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, guard = null, bar = null, step = null, pct = null;
const read = (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* rien */ } };
const SAFE = /^(https:\/\/[^\s"'<>()]+|fond\/[\w.\- /]+)$/;
const bgUrl = (u) => (u.indexOf('fond/') === 0 ? 'nui://wb_loading/' + u : u).replace(/ /g, '%20');

// (patch 329) images du panel : fondu enchaîné + flou qui se précise (animation CSS gbSharp)
function layers(list, cls) {
  const wrap = h('div', { class: cls + ' gb-slides' });
  const els = list.map((u, i) => h('div', { class: i ? '' : 'on', style: { backgroundImage: 'url("' + bgUrl(String(u)) + '")' } }));
  els.forEach((e) => wrap.appendChild(e));
  if (els.length > 1) { let i = 0; const t = setInterval(() => { if (!wrap.isConnected) return clearInterval(t); els[i].classList.remove('on'); i = (i + 1) % els.length; els[i].classList.add('on'); }, 7000); }
  return wrap;
}
function show(d) {
  if (el) return;
  let c = {};
  try { c = JSON.parse(read('pb_boot_cfg') || '{}') || {}; } catch (e) { c = {}; }
  const logo = read('pb_boot_logo'), rgb = read('pb_boot_rgb');
  const name = d && d.name ? String(d.name) : '';
  bar = h('i'); step = h('b', null, name ? 'Chargement de la session' : 'Connexion à la ville');
  pct = h('span', null, '');
  const bgs = (Array.isArray(c.bg) ? c.bg : []).filter((u) => SAFE.test(String(u))), bg = bgs[0];
  if (!name) {   // connexion (avant le choix du personnage)
    const server = read('pb_boot_name');
    el = h('div', { id: 'g-boot', class: 'gb-hero' + (d && d.pct ? ' sure' : ''), style: rgb ? { '--gb-rgb': rgb } : {} },
      bg ? layers(bgs, 'gb-h-pic') : h('div', { class: 'gb-h-bg' }), h('div', { class: 'gb-h-vig' }),
      h('div', { class: 'gb-h-mid' },
        h('div', { class: 'gb-h-logo' }, h('i'), h('img', { src: logo || 'img/brand/entree-logo.png', alt: '', onerror: (e) => { e.target.src = 'img/brand/entree-logo.png'; } })),
        server ? h('h1', null, server) : null,
        h('div', { class: 'gb-h-state' }, step, pct),
        h('div', { class: 'gb-bar' }, bar)),
      h('small', { class: 'gb-h-note' }, 'Le jeu se prépare, ne le ferme pas'));
    document.body.appendChild(el);
    return;
  }
  // (patch 328) sans image réglée au panel : l'illustration du serveur (elle porte déjà son logo)
  const art = !bg;
  el = h('div', { id: 'g-boot', class: 'gb-da' + (art ? ' art' : '') + (d && d.pct ? ' sure' : ''), style: rgb ? { '--gb-rgb': rgb } : {} },
    (bg ? layers(bgs, 'gb-bg') : h('div', { class: 'gb-bg on', style: { backgroundImage: 'url("img/brand/arrivee.jpg")' } })), h('div', { class: 'gb-shade' }),
    (logo && !art) ? h('img', { class: 'gb-logo', src: logo, alt: '' }) : null,
    h('div', { class: 'gb-mid' }, h('small', null, c.kick || 'Préparation de votre session'),
      h('h1', null, name ? String(c.title || 'Bonjour {nom}…').replace(/\{nom\}/g, name) : 'Connexion…'), h('p', null, c.text || 'Le chargement ne prend que quelques instants : ne fermez pas le jeu.')),
    h('div', { class: 'gb-low' }, step, pct), h('div', { class: 'gb-bar' }, bar));
  document.body.appendChild(el);
}
function hide() {
  clearTimeout(guard); guard = null;
  if (!el) return;
  const e = el; el = null;
  e.classList.add('bye');
  setTimeout(() => e.remove(), 600);
}
G.on('boot.show', show);
G.on('arrive.open', (d) => { if (el) { el.remove(); el = null; } show({ name: (d && d.name) || '', pct: true }); clearTimeout(guard); guard = setTimeout(hide, 45000); });
G.on('arrive.step', (d) => { if (!el) return; const v = Math.max(0, Math.min(100, Math.round(Number(d.pct) || 0))); if (bar) bar.style.width = v + '%'; if (pct) { pct.textContent = v; pct.appendChild(h('em', null, '%')); } if (step && d.text) step.textContent = String(d.text); });
G.on('arrive.done', hide);
G.on('boot.done', hide);
G.on('boot.ping', () => { clearTimeout(guard); guard = setTimeout(hide, 90000); });   // sécurité si le jeu ne répond plus
G.on('cfg', () => {
  const b = G.cfg && G.cfg.brand, u = (G.cfg && G.cfg.uida) || {};
  if (b && b.logo && G.logoUrl) save('pb_boot_logo', G.logoUrl());
  if (b && b.name) save('pb_boot_name', String(b.name).slice(0, 40));
  save('pb_boot_cfg', JSON.stringify({ kick: u.boot_kick, title: u.boot_title, text: u.boot_text, bg: u.ls_bg }));
  const rgb = G.daAccent ? G.daAccent(G.cfg) : '';
  if (rgb) save('pb_boot_rgb', rgb);
});
if (typeof window.GetParentResourceName === 'function') show();
})();
