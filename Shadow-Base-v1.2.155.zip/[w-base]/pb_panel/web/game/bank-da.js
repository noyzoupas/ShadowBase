/* Banque, écran d'un seul tenant : compte à gauche, activité et historique au centre, opérations à droite. Toutes les opérations passent par le serveur (bank.act). */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const add = (el, ...k) => el.append(...k.filter((x) => x != null));   // append(null) écrirait « null »
const money = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR') + ' $';
const PERIODS = [['12H', 12], ['24H', 24], ['48H', 48], ['3D', 72], ['7D', 168], ['14D', 336], ['30D', 720]];
const LABEL = { deposit: 'Dépôt', withdraw: 'Retrait', transfer_out: 'Virement émis', transfer_in: 'Virement reçu', fee: 'Frais', admin: 'Ajustement', salary: 'Salaire' };
const IN = { deposit: 1, transfer_in: 1, salary: 1 };
const when = (t) => { const d = new Date(t * 1000); return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };

G.bankDa = function (o) {
  let frame = o.frame, op = 'deposit', hours = 12, sel = null, amount = 500, iban = '', note = '', flash = null;
  const left = h('section', { class: 'bk-col bk-l' }), mid = h('section', { class: 'bk-mid' }), right = h('section', { class: 'bk-col bk-r' }), top = h('header', { class: 'bk-top' });
  const win = h('div', { class: 'bk-win' }, top, left, mid, right, h('footer', { class: 'bk-keys' }, h('span', null, h('kbd', null, 'Clic'), 'Sélectionner'), h('span', null, h('kbd', null, 'Molette'), 'Défiler'), h('span', null, h('kbd', null, 'Échap'), 'Fermer')));
  const el = h('div', { class: 'bk' + (frame.da.atm ? ' atm' : '') }, win);
  const fit = () => el.style.setProperty('--k', String(Math.min(window.innerWidth / 1920, window.innerHeight / 1080)));
  fit(); window.addEventListener('resize', fit);
  const acc = (frame.da.color && /^#[0-9a-f]{6}$/i.test(frame.da.color)) ? frame.da.color : '#27a04f';   // banque : vert, indépendant de la couleur du serveur
  el.style.setProperty('--bk', acc); el.style.setProperty('--bk-rgb', G.hexToRgb(acc));

  function drawTop() {
    const d = frame.da;
    G.clear(top);
    add(top, h('b', { class: 'bk-brand' }, String(d.brand || 'Fleeca').toUpperCase()), h('i'), h('span', { class: 'bk-t' }, d.atm ? 'Distributeur' : 'Banque'), h('span', { class: 'bk-chip' }, ico('user'), 'Personnel'), h('em'),
      h('div', { class: 'bk-cash' }, h('small', null, 'Liquide sur vous'), h('b', null, money(d.cash))), h('span', { class: 'bk-iban' }, ico('card'), String(d.iban || '—')), h('button', { class: 'bk-x', 'aria-label': 'Fermer', onclick: o.onClose }, ico('close')));
  }
  const row = (k, v, cls) => h('div', { class: 'bk-row' + (cls ? ' ' + cls : '') }, h('span', null, k), h('b', null, v));
  const limit = (k, used, max) => { const left2 = Math.max(0, max - used); return h('div', { class: 'bk-lim' }, row(k, money(left2) + ' / ' + money(max)), h('i', null, h('u', { style: { width: (left2 / Math.max(1, max) * 100) + '%' } }))); };
  function drawLeft() {
    const d = frame.da;
    G.clear(left);
    add(left, h('div', { class: 'bk-h' }, h('b', null, 'Compte'), h('small', null, 'Compte personnel')),
      h('div', { class: 'bk-card' }, h('div', { class: 'bk-cr' }, h('b', { class: 'bk-cb' }, String(d.brand || 'Fleeca').toUpperCase()), h('span', null, 'Standard')),
        h('small', null, 'Solde disponible'), h('div', { class: 'bk-bal' }, Math.floor(Number(d.bank) || 0).toLocaleString('fr-FR'), h('em', null, ' $')),
        h('div', { class: 'bk-no' }, '•••• •••• ' + String(d.iban || '').slice(-4)), h('b', { class: 'bk-own' }, String(d.owner || '')), h('i', { class: 'bk-chipc' })),
      h('div', { class: 'bk-tags' }, h('span', null, 'Compte personnel'), h('span', null, 'Formule Standard')),
      row('Titulaire', String(d.owner || '')), row('IBAN', String(d.iban || '—')),
      d.day_max > 0 ? limit(d.atm ? 'Retraits du jour restants' : 'Plafond journalier restant', d.day_used, d.day_max) : null,
      d.atm ? null : row('Frais de virement', d.tr_fee + ' %'), d.atm ? row('Frais de retrait', d.atm_fee + ' %') : row('Virement maximum', money(d.tr_max)));
  }
  function drawMid() {
    const d = frame.da, now = Date.now() / 1000, since = now - hours * 3600;
    const list = (d.tx || []).filter((t) => t.at >= since);
    let inn = 0, out = 0;
    list.forEach((t) => { if (IN[t.kind]) inn += t.amount; else out += t.amount; });
    G.clear(mid);
    mid.appendChild(h('div', { class: 'bk-h' }, h('b', null, 'Activité du compte'), h('em'),
      h('div', { class: 'bk-per' }, PERIODS.map(([l, v]) => h('button', { class: v === hours ? 'on' : '', onclick: () => { hours = v; drawMid(); } }, l)))));
    mid.appendChild(h('div', { class: 'bk-stats' }, [['Entrées', '+ ' + money(inn), 'in'], ['Sorties', '- ' + money(out), 'out'], ['Balance', (inn - out >= 0 ? '+ ' : '- ') + money(Math.abs(inn - out)), 'in']].map(([a, b, c]) => h('div', { class: c }, h('small', null, a), h('b', null, b)))));
    // courbe du solde sur la période : du plus ancien au plus récent
    const W = 620, H = 180, asc = list.slice().sort((a, b) => a.at - b.at);
    const pts = asc.map((t) => [t.at, t.bal]);
    const startBal = asc.length ? asc[0].bal + (IN[asc[0].kind] ? -asc[0].amount : asc[0].amount) : Number(d.bank) || 0;
    pts.unshift([since, startBal]); pts.push([now, Number(d.bank) || 0]);
    const ys = pts.map((p) => p[1]), min = Math.min.apply(null, ys), max = Math.max.apply(null, ys), span = max - min || 1;
    const X = (t) => ((t - since) / (now - since)) * W, Y = (v) => H - 14 - ((v - min) / span) * (H - 34);
    let line = '';
    pts.forEach((p, i) => { line += (i ? 'L' : 'M') + X(p[0]).toFixed(1) + ' ' + (i && max === min ? Y(min).toFixed(1) : Y(p[1]).toFixed(1)) + ' '; });
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); svg.setAttribute('class', 'bk-chart'); svg.setAttribute('preserveAspectRatio', 'none');
    const a = document.createElementNS(NS, 'path'); a.setAttribute('d', line + 'L' + W + ' ' + H + ' L0 ' + H + ' Z'); a.setAttribute('class', 'a');
    const l = document.createElementNS(NS, 'path'); l.setAttribute('d', line); l.setAttribute('class', 'l');
    add(svg, a, l);
    const ticks = h('div', { class: 'bk-ticks' }); for (let i = 0; i < 4; i++) { const t = new Date((since + (now - since) * (i + 0.5) / 4) * 1000); ticks.appendChild(h('span', null, String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0'))); }
    mid.appendChild(h('div', { class: 'bk-graph' }, svg, ticks));
    const hist = h('div', { class: 'bk-list' }), detail = h('div', { class: 'bk-det' });
    const all = d.tx || [];
    if (!all.length) hist.appendChild(h('div', { class: 'bk-empty' }, ico('card'), h('b', null, 'Aucune transaction enregistrée.')));
    all.forEach((t) => hist.appendChild(h('button', { class: 'bk-tx' + (sel === t.id ? ' on' : ''), onclick: () => { sel = t.id; drawMid(); } }, h('i', { class: IN[t.kind] ? 'in' : 'out' }, IN[t.kind] ? '↑' : '↓'),
      h('div', null, h('b', null, LABEL[t.kind] || String(t.kind)), h('small', null, when(t.at))), h('em', { class: IN[t.kind] ? 'in' : 'out' }, (IN[t.kind] ? '+ ' : '- ') + money(t.amount)))));
    const s = all.find((t) => t.id === sel);
    if (s) add(detail, h('h3', null, LABEL[s.kind] || String(s.kind)), row('Montant', money(s.amount)), row('Date', when(s.at)), row('Solde après', money(s.bal)), s.other ? row('Compte', String(s.other)) : null, s.note ? h('p', null, String(s.note)) : null);
    else detail.appendChild(h('div', { class: 'bk-empty' }, ico('file'), h('b', null, 'Sélectionnez une transaction pour voir les détails.')));
    const nIn = all.filter((t) => IN[t.kind]).length;
    mid.appendChild(h('div', { class: 'bk-bot' }, h('div', { class: 'bk-hc' }, h('div', { class: 'bk-h' }, h('b', null, 'Historique'), h('em'), h('span', { class: 'bk-n' }, '↑ ' + nIn), h('span', { class: 'bk-n' }, '↓ ' + (all.length - nIn)), h('span', { class: 'bk-n' }, all.length + ' total')), hist),
      h('div', { class: 'bk-dc' }, h('div', { class: 'bk-h' }, h('b', null, 'Détails')), detail)));
  }
  function drawRight() {
    const d = frame.da;
    G.clear(right);
    const OPS = [['deposit', 'Déposer', '↑'], ['withdraw', 'Retirer', '↓'], ['transfer', 'Virement', '⇄']].filter((x) => !d.atm || x[0] === 'withdraw');
    if (d.atm) op = 'withdraw';
    const INFO = { deposit: ["Dépôt d'argent", 'Transférez du liquide vers votre compte', 'Confirmer le dépôt'], withdraw: ["Retrait d'argent", 'Transférez de votre compte vers votre liquide', 'Confirmer le retrait'], transfer: ['Virement', 'Envoyez de l\'argent vers un autre compte', 'Envoyer le virement'] }[op];
    const input = h('input', { type: 'text', inputmode: 'numeric', maxlength: 10, value: String(amount), oninput: (e) => { amount = parseInt(e.target.value.replace(/\D/g, ''), 10) || 0; e.target.value = amount ? String(amount) : ''; recap(); } });
    const rec = h('div', { class: 'bk-rec' });
    const recap = () => {
      G.clear(rec);
      const fee = op === 'transfer' ? Math.floor(amount * d.tr_fee / 100 + 0.5) : (op === 'withdraw' && d.atm ? Math.floor(amount * d.atm_fee / 100 + 0.5) : 0);
      const after = op === 'deposit' ? d.bank + amount : d.bank - amount - fee;
      add(rec, row('Solde disponible', money(d.bank)), row('Argent liquide', money(d.cash)), fee ? row('Frais', money(fee)) : null, h('i'), row(op === 'deposit' ? 'Montant à déposer' : op === 'withdraw' ? 'Montant à retirer' : 'Montant à envoyer', money(amount), 'ac'), row('Solde après opération', money(after)));
    };
    add(right, h('div', { class: 'bk-h' }, h('b', null, 'Opérations')),
      h('div', { class: 'bk-ops' }, OPS.map(([k, l, s]) => h('button', { class: k === op ? 'on' : '', onclick: () => { op = k; drawRight(); } }, h('i', null, s), l))),
      h('div', { class: 'bk-oi' }, h('i', null, op === 'withdraw' ? '↓' : op === 'deposit' ? '↑' : '⇄'), h('div', null, h('b', null, INFO[0]), h('small', null, INFO[1]))),
      op === 'transfer' ? h('label', { class: 'bk-f' }, 'IBAN du destinataire', h('div', { class: 'bk-in' }, h('input', { type: 'text', maxlength: 16, value: iban, placeholder: 'PB00000000', oninput: (e) => { iban = e.target.value; } }))) : null,
      h('label', { class: 'bk-f' }, 'Montant', h('div', { class: 'bk-in' }, input, h('span', null, '$'))),
      op === 'transfer' ? h('label', { class: 'bk-f' }, 'Motif (facultatif)', h('div', { class: 'bk-in' }, h('input', { type: 'text', maxlength: 80, value: note, oninput: (e) => { note = e.target.value; } }))) : null,
      h('div', { class: 'bk-quick' }, [100, 500, 1000, 5000, 10000, 50000].map((v) => h('button', { onclick: () => { amount += v; input.value = String(amount); recap(); } }, '+' + v.toLocaleString('fr-FR')))),
      h('button', { class: 'bk-go', onclick: () => { if (!amount) return; o.onAct(op, op === 'transfer' ? { amount, iban, note } : { amount }, frame.page || 'home'); } }, ico('check'), INFO[2]),
      flash ? h('div', { class: 'bk-msg ' + (flash[0] ? 'ok' : 'ko') }, String(flash[1])) : null,
      h('div', { class: 'bk-rect' }, ico('file'), 'Récapitulatif'), rec);
    recap();
  }
  function all() { drawTop(); drawLeft(); drawMid(); drawRight(); }
  all();
  return { el, set(d) { if (d && d.frame && d.frame.da) { frame = d.frame; all(); } }, say(ok, msg) { flash = [ok, msg]; if (ok) { amount = 500; iban = ''; note = ''; } drawRight(); setTimeout(() => { flash = null; if (el.isConnected) drawRight(); }, 4000); }, destroy() { window.removeEventListener('resize', fit); } };
};
})();
