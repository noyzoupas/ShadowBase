/* Boutique du serveur (coins) v5 — (v1.2.78) refaite dans la DA Shadow Studio V2 (noir et verre, couleur du serveur en accent),
   mise en page « boutique de serveur » : onglets en haut (Accueil, catégories, Boutique du jour avec son minuteur, Panier),
   solde et « Quitter » à droite ; cartes avec rareté, réduction, stock, « 1 par joueur », bouton + (panier) et Acheter / Solde insuffisant ;
   fiche d'un article (caractéristiques, contenu, Acheter, Ajouter au panier, Offrir à un joueur) ; VIP en paliers ; panier avec récapitulatif,
   confirmation et suggestions ; Mes achats et Historique.
   Le serveur décide de tout (prix, stock, offres du jour, livraison) : ici on affiche et on envoie premium.buy / premium.claim / premium.close.
   Le panier passe les achats un par un (chacun revérifié par le serveur). Tout texte venant du serveur est inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
let cur = null;
const host = () => document.getElementById('g-premium') || (function () { const e = h('div', { id: 'g-premium', class: 'hidden' }); G.root.appendChild(e); return e; })();
const num = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR');
const hexRgb = (c) => { c = String(c).replace('#', ''); return [0, 2, 4].map((i) => parseInt(c.substr(i, 2), 16) || 0).join(','); };
const CAT_ICO = { vehicle: 'car', weapon: 'crosshair', vip: 'crown', boost: 'bolt', villa: 'home', money: 'coins', item: 'box', plate: 'card' };
const KIND = { vehicle: 'Véhicule', weapon: 'Arme', vip: 'VIP', boost: 'Boost', villa: 'Villa', money: 'Argent', item: 'Objet', plate: 'Plaque' };
const pad = (n) => String(Math.max(0, Math.floor(n))).padStart(2, '0');
const hm = (s) => pad(s / 3600) + ':' + pad((s % 3600) / 60);
const hms = (s) => pad(s / 3600) + 'h ' + pad((s % 3600) / 60) + 'm ' + pad(s % 60) + 's';

function premiumView(o) {
  let d = o.d || {};
  const rar = {};
  (d.rarity || [{ id: 'commun', label: 'Commun', color: '#9aa3b2' }]).forEach((r) => { rar[r.id] = r; });
  const R = (id) => rar[id] || rar.commun || { label: 'Commun', color: '#9aa3b2' };
  const accent = /^#[0-9a-f]{6}$/i.test(d.accent || '') ? d.accent : G.accentHex();
  const coinName = () => String(d.coin || 'Coins');
  const st = { view: 'home', cart: [], tab: 'cart', queue: null };
  let resetAt = Date.now() + (Number(d.reset_in) || 0) * 1000;
  const left = () => Math.max(0, Math.round((resetAt - Date.now()) / 1000));

  // --- squelette ---
  const logo = (G.cfg && G.cfg.brand && G.cfg.brand.logo) ? G.assetUrl(G.cfg.brand.logo) : G.logoUrl();
  const nav = h('nav', { class: 'kb-nav' });
  const right = h('div', { class: 'kb-hr' });
  const sub = h('div', { class: 'kb-sub' });
  const main = h('main', { class: 'kb-main' });
  const modal = h('div', { class: 'kb-modal hidden' });
  const toast = h('div', { class: 'kb-toast hidden' });
  const el = h('div', { class: 'kb', style: { '--acc': accent, '--acc-rgb': hexRgb(accent) } },
    h('div', { class: 'kb-win' },
      h('header', { class: 'kb-head' },
        h('div', { class: 'kb-brand' }, h('img', { src: logo, alt: '', 'data-pblogo': '1' }), h('div', null, h('small', null, String(d.name || 'Boutique').replace(/\s*boutique\s*/i, '') || 'Serveur'), h('b', null, 'Boutique'))),
        nav, right),
      sub, main),
    modal, toast);
  let tt = null;
  function say(ok, msg) { if (!msg) return; toast.textContent = String(msg); toast.className = 'kb-toast ' + (ok ? 'ok' : 'bad'); clearTimeout(tt); tt = setTimeout(() => toast.classList.add('hidden'), 4500); }

  // --- utilitaires ---
  const allItems = () => (d.items || []);
  const catOf = (id) => (d.cats || []).find((c) => c.id === id) || {};
  const blockedOf = (c) => c.owned || c.taken || c.off || c.stock === 0 || (c.daily && c.bought);
  const cartCount = () => st.cart.reduce((n, l) => n + l.qty, 0);
  const cartTotal = () => st.cart.reduce((n, l) => n + l.c.price * l.qty, 0);
  const keyOf = (c) => (c.daily ? 'd' : 'i') + c.id;
  function addCart(c, qty) {
    if (blockedOf(c)) return;
    if (c.cat === 'plate') { open(c); return; }   // une plaque demande son texte : par la fiche
    const k = keyOf(c);
    const l = st.cart.find((x) => x.k === k);
    const max = c.daily || c.limit ? 1 : Math.max(1, Number(c.maxq) || 1);
    if (l) l.qty = Math.min(max, l.qty + (qty || 1)); else st.cart.push({ k, c, qty: Math.min(max, qty || 1) });
    G.click(); say(true, String(c.label) + ' ajouté au panier.');
    drawNav();
  }
  function img(c, big) {
    const box = h('div', { class: 'kb-img' + (big ? ' big' : '') });
    const src = G.assetUrl(c.img || '') || (c.img && /^https:\/\//.test(c.img) ? c.img : '');
    const glyph = () => box.appendChild(h('span', { class: 'kb-glyph' }, ico(CAT_ICO[c.cat] || c.icon || 'star')));
    if (src) { const im = h('img', { src, alt: '', loading: 'lazy' }); im.addEventListener('error', () => { im.remove(); glyph(); }); box.appendChild(im); } else glyph();
    return box;
  }
  const pctOf = (c) => c.promo || (c.was > c.price ? Math.round((1 - c.price / c.was) * 100) : 0);
  const priceEl = (c, cls) => h('span', { class: 'kb-price ' + (cls || '') }, ico('coins'), h('b', null, num(c.price)), c.was && c.was > c.price ? h('s', null, num(c.was)) : null);

  // --- en-tête : onglets, solde, quitter ---
  function navBtn(id, label, extra, cls) {
    return h('button', { type: 'button', class: 'kb-tab' + (st.view === id ? ' on' : '') + (cls ? ' ' + cls : ''), onclick: () => go(id) }, label, extra || null);
  }
  function drawNav() {
    G.clear(nav);
    nav.appendChild(navBtn('home', 'Accueil'));
    (d.cats || []).forEach((c) => { if (allItems().some((i) => i.cat === c.id)) nav.appendChild(navBtn(c.id, c.label)); });
    if ((d.daily || []).length) nav.appendChild(navBtn('daily', 'Boutique du jour', h('em', { class: 'kb-clock' }, hm(left())), 'hot'));
    const n = cartCount();
    nav.appendChild(navBtn('cart', 'Panier', n ? h('i', { class: 'kb-count' }, String(n)) : null, 'cart'));
    G.clear(right);
    right.appendChild(h('div', { class: 'kb-coins', title: 'Ton solde' }, ico('coins'), h('b', null, num(d.coins)), h('small', null, coinName())));
    right.appendChild(h('button', { type: 'button', class: 'kb-quit', onclick: () => { G.click(); o.onClose && o.onClose(); } }, ico('chevron'), 'Quitter'));
  }
  function drawSub(icon, t, s) {
    G.clear(sub);
    const ini = String(d.who || '?').split(/\s+/).map((w) => w.charAt(0)).join('').slice(0, 2).toUpperCase();
    sub.append(h('div', { class: 'kb-st' }, ico(icon), h('b', null, t), s ? h('small', null, s) : null),
      h('div', { class: 'kb-me' }, h('span', { class: 'kb-av' }, ini), h('b', null, String(d.who || '')), d.id != null ? h('small', null, 'ID ' + d.id) : null,
        d.vip ? h('span', { class: 'kb-vipb' }, ico('crown'), 'VIP') : null));
  }
  function go(view) { if (st.view !== view) G.click(); st.view = view; closeModal(); draw(); main.scrollTop = 0; }

  // --- cartes ---
  function card(c, big) {
    const r = R(c.rarity);
    const blocked = blockedOf(c);
    const enough = Number(d.coins) >= Number(c.price);
    const pct = pctOf(c);
    const tags = h('div', { class: 'kb-tags' }, pct ? h('span', { class: 'kb-off' }, '-' + pct + ' %') : null, big ? h('span', { class: 'kb-hl' }, 'Offre phare') : null);
    let action;
    if (blocked) action = h('span', { class: 'kb-state' }, ico('check'), c.owned ? 'Possédé' : (c.daily && c.bought ? 'Déjà acheté' : (c.taken ? 'Déjà prise' : 'Indisponible')));
    else action = h('div', { class: 'kb-acts' },
      c.cat !== 'plate' ? h('button', { type: 'button', class: 'kb-plus', title: 'Ajouter au panier', onclick: (e) => { e.stopPropagation(); addCart(c); } }, ico('plus')) : null,
      h('button', { type: 'button', class: 'kb-buy' + (enough ? '' : ' poor'), onclick: (e) => { e.stopPropagation(); G.click(); open(c); } }, enough ? 'Acheter' : 'Solde insuffisant'));
    const foot = [];
    if (c.stock != null) foot.push(c.stock_max ? (c.stock + ' restant' + (c.stock > 1 ? 's' : '') + ' sur ' + c.stock_max) : (c.stock + ' en stock'));
    if (c.limit || c.daily) foot.push(c.daily ? '1 par jour' : (c.limit === 1 ? '1 par joueur' : c.limit + ' par joueur'));
    return h('article', { class: 'kb-card' + (big ? ' big' : '') + (blocked ? ' done' : ''), style: { '--rc': r.color, '--rc-rgb': hexRgb(r.color) }, onclick: () => { G.click(); open(c); } },
      h('div', { class: 'kb-media' }, img(c, big), tags),
      h('div', { class: 'kb-cb' },
        h('small', { class: 'kb-kind' }, (KIND[c.cat] || catOf(c.cat).label || ''), h('i'), h('span', { style: { color: r.color } }, r.label)),
        h('b', { class: 'kb-name' }, String(c.label || '')),
        c.sub ? h('small', { class: 'kb-desc' }, String(c.sub)) : null,
        h('div', { class: 'kb-row' }, priceEl(c), action),
        foot.length ? h('div', { class: 'kb-foot' }, foot.map((t) => h('span', null, t))) : null));
  }
  const empty = (icon, t, s) => h('div', { class: 'kb-empty' }, ico(icon), h('b', null, t), s ? h('small', null, s) : null);
  const grid = (list, cls) => h('div', { class: 'kb-grid ' + (cls || '') }, list);

  // --- pages ---
  function pageHome() {
    drawSub('home', 'Accueil', 'Les offres du moment et le meilleur de chaque catégorie');
    const daily = d.daily || [];
    const rank = (c) => (R(c.rarity) && Object.keys(rar).indexOf(c.rarity)) || 0;
    const pool = allItems().filter((c) => !blockedOf(c));
    const hero = daily.find((c) => !blockedOf(c)) || pool.slice().sort((a, b) => rank(b) - rank(a) || b.price - a.price)[0];
    const top = h('div', { class: 'kb-home' });
    if (hero) top.appendChild(card(hero, true));
    const side = h('div', { class: 'kb-hside' });
    daily.filter((c) => c !== hero).slice(0, 4).forEach((c) => side.appendChild(card(c)));
    if (!side.childElementCount) pool.filter((c) => c !== hero).slice(0, 4).forEach((c) => side.appendChild(card(c)));
    top.appendChild(side);
    main.appendChild(top);
    if (daily.length) main.appendChild(h('div', { class: 'kb-reset' }, ico('clock'), 'Renouvellement de la boutique du jour dans ', h('b', { class: 'kb-live' }, hms(left()))));
    (d.cats || []).forEach((cat) => {
      const list = allItems().filter((i) => i.cat === cat.id);
      if (!list.length) return;
      main.appendChild(h('div', { class: 'kb-sec' }, h('b', null, cat.label), h('button', { type: 'button', class: 'kb-more', onclick: () => go(cat.id) }, 'Voir tout', ico('chevron'))));
      main.appendChild(grid(list.slice(0, 4).map((c) => card(c)), 'row'));
    });
  }
  function pageDaily() {
    drawSub('clock', 'Boutique du jour', 'Des offres exclusives qui changent chaque jour · -' + (d.daily_pct || 0) + ' % · un achat par offre');
    main.appendChild(h('div', { class: 'kb-reset' }, ico('clock'), 'Nouvelles offres dans ', h('b', { class: 'kb-live' }, hms(left()))));
    const list = d.daily || [];
    if (!list.length) { main.appendChild(empty('clock', 'Aucune offre aujourd\'hui')); return; }
    main.appendChild(grid(list.map((c, i) => card(c, i === 0)), 'daily'));
  }
  function pageVip(cat) {
    drawSub('crown', cat.label || 'VIP', cat.sub || 'Les avantages VIP');
    const list = allItems().filter((i) => i.cat === 'vip').slice().sort((a, b) => a.price - b.price);
    const best = list.length >= 3 ? list[Math.floor(list.length / 2)] : null;
    const tiers = list.map((c, i) => {
      const blocked = blockedOf(c);
      const enough = Number(d.coins) >= Number(c.price);
      const stars = Math.min(3, i + 1);
      return h('article', { class: 'kb-tier' + (c === best ? ' best' : ''), style: { '--rc': R(c.rarity).color } },
        c === best ? h('span', { class: 'kb-reco' }, 'Recommandé') : null,
        h('div', { class: 'kb-th' }, h('div', { class: 'kb-stars' }, Array.from({ length: stars }, () => ico('star'))), h('b', null, String(c.label || '')), c.sub ? h('small', null, String(c.sub)) : null),
        c.descr && !c.descr_in_list ? h('p', null, String(c.descr)) : null,
        h('ul', null, (c.incl || []).map((t) => h('li', null, ico('check'), h('span', null, String(t))))),
        h('div', { class: 'kb-tf' }, priceEl(c),
          blocked ? h('span', { class: 'kb-state' }, ico('check'), c.owned ? 'Actif' : 'Indisponible')
            : h('button', { type: 'button', class: 'kb-buy' + (enough ? '' : ' poor'), onclick: () => { G.click(); open(c); } }, enough ? 'Acheter' : 'Solde insuffisant')),
        !blocked && c.gift ? h('button', { type: 'button', class: 'kb-ghost', onclick: () => { G.click(); giftModal(c); } }, ico('gift'), 'Offrir') : null);
    });
    if (!tiers.length) { main.appendChild(empty('crown', 'Aucune offre VIP pour le moment')); return; }
    main.appendChild(h('div', { class: 'kb-tiers' }, tiers));
  }
  function pageCat(id) {
    const cat = catOf(id);
    if (id === 'vip') { pageVip(cat); return; }
    drawSub(cat.icon || CAT_ICO[id] || 'star', cat.label || 'Boutique', cat.sub || '');
    const list = allItems().filter((i) => i.cat === id);
    if (!list.length) { main.appendChild(empty('star', 'Rien pour le moment', 'Le staff prépare cette catégorie.')); return; }
    main.appendChild(grid(list.map((c) => card(c))));
  }
  function pageCart() {
    drawSub('cart', 'Panier', st.tab === 'cart' ? 'Vérifie ta commande avant de valider' : (st.tab === 'mine' ? 'Ce que tu as acheté' : 'Mouvements de ' + coinName().toLowerCase()));
    const pill = (id, label, n) => h('button', { type: 'button', class: 'kb-pill' + (st.tab === id ? ' on' : ''), onclick: () => { G.click(); st.tab = id; draw(); } }, label, n ? h('i', null, String(n)) : null);
    main.appendChild(h('div', { class: 'kb-pills' }, pill('cart', 'Panier', cartCount()), pill('mine', 'Mes achats', (d.owned || []).length), pill('hist', 'Historique des achats')));
    if (st.tab === 'mine') { pageMine(); return; }
    if (st.tab === 'hist') { pageHist(); return; }
    const lines = h('div', { class: 'kb-lines' });
    if (!st.cart.length) lines.appendChild(empty('cart', 'Ton panier est vide', 'Ajoute des articles avec le bouton +.'));
    st.cart.forEach((l) => {
      const c = l.c;
      const max = c.daily || c.limit ? 1 : Math.max(1, Number(c.maxq) || 1);
      const q = (n) => { l.qty = Math.max(1, Math.min(max, n)); draw(); };
      lines.appendChild(h('div', { class: 'kb-line' }, img(c),
        h('div', { class: 'kb-li' }, h('small', null, (KIND[c.cat] || '') + (c.daily ? ' · offre du jour' : '')), h('b', null, String(c.label || ''))),
        h('div', { class: 'kb-q' }, h('button', { type: 'button', disabled: l.qty <= 1 || null, onclick: () => { G.click(); q(l.qty - 1); } }, '−'), h('b', null, String(l.qty)),
          h('button', { type: 'button', disabled: l.qty >= max || null, onclick: () => { G.click(); q(l.qty + 1); } }, '+')),
        h('span', { class: 'kb-lp' }, ico('coins'), h('b', null, num(c.price * l.qty))),
        h('button', { type: 'button', class: 'kb-del', title: 'Retirer', onclick: () => { G.click(); st.cart = st.cart.filter((x) => x !== l); draw(); } }, ico('trash'))));
    });
    const total = cartTotal(), enough = Number(d.coins) >= total;
    const recap = h('aside', { class: 'kb-recap' }, h('b', { class: 'kb-rt' }, 'Récapitulatif'),
      h('div', { class: 'kb-rr' }, h('span', null, 'Sous-total · ' + cartCount() + ' article' + (cartCount() > 1 ? 's' : '')), h('b', null, num(total))),
      h('div', { class: 'kb-rr' }, h('span', null, 'Ton solde'), h('b', null, num(d.coins))),
      h('i', { class: 'kb-rsep' }),
      h('div', { class: 'kb-rr total' }, h('span', null, 'Total'), h('b', null, ico('coins'), num(total))),
      !enough && total > 0 ? h('small', { class: 'kb-miss' }, 'Il te manque ' + num(total - d.coins) + ' ' + coinName() + '.') : null,
      h('button', { type: 'button', class: 'kb-buy wide' + (enough ? '' : ' poor'), disabled: (!st.cart.length || !enough) || null, onclick: () => { G.click(); confirmCart(); } }, ico('cart'), enough ? 'Valider la commande' : 'Solde insuffisant'),
      h('button', { type: 'button', class: 'kb-ghost wide', onclick: buyCoins }, ico('gem'), 'Acheter des ' + coinName().toLowerCase()));
    main.appendChild(h('div', { class: 'kb-cart' }, lines, recap));
    // suggestions
    const inCart = new Set(st.cart.map((l) => l.c.id));
    const sugg = allItems().filter((c) => !inCart.has(c.id) && !blockedOf(c)).sort((a, b) => (pctOf(b) - pctOf(a)) || (a.price - b.price)).slice(0, 4);
    if (sugg.length) { main.appendChild(h('div', { class: 'kb-sec' }, h('b', null, 'Vous aimerez aussi'))); main.appendChild(grid(sugg.map((c) => card(c)), 'row')); }
  }
  function pageMine() {
    const list = h('div', { class: 'kb-list' });
    if (!(d.owned || []).length) { list.appendChild(empty('box', 'Aucun achat pour le moment', 'Arme ou véhicule à récupérer, GPS de ta villa : tout apparaît ici.')); main.appendChild(list); return; }
    (d.owned || []).forEach((r) => list.appendChild(h('div', { class: 'kb-hrow' }, h('span', { class: 'kb-hi' }, ico(CAT_ICO[r.cat] || 'star')),
      h('div', null, h('b', null, String(r.label)), h('small', null, [r.info, r.from ? 'offert par ' + r.from : null, r.at ? new Date(r.at * 1000).toLocaleDateString('fr-FR') : null].filter(Boolean).join(' · '))),
      r.act ? h('button', { type: 'button', class: 'kb-buy sm' + (r.wait ? ' poor' : ''), disabled: r.wait ? true : null, onclick: () => { G.click(); o.onClaim && o.onClaim(r.id); } }, r.wait ? 'Dans ' + r.wait : r.act) : null)));
    main.appendChild(list);
  }
  function pageHist() {
    const list = h('div', { class: 'kb-list' });
    if (!(d.hist || []).length) { list.appendChild(empty('file', 'Aucun mouvement')); main.appendChild(list); return; }
    (d.hist || []).forEach((t) => list.appendChild(h('div', { class: 'kb-hrow' }, h('span', { class: 'kb-hi' + (t.d > 0 ? ' plus' : '') }, ico(t.d > 0 ? 'plus' : 'minus')),
      h('div', null, h('b', null, String(t.l || '')), h('small', null, t.at ? new Date(t.at * 1000).toLocaleString('fr-FR') : '')),
      h('strong', { class: t.d > 0 ? 'plus' : '' }, (t.d > 0 ? '+' : '') + num(t.d) + ' ' + coinName()))));
    main.appendChild(list);
  }
  function draw() {
    drawNav(); G.clear(main);
    if (st.view === 'home') pageHome();
    else if (st.view === 'daily') pageDaily();
    else if (st.view === 'cart') pageCart();
    else pageCat(st.view);
  }
  function buyCoins() {
    G.click();
    const url = String(d.url || '');
    if (!/^https:\/\//.test(url)) { say(false, "La boutique en ligne n'est pas encore configurée : demande au staff."); return; }
    try { if (window.invokeNative) { window.invokeNative('openUrl', url); say(true, "La boutique en ligne s'ouvre dans ton navigateur."); return; } } catch (e) { /* hors jeu */ }
    say(true, 'Boutique en ligne : ' + url + ' — ton ID : ' + (d.id != null ? d.id : '?'));
  }

  // --- fenêtres ---
  let pending = null;   // { c } achat direct en attente de réponse
  function closeModal() { modal.classList.add('hidden'); G.clear(modal); }
  function shell(cls, ...kids) {
    G.clear(modal); modal.classList.remove('hidden');
    const box = h('div', { class: 'kb-dlg ' + (cls || '') }, h('button', { type: 'button', class: 'kb-x', title: 'Fermer', onclick: () => { G.click(); closeModal(); } }, ico('x')), ...kids);
    modal.appendChild(box);
    return box;
  }
  function open(c) {
    const r = R(c.rarity), blocked = blockedOf(c);
    const enough = () => Number(d.coins) >= Number(c.price) * qty;
    let qty = 1, plate = null, veh = null;
    const maxq = c.daily || c.limit ? 1 : Math.max(1, Number(c.maxq) || 1);
    const total = h('b', null, num(c.price));
    const qn = h('b', null, '1');
    const buy = h('button', { type: 'button', class: 'kb-buy wide' });
    const refresh = () => { total.textContent = num(c.price * qty); qn.textContent = String(qty); buy.classList.toggle('poor', !enough()); buy.textContent = blocked ? (c.owned ? 'Déjà possédé' : 'Indisponible') : (enough() ? 'Acheter' : 'Solde insuffisant'); buy.disabled = blocked || !enough(); };
    buy.addEventListener('click', () => {
      if (blocked || !enough()) return;
      const p = {};
      if (qty > 1) p.qty = qty;
      if (c.daily) p.daily = true;
      if (plate) { p.text = plate.value.trim(); p.vplate = veh && veh.value; if (!p.text) { say(false, 'Écris le texte de la plaque.'); return; } }
      G.click(); pending = { c }; buy.disabled = true; buy.classList.add('wait');
      o.onBuy && o.onBuy(c.id, p);
    });
    const right = h('div', { class: 'kb-dr' });
    if (c.stats && Array.isArray(c.stats.bars)) {
      right.appendChild(h('small', { class: 'kb-dh' }, 'Caractéristiques'));
      right.appendChild(h('div', { class: 'kb-bars' }, c.stats.bars.map((b) => h('div', null, h('span', null, String(b[0])), h('i', null, h('u', { style: { width: Math.max(3, Math.min(100, Number(b[1]) || 0)) + '%' } })), h('b', null, String(Math.round(Number(b[1]) || 0)))))));
    }
    if ((c.incl || []).length) {
      right.appendChild(h('small', { class: 'kb-dh' }, 'Inclus'));
      right.appendChild(h('ul', { class: 'kb-incl' }, (c.incl || []).map((t) => h('li', null, ico('check'), h('span', null, String(t))))));
    }
    if (c.cat === 'plate') {
      veh = h('select', { class: 'kb-in' }, (d.vehs || []).map((v) => h('option', { value: v.plate }, String(v.label) + ' — ' + String(v.plate))));
      plate = h('input', { type: 'text', class: 'kb-in', maxlength: 8, placeholder: 'NOUVELLE PLAQUE', oninput: (e) => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9 ]/g, ''); } });
      plate.addEventListener('keydown', (e) => e.stopPropagation());
      right.appendChild(h('small', { class: 'kb-dh' }, 'Options'));
      right.appendChild(h('label', { class: 'kb-fl' }, h('span', null, 'Véhicule'), veh));
      right.appendChild(h('label', { class: 'kb-fl' }, h('span', null, 'Texte (8 max.)'), plate));
    }
    right.appendChild(h('i', { class: 'kb-fill' }));
    if (maxq > 1 && !blocked) right.appendChild(h('div', { class: 'kb-q dq' }, h('span', null, 'Quantité'),
      h('button', { type: 'button', onclick: () => { G.click(); qty = Math.max(1, qty - 1); refresh(); } }, '−'), qn,
      h('button', { type: 'button', onclick: () => { G.click(); qty = Math.min(maxq, qty + 1); refresh(); } }, '+')));
    right.appendChild(h('div', { class: 'kb-dp' }, ico('coins'), total, c.was && c.was > c.price ? h('s', null, num(c.was)) : null, pctOf(c) ? h('em', null, '-' + pctOf(c) + ' %') : null));
    right.appendChild(h('small', { class: 'kb-dnote' }, ({ vehicle: 'Livré dans ton garage', weapon: 'Récupérable si perdue', villa: 'Sans impôt ni loyer', money: 'Versé en banque', item: 'Ajouté à ton sac', vip: 'Lié à ton compte', boost: 'Actif dès l\'achat', plate: 'Le coffre et les clés suivent' })[c.cat] || ''));
    right.appendChild(buy);
    if (!blocked) {
      const two = h('div', { class: 'kb-two' });
      if (c.cat !== 'plate') two.appendChild(h('button', { type: 'button', class: 'kb-ghost', onclick: () => { addCart(c, qty); closeModal(); } }, ico('cart'), 'Ajouter au panier'));
      if (c.gift) two.appendChild(h('button', { type: 'button', class: 'kb-ghost', onclick: () => { G.click(); giftModal(c); } }, ico('gift'), 'Offrir à un joueur'));
      if (two.childElementCount) right.appendChild(two);
    }
    const pct = pctOf(c);
    shell('item',
      h('div', { class: 'kb-dl' },
        h('div', { class: 'kb-dtags' }, h('span', { class: 'kb-rar', style: { '--rc': r.color } }, (KIND[c.cat] || '') + ' · ' + r.label), pct ? h('span', { class: 'kb-off' }, '-' + pct + ' %') : null, c.daily ? h('span', { class: 'kb-hl' }, 'Offre du jour') : null),
        h('h3', null, String(c.label || '')),
        c.descr && !c.descr_in_list ? h('p', null, String(c.descr)) : (c.sub ? h('p', null, String(c.sub)) : null),
        img(c, true)),
      right);
    refresh();
  }
  function giftModal(c) {
    const id = h('input', { type: 'text', class: 'kb-in', inputmode: 'numeric', maxlength: 7, placeholder: 'ID du joueur', oninput: (e) => { e.target.value = e.target.value.replace(/[^0-9]/g, ''); } });
    id.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') go2(); });
    const miss = Number(c.price) - Number(d.coins);
    const btn = h('button', { type: 'button', class: 'kb-buy', disabled: miss > 0 || null }, ico('gift'), 'Offrir');
    function go2() {
      if (miss > 0) return;
      const n = Number(id.value);
      if (!n) { say(false, 'Entre l\'ID du joueur.'); id.focus(); return; }
      G.click(); pending = { c }; btn.disabled = true; btn.classList.add('wait');
      o.onBuy && o.onBuy(c.id, { gift: n });
    }
    btn.addEventListener('click', go2);
    shell('gift', h('b', { class: 'kb-gt' }, 'Offrir à un joueur'),
      h('div', { class: 'kb-gi' }, img(c), h('div', null, h('b', null, String(c.label || '')), priceEl(c))),
      h('label', { class: 'kb-fl' }, h('span', null, 'ID du joueur (connecté)'), id),
      miss > 0 ? h('small', { class: 'kb-miss' }, 'Il te manque ' + num(miss) + ' ' + coinName() + '.') : h('small', { class: 'kb-dnote' }, 'C\'est toi qui paies ; il le reçoit tout de suite.'),
      h('div', { class: 'kb-two' }, h('button', { type: 'button', class: 'kb-ghost', onclick: () => { G.click(); closeModal(); } }, 'Annuler'), btn));
    setTimeout(() => id.focus(), 60);
  }
  function confirmCart() {
    const total = cartTotal();
    shell('confirm', h('b', { class: 'kb-gt' }, 'Confirmation'),
      h('p', null, 'Valider ta commande de ' + cartCount() + ' article' + (cartCount() > 1 ? 's' : '') + ' pour ' + num(total) + ' ' + coinName() + ' ?'),
      h('div', { class: 'kb-two' }, h('button', { type: 'button', class: 'kb-ghost', onclick: () => { G.click(); closeModal(); } }, 'Annuler'),
        h('button', { type: 'button', class: 'kb-buy', onclick: () => { G.click(); closeModal(); runQueue(); } }, 'Confirmer')));
  }
  // panier : un achat à la fois, le suivant part à la réponse du serveur
  function runQueue() {
    st.queue = { list: st.cart.map((l) => ({ c: l.c, qty: l.qty })), ok: 0, fail: [] };
    say(true, 'Commande en cours…');
    next();
  }
  function next() {
    const q = st.queue;
    if (!q) return;
    const it = q.list.shift();
    if (!it) {
      st.queue = null;
      st.cart = st.cart.filter((l) => q.fail.some((f) => f.c === l.c));
      draw();
      say(q.fail.length === 0, q.fail.length === 0 ? 'Commande validée : ' + q.ok + ' achat' + (q.ok > 1 ? 's' : '') + '.' : q.ok + ' achat(s) réussi(s), ' + q.fail.length + ' refusé(s) : ' + q.fail.map((f) => f.msg).join(' · '));
      return;
    }
    q.cur = it;
    const p = {};
    if (it.qty > 1) p.qty = it.qty;
    if (it.c.daily) p.daily = true;
    setTimeout(() => o.onBuy && o.onBuy(it.c.id, p), 950);   // le serveur limite à un achat par seconde
  }

  // minuteur (onglet « Boutique du jour » et compteurs)
  const tick = setInterval(() => {
    const s = left();
    el.querySelectorAll('.kb-clock').forEach((x) => { x.textContent = hm(s); });
    el.querySelectorAll('.kb-live').forEach((x) => { x.textContent = hms(s); });
  }, 1000);
  draw();

  return {
    el,
    set(nd, ok, msg) {
      if (nd) { d = nd; resetAt = Date.now() + (Number(d.reset_in) || 0) * 1000; }
      // les articles du panier suivent les nouvelles données (prix, stock, possédé)
      st.cart.forEach((l) => { const f = (l.c.daily ? d.daily : d.items || []).find((x) => x.id === l.c.id); if (f) l.c = f; });
      if (st.queue && st.queue.cur) {
        const cur2 = st.queue.cur; st.queue.cur = null;
        if (ok) st.queue.ok += 1; else st.queue.fail.push({ c: cur2.c, msg: String(msg || 'refusé') });
        st.cart.forEach((l) => { if (l.c.id === cur2.c.id && !!l.c.daily === !!cur2.c.daily) l.c = Object.assign({}, l.c); });
        next();
        return true;
      }
      const p = pending; pending = null;
      draw();
      if (p && ok) { closeModal(); say(true, msg); return true; }
      if (p && !ok) { const b = modal.querySelector('.kb-buy.wait'); if (b) { b.disabled = false; b.classList.remove('wait'); } }
      return false;
    },
    coins(n) { d.coins = n; drawNav(); },
    say,
    escape() { if (!modal.classList.contains('hidden')) { closeModal(); return true; } return false; },
    destroy() { clearInterval(tick); clearTimeout(tt); },
  };
}
G.premiumView = premiumView;

function closeUi() { if (cur && cur.destroy) cur.destroy(); const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'premium'); }
G.on('premium.open', (m) => {
  if (cur && cur.destroy) cur.destroy();
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = premiumView({ d: m.d, onClose: () => G.post('premium.close', {}), onBuy: (id, p) => G.post('premium.buy', { id, p }), onClaim: (id) => G.post('premium.claim', { id }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'premium');
  G.uiStack.push({ id: 'premium', onEscape: () => { if (!(cur && cur.escape())) G.post('premium.close', {}); } });
});
G.on('premium.result', (m) => { if (!cur) return; if (!cur.set(m.d, m.ok, m.msg)) cur.say(m.ok, m.msg); });
G.on('premium.coins', (m) => { if (cur) cur.coins(m.coins); });
G.on('premium.close', closeUi);

// données d'exemple (aperçu du panel et tests)
G.premiumSample = function () {
  return { name: 'Boutique Shadow', coin: 'Coins', who: 'Karl Wilmo', id: 12, coins: 2450, hours: 6, url: 'https://exemple.tebex.io', reset_in: 34384, daily_pct: 25,
    vip: { on: true, until_at: 1763000000 }, boosts: [{ kind: 'pay', label: 'Paie', pct: 25, left: 50000 }],
    rarity: [{ id: 'commun', label: 'Commun', color: '#9aa3b2' }, { id: 'rare', label: 'Rare', color: '#4aa3ff' }, { id: 'epique', label: 'Épique', color: '#b06bff' }, { id: 'legendaire', label: 'Légendaire', color: '#f2b440' }],
    cats: [{ id: 'vehicle', label: 'Véhicules', icon: 'car', sub: 'Livré à ton garage, à toi pour toujours.' }, { id: 'weapon', label: 'Armes', icon: 'crosshair' }, { id: 'vip', label: 'VIP', icon: 'crown', sub: 'Paie toutes les 15 min, multi-personnages, meubles…' }, { id: 'boost', label: 'Boosts', icon: 'bolt' }, { id: 'money', label: 'Argent en jeu', icon: 'coins' }],
    daily: [{ id: 13, cat: 'vehicle', label: 'Pegassi Bati 801', price: 675, was: 900, daily: true, rarity: 'rare', img: 'https://docs.fivem.net/vehicles/bati.webp', incl: ['Véhicule : Bati 801', 'Livré à ton garage'] },
      { id: 5, cat: 'money', label: '50 000 $', sub: 'Versés en banque', price: 225, was: 300, daily: true, rarity: 'commun' },
      { id: 20, cat: 'boost', label: 'Boost de paie +25 %', sub: 'Paie +25 % · 24 h', price: 150, was: 200, daily: true, bought: true, rarity: 'rare' }],
    items: [{ id: 2, cat: 'vehicle', label: 'Pegassi Zentorno', descr: 'Supercar, livrée au garage.', price: 3500, img: 'https://docs.fivem.net/vehicles/zentorno.webp', gift: true, rarity: 'legendaire', model: 'zentorno', stock: 2, stock_max: 3, limit: 1,
        stats: { kmh: 213, bars: [['Vitesse', 92], ['Accélération', 81], ['Freinage', 64], ['Adhérence', 77]] }, incl: ['Véhicule : Zentorno', 'Livré à ton garage', 'Récupérable dans « Mes achats »'] },
      { id: 13, cat: 'vehicle', label: 'Pegassi Bati 801', descr: 'Moto sportive.', price: 900, img: 'https://docs.fivem.net/vehicles/bati.webp', gift: true, rarity: 'rare', limit: 1 },
      { id: 14, cat: 'vehicle', label: 'Obey 10F', descr: 'Sportive élégante.', price: 2200, img: 'https://docs.fivem.net/vehicles/tenf.webp', gift: true, rarity: 'epique', owned: true },
      { id: 1, cat: 'weapon', label: 'Pistolet .50', descr: 'Pistolet lourd, toujours à toi.', price: 1200, gift: true, rarity: 'rare' },
      { id: 30, cat: 'vip', label: 'Silver', sub: '30 jours', price: 500, gift: true, rarity: 'rare', incl: ['Paie VIP toutes les 15 min', 'Double emploi', '2 personnages'] },
      { id: 3, cat: 'vip', label: 'Gold', sub: '30 jours', price: 800, was: 1000, promo: 20, gift: true, rarity: 'epique', incl: ['Tout Silver', 'Animal de compagnie', 'Location VIP', '3 personnages'] },
      { id: 31, cat: 'vip', label: 'Platinum', sub: 'À vie', price: 12000, gift: true, rarity: 'legendaire', incl: ['Tout Gold', 'Villa sans impôt', 'Pêche automatique'] },
      { id: 20, cat: 'boost', label: 'Boost de paie +25 %', sub: 'Paie +25 % · 24 h', descr: 'Ta paie augmente de 25 % pendant 24 heures.', price: 200, gift: true, rarity: 'rare', maxq: 5 },
      { id: 5, cat: 'money', label: '50 000 $', sub: 'Versés en banque', descr: 'Versés sur ton compte en banque.', price: 300, gift: true, rarity: 'commun', maxq: 10 }],
    owned: [{ id: 9, cat: 'weapon', label: 'Revolver lourd', info: 'Arme permanente', act: 'Récupérer', wait: '2 h 10', at: 1760000000 }, { id: 10, cat: 'vip', label: 'VIP 30 jours', info: 'VIP 30 jours', at: 1760100000, from: 'Alex Martin' }],
    hist: [{ d: 5000, l: 'Achat boutique en ligne', at: 1760000000 }, { d: -1500, l: 'Revolver lourd', at: 1760003600 }], vehs: [{ plate: 'PB12345', label: 'Sultan' }] };
};
G.preview.premium = function (box) {
  G.clear(box);
  const s = h('div', { class: 'gstage ps-stage' }); box.appendChild(s);
  s.appendChild(premiumView({ d: G.premiumSample(), onClose: () => {}, onBuy: () => {}, onClaim: () => {} }).el);
};
})();
