/* (patch 340) Établi vu du dessus : les pièces sont posées sur un tapis, on les glisse à la souris sur leur emplacement pour assembler.
   Mode « weapon » (armes : tapis bleu quadrillé) et « drug » (drogues : tapis sombre, balance, sachets…).
   Jeu → NUI : bench.open { mode, title, hint, secs, parts: [{ id, label, kind }] } · NUI → jeu : bench.done { ok, errors, ms }. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const NS = 'http://www.w3.org/2000/svg';
// formes (viewBox 100 × 40), remplies en noir avec un liseré clair, comme les pièces posées sur l'établi
const SHAPE = {
  barrel: 'M2 14h74l4-4h18v20H80l-4-4H2z',
  slide: 'M2 8h88l8 8v8H2z',
  receiver: 'M4 6h72l12 10v8H64l-6 12H44l4-12H4z',
  stock: 'M2 12l60-4 36 4v18l-36 4L2 28z',
  grip: 'M20 2h30l12 36H34z',
  spring: 'M2 20h12l6-14 10 28 10-28 10 28 10-28 6 14h30',
  plate: 'M4 6h92v28H4zM14 14h72v12H14z',
  jar: 'M30 6h40v6l6 6v18H24V18l6-6z',
  powder: 'M14 34c4-18 20-24 36-24s32 6 36 24z',
  pills: 'M8 20a10 10 0 0110-10h22a10 10 0 010 20H18A10 10 0 018 20zM60 20a10 10 0 0110-10h12a10 10 0 010 20H70a10 10 0 01-10-10z',
  scale: 'M10 34h80v4H10zM46 10h8v24h-8zM14 12h72l-8 12H22z',
  bag: 'M30 4h40l-4 8 14 8v18H20V20l14-8z',
};
const LAY = {"pistol":{"vw":560,"vh":499,"parts":[{"id":"receiver","file":"pistol_receiver.png","x":39,"y":141,"w":360,"h":186},{"id":"slide","file":"pistol_slide.png","x":59,"y":83,"w":354,"h":76},{"id":"barrel","file":"pistol_barrel.png","x":397,"y":110,"w":74,"h":36},{"id":"grip","file":"pistol_grip.png","x":10,"y":348,"w":142,"h":138},{"id":"mag","file":"pistol_mag.png","x":172,"y":348,"w":140,"h":151},{"id":"trigger","file":"pistol_trigger.png","x":245,"y":183,"w":26,"h":34},{"id":"spring","file":"pistol_spring.png","x":332,"y":348,"w":262,"h":24}]},"combatpistol":{"vw":560,"vh":499,"parts":[{"id":"receiver","file":"combatpistol_receiver.png","x":49,"y":157,"w":340,"h":170},{"id":"slide","file":"combatpistol_slide.png","x":59,"y":83,"w":344,"h":76},{"id":"barrel","file":"combatpistol_barrel.png","x":387,"y":110,"w":74,"h":36},{"id":"grip","file":"combatpistol_grip.png","x":10,"y":348,"w":136,"h":134},{"id":"mag","file":"combatpistol_mag.png","x":166,"y":348,"w":140,"h":151},{"id":"trigger","file":"combatpistol_trigger.png","x":245,"y":183,"w":26,"h":34},{"id":"spring","file":"combatpistol_spring.png","x":326,"y":348,"w":252,"h":24}]},"snspistol":{"vw":460,"vh":422,"parts":[{"id":"receiver","file":"snspistol_receiver.png","x":40,"y":139.5,"w":279.5,"h":140},{"id":"slide","file":"snspistol_slide.png","x":48,"y":79,"w":283,"h":63},{"id":"barrel","file":"snspistol_barrel.png","x":317,"y":101,"w":37,"h":30.5},{"id":"grip","file":"snspistol_grip.png","x":10,"y":298,"w":112.5,"h":110.5},{"id":"mag","file":"snspistol_mag.png","x":142.5,"y":298,"w":115.5,"h":124},{"id":"trigger","file":"snspistol_trigger.png","x":200.5,"y":161,"w":22,"h":28.5},{"id":"spring","file":"snspistol_spring.png","x":278.0,"y":298,"w":207,"h":20.5}]},"pistol50":{"vw":700,"vh":574,"parts":[{"id":"receiver","file":"pistol50_receiver.png","x":54,"y":198.5,"w":429,"h":187.5},{"id":"slide","file":"pistol50_slide.png","x":65,"y":117,"w":440,"h":84},{"id":"barrel","file":"pistol50_barrel.png","x":480.5,"y":147,"w":103.5,"h":39.5},{"id":"grip","file":"pistol50_grip.png","x":10,"y":408,"w":156.5,"h":152},{"id":"mag","file":"pistol50_mag.png","x":186.5,"y":408,"w":154,"h":166},{"id":"trigger","file":"pistol50_trigger.png","x":269.5,"y":227,"w":28.5,"h":37.5},{"id":"spring","file":"pistol50_spring.png","x":360.5,"y":408,"w":332,"h":26.5}]},"revolver":{"vw":660,"vh":572,"parts":[{"id":"receiver","file":"revolver_receiver.png","x":85,"y":55,"w":241,"h":160},{"id":"slide","file":"revolver_slide.png","x":215,"y":71,"w":118,"h":92},{"id":"barrel","file":"revolver_barrel.png","x":323,"y":65,"w":294,"h":90},{"id":"grip","file":"revolver_grip.png","x":35,"y":161,"w":142,"h":176},{"id":"mag","file":"revolver_mag.png","x":329,"y":133.5,"w":192,"h":9},{"id":"trigger","file":"revolver_trigger.png","x":10,"y":368,"w":174,"h":204},{"id":"spring","file":"revolver_spring.png","x":204,"y":368,"w":184,"h":17}]},"microsmg":{"vw":760,"vh":653,"parts":[{"id":"stock","file":"microsmg_stock.png","x":13,"y":119,"w":138,"h":92},{"id":"receiver","file":"microsmg_receiver.png","x":149,"y":87,"w":342,"h":94},{"id":"slide","file":"microsmg_slide.png","x":10,"y":428,"w":332,"h":44},{"id":"barrel","file":"microsmg_barrel.png","x":479,"y":97,"w":122,"h":66},{"id":"grip","file":"microsmg_grip.png","x":235,"y":179,"w":88,"h":232},{"id":"mag","file":"microsmg_mag.png","x":362,"y":428,"w":78,"h":225},{"id":"trigger","file":"microsmg_trigger.png","x":460,"y":428,"w":58,"h":52},{"id":"spring","file":"microsmg_spring.png","x":538,"y":428,"w":264,"h":22}]},"smg":{"vw":900,"vh":486,"parts":[{"id":"stock","file":"smg_stock.png","x":29,"y":79,"w":202,"h":124},{"id":"receiver","file":"smg_receiver.png","x":229,"y":79,"w":282,"h":72},{"id":"slide","file":"smg_slide.png","x":10,"y":428,"w":282,"h":42},{"id":"barrel","file":"smg_barrel.png","x":699,"y":71,"w":102,"h":60},{"id":"handguard","file":"smg_handguard.png","x":509,"y":73,"w":192,"h":82},{"id":"grip","file":"smg_grip.png","x":253,"y":149,"w":104,"h":232},{"id":"mag","file":"smg_mag.png","x":395,"y":149,"w":94,"h":256},{"id":"trigger","file":"smg_trigger.png","x":312,"y":428,"w":78,"h":58},{"id":"spring","file":"smg_spring.png","x":410,"y":428,"w":255,"h":24}]},"pumpshotgun":{"vw":1120,"vh":350,"parts":[{"id":"stock","file":"pumpshotgun_stock.png","x":13,"y":105,"w":324,"h":144},{"id":"receiver","file":"pumpshotgun_receiver.png","x":329,"y":81,"w":242,"h":114},{"id":"barrel","file":"pumpshotgun_barrel.png","x":569,"y":81,"w":482,"h":56},{"id":"handguard","file":"pumpshotgun_handguard.png","x":659,"y":115,"w":224,"h":64},{"id":"mag","file":"pumpshotgun_mag.png","x":569,"y":140,"w":422,"h":32},{"id":"trigger","file":"pumpshotgun_trigger.png","x":399,"y":193,"w":72,"h":62},{"id":"spring","file":"pumpshotgun_spring.png","x":10,"y":328,"w":344,"h":22}]},"sawnoff":{"vw":900,"vh":386,"parts":[{"id":"stock","file":"sawnoff_stock.png","x":7,"y":107,"w":324,"h":154},{"id":"receiver","file":"sawnoff_receiver.png","x":319,"y":49,"w":192,"h":134},{"id":"barrel","file":"sawnoff_barrel.png","x":499,"y":100,"w":342,"h":61},{"id":"handguard","file":"sawnoff_handguard.png","x":10,"y":328,"w":212,"h":58},{"id":"trigger","file":"sawnoff_trigger.png","x":379,"y":181,"w":82,"h":70},{"id":"spring","file":"sawnoff_spring.png","x":242,"y":328,"w":264.5,"h":22}]},"assaultrifle":{"vw":1180,"vh":478,"parts":[{"id":"stock","file":"assaultrifle_stock.png","x":17,"y":149,"w":294,"h":160},{"id":"receiver","file":"assaultrifle_receiver.png","x":299,"y":127,"w":364,"h":78},{"id":"slide","file":"assaultrifle_slide.png","x":10,"y":408,"w":364,"h":70},{"id":"barrel","file":"assaultrifle_barrel.png","x":811,"y":63,"w":282,"h":124},{"id":"handguard","file":"assaultrifle_handguard.png","x":661,"y":97,"w":192,"h":108},{"id":"grip","file":"assaultrifle_grip.png","x":365,"y":199,"w":82,"h":142},{"id":"mag","file":"assaultrifle_mag.png","x":493,"y":197,"w":144,"h":203},{"id":"trigger","file":"assaultrifle_trigger.png","x":394,"y":408,"w":84,"h":58},{"id":"spring","file":"assaultrifle_spring.png","x":498,"y":408,"w":325,"h":24}]},"compactrifle":{"vw":1020,"vh":478,"parts":[{"id":"stock","file":"compactrifle_stock.png","x":25,"y":147,"w":296,"h":154},{"id":"receiver","file":"compactrifle_receiver.png","x":299,"y":127,"w":364,"h":78},{"id":"slide","file":"compactrifle_slide.png","x":10,"y":408,"w":364,"h":70},{"id":"barrel","file":"compactrifle_barrel.png","x":761,"y":63,"w":152,"h":124},{"id":"handguard","file":"compactrifle_handguard.png","x":661,"y":97,"w":166,"h":108},{"id":"grip","file":"compactrifle_grip.png","x":365,"y":199,"w":82,"h":142},{"id":"mag","file":"compactrifle_mag.png","x":493,"y":197,"w":144,"h":203},{"id":"trigger","file":"compactrifle_trigger.png","x":394,"y":408,"w":84,"h":58},{"id":"spring","file":"compactrifle_spring.png","x":498,"y":408,"w":325,"h":24}]},"carbinerifle":{"vw":1160,"vh":492,"parts":[{"id":"stock","file":"carbinerifle_stock.png","x":25,"y":117,"w":326,"h":108},{"id":"receiver","file":"carbinerifle_receiver.png","x":349,"y":95,"w":322,"h":130},{"id":"slide","file":"carbinerifle_slide.png","x":10,"y":428,"w":372,"h":54},{"id":"barrel","file":"carbinerifle_barrel.png","x":899,"y":59,"w":220,"h":84},{"id":"handguard","file":"carbinerifle_handguard.png","x":659,"y":77,"w":262,"h":92},{"id":"grip","file":"carbinerifle_grip.png","x":385,"y":205,"w":86,"h":146},{"id":"mag","file":"carbinerifle_mag.png","x":469,"y":219,"w":124,"h":201},{"id":"trigger","file":"carbinerifle_trigger.png","x":402,"y":428,"w":98,"h":64},{"id":"spring","file":"carbinerifle_spring.png","x":157,"y":138,"w":185,"h":24}]}};
let box = null, tick = 0;
function svg(kind, cls) {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 100 40'); s.setAttribute('class', cls || '');
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', SHAPE[kind] || SHAPE.plate);
  if (kind === 'spring') p.setAttribute('fill', 'none');
  s.appendChild(p); return s;
}
function drop(res) {
  clearInterval(tick); tick = 0;
  if (box) { box.remove(); box = null; }
  if (res) G.post('bench.done', res);
}
G.on('bench.close', () => drop(null));
G.on('bench.open', function (d) {
  drop(null);
  const mode = d.mode === 'drug' ? 'drug' : 'weapon';
  const parts = (Array.isArray(d.parts) ? d.parts : []).slice(0, 8);
  if (!parts.length) { G.post('bench.done', { ok: true, errors: 0, ms: 0 }); return; }
  const secs = Math.max(3, Math.min(240, Number(d.secs) || 10)), t0 = Date.now();
  const W = 1100, H = 600;
  let placed = 0, errors = 0, finishing = false;
  const stage = h('div', { class: 'bn-st', style: { width: W + 'px', height: H + 'px' } });
  const lay = mode === 'weapon' && LAY[d.weapon] ? LAY[d.weapon] : null;
  let pieces;
  if (lay) {
    // (patch 342) pièces rendues en 3D (web/img/bench) : l'arme assemblée est dessinée en ombre en haut, les pièces sont éparpillées dessous
    const want = {}; parts.forEach((p) => { want[p.id] = 1; });
    const lp = lay.parts;   // toutes les pièces de l'arme (pas seulement celles de la recette)
    const f = Math.min(1.15, 980 / lay.vw, 285 / lay.vh), ox = (W - lay.vw * f) / 2, oy = 24;
    pieces = lp.map((q) => {
      const w = q.w * f, hh = q.h * f, sx = ox + q.x * f, sy = oy + q.y * f;
      const slot = h('div', { class: 'bn-sl img', style: { left: sx + 'px', top: sy + 'px', width: w + 'px', height: hh + 'px' } }, h('img', { src: 'img/bench/' + q.file, draggable: false, alt: '' }));
      const px = 20 + Math.random() * Math.max(10, W - w - 40), py = 300 + Math.random() * Math.max(10, H - 340 - hh * 0.5);
      const el = h('div', { class: 'bn-p img', style: { left: px + 'px', top: py + 'px', width: w + 'px', height: hh + 'px', transform: 'rotate(' + Math.round(Math.random() * 60 - 30) + 'deg)' } }, h('img', { src: 'img/bench/' + q.file, draggable: false, alt: '' }));
      stage.appendChild(slot); return { slot, el, sx, sy, w, h: hh, done: false };
    });
  } else {
    const n0 = parts.length, gap = (W - 60) / n0;
    pieces = parts.map((p, i) => {
      const sx = 30 + gap * i + gap / 2 - 60;
      const slot = h('div', { class: 'bn-sl', style: { left: sx + 'px', top: '70px' } }, svg(p.kind, 'g'), h('small', null, String(p.label || '')));
      const px = 40 + Math.random() * (W - 220), py = 260 + Math.random() * 270;
      const el = h('div', { class: 'bn-p', style: { left: px + 'px', top: py + 'px', transform: 'rotate(' + Math.round(Math.random() * 50 - 25) + 'deg)' } }, svg(p.kind, 'f'));
      stage.appendChild(slot); return { slot, el, sx, sy: 70, w: 120, h: 70, done: false };
    });
  }
  pieces.forEach((q) => stage.appendChild(q.el));
  const n = pieces.length;
  const msg = h('div', { class: 'bn-msg' }, String(d.hint || (mode === 'drug' ? 'Glisse chaque ingrédient sur son emplacement.' : "Assemble les pièces de l'arme : clic gauche pour glisser.")));
  const bar = h('i'), barw = h('div', { class: 'bn-bar' }, bar);
  box = h('div', { id: 'g-bench', class: 'bn-' + mode }, [
    h('div', { class: 'bn-top' }, h('b', null, String(d.title || 'Établi')), h('span', null, 'Échap : annuler')),
    h('div', { class: 'bn-mat' }, stage), msg, barw]);
  G.root.appendChild(box);
  const sc = Math.min(1.4, (window.innerWidth * 0.84) / W, (window.innerHeight * 0.7) / H);
  stage.style.transform = 'scale(' + sc + ')'; stage.style.transformOrigin = '50% 0';
  let drag = null;
  pieces.forEach((q) => {
    q.el.addEventListener('pointerdown', (e) => {
      if (q.done || finishing) return;
      const r = q.el.getBoundingClientRect();
      drag = { q, dx: e.clientX - r.left, dy: e.clientY - r.top };
      q.el.classList.add('up'); q.el.style.transform = 'rotate(0deg)';
      try { q.el.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
    });
    q.el.addEventListener('pointermove', (e) => {
      if (!drag || drag.q !== q) return;
      const s = stage.getBoundingClientRect();
      q.el.style.left = ((e.clientX - s.left - drag.dx) / sc) + 'px';
      q.el.style.top = ((e.clientY - s.top - drag.dy) / sc) + 'px';
    });
    q.el.addEventListener('pointerup', () => {
      if (!drag || drag.q !== q) return;
      drag = null; q.el.classList.remove('up');
      const x = parseFloat(q.el.style.left), y = parseFloat(q.el.style.top);
      let hit = null;
      pieces.forEach((o) => { if (!o.done && Math.abs(x - o.sx) < 48 && Math.abs(y - o.sy) < 40) hit = o; });
      if (hit === q) {
        q.done = true; placed++;
        q.el.style.left = q.sx + 'px'; q.el.style.top = q.sy + 'px'; q.el.classList.add('ok'); q.slot.classList.add('ok');
        if (placed >= n) finish();
      } else if (hit) { errors++; q.el.classList.add('bad'); setTimeout(() => q.el.classList.remove('bad'), 300); }
    });
  });
  function finish() {
    finishing = true;
    msg.textContent = mode === 'drug' ? 'Mélange en cours…' : 'Assemblage…';
    pieces.forEach((q) => { q.slot.style.opacity = '0'; });
    box.classList.add('fin');
  }
  tick = setInterval(() => {
    const el = (Date.now() - t0) / 1000;
    bar.style.width = Math.min(100, el / secs * 100) + '%';
    if (finishing && el >= secs) drop({ ok: true, errors, ms: Date.now() - t0 });
    else if (!finishing && el >= secs * 4 + 20) drop({ ok: false, errors, ms: Date.now() - t0 });   // trop long : abandon
  }, 100);
});
G.nui = G.nui || {};
window.addEventListener('keydown', (e) => { if (box && e.key === 'Escape') { e.preventDefault(); drop({ ok: false, errors: 0, ms: 0, cancel: true }); } }, true);
})();
