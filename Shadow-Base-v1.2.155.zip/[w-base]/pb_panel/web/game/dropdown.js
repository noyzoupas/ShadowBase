/* Listes déroulantes : la liste native du navigateur s'affiche blanche, avec un texte illisible. Ici, tout <select> de l'interface (jeu et panel)
   ouvre la même liste aux couleurs du serveur. Le <select> reste en place : valeur, évènements et formulaires ne changent pas.
   Texte inséré avec textContent. */
(function () {
'use strict';
const SEARCH_FROM = 12;   // à partir de ce nombre de choix : champ de recherche
let box = null, cur = null, active = -1, rows = [];

function close(refocus) {
  if (!box) return;
  const s = cur;
  box.remove(); box = null; cur = null; rows = []; active = -1;
  if (s) { s.classList.remove('pbdd-open'); if (refocus && s.isConnected) s.focus(); }
}
function choose(opt) {
  const s = cur;
  if (!s || opt.disabled) return;
  const changed = s.value !== opt.value;
  s.value = opt.value;
  close(true);
  if (changed) {
    s.dispatchEvent(new Event('input', { bubbles: true }));
    s.dispatchEvent(new Event('change', { bubbles: true }));
  }
}
function mark(i, scroll) {
  if (rows[active]) rows[active].el.classList.remove('hover');
  active = i;
  const r = rows[active];
  if (!r) return;
  r.el.classList.add('hover');
  if (scroll) r.el.scrollIntoView({ block: 'nearest' });
}
function step(d) {
  const shown = rows.filter((r) => !r.el.hidden && !r.opt.disabled);
  if (!shown.length) return;
  const k = shown.indexOf(rows[active]);
  mark(rows.indexOf(shown[k < 0 ? 0 : Math.max(0, Math.min(shown.length - 1, k + d))]), true);
}
function place(s) {
  const r = s.getBoundingClientRect(), vh = window.innerHeight, vw = window.innerWidth;
  const w = Math.max(r.width, 160);
  box.style.width = w + 'px';
  box.style.left = Math.max(4, Math.min(vw - w - 4, r.left)) + 'px';
  const below = vh - r.bottom - 8, above = r.top - 8;
  const up = below < 180 && above > below;
  box.style.maxHeight = Math.max(120, Math.min(320, up ? above : below)) + 'px';
  if (up) { box.style.top = 'auto'; box.style.bottom = (vh - r.top + 4) + 'px'; } else { box.style.top = (r.bottom + 4) + 'px'; box.style.bottom = 'auto'; }
}
function open(s) {
  close();
  cur = s;
  s.classList.add('pbdd-open');
  box = document.createElement('div');
  box.className = 'pbdd';
  const list = document.createElement('div');
  list.className = 'pbdd-l';
  let search = null;
  if (s.options.length >= SEARCH_FROM) {
    search = document.createElement('input');
    search.type = 'text';
    search.className = 'pbdd-s';
    search.placeholder = 'Rechercher…';
    search.addEventListener('input', () => {
      const q = search.value.trim().toLowerCase();
      rows.forEach((r) => { r.el.hidden = !!q && r.opt.text.toLowerCase().indexOf(q) < 0; });
      list.querySelectorAll('.pbdd-g').forEach((g) => { g.hidden = !!q; });
      const first = rows.findIndex((r) => !r.el.hidden && !r.opt.disabled);
      mark(first, false);
    });
    box.appendChild(search);
  }
  let group = null;
  Array.prototype.forEach.call(s.options, (opt) => {
    const pg = opt.parentElement && opt.parentElement.tagName === 'OPTGROUP' ? opt.parentElement : null;
    if (pg && pg !== group) {
      const g = document.createElement('div');
      g.className = 'pbdd-g';
      g.textContent = pg.label;
      list.appendChild(g);
    }
    group = pg;
    const el = document.createElement('button');
    el.type = 'button';
    el.className = 'pbdd-o' + (opt.selected ? ' on' : '');
    el.disabled = opt.disabled;
    el.textContent = opt.text || '—';
    el.title = opt.text;
    const row = { el, opt };
    rows.push(row);
    el.addEventListener('mouseenter', () => { if (!opt.disabled) mark(rows.indexOf(row)); });
    el.addEventListener('click', () => choose(opt));
    list.appendChild(el);
  });
  box.appendChild(list);
  document.body.appendChild(box);
  place(s);
  mark(Math.max(0, s.selectedIndex), true);
  if (search) search.focus();
}
const usable = (t) => t && t.tagName === 'SELECT' && !t.disabled && !t.multiple && t.size <= 1;

// le bouton de la souris : on prend la main avant que le navigateur n'ouvre sa liste
window.addEventListener('mousedown', (e) => {
  if (box && box.contains(e.target)) return;
  const t = e.target;
  if (usable(t) && e.button === 0) {
    e.preventDefault();
    if (cur === t) { close(true); return; }
    t.focus();
    open(t);
    return;
  }
  close();
}, true);
window.addEventListener('keydown', (e) => {
  if (box) {
    const k = e.key;
    if (k === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); close(true); return; }
    if (k === 'ArrowDown') { e.preventDefault(); e.stopPropagation(); step(1); return; }
    if (k === 'ArrowUp') { e.preventDefault(); e.stopPropagation(); step(-1); return; }
    if (k === 'Enter') { e.preventDefault(); e.stopPropagation(); if (rows[active] && !rows[active].el.hidden) choose(rows[active].opt); return; }
    if (k === 'Tab') { close(); return; }
    e.stopPropagation();   // la saisie dans la recherche ne déclenche pas les touches de l'interface derrière
    return;
  }
  if (usable(document.activeElement) && (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
    e.preventDefault(); e.stopPropagation();
    open(document.activeElement);
  }
}, true);
window.addEventListener('resize', () => close());
window.addEventListener('scroll', (e) => { if (box && !box.contains(e.target)) close(); }, true);
})();
