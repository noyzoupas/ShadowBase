-- (v1.2.78) Pôle emploi : PNJ posé au Builder ; E ouvre la liste des emplois sans métier et des entreprises qui recrutent.
local G = PBG

local points, blips = {}, {}
local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local jc = c.jobcenter or {}
    points = jc.enabled == false and {} or (jc.points or {})
    local npcs = {}
    for _, p in ipairs(points) do npcs[#npcs + 1] = { id = p.id, model = tostring(jc.ped or 'a_f_y_business_02'), x = p.x, y = p.y, z = p.z, h = p.h or 0.0, scenario = 'WORLD_HUMAN_CLIPBOARD' } end
    G.Npcs('jobcenter', npcs)
    clearBlips()
    if jc.blip ~= false then
        for _, p in ipairs(points) do
            local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, 407) SetBlipColour(b, 0) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label or 'Pôle emploi')) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        end
    end
end

RegisterNetEvent('pb:g:jobc:menu', function(j)
    local d = G.decode(j)
    if not d or G.creating or G.state.dead then return end
    local items = { { type = 'separator', label = 'Emplois sans métier' } }
    for _, e in ipairs(d.jobs or {}) do
        items[#items + 1] = { label = e.label, icon = e.icon, right = e.ok and (e.dist and (e.dist >= 1000 and (('%.1f km'):format(e.dist / 1000)) or (e.dist .. ' m'))) or 'Bientôt',
            disabled = (not e.ok) or nil, description = e.desc .. (e.ok and (' Entrée : GPS vers « ' .. tostring(e.who) .. ' ».') or ''),
            onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:jobc:pick', 'job', e.id) end }
    end
    if #(d.jobs or {}) == 0 then items[#items + 1] = { label = 'Aucun emploi libre installé', disabled = true } end
    if #(d.hiring or {}) > 0 then
        items[#items + 1] = { type = 'separator', label = 'Entreprises qui recrutent' }
        for _, b in ipairs(d.hiring) do
            items[#items + 1] = { label = b.label, icon = 'briefcase', disabled = (not b.ok) or nil, description = 'Entrée : GPS vers le siège. Le patron (ou un responsable) doit t\'engager.',
                onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:jobc:pick', 'biz', b.id) end }
        end
    end
    G.Menu.Open({ id = 'jobcenter', title = 'Pôle emploi', subtitle = 'Trouve un travail', banner = { text = 'Pôle emploi' }, items = items })
end)

CreateThread(function()
    local shown
    while true do
        local best, bd = nil, 1e9
        if #points > 0 and G.begun and not G.state.dead then
            local c = GetEntityCoords(PlayerPedId())
            for _, p in ipairs(points) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd = p, d end end
        end
        if best and bd <= 12.0 then
            G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
            if bd <= 2.5 and not G.Menu.IsOpen() and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt2', { id = 'jobcenter', show = true, key = 'E', text = tostring(best.label or 'Pôle emploi') }) end
                if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:jobc:open', best.id) end
            elseif shown then shown = nil G.send('prompt2', { id = 'jobcenter', show = false }) end
            Wait(0)
        else
            if shown then shown = nil G.send('prompt2', { id = 'jobcenter', show = false }) end
            Wait(700)
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then clearBlips() end end)
