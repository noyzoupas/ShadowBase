-- Gestes du menu ALT : animations sur soi (clé reçue du serveur), gestes à deux avec réponse Y / N, portage, copie de l'ID.
-- Cosmétique : le serveur décide qui peut proposer quoi, ce fichier joue seulement les animations.
local G = PBG
local GE = {
    surrender = { 'anim', 'random@arrests@busted', 'idle_a', 1 }, kneel = { 'anim', 'amb@medic@standing@kneel@idle_a', 'idle_a', 1 },
    headhands = { 'anim', 'random@arrests', 'kneeling_arrest_idle', 1 },
    hello = { 'anim', 'gestures@m@standing@casual', 'gesture_hello', 48 }, bye = { 'anim', 'gestures@m@standing@casual', 'gesture_bye_hard', 48 },
    come = { 'anim', 'gestures@m@standing@casual', 'gesture_come_here_hard', 48 }, point = { 'anim', 'gestures@m@standing@casual', 'gesture_point', 48 },
    halt = { 'anim', 'gestures@m@standing@casual', 'gesture_hand_down', 48 }, shush = { 'anim', 'anim@mp_player_intcelebrationmale@shush', 'shush', 48 },
    shrug = { 'anim', 'gestures@m@standing@casual', 'gesture_shrug_hard', 48 }, nope = { 'anim', 'gestures@m@standing@casual', 'gesture_head_no', 48 },
    damn = { 'anim', 'gestures@m@standing@casual', 'gesture_damn', 48 }, what = { 'anim', 'gestures@m@standing@casual', 'gesture_what_hard', 48 },
    peace = { 'anim', 'anim@mp_player_intcelebrationmale@peace', 'peace', 48 }, rock = { 'anim', 'anim@mp_player_intcelebrationmale@rock', 'rock', 48 },
    kiss = { 'anim', 'anim@mp_player_intcelebrationmale@blow_kiss', 'blow_kiss', 48 }, slowclap = { 'anim', 'anim@mp_player_intcelebrationmale@slow_clap', 'slow_clap', 48 },
    cheer = { 'scn', 'WORLD_HUMAN_CHEERING' },
    sitground = { 'scn', 'WORLD_HUMAN_PICNIC' }, sitbench = { 'scn', 'PROP_HUMAN_SEAT_BENCH' }, lean = { 'scn', 'WORLD_HUMAN_LEANING' },
    lieback = { 'scn', 'WORLD_HUMAN_SUNBATHE_BACK' }, lieface = { 'scn', 'WORLD_HUMAN_SUNBATHE' }, smoke = { 'scn', 'WORLD_HUMAN_SMOKING' },
    coffee = { 'scn', 'WORLD_HUMAN_AA_COFFEE' }, drink = { 'scn', 'WORLD_HUMAN_DRINKING' }, phonecall = { 'scn', 'WORLD_HUMAN_STAND_MOBILE' },
    binoc = { 'scn', 'WORLD_HUMAN_BINOCULARS' }, guard = { 'scn', 'WORLD_HUMAN_GUARD_STAND' }, impatient = { 'scn', 'WORLD_HUMAN_STAND_IMPATIENT' },
    pushups = { 'scn', 'WORLD_HUMAN_PUSH_UPS' }, situps = { 'scn', 'WORLD_HUMAN_SIT_UPS' }, yoga = { 'scn', 'WORLD_HUMAN_YOGA' },
    jog = { 'scn', 'WORLD_HUMAN_JOG_STANDING' }, flex = { 'scn', 'WORLD_HUMAN_MUSCLE_FLEX' },
    dance1 = { 'anim', 'anim@amb@nightclub@dancers@crowddance_groups@', 'hi_dance_crowd_09_v1_male^1', 1 }, dance2 = { 'anim', 'anim@amb@nightclub@dancers@crowddance_groups@', 'hi_dance_crowd_11_v1_female^1', 1 },
    party = { 'scn', 'WORLD_HUMAN_PARTYING' },
}
G.CtxGestKeys = GE

local function load(dict)
    if HasAnimDictLoaded(dict) then return true end
    RequestAnimDict(dict)
    local t = GetGameTimer() + 3000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(10) end
    return HasAnimDictLoaded(dict)
end
local function canPlay()
    local ped = PlayerPedId()
    if G.state.dead or IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) then return false end
    if G.IsCuffed and G.IsCuffed() then return false end
    return true
end

function G.CtxGestPlay(key)
    if key == 'stop' then ClearPedTasks(PlayerPedId()) return end
    local a = GE[key]
    if not a or not canPlay() then return end
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    if a[1] == 'scn' then TaskStartScenarioInPlace(ped, a[2], 0, true) return end
    if load(a[2]) then TaskPlayAnim(ped, a[2], a[3], 4.0, -4.0, -1, a[4], 0, false, false, false) else G.send('notify', { type = 'warn', text = 'Animation introuvable.' }) end
end

-- Copie de l'ID : le navigateur intégré écrit dans le presse-papiers
function G.CtxCopy(text) G.send('ctx.copy', { text = tostring(text or ''):sub(1, 24) }) end

-- Demande reçue : Y accepte, N refuse (ou expiration)
local pending
RegisterNetEvent('pb:g:ctx:invite', function(j)
    local d = G.decode(j)
    if not d then return end
    pending = { exp = GetGameTimer() + math.max(5, math.min(60, tonumber(d.secs) or 15)) * 1000 }
    G.send('ctx.invite', { name = tostring(d.name or ''), text = tostring(d.text or ''), secs = tonumber(d.secs) or 15 })
end)
CreateThread(function()
    while true do
        if pending then
            Wait(0)
            if IsControlJustPressed(0, 246) then pending = nil G.send('ctx.invite', { stop = true }) TriggerServerEvent('pb:g:ctx:inviteans', true)
            elseif IsControlJustPressed(0, 249) then pending = nil G.send('ctx.invite', { stop = true }) TriggerServerEvent('pb:g:ctx:inviteans', false)
            elseif GetGameTimer() > pending.exp then pending = nil G.send('ctx.invite', { stop = true }) end
        else Wait(250) end
    end
end)

-- Proposition de recrutement : carte à l'écran, Y accepte, N refuse. Le serveur garde l'offre et fait le reste.
local offer
RegisterNetEvent('pb:g:recruit:offer', function(j)
    local d = G.decode(j)
    if not d or not d.token then return end
    offer = { token = d.token, exp = GetGameTimer() + (tonumber(d.secs) or 60) * 1000 }
    G.send('recruit.offer', d)
end)
CreateThread(function()
    while true do
        if offer then
            Wait(0)
            local y, n = IsControlJustPressed(0, 246), IsControlJustPressed(0, 249)
            if y or n then TriggerServerEvent('pb:g:recruit:answer', offer.token, y) offer = nil G.send('recruit.offer', { stop = true })
            elseif GetGameTimer() > offer.exp then offer = nil G.send('recruit.offer', { stop = true }) end
        else Wait(250) end
    end
end)

-- Gestes à deux : les deux joueurs se font face puis jouent chacun leur rôle
-- { dictionnaire, animation de celui qui propose, animation de celui qui accepte, durée en ms } (noms vérifiés dans les fichiers du jeu)
local CEL = 'anim@mp_player_intcelebrationpaired@m_m_'
local PAIR = {
    check = { CEL .. 'fist_bump', 'fist_bump_left', 'fist_bump_right', 3500 },
    handshake = { 'mp_ped_interaction', 'handshake_guy_a', 'handshake_guy_b', 3000 },
    hug = { 'mp_ped_interaction', 'hugs_guy_a', 'hugs_guy_b', 3500 },
    highfive = { CEL .. 'high_five', 'high_five_left', 'high_five_right', 3500 },
    brohug = { CEL .. 'bro_hug', 'bro_hug_left', 'bro_hug_right', 4000 },
    backslap = { CEL .. 'backslap', 'backslap_left', 'backslap_right', 4000 },
    manlyshake = { CEL .. 'manly_handshake', 'manly_handshake_left', 'manly_handshake_right', 4000 },
    kiss = { 'mp_ped_interaction', 'kisses_guy_a', 'kisses_guy_b', 4000 },
    give = { 'mp_common', 'givetake1_a', 'givetake1_b', 2200 },
    slap = { 'melee@unarmed@streamed_variations', 'plyr_takedown_front_slap', 'victim_takedown_front_slap', 3000 },
    headbutt = { 'melee@unarmed@streamed_variations', 'plyr_takedown_front_headbutt', 'victim_takedown_front_headbutt', 3000 },
}
RegisterNetEvent('pb:g:ctx:pair', function(j)
    local d = G.decode(j)
    local a = d and PAIR[d.kind]
    if not a or not canPlay() then return end
    local ped = PlayerPedId()
    local pl = GetPlayerFromServerId(math.floor(tonumber(d.with) or -1))
    if pl and pl ~= -1 then
        local other = GetPlayerPed(pl)
        if other and other ~= 0 then TaskTurnPedToFaceEntity(ped, other, 800) Wait(800) end
    end
    if load(a[1]) then
        ClearPedTasks(ped)
        TaskPlayAnim(ped, a[1], d.role == 'a' and a[2] or a[3], 8.0, -8.0, a[4], 0, 0, false, false, false)
    end
end)

-- Portage : le porté est attaché au porteur ; X pour arrêter
local carry
RegisterNetEvent('pb:g:ctx:carry', function(j)
    local d = G.decode(j)
    local ped = PlayerPedId()
    if not d or d.on ~= true then
        if carry then
            if not carry.carrier then DetachEntity(ped, true, false) end
            ClearPedTasks(ped)
        end
        carry = nil
        return
    end
    local pl = GetPlayerFromServerId(math.floor(tonumber(d.other) or -1))
    if not pl or pl == -1 then return end
    local other = GetPlayerPed(pl)
    if not other or other == 0 then return end
    carry = { carrier = d.carrier == true, other = other }
    if carry.carrier then
        if load('missfinale_c2mcs_1') then TaskPlayAnim(ped, 'missfinale_c2mcs_1', 'fin_c2_mcs_1_camman', 8.0, -8.0, -1, 49, 0, false, false, false) end
    else
        if load('nm') then
            AttachEntityToEntity(ped, other, 0, 0.27, 0.15, 0.63, 0.5, 0.5, 180.0, false, false, false, false, 2, false)
            TaskPlayAnim(ped, 'nm', 'firemans_carry', 8.0, -8.0, -1, 33, 0, false, false, false)
        end
    end
end)
CreateThread(function()
    while true do
        if carry then
            Wait(0)
            if IsControlJustPressed(0, 73) then TriggerServerEvent('pb:g:ctx:carrystop') end
        else Wait(400) end
    end
end)
