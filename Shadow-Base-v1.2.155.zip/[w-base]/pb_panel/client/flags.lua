-- Drapeaux de vente : le drapeau est un objet du jeu (réglage pole_model), avec un halo à ses pieds ; l'état de la zone s'affiche en bas à droite de l'écran.
-- ALT sur le drapeau : le bonus, le temps de capture, et le bouton pour la lancer. Le serveur décide de tout.
local G = PBG
local spots, me, boss, rad, enabled = {}, nil, false, 25.0, true
local model, info = '', {}
local objs = {}
local prog = {}
local recvAt = 0
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local f = c.flags or {}
    enabled = f.enabled ~= false and f.show ~= false
    rad = (tonumber(f.radius) or 25) + 0.0
    model = type(f.pole_model) == 'string' and f.pole_model or model
end
local function rgb(hex)
    if type(hex) ~= 'string' then return 223, 226, 231 end
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 223, 226, 231 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
-- Points de vente / drapeaux sur la carte : seulement pour les membres d'un groupe illégal
local flagBlips = {}
local function drawFlagBlips()
    for _, b in ipairs(flagBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    flagBlips = {}
    if not enabled or not me or me == '' then return end
    if not (G.cfg.flags and G.cfg.flags.map_blips == true) then return end   -- (v1.2.45) point de vente de drogue : pas sur la carte
    for _, s in ipairs(spots) do
        local o = s.owner
        local col = o and G.blipColourFor and G.blipColourFor(o.color) or 4
        local a = AddBlipForRadius(s.x + 0.0, s.y + 0.0, s.z + 0.0, rad)
        SetBlipColour(a, col) SetBlipAlpha(a, o and 110 or 50)
        flagBlips[#flagBlips + 1] = a
        local c = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(c, 38) SetBlipColour(c, col) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Drapeau · ' .. tostring(s.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
        flagBlips[#flagBlips + 1] = c
    end
end
local lastSig = ''
RegisterNetEvent('pb:g:flag:state', function(j)
    local d = G.decode(j)
    if not d then return end
    spots, me, boss = d.spots or {}, d.me, d.boss == true
    recvAt = GetGameTimer()   -- le temps restant du propriétaire se décompte ici (le serveur ne renvoie plus l'état chaque seconde)
    local sig = tostring(me)
    for _, s in ipairs(spots) do sig = sig .. '|' .. s.id .. ':' .. tostring(s.owner and s.owner.gang or '') end
    if sig ~= lastSig then lastSig = sig drawFlagBlips() end
    if d.cfg then
        if d.cfg.radius then rad = (tonumber(d.cfg.radius) or 25) + 0.0 end
        if d.cfg.model ~= nil then model = tostring(d.cfg.model) end
        info = d.cfg
    end
end)

-- drapeau : objet du jeu posé au sol, créé à l'approche, supprimé en s'éloignant
local function pole(s, near)
    local o = objs[s.id]
    if not near or model == '' then
        if o and o.e and DoesEntityExist(o.e) then DeleteEntity(o.e) end
        objs[s.id] = nil
        return false
    end
    if o then return o.e ~= nil and DoesEntityExist(o.e) end
    objs[s.id] = { e = nil, bad = false }
    CreateThread(function()
        local h = GetHashKey(model)
        if not IsModelInCdimage(h) then objs[s.id].bad = true return end
        RequestModel(h)
        local t = GetGameTimer()
        while not HasModelLoaded(h) and GetGameTimer() - t < 3000 do Wait(50) end
        if not HasModelLoaded(h) then objs[s.id].bad = true return end
        local e = CreateObject(h, s.x + 0.0, s.y + 0.0, s.z - 0.95, false, false, false)
        SetEntityAsMissionEntity(e, true, true)
        PlaceObjectOnGroundProperly(e)
        FreezeEntityPosition(e, true)
        SetModelAsNoLongerNeeded(h)
        if objs[s.id] then objs[s.id].e = e else DeleteEntity(e) end
    end)
    return false
end
local function fmt(sec) sec = math.max(0, math.floor(sec)) return ('%d h %02d'):format(sec // 3600, sec % 3600 // 60) end
local function dur(sec)
    sec = math.floor(tonumber(sec) or 0)
    if sec < 60 then return sec .. ' s' end
    return sec % 60 == 0 and ((sec // 60) .. ' min') or ('%d min %02d s'):format(sec // 60, sec % 60)
end
-- ALT : les drapeaux visibles (index -> objet)
function G.FlagTargets()
    local out = {}
    if not enabled then return out end
    for i, s in ipairs(spots) do
        local o = objs[s.id]
        if o and o.e and DoesEntityExist(o.e) then out[i] = o.e end
    end
    return out
end
-- ALT › clic sur le drapeau
function G.FlagMenu(i)
    local s = spots[i]
    if not s then return end
    local items = {}
    items[#items + 1] = { label = 'Bonus sur les ventes', icon = 'coins', right = 'x' .. tostring(info.mult or 1), description = 'Pour ton groupe, sur ce point, tant que vous le tenez.' }
    items[#items + 1] = { label = 'Temps de possession', icon = 'clock', right = tostring(info.hours or 0) .. ' h', description = 'Le point reste à ton groupe pendant cette durée.' }
    items[#items + 1] = { label = 'Temps de capture', icon = 'flag', right = dur(info.secs), description = ('Reste dans le cercle de %d m : un autre groupe qui entre, ou moins de %d membres, annule la capture.'):format(math.floor(rad), tonumber(info.min) or 1) }
    items[#items + 1] = { label = 'Membres nécessaires', icon = 'users', right = tostring(info.min or 1), description = 'Membres de ton groupe présents dans le cercle.' }
    items[#items + 1] = { type = 'separator' }
    local function act(label, icon, ev, desc)
        items[#items + 1] = { label = label, icon = icon, description = desc, onSelect = function() G.Menu.Close() TriggerServerEvent(ev, s.id) end }
    end
    local function note(label, desc) items[#items + 1] = { label = label, icon = 'flag', disabled = true, description = desc } end
    if s.ready then
        if s.ready.gang == me and boss then act('Récupérer le drapeau', 'check', 'pb:g:flag:claim', 'Le point devient celui de ton groupe.')
        else note('Drapeau prêt : ' .. tostring(s.ready.label), s.ready.gang == me and 'Le chef de ton groupe doit venir le récupérer.' or nil) end
    elseif s.by then note(('Capture en cours : %s, %d %%'):format(tostring(s.by.label), tonumber(s.prog) or 0))
    elseif s.owner and s.owner.gang == me then
        local left = (tonumber(s.owner.left) or 0) - (GetGameTimer() - recvAt) / 1000
        note('Ton groupe tient ce point', 'Encore ' .. fmt(left) .. '.')
    elseif not me or me == '' then note('Commencer la capture', 'Il faut être dans un groupe illégal.')
    else act('Commencer la capture', 'flag', 'pb:g:flag:start', s.owner and ('Ce point est tenu par ' .. tostring(s.owner.label) .. '.') or nil) end
    G.Menu.Open({ id = 'flag.alt', title = tostring(s.label), subtitle = s.owner and ('Tenu par ' .. tostring(s.owner.label)) or 'Point neutre', items = items })
end
local hudKey = ''

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or not enabled or #spots == 0 then hide() if hudKey ~= '' then hudKey = '' G.send('flag.hud', { show = false }) end Wait(800)
        else
            local c = GetEntityCoords(PlayerPedId())
            local near, nd
            local anyNear = false
            for _, s in ipairs(spots) do
                local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0))
                if d < 90.0 then
                    anyNear = true
                    local x, y, z = s.x + 0.0, s.y + 0.0, s.z - 0.95
                    -- halo au pied du drapeau : blanc tant que personne ne tient le point, puis couleur du groupe
                    local hr, hg, hb = 255, 255, 255
                    if s.owner then hr, hg, hb = rgb(s.owner.color)
                    elseif s.ready and s.ready.color then hr, hg, hb = rgb(s.ready.color)
                    elseif s.by and (tonumber(s.prog) or 0) > 0 then
                        local k = math.min(1.0, (tonumber(s.prog) or 0) / 100.0)
                        local cr, cg, cb = rgb(s.by.color)
                        hr, hg, hb = math.floor(255 + (cr - 255) * k), math.floor(255 + (cg - 255) * k), math.floor(255 + (cb - 255) * k)
                    end
                    DrawMarker(1, x, y, z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 1.6, hr, hg, hb, 110, false, false, 2, false, nil, nil, false)
                    pole(s, d < 70.0)
                    if not nd or d < nd then near, nd = s, d end
                end
            end
            for _, s in ipairs(spots) do if objs[s.id] and #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) >= 90.0 then pole(s, false) end end
            -- état de la zone sur le côté de l'écran (comme « Zone capturée ») tant qu'on est dans le cercle
            local hud
            if near and nd <= rad then
                local s = near
                if s.owner then
                    local left = math.max(0, math.floor((tonumber(s.owner.left) or 0) - (GetGameTimer() - recvAt) / 1000))
                    hud = { title = 'Zone contrôlée', sub = tostring(s.owner.label), info = tostring(s.label) .. ' · encore ' .. fmt(left), color = s.owner.color }
                elseif s.ready then
                    hud = { title = 'Drapeau prêt', sub = tostring(s.ready.label or ''), info = 'Le chef doit venir le récupérer', color = s.ready.color }
                else
                    hud = { title = 'Zone neutre', sub = '', info = '' }
                end
            end
            if hud then
                -- une ligne par groupe présent : nom, effectif et, pour celui qui capture, sa progression
                local byLabel, pr = near.by and near.by.label, tonumber(near.prog) or 0
                hud.pres = {}
                for _, x in ipairs(near.pres or {}) do
                    hud.pres[#hud.pres + 1] = { label = x.label, n = x.n, prog = (x.label == byLabel) and pr or 0 }
                end
            end
            local key = hud and (hud.title .. hud.sub .. hud.info .. json.encode(hud.pres)) or ''
            if key ~= hudKey then hudKey = key G.send('flag.hud', hud or { show = false }) end
            -- invite : le chef du gang dont le drapeau est prêt, dans le cercle
            if near and nd <= rad and near.ready and near.ready.gang == me and boss and not G.Menu.IsOpen() then
                if shown ~= near.id then shown = near.id G.send('prompt', { show = true, key = 'E', text = 'Récupérer le drapeau' }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:flag:claim', near.id) end
            else hide() end
            Wait(anyNear and 0 or 500)   -- aucun drapeau à moins de 90 m : inutile de repasser à chaque image
            if not near then Wait(500) end
        end
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    for _, o in pairs(objs) do if o.e and DoesEntityExist(o.e) then DeleteEntity(o.e) end end
end)
