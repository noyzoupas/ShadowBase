-- (v1.2.91) Carte des joueurs et caméra libre du staff (server/game/staffmap.lua).
local G = PBG

-- Carte des joueurs ---------------------------------------------------------------------------------------------------------------------------
local blips = {}   -- id serveur -> blip
local function clearAll() for _, b in pairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent('pb:g:staff:pmap', function(j)
    local d = G.decode(j) or {}
    if d.off then clearAll() return end
    local seen = {}
    for _, p in ipairs(d.list or {}) do
        seen[p.i] = true
        local b = blips[p.i]
        if not b or not DoesBlipExist(b) then
            b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, 1) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, false) SetBlipCategory(b, 7)
            blips[p.i] = b
        else
            SetBlipCoords(b, p.x + 0.0, p.y + 0.0, p.z + 0.0)
        end
        -- couleur : staff en service (rouge), gang (violet), métier (bleu), sans rien (blanc)
        SetBlipColour(b, p.s and 1 or (p.g and 27 or (p.j and 3 or 0)))
        local label = ('[%s] %s'):format(tostring(p.u), tostring(p.n)) .. (p.j and (' · ' .. p.j) or '') .. (p.g and (' · ' .. p.g) or '')
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(label) EndTextCommandSetBlipName(b)
    end
    for id, b in pairs(blips) do if not seen[id] then if DoesBlipExist(b) then RemoveBlip(b) end blips[id] = nil end end
end)

function G.StaffMapItems(spec, send)
    local m = spec and spec.pmap
    if not m then return {} end
    local function show(kind, id, label) return { label = label, icon = 'gps', checked = nil, right = (m.on and m.kind == kind and (m.id or '') == (id or '')) and 'affiché' or nil,
        onSelect = function() send('pmap', { kind = kind, id = id }) end } end
    local jobs, gangs = {}, {}
    for _, b in ipairs(m.jobs or {}) do jobs[#jobs + 1] = show('job', b[1], b[2]) end
    for _, g in ipairs(m.gangs or {}) do gangs[#gangs + 1] = show('gang', g[1], g[2]) end
    if #jobs == 0 then jobs[1] = { label = 'Aucune entreprise', disabled = true } end
    if #gangs == 0 then gangs[1] = { label = 'Aucun gang', disabled = true } end
    return {
        show('all', '', 'Tous les joueurs'),
        show('staff', '', 'Staff en service'),
        { type = 'submenu', label = 'Une entreprise', icon = 'building', badge = tostring(#(m.jobs or {})), submenu = { id = 'staff.pmap.jobs', title = 'Par entreprise', items = jobs } },
        { type = 'submenu', label = 'Un gang', icon = 'users', badge = tostring(#(m.gangs or {})), submenu = { id = 'staff.pmap.gangs', title = 'Par gang', items = gangs } },
        { label = 'Masquer la carte des joueurs', icon = 'x', disabled = not m.on or nil, onSelect = function() send('pmap', { on = false }) end },
    }
end

-- Caméra libre ----------------------------------------------------------------------------------------------------------------------------------
-- ZQSD / flèches : avancer · souris : regarder · Maj : vite · Ctrl : lent · E / A : monter / descendre · molette : vitesse
-- H : cacher l'interface (pour filmer) · Retour arrière : quitter. Le personnage devient invisible et suit la caméra (le monde reste chargé).
local fc = nil
local function fcStop()
    if not fc then return end
    local f = fc
    fc = nil
    local ped = PlayerPedId()
    RenderScriptCams(false, true, 400, true, true)
    DestroyCam(f.cam, false)
    ClearFocus()
    SetEntityCoordsNoOffset(ped, f.back.x, f.back.y, f.back.z, false, false, false)
    SetEntityHeading(ped, f.bh)
    FreezeEntityPosition(ped, false)
    SetEntityCollision(ped, true, true)
    SetEntityInvincible(ped, f.wasGod)
    SetEntityVisible(ped, f.wasVisible, false)
    DisplayRadar(true)
    if f.hidden then G.send('photo', { on = false }) end
    G.send('prompt', { show = false })
    G.send('notify', { type = 'info', title = 'Caméra libre', text = 'Tu es revenu à ton personnage.' })
end
local function fcStart()
    if fc then fcStop() return end
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then G.send('notify', { type = 'warn', title = 'Caméra libre', text = 'Descends du véhicule d\'abord.' }) return end
    local c = GetGameplayCamCoord()
    local r = GetGameplayCamRot(2)
    local cam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', c.x, c.y, c.z, r.x, 0.0, r.z, 60.0, true, 2)
    RenderScriptCams(true, true, 400, true, true)
    local p = GetEntityCoords(ped)
    fc = { cam = cam, pos = vector3(c.x, c.y, c.z), rx = r.x, rz = r.z, speed = 1.0, fov = 60.0, back = p, bh = GetEntityHeading(ped),
        wasVisible = IsEntityVisible(ped), wasGod = GetPlayerInvincible(PlayerId()), hidden = false }
    SetEntityVisible(ped, false, false)
    SetEntityInvincible(ped, true)
    SetEntityCollision(ped, false, false)
    FreezeEntityPosition(ped, true)
    G.send('prompt', { show = true, free = true, key = '⌫', text = 'Caméra libre : ZQSD · souris · Maj vite · Ctrl lent · E/A monter/descendre · molette vitesse · H interface · Retour arrière : quitter' })
    CreateThread(function()
        while fc do
            Wait(0)
            local f = fc
            DisableAllControlActions(0)
            for _, k in ipairs({ 1, 2, 245, 249 }) do EnableControlAction(0, k, true) end   -- souris, chat, micro
            local mx, my = GetDisabledControlNormal(0, 1), GetDisabledControlNormal(0, 2)
            f.rz = f.rz - mx * 8.0
            f.rx = math.max(-89.0, math.min(89.0, f.rx - my * 8.0))
            if IsDisabledControlJustPressed(0, 241) then f.speed = math.min(8.0, f.speed * 1.25) end
            if IsDisabledControlJustPressed(0, 242) then f.speed = math.max(0.05, f.speed / 1.25) end
            local sp = f.speed * (IsDisabledControlPressed(0, 21) and 4.0 or 1.0) * (IsDisabledControlPressed(0, 36) and 0.2 or 1.0) * 0.6
            local rz, rx = math.rad(f.rz), math.rad(f.rx)
            local fwd = vector3(-math.sin(rz) * math.cos(rx), math.cos(rz) * math.cos(rx), math.sin(rx))
            local right = vector3(math.cos(rz), math.sin(rz), 0.0)
            local mv = vector3(0.0, 0.0, 0.0)
            if IsDisabledControlPressed(0, 32) then mv = mv + fwd end
            if IsDisabledControlPressed(0, 33) then mv = mv - fwd end
            if IsDisabledControlPressed(0, 34) then mv = mv - right end
            if IsDisabledControlPressed(0, 35) then mv = mv + right end
            if IsDisabledControlPressed(0, 38) then mv = mv + vector3(0.0, 0.0, 1.0) end
            if IsDisabledControlPressed(0, 44) then mv = mv - vector3(0.0, 0.0, 1.0) end
            f.pos = f.pos + mv * sp
            SetCamCoord(f.cam, f.pos.x, f.pos.y, f.pos.z)
            SetCamRot(f.cam, f.rx, 0.0, f.rz, 2)
            SetFocusPosAndVel(f.pos.x, f.pos.y, f.pos.z, 0.0, 0.0, 0.0)
            -- le personnage (invisible) suit sous la caméra : les joueurs et le décor autour restent chargés
            SetEntityCoordsNoOffset(PlayerPedId(), f.pos.x, f.pos.y, f.pos.z - 2.0, false, false, false)
            if IsDisabledControlJustPressed(0, 74) then   -- H : interface
                f.hidden = not f.hidden
                DisplayRadar(not f.hidden)
                G.send('photo', { on = f.hidden })
                G.send('prompt', { show = not f.hidden, free = true, key = '⌫', text = 'Caméra libre : Retour arrière pour quitter · H interface' })
            end
            if f.hidden then HideHudAndRadarThisFrame() end
            if IsDisabledControlJustPressed(0, 177) or IsEntityDead(PlayerPedId()) then fcStop() end
        end
    end)
end
G.StaffFreecam = fcStart
function G.StaffFreecamOn() return fc ~= nil end
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then fcStop() clearAll() end end)
