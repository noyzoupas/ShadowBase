-- Objets du décor retirés (server/game/decorhide.lua) : chaque joueur les masque de son côté. Le staff les choisit à la visée depuis le Builder.
local G = PBG
local list, applied = {}, {}   -- applied : id -> ligne masquée sur ce poste
local RADIUS = 0.8

local function hide(r) CreateModelHide(r.x + 0.0, r.y + 0.0, r.z + 0.0, RADIUS, r.m, true) applied[r.id] = r end
local function show(r) RemoveModelHide(r.x + 0.0, r.y + 0.0, r.z + 0.0, RADIUS, r.m, false) applied[r.id] = nil end

RegisterNetEvent('pb:g:decor:all', function(j)
    list = G.decode(j) or {}
    local keep = {}
    for _, r in ipairs(list) do keep[r.id] = true if not applied[r.id] then hide(r) end end
    for id, r in pairs(applied) do if not keep[id] then show(r) end end
    if G.Menu.IsOpen() and G.Menu.Stack:Current() and G.Menu.Stack:Current().def.id == 'b.decor' then G.Menu.Refresh() end
end)
AddEventHandler('onResourceStop', function(res) if res == GetCurrentResourceName() then for _, r in pairs(applied) do show(r) end end end)

function G.DecorList() return list end
-- objet retiré ? (les recherches d'objets du jeu peuvent encore le trouver : distributeur, menu ALT)
function G.DecorHidden(obj)
    if not obj or obj == 0 or not next(applied) then return false end
    local m, c = GetEntityModel(obj), GetEntityCoords(obj)
    for _, r in pairs(applied) do
        if r.m == m and math.abs(r.x - c.x) < 1.0 and math.abs(r.y - c.y) < 1.0 and math.abs(r.z - c.z) < 1.5 then return true end
    end
    return false
end

local function nameOf(ent, hash)
    local ok, n = pcall(GetEntityArchetypeName, ent)
    if ok and type(n) == 'string' and n ~= '' then return n end
    return 'Objet ' .. tostring(hash)
end
local function aimed()
    local rot = GetGameplayCamRot(2)
    local x, z = math.rad(rot.x), math.rad(rot.z)
    local dir = vector3(-math.sin(z) * math.abs(math.cos(x)), math.cos(z) * math.abs(math.cos(x)), math.sin(x))
    local from = GetGameplayCamCoord()
    local to = from + dir * 40.0
    local ray = StartExpensiveSynchronousShapeTestLosProbe(from.x, from.y, from.z, to.x, to.y, to.z, 16 + 256, PlayerPedId(), 0)
    local _, hit, _, _, ent = GetShapeTestResult(ray)
    if (hit == 1 or hit == true) and ent and ent ~= 0 and DoesEntityExist(ent) and GetEntityType(ent) == 3 then return ent end
    return nil
end

-- Mode visée : l'objet regardé est entouré ; E le retire pour tout le monde, Retour arrière quitte
local running = false
function G.DecorPick()
    if running then return end
    running = true
    if G.Menu.Suspend then G.Menu.Suspend() end
    CreateThread(function()
        local cur, shown = nil, nil
        local armed = 0   -- E déjà appuyé sur cet objet : il en faut trois (visée, confirmation, dernière confirmation)
        local function prompt(text) if shown ~= text then shown = text G.send('prompt', { show = true, free = true, key = 'E', text = text }) end end
        while true do
            Wait(0)
            local ent = aimed()
            if ent ~= cur then
                if cur and DoesEntityExist(cur) then SetEntityDrawOutline(cur, false) end
                cur = ent
                armed = 0
                if cur then SetEntityDrawOutline(cur, true) SetEntityDrawOutlineColor(255, 90, 90, 255) end
            end
            local verb = armed == 0 and 'Retirer' or armed == 1 and 'E encore pour confirmer : retirer' or 'Dernière confirmation, E : retirer'
            prompt(cur and (verb .. ' « ' .. nameOf(cur, GetEntityModel(cur)) .. ' » pour tout le monde  ·  Retour arrière : quitter') or 'Vise un objet du décor  ·  Retour arrière : quitter')
            if cur and IsControlJustPressed(0, 38) then
                if armed < 2 then armed = armed + 1
                else
                    local c, m = GetEntityCoords(cur), GetEntityModel(cur)
                    SetEntityDrawOutline(cur, false)
                    TriggerServerEvent('pb:g:decor:hide', { model = m, x = c.x, y = c.y, z = c.z, label = nameOf(cur, m) })
                    cur, armed = nil, 0
                    Wait(450)
                end
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                break
            end
        end
        if cur and DoesEntityExist(cur) then SetEntityDrawOutline(cur, false) end
        G.send('prompt', { show = false })
        running = false
        if G.Menu.Resume then G.Menu.Resume() end
    end)
end

-- Entrée du Builder
function G.DecorItems()
    local rows = {}
    rows[#rows + 1] = { label = 'Retirer un objet à la visée', icon = 'trash', description = "Distributeur, poubelle, barrière… Vise l'objet puis E. Il disparaît pour tout le monde.", onSelect = function() G.DecorPick() end }
    rows[#rows + 1] = { type = 'separator', label = 'Objets retirés : Entrée pour les remettre' }
    local me = GetEntityCoords(PlayerPedId())
    local sorted = {}
    for _, r in ipairs(list) do sorted[#sorted + 1] = { r = r, d = #(me - vector3(r.x + 0.0, r.y + 0.0, r.z + 0.0)) } end
    table.sort(sorted, function(a, b) return a.d < b.d end)
    for _, s in ipairs(sorted) do
        rows[#rows + 1] = { label = (s.r.l ~= '' and s.r.l) or ('Objet ' .. s.r.m), icon = 'plus', right = math.floor(s.d + 0.5) .. ' m', description = 'Remet cet objet pour tout le monde.', onSelect = function() TriggerServerEvent('pb:g:decor:show', s.r.id) end }
    end
    if #sorted == 0 then rows[#rows + 1] = { label = 'Aucun objet retiré', disabled = true } end
    return rows
end
