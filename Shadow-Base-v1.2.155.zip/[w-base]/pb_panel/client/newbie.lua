-- (v1.2.79) Protection des nouveaux joueurs (server/game/newbie.lua).
-- Pour le nouveau : arme rangée, pas de tir ni de coup, temps restant affiché, et son véhicule traverse les autres joueurs et leurs véhicules.
-- Pour tous les autres : le véhicule d'un nouveau proche les traverse aussi (la collision est coupée des deux côtés).
local G = PBG
local endAt = 0
RegisterNetEvent('pb:g:newbie', function(j)
    local d = G.decode(j) or {}
    local left = tonumber(d.left) or 0
    endAt = left > 0 and (GetGameTimer() + left * 1000) or 0
    if left > 0 then SetCurrentPedWeapon(PlayerPedId(), GetHashKey('WEAPON_UNARMED'), true) end
end)
local function protected() return endAt > GetGameTimer() end
local function txt(s, y)
    SetTextFont(4) SetTextScale(0.0, 0.34) SetTextColour(181, 140, 255, 215) SetTextCentre(true) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(s) EndTextCommandDisplayText(0.5, y)
end

-- tir, visée, coups, lancer, tir depuis un véhicule
local CONTROLS = { 24, 25, 37, 45, 47, 58, 69, 70, 92, 114, 140, 141, 142, 143, 257, 263, 264, 331 }
local warnAt = 0
CreateThread(function()
    while true do
        if protected() and G.begun then
            Wait(0)
            local me, ped = PlayerId(), PlayerPedId()
            DisablePlayerFiring(me, true)
            for _, c in ipairs(CONTROLS) do DisableControlAction(0, c, true) end
            if GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_UNARMED') then
                SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
                if GetGameTimer() > warnAt then
                    warnAt = GetGameTimer() + 8000
                    G.send('notify', { type = 'warn', title = 'Nouveau joueur', text = 'Pas d\'arme pendant tes premières minutes de jeu.' })
                end
            end
            local left = math.floor((endAt - GetGameTimer()) / 1000)
            txt(('NOUVEAU JOUEUR  ·  protection encore %d min'):format(math.ceil(left / 60)), 0.915)
        else
            Wait(500)
        end
    end
end)

-- Véhicules qui se traversent : on relit la liste des joueurs proches toutes les 500 ms, la collision est coupée à chaque image
local pairsNow = {}   -- { { a, b }, … } entités qui ne doivent pas se toucher
local function isNew(sid) local st = Player(sid).state return st and st.pbNew == true end
CreateThread(function()
    while true do
        Wait(500)
        local out = {}
        local me = PlayerPedId()
        local mc = GetEntityCoords(me)
        local myVeh = GetVehiclePedIsIn(me, false)
        local iAmNew = protected() and myVeh ~= 0 and GetPedInVehicleSeat(myVeh, -1) == me   -- seulement au volant
        for _, pl in ipairs(GetActivePlayers()) do
            if pl ~= PlayerId() then
                local ped = GetPlayerPed(pl)
                if ped ~= 0 and #(GetEntityCoords(ped) - mc) < 120.0 then
                    local veh = GetVehiclePedIsIn(ped, false)
                    if iAmNew then   -- mon véhicule traverse les autres et leurs véhicules
                        out[#out + 1] = { myVeh, ped }
                        if veh ~= 0 and veh ~= myVeh then out[#out + 1] = { myVeh, veh } end
                    end
                    if veh ~= 0 and veh ~= myVeh and GetPedInVehicleSeat(veh, -1) == ped and isNew(GetPlayerServerId(pl)) then   -- le véhicule d'un nouveau me traverse
                        out[#out + 1] = { veh, me }
                        if myVeh ~= 0 then out[#out + 1] = { veh, myVeh } end
                    end
                end
            end
        end
        pairsNow = out
    end
end)
CreateThread(function()
    while true do
        if #pairsNow == 0 then Wait(250)
        else
            Wait(0)
            for _, p in ipairs(pairsNow) do
                if DoesEntityExist(p[1]) and DoesEntityExist(p[2]) then
                    SetEntityNoCollisionEntity(p[1], p[2], true)
                    SetEntityNoCollisionEntity(p[2], p[1], true)
                end
            end
        end
    end
end)
