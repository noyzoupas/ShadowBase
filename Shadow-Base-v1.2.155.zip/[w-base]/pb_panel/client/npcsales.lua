-- (v1.2.78) Agence immobilière PNJ (Builder › Immobilier) : E -> logements libres, GPS et visite de 15 minutes.
local G = PBG

local points, blips = {}, {}
local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local n = c.npcsales or {}
    points = n.agency or {}
    local npcs = {}
    for _, p in ipairs(points) do npcs[#npcs + 1] = { id = p.id, model = tostring(n.ped or 'a_m_y_business_03'), x = p.x, y = p.y, z = p.z, h = p.h or 0.0, scenario = 'WORLD_HUMAN_CLIPBOARD' } end
    G.Npcs('npcagency', npcs)
    clearBlips()
    for _, p in ipairs(points) do
        local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(b, 374) SetBlipColour(b, 0) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label or 'Agence immobilière')) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end

local function money(n) return PB.Money(n) end
RegisterNetEvent('pb:g:npcre:menu', function(j)
    local d = G.decode(j)
    if not d or G.creating or G.state.dead then return end
    local items = {}
    for _, h in ipairs(d.homes or {}) do
        local price = h.kind == 'buy' and money(h.price) or (money(h.rent) .. ' / ' .. (d.days or 7) .. ' j')
        local dist = h.dist >= 1000 and ('%.1f km'):format(h.dist / 1000) or (h.dist .. ' m')
        local sub = {
            { label = 'Mettre le GPS', icon = 'gps', description = 'Achat ou location à la porte (E).', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:npcre:act', h.id, 'gps') end },
        }
        if h.inside then sub[#sub + 1] = { label = 'Visiter (15 minutes)', icon = 'home', description = "L'agence t'ouvre la porte 15 minutes ; le GPS se pose dessus.", onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:npcre:act', h.id, 'visit') end } end
        items[#items + 1] = { type = 'submenu', label = tostring(h.label), icon = 'home', right = price, description = (h.kind == 'buy' and 'À vendre' or 'À louer') .. ' · ' .. dist,
            submenu = { id = 'npcre.' .. h.id, title = tostring(h.label), subtitle = price, items = sub } }
    end
    if #items == 0 then items[1] = { label = 'Aucun logement libre pour le moment', disabled = true } end
    G.Menu.Open({ id = 'npcre', title = 'Agence immobilière', subtitle = 'Logements libres', banner = { text = 'Immobilier' }, items = items })
end)

CreateThread(function()
    local shown
    while true do
        local best, bd = nil, 1e9
        if #points > 0 and G.begun and not G.state.dead then
            local c = GetEntityCoords(PlayerPedId())
            for _, p in ipairs(points) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd = p, d end end
        end
        if best and bd <= 12.0 then
            G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 223, 226, 231, 1.0)
            if bd <= 2.5 and not G.Menu.IsOpen() and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt2', { id = 'npcagency', show = true, key = 'E', text = tostring(best.label or 'Agence immobilière') }) end
                if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:npcre:open') end
            elseif shown then shown = nil G.send('prompt2', { id = 'npcagency', show = false }) end
            Wait(0)
        else
            if shown then shown = nil G.send('prompt2', { id = 'npcagency', show = false }) end
            Wait(700)
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then clearBlips() end end)
