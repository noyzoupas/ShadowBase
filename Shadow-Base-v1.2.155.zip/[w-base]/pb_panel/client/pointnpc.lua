-- PNJ d'un point posé au Builder : choix du style avec aperçu devant soi, puis placement à la main. Le serveur vérifie et enregistre.
local G = PBG

RegisterNetEvent('pb:g:pnpc:list', function(j)
    local rows = G.decode(j) or {}
    local list = {}
    for _, r in ipairs(rows) do list[#list + 1] = { id = r.id, model = r.model, x = r.x + 0.0, y = r.y + 0.0, z = r.z + 0.0, h = (tonumber(r.h) or 0) + 0.0, scenario = 'WORLD_HUMAN_STAND_IMPATIENT' } end
    G.Npcs('points', list)
end)

local function ghostPed(model, at, h)
    local m = joaat(model)
    if not IsModelInCdimage(m) then return nil end
    RequestModel(m)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(m) and GetGameTimer() < t do Wait(10) end
    if not HasModelLoaded(m) then return nil end
    local e = CreatePed(4, m, at.x, at.y, at.z - 50.0, h, false, false)
    SetModelAsNoLongerNeeded(m)
    SetEntityAlpha(e, 190, false)
    SetEntityCollision(e, false, false)
    SetEntityInvincible(e, true)
    SetBlockingOfNonTemporaryEvents(e, true)
    FreezeEntityPosition(e, true)
    SetPedDefaultComponentVariation(e)
    return e
end
local function dropPed(e) if e and DoesEntityExist(e) then DeleteEntity(e) end end
-- point au sol, à `dist` mètres devant le joueur
local function ahead(dist)
    local me = PlayerPedId()
    local c, r = GetEntityCoords(me), math.rad(GetEntityHeading(me))
    local x, y = c.x - math.sin(r) * dist, c.y + math.cos(r) * dist
    local ok, gz = GetGroundZFor_3dCoord(x, y, c.z + 1.0, false)
    return vector3(x, y, (ok and math.abs(gz - c.z) < 4.0) and gz or (c.z - 1.0))
end

-- Aperçu du style survolé
local pv = { model = nil, run = false }
local function previewStop() pv.model = nil end
local function previewSet(model)
    pv.model = model
    if pv.run or not model then return end
    pv.run = true
    CreateThread(function()
        local cur, e
        while pv.model do
            if cur ~= pv.model then
                dropPed(e)
                cur = pv.model
                e = ghostPed(cur, GetEntityCoords(PlayerPedId()), 0.0)
            end
            if e and DoesEntityExist(e) then
                local p = ahead(2.2)
                SetEntityCoordsNoOffset(e, p.x, p.y, p.z + 1.0, false, false, false)
                SetEntityHeading(e, (GetEntityHeading(PlayerPedId()) + 180.0) % 360.0)
            end
            Wait(0)
        end
        dropPed(e)
        pv.run = false
    end)
end

-- Placement : le PNJ se tient devant toi et te suit. ← → : tourner · ↑ ↓ : plus loin / plus près · E : poser · Retour arrière : annuler
local function place(model, cb)
    if G.Menu.Suspend then G.Menu.Suspend() end
    CreateThread(function()
        while pv.run do Wait(0) end
        local e = ghostPed(model, GetEntityCoords(PlayerPedId()), 0.0)
        if not e then
            if G.Menu.Resume then G.Menu.Resume() end
            G.send('notify', { type = 'error', title = 'Builder', text = 'Ce style de PNJ est introuvable dans le jeu.' })
            cb(nil)
            return
        end
        local dist, turn = 2.0, 180.0
        G.send('prompt', { show = true, free = true, key = 'E', text = 'Poser le PNJ  ·  ← → tourner  ·  ↑ ↓ plus loin / plus près  ·  Retour arrière : annuler' })
        local pos, h
        while true do
            Wait(0)
            for _, k in ipairs({ 172, 173, 174, 175, 200 }) do DisableControlAction(0, k, true) end
            if IsDisabledControlPressed(0, 174) then turn = turn + 1.5 end
            if IsDisabledControlPressed(0, 175) then turn = turn - 1.5 end
            if IsDisabledControlPressed(0, 172) then dist = math.min(12.0, dist + 0.03) end
            if IsDisabledControlPressed(0, 173) then dist = math.max(0.8, dist - 0.03) end
            local p = ahead(dist)
            local ph = (GetEntityHeading(PlayerPedId()) + turn) % 360.0
            SetEntityCoordsNoOffset(e, p.x, p.y, p.z + 1.0, false, false, false)
            SetEntityHeading(e, ph)
            if IsControlJustPressed(0, 38) then pos, h = p, ph break
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then break end
        end
        dropPed(e)
        G.send('prompt', { show = false })
        if G.Menu.Resume then G.Menu.Resume() end
        cb(pos, h)
    end)
end

RegisterNetEvent('pb:g:pnpc:offer', function(j)
    local d = G.decode(j)
    if not d then return end
    CreateThread(function()
        Wait(450)   -- le temps que la liste du Builder revienne : ce menu s'ouvre par-dessus
        while G.VehSpotBusy and G.VehSpotBusy() do Wait(100) end   -- location : d'abord l'emplacement des véhicules
        local pushed = G.Menu.IsOpen()
        local function leave()
            previewStop()
            if pushed then G.Menu.Back() else G.Menu.Close() end
        end
        local items = { { label = 'Sans PNJ', icon = 'x', description = 'Le point reste seul.', onSelect = function() leave() TriggerServerEvent('pb:g:pnpc:none') end } }
        items[#items + 1] = { type = 'separator', label = 'Styles : aperçu devant toi au survol' }
        for _, s in ipairs(d.styles or {}) do
            if IsModelInCdimage(joaat(s[1])) then
                items[#items + 1] = { label = s[2], icon = 'user', pm = s[1], description = 'Entrée : le placer toi-même.', onSelect = function()
                    previewStop()
                    place(s[1], function(pos, h)
                        leave()
                        if pos then TriggerServerEvent('pb:g:pnpc:set', s[1], pos.x, pos.y, pos.z, h) end
                    end)
                end }
            end
        end
        local def = { id = 'pnpc.pick', title = 'PNJ du point', subtitle = tostring(d.label or ''), nosearch = true, items = items,
            onHover = function(it) previewSet(it and it.pm or nil) end,
            onClose = previewStop }
        if pushed then G.Menu.Push(def) else G.Menu.Open(def) end
    end)
end)
-- Menu ALT du staff sur un PNJ posé
function G.NpcMenu(np)
    local note = np.group == 'shops' and 'Le vendeur de ce magasin disparaît pour tout le monde. Il se remet dans Builder › Existant, « PNJ de ce point ».' or 'Ce PNJ disparaît pour tout le monde. Il se remet dans Builder › Existant, « PNJ de ce point ».'
    G.Menu.Open({ id = 'staff.npc.alt', title = 'PNJ', subtitle = np.group == 'shops' and 'Vendeur du magasin' or 'PNJ du point', nosearch = true, items = {
        { label = 'Retirer ce PNJ', icon = 'trash', description = note, onSelect = function()
            G.Menu.ConfirmTwice('Ce PNJ', note, function() G.Menu.Close() TriggerServerEvent('pb:g:pnpc:remove', np.group, np.id) end)
        end },
    } })
end
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then previewStop() end end)
