-- (patch 340) Établi vu du dessus : caméra au-dessus de l'établi, pièces à glisser sur le tapis (web/game/bench.js).
-- Autres ressources : TriggerEvent('pb:g:bench', { token, mode = 'weapon'|'drug', title, hint, secs, parts = { { id, label, kind } } })
-- puis écouter 'pb:g:bench:done' (token, { ok, errors, ms, cancel }).
local G = PB.G
local running, cam, cur
local function finish(res)
    if not running then return end
    running = false
    G.send('bench.close', {})
    G.focus(false)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    if cam then RenderScriptCams(false, true, 500, true, false) DestroyCam(cam, false) cam = nil end
    local tok = cur and cur.token
    cur = nil
    TriggerEvent('pb:g:bench:done', tok, res or { ok = false })
end
function G.BenchGame(spec)
    if running or not spec then return false end
    running, cur = true, spec
    local ped = PlayerPedId()
    local c, hd = GetEntityCoords(ped), math.rad(GetEntityHeading(ped))
    local fx, fy = -math.sin(hd), math.cos(hd)
    FreezeEntityPosition(ped, true)
    cam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', c.x + fx * 0.5, c.y + fy * 0.5, c.z + 1.9, -89.0, 0.0, GetEntityHeading(ped), 50.0, true, 2)
    SetCamActive(cam, true) RenderScriptCams(true, true, 700, true, false)
    G.focus(true)
    G.send('bench.open', spec)
    CreateThread(function()
        local at = c
        while running do
            Wait(250)
            local p = PlayerPedId()
            if IsEntityDead(p) or #(GetEntityCoords(p) - at) > 3.0 then finish({ ok = false, cancel = true }) end
        end
    end)
    return true
end
G.nui['bench.done'] = function(d) finish({ ok = d.ok == true, errors = tonumber(d.errors) or 0, ms = tonumber(d.ms) or 0, cancel = d.cancel == true }) return {} end
AddEventHandler('pb:g:bench', function(spec) if type(spec) == 'table' then G.BenchGame(spec) end end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and running then running = false FreezeEntityPosition(PlayerPedId(), false) G.focus(false) if cam then RenderScriptCams(false, false, 0, true, false) DestroyCam(cam, false) end end end)
