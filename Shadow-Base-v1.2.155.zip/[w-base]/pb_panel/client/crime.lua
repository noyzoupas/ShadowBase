-- Activités illégales : marqueurs, invite E, barre de progression ; le serveur valide le départ et la fin.
local G = PBG
local spots, active = {}, false
-- niveau d'un braquage (même règle que le serveur, server/game/crime.lua C.TierOf)
function G.HeistTier(s)
    local t = tostring(s and s.tier or ''):lower()
    if t == 'superette' or t == 'bijouterie' or t == 'fleeca' or t == 'maze' then return t end
    local n = (tostring(s and s.label or '') .. ' ' .. tostring(s and s.id or '')):lower()
    for _, w in ipairs({ 'maze', 'pacific', 'union', 'centrale', 'depository' }) do if n:find(w, 1, true) then return 'maze' end end
    for _, w in ipairs({ 'fleeca', 'banque', 'bank', 'blaine', 'paleto' }) do if n:find(w, 1, true) then return 'fleeca' end end
    for _, w in ipairs({ 'bijou', 'jewel', 'vangelico' }) do if n:find(w, 1, true) then return 'bijouterie' end end
    return 'superette'
end
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local cr = c.crime or {}
    spots = {}
    if cr.enabled == false then return end
    local polys = cr.polys or {}
    local function add(kind, list) for _, s in ipairs(list or {}) do local p = polys[s.id] spots[#spots + 1] = { kind = kind, id = s.id, label = s.label, x = s.x + 0.0, y = s.y + 0.0, z = s.z + 0.0, r = tonumber(s.radius) or 3.0, poly = (type(p) == 'table' and #p >= 3) and p or nil, npc = s.mode == 'npc' or nil, cook = s.mode == 'cook' or nil, drug = s.drug, io = tostring(s.item_in or '') .. ' ' .. tostring(s.item_out or '') } end end
    add('chain', cr.chain) for _, s in ipairs(cr.heists or {}) do local t = G.HeistTier(s) spots[#spots + 1] = { kind = 'heist', id = s.id, label = s.label, x = s.x + 0.0, y = s.y + 0.0, z = s.z + 0.0, r = tonumber(s.radius) or 3.0, ped = s.ped, h = s.h, px = tonumber(s.px), py = tonumber(s.py), pz = tonumber(s.pz), tier = t, mode = t == 'superette' and 'clerk' or 'interact', auto = s.auto } end   -- (patch 136) blanchiment : client/launder.lua (contact PNJ)
    G.crimeCfg = cr
end

-- Filière : le geste remplace la barre de progression (récolte : se penche ; transformation : prépare ; vente : échange), joué en boucle pendant l'action
local GESTURE = {
    harvest = { 'pickup_object', 'pickup_low' },
    process = { 'anim@amb@business@meth@meth_monitoring_cooking@cooking@', 'chemical_pour_long_cooker' },   -- (v1.2.45) labo : on verse les produits
    sell = { 'mp_common', 'givetake1_a' },
}
local function playGesture(kind, secs)
    local g = GESTURE[kind]
    if not g then return false end
    RequestAnimDict(g[1])
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded(g[1]) and GetGameTimer() < t do Wait(10) end
    if not HasAnimDictLoaded(g[1]) then return false end
    CreateThread(function()
        local stop = GetGameTimer() + secs * 1000
        while active and GetGameTimer() < stop do
            TaskPlayAnim(PlayerPedId(), g[1], g[2], 8.0, -8.0, -1, 0, 0, false, false, false)
            local len = math.max(600, math.floor((GetAnimDuration(g[1], g[2]) or 1.0) * 1000))
            Wait(math.min(len, math.max(200, stop - GetGameTimer())))
        end
        RemoveAnimDict(g[1])
    end)
    return true
end

RegisterNetEvent('pb:g:crime:go', function(j)
    local d = G.decode(j)
    if not d then return end
    -- prise de territoire : seulement la barre (client/territories.lua gère la fin) ; on ne bloque pas le joueur
    if d.kind == 'terr' then G.send('crime.progress', { label = d.label, secs = tonumber(d.time) or 30 }) return end
    if d.kind == 'heist' then G.HeistRun(d) return end
    if d.cook then G.CookRun(d) return end   -- (patch 313) labo interactif
    -- (patch 340) laboratoire : établi vu du dessus, on glisse les ingrédients sur le tapis (client/bench.lua) ; le temps de la recette reste le minimum
    if d.anim == 'process' and G.BenchGame then
        active = true
        local res
        local h = AddEventHandler('pb:g:bench:done', function(tok, r) if tok == 'crime' then res = r or { ok = false } end end)
        TriggerEvent('pb:g:bench', { token = 'crime', mode = 'drug', title = tostring(d.label or 'Laboratoire'), secs = tonumber(d.time) or 8, hint = 'Glisse chaque élément sur son emplacement.',
            parts = { { id = 'a', label = 'Produit', kind = 'jar' }, { id = 'b', label = 'Poudre', kind = 'powder' }, { id = 'c', label = 'Balance', kind = 'scale' }, { id = 'd', label = 'Sachet', kind = 'bag' } } })
        CreateThread(function()
            while not res do Wait(100) end
            RemoveEventHandler(h)
            active = false
            if res.ok then TriggerServerEvent('pb:g:crime:end', true) else G.send('notify', { type = 'warn', title = 'Activité', text = 'Interrompu.' }) TriggerServerEvent('pb:g:crime:end', false) end
        end)
        return
    end
    -- (v1.2.45) laboratoire : plus de mini-jeu, seulement l'animation de préparation (et la barre de progression)
    active = true
    local ped = PlayerPedId()
    local secs = tonumber(d.time) or 5
    local gesture = d.anim and GESTURE[d.anim] ~= nil
    local bar = true   -- barre de progression à chaque action (récolte, labo, vente) : elle sera toujours retirée à la fin
    if bar then G.send('crime.progress', { label = d.label, secs = secs, x = true }) end
    local scene
    if gesture then playGesture(d.anim, secs)
    else TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_STAND_IMPATIENT', 0, true) end
    CreateThread(function()
        local t0, ok = GetGameTimer(), true
        while GetGameTimer() - t0 < secs * 1000 do
            Wait(100)
            local p = PlayerPedId()
            local c = GetEntityCoords(p)
            if IsEntityDead(p) or #(c - vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)) > (tonumber(d.radius) or 4.5) then ok = false break end
            -- X (arrêt de l'animation) : l'action est annulée pour de vrai (avant, l'animation s'arrêtait mais le compteur continuait)
            if IsControlJustPressed(0, 73) or IsDisabledControlJustPressed(0, 73) then ok = false break end
        end
        active = false
        if scene then scene.stop(ok) end
        ClearPedTasks(PlayerPedId())
        if bar then G.send('crime.progress', { cancel = true }) end
        if not ok then G.send('notify', { type = 'warn', title = 'Activité', text = 'Interrompu.' }) end
        TriggerServerEvent('pb:g:crime:end', ok)
    end)
end)

CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #spots == 0 or active or G.Menu.IsOpen() then hide() Wait(500)
        else
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(spots) do if s.kind ~= 'heist' and not s.npc then   -- (patch 315) vente aux passants : gérée plus bas
                local d = #(c - vector3(s.x, s.y, s.z))
                -- zone tracée : 0 dedans, sinon la distance à son bord (à peu près)
                if s.poly then d = (math.abs(c.z - s.z) < 15.0 and G.InPoly(c.x, c.y, s.poly)) and 0.0 or math.max(0.1, d - s.r) end
                if not bd or d < bd then best, bd = s, d end
            end end
            local cr = G.crimeCfg or {}
            local isZone = best and (best.poly or best.r > 3.5)
            local seen = best and not isZone and bd < 25.0 and cr.show_markers ~= false
            if seen then
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 0.95, 255, 255, 255, 1.0)   -- la touche E flotte au-dessus du point
            end
            local near = best and (best.poly and bd == 0.0 or (not best.poly and bd <= math.max(best.r, tonumber(cr.use_dist) or 2.5)))
            if near and GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
                if shown ~= best.id then shown = best.id G.send('prompt', { show = true, key = 'E', text = best.label }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:crime:start', best.kind, best.id) end
                Wait(0)
            else hide() Wait(seen and 0 or (bd and bd < 40 and 150 or 700)) end   -- le repère se dessine à chaque image, sinon il ne se voit pas
        end
    end
end)

-- Braquage. Supérette : on vise le vendeur (arme à feu ou arme blanche) un court instant ; le vendeur est le PNJ du jeu déjà au
-- comptoir, sinon on en pose un. Bijouterie et banques : touche E au point posé. Le serveur relit la distance, l'arme, les policiers
-- et le délai. L'invite du braquage a sa propre ligne (« prompt2 ») : celle du magasin au même comptoir ne l'efface plus.
local clerks = {}        -- id du point -> ped posé par nous
local MELEE = 2685387236
local function clerkPos(s)
    if s.px and s.py then return s.px, s.py, s.pz or s.z, s.h end
    local c = PB.ClerkSpot(s.x, s.y, s.z)
    if c then return c.x, c.y, c.z, c.h end
    return s.x, s.y, s.z, s.h
end
local found = {}   -- vendeur trouvé dans le décor : gardé tant qu'il existe et reste au comptoir (plus de clignotement de l'invite)
local function okPed(p) return p and DoesEntityExist(p) and not IsEntityDead(p) end
local function clerkAt(s)
    local ped = clerks[s.id]
    if okPed(ped) then return ped end
    local cx, cy, cz = clerkPos(s)
    local here = vector3(cx + 0.0, cy + 0.0, (cz or s.z) + 0.0)
    local f = found[s.id]
    if f and okPed(f.ped) and #(GetEntityCoords(f.ped) - here) < 8.0 then return f.ped end
    if f and not f.ped and GetGameTimer() < f.t then return nil end
    local me = PlayerPedId()
    local best, bd
    for _, p in ipairs(GetGamePool and GetGamePool('CPed') or {}) do
        if p ~= me and not IsPedAPlayer(p) and not IsPedDeadOrDying(p, true) and not IsPedInAnyVehicle(p, false) then
            local d = #(GetEntityCoords(p) - here)
            if d < 4.5 and (not bd or d < bd) then best, bd = p, d end
        end
    end
    found[s.id] = { ped = best, t = GetGameTimer() + 1000 }
    return best
end
local spawning = {}
local function spawnClerk(s)
    if spawning[s.id] then return end
    spawning[s.id] = true
    CreateThread(function()
        local model = joaat(s.ped ~= nil and s.ped ~= '' and s.ped or 'mp_m_shopkeep_01')
        RequestModel(model)
        local t = GetGameTimer() + 3000
        while not HasModelLoaded(model) and GetGameTimer() < t do Wait(50) end
        if HasModelLoaded(model) and not okPed(clerks[s.id]) then
            local cx, cy, cz, ch = clerkPos(s)
            local ped = CreatePed(4, model, cx, cy, G.Ground(cx, cy, cz), (tonumber(ch) or 0.0) + 0.0, false, false)
            SetEntityInvincible(ped, false) SetBlockingOfNonTemporaryEvents(ped, true) SetPedFleeAttributes(ped, 0, false) FreezeEntityPosition(ped, true)
            SetModelAsNoLongerNeeded(model)
            clerks[s.id] = ped
        end
        spawning[s.id] = nil
    end)
end
CreateThread(function()
    local hold, shown = 0, nil
    local function show(key, text)
        if shown ~= key .. text then shown = key .. text G.send('prompt2', { id = 'heist', show = true, key = key, text = text }) end
    end
    local function hide() hold = 0 if shown then shown = nil G.send('prompt2', { id = 'heist', show = false }) end end
    while true do
        local sleep = 700
        if G.begun and not active and not G.Menu.IsOpen() then
            local me = PlayerPedId()
            local c = GetEntityCoords(me)
            local target, td
            for _, s in ipairs(spots) do
                if s.kind == 'heist' then
                    local d = #(c - vector3(s.x, s.y, s.z))
                    if d < 45.0 then
                        sleep = math.min(sleep, 250)
                        if s.mode == 'clerk' and not s.auto and d < 30.0 and not clerkAt(s) then spawnClerk(s) end   -- supérette auto : son propre vendeur (pas de second)
                    end
                    if d < s.r + 4.0 and (not td or d < td) then target, td = s, d end
                end
            end
            local cr = G.crimeCfg or {}
            if target and target.mode ~= 'clerk' and td < 25.0 and cr.show_markers ~= false then G.Point(target.x, target.y, target.z - 0.95, 255, 255, 255, 1.0) sleep = 0 end
            if target and GetVehiclePedIsIn(me, false) == 0 then
                local s = target
                sleep = 0
                if s.mode == 'clerk' then
                    local ped = clerkAt(s)
                    local _, w = GetCurrentPedWeapon(me, true)
                    local armed = w and w ~= joaat('WEAPON_UNARMED')
                    if not ped then show('…', "Le vendeur n'est pas au comptoir")
                    elseif not armed then show('TAB', 'Sors une arme (même blanche) et vise le vendeur')
                    else
                        local aiming
                        if GetWeapontypeGroup(w) == MELEE then
                            local to = GetEntityCoords(ped) - c
                            local len = #to
                            local fwd = GetEntityForwardVector(me)
                            aiming = IsControlPressed(0, 25) and len < 3.5 and len > 0.01 and ((fwd.x * to.x + fwd.y * to.y) / len) > 0.6
                        else
                            aiming = IsPlayerFreeAimingAtEntity(PlayerId(), ped) or (IsControlPressed(0, 25) and IsPlayerTargettingEntity(PlayerId(), ped))
                        end
                        if aiming then
                            hold = hold + (GetFrameTime and GetFrameTime() or 0.016)
                            local need = math.max(0.5, math.min(20, tonumber((G.crimeCfg or {}).aim_hold) or 5))
                            show('CLIC', ('Garde le vendeur en joue… %d %%'):format(math.min(100, math.floor(hold / need * 100))))
                            if hold >= need then
                                hide()
                                G.heistClerk, G.heistClerkAt = ped, GetGameTimer()
                                TriggerServerEvent('pb:g:crime:start', 'heist', s.id)
                                Wait(1500)
                            end
                        else hold = 0 show('CLIC', 'Vise le vendeur pour braquer : ' .. s.label) end
                    end
                elseif td <= math.max(s.r, tonumber(cr.use_dist) or 2.5) then
                    show('E', 'Braquer : ' .. s.label)
                    if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:crime:start', 'heist', s.id) Wait(1500) end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)
-- le vendeur lève les mains pendant le braquage

-- Mise en scène des braquages ----------------------------------------------------------------------------------------------------------------
local function dict(d) RequestAnimDict(d) local t = GetGameTimer() + 1500 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
local function prop(model, ped, bone, pos, rot)
    local h = GetHashKey(model)
    if not IsModelInCdimage(h) then return nil end
    RequestModel(h)
    local t = GetGameTimer() + 1500
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
    if not HasModelLoaded(h) then return nil end
    local c = GetEntityCoords(ped)
    local o = CreateObject(h, c.x, c.y, c.z, false, false, false)
    AttachEntityToEntity(o, ped, GetPedBoneIndex(ped, bone), pos[1], pos[2], pos[3], rot[1], rot[2], rot[3], true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(h)
    return o
end

-- Supérette : le vendeur lève les mains, crie, remplit un sac à la caisse, puis se recroqueville ; le braqueur le tient en joue.
function G.RobberyScene(clerk, robber, secs)
    local alive, bag = true, nil
    G.SetBusy(clerk, true)   -- le vendeur ne se retourne plus vers le joueur : il va à la caisse
    FreezeEntityPosition(clerk, false)
    SetBlockingOfNonTemporaryEvents(clerk, true)
    ClearPedTasksImmediately(clerk)
    TaskAimGunAtEntity(robber, clerk, 2500, true)                       -- pointe l'arme un instant, puis le braqueur est libre (il doit tenir la zone)
    CreateThread(function()
        PlayPedAmbientSpeechNative(clerk, 'GENERIC_FRIGHTENED_HIGH', 'SPEECH_PARAMS_FORCE_SHOUTED')
        if dict('missminuteman_1ig_2') then TaskPlayAnim(clerk, 'missminuteman_1ig_2', 'handsup_base', 4.0, -4.0, -1, 49, 0, false, false, false) end
        Wait(2200)
        if not alive then return end
        -- à la caisse : l'animation de braquage du jeu (le vendeur remplit le sac)
        local holdup = dict('mp_am_hold_up')
        if holdup then
            ClearPedTasksImmediately(clerk)
            TaskPlayAnim(clerk, 'mp_am_hold_up', 'holdup_victim_20s', 2.0, -2.0, -1, 1, 0, false, false, false)
            bag = prop('p_poly_bag_01_s', clerk, 28422, { 0.05, 0.0, -0.05 }, { 0.0, 0.0, 0.0 })
        end
        local t0 = GetGameTimer()
        while alive and GetGameTimer() - t0 < math.max(0, secs * 1000 - 2400) do
            Wait(500)
            -- si quelque chose a coupé l'animation (PNJ du magasin, autre script), il retourne vider la caisse
            if holdup and DoesEntityExist(clerk) and not IsEntityPlayingAnim(clerk, 'mp_am_hold_up', 'holdup_victim_20s', 3) then
                TaskPlayAnim(clerk, 'mp_am_hold_up', 'holdup_victim_20s', 2.0, -2.0, -1, 1, 0, false, false, false)
            end
            if math.random() < 0.12 then PlayPedAmbientSpeechNative(clerk, 'GENERIC_FRIGHTENED_MED', 'SPEECH_PARAMS_FORCE') end
        end
    end)
    return { stop = function(ok)
        alive = false
        if bag and DoesEntityExist(bag) then DeleteEntity(bag) end
        if not DoesEntityExist(clerk) then return end
        ClearPedTasks(clerk)
        -- caisse vidée : il se recroqueville derrière le comptoir ; braquage interrompu : il reste les mains levées
        if ok and dict('amb@code_human_cower_stand@male@base') then TaskPlayAnim(clerk, 'amb@code_human_cower_stand@male@base', 'base', 4.0, -4.0, 45000, 1, 0, false, false, false)
        elseif dict('missminuteman_1ig_2') then TaskPlayAnim(clerk, 'missminuteman_1ig_2', 'handsup_base', 4.0, -4.0, 20000, 49, 0, false, false, false) end
        SetTimeout(46000, function() if DoesEntityExist(clerk) then ClearPedTasks(clerk) FreezeEntityPosition(clerk, true) end G.SetBusy(clerk, false) end)
        if ok and dict('mp_common') then TaskPlayAnim(robber, 'mp_common', 'givetake1_b', 8.0, -8.0, 1500, 49, 0, false, false, false) end
    end }
end

-- Banque / bijouterie (sans vendeur) : le braqueur ramasse les billets ou casse les vitrines en boucle
function G.LootScene(robber, label, secs)
    local l = tostring(label):lower()
    local d, a = 'anim@heists@ornate_bank@grab_cash', 'grab'
    if l:find('bijou', 1, true) or l:find('jewel', 1, true) then d, a = 'missheist_jewel', 'smash_case' end
    local alive = true
    local bag = prop('p_ld_heist_bag_s_1', robber, 24818, { -0.25, -0.25, 0.0 }, { 0.0, 90.0, 180.0 })
    CreateThread(function()
        if not dict(d) then TaskStartScenarioInPlace(robber, 'PROP_HUMAN_BUM_BIN', 0, true) return end
        local stop = GetGameTimer() + secs * 1000
        while alive and GetGameTimer() < stop do
            TaskPlayAnim(robber, d, a, 8.0, -8.0, -1, 0, 0, false, false, false)
            Wait(math.max(800, math.floor((GetAnimDuration(d, a) or 1.5) * 1000)))
        end
    end)
    return { stop = function() alive = false if bag and DoesEntityExist(bag) then DeleteEntity(bag) end end }
end

-- Braquage en cours : minuteur selon le niveau (le temps que la police arrive), zone à tenir, braqueur libre de ses mouvements.
-- Sortir de la zone lance un compte à rebours (« out_grace ») ; mort, menotté ou trop longtemps dehors = braquage raté.
function G.HeistRun(d)
    active = true
    local ped = PlayerPedId()
    local secs = math.max(5, tonumber(d.time) or 60)
    local zone = tonumber(d.radius) or 12.0
    local grace = tonumber(d.grace) or 15
    local at = vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)
    local clerk = (G.heistClerk and GetGameTimer() - (G.heistClerkAt or 0) < 5000) and G.heistClerk or nil
    G.heistClerk = nil
    local scene
    if clerk and DoesEntityExist(clerk) then scene = G.RobberyScene(clerk, ped, secs)
    else scene = G.LootScene(ped, d.label or '', math.min(6, secs)) end
    G.send('crime.heist', { label = d.label, secs = secs, zone = math.floor(zone), tier = d.tier })
    CreateThread(function()
        local endAt, ok, outSince = GetGameTimer() + secs * 1000, true, nil
        while GetGameTimer() < endAt or outSince do
            Wait(250)
            local p = PlayerPedId()
            if IsEntityDead(p) or IsPedCuffed(p) then ok = false break end
            if #(GetEntityCoords(p) - at) > zone then
                if not outSince then outSince = GetGameTimer() G.send('crime.heist', { out = grace }) end
                if GetGameTimer() - outSince > grace * 1000 then ok = false break end
            elseif outSince then outSince = nil G.send('crime.heist', { out = false }) end
        end
        active = false
        if scene then scene.stop(ok) end
        G.send('crime.heist', { done = true, ok = ok })
        if ok then
            if not clerk and dict('anim@heists@ornate_bank@grab_cash') then
                TaskPlayAnim(PlayerPedId(), 'anim@heists@ornate_bank@grab_cash', 'grab', 8.0, -8.0, 2500, 48, 0, false, false, false)
                Wait(2500)
            end
        else G.send('notify', { type = 'warn', title = 'Braquage', text = 'Braquage raté : tu as quitté la zone ou tu es tombé.' }) end
        TriggerServerEvent('pb:g:crime:end', ok)
    end)
end


-- Labo immersif en PREMIÈRE PERSONNE (patch 326) : on se met face à l'établi, la vue passe à la première personne et chaque geste se fait à la main :
-- clic gauche maintenu + souris pour remuer, clic gauche maintenu pour verser, clic gauche pour taper (marteau, couteau). Le serveur valide chaque étape (durée, distance).
local function cdict(dname) RequestAnimDict(dname) local t = GetGameTimer() + 1500 while not HasAnimDictLoaded(dname) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(dname) end
local function cobj(models, x, y, z, h)
    for _, m in ipairs(models) do
        local hash = joaat(m)
        if IsModelInCdimage(hash) then
            RequestModel(hash)
            local t = GetGameTimer() + 1500
            while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
            if HasModelLoaded(hash) then
                local o = CreateObject(hash, x, y, z, false, false, false)
                SetEntityCollision(o, false, false)
                if h then SetEntityHeading(o, h) end
                FreezeEntityPosition(o, true)
                SetModelAsNoLongerNeeded(hash)
                return o
            end
        end
    end
end
local PROPS = {
    pot = { 'prop_cs_pot_01', 'prop_pot_01', 'prop_cs_bowl_01' },
    plate = { 'prop_cs_plate_01', 'prop_food_tray_01', 'v_res_mplatterlrg' },
    hammer = { 'prop_tool_hammer', 'prop_tool_mallet' },
    knife = { 'prop_knife', 'prop_cs_steak_knife' },
}
local TOOL_NAME = { hammer = 'le marteau', knife = 'le couteau', pot = 'la casserole' }
local function txt2d(x, y, scale, text, r, g, b)
    SetTextFont(4) SetTextScale(0.0, scale) SetTextColour(r or 255, g or 255, b or 255, 235) SetTextCentre(true) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(text) EndTextCommandDisplayText(x, y)
end
local function bar2d(p, label)
    DrawRect(0.5, 0.905, 0.22, 0.016, 0, 0, 0, 150)
    DrawRect(0.5 - 0.11 + 0.11 * p, 0.905, 0.22 * p, 0.010, 240, 240, 240, 230)
    if label then txt2d(0.5, 0.86, 0.34, label) end
end

function G.CookRun(d)
    active = true
    local me = PlayerPedId()
    local at = vector3(d.x + 0.0, d.y + 0.0, d.z + 0.0)
    local zone = (tonumber(d.radius) or 4.5) + 3.0
    local running, lookLock = true, false
    local prevView = GetFollowPedCamViewMode()
    local pot, plate, tool, held
    local function alive()
        local p = PlayerPedId()
        return not IsEntityDead(p) and not IsPedCuffed(p) and #(GetEntityCoords(p) - at) <= zone
    end
    local function cancelled() return IsControlJustPressed(0, 73) or IsDisabledControlJustPressed(0, 73) end
    local function hint(key, text) G.send('prompt', { show = true, key = key, text = text .. '  ·  X : annuler' }) end
    local function unhint() G.send('prompt', { show = false }) end
    local function del(o) if o and DoesEntityExist(o) then DeleteEntity(o) end end
    local function cleanup(ok)
        running = false
        active = false
        unhint()
        G.send('crime.progress', { cancel = true })
        ClearPedTasks(PlayerPedId())
        del(pot) del(plate) del(tool)
        SetFollowPedCamViewMode(prevView)
        if not ok then G.send('notify', { type = 'warn', title = d.label or 'Labo', text = 'Recette interrompue.' }) TriggerServerEvent('pb:g:crime:end', false) end
    end
    -- première personne, pas de déplacement, pas de tir : seuls la souris et E / clic servent
    CreateThread(function()
        while running do
            Wait(0)
            for _, k in ipairs({ 21, 22, 23, 24, 25, 30, 31, 32, 33, 34, 35, 36, 37, 44, 45, 140, 141, 142, 143, 257, 263, 264 }) do DisableControlAction(0, k, true) end
            DisableControlAction(0, 0, true)   -- V : changer de vue
            if lookLock then DisableControlAction(0, 1, true) DisableControlAction(0, 2, true) end
            SetFollowPedCamViewMode(4)
            DisablePlayerFiring(PlayerId(), true)
        end
    end)

    -- Se placer face à l'établi, à 90 cm, et le regarder
    local bench = G.LabBenchNear and G.LabBenchNear(at)
    local center = bench and GetEntityCoords(bench) or vector3(at.x, at.y, at.z - 0.95)
    local top = center.z + 0.85
    if bench then
        local okd, mn, mx = pcall(GetModelDimensions, GetEntityModel(bench))
        if okd and mx and mx.z and mx.z > 0.4 and mx.z < 1.6 then top = center.z + mx.z end
    end
    local pc = GetEntityCoords(me)
    local dx, dy = pc.x - center.x, pc.y - center.y
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 0.15 then dx, dy, len = 0.0, -1.0, 1.0 end
    dx, dy = dx / len, dy / len
    local sx, sy = center.x + dx * 0.95, center.y + dy * 0.95
    local fx, fy = -dx, -dy                 -- regard vers l'établi
    local rx, ry = fy, -fx                   -- sa droite
    TaskGoStraightToCoord(me, sx, sy, pc.z, 1.0, 2500, GetHeadingFromVector_2d(fx, fy), 0.05)
    local t0 = GetGameTimer() + 2600
    while GetGameTimer() < t0 and #(GetEntityCoords(me).xy - vector2(sx, sy)) > 0.25 do Wait(50) end
    ClearPedTasks(me)
    SetEntityHeading(me, GetHeadingFromVector_2d(fx, fy))
    Wait(200)
    SetGameplayCamRelativeHeading(0.0)
    SetGameplayCamRelativePitch(-32.0, 1.0)

    -- Accessoires posés sur l'établi : casserole à gauche, plaque au centre, outil à droite
    local function spot(lat, fwd) return center.x + rx * lat + fx * fwd, center.y + ry * lat + fy * fwd end
    local steps = type(d.cook) == 'table' and d.cook or {}
    local needPot, needPlate, toolKind = false, false, nil
    for _, st in ipairs(steps) do
        if st.pot == true then needPot = true end
        if st.plate then needPlate = true end
        if st.t == 'hits' and st.tool and st.tool ~= 'hands' then toolKind = st.tool end
    end
    if needPot then local x, y = spot(-0.28, 0.0) pot = cobj(PROPS.pot, x, y, top, 0.0) end
    if needPlate then local x, y = spot(0.0, 0.05) plate = cobj(PROPS.plate, x, y, top + 0.01, 0.0) end
    if toolKind then local x, y = spot(0.30, 0.0) tool = cobj(PROPS[toolKind], x, y, top + 0.02, GetHeadingFromVector_2d(rx, ry)) end

    local function play(dict, anim, dur, flag)
        if cdict(dict) then TaskPlayAnim(PlayerPedId(), dict, anim, 8.0, -8.0, dur, flag or 49, 0, false, false, false) return true end
        return false
    end
    local function hold(o, bone, pos, rot)
        AttachEntityToEntity(o, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), bone), pos[1], pos[2], pos[3], rot[1], rot[2], rot[3], true, true, false, true, 1, true)
        held = o
    end
    local function putBack(o, lat, fwd, h)
        if not o or not DoesEntityExist(o) then return end
        DetachEntity(o, true, true)
        local x, y = spot(lat, fwd)
        SetEntityCoordsNoOffset(o, x, y, top + 0.02, false, false, false)
        if h then SetEntityHeading(o, h) end
        FreezeEntityPosition(o, true)
        held = nil
    end
    -- E pour saisir un objet posé sur l'établi (animation de la main), puis il est dans la main droite
    local function grab(o, name, bone, pos, rot)
        if not o or not DoesEntityExist(o) then return true end
        hint('E', 'Prends ' .. name)
        while true do
            Wait(0)
            if not alive() or cancelled() then return false end
            if IsControlJustPressed(0, 38) then break end
        end
        unhint()
        play('pickup_object', 'pickup_low', 900, 48)
        Wait(550)
        hold(o, bone, pos, rot)
        Wait(350)
        return true
    end
    -- Progression pilotée par la souris, plafonnée dans le temps pour que la recette ne se fasse pas en une seconde.
    -- mode « stir » : clic gauche maintenu + mouvements de souris (la vue est verrouillée) ; mode « pour » : clic gauche maintenu
    local function manual(mode, label, secs, animDict, anim)
        hint('CLIC', label)
        local p, last, playing = 0.0, GetGameTimer(), false
        local cap = 1.0 / math.max(2.0, secs)
        while p < 1.0 do
            Wait(0)
            if not alive() or cancelled() then lookLock = false return false end
            local now = GetGameTimer()
            local dt = (now - last) / 1000.0
            last = now
            local down = IsDisabledControlPressed(0, 24)
            lookLock = down and mode == 'stir'
            local gain = 0.0
            if down then
                if mode == 'pour' then gain = cap
                else
                    local m = math.abs(GetDisabledControlNormal(0, 1)) + math.abs(GetDisabledControlNormal(0, 2)) * 0.6
                    gain = cap * math.min(1.0, m * 8.0)   -- plus la souris bouge, plus ça avance (jusqu'au plafond de temps)
                end
            end
            p = math.min(1.0, p + gain * dt)
            if down and not playing and animDict then playing = play(animDict, anim, -1, 49) or true
            elseif (not down) and playing and animDict then ClearPedTasks(PlayerPedId()) playing = false end
            bar2d(p, label)
        end
        lookLock = false
        ClearPedTasks(PlayerPedId())
        unhint()
        return true
    end

    CreateThread(function()
        local ok, err = pcall(function()
            local DICT = 'anim@amb@business@meth@meth_monitoring_cooking@cooking@'
            for i, st in ipairs(steps) do
                if st.t == 'work' then
                    if st.pour then
                        if pot and not held then
                            if not grab(pot, TOOL_NAME.pot, 28422, { 0.12, 0.02, -0.02 }, { 0.0, 0.0, 0.0 }) then return cleanup(false) end
                        end
                        if not manual('pour', 'Maintiens le clic gauche : ' .. (st.text or 'verse'), st.secs or 4, DICT, 'chemical_pour_short_cooker') then return cleanup(false) end
                        if pot then putBack(pot, -0.28, 0.0, 0.0) end
                    else
                        if not manual('stir', 'Clic gauche maintenu + souris : ' .. (st.text or 'remue'), st.secs or 5, DICT, 'chemical_pour_long_cooker') then return cleanup(false) end
                    end
                elseif st.t == 'wait' then
                    G.send('crime.progress', { label = st.bar or 'Patiente…', secs = st.secs or 5, x = true })
                    local stop = GetGameTimer() + (st.secs or 5) * 1000
                    while GetGameTimer() < stop do
                        Wait(50)
                        if not alive() or cancelled() then return cleanup(false) end
                    end
                    G.send('crime.progress', { cancel = true })
                elseif st.t == 'hits' then
                    local n = st.n or 3
                    if toolKind and tool and not held then
                        if not grab(tool, TOOL_NAME[toolKind] or 'l\'outil', 28422, toolKind == 'hammer' and { 0.09, 0.0, -0.02 } or { 0.07, 0.0, -0.01 }, toolKind == 'hammer' and { 80.0, 0.0, 90.0 } or { 0.0, 90.0, 0.0 }) then return cleanup(false) end
                    end
                    local done, lastHit = 0, 0
                    hint('CLIC', ('%s (%d/%d)'):format(st.text or 'Frappe', 0, n))
                    while done < n do
                        Wait(0)
                        if not alive() or cancelled() then return cleanup(false) end
                        txt2d(0.5, 0.86, 0.36, ('%s  %d/%d'):format(st.text or 'Frappe', done, n))
                        if IsDisabledControlJustPressed(0, 24) and GetGameTimer() - lastHit > 1400 then
                            lastHit = GetGameTimer()
                            if toolKind == 'hammer' then
                                play('amb@world_human_hammering@male@base', 'base', 1300, 48)
                            elseif toolKind == 'knife' then
                                play('melee@knife@streamed_core', 'ground_attack_on_spot', 1300, 48)
                            else
                                play('anim@amb@business@weed@weed_inspecting_lo_med_hi@', 'weed_crouch_checkingleaves_idle_01_inspector', 1300, 48)
                            end
                            Wait(520)
                            done = done + 1
                            PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                            ShakeGameplayCam('JOLT_SHAKE', 0.07)
                            hint('CLIC', ('%s (%d/%d)'):format(st.text or 'Frappe', done, n))
                        end
                    end
                    unhint()
                    Wait(600)
                    if tool then del(tool) tool = nil held = nil end
                    del(plate) plate = nil
                end
                if st.pot == false and pot then del(pot) pot = nil end
                TriggerServerEvent('pb:g:crime:cook', i)
            end
            cleanup(true)
        end)
        if not ok then print('[labo] ' .. tostring(err)) if running then cleanup(false) end end
    end)
end


-- Vente aux passants (patch 315) : dans la zone d'un point de vente en mode « npc », on propose sa marchandise à un PNJ du jeu.
-- Le serveur tire la réponse : il accepte (échange, paiement) ou refuse (il est alors supprimé du monde).
local dealt = {}
local function inNpcZone(c)
    for _, s in ipairs(spots) do
        if s.npc then
            if s.poly then if math.abs(c.z - s.z) < 25.0 and G.InPoly(c.x, c.y, s.poly) then return s end
            elseif #(c - vector3(s.x, s.y, s.z)) <= math.max(s.r, 3.0) then return s end
        end
    end
end
local function findBuyer(me, c)
    local fwd = GetEntityForwardVector(me)
    local best, bd
    for _, p in ipairs(GetGamePool and GetGamePool('CPed') or {}) do
        if p ~= me and not dealt[p] and not IsPedAPlayer(p) and not IsPedDeadOrDying(p, true) and not IsPedInAnyVehicle(p, false) and IsPedHuman(p) then
            local pt = GetPedType(p)
            if pt ~= 6 and pt ~= 27 and pt ~= 29 then   -- ni policiers, ni armée
                local to = GetEntityCoords(p) - c
                local len = #to
                if len < 2.4 and len > 0.1 and ((fwd.x * to.x + fwd.y * to.y) / len) > 0.35 and (not bd or len < bd) then best, bd = p, len end
            end
        end
    end
    return best
end
local asked
RegisterNetEvent('pb:g:crime:npcres', function(ok, text)
    local buyer = asked
    asked = nil
    if not buyer or not DoesEntityExist(buyer) then return end
    CreateThread(function()
        local me = PlayerPedId()
        local function anim(ped, dname, a, ms)
            RequestAnimDict(dname)
            local t = GetGameTimer() + 1000
            while not HasAnimDictLoaded(dname) and GetGameTimer() < t do Wait(10) end
            if HasAnimDictLoaded(dname) then TaskPlayAnim(ped, dname, a, 8.0, -8.0, ms, 48, 0, false, false, false) end
        end
        NetworkRequestControlOfEntity(buyer)
        SetEntityAsMissionEntity(buyer, true, true)
        if ok then
            anim(me, 'mp_common', 'givetake1_a', 1800) anim(buyer, 'mp_common', 'givetake1_b', 1800)
            PlayPedAmbientSpeechNative(buyer, 'GENERIC_THANKS', 'SPEECH_PARAMS_FORCE')
            Wait(2000)
            ClearPedTasks(buyer)
            SetBlockingOfNonTemporaryEvents(buyer, false)
            TaskWanderStandard(buyer, 10.0, 10)
            Wait(3000)   -- (patch 318) servi : il s'en va et disparaît 5 s après la vente
            for a = 255, 0, -51 do if DoesEntityExist(buyer) then SetEntityAlpha(buyer, a, false) end Wait(60) end
            if DoesEntityExist(buyer) then DeleteEntity(buyer) end
        else
            PlayPedAmbientSpeechNative(buyer, 'GENERIC_INSULT_HIGH', 'SPEECH_PARAMS_FORCE_SHOUTED')
            SetBlockingOfNonTemporaryEvents(buyer, true)
            TaskSmartFleePed(buyer, me, 60.0, -1, false, false)
            Wait(1800)
            for a = 255, 0, -51 do SetEntityAlpha(buyer, a, false) Wait(80) end
            if DoesEntityExist(buyer) then DeleteEntity(buyer) end   -- il refuse : il disparaît
        end
    end)
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt2', { id = 'npcdeal', show = false }) end end
    while true do
        local sleep = 800
        local any = false
        for _, s in ipairs(spots) do if s.npc then any = true break end end
        if any and G.begun and not active and not asked and not G.Menu.IsOpen() and not G.state.dead then
            local me = PlayerPedId()
            local c = GetEntityCoords(me)
            local zone = GetVehiclePedIsIn(me, false) == 0 and inNpcZone(c)
            if zone then
                sleep = 250
                local buyer = findBuyer(me, c)
                if buyer then
                    sleep = 0
                    if shown ~= 'y' then shown = 'y' G.send('prompt2', { id = 'npcdeal', show = true, key = 'E', text = 'Proposer de la marchandise' }) end
                    if IsControlJustPressed(0, 38) then
                        hide()
                        dealt[buyer] = true
                        asked = buyer
                        TaskTurnPedToFaceEntity(buyer, me, 1500)
                        TaskTurnPedToFaceEntity(me, buyer, 800)
                        TriggerServerEvent('pb:g:crime:npcsell', zone.id)
                        SetTimeout(6000, function() if asked == buyer then asked = nil end end)
                    end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)


-- Passants de la zone de vente (patch 315/318) : on fait apparaître des PNJ dans la zone ; plus il y a de joueurs dedans, plus il y a de passants.
-- Cible = npc_base + npc_per_player × joueurs dans la zone, plafonnée à npc_max (réglable au panel). Ils apparaissent près de toi et disparaissent quand tu pars.
local crowd, crowdAt = {}, {}
local CROWD_MODELS = { 'a_m_y_hipster_01', 'a_f_y_hipster_01', 'a_m_y_stbla_01', 'a_f_y_vinewood_01', 'a_m_y_vinewood_01', 'a_m_m_skater_01', 'a_f_y_tourist_01', 'a_m_y_beach_01', 'a_f_y_fitness_01', 'a_m_m_business_01', 'a_f_m_downtown_01', 'a_m_y_runner_01' }
local function inZoneAt(s, x, y, z)
    if s.poly then return math.abs(z - s.z) < 25.0 and G.InPoly(x, y, s.poly) end
    return #(vector3(x, y, z) - vector3(s.x, s.y, s.z)) <= math.max(s.r, 3.0)
end
local function zoneBox(s)
    if not s.poly then return s.x - s.r, s.y - s.r, s.x + s.r, s.y + s.r, s.r + 20.0 end
    local x1, y1, x2, y2 = 1e9, 1e9, -1e9, -1e9
    for _, p in ipairs(s.poly) do
        local px, py = p.x or p[1], p.y or p[2]
        x1, y1, x2, y2 = math.min(x1, px), math.min(y1, py), math.max(x2, px), math.max(y2, py)
    end
    return x1, y1, x2, y2, math.max(x2 - x1, y2 - y1) / 2 + 20.0
end
local function dropCrowd(p, fade)
    crowd[p] = nil crowdAt[p] = nil
    if DoesEntityExist(p) then
        if fade then for a = 255, 0, -51 do SetEntityAlpha(p, a, false) Wait(60) end end
        DeleteEntity(p)
    end
end
local function spawnBuyer(s, me)
    local x1, y1, x2, y2 = zoneBox(s)
    for _ = 1, 12 do
        local x, y = x1 + math.random() * (x2 - x1), y1 + math.random() * (y2 - y1)
        if inZoneAt(s, x, y, s.z) then
            local ok, gz = GetGroundZFor_3dCoord(x + 0.0, y + 0.0, s.z + 50.0, false)
            if ok and #(GetEntityCoords(me) - vector3(x, y, gz)) > 12.0 then
                local mh = joaat(CROWD_MODELS[math.random(#CROWD_MODELS)])
                RequestModel(mh)
                local t = GetGameTimer() + 1500
                while not HasModelLoaded(mh) and GetGameTimer() < t do Wait(10) end
                if HasModelLoaded(mh) then
                    local p = CreatePed(4, mh, x + 0.0, y + 0.0, gz, math.random(360) + 0.0, false, false)
                    SetModelAsNoLongerNeeded(mh)
                    if p and p ~= 0 then
                        SetEntityAsMissionEntity(p, true, true)
                        SetPedRandomComponentVariation(p, 0)
                        local cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
                        local _, _, _, _, rad = zoneBox(s)
                        TaskWanderInArea(p, cx, cy, s.z + 0.0, rad - 10.0, 1.5, 4.0)
                        crowd[p] = s.id
                        crowdAt[p] = GetGameTimer()
                        return true
                    end
                end
            end
        end
    end
end
CreateThread(function()
    while true do
        Wait(1500)
        local cr = G.crimeCfg or {}
        local me = PlayerPedId()
        local c = GetEntityCoords(me)
        local near
        if G.begun and not G.state.dead then
            for _, s in ipairs(spots) do
                if s.npc then
                    local _, _, _, _, rad = zoneBox(s)
                    local cx = s.poly and (select(1, zoneBox(s)) + select(3, zoneBox(s))) / 2 or s.x
                    local cy = s.poly and (select(2, zoneBox(s)) + select(4, zoneBox(s))) / 2 or s.y
                    if #(vector2(c.x, c.y) - vector2(cx, cy)) < rad + 70.0 then near = s break end
                end
            end
        end
        -- ménage : trop loin, déjà servi depuis un moment ou disparu
        for p, zid in pairs(crowd) do
            if not near or not DoesEntityExist(p) or IsPedDeadOrDying(p, true) then CreateThread(function() dropCrowd(p, near ~= nil) end)
            elseif dealt[p] and GetGameTimer() - (crowdAt[p] or 0) > 8000 then CreateThread(function() dropCrowd(p, true) end) end
        end
        if near then
            local players = 0
            for _, pl in ipairs(GetActivePlayers()) do
                local pc = GetEntityCoords(GetPlayerPed(pl))
                if inZoneAt(near, pc.x, pc.y, pc.z) then players = players + 1 end
            end
            local want = math.min(tonumber(cr.npc_max) or 14, (tonumber(cr.npc_base) or 2) + (tonumber(cr.npc_per_player) or 2) * players)
            local have = 0
            for p in pairs(crowd) do if not dealt[p] then have = have + 1 end end
            if have < want and not IsPedInAnyVehicle(me, false) then spawnBuyer(near, me) end
        end
    end
end)
AddEventHandler('onResourceStop', function(r)
    if r == GetCurrentResourceName() then for p in pairs(crowd) do if DoesEntityExist(p) then DeleteEntity(p) end end end
end)


-- Établi du labo immersif (patch 324) : un prop posé à l'emplacement du point, propre à chaque drogue (modèles essayés dans l'ordre, le premier qui existe est gardé)
local BENCH = {
    coke = { 'bkr_prop_coke_table01a', 'bkr_prop_coke_cutblock_01', 'prop_table_03' },
    meth = { 'bkr_prop_meth_table01a', 'bkr_prop_meth_scales', 'prop_table_03' },
    weed = { 'bkr_prop_weed_table_01a', 'bkr_prop_weed_drying_01a', 'prop_table_03' },
    heroin = { 'bkr_prop_coke_table01a', 'prop_table_03' },
    ecstasy = { 'bkr_prop_coke_table01a', 'prop_table_03' },
}
local function drugOf(s)
    if s.drug and BENCH[s.drug] then return s.drug end
    local n = tostring(s.io or ''):lower()
    for k, words in pairs({ weed = { 'weed', 'joint', 'cannabis' }, coke = { 'coke', 'coca' }, heroin = { 'heroin', 'poppy' }, ecstasy = { 'ecstasy', 'mdma' } }) do
        for _, w in ipairs(words) do if n:find(w, 1, true) then return k end end
    end
    return 'meth'
end
local function makeBench(drug, x, y, z, h)
    for _, m in ipairs(BENCH[drug] or BENCH.meth) do
        local hash = joaat(m)
        if IsModelInCdimage(hash) then
            RequestModel(hash)
            local t = GetGameTimer() + 2000
            while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
            if HasModelLoaded(hash) then
                local o = CreateObject(hash, x, y, z - 0.95, false, false, false)
                if o and o ~= 0 then
                    SetEntityHeading(o, h or 0.0)
                    PlaceObjectOnGroundProperly(o)
                    FreezeEntityPosition(o, true)
                    SetModelAsNoLongerNeeded(hash)
                    return o, m
                end
            end
        end
    end
end
local benches = {}
CreateThread(function()
    while true do
        Wait(2000)
        local c = GetEntityCoords(PlayerPedId())
        local keep = {}
        for _, s in ipairs(spots) do
            if s.cook then
                keep[s.id] = true
                local d = #(c - vector3(s.x, s.y, s.z))
                local have = benches[s.id]
                if have and not DoesEntityExist(have) then benches[s.id] = nil have = nil end
                if d < 60.0 and not have then benches[s.id] = makeBench(drugOf(s), s.x, s.y, s.z, 0.0)
                elseif d > 90.0 and have then DeleteEntity(have) benches[s.id] = nil end
            end
        end
        for id, o in pairs(benches) do   -- point supprimé ou repassé en classique : l'établi disparaît
            if not keep[id] then if DoesEntityExist(o) then DeleteEntity(o) end benches[id] = nil end
        end
    end
end)
AddEventHandler('onResourceStop', function(r)
    if r == GetCurrentResourceName() then for _, o in pairs(benches) do if DoesEntityExist(o) then DeleteEntity(o) end end end
end)
-- /laboprop [drogue] (staff) : fait apparaître l'établi devant toi 15 s et dit quel modèle a été trouvé
RegisterCommand('laboprop', function(_, args)
    local k = tostring(args[1] or 'meth'):lower()
    local me = PlayerPedId()
    local p = GetOffsetFromEntityInWorldCoords(me, 0.0, 2.0, 0.0)
    local o, m = makeBench(BENCH[k] and k or 'meth', p.x, p.y, p.z, GetEntityHeading(me))
    G.send('notify', { type = o and 'success' or 'error', title = 'Établi', text = o and ('Modèle utilisé : ' .. m) or "Aucun modèle d'établi n'existe sur ce serveur." })
    if o then SetTimeout(15000, function() if DoesEntityExist(o) then DeleteEntity(o) end end) end
end, false)

-- établi le plus proche d'une position (le labo en première personne s'y place)
function G.LabBenchNear(at)
    local best, bd = nil, 4.0
    for _, o in pairs(benches) do
        if DoesEntityExist(o) then
            local d = #(GetEntityCoords(o) - at)
            if d < bd then best, bd = o, d end
        end
    end
    return best
end
