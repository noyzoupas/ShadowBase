-- (v1.2.99) Pharmacie : soin progressif jusqu'à un plafond (server/game/pharmacy.lua). Les secours (EMS) restent seuls à soigner au-delà.
local G = PBG
local healing = nil
RegisterNetEvent('pb:g:pharma:heal', function(j)
    local d = G.decode(j) or {}
    local secs = math.max(1, math.min(30, tonumber(d.secs) or 4))
    local amount = math.max(0, math.min(100, tonumber(d.amount) or 0))
    local cap = math.max(10, math.min(100, tonumber(d.cap) or 70))
    local token = {}
    healing = token
    CreateThread(function()
        local ped = PlayerPedId()
        local max = GetEntityMaxHealth(ped)
        local range = math.max(1, max - 100)          -- au jeu : 100 = à terre, max = pleine forme
        local ceil = 100 + math.floor(range * cap / 100)
        local total = range * amount / 100
        local steps = secs * 4
        local per = total / steps
        local acc = 0.0
        if GetEntityHealth(ped) >= ceil then
            G.send('notify', { type = 'info', title = tostring(d.label or 'Pharmacie'), text = ("Tu es déjà à %d %% : au-delà, il faut un soignant (EMS)."):format(cap) })
            return
        end
        for _ = 1, steps do
            Wait(250)
            if healing ~= token then return end
            ped = PlayerPedId()
            if IsEntityDead(ped) or GetEntityHealth(ped) <= 100 then return end
            acc = acc + per
            local add = math.floor(acc)
            if add >= 1 then
                acc = acc - add
                local h = GetEntityHealth(ped)
                if h >= ceil then break end
                SetEntityHealth(ped, math.min(ceil, h + add))
            end
        end
        if GetEntityHealth(PlayerPedId()) >= ceil then G.send('notify', { type = 'info', title = tostring(d.label or 'Pharmacie'), text = ("Soins légers au maximum (%d %%). Pour la suite : les secours."):format(cap) }) end
    end)
end)
