-- (v1.2.98) Menu staff : motifs prêts, comptes liés, surveillance, catégorie « Modération » et lecteur de rediffusion des morts
-- (server/game/staffmod.lua). Rien n'est décidé ici : le serveur revérifie chaque droit et chaque rang.
local G = PBG
G.StaffCat = G.StaffCat or {}
G.StaffPlayerExtra = G.StaffPlayerExtra or {}
local function ago(t, nowS)
    local d = math.max(0, (nowS or 0) - (tonumber(t) or 0))
    if d < 60 then return d .. ' s' elseif d < 3600 then return (d // 60) .. ' min' elseif d < 86400 then return (d // 3600) .. ' h' end
    return (d // 86400) .. ' j'
end

-- Fiche d'un joueur : sanction rapide, comptes liés, surveillance
table.insert(G.StaffPlayerExtra, function(pl, spec, send)
    local out = {}
    local ms = spec.motifs or {}
    if #ms > 0 then
        local sub = {}
        for _, m in ipairs(ms) do
            sub[#sub + 1] = { label = m.label, right = m.dur, danger = (m.kind == 'ban' or m.kind == 'kick') or nil, disabled = (not pl.rank) or nil,
                description = pl.rank and ('Applique : ' .. m.dur .. '. Une précision facultative est ajoutée au motif.') or 'Ce joueur a un rang égal ou supérieur au tien.',
                onSelect = function()
                    local d = G.Menu.Ask(m.label .. ' · précision (facultatif)', '', 80)
                    if d == nil then return end
                    send('motif', { id = pl.id, motif = m.i, detail = d })
                end }
        end
        out[#out + 1] = { type = 'submenu', label = 'Sanction rapide (motif prêt)', icon = 'shield', badge = tostring(#sub), description = 'Freekill, HRP, Metagaming… avec la sanction et la durée déjà choisies.', submenu = { id = 'staff.motif.' .. pl.id, title = 'Motifs', subtitle = pl.name, items = sub } }
    end
    out[#out + 1] = { label = 'Comptes liés', icon = 'users', description = 'Autres comptes qui partagent son PC, son Steam, son Discord ou son IP (anti-contournement de ban).', onSelect = function() send('p_links', { id = pl.id }) end }
    if pl.watch then
        out[#out + 1] = { label = 'Ne plus surveiller', icon = 'eye', right = 'surveillé', description = 'Motif : ' .. tostring(pl.watch), onSelect = function() send('watch', { id = pl.id }) end }
    else
        out[#out + 1] = { label = 'Surveiller ce joueur', icon = 'eye', description = 'Le staff en service sera prévenu à chacune de ses connexions.', disabled = (not pl.rank) or nil, onSelect = function()
            local r = G.Menu.Ask('Pourquoi le surveiller ?', '', 160)
            if r and r ~= '' then send('watch', { id = pl.id, reason = r }) end
        end }
    end
    return out
end)

RegisterNetEvent('pb:g:staff:links', function(j)
    local d = G.decode(j)
    if not d then return end
    local send = G.StaffSend
    local items = {}
    for _, r in ipairs(d.rows or {}) do
        local desc = 'En commun : ' .. tostring(r.kinds) .. (r.strong and '' or ' (lien faible : IP seulement)')
        if r.banned then desc = desc .. ' · BANNI : ' .. tostring(r.banned) end
        if r.watched then desc = desc .. ' · surveillé : ' .. tostring(r.watched) end
        items[#items + 1] = { label = r.name, icon = r.banned and 'banned' or 'user', danger = r.banned and true or nil, right = (r.seen or 0) > 0 and os.date('%d/%m/%y', r.seen) or '—', description = desc,
            onSelect = function() if send then send('p_card', { license = r.license }) end end }
    end
    if #items == 0 then items[1] = { label = 'Aucun compte lié', description = "Aucun autre compte n'a utilisé ses identifiants (depuis la mise à jour 1.2.98).", disabled = true } end
    G.Menu.Push({ id = 'staff.links', title = 'Comptes liés', subtitle = #(d.rows or {}) .. ' compte(s)', items = items })
end)

-- Catégorie « Modération »
G.StaffCat.mod = function(spec, send)
    local m = spec.mod or {}
    local items = {}
    local ks = {}
    for _, k in ipairs(m.kills or {}) do
        local sub = {}
        if k.rp and m.replay then sub[#sub + 1] = { label = 'Rediffusion (30 s)', icon = 'video', description = 'Revois la scène : positions, armes en main, qui a tiré. Espace pause, flèches pour avancer.', onSelect = function() send('kill_replay', { kid = k.id }) end } end
        sub[#sub + 1] = { label = 'Y aller', icon = 'pin', onSelect = function() send('kill_goto', { kid = k.id }) end }
        if k.kl then sub[#sub + 1] = { label = 'Dossier du tueur', icon = 'user', right = k.k, onSelect = function() send('p_card', { license = k.kl }) end } end
        sub[#sub + 1] = { label = 'Dossier de la victime', icon = 'user', right = k.v, onSelect = function() send('p_card', { license = k.vl }) end }
        ks[#ks + 1] = { type = 'submenu', label = k.k and (k.k .. ' → ' .. k.v) or (k.v .. ' (' .. tostring(k.w) .. ')'), icon = k.rp and 'video' or 'skull', right = ago(k.at, m.now),
            description = tostring(k.w) .. ((k.d or 0) > 0 and (' · ' .. k.d .. ' m') or '') .. (k.rp and ' · rediffusion disponible' or ''),
            submenu = { id = 'staff.mod.k.' .. k.id, title = 'Mort', subtitle = k.v, items = sub } }
    end
    if #ks == 0 then ks[1] = { label = 'Aucune mort enregistrée', disabled = true } end
    items[#items + 1] = { type = 'submenu', label = 'Morts récentes', icon = 'skull', badge = tostring(#(m.kills or {})), description = 'Les 30 dernières morts : tueur, arme, distance, rediffusion.', submenu = { id = 'staff.mod.kills', title = 'Morts récentes', items = ks } }

    local ws = {}
    for _, w in ipairs(m.watch or {}) do
        ws[#ws + 1] = { type = 'submenu', label = w.name, icon = 'eye', right = w.online and ('en ligne · ID ' .. w.online) or 'hors ligne', description = tostring(w.reason) .. ' · par ' .. tostring(w.by),
            submenu = { id = 'staff.mod.w.' .. w.license, title = w.name, items = {
                { label = 'Dossier', icon = 'user', onSelect = function() send('p_card', { license = w.license }) end },
                { label = 'Retirer de la surveillance', icon = 'x', onSelect = function() send('watch_del', { license = w.license }) end },
            } } }
    end
    if #ws == 0 then ws[1] = { label = 'Personne', description = 'Fiche d\'un joueur › Surveiller ce joueur.', disabled = true } end
    items[#items + 1] = { type = 'submenu', label = 'Liste de surveillance', icon = 'eye', badge = tostring(#(m.watch or {})), submenu = { id = 'staff.mod.watch', title = 'Surveillance', items = ws } }

    local st = {}
    for _, r in ipairs(m.stats or {}) do
        st[#st + 1] = { label = r.name .. (r.me and ' (toi)' or ''), icon = 'user', right = r.hours, disabled = true,
            description = ('Reports pris : %d · réponse : %s · sanctions : %d · note : %s'):format(r.claims or 0, tostring(r.resp), r.sanc or 0, tostring(r.rate)) }
    end
    if #st == 0 then st[1] = { label = 'Aucune activité', disabled = true } end
    items[#items + 1] = { type = 'submenu', label = 'Statistiques du staff (7 jours)', icon = 'chart', submenu = { id = 'staff.mod.stats', title = 'Statistiques', subtitle = '7 derniers jours', items = st } }
    return items
end

-- Lecteur de rediffusion ------------------------------------------------------------------------------------------------------------------------
-- Espace : pause · ← → : 2 s en arrière / en avant · ↑ ↓ : vitesse · souris : tourner · molette : zoom · ZQSD : déplacer · Tab : suivre un joueur
-- Retour arrière : quitter. Les joueurs sont dessinés (cercle, flèche, nom, arme en main) : personne d'autre ne voit rien.
local RP = nil
local COL = { killer = { 235, 64, 52 }, victim = { 70, 150, 255 }, other = { 255, 205, 70 } }
local function text3d(x, y, z, s, scale)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.0, scale or 0.32) SetTextFont(4) SetTextCentre(true) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(s) EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end
local function hud(s)
    SetTextScale(0.0, 0.34) SetTextFont(4) SetTextOutline() SetTextColour(255, 255, 255, 230)
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(s) EndTextCommandDisplayText(0.012, 0.012)
end
local function sampleAt(pts, t)
    if t <= pts[1][1] then return pts[1], nil, 0 end
    for i = 2, #pts do
        if pts[i][1] >= t then
            local a, b = pts[i - 1], pts[i]
            local f = (b[1] == a[1]) and 0 or (t - a[1]) / (b[1] - a[1])
            return a, b, f
        end
    end
    return pts[#pts], nil, 0
end
local function posAt(pts, t)
    local a, b, f = sampleAt(pts, t)
    if not b then return a[2], a[3], a[4], a end
    if t > pts[#pts][1] then return nil end
    return a[2] + (b[2] - a[2]) * f, a[3] + (b[3] - a[3]) * f, a[4] + (b[4] - a[4]) * f, (f < 0.5) and a or b
end
local function rpStop()
    if not RP then return end
    local r = RP
    RP = nil
    RenderScriptCams(false, true, 400, true, true)
    DestroyCam(r.cam, false)
    ClearFocus()
    DisplayRadar(true)
    G.Menu.Resume()
end
local function rpStart(d)
    if RP then rpStop() end
    local k = d.kill or {}
    local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    RP = { d = d, t = -300, speed = 1.0, pause = false, cam = cam, yaw = 0.0, pitch = -35.0, dist = 35.0, tx = k.x + 0.0, ty = k.y + 0.0, tz = k.z + 0.0, follow = 0, last = GetGameTimer() }
    G.Menu.Suspend()
    RenderScriptCams(true, true, 500, true, true)
    DisplayRadar(false)
    local tmin, tmax = 0, 0
    for _, a in ipairs(d.actors or {}) do if #a.p > 0 then tmin = math.min(tmin, a.p[1][1]) tmax = math.max(tmax, a.p[#a.p][1]) end end
    RP.t, RP.tmin, RP.tmax = tmin, tmin, tmax
    CreateThread(function()
        while RP do
            Wait(0)
            local r = RP
            local nowMs = GetGameTimer()
            local dt = (nowMs - r.last) / 100.0   -- en dixièmes de seconde
            r.last = nowMs
            DisableAllControlActions(0)
            for _, c in ipairs({ 1, 2, 245, 249 }) do EnableControlAction(0, c, true) end
            if IsDisabledControlJustPressed(0, 22) then r.pause = not r.pause end
            if IsDisabledControlJustPressed(0, 174) then r.t = math.max(r.tmin, r.t - 20) end
            if IsDisabledControlJustPressed(0, 175) then r.t = math.min(r.tmax, r.t + 20) end
            if IsDisabledControlJustPressed(0, 172) then r.speed = math.min(4.0, r.speed * 2) end
            if IsDisabledControlJustPressed(0, 173) then r.speed = math.max(0.25, r.speed / 2) end
            if IsDisabledControlJustPressed(0, 241) then r.dist = math.max(5.0, r.dist / 1.2) end
            if IsDisabledControlJustPressed(0, 242) then r.dist = math.min(150.0, r.dist * 1.2) end
            if IsDisabledControlJustPressed(0, 37) then r.follow = (r.follow + 1) % (#r.d.actors + 1) end
            if IsDisabledControlJustPressed(0, 177) then rpStop() break end
            if not r.pause then r.t = r.t + dt * r.speed if r.t > r.tmax then r.t = r.tmax r.pause = true end end
            r.yaw = r.yaw - GetDisabledControlNormal(0, 1) * 6.0
            r.pitch = math.max(-89.0, math.min(-5.0, r.pitch - GetDisabledControlNormal(0, 2) * 6.0))
            local ry = math.rad(r.yaw)
            local fx, fy = -math.sin(ry), math.cos(ry)
            local step = r.dist / 60.0
            if IsDisabledControlPressed(0, 32) then r.tx, r.ty = r.tx + fx * step, r.ty + fy * step end
            if IsDisabledControlPressed(0, 33) then r.tx, r.ty = r.tx - fx * step, r.ty - fy * step end
            if IsDisabledControlPressed(0, 34) then r.tx, r.ty = r.tx - fy * step, r.ty + fx * step end
            if IsDisabledControlPressed(0, 35) then r.tx, r.ty = r.tx + fy * step, r.ty - fx * step end
            local killerPos, victimPos
            for i, a in ipairs(r.d.actors or {}) do
                local x, y, z, s = posAt(a.p, r.t)
                if x then
                    local c = COL[a.role or 'other'] or COL.other
                    if s[8] then c = { 140, 140, 140 } end
                    DrawMarker(25, x, y, z - 0.95, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.1, 1.1, 1.0, c[1], c[2], c[3], 190, false, false, 2, false, nil, nil, false)
                    DrawMarker(0, x, y, z + 1.25, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 0.45, 0.45, 0.45, c[1], c[2], c[3], 220, true, false, 2, false, nil, nil, false)
                    local h = math.rad(s[5] or 0)
                    DrawLine(x, y, z, x - math.sin(h) * 1.6, y + math.cos(h) * 1.6, z, c[1], c[2], c[3], 255)
                    -- traînée des 5 dernières secondes
                    local px, py, pz
                    for _, q in ipairs(a.p) do
                        if q[1] <= r.t and q[1] >= r.t - 50 then
                            if px then DrawLine(px, py, pz - 0.9, q[2], q[3], q[4] - 0.9, c[1], c[2], c[3], 140) end
                            px, py, pz = q[2], q[3], q[4]
                        end
                    end
                    local tag = ('%s [%s]%s%s%s'):format(a.n, tostring(a.u), a.role == 'killer' and ' · TUEUR' or (a.role == 'victim' and ' · VICTIME' or ''), s[6] and (' · ' .. s[6]) or '', s[7] and ' · en véhicule' or '')
                    text3d(x, y, z + 1.65, tag, 0.3)
                    if a.role == 'killer' then killerPos = vector3(x, y, z) elseif a.role == 'victim' then victimPos = vector3(x, y, z) end
                    if r.follow == i then r.tx, r.ty, r.tz = x, y, z end
                end
            end
            if r.t >= 0 and r.t <= 30 and killerPos and victimPos then DrawLine(killerPos.x, killerPos.y, killerPos.z + 0.4, victimPos.x, victimPos.y, victimPos.z + 0.4, 255, 40, 40, 255) end
            local k = r.d.kill or {}
            if r.t >= -5 then DrawMarker(28, k.x, k.y, k.z - 0.9, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.6, 0.6, 0.6, 255, 40, 40, r.t >= 0 and 120 or 40, false, false, 2, false, nil, nil, false) end
            local rp = math.rad(r.pitch)
            local cx = r.tx + math.sin(ry) * math.cos(rp) * r.dist
            local cy = r.ty - math.cos(ry) * math.cos(rp) * r.dist
            local cz = r.tz - math.sin(rp) * r.dist
            SetCamCoord(r.cam, cx, cy, cz)
            PointCamAtCoord(r.cam, r.tx, r.ty, r.tz)
            SetFocusPosAndVel(r.tx, r.ty, r.tz, 0.0, 0.0, 0.0)
            local followName = r.follow > 0 and r.d.actors[r.follow] and r.d.actors[r.follow].n or 'libre'
            hud(('Rediffusion · %s → %s (%s, %d m) · %s%.1f s · x%s%s\nEspace pause · ←/→ 2 s · ↑/↓ vitesse · souris tourner · molette zoom · ZQSD déplacer · Tab suivre (%s) · Retour arrière quitter'):format(
                tostring(k.killer ~= '' and k.killer or '?'), tostring(k.victim), tostring(k.weapon), tonumber(k.dist) or 0, r.t >= 0 and '+' or '', r.t / 10, tostring(r.speed), r.pause and ' · PAUSE' or '', followName))
        end
    end)
end
RegisterNetEvent('pb:g:staff:replay', function(j)
    local d = G.decode(j)
    if not d or type(d.actors) ~= 'table' or #d.actors == 0 then return end
    rpStart(d)
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then rpStop() end end)
