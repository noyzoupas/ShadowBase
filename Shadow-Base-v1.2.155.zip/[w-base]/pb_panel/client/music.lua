-- Musique : boombox en main, CarPlay des véhicules et volume selon la distance. Le serveur tient la liste des musiques (server/game/music.lua) ;
-- ici on place l'objet dans la main, on ouvre l'écran (web/game/music.js) et on dit à la page quoi jouer et à quel volume.
local G = PBG
local sources, stations, boxRange, carRange, volume = {}, {}, 30, 16, 70
local kv = GetResourceKvpInt('pb_music_vol')
local myVol = kv > 0 and (kv - 1) or 100   -- réglage personnel (0..100), mémorisé +1 (0 = jamais réglé)
local ui = nil      -- { mode = 'car' | 'box', veh }
local held = false
local prop = nil
local PROP, ANIM_DICT, ANIM = 'prop_boombox_01', 'move_weapon@jerrycan@generic', 'idle'
local placed = nil   -- boombox posée au sol : { obj, x, y, z }
local boxPos = { 0.15, 0.0, 0.0, 90.0, 342.5, 0.0 }   -- position dans la main (x, y, z, rotations), réglable en jeu : /boombox_regler
local function placeBox()
    if not prop or not DoesEntityExist(prop) then return end
    local ped = PlayerPedId()
    AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 57005), boxPos[1] + 0.0, boxPos[2] + 0.0, boxPos[3] + 0.0, boxPos[4] + 0.0, boxPos[5] + 0.0, boxPos[6] + 0.0, true, true, false, true, 1, true)
end

local function me() return GetPlayerServerId(PlayerId()) end
local function myKey()
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh ~= 0 then return 'car:' .. NetworkGetNetworkIdFromEntity(veh) end
    if held or placed then return 'box:' .. me() end
end
local function current()
    local k = myKey()
    local s = k and sources[k]
    return s and { kind = s.kind, id = s.id, title = s.title, by = s.by } or nil
end

local function closeUi()
    if not ui then return end
    ui = nil
    SetNuiFocusKeepInput(false)
    G.focus(false)
    G.send('music.close', {})
end
G.onForceClose(closeUi)

local function openUi()
    if ui or not G.begun or G.dead or G.creating or G.wardrobe then return end
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 and not held and not placed then
        G.send('notify', { type = 'info', title = 'Musique', text = 'Monte dans un véhicule ou équipe ta boombox.' })
        return
    end
    ui = { mode = veh ~= 0 and 'car' or 'box', veh = veh }
    local label = 'Boombox'
    if veh ~= 0 then
        local n = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(veh)))
        label = (n and n ~= 'NULL') and n or 'CarPlay'
    end
    G.focus(true)
    SetNuiFocusKeepInput(true)   -- on continue à conduire ou marcher, écran ouvert
    G.send('music.open', { mode = ui.mode, label = label, stations = stations, vol = myVol, cur = current(), placed = placed ~= nil })
    CreateThread(function()
        while ui do
            for _, c in ipairs({ 1, 2, 24, 25, 68, 69, 70, 91, 92, 106, 140, 141, 142, 257, 263, 264, 199, 200, 245 }) do DisableControlAction(0, c, true) end
            local veh2 = GetVehiclePedIsIn(PlayerPedId(), false)
            if (ui.mode == 'car' and veh2 ~= ui.veh) or (ui.mode == 'box' and not held and not placed) then closeUi() end
            Wait(0)
        end
    end)
end
RegisterCommand('pb_music', function() if ui then closeUi() else openUi() end end, false)
RegisterKeyMapping('pb_music', 'Musique : CarPlay et boombox', 'keyboard', 'O')

G.nui['music.close'] = function() closeUi() return {} end
G.nui['music.typing'] = function(d) if ui then SetNuiFocusKeepInput(not (d and d.on)) end return {} end
G.nui['music.play'] = function(d)
    d = d or {}
    TriggerServerEvent('pb:g:music:play', tonumber(d.station), d.url and tostring(d.url):sub(1, 300) or nil)
    return {}
end
G.nui['music.stop'] = function() TriggerServerEvent('pb:g:music:stop') return {} end
G.nui['music.holster'] = function() TriggerServerEvent('pb:g:music:holster') return {} end
G.nui['music.place'] = function() closeUi() CreateThread(function() G.BoxPlace() end) return {} end
G.nui['music.pickup'] = function() closeUi() CreateThread(function() G.BoxPickup() end) return {} end
G.nui['music.vol'] = function(d)
    myVol = math.max(0, math.min(100, math.floor(tonumber(d and d.v) or myVol)))
    SetResourceKvpInt('pb_music_vol', myVol + 1)
    return {}
end

RegisterNetEvent('pb:g:music:list', function(j)
    local d = G.decode(j)
    if not d then return end
    boxRange, carRange, volume = tonumber(d.box_range) or 30, tonumber(d.car_range) or 16, tonumber(d.volume) or 70
    stations = d.stations or {}
    if type(d.box_pos) == 'table' and #d.box_pos == 6 and json.encode(d.box_pos) ~= json.encode(boxPos) then boxPos = d.box_pos placeBox() end
    local by = {}
    for _, s in ipairs(d.sources or {}) do by[s.k] = s end
    sources = by
    if ui then G.send('music.state', { cur = current() }) end
end)

-- Boombox en main ----------------------------------------------------------------------------------------------------------------------
local function dropProp()
    if prop and DoesEntityExist(prop) then DetachEntity(prop, true, false) DeleteEntity(prop) end
    prop = nil
end
local function loadOr(check, req, ms)
    req()
    local t = GetGameTimer() + ms
    while not check() and GetGameTimer() < t do Wait(10) end
    return check()
end
RegisterNetEvent('pb:g:music:box', function(on)
    held = on == true
    local ped = PlayerPedId()
    if not held then
        dropProp()
        if placed then if DoesEntityExist(placed.obj) then DeleteEntity(placed.obj) end placed = nil end
        StopAnimTask(ped, ANIM_DICT, ANIM, 2.0)
        return
    end
    SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
    local model = joaat(PROP)
    if loadOr(function() return HasModelLoaded(model) end, function() RequestModel(model) end, 3000) then
        local c = GetEntityCoords(ped)
        dropProp()
        prop = CreateObject(model, c.x, c.y, c.z + 0.2, true, true, false)
        placeBox()
        SetModelAsNoLongerNeeded(model)
    end
    loadOr(function() return HasAnimDictLoaded(ANIM_DICT) end, function() RequestAnimDict(ANIM_DICT) end, 3000)
    if G.invClose then G.invClose() end   -- équipée depuis le sac : l'inventaire ne reste pas derrière l'écran
    openUi()
    CreateThread(function()
        while held do
            local p = PlayerPedId()
            if HasAnimDictLoaded(ANIM_DICT) and not IsEntityPlayingAnim(p, ANIM_DICT, ANIM, 3) then TaskPlayAnim(p, ANIM_DICT, ANIM, 4.0, -4.0, -1, 49, 0.0, false, false, false) end
            for _ = 1, 25 do   -- une boombox à la main : pas d'arme ni de coup
                if not held then break end
                DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 37, true) DisableControlAction(0, 140, true)
                Wait(0)
            end
        end
    end)
end)

-- (v1.2.59) Poser la boombox au sol : même pose que les props (flèches, molette), puis E près d'elle pour l'écran
function G.BoxPlace()
    if not held or placed then return end
    dropProp()
    local ped = PlayerPedId()
    StopAnimTask(ped, ANIM_DICT, ANIM, 2.0)
    held = false
    G.PropPlace(PROP, 'Boombox', function(pos, heading)
        local model = joaat(PROP)
        if not pos or not loadOr(function() return HasModelLoaded(model) end, function() RequestModel(model) end, 3000) then
            TriggerServerEvent('pb:g:music:holster')
            return
        end
        local obj = CreateObjectNoOffset(model, pos.x, pos.y, pos.z, true, true, false)
        SetEntityHeading(obj, heading)
        FreezeEntityPosition(obj, true)
        SetModelAsNoLongerNeeded(model)
        placed = { obj = obj, x = pos.x, y = pos.y, z = pos.z }
        TriggerServerEvent('pb:g:music:place', pos.x, pos.y, pos.z, NetworkGetNetworkIdFromEntity(obj))
        G.send('notify', { type = 'success', title = 'Musique', text = 'Boombox posée. Approche-toi et appuie sur E pour le son ou pour la reprendre.' })
    end)
end
function G.BoxPickup()
    if not placed then return end
    if DoesEntityExist(placed.obj) then DeleteEntity(placed.obj) end
    placed = nil
    TriggerServerEvent('pb:g:music:pickup')
    TriggerEvent('pb:g:music:box', true)
end
CreateThread(function()
    local shown = false
    while true do
        local sleep = 700
        if placed then
            local d = #(GetEntityCoords(PlayerPedId()) - vector3(placed.x, placed.y, placed.z))
            if d < 2.2 and not ui then
                sleep = 0
                if not shown then shown = true G.send('prompt', { show = true, key = 'E', text = 'Boombox : son et réglages' }) end
                if IsControlJustPressed(0, 38) then shown = false G.send('prompt', { show = false }) openUi() end
            elseif shown then shown = false G.send('prompt', { show = false }) end
        elseif shown then shown = false G.send('prompt', { show = false }) end
        Wait(sleep)
    end
end)

-- Réglage en direct de la position dans la main (droit « Gérer la musique », boombox en main). Validé par le serveur, appliqué à tout le monde.
local adjusting = false
-- Rotation autour d'un axe de la boombox elle-même. Modifier directement un des trois angles ne suffit pas : quand elle est droite,
-- deux angles sur trois font tourner autour du même axe (blocage de cardan). Ordre du jeu : R = Rx * Ry * Rz.
-- rotmath:debut
local function turnBox(ax, ay, az, axis, deg)
    local rad = math.rad
    local cx, sx, cy, sy, cz, sz = math.cos(rad(ax)), math.sin(rad(ax)), math.cos(rad(ay)), math.sin(rad(ay)), math.cos(rad(az)), math.sin(rad(az))
    local m = {
        { cy * cz, -cy * sz, sy },
        { sx * sy * cz + cx * sz, -sx * sy * sz + cx * cz, -sx * cy },
        { -cx * sy * cz + sx * sz, cx * sy * sz + sx * cz, cx * cy },
    }
    local c, n = math.cos(rad(deg)), math.sin(rad(deg))
    local t = axis == 1 and { { 1, 0, 0 }, { 0, c, -n }, { 0, n, c } } or axis == 2 and { { c, 0, n }, { 0, 1, 0 }, { -n, 0, c } } or { { c, -n, 0 }, { n, c, 0 }, { 0, 0, 1 } }
    local r = {}
    for i = 1, 3 do
        r[i] = {}
        for j = 1, 3 do r[i][j] = m[i][1] * t[1][j] + m[i][2] * t[2][j] + m[i][3] * t[3][j] end
    end
    local y = math.asin(math.max(-1.0, math.min(1.0, r[1][3])))
    local x, z
    if math.abs(math.cos(y)) > 0.0001 then
        x, z = math.atan(-r[2][3], r[3][3]), math.atan(-r[1][2], r[1][1])
    else
        x, z = math.atan(r[3][2], r[2][2]), 0.0
    end
    local function deg360(v) return math.floor(math.deg(v) % 360 * 100 + 0.5) / 100 end
    return deg360(x), deg360(y), deg360(z)
end
-- rotmath:fin
RegisterCommand('boombox_regler', function() TriggerServerEvent('pb:g:music:adjust') end, false)
-- (v1.2.59) panneau à boutons (web/game/music.js) à la place des touches : déplacer, tourner, retourner d'un quart de tour, enregistrer
local adjustSaved
G.nui['boxadj.step'] = function(d)
    if not adjusting then return {} end
    local i = math.floor(tonumber(d.i) or 0)
    local v = tonumber(d.v) or 0
    if d.kind == 'move' and i >= 1 and i <= 3 then boxPos[i] = math.floor(math.max(-0.6, math.min(0.6, boxPos[i] + v)) * 100 + 0.5) / 100
    elseif d.kind == 'turn' and i >= 1 and i <= 3 then boxPos[4], boxPos[5], boxPos[6] = turnBox(boxPos[4], boxPos[5], boxPos[6], i, v) end
    placeBox()
    return {}
end
G.nui['boxadj.done'] = function(d)
    if not adjusting then return {} end
    adjusting = false
    G.focus(false)
    SetNuiFocusKeepInput(false)
    if d.save then TriggerServerEvent('pb:g:music:savepos', boxPos) else boxPos = adjustSaved placeBox() end
    return {}
end
RegisterNetEvent('pb:g:music:adjust', function()
    if adjusting or not held or not prop then return end
    adjusting = true
    closeUi()
    adjustSaved = { table.unpack(boxPos) }
    G.focus(true)
    SetNuiFocusKeepInput(true)
    G.send('boxadj.open', {})
end)

-- Son : qui joue autour de moi, à quel volume ---------------------------------------------------------------------------------------------
local lastSent = ''
CreateThread(function()
    while true do
        Wait(300)
        local list = {}
        if G.begun then
            local ped = PlayerPedId()
            local here = GetEntityCoords(ped)
            local myVeh = GetVehiclePedIsIn(ped, false)
            local near = {}
            for k, s in pairs(sources) do
                local ent, factor = 0, 0.0
                if s.t == 'car' then
                    if NetworkDoesEntityExistWithNetworkId(s.net) then ent = NetToVeh(s.net) end
                    if ent ~= 0 and ent == myVeh then
                        factor = 1.0
                        if GetPlayerRadioStationName() then SetVehRadioStation(ent, 'OFF') end   -- la radio du jeu ne joue pas par-dessus
                    elseif ent ~= 0 and carRange > 0 then
                        factor = math.max(0.0, 1.0 - #(here - GetEntityCoords(ent)) / carRange) * 0.55
                    end
                elseif s.pos and s.stage then   -- (v1.2.99) scène de concert : fort dans toute la foule, puis le son baisse sur le dernier tiers
                    local r = tonumber(s.range) or 60
                    local d = #(here - vector3(s.pos.x + 0.0, s.pos.y + 0.0, s.pos.z + 0.0))
                    factor = d <= r * 0.65 and 1.0 or math.max(0.0, 1.0 - (d - r * 0.65) / (r * 0.35))
                elseif s.pos then   -- boombox posée au sol : le son part de là, pour tout le monde
                    factor = math.max(0.0, 1.0 - #(here - vector3(s.pos.x + 0.0, s.pos.y + 0.0, s.pos.z + 0.0)) / boxRange)
                elseif s.o == me() then
                    factor = 0.9
                else
                    local pl = GetPlayerFromServerId(s.o)
                    if pl and pl ~= -1 then
                        ent = GetPlayerPed(pl)
                        if ent and ent ~= 0 then factor = math.max(0.0, 1.0 - #(here - GetEntityCoords(ent)) / boxRange) end
                    end
                end
                if factor > 0.0 then
                    if myVeh ~= 0 and ent ~= myVeh then factor = factor * 0.5 end   -- vitres fermées : on entend moins le dehors
                    near[#near + 1] = { s = s, k = k, f = factor }
                end
            end
            table.sort(near, function(a, b) return a.f > b.f end)
            for i = 1, math.min(3, #near) do   -- trois musiques à la fois au plus
                local n, s = near[i], near[i].s
                local v = math.floor(volume * (myVol / 100) * n.f / 2 + 0.5) * 2
                list[#list + 1] = { k = n.k, kind = s.kind, id = s.id, url = s.url, at = s.at, start = math.max(0, GetCloudTimeAsInt() - (tonumber(s.at) or 0)) * (s.kind == 'stream' and 0 or 1), vol = v }
            end
        end
        local sig = {}
        for _, e in ipairs(list) do sig[#sig + 1] = e.k .. ':' .. tostring(e.at) .. ':' .. e.vol end
        table.sort(sig)
        local joined = table.concat(sig, '|')
        if joined ~= lastSent then
            lastSent = joined
            G.send('music.sync', { list = list })
        end
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r == GetCurrentResourceName() then
        dropProp()
        if placed and DoesEntityExist(placed.obj) then DeleteEntity(placed.obj) end
    end
end)

-- (v1.2.99) Scènes de concert : console du DJ (E à côté) et lumières quand la sono joue
local stages = {}
RegisterNetEvent('pb:g:music:stages', function(j) stages = G.decode(j) or {} end)
RegisterNetEvent('pb:g:music:stagemenu', function(j)
    local d = G.decode(j)
    if not d then return end
    if not d.can then G.send('notify', { type = 'info', title = d.label, text = d.playing and ('En ce moment : ' .. d.playing .. (d.by and (' (par ' .. d.by .. ')') or '')) or 'La sono est coupée.' }) return end
    local items = { { type = 'separator', label = d.playing and ('En cours : ' .. d.playing) or 'Sono coupée' } }
    items[#items + 1] = { label = 'Lien YouTube', icon = 'video', description = 'Colle le lien d\'une vidéo ou d\'une musique.', onSelect = function()
        local v = G.Menu.Ask('Lien YouTube', '', 200)
        if v and v ~= '' then TriggerServerEvent('pb:g:music:stage', d.id, 'link', v) G.Menu.Close() end
    end }
    local sub = {}
    for i, st in ipairs(d.stations or {}) do sub[#sub + 1] = { label = st.n, icon = 'music', onSelect = function() TriggerServerEvent('pb:g:music:stage', d.id, 'station', i) G.Menu.Close() end } end
    if #sub > 0 then items[#items + 1] = { type = 'submenu', label = 'Radios', icon = 'music', badge = tostring(#sub), submenu = { id = 'stage.radios.' .. d.id, title = 'Radios', items = sub } } end
    if d.playing then items[#items + 1] = { label = 'Couper la sono', icon = 'x', danger = true, onSelect = function() TriggerServerEvent('pb:g:music:stage', d.id, 'stop') G.Menu.Close() end } end
    G.Menu.Open({ id = 'stage.' .. d.id, title = d.label, subtitle = 'Console du DJ', items = items })
end)
CreateThread(function()
    local hue = 0.0
    while true do
        local wait = 800
        if G.begun and #stages > 0 then
            local here = GetEntityCoords(PlayerPedId())
            for _, st in ipairs(stages) do
                local p = vector3(st.x + 0.0, st.y + 0.0, st.z + 0.0)
                local d = #(here - p)
                if d < 3.0 then
                    wait = 0
                    BeginTextCommandDisplayHelp('STRING') AddTextComponentSubstringPlayerName('~INPUT_CONTEXT~ Console du DJ · ' .. tostring(st.label)) EndTextCommandDisplayHelp(0, false, false, -1)
                    if IsControlJustPressed(0, 38) and not (G.Menu and G.Menu.IsOpen()) then TriggerServerEvent('pb:g:music:stagemenu', st.id) end
                end
                if st.on and st.lights and d < (tonumber(st.range) or 60) + 40 then
                    wait = 0
                    hue = (hue + 0.6) % 360
                    for i = 0, 2 do
                        local a = math.rad(hue + i * 120)
                        local r, g, b = math.floor(127 + 127 * math.sin(a)), math.floor(127 + 127 * math.sin(a + 2.1)), math.floor(127 + 127 * math.sin(a + 4.2))
                        DrawLightWithRange(p.x + math.cos(a) * 6.0, p.y + math.sin(a) * 6.0, p.z + 4.0, r, g, b, 18.0, 6.0)
                    end
                end
            end
        end
        Wait(wait)
    end
end)
