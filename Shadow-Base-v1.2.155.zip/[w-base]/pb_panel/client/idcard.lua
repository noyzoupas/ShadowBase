-- (v1.2.99) Carte d'identité à l'écran (server/game/idcard.lua) : dessinée par le jeu, photo du personnage prise par ce client.
local G = PBG
local card, untilT, shot = nil, 0, nil
local function txt(s, x, y, scale, r, g, b, font, right)
    SetTextFont(font or 4) SetTextScale(0.0, scale) SetTextColour(r or 20, g or 24, b or 32, 255)
    if right then SetTextRightJustify(true) SetTextWrap(0.0, x) end
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(tostring(s)) EndTextCommandDisplayText(x, y)
end
local function release() if shot then UnregisterPedheadshot(shot) shot = nil end end
RegisterNetEvent('pb:g:idcard', function(j)
    local d = G.decode(j)
    if not d then return end
    release()
    card, untilT = d, GetGameTimer() + 9000
    local p = GetPlayerFromServerId(tonumber(d.from) or -1)
    local ped = (p and p ~= -1) and GetPlayerPed(p) or 0
    if ped ~= 0 and DoesEntityExist(ped) then
        shot = RegisterPedheadshot(ped)
        local t = GetGameTimer() + 3000
        while shot and not IsPedheadshotReady(shot) and GetGameTimer() < t do Wait(50) end
    end
    if card ~= d then return end
    CreateThread(function()
        while card == d and GetGameTimer() < untilT do
            Wait(0)
            if IsControlJustPressed(0, 177) then break end   -- Retour arrière : ranger la carte
            local x, y, w, h = 0.835, 0.73, 0.28, 0.2
            DrawRect(x, y, w + 0.006, h + 0.01, 15, 18, 26, 200)
            DrawRect(x, y, w, h, 232, 236, 242, 250)
            DrawRect(x, y - h / 2 + 0.017, w, 0.034, 40, 74, 140, 255)
            txt(("CARTE NATIONALE D'IDENTITÉ · %s"):format(tostring(d.city or ''):upper()), x - w / 2 + 0.008, y - h / 2 + 0.004, 0.32, 255, 255, 255, 4)
            local px, py, pw, ph = x - w / 2 + 0.05, y + 0.012, 0.075, 0.12
            DrawRect(px, py, pw + 0.004, ph + 0.006, 120, 130, 145, 255)
            if shot and IsPedheadshotReady(shot) then
                local tx = GetPedheadshotTxdString(shot)
                DrawSprite(tx, tx, px, py, pw, ph, 0.0, 255, 255, 255, 255)
            else DrawRect(px, py, pw, ph, 190, 196, 205, 255) end
            local lx = x - w / 2 + 0.1
            local function line(label, value, yy) txt(label, lx, yy, 0.24, 90, 100, 118, 4) txt(value, lx, yy + 0.014, 0.36, 18, 22, 30, 4) end
            line('NOM', tostring(d.last or ''):upper(), y - 0.062)
            line('PRÉNOM', tostring(d.first or ''), y - 0.027)
            line('NÉ(E) LE', tostring(d.dob or '?'), y + 0.008)
            line('SEXE · TAILLE', tostring(d.sex or '?') .. (d.height and (' · ' .. d.height .. ' cm') or ''), y + 0.043)
            txt('NATIONALITÉ', x + 0.045, y - 0.027, 0.24, 90, 100, 118, 4) txt(tostring(d.nat or ''), x + 0.045, y - 0.013, 0.34, 18, 22, 30, 4)
            txt('N°', x + 0.045, y + 0.008, 0.24, 90, 100, 118, 4) txt(tostring(d.num or ''), x + 0.045, y + 0.022, 0.34, 18, 22, 30, 4)
            if d.issued then txt('DÉLIVRÉE LE', x + 0.045, y + 0.043, 0.24, 90, 100, 118, 4) txt(d.issued, x + 0.045, y + 0.057, 0.34, 18, 22, 30, 4) end
        end
        if card == d then card = nil release() end
    end)
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then release() end end)
