-- (v1.2.78) Diffusion vidéo du fondateur : plein écran pour tout le monde, l'écran est bloqué, seul le volume se règle.
local G = PBG
local on = false
local function stop()
    if not on then return end
    on = false
    G.send('video.close', {})
    G.focus(false)
end
RegisterNetEvent('pb:g:video', function(j)
    local d = G.decode(j) or {}
    if d.ev == 'play' and d.id then
        if G.Menu.IsOpen() then G.Menu.Close() end
        if not on then on = true G.focus(true) end
        G.send('video.open', { id = d.id, at = tonumber(d.at) or 0, by = d.by, stop = d.stop == true, vol = GetResourceKvpInt('pb_video_vol') })
    elseif d.ev == 'stop' then stop() end
end)
G.nui['video.stop'] = function() TriggerServerEvent('pb:g:video:stop') return {} end
G.nui['video.vol'] = function(d) local v = math.floor(tonumber(d.v) or 50) SetResourceKvpInt('pb_video_vol', math.max(1, math.min(101, v + 1))) return {} end
G.nui['video.ended'] = function(d)
    if d.err then G.send('notify', { type = 'error', title = 'Diffusion', text = "Cette vidéo ne peut pas être lue ici (intégration bloquée par YouTube)." })
    else TriggerServerEvent('pb:g:video:ended', tostring(d.id or ''), tonumber(d.dur) or 0) end
    stop()
    return {}
end
-- écran bloqué : pas de jeu tant que la vidéo tourne (le menu pause reste coupé)
CreateThread(function()
    while true do
        if on then
            Wait(0)
            DisableAllControlActions(0) DisableAllControlActions(1) DisableAllControlActions(2)
            if IsPauseMenuActive() then SetFrontendActive(false) end
        else Wait(500) end
    end
end)
G.onForceClose(function() if on then SetTimeout(200, function() if on then G.focus(true) end end) end end)   -- la remise à zéro ne coupe pas la diffusion
