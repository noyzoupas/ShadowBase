-- Shadow Base — Auto-école (serveur).
-- Le moniteur (PNJ posé au Builder) propose l'examen du code (questions tirées au sort, réponses justes gardées ici) puis l'examen de conduite :
-- véhicule prêté, parcours de points posés au Builder, limite de vitesse contrôlée PAR LE SERVEUR, fautes comptées, échec si le candidat
-- sort du véhicule ou ne suit pas le parcours. Les permis réussis sont enregistrés (table wb_autoecole_licences) et lisibles par les autres
-- ressources : exports.wb_autoecole:HasLicence(src, 'car' | 'bike' | 'truck' | 'code').

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'
local T_LIC, T_LOG, T_PTS = RES .. '_licences', RES .. '_log', RES .. '_points'

local cache = {}
local function cfg(k, d)
    local v = cache[k]
    if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end
    if v == nil then return d end
    return v
end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, AE.label, text) end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end
local function d2(c, s) return #(vector2(c.x, c.y) - vector2(s.x + 0.0, s.y + 0.0)) end
local function d3(c, s) return #(vector3(c.x, c.y, c.z) - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) end
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function feeOf(kind) if kind == 'code' then return ecoPrice(num('fee_code', AE.code_fee)) end return ecoPrice(num('fee_' .. kind, AE_KIND_BY[kind].fee)) end
local function labelOf(kind) if kind == 'code' then return 'Code de la route' end return AE_KIND_BY[kind].label end

-- Permis --------------------------------------------------------------------------------------------------------------------------------------------------------------
local owned = {}      -- license -> { [kind] = true }
local function loadOwned(lic)
    local o = {}
    for _, r in ipairs(MySQL.query.await('SELECT kind, at FROM ' .. T_LIC .. ' WHERE license = ?', { lic }) or {}) do o[r.kind] = tonumber(r.at) or 1 end
    owned[lic] = o
    return o
end
local function has(src, kind)
    local lic = W:GetLicense(src)
    if not lic then return false end
    local o = owned[lic] or loadOwned(lic)
    return o[kind] ~= nil
end
exports('HasLicence', function(src, kind) return has(tonumber(src), tostring(kind or 'car')) end)
-- Points : exports.wb_autoecole:GetPoints(src) -> points, maximum, permis { [type] = date }
exports('GetPoints', function(src)
    local lic = W:GetLicense(tonumber(src))
    if not lic then return nil end
    return getPts(lic), maxPts(), owned[lic] or loadOwned(lic)
end)
local function pushMine(src)
    local lic = W:GetLicense(src)
    if not lic then return end
    TriggerClientEvent(RES .. ':mine', src, json.encode(owned[lic] or loadOwned(lic)))
end
-- (Shadow Base 1.2.90) Points du permis : 12 au départ (réglable). La police en retire ; à 0, tous les permis (code compris) sont
-- annulés et il faut repasser l'auto-école. Un permis de conduite obtenu à nouveau redonne tous les points.
local DRIVE = { car = true, bike = true, truck = true }
local function maxPts() return math.max(1, math.min(48, math.floor(num('points_max', 12)))) end
local function getPts(lic)
    local v = MySQL.scalar.await('SELECT points FROM ' .. T_PTS .. ' WHERE license = ?', { lic })
    if v == nil then return maxPts() end
    return math.max(0, tonumber(v) or 0)
end
local function setPts(lic, n) MySQL.query.await('REPLACE INTO ' .. T_PTS .. ' (license, points, at) VALUES (?, ?, ?)', { lic, math.max(0, math.floor(n)), os.time() }) end
local function grant(src, kind, score, faults)
    local lic = W:GetLicense(src)
    if not lic then return false end
    MySQL.insert.await('REPLACE INTO ' .. T_LIC .. ' (license, kind, score, faults, at) VALUES (?, ?, ?, ?, ?)', { lic, kind, score or 0, faults or 0, os.time() })
    if DRIVE[kind] and getPts(lic) <= 0 then setPts(lic, maxPts()) end
    local o = owned[lic] or loadOwned(lic)
    o[kind] = os.time()
    pushMine(src)
    return true
end
local function revoke(lic, kind)
    MySQL.query.await('DELETE FROM ' .. T_LIC .. ' WHERE license = ? AND kind = ?', { lic, kind })
    owned[lic] = nil
end
-- exports.wb_autoecole:RemovePoints(src, n, motif, par) -> ok, message (côté agent)
local function removePoints(src, n, why, by)
    local lic = W:GetLicense(src)
    if not lic then return false, 'Personne introuvable.' end
    n = math.floor(tonumber(n) or 0)
    if n < 1 or n > maxPts() then return false, ('Entre 1 et %d points.'):format(maxPts()) end
    local o = owned[lic] or loadOwned(lic)
    if not (o.car or o.bike or o.truck) then return false, "Cette personne n'a pas de permis de conduire." end
    local left = math.max(0, getPts(lic) - n)
    setPts(lic, left)
    why = tostring(why or ''):gsub('[%c<>]', ''):sub(1, 80)
    MySQL.insert('INSERT INTO ' .. T_LOG .. ' (license, kind, passed, detail, at) VALUES (?, ?, ?, ?, ?)', { lic, 'points', 0, ('-%d pt(s) : %s (%s)'):format(n, why, tostring(by or 'police')):sub(1, 120), os.time() })
    if left <= 0 then
        for _, k in ipairs({ 'code', 'car', 'bike', 'truck' }) do MySQL.query.await('DELETE FROM ' .. T_LIC .. ' WHERE license = ? AND kind = ?', { lic, k }) end
        owned[lic] = nil
        pushMine(src)
        notify(src, 'error', ('Permis annulé : plus aucun point (%s). Repasse le code et la conduite à l\'auto-école.'):format(why))
        return true, 'Plus aucun point : son permis est annulé, il doit repasser l\'auto-école.'
    end
    notify(src, 'warn', ('%d point(s) retiré(s) sur ton permis : %s. Il t\'en reste %d sur %d.'):format(n, why, left, maxPts()))
    return true, ('%d point(s) retiré(s). Il lui reste %d point(s) sur %d.'):format(n, left, maxPts())
end
exports('RemovePoints', function(src, n, why, by) return removePoints(tonumber(src), n, why, by) end)
local function logExam(src, kind, passed, detail)
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO ' .. T_LOG .. ' (license, kind, passed, detail, at) VALUES (?, ?, ?, ?, ?)', { lic, kind, passed and 1 or 0, tostring(detail or ''):sub(1, 120), os.time() }) end
end

-- Réglages et page du panel ------------------------------------------------------------------------------------------------------------------------------
local forms, licBlocks = {}, nil
local XYZ = { { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -1000, max = 3000, int = false } }
local function setup()
    W:ExtRegister({ label = AE.label, version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier : auto-école (points, tarifs, permis)', true)
    W:ExtMigrate(RES .. '_001', 'Auto-école : permis et journal des examens', {
        'CREATE TABLE IF NOT EXISTS ' .. T_LIC .. ' (license VARCHAR(64) NOT NULL, kind VARCHAR(16) NOT NULL, score INT NOT NULL DEFAULT 0, faults INT NOT NULL DEFAULT 0, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license, kind))',
        'CREATE TABLE IF NOT EXISTS ' .. T_LOG .. [[ (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, kind VARCHAR(16) NOT NULL, passed TINYINT NOT NULL DEFAULT 0,
            detail VARCHAR(120) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (id), KEY k_at (at))]],
    })
    W:ExtMigrate(RES .. '_002', 'Auto-école : points du permis', {
        'CREATE TABLE IF NOT EXISTS ' .. T_PTS .. ' (license VARCHAR(64) NOT NULL, points INT NOT NULL DEFAULT 12, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))',
    })
    forms.main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = 'Auto-école active', default = true },
        { k = 'require_license', type = 'toggle', label = 'Permis obligatoire pour conduire', default = false, hint = 'Sans le permis du bon type, le moteur ne démarre pas. Désactivé par défaut : active-le quand les joueurs ont eu le temps de passer l\'examen.' },
        { k = 'fee_code', type = 'number', label = 'Prix du code ($)', default = AE.code_fee, min = 0, max = 100000 },
        { k = 'fee_car', type = 'number', label = 'Prix du permis voiture ($)', default = AE_KIND_BY.car.fee, min = 0, max = 100000 },
        { k = 'fee_bike', type = 'number', label = 'Prix du permis moto ($)', default = AE_KIND_BY.bike.fee, min = 0, max = 100000 },
        { k = 'fee_truck', type = 'number', label = 'Prix du permis poids lourd ($)', default = AE_KIND_BY.truck.fee, min = 0, max = 100000 },
        { k = 'q_count', type = 'number', label = 'Questions par examen du code', default = 10, min = 3, max = 30 },
        { k = 'pass_pct', type = 'number', label = 'Réussite du code (% de bonnes réponses)', default = 80, min = 30, max = 100 },
        { k = 'speed_limit', type = 'number', label = 'Limite de vitesse pendant l\'examen (km/h)', default = 80, min = 30, max = 200 },
        { k = 'max_faults', type = 'number', label = 'Fautes maximum à l\'examen de conduite', default = 6, min = 1, max = 30 },
        { k = 'cooldown_min', type = 'number', label = 'Attente après un échec (minutes)', default = 5, min = 0, max = 1440 },
        { k = 'pay', type = 'select', label = 'Paiement des examens', opts = { { 'cash', 'Espèces' }, { 'bank', 'Banque' } }, default = 'cash' },
        { k = 'blips', type = 'toggle', label = 'Auto-école sur la carte', default = true },
        { k = 'points_max', type = 'number', label = 'Points du permis', default = 12, min = 1, max = 48, hint = 'La police en retire (menu ALT ou F6). À 0, le permis est annulé : code et conduite à repasser.' },
    } })
    forms.spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Points posés', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Moniteur, départ et parcours', default = {}, wide = true, maxitems = 80, unique = 'id',
          hint = 'Pose-les en jeu : menu staff (F10) › Builder › Auto-école. Types : school (moniteur), start (départ du véhicule, dans le sens du cap du staff), cp (points du parcours) et stop (arrêt obligatoire), numérotés dans l\'ordre. Le nom d\'un point est la consigne dite par le moniteur.',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true },
            { k = 'label', label = 'Nom', required = true, maxlen = 40 }, XYZ[1], XYZ[2], XYZ[3], { k = 'h', label = 'Cap', type = 'number', min = 0, max = 360, int = false } } } } })
    W:ExtModule({
        id = RES, label = AE.label, icon = AE.icon, perm = PERM, hint = 'Moniteur, code, examen de conduite et permis des joueurs.',
        caps = {
            { 'Code', 'ok', 'Questions tirées au sort parmi ' .. #AE_QUESTIONS .. ', réponses justes gardées par le serveur.' },
            { 'Conduite', 'ok', 'Parcours de points et d\'arrêts posés au Builder ; vitesse, arrêts, sortie du véhicule et progression contrôlées par le serveur.' },
            { 'Permis', 'ok', 'Voiture, moto, poids lourd. Lisibles par les autres ressources (exports.' .. RES .. ':HasLicence).' },
            { 'Obligation', 'ok', 'Option : sans permis, le moteur ne démarre pas.' },
        },
        doc = "## Auto-école\nPose au Builder (F10 › Builder › Auto-école) : **le moniteur**, **le point de départ** (le véhicule apparaît là où tu te tiens, dans ton sens) puis **les points du parcours** dans l'ordre. Au moins 2 points sont nécessaires pour l'examen de conduite.\n\nCommandes staff : `/permis_donner [id] [code|car|bike|truck]`, `/permis_retirer [id] [type]`. Un joueur voit ses permis avec `/permis`.\n\nAutres ressources : `exports.wb_autoecole:HasLicence(source, 'car')`.",
        tabs = {
            { id = 'lic', label = 'Permis délivrés', icon = 'id', build = function() return licBlocks() end },
            { id = 'main', label = 'Réglages', icon = 'sliders', form = forms.main },
            { id = 'spots', label = 'Points posés', icon = 'pin', form = forms.spots },
        },
    })
end

licBlocks = function()
    local rows = {}
    for _, r in ipairs(MySQL.query.await('SELECT l.license, l.kind, l.score, l.faults, l.at, p.firstname, p.lastname FROM ' .. T_LIC .. ' l LEFT JOIN pb_players p ON p.license = l.license ORDER BY l.at DESC LIMIT 200') or {}) do
        local who = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
        rows[#rows + 1] = { who = who ~= '' and who or r.license, kind = labelOf(r.kind), score = r.kind == 'code' and (r.score .. ' %') or (r.faults .. ' faute(s)'), at = r.at }
    end
    local day = os.time() - 86400
    local n = MySQL.scalar.await('SELECT COUNT(*) FROM ' .. T_LOG .. ' WHERE passed = 1 AND at > ?', { day }) or 0
    local t = MySQL.scalar.await('SELECT COUNT(*) FROM ' .. T_LOG .. ' WHERE at > ?', { day }) or 0
    return { { type = 'stats', items = { { label = 'Examens (24 h)', value = t, icon = AE.icon }, { label = 'Réussis (24 h)', value = n, icon = 'check' } } },
        { type = 'table', id = 'lic', title = 'Permis délivrés (200 derniers)', rows = rows, empty = 'Aucun permis délivré.',
          columns = { { k = 'who', label = 'Joueur' }, { k = 'kind', label = 'Permis' }, { k = 'score', label = 'Résultat' }, { k = 'at', label = 'Date', type = 'date' } } } }
end

local function schools()
    local out = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do if s.kind == 'school' then out[#out + 1] = { id = s.id, kind = 'school', label = s.label, x = s.x, y = s.y, z = s.z, h = s.h } end end
    return out
end
local function publicCfg() return { enabled = cfg('enabled', true) ~= false, blips = cfg('blips', true) ~= false, require = cfg('require_license', false) == true, spots = schools() } end
local function push(target) TriggerClientEvent(RES .. ':cfg', target or -1, json.encode(publicCfg())) end
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns ~= NS then return end cache = {} push() end)
RegisterNetEvent(RES .. ':hello', function() local src = source push(src) pushMine(src) end)

-- Parcours ------------------------------------------------------------------------------------------------------------------------------------------------------------
local function route()
    local list, start = {}, nil
    for _, s in ipairs(cfg('spots', {}) or {}) do
        if s.kind == 'cp' or s.kind == 'stop' then list[#list + 1] = s elseif s.kind == 'start' then start = s end
    end
    table.sort(list, function(a, b) return (tonumber(tostring(a.id):match('(%d+)$')) or 0) < (tonumber(tostring(b.id):match('(%d+)$')) or 0) end)
    return start, list
end

-- Examens en cours ------------------------------------------------------------------------------------------------------------------------------------------------
local S, cool, lastAct = {}, {}, {}
AddEventHandler('playerDropped', function() local s = source S[s], lastAct[s] = nil, nil end)
local function throttle(src, ms) local t = GetGameTimer() if lastAct[src] and t - lastAct[src] < (ms or 600) then return false end lastAct[src] = t return true end
local function coolLeft(src, kind)
    local lic = W:GetLicense(src)
    local u = lic and cool[lic .. kind]
    if u and u > os.time() then return u - os.time() end
    return 0
end
local function setCool(src, kind)
    local lic, m = W:GetLicense(src), num('cooldown_min', 5)
    if lic and m > 0 then cool[lic .. kind] = os.time() + m * 60 end
end
-- où revient un candidat recalé : devant le moniteur, pas sur lui
local function frontOf(s)
    local h = math.rad(tonumber(s.h) or 0.0)
    return { x = s.x - math.sin(h) * 1.5, y = s.y + math.cos(h) * 1.5, z = s.z, h = ((tonumber(s.h) or 0.0) + 180.0) % 360.0 }
end
local function nearSchool(src, id)
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or s.kind ~= 'school' or not c or d2(c, s) > 6 then return nil end
    return s
end

RegisterNetEvent(RES .. ':open', function(id)
    local src = source
    if not throttle(src) or not cfg('enabled', true) or not W:CanAct(src) then return end
    local s = nearSchool(src, id)
    if not s then return end
    local _, cps = route()
    local list = {}
    local function entry(kind)
        local e = { key = kind, label = labelOf(kind), fee = feeOf(kind) }
        local left = coolLeft(src, kind)
        if has(src, kind) then e.state = 'done'
        elseif kind ~= 'code' and not has(src, 'code') then e.state = 'needcode'
        elseif left > 0 then e.state = 'cool' e.wait = math.ceil(left / 60)
        elseif kind ~= 'code' and #cps < 2 then e.state = 'noroute'
        else e.state = 'ok' end
        return e
    end
    list[1] = entry('code')
    for _, k in ipairs(AE.kinds) do list[#list + 1] = entry(k.key) end
    local nq, pass, lim, mx = math.min(#AE_QUESTIONS, math.floor(num('q_count', 10))), math.floor(num('pass_pct', 80)), math.floor(num('speed_limit', 80)), math.floor(num('max_faults', 6))
    for _, e in ipairs(list) do
        if e.key == 'code' then e.info = ('%d questions à choix multiple, %d %% de bonnes réponses pour réussir. Les corrections sont montrées à la fin.'):format(nq, pass)
        else e.info = ('Parcours de %d points avec un véhicule prêté. Limite %d km/h, %d fautes permises.'):format(#cps, lim, mx) end
    end
    local id_ = W:GetIdentity(src) or {}
    local who = ((id_.firstname or '') .. ' ' .. (id_.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    local lic = W:GetLicense(src)
    TriggerClientEvent(RES .. ':hub', src, s.id, json.encode({ id = s.id, title = s.label, who = who ~= '' and who or nil, dob = id_.dob, mine = lic and (owned[lic] or loadOwned(lic)) or {}, list = list,
        rules = { 'Le code se passe sans limite de temps, une question à la fois.', 'À l\'examen de conduite, suis les points jaunes et respecte la limite de vitesse.', 'Un choc, un excès de vitesse ou un arrêt non marqué comptent comme une faute.', 'Quitter le véhicule plus de 10 secondes met fin à l\'examen.' } }))
end)

local function shuffle(t) for i = #t, 2, -1 do local j = math.random(i) t[i], t[j] = t[j], t[i] end return t end
local function sendQ(src)
    local s = S[src]
    if not s or s.type ~= 'code' then return end
    local q = AE_QUESTIONS[s.qs[s.i]]
    local order = {}
    for i = 1, #q[2] do order[i] = i end
    shuffle(order)
    local opts, right = {}, 1
    for pos_, orig in ipairs(order) do opts[pos_] = q[2][orig] if orig == q[3] then right = pos_ end end
    s.right, s.opts, s.qtext = right, opts, q[1]
    TriggerClientEvent(RES .. ':q', src, s.i, #s.qs, q[1], json.encode(opts))
end

RegisterNetEvent(RES .. ':start', function(id, what)
    local src = source
    if not throttle(src) or not cfg('enabled', true) or not W:CanAct(src) then return end
    local sp = nearSchool(src, id)
    what = tostring(what)
    if not sp or not (what == 'code' or AE_KIND_BY[what]) then return end
    if S[src] then notify(src, 'warn', 'Un examen est déjà en cours.') return end
    if has(src, what) then notify(src, 'info', 'Tu as déjà ce permis.') return end
    if what ~= 'code' and not has(src, 'code') then notify(src, 'error', 'Il faut d\'abord réussir le code.') return end
    local left = coolLeft(src, what)
    if left > 0 then notify(src, 'warn', ('Reviens dans %d min pour repasser cet examen.'):format(math.ceil(left / 60))) return end
    local start, cps
    if what ~= 'code' then
        start, cps = route()
        if not start or #cps < 2 then notify(src, 'error', 'Le parcours d\'examen n\'est pas encore posé.') return end
    end
    local fee = feeOf(what)
    if fee > 0 and not W:Pay(src, fee, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash', 'Auto-école : ' .. labelOf(what):lower()) then notify(src, 'error', ('Il te faut $%d pour passer cet examen.'):format(fee)) return end
    if what == 'code' then
        local idx = {}
        for i = 1, #AE_QUESTIONS do idx[i] = i end
        shuffle(idx)
        local n = math.min(#AE_QUESTIONS, math.max(3, math.floor(num('q_count', 10))))
        local qs = {}
        for i = 1, n do qs[i] = idx[i] end
        S[src] = { type = 'code', qs = qs, i = 1, good = 0, at = os.time() }
        notify(src, 'info', ('Examen du code : %d questions, %d %% de bonnes réponses pour réussir.'):format(n, num('pass_pct', 80)))
        sendQ(src)
    else
        local k = AE_KIND_BY[what]
        local pts = {}
        for i, p in ipairs(cps) do pts[i] = { x = p.x, y = p.y, z = p.z, say = p.label, stop = p.kind == 'stop' or nil } end
        S[src] = { type = 'drive', kind = what, cps = cps, next = 1, log = {}, over = 0, out = 0, at = os.time(), lastAt = GetGameTimer(), lastPos = { x = start.x, y = start.y, z = start.z }, back = frontOf(sp) }
        TriggerClientEvent(RES .. ':exam', src, what, k.model, k.plate, { x = start.x, y = start.y, z = start.z, h = tonumber(start.h) or 0.0 }, json.encode(pts), num('speed_limit', 80), num('max_faults', 6))
    end
end)

local function finishCode(src, s)
    S[src] = nil
    local total = #s.qs
    local pct = math.floor(s.good / total * 100 + 0.5)
    local need = num('pass_pct', 80)
    local ok = pct >= need
    logExam(src, 'code', ok, ('%d/%d'):format(s.good, total))
    if ok then grant(src, 'code', pct, 0) else setCool(src, 'code') end
    TriggerClientEvent(RES .. ':result', src, json.encode({ type = 'code', ok = ok, good = s.good, total = total, pct = pct, need = need, miss = s.miss or {} }))
end
RegisterNetEvent(RES .. ':ans', function(idx)
    local src = source
    local s = S[src]
    if not s or s.type ~= 'code' or not s.right or not throttle(src, 250) then return end
    idx = tonumber(idx)
    if not idx then return end
    if idx == s.right then s.good = s.good + 1 else s.miss = s.miss or {} s.miss[#s.miss + 1] = { q = s.qtext, picked = s.opts[idx] or '?', right = s.opts[s.right] } end
    s.right = nil
    s.i = s.i + 1
    if s.i > #s.qs then finishCode(src, s) else sendQ(src) end
end)

local function finishDrive(src, s, ok, why)
    S[src] = nil
    logExam(src, s.kind, ok, ok and (#s.log .. ' faute(s)') or why)
    if ok then grant(src, s.kind, 0, #s.log) else setCool(src, s.kind) end
    local counts, order = {}, {}
    for _, r in ipairs(s.log) do if not counts[r] then counts[r] = 0 order[#order + 1] = r end counts[r] = counts[r] + 1 end
    local reasons = {}
    for _, r in ipairs(order) do reasons[#reasons + 1] = { reason = r, n = counts[r] } end
    local dur = math.max(0, os.time() - s.at)
    -- recalé : retour direct à l'auto-école (sauf à terre : les secours s'en occupent)
    local ped = GetPlayerPed(src)
    local back = not ok and ped and ped ~= 0 and GetEntityHealth(ped) > 0 and s.back or nil
    if back then pcall(function() W:AntiCheatGrace(src, 20) end) end
    TriggerClientEvent(RES .. ':finish', src, ok, json.encode({ type = 'drive', ok = ok, back = back, label = labelOf(s.kind), why = why ~= '' and (why:sub(1, 1):upper() .. why:sub(2)) or '', faults = #s.log, max = num('max_faults', 6), reasons = reasons, mins = dur // 60, secs = dur % 60 }))
end
local function fault(src, s, why)
    s.log[#s.log + 1] = why
    TriggerClientEvent(RES .. ':faults', src, #s.log, why)
    if #s.log > num('max_faults', 6) then finishDrive(src, s, false, 'trop de fautes.') end
end
RegisterNetEvent(RES .. ':cp', function(i)
    local src = source
    local s = S[src]
    if not s or s.type ~= 'drive' or tonumber(i) ~= s.next then return end
    local c = pos(src)
    local p = s.cps[s.next]
    if not c or not p or d3(c, p) > 40 then return end
    local dt = math.max(0.2, (GetGameTimer() - s.lastAt) / 1000)
    if d3(s.lastPos, p) / dt > 80 then finishDrive(src, s, false, 'parcours non respecté.') return end   -- 80 m/s = 288 km/h : téléportation
    s.lastAt, s.lastPos = GetGameTimer(), { x = p.x, y = p.y, z = p.z }
    if p.kind == 'stop' then
        local ped = GetPlayerPed(src)
        local veh = ped and GetVehiclePedIsIn(ped, false) or 0
        if veh and veh ~= 0 and GetEntitySpeed(veh) * 3.6 > 12 then fault(src, s, 'arrêt non marqué') if not S[src] then return end end
    end
    s.next = s.next + 1
    if s.next > #s.cps then finishDrive(src, s, true, '') end
end)
RegisterNetEvent(RES .. ':hit', function()
    local src = source
    local s = S[src]
    if not s or s.type ~= 'drive' or not s.boarded then return end
    local t = GetGameTimer()
    if s.lastHit and t - s.lastHit < 4000 then return end
    s.lastHit = t
    fault(src, s, 'collision')
end)
RegisterNetEvent(RES .. ':abort', function()
    local src = source
    local s = S[src]
    if s and s.type == 'drive' then finishDrive(src, s, false, 'examen abandonné.') elseif s then S[src] = nil end
end)

-- Contrôle serveur : vitesse, sortie du véhicule, durée -------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(1000)
        local now = os.time()
        for src, s in pairs(S) do
            if s.type == 'code' then
                if now - s.at > 900 then S[src] = nil end
            elseif s.type == 'drive' then
                local ped = GetPlayerPed(src)
                if not ped or ped == 0 or GetEntityHealth(ped) <= 0 then finishDrive(src, s, false, 'candidat à terre.')
                elseif now - s.at > 1800 then finishDrive(src, s, false, 'temps écoulé.')
                else
                    local veh = GetVehiclePedIsIn(ped, false)
                    if veh and veh ~= 0 then
                        s.boarded, s.out = true, 0
                        local kmh = GetEntitySpeed(veh) * 3.6
                        if kmh > num('speed_limit', 80) + 5 then
                            s.over = s.over + 1
                            if s.over >= 4 then s.over = 0 fault(src, s, 'excès de vitesse') end
                        elseif s.over > 0 then s.over = s.over - 1 end
                    else
                        s.out = s.out + 1
                        if (s.boarded and s.out >= 10) or (not s.boarded and now - s.at > 40) then finishDrive(src, s, false, 'tu as quitté le véhicule.') end
                    end
                end
            end
        end
    end
end)

-- Commandes -------------------------------------------------------------------------------------------------------------------------------------------------------------
local function staff(src) if src == 0 then return true end local ok, r = pcall(function() return W:HasPermission(src, PERM) end) return ok and r == true end
local function kindOk(k) return k == 'code' or AE_KIND_BY[k] ~= nil end
RegisterCommand('permis', function(src)
    if src == 0 then return end
    local lic = W:GetLicense(src)
    if not lic then return end
    local id_ = W:GetIdentity(src) or {}
    local who = ((id_.firstname or '') .. ' ' .. (id_.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    local mine = owned[lic] or loadOwned(lic)
    local drive = mine.car or mine.bike or mine.truck
    TriggerClientEvent(RES .. ':card', src, json.encode({ who = who ~= '' and who or nil, dob = id_.dob, mine = mine, pts = drive and getPts(lic) or nil, ptsMax = maxPts() }))
end, false)
RegisterCommand('permis_donner', function(src, args)
    if not staff(src) then return end
    local tid, kind = tonumber(args[1]), tostring(args[2] or 'car')
    if not tid or not kindOk(kind) or not GetPlayerName(tid) then print('usage : permis_donner [id] [code|car|bike|truck]') return end
    if grant(tid, kind, 100, 0) then
        notify(tid, 'success', labelOf(kind) .. ' délivré par le staff.')
        if src ~= 0 then notify(src, 'success', labelOf(kind) .. ' donné.') end
    end
end, false)
RegisterCommand('permis_retirer', function(src, args)
    if not staff(src) then return end
    local tid, kind = tonumber(args[1]), tostring(args[2] or 'car')
    local lic = tid and W:GetLicense(tid)
    if not lic or not kindOk(kind) then print('usage : permis_retirer [id] [code|car|bike|truck]') return end
    revoke(lic, kind)
    pushMine(tid)
    notify(tid, 'warn', labelOf(kind) .. ' retiré.')
    if src ~= 0 then notify(src, 'success', labelOf(kind) .. ' retiré.') end
end, false)

-- Builder (F10 › Builder › Auto-école) --------------------------------------------------------------------------------------------------------------------
local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = d2(c, s) if d < 15 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Aucun point à moins de 15 m.') return false end
        local s = table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', ('« %s » supprimé.'):format(s.label))
        return true
    end
    if what ~= 'school' and what ~= 'start' and what ~= 'cp' and what ~= 'stop' then return false end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    local ped = GetPlayerPed(src)
    local h = math.floor((GetEntityHeading(ped) or 0.0) * 10) / 10
    local row = { kind = what, x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, h = h }
    if what == 'start' then
        for i = #spots, 1, -1 do if spots[i].kind == 'start' then table.remove(spots, i) end end    -- un seul départ
        row.id, row.label = 'start', name ~= '' and name or 'Départ du véhicule d\'examen'
    else
        local n = 0
        local pat = (what == 'school') and '^school_(%d+)$' or '^%a+_(%d+)$'
        for _, s in ipairs(spots) do
            if what == 'school' ~= (s.kind ~= 'school') then
                local k = (what == 'school' or s.kind == 'cp' or s.kind == 'stop') and tonumber(tostring(s.id):match(pat))
                if k and k > n then n = k end
            end
        end
        row.id = what .. '_' .. (n + 1)
        row.label = name ~= '' and name or (what == 'school' and AE.moniteur or (what == 'stop' and 'Marquez l\'arrêt' or 'Continuez tout droit'))
    end
    spots[#spots + 1] = row
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : ' .. row.label)
    notify(src, 'success', row.label .. ' posé ici' .. (what == 'start' and ' (le véhicule apparaît dans ton sens).' or '.'))
    return true
end

local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        W:RegisterBuilder({ list = true, id = 'autoecole', label = AE.label, icon = AE.icon, points = {
            { id = 'school', label = AE.moniteur .. ' (examens)', ask = 'Nom affiché (vide = « ' .. AE.moniteur .. ' »)' },
            { id = 'start', label = 'Départ du véhicule (dans ton sens, un seul)' },
            { id = 'cp', label = 'Point du parcours (dans l\'ordre)', ask = 'Consigne du moniteur (vide = « Continuez tout droit »)' },
            { id = 'stop', label = 'Arrêt obligatoire (stop, dans l\'ordre)', ask = 'Consigne (vide = « Marquez l\'arrêt »)' },
            { id = 'delete', label = 'Supprimer le point le plus proche' },
        } }, function(src, what, extra)
            if what == '__list' then
                local out = {}
                for _, s in ipairs(cfg('spots', {}) or {}) do out[#out + 1] = { key = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
                return out
            elseif what == '__delete' then
                local spots = cfg('spots', {}) or {}
                for i, s in ipairs(spots) do
                    if tostring(s.id) == tostring(extra) then table.remove(spots, i) W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression') return true end
                end
                return false
            end
            return placeSpot(src, tostring(what), tostring(extra or ''))
        end)
    end)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
