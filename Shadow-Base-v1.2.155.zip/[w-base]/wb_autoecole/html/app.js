'use strict';
const $ = (id) => document.getElementById(id);
const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'wb_autoecole';
const post = (name, data) => fetch(`https://${RES}/${name}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {}) }).catch(() => {});
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const SCREENS = ['hub', 'quiz', 'res', 'card'];
const CATS = [['code', 'Code', 'Théorie'], ['car', 'B', 'Voiture'], ['bike', 'A', 'Moto'], ['truck', 'C', 'Poids lourd']];
let current = null, spotId = null, locked = false, cardTimer = null;

function show(name) {
  SCREENS.forEach((s) => { $(s).hidden = s !== name; });
  current = name;
}
function hideAll() { SCREENS.forEach((s) => { $(s).hidden = true; }); current = null; }

function licenceCard(d) {
  const mine = d.mine || {};
  const cats = CATS.map(([k, l, s]) => `<div class="cat${mine[k] ? ' on' : ''}"><b>${l}</b><span>${s}</span></div>`).join('');
  const pts = d.pts != null ? `<div class="dob">Points : <b>${Number(d.pts)}</b> / ${Number(d.ptsMax || 12)}</div>` : '';
  return `<div class="lic"><small>Permis de conduire</small><div class="nm">${esc(d.who || 'Candidat')}</div><div class="dob">${d.dob ? 'Né(e) le ' + esc(d.dob) : ' '}</div>${pts}<div class="cats">${cats}</div></div>`;
}

function renderHub(d) {
  spotId = d.id;
  $('hubTitle').textContent = d.title || 'Auto-école';
  $('hubCard').innerHTML = licenceCard(d);
  $('hubRules').innerHTML = (d.rules || []).map((r) => `<li>${esc(r)}</li>`).join('');
  $('hubCards').innerHTML = d.list.map((e) => {
    const letter = e.key === 'code' ? '§' : (CATS.find((c) => c[0] === e.key) || [0, '?'])[1];
    let chip = '', btn;
    if (e.state === 'done') chip = '<span class="chip done">Obtenu</span>';
    else if (e.state === 'cool') chip = `<span class="chip cool">Dans ${e.wait} min</span>`;
    else if (e.state === 'needcode') chip = '<span class="chip">Code requis</span>';
    else if (e.state === 'noroute') chip = '<span class="chip">Bientôt</span>';
    if (e.state === 'ok') btn = `<button class="btn" data-start="${e.key}">Passer l'examen · $${e.fee}</button>`;
    else if (e.state === 'done') btn = '<button class="btn" disabled>Déjà obtenu</button>';
    else btn = `<button class="btn" disabled>${e.state === 'noroute' ? 'Parcours non posé' : e.state === 'needcode' ? 'Réussis le code d\'abord' : 'Reviens plus tard'}</button>`;
    return `<div class="pc ${e.state === 'ok' ? 'ok' : ''} ${e.state === 'done' ? 'done' : ''}"><div class="top"><div class="letter">${letter}</div><h3>${esc(e.label)}</h3>${chip}</div><div class="info">${esc(e.info)}</div>${btn}</div>`;
  }).join('');
}

function renderQuiz(d) {
  show('quiz');
  locked = false;
  $('qCount').textContent = `Question ${d.i} sur ${d.total}`;
  $('qSeg').innerHTML = Array.from({ length: d.total }, (_, k) => `<i class="${k + 1 < d.i ? 'on' : (k + 1 === d.i ? 'cur' : '')}"></i>`).join('');
  $('qText').textContent = d.text;
  $('qAns').innerHTML = d.opts.map((o, k) => `<button class="an" data-ans="${k + 1}"><b>${k + 1}</b><span>${esc(o)}</span></button>`).join('');
}
function answer(n) {
  if (locked || current !== 'quiz') return;
  const b = document.querySelector(`[data-ans="${n}"]`);
  if (!b) return;
  locked = true;
  b.classList.add('pick');
  $('qAns').classList.add('lock');
  document.querySelectorAll('.an').forEach((x) => x.classList.add('lock'));
  setTimeout(() => post('ans', { n }), 260);
}

function renderResult(d) {
  show('res');
  const ok = !!d.ok;
  $('rRing').style.setProperty('--c', ok ? 'var(--ok)' : 'var(--bad)');
  $('rNext').hidden = true;
  if (d.type === 'code') {
    $('rTitle').textContent = ok ? 'Code réussi' : 'Code raté';
    $('rSub').textContent = ok ? 'Tu peux maintenant passer l\'examen de conduite.' : `Il fallait ${d.need} % de bonnes réponses. Relis les corrections ci-dessous.`;
    $('rRing').style.setProperty('--p', d.pct);
    $('rRing').innerHTML = `<b>${d.good}/${d.total}</b>`;
    $('rStats').innerHTML = `<div><span class="tag ${ok ? 'ok' : 'bad'}">${ok ? 'Admis' : 'Ajourné'}</span></div><div>Score <strong>${d.pct} %</strong></div><div>Seuil <strong>${d.need} %</strong></div>`;
    $('rRev').innerHTML = d.miss && d.miss.length
      ? d.miss.map((m) => `<div class="rv"><p>${esc(m.q)}</p><div class="w">Ta réponse : ${esc(m.picked)}</div><div class="r">Bonne réponse : ${esc(m.right)}</div></div>`).join('')
      : '<div class="rv none">Aucune erreur. Sans faute !</div>';
    if (ok) { $('rNext').hidden = false; $('rNext').textContent = 'Passer à la conduite'; $('rNext').onclick = () => post('again', { id: spotId }); }
  } else {
    $('rTitle').textContent = ok ? `${d.label} obtenu` : 'Examen de conduite raté';
    $('rSub').textContent = ok ? 'Le permis est enregistré sur ton dossier.' : d.why || '';
    const pct = Math.max(0, Math.round(100 - (d.faults / Math.max(1, d.max)) * 100));
    $('rRing').style.setProperty('--p', ok ? pct : 100);
    $('rRing').innerHTML = `<b>${d.faults}/${d.max}</b>`;
    $('rStats').innerHTML = `<div><span class="tag ${ok ? 'ok' : 'bad'}">${ok ? 'Admis' : 'Ajourné'}</span></div><div>Fautes <strong>${d.faults} sur ${d.max} permises</strong></div><div>Durée <strong>${d.mins} min ${String(d.secs).padStart(2, '0')} s</strong></div>`;
    $('rRev').innerHTML = d.reasons && d.reasons.length
      ? d.reasons.map((r) => `<div class="rv"><p>${esc(r.reason)}</p><div class="w">${r.n} fois</div></div>`).join('')
      : '<div class="rv none">Conduite parfaite, aucune faute relevée.</div>';
  }
}

function showCard(d) {
  clearTimeout(cardTimer);
  $('cardBox').innerHTML = licenceCard(d);
  show('card');
  cardTimer = setTimeout(hideAll, 7000);
}

function toast(text) {
  const t = $('toast');
  t.textContent = text;
  t.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => { t.hidden = true; }, 3200);
}

window.addEventListener('message', (ev) => {
  const d = ev.data || {};
  switch (d.a) {
    case 'hub': renderHub(d); show('hub'); break;
    case 'quiz': renderQuiz(d); break;
    case 'result': renderResult(d); break;
    case 'card': showCard(d); break;
    case 'hide': hideAll(); break;
    case 'hudStart':
      $('hud').hidden = false;
      $('hWho').textContent = d.who || 'Moniteur';
      $('hPips').innerHTML = Array.from({ length: d.max }, () => '<i></i>').join('');
      $('hLimTxt').textContent = `limite ${d.limit} km/h`;
      break;
    case 'hud': {
      const over = d.speed > d.limit + 5;
      $('hSpd').textContent = d.speed;
      $('hLim').style.width = Math.min(100, (d.speed / (d.limit * 1.4)) * 100) + '%';
      document.querySelector('.spd').classList.toggle('over', over);
      $('hSay').textContent = d.say || '';
      $('hPt').textContent = `Point ${d.i} / ${d.n}`;
      document.querySelectorAll('#hPips i').forEach((p, k) => p.classList.toggle('f', k < d.faults));
      break;
    }
    case 'fault': toast(d.text); break;
    case 'hudStop': $('hud').hidden = true; break;
  }
});

document.addEventListener('click', (e) => {
  const t = e.target.closest('button');
  if (!t) return;
  if (t.dataset.start) { post('start', { id: spotId, key: t.dataset.start }); }
  else if (t.dataset.ans) answer(+t.dataset.ans);
  else if ('close' in t.dataset) post('close');
  else if ('abort' in t.dataset) post('abort');
});
document.addEventListener('keydown', (e) => {
  if (current === 'quiz') {
    if (e.key >= '1' && e.key <= '4') answer(+e.key);
    else if (e.key === 'Escape') post('abort');
  } else if (current === 'hub' || current === 'res') {
    if (e.key === 'Escape') post('close');
  }
});
