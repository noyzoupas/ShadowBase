/* Établi d'armes : recettes, matériaux et où les trouver. Le serveur vérifie tout ; ici on affiche et on demande.
   Tout texte reçu est inséré avec textContent ; les images sont celles de l'inventaire (pb_panel/web/img). */
'use strict';
const $ = (id) => document.getElementById(id);
const h = (tag, attrs, ...kids) => {
  const e = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v == null) return; if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); });
  kids.flat().forEach((c) => { if (c != null) e.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c))); });
  return e;
};
const inGame = typeof GetParentResourceName === 'function';
const post = (name, d) => { if (!inGame) { window.__posts = (window.__posts || []).concat([[name, d]]); return; } fetch('https://' + GetParentResourceName() + '/' + name, { method: 'POST', body: JSON.stringify(d || {}) }).catch(() => {}); };
let D = null, page = 'weapons', sel = null, qty = 1;

// Image d'un objet : la même que dans l'inventaire
const WEB = inGame ? 'nui://pb_panel/web/img/' : '../../pb_panel/web/img/';
const pic = (item) => {
  const n = String(item || '').toLowerCase();
  const src = n.startsWith('weapon_') ? WEB + 'ox/WEAPON_' + n.slice(7).toUpperCase() + '.png' : WEB + 'items/' + n + '.svg';
  return h('img', { src, alt: '', onerror: (e) => { e.target.onerror = null; e.target.src = WEB + 'items/_item.svg'; } });
};
const ICONS = {
  weapons: '<path d="M3 9h11l2 2h5v3h-3l-1 3h-3l-1-3H8l-1 4H4l1-4H3z"/>',
  parts: '<circle cx="12" cy="12" r="3.2"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
  scrap: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
  sources: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.4"/>',
  market: '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h7M9 17h7"/>',
};
const svg = (k) => { const e = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); e.setAttribute('viewBox', '0 0 24 24'); e.innerHTML = ICONS[k] || ICONS.parts; return e; };
const ORDER = ['weapons', 'parts', 'scrap'];
const pages = () => (D.cats || []).slice().sort((a, b) => ORDER.indexOf(a.id) - ORDER.indexOf(b.id))
  .map((c) => ({ id: c.id, label: c.label, desc: c.desc, n: (D.recipes || []).filter((r) => r.cat === c.id).length }))
  .concat([{ id: 'sources', label: 'Où trouver', desc: 'La ferraille se récupère sur place, ou s\'achète au marché noir de l\'atelier (argent sale d\'abord).' },
    { id: 'market', label: 'Plans', desc: 'Chaque famille d\'armes demande un plan. Un plan ne se consomme jamais : on l\'achète une seule fois.' }]);
const rawOf = (item) => (D.raw || []).find((x) => x.item === item);
const recipeFor = (item) => (D.recipes || []).find((r) => r.item === item);

function scale() { document.documentElement.style.setProperty('--k', String(Math.min(1.2, Math.min(window.innerWidth / 1240, window.innerHeight / 760)))); }
window.addEventListener('resize', scale);

// Couleur du serveur
function accent() {
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(String(D.color || ''));
  if (!m) return;
  const [r, g, b] = [m[1], m[2], m[3]].map((x) => parseInt(x, 16));
  const s = document.documentElement.style;
  s.setProperty('--ac', '#' + m[1] + m[2] + m[3]); s.setProperty('--ac-rgb', r + ',' + g + ',' + b);
  s.setProperty('--ac-ink', 0.299 * r + 0.587 * g + 0.114 * b > 150 ? '#111' : '#fff');
}

function draw() {
  if (!D) return;
  $('spot').textContent = D.label || 'Atelier';
  $('lvl').textContent = 'Niveau ' + D.level;
  $('xp').textContent = D.next ? D.xp + ' / ' + D.next + ' XP' : D.xp + ' XP';
  $('xpbar').style.width = (D.next ? Math.min(100, D.xp / D.next * 100) : 100) + '%';
  const nav = $('nav'); nav.textContent = '';
  const list = pages();
  list.forEach((p) => nav.appendChild(h('button', { class: 'tb' + (p.id === page ? ' on' : ''), onclick: () => { page = p.id; sel = null; qty = 1; draw(); } },
    svg(p.id), p.label, p.n ? h('em', null, p.n) : null)));
  const cur = list.find((p) => p.id === page) || list[0];
  $('intro').textContent = cur.desc || '';
  const body = $('body'); body.textContent = '';
  if (page === 'sources') viewSources(body); else if (page === 'market') viewPlans(body); else viewRecipes(body);
  drawDetail();
}

// Ce qui bloque une recette, en clair
const stateOf = (r) => {
  if (!r.lvOk) return ['Niveau ' + r.level + ' requis', 'bad'];
  if (r.plan && !r.planOk) return ['Plan manquant', 'bad'];
  if (r.can) return ['Prêt à fabriquer', 'ok'];
  return [r.needs.filter((x) => x.have >= x.need).length + ' / ' + r.needs.length + ' matériaux', ''];
};
function viewRecipes(body) {
  const rec = (D.recipes || []).filter((r) => r.cat === page);
  if (!sel || sel.cat !== page) sel = rec.find((r) => r.can) || rec[0] || null;
  rec.forEach((r) => {
    const s = stateOf(r);
    const have = r.needs.filter((x) => x.have >= x.need).length;
    body.appendChild(h('button', { class: 'card' + (sel && sel.id === r.id ? ' on' : '') + (r.lvOk ? '' : ' dim'), onclick: () => { sel = r; qty = 1; draw(); } },
      h('div', { class: 'pic' }, pic(r.item)),
      h('div', { class: 'txt' }, h('b', null, r.label), h('span', { class: 'st ' + s[1] }, s[0]),
        h('div', { class: 'bar' + (r.can ? ' ok' : '') }, h('i', { style: 'width:' + Math.round(have / Math.max(1, r.needs.length) * 100) + '%' })))));
  });
  if (!rec.length) body.appendChild(h('p', { class: 'wide empty' }, 'Rien à faire ici pour le moment.'));
}

// Ligne de matériau : cliquable quand il manque et qu'on sait où l'obtenir
function need(ok, thumb, label, right, hint, onClick) {
  return h(onClick ? 'button' : 'div', { class: 'need ' + (ok ? 'yes' : 'no'), onclick: onClick || null },
    h('div', { class: 'th' }, thumb), h('div', { class: 'nt' }, h('span', null, label), hint ? h('small', null, hint) : null), h('em', null, right));
}
function howTo(d) {
  d.appendChild(h('h2', { class: 'how' }, 'Comment ça marche'));
  d.appendChild(h('ul', { class: 'steps' },
    h('li', null, h('b', null, '1'), h('div', null, 'Récupère de la ferraille', h('small', null, 'Sur les tas indiqués dans « Où trouver », ou achète-la ici.'))),
    h('li', null, h('b', null, '2'), h('div', null, 'Fabrique des pièces', h('small', null, 'Pièces d\'acier, ressorts, canons, culasses… dans l\'onglet Pièces.'))),
    h('li', null, h('b', null, '3'), h('div', null, 'Assemble ton arme', h('small', null, 'Il faut le plan de la famille d\'armes (onglet Plans) et le bon niveau.'))),
    h('li', null, h('b', null, '+'), h('div', null, 'Les munitions', h('small', null, 'Elles ne se fabriquent pas : achète-les à l\'Ammu-Nation.')))));
}
function drawDetail() {
  const d = $('detail'); d.textContent = '';
  if (page === 'sources' || page === 'market' || !sel) { howTo(d); return; }
  const r = sel;
  d.appendChild(h('div', { class: 'head' }, h('div', { class: 'hero' }, pic(r.item)),
    h('div', { class: 'hd' }, h('h2', null, r.label), h('div', { class: 'facts' }, h('span', null, r.time + ' s'), r.fail > 0 ? h('span', null, r.fail + ' % de raté') : null, r.qty > 1 ? h('span', null, 'Donne × ' + r.qty) : null))));
  d.appendChild(h('div', { class: 'sec' }, 'Ce qu\'il te faut'));
  const list = h('div', { class: 'needs' });
  r.needs.forEach((x) => {
    const n = x.need * qty, ok = x.have >= n;
    const made = recipeFor(x.item), raw = rawOf(x.item);
    const go = ok ? null : raw ? () => { page = 'sources'; sel = null; draw(); } : made ? () => { page = made.cat; sel = made; qty = 1; draw(); } : null;
    list.appendChild(need(ok, pic(x.item), x.label, x.have + ' / ' + n, ok ? null : raw ? 'Où en trouver ›' : made ? 'Voir la recette ›' : null, go));
  });
  if (r.plan) list.appendChild(need(r.planOk, pic(r.planItem), r.plan, r.planOk ? 'Possédé' : 'Manquant', r.planOk ? null : 'Acheter le plan ›', r.planOk ? null : () => { page = 'market'; sel = null; draw(); }));
  d.appendChild(list);
  const foot = h('div', { class: 'foot' });
  if (r.batch > 1) foot.appendChild(h('div', { class: 'qty' }, h('span', null, 'Quantité'), h('div', null,
    h('button', { onclick: () => { qty = Math.max(1, qty - 1); draw(); } }, '−'), h('b', null, qty), h('button', { onclick: () => { qty = Math.min(r.batch, qty + 1); draw(); } }, '+'))));
  const enough = r.needs.every((x) => x.have >= x.need * qty);
  const why = !r.lvOk ? 'Niveau d\'armurier ' + r.level + ' requis.' : (r.plan && !r.planOk) ? 'Il te manque le plan.' : !enough ? 'Il te manque des matériaux.' : null;
  foot.appendChild(h('button', { class: 'go', disabled: why ? 'disabled' : null, onclick: () => post('start', { id: D.id, rid: r.id, n: qty }) }, 'Fabriquer'));
  foot.appendChild(h('p', { class: 'why' + (why ? ' bad' : '') }, why || 'Reste près de l\'établi pendant la fabrication.'));
  d.appendChild(foot);
}

function viewSources(body) {
  (D.raw || []).forEach((m) => {
    const box = h('div', { class: 'box wide' }, h('h3', null, h('div', { class: 'th' }, pic(m.item)), m.label, h('span', null, 'Tu en as ' + m.have)));
    (m.places || []).forEach((p) => box.appendChild(h('div', { class: 'place' }, h('div', null, h('b', null, p.label), h('small', null, 'À ' + (p.dist >= 1000 ? (p.dist / 1000).toFixed(1) + ' km' : p.dist + ' m'))),
      h('button', { class: 'mini', onclick: () => post('gps', { x: p.x, y: p.y }) }, 'Marquer sur la carte'))));
    if (!(m.places || []).length) box.appendChild(h('div', { class: 'place' }, h('div', null, h('small', null, 'Aucun lieu indiqué pour le moment.'))));
    if (m.price) box.appendChild(h('div', { class: 'place' }, h('div', null, h('b', null, 'Marché noir de cet atelier'), h('small', null, '$' + m.price + ' l\'unité')),
      h('button', { class: 'mini pri', onclick: () => post('buy', { id: D.id, item: m.item, qty: 5 }) }, 'Acheter 5'), h('button', { class: 'mini pri', onclick: () => post('buy', { id: D.id, item: m.item, qty: 25 }) }, 'Acheter 25')));
    body.appendChild(box);
  });
}
function viewPlans(body) {
  (D.market || []).filter((m) => m.plan).forEach((m) => body.appendChild(h('div', { class: 'card' }, h('div', { class: 'pic' }, pic(m.item)),
    h('div', { class: 'txt' }, h('b', null, m.label),
      m.owned ? h('span', { class: 'st ok' }, 'Possédé : ses armes sont débloquées') : h('button', { class: 'mini pri buy', onclick: () => post('buy', { id: D.id, item: m.item, qty: 1 }) }, 'Acheter · $' + m.price)))));
}

function open(data) {
  const keep = sel && sel.id;
  D = data; scale(); accent();
  sel = keep ? (D.recipes || []).find((x) => x.id === keep) || null : null;
  $('scr').hidden = false;
  draw();
}
window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.a === 'open') open(m.data);
  else if (m.a === 'close') $('scr').hidden = true;
});
const quit = () => { $('scr').hidden = true; post('close', {}); };
$('quit').addEventListener('click', quit);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('scr').hidden) quit(); });
