-- Shadow Base — Atelier d'armes clandestin (client) : invite E à côté d'un atelier caché, menu de fabrication, geste + barre,
-- mini-jeu d'assemblage (touche affichée à presser à temps) pour les armes.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local near = {}          -- ateliers signalés par le serveur (juste à côté)
local busy = false
local data               -- dernier menu reçu

local function notify(kind, text) W:Notify({ type = kind, title = 'Atelier', text = text }) end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end

RegisterNetEvent(RES .. ':near', function(j) local ok, l = pcall(json.decode, j) near = ok and type(l) == 'table' and l or {} end)

-- Invite E ------------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if #near > 0 and not busy and isFree() and not IsPedInAnyVehicle(PlayerPedId(), false) then
            sleep = 200
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(near) do local d = #(c - vector3(s.x, s.y, s.z)) if d < 2.0 and (not bd or d < bd) then best, bd = s, d end end
            if best then
                sleep = 0
                if shown ~= best.id then shown = best.id W:Prompt(best.source and (best.verb or best.label) or 'Utiliser l\'établi', 'E', best.x, best.y, best.z) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. (best.source and ':gather' or ':open'), best.id) Wait(500) end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Tablette (page html/) ------------------------------------------------------------------------------------------------------------------------
local tabletOpen = false
local function openTablet()
    if not data or busy then return end
    tabletOpen = true
    SendNUIMessage({ a = 'open', data = data })
    SetNuiFocus(true, true)
end
local function closeTablet()
    tabletOpen = false
    SendNUIMessage({ a = 'close' })
    SetNuiFocus(false, false)
end
RegisterNetEvent(RES .. ':menu', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    data = d
    if not busy then openTablet() end
end)
RegisterNUICallback('close', function(_, cb) cb(1) tabletOpen = false SetNuiFocus(false, false) end)
RegisterNUICallback('start', function(d, cb) cb(1) closeTablet() TriggerServerEvent(RES .. ':start', d.id, d.rid, d.n) end)
RegisterNUICallback('buy', function(d, cb) cb(1) TriggerServerEvent(RES .. ':buy', d.id, d.item, d.qty) end)
RegisterNUICallback('gps', function(d, cb)
    cb(1)
    local x, y = tonumber(d.x), tonumber(d.y)
    if x and y then SetNewWaypoint(x + 0.0, y + 0.0) notify('success', 'Position marquée sur ta carte.') end
end)
AddEventHandler('onResourceStop', function(r) if r == RES and tabletOpen then SetNuiFocus(false, false) end end)

-- Récupérer un matériau à un lieu posé
RegisterNetEvent(RES .. ':gathergo', function(verb, secs)
    busy = true
    local ped = PlayerPedId()
    local at = GetEntityCoords(ped)
    TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_GARDENER_PLANT', 0, true)
    W:Progress(tostring(verb), secs)
    local stop, ok = GetGameTimer() + secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - at) > 3.0 then ok = false break end
    end
    ClearPedTasks(ped)
    busy = false
    if ok then TriggerServerEvent(RES .. ':gatherdone') else W:CancelProgress() end
end)

-- Fabrication : geste + barre ; X ou s'éloigner annule ; mini-jeu pour les armes -----------------------------------------------------------------------
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
local KIND = { canon_court = 'barrel', canon_long = 'barrel', culasse = 'slide', carcasse = 'receiver', crosse = 'stock', ressort = 'spring', piece_acier = 'plate' }   -- id des pièces dessinées en 3D (pb_panel › web/img/bench)
-- (patch 340) assemblage des armes : établi vu du dessus, pièces à glisser sur leur emplacement (pb_panel › web/game/bench.js)
local function benchFor(d)
    local r = RECIPE_BY[d.id]
    local parts = {}
    for _, nd in ipairs(r and r.needs or {}) do
        local it = PARTS_BY and PARTS_BY[nd[1]]
        if KIND[nd[1]] and nd[1] ~= 'piece_acier' then parts[#parts + 1] = { id = KIND[nd[1]], label = (it and it.label) or nd[1], kind = KIND[nd[1]] } end
    end
    if #parts < 3 then parts[#parts + 1] = { id = 'piece_acier', label = "Pièce d'acier", kind = 'plate' } end
    return { token = 'armes', mode = 'weapon', weapon = d.id, title = d.label, secs = d.secs, parts = parts }
end
local benchRes
AddEventHandler('pb:g:bench:done', function(tok, res) if tok == 'armes' then benchRes = res or { ok = false } end end)
RegisterNetEvent(RES .. ':go', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    busy = true
    if d.mini then
        benchRes = nil
        TriggerEvent('pb:g:bench', benchFor(d))
        while not benchRes do Wait(100) end
        busy = false
        if benchRes.cancel then notify('warn', 'Fabrication interrompue.') TriggerServerEvent(RES .. ':cancel') return end
        local e = benchRes.errors or 0
        local score = benchRes.ok and (e == 0 and 3 or e <= 2 and 2 or 1) or 0
        notify(score == 3 and 'success' or 'info', ('Assemblage : %s.'):format(score == 3 and 'parfait' or (e .. ' erreur(s)')))
        TriggerServerEvent(RES .. ':done', score)
        return
    end
    local ped = PlayerPedId()
    local at = GetEntityCoords(ped)
    if loadDict('mini@repair') then TaskPlayAnim(ped, 'mini@repair', 'fixing_a_ped', 3.0, 3.0, -1, 1, 0, false, false, false) end
    W:Progress(d.label .. (d.n > 1 and (' × ' .. d.n) or ''), d.secs)
    local stop, done = GetGameTimer() + d.secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - at) > 3.0 then done = false break end
    end
    ClearPedTasks(ped)
    busy = false
    if not done then W:CancelProgress() notify('warn', 'Fabrication interrompue.') TriggerServerEvent(RES .. ':cancel') return end
    TriggerServerEvent(RES .. ':done', 0)
end)
