fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_shield'
description 'Shadow Base — protection contre le déclenchement d\'évènements : jeton signé sur chaque évènement réseau protégé, anti-rejeu et limite de débit. Extension de pb_panel.'
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

-- shield.lua est ajouté aux autres ressources par la commande `shield_install` (console du serveur) ; il ne se charge pas lui-même.
server_script 'server.lua'
