-- Banque : agences (blips, marqueur, invite « E ») et distributeurs du décor (détection des props). Le serveur valide chaque opération.
local G = PBG
local isOpen = false
local points, blips = {}, {}
local atmHashes = {}

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

local function close()
    if not isOpen then return end
    isOpen = false
    TriggerServerEvent('pb:g:bank:close')
    G.focus(false)
    G.send('bank.close', {})
end

RegisterNetEvent('pb:g:bank:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then TriggerServerEvent('pb:g:bank:close') return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('bank.' .. tostring(d.ev), d)
end)

G.nui['bank.page'] = function(d) if isOpen then TriggerServerEvent('pb:g:bank:page', tostring(d.page or 'home')) end return {} end
G.nui['bank.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:bank:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or 'home')) end return {} end
G.nui['bank.close'] = function() close() return {} end

local function rebuildBlips()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (G.cfg.bank and G.cfg.bank.blips) then return end
    for _, p in ipairs(points) do
        if p.kind == 'branch' then
            local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, 108) SetBlipColour(b, 2) SetBlipScale(b, 0.8) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.label)) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        end
    end
end

local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    points = c.bank_points or {}
    local npcs = {}
    if (c.bank or {}).npc ~= false then
        for _, p in ipairs(points) do if p.kind == 'branch' then npcs[#npcs + 1] = { id = p.id, model = (c.bank or {}).npc_model or 'a_m_m_business_01', x = p.x, y = p.y, z = p.z, h = p.h } end end
    end
    G.Npcs('bank', npcs)   -- banquier à chaque agence
    atmHashes = {}
    for m in tostring((c.bank or {}).atm_models or ''):gmatch('[%w_]+') do atmHashes[#atmHashes + 1] = GetHashKey(m) end
    rebuildBlips()
end

CreateThread(function()
    local shown, key = false, nil
    local function hide() if shown then shown = false key = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or busy() or isOpen then hide() Wait(700)
        else
            local bc = G.cfg.bank or {}
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd, label, bp = nil, 1e9, nil, nil
            for _, p in ipairs(points) do local d = #(c - vector3(p.x + 0.0, p.y + 0.0, p.z + 0.0)) if d < bd then best, bd, label, bp = p.id, d, p.label, p end end
            local near = bd <= 12.0
            local ref, text = best, label
            local ud = (bc.use_distance or 2.0) + 0.6
            if not (near and bd <= ud) and bc.atm_props then
                -- distributeur du décor à portée de main
                for _, h in ipairs(atmHashes) do
                    local o = GetClosestObjectOfType(c.x, c.y, c.z, 1.6, h, false, false, false)
                    if o ~= 0 and not G.DecorHidden(o) then ref, text, bd = 'atm', 'Distributeur', 1.0 break end
                end
            end
            if near and bd <= 12.0 and ref == best then
                G.Point(bp.x + 0.0, bp.y + 0.0, bp.z - 0.95, 111, 180, 255, 1.0)
            end
            if ref and bd <= ud and not IsPedInAnyVehicle(ped, false) then
                if not shown or key ~= ref then shown, key = true, ref G.send('prompt', { show = true, key = 'E', text = (ref == 'atm' and 'Utiliser le distributeur' or ('Banque : ' .. text)) }) end
                if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:g:bank:open', ref) end
                Wait(0)
            else hide() Wait(near and 100 or 400) end
        end
    end
end)

CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)
