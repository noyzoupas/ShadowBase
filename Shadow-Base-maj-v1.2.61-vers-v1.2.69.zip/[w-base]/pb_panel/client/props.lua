-- Props permanents : fait apparaître (localement) les objets posés par le staff à moins de 150 m, et le mode de pose du menu F10.
-- Le serveur garde la liste et revérifie chaque pose ; ici on ne fait que dessiner et proposer.
local G = PBG
local list, spawned = {}, {}   -- id -> entité
local moving = nil   -- prop en cours de déplacement : seul son aperçu est affiché

local function remove(id) local e = spawned[id] if e and DoesEntityExist(e) then DeleteEntity(e) end spawned[id] = nil end
RegisterNetEvent('pb:g:props:all', function(j)
    local l = G.decode(j) or {}
    local keep = {}
    for _, p in ipairs(l) do keep[p.id] = p end
    for id in pairs(spawned) do
        local o, n = list[id], keep[id]
        if not n or not o or o.m ~= n.m or o.x ~= n.x or o.y ~= n.y or o.z ~= n.z or o.h ~= n.h then remove(id) end
    end
    list = keep
end)

CreateThread(function()
    while true do
        Wait(1500)
        local me = GetEntityCoords(PlayerPedId())
        for id, p in pairs(list) do
            local near = id ~= moving and #(me - vector3(p.x, p.y, p.z)) < 150.0
            if near and not (spawned[id] and DoesEntityExist(spawned[id])) then
                local h = joaat(p.m)
                if IsModelInCdimage(h) then
                    RequestModel(h)
                    local t = GetGameTimer() + 3000
                    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
                    if HasModelLoaded(h) and list[id] == p then
                        local e = CreateObjectNoOffset(h, p.x, p.y, p.z, false, false, false)
                        SetEntityRotation(e, p.p or 0.0, p.r or 0.0, p.h or 0.0, 2, true)
                        FreezeEntityPosition(e, true)
                        SetEntityCollision(e, p.c ~= 0, p.c ~= 0)
                        SetEntityInvincible(e, true)
                        SetModelAsNoLongerNeeded(h)
                        spawned[id] = e
                    end
                else spawned[id] = 0 end   -- modèle absent sur cette version du jeu : on n'insiste pas
            elseif not near and spawned[id] then remove(id) end
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then for id in pairs(spawned) do remove(id) end end end)

-- Mode de pose : aperçu transparent là où vise la caméra ; la première flèche le fixe, puis ← → gauche / droite, ↑ ↓ monter / descendre,
-- Maj + ↑ ↓ avancer / reculer (selon la caméra) ; molette, Q / X ou Ctrl + ← → tourner à plat, G le rendre à la visée, E poser, Retour arrière annuler
local placing = false
-- déplacement dans le monde pour un axe de caméra rz (degrés) : side droite / gauche, fwd avant / arrière, up haut / bas
local function nudge(rz, side, fwd, up, d)
    local r = math.rad(rz)
    local c, s = math.cos(r), math.sin(r)
    return (c * side - s * fwd) * d, (s * side + c * fwd) * d, up * d
end
local function rotToDir(r) local x, z = math.rad(r.x), math.rad(r.z) return vector3(-math.sin(z) * math.abs(math.cos(x)), math.cos(z) * math.abs(math.cos(x)), math.sin(x)) end
local function aimPoint(ignore)
    local from = GetGameplayCamCoord()
    local to = from + rotToDir(GetGameplayCamRot(2)) * 38.0
    local ray = StartShapeTestRay(from.x, from.y, from.z, to.x, to.y, to.z, 1 + 16, ignore or PlayerPedId(), 0)
    local _, hit, pos = GetShapeTestResult(ray)
    if hit == 1 then return pos end
    return to
end
-- onDone(position, cap) : au lieu de créer un prop permanent, rend le point choisi (nil si annulé) ; sert à la boombox et au déplacement
-- start (facultatif) : { x, y, z, h } : l'aperçu part de cette position (prop déjà posé)
function G.PropPlace(model, label, onDone, start)
    if placing then return end
    if G.PropPreviewStop then G.PropPreviewStop() end   -- (v1.2.43) l'aperçu est défini plus bas : l'appel direct plantait et empêchait toute pose
    local h = joaat(model)
    if not IsModelInCdimage(h) then G.send('notify', { type = 'error', title = 'Props', text = ('Modèle « %s » introuvable dans le jeu.'):format(model) }) if onDone then onDone(nil) end return end
    placing = true
    if G.Menu.Suspend then G.Menu.Suspend() end
    CreateThread(function()
        RequestModel(h)
        local t = GetGameTimer() + 4000
        while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
        if not HasModelLoaded(h) then placing = false if G.Menu.Resume then G.Menu.Resume() end if onDone then onDone(nil) end return end
        local ped = PlayerPedId()
        local c = GetEntityCoords(ped)
        local e = CreateObjectNoOffset(h, c.x, c.y, c.z, false, false, false)
        SetModelAsNoLongerNeeded(h)
        SetEntityAlpha(e, 160, false)
        SetEntityCollision(e, false, false)
        FreezeEntityPosition(e, true)
        local heading, anchor, held = start and start.h or GetEntityHeading(ped), start and vector3(start.x, start.y, start.z) or nil, 0.0
        G.send('prompt', { show = true, free = true, key = 'E', text = ('Poser « %s »  ·  ← → ↑ ↓ déplacer  ·  Maj + ↑ ↓ avancer / reculer  ·  Molette, Q / X ou Ctrl + ← → tourner  ·  G suivre la visée  ·  Retour arrière : annuler'):format(label or model) })
        local done, chosen = false, nil
        while not done do
            Wait(0)
            DisableControlAction(0, 172, true) DisableControlAction(0, 173, true) DisableControlAction(0, 174, true) DisableControlAction(0, 175, true)
            DisableControlAction(0, 200, true) DisableControlAction(0, 24, true) DisableControlAction(0, 25, true)
            for _, k in ipairs({ 14, 15, 16, 17, 21, 36, 44, 47, 73 }) do DisableControlAction(0, k, true) end
            local up, down, left, right = IsDisabledControlPressed(0, 172), IsDisabledControlPressed(0, 173), IsDisabledControlPressed(0, 174), IsDisabledControlPressed(0, 175)
            if IsDisabledControlPressed(0, 36) then   -- Ctrl + ← → : tourner à plat, sans déplacer
                if left then heading = heading + 1.5 end
                if right then heading = heading - 1.5 end
                left, right = false, false
            end
            if up or down or left or right then
                local ft = GetFrameTime()
                held = held + ft
                anchor = anchor or GetEntityCoords(e)
                -- une pression brève ajuste au centimètre, une pression longue va plus vite
                local v, shift = (up and 1 or 0) - (down and 1 or 0), IsDisabledControlPressed(0, 21)
                local dx, dy, dz = nudge(GetGameplayCamRot(2).z, (right and 1 or 0) - (left and 1 or 0), shift and v or 0, shift and 0 or v, math.min(2.0, 0.25 + held * 1.2) * ft)
                local to = anchor + vector3(dx, dy, dz)
                if #(to - GetEntityCoords(PlayerPedId())) < 38.0 then anchor = to end   -- le serveur refuse au-delà de sa distance de pose
            else held = 0.0 end
            if IsDisabledControlPressed(0, 44) then heading = heading + 1.5 end
            if IsDisabledControlPressed(0, 73) then heading = heading - 1.5 end
            if IsDisabledControlJustPressed(0, 15) then heading = heading + 5.0 end
            if IsDisabledControlJustPressed(0, 14) then heading = heading - 5.0 end
            if IsDisabledControlJustPressed(0, 47) then anchor = nil end
            local p = anchor or aimPoint(e)
            SetEntityCoordsNoOffset(e, p.x, p.y, p.z, false, false, false)
            SetEntityHeading(e, heading % 360.0)
            SetEntityDrawOutline(e, true)
            SetEntityDrawOutlineColor(255, 255, 255, 255)
            if IsControlJustPressed(0, 38) then
                local pos = GetEntityCoords(e)
                if onDone then chosen = { pos, heading % 360.0 }
                else TriggerServerEvent('pb:g:props:place', { model = model, label = label or '', x = pos.x, y = pos.y, z = pos.z, h = heading % 360.0 }) end
                done = true
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then done = true end
        end
        SetEntityDrawOutline(e, false)
        DeleteEntity(e)
        G.send('prompt', { show = false })
        placing = false
        if G.Menu.Resume then G.Menu.Resume() end
        if onDone then onDone(chosen and chosen[1] or nil, chosen and chosen[2] or nil) end
    end)
end

-- Catalogue intégré, trié par thème (les modèles ajoutés dans le panel arrivent dans « Ajoutés par le serveur »)
local CATALOG = {
    { 'Télés et écrans (ALT : diffuser une vidéo)', 'eye', {
        { 'prop_tv_flat_01', 'Télé écran plat' }, { 'prop_tv_flat_02', 'Télé écran plat 2' }, { 'prop_tv_flat_02b', 'Télé écran plat 3' }, { 'prop_tv_flat_03', 'Petite télé plate' },
        { 'prop_tv_flat_03b', 'Petite télé plate 2' }, { 'prop_tv_flat_michael', 'Grande télé de salon' }, { 'prop_trev_tv_01', 'Télé de caravane' }, { 'prop_tv_02', 'Vieille télé' },
        { 'prop_tv_03', 'Vieille télé 2' }, { 'prop_tv_06', 'Vieille télé 3' }, { 'prop_monitor_w_large', 'Grand moniteur' }, { 'prop_monitor_02', 'Moniteur de bureau' },
        { 'prop_laptop_lester2', 'Ordinateur portable' }, { 'prop_huge_display_01', 'Grand écran' }, { 'prop_huge_display_02', 'Grand écran 2' }, { 'v_ilev_cin_screen', 'Écran de cinéma' } } },
    { 'Barrières et signalisation', 'shield', {
        { 'prop_barrier_work05', 'Barrière de chantier' }, { 'prop_barrier_work06a', 'Barrière de chantier (longue)' }, { 'prop_mp_barrier_02b', 'Barrière de police' },
        { 'prop_mp_barrier_01', 'Barrière de sécurité' }, { 'prop_barier_conc_05a', 'Muret béton' }, { 'prop_mp_arrow_barrier_01', 'Panneau flèche' },
        { 'prop_roadcone02a', 'Cône' }, { 'prop_mp_cone_02', 'Cône (grand)' }, { 'prop_consign_01a', 'Panneau travaux' } } },
    { 'Mobilier', 'home', {
        { 'prop_table_03', 'Table' }, { 'prop_chair_01a', 'Chaise' }, { 'prop_bench_01a', 'Banc' }, { 'prop_off_chair_01', 'Chaise de bureau' },
        { 'prop_couch_01', 'Canapé' }, { 'prop_patio_lounger1', 'Transat' }, { 'prop_table_para_comb_04', 'Table avec parasol' }, { 'prop_parasol_04b', 'Parasol' } } },
    { 'Événements', 'star', {
        { 'prop_tent_01', 'Tente' }, { 'prop_gazebo_02', 'Barnum' }, { 'prop_bbq_1', 'Barbecue' }, { 'prop_beach_fire', 'Feu de camp' },
        { 'prop_speaker_06', 'Enceinte (ALT : mettre de la musique)' }, { 'prop_flag_france', 'Drapeau France' }, { 'prop_flag_us', 'Drapeau USA' }, { 'prop_portaloo_01a', 'Toilettes mobiles' } } },
    { 'DJ et musique', 'music', {
        { 'ba_prop_battle_dj_mixer_01a', 'Table de mixage (ALT : mettre de la musique)' }, { 'ba_prop_battle_dj_kit_mixer', 'Table de mixage compacte' },
        { 'ba_prop_battle_dj_deck_01a', 'Platines DJ (ALT : mettre de la musique)' }, { 'ba_prop_battle_dj_stand', 'Pupitre DJ (ALT : mettre de la musique)' }, { 'ba_prop_battle_dj_kit_speaker', 'Enceinte de DJ (ALT : mettre de la musique)' },
        { 'prop_speaker_06', 'Enceinte (ALT : mettre de la musique)' }, { 'prop_huge_display_01', 'Grand écran (ALT : diffuser une vidéo)' } } },
    { 'Éclairage et énergie', 'bolt', {
        { 'prop_worklight_03b', 'Projecteur' }, { 'prop_worklight_04b', 'Projecteur sur pied' }, { 'prop_streetlight_01', 'Lampadaire' }, { 'prop_generator_03b', 'Groupe électrogène' } } },
    { 'Chantier et stockage', 'box', {
        { 'prop_boxpile_07d', 'Pile de cartons' }, { 'prop_pallet_02a', 'Palette' }, { 'prop_cementbags01', 'Sacs de ciment' }, { 'prop_toolchest_05', 'Servante à outils' },
        { 'prop_container_01a', 'Conteneur' }, { 'prop_dumpster_01a', 'Benne' }, { 'prop_portacabin01', 'Algeco' } } },
    { 'Divers', 'tag', {
        { 'prop_fire_exting_1a', 'Extincteur' }, { 'prop_bin_05a', 'Poubelle' }, { 'prop_atm_01', 'Distributeur (décor)' }, { 'prop_vend_soda_01', 'Distributeur de boissons' },
        { 'prop_vend_snak_01', 'Distributeur de snacks' }, { 'prop_pot_plant_01a', 'Plante en pot' } } },
}

-- Aperçu au survol : un fantôme du modèle tourne devant toi tant que la liste est ouverte
local pv = { model = nil, ent = nil, run = false }
local function previewStop()
    pv.model = nil
    if pv.ent and DoesEntityExist(pv.ent) then DeleteEntity(pv.ent) end
    pv.ent = nil
end
local function previewSet(model)
    if pv.model == model then return end
    previewStop()
    if not model then return end
    local h = joaat(model)
    if not IsModelInCdimage(h) then return end
    pv.model = model
    if pv.run then return end
    pv.run = true
    CreateThread(function()
        local spin, cur = 0.0, nil
        while pv.model and G.Menu.IsOpen() and not placing do
            if cur ~= pv.model then
                cur = pv.model
                if pv.ent and DoesEntityExist(pv.ent) then DeleteEntity(pv.ent) end
                pv.ent = nil
                local h = joaat(cur)
                RequestModel(h)
                local t = GetGameTimer() + 3000
                while not HasModelLoaded(h) and GetGameTimer() < t and pv.model == cur do Wait(10) end
                if HasModelLoaded(h) and pv.model == cur then
                    local c = GetEntityCoords(PlayerPedId())
                    pv.ent = CreateObjectNoOffset(h, c.x, c.y, c.z - 50.0, false, false, false)
                    SetEntityAlpha(pv.ent, 190, false)
                    SetEntityCollision(pv.ent, false, false)
                    FreezeEntityPosition(pv.ent, true)
                    SetModelAsNoLongerNeeded(h)
                end
            end
            local e = pv.ent
            if e and DoesEntityExist(e) then
                local mn, mx = GetModelDimensions(GetEntityModel(e))
                local size = math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z)
                local ped = PlayerPedId()
                local dist = math.min(14.0, 1.6 + size * 1.1)
                local p = GetOffsetFromEntityInWorldCoords(ped, 0.0, dist, 0.0)
                local ok, gz = GetGroundZFor_3dCoord(p.x, p.y, p.z + 2.0, false)
                SetEntityCoordsNoOffset(e, p.x, p.y, (ok and gz or (p.z - 1.0)) - mn.z, false, false, false)
                spin = (spin + 0.6) % 360.0
                SetEntityHeading(e, spin)
                SetEntityDrawOutline(e, true)
                SetEntityDrawOutlineColor(255, 255, 255, 200)
            end
            Wait(0)
        end
        pv.run = false
        previewStop()
    end)
end
G.PropPreviewStop = previewStop

-- Tous les props du jeu (data/props.txt, fait par outils/liste_props.py) : lus une seule fois, à la première ouverture
local allProps
local function loadAll()
    if allProps then return allProps end
    allProps = {}
    local cur
    for line in (LoadResourceFile(GetCurrentResourceName(), 'data/props.txt') or ''):gmatch('[^\r\n]+') do
        local title, icon = line:match('^# (.-)|(.+)$')
        if title then cur = { title = title, icon = icon, names = {} } allProps[#allProps + 1] = cur
        elseif cur then cur.names[#cur.names + 1] = line end
    end
    return allProps
end
-- tous les mots cherchés doivent être dans le nom ; limit : nombre de résultats gardés. Renvoie aussi le total trouvé.
local function searchAll(text, limit)
    local words, out, total = {}, {}, 0
    for w in tostring(text or ''):lower():gmatch('[^%s]+') do words[#words + 1] = w end
    if #words == 0 then return out, 0 end
    for _, c in ipairs(loadAll()) do
        for _, n in ipairs(c.names) do
            local ok = true
            for _, w in ipairs(words) do if not n:find(w, 1, true) then ok = false break end end
            if ok then total = total + 1 if #out < limit then out[#out + 1] = n end end
        end
    end
    return out, total
end
G.PropsSearch = searchAll

-- Menu staff F10 › Props permanents
local presets = {}
RegisterNetEvent('pb:g:props:presets', function(j) presets = G.decode(j) or {} if G.Menu.IsOpen() then G.Menu.Refresh() end end)
local hl
local function highlight(id)
    if hl and spawned[hl] and spawned[hl] ~= 0 and DoesEntityExist(spawned[hl]) then SetEntityDrawOutline(spawned[hl], false) end
    hl = id
    local e = id and spawned[id]
    if e and e ~= 0 and DoesEntityExist(e) then SetEntityDrawOutline(e, true) SetEntityDrawOutlineColor(255, 200, 80, 255) end
end
-- Actions sur un prop posé (Props proches, menu ALT). afterRemove : suite du menu une fois le prop retiré. useCmd : la commande de l'objet (musique, télé…)
local function propActions(id, p, afterRemove, useCmd)
    local name = (p.l ~= '' and p.l) or p.m
    local items = {}
    if useCmd then items[#items + 1] = { label = 'Utiliser', icon = 'music', description = 'Musique, vidéo ou autre usage de cet objet.', onSelect = function() highlight(nil) G.Menu.Close() ExecuteCommand(useCmd) end } end
    items[#items + 1] = { label = 'Déplacer et tourner', icon = 'arrow', description = "Il reprend sa place dans le mode de pose : E pour valider, Retour arrière pour le laisser où il était.", onSelect = function()
        highlight(nil)
        moving = id
        remove(id)
        G.PropPlace(p.m, name, function(pos, heading)
            moving = nil
            if pos then TriggerServerEvent('pb:g:props:move', id, { x = pos.x, y = pos.y, z = pos.z, h = heading }) end
        end, { x = p.x, y = p.y, z = p.z, h = p.h or 0.0 })
    end }
    items[#items + 1] = { label = 'Dupliquer', icon = 'plus', description = 'Pose une copie, à placer où tu veux : E pour valider, Retour arrière pour annuler.', onSelect = function()
        highlight(nil)
        G.PropPlace(p.m, name, nil, { x = p.x, y = p.y, z = p.z, h = p.h or 0.0 })
    end }
    items[#items + 1] = { label = 'Retirer', icon = 'trash', onSelect = function() highlight(nil) TriggerServerEvent('pb:g:props:remove', id) afterRemove() end }
    return items
end
-- Menu ALT : les props posés à portée, et le menu d'un prop
function G.PropsSpawned() return spawned end
function G.PropIdOf(ent) for id, e in pairs(spawned) do if e == ent then return id end end end
function G.PropMenu(id, useCmd)
    local p = list[id]
    if not p then return end
    highlight(id)
    G.Menu.Open({ id = 'staff.props.alt', title = (p.l ~= '' and p.l) or p.m, subtitle = 'Prop posé', onClose = function() highlight(nil) end, items = propActions(id, p, function() G.Menu.Close() end, useCmd) })
end
function G.PropsItems()
    if #presets == 0 then TriggerServerEvent('pb:g:props:presets') end
    local function pickItem(m, l) return { label = l, right = m ~= l and m or nil, pm = m, description = 'Aperçu devant toi au survol. Entrée : le placer (E pour poser).', onSelect = function() previewStop() G.PropPlace(m, l) end } end
    local function pickMenu(id, title, items)
        return { id = id, title = title, subtitle = 'Survole pour prévisualiser', items = items,
            onHover = function(it) previewSet(it and it.pm or nil) end,
            onOpen = function(m) local it = m.items[m.sel or 1] previewSet(it and it.pm or nil) end,
            onClose = function() previewStop() end }
    end
    local known, pick = {}, {}
    for _, cat in ipairs(CATALOG) do
        local items = {}
        for _, p in ipairs(cat[3]) do
            known[p[1]] = true
            if IsModelInCdimage(joaat(p[1])) then items[#items + 1] = pickItem(p[1], p[2]) end
        end
        table.sort(items, function(a, b) return a.label < b.label end)
        if #items > 0 then pick[#pick + 1] = { type = 'submenu', label = cat[1], icon = cat[2], right = tostring(#items), submenu = pickMenu('staff.props.c.' .. #pick, cat[1], items) } end
    end
    local extra = {}
    for _, p in ipairs(presets) do if not known[p.m] then extra[#extra + 1] = pickItem(p.m, p.l) end end
    if #extra > 0 then
        table.sort(extra, function(a, b) return a.label < b.label end)
        pick[#pick + 1] = { type = 'submenu', label = 'Ajoutés par le serveur', icon = 'list', right = tostring(#extra), description = 'Modèles ajoutés dans le panel (Props › Modèles proposés).', submenu = pickMenu('staff.props.c.srv', 'Ajoutés par le serveur', extra) }
    end
    -- tous les props du jeu : par thème, 100 par page (seuls ceux présents sur cette version du jeu sont affichés)
    local function pageOf(id, title, names, from, sub)
        local items = {}
        for i = from, math.min(#names, from + 99) do
            if IsModelInCdimage(joaat(names[i])) then items[#items + 1] = pickItem(names[i], names[i]) end
        end
        if #names >= from + 100 then
            items[#items + 1] = { label = 'Page suivante', icon = 'plus', right = ('%d à %d sur %d'):format(from + 100, math.min(#names, from + 199), #names), onSelect = function() previewStop() G.Menu.Push(pageOf(id, title, names, from + 100, sub)) end }
        end
        if #items == 0 then items[1] = { label = 'Aucun prop à afficher', disabled = true } end
        local def = pickMenu(id .. '.' .. from, title, items)
        def.subtitle = sub or def.subtitle
        return def
    end
    local function allItems()
        local all, count = {}, 0
        all[1] = { label = 'Rechercher un prop…', icon = 'eye', description = 'Un ou plusieurs mots du nom en anglais : chair, tv, fence, bbq…', onSelect = function()
            local q = G.Menu.Ask('Mot à chercher (en anglais)', '', 40)
            if not q or q == '' then return end
            local names, total = searchAll(q, 300)
            G.Menu.Push(pageOf('staff.props.s', 'Recherche : ' .. q:sub(1, 24), names, 1, total > 300 and ('300 premiers sur ' .. total .. ' : précise ta recherche') or (total .. ' résultat(s)')))
        end }
        all[2] = { type = 'separator', label = 'Par thème' }
        for i, c in ipairs(loadAll()) do
            count = count + #c.names
            all[#all + 1] = { label = c.title, icon = c.icon, right = tostring(#c.names), onSelect = function() G.Menu.Push(pageOf('staff.props.t' .. i, c.title, c.names, 1)) end }
        end
        return all, count
    end
    pick[#pick + 1] = { type = 'separator', label = 'Autre' }
    pick[#pick + 1] = { label = 'Tous les props du jeu', icon = 'box', description = 'Toute la liste du jeu, par thème ou par recherche.', onSelect = function()
        local all, count = allItems()
        G.Menu.Push({ id = 'staff.props.all', title = 'Tous les props du jeu', subtitle = count .. ' props', items = all })
    end }
    pick[#pick + 1] = { label = 'Autre modèle…', icon = 'edit', description = 'Tape le nom technique du modèle (ex. prop_barrier_work05).', onSelect = function()
        local m = G.Menu.Ask('Nom du modèle', '', 64)
        if m and m:match('^[%w_]+$') then G.PropPlace(m:lower(), m:lower()) end
    end }
    local me = GetEntityCoords(PlayerPedId())
    local near = {}
    for id, p in pairs(list) do
        local d = #(me - vector3(p.x, p.y, p.z))
        if d < 60.0 then near[#near + 1] = { id = id, p = p, d = d } end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    local nearItems = {}
    for _, n in ipairs(near) do
        local name = (n.p.l ~= '' and n.p.l) or n.p.m
        nearItems[#nearItems + 1] = { type = 'submenu', label = name, right = math.floor(n.d + 0.5) .. ' m', pid = n.id, description = 'Entouré à l\'écran. Entrée : le déplacer, le dupliquer ou le retirer.',
            submenu = { id = 'staff.props.one', title = name, subtitle = 'Prop posé', onOpen = function() highlight(n.id) end, items = propActions(n.id, n.p, function() G.Menu.Stack:Back() G.Menu.Stack:Back() G.Menu.Refresh() end) } }
    end
    if #nearItems == 0 then nearItems[1] = { label = 'Aucun prop à moins de 60 m', disabled = true } end
    return {
        { type = 'submenu', label = 'Poser un prop', icon = 'plus', description = 'Catalogue trié par thème, aperçu au survol, puis E pour poser. Il reste après un redémarrage.', submenu = { id = 'staff.props.pick', title = 'Poser un prop', items = pick } },
        { type = 'submenu', label = 'Props proches', icon = 'box', right = tostring(#near), description = 'Le prop survolé est entouré.', submenu = { id = 'staff.props.near', title = 'Props proches', items = nearItems,
            onHover = function(it) highlight(it and it.pid or nil) end, onOpen = function(m) local it = m.items[m.sel or 1] highlight(it and it.pid or nil) end, onClose = function() highlight(nil) end } },
    }
end
