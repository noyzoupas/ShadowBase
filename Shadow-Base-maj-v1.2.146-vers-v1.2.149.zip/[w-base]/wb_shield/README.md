# wb_shield — protection contre le déclenchement d'évènements

Un menu de triche déclenche des évènements serveur « à l'aveugle » (donner de l'argent, un objet, une arme…). wb_shield exige un **jeton signé** sur les évènements protégés : sans lui (ou avec un faux, ou rejoué), l'évènement est signalé et, en mode `block`, refusé.

## Fonctionnement
- Le serveur donne à chaque joueur un secret de session. Côté client, `TriggerServerEvent` ajoute un jeton `aléa:signature` aux évènements que le serveur a déclarés protégés ; le serveur le vérifie puis le retire (tes scripts ne voient aucun changement d'arguments).
- Un jeton ne sert qu'une fois (anti-rejeu). Un même évènement ne peut être appelé que `wb_shield_rate` fois / 10 s par joueur.
- Les alertes arrivent dans l'anticheat du panel (« Évènement sans jeton valide », « Évènement déclenché en rafale »).

## Installation (console du serveur, pas en jeu)
1. `ensure wb_shield` **avant** les ressources à protéger dans `server.cfg`.
2. `shield_install all dry` : liste ce qui serait modifié ; puis `shield_install pb_panel` (ou `all`). La commande ajoute `shared_script '@wb_shield/shield.lua'` aux `fxmanifest.lua` (sauvegarde `fxmanifest.lua.wbshield.bak`). Les ressources sous escrow (`.fxap`) sont ignorées.
3. Redémarre le serveur. **Un `wupdate` remet les manifestes d'origine** : relance `shield_install` après.
4. `shield_remove <ressource|all>` retire la ligne. `shield_status` affiche les compteurs.

## Réglages (server.cfg)
```
set wb_shield_mode "log"      # log = signale et laisse passer (défaut) | block = refuse
set wb_shield_rate 60         # appels max par joueur, évènement et 10 s
set wb_shield_ignore "evt:a,evt:b"   # évènements exclus
```
## Mise en route conseillée
1. Reste en `log` plusieurs jours. Toute alerte « sans jeton » d'un joueur légitime montre un évènement à exclure (`wb_shield_ignore`) ou une ressource à protéger aussi.
2. Passe en `block` seulement quand les alertes légitimes ont disparu. Mets l'anticheat du panel en « Expulser » pour les deux nouvelles détections ensuite.

## Limites honnêtes
- Vérifié par simulation uniquement, pas dans un vrai client FiveM. Teste sur un serveur de test.
- Un cheat qui lit la mémoire du client peut récupérer le secret et signer ses évènements : wb_shield bloque les menus « à l'aveugle », pas un attaquant qui connaît le système.
- Une ressource non protégée qui écoute un évènement protégé reçoit le jeton comme premier argument : protège toutes les ressources concernées ou exclus l'évènement.
- Les évènements locaux (`TriggerEvent` côté serveur) ne sont pas vérifiés.
