-- wb_shield (serveur) : secret de session par joueur, vérification des jetons, anti-rejeu, limite de débit, installation dans les ressources.
--   convar wb_shield_mode   = log (défaut : signale, laisse passer) | block (refuse l'évènement)
--   convar wb_shield_rate   = appels max par joueur, évènement et 10 s (défaut 60)
--   convar wb_shield_ignore = évènements exclus, séparés par des virgules
local secrets, names, nameList, seen, rates, memo, lastFlag = {}, {}, {}, {}, {}, {}, {}
local stats = { ok = 0, bad = 0, flood = 0, notoken = 0 }

local function mode() return GetConvar('wb_shield_mode', 'log') == 'block' and 'block' or 'log' end
local function rateMax() return tonumber(GetConvar('wb_shield_rate', '60')) or 60 end

local function mix(s)
    local h = 0xcbf29ce484222325
    for i = 1, #s do h = (h ~ s:byte(i)) * 0x100000001b3 end
    h = h ~ (h >> 29); h = h * 0xbf58476d1ce4e5b9; h = h ~ (h >> 32)
    return string.format('%x', h)
end
local function newSecret()
    local t = {}
    for i = 1, 4 do t[i] = string.format('%08x', math.random(0, 0x7fffffff)) end
    return table.concat(t)
end
local function ensure(src)
    if not secrets[src] then secrets[src] = newSecret() seen[src] = { set = {}, order = {} } end
    return secrets[src]
end

local function report(src, kind, detail)
    local k = src .. kind .. detail
    if (lastFlag[k] or 0) > os.time() - 60 then return end            -- une alerte par minute et par cause
    lastFlag[k] = os.time()
    print(('[wb_shield] %s #%d — %s'):format(kind, src, detail))
    pcall(function() exports.pb_panel:AntiCheatFlag(src, kind, detail) end)
end

AddEventHandler('playerJoining', function() ensure(source) end)
AddEventHandler('playerDropped', function() local s = source secrets[s], seen[s], rates[s], memo[s] = nil, nil, nil, nil end)

RegisterNetEvent('wb_shield:hello', function()
    local src = source
    local r = rates[src] or {}
    rates[src] = r
    local k = 'hello'
    r[k] = r[k] or { t0 = os.time(), n = 0 }
    if os.time() - r[k].t0 > 60 then r[k] = { t0 = os.time(), n = 0 } end
    r[k].n = r[k].n + 1
    if r[k].n > 30 then return end
    TriggerClientEvent('wb_shield:init', src, ensure(src), nameList)
end)

exports('Declare', function(list)
    local fresh = {}
    for _, n in ipairs(type(list) == 'table' and list or {}) do
        if not names[n] then names[n] = true nameList[#nameList + 1] = n fresh[#fresh + 1] = n end
    end
    if #fresh > 0 then TriggerClientEvent('wb_shield:add', -1, fresh) end
end)

-- Retourne false si l'évènement doit être refusé, true sinon.
exports('Check', function(src, name, token, res)
    local sec = secrets[src]
    if not sec then return true end                                         -- joueur pas encore connu : on ne bloque pas
    local m = memo[src]
    if token and m and m.tok == token and GetGameTimer() - m.t <= 30 then return m.ok end   -- plusieurs écouteurs du même évènement
    local ok, why = true, nil
    -- débit
    local r = rates[src] or {}
    rates[src] = r
    local rk = 'e:' .. name
    r[rk] = r[rk] or { t0 = os.time(), n = 0 }
    if os.time() - r[rk].t0 >= 10 then r[rk] = { t0 = os.time(), n = 0 } end
    r[rk].n = r[rk].n + 1
    if r[rk].n > rateMax() then
        stats.flood = stats.flood + 1
        report(src, 'event_flood', ('%s appelé %d fois en 10 s (ressource %s)'):format(name, r[rk].n, tostring(res)))
        if mode() == 'block' then ok = false end
    end
    -- jeton
    if ok then
        if not token then
            stats.notoken = stats.notoken + 1
            report(src, 'event_token', ('%s appelé sans jeton (ressource %s)'):format(name, tostring(res)))
            if mode() == 'block' then ok = false end
        else
            local rnd, sig = token:match('^(%d+):(%x+)$')
            local sv = seen[src]
            if not rnd or sig ~= mix(sec .. '|' .. name .. '|' .. rnd) then
                stats.bad = stats.bad + 1
                report(src, 'event_token', ('%s avec un jeton faux (ressource %s)'):format(name, tostring(res)))
                if mode() == 'block' then ok = false end
            elseif sv.set[token] then
                stats.bad = stats.bad + 1
                report(src, 'event_token', ('%s rejoué (jeton déjà utilisé, ressource %s)'):format(name, tostring(res)))
                if mode() == 'block' then ok = false end
            else
                sv.set[token] = true
                sv.order[#sv.order + 1] = token
                if #sv.order > 2000 then sv.set[table.remove(sv.order, 1)] = nil end
                stats.ok = stats.ok + 1
            end
        end
    end
    if token then memo[src] = { tok = token, t = GetGameTimer(), ok = ok } end
    return ok
end)
exports('Stats', function() local n = 0 for _ in pairs(names) do n = n + 1 end return { mode = mode(), events = n, ok = stats.ok, bad = stats.bad, flood = stats.flood, notoken = stats.notoken } end)

-- Console du serveur ----------------------------------------------------------------------------------------------------------------------
local LINE = "shared_script '@wb_shield/shield.lua'"
local NEVER = { wb_shield = true, oxmysql = true, chat = true, spawnmanager = true, sessionmanager = true, mapmanager = true, hardcap = true, baseevents = true, ['rconlog'] = true, webpack = true, yarn = true, monitor = true }
local function eligible(res)
    if NEVER[res] or res:find('^cfx') or res:find('^fivem') then return false end
    local f = LoadResourceFile(res, 'fxmanifest.lua')
    if not f then return false end
    if f:find('wb_shield/shield.lua', 1, true) then return false, 'déjà' end
    if LoadResourceFile(res, '.fxap') then return false, 'protégée (escrow)' end
    if not (f:find('client_script') or f:find('server_script')) then return false end
    return true, f
end
local function cmd(name, fn) RegisterCommand(name, function(src, args) if src ~= 0 then return end fn(args) end, true) end

cmd('shield_status', function()
    local s = exports.wb_shield:Stats()
    print(('[wb_shield] mode %s — %d évènements protégés — %d jetons valides, %d faux/rejoués, %d sans jeton, %d en rafale'):format(s.mode, s.events, s.ok, s.bad, s.notoken, s.flood))
end)
cmd('shield_install', function(a)
    local target, dry = a[1], a[2] == 'dry' or a[1] == 'dry'
    if not target or target == 'dry' then print('[wb_shield] usage : shield_install <ressource|all> [dry]') return end
    local n = 0
    for i = 0, GetNumResources() - 1 do
        local res = GetResourceByFindIndex(i)
        if res and (target == 'all' or target == res) then
            local ok, f = eligible(res)
            if ok then
                n = n + 1
                if dry then print('[wb_shield] (simulation) ' .. res)
                else
                    SaveResourceFile(res, 'fxmanifest.lua.wbshield.bak', f, -1)
                    SaveResourceFile(res, 'fxmanifest.lua', f .. '\n\n' .. LINE .. '\n', -1)
                    print('[wb_shield] ajouté à ' .. res .. ' (sauvegarde : fxmanifest.lua.wbshield.bak)')
                end
            elseif f and target == res then print('[wb_shield] ' .. res .. ' : ' .. tostring(f)) end
        end
    end
    print(('[wb_shield] %d ressource(s)%s. Redémarre-les (ou le serveur) pour appliquer. Un wupdate remet les manifestes d\'origine : relance la commande ensuite.'):format(n, dry and ' (simulation)' or ' modifiée(s)'))
end)
cmd('shield_remove', function(a)
    local target = a[1]
    if not target then print('[wb_shield] usage : shield_remove <ressource|all>') return end
    local n = 0
    for i = 0, GetNumResources() - 1 do
        local res = GetResourceByFindIndex(i)
        if res and (target == 'all' or target == res) then
            local f = LoadResourceFile(res, 'fxmanifest.lua')
            if f and f:find('wb_shield/shield.lua', 1, true) then
                SaveResourceFile(res, 'fxmanifest.lua', (f:gsub("\n*shared_script '@wb_shield/shield%.lua'\n*", '\n')), -1)
                n = n + 1
                print('[wb_shield] retiré de ' .. res)
            end
        end
    end
    print(('[wb_shield] %d ressource(s) nettoyée(s).'):format(n))
end)
