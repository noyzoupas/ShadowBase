-- wb_shield : script partagé, ajouté (par `shield_install`) aux ressources à protéger.
--  * côté client, TriggerServerEvent ajoute un jeton signé à chaque évènement que le serveur a déclaré protégé ;
--  * côté serveur, RegisterNetEvent / AddEventHandler vérifient ce jeton avant d'appeler le script, puis le retirent des arguments (le script ne voit rien de changé) ;
--  * un jeton ne sert qu'une fois (anti-rejeu) et le nombre d'appels par joueur et par évènement est limité.
-- Rien ici n'arrête un cheat qui lit la mémoire du jeu pour récupérer le secret de session : il bloque les menus qui déclenchent des évènements « à l'aveugle ».
local RES = GetCurrentResourceName()
if RES == 'wb_shield' then return end
local isServer = IsDuplicityVersion()

local function mix(s)
    local h = 0xcbf29ce484222325
    for i = 1, #s do h = (h ~ s:byte(i)) * 0x100000001b3 end
    h = h ~ (h >> 29); h = h * 0xbf58476d1ce4e5b9; h = h ~ (h >> 32)
    return string.format('%x', h)
end
local function ignored()
    local set = {}
    for n in tostring(GetConvar('wb_shield_ignore', '')):gmatch('[^,%s]+') do set[n] = true end
    return set
end
local SKIP = { '^__cfx', '^cfx', '^chat:', '^txAdmin', '^txsv:', '^wb_shield:', '^playerJoining$', '^playerDropped$', '^onResource', '^onClientResource', '^onServerResource', '^baseevents:', '^mapmanager', '^sessionmanager', '^hardcap', '^rconCommand$' }
local function skipName(name)
    if type(name) ~= 'string' then return true end
    for _, p in ipairs(SKIP) do if name:find(p) then return true end end
    return false
end

------------------------------------------------------------------------------------------------------------------------------------
if not isServer then
    local rawTrigger, rawLatent = TriggerServerEvent, TriggerLatentServerEvent
    local secret, protected, queue = nil, {}, {}
    math.randomseed(GetGameTimer() + math.floor(GetFrameTime() * 1000000))

    local function tokenFor(name)
        local r = math.random(1, 2147483647)
        return r .. ':' .. mix(secret .. '|' .. name .. '|' .. r)
    end
    local function dispatch(latent, name, bps, args)
        if secret and protected[name] then
            if latent then rawLatent(name, bps, tokenFor(name), table.unpack(args, 1, args.n))
            else rawTrigger(name, tokenFor(name), table.unpack(args, 1, args.n)) end
        else
            if latent then rawLatent(name, bps, table.unpack(args, 1, args.n)) else rawTrigger(name, table.unpack(args, 1, args.n)) end
        end
    end
    local function flush()
        local q = queue
        queue = {}
        for _, e in ipairs(q) do dispatch(e[1], e[2], e[3], e[4]) end
    end
    TriggerServerEvent = function(name, ...)
        if not secret and not skipName(name) then
            if #queue < 300 then queue[#queue + 1] = { false, name, nil, table.pack(...) } end
            return
        end
        dispatch(false, name, nil, table.pack(...))
    end
    TriggerLatentServerEvent = function(name, bps, ...)
        if not secret and not skipName(name) then
            if #queue < 300 then queue[#queue + 1] = { true, name, bps, table.pack(...) } end
            return
        end
        dispatch(true, name, bps, table.pack(...))
    end

    RegisterNetEvent('wb_shield:init', function(sec, list)
        if type(sec) ~= 'string' or secret then return end
        secret = sec
        for _, n in ipairs(type(list) == 'table' and list or {}) do protected[tostring(n)] = true end
        flush()
    end)
    RegisterNetEvent('wb_shield:add', function(list)
        for _, n in ipairs(type(list) == 'table' and list or {}) do protected[tostring(n)] = true end
    end)
    CreateThread(function()
        Wait(500)
        rawTrigger('wb_shield:hello', RES)
        Wait(15000)
        if not secret then secret = '' flush() end   -- serveur sans protection : on n'attend pas indéfiniment
    end)
    return
end

------------------------------------------------------------------------------------------------------------------------------------
local rawRegister, rawAdd = RegisterNetEvent, AddEventHandler
local netNames, pending, flushing = {}, {}, false
local skip = ignored()

local function declare(name)
    if netNames[name] or skip[name] or skipName(name) then return end
    netNames[name] = true
    pending[#pending + 1] = name
    if not flushing then
        flushing = true
        SetTimeout(250, function()
            flushing = false
            local l = pending
            pending = {}
            pcall(function() exports['wb_shield']:Declare(l) end)
        end)
    end
end

local function guard(name, fn)
    return function(...)
        local n = tonumber(source)
        if not n or n <= 0 or GetInvokingResource() then return fn(...) end          -- évènement local : rien à vérifier
        local first = ...
        local hasTok = type(first) == 'string' and first:match('^%d+:%x+$') ~= nil
        local ok, verdict = pcall(function() return exports['wb_shield']:Check(n, name, hasTok and first or nil, RES) end)
        if ok and verdict == false then return end                                     -- bloqué (mode « block »)
        if hasTok then return fn(select(2, ...)) end
        return fn(...)
    end
end

RegisterNetEvent = function(name, fn)
    local h = rawRegister(name)
    if type(name) == 'string' then declare(name) end
    if type(fn) == 'function' then return rawAdd(name, (netNames[name] and guard(name, fn)) or fn) end
    return h
end
RegisterServerEvent = RegisterNetEvent
AddEventHandler = function(name, fn)
    if netNames[name] and type(fn) == 'function' then return rawAdd(name, guard(name, fn)) end
    return rawAdd(name, fn)
end
