-- Anticheat (suite) : dégâts truqués, tirs impossibles, projectiles, armes retirées, entités et chat en rafale, pseudos, et rapports du client recoupés par le serveur.
-- Même philosophie que anticheat.lua : le serveur décide, les détections de comportement sont réglées sur « Journaliser » tant qu'elles ne sont pas éprouvées, et `anticheat.bypass` n'est jamais sanctionné.
local G = PB.G
local AC = PB.AC
if not AC then return end
local cfg, Flag, tracked, bump, cancel = AC.Cfg, AC.Flag, AC.Tracked, AC.bump, AC.Cancel
local function on(src) return src and cfg('enabled') ~= false and not AC.Bypass(src) end
local function lowerSet(l) local t = {} for _, v in ipairs(l or {}) do t[GetHashKey(tostring(v):lower())] = tostring(v):lower() end return t end

-- Dégâts truqués et tirs impossibles ---------------------------------------------------------------------------------------------------------
AddEventHandler('weaponDamageEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    local dmg = tonumber(d.weaponDamage) or 0
    if d.overrideDefaultDamage and dmg > (tonumber(cfg('dmg_max')) or 400) then
        if AC.ModeOf('damage_mod') ~= 'log' then cancel() end
        Flag(src, 'damage_mod', ('%d dégâts en un coup (arme %s)'):format(dmg, tostring(d.weaponType)))
        return
    end
    local gid = tonumber(d.hitGlobalId)
    if gid and gid ~= 0 and NetworkGetEntityFromNetworkId then
        local tgt = NetworkGetEntityFromNetworkId(gid)
        local ped = GetPlayerPed(src)
        if tgt and tgt ~= 0 and ped and ped ~= 0 then
            local a, b = GetEntityCoords(ped), GetEntityCoords(tgt)
            local dist = #(a - b)
            if dist > (tonumber(cfg('hit_range')) or 900) then
                if AC.ModeOf('hit_far') ~= 'log' then cancel() end
                Flag(src, 'hit_far', ('cible touchée à %d m'):format(math.floor(dist)))
            end
        end
    end
end)

-- Projectiles ---------------------------------------------------------------------------------------------------------------------------------
local bp
AddEventHandler('startProjectileEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    bp = bp or lowerSet(cfg('projectiles'))
    local name = bp[d.weaponHash] or bp[d.projectileHash]
    local n = bump(src, 'projectile', 10)
    if name then cancel() Flag(src, 'projectile', 'projectile interdit : ' .. name)
    elseif n > (tonumber(cfg('proj_max')) or 8) then cancel() if n == (tonumber(cfg('proj_max')) or 8) + 1 then Flag(src, 'projectile', ('%d projectiles en 10 s'):format(n)) end end
end)
PB.Cfg.OnChange('anticheat', function() bp = nil end)

-- Désarmer un autre joueur --------------------------------------------------------------------------------------------------------------------
AddEventHandler('removeAllWeaponsEvent', function(sender, d)
    local src = tracked(sender)
    if not src or not on(src) or type(d) ~= 'table' then return end
    local e = d.pedId and NetworkGetEntityFromNetworkId and NetworkGetEntityFromNetworkId(d.pedId)
    local owner = e and e ~= 0 and NetworkGetEntityOwner and NetworkGetEntityOwner(e) or nil
    if owner and owner ~= src and tracked(owner) then cancel() Flag(src, 'remove_weapons', 'armes retirées à #' .. tostring(owner)) end
end)

-- Entités créées en rafale (en plus de la liste noire déjà gérée) ------------------------------------------------------------------------------
AddEventHandler('entityCreating', function(ent)
    if cfg('enabled') == false or not ent or ent == 0 then return end
    local owner = NetworkGetEntityOwner and NetworkGetEntityOwner(ent) or nil
    local src = tracked(owner)
    if not src or not on(src) then return end
    local ty = GetEntityType and GetEntityType(ent) or 0
    local key, lim, lbl = nil, nil, nil
    if ty == 2 then key, lim, lbl = 'ent_veh', tonumber(cfg('ent_veh_max')) or 4, 'véhicules'
    elseif ty == 1 then key, lim, lbl = 'ent_ped', tonumber(cfg('ent_ped_max')) or 8, 'peds'
    elseif ty == 3 then key, lim, lbl = 'ent_obj', tonumber(cfg('ent_obj_max')) or 30, 'objets' end
    if not key then return end
    local n = bump(src, key, 10)
    if n > lim then
        cancel()
        if n == lim + 1 then Flag(src, 'entity_spam', ('%d %s en 10 s'):format(n, lbl)) end
    end
end)

-- Chat ----------------------------------------------------------------------------------------------------------------------------------------
local function hasWord(text, list)
    text = tostring(text or ''):lower()
    for _, w in ipairs(list or {}) do w = tostring(w):lower() if w ~= '' and text:find(w, 1, true) then return w end end
end
AddEventHandler('chatMessage', function(src, _, msg)
    src = tonumber(src)
    if not tracked(src) or not on(src) then return end
    local n = bump(src, 'chat', 10)
    local w = hasWord(msg, cfg('chat_words'))
    if w then if AC.ModeOf('chat_spam') ~= 'log' then cancel() end Flag(src, 'chat_spam', 'mot interdit : ' .. w) return end
    if n > (tonumber(cfg('chat_burst')) or 6) then cancel() if n == (tonumber(cfg('chat_burst')) or 6) + 1 then Flag(src, 'chat_spam', ('%d messages en 10 s'):format(n)) end end
end)

-- Pseudo à la connexion -----------------------------------------------------------------------------------------------------------------------
AddEventHandler('playerConnecting', function(name, setKickReason)
    if cfg('enabled') == false or AC.ModeOf('name') == 'off' then return end
    local src = source
    local okb, ex = pcall(AC.Bypass, src)
    if okb and ex then return end
    local why
    name = tostring(name or '')
    if #name:gsub('%s', '') < 2 then why = 'pseudo trop court ou vide'
    elseif #name > 40 then why = 'pseudo trop long'
    elseif name:find('[%z\1-\31\127]') or name:find('\226\128[\139-\143]') or name:find('\226\128[\168-\175]') or name:find('\239\187\191') then why = 'caractères invisibles ou de contrôle'
    else local w = hasWord(name, cfg('name_words')) if w then why = 'mot interdit : ' .. w end end
    if why then
        pcall(function() PB.Audit.Log('securite', 'anticheat.name', 0, name:sub(1, 40) .. ' — ' .. why) end)
        if AC.ModeOf('name') ~= 'log' then
            if CancelEvent then CancelEvent() end
            if setKickReason then setKickReason('Pseudo refusé (' .. why .. '). Change de pseudo FiveM puis reconnecte-toi.') end
        end
    end
end)

-- Rapports du client : signés avec le code de session, plausibles, puis recoupés par le serveur ------------------------------------------------
local function tok(sec, kind, val) return AC.Hash(sec .. '|' .. kind .. '|' .. tostring(math.floor(tonumber(val) or 0))) end
local LIMITS = { god = true, vehboost = true, vehgod = true, hp = true, armor = true, noclip = true, speed = true, invisible = true, freecam = true, spectate = true, ammo = true, jump = true, tiny = true, vision = true, stamina = true, ragdoll = true }
RegisterNetEvent('pb:ac:rep', function(kind, val, proof)
    local src = source
    local t = AC.track[src]
    if not t or not on(src) then return end
    kind = tostring(kind or '')
    if not LIMITS[kind] or tonumber(proof) ~= tok(t.sec, kind, val) then return end   -- jeton faux : ignoré (un code périmé n'est jamais sanctionné)
    if (t.grace or 0) > os.time() then return end
    if bump(src, 'rep_' .. kind, 60) > 6 then return end                              -- un client ne peut pas inonder le serveur
    local S = G.Staff
    if S and S.OnDuty and S.OnDuty(src) then return end                               -- le staff en service peut être invisible, invincible…
    local ped = GetPlayerPed(src)
    local pl = G.Get and G.Get(src)
    local dead = pl and PB.ToBool(pl.row and pl.row.dead)
    local v = tonumber(val) or 0
    local msg
    if kind == 'hp' then
        if v > (tonumber(cfg('hp_max')) or 200) then msg = ('santé %d (max plausible %d)'):format(v, tonumber(cfg('hp_max')) or 200) end
    elseif kind == 'armor' then
        if v > (tonumber(cfg('armor_max')) or 100) then msg = ('armure %d'):format(v) end
    elseif kind == 'noclip' then
        local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
        if not dead and veh == 0 then msg = 'collisions désactivées et déplacement libre' end
    elseif kind == 'speed' then msg = ('vitesse à pied %.0f m/s'):format(v)
    elseif kind == 'invisible' then if not dead then msg = 'joueur invisible' end
    elseif kind == 'freecam' then msg = 'caméra libre'
    elseif kind == 'spectate' then msg = 'mode spectateur réseau'
    elseif kind == 'ammo' then msg = 'munitions infinies (aucune consommée)'
    elseif kind == 'jump' then msg = 'super saut'
    elseif kind == 'tiny' then msg = 'ped minuscule'
    elseif kind == 'vision' then msg = 'vision nocturne ou thermique'
    elseif kind == 'god' then if not dead and (pl and PB.ToBool(pl.row and pl.row.created)) then msg = 'invincibilité (le client ne peut pas être blessé)' end
    elseif kind == 'vehboost' then
        local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
        if veh ~= 0 then
            local vel = GetEntityVelocity(veh)
            local sp = math.sqrt(vel.x ^ 2 + vel.y ^ 2 + vel.z ^ 2)
            if v > (tonumber(cfg('veh_boost_pct')) or 190) and sp > 25 then msg = ('véhicule à %d %% du maximum de son modèle (%.0f m/s mesurés)'):format(v, sp) end
        end
    elseif kind == 'vehgod' then msg = 'véhicule indestructible ou santé hors limites'
    elseif kind == 'stamina' then msg = 'endurance infinie'
    elseif kind == 'ragdoll' then msg = 'ragdoll désactivé' end
    if msg then t.rep = (t.rep or {}) t.rep[kind] = (t.rep[kind] or 0) + 1
        if t.rep[kind] >= (tonumber(cfg('noclip_hits')) or 3) then t.rep[kind] = 0 Flag(src, (kind == 'vehboost' and 'veh_boost') or (kind == 'vehgod' and 'veh_god') or 'client_report', msg) end
    else if t.rep then t.rep[kind] = 0 end end
end)

-- Ressources connues côté client : tout ce qui n'existe pas côté serveur est suspect -----------------------------------------------
local function serverRes()
    local s = {}
    for i = 0, (GetNumResources and GetNumResources() or 0) - 1 do local n = GetResourceByFindIndex(i) if n then s[n] = true end end
    return s
end
RegisterNetEvent('pb:ac:res', function(list, proof)
    local src = source
    local t = AC.track[src]
    if not t or not on(src) or type(list) ~= 'table' or #list > 600 then return end
    if tonumber(proof) ~= tok(t.sec, 'res', #list) then return end
    if (t.grace or 0) > os.time() or bump(src, 'res', 120) > 3 then return end
    local sr, bad = serverRes(), {}
    for _, n in ipairs(list) do n = tostring(n) if not sr[n] and #bad < 5 then bad[#bad + 1] = n:sub(1, 40) end end
    if #bad > 0 then Flag(src, 'resource_inject', 'ressources côté client inconnues du serveur : ' .. table.concat(bad, ', ')) end
end)

-- Changement de modèle de joueur (ped changer) : lu côté serveur, sans rien demander au client -----------------------------------------------
local allowedPed
PB.Cfg.OnChange('anticheat', function() allowedPed = nil end)
CreateThread(function()
    while true do
        Wait(5000)
        pcall(function()
            if cfg('enabled') == false or AC.ModeOf('ped_change') == 'off' then return end
            if not allowedPed then allowedPed = {} for _, m in ipairs(cfg('peds') or {}) do allowedPed[GetHashKey(tostring(m):lower())] = tostring(m):lower() end end
            local S = G.Staff
            for src, t in pairs(AC.track) do
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 and (t.grace or 0) <= os.time() and not AC.Bypass(src) and not (S and S.OnDuty and S.OnDuty(src)) then
                    local pl = G.Get and G.Get(src)
                    if pl and PB.ToBool(pl.row and pl.row.created) then
                        local m = GetEntityModel(ped)
                        if m ~= 0 and not allowedPed[m] then
                            t.pedBad = (t.pedBad or 0) + 1
                            if t.pedBad >= 3 then t.pedBad = 0 Flag(src, 'ped_change', ('modèle %s non autorisé'):format(tostring(m))) end
                        else t.pedBad = 0 end
                    end
                end
            end
        end)
    end
end)
