-- Shadow Base — Récolte libre (client) : zones, filons / arbres choisis par le serveur, récolte (E), marché et guide. Décrit par shared.lua (FARM).
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {} }
local blips, nodes = {}, {}     -- nodes : token -> { obj, id }
local busy = false

local function notify(kind, text) W:Notify({ type = kind, title = FARM.label, text = text }) end
local _keyTex, _keyChk = nil, 0
local function marker(x, y, z)
    -- même touche « E » arrondie que Shadow Base (texture pb_ui/key_e créée par pb_panel), sinon petit point lumineux
    local pz = z + 1.0
    if _keyTex == nil or GetGameTimer() > (_keyChk or 0) then
        _keyChk = GetGameTimer() + 5000
        local res = GetTextureResolution('pb_ui', 'key_e')
        _keyTex = res and res.x and res.x > 4 or false
    end
    if _keyTex then
        local ok, sx, sy = GetScreenCoordFromWorldCoord(x + 0.0, y + 0.0, pz + 0.0)
        if not ok then return end
        local d = #(GetEntityCoords(PlayerPedId()) - vector3(x + 0.0, y + 0.0, pz + 0.0))
        local k = math.max(0.55, 1.0 - d / 30.0)
        local hs = 0.036 * k
        DrawSprite('pb_ui', 'key_e', sx, sy, hs / GetAspectRatio(false), hs, 0.0, 255, 255, 255, math.floor(math.max(90, 235 - d * 9)))
        return
    end
    local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end

local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, s in ipairs(C.spots or {}) do
        if s.kind == 'zone' then
            local r = AddBlipForRadius(s.x + 0.0, s.y + 0.0, s.z + 0.0, (s.r or 120) + 0.0)
            SetBlipColour(r, FARM.blip[2]) SetBlipAlpha(r, 60)
            blips[#blips + 1] = r
        end
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, s.kind == 'zone' and FARM.blip[1] or (s.kind == 'market' and 52 or 280)) SetBlipColour(b, FARM.blip[2]) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end)
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
end)

-- Dans une zone : demande régulière au serveur ; nettoyage des filons trop loin
local function inZone()
    local c = GetEntityCoords(PlayerPedId())
    for _, s in ipairs(C.spots or {}) do
        if s.kind == 'zone' and #(vector2(c.x, c.y) - vector2(s.x + 0.0, s.y + 0.0)) <= (s.r or 120) then return s end
    end
end
CreateThread(function()
    while true do
        Wait(5000)
        if C.enabled and inZone() and not IsPedInAnyVehicle(PlayerPedId(), false) then TriggerServerEvent(RES .. ':want') end
        local c = GetEntityCoords(PlayerPedId())
        for tok, n in pairs(nodes) do
            if not DoesEntityExist(n.obj) or #(GetEntityCoords(n.obj) - c) > 220.0 then
                if DoesEntityExist(n.obj) then DeleteEntity(n.obj) end
                nodes[tok] = nil
                TriggerServerEvent(RES .. ':gone', tok)
            end
        end
    end
end)

-- Apparition à 15-45 m du joueur, posée au sol
local function loadModel(list)
    for _, name in ipairs(list) do
        local h = joaat(name)
        if IsModelInCdimage(h) then
            RequestModel(h)
            local t = GetGameTimer() + 3000
            while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
            if HasModelLoaded(h) then return h end
        end
    end
end
RegisterNetEvent(RES .. ':spawn', function(token, id)
    local n = FARM_NODE_BY[id]
    if not n then return end
    local h = loadModel(n.models or FARM.models)
    if not h then TriggerServerEvent(RES .. ':gone', token) return end
    local c = GetEntityCoords(PlayerPedId())
    local ang, dist = math.random() * math.pi * 2, 15 + math.random() * 30
    local x, y = c.x + math.cos(ang) * dist, c.y + math.sin(ang) * dist
    local ok, gz = GetGroundZFor_3dCoord(x, y, c.z + 50.0, false)
    if not ok or math.abs(gz - c.z) > 25.0 then SetModelAsNoLongerNeeded(h) TriggerServerEvent(RES .. ':gone', token) return end
    local obj = CreateObject(h, x, y, gz, false, false, false)
    SetModelAsNoLongerNeeded(h)
    if not obj or obj == 0 then TriggerServerEvent(RES .. ':gone', token) return end
    SetEntityHeading(obj, math.random(0, 359) + 0.0)
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
    SetEntityAsMissionEntity(obj, true, true)
    nodes[token] = { obj = obj, id = id }
end)
local VEH_DEF = FARM.vehicle

-- (v1.2.58) véhicule prêté par le guide : posé à sa sortie (Builder), sinon sur la route la plus proche
RegisterNetEvent(RES .. ':vehspawn', function(x, y, z, hd)
    local V = VEH_DEF
    if not V then return end
    local h = loadModel(V.models)
    if not h then notify('error', 'Véhicule indisponible.') return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    if not x then
        local ok, node, heading = GetClosestVehicleNodeWithHeading(c.x, c.y, c.z, 1, 3.0, 0)
        if ok and node and #(node - c) < 60.0 then x, y, z, hd = node.x, node.y, node.z, heading
        else local p = c + GetEntityForwardVector(ped) * 5.0 x, y, z, hd = p.x, p.y, p.z, GetEntityHeading(ped) end
    end
    local v = CreateVehicle(h, x + 0.0, y + 0.0, z + 0.5, (hd or 0.0) + 0.0, true, false)
    SetModelAsNoLongerNeeded(h)
    if not v or v == 0 then return end
    SetVehicleOnGroundProperly(v)
    SetVehicleNumberPlateText(v, (V.plate .. '%04d'):format(math.random(0, 9999)))
    SetVehicleDoorsLocked(v, 1)
    SetEntityAsMissionEntity(v, true, true)
    TriggerServerEvent(RES .. ':vehnet', NetworkGetNetworkIdFromEntity(v))
end)

-- Récolte : E près d'un filon / arbre, le serveur contrôle l'outil (:try) puis lance l'animation (:go)
-- (v1.2.57) l'outil est tenu en main (pioche / hache) et le joueur le balance sur le filon ; sans le modèle ou l'animation, retour au scénario du jeu
local function holdTool(ped)
    local t = FARM.prop
    if not t then return nil end
    local h = loadModel(t.models)
    if not h then return nil end
    local c = GetEntityCoords(ped)
    local obj = CreateObject(h, c.x, c.y, c.z + 0.3, true, true, false)
    SetModelAsNoLongerNeeded(h)
    if not obj or obj == 0 then return nil end
    AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, t.bone or 57005), t.pos[1] + 0.0, t.pos[2] + 0.0, t.pos[3] + 0.0, t.rot[1] + 0.0, t.rot[2] + 0.0, t.rot[3] + 0.0, true, true, false, true, 1, true)
    return obj
end
local function workAnim(label, secs)
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    local tool = holdTool(ped)
    local a, played = FARM.anim, false
    if a then
        RequestAnimDict(a.dict)
        local t = GetGameTimer() + 2000
        while not HasAnimDictLoaded(a.dict) and GetGameTimer() < t do Wait(10) end
        if HasAnimDictLoaded(a.dict) then TaskPlayAnim(ped, a.dict, a.name, 4.0, -4.0, -1, a.flag or 1, 0.0, false, false, false) played = true end
    end
    if not played then TaskStartScenarioInPlace(ped, FARM.scenario, 0, true) end
    W:Progress(label, secs)
    local stop, ok = GetGameTimer() + secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) then ok = false break end
    end
    ClearPedTasks(ped)
    if tool and DoesEntityExist(tool) then DetachEntity(tool, true, true) DeleteEntity(tool) end
    if not ok then W:CancelProgress() end
    return ok
end
RegisterNetEvent(RES .. ':go', function(token, secs)
    local n = nodes[token]
    if not n or not DoesEntityExist(n.obj) then return end
    busy = true
    local def = FARM_NODE_BY[n.id]
    -- face au filon
    TaskTurnPedToFaceEntity(PlayerPedId(), n.obj, 600)
    Wait(600)
    if workAnim(FARM.progress, tonumber(secs) or FARM.secs) then
        TriggerServerEvent(RES .. ':done', token)
        nodes[token] = nil
        SetTimeout(600, function() if DoesEntityExist(n.obj) then DeleteEntity(n.obj) end end)
    end
    busy = false
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 500
        if next(nodes) and not busy and isFree() and C.enabled then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for tok, n in pairs(nodes) do
                if DoesEntityExist(n.obj) then
                    local p = GetEntityCoords(n.obj)
                    local d = #(p - c)
                    if d < 30.0 then sleep = 0 end
                    if d < 22.0 then marker(p.x, p.y, p.z + 0.4) end
                    if d < 2.6 and (not bd or d < bd) then best, bd = tok, d end
                end
            end
            if best then
                if shown ~= best then shown = best local p = GetEntityCoords(nodes[best].obj) W:Prompt(FARM.verb .. ' : ' .. (FARM_NODE_BY[nodes[best].id] or {}).label, 'E', p.x, p.y, p.z + 0.6) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':try', best) Wait(400) end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Marchés et guides
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if C.enabled and isFree() then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(C.spots or {}) do
                if s.kind ~= 'zone' then local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end
            end
            if best and bd < 30.0 then
                sleep = 0
                if not (NPCS and NPCS[best.id] and DoesEntityExist(NPCS[best.id])) then marker(best.x, best.y, best.z - 0.95) end
                if bd < 2.5 then
                    if shown ~= best.id then shown = best.id W:Prompt((best.kind == 'market' and FARM.sell_prompt or FARM.guide_prompt) .. ' : ' .. best.label, 'E', best.x, best.y, best.z) end
                    if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':open', best.id) Wait(500) end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

local openSpot
RegisterNetEvent(RES .. ':shop', function(id, kind, title, j, vip, allT, allN)
    local ok, list = pcall(json.decode, j)
    if not ok or type(list) ~= 'table' then return end
    openSpot = id
    local items = {}
    if kind == 'market' then
        if vip then items[#items + 1] = { label = 'Bonus VIP actif', icon = 'crown', description = 'Tu touches un bonus sur chaque vente.', disabled = true } end
        if (allN or 0) > 0 then
            items[#items + 1] = { label = 'Tout vendre', icon = 'coins', right = ('$%d'):format(allT), description = ('%d objets pour $%d. Le cours baisse à chaque unité vendue : ce prix en tient compte.'):format(allN, allT),
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sellall', id) end }
            items[#items + 1] = { type = 'separator', label = 'À l\'unité' }
        end
        for _, x in ipairs(list) do
            local trend = x.pct >= 105 and ' ▲' or (x.pct <= 95 and ' ▼' or '')
            local it = { label = x.label, right = (x.n > 0 and (x.n .. ' × ') or '') .. ('$%d%s'):format(x.price, trend), description = ('%s · cours %d %% du prix normal ($%d)'):format((FARM_RARITY_BY[x.rarity] or {}).label or '', x.pct, x.base) }
            if x.n > 0 then it.onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sell', id, x.item) end else it.disabled = true end
            items[#items + 1] = it
        end
        W:OpenMenu({ id = RES .. '.market', title = title, subtitle = FARM.sell_sub, items = items })
    else
        for _, x in ipairs(list) do
            if x.veh then
                items[#items + 1] = { label = x.label, icon = 'engine', right = x.veh == 'take' and 'Gratuit' or nil, description = x.desc,
                    onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':veh', id, x.veh) end }
            else
                items[#items + 1] = { label = x.label, icon = 'tool', right = x.kit == 'take' and 'Gratuit' or nil, description = FARM.kit_desc,
                    onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':kit', id, x.kit) end }
            end
        end
        W:OpenMenu({ id = RES .. '.shop', title = title, subtitle = FARM.guide, items = items })
    end
end)
RegisterNetEvent(RES .. ':refresh', function(id) if openSpot == id then TriggerServerEvent(RES .. ':open', id) end end)

-- PNJ du guide et du marchand (posés seulement quand on est à moins de 60 m)
local npcs = {}
NPCS = npcs
CreateThread(function()
    while true do
        Wait(1500)
        local c = GetEntityCoords(PlayerPedId())
        local want = {}
        if C.enabled then
            for _, s in ipairs(C.spots or {}) do
                if s.kind ~= 'zone' and #(c - vector3(s.x, s.y, s.z)) < 60.0 then
                    want[s.id] = true
                    if not (npcs[s.id] and DoesEntityExist(npcs[s.id])) then
                        local m = joaat(FARM.npc[s.kind] or FARM.npc.shop)
                        if not IsModelInCdimage(m) then m = joaat('a_m_m_hillbilly_01') end
                        RequestModel(m)
                        local t = GetGameTimer() + 3000
                        while not HasModelLoaded(m) and GetGameTimer() < t do Wait(20) end
                        if HasModelLoaded(m) then
                            local ok, gz = GetGroundZFor_3dCoord(s.x + 0.0, s.y + 0.0, s.z + 2.0, false)
                            local p = CreatePed(4, m, s.x + 0.0, s.y + 0.0, ok and gz or (s.z - 1.0), (tonumber(s.h) or 0.0) + 0.0, false, false)
                            SetEntityInvincible(p, true) FreezeEntityPosition(p, true) SetBlockingOfNonTemporaryEvents(p, true)
                            TaskStartScenarioInPlace(p, s.kind == 'shop' and 'WORLD_HUMAN_CLIPBOARD' or 'WORLD_HUMAN_STAND_IMPATIENT', 0, true)
                            SetModelAsNoLongerNeeded(m)
                            npcs[s.id] = p
                        end
                    end
                end
            end
        end
        for id, p in pairs(npcs) do if not want[id] then if DoesEntityExist(p) then DeleteEntity(p) end npcs[id] = nil end end
    end
end)

AddEventHandler('onClientResourceStop', function(res)
    if res ~= RES then return end
    for _, p in pairs(npcs) do if DoesEntityExist(p) then DeleteEntity(p) end end
    clearBlips()
    for _, n in pairs(nodes) do if DoesEntityExist(n.obj) then DeleteEntity(n.obj) end end
end)
