-- Shadow Base — Bûcheronnage libre : arbres, bois, outil prêté.
FARM = {
    key = 'bucheron', label = 'Bûcheron', icon = 'leaf', hint = 'Arbres, bois, marché aux prix variables',
    guide = 'Chef de chantier forestier', market = 'Scierie du bûcheron', zone_label = 'Zone de coupe',
    tool = { name = 'hache_bucheron', label = 'Hache (prêtée)', weight = 2000 },
    blip = { 480, 25 }, scenario = 'WORLD_HUMAN_HAMMERING',
    anim = { dict = 'melee@large_wpn@streamed_core', name = 'ground_attack_on_spot', flag = 1 },
    prop = { models = { 'prop_ld_fireaxe', 'prop_tool_fireaxe' }, bone = 57005, pos = { 0.1, 0.0, -0.02 }, rot = { -80.0, 0.0, 0.0 } }, progress = 'Abattage', secs = 8, verb = 'Abattre',
    spawn_label = 'Un arbre apparaît', spawn_many = 'Arbres',
    models = { 'prop_log_01', 'prop_logpile_05', 'prop_tree_log_01' },
    npc = { shop = 'a_m_m_hillbilly_01', market = 'a_m_m_farmer_01' },
    ask = 'Demander une hache', kit_ok = 'Le chef de chantier te prête une hache. Rends-la à la scierie en vendant ton bois.',
    kit_desc = 'Le chef de chantier te prête une hache gratuitement. La scierie la reprend avant la vente.',
    guide_prompt = 'Parler au chef de chantier', sell_prompt = 'Vendre ton bois', sell_sub = 'Vendre ton bois',
    rarity_text = 'Pin et résine (communs), chêne (peu commun), noyer (rare), ébène (épique), arbre ancien (légendaire).',
    doc = "## Bûcheron\nVa voir le **chef de chantier forestier** : « Demander une hache » te la prête gratuitement. Dans une **zone de coupe**, des arbres apparaissent autour de toi : **E** pour abattre. Revends à la **scierie du bûcheron** (elle reprend la hache d'abord). Aucun métier nécessaire.",
}
FARM_RARITY = {
    { id = 'c',  label = 'Commun',     weight = 60 },
    { id = 'pc', label = 'Peu commun', weight = 26 },
    { id = 'r',  label = 'Rare',       weight = 10 },
    { id = 'e',  label = 'Épique',     weight = 3 },
    { id = 'l',  label = 'Légendaire', weight = 1 },
}
FARM_RARITY_BY = {}
for i, r in ipairs(FARM_RARITY) do r.n = i FARM_RARITY_BY[r.id] = r end

-- loot : { objet, min, max }
FARM_NODES = {
    { id = 'pin',     label = 'Pin',           rarity = 'c',  time = 7,  models = { 'prop_tree_pine_02', 'prop_tree_cedar_s_01', 'prop_log_01' }, loot = { { 'wood_log', 2, 4 } } },
    { id = 'souche',  label = 'Souche résineuse', rarity = 'c', time = 6, models = { 'prop_log_01', 'prop_logpile_05' }, loot = { { 'resin', 1, 3 } } },
    { id = 'chene',   label = 'Chêne',         rarity = 'pc', time = 9,  models = { 'prop_tree_oak_01', 'prop_tree_birch_03', 'prop_log_01' }, loot = { { 'oak_log', 1, 3 } } },
    { id = 'noyer',   label = 'Noyer',         rarity = 'r',  time = 10, models = { 'prop_tree_birch_03', 'prop_log_01' }, loot = { { 'walnut_log', 1, 2 } } },
    { id = 'ebene',   label = 'Ébène',         rarity = 'e',  time = 11, models = { 'prop_tree_cedar_02', 'prop_log_01' }, loot = { { 'ebony_log', 1, 2 } } },
    { id = 'ancien',  label = 'Arbre ancien',  rarity = 'l',  time = 13, models = { 'prop_tree_cedar_04', 'prop_log_01' }, loot = { { 'ancient_log', 1, 1 }, { 'resin', 2, 3 } } },
}
-- Produits vendus à la scierie (prix de base)
FARM_GOODS = {
    { name = 'wood_log',    label = 'Bûche de pin',     rarity = 'c',  price = 8,   weight = 1500 },
    { name = 'resin',       label = 'Résine',           rarity = 'c',  price = 14,  weight = 200 },
    { name = 'oak_log',     label = 'Bûche de chêne',   rarity = 'pc', price = 24,  weight = 1800 },
    { name = 'walnut_log',  label = 'Bûche de noyer',   rarity = 'r',  price = 60,  weight = 1800 },
    { name = 'ebony_log',   label = "Bûche d'ébène",    rarity = 'e',  price = 200, weight = 2200 },
    { name = 'ancient_log', label = "Bois d'arbre ancien", rarity = 'l', price = 750, weight = 2500 },
}

FARM_NODE_BY, FARM_GOOD_BY = {}, {}
for _, n in ipairs(FARM_NODES) do FARM_NODE_BY[n.id] = n end
for _, g in ipairs(FARM_GOODS) do FARM_GOOD_BY[g.name] = g end
