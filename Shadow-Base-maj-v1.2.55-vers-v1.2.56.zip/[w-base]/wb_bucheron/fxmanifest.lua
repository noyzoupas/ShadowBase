fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_bucheron'
description "Shadow Base — bûcheronnage libre (sans métier) : guide qui prête la hache, zones d'arbres de rareté différente, marché aux prix variables, bonus VIP. Extension de pb_panel."
author 'Shadow Base'
version '1.0.0'

dependency 'pb_panel'

shared_script 'shared.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'
