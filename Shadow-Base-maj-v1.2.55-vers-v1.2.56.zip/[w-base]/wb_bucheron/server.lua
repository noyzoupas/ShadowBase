-- Shadow Base — Récolte libre (serveur) : minage ou bûcheronnage, même système que la chasse mais sans métier ni entreprise.
-- Le guide prête l'outil (gratuit), dans une zone posée au Builder des filons / arbres apparaissent autour du joueur (le serveur tire le type
-- et remet un jeton), la récolte donne des matières de rareté différente, revendues au marché : chaque vente fait baisser le cours, qui remonte
-- avec le temps. Bonus de revente pour les VIP. Tout est décrit dans shared.lua (FARM) : ce fichier est identique pour toutes les récoltes.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'
local T_MARKET, T_LOG, T_LOANS, T_LOADS = RES .. '_market', RES .. '_log', RES .. '_loans', RES .. '_loads'
local VEH, GOODS = FARM.vehicle, FARM_GOODS

local cache = {}
local function cfg(k, d)
    local v = cache[k]
    if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end
    if v == nil then return d end
    return v
end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, FARM.label, text) end
local function label(item) local i = W:ItemInfo(item) return i and i.label or item end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end
local function d2(c, s) return #(vector2(c.x, c.y) - vector2(s.x + 0.0, s.y + 0.0)) end
local function isVip(src) local ok, v = pcall(function() return W:IsVip(src) end) return ok and v == true end
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function ecoIn(n, kind) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoIncome(n, kind) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end

-- Marché : coefficient de prix par produit -------------------------------------------------------------------------------------------------------------
local factor, dirty = {}, {}
local DROP = { c = 0.004, pc = 0.006, r = 0.012, e = 0.025, l = 0.05 }
local function f(item) return factor[item] or 1.0 end
local function setF(item, v) factor[item] = math.max((tonumber(cfg('min_factor', 40)) or 40) / 100, math.min(1.4, v)) dirty[item] = true end
local function unitPrice(item)
    local g = FARM_GOOD_BY[item]
    if not g then return 0 end
    return math.max(1, ecoIn(g.price * f(item) * ((tonumber(cfg('price_mult', 35)) or 35) / 100), 'activity'))
end
local function saveMarket()
    for item in pairs(dirty) do MySQL.insert('REPLACE INTO ' .. T_MARKET .. ' (item, factor, updated) VALUES (?, ?, ?)', { item, factor[item] or 1, os.time() }) end
    dirty = {}
end
CreateThread(function()
    while true do
        Wait(5 * 60000)
        local rec = (tonumber(cfg('recover', 6)) or 6) / 100
        for _, g in ipairs(FARM_GOODS) do
            local cur = f(g.name)
            local nv = cur + (1 - cur) * rec + (math.random() - 0.5) * 0.04
            if math.abs(nv - cur) > 0.0005 then setF(g.name, nv) end
        end
        saveMarket()
    end
end)

-- (v1.2.58) Véhicule prêté par le guide : ce qui est récolté à moins de 40 m de lui va dans son chargement, revendu au marché s'il est à moins de 60 m
local vehs, loads, vehAsk = {}, {}, {}   -- src -> id réseau ; licence -> { [objet] = quantité }
local function loadOf(lic)
    if loads[lic] then return loads[lic] end
    local r = MySQL.single.await('SELECT data FROM ' .. T_LOADS .. ' WHERE license = ?', { lic })
    local ok, d = pcall(json.decode, r and r.data or '{}')
    loads[lic] = ok and type(d) == 'table' and d or {}
    return loads[lic]
end
local function saveLoad(lic)
    local d = loads[lic]
    if d and next(d) then MySQL.insert('REPLACE INTO ' .. T_LOADS .. ' (license, data) VALUES (?, ?)', { lic, json.encode(d) })
    else MySQL.update('DELETE FROM ' .. T_LOADS .. ' WHERE license = ?', { lic }) end
end
local function loadCount(d) local n = 0 for _, q in pairs(d) do n = n + q end return n end
local function vehEntity(src)
    local net = vehs[src]
    if not net then return nil end
    local e = NetworkGetEntityFromNetworkId(net)
    if e and e ~= 0 and DoesEntityExist(e) then return e end
    vehs[src] = nil
    return nil
end
local function vehNear(src, dist)
    local e, c = vehEntity(src), pos(src)
    return e ~= nil and c ~= nil and #(GetEntityCoords(e) - c) <= dist
end
-- range la récolte : dans le véhicule s'il est là et pas plein, sinon dans le sac. Renvoie le texte à afficher, nil si rien n'a pu être rangé.
local function stow(src, item, q)
    if VEH and vehNear(src, 40.0) then
        local lic = W:GetLicense(src)
        local d = lic and loadOf(lic)
        if d and loadCount(d) + q <= (tonumber(cfg('veh_cap', 200)) or 200) then
            d[item] = (d[item] or 0) + q
            saveLoad(lic)
            return q .. ' × ' .. label(item) .. ' (' .. VEH.short .. ')'
        end
    end
    if W:CanCarryItem(src, item, q) and W:AddItem(src, item, q) then return q .. ' × ' .. label(item) end
    return nil
end
local function stockOf(src, item)
    local n = W:GetItemCount(src, item) or 0
    if VEH and vehNear(src, 60.0) then
        local lic = W:GetLicense(src)
        if lic then n = n + (loadOf(lic)[item] or 0) end
    end
    return n
end
local function takeStock(src, item, n)
    local bag = math.min(W:GetItemCount(src, item) or 0, n)
    if bag > 0 and not W:RemoveItem(src, item, bag) then return false end
    local rest = n - bag
    if rest <= 0 then return true end
    local lic = W:GetLicense(src)
    local d = lic and loadOf(lic)
    if not d or (d[item] or 0) < rest then return false end
    d[item] = d[item] - rest
    if d[item] <= 0 then d[item] = nil end
    saveLoad(lic)
    return true
end
-- prix de « Tout vendre » : calculé comme la vente (le cours baisse à chaque unité), sans rien changer
local function simAll(src)
    local total, count = 0, 0
    for _, g in ipairs(GOODS) do
        local n = math.min(stockOf(src, g.name), 100)
        if n > 0 then
            local keep = factor[g.name]
            for _ = 1, n do total = total + unitPrice(g.name) setF(g.name, f(g.name) - DROP[g.rarity]) end
            factor[g.name] = keep
            count = count + n
        end
    end
    return total + (isVip(src) and math.floor(total * (tonumber(cfg('vip_bonus', 15)) or 15) / 100) or 0), count
end
AddEventHandler('playerDropped', function()
    local s = source
    local e = vehEntity(s)
    if e then DeleteEntity(e) end
    vehs[s], vehAsk[s] = nil, nil
end)

-- Réglages et page du panel ------------------------------------------------------------------------------------------------------------------------------
local forms, marketBlocks = {}, nil
local XYZ = { { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -1000, max = 3000, int = false } }
local function setup()
    W:ExtRegister({ label = FARM.label, version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier : ' .. FARM.label:lower() .. ' (zones, marché, guide)', true)
    W:ExtMigrate(RES .. '_001', FARM.label .. ' : marché, journal et matériel prêté', {
        'CREATE TABLE IF NOT EXISTS ' .. T_MARKET .. ' (item VARCHAR(40) NOT NULL, factor DOUBLE NOT NULL DEFAULT 1, updated INT NOT NULL DEFAULT 0, PRIMARY KEY (item))',
        'CREATE TABLE IF NOT EXISTS ' .. T_LOG .. [[ (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, node VARCHAR(24) NOT NULL DEFAULT '', item VARCHAR(40) NOT NULL DEFAULT '',
            qty INT NOT NULL DEFAULT 0, money INT NOT NULL DEFAULT 0, kind VARCHAR(6) NOT NULL DEFAULT 'gather', at INT NOT NULL, PRIMARY KEY (id), KEY k_at (at))]],
        'CREATE TABLE IF NOT EXISTS ' .. T_LOANS .. ' (license VARCHAR(64) NOT NULL, at INT NOT NULL DEFAULT 0, PRIMARY KEY (license))',
    })
    W:ExtMigrate(RES .. '_002', FARM.label .. ' : chargement du véhicule prêté', { 'CREATE TABLE IF NOT EXISTS ' .. T_LOADS .. ' (license VARCHAR(64) NOT NULL, data TEXT NOT NULL, PRIMARY KEY (license))' })
    for _, g in ipairs(FARM_GOODS) do
        W:EnsureItem({ name = g.name, label = g.label, weight = g.weight, stack = 50, kind = 'misc', usable = false, description = FARM_RARITY_BY[g.rarity].label .. ' · se revend au marché (' .. FARM.market .. ').' })
    end
    W:EnsureItem({ name = FARM.tool.name, label = FARM.tool.label, weight = FARM.tool.weight or 2000, stack = 1, kind = 'tool', usable = false, description = 'Prêté par le guide : rendu tout seul au marché avant la vente.' })
    for _, r in ipairs(MySQL.query.await('SELECT item, factor FROM ' .. T_MARKET) or {}) do factor[r.item] = tonumber(r.factor) or 1 end
    forms.main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = FARM.label .. ' actif', default = true },
        { k = 'spawn_secs', type = 'number', label = FARM.spawn_label .. ' toutes les (s) dans une zone', default = 20, min = 5, max = 900 },
        { k = 'max_alive', type = 'number', label = FARM.spawn_many .. ' en même temps par joueur', default = 6, min = 1, max = 12 },
        { k = 'max_per_hour', type = 'number', label = 'Récoltes maximum par heure', default = 150, min = 1, max = 600 },
        { k = 'price_mult', type = 'number', label = 'Prix du marché (% des prix de base)', default = 35, min = 0, max = 1000, hint = 'Bas par défaut : le farm est un loisir libre, les entreprises restent la vraie source de revenus.' },
        { k = 'min_factor', type = 'number', label = 'Prix plancher (% du prix de base)', default = 40, min = 5, max = 100 },
        { k = 'recover', type = 'number', label = 'Remontée des prix toutes les 5 min (%)', default = 6, min = 0, max = 100 },
        { k = 'vip_bonus', type = 'number', label = 'Bonus de revente des VIP (%)', default = 15, min = 0, max = 200 },
        { k = 'pay', type = 'select', label = 'Paiement des ventes', opts = { { 'cash', 'Espèces' }, { 'bank', 'Banque' } }, default = 'cash' },
        { k = 'blips', type = 'toggle', label = 'Zones, marchés et guides sur la carte', default = true },
        { k = 'veh_cap', type = 'number', label = 'Capacité du véhicule prêté (objets)', default = 200, min = 10, max = 2000 },
    } })
    forms.spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Points posés', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Zones, marchés et guides', default = {}, wide = true, maxitems = 60, unique = 'id',
          hint = 'Pose-les en jeu : menu staff (F10) › Builder › ' .. FARM.label .. '. Type : zone, market ou shop. Rayon : zones seulement.',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'kind', label = 'Type', pattern = '^%a+$', required = true, maxlen = 8, lower = true },
            { k = 'label', label = 'Nom', required = true, maxlen = 40 }, XYZ[1], XYZ[2], XYZ[3], { k = 'radius', label = 'Rayon (m)', type = 'number', min = 20, max = 800 }, { k = 'h', label = 'Cap', type = 'number', min = 0, max = 360, int = false } } } } })
    W:ExtModule({
        id = RES, label = FARM.label, icon = FARM.icon or 'box', perm = PERM, hint = FARM.hint,
        caps = {
            { 'Libre', 'ok', 'Aucun métier ni entreprise : le guide prête l\'outil gratuitement, comme pour la chasse.' },
            { 'Zones', 'ok', 'Posées au Builder : ' .. FARM.spawn_many:lower() .. ' apparaissent autour du joueur (rayon réglable).' },
            { 'Raretés', 'ok', FARM.rarity_text },
            { 'Marché vivant', 'ok', 'Chaque vente fait baisser le cours du produit, qui remonte avec le temps. Bonus VIP.' },
        },
        doc = FARM.doc,
        tabs = {
            { id = 'market', label = 'Marché', icon = 'coins', build = function() return marketBlocks() end },
            { id = 'main', label = 'Réglages', icon = 'sliders', form = forms.main },
            { id = 'spots', label = 'Points posés', icon = 'pin', form = forms.spots },
        },
    })
end
marketBlocks = function()
    local rows = {}
    for _, g in ipairs(FARM_GOODS) do rows[#rows + 1] = { label = g.label, rarity = FARM_RARITY_BY[g.rarity].label, base = '$' .. g.price, now = '$' .. unitPrice(g.name), trend = math.floor(f(g.name) * 100 + 0.5) .. ' %' } end
    local n = MySQL.scalar.await('SELECT COUNT(*) FROM ' .. T_LOG .. " WHERE kind = 'gather' AND at > ?", { os.time() - 86400 }) or 0
    return { { type = 'stats', items = { { label = 'Récoltes (24 h)', value = n, icon = FARM.icon or 'box' } } },
        { type = 'table', id = 'm', title = 'Cours du marché', rows = rows, columns = { { k = 'label', label = 'Produit' }, { k = 'rarity', label = 'Rareté' }, { k = 'base', label = 'Prix de base' }, { k = 'now', label = 'Prix actuel' }, { k = 'trend', label = 'Cours' } } } }
end

local function publicCfg()
    local spots = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do if s.kind ~= 'car' then spots[#spots + 1] = { id = s.id, kind = s.kind, label = s.label, x = s.x, y = s.y, z = s.z, h = tonumber(s.h), r = tonumber(s.radius) or 120 } end end
    return { enabled = cfg('enabled', true) ~= false, blips = cfg('blips', true) ~= false, spawn = tonumber(cfg('spawn_secs', 20)) or 20, spots = spots }
end
local function push(target) TriggerClientEvent(RES .. ':cfg', target or -1, json.encode(publicCfg())) end
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns ~= NS then return end cache = {} push() end)
RegisterNetEvent(RES .. ':hello', function() push(source) end)

-- Filons / arbres : le serveur tire le type, le client les fait apparaître ------------------------------------------------------------------------------------
local alive, lastSpawn, hourly = {}, {}, {}     -- src -> { [token] = { node, zone, at, go } }
local seq = 0
AddEventHandler('playerDropped', function() local s = source alive[s], lastSpawn[s], hourly[s] = nil, nil, nil end)
local function zoneOf(src)
    local c = pos(src)
    if not c then return nil end
    for _, s in ipairs(cfg('spots', {}) or {}) do if s.kind == 'zone' and d2(c, s) <= (tonumber(s.radius) or 120) then return s end end
end
local function roll()
    local total = 0
    for _, r in ipairs(FARM_RARITY) do total = total + r.weight end
    local x, tier = math.random() * total, 1
    for i, r in ipairs(FARM_RARITY) do x = x - r.weight if x <= 0 then tier = i break end end
    for t = tier, 1, -1 do
        local pool = {}
        for _, n in ipairs(FARM_NODES) do if FARM_RARITY_BY[n.rarity].n == t then pool[#pool + 1] = n end end
        if #pool > 0 then return pool[math.random(#pool)] end
    end
    return FARM_NODES[1]
end
local function count(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end
RegisterNetEvent(RES .. ':want', function()
    local src = source
    if not cfg('enabled', true) or not W:CanAct(src) then return end
    local now = os.time()
    if lastSpawn[src] and now - lastSpawn[src] < (tonumber(cfg('spawn_secs', 20)) or 20) then return end
    lastSpawn[src] = now
    local z = zoneOf(src)
    if not z then return end
    alive[src] = alive[src] or {}
    if count(alive[src]) >= (tonumber(cfg('max_alive', 6)) or 6) then return end
    local n = roll()
    seq = seq + 1
    local token = ('%d_%d'):format(seq, math.random(1000, 9999))
    alive[src][token] = { node = n.id, zone = z.id, at = os.time() }
    TriggerClientEvent(RES .. ':spawn', src, token, n.id)
end)
RegisterNetEvent(RES .. ':gone', function(token) local a = alive[source] if a then a[tostring(token)] = nil end end)

-- Récolte : 1) le client demande (:try), le serveur contrôle l'outil et répond (:go) ; 2) à la fin de l'animation (:done) le serveur contrôle le délai et donne les matières
local lastTry = {}
RegisterNetEvent(RES .. ':try', function(token)
    local src = source
    local t = alive[src] and alive[src][tostring(token)]
    if not t or not cfg('enabled', true) or not W:CanAct(src) then return end
    local now = GetGameTimer()
    if lastTry[src] and now - lastTry[src] < 800 then return end
    lastTry[src] = now
    if os.time() - t.at < 2 then return end
    if not W:HasItem(src, FARM.tool.name, 1) then notify(src, 'error', 'Il te faut l\'outil du guide : ' .. FARM.tool.label .. '. Va voir le ' .. FARM.guide:lower() .. '.') return end
    local h = hourly[src]
    local os_ = os.time()
    if not h or os_ - h.t >= 3600 then h = { t = os_, n = 0 } hourly[src] = h end
    if h.n >= (tonumber(cfg('max_per_hour', 150)) or 150) then notify(src, 'warn', 'Tu as assez travaillé pour cette heure.') return end
    t.go = GetGameTimer()
    TriggerClientEvent(RES .. ':go', src, tostring(token), FARM_NODE_BY[t.node].time or FARM.secs)
end)
RegisterNetEvent(RES .. ':done', function(token)
    local src = source
    local mine = alive[src]
    local t = mine and mine[tostring(token)]
    if not t or not t.go then return end
    local n = FARM_NODE_BY[t.node]
    if GetGameTimer() - t.go < ((n.time or FARM.secs) - 1) * 1000 then return end
    if not W:HasItem(src, FARM.tool.name, 1) then return end
    local z = find(cfg('spots', {}), t.zone)
    local c = pos(src)
    if not z or not c or d2(c, z) > (tonumber(z.radius) or 120) + 80 then return end
    mine[tostring(token)] = nil
    local h = hourly[src]
    if h then h.n = h.n + 1 end
    local parts = {}
    for _, l in ipairs(n.loot) do
        local q = math.random(l[2], l[3])
        if q > 0 then local t = stow(src, l[1], q) if t then parts[#parts + 1] = t end end
    end
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO ' .. T_LOG .. ' (license, node, kind, at) VALUES (?, ?, ?, ?)', { lic, n.id, 'gather', os.time() }) end
    notify(src, #parts > 0 and 'success' or 'warn', ('%s (%s) : %s.'):format(n.label, FARM_RARITY_BY[n.rarity].label, #parts > 0 and table.concat(parts, ', ') or 'ton sac est plein'))
    TriggerEvent(RES .. ':gathered', src, n.id)
end)

-- Outil prêté par le guide ------------------------------------------------------------------------------------------------------------------------------------
local function loanOf(src) local lic = W:GetLicense(src) return lic and MySQL.single.await('SELECT * FROM ' .. T_LOANS .. ' WHERE license = ?', { lic }) or nil, lic end
local function giveKit(src)
    local loan, lic = loanOf(src)
    if not lic then return false, 'Joueur introuvable.' end
    if loan or (W:GetItemCount(src, FARM.tool.name) or 0) > 0 then return false, 'Tu as déjà ton outil. Rends-le au marché en vendant ta récolte.' end
    if not W:CanCarryItem(src, FARM.tool.name, 1) then return false, 'Ton sac est plein : fais de la place pour l\'outil.' end
    if not W:AddItem(src, FARM.tool.name, 1) then return false, 'Impossible de te donner l\'outil.' end
    MySQL.insert('REPLACE INTO ' .. T_LOANS .. ' (license, at) VALUES (?, ?)', { lic, os.time() })
    return true, FARM.kit_ok
end
-- Reprend l'outil prêté (et tout autre exemplaire). Renvoie false si l'outil manque alors qu'il avait été prêté.
local function takeKit(src, strict)
    local loan, lic = loanOf(src)
    local n = W:GetItemCount(src, FARM.tool.name) or 0
    if loan and n == 0 and strict then return false end
    if n > 0 then W:RemoveItem(src, FARM.tool.name, n) end
    if loan then MySQL.update('DELETE FROM ' .. T_LOANS .. ' WHERE license = ?', { lic }) end
    return true, (n > 0 or loan) and true or false
end

-- Marché et guide -------------------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent(RES .. ':open', function(id)
    local src = source
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s then notify(src, 'error', "Ce point n'existe plus.") return end
    if not c or d2(c, s) > 5 then notify(src, 'warn', 'Rapproche-toi du comptoir.') return end
    local list = {}
    if s.kind == 'market' then
        local ok, had = takeKit(src, true)
        if not ok then notify(src, 'error', "Rapporte d'abord l'outil prêté par le guide : sans lui, pas de vente.") return end
        if had then notify(src, 'info', 'Le marchand reprend l\'outil du guide.') end
        for _, g in ipairs(FARM_GOODS) do list[#list + 1] = { item = g.name, label = g.label, n = stockOf(src, g.name), price = unitPrice(g.name), base = g.price, rarity = g.rarity, pct = math.floor(f(g.name) * 100 + 0.5) } end
    elseif s.kind == 'shop' then
        local loan = loanOf(src)
        list[#list + 1] = { item = '__kit', label = loan and "Rendre l'outil du guide" or FARM.ask, kit = loan and 'return' or 'take' }
        if VEH then
            local out = vehEntity(src) ~= nil
            list[#list + 1] = { item = '__veh', label = out and ('Rendre le ' .. VEH.short) or VEH.ask, veh = out and 'return' or 'take', desc = VEH.desc }
        end
    else return end
    local allT, allN = 0, 0
    if s.kind == 'market' then allT, allN = simAll(src) end
    TriggerClientEvent(RES .. ':shop', src, s.id, s.kind, s.label, json.encode(list), isVip(src), allT, allN)
end)
local lastAct = {}
local function throttle(src) local t = GetGameTimer() if lastAct[src] and t - lastAct[src] < 700 then return false end lastAct[src] = t return true end
AddEventHandler('playerDropped', function() lastAct[source] = nil lastTry[source] = nil end)
RegisterNetEvent(RES .. ':sell', function(id, item)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local g = FARM_GOOD_BY[tostring(item)]
    local c = pos(src)
    if not s or s.kind ~= 'market' or not g or not c or d2(c, s) > 4 then return end
    local n = math.min(stockOf(src, g.name), 100)
    if n <= 0 or not takeStock(src, g.name, n) then return end
    local total = 0
    for _ = 1, n do total = total + unitPrice(g.name) setF(g.name, f(g.name) - DROP[g.rarity]) end
    local bonus = isVip(src) and math.floor(total * (tonumber(cfg('vip_bonus', 15)) or 15) / 100) or 0
    total = total + bonus
    W:AddMoney(src, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash', total, 'Vente : ' .. FARM.label:lower())
    local lic = W:GetLicense(src)
    if lic then MySQL.insert('INSERT INTO ' .. T_LOG .. ' (license, item, qty, money, kind, at) VALUES (?, ?, ?, ?, ?, ?)', { lic, g.name, n, total, 'sell', os.time() }) end
    notify(src, 'success', ('Vendu : %d × %s pour $%d%s. Nouveau cours : $%d.'):format(n, g.label, total, bonus > 0 and (' (dont bonus VIP $' .. bonus .. ')') or '', unitPrice(g.name)))
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)
RegisterNetEvent(RES .. ':sellall', function(id)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or s.kind ~= 'market' or not c or d2(c, s) > 4 then return end
    local total, count = 0, 0
    local lic = W:GetLicense(src)
    for _, g in ipairs(GOODS) do
        local n = math.min(stockOf(src, g.name), 100)
        if n > 0 and takeStock(src, g.name, n) then
            local part = 0
            for _ = 1, n do part = part + unitPrice(g.name) setF(g.name, f(g.name) - DROP[g.rarity]) end
            total, count = total + part, count + n
            if lic then MySQL.insert('INSERT INTO ' .. T_LOG .. ' (license, item, qty, money, kind, at) VALUES (?, ?, ?, ?, ?, ?)', { lic, g.name, n, part, 'sell', os.time() }) end
        end
    end
    if count <= 0 then return end
    local bonus = isVip(src) and math.floor(total * (tonumber(cfg('vip_bonus', 15)) or 15) / 100) or 0
    total = total + bonus
    W:AddMoney(src, cfg('pay', 'cash') == 'bank' and 'bank' or 'cash', total, 'Vente : ' .. FARM.label:lower() .. '')
    notify(src, 'success', ('Tout vendu : %d objets pour $%d%s.'):format(count, total, bonus > 0 and (' (dont bonus VIP $' .. bonus .. ')') or ''))
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)
RegisterNetEvent(RES .. ':vehnet', function(net)
    local src = source
    if not VEH or not vehAsk[src] then return end
    vehAsk[src] = nil
    vehs[src] = tonumber(net)
end)
RegisterNetEvent(RES .. ':veh', function(id, what)
    local src = source
    if not VEH or not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or s.kind ~= 'shop' or not c or d2(c, s) > 5 then return end
    local e = vehEntity(src)
    if what == 'take' then
        if e then notify(src, 'error', 'Tu as déjà ton ' .. VEH.short .. '.') return end
        local sp
        for _, x in ipairs(cfg('spots', {}) or {}) do if x.kind == 'car' and (not sp or d2(c, x) < d2(c, sp)) then sp = x end end
        vehAsk[src] = true
        TriggerClientEvent(RES .. ':vehspawn', src, sp and sp.x or nil, sp and sp.y or nil, sp and sp.z or nil, sp and tonumber(sp.h) or nil)
        notify(src, 'success', VEH.ok)
    else
        if e then DeleteEntity(e) end
        vehs[src] = nil
        -- ce qui reste dans le véhicule revient dans le sac autant que possible ; le reste est gardé pour la prochaine fois
        local lic = W:GetLicense(src)
        local d = lic and loadOf(lic) or {}
        local left = 0
        for item, q in pairs(d) do
            local back = 0
            for _ = 1, q do if W:CanCarryItem(src, item, 1) and W:AddItem(src, item, 1) then back = back + 1 else break end end
            d[item] = q - back > 0 and (q - back) or nil
            left = left + (q - back)
        end
        if lic then saveLoad(lic) end
        notify(src, left > 0 and 'warn' or 'success', left > 0 and ('Sac plein : %d objets restent dans le chargement, tu les retrouveras avec le prochain véhicule.'):format(left) or ('Tu as rendu ton ' .. VEH.short .. '.'))
    end
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)
RegisterNetEvent(RES .. ':kit', function(id, what)
    local src = source
    if not throttle(src) or not W:CanAct(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    local c = pos(src)
    if not s or s.kind ~= 'shop' or not c or d2(c, s) > 5 then return end
    if what == 'take' then
        local ok, msg = giveKit(src)
        notify(src, ok and 'success' or 'error', msg)
    else
        takeKit(src, false)
        notify(src, 'success', 'Tu as rendu l\'outil au guide.')
    end
    TriggerClientEvent(RES .. ':refresh', src, s.id)
end)

-- Builder (F10 › Builder › ...) --------------------------------------------------------------------------------------------------------------------------------------
local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = d2(c, s) if d < 15 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Aucun point à moins de 15 m.') return false end
        local s = table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', ('« %s » supprimé.'):format(s.label))
        return true
    end
    if what ~= 'zone' and what ~= 'market' and what ~= 'shop' and not (what == 'car' and VEH) then return false end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    local n = 1
    while find(spots, what .. '_' .. n) do n = n + 1 end
    local def = { zone = FARM.zone_label, market = FARM.market, shop = FARM.guide, car = 'Sortie du véhicule' }
    local row = { id = what .. '_' .. n, kind = what, label = name ~= '' and name or def[what], x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, h = math.floor((GetEntityHeading(GetPlayerPed(src)) or 0.0) * 10) / 10 }
    if what == 'zone' then row.radius = 120 end
    spots[#spots + 1] = row
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : ' .. row.label)
    notify(src, 'success', row.label .. ' posé ici' .. (what == 'zone' and ' (rayon 120 m, modifiable dans le panel).' or '.'))
    return true
end

local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        local points = {
            { id = 'zone', label = FARM.zone_label .. ' (rayon 120 m, au centre)', ask = 'Nom affiché (vide = « ' .. FARM.zone_label .. ' »)' },
            { id = 'market', label = FARM.market .. ' (revente, prix variables)', ask = 'Nom affiché (vide = « ' .. FARM.market .. ' »)' },
            { id = 'shop', label = FARM.guide .. ' (prête l\'outil)', ask = 'Nom affiché (vide = « ' .. FARM.guide .. ' »)' },
        }
        if VEH then points[#points + 1] = { id = 'car', label = 'Sortie du véhicule prêté (dans ton sens)' } end
        points[#points + 1] = { id = 'delete', label = 'Supprimer le point le plus proche' }
        W:RegisterBuilder({ list = true, id = FARM.key, label = FARM.label, icon = FARM.icon or 'map', points = points }, function(src, what, extra)
            if what == '__list' then
                local out = {}
                for _, s in ipairs(cfg('spots', {}) or {}) do out[#out + 1] = { key = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
                return out
            elseif what == '__delete' then
                local spots = cfg('spots', {}) or {}
                for i, s in ipairs(spots) do
                    if tostring(s.id) == tostring(extra) then table.remove(spots, i) W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression') return true end
                end
                return false
            end
            return placeSpot(src, tostring(what), tostring(extra or ''))
        end)
    end)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
AddEventHandler('onResourceStop', function(res) if res == RES then saveMarket() end end)
