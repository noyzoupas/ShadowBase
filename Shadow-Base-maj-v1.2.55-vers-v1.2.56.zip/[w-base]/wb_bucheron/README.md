# wb_bucheron — bûcheronnage (extension Shadow Base)

- **Chef de chantier forestier** (PNJ, posé au Builder : F10 › Builder › Activités et extensions › Bûcheron) : « Demander une hache » prête une **hache** gratuitement. Aucun métier ni entreprise : c'est du farm libre, comme la chasse.
- **Zones de coupe** (rayon 120 m réglable) : des arbres apparaissent autour de toi (un toutes les 20 s, 6 en même temps par défaut).
- **Raretés** : pin et résine (communs), chêne (peu commun), noyer (rare), ébène (épique), arbre ancien (légendaire).
- **Abattage** : E près d'un arbre, avec la hache du guide.
- **Scierie du bûcheron** (PNJ) : le marchand reprend d'abord la hache prêtée (sans elle, pas de vente), puis rachète le bois. Prix volontairement bas (35 % des prix de base). Chaque vente fait baisser le cours, qui remonte avec le temps.
- La scierie de transformation reste dans **Activités**.
- Réglages : panel › Extensions › Bûcheron.
