/* Tablette de l'atelier d'armes : recettes, matériaux et où les trouver. Le serveur vérifie tout ; ici on affiche et on demande.
   Tout texte reçu est inséré avec textContent. */
'use strict';
const $ = (id) => document.getElementById(id);
const h = (tag, attrs, ...kids) => {
  const e = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v == null) return; if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); });
  kids.flat().forEach((c) => { if (c != null) e.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c))); });
  return e;
};
const post = (name, d) => { if (typeof GetParentResourceName !== 'function') { window.__posts = (window.__posts || []).concat([[name, d]]); return; } fetch('https://' + GetParentResourceName() + '/' + name, { method: 'POST', body: JSON.stringify(d || {}) }).catch(() => {}); };
let D = null, page = 'weapons', sel = null, qty = 1, focusItem = null;

function scale() {
  const k = Math.min(1.15, Math.min(window.innerWidth / 1360, window.innerHeight / 820));
  document.documentElement.style.setProperty('--k', String(k));
}
window.addEventListener('resize', scale);
function ink(hex) {
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
  if (!m) return '#fff';
  const v = (parseInt(m[1], 16) * 299 + parseInt(m[2], 16) * 587 + parseInt(m[3], 16) * 114) / 1000;
  return v > 150 ? '#0b0b0f' : '#fff';
}
const pages = () => (D.cats || []).map((c) => ({ id: c.id, label: c.label, desc: c.desc, n: (D.recipes || []).filter((r) => r.cat === c.id).length }))
  .sort((a, b) => (a.id === 'weapons' ? -1 : b.id === 'weapons' ? 1 : 0))
  .concat([{ id: 'sources', label: 'Où trouver', desc: 'Les lieux où récupérer les matériaux, et le marché noir de cet atelier.' }, { id: 'market', label: 'Plans', desc: 'Chaque famille d\'armes demande un plan, jamais consommé.' }]);

function draw() {
  if (!D) return;
  $('spot').textContent = D.label || 'Atelier';
  $('lvl').textContent = 'Armurier niv. ' + D.level;
  $('xp').textContent = D.next ? D.xp + ' / ' + D.next + ' XP' : D.xp + ' XP';
  $('xpbar').style.width = (D.next ? Math.min(100, D.xp / D.next * 100) : 100) + '%';
  const nav = $('nav'); nav.textContent = '';
  const list = pages();
  list.forEach((p) => nav.appendChild(h('button', { class: 'nv' + (p.id === page ? ' on' : ''), onclick: () => { page = p.id; sel = null; qty = 1; focusItem = null; draw(); } }, p.label, p.n ? h('em', null, p.n) : null)));
  const cur = list.find((p) => p.id === page) || list[0];
  $('title').textContent = cur.label; $('sub').textContent = cur.desc || '';
  const body = $('body'); body.textContent = '';
  if (page === 'sources') body.appendChild(viewSources());
  else if (page === 'market') body.appendChild(viewPlans());
  else body.appendChild(viewRecipes());
  drawDetail();
}
function state(r) {
  if (!r.lvOk) return ['Niveau ' + r.level, ''];
  if (r.plan && !r.planOk) return ['Plan manquant', 'bad'];
  return r.can ? ['Prêt', 'ok'] : ['Matériaux', ''];
}
function viewRecipes() {
  const rec = (D.recipes || []).filter((r) => r.cat === page);
  if (!sel || sel.cat !== page) sel = rec.find((r) => r.can) || rec[0] || null;
  const g = h('div', { class: 'grid' });
  rec.forEach((r) => {
    const s = state(r);
    g.appendChild(h('button', { class: 'card' + (sel && sel.id === r.id ? ' on' : '') + (r.lvOk ? '' : ' dim'), onclick: () => { sel = r; qty = 1; draw(); } },
      h('div', { class: 'r' }, h('b', null, r.label), h('span', { class: 'pill ' + s[1] }, s[0])),
      h('small', null, r.needs.map((x) => x.label + ' ×' + x.need).join(' · '))));
  });
  return g;
}
const rawOf = (item) => (D.raw || []).find((x) => x.item === item);
const recipeFor = (item) => (D.recipes || []).find((r) => r.item === item);
function drawDetail() {
  const d = $('detail'); d.textContent = '';
  if (page === 'sources' || page === 'market') {
    d.appendChild(h('h2', null, 'Comment ça marche'));
    d.appendChild(h('p', { class: 'why' }, 'La ferraille et la poudre se récupèrent sur place dans les lieux indiqués, ou s\'achètent au marché noir de l\'atelier, en argent sale d\'abord. Toutes les autres pièces se fabriquent ici à partir de ces matériaux.'));
    return;
  }
  if (!sel) { d.appendChild(h('p', { class: 'why' }, 'Choisis une recette.')); return; }
  const r = sel;
  d.appendChild(h('h2', null, r.label));
  d.appendChild(h('div', { class: 'meta' }, h('span', { class: 'pill' }, 'Niveau ' + r.level), h('span', { class: 'pill' }, r.time + ' s'), h('span', { class: 'pill' }, 'Raté ' + r.fail + ' %'), r.qty > 1 ? h('span', { class: 'pill ac' }, '× ' + r.qty) : null));
  d.appendChild(h('h3', null, 'Il te faut'));
  r.needs.forEach((x) => {
    const need = x.need * qty, ok = x.have >= need;
    const made = recipeFor(x.item), raw = rawOf(x.item);
    d.appendChild(h('div', { class: 'need ' + (ok ? 'yes' : 'no') },
      h('div', { class: 'r' }, h('span', null, x.label), h('em', null, x.have + ' / ' + need)),
      h('div', { class: 'bar' }, h('i', { style: 'width:' + Math.min(100, x.have / Math.max(1, need) * 100) + '%' })),
      !ok && raw ? h('button', { class: 'link', onclick: () => { page = 'sources'; focusItem = x.item; draw(); } }, 'Où en trouver') : null,
      !ok && !raw && made ? h('button', { class: 'link', onclick: () => { page = made.cat; sel = made; qty = 1; draw(); } }, 'Se fabrique ici : voir la recette') : null));
  });
  if (r.plan) d.appendChild(h('div', { class: 'need ' + (r.planOk ? 'yes' : 'no') }, h('div', { class: 'r' }, h('span', null, r.plan), h('em', null, r.planOk ? 'Possédé' : 'Manquant')),
    r.planOk ? null : h('button', { class: 'link', onclick: () => { page = 'market'; draw(); } }, 'Acheter le plan')));
  d.appendChild(h('div', { class: 'sp' }));
  if (r.batch > 1) d.appendChild(h('div', { class: 'qty' }, h('button', { onclick: () => { qty = Math.max(1, qty - 1); draw(); } }, '−'), h('span', null, 'Quantité : ' + qty), h('button', { onclick: () => { qty = Math.min(r.batch, qty + 1); draw(); } }, '+')));
  const enough = r.needs.every((x) => x.have >= x.need * qty);
  const why = !r.lvOk ? 'Niveau d\'armurier ' + r.level + ' requis.' : (r.plan && !r.planOk) ? 'Il te manque le plan.' : !enough ? 'Il te manque des matériaux.' : null;
  d.appendChild(h('button', { class: 'go', disabled: why ? 'disabled' : null, onclick: () => post('start', { id: D.id, rid: r.id, n: qty }) }, 'Fabriquer'));
  d.appendChild(h('p', { class: 'why' }, why || (r.cat === 'weapons' ? 'Un assemblage minutieux améliore la finition.' : 'Reste près de l\'établi pendant la fabrication.')));
}
function viewSources() {
  const w = h('div', null);
  (D.raw || []).forEach((m) => {
    const card = h('div', { class: 'card' + (focusItem === m.item ? ' on' : ''), style: 'margin-bottom:10px;cursor:default' },
      h('div', { class: 'r' }, h('b', null, m.label), h('span', { class: 'pill' }, 'Tu en as ' + m.have)));
    if (m.places.length) m.places.forEach((p) => card.appendChild(h('div', { class: 'place' }, h('div', null, h('b', null, p.label), h('small', null, 'À ' + (p.dist >= 1000 ? (p.dist / 1000).toFixed(1) + ' km' : p.dist + ' m'))),
      h('button', { class: 'mini', onclick: () => post('gps', { x: p.x, y: p.y }) }, 'GPS'))));
    else card.appendChild(h('small', null, 'Aucun lieu indiqué pour le moment.'));
    if (m.price) card.appendChild(h('div', { class: 'place' }, h('div', null, h('b', null, 'Marché noir de cet atelier'), h('small', null, '$' + m.price + ' l\'unité')),
      h('button', { class: 'mini alt', onclick: () => post('buy', { id: D.id, item: m.item, qty: 5 }) }, 'Acheter 5'), h('button', { class: 'mini alt', onclick: () => post('buy', { id: D.id, item: m.item, qty: 25 }) }, '25')));
    w.appendChild(card);
  });
  return w;
}
function viewPlans() {
  const g = h('div', { class: 'grid' });
  (D.market || []).filter((m) => m.plan).forEach((m) => g.appendChild(h('div', { class: 'card', style: 'cursor:default' },
    h('div', { class: 'r' }, h('b', null, m.label), h('span', { class: 'pill ' + (m.owned ? 'ok' : '') }, m.owned ? 'Possédé' : '$' + m.price)),
    m.owned ? null : h('button', { class: 'mini', style: 'align-self:flex-start', onclick: () => post('buy', { id: D.id, item: m.item, qty: 1 }) }, 'Acheter'))));
  return g;
}
function tick() { const d = new Date(); $('clock').textContent = d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
setInterval(tick, 5000);
function open(data) {
  const keep = sel && sel.id;
  D = data; scale(); tick();
  const r = document.documentElement.style;
  if (/^#[0-9a-f]{6}$/i.test(D.color || '')) { r.setProperty('--ac', D.color); r.setProperty('--ac-ink', ink(D.color)); }
  sel = keep ? (D.recipes || []).find((x) => x.id === keep) || null : null;
  $('scr').hidden = false;
  draw();
}
window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.a === 'open') open(m.data);
  else if (m.a === 'close') $('scr').hidden = true;
});
const quit = () => { $('scr').hidden = true; post('close', {}); };
$('quit').addEventListener('click', quit);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('scr').hidden) quit(); });
