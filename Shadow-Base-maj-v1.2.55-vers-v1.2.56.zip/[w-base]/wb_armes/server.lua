-- Shadow Base — Atelier d'armes clandestin (serveur).
--   Ateliers : points cachés posés au Builder (aucune icône, jamais envoyés à l'avance : signalés seulement au joueur qui est juste à côté).
--   Accès : tout le monde, ou réservé à des gangs / entreprises (réglage du point).
--   Fabrication en chaîne : ferraille → pièces d'acier → pièces d'arme → armes (plan nécessaire) ; munitions ; démontage.
--   Niveau d'armurier par personnage : débloque les recettes, réduit les ratés, améliore la qualité.
--   Qualité (artisanale, correcte, excellente) : selon le niveau et le mini-jeu d'assemblage ; une arme excellente est livrée avec une boîte de munitions.
--   Le serveur vérifie distance, objets, plan, niveau et durée réelle de la fabrication.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'

local cache = {}
local function cfg(k, d) local v = cache[k] if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end if v == nil then return d end return v end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Atelier', text) end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function dist(src, s) local c = pos(src) if not c then return 9999 end return #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end
-- Onglet Économie du panel (v1.2.42) : prix × multiplicateur × TVA, gains × salaires (× illégal / × activités)
local function ecoPrice(n) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoPrice(n) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function ecoIn(n, kind) n = tonumber(n) or 0 local ok, v = pcall(function() return W:EcoIncome(n, kind) end) return (ok and tonumber(v)) and math.floor(tonumber(v)) or math.floor(n) end
local function now() return os.time() end
local function label(item) local i = W:ItemInfo(item) return i and i.label or item end
local function charId(src) local ok, id = pcall(function() return W:GetCharId(src) end) return ok and id or W:GetLicense(src) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < (ms or 600) then return false end last[src] = t return true end

-- Niveau d'armurier ---------------------------------------------------------------------------------------------------------------------------
local xpCache = {}
local function xpOf(src)
    local id = charId(src)
    if not id then return 0 end
    if xpCache[id] == nil then xpCache[id] = tonumber(MySQL.scalar.await('SELECT xp FROM wb_armes_skill WHERE charid = ?', { id })) or 0 end
    return xpCache[id]
end
local function levelOf(xp) local lv = 1 for i, min in ipairs(LEVELS) do if xp >= min then lv = i end end return lv end
local function addXp(src, n)
    local id = charId(src)
    if not id or n <= 0 then return end
    local before = levelOf(xpOf(src))
    xpCache[id] = xpOf(src) + n
    MySQL.update.await('INSERT INTO wb_armes_skill (charid, xp) VALUES (?, ?) ON DUPLICATE KEY UPDATE xp = ?', { id, xpCache[id], xpCache[id] })
    local after = levelOf(xpCache[id])
    if after > before then notify(src, 'success', ('Armurier niveau %d : de nouvelles recettes sont à ta portée.'):format(after)) end
end

-- Accès à un atelier : « » ou « all » = tout le monde ; sinon jetons « gang:<id> » et « biz:<id> » séparés par des virgules
local function canUse(src, s)
    local acc = tostring(s.access or ''):gsub('%s', '')
    if acc == '' or acc == 'all' then return true end
    local ok, staff = pcall(function() return W:IsStaffOnDuty(src) end)
    if ok and staff then return true end
    local job = W:GetJob(src)
    local okg, gang = pcall(function() return W:GetPlayerGang(src) end)
    for tok in acc:gmatch('[^,]+') do
        if tok == 'all' then return true end
        if job and tok == 'biz:' .. tostring(job.biz) then return true end
        if okg and gang and tok == 'gang:' .. tostring(gang) then return true end
    end
    return false
end

-- Réglages, page du panel ---------------------------------------------------------------------------------------------------------------------
local function setup()
    W:ExtRegister({ label = "Atelier d'armes", version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, "Modifier l'atelier d'armes clandestin", true)
    W:ExtMigrate(RES .. '_001_tables', "Atelier d'armes : niveaux et journal", {
        [[CREATE TABLE IF NOT EXISTS wb_armes_skill (charid VARCHAR(80) NOT NULL, xp INT NOT NULL DEFAULT 0, PRIMARY KEY (charid))]],
        [[CREATE TABLE IF NOT EXISTS wb_armes_log (id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, charid VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', recipe VARCHAR(32) NOT NULL, n INT NOT NULL DEFAULT 1, ok TINYINT(1) NOT NULL DEFAULT 1, quality VARCHAR(16) NOT NULL DEFAULT '', spot VARCHAR(40) NOT NULL DEFAULT '', PRIMARY KEY (id), KEY k_at (at))]],
    })
    for _, p in ipairs(PARTS) do W:EnsureItem({ name = p.name, label = p.label, weight = p.weight, stack = p.stack or 50, kind = 'misc', usable = false, description = p.desc }) end
    for _, p in ipairs(PLANS) do W:EnsureItem({ name = p.name, label = p.label, weight = 50, stack = 1, kind = 'misc', usable = false, description = "Plan d'atelier : jamais consommé, il débloque une famille d'armes." }) end
    for _, w in ipairs(WEAPONS) do
        if not W:ItemInfo(w.item) then pcall(function() W:EnsureWeapon({ item = w.item, label = w.label, hash = w.hash, ammo_item = w.ammo_item, ammo_label = w.ammo_label, weight = w.weight, permit = true }) end) end
    end
    local main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = "Atelier d'armes actif", default = true },
        { k = 'alert_chance', type = 'number', label = "Chance qu'une arme terminée alerte la police (%)", default = 15, min = 0, max = 100 },
        { k = 'xp_mult', type = 'number', label = "Multiplicateur d'expérience (%)", default = 100, min = 10, max = 1000 },
        { k = 'time_mult', type = 'number', label = 'Durée des fabrications (%)', default = 100, min = 10, max = 500 },
        { k = 'price_mult', type = 'number', label = 'Prix du marché noir (%)', default = 100, min = 10, max = 1000 },
        { k = 'batch_max', type = 'number', label = 'Quantité maximum par fabrication (pièces, munitions)', default = 10, min = 1, max = 50 },
        { k = 'minigame', type = 'toggle', label = "Mini-jeu d'assemblage pour les armes", default = true },
        { k = 'gather_min', type = 'number', label = 'Attente avant de refouiller un même lieu (minutes)', default = 10, min = 0, max = 1440 },
    } })
    local spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Ateliers', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Ateliers cachés', default = {}, wide = true, maxitems = 50, unique = 'id',
          hint = "Pose-les en jeu : F10 › Builder › Atelier d'armes. Accès : vide = tout le monde ; sinon par ex. « gang:ballas,biz:mecano ». Aucune icône sur la carte : à trouver en RP.",
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
            { k = 'access', label = 'Accès', maxlen = 200, pattern = '^[%w_:,%-]*$' },
            { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false },
            { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false }, { k = 'h', label = 'Cap', type = 'number', min = 0, max = 360, int = false } } } } })
    local sources = W:ExtSettings({ ns = NS, id = 'sources', title = 'Lieux des matériaux', perm = PERM, fields = {
        { k = 'sources', type = 'rows', label = 'Lieux où récupérer ferraille et poudre', default = {}, wide = true, maxitems = 60, unique = 'id',
          hint = "Pose-les en jeu : F10 › Builder › Atelier d'armes. Ils sont listés dans la tablette de l'atelier, avec le GPS.",
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'item', label = 'Objet', pattern = '^[%w_]+$', required = true, maxlen = 40 }, { k = 'label', label = 'Nom', required = true, maxlen = 40 },
            { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false }, { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false } } } } })
    W:ExtModule({
        id = RES, label = "Atelier d'armes", icon = 'wrench', perm = PERM, hint = 'Ateliers cachés, pièces, plans, niveaux, qualité',
        doc = "## Atelier d'armes clandestin\nDes **ateliers cachés** (aucune icône) posés au Builder, à trouver en RP. Le joueur y voit une invite **E** seulement quand il est juste à côté.\n\n"
            .. "- **Chaîne de fabrication** : ferraille → pièces d'acier → ressorts, canons, culasses, carcasses, crosses → armes. Munitions avec douilles et poudre. Démontage d'armes pour récupérer des pièces.\n"
            .. "- **Plans** : chaque famille d'armes demande un plan (jamais consommé), vendu au marché noir de l'atelier.\n"
            .. "- **Niveau d'armurier** (1 à 10, par personnage) : débloque les recettes, réduit les ratés et améliore la qualité.\n"
            .. "- **Qualité** : artisanale, correcte ou excellente, selon le niveau et le **mini-jeu d'assemblage** (touches à presser au bon moment). Une arme excellente est livrée avec une boîte de munitions.\n"
            .. "- **Raté** : une partie des pièces est perdue.\n- **Police** : une arme terminée peut déclencher une alerte (réglable).\n- **Accès** : un atelier peut être réservé à des gangs ou à des entreprises.\n\nPoser un atelier : **F10 › Builder › Atelier d'armes**.",
        tabs = { { id = 'main', label = 'Réglages', icon = 'sliders', form = main }, { id = 'spots', label = 'Ateliers', icon = 'pin', form = spots }, { id = 'sources', label = 'Lieux des matériaux', icon = 'pin', form = sources } },
    })
end

-- Ateliers cachés : signalés seulement au joueur qui est juste à côté (6 m) ---------------------------------------------------------------------
local nearSent = {}
CreateThread(function()
    while true do
        Wait(1500)
        local spots = cfg('enabled', true) ~= false and (cfg('spots', {}) or {}) or {}
        for _, id in ipairs(GetPlayers()) do
            local src = tonumber(id)
            local c = pos(src)
            local list, key = {}, ''
            if c then for _, s in ipairs(spots) do if #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) < 6.0 then list[#list + 1] = { id = s.id, label = s.label, x = s.x, y = s.y, z = s.z } key = key .. s.id end end end
            -- lieux des matériaux : l'invite E n'existe qu'à côté, comme pour les ateliers
            if c and cfg('enabled', true) ~= false then
                for _, x in ipairs(cfg('sources', {}) or {}) do
                    if #(c - vector3(x.x + 0.0, x.y + 0.0, x.z + 0.0)) < 6.0 then
                        list[#list + 1] = { id = x.id, label = x.label, x = x.x, y = x.y, z = x.z, source = true, verb = (RAW_BY[x.item] or {}).verb }
                        key = key .. x.id
                    end
                end
            end
            if nearSent[src] ~= key then nearSent[src] = key TriggerClientEvent(RES .. ':near', src, json.encode(list)) end
        end
    end
end)
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == NS then cache = {} nearSent = {} end end)

-- Menu de l'atelier --------------------------------------------------------------------------------------------------------------------------------
local function price(p) return math.max(1, ecoPrice(p * (tonumber(cfg('price_mult', 100)) or 100) / 100)) end
local function secsOf(r, n) return math.max(3, math.min(600, math.floor(r.time * n * (n > 1 and 0.85 or 1) * (tonumber(cfg('time_mult', 100)) or 100) / 100))) end
-- chance de raté (%) : baisse avec l'écart de niveau et le score du mini-jeu
local function failChance(r, lv, score)
    local diff = lv - r.level
    if r.cat == 'weapons' then return math.max(2, 22 - diff * 5 - (score or 0) * 4) end
    if r.cat == 'scrap' then return 0 end
    return math.max(0, 8 - diff * 3)
end
local function menuData(src, s)
    local xp = xpOf(src)
    local lv = levelOf(xp)
    local list = {}
    for _, r in ipairs(RECIPES) do
        local needs, can = {}, true
        for _, n in ipairs(r.needs) do
            local have = W:GetItemCount(src, n[1]) or 0
            needs[#needs + 1] = { item = n[1], label = label(n[1]), have = have, need = n[2] }
            if have < n[2] then can = false end
        end
        local planOk = not r.plan or W:HasItem(src, r.plan, 1)
        local stack = r.cat ~= 'weapons' and r.cat ~= 'scrap'
        list[#list + 1] = { id = r.id, cat = r.cat, label = r.label, out = label(r.out), qty = r.qty, needs = needs, level = r.level, plan = r.plan and label(r.plan) or nil, planOk = planOk,
            lvOk = lv >= r.level, can = can and planOk and lv >= r.level, time = secsOf(r, 1), fail = failChance(r, lv, r.cat == 'weapons' and 1 or 0), batch = stack and math.floor(tonumber(cfg('batch_max', 10)) or 10) or 1 }
        list[#list].item = r.out
    end
    local market = {}
    for _, m in ipairs(MARKET) do market[#market + 1] = { item = m.item, label = label(m.item), price = price(m.price) } end
    for _, p in ipairs(PLANS) do market[#market + 1] = { item = p.name, label = p.label, price = price(p.price), plan = true, owned = W:HasItem(src, p.name, 1) } end
    local nextXp = LEVELS[lv + 1]
    -- où trouver les matériaux de base : les lieux posés (du plus proche au plus loin) et le prix au marché noir
    local raw, c = {}, pos(src)
    for _, r in ipairs(RAW_ITEMS) do
        local places = {}
        for _, x in ipairs(cfg('sources', {}) or {}) do
            if x.item == r.item then places[#places + 1] = { label = x.label, x = x.x, y = x.y, dist = c and math.floor(#(vector2(c.x, c.y) - vector2(x.x + 0.0, x.y + 0.0))) or 0 } end
        end
        table.sort(places, function(a, b) return a.dist < b.dist end)
        local cost
        for _, m in ipairs(MARKET) do if m.item == r.item then cost = price(m.price) end end
        raw[#raw + 1] = { item = r.item, label = label(r.item), have = W:GetItemCount(src, r.item) or 0, places = places, price = cost }
    end
    return json.encode({ id = s.id, label = s.label, level = lv, xp = xp, next = nextXp, recipes = list, market = market, cats = CATS, raw = raw, color = W:CfgGet('general', 'color_primary', ''), dirty = W:ItemInfo('black_money') ~= nil })
end
local function spotFor(src, id)
    if not cfg('enabled', true) then return nil end
    local s = find(cfg('spots', {}), tostring(id))
    if not s or dist(src, s) > 4.0 then return nil end
    return s
end
RegisterNetEvent(RES .. ':open', function(id)
    local src = source
    if not throttle(src, 500) or not W:CanAct(src) then return end
    local s = spotFor(src, id)
    if not s then notify(src, 'error', "Rapproche-toi de l'établi.") return end
    if not canUse(src, s) then notify(src, 'error', "Les gars de l'atelier ne te connaissent pas. Dégage.") return end
    TriggerClientEvent(RES .. ':menu', src, menuData(src, s))
end)

-- Marché noir : argent sale en priorité, sinon espèces
RegisterNetEvent(RES .. ':buy', function(id, item, qty)
    local src = source
    if not throttle(src, 500) or not W:CanAct(src) then return end
    local s = spotFor(src, id)
    if not s or not canUse(src, s) then return end
    local entry, isPlan
    for _, m in ipairs(MARKET) do if m.item == item then entry = m end end
    for _, p in ipairs(PLANS) do if p.name == item then entry, isPlan = { item = p.name, price = p.price }, true end end
    if not entry then return end
    qty = isPlan and 1 or math.max(1, math.min(50, math.floor(tonumber(qty) or 1)))
    if isPlan and W:HasItem(src, item, 1) then notify(src, 'warn', 'Tu as déjà ce plan.') return end
    local total = price(entry.price) * qty
    if not W:CanCarryItem(src, item, qty) then notify(src, 'error', 'Tu ne peux pas porter ça.') return end
    local paid
    if W:ItemInfo('black_money') and (W:GetItemCount(src, 'black_money') or 0) >= total and W:RemoveItem(src, 'black_money', total) then paid = 'argent sale'
    elseif W:Pay(src, total, 'cash', "Marché noir") then paid = 'espèces' end
    if not paid then notify(src, 'error', ('Il te faut $%d (argent sale ou espèces).'):format(total)) return end
    W:AddItem(src, item, qty)
    notify(src, 'success', ('%s × %d pour $%d (%s).'):format(label(item), qty, total, paid))
    TriggerClientEvent(RES .. ':menu', src, menuData(src, s))
end)

-- Récupérer un matériau à un lieu posé : le serveur vérifie la distance et l'attente, puis la durée du geste
local gatherJobs, gatherNext = {}, {}
AddEventHandler('playerDropped', function() gatherJobs[source] = nil end)
RegisterNetEvent(RES .. ':gather', function(id)
    local src = source
    if not throttle(src, 500) or not W:CanAct(src) or not cfg('enabled', true) then return end
    local x = find(cfg('sources', {}), tostring(id))
    local r = x and RAW_BY[x.item]
    if not r or dist(src, x) > 4.0 then return end
    local lic = W:GetLicense(src)
    local k = tostring(lic) .. ':' .. x.id
    if gatherNext[k] and gatherNext[k] > now() then notify(src, 'warn', ('Déjà fouillé. Reviens dans %d min.'):format(math.ceil((gatherNext[k] - now()) / 60))) return end
    gatherJobs[src] = { id = x.id, t = now() }
    TriggerClientEvent(RES .. ':gathergo', src, r.verb, 6)
end)
RegisterNetEvent(RES .. ':gatherdone', function()
    local src = source
    local j = gatherJobs[src]
    gatherJobs[src] = nil
    if not j or now() - j.t < 4 then return end
    local x = find(cfg('sources', {}), j.id)
    local r = x and RAW_BY[x.item]
    if not r or dist(src, x) > 5.0 then return end
    local q = math.random(r.min, r.max)
    if not W:CanCarryItem(src, r.item, q) or not W:AddItem(src, r.item, q) then notify(src, 'error', 'Ton sac est plein.') return end
    gatherNext[tostring(W:GetLicense(src)) .. ':' .. x.id] = now() + (tonumber(cfg('gather_min', 10)) or 10) * 60
    notify(src, 'success', ('%s × %d récupérée.'):format(label(r.item), q))
end)

-- Fabrication : début (le serveur note l'heure), fin (durée vérifiée, objets revérifiés) ---------------------------------------------------------
local jobs = {}
AddEventHandler('playerDropped', function() local src = source jobs[src] = nil last[src] = nil nearSent[src] = nil end)
local function missing(src, r, n)
    if r.plan and not W:HasItem(src, r.plan, 1) then return 'Il te faut le ' .. label(r.plan):lower() .. '.' end
    for _, x in ipairs(r.needs) do if (W:GetItemCount(src, x[1]) or 0) < x[2] * n then return ('Il manque : %s (%d / %d).'):format(label(x[1]), W:GetItemCount(src, x[1]) or 0, x[2] * n) end end
    return nil
end
RegisterNetEvent(RES .. ':start', function(id, rid, n)
    local src = source
    if not throttle(src, 500) or not W:CanAct(src) or jobs[src] then return end
    local s = spotFor(src, id)
    local r = RECIPE_BY[tostring(rid)]
    if not s or not r or not canUse(src, s) then return end
    local maxN = (r.cat == 'weapons' or r.cat == 'scrap') and 1 or math.floor(tonumber(cfg('batch_max', 10)) or 10)
    n = math.max(1, math.min(maxN, math.floor(tonumber(n) or 1)))
    if levelOf(xpOf(src)) < r.level then notify(src, 'error', ('Niveau d\'armurier %d requis.'):format(r.level)) return end
    local miss = missing(src, r, n)
    if miss then notify(src, 'error', miss) return end
    local secs = secsOf(r, n)
    jobs[src] = { spot = s.id, rid = r.id, n = n, t = now(), secs = secs }
    TriggerClientEvent(RES .. ':go', src, json.encode({ id = r.id, label = r.label, n = n, secs = secs, mini = r.cat == 'weapons' and cfg('minigame', true) ~= false }))
end)
RegisterNetEvent(RES .. ':cancel', function() jobs[source] = nil end)
local QUAL = { 'artisanale', 'correcte', 'excellente' }
RegisterNetEvent(RES .. ':done', function(score)
    local src = source
    local j = jobs[src]
    jobs[src] = nil
    if not j then return end
    local s = spotFor(src, j.spot)
    local r = RECIPE_BY[j.rid]
    if not s or not r then notify(src, 'error', "Tu t'es éloigné de l'établi : fabrication perdue.") return end
    if now() - j.t < j.secs - 2 then notify(src, 'error', 'Trop rapide : fabrication annulée.') return end
    local miss = missing(src, r, j.n)
    if miss then notify(src, 'error', miss) return end
    score = math.max(0, math.min(3, math.floor(tonumber(score) or 0)))
    local lv = levelOf(xpOf(src))
    -- raté : la moitié des pièces est perdue (au moins une de chaque), rien ne sort
    if math.random(100) <= failChance(r, lv, score) then
        for _, x in ipairs(r.needs) do W:RemoveItem(src, x[1], math.max(1, math.floor(x[2] * j.n / 2))) end
        addXp(src, math.floor(r.xp * j.n * 0.3 * (tonumber(cfg('xp_mult', 100)) or 100) / 100))
        notify(src, 'error', "L'assemblage a raté : une partie des pièces est perdue.")
        MySQL.insert('INSERT INTO wb_armes_log (at, charid, name, recipe, n, ok, quality, spot) VALUES (?, ?, ?, ?, ?, 0, ?, ?)', { now(), charId(src) or '', GetPlayerName(src) or '', r.id, j.n, '', s.id })
        TriggerClientEvent(RES .. ':menu', src, menuData(src, s))
        return
    end
    local outQty = r.qty * j.n
    if not W:CanCarryItem(src, r.out, outQty) then notify(src, 'error', 'Ton sac est plein : fais de la place avant de terminer.') return end
    local taken = {}
    for _, x in ipairs(r.needs) do
        if not W:RemoveItem(src, x[1], x[2] * j.n) then
            for _, t in ipairs(taken) do W:AddItem(src, t[1], t[2]) end
            notify(src, 'error', 'Il te manque des pièces.') return
        end
        taken[#taken + 1] = { x[1], x[2] * j.n }
    end
    -- qualité : niveau au-dessus de la recette + mini-jeu
    local q = 2
    if r.cat == 'weapons' then
        local pts = (lv - r.level) + score + math.random(0, 2)
        q = pts >= 5 and 3 or pts >= 2 and 2 or 1
    end
    W:AddItem(src, r.out, outQty)
    for _, e in ipairs(r.extra or {}) do if W:CanCarryItem(src, e[1], e[2]) then W:AddItem(src, e[1], e[2]) end end
    local bonus = ''
    if r.cat == 'weapons' and q == 3 then
        for _, w in ipairs(WEAPONS) do if w.item == r.out and w.ammo_item and W:ItemInfo(w.ammo_item) and W:CanCarryItem(src, w.ammo_item, 1) then W:AddItem(src, w.ammo_item, 1) bonus = ' Une boîte de munitions en prime.' end end
    end
    addXp(src, math.floor(r.xp * j.n * (q == 3 and 1.25 or 1) * (tonumber(cfg('xp_mult', 100)) or 100) / 100))
    if r.cat == 'weapons' then
        notify(src, 'success', ('%s terminé : finition %s.%s'):format(r.label, QUAL[q], bonus))
        if math.random(100) <= (tonumber(cfg('alert_chance', 15)) or 15) then
            pcall(function() W:PoliceAlert('Bruits suspects de métal : possible atelier clandestin', s.x, s.y, s.z) end)
        end
    else
        notify(src, 'success', ('%s × %d fabriqué.'):format(label(r.out), outQty))
    end
    MySQL.insert('INSERT INTO wb_armes_log (at, charid, name, recipe, n, ok, quality, spot) VALUES (?, ?, ?, ?, ?, 1, ?, ?)', { now(), charId(src) or '', GetPlayerName(src) or '', r.id, j.n, r.cat == 'weapons' and QUAL[q] or '', s.id })
    TriggerClientEvent(RES .. ':menu', src, menuData(src, s))
end)

-- Builder -------------------------------------------------------------------------------------------------------------------------------------------------
local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = #(vector2(c.x, c.y) - vector2(s.x, s.y)) if d < 10 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Aucun atelier à moins de 10 m.') return false end
        table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', 'Atelier supprimé.')
        return true
    end
    for _, r in ipairs(RAW_ITEMS) do
        if what == r.builder then
            local list = cfg('sources', {}) or {}
            local n = 1
            while find(list, r.builder .. '_' .. n) do n = n + 1 end
            local nm = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
            list[#list + 1] = { id = r.builder .. '_' .. n, item = r.item, label = nm ~= '' and nm or r.place, x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100 }
            W:CfgSet(NS, 'sources', list, GetPlayerName(src), 'Builder : ' .. r.place)
            notify(src, 'success', r.place .. ' posé ici : il apparaît dans la tablette de l\'atelier.')
            return true
        end
    end
    if what ~= 'atelier' then return false end
    local n = 1
    while find(spots, 'atelier_' .. n) do n = n + 1 end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    spots[#spots + 1] = { id = 'atelier_' .. n, label = name ~= '' and name or 'Atelier clandestin', access = '', x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, h = math.floor(GetEntityHeading(GetPlayerPed(src))) }
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), "Builder : atelier d'armes")
    notify(src, 'success', "Atelier posé ici (caché, sans icône). Accès réservé : panel › Atelier d'armes › Ateliers.")
    return true
end
local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        W:RegisterBuilder({ list = true, id = 'armes', label = "Atelier d'armes", icon = 'wrench', points = {
            { id = 'atelier', label = 'Atelier clandestin (caché)', ask = 'Nom (vide = « Atelier clandestin »)' },
            { id = 'src_ferraille', label = 'Lieu de ferraille (matériau)', ask = 'Nom (vide = « Tas de ferraille »)' },
            { id = 'src_poudre', label = 'Lieu de poudre (matériau)', ask = 'Nom (vide = « Stock de poudre »)' },
            { id = 'delete', label = "Supprimer l'atelier le plus proche" } } },
            function(src, what, extra)
            -- Builder › Existant : liste des points posés et suppression d'un point précis (plus seulement « le plus proche »)
            if what == '__list' then
                local out = {}
                for _, s in ipairs(cfg('spots', {}) or {}) do out[#out + 1] = { key = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
                for _, s in ipairs(cfg('sources', {}) or {}) do out[#out + 1] = { key = s.id, label = s.label, x = s.x, y = s.y, z = s.z } end
                return out
            elseif what == '__delete' then
                for _, k in ipairs({ 'spots', 'sources' }) do
                    local spots = cfg(k, {}) or {}
                    for i, s in ipairs(spots) do
                        if tostring(s.id) == tostring(extra) then table.remove(spots, i) W:CfgSet(NS, k, spots, GetPlayerName(src), 'Builder : suppression') return true end
                    end
                end
                return false
            end
            return placeSpot(src, tostring(what), tostring(extra or ''))
        end)
    end)
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
