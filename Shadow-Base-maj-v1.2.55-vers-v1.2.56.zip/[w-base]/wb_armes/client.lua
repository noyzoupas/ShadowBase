-- Shadow Base — Atelier d'armes clandestin (client) : invite E à côté d'un atelier caché, menu de fabrication, geste + barre,
-- mini-jeu d'assemblage (touche affichée à presser à temps) pour les armes.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local near = {}          -- ateliers signalés par le serveur (juste à côté)
local busy = false
local data               -- dernier menu reçu

local function notify(kind, text) W:Notify({ type = kind, title = 'Atelier', text = text }) end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end

RegisterNetEvent(RES .. ':near', function(j) local ok, l = pcall(json.decode, j) near = ok and type(l) == 'table' and l or {} end)

-- Invite E ------------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if #near > 0 and not busy and isFree() and not IsPedInAnyVehicle(PlayerPedId(), false) then
            sleep = 200
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(near) do local d = #(c - vector3(s.x, s.y, s.z)) if d < 2.0 and (not bd or d < bd) then best, bd = s, d end end
            if best then
                sleep = 0
                if shown ~= best.id then shown = best.id W:Prompt(best.source and (best.verb or best.label) or 'Utiliser l\'établi', 'E', best.x, best.y, best.z) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. (best.source and ':gather' or ':open'), best.id) Wait(500) end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Tablette (page html/) ------------------------------------------------------------------------------------------------------------------------
local tabletOpen = false
local function openTablet()
    if not data or busy then return end
    tabletOpen = true
    SendNUIMessage({ a = 'open', data = data })
    SetNuiFocus(true, true)
end
local function closeTablet()
    tabletOpen = false
    SendNUIMessage({ a = 'close' })
    SetNuiFocus(false, false)
end
RegisterNetEvent(RES .. ':menu', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    data = d
    if not busy then openTablet() end
end)
RegisterNUICallback('close', function(_, cb) cb(1) tabletOpen = false SetNuiFocus(false, false) end)
RegisterNUICallback('start', function(d, cb) cb(1) closeTablet() TriggerServerEvent(RES .. ':start', d.id, d.rid, d.n) end)
RegisterNUICallback('buy', function(d, cb) cb(1) TriggerServerEvent(RES .. ':buy', d.id, d.item, d.qty) end)
RegisterNUICallback('gps', function(d, cb)
    cb(1)
    local x, y = tonumber(d.x), tonumber(d.y)
    if x and y then SetNewWaypoint(x + 0.0, y + 0.0) notify('success', 'Position marquée sur ta carte.') end
end)
AddEventHandler('onResourceStop', function(r) if r == RES and tabletOpen then SetNuiFocus(false, false) end end)

-- Récupérer un matériau à un lieu posé
RegisterNetEvent(RES .. ':gathergo', function(verb, secs)
    busy = true
    local ped = PlayerPedId()
    local at = GetEntityCoords(ped)
    TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_GARDENER_PLANT', 0, true)
    W:Progress(tostring(verb), secs)
    local stop, ok = GetGameTimer() + secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - at) > 3.0 then ok = false break end
    end
    ClearPedTasks(ped)
    busy = false
    if ok then TriggerServerEvent(RES .. ':gatherdone') else W:CancelProgress() end
end)

-- Fabrication : geste + barre ; X ou s'éloigner annule ; mini-jeu pour les armes -----------------------------------------------------------------------
local KEYS = { { 'E', 38 }, { 'G', 47 }, { 'F', 23 } }
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
RegisterNetEvent(RES .. ':go', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    busy = true
    local ped = PlayerPedId()
    local at = GetEntityCoords(ped)
    if d.mini then TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_WELDING', 0, true)
    elseif loadDict('mini@repair') then TaskPlayAnim(ped, 'mini@repair', 'fixing_a_ped', 3.0, 3.0, -1, 1, 0, false, false, false) end
    W:Progress(d.label .. (d.n > 1 and (' × ' .. d.n) or ''), d.secs)
    local stop, done, score = GetGameTimer() + d.secs * 1000, true, 0
    -- 3 moments d'assemblage répartis dans la fabrication : la touche affichée doit être pressée en moins de 1,4 s
    local marks = {}
    if d.mini then for i = 1, 3 do marks[i] = { at = GetGameTimer() + math.floor(d.secs * 1000 * (i / 4)) + math.random(-800, 800), key = KEYS[math.random(#KEYS)] } end end
    local cur
    while GetGameTimer() < stop do
        Wait(0)
        local t = GetGameTimer()
        if not cur and marks[1] and t >= marks[1].at then cur = table.remove(marks, 1) cur.until_ = t + 1400 W:Prompt('Ajuste la pièce !', cur.key[1]) end
        if cur then
            local pressed
            for _, k in ipairs(KEYS) do if IsControlJustPressed(0, k[2]) then pressed = k end end
            if pressed then
                if pressed == cur.key then score = score + 1 PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                else PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
                cur = nil W:HidePrompt()
            elseif t > cur.until_ then cur = nil W:HidePrompt() PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
        end
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - at) > 3.0 then done = false break end
    end
    if cur then W:HidePrompt() end
    ClearPedTasks(ped)
    busy = false
    if not done then W:CancelProgress() notify('warn', 'Fabrication interrompue.') TriggerServerEvent(RES .. ':cancel') return end
    if d.mini then notify(score == 3 and 'success' or 'info', ('Assemblage : %d / 3 gestes parfaits.'):format(score)) end
    TriggerServerEvent(RES .. ':done', score)
end)
