-- Shadow Base — Minage libre : filons, minerais, outil prêté.
FARM = {
    key = 'minage', label = 'Minage', icon = 'gem', hint = 'Filons, minerais, marché aux prix variables',
    guide = 'Chef de mine', market = 'Comptoir des minerais', zone_label = 'Zone de minage',
    tool = { name = 'pioche_mine', label = 'Pioche (prêtée)', weight = 2500 },
    vehicle = { models = { 'rubble', 'tiptruck' }, plate = 'MINE', short = 'camion', ask = 'Prendre le camion de la mine', ok = 'Ton camion t\'attend à côté. Mine à moins de 40 m de lui : les roches vont dans sa benne.',
        desc = 'Camion prêté gratuitement : ce que tu mines près de lui va dans sa benne, et le comptoir rachète son chargement s\'il est garé à côté.' },
    blip = { 618, 31 }, scenario = 'WORLD_HUMAN_CONST_DRILL',
    anim = { dict = 'melee@large_wpn@streamed_core', name = 'ground_attack_on_spot', flag = 1 },
    prop = { models = { 'prop_tool_pickaxe' }, bone = 57005, pos = { 0.09, 0.03, -0.02 }, rot = { -78.0, 13.0, 28.0 } }, progress = 'Extraction du minerai', secs = 8, verb = 'Miner',
    spawn_label = 'Un filon apparaît', spawn_many = 'Filons',
    models = { 'prop_rock_4_c', 'prop_rock_1_a', 'prop_rock_3_a', 'prop_rock_2_a' },
    npc = { shop = 's_m_y_construct_01', market = 's_m_y_construct_02' },
    ask = 'Demander une pioche', kit_ok = 'Le chef de mine te prête une pioche. Rends-la au comptoir des minerais en vendant ta récolte.',
    kit_desc = 'Le chef de mine te prête une pioche gratuitement. Le comptoir des minerais la reprend avant la vente.',
    guide_prompt = 'Parler au chef de mine', sell_prompt = 'Vendre tes minerais', sell_sub = 'Vendre tes minerais',
    rarity_text = 'Pierre et charbon (communs), fer et cuivre (peu communs), argent (rare), or (épique), diamant brut (légendaire).',
    doc = "## Minage\nVa voir le **chef de mine** : « Demander une pioche » te la prête gratuitement. Dans une **zone de minage**, des filons apparaissent autour de toi : **E** pour extraire. Revends au **comptoir des minerais** (il reprend la pioche d'abord). Aucun métier nécessaire.",
}
FARM_RARITY = {
    { id = 'c',  label = 'Commun',     weight = 60 },
    { id = 'pc', label = 'Peu commun', weight = 26 },
    { id = 'r',  label = 'Rare',       weight = 10 },
    { id = 'e',  label = 'Épique',     weight = 3 },
    { id = 'l',  label = 'Légendaire', weight = 1 },
}
FARM_RARITY_BY = {}
for i, r in ipairs(FARM_RARITY) do r.n = i FARM_RARITY_BY[r.id] = r end

-- loot : { objet, min, max }
FARM_NODES = {
    { id = 'pierre',  label = 'Roche',          rarity = 'c',  time = 6, loot = { { 'stone', 2, 4 } } },
    { id = 'charbon', label = 'Veine de charbon', rarity = 'c', time = 7, loot = { { 'coal', 1, 3 } } },
    { id = 'fer',     label = 'Filon de fer',    rarity = 'pc', time = 8, loot = { { 'iron_ore', 1, 3 } } },
    { id = 'cuivre',  label = 'Filon de cuivre', rarity = 'pc', time = 8, loot = { { 'copper_ore', 1, 3 } } },
    { id = 'argent',  label = "Filon d'argent",  rarity = 'r',  time = 9, loot = { { 'silver_ore', 1, 2 } } },
    { id = 'or',      label = "Filon d'or",      rarity = 'e',  time = 10, loot = { { 'gold_nugget', 1, 2 } } },
    { id = 'diamant', label = 'Poche de diamants', rarity = 'l', time = 12, loot = { { 'diamond_raw', 1, 1 } } },
}
-- Produits vendus au comptoir (prix de base ; plus c'est rare, plus le cours chute vite quand on en vend beaucoup)
FARM_GOODS = {
    { name = 'stone',        label = 'Pierre',            rarity = 'c',  price = 6,   weight = 1500 },
    { name = 'coal',         label = 'Charbon',           rarity = 'c',  price = 9,   weight = 1200 },
    { name = 'iron_ore',     label = 'Minerai de fer',    rarity = 'pc', price = 18,  weight = 1500 },
    { name = 'copper_ore',   label = 'Minerai de cuivre', rarity = 'pc', price = 22,  weight = 1500 },
    { name = 'silver_ore',   label = "Minerai d'argent",  rarity = 'r',  price = 70,  weight = 1200 },
    { name = 'gold_nugget',  label = "Pépite d'or",       rarity = 'e',  price = 220, weight = 300 },
    { name = 'diamond_raw',  label = 'Diamant brut',      rarity = 'l',  price = 900, weight = 100 },
}

FARM_NODE_BY, FARM_GOOD_BY = {}, {}
for _, n in ipairs(FARM_NODES) do FARM_NODE_BY[n.id] = n end
for _, g in ipairs(FARM_GOODS) do FARM_GOOD_BY[g.name] = g end
