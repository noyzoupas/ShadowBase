# wb_minage — minage (extension Shadow Base)

- **Chef de mine** (PNJ, posé au Builder : F10 › Builder › Activités et extensions › Minage) : « Demander une pioche » prête une **pioche** gratuitement. Aucun métier ni entreprise : c'est du farm libre, comme la chasse.
- **Zones de minage** (rayon 120 m réglable) : des filons apparaissent autour de toi (un toutes les 20 s, 6 en même temps par défaut).
- **Raretés** : pierre et charbon (communs), fer et cuivre (peu communs), argent (rare), or (épique), diamant brut (légendaire).
- **Extraction** : E près d'un filon, avec la pioche du guide.
- **Comptoir des minerais** (PNJ) : le marchand reprend d'abord la pioche prêtée (sans elle, pas de vente), puis rachète les minerais. Prix volontairement bas (35 % des prix de base) : les entreprises restent la vraie source de revenus. Chaque vente fait baisser le cours, qui remonte avec le temps.
- Les fonderies, le concasseur et la verrerie restent dans **Activités**.
- Réglages : panel › Extensions › Minage.
