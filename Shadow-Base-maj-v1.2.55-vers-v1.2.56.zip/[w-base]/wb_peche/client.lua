-- Shadow Base — Pêche (client) : eau devant soi, choix de l'appât, attente de la touche, ferrage (E dans la zone verte ; automatique pour les VIP),
-- marchés aux poissons et magasins de pêche. Le serveur tire le poisson au sort et paie.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {} }
local blips = {}
local fishing = false
local RAR = {}
for _, r in ipairs(FISH_RARITY) do RAR[r.id] = r end

local function notify(kind, text) W:Notify({ type = kind, title = 'Pêche', text = text }) end
local function hint(text, ms) BeginTextCommandPrint('STRING') AddTextComponentSubstringPlayerName(text) EndTextCommandPrint(ms or 4000, true) end

-- Marqueur et « libre ? » en local : appeler un export de pb_panel à chaque image coûte cher (appel entre ressources)
local _keyTex, _keyChk = nil, 0
local function marker(x, y, z)
    -- (v1.2.43) même touche « E » arrondie que Shadow Base (texture pb_ui/key_e créée par pb_panel), sinon petit point lumineux
    local pz = z + 1.0
    if _keyTex == nil or GetGameTimer() > (_keyChk or 0) then
        _keyChk = GetGameTimer() + 5000
        local res = GetTextureResolution('pb_ui', 'key_e')
        _keyTex = res and res.x and res.x > 4 or false
    end
    if _keyTex then
        local ok, sx, sy = GetScreenCoordFromWorldCoord(x + 0.0, y + 0.0, pz + 0.0)
        if not ok then return end
        local d = #(GetEntityCoords(PlayerPedId()) - vector3(x + 0.0, y + 0.0, pz + 0.0))
        local k = math.max(0.55, 1.0 - d / 30.0)
        local hs = 0.036 * k
        DrawSprite('pb_ui', 'key_e', sx, sy, hs / GetAspectRatio(false), hs, 0.0, 255, 255, 255, math.floor(math.max(90, 235 - d * 9)))
        return
    end
    local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local freeCache, freeAt = false, 0
local function isFree()
    local now = GetGameTimer()
    if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end
    return freeCache
end
-- Points (marchés, magasins) ------------------------------------------------------------------------------------------------------------------------
local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, s in ipairs(C.spots or {}) do
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, s.kind == 'market' and 356 or 52) SetBlipColour(b, s.kind == 'market' and 3 or 38) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end)
-- Réinitialisation des repères (/blips reset ou panel) : on efface les nôtres et on redemande la liste
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if C.enabled and not fishing and isFree() then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(C.spots or {}) do local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end
            if best and bd < 30.0 then
                sleep = 0
                marker(best.x, best.y, best.z - 0.95)
                if bd < 2.5 then
                    if shown ~= best.id then shown = best.id W:Prompt((best.kind == 'market' and 'Vendre ta pêche : ' or 'Acheter : ') .. best.label, 'E', best.x, best.y, best.z) end
                    if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':open', best.id) Wait(500) end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Eau devant soi, type d'eau ---------------------------------------------------------------------------------------------------------------------------
local LAKES = { { 300, 3450, 2700, 4800 }, { 1500, -250, 2300, 700 }, { 1020, -720, 1180, -560 } }   -- Alamo Sea, réservoir Land Act, lac de Mirror Park
local function waterAhead()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    if IsPedInAnyBoat(ped) then
        local ok, h = GetWaterHeight(c.x, c.y, c.z + 2.0)
        if ok then return vector3(c.x, c.y, h), true end
    end
    if IsPedInAnyVehicle(ped, false) then return nil end
    local fwd = GetEntityForwardVector(ped)
    for _, dist in ipairs({ 3.0, 5.0, 8.0, 11.0, 15.0 }) do
        local x, y = c.x + fwd.x * dist, c.y + fwd.y * dist
        local ok, h = GetWaterHeight(x, y, c.z + 2.0)
        if ok and h < c.z + 0.5 and h > c.z - 30.0 then return vector3(x, y, h), false end
    end
    return nil
end
local function waterType(p, boat)
    if p.z > 1.5 then
        for _, b in ipairs(LAKES) do if p.x >= b[1] and p.x <= b[3] and p.y >= b[2] and p.y <= b[4] then return 'lac' end end
        return 'riviere'
    end
    if boat then
        local ok, gz = GetGroundZFor_3dCoord(p.x, p.y, p.z, false)
        if not ok or p.z - gz > 25.0 then return 'large' end
    end
    return 'mer'
end

-- Choix de l'appât puis lancer -------------------------------------------------------------------------------------------------------------------------
local lastLure
RegisterNetEvent(RES .. ':choose', function(j)
    local ok, list = pcall(json.decode, j)
    if not ok or type(list) ~= 'table' or fishing then return end
    local items = {}
    table.sort(list, function(a, b) return (lastLure == a.name) and not (lastLure == b.name) end)
    for _, l in ipairs(list) do
        local r = RAR[l.rarity] or RAR.c
        items[#items + 1] = { label = l.label, right = ('×%d'):format(l.n), description = r.label .. (lastLure == l.name and ' · dernier utilisé' or ''),
            onSelect = function()
                W:CloseMenu()
                local p, boat = waterAhead()
                if not p then notify('error', "Mets-toi face à l'eau (ou dans un bateau).") return end
                lastLure = l.name
                TriggerServerEvent(RES .. ':cast', l.name, waterType(p, boat))
            end }
    end
    W:OpenMenu({ id = RES .. '.lure', title = 'Pêche', subtitle = 'Choisis ton appât', items = items })
end)

-- Ferrage : le curseur va et vient, E quand il est dans la zone verte -----------------------------------------------------------------------------------
local function txt(s, x, y, scale, r, g, b)
    SetTextFont(4) SetTextScale(scale, scale) SetTextColour(r or 255, g or 255, b or 255, 230) SetTextCentre(true) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(s) EndTextCommandDisplayText(x, y)
end
local function minigame(d)
    local hits, misses = 0, 0
    local zc = 0.2 + math.random() * 0.6
    local t0, deadline = GetGameTimer(), GetGameTimer() + 15000
    local phase = math.random() * 6.28
    PlaySoundFrontend(-1, 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET', true)
    while GetGameTimer() < deadline do
        Wait(0)
        DisableControlAction(0, 38, true) DisableControlAction(0, 24, true) DisableControlAction(0, 25, true)
        local t = (GetGameTimer() - t0) / 1000.0
        local pos = (math.sin(t * d.speed * 3.2 + phase) + 1) / 2
        local W0, X0, Y0 = 0.30, 0.5, 0.83
        DrawRect(X0, Y0, W0 + 0.008, 0.032, 10, 12, 16, 200)
        DrawRect(X0 - W0 / 2 + zc * W0, Y0, d.zone * W0, 0.022, 90, 210, 130, 220)
        DrawRect(X0 - W0 / 2 + pos * W0, Y0, 0.004, 0.034, 255, 255, 255, 255)
        txt(('Ça mord ! Ferre avec ~y~E~w~   %d/%d'):format(hits, d.hits), X0, Y0 - 0.055, 0.42)
        txt(('Ligne : %s'):format(string.rep('■', math.max(0, d.misses + 1 - misses)) .. string.rep('□', misses)), X0, Y0 + 0.022, 0.34, 200, 205, 214)
        if IsDisabledControlJustPressed(0, 38) then
            if math.abs(pos - zc) <= d.zone / 2 then
                hits = hits + 1
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if hits >= d.hits then return true end
                zc = 0.15 + math.random() * 0.7
            else
                misses = misses + 1
                PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if misses > d.misses then return false end
            end
        end
        if IsControlJustPressed(0, 73) or IsEntityDead(PlayerPedId()) then return false end
    end
    return false
end

-- Canne tenue en main + posture de pêche (à pied comme en bateau)
local rodObj
local function holdRod(on)
    local ped = PlayerPedId()
    if not on then
        if rodObj and DoesEntityExist(rodObj) then DeleteEntity(rodObj) end
        rodObj = nil
        StopAnimTask(ped, 'amb@world_human_stand_fishing@idle_a', 'idle_c', 2.0)
        return
    end
    local h = joaat('prop_fishing_rod_01')
    RequestModel(h)
    local t = GetGameTimer() + 2000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
    if HasModelLoaded(h) and not (rodObj and DoesEntityExist(rodObj)) then
        local c = GetEntityCoords(ped)
        rodObj = CreateObject(h, c.x, c.y, c.z, true, true, false)
        AttachEntityToEntity(rodObj, ped, GetPedBoneIndex(ped, 18905), 0.1, 0.05, 0.0, 80.0, 120.0, 160.0, true, true, false, true, 1, true)
        SetModelAsNoLongerNeeded(h)
    end
    RequestAnimDict('amb@world_human_stand_fishing@idle_a')
    t = GetGameTimer() + 2000
    while not HasAnimDictLoaded('amb@world_human_stand_fishing@idle_a') and GetGameTimer() < t do Wait(10) end
    TaskPlayAnim(ped, 'amb@world_human_stand_fishing@idle_a', 'idle_c', 3.0, 3.0, -1, IsPedInAnyVehicle(ped, false) and 49 or 1, 0, false, false, false)
end

local autoSeq = 0   -- pêche automatique VIP : numéro du lancer en cours (pour savoir si une relance a bien abouti)
RegisterNetEvent(RES .. ':bite', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' or fishing then return end
    fishing = true
    autoSeq = autoSeq + 1
    local ped = PlayerPedId()
    local start = GetEntityCoords(ped)
    local boat = IsPedInAnyVehicle(ped, false)
    holdRod(true)
    if d.auto then hint(('~y~Pêche automatique (VIP)~w~ · %s, %s. Les prises s\'enchaînent. ~y~X~w~ pour arrêter.'):format(d.rod, d.lure), 5000)
    else hint(('Ligne à l\'eau (%s, %s). Attends la touche… ~y~X~w~ pour remonter.'):format(d.rod, d.lure), 5000) end
    local bite = GetGameTimer() + d.wait * 1000
    local cancelled = false
    while GetGameTimer() < bite do
        Wait(0)
        DisableControlAction(0, 24, true) DisableControlAction(0, 25, true)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - start) > 5.0 then cancelled = true break end
    end
    if cancelled then
        holdRod(false)
        fishing = false
        TriggerServerEvent(RES .. ':cancel')
        hint('Ligne remontée.', 2000)
        return
    end
    if d.big then ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08) end
    if d.auto then
        -- VIP : la touche est ferrée toute seule (le serveur l'a décidé au lancer), puis on relance avec le même appât
        PlaySoundFrontend(-1, 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET', true)
        hint('Ça mord ! Ferrage automatique…', 1500)
        Wait(1200)
        TriggerServerEvent(RES .. ':reel', true)
        Wait(1500)
        fishing = false
        if IsControlPressed(0, 73) or IsEntityDead(ped) or #(GetEntityCoords(ped) - start) > 5.0 then holdRod(false) return end
        local p, boat2 = waterAhead()
        if not p then holdRod(false) return end
        local seq = autoSeq
        TriggerServerEvent(RES .. ':cast', d.lureName or lastLure, waterType(p, boat2))
        -- plus d'appât, sac plein, limite horaire : pas de nouvelle touche, on range la canne
        SetTimeout(4000, function() if autoSeq == seq and not fishing then holdRod(false) hint('Pêche automatique arrêtée (plus d\'appât, sac plein ou pause).', 4000) end end)
        return
    end
    local won = minigame(d)
    TriggerServerEvent(RES .. ':reel', won)
    Wait(won and 1200 or 400)
    holdRod(false)
    fishing = false
end)

RegisterNetEvent(RES .. ':net', function(secs)
    if fishing then return end
    fishing = true
    local ped = PlayerPedId()
    W:Progress('Filet à l\'eau', secs)
    local stop, ok = GetGameTimer() + secs * 1000, true
    while GetGameTimer() < stop do
        Wait(0)
        if IsControlJustPressed(0, 73) or IsEntityDead(ped) or not IsPedInAnyBoat(ped) then ok = false break end
    end
    if not ok then W:CancelProgress() end
    TriggerServerEvent(RES .. ':netdone', ok)
    fishing = false
end)

RegisterNetEvent(RES .. ':caught', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    local r = RAR[d.rarity] or RAR.c
    local text = d.kg and ('%s · %s · %.2f kg'):format(d.label, r.label, d.kg) or ('%s · %s'):format(d.label, r.label)
    W:Notify({ type = r.n >= 3 and 'success' or 'info', title = d.record and 'Nouveau record du serveur !' or 'Belle prise', text = text })
    if r.n >= 4 then PlaySoundFrontend(-1, 'MEDAL_GOLD', 'HUD_AWARDS', true) elseif r.n >= 3 then PlaySoundFrontend(-1, 'MEDAL_SILVER', 'HUD_AWARDS', true) end
end)

-- Marché et magasin ----------------------------------------------------------------------------------------------------------------------------------------
local openSpot
RegisterNetEvent(RES .. ':shop', function(id, kind, title, j, leader, vip, allT, allN)
    local ok, list = pcall(json.decode, j)
    if not ok or type(list) ~= 'table' then return end
    openSpot = id
    local items = {}
    if kind == 'market' then
        local mine, others = {}, {}
        for _, x in ipairs(list) do
            local r = RAR[x.rarity] or RAR.c
            local trend = x.pct >= 105 and ' ▲' or (x.pct <= 95 and ' ▼' or '')
            local it = { label = x.label .. (x.featured and ' ★' or ''), right = ('$%d%s'):format(x.price, trend),
                description = ('%s · cours %d %% du prix normal ($%d)%s'):format(r.label, x.pct, x.base, x.featured and ' · pêche du jour, mieux payée' or '') }
            if x.n > 0 then
                it.right = ('%d × $%d%s'):format(x.n, x.price, trend)
                it.onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sell', id, x.item) end
                mine[#mine + 1] = it
            else it.disabled = true others[#others + 1] = it end
        end
        if leader then items[#items + 1] = { label = 'Concours de la semaine', icon = 'crown', description = leader .. (vip and ' · Tu es VIP : bonus à la revente.' or ''), disabled = true } end
        if (allN or 0) > 0 then
            items[#items + 1] = { label = 'Tout vendre', icon = 'coins', right = ('$%d'):format(allT), description = ('%d objets pour $%d. Le cours baisse à chaque unité vendue : ce prix en tient compte.'):format(allN, allT),
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sellall', id) end }
            items[#items + 1] = { type = 'separator', label = 'À l\'unité' }
        end
        if #mine == 0 then items[#items + 1] = { label = 'Rien à vendre', description = 'Le marché achète tous les poissons pêchés.', disabled = true } end
        for _, it in ipairs(mine) do items[#items + 1] = it end
        if #others > 0 then items[#items + 1] = { type = 'separator', label = 'Cours du jour' } for _, it in ipairs(others) do items[#items + 1] = it end end
        W:OpenMenu({ id = RES .. '.market', title = title, subtitle = 'Vendre ta pêche', items = items })
    else
        items[#items + 1] = { type = 'separator', label = 'Cannes' }
        for _, x in ipairs(list) do
            if x.rod then
                items[#items + 1] = { label = x.label .. (x.vip and ' (VIP)' or ''), right = '$' .. x.price, disabled = x.locked or nil,
                    description = x.locked and 'Réservé aux VIP.' or ('Ferrage plus facile (%d/4) et meilleures chances de poissons rares. La meilleure canne du sac est utilisée.'):format(x.power),
                    onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':buy', id, x.item, 1) end }
            end
        end
        items[#items + 1] = { type = 'separator', label = 'Appâts et leurres' }
        for _, x in ipairs(list) do
            if x.net then
                items[#items + 1] = { type = 'separator', label = 'En bateau' }
                items[#items + 1] = { label = x.label, right = '$' .. x.price, description = "Utilise-le depuis un bateau à l'arrêt : plusieurs poissons d'un coup. Peut se déchirer.",
                    onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':buy', id, x.item, 1) end }
            elseif not x.rod then
                local r = RAR[x.rarity] or RAR.c
                local qty = x.price <= 10 and 10 or 1
                items[#items + 1] = { label = x.label .. (qty > 1 and (' ×' .. qty) or '') .. (x.vip and ' (VIP)' or ''), right = '$' .. (x.price * qty), disabled = x.locked or nil,
                    description = x.locked and 'Réservé aux VIP.' or (r.label .. (qty > 1 and ' · consommé à chaque prise' or ' · peut se perdre si le poisson casse la ligne')),
                    onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':buy', id, x.item, qty) end }
            end
        end
        W:OpenMenu({ id = RES .. '.shop', title = title, subtitle = 'Magasin de pêche', items = items })
    end
end)
RegisterNetEvent(RES .. ':refresh', function(id) if openSpot == id then TriggerServerEvent(RES .. ':open', id) end end)

AddEventHandler('onClientResourceStop', function(res)
    if res ~= RES then return end
    clearBlips()
    if fishing then holdRod(false) end
end)
