fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wb_autoecole'
description "Shadow Base — auto-école : moniteur (PNJ), examen du code (questions tirées au sort), examen de conduite sur parcours posé au Builder avec HUD, rapport de fautes et carte de permis. Extension de pb_panel."
author 'Shadow Base'
version '1.1.0'

dependency 'pb_panel'

ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css', 'html/app.js', 'html/fonts/*.ttf' }

shared_script 'shared.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
client_script 'client.lua'
