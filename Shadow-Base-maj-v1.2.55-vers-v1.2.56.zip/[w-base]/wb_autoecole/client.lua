-- Shadow Base — Auto-école (client) : moniteur (PNJ), interface dédiée (accueil, code, rapport, carte de permis), examen de conduite avec HUD,
-- moniteur assis à côté, blocage optionnel sans permis. L'interface est la page html/ de cette ressource.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {}, require = false }
local mine = {}
local blips = {}
local exam = nil          -- examen de conduite en cours
local uiOpen = false
local function notify(kind, text) W:Notify({ type = kind, title = AE.label, text = text }) end
local function ui(t) SendNUIMessage(t) end
local function focus(on) uiOpen = on SetNuiFocus(on, on) end
local _keyTex, _keyChk = nil, 0
local function marker(x, y, z)
    -- même touche « E » arrondie que Shadow Base (texture pb_ui/key_e créée par pb_panel), sinon petit point lumineux
    local pz = z + 1.0
    if _keyTex == nil or GetGameTimer() > (_keyChk or 0) then
        _keyChk = GetGameTimer() + 5000
        local res = GetTextureResolution('pb_ui', 'key_e')
        _keyTex = res and res.x and res.x > 4 or false
    end
    if _keyTex then
        local ok, sx, sy = GetScreenCoordFromWorldCoord(x + 0.0, y + 0.0, pz + 0.0)
        if not ok then return end
        local d = #(GetEntityCoords(PlayerPedId()) - vector3(x + 0.0, y + 0.0, pz + 0.0))
        local k = math.max(0.55, 1.0 - d / 30.0)
        local hs = 0.036 * k
        DrawSprite('pb_ui', 'key_e', sx, sy, hs / GetAspectRatio(false), hs, 0.0, 255, 255, 255, math.floor(math.max(90, 235 - d * 9)))
        return
    end
    local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
    DrawMarker(28, x + 0.0, y + 0.0, pz, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end


local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, s in ipairs(C.spots or {}) do
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, AE.blip[1]) SetBlipColour(b, AE.blip[2]) SetBlipScale(b, 0.8) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end)
RegisterNetEvent(RES .. ':mine', function(j) local ok, m = pcall(json.decode, j) if ok and type(m) == 'table' then mine = m end end)
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
end)


-- Moniteur : invite -------------------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if C.enabled and not exam and not uiOpen and isFree() then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(C.spots or {}) do local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end
            if best and bd < 30.0 then
                sleep = 0
                if not (NPCS and NPCS[best.id] and DoesEntityExist(NPCS[best.id])) then marker(best.x, best.y, best.z - 0.95) end
                if bd < 2.5 then
                    if shown ~= best.id then shown = best.id W:Prompt('Passer le permis : ' .. best.label, 'E', best.x, best.y, best.z) end
                    if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':open', best.id) Wait(500) end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Interface ------------------------------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent(RES .. ':hub', function(id, j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    d.a = 'hub'
    ui(d)
    focus(true)
end)
RegisterNetEvent(RES .. ':q', function(i, total, text, j)
    local ok, opts = pcall(json.decode, j)
    if not ok or type(opts) ~= 'table' then return end
    ui({ a = 'quiz', i = i, total = total, text = text, opts = opts })
    focus(true)
end)
RegisterNetEvent(RES .. ':result', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    d.a = 'result'
    ui(d)
    focus(true)
end)
RegisterNetEvent(RES .. ':card', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' then return end
    d.a = 'card'
    ui(d)
end)
local function closeUi() ui({ a = 'hide' }) focus(false) end
RegisterNUICallback('start', function(d, cb) cb(1) TriggerServerEvent(RES .. ':start', d.id, d.key) end)
RegisterNUICallback('ans', function(d, cb) cb(1) TriggerServerEvent(RES .. ':ans', tonumber(d.n)) end)
RegisterNUICallback('again', function(d, cb) cb(1) TriggerServerEvent(RES .. ':open', d.id) end)
RegisterNUICallback('close', function(_, cb) cb(1) closeUi() end)
RegisterNUICallback('abort', function(_, cb) cb(1) TriggerServerEvent(RES .. ':abort') closeUi() end)

-- Examen de conduite -----------------------------------------------------------------------------------------------------------------------------------------------
local function endExam()
    if not exam then return end
    local e = exam
    exam = nil
    ui({ a = 'hudStop' })
    if e.blip and DoesBlipExist(e.blip) then RemoveBlip(e.blip) end
    local ped = PlayerPedId()
    if e.coach and DoesEntityExist(e.coach) then DeleteEntity(e.coach) end
    if e.veh and DoesEntityExist(e.veh) then
        if IsPedInVehicle(ped, e.veh, false) then TaskLeaveVehicle(ped, e.veh, 0) Wait(1500) end
        SetEntityAsMissionEntity(e.veh, true, true) DeleteVehicle(e.veh)
    end
end
local function nextBlip()
    if not exam then return end
    if exam.blip and DoesBlipExist(exam.blip) then RemoveBlip(exam.blip) end
    local p = exam.cps[exam.i]
    if not p then return end
    local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
    SetBlipSprite(b, p.stop and 1 or 1) SetBlipColour(b, p.stop and 1 or 5) SetBlipScale(b, 0.9) SetBlipRoute(b, true) SetBlipRouteColour(b, p.stop and 1 or 5)
    exam.blip = b
    exam.say = p.say or (p.stop and 'Marquez l\'arrêt.' or 'Continuez tout droit.')
end
local function pushHud()
    if not exam then return end
    ui({ a = 'hud', speed = math.floor(GetEntitySpeed(exam.veh) * 3.6 + 0.5), limit = exam.limit, faults = exam.faults, i = math.min(exam.i, #exam.cps), n = #exam.cps, say = exam.say })
end
RegisterNetEvent(RES .. ':exam', function(kind, model, plate, start, j, limit, maxf)
    local ok, cps = pcall(json.decode, j)
    if exam or not ok or type(cps) ~= 'table' or #cps < 2 then TriggerServerEvent(RES .. ':abort') return end
    closeUi()
    local m = joaat(model)
    RequestModel(m)
    local t = GetGameTimer() + 5000
    while not HasModelLoaded(m) and GetGameTimer() < t do Wait(20) end
    if not HasModelLoaded(m) then notify('error', 'Véhicule d\'examen introuvable.') TriggerServerEvent(RES .. ':abort') return end
    local veh = CreateVehicle(m, start.x + 0.0, start.y + 0.0, start.z + 0.0, start.h + 0.0, true, false)
    SetModelAsNoLongerNeeded(m)
    if not veh or veh == 0 then TriggerServerEvent(RES .. ':abort') return end
    SetVehicleNumberPlateText(veh, plate or 'AUTOECOL')
    SetVehicleOnGroundProperly(veh) SetVehicleEngineOn(veh, true, true, false) SetVehicleDoorsLocked(veh, 1)
    SetPedIntoVehicle(PlayerPedId(), veh, -1)
    exam = { kind = kind, veh = veh, cps = cps, i = 1, faults = 0, limit = limit, maxf = maxf, hp = GetEntityHealth(veh), say = 'Suivez le tracé.' }
    -- moniteur assis à côté (local, jamais synchronisé)
    if kind ~= 'bike' then
        local cm = joaat(AE.npc)
        RequestModel(cm)
        local tt = GetGameTimer() + 3000
        while not HasModelLoaded(cm) and GetGameTimer() < tt do Wait(20) end
        if HasModelLoaded(cm) then
            local coach = CreatePed(4, cm, start.x + 0.0, start.y + 0.0, start.z + 0.0, 0.0, false, false)
            SetPedIntoVehicle(coach, veh, 0)
            SetEntityInvincible(coach, true) SetBlockingOfNonTemporaryEvents(coach, true) SetPedCanBeDraggedOut(coach, false)
            SetModelAsNoLongerNeeded(cm)
            exam.coach = coach
        end
    end
    nextBlip()
    ui({ a = 'hudStart', who = AE.moniteur, limit = limit, max = maxf })
    exam.say = 'Démarrons. ' .. exam.say
    pushHud()
    CreateThread(function()   -- repère, franchissement des points
        while exam and exam.veh == veh do
            local p = exam.cps[exam.i]
            if p then
                local r, g, b = 255, 214, 0
                if p.stop then r, g, b = 255, 80, 90 end
                DrawMarker(1, p.x + 0.0, p.y + 0.0, p.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.0, 6.0, 2.5, r, g, b, 110, false, false, 2, false, nil, nil, false)
                if #(GetEntityCoords(PlayerPedId()) - vector3(p.x, p.y, p.z)) < 7.0 then
                    TriggerServerEvent(RES .. ':cp', exam.i)
                    exam.i = exam.i + 1
                    if exam.i <= #exam.cps then nextBlip() else exam.say = 'Rangez-vous et coupez le moteur, l\'examen est terminé.' end
                end
            end
            Wait(0)
        end
    end)
    CreateThread(function()   -- HUD, chocs, abandon
        while exam and exam.veh == veh do
            Wait(120)
            if not DoesEntityExist(veh) then TriggerServerEvent(RES .. ':abort') break end
            pushHud()
            local hp = GetEntityHealth(veh)
            if hp < exam.hp - 25 then TriggerServerEvent(RES .. ':hit') end
            exam.hp = hp
            if IsEntityDead(PlayerPedId()) or IsEntityDead(veh) then TriggerServerEvent(RES .. ':abort') break end
        end
    end)
end)
RegisterNetEvent(RES .. ':faults', function(n, why)
    if not exam then return end
    exam.faults = n
    PlaySoundFrontend(-1, 'ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    ui({ a = 'fault', text = ('Faute %d/%d · %s'):format(n, exam.maxf, why or '') })
    pushHud()
end)
RegisterNetEvent(RES .. ':finish', function(ok, j)
    local good, d = pcall(json.decode, j)
    CreateThread(function()
        local back = good and type(d) == 'table' and d.back or nil
        if back and IsEntityDead(PlayerPedId()) then back = nil end
        if back then
            DoScreenFadeOut(500)
            local t = GetGameTimer() + 1000
            while not IsScreenFadedOut() and GetGameTimer() < t do Wait(0) end
        end
        endExam()
        if back then   -- recalé : retour devant le moniteur
            local ped = PlayerPedId()
            FreezeEntityPosition(ped, true)
            RequestCollisionAtCoord(back.x + 0.0, back.y + 0.0, back.z + 0.0)
            SetEntityCoords(ped, back.x + 0.0, back.y + 0.0, back.z - 1.0, false, false, false, false)
            SetEntityHeading(ped, back.h + 0.0)
            local t = GetGameTimer() + 2500
            while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < t do Wait(0) end
            FreezeEntityPosition(ped, false)
            Wait(250)
            DoScreenFadeIn(500)
        end
        if good and type(d) == 'table' then
            d.a = 'result'
            ui(d)
            focus(true)
        end
    end)
end)

-- Permis obligatoire (option) : sans le bon permis le moteur ne démarre pas -----------------------------------------------------------------------------
local function needOf(veh)
    local cl = GetVehicleClass(veh)
    if cl == 8 then return 'bike' end
    if cl == 10 or cl == 11 or cl == 20 then return 'truck' end
    if (cl >= 0 and cl <= 7) or cl == 9 or cl == 12 then return 'car' end
    return nil
end
CreateThread(function()
    local lastMsg = 0
    while true do
        local sleep = 1000
        if C.require and not exam then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                sleep = 250
                local need = needOf(veh)
                if need and not mine[need] then
                    SetVehicleEngineOn(veh, false, true, true)
                    SetVehicleUndriveable(veh, true)
                    if GetGameTimer() - lastMsg > 15000 then lastMsg = GetGameTimer() notify('warn', 'Il te faut le ' .. ((AE_KIND_BY[need] or {}).label or 'permis'):lower() .. ' pour conduire ce véhicule.') end
                else SetVehicleUndriveable(veh, false) end
            end
        end
        Wait(sleep)
    end
end)

-- PNJ moniteur (posé seulement à moins de 60 m)
local npcs = {}
NPCS = npcs
CreateThread(function()
    while true do
        Wait(1500)
        local c = GetEntityCoords(PlayerPedId())
        local want = {}
        if C.enabled then
            for _, s in ipairs(C.spots or {}) do
                if #(c - vector3(s.x, s.y, s.z)) < 60.0 then
                    want[s.id] = true
                    if not (npcs[s.id] and DoesEntityExist(npcs[s.id])) then
                        local m = joaat(AE.npc)
                        if not IsModelInCdimage(m) then m = joaat('a_m_m_business_01') end
                        RequestModel(m)
                        local t = GetGameTimer() + 3000
                        while not HasModelLoaded(m) and GetGameTimer() < t do Wait(20) end
                        if HasModelLoaded(m) then
                            local ok, gz = GetGroundZFor_3dCoord(s.x + 0.0, s.y + 0.0, s.z + 2.0, false)
                            local p = CreatePed(4, m, s.x + 0.0, s.y + 0.0, ok and gz or (s.z - 1.0), (tonumber(s.h) or 0.0) + 0.0, false, false)
                            SetEntityInvincible(p, true) FreezeEntityPosition(p, true) SetBlockingOfNonTemporaryEvents(p, true)
                            TaskStartScenarioInPlace(p, 'WORLD_HUMAN_CLIPBOARD', 0, true)
                            SetModelAsNoLongerNeeded(m)
                            npcs[s.id] = p
                        end
                    end
                end
            end
        end
        for id, p in pairs(npcs) do if not want[id] then if DoesEntityExist(p) then DeleteEntity(p) end npcs[id] = nil end end
    end
end)

AddEventHandler('onClientResourceStop', function(res)
    if res ~= RES then return end
    for _, p in pairs(npcs) do if DoesEntityExist(p) then DeleteEntity(p) end end
    clearBlips()
    if uiOpen then SetNuiFocus(false, false) end
    if exam then if exam.blip and DoesBlipExist(exam.blip) then RemoveBlip(exam.blip) end if exam.coach and DoesEntityExist(exam.coach) then DeleteEntity(exam.coach) end if exam.veh and DoesEntityExist(exam.veh) then DeleteVehicle(exam.veh) end end
end)
