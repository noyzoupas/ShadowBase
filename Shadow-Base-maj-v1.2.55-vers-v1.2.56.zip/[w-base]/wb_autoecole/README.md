# wb_autoecole — auto-école (extension Shadow Base)

Interface dédiée (page `html/`) dans le style de Shadow Base : verre sombre, Poppins, coins arrondis.

- **Moniteur** (PNJ) : pose-le au Builder (F10 › Builder › Activités et extensions › Services et permis › Auto-école). E près de lui ouvre l'accueil : carte de permis, état de chaque examen, prix.
- **Code de la route** : une question à la fois (touches 1 à 4), 10 questions tirées parmi 33 (modifiables dans `shared.lua`), 80 % pour réussir. Les bonnes réponses restent sur le serveur ; à la fin, l'écran de résultat montre le score et la correction de chaque erreur.
- **Examen de conduite** (voiture, moto, poids lourd) : il faut avoir le code. Le véhicule d'examen apparaît au départ, un moniteur s'assoit à côté (sauf moto). Affichage en jeu : vitesse et limite, fautes, point en cours, consigne du moniteur. Fin : rapport des fautes et du temps.
- **Contrôlé par le serveur** : limite de vitesse (4 s au-dessus = 1 faute), arrêt obligatoire non marqué, chocs, sortie du véhicule (10 s = échec), progression sur le parcours (point à moins de 40 m, vitesse plausible), durée maximale 30 min. Trop de fautes = échec, puis attente avant de repasser.
- **Parcours** (Builder) : un **Départ du véhicule** (dans ton sens), puis des **Points du parcours** et des **Arrêts obligatoires** dans l'ordre (2 minimum). Le nom saisi à la pose est la consigne que dit le moniteur (« Tournez à droite au feu »).
- **Permis** : enregistrés par joueur (table `wb_autoecole_licences`). Option « Permis obligatoire pour conduire » (désactivée par défaut) : sans le bon permis, le moteur ne démarre pas.
- Commandes : `/permis` (carte de permis), staff : `/permis_donner [id] [code|car|bike|truck]`, `/permis_retirer [id] [type]`.
- Autres ressources : `exports.wb_autoecole:HasLicence(source, 'car')`.
- Réglages : panel › Extensions › Auto-école (prix, note, limite, fautes, attente, paiement, carte).
