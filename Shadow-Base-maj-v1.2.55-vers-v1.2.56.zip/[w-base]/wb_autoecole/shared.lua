-- Shadow Base — Auto-école : ce qui est décrit ici (permis, véhicules d'examen, questions du code) se modifie sans toucher au reste.
-- Les réponses justes ne quittent jamais le serveur : le client ne reçoit que la question et les propositions.

AE = {
    label = 'Auto-école',
    icon = 'car',
    moniteur = 'Moniteur',
    blip = { 225, 3 },                                 -- sprite, couleur
    npc = 'a_m_y_business_03',
    kinds = {                                          -- permis pratiques ; 'code' est l'examen théorique commun
        { key = 'car',   label = 'Permis voiture', model = 'blista',  fee = 400, plate = 'AUTOECOL' },
        { key = 'bike',  label = 'Permis moto',    model = 'faggio',   fee = 300, plate = 'AUTOECOL' },
        { key = 'truck', label = 'Permis poids lourd', model = 'mule', fee = 600, plate = 'AUTOECOL' },
    },
    code_fee = 150,
}
AE_KIND_BY = {}
for _, k in ipairs(AE.kinds) do AE_KIND_BY[k.key] = k end

-- Chaque question : texte, propositions, index de la bonne réponse (la première proposition est la n°1)
AE_QUESTIONS = {
    { 'À un feu orange fixe, que fais-tu ?', { 'Je m\'arrête si je peux le faire sans freinage brusque', 'J\'accélère pour passer', 'Je klaxonne', 'Je continue sans changer' }, 1 },
    { 'Quelle est la vitesse maximale en agglomération, sauf indication contraire ?', { '30 km/h', '50 km/h', '70 km/h', '90 km/h' }, 2 },
    { 'Que signifie un panneau STOP ?', { 'Ralentir et passer si la voie est libre', 'Arrêt complet obligatoire, puis céder le passage', 'Stationnement interdit', 'Fin de zone limitée' }, 2 },
    { 'Tu arrives à un carrefour sans signalisation. Qui passe en premier ?', { 'Le véhicule le plus rapide', 'Le véhicule venant de ta droite', 'Le véhicule venant de ta gauche', 'Le plus gros véhicule' }, 2 },
    { 'Avant de doubler, tu dois…', { 'Klaxonner et accélérer', 'Vérifier que la voie est libre et mettre ton clignotant', 'Éteindre tes feux', 'Rouler au milieu de la route' }, 2 },
    { 'Que fais-tu quand un véhicule de police ou d\'ambulance arrive avec sirène et gyrophare ?', { 'Je continue à ma vitesse', 'Je me range et je le laisse passer', 'Je l\'accompagne', 'Je freine au milieu de la voie' }, 2 },
    { 'Peut-on conduire en tenant son téléphone en main ?', { 'Oui, si c\'est court', 'Oui, à l\'arrêt au feu rouge', 'Non, jamais', 'Seulement en ville' }, 3 },
    { 'À quoi sert la distance de sécurité ?', { 'À laisser de la place aux piétons', 'À pouvoir freiner sans percuter le véhicule de devant', 'À économiser du carburant', 'À doubler plus facilement' }, 2 },
    { 'Quel est le sens de circulation ?', { 'À gauche', 'À droite', 'Au milieu', 'Au choix' }, 2 },
    { 'Un piéton s\'engage sur un passage protégé. Tu dois…', { 'Klaxonner', 'Accélérer pour passer avant lui', 'Le laisser traverser', 'Le contourner par la gauche' }, 3 },
    { 'La ceinture de sécurité est obligatoire…', { 'Seulement sur autoroute', 'Pour le conducteur uniquement', 'Pour tous les occupants du véhicule', 'Hors agglomération' }, 3 },
    { 'Que faire en cas de brouillard épais ?', { 'Rouler plus vite pour sortir de la zone', 'Allumer les feux de brouillard et réduire la vitesse', 'Éteindre tous les feux', 'S\'arrêter au milieu de la route' }, 2 },
    { 'Sur une route mouillée, la distance de freinage…', { 'Diminue', 'Reste identique', 'Augmente', 'Dépend uniquement des pneus' }, 3 },
    { 'À un rond-point, qui est prioritaire ?', { 'Celui qui entre', 'Celui qui est déjà engagé dans le rond-point', 'Le plus rapide', 'Celui qui klaxonne' }, 2 },
    { 'Quand faut-il mettre son clignotant ?', { 'Seulement pour tourner à gauche', 'Avant chaque changement de direction ou de voie', 'Jamais en ville', 'Après avoir tourné' }, 2 },
    { 'Que signifie une ligne blanche continue au milieu de la route ?', { 'Tu peux la franchir pour doubler', 'Tu ne dois pas la franchir', 'La route est en travaux', 'Stationnement autorisé' }, 2 },
    { 'Tu es fatigué au volant. Que fais-tu ?', { 'Je baisse la vitre et je continue', 'Je monte la musique', 'Je m\'arrête pour me reposer', 'J\'accélère pour arriver plus vite' }, 3 },
    { 'Quand est-il autorisé de conduire après avoir bu de l\'alcool ?', { 'Si on a mangé avant', 'Si on roule doucement', 'Jamais au-delà de la limite légale, et le mieux est de ne pas boire', 'La nuit seulement' }, 3 },
    { 'À quoi servent les feux de détresse (warning) ?', { 'À remplacer le clignotant', 'À signaler un danger ou un véhicule immobilisé', 'À mieux voir de nuit', 'À rouler plus vite' }, 2 },
    { 'Un panneau triangulaire à bord rouge est un panneau…', { 'D\'obligation', 'D\'interdiction', 'De danger', 'De stationnement' }, 3 },
    { 'Un panneau rond à bord rouge est un panneau…', { 'D\'interdiction ou de limitation', 'De danger', 'D\'information', 'De direction' }, 1 },
    { 'Où dois-tu te placer pour tourner à droite ?', { 'Le plus à gauche possible', 'Au milieu de la chaussée', 'Le plus près possible du bord droit', 'Peu importe' }, 3 },
    { 'En moto, le casque est…', { 'Recommandé', 'Obligatoire pour le conducteur et le passager', 'Obligatoire seulement en ville', 'Inutile à basse vitesse' }, 2 },
    { 'Quand les feux de croisement doivent-ils être allumés ?', { 'De nuit et quand la visibilité est mauvaise', 'Jamais en ville', 'Uniquement sur autoroute', 'Seulement par temps de pluie' }, 1 },
    { 'Que faire après un accident avec des blessés ?', { 'Partir pour éviter les ennuis', 'Protéger la zone, appeler les secours et rester sur place', 'Déplacer tous les blessés', 'Prendre des photos puis partir' }, 2 },
    { 'Que signifie un feu rouge clignotant à un passage à niveau ?', { 'Tu peux passer vite', 'Tu dois t\'arrêter', 'Tu dois klaxonner', 'Tu dois ralentir seulement' }, 2 },
    { 'Dans un virage, il faut…', { 'Freiner avant le virage, pas dedans', 'Accélérer au maximum', 'Freiner fort au milieu du virage', 'Rouler au centre de la route' }, 1 },
    { 'La vitesse doit toujours être adaptée…', { 'Uniquement à la limite affichée', 'À la route, la météo, la circulation et l\'état du véhicule', 'À ta voiture seulement', 'À la musique écoutée' }, 2 },
    { 'Un camion qui tourne à droite peut avoir un angle mort. Tu dois…', { 'Te glisser sur sa droite', 'Rester à distance et ne pas te mettre dans son angle mort', 'Klaxonner et le doubler', 'Le coller de près' }, 2 },
    { 'Que faire en entendant les freins chauffer dans une longue descente ?', { 'Maintenir la pédale enfoncée à fond', 'Rétrograder et utiliser le frein moteur', 'Passer au point mort', 'Couper le contact' }, 2 },
    { 'Un véhicule est garé sur un passage piéton. C\'est…', { 'Autorisé deux minutes', 'Autorisé la nuit', 'Interdit', 'Autorisé avec les feux de détresse' }, 3 },
}
