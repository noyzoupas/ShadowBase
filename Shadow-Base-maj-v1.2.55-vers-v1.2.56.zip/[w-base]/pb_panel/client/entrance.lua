-- Écran d'entrée dans la boîte de nuit (After Hours) : vue d'ensemble avec la piste qui danse, « Appuyez sur E » ; la caméra glisse
-- jusqu'au personnage accoudé à la rambarde ; ← → passe d'un personnage à l'autre. « Entrer en ville » : transition du jeu
-- (écran d'arrivée : le décor se charge derrière, le joueur n'est montré qu'une fois tout en place). Tout est local au joueur.
local G = PBG
local S = nil          -- scène en cours : { d, peds = {slot -> ped}, extras = {}, cam, idx }

-- intérieur de la boîte de nuit : décor, bar, DJ, lumières (ensembles d'objets de l'intérieur)
local SETS = { 'Int01_ba_clubname_01', 'Int01_ba_Style01', 'Int01_ba_style01_podium', 'Int01_ba_equipment_setup', 'Int01_ba_equipment_upgrade', 'Int01_ba_security_upgrade',
    'Int01_ba_dj01', 'DJ_01_Lights_01', 'Int01_ba_lights_screen', 'Int01_ba_Screen', 'Int01_ba_bar_content', 'Int01_ba_booze_01', 'Int01_ba_booze_02', 'Int01_ba_booze_03',
    'Int01_ba_dry_ice', 'Int01_ba_trad_lights', 'Int01_ba_Clutter' }
-- haut-parleurs de la boîte (musique)
local EMITTERS = { 'SE_ba_dlc_int_01_main_area', 'SE_ba_dlc_int_01_Entry_Hall', 'SE_ba_dlc_int_01_Entry_Stairs', 'SE_ba_dlc_int_01_Bogs' }
-- accoudé à une rambarde (animations du yacht), danseurs : clients de la boîte
local LEAN = { m = { 'anim@amb@yacht@rail@standing@male@variant_01@', 'base' }, f = { 'anim@amb@yacht@rail@standing@female@variant_01@', 'base' } }
local DANCERS = { 'a_f_y_clubcust_01', 'a_f_y_clubcust_02', 'a_f_y_clubcust_03', 'a_m_y_clubcust_01', 'a_m_y_clubcust_02', 'a_m_y_clubcust_03' }

local function anim(dict) RequestAnimDict(dict) local t = GetGameTimer() + 3000 while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(dict) end
local function v3(p, dz) return vector3(p.x + 0.0, p.y + 0.0, p.z + (dz or 0.0)) end

local function setupInterior(p)
    local id = GetInteriorAtCoords(p.x + 0.0, p.y + 0.0, p.z + 0.0)
    if id and id ~= 0 then
        PinInteriorInMemory(id)
        local t = GetGameTimer() + 5000
        while not IsInteriorReady(id) and GetGameTimer() < t do Wait(50) end
        for _, s in ipairs(SETS) do if not IsInteriorEntitySetActive(id, s) then ActivateInteriorEntitySet(id, s) end end
        RefreshInterior(id)
    end
end
local function music(on, station)
    for _, e in ipairs(EMITTERS) do
        pcall(SetStaticEmitterEnabled, e, on)
        if on and station and station ~= '' then pcall(SetEmitterRadioStation, e, station) end
    end
end

-- caméra devant un emplacement (personnage accoudé, tourné vers la piste) : légèrement de côté, à hauteur du visage
local function spotCam(p)
    local h = math.rad(p.h or 0.0)
    local fx, fy = -math.sin(h), math.cos(h)        -- devant le personnage (vers la piste)
    local rx, ry = math.cos(h), math.sin(h)         -- à sa droite
    local pos = vector3(p.x + fx * 1.9 + rx * 0.7, p.y + fy * 1.9 + ry * 0.7, p.z + 0.55)
    return pos, vector3(p.x + 0.0, p.y + 0.0, p.z + 0.45)
end
local function newCam(pos, look, fov)
    local c = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', pos.x, pos.y, pos.z, 0.0, 0.0, 0.0, (fov or 50) + 0.0, false, 0)
    PointCamAtCoord(c, look.x, look.y, look.z)
    return c
end
-- glissement d'une caméra à l'autre ; l'ancienne est détruite à la fin
local function moveTo(pos, look, fov, ms)
    if not S then return end
    local c = newCam(pos, look, fov)
    SetFocusPosAndVel(pos.x, pos.y, pos.z, 0.0, 0.0, 0.0)
    if S.cam then
        SetCamActiveWithInterp(c, S.cam, ms or 1400, 1, 1)
        local old = S.cam
        SetTimeout((ms or 1400) + 100, function() if DoesCamExist(old) then DestroyCam(old, false) end end)
    else
        SetCamActive(c, true)
        RenderScriptCams(true, false, 0, true, true)
    end
    S.cam = c
end

local function spawnPed(model, p, heading)
    local h = G.loadModel(model)
    if not HasModelLoaded(h) then return nil end
    local ped = CreatePed(4, h, p.x + 0.0, p.y + 0.0, p.z - 1.0, (heading or 0.0) + 0.0, false, false)
    SetModelAsNoLongerNeeded(h)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedCanRagdoll(ped, false)
    FreezeEntityPosition(ped, true)
    return ped
end
local function leanOf(c) return (c.sex == 'f' or (c.appearance and c.appearance.model == 'mp_f_freemode_01')) and LEAN.f or LEAN.m end
local function placeChar(i, c)
    local p = S.d.spots[i]
    if not p or not c.appearance then return end
    local ped = spawnPed(c.appearance.model or (c.sex == 'f' and 'mp_f_freemode_01' or 'mp_m_freemode_01'), p, p.h)
    if not ped then return end
    G.applyAppearance(c.appearance, false, ped)
    local l = leanOf(c)
    if anim(l[1]) then TaskPlayAnim(ped, l[1], l[2], 8.0, -8.0, -1, 1, 0.0, false, false, false) end
    S.peds[i] = ped
end
local function spawnDancers(n, center, r)
    for k = 1, n do
        local a, d = math.random() * math.pi * 2, math.sqrt(math.random()) * r
        local p = { x = center.x + math.cos(a) * d, y = center.y + math.sin(a) * d, z = center.z }
        local ped = spawnPed(DANCERS[(k - 1) % #DANCERS + 1], p, math.random(0, 359))
        if ped then
            FreezeEntityPosition(ped, false)
            SetEntityCoordsNoOffset(ped, p.x, p.y, p.z, false, false, false)
            TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_PARTYING', 0, true)
            S.extras[#S.extras + 1] = ped
        end
    end
end

-- nettoyage complet (keepMusic : pendant la montée vers le ciel)
local function cleanup()
    if not S then return end
    for _, ped in pairs(S.peds) do if DoesEntityExist(ped) then DeleteEntity(ped) end end
    for _, ped in ipairs(S.extras) do if DoesEntityExist(ped) then DeleteEntity(ped) end end
    if S.cam then RenderScriptCams(false, false, 0, true, true) DestroyCam(S.cam, false) end
    music(false)
    ClearFocus()
    DisplayRadar(true)
    S = nil
    G.entrance, G.hidden = false, false
end
G.EntranceCleanup = cleanup
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then cleanup() end end)

local function uiList()
    local out = {}
    for i, c in ipairs(S.list) do
        out[i] = { slot = c.slot, name = c.name, first = c.first, last = c.last, dob = c.dob, cash = c.cash, bank = c.bank, job = c.job, seen = c.seen, locked = c.locked or nil, new = (not c.name and not c.locked) or nil }
    end
    return out
end

local function start(d)
    if S then cleanup() end
    S = { d = d.scene, list = d.list, peds = {}, extras = {}, idx = 1, test = d.test }
    G.entrance, G.hidden = true, true   -- HUD caché pendant la scène
    DoScreenFadeOut(400) Wait(450)
    pcall(ShutdownLoadingScreen) if ShutdownLoadingScreenNui then pcall(ShutdownLoadingScreenNui) end
    local sc = S.d
    setupInterior(sc.interior)
    -- le joueur attend, invisible, sur le premier emplacement (pour le chargement du décor)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true)
    SetEntityVisible(ped, false, false)
    SetEntityInvincible(ped, true)
    SetEntityCoordsNoOffset(ped, sc.spots[1].x + 0.0, sc.spots[1].y + 0.0, sc.spots[1].z + 0.0, false, false, false)
    RequestCollisionAtCoord(sc.cam.x + 0.0, sc.cam.y + 0.0, sc.cam.z + 0.0)
    DisplayRadar(false)
    for i, c in ipairs(S.list) do if i <= #sc.spots and c.name then placeChar(i, c) end end
    spawnDancers(sc.dancers or 0, sc.dance, sc.dance_r or 4.5)
    music(true, sc.radio)
    moveTo(v3(sc.cam), v3(sc.look), sc.fov, 0)
    G.focus(true)
    G.send('entrance.open', { title = sc.title, sub = sc.sub, list = uiList(), vip = d.vip or false, intro = sc.intro, slogan = sc.slogan, discord = sc.discord, online = sc.online, maxp = sc.maxp })
    Wait(600)
    if G.LoadingDone then G.LoadingDone({ keep = true }) end   -- le décor est prêt : l'écran de chargement laisse place à la scène
    DoScreenFadeIn(900)
end

RegisterNetEvent('pb:g:charselect', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' or not d.scene or type(d.list) ~= 'table' then return end
    start(d)
end)

-- Interface ------------------------------------------------------------------------------------------------------------------------------
G.nui['entrance.focus'] = function(d)   -- E ou ← → : caméra sur l'emplacement choisi
    if not S then return {} end
    local i = math.max(1, math.min(#S.list, math.floor(tonumber(d.i) or 1)))
    S.idx = i
    local p = S.d.spots[math.min(i, #S.d.spots)]
    local pos, look = spotCam(p)
    moveTo(pos, look, 42, tonumber(d.ms) or 1400)
    return {}
end
G.nui['entrance.overview'] = function()   -- Échap : retour à la vue d'ensemble
    if S then moveTo(v3(S.d.cam), v3(S.d.look), S.d.fov, 1600) end
    return {}
end

-- (v1.2.58) Entrer en ville : l'écran d'arrivée couvre tout dès le clic, le décor se charge derrière, le joueur n'est montré qu'une fois tout en place
local function enterCity(i, c)
    G.focus(false)
    G.send('arrive.open', { name = c.first or c.name })
    G.arriving = true
    Wait(450)   -- l'écran a fini de couvrir la scène
    G.applyAppearance(c.appearance, true)
    local ped = PlayerPedId()
    SetEntityVisible(ped, false, false)
    FreezeEntityPosition(ped, true)
    RenderScriptCams(false, false, 0, true, true)
    if S and S.cam then DestroyCam(S.cam, false) S.cam = nil end
    TriggerServerEvent('pb:g:charpick', c.slot)
end
G.nui['entrance.play'] = function(d)
    if not S or G.arriving then return {} end
    local i = math.floor(tonumber(d.i) or 0)
    local c = S.list[i]
    if not c or c.locked then return {} end
    if S.test then   -- /entree test : on rejoue la scène sans changer de personnage
        G.send('entrance.close', {}) G.focus(false)
        DoScreenFadeOut(300) Wait(350)
        cleanup()
        local ped = PlayerPedId()
        SetEntityVisible(ped, true, false) FreezeEntityPosition(ped, false) SetEntityInvincible(ped, false)
        if G.lastPos then SetEntityCoordsNoOffset(ped, G.lastPos.x, G.lastPos.y, G.lastPos.z, false, false, false) end
        DoScreenFadeIn(500)
        return {}
    end
    if not c.name then
        -- nouveau personnage : le créateur s'ouvre ici, dans la boîte
        local p = S.d.spots[math.min(i, #S.d.spots)]
        G.send('entrance.close', {}) G.focus(false)
        DoScreenFadeOut(300) Wait(350)
        cleanup()
        local ped = PlayerPedId()
        SetEntityCoordsNoOffset(ped, p.x + 0.0, p.y + 0.0, p.z + 0.0, false, false, false)
        SetEntityVisible(ped, true, false)
        TriggerServerEvent('pb:g:charpick', c.slot)
        return {}
    end
    CreateThread(function() enterCity(i, c) end)
    return {}
end

-- Arrivée : appelé par client/character.lua à la réception de « pb:g:begin » pendant la transition
function G.EntranceArrive(d)
    CreateThread(function()
        local fallback = S and S.d and S.d.spawn   -- lu avant le nettoyage de la scène
        cleanup()
        G.send('entrance.close', {})
        local sp = (type(d.pos) == 'table' and tonumber(d.pos.x)) and d.pos or fallback or { x = -269.4, y = -955.3, z = 31.2, h = 205.0 }
        local ped = PlayerPedId()
        ClearPedTasksImmediately(ped)
        if d.appearance then G.applyAppearance(d.appearance, true) ped = PlayerPedId() end
        FreezeEntityPosition(ped, true)
        SetEntityVisible(ped, false, false)
        SetEntityCoordsNoOffset(ped, sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, false, false, false)
        SetEntityHeading(ped, (tonumber(sp.h) or 0.0) + 0.0)
        G.LoadScene(sp.x + 0.0, sp.y + 0.0, sp.z + 0.0, function(pct, text) G.send('arrive.step', { pct = pct, text = text }) end)
        ped = PlayerPedId()
        SetGameplayCamRelativeHeading(0.0)
        SetGameplayCamRelativePitch(0.0, 1.0)
        SetEntityVisible(ped, true, false)
        FreezeEntityPosition(ped, false)
        SetEntityInvincible(ped, false)
        G.send('arrive.step', { pct = 100, text = 'Bienvenue en ville' })
        Wait(500)
        G.arriving = false
        G.send('arrive.done', {})
        if d.dead then Wait(300) G.startDeath() end
    end)
end

-- Réglages en jeu (staff) : /entree camera | place 1-5 | piste | test --------------------------------------------------------------------
local function camLook()
    local c, r = GetGameplayCamCoord(), GetGameplayCamRot(2)
    local x, z = math.rad(r.x), math.rad(r.z)
    local dir = vector3(-math.sin(z) * math.abs(math.cos(x)), math.cos(z) * math.abs(math.cos(x)), math.sin(x))
    local l = c + dir * 12.0
    return c, l
end
RegisterCommand('entree', function(_, args)
    local a = tostring(args[1] or ''):lower()
    local ped = PlayerPedId()
    local p = GetEntityCoords(ped)
    if a == 'camera' or a == 'cam' then
        local c, l = camLook()
        TriggerServerEvent('pb:g:entrance:set', 'cam', { x = c.x, y = c.y, z = c.z, lx = l.x, ly = l.y, lz = l.z })
    elseif a == 'place' then
        local n = math.floor(tonumber(args[2]) or 0)
        if n < 1 or n > 5 then G.send('notify', { type = 'warn', title = "Écran d'entrée", text = 'Utilisation : /entree place 1 à 5' }) return end
        TriggerServerEvent('pb:g:entrance:set', 'spot' .. n, { x = p.x, y = p.y, z = p.z, h = GetEntityHeading(ped) })
    elseif a == 'piste' then
        TriggerServerEvent('pb:g:entrance:set', 'dance', { x = p.x, y = p.y, z = p.z })
    elseif a == 'test' then
        G.lastPos = { x = p.x, y = p.y, z = p.z }
        TriggerServerEvent('pb:g:entrance:test')
    else
        G.send('notify', { type = 'info', title = "Écran d'entrée", text = '/entree camera · /entree place 1 à 5 · /entree piste · /entree test' })
    end
end, false)
