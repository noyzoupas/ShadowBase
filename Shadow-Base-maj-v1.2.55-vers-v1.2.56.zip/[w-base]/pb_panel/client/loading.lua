-- Écran de chargement entre le loading screen et l'écran d'entrée : le joueur ne voit plus son personnage tomber dans le vide.
-- L'écran est affiché d'office par la page (web/game/boot.js). Le personnage reste figé derrière jusqu'à G.LoadingDone,
-- appelé quand l'écran d'entrée, le créateur ou la reconnexion sont prêts. Sécurité : levé tout seul au bout de 60 s.
local G = PBG
local active = true

-- (v1.2.58) Charge le décor autour d'un point (mappings, intérieur, collisions) ; onStep(pct, texte) suit l'avancement. Durée bornée : jamais bloquant.
function G.LoadScene(x, y, z, onStep)
    local step = onStep or function() end
    step(12, 'Arrivée à Los Santos')
    RequestCollisionAtCoord(x, y, z)
    NewLoadSceneStartSphere(x, y, z, 180.0, 0)
    local t0 = GetGameTimer()
    while not IsNewLoadSceneLoaded() and GetGameTimer() - t0 < 12000 do
        Wait(100)
        RequestCollisionAtCoord(x, y, z)
        step(math.floor(12 + math.min(1, (GetGameTimer() - t0) / 9000) * 48), 'Chargement des mappings')
    end
    NewLoadSceneStop()
    step(62, 'Chargement des intérieurs')
    local int = GetInteriorAtCoords(x, y, z)
    if int and int ~= 0 then
        PinInteriorInMemory(int)
        local t1 = GetGameTimer()
        while not IsInteriorReady(int) and GetGameTimer() - t1 < 4000 do Wait(100) end
    end
    step(78, 'Mise en place du décor')
    local t2, ped = GetGameTimer(), PlayerPedId()
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t2 < 5000 do
        Wait(50)
        RequestCollisionAtCoord(x, y, z)
        ped = PlayerPedId()
    end
    step(94, 'Presque prêt')
end

-- o.keep : le personnage reste figé (l'écran d'entrée ou le créateur s'en occupent) ; o.delay : attente avant de lever l'écran (ms)
function G.LoadingDone(o)
    if not active then return end
    active = false
    o = o or {}
    CreateThread(function()
        if not o.keep then
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            RequestCollisionAtCoord(c.x, c.y, c.z)
            local t = GetGameTimer()
            while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() - t < 4000 do Wait(50) ped = PlayerPedId() end
            FreezeEntityPosition(PlayerPedId(), false)
        end
        if o.delay then Wait(o.delay) end
        G.send('boot.done', {})
    end)
end

CreateThread(function()
    local started
    while active do
        Wait(200)
        FreezeEntityPosition(PlayerPedId(), true)
        if not started and NetworkIsPlayerActive(PlayerId()) and not (GetIsLoadingScreenActive and GetIsLoadingScreenActive()) then
            started = GetGameTimer()
            G.send('boot.ping', {})
        end
        if started and GetGameTimer() - started > 60000 then G.LoadingDone() end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and active then FreezeEntityPosition(PlayerPedId(), false) end end)
