-- Mort RP (server/game/mortrp.lua) : quand le staff l'active, la prochaine balle reçue tue le personnage pour de bon.
local G = PBG
local armed, shown = false, false
RegisterNetEvent('pb:g:mortrp:arm', function(on) armed = on == true end)
-- dégâts reçus : seulement les armes à balles (type de dégâts 3)
AddEventHandler('gameEventTriggered', function(name, args)
    if not armed or name ~= 'CEventNetworkEntityDamage' then return end
    local ped = PlayerPedId()
    if args[1] ~= ped then return end
    local weapon = args[7]
    if weapon and GetWeaponDamageType(weapon) == 3 then
        armed = false
        G.mortrp = true   -- avant la mort : l'écran « inconscient » ne s'ouvre pas
        -- sans réponse du serveur, la mort redevient normale : personne ne reste bloqué mort sans écran
        SetTimeout(5000, function() if not shown then G.mortrp = false end end)
        SetEntityHealth(ped, 0)
        TriggerServerEvent('pb:g:mortrp:hit')
    end
end)
RegisterNetEvent('pb:g:mortrp:screen', function(j)
    local d = G.decode(j) or {}
    G.mortrp, shown = true, true
    G.send('death.close', {})
    StopScreenEffect('DeathFailOut')
    G.send('mortrp', d)
end)
