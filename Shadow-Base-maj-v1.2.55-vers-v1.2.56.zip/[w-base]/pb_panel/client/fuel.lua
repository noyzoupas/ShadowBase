-- Carburant : consommation selon la vitesse, moteur qui cale à sec, pompes (menu), sauvegarde des dégâts en route, épave, clé du véhicule.
-- Le serveur décide du prix et du paiement ; ici on lit le jeu (vitesse, régime) et on applique le niveau d'essence.
local G = PBG
local stations, blips = {}, {}
local dry = {}                      -- véhicules à sec déjà signalés
local keyOk = {}                    -- plaque -> clé vérifiée par le serveur

local function cfg() return G.cfg and G.cfg.fuel or {} end
local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', '') end
local function tankOf(veh)
    local hud = G.cfg and G.cfg.hud or {}
    local t = tonumber(hud.tank_l) or 0
    if t <= 0 then t = (GetVehicleHandlingFloat and GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')) or 0.0 end
    if not t or t < 1.0 then t = 65.0 end
    return t
end
local function level(veh) return GetVehicleFuelLevel and GetVehicleFuelLevel(veh) or 0.0 end

-- Consommation --------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(1000)
        local c = cfg()
        if c.enabled ~= false and G.begun then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and GetIsVehicleEngineRunning(veh) and not IsEntityDead(veh) then
                local maxs = (GetVehicleEstimatedMaxSpeed and GetVehicleEstimatedMaxSpeed(veh) or 40.0) + 0.1
                local ratio = math.min(1.0, GetEntitySpeed(veh) / maxs)
                local rpm = GetVehicleCurrentRpm and GetVehicleCurrentRpm(veh) or 0.3
                local idle, drive = tonumber(c.idle_pct_min) or 0.35, tonumber(c.drive_pct_min) or 2.6
                local pct = idle + (drive - idle) * (ratio ^ 1.3) * (0.6 + 0.4 * rpm)
                local lv = level(veh)
                local nlv = math.max(0.0, lv - tankOf(veh) * pct / 100.0 / 60.0)
                if SetVehicleFuelLevel then SetVehicleFuelLevel(veh, nlv) end
                -- consommation moyenne réelle (L/100 km), lissée : sert à l'autonomie du compteur
                local kmh = GetEntitySpeed(veh) * 3.6
                if kmh > 10.0 then
                    local per100 = (lv - nlv) / (kmh / 3600.0) * 100.0
                    per100 = math.max(3.0, math.min(60.0, per100))
                    G.fuelAvg = G.fuelAvg and (G.fuelAvg * 0.9 + per100 * 0.1) or per100
                end
                if nlv <= 0.05 then
                    SetVehicleEngineOn(veh, false, true, true)
                    if not dry[veh] then dry[veh] = true G.send('notify', { type = 'warn', title = 'Carburant', text = 'Panne sèche !' }) end
                end
            end
        end
    end
end)
-- à sec, le moteur ne se rallume pas
CreateThread(function()
    while true do
        Wait(250)
        local veh = GetVehiclePedIsIn(PlayerPedId(), false)
        if veh ~= 0 and level(veh) <= 0.05 and GetIsVehicleEngineRunning(veh) and (cfg().enabled ~= false) then SetVehicleEngineOn(veh, false, true, true) end
        if veh ~= 0 and level(veh) > 0.5 then dry[veh] = nil end
    end
end)

-- Stations -------------------------------------------------------------------------------------------------------------------------------
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    stations = (c.fuel and c.fuel.stations) or {}
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (c.fuel and c.fuel.blips) then return end
    for _, s in ipairs(stations) do
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, 361) SetBlipColour(b, 1) SetBlipScale(b, 0.7) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end

local filling = false   -- plein en cours (animation)
local fillVeh = 0   -- véhicule choisi pour le plein (à pied : celui garé à côté de la pompe)
local function pumpMenu(st, veh)
    fillVeh = veh
    local c = cfg()
    local tank = tankOf(veh)
    local need = math.floor(tank - level(veh) + 0.5)
    if need < 1 then G.send('notify', { type = 'info', title = st.label, text = 'Le réservoir est déjà plein.' }) return end
    local price = (tonumber(st.price) or 0) > 0 and tonumber(st.price) or (tonumber(c.price) or 3)
    price = math.floor(price * G.EcoFactor() * 100 + 0.5) / 100   -- même prix que celui payé (onglet Économie)
    local function opt(label, l)
        l = math.min(l, need)
        return { label = ('%s — %d L'):format(label, l), right = '≈ ' .. PB.Money(price * l), onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:fuel:buy', st.id, l) end }
    end
    G.Menu.Open({ id = 'fuel', title = st.label, subtitle = ('%s $ le litre · il manque %d L'):format(tostring(price), need), items = { opt('Un peu', 10), opt('Moyen', 25), opt('Faire le plein', need) } })
end

-- (v1.2.41) plein à pied avec animation (pistolet de la pompe) : durée selon les litres, le joueur reste sur place pendant le plein
local ANIM_DICT, ANIM_NAME = 'timetable@gardener@filling_can', 'gar_ig_5_filling_can'
RegisterNetEvent('pb:g:fuel:add', function(j)
    local d = G.decode(j)
    local ped = PlayerPedId()
    local veh = (fillVeh ~= 0 and DoesEntityExist(fillVeh)) and fillVeh or GetVehiclePedIsIn(ped, false)
    if veh == 0 then local c = GetEntityCoords(ped) veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    if not d or veh == 0 or not SetVehicleFuelLevel then return end
    local liters = tonumber(d.liters) or 0
    local target = math.min(tankOf(veh), level(veh) + liters)
    CreateThread(function()
        filling = true
        local onFoot = GetVehiclePedIsIn(ped, false) == 0
        local dur = math.max(3000, math.min(12000, math.floor(liters * 120)))
        if onFoot then
            TaskTurnPedToFaceEntity(ped, veh, 800) Wait(800)
            RequestAnimDict(ANIM_DICT)
            local t = GetGameTimer() + 2000
            while not HasAnimDictLoaded(ANIM_DICT) and GetGameTimer() < t do Wait(10) end
            if HasAnimDictLoaded(ANIM_DICT) then TaskPlayAnim(ped, ANIM_DICT, ANIM_NAME, 2.0, 2.0, -1, 1, 0, false, false, false) end
            G.send('prompt', { show = true, text = 'Plein en cours…' })
        end
        local start, t0 = level(veh), GetGameTimer()
        while GetGameTimer() - t0 < dur do
            local k = math.min(1.0, (GetGameTimer() - t0) / dur)
            SetVehicleFuelLevel(veh, start + (target - start) * k)
            if onFoot then for _, ctl in ipairs({ 21, 22, 24, 25, 30, 31, 32, 33, 34, 35, 44, 140, 141, 142 }) do DisableControlAction(0, ctl, true) end end
            Wait(0)
        end
        SetVehicleFuelLevel(veh, target)
        if onFoot then StopAnimTask(ped, ANIM_DICT, ANIM_NAME, 1.0) RemoveAnimDict(ANIM_DICT) G.send('prompt', { show = false }) end
        dry[veh] = nil
        filling = false
    end)
end)

-- (v1.2.39) Plein à une vraie pompe : à pied à côté de la pompe (véhicule garé à côté) ou au volant, moteur coupé automatiquement.
local PUMPS = {}
for _, m in ipairs({ 'prop_gas_pump_1a', 'prop_gas_pump_1b', 'prop_gas_pump_1c', 'prop_gas_pump_1d', 'prop_vintage_pump', 'prop_gas_pump_old2', 'prop_gas_pump_old3' }) do PUMPS[#PUMPS + 1] = GetHashKey(m) end
local function pumpNear(pos, r)
    for _, h in ipairs(PUMPS) do
        local o = GetClosestObjectOfType(pos.x, pos.y, pos.z, r, h, false, false, false)
        if o ~= 0 then return o end
    end
end
local function carNear(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 then return GetPedInVehicleSeat(veh, -1) == ped and veh or 0 end
    local c = GetEntityCoords(ped)
    local best, bd = 0, 7.0
    for _, v in ipairs(GetGamePool and GetGamePool('CVehicle') or {}) do
        local d = #(c - GetEntityCoords(v))
        if d < bd then best, bd = v, d end
    end
    return best
end
CreateThread(function()
    local shown = false
    local function hide() if shown then shown = false G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #stations == 0 or filling or G.Menu.IsOpen() or cfg().enabled == false then hide() Wait(600)
        else
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd
            for _, s in ipairs(stations) do local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) if not bd or d < bd then best, bd = s, d end end
            local area = tonumber(cfg().area) or 30.0
            local ok, veh, inCar = false, 0, GetVehiclePedIsIn(ped, false) ~= 0
            if best and bd <= area then
                -- (v1.2.41) le plein se fait à pied : on descend, on se met à la pompe, le véhicule garé à côté
                local reach = (tonumber(cfg().use_dist) or 4.0) + (inCar and 2.5 or 0.0)
                local pump = pumpNear(c, reach)
                if pump ~= nil or bd <= reach then
                    if inCar then ok = 'car'
                    else veh = carNear(ped) ok = veh ~= 0 end
                end
            end
            if ok == 'car' then
                local v = GetVehiclePedIsIn(ped, false)
                if GetEntitySpeed(v) < 1.0 then
                    if shown ~= 'car' then shown = 'car' G.send('prompt', { show = true, text = 'Descends du véhicule pour faire le plein' }) end
                else hide() end
                Wait(200)
            elseif ok then
                if shown ~= 'foot' then shown = 'foot' G.send('prompt', { show = true, key = 'E', text = 'Faire le plein : ' .. best.label }) end
                if IsControlJustPressed(0, 38) and not filling then
                    if cfg().engine_off_to_fill ~= false and GetIsVehicleEngineRunning(veh) then SetVehicleEngineOn(veh, false, false, true) end
                    hide() pumpMenu(best, veh)
                end
                Wait(0)
            else hide() Wait(bd and bd < 60 and 250 or 900) end
        end
    end
end)

-- Dégâts : sauvegarde de l'état toutes les 30 s et en sortant, épave si le véhicule est détruit ---------------------------------------
local function tyres(veh) local m = 0 for i = 0, 7 do if IsVehicleTyreBurst(veh, i, false) then m = m | (1 << i) end end return m end
local function doors(veh) local m = 0 for i = 0, 5 do if IsVehicleDoorDamaged and IsVehicleDoorDamaged(veh, i) then m = m | (1 << i) end end return m end
function G.VehProps(veh)
    local c1, c2 = GetVehicleColours(veh)
    return { eh = GetVehicleEngineHealth(veh), bh = GetVehicleBodyHealth(veh), th = GetVehiclePetrolTankHealth(veh), fuel = level(veh), c1 = c1, c2 = c2, dirt = GetVehicleDirtLevel(veh), ty = tyres(veh), dr = doors(veh) }
end
function G.ApplyDamage(veh, p)
    if p.ty then for i = 0, 7 do if p.ty & (1 << i) ~= 0 then SetVehicleTyreBurst(veh, i, true, 1000.0) end end end
    if p.dr then for i = 0, 5 do if p.dr & (1 << i) ~= 0 then SetVehicleDoorBroken(veh, i, true) end end end
end
CreateThread(function()
    local lastVeh, lastPlate = 0, ''
    while true do
        Wait(1500)
        if G.begun then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                lastVeh, lastPlate = veh, plateOf(veh)
                if IsEntityDead(veh) then TriggerServerEvent('pb:g:veh:wreck', lastPlate) Wait(4000) end
            elseif lastVeh ~= 0 then
                if DoesEntityExist(lastVeh) and not IsEntityDead(lastVeh) then TriggerServerEvent('pb:g:veh:sync', lastPlate, G.VehProps(lastVeh)) end
                lastVeh, lastPlate = 0, ''
            end
        end
    end
end)
CreateThread(function()
    while true do
        Wait(30000)
        local ped = PlayerPedId()
        local veh = G.begun and GetVehiclePedIsIn(ped, false) or 0
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and not IsEntityDead(veh) then TriggerServerEvent('pb:g:veh:sync', plateOf(veh), G.VehProps(veh)) end
    end
end)

-- Clé : un véhicule acheté en ville ne démarre qu'avec sa clé (le trafic reste libre) ---------------------------------------------------
RegisterNetEvent('pb:g:veh:checked', function(j)
    local d = G.decode(j)
    if d and d.plate then keyOk[d.plate] = (not d.owned) or d.key == true end
end)
CreateThread(function()
    local asked = {}
    while true do
        Wait(300)
        local veh = G.begun and GetVehiclePedIsIn(PlayerPedId(), false) or 0
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == PlayerPedId() then
            local plate = plateOf(veh)
            if keyOk[plate] == nil then
                -- on demande au serveur ; le moteur n'est PAS coupé en attendant (sinon il calait à chaque première montée,
                -- comme un moteur froid) : il ne sera coupé que si la réponse dit « pas la clé »
                if not asked[plate] or GetGameTimer() - asked[plate] > 4000 then asked[plate] = GetGameTimer() TriggerServerEvent('pb:g:veh:check', plate) end
            elseif keyOk[plate] == false then
                if not asked[plate] or GetGameTimer() - asked[plate] > 5000 then asked[plate] = GetGameTimer() TriggerServerEvent('pb:g:veh:check', plate) end
                if GetIsVehicleEngineRunning(veh) then SetVehicleEngineOn(veh, false, true, true) G.send('notify', { type = 'warn', title = 'Véhicule', text = "Tu n'as pas la clé de ce véhicule." }) end
            end
        end
    end
end)
