-- Police : menottes (animation + contrôles bloqués), ouverture de la fouille, recherche de la plaque du véhicule le plus proche.
local G = PBG
local cuffed = false
function G.IsCuffed() return cuffed end   -- gestes, animations, graffitis : bloqués menotté

RegisterNetEvent('pb:g:police:cuff', function(j)
    local d = G.decode(j)
    if not d then return end
    cuffed = d.on == true
    local ped = PlayerPedId()
    if cuffed then
        RequestAnimDict('mp_arresting')
        local t = GetGameTimer()
        while not HasAnimDictLoaded('mp_arresting') and GetGameTimer() - t < 3000 do Wait(10) end
        SetEnableHandcuffs(ped, true)
        SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
        TaskPlayAnim(ped, 'mp_arresting', 'idle', 8.0, -8.0, -1, 49, 0, false, false, false)
        if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 0) end
        G.send('menu.close', {})
    else
        SetEnableHandcuffs(ped, false)
        ClearPedTasks(ped)
    end
end)

local CUFF_CONTROLS = { 24, 25, 140, 141, 142, 257, 263, 264, 21, 22, 23, 75, 44, 45 }
CreateThread(function()
    while true do
        if cuffed then
            local ped = PlayerPedId()
            DisablePlayerFiring(PlayerId(), true)
            for i = 1, #CUFF_CONTROLS do DisableControlAction(0, CUFF_CONTROLS[i], true) end
            if not IsEntityPlayingAnim(ped, 'mp_arresting', 'idle', 3) and HasAnimDictLoaded('mp_arresting') and not IsPedInAnyVehicle(ped, false) then
                TaskPlayAnim(ped, 'mp_arresting', 'idle', 8.0, -8.0, -1, 49, 0, false, false, false)
            end
            Wait(0)
        else Wait(500) end
    end
end)

-- Fouille : l'inventaire du suspect s'ouvre à côté du sac de l'agent
RegisterNetEvent('pb:g:police:search', function(owner)
    Wait(200)
    TriggerServerEvent('pb:g:inv:open', tostring(owner))
end)

-- Saisie : le client ne fait que lire la plaque du véhicule le plus proche ; le serveur revérifie tout
RegisterNetEvent('pb:g:police:askVehicle', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then veh = GetClosestVehicle(c.x, c.y, c.z, 8.0, 0, 71) end
    if veh == 0 then TriggerServerEvent('pb:g:police:vehicle', '', 0) return end
    TriggerServerEvent('pb:g:police:vehicle', (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', ''), NetworkGetNetworkIdFromEntity(veh))
end)
