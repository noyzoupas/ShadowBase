-- Gestes de métier (menu F6) côté joueur : désigner le véhicule, animation + barre de progression, puis l'effet demandé par le serveur.
-- Le serveur décide de tout (droits, durée, distance, prix) ; ici on ne fait que viser, jouer l'animation et appliquer l'effet.
local G = PBG

local function notify(t, title, text) G.send('notify', { type = t, title = title, text = text }) end
local function closestVeh(r, notModel)
    local ped = PlayerPedId()
    local v = GetVehiclePedIsIn(ped, false)
    if v ~= 0 and (not notModel or GetEntityModel(v) ~= notModel) then return v end
    local me = GetEntityCoords(ped)
    local best, bd = nil, r or 6.0
    for _, e in ipairs(GetGamePool('CVehicle')) do
        if (not notModel or GetEntityModel(e) ~= notModel) and not IsEntityAttached(e) then
            local d = #(GetEntityCoords(e) - me)
            if d < bd then best, bd = e, d end
        end
    end
    return best
end
local function grab(veh)
    if NetworkHasControlOfEntity(veh) then return true end
    NetworkRequestControlOfEntity(veh)
    local t = GetGameTimer() + 1500
    while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(30) NetworkRequestControlOfEntity(veh) end
    return NetworkHasControlOfEntity(veh)
end
local function vehOf(netId)
    local v = (netId and netId ~= 0 and NetworkDoesNetworkIdExist(netId)) and NetworkGetEntityFromNetworkId(netId) or 0
    if v == 0 or not DoesEntityExist(v) then v = closestVeh(8.0) end
    return v
end

-- 1. le serveur demande le véhicule visé
RegisterNetEvent('pb:g:job:veh', function(id, j)
    local v = closestVeh(6.0)
    if not v then notify('warn', 'Métier', 'Aucun véhicule à côté de toi.') return end
    if not NetworkGetEntityIsNetworked(v) then NetworkRegisterEntityAsNetworked(v) end
    TriggerServerEvent('pb:g:job:vehicle', id, NetworkGetNetworkIdFromEntity(v), G.decode(j) or {})
end)

-- 2. animation et barre de progression ; le serveur vérifie la durée à la fin
local working = false
RegisterNetEvent('pb:g:job:work', function(j)
    local d = G.decode(j)
    if not d or working then return end
    working = true
    if G.Menu.IsOpen() then G.Menu.Close() end
    CreateThread(function()
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then TaskLeaveAnyVehicle(ped, 0, 0) Wait(1500) end
        local veh = d.netId and d.netId ~= 0 and vehOf(d.netId) or nil
        if veh then TaskTurnPedToFaceEntity(ped, veh, 800) Wait(800) end
        local start = GetEntityCoords(ped)
        if d.anim then TaskStartScenarioInPlace(ped, d.anim, 0, true) end
        G.send('crime.progress', { label = tostring(d.label or 'Travail'), secs = d.secs })
        local t = GetGameTimer() + (tonumber(d.secs) or 5) * 1000
        while GetGameTimer() < t do
            Wait(250)
            if #(GetEntityCoords(ped) - start) > 3.0 or IsEntityDead(ped) then
                ClearPedTasks(ped) G.send('crime.progress', { cancel = true }) notify('warn', tostring(d.label or 'Travail'), 'Travail interrompu.')
                working = false
                return
            end
        end
        ClearPedTasks(ped)
        working = false
        TriggerServerEvent('pb:g:job:done')
    end)
end)

-- 3. effets
local function pct(v, max) return math.max(0, math.min(100, math.floor((tonumber(v) or 0) / max * 100 + 0.5))) end
local towed = {}   -- plateau (entité) -> véhicule chargé
local FLATBED = joaat('flatbed')
local FX = {}
FX.diag = function(veh)
    local burst = 0
    for i = 0, 7 do if IsVehicleTyreBurst(veh, i, false) then burst = burst + 1 end end
    local tank = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')
    local function row(l, v, warn) return { label = l, right = v, icon = warn and 'alert' or 'check', disabled = true } end
    local eng, body, petrol = pct(GetVehicleEngineHealth(veh), 1000), pct(GetVehicleBodyHealth(veh), 1000), pct(GetVehiclePetrolTankHealth(veh), 1000)
    local fuel = tank and tank > 0 and pct(GetVehicleFuelLevel(veh), tank) or pct(GetVehicleFuelLevel(veh), 100)
    G.Menu.Open({ id = 'job.diag', title = 'Diagnostic', subtitle = (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', ''), banner = { text = 'Diagnostic' }, items = {
        row('Moteur', eng .. ' %', eng < 60), row('Carrosserie', body .. ' %', body < 60), row('Réservoir', petrol .. ' %', petrol < 60),
        row('Pneus crevés', tostring(burst), burst > 0), row('Carburant', fuel .. ' %', fuel < 20), row('Saleté', pct(GetVehicleDirtLevel(veh), 15) .. ' %', GetVehicleDirtLevel(veh) > 8),
        row('Sur ses roues', IsVehicleOnAllWheels(veh) and 'Oui' or 'Non', not IsVehicleOnAllWheels(veh)),
        row('Verrouillé', GetVehicleDoorLockStatus(veh) >= 2 and 'Oui' or 'Non', false) } })
end
FX.engine = function(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleUndriveable(veh, false) end
FX.body = function(veh)
    local eng = GetVehicleEngineHealth(veh)
    SetVehicleDeformationFixed(veh) SetVehicleBodyHealth(veh, 1000.0)
    for i = 0, 7 do FixVehicleWindow(veh, i) end
    for i = 0, 5 do SetVehicleDoorShut(veh, i, false) end
    SetVehicleEngineHealth(veh, eng)   -- la carrosserie ne répare pas le moteur
end
FX.tyres = function(veh) for _, i in ipairs({ 0, 1, 2, 3, 4, 5, 45, 47 }) do SetVehicleTyreFixed(veh, i) end end
FX.flip = function(veh) local r = GetEntityRotation(veh, 2) SetEntityRotation(veh, 0.0, 0.0, r.z, 2, true) SetVehicleOnGroundProperly(veh) end
FX.unlock = function(veh) SetVehicleDoorsLocked(veh, 1) SetVehicleDoorsLockedForAllPlayers(veh, false) SetVehicleNeedsToBeHotwired(veh, false) end
FX.wash = function(veh) SetVehicleDirtLevel(veh, 0.0) WashDecalsFromVehicle(veh, 1.0) end
FX.refuel = function() TriggerEvent('pb:g:fuel:add', json.encode({ liters = 500 })) end
FX.extinguish = function()
    local c = GetEntityCoords(PlayerPedId())
    StopFireInRange(c.x, c.y, c.z, 20.0)
    for _, e in ipairs(GetGamePool('CVehicle')) do if #(GetEntityCoords(e) - c) < 20.0 and IsEntityOnFire(e) then StopEntityFire(e) end end
    notify('success', 'Pompiers', 'Feux éteints autour de toi.')
end
local function flatbedNear()
    local me = GetEntityCoords(PlayerPedId())
    local best, bd = nil, 12.0
    for _, e in ipairs(GetGamePool('CVehicle')) do
        if GetEntityModel(e) == FLATBED then local d = #(GetEntityCoords(e) - me) if d < bd then best, bd = e, d end end
    end
    return best
end
FX.tow_load = function()
    local fb = flatbedNear()
    if not fb then notify('warn', 'Plateau', 'Aucune dépanneuse à plateau (Flatbed) à côté de toi.') return end
    if towed[fb] and DoesEntityExist(towed[fb]) and IsEntityAttachedToEntity(towed[fb], fb) then notify('warn', 'Plateau', 'Le plateau est déjà chargé.') return end
    local back = GetOffsetFromEntityInWorldCoords(fb, 0.0, -7.0, 0.0)
    local veh, bd = nil, 7.0
    for _, e in ipairs(GetGamePool('CVehicle')) do
        if e ~= fb and not IsEntityAttached(e) then local d = #(GetEntityCoords(e) - back) if d < bd then veh, bd = e, d end end
    end
    if not veh then notify('warn', 'Plateau', 'Mets le véhicule à charger juste derrière la dépanneuse.') return end
    if GetPedInVehicleSeat(veh, -1) ~= 0 then notify('warn', 'Plateau', "Quelqu'un est au volant de ce véhicule.") return end
    if not grab(veh) then notify('error', 'Plateau', 'Impossible de prendre la main sur ce véhicule.') return end
    local mn = GetModelDimensions(GetEntityModel(veh))
    AttachEntityToEntity(veh, fb, GetEntityBoneIndexByName(fb, 'bodyshell'), 0.0, -2.0, 0.55 - mn.z, 0.0, 0.0, 0.0, false, false, true, false, 20, true)
    towed[fb] = veh
    notify('success', 'Plateau', 'Véhicule chargé : roule, puis « Décharger le plateau ».')
end
FX.tow_unload = function()
    local fb = flatbedNear()
    if not fb then notify('warn', 'Plateau', 'Aucune dépanneuse à plateau à côté de toi.') return end
    local veh = towed[fb]
    if not (veh and DoesEntityExist(veh) and IsEntityAttachedToEntity(veh, fb)) then
        veh = nil
        for _, e in ipairs(GetGamePool('CVehicle')) do if IsEntityAttachedToEntity(e, fb) then veh = e end end
    end
    if not veh then notify('warn', 'Plateau', 'Le plateau est vide.') return end
    if not grab(veh) then notify('error', 'Plateau', 'Impossible de prendre la main sur ce véhicule.') return end
    DetachEntity(veh, true, true)
    local p = GetOffsetFromEntityInWorldCoords(fb, 0.0, -9.0, 0.0)
    SetEntityCoords(veh, p.x, p.y, p.z + 0.5, false, false, false, false)
    SetEntityHeading(veh, GetEntityHeading(fb))
    SetVehicleOnGroundProperly(veh)
    towed[fb] = nil
    notify('success', 'Plateau', 'Véhicule déchargé derrière la dépanneuse.')
end
RegisterNetEvent('pb:g:job:fx', function(j)
    local d = G.decode(j)
    local f = d and FX[d.kind]
    if not f then return end
    if d.kind == 'refuel' or d.kind == 'extinguish' or d.kind == 'tow_load' or d.kind == 'tow_unload' then f() return end
    local veh = vehOf(d.netId)
    if not veh then notify('warn', 'Métier', 'Le véhicule a disparu.') return end
    if d.kind ~= 'diag' and not grab(veh) then notify('error', 'Métier', 'Impossible de travailler sur ce véhicule (un autre joueur le contrôle).') return end
    f(veh)
end)
