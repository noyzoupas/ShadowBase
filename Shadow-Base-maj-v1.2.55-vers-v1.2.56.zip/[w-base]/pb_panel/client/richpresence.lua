-- Statut Discord du joueur : réglé dans le panel (server/game/richpresence.lua), appliqué ici régulièrement.
local G = PBG
local lastApp

local function fill(t)
    local id = G.identity or {}
    local name = ((id.firstname or '') .. ' ' .. (id.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    local brand = (G.cfg.brand and G.cfg.brand.name) or ''
    local vals = { serveur = brand, joueurs = tostring(GlobalState.pb_online or 0), max = tostring(GlobalState.pb_maxp or 0), nom = name ~= '' and name or brand, id = tostring(GetPlayerServerId(PlayerId())) }
    return (tostring(t or ''):gsub('{(%a+)}', function(k) return vals[k] end))
end
local function apply()
    local c = G.cfg and G.cfg.richp
    if not c then return end
    if c.enabled == false or tostring(c.app_id or '') == '' then
        if lastApp then SetRichPresence('') lastApp = nil end
        return
    end
    if lastApp ~= c.app_id then SetDiscordAppId(tostring(c.app_id)) lastApp = c.app_id end
    SetRichPresence(fill(c.text))
    if (c.large_key or '') ~= '' then SetDiscordRichPresenceAsset(c.large_key) SetDiscordRichPresenceAssetText(fill(c.large_text)) end
    if (c.small_key or '') ~= '' then SetDiscordRichPresenceAssetSmall(c.small_key) SetDiscordRichPresenceAssetSmallText(fill(c.small_text)) end
    if (c.btn1_label or '') ~= '' and (c.btn1_url or '') ~= '' then SetDiscordRichPresenceAction(0, c.btn1_label, c.btn1_url) end
    if (c.btn2_label or '') ~= '' and (c.btn2_url or '') ~= '' then SetDiscordRichPresenceAction(1, c.btn2_label, c.btn2_url) end
end
CreateThread(function()
    while true do
        pcall(apply)
        Wait(math.max(15, tonumber(G.cfg and G.cfg.richp and G.cfg.richp.refresh) or 30) * 1000)
    end
end)
