-- Effets des gestes du staff reçus du serveur (pb:g:gx). Le serveur a déjà vérifié le droit, le rang et borné les durées ;
-- le client n'exécute que des effets de cette liste blanche, avec des durées bornées de nouveau ici.
local G = PBG

local ANIM = {
    salute = { 'anim', 'anim@mp_player_intincarsalutestd@ds@', 'idle_a', 49 }, handsup = { 'anim', 'missminuteman_1ig_2', 'handsup_base', 49 },
    facepalm = { 'anim', 'anim@mp_player_intcelebrationmale@face_palm', 'face_palm', 49 }, thumbs = { 'anim', 'anim@mp_player_intincarthumbs_upbodhi@ps@', 'enter', 49 },
    dj = { 'anim', 'anim@mp_player_intcelebrationmale@dj', 'dj', 49 }, guitar = { 'anim', 'anim@mp_player_intcelebrationmale@air_guitar', 'air_guitar', 49 },
    wave = { 'anim', 'friends@frj@ig_1', 'wave_a', 49 }, cheer = { 'scn', 'WORLD_HUMAN_CHEERING' }, pushups = { 'scn', 'WORLD_HUMAN_PUSH_UPS' },
    situps = { 'scn', 'WORLD_HUMAN_SIT_UPS' }, yoga = { 'scn', 'WORLD_HUMAN_YOGA' }, flex = { 'scn', 'WORLD_HUMAN_MUSCLE_FLEX' }, party = { 'scn', 'WORLD_HUMAN_PARTYING' },
    smoke = { 'scn', 'WORLD_HUMAN_SMOKING' }, impatient = { 'scn', 'WORLD_HUMAN_STAND_IMPATIENT' }, slump = { 'scn', 'WORLD_HUMAN_BUM_SLUMPED' },
}
local SOUND = { beep = { 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS' }, alert = { 'TIMER_STOP', 'HUD_MINI_GAME_SOUNDSET' }, success = { 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET' }, timer = { '5_SEC_WARNING', 'HUD_MINI_GAME_SOUNDSET' } }

local active = {}    -- effet -> échéance (ms)
local function dur(d) return math.max(3, math.min(300, math.floor(tonumber(d) or 10))) * 1000 end
local function until_(name, d) active[name] = GetGameTimer() + dur(d) end
local function loadDict(dict)
    RequestAnimDict(dict)
    local t = GetGameTimer() + 3000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(10) end
    return HasAnimDictLoaded(dict)
end
local function vehicle(ped)
    local v = GetVehiclePedIsIn(ped, false)
    if v ~= 0 then return v end
    local c = GetEntityCoords(ped)
    v = GetClosestVehicle(c.x, c.y, c.z, 12.0, 0, 71)
    return (v ~= 0 and DoesEntityExist(v)) and v or 0
end
local function owner(v) if not NetworkHasControlOfEntity(v) then NetworkRequestControlOfEntity(v) local t = GetGameTimer() + 600 while not NetworkHasControlOfEntity(v) and GetGameTimer() < t do Wait(20) end end end

local function clearAll()
    for k in pairs(active) do active[k] = nil end
    local ped = PlayerPedId()
    ClearTimecycleModifier() StopGameplayCamShaking(true) ResetPedMovementClipset(ped, 0.5) SetPedMotionBlur(ped, false)
    SetPlayerInvincible(PlayerId(), false) SetRunSprintMultiplierForPlayer(PlayerId(), 1.0) SetPedMoveRateOverride(ped, 1.0)
    if IsScreenFadedOut() then DoScreenFadeIn(300) end
    SetEntityVisible(ped, true, false)
    G.send('gx.clear', {})
end

local OPS = {}
OPS.hp = function(d) local ped = PlayerPedId() if not IsEntityDead(ped) then SetEntityHealth(ped, math.max(101, math.min(GetEntityMaxHealth(ped), 100 + math.floor(tonumber(d.value) or 1)))) end end
OPS.armor = function(d) SetPedArmour(PlayerPedId(), math.max(0, math.min(100, math.floor(tonumber(d.value) or 0)))) end
OPS.god = function(d) SetPlayerInvincible(PlayerId(), true) until_('god', d.dur) end
OPS.ragdoll = function(d) local ms = math.min(dur(d.dur or 4), 120000) SetPedToRagdoll(PlayerPedId(), ms, ms, 0, false, false, false) end
OPS.speed = function(d) active.speed = GetGameTimer() + dur(d.dur) active.speedMult = math.max(0.5, math.min(1.49, tonumber(d.mult) or 1.0)) end
OPS.jump = function(d) until_('jump', d.dur) end
OPS.hide = function(d) SetEntityVisible(PlayerPedId(), false, false) until_('hide', d.dur) end
OPS.restore = function()
    if G.appearance and G.applyAppearance then G.applyAppearance(G.appearance, true) end
    SetEntityVisible(PlayerPedId(), true, false)
end
OPS.ped = function(d)
    local m = tostring(d.model or '')
    if not m:match('^[%w_]+$') then return end
    local h = GetHashKey(m)
    if not IsModelInCdimage(h) or not IsModelAPed(h) then G.send('notify', { type = 'warn', text = 'Modèle de ped inconnu.' }) return end
    RequestModel(h)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(0) end
    if HasModelLoaded(h) then SetPlayerModel(PlayerId(), h) SetModelAsNoLongerNeeded(h) end
end
OPS.props = function() local ped = PlayerPedId() ClearPedProp(ped, 0) ClearPedProp(ped, 1) end
OPS.clean = function() local ped = PlayerPedId() ClearPedBloodDamage(ped) ClearPedEnvDirt(ped) ResetPedVisibleDamage(ped) end
OPS.anim = function(d)
    local a = ANIM[tostring(d.key or '')]
    local ped = PlayerPedId()
    if not a or IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) then return end
    ClearPedTasks(ped)
    if a[1] == 'scn' then TaskStartScenarioInPlace(ped, a[2], 0, true)
    elseif loadDict(a[2]) then TaskPlayAnim(ped, a[2], a[3], 8.0, -8.0, -1, a[4], 0, false, false, false) end
end
OPS.animstop = function() ClearPedTasks(PlayerPedId()) end
OPS.banner = function(d) G.send('gx.banner', { text = tostring(d.text or ''):sub(1, 140), ms = dur(d.dur) }) end
OPS.sound = function(d) local s = SOUND[tostring(d.key or '')] if s then PlaySoundFrontend(-1, s[1], s[2], true) end end
OPS.media = function(d)
    local kind = tostring(d.kind or '')
    if (kind == 'image' or kind == 'audio' or kind == 'video') and type(d.url) == 'string' and d.url:sub(1, 8) == 'https://' then G.send('gx.media', { url = d.url, kind = kind, ms = dur(d.dur) }) end
end
OPS.drunk = function(d)
    local ped = PlayerPedId()
    RequestAnimSet('move_m@drunk@verydrunk')
    local t = GetGameTimer() + 2000
    while not HasAnimSetLoaded('move_m@drunk@verydrunk') and GetGameTimer() < t do Wait(10) end
    SetPedMovementClipset(ped, 'move_m@drunk@verydrunk', 1.0) SetTimecycleModifier('spectator5') SetPedMotionBlur(ped, true)
    ShakeGameplayCam('DRUNK_SHAKE', 1.0)
    until_('drunk', d.dur)
end
OPS.shake = function(d) ShakeGameplayCam('MEDIUM_EXPLOSION_SHAKE', 0.4) until_('shake', d.dur) end
OPS.blur = function(d) SetTimecycleModifier('drug_flying_base') until_('blur', d.dur) end
OPS.black = function(d) DoScreenFadeOut(300) active.black = GetGameTimer() + math.min(dur(d.dur), 15000) end
OPS.scream = function() PlayPain(PlayerPedId(), 7, 0.0) end
OPS.stop = function() clearAll() end
OPS.intoveh = function(d)
    local ped = PlayerPedId()
    local net = math.floor(tonumber(d.net) or 0)
    if net <= 0 or not NetworkDoesNetworkIdExist(net) or IsPedInAnyVehicle(ped, false) then return end
    local v = NetworkGetEntityFromNetworkId(net)
    if v == 0 or not DoesEntityExist(v) then return end
    for seat = 0, GetVehicleModelNumberOfSeats(GetEntityModel(v)) - 2 do if IsVehicleSeatFree(v, seat) then SetPedIntoVehicle(ped, v, seat) return end end
end

-- véhicule
local function withVeh(fn) return function(d) local v = vehicle(PlayerPedId()) if v ~= 0 then owner(v) fn(v, d) end end end
OPS.vrepair = withVeh(function(v) SetVehicleFixed(v) SetVehicleDeformationFixed(v) SetVehicleDirtLevel(v, 0.0) SetVehicleEngineHealth(v, 1000.0) end)
OPS.vflip = withVeh(function(v) local r = GetEntityRotation(v, 2) SetEntityRotation(v, 0.0, 0.0, r.z, 2, true) SetVehicleOnGroundProperly(v) end)
OPS.vengine = withVeh(function(v) SetVehicleEngineOn(v, not GetIsVehicleEngineRunning(v), true, true) end)
OPS.vlock = withVeh(function(v) SetVehicleDoorsLocked(v, GetVehicleDoorLockStatus(v) > 1 and 1 or 2) end)
OPS.vburst = withVeh(function(v) for i = 0, 7 do SetVehicleTyreBurst(v, i, true, 1000.0) end end)
OPS.vbrake = function(d) local v = vehicle(PlayerPedId()) if v ~= 0 then active.brake = GetGameTimer() + dur(d.dur) active.brakeVeh = v end end
OPS.vboost = withVeh(function(v) SetVehicleForwardSpeed(v, math.min(GetEntitySpeed(v) + 25.0, 60.0)) end)
OPS.vspin = withVeh(function(v) SetEntityHeading(v, (GetEntityHeading(v) + 180.0) % 360.0) end)
OPS.vdoors = withVeh(function(v) for i = 0, 5 do SetVehicleDoorOpen(v, i, false, false) end end)
OPS.vdelete = withVeh(function(v) SetEntityAsMissionEntity(v, true, true) DeleteVehicle(v) end)

RegisterNetEvent('pb:g:gx', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' or type(d.op) ~= 'string' then return end
    local f = OPS[d.op]
    if f then CreateThread(function() pcall(f, d) end) end
end)

-- Boucle des effets durables
CreateThread(function()
    while true do
        if next(active) then
            Wait(0)
            local now, ped = GetGameTimer(), PlayerPedId()
            if active.speed then
                if now > active.speed then active.speed = nil active.speedMult = nil SetRunSprintMultiplierForPlayer(PlayerId(), 1.0) SetPedMoveRateOverride(ped, 1.0)
                else SetRunSprintMultiplierForPlayer(PlayerId(), active.speedMult or 1.0) SetPedMoveRateOverride(ped, active.speedMult or 1.0) end
            end
            if active.jump then if now > active.jump then active.jump = nil else SetSuperJumpThisFrame(PlayerId()) end end
            if active.brake then
                if now > active.brake or not DoesEntityExist(active.brakeVeh or 0) then
                    if DoesEntityExist(active.brakeVeh or 0) then SetVehicleHandbrake(active.brakeVeh, false) end
                    active.brake, active.brakeVeh = nil, nil
                else SetVehicleHandbrake(active.brakeVeh, true) end
            end
            for _, k in ipairs({ 'god', 'hide', 'drunk', 'shake', 'blur', 'black' }) do
                if active[k] and now > active[k] then
                    active[k] = nil
                    if k == 'god' then SetPlayerInvincible(PlayerId(), false)
                    elseif k == 'hide' then SetEntityVisible(ped, true, false)
                    elseif k == 'drunk' then ResetPedMovementClipset(ped, 0.5) ClearTimecycleModifier() StopGameplayCamShaking(true) SetPedMotionBlur(ped, false)
                    elseif k == 'shake' then StopGameplayCamShaking(true)
                    elseif k == 'blur' then ClearTimecycleModifier()
                    elseif k == 'black' then DoScreenFadeIn(500) end
                end
            end
        else Wait(500) end
    end
end)

-- Vue d'écran (capture ou direct) : l'image reçue est transmise telle quelle à l'interface, qui la contrôle de nouveau.
RegisterNetEvent('pb:g:gx:screen', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    if d.stop then G.send('gx.screen', { stop = true }) return end
    if type(d.img) == 'string' and d.img:sub(1, 23) == 'data:image/jpeg;base64,' then G.send('gx.screen', { id = d.id, name = tostring(d.name or ''):sub(1, 60), img = d.img, live = d.live == true }) end
end)
G.nui['gx.screen.close'] = function() TriggerServerEvent('pb:g:gx:screenstop') return {} end
-- (v1.2.59) mini-écrans du staff : déplacés et redimensionnés avec la souris le temps de /ecrans
local editWins = false
RegisterNetEvent('pb:g:gx:win', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' then return end
    if d.stop then G.send('specwin.stop', { id = d.id })
    elseif d.open then G.send('specwin.open', { id = d.id, name = tostring(d.name or ''):sub(1, 60) })
    elseif type(d.img) == 'string' then G.send('specwin.frame', { id = d.id, name = tostring(d.name or ''):sub(1, 60), img = d.img }) end
end)
G.nui['specwin.close'] = function(d) TriggerServerEvent('pb:g:gx:winclose', tonumber(d.id)) return {} end
local function setEditWins(on)
    if on == editWins then return end
    editWins = on
    G.focus(on)
    G.send('specwin.edit', { on = on })
end
G.nui['specwin.editoff'] = function() setEditWins(false) return {} end
RegisterCommand('ecrans', function() setEditWins(not editWins) end, false)

AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then pcall(clearAll) end end)
