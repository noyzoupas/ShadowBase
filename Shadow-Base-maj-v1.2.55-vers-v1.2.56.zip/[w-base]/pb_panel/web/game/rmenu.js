/* pb_menu — rendu du menu « RageUI » : bannière, titre + compteur, ligne de progression, sous-titre, éléments, description.
   Tout texte reçu est inséré avec textContent. Le thème vient de la configuration « menus » (panel > Menus). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;

const DEFAULTS = { accent: '#dfe2e7', bg: '#111216', bg2: '#2b2e35', text: '#ffffff', muted: '#8d939e', banner_mode: 'anim', banner_text: '', banner_sub: '', banner_image: '', banner_height: 110, banner_band: true,
  chips: ['discord|DISCORD.GG/MONSERVEUR', 'globe|HTTPS://MONSERVEUR.FR'], width: 440, radius: 10, opacity: 88, blur: 0, row_height: 44, font_scale: 100, position: 'center', offset_x: 0, offset_y: -300,
  show_counter: true, show_desc: true, show_progress: true, title_case: 'upper', selected_style: 'bar', skin: 'nova', banner_logo: '', discord: 'discord.gg/monserveur' };

const num = (v, d, lo, hi) => { v = Number(v); if (!isFinite(v)) v = d; return Math.max(lo, Math.min(hi, v)); };
function themeOf(cfg) {
  const t = Object.assign({}, DEFAULTS, cfg || {});
  t.banner_height = num(t.banner_height, 130, 0, 260); t.width = num(t.width, 440, 280, 640); t.radius = num(t.radius, 16, 0, 32);
  t.opacity = num(t.opacity, 96, 40, 100); t.blur = num(t.blur, 0, 0, 30); t.row_height = num(t.row_height, 44, 32, 72); t.font_scale = num(t.font_scale, 100, 70, 160);
  t.offset_x = num(t.offset_x, 0, -2000, 2000); t.offset_y = num(t.offset_y, 0, -2000, 2000);
  if (!/^#[0-9a-f]{6}$/i.test(t.accent)) t.accent = DEFAULTS.accent;
  ['bg', 'bg2', 'text', 'muted'].forEach((k) => { if (!/^#[0-9a-f]{6}$/i.test(t[k])) t[k] = DEFAULTS[k]; });
  return t;
}
const safeUrl = (u) => G.assetUrl(u);

function chip(spec) {
  const parts = String(spec || '').split('|');
  const name = parts.length > 1 ? parts[0].trim() : 'link', text = (parts.length > 1 ? parts.slice(1).join('|') : parts[0]).trim();
  return h('span', { class: 'rm-chip' }, G.ico(name, 'rm-chi'), h('b', null, text));
}

// ---- habillage « Shadow » (maquette Shadow Studio, reproduite à l'identique) : fond complet de la maquette (cadre, logo, décor, flèche),
// bloc de contenu à 124 px du haut et 17 px du bord, lignes 314 × 35 avec leur image, puce et icônes de la maquette, description en dessous.
// Les icônes de la maquette remplacent celles du thème quand elles existent (taille, opacité et marge reprises de la maquette).
const SH_IC = {
  tune: ['i_tune', 14, 14, 14, 14, 1, 5], bolt: ['i_bolt', 13, 13, 9.21, 13, 0.6, 6], users: ['i_user', 11, 11, 8.44, 9.74, 0.63, 6], user: ['i_user', 11, 11, 8.44, 9.74, 0.63, 6],
  engine: ['i_engine', 12, 11, 10, 9.17, 0.79, 6], car: ['i_engine', 12, 11, 10, 9.17, 0.79, 6], help: ['i_help', 13, 13, 13, 13, 0.37, 6],
  shield: ['i_shield', 13, 13, 10.29, 10.29, 0.56, 6], eye: ['i_eye', 11, 10, 9.92, 7.5, 0.56, 6], sliders: ['i_sliders', 12, 12, 10, 10, 0.68, 5],
};
function shIcon(name) {
  const d = SH_IC[name];
  const px = (v) => 'calc(' + v + 'px * var(--k))';
  if (!d) return h('span', { class: 'rms-ic', style: { width: px(13), height: px(13), marginRight: px(6), opacity: 0.6 } }, G.ico(name || 'chevron'));
  return h('span', { class: 'rms-ic', style: { width: px(d[1]), height: px(d[2]), marginRight: px(d[6]), opacity: d[5] } },
    h('img', { src: 'img/menu/' + d[0] + '.png', alt: '', draggable: false, style: { width: px(d[3]), height: px(d[4]) } }));
}
function buildShadow(t, snap, cb) {
  const k = t.width / 342;
  const el = h('div', { class: 'rm rms pos-' + t.position + (cb ? ' ui' : ''), style: { '--k': k, '--ox': t.offset_x + 'px', '--oy': t.offset_y + 'px', '--op': t.opacity / 100 } });
  const box = h('div', { class: 'rms-box' });
  // bannière du haut : celle de la maquette (logo pris dans son dégradé noir), ou l'image choisie dans le panel (Menus › Bannière : Image)
  const ban = snap.banner || {};
  const custom = safeUrl(ban.image != null ? ban.image : ((ban.mode || t.banner_mode) === 'image' ? t.banner_image : ''));
  box.appendChild(custom
    ? h('div', { class: 'rms-ban custom' }, h('img', { src: custom, alt: '', draggable: false }))
    : h('div', { class: 'rms-ban' }, h('img', { src: 'img/menu/ban_default.png', alt: '', draggable: false })));
  box.appendChild(h('img', { class: 'rms-str', src: 'img/menu/streaks.png', alt: '', draggable: false }));   // traits du haut, au-dessus du fondu (comme la maquette)
  if (cb) box.appendChild(h('button', { class: 'rms-x', title: 'Fermer', onclick: () => cb.close() }, G.ico('close')));
  const total = (snap.counter && snap.counter[1]) || 0, cur = (snap.counter && snap.counter[0]) || 0;
  const blk = h('div', { class: 'rms-blk' });
  blk.appendChild(h('div', { class: 'rms-head' },
    (cb && snap.depth > 1) ? h('button', { class: 'rms-back', title: 'Retour', onclick: () => cb.back() }, G.ico('chevron')) : null,
    h('span', { class: 'rms-t' }, String(snap.title || ''), snap.subtitle ? [' ', h('i', null, '-'), ' ', h('em', null, String(snap.subtitle))] : null),
    t.show_counter && total ? h('span', { class: 'rms-n' }, cur + '/' + total) : null));
  const list = h('div', { class: 'rms-list rm-list' });
  (snap.items || []).forEach((it) => list.appendChild(rowShadow(it, cb)));
  blk.appendChild(list);
  box.appendChild(blk);
  // mode « lib » : la ligne choisie reste toujours visible ; en interface, la liste trop longue défile (molette)
  requestAnimationFrame(() => {
    const on = list.querySelector('.rms-r.on');
    if (!on) return;
    const lr = list.getBoundingClientRect(), rr = on.getBoundingClientRect();
    if (rr.bottom > lr.bottom) list.scrollTop += rr.bottom - lr.bottom + 8;
    else if (rr.top < lr.top) list.scrollTop -= Math.min(lr.top - rr.top + 8, list.scrollTop);
  });
  el.appendChild(box);
  if (t.show_desc && snap.desc) el.appendChild(h('div', { class: 'rms-desc' }, String(snap.desc)));
  return el;
}
// en jeu : même place et même taille que sur la maquette (1920 × 1080 : 48 px du bord gauche, 226,5 px du haut), mises à l'échelle de l'écran
function placeShadow(m) {
  if (!m || !m.classList.contains('rms')) return;
  const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080) || 1;
  m.classList.add('rms-game');
  m.style.setProperty('--k', String(s));
  m.style.left = (48 * s) + 'px'; m.style.top = (226 * s) + 'px';
}
function rowShadow(it, cb) {
  if (it.kind === 'separator') return h('div', { class: 'rms-sep' }, it.label ? h('span', null, String(it.label)) : null);
  let right = null;
  if (it.kind === 'list') right = h('span', { class: 'rms-val' }, it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, -1); } : null }, '‹') : null, String(it.value || ''), it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, 1); } : null }, '›') : null);
  else if (it.kind === 'checkbox') right = h('span', { class: 'rms-chk' + (it.checked ? ' on' : '') });
  else if (it.kind === 'slider') { const p = it.max > it.min ? (it.value - it.min) / (it.max - it.min) * 100 : 0; right = h('span', { class: 'rms-sl' }, h('u', null, h('i', { style: { width: p + '%' } })), h('b', null, String(it.value))); }
  else if (it.kind === 'input') right = h('span', { class: 'rms-val' }, String(it.value || '…'));
  else right = shIcon(it.icon || 'chevron');
  const ev = cb ? { onmouseenter: () => { if (!it.active && !it.disabled) cb.hover(it.i); },
    onclick: (e) => { if (it.disabled) return; if (it.kind === 'list' || it.kind === 'slider') { const r = e.currentTarget.getBoundingClientRect(); cb.change(it.i, (e.clientX - r.left) < r.width / 2 ? -1 : 1); } else cb.select(it.i); } } : null;
  return h('div', Object.assign({ class: 'rms-r' + (it.active ? ' on' : '') + (it.disabled ? ' off' : ''), 'data-i': it.i }, ev || {}),
    h('img', { class: 'rms-dot', src: 'img/menu/' + (it.active ? 'dot_on' : 'dot') + '.png', alt: '', draggable: false }), h('span', { class: 'rms-l' }, String(it.label || '')),
    h('span', { class: 'rms-rr' }, it.right ? h('span', { class: 'rms-rt' }, String(it.right)) : null, it.badge ? h('span', { class: 'rms-bd' }, String(it.badge)) : null, right));
}

// ---- habillage « Nova » : bloc noir à coins doux, logo rond + titre + onglets, barre de section avec compteur, lignes à icônes
// (la ligne choisie est blanche), interrupteurs, curseurs, valeurs à points, description à part, touches en bas. Tailles d'une maquette
// 1920 × 1080 multipliées par --k (écran en jeu, réduit dans le panel).
function novaBold(text) {
  // met en gras les valeurs (nombres, montants, poids) d'une description : « Poids : 12,4 / 30 kg »
  const out = [], re = /(\d[\d\s.,]*(?:\s?\/\s?\d[\d\s.,]*)?\s?(?:kg|g|\$|%|km|m|L|min|h)?)/g;
  let last = 0, m;
  const str = String(text || '');
  while ((m = re.exec(str))) {
    if (m.index > last) out.push(str.slice(last, m.index));
    out.push(h('b', null, m[0]));
    last = m.index + m[0].length;
  }
  if (last < str.length) out.push(str.slice(last));
  return out;
}
function novaLogo(t, snap) {
  const ban = snap.banner || {};
  // le logo du serveur (panel › Identité) en priorité ; sinon celui choisi pour les menus ; sinon le logo par défaut
  const url = safeUrl((G.cfg.brand && G.cfg.brand.logo) || '') || safeUrl(ban.logo || '') || safeUrl(t.banner_logo || '');
  // sans logo réglé : le logo de Shadow Base (détouré)
  return h('span', { class: 'rmn-logo' }, h('img', { src: url || 'img/brand/shadow-logo.png', alt: '', draggable: false }));
}
function rowNova(it, cb) {
  if (it.kind === 'separator') return h('div', { class: 'rmn-sep' }, String(it.label || ''));
  let right = null;
  if (it.kind === 'list') {
    const n = Math.max(1, Math.min(6, Number(it.count) || 1)), pos = Math.max(1, Number(it.pos) || 1);
    const at = n >= (Number(it.count) || 1) ? pos : Math.min(n, Math.max(1, Math.round(pos / (Number(it.count) || 1) * n)));
    right = h('span', { class: 'rmn-val' },
      h('span', { class: 'rmn-vt' }, it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, -1); } : null }, '‹') : null, h('span', { class: 'rmn-vx' }, String(it.value || '')), it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, 1); } : null }, '›') : null),
      (Number(it.count) || 0) > 1 ? h('span', { class: 'rmn-dots' }, Array.from({ length: n }, (_, k) => h('i', { class: k + 1 === at ? 'on' : '' }))) : null);
  } else if (it.kind === 'checkbox') right = h('span', { class: 'rmn-sw' + (it.checked ? ' on' : '') }, h('i'));
  else if (it.kind === 'slider') { const p = it.max > it.min ? (it.value - it.min) / (it.max - it.min) * 100 : 0; right = h('span', { class: 'rmn-sl' }, h('i', { style: { width: p + '%' } })); }
  else if (it.kind === 'input') right = h('span', { class: 'rmn-rt' }, String(it.value || '…'));
  const arrow = /^(›|>|→)$/.test(String(it.right || ''));
  const rt = it.right && !arrow ? h('span', { class: 'rmn-rt' }, String(it.right)) : null;
  const bd = it.badge ? h('span', { class: 'rmn-bd' }, h('b', null, String(it.badge)), '→') : null;
  const go = !right && !bd && (it.kind === 'submenu' || arrow) ? h('span', { class: 'rmn-go' }, G.ico('chevron')) : null;
  const ev = cb ? { onmouseenter: () => { if (!it.active && !it.disabled) cb.hover(it.i); },
    onclick: (e) => { if (it.disabled) return; if (it.kind === 'list' || it.kind === 'slider') { const r = e.currentTarget.getBoundingClientRect(); cb.change(it.i, (e.clientX - r.left) < r.width / 2 ? -1 : 1); } else cb.select(it.i); } } : null;
  const defIc = it.kind === 'checkbox' ? 'power' : (it.kind === 'slider' || it.kind === 'list') ? 'sliders' : it.kind === 'input' ? 'edit' : 'chevron';
  return h('div', Object.assign({ class: 'rmn-r rm-r' + (it.active ? ' on' : '') + (it.disabled ? ' off' : '') + ((it.danger || it.icon === 'trash') ? ' bad' : ''), 'data-i': it.i }, ev || {}),
    h('span', { class: 'rmn-ic' }, G.ico(it.icon || defIc)), h('span', { class: 'rmn-l' }, String(it.label || '')),
    h('span', { class: 'rmn-rr' }, rt, bd, right, go));
}
function buildNova(t, snap, cb) {
  // même taille que la lib Shadow : 336 px de large (sur 342 de réglage), soit la maquette Nova (754) × 336/754
  // (v1.2.56) fond plus transparent : 72 % au plus, moins si le panel règle moins
  const hd = snap.head && typeof snap.head === 'object' ? snap.head : null;
  const el = h('div', { class: 'rm rmn pos-' + t.position + (cb ? ' ui' : '') + (hd ? ' rmn-pl' : ''), style: { '--k': (t.width / 342 * 336 / 380).toFixed(4), '--op': String(Math.min(0.72, t.opacity / 100)), '--bl': t.blur + 'px', '--ox': t.offset_x + 'px', '--oy': t.offset_y + 'px' } });
  const top = h('div', { class: 'rmn-box' });
  const tabs = Array.isArray(snap.tabs) ? snap.tabs : [];
  const rootTitle = String(snap.root || (snap.path && snap.path[0]) || snap.title || '');
  // en-tête : halo de la couleur du serveur derrière le logo, nom du serveur au-dessus du titre, pastilles (Discord, site…) en dessous
  const brand = G.cfg.brand || {};
  const glow = /^#[0-9a-f]{6}$/i.test(brand.color || '') ? G.hexToRgb(brand.color) : '255,255,255';
  // une seule pastille : le Discord du serveur (Menus › Discord en haut des menus ; vide = rien)
  const dc = String(t.discord == null ? '' : t.discord).trim().slice(0, 48);
  const chips = dc ? [h('span', { class: 'rmn-chip' }, G.ico('discord'), h('b', null, dc.toLowerCase()))] : [];
  const eyebrow = String(brand.name || t.banner_text || '').trim();
  top.appendChild(h('div', { class: 'rmn-head', style: { '--glow': glow } },
    h('i', { class: 'rmn-glow' }), h('i', { class: 'rmn-tex' }),
    novaLogo(t, snap), h('i', { class: 'rmn-div' }),
    hd ? h('span', { class: 'rmn-hx' }, h('small', { class: 'rmn-crumb' }, String(hd.crumb || '')), h('span', { class: 'rmn-t' }, String(hd.name || ''))) :
      h('span', { class: 'rmn-hx' }, eyebrow ? h('small', { class: 'rmn-crumb' }, eyebrow) : null, h('span', { class: 'rmn-t' }, rootTitle)),
    hd && hd.badge ? h('span', { class: 'rmn-id' }, String(hd.badge)) : null,
    tabs.length ? h('span', { class: 'rmn-tabs' }, tabs.map((tb, k) => h('span', { class: 'rmn-tab' + (k + 1 === (snap.tab || 1) ? ' on' : ''), title: tb.label }, G.ico(tb.icon || 'star')))) : null,
    cb ? h('button', { class: 'rmn-x', title: 'Fermer', onclick: () => cb.close() }, G.ico('close')) : null));
  const total = (snap.counter && snap.counter[1]) || 0, cur = (snap.counter && snap.counter[0]) || 0;
  top.appendChild(h('div', { class: 'rmn-sec' },
    (cb && snap.depth > 1) ? h('button', { class: 'rmn-back', title: 'Retour', onclick: () => cb.back() }, G.ico('chevron')) : null,
    // menu racine : le titre est déjà dans l'en-tête, la barre montre le sous-titre (grade, service…) ; sous-menu : son titre
    h('span', { class: 'rmn-st' }, String((snap.depth > 1 || !snap.subtitle || String(snap.title || '') !== rootTitle) ? (snap.title || '') : snap.subtitle),
      snap.subtitle && (snap.depth > 1 || String(snap.title || '') !== rootTitle) ? h('small', null, String(snap.subtitle)) : null),
    t.show_counter && total ? h('span', { class: 'rmn-n' }, h('b', null, String(cur)), ' / ' + total) : null));
  const list = h('div', { class: 'rmn-list rm-list' });
  (snap.items || []).forEach((it) => list.appendChild(rowNova(it, cb)));
  const wrap = h('div', { class: 'rmn-lw' }, list);
  if (!cb && total > 0 && (snap.up || snap.down)) {
    const vis = (snap.items || []).filter((x) => x.kind !== 'separator').length || 1;
    const hgt = Math.max(12, Math.min(100, vis / total * 100)), pos = total > 1 ? (cur - 1) / (total - 1) * (100 - hgt) : 0;
    wrap.appendChild(h('span', { class: 'rmn-sb' }, h('i', { style: { height: hgt + '%', top: pos + '%' } })));
  }
  top.appendChild(wrap);
  el.appendChild(top);
  if (t.show_desc && snap.desc) el.appendChild(h('div', { class: 'rmn-desc' }, ...novaBold(snap.desc)));
  if (!cb) {
    const key = (glyph) => h('kbd', { class: 'rmn-k' }, glyph);
    el.appendChild(h('div', { class: 'rmn-keys' },
      h('span', null, key('↑'), key('↓'), 'Parcourir'), h('span', null, key('↵'), 'Valider'), h('span', null, key('⌫'), 'Retour')));
  }
  return el;
}
// (v1.2.37) taille et place de la maquette : 380 px de large, en haut à gauche à 24 px des bords sur 1920 × 1080, à l'échelle de l'écran
function placeNova(m) {
  if (!m || !m.classList.contains('rmn')) return;
  const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080) || 1;
  m.classList.add('rmn-game');
  m.style.setProperty('--k', String(s));
  m.style.left = (24 * s) + 'px'; m.style.top = (24 * s) + 'px';
}

let banKey = '', banT0 = 0, banFresh = true;
function build(theme, snap, brandName, cb) {
  const t = themeOf(theme);
  snap = snap || {};
  // (v1.2.37) la lib n'a plus qu'un style : Shadow Studio V2 (anciennement « Nova »), quel que soit le réglage enregistré
  return buildNova(t, snap, cb);
  const ban = snap.banner || {};
  const name = (ban.text != null ? ban.text : (t.banner_text || brandName || 'MON SERVEUR'));
  const imgUrl = safeUrl(ban.image != null ? ban.image : t.banner_image);
  const mode = ban.mode || t.banner_mode;
  const flat = t.skin !== 'classic';
  const el = h('div', { class: 'rm pos-' + t.position + ' sel-' + t.selected_style + (flat ? ' skin-flat' : '') + (cb ? ' ui' : ''), style: {
    '--ac': t.accent, '--acr': G.hexToRgb(t.accent), '--bg': t.bg, '--bgr': G.hexToRgb(t.bg), '--bg2': t.bg2, '--bg2r': G.hexToRgb(t.bg2), '--tx': t.text, '--mu': t.muted,
    '--w': t.width + 'px', '--rd': t.radius + 'px', '--op': t.opacity / 100, '--bl': t.blur + 'px', '--rh': t.row_height + 'px', '--fs': t.font_scale / 100, '--bh': t.banner_height + 'px', '--ox': t.offset_x + 'px', '--oy': t.offset_y + 'px' } });

  if (t.banner_height > 0) {
    const bn = h('div', { class: 'rm-ban' + (mode === 'image' && imgUrl ? ' img' : '') + (mode === 'anim' ? ' anim' : '') });
    if (mode === 'anim') {
      // bannière animée : le W se dessine, puis le nom du menu ouvert apparaît. Le texte suit le menu (Menu admin, Menu police…) ; rien d'autre.
      const root0 = (snap.path && snap.path[0]) || snap.title || '';
      const raw = ban.text != null ? String(ban.text) : (t.banner_text ? String(t.banner_text) : String(root0 || brandName || 'Menu'));
      const raw2 = /^menu staff$/i.test(raw) ? 'Menu admin' : raw;
      const label = (/^menu\b/i.test(raw2) ? raw2 : 'Menu ' + raw2.charAt(0).toLowerCase() + raw2.slice(1)).slice(0, 32);
      const now = performance.now();
      if (label !== banKey || banFresh) { banKey = label; banT0 = now; banFresh = false; }
      bn.style.setProperty('--bt', (-(now - banT0)) + 'ms');          // reprend l'animation là où elle en était quand le menu se redessine
      if (G.season && G.season()) bn.classList.add('hw');
      const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 1024 1024'); svg.setAttribute('class', 'rm-wsvg');
      const mk = (cls) => { const e = document.createElementNS(NS, 'path'); e.setAttribute('d', G.WPATH || ''); e.setAttribute('class', cls); if (cls === 'rm-wp') e.setAttribute('pathLength', '1'); return e; };
      svg.appendChild(mk('rm-wf')); svg.appendChild(mk('rm-wp'));
      bn.appendChild(h('i', { class: 'rm-aur a1' })); bn.appendChild(h('i', { class: 'rm-aur a2' }));
      bn.appendChild(h('div', { class: 'rm-an' }, h('span', { class: 'rm-anw' }, svg), h('div', { class: 'rm-ant' }, h('b', null, label.toUpperCase()))));
      bn.appendChild(h('i', { class: 'rm-line' }));
    } else if (mode === 'image' && imgUrl) bn.style.backgroundImage = 'linear-gradient(180deg,rgba(0,0,0,.05),rgba(var(--bgr),.85)),url("' + imgUrl + '")';
    else {
      if (t.banner_band) bn.appendChild(h('i', { class: 'rm-band' }));
      const nm = String(name), room = t.width - ((Array.isArray(t.chips) && t.chips.filter(Boolean).length) ? 150 : 40);
      const lg = h('div', { class: 'rm-logo', style: { '--lf': Math.max(18, Math.min(t.banner_height * .46, room / Math.max(4, nm.length) / .5)) + 'px' } }, h('b', null, String(name).toUpperCase()), (ban.sub != null ? ban.sub : t.banner_sub) ? h('small', null, String(ban.sub != null ? ban.sub : t.banner_sub).toUpperCase()) : null);
      bn.appendChild(lg);
    }
    const logoUrl = safeUrl(ban.logo != null ? ban.logo : (t.banner_logo || (G.cfg.brand && G.cfg.brand.logo) || ''));
    if (flat && logoUrl && mode !== 'anim') { G.clear(bn); bn.classList.add('haslogo'); bn.appendChild(h('img', { class: 'rm-logoimg', src: logoUrl, alt: '' })); }
    const chips = (Array.isArray(t.chips) ? t.chips : []).filter(Boolean).slice(0, 3);
    if (chips.length && !flat) bn.appendChild(h('div', { class: 'rm-chips' }, chips.map(chip)));
    if (cb && flat) bn.appendChild(h('button', { class: 'rm-x', title: 'Fermer', onclick: () => cb.close() }, G.ico('close')));
    el.appendChild(bn);
  }
  const total = (snap.counter && snap.counter[1]) || 0, cur = (snap.counter && snap.counter[0]) || 0;
  const title = t.title_case === 'upper' ? String(snap.title || '').toUpperCase() : String(snap.title || '');
  if (flat) {
    el.appendChild(h('div', { class: 'rm-head' },
      (cb && snap.depth > 1) ? h('button', { class: 'rm-back', title: 'Retour', onclick: () => cb.back() }, G.ico('chevron')) : null,
      h('span', { class: 'rm-t' }, String(snap.title || '')), h('span', { class: 'rm-s' }, snap.subtitle ? String(snap.subtitle) : ''),
      t.show_counter && total ? h('span', { class: 'rm-n' }, cur + '/' + total) : null,
      (cb && cb.style) ? h('button', { class: 'rm-sw', title: 'Passer au menu à flèches', onclick: () => cb.style('lib') }, G.ico('refresh')) : null));
  } else {
    el.appendChild(h('div', { class: 'rm-head' }, h('span', { class: 'rm-t' }, title), t.show_counter && total ? h('span', { class: 'rm-n' }, cur + ' / ' + total) : null));
    if (t.show_progress && total) el.appendChild(h('div', { class: 'rm-pr' }, h('i', { style: { left: ((cur - 1) / total * 100) + '%', width: (100 / total) + '%' } })));
    if (snap.subtitle) el.appendChild(h('div', { class: 'rm-sub' }, h('span', null, String(snap.subtitle).toUpperCase()), h('hr')));
  }
  const list = h('div', { class: 'rm-list' });
  if (snap.up) list.appendChild(h('div', { class: 'rm-more up' }, G.ico('chevron')));
  (snap.items || []).forEach((it, i) => list.appendChild(row(it, cb)));
  if (snap.down) list.appendChild(h('div', { class: 'rm-more dn' }, G.ico('chevron')));
  el.appendChild(list);
  if (t.show_desc && snap.desc) el.appendChild(h('div', { class: 'rm-desc' }, String(snap.desc)));
  return el;
}

function row(it, cb) {
  if (it.kind === 'separator') return h('div', { class: 'rm-sep' }, h('span', null, String(it.label || '')));
  const cls = 'rm-r' + (it.active ? ' on' : '') + (it.disabled ? ' off' : '');
  let right;
  if (it.kind === 'list') right = h('span', { class: 'rm-val' }, it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, -1); } : null }, '‹') : null, String(it.value || ''), it.active ? h('em', { onclick: cb ? (e) => { e.stopPropagation(); cb.change(it.i, 1); } : null }, '›') : null);
  else if (it.kind === 'checkbox') right = h('span', { class: 'rm-chk' + (it.checked ? ' on' : '') }, h('i'));
  else if (it.kind === 'slider') { const p = it.max > it.min ? (it.value - it.min) / (it.max - it.min) * 100 : 0; right = h('span', { class: 'rm-sl' }, h('i', { style: { width: p + '%' } }), h('b', null, String(it.value))); }
  else if (it.kind === 'input') right = h('span', { class: 'rm-val' }, String(it.value || '…'));
  else right = null;
  const ev = cb ? { onmouseenter: () => { if (!it.active && !it.disabled) cb.hover(it.i); },
    onclick: (e) => { if (it.disabled) return; if (it.kind === 'list' || it.kind === 'slider') { const r = e.currentTarget.getBoundingClientRect(); cb.change(it.i, (e.clientX - r.left) < r.width / 2 ? -1 : 1); } else cb.select(it.i); } } : null;
  return h('div', Object.assign({ class: cls, 'data-i': it.i }, ev || {}), h('span', { class: 'rm-l' }, String(it.label || '')),
    it.right ? h('span', { class: 'rm-rt' }, String(it.right)) : null,
    it.badge ? h('span', { class: 'rm-bd' }, String(it.badge), h('i')) : null,
    right, (it.kind === 'button' || it.kind === 'submenu' || it.kind === 'list' && false) ? h('span', { class: 'rm-ic' }, G.ico(it.icon || 'chevron')) : null);
}
// Position / taille / opacité du menu staff réglées dans le panel (Interface > Menu de la librairie admin) : x et y sont le centre, en % de l'écran.
// x = milieu du menu, y = HAUT de la bannière (le haut reste fixe quand la liste s'allonge ou se raccourcit), en % de l'écran.
function staffTheme(theme, layIn, vw, vh) {
  const lay = layIn || (G.cfg && G.cfg.staffmenu);
  vw = vw || window.innerWidth; vh = vh || window.innerHeight;
  if (!lay || typeof lay !== 'object') return theme;
  const t = Object.assign({}, DEFAULTS, theme || {}), sc = num(lay.scale, 1, 0.6, 1.6);
  t.position = 'center';
  t.offset_x = Math.round((num(lay.x, 50, 0, 100) - 50) / 100 * vw);
  t.offset_y = Math.round((num(lay.y, 12, 0, 100) - 50) / 100 * vh);
  t.font_scale = num(t.font_scale, 100, 70, 160) * sc; t.width = num(t.width, 440, 280, 640) * sc; t.row_height = num(t.row_height, 44, 32, 72) * sc;
  t.opacity = Math.max(30, Math.round(num(t.opacity, 96, 40, 100) * num(lay.opacity, 1, 0.3, 1)));
  return t;
}
G.rmenu = { build, themeOf, DEFAULTS, staffTheme, placeShadow, placeNova, restartBanner() { banFresh = true; } };

// ---- saisie d'un menu (motif, montant, nom…) : même fenêtre que Bannir, à côté du menu ; Ctrl+V fonctionne
let askEl = null, askKeys = null;
function askClose() { if (askEl) { askEl.remove(); askEl = null; } if (askKeys) { window.removeEventListener('keydown', askKeys, true); askKeys = null; } }
G.on('menuask.close', askClose);
G.on('menuask.open', (d) => {
  askClose();
  const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080) || 1;
  const inp = h('input', { class: 'rban-in', type: 'text', value: String(d.value || ''), maxlength: String(d.maxlen || 120) });
  const done = (txt) => { askClose(); G.post('umenu.asked', { text: txt }); };
  askEl = h('div', { class: 'rban ask', style: { '--k': String(s) } },
    h('div', { class: 'rban-t' }, String(d.prompt || 'Saisie')), inp,
    h('div', { class: 'rban-b' }, h('button', { type: 'button', class: 'ok', onclick: () => done(inp.value) }, 'Valider'), h('button', { type: 'button', class: 'no', onclick: () => done(null) }, 'Annuler')));
  const m = document.querySelector('#g-umenu .rmn, #g-rmenu .rmn');
  const r = m ? m.getBoundingClientRect() : { right: 400 * s, top: 200 * s, height: 300 * s };
  askEl.style.left = (r.right + 46 * s) + 'px';
  askEl.style.top = (r.top + r.height * 0.28) + 'px';
  G.root.appendChild(askEl);
  askKeys = (e) => {
    e.stopPropagation();
    if (e.key === 'Escape') { e.preventDefault(); done(null); } else if (e.key === 'Enter') { e.preventDefault(); done(inp.value); }
  };
  window.addEventListener('keydown', askKeys, true);
  setTimeout(() => { inp.focus(); inp.select(); }, 30);
});

// ---- fenêtre « Bannir » à côté du menu : motif, durée, confirmer en rouge. Texte inséré avec textContent par G.h.
let banEl = null, banKeys = null;
function banClose() { if (banEl) { banEl.remove(); banEl = null; } if (banKeys) { window.removeEventListener('keydown', banKeys, true); banKeys = null; } }
G.on('staffban.close', banClose);
G.on('staffban.open', (d) => {
  banClose();
  const durs = Array.isArray(d.durs) ? d.durs.map(String) : [];
  if (!durs.length) return;
  let at = Math.max(0, Math.min(durs.length - 1, (Number(d.def) || 1) - 1));
  const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080) || 1;
  const val = h('b', null, durs[at]);
  const turn = (dir) => { at = (at + dir + durs.length) % durs.length; val.textContent = durs[at]; };
  const inp = h('input', { class: 'rban-in', type: 'text', maxlength: '120', placeholder: 'Ex. Freekill, Insultes…' });
  const done = (r) => { banClose(); G.post('staffban.done', r || {}); };
  const go = () => {
    const reason = inp.value.trim();
    if (!reason) { inp.classList.add('err'); inp.focus(); return; }
    done({ ok: true, reason, duration: durs[at] });
  };
  banEl = h('div', { class: 'rban', style: { '--k': String(s) } },
    h('div', { class: 'rban-t' }, 'Bannir ' + String(d.name || '') + ' ?'),
    h('label', { class: 'rban-l' }, 'Raison'), inp,
    h('label', { class: 'rban-l' }, 'Durée'),
    h('div', { class: 'rban-d' }, h('button', { type: 'button', onclick: () => turn(-1) }, '‹'), val, h('button', { type: 'button', onclick: () => turn(1) }, '›')),
    h('div', { class: 'rban-b' }, h('button', { type: 'button', class: 'yes', onclick: go }, 'Confirmer'), h('button', { type: 'button', class: 'no', onclick: () => done() }, 'Annuler')));
  // à droite du menu ouvert, à mi-hauteur
  const m = document.querySelector('#g-umenu .rmn, #g-rmenu .rmn');
  const r = m ? m.getBoundingClientRect() : { right: 400 * s, top: 200 * s, height: 300 * s };
  banEl.style.left = (r.right + 46 * s) + 'px';
  banEl.style.top = (r.top + r.height * 0.28) + 'px';
  G.root.appendChild(banEl);
  // les touches restent dans cette fenêtre : le menu derrière ne bouge pas
  banKeys = (e) => {
    e.stopPropagation();
    if (e.key === 'Escape') { e.preventDefault(); done(); }
    else if (e.key === 'Enter') { e.preventDefault(); go(); }
    else if (e.target !== inp && e.key === 'ArrowLeft') { e.preventDefault(); turn(-1); }
    else if (e.target !== inp && e.key === 'ArrowRight') { e.preventDefault(); turn(1); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (document.activeElement === inp) inp.blur(); else inp.focus(); }
  };
  window.addEventListener('keydown', banKeys, true);
  setTimeout(() => inp.focus(), 30);
});

// ---- en jeu : la bibliothèque Lua envoie l'état à afficher, les touches sont lues côté Lua (pas de focus souris)
let host = null;
const box = () => host || (host = (function () { const e = h('div', { id: 'g-rmenu', class: 'hidden' }); G.root.appendChild(e); return e; })());
function draw(d, fresh) {
  const b = box(); G.clear(b);
  const m = build(d.staff ? staffTheme(d.theme || G.cfg.menus) : (d.theme || G.cfg.menus), d.menu, (G.cfg.brand && G.cfg.brand.name) || '');
  if (!fresh) m.classList.add('still');
  placeShadow(m); placeNova(m);
  b.appendChild(m);
}
let lastDraw = null;
G.on('rmenu.open', (d) => { banFresh = true; lastDraw = d; box().classList.remove('hidden'); draw(d, true); });
G.on('rmenu.render', (d) => { if (host && !host.classList.contains('hidden')) { lastDraw = d; draw(d); } });
// logo du serveur reçu ou changé (image arrivée après l'ouverture, nouveau logo dans le panel) : le menu ouvert se redessine
G.on('cfg', () => { if (host && !host.classList.contains('hidden') && lastDraw) draw(lastDraw); });
G.on('rmenu.close', () => { lastDraw = null; if (host) { G.clear(host); host.classList.add('hidden'); } });

// ---- aperçu du panel : même rendu, flèches / clic pour naviguer
G.preview.rmenu = function (host2, cfg, opts) {
  G.clear(host2);
  opts = opts || {};
  const items = opts.items || [
    { label: 'Mon Inventaire', desc: "Ouvre ton inventaire.", icon: 'bag' }, { label: 'Mon Espace', desc: 'Finances, factures, entreprise.', icon: 'briefcase' }, { label: 'Mon Portefeuille', desc: 'Espèces, banque et factures.', icon: 'card' },
    { label: 'Status des Entreprises', desc: 'Emploi, grade, service et caisse.', icon: 'building' }, { label: 'Mon VIP', badge: 'GOLD', desc: 'Avantages de ton abonnement.', icon: 'crown' }, { label: 'Mes Animaux', desc: 'Gère tes compagnons.', icon: 'paw' },
    { label: 'Accéder aux zone GunFight', desc: 'Permet de rentrer en zone GF.', icon: 'bolt' }, { label: 'Mes Paramètres', desc: 'Préférences personnelles.', icon: 'sliders' }];
  const title = opts.menuTitle || 'Voici votre menu personnel', subtitle = opts.subtitle || 'Votre ID est : 1 | Votre unique ID est : 1';
  let sel = opts.sel != null ? opts.sel : 6;
  const wrap = h('div', { class: 'rm-stage', tabindex: '0' });
  let render = function () {
    G.clear(wrap);
    const snap = { banner: { text: opts.bannerText || 'Menu personnel' }, title, subtitle, items: items.map((it, i) => Object.assign({ kind: 'button' }, it, { active: i === sel })), counter: [sel + 1, items.length], desc: items[sel].desc };
    const m = build(cfg, snap, (opts.brand || (G.cfg.brand && G.cfg.brand.name) || 'Shadow Base'));
    m.classList.add('static'); wrap.appendChild(m);
    m.querySelectorAll('.rm-r').forEach((r, i) => r.addEventListener('click', () => { sel = i; render(); }));
  };
  wrap.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { sel = (sel + 1) % items.length; render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = (sel + items.length - 1) % items.length; render(); e.preventDefault(); }
  });
  const stage = h('div', { class: 'gstage auto' }, wrap);
  // aperçu en entier même sur téléphone : le menu est réduit pour tenir dans la largeur disponible
  function fit() {
    const m = wrap.firstChild; if (!m) return;
    wrap.style.transform = ''; wrap.style.marginBottom = '';
    const avail = stage.clientWidth - 8, need = m.offsetWidth + 24;
    const k = need > avail && avail > 0 ? avail / need : 1;
    wrap.style.transformOrigin = 'top center'; wrap.style.transform = k < 1 ? 'scale(' + k + ')' : '';
    wrap.style.marginBottom = k < 1 ? (-(wrap.offsetHeight) * (1 - k)) + 'px' : '';
  }
  render(); host2.appendChild(stage);
  requestAnimationFrame(fit); if (window.ResizeObserver) new ResizeObserver(fit).observe(stage);
  const r0 = render; render = function () { r0(); fit(); };
};
G.preview.quick = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu police', menuTitle: 'Actions rapides', subtitle: 'Police · Officier · En service', sel: 2, items: [
    { kind: 'separator', label: 'Police · Officier' }, { label: 'Cible', kind: 'list', value: 'Alex Martin (#12)', desc: 'Joueur proche sur lequel agiront les actions ci-dessous.' },
    { label: 'En service', kind: 'checkbox', checked: true, desc: 'Prends ou quitte ton service.' }, { label: 'Menotter', icon: 'lock', desc: 'Menotte la personne ciblée, tout près de toi.' },
    { label: 'Fouiller', icon: 'search', desc: 'Fouille une personne menottée.' }, { label: 'Amende', kind: 'submenu', icon: 'tag', desc: "Choisis l'infraction du catalogue." },
    { label: 'Facturer', icon: 'card', desc: 'Envoie une facture à la personne ciblée.' }, { kind: 'separator', label: "Gestion de l'entreprise" },
    { label: 'Tableau de bord', icon: 'home', right: '›', desc: 'Grade, service, paie, statistiques du jour.' }, { label: 'Citoyens', icon: 'users', right: '›', desc: 'Amendes, notes et dossiers récents.' },
    { label: 'Factures émises', icon: 'file', right: '›' }, { label: 'Équipe', icon: 'users', right: '›' }, { label: 'Annonces', icon: 'chat', right: '›' }] });
};
// Menu F7 d'une organisation : actions puis toutes les pages de gestion (plus de tablette)
G.preview.orga = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Ballas', menuTitle: 'Organisation', subtitle: 'Chef', sel: 2, items: [
    { kind: 'separator', label: 'Ballas · Chef' }, { kind: 'separator', label: 'Sur une personne' }, { label: 'Ligoter', kind: 'submenu', icon: 'lock', desc: 'Attache les mains de la personne choisie.' },
    { label: 'Fouiller', kind: 'submenu', icon: 'search' }, { kind: 'separator', label: 'Organisation' }, { label: 'GPS : notre QG', icon: 'gps' }, { label: 'Verser à la caisse commune', icon: 'coins' },
    { kind: 'separator', label: "Gestion de l'organisation" }, { label: 'Crypto', icon: 'coins', right: '›', desc: 'Cours, achat et vente de jetons.' }, { label: 'Leaderboard', icon: 'chart', right: '›' },
    { label: 'Territoires', icon: 'pin', right: '›' }, { label: 'Contrats', icon: 'alert', right: '›' }, { label: 'Messages', icon: 'chat', right: '›' }] });
};
G.preview.staff = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu admin', menuTitle: 'Menu staff', subtitle: 'Administrateur · en service', sel: 3, items: [
    { kind: 'separator', label: 'Administrateur · en service' }, { label: 'Prendre mon service', kind: 'checkbox', checked: true, icon: 'bolt', desc: 'Obligatoire pour utiliser les outils.' },
    { label: 'Gestion des joueurs (12)', kind: 'submenu', icon: 'users', desc: 'Infos, téléportation, soins, argent, sanctions.' }, { label: 'Gestion personnelle', kind: 'submenu', icon: 'bolt', desc: 'Noclip, invincibilité, invisibilité, noms.' },
    { label: 'Gestion des véhicules', kind: 'submenu', icon: 'engine', desc: 'Créer, réparer, supprimer.' }, { label: 'Gestion du serveur', kind: 'submenu', icon: 'globe', desc: 'Annonces, météo, heure, maintenance.' },
    { label: 'Gestion des reports (2)', kind: 'submenu', icon: 'help', desc: 'Les demandes des joueurs.' }, { label: 'Gestion des sanctions', kind: 'submenu', icon: 'shield', desc: 'Lever un bannissement.' },
    { label: 'Options supplémentaires', icon: 'sliders', desc: 'Ouvre le panel de configuration (propriétaire).' }, { label: 'Réorganiser ce menu', kind: 'submenu', icon: 'sliders', desc: 'Change l\'ordre des entrées.' }] });
};
G.preview.fuel = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu station', menuTitle: 'Station Mirror Park', subtitle: '3 $ le litre · il manque 41 L', sel: 1, items: [
    { label: 'Un peu — 10 L', right: '≈ 30 $', desc: 'Ajoute 10 litres.' }, { label: 'Moyen — 25 L', right: '≈ 75 $' }, { label: 'Faire le plein — 41 L', right: '≈ 123 $' }] });
};
G.preview.mech = function (box, cfg) {
  G.preview.rmenu(box, cfg, { bannerText: 'Menu atelier', menuTitle: 'Atelier', subtitle: 'PB 4821', sel: 2, items: [
    { kind: 'separator', label: 'Garage Benny · caisse 18 400 $' }, { label: 'Réparation complète', right: '150 $', desc: 'Carrosserie, moteur, pneus et propreté.' }, { label: 'Moteur', kind: 'submenu' }, { label: 'Freins', kind: 'submenu' },
    { label: 'Transmission', kind: 'submenu' }, { label: 'Suspension', kind: 'submenu' }, { label: 'Blindage', kind: 'submenu' }, { label: 'Turbo', kind: 'submenu' }, { label: 'Vitres teintées', kind: 'submenu' }, { label: 'Peinture', kind: 'submenu' }] });
};
})();
