/* Écran de chargement entre le loading screen et l'écran d'entrée (client/loading.lua) : logo du serveur, lumière qui file, sur fond noir.
   Affiché dès le chargement de la page, en jeu seulement. Le logo et la couleur sont gardés sur le poste : la configuration du serveur
   n'arrive qu'à la fin de la connexion. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, guard = null, bar = null, step = null, pct = null;
const read = (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* rien */ } };

// (v1.2.59) écran sobre : logo, nom, étape et pourcentage. Pas de décor, pas d'effet : du noir, du texte, une ligne qui avance.
function show(d) {
  if (el) return;
  const logo = read('pb_boot_logo'), rgb = read('pb_boot_rgb');
  bar = h('i'); step = h('small', null, d && d.name ? 'Arrivée à Los Santos' : 'Connexion à la ville');
  pct = h('span', { class: 'gb-pct' }, '');
  el = h('div', { id: 'g-boot', class: 'gb-new' + (d && d.pct ? ' sure' : ''), style: rgb ? { '--sv-rgb': rgb, '--sv': 'rgb(' + rgb + ')' } : {} },
    logo ? h('img', { src: logo, alt: '' }) : null,
    h('div', { class: 'gb-low' }, h('div', { class: 'gb-txt' }, d && d.name ? h('b', null, String(d.name)) : null, step), pct),
    h('div', { class: 'gb-bar' }, bar));
  document.body.appendChild(el);
}
function hide() {
  clearTimeout(guard); guard = null;
  if (!el) return;
  const e = el; el = null;
  e.classList.add('bye');
  setTimeout(() => e.remove(), 600);
}
G.on('boot.show', show);
G.on('arrive.open', (d) => { if (el) { el.remove(); el = null; } show({ name: (d && d.name) || '', pct: true }); clearTimeout(guard); guard = setTimeout(hide, 45000); });
G.on('arrive.step', (d) => { if (!el) return; const v = Math.max(0, Math.min(100, Math.round(Number(d.pct) || 0))); if (bar) bar.style.width = v + '%'; if (pct) pct.textContent = v + ' %'; if (step && d.text) step.textContent = String(d.text); });
G.on('arrive.done', hide);
G.on('boot.done', hide);
G.on('boot.ping', () => { clearTimeout(guard); guard = setTimeout(hide, 90000); });   // sécurité si le jeu ne répond plus
G.on('cfg', () => {
  const b = G.cfg && G.cfg.brand;
  if (b && b.logo && G.logoUrl) save('pb_boot_logo', G.logoUrl());
  const rgb = getComputedStyle(document.body).getPropertyValue('--sv-rgb').trim();
  if (rgb) save('pb_boot_rgb', rgb);
});
if (typeof window.GetParentResourceName === 'function') show();
})();
