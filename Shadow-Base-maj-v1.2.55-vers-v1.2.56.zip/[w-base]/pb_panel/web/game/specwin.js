/* Mini-écrans du staff : une fenêtre par joueur observé (image renouvelée toutes les ~2 s), à déplacer et redimensionner.
   Hors mode placement, les fenêtres ne prennent pas la souris : on continue de jouer. /ecrans active le mode placement. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const KEY = 'pb_specwin';
const wins = new Map();
let host = null, edit = false, tip = null;
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } };
const save = (s) => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* stockage indisponible */ } };
function box() {
  if (!host) { host = h('div', { id: 'g-specwin' }); G.root.appendChild(host); }
  return host;
}
function slotOf() { for (let i = 0; i < 8; i++) { if (![...wins.values()].some((w) => w.slot === i)) return i; } return 0; }
function place(w) {
  const s = load()[w.slot];
  const vw = window.innerWidth, vh = window.innerHeight, def = Math.round(vw * 0.2);
  w.w = s && s.w ? s.w : def;
  w.x = s && s.x != null ? s.x : vw - def - 20 - (w.slot % 3) * (def + 12);
  w.y = s && s.y != null ? s.y : 20 + Math.floor(w.slot / 3) * (def * 0.6 + 12);
  apply(w);
}
function apply(w) {
  const vw = window.innerWidth, vh = window.innerHeight;
  w.w = Math.max(200, Math.min(vw * 0.8, w.w));
  w.x = Math.max(0, Math.min(vw - w.w, w.x));
  w.y = Math.max(0, Math.min(vh - 60, w.y));
  w.el.style.width = w.w + 'px'; w.el.style.left = w.x + 'px'; w.el.style.top = w.y + 'px';
}
function persist(w) { const s = load(); s[w.slot] = { x: Math.round(w.x), y: Math.round(w.y), w: Math.round(w.w) }; save(s); }
function drop(id) { const w = wins.get(id); if (!w) return; w.el.remove(); wins.delete(id); if (!wins.size && edit) G.post('specwin.editoff', {}); }
function make(d) {
  const img = h('img', { alt: '' }), name = h('span', { class: 'sw-n' }, String(d.name || ''));
  const close = h('button', { class: 'sw-x', title: 'Fermer', onclick: () => { G.post('specwin.close', { id: d.id }); drop(d.id); } }, G.ico('x'));
  const grip = h('i', { class: 'sw-g' });
  const el = h('div', { class: 'sw' }, h('div', { class: 'sw-t' }, h('b', { class: 'sw-dot' }), name, close), h('div', { class: 'sw-i' }, img, h('small', { class: 'sw-w' }, 'En attente de l\'image…')), grip);
  const w = { id: d.id, el, img, name, slot: slotOf() };
  wins.set(d.id, w);
  box().appendChild(el);
  place(w);
  // déplacer par la barre, redimensionner par le coin
  el.querySelector('.sw-t').addEventListener('mousedown', (e) => {
    if (!edit || e.target.closest('.sw-x')) return;
    e.preventDefault();
    const ox = e.clientX - w.x, oy = e.clientY - w.y;
    const mv = (ev) => { w.x = ev.clientX - ox; w.y = ev.clientY - oy; apply(w); };
    const end = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', end); persist(w); };
    window.addEventListener('mousemove', mv); window.addEventListener('mouseup', end);
  });
  grip.addEventListener('mousedown', (e) => {
    if (!edit) return;
    e.preventDefault(); e.stopPropagation();
    const sx = e.clientX, sw = w.w;
    const mv = (ev) => { w.w = sw + ev.clientX - sx; apply(w); };
    const end = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', end); persist(w); };
    window.addEventListener('mousemove', mv); window.addEventListener('mouseup', end);
  });
  return w;
}
G.on('specwin.frame', (d) => {
  const img = String(d.img || '');
  if (!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(img)) return;
  const w = wins.get(d.id) || make(d);
  w.name.textContent = String(d.name || '');
  w.img.src = img;
  const wait = w.el.querySelector('.sw-w'); if (wait) wait.remove();
});
G.on('specwin.open', (d) => { if (!wins.get(d.id)) make(d); });
G.on('specwin.stop', (d) => drop(d.id));
G.on('specwin.clear', () => { [...wins.keys()].forEach(drop); });
G.on('specwin.edit', (d) => {
  edit = !!d.on;
  box().classList.toggle('edit', edit);
  if (tip) { tip.remove(); tip = null; }
  if (edit) { tip = h('div', { class: 'sw-tip' }, 'Glisse la barre pour déplacer, le coin pour la taille. ', h('kbd', null, 'Échap'), ' terminer'); box().appendChild(tip); }
});
document.addEventListener('keydown', (e) => { if (edit && e.key === 'Escape') G.post('specwin.editoff', {}); });
})();
