/* Mini-jeu du crochet : relier chaque fil à sa borne de la même couleur, avant la fin du temps. Le résultat part au jeu (wires.done),
   le serveur ne déverrouille qu'après une durée crédible. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const NS = 'http://www.w3.org/2000/svg';
let cur = null;
const svgEl = (tag, attrs) => { const e = document.createElementNS(NS, tag); Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v)); return e; };
function close(ok, cancelled) {
  if (!cur) return;
  clearInterval(cur.timer);
  window.removeEventListener('keydown', cur.keys, true);
  window.removeEventListener('mousemove', cur.move);
  window.removeEventListener('mouseup', cur.up);
  const el = cur.el; cur = null;
  el.classList.add(ok ? 'won' : 'lost');
  setTimeout(() => el.remove(), 450);
  G.post('wires.done', { ok: !!ok, cancelled: !!cancelled });
}
G.on('wires.close', () => { if (cur) { const e = cur; cur = null; clearInterval(e.timer); window.removeEventListener('keydown', e.keys, true); window.removeEventListener('mousemove', e.move); window.removeEventListener('mouseup', e.up); e.el.remove(); } });
G.on('wires.open', (d) => {
  if (cur) return;
  const COLORS = ['var(--sv,#7c3cff)', '#ee6565', '#4fd1ff', '#ffc857', '#6fe3a5', '#ff7ad9'];
  const n = Math.max(3, Math.min(6, Number(d.n) || 4)), total = Math.max(5, Number(d.secs) || 14) * 1000;
  const W = 520, H = 340, top = 34, gap = (H - top * 2) / (n - 1);
  const order = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  if (order.every((v, i) => v === i)) { order.push(order.shift()); }
  const svg = svgEl('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'wg-b' });
  const wires = [], ends = [];
  for (let i = 0; i < n; i++) {
    const y = top + i * gap, ry = top + order.indexOf(i) * gap, col = COLORS[i];
    const line = svgEl('path', { class: 'wg-l', d: '', style: 'stroke:' + col });
    svg.appendChild(line);
    svg.appendChild(svgEl('rect', { x: 0, y: y - 11, width: 42, height: 22, rx: 4, style: 'fill:' + col }));
    const start = svgEl('circle', { cx: 52, cy: y, r: 13, class: 'wg-s', style: 'fill:' + col, 'data-i': i });
    svg.appendChild(start);
    svg.appendChild(svgEl('rect', { x: W - 42, y: ry - 11, width: 42, height: 22, rx: 4, style: 'fill:' + col }));
    const end = svgEl('circle', { cx: W - 52, cy: ry, r: 13, class: 'wg-e', style: 'stroke:' + col, 'data-i': i });
    svg.appendChild(end);
    wires[i] = { y, ry, line, start, done: false };
    ends[i] = end;
  }
  const bar = h('i');
  const left = h('b', null, '');
  const el = h('div', { id: 'g-wires' }, h('div', { class: 'wg' },
    h('div', { class: 'wg-h' }, h('div', null, h('small', null, 'Serrure forcée'), h('strong', null, 'Relie les fils')), left),
    h('div', { class: 'wg-t' }, bar), svg,
    h('div', { class: 'wg-f' }, 'Glisse chaque fil jusqu\'à la borne de sa couleur', h('span', null, h('kbd', null, 'Échap'), ' abandonner'))));
  G.root.appendChild(el);
  const curve = (x1, y1, x2, y2) => 'M' + x1 + ' ' + y1 + ' C' + (x1 + 120) + ' ' + y1 + ' ' + (x2 - 120) + ' ' + y2 + ' ' + x2 + ' ' + y2;
  const toSvg = (e) => { const r = svg.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * W, y: (e.clientY - r.top) / r.height * H }; };
  let drag = null, deadline = Date.now() + total;
  const penal = () => { deadline -= 1500; el.firstChild.classList.remove('shake'); void el.firstChild.offsetWidth; el.firstChild.classList.add('shake'); if (G.click) G.click(); };
  svg.addEventListener('mousedown', (e) => {
    const i = e.target.getAttribute && e.target.getAttribute('data-i');
    if (i == null || !e.target.classList.contains('wg-s')) return;
    if (wires[+i].done) return;
    drag = +i; e.preventDefault();
  });
  const move = (e) => { if (drag == null) return; const p = toSvg(e), w = wires[drag]; w.line.setAttribute('d', curve(52, w.y, p.x, p.y)); };
  const up = (e) => {
    if (drag == null) return;
    const i = drag, w = wires[i], p = toSvg(e); drag = null;
    let hit = -1;
    ends.forEach((c, k) => { if (Math.hypot(p.x - (W - 52), p.y - wires[k].ry) < 24) hit = k; });
    if (hit === i) {
      w.done = true; w.line.setAttribute('d', curve(52, w.y, W - 52, w.ry)); w.line.classList.add('done'); ends[i].classList.add('done');
      if (G.click) G.click();
      if (wires.every((x) => x.done)) close(true);
    } else {
      w.line.setAttribute('d', '');
      if (hit >= 0) penal();
    }
  };
  const keys = (e) => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); close(false, true); } };
  const timer = setInterval(() => {
    const leftMs = deadline - Date.now();
    bar.style.width = Math.max(0, leftMs / total * 100) + '%';
    left.textContent = Math.max(0, Math.ceil(leftMs / 1000)) + ' s';
    el.firstChild.classList.toggle('late', leftMs < 4000);
    if (leftMs <= 0) close(false);
  }, 100);
  window.addEventListener('mousemove', move);
  window.addEventListener('mouseup', up);
  window.addEventListener('keydown', keys, true);
  cur = { el, timer, keys, move, up };
});
})();
