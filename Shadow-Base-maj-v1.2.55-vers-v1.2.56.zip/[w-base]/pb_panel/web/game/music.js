/* Mini CarPlay (boombox en main, musique du véhicule) et lecteurs audio.
   Jeu → NUI : music.open { mode, label, stations, vol } ; music.state { cur } ; music.close ; music.sync { list: [{ k, kind, id, url, start, vol }] }.
   NUI → jeu : music.play { station | url } ; music.stop ; music.vol { v } ; music.typing { on } ; music.close ; music.holster.
   Le serveur valide tout : les adresses reçues ici viennent de lui (radios du réglage, identifiants de vidéo vérifiés). Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
const KEY = 'pb_music_recent';
let el = null, st = null, tab = 'now', clockT = null;

function recents() { try { return JSON.parse(localStorage.getItem(KEY) || '[]') || []; } catch (e) { return []; } }
function saveRecents(l) { try { localStorage.setItem(KEY, JSON.stringify(l.slice(0, 8))); } catch (e) { /* stockage indisponible */ } }
function remember(url) { if (url) saveRecents([{ url, title: '' }].concat(recents().filter((r) => r.url !== url))); }
function titleRecents(cur) {   // le titre arrive du serveur après coup : on le garde pour la liste
  if (!cur || !cur.id || !cur.title) return;
  const l = recents(); let ch = false;
  l.forEach((r) => { if (!r.title && r.url.indexOf(cur.id) >= 0) { r.title = cur.title; ch = true; } });
  if (ch) saveRecents(l);
}
const initials = (s) => String(s || '?').replace(/[^\p{L}\p{N} ]/gu, '').split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '♪';

function vol() {
  const i = h('input', { type: 'range', min: 0, max: 100, value: st.vol });
  i.addEventListener('input', () => { st.vol = Number(i.value); G.post('music.vol', { v: st.vol }); });
  return h('div', { class: 'mu-vol', title: 'Mon volume' }, ico('volume'), i);
}
function viewNow() {
  const c = st.cur;
  if (!c) return h('div', { class: 'mu-empty' }, h('div', null, 'Rien pour le moment.'),
    h('button', { class: 'mu-btn pri', onclick: () => go('radio') }, 'Choisir une radio'), h('div', { class: 'mu-ctl', style: { width: '260px' } }, vol()));
  const art = h('div', { class: 'mu-art' });
  if (c.kind === 'yt') art.style.backgroundImage = 'url("https://i.ytimg.com/vi/' + encodeURIComponent(c.id) + '/mqdefault.jpg")';
  else art.textContent = initials(c.title);
  return h('div', { class: 'mu-now' }, art,
    h('div', { class: 'mu-info' },
      h('div', { class: 'mu-tag' }, h('span', { class: 'mu-eq' }, h('i'), h('i'), h('i')), c.kind === 'stream' ? 'Radio en direct' : 'Lecture'),
      h('div', { class: 'mu-title' }, c.title || 'Chargement du titre…'),
      h('div', { class: 'mu-by' }, c.by ? 'Mis par ' + c.by : ''),
      h('div', { class: 'mu-ctl' }, vol(), h('button', { class: 'mu-btn', onclick: () => G.post('music.stop', {}) }, 'Couper'))));
}
function viewRadio() {
  const grid = h('div', { class: 'mu-grid' });
  (st.stations || []).forEach((s) => {
    const on = st.cur && st.cur.kind === 'stream' && st.cur.title === s.n;
    grid.appendChild(h('button', { class: 'mu-st' + (on ? ' on' : ''), onclick: () => G.post('music.play', { station: s.i }) }, h('i', null, initials(s.n)), h('span', null, s.n)));
  });
  if (!grid.childElementCount) return h('div', { class: 'mu-empty' }, 'Aucune radio configurée.');
  return grid;
}
function viewLink() {
  const err = h('div', { class: 'mu-err' });
  const i = h('input', { type: 'text', maxlength: 300, placeholder: 'https://www.youtube.com/watch?v=…', spellcheck: 'false' });
  const send = () => {
    const url = i.value.trim();
    if (!/^https:\/\//.test(url)) { err.textContent = 'Colle un lien complet qui commence par https://'; return; }
    err.textContent = ''; remember(url); G.post('music.play', { url }); i.value = ''; i.blur(); go('now');
  };
  i.addEventListener('focus', () => G.post('music.typing', { on: true }));
  i.addEventListener('blur', () => G.post('music.typing', { on: false }));
  i.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') send(); else if (e.key === 'Escape') i.blur(); });
  setTimeout(() => { if (i.isConnected) i.focus(); }, 60);
  return h('div', { class: 'mu-link' }, h('p', null, 'Colle un lien YouTube ou Vimeo avec Ctrl + V, puis Entrée.'),
    h('div', { class: 'mu-field' }, i, h('button', { class: 'mu-btn pri', onclick: send }, 'Lancer')), err);
}
function viewRecent() {
  const l = recents();
  if (!l.length) return h('div', { class: 'mu-empty' }, 'Les liens que tu lances apparaîtront ici.');
  const box = h('div', { class: 'mu-rec' });
  l.forEach((r) => box.appendChild(h('button', { class: 'mu-st', onclick: () => { G.post('music.play', { url: r.url }); go('now'); } }, h('i', null, initials(r.title || 'Lien')), h('span', null, r.title || r.url))));
  return box;
}
const TABS = [{ id: 'now', icon: 'music', label: 'En cours', view: viewNow }, { id: 'radio', icon: 'radio', label: 'Radios', view: viewRadio },
  { id: 'link', icon: 'link', label: 'Lien', view: viewLink }, { id: 'recent', icon: 'clock', label: 'Récents', view: viewRecent }];
function go(id) { tab = id; draw(); }
function draw() {
  if (!el || !st) return;
  G.clear(el);
  const t = TABS.find((x) => x.id === tab) || TABS[0];
  const clock = h('div', { class: 'mu-clock' });
  const tickClock = () => { const d = new Date(); clock.textContent = d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); };
  tickClock(); clearInterval(clockT); clockT = setInterval(tickClock, 5000);
  const rail = h('div', { class: 'mu-rail' }, clock);
  TABS.forEach((x) => rail.appendChild(h('button', { class: 'mu-app' + (x.id === tab ? ' on' : ''), title: x.label, onclick: () => go(x.id) }, ico(x.icon))));
  rail.appendChild(h('div', { class: 'mu-sp' }));
  rail.appendChild(h('button', { class: 'mu-app', title: 'Fermer', onclick: () => G.post('music.close', {}) }, ico('x')));
  el.appendChild(rail);
  const sb = (label, ev) => h('button', { class: 'mu-btn', style: { padding: '4px 10px', fontSize: '11.5px' }, onclick: () => G.post(ev, {}) }, label);
  const side = st.mode !== 'box' ? h('small', null, 'Tout le monde à bord peut changer') : (st.placed ? sb('Reprendre', 'music.pickup') : h('span', { style: { display: 'flex', gap: '6px' } }, sb('Poser au sol', 'music.place'), sb('Ranger', 'music.holster')));
  el.appendChild(h('div', { class: 'mu-main' }, h('div', { class: 'mu-head' }, h('b', null, tab === 'now' ? (st.label || 'Musique') : t.label), side), h('div', { class: 'mu-body' }, t.view())));
}
function host() { if (!el) { el = h('div', { id: 'g-music', class: 'hidden' }); G.root.appendChild(el); } return el; }
G.on('music.open', (d) => {
  st = { placed: !!d.placed, mode: d.mode, label: d.label, stations: d.stations || [], vol: d.vol == null ? 100 : d.vol, cur: d.cur || null };
  tab = st.cur ? 'now' : 'radio';
  host().classList.remove('hidden');
  titleRecents(st.cur); draw();
});
G.on('music.state', (d) => {
  if (!st) return;
  const typing = el && document.activeElement && el.contains(document.activeElement) && document.activeElement.tagName === 'INPUT' && document.activeElement.type === 'text';
  st.cur = d.cur || null; titleRecents(st.cur);
  if (!typing) draw();
});
G.on('music.close', () => { st = null; clearInterval(clockT); if (el) { G.clear(el); el.classList.add('hidden'); } });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st) G.post('music.close', {}); });

// Réglage de la boombox dans la main : des boutons, le résultat se voit tout de suite sur le personnage
let adj = null;
G.on('boxadj.open', () => {
  if (adj) adj.remove();
  const step = (kind, i, v) => () => G.post('boxadj.step', { kind, i, v });
  const row = (label, a, b) => h('div', { class: 'ba-r' }, h('span', null, label), h('button', { onclick: a }, '−'), h('button', { onclick: b }, '+'));
  const done = (save) => { if (adj) { adj.remove(); adj = null; } G.post('boxadj.done', { save }); };
  adj = h('div', { id: 'g-boxadj' },
    h('b', null, 'Boombox en main'), h('small', null, 'Clique : elle bouge tout de suite sur ton personnage.'),
    h('h4', null, 'Position'),
    row('Haut / bas', step('move', 1, -0.02), step('move', 1, 0.02)), row('Avant / arrière', step('move', 2, -0.02), step('move', 2, 0.02)), row('Gauche / droite', step('move', 3, -0.02), step('move', 3, 0.02)),
    h('h4', null, 'Rotation'),
    row('Tourner', step('turn', 3, -10), step('turn', 3, 10)), row('Pencher', step('turn', 2, -10), step('turn', 2, 10)), row('Incliner', step('turn', 1, -10), step('turn', 1, 10)),
    h('h4', null, "Quart de tour"),
    h('div', { class: 'ba-q' }, h('button', { onclick: step('turn', 3, 90) }, 'Axe 1'), h('button', { onclick: step('turn', 2, 90) }, 'Axe 2'), h('button', { onclick: step('turn', 1, 90) }, 'Axe 3')),
    h('div', { class: 'ba-b' }, h('button', { class: 'ok', onclick: () => done(true) }, 'Enregistrer'), h('button', { onclick: () => done(false) }, 'Annuler')));
  G.root.appendChild(adj);
});

/* Lecteurs : une radio = un élément audio, une vidéo = la page tvdui.html cachée (YouTube ou Vimeo en son seul) */
const live = {};
function drop(k) {
  const p = live[k]; if (!p) return;
  if (p.audio) { p.audio.pause(); p.audio.src = ''; }
  if (p.frame) p.frame.remove();
  delete live[k];
}
function frameSend(p, m) { if (p.ready && p.frame.contentWindow) p.frame.contentWindow.postMessage(JSON.stringify(m), '*'); else p.queue.push(m); }
function start(s) {
  const p = { sig: s.sig };
  if (s.kind === 'stream') {
    p.audio = new Audio(); p.audio.src = s.url; p.audio.volume = 0; p.audio.play().catch(() => {});
  } else {
    p.queue = []; p.frame = h('iframe', { src: 'tvdui.html', allow: 'autoplay', style: { position: 'fixed', left: '-2000px', top: '0', width: '320px', height: '240px', border: '0', pointerEvents: 'none' } });
    p.frame.addEventListener('load', () => { p.ready = true; p.queue.forEach((m) => frameSend(p, m)); p.queue = []; });
    document.body.appendChild(p.frame);
    frameSend(p, { type: 'play', kind: s.kind, id: s.id, start: s.start });
  }
  live[s.k] = p;
  return p;
}
G.on('music.sync', (d) => {
  const want = {};
  (d.list || []).forEach((s) => {
    s.sig = s.kind + ':' + (s.id || s.url) + ':' + (s.at || 0);
    want[s.k] = true;
    let p = live[s.k];
    if (p && p.sig !== s.sig) { drop(s.k); p = null; }
    if (!p) p = start(s);
    const v = Math.max(0, Math.min(100, Number(s.vol) || 0));
    if (p.vol === v) return;
    p.vol = v;
    if (p.audio) p.audio.volume = v / 100; else frameSend(p, { type: 'vol', v });
  });
  Object.keys(live).forEach((k) => { if (!want[k]) drop(k); });
});
})();
