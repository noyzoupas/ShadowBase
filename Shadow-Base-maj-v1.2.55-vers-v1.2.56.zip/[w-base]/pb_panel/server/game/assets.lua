-- Images envoyées depuis le PC (bannière, logo…) : stockées en base, référencées dans la configuration par « asset:<id> »,
-- envoyées aux joueurs à la demande, en morceaux. Aucun lien externe n'est nécessaire.

local P = PB.Perm
local G, DB = PB.G, PB.DB
local A = {}
PB.Asset = A

P.Register('assets.upload', 'Envoyer des images depuis le PC (bannières, logos)', 'general', true)

PB.Migrate('072_assets', 'Images envoyées depuis le panel', {
    [[CREATE TABLE IF NOT EXISTS pb_assets (
        id VARCHAR(32) NOT NULL, name VARCHAR(80) NOT NULL DEFAULT '', mime VARCHAR(16) NOT NULL, size INT NOT NULL DEFAULT 0, data MEDIUMTEXT NOT NULL,
        by_name VARCHAR(64) NOT NULL DEFAULT '', created INT NOT NULL, PRIMARY KEY (id))]],
})

local MAX_BYTES = 900 * 1024      -- taille de l'image décodée
local MAX_COUNT = 200
local MIMES = { ['image/png'] = 'iVBORw0KGgo', ['image/jpeg'] = '/9j/', ['image/webp'] = 'UklGR' }

local function newId()
    local t = {}
    for i = 1, 16 do t[i] = ('%x'):format(math.random(0, 15)) end
    return table.concat(t)
end

function A.Valid(v) return type(v) == 'string' and v:match('^asset:%x+$') ~= nil and #v >= 12 and #v <= 38 end
function A.Exists(v)
    if not A.Valid(v) then return false end
    return DB.one('SELECT id FROM pb_assets WHERE id = ?', { v:sub(7) }) ~= nil
end
function A.Get(id)
    id = tostring(id or '')
    if not id:match('^%x+$') or #id < 6 or #id > 32 then return nil end
    local r = DB.one('SELECT mime, data FROM pb_assets WHERE id = ?', { id })
    if not r then return nil end
    return 'data:' .. r.mime .. ';base64,' .. r.data, r.mime
end

function A.Save(name, mime, b64, byName)
    if type(mime) ~= 'string' or not MIMES[mime] then return nil, 'Format accepté : PNG, JPEG ou WebP.' end
    if type(b64) ~= 'string' or b64 == '' or not b64:match('^[%w%+/]+=?=?$') then return nil, 'Image invalide.' end
    if b64:sub(1, #MIMES[mime]) ~= MIMES[mime] then return nil, "Le contenu ne correspond pas au format annoncé." end
    local bytes = math.floor(#b64 * 3 / 4)
    if bytes > MAX_BYTES then return nil, 'Image trop lourde (' .. math.floor(bytes / 1024) .. ' Ko, maximum ' .. math.floor(MAX_BYTES / 1024) .. ' Ko).' end
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_assets')
    if n and n.n >= MAX_COUNT then return nil, 'Trop d\'images stockées : supprime les anciennes (onglet Images).' end
    local id = newId()
    DB.exec('INSERT INTO pb_assets (id, name, mime, size, data, by_name, created) VALUES (?, ?, ?, ?, ?, ?, ?)',
        { id, tostring(name or ''):gsub('[%c<>]', ''):sub(1, 80), mime, bytes, b64, tostring(byName or ''):sub(1, 64), os.time() })
    return id, bytes
end

-- Panel : envoi (la requête peut être volumineuse : le transport du panel la découpe) ----------------------------------------------------
PB.Action('asset.upload', 'assets.upload', function(ctx, p)
    local id, bytes = A.Save(p.name, p.mime, p.data, ctx.actor and ctx.actor.name)
    if not id then return false, bytes end
    ctx.audit('config', 'image.envoyer', id, nil, { name = tostring(p.name or ''):sub(1, 80), ko = math.floor(bytes / 1024) })
    ctx.toast = 'Image envoyée.'
    ctx.refresh = false
    return true, { id = 'asset:' .. id }
end, { rate = 20 })

PB.Action('asset.get', 'panel.open', function(ctx, p)
    local id = tostring(p.id or ''):gsub('^asset:', '')
    local uri = A.Get(id)
    if not uri then return false, 'Image introuvable.' end
    ctx.refresh = false
    return true, { uri = uri }
end, { read = true })

PB.Action('asset.delete', 'assets.upload', function(ctx, p)
    local id = tostring(p.id or ''):gsub('^asset:', '')
    if not id:match('^%x+$') then return false, 'Identifiant invalide.' end
    -- refuse de supprimer une image encore utilisée
    local ref = A.Used('asset:' .. id)
    if ref then return false, 'Cette image est utilisée par « ' .. ref .. ' ».' end
    DB.exec('DELETE FROM pb_assets WHERE id = ?', { id })
    ctx.audit('config', 'image.supprimer', id)
    ctx.toast = 'Image supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette image ?', text = 'Action définitive.' } })

-- Où une image est-elle utilisée ? (parcourt la configuration)
function A.Used(ref)
    for _, r in ipairs(DB.q('SELECT ns, k, v FROM pb_kv') or {}) do
        if type(r.v) == 'string' and r.v:find(ref, 1, true) then return r.ns .. '.' .. r.k end
    end
    return nil
end

-- Envoi aux joueurs, à la demande, en morceaux de 24 Ko ----------------------------------------------------------------------------------
local asked = {}
RegisterNetEvent('pb:g:asset:get', function(id)
    local src = source
    if not G.Players()[src] and not (PB.G.IsPending and PB.G.IsPending(src)) then
        -- les joueurs peuvent demander dès l'écran d'accueil : on ne vérifie que la fréquence
    end
    local t = os.time()
    local b = asked[src]
    if not b or t - b.t > 60 then b = { t = t, n = 0 } asked[src] = b end
    b.n = b.n + 1
    if b.n > 40 then return end
    local uri = A.Get(id)
    if not uri then TriggerClientEvent('pb:g:asset:none', src, tostring(id):sub(1, 32)) return end
    local CH = 24000
    local n = math.ceil(#uri / CH)
    -- évènements « latents » (débit limité) : une image entière en évènements normaux peut saturer la file réseau du joueur
    for i = 1, n do
        TriggerLatentClientEvent('pb:g:asset:part', src, 200000, tostring(id), i, n, uri:sub((i - 1) * CH + 1, i * CH))
    end
end)
AddEventHandler('playerDropped', function() asked[source] = nil end)

-- Panel : onglet « Images » (liste, suppression) ------------------------------------------------------------------------------------------
PB.Module({
    id = 'images', label = 'Images', icon = 'image', group = 'Serveur', order = 150, perm = 'assets.upload', hint = 'Bannières et logos envoyés depuis le PC',
    caps = function()
        return PB.Capsify({
            { 'Envoi depuis le PC (PNG, JPEG, WebP)', 'ok', "L'image est réduite dans le navigateur puis stockée dans la base du serveur : aucun lien externe." },
            { 'Taille', 'partial', '900 Ko maximum par image et 200 images ; les images sont redimensionnées automatiquement avant envoi.' },
            { 'Formats animés (GIF, vidéo)', 'off', 'Non pris en charge.' },
        })
    end,
    view = function(ctx)
        return { tabs = { { id = 'list', label = 'Images', icon = 'image', build = function()
            local rows = {}
            for _, r in ipairs(DB.q('SELECT id, name, size, by_name, created FROM pb_assets ORDER BY created DESC LIMIT 200') or {}) do
                local used = A.Used('asset:' .. r.id)
                rows[#rows + 1] = { name = r.name ~= '' and r.name or r.id, ko = math.floor(r.size / 1024) .. ' Ko', used = used or 'Non utilisée', by = r.by_name, at = r.created,
                    actions = { { action = 'asset.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = r.id } } } }
            end
            return { PB.B.notice('info', "Les images s'ajoutent depuis les champs « Image » des autres onglets (Menus, Identité du serveur…). Ici : la liste et le nettoyage."),
                PB.B.table({ id = 'assets', title = 'Images envoyées (' .. #rows .. ')', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'ko', label = 'Taille' }, { k = 'used', label = 'Utilisée par' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Aucune image.' }) }
        end } } }
    end,
})

PB.SelfTest.Add('images', function(R)
    local n = DB.one('SELECT COUNT(*) AS n FROM pb_assets')
    R.check(n ~= nil, 'table des images', 'table introuvable')
end)

-- (v1.2.56) Le logo principal du panel (« Logo (fichier) ») devient aussi le logo en jeu (écran d'entrée, menus, notifications, bienvenue)
-- tant qu'aucun « Logo du serveur en jeu » n'est réglé : copié en image de jeu, remplacée quand le logo change, retirée quand il disparaît.
local function syncMainLogo()
    local d = PB.Cfg.Get('general', 'logo_data', '')
    local cur = PB.Cfg.Get('general', 'logo_game', '')
    if type(d) ~= 'string' or d == '' then
        if cur ~= '' then
            if A.Valid(cur) then DB.exec('DELETE FROM pb_assets WHERE id = ?', { cur:sub(7) }) end
            PB.Cfg.Set('general', 'logo_game', '', nil, 'Logo du panel retiré')
            PB.Cfg.Set('general', 'logo_game_src', '', nil, 'Logo du panel retiré')
        end
        return
    end
    local sig = #d .. ':' .. d:sub(-32)
    if cur ~= '' and PB.Cfg.Get('general', 'logo_game_src', '') == sig and A.Exists(cur) then return end
    local mime, b64 = d:match('^data:(image/%a+);base64,([%w%+/=]+)$')
    if not mime then return end
    local id = A.Save('Logo du panel', mime, b64, 'système')
    if not id then return end
    if cur ~= '' and A.Valid(cur) then DB.exec('DELETE FROM pb_assets WHERE id = ?', { cur:sub(7) }) end
    PB.Cfg.Set('general', 'logo_game', 'asset:' .. id, nil, 'Logo du panel en jeu')
    PB.Cfg.Set('general', 'logo_game_src', sig, nil, 'Logo du panel en jeu')
end
PB.Cfg.OnChange('general', function(k) if k == 'logo_data' then SetTimeout(300, syncMainLogo) end end)
PB.OnReady(function() SetTimeout(1500, syncMainLogo) end)
