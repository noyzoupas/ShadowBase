-- Coffre de véhicule : s'ouvre à pied, derrière le véhicule, avec une touche réglable (ou depuis le menu contextuel).
-- La capacité dépend de la classe du véhicule (réglable). Le serveur vérifie la distance au véhicule, la clé pour un véhicule possédé et le verrouillage.
-- Touches du véhicule (coffre, capot, moteur, ceinture, vitres) : réglables par le joueur dans Paramètres > Raccourcis clavier de FiveM.

local B, P, DB, Form = PB.B, PB.Perm, PB.DB, PB.Form
local G = PB.G
local Inv = G.Inv
local T = {}
G.VehTrunk = T

P.Register('trunk.edit', 'Régler les coffres et les touches des véhicules', 'trunk', true)

-- classe du jeu -> { libellé, emplacements, poids en grammes }
-- (v1.2.45) coffres agrandis : poids doublé, emplacements +50 %
-- (v1.2.45) au moins 130 kg pour tous les véhicules (sauf motos et vélos), au moins 200 kg pour les camions, utilitaires, fourgons, services…
local CLASSES = {
    { 0, 'Compactes', 40, 130000 }, { 1, 'Berlines', 45, 150000 }, { 2, 'SUV', 55, 180000 }, { 3, 'Coupés', 40, 130000 }, { 4, 'Muscle', 40, 130000 }, { 5, 'Sportives classiques', 40, 130000 },
    { 6, 'Sportives', 40, 130000 }, { 7, 'Supersportives', 40, 130000 }, { 8, 'Motos', 6, 16000 }, { 9, 'Tout-terrain', 55, 180000 }, { 10, 'Industriels', 90, 400000 }, { 11, 'Utilitaires', 75, 300000 },
    { 12, 'Fourgons', 75, 360000 }, { 13, 'Vélos', 3, 6000 }, { 14, 'Bateaux', 45, 160000 }, { 15, 'Hélicoptères', 40, 130000 }, { 16, 'Avions', 40, 130000 }, { 17, 'Services', 60, 200000 },
    { 18, 'Urgences', 60, 200000 }, { 19, 'Militaires', 75, 300000 }, { 20, 'Commerciaux', 105, 500000 },
}
local BIG = { [10] = true, [11] = true, [12] = true, [17] = true, [18] = true, [19] = true, [20] = true }
local SMALL = { [8] = true, [13] = true }
-- capacité minimale d'une classe : { emplacements, grammes } (nil = pas de minimum : motos, vélos)
function T.MinCap(class)
    class = tonumber(class)
    if SMALL[class] then return nil end
    if BIG[class] then return 60, 200000 end
    return 40, 130000
end
local DEF = {}
for _, c in ipairs(CLASSES) do DEF[#DEF + 1] = { class = c[1], label = c[2], slots = c[3], weight = c[4] } end
PB.Cfg.Define('trunk', { enabled = true, key_trunk = 'K', key_hood = 'J', key_engine = 'Y', key_belt = 'B', key_windows = 'U', open_dist = 3.5, need_key = true, open_locked = false, classes = DEF })
local function cfg(k, d) return PB.Cfg.Get('trunk', k, d) end
-- (v1.2.45) les capacités déjà enregistrées sont agrandies une fois (poids × 2, emplacements × 1,5), même réglées à la main
PB.OnReady(function()
    if PB.Cfg.Get('trunk', 'cap_v145', false) == true then return end
    local cur = PB.Cfg.Has('trunk', 'classes') and PB.Cfg.Get('trunk', 'classes', nil) or nil   -- seulement des valeurs déjà enregistrées (pas les nouvelles par défaut)
    if type(cur) == 'table' and #cur > 0 then
        local out = {}
        for _, r in ipairs(cur) do
            out[#out + 1] = { class = r.class, label = r.label, slots = math.min(200, math.ceil((tonumber(r.slots) or 10) * 1.5)), weight = math.min(2000000, math.floor((tonumber(r.weight) or 40000) * 2)) }
        end
        PB.Cfg.Set('trunk', 'classes', out, nil, 'Coffres agrandis')
    end
    PB.Cfg.Set('trunk', 'cap_v145', true, nil, 'Migration')
end)
-- (v1.2.45) minimums relevés une fois sur les capacités déjà enregistrées (jamais baissées)
PB.OnReady(function()
    if PB.Cfg.Get('trunk', 'cap_v153', false) == true then return end
    local cur = PB.Cfg.Has('trunk', 'classes') and PB.Cfg.Get('trunk', 'classes', nil) or nil
    if type(cur) == 'table' and #cur > 0 then
        local out = {}
        for _, r in ipairs(cur) do
            local ms, mw = T.MinCap(r.class)
            out[#out + 1] = { class = r.class, label = r.label, slots = ms and math.max(ms, math.floor(tonumber(r.slots) or 0)) or r.slots, weight = mw and math.max(mw, math.floor(tonumber(r.weight) or 0)) or r.weight }
        end
        PB.Cfg.Set('trunk', 'classes', out, nil, 'Coffres : 130 kg minimum, 200 kg pour les camions')
    end
    PB.Cfg.Set('trunk', 'cap_v153', true, nil, 'Migration')
end)

local caps = {}   -- plaque -> { slots, weight, net }
T.Override = {}   -- plaque -> { slots, weight } : capacité imposée (ex. location VIP avec grand coffre)
function Inv.TrunkCap(plate)
    local c = caps[tostring(plate)]
    if c then return { c[1], c[2] } end
    -- coffre vu à distance (F5) : capacité gardée à la dernière ouverture
    local ok, w, n = pcall(function() return GetResourceKvpInt('pb_tcap:' .. tostring(plate)), GetResourceKvpInt('pb_tslot:' .. tostring(plate)) end)
    if ok and (tonumber(w) or 0) > 0 then return { (tonumber(n) or 0) > 0 and n or 12, w } end
    return nil
end

local function capFor(class)
    for _, r in ipairs(cfg('classes', DEF) or DEF) do
        if tonumber(r.class) == class then return math.max(1, math.floor(tonumber(r.slots) or 10)), math.max(1000, math.floor(tonumber(r.weight) or 40000)) end
    end
    return 12, 60000
end

-- capacité connue d'un coffre (dernière ouverture ou dernier passage au volant), gardée entre les redémarrages : affichée dans F5 › Mes véhicules
local function remember(plate, weight, slots)
    if plate == '' or not SetResourceKvpInt then return end
    pcall(SetResourceKvpInt, 'pb_tcap:' .. plate, math.floor(weight))
    if slots then pcall(SetResourceKvpInt, 'pb_tslot:' .. plate, math.floor(slots)) end
end
function T.MaxOf(plate)
    local c = caps[tostring(plate)]
    if c then return c[2] end
    local ok, v = pcall(function() return GetResourceKvpInt and GetResourceKvpInt('pb_tcap:' .. tostring(plate)) end)
    v = ok and tonumber(v) or 0
    return v > 0 and v or nil
end
-- (v1.2.45) coffre plus grand si le propriétaire du véhicule est VIP (emplacements, grammes)
function T.VipBonus(plate)
    if not (G.Vip and G.Vip.TrunkBonus) then return 0, 0 end
    local r = PB.DB.one('SELECT license FROM pb_vehicles WHERE plate = ?', { tostring(plate) })
    if not r then return 0, 0 end
    return G.Vip.TrunkBonus(r.license)
end
function T.Cap(class) local a, b = capFor(math.floor(tonumber(class) or 1)) return { a, b } end

local function vehOf(netId)
    netId = math.floor(tonumber(netId) or 0)
    if netId <= 0 then return nil end
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, netId)
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) then return nil end
    local plate = ''
    pcall(function() plate = tostring(GetVehicleNumberPlateText(ent) or ''):gsub('^%s+', ''):gsub('%s+$', ''):upper() end)
    local c = GetEntityCoords(ent)
    return { ent = ent, plate = plate, x = c.x, y = c.y, z = c.z, net = netId }
end

-- Peut-on ouvrir ce coffre ? Renvoie ok, message.
function T.Check(src, v)
    if not v or v.plate == '' then return false, 'Véhicule introuvable.' end
    local d = G.DistTo(src, v.x, v.y, v.z)
    if d > (tonumber(cfg('open_dist', 3.5)) or 3.5) + 3.5 then return false, 'Tu es trop loin du véhicule.' end
    local owned = G.Garage and G.Garage.Vehicle(v.plate)
    if owned and cfg('need_key', true) ~= false then
        local p = G.Get(src)
        if not (p and (G.Garage.HasKey(p.license, v.plate) or (G.Garage.IsMechanic and G.Garage.IsMechanic(src)))) then return false, "Tu n'as pas la clé de ce véhicule." end
    end
    if cfg('open_locked', false) ~= true then
        local ok, st = pcall(GetVehicleDoorLockStatus, v.ent)
        if ok and tonumber(st) and tonumber(st) >= 2 then return false, 'Le véhicule est verrouillé.' end
    end
    return true
end

RegisterNetEvent('pb:g:veh:trunk', function(netId, class)
    local src = source
    if cfg('enabled', true) == false then return end
    local p = G.Get(src)
    if not p or not PB.ToBool(p.row.created) or PB.ToBool(p.row.dead) then return end
    local v = vehOf(netId)
    local ok, why = T.Check(src, v)
    if not ok then G.Notify(src, { type = 'error', title = 'Coffre', text = why }) return end
    local slots, weight = capFor(math.floor(tonumber(class) or 1))
    local bs, bw = T.VipBonus(v.plate)
    slots, weight = slots + bs, weight + bw
    local o = T.Override[v.plate]
    if o then slots, weight = o[1], o[2] end
    caps[v.plate] = { slots, weight, v.net }
    remember(v.plate, weight, slots)
    TriggerClientEvent('pb:g:veh:trunkok', src, PB.Json({ net = v.net }))
    Inv.OpenFor(src, 'v:' .. v.plate)
end)

-- accès aux conteneurs « v:PLAQUE » (utilisé par l'inventaire à chaque mouvement)
local prev = Inv.ExtraAccess
Inv.ExtraAccess = function(src, kind, id)
    if kind == 'v' then
        local c = caps[tostring(id)]
        if not c then return false end
        local v = vehOf(c[3])
        if not v or v.plate ~= tostring(id) then return false end
        return T.Check(src, v) and true or false
    end
    if prev then return prev(src, kind, id) end
    return false
end

-- Poids du coffre pour le compteur du conducteur (kg) : seulement s'il est dans le véhicule, au plus une fois toutes les 4 s
local wAt = {}
AddEventHandler('playerDropped', function() wAt[source] = nil end)
RegisterNetEvent('pb:g:veh:trunkw', function(netId, class)
    local src = source
    local t = GetGameTimer()
    if wAt[src] and t - wAt[src] < 4000 then return end
    wAt[src] = t
    local v = vehOf(netId)
    if not v or v.plate == '' or G.DistTo(src, v.x, v.y, v.z) > 6 then return end
    local _, maxw = capFor(math.floor(tonumber(class) or 1))
    local _, bw = T.VipBonus(v.plate)
    maxw = maxw + bw
    if T.Override[v.plate] then maxw = T.Override[v.plate][2] end
    if T.MaxOf(v.plate) ~= maxw then remember(v.plate, maxw) end
    local w = Inv.Weight and Inv.Weight('v:' .. v.plate) or 0
    TriggerClientEvent('pb:g:veh:trunkw', src, PB.Json({ w = math.floor((tonumber(w) or 0) / 100) / 10, max = math.floor(maxw / 100) / 10 }))
end)

-- Menu contextuel : « Coffre : ouvrir / fermer » ouvre aussi le sac du coffre
exports('OpenTrunk', function(src, netId, class) TriggerEvent('pb:g:veh:trunk', netId, class) end)

-- Réglages dans le panel ----------------------------------------------------------------------------------------------------------------------
local keys = Form.Cfg({ ns = 'trunk', id = 'keys', title = 'Touches et règles', perm = 'trunk.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Coffres de véhicules actifs', default = true },
    { k = 'need_key', type = 'toggle', label = 'Clé obligatoire pour un véhicule possédé', default = true },
    { k = 'open_locked', type = 'toggle', label = 'Ouvrir même si le véhicule est verrouillé', default = false },
    { k = 'open_dist', type = 'number', label = 'Distance maximale du coffre (m)', default = 3.5, min = 1, max = 8, step = 0.5, int = false },
    { k = 'key_trunk', type = 'text', label = 'Touche : coffre', default = 'K', maxlen = 16, hint = 'Chaque joueur peut la changer dans Paramètres › Raccourcis clavier › FiveM.' },
    { k = 'key_hood', type = 'text', label = 'Touche : capot', default = 'J', maxlen = 16 }, { k = 'key_engine', type = 'text', label = 'Touche : moteur', default = 'Y', maxlen = 16 },
    { k = 'key_belt', type = 'text', label = 'Touche : ceinture', default = 'B', maxlen = 16 }, { k = 'key_windows', type = 'text', label = 'Touche : vitres', default = 'U', maxlen = 16 },
} })
local cls = Form.Cfg({ ns = 'trunk', id = 'classes', title = 'Capacité par classe de véhicule', perm = 'trunk.edit', fields = {
    { k = 'classes', type = 'rows', label = 'Classes', default = DEF, wide = true, maxitems = 30, unique = 'class', cols = {
        { k = 'class', label = 'Classe du jeu', type = 'number', min = 0, max = 30 }, { k = 'label', label = 'Nom', maxlen = 30 },
        { k = 'slots', label = 'Emplacements', type = 'number', min = 1, max = 200 }, { k = 'weight', label = 'Poids max (g)', type = 'number', min = 1000, max = 2000000 } } } } })

PB.Module({
    id = 'vehtrunk', label = 'Coffres de véhicules', icon = 'engine', group = 'Serveur', order = 131, perm = 'trunk.edit', hint = 'Capacité et touches du véhicule',
    caps = function()
        return PB.Capsify({
            { 'Coffre à pied, clé et distance vérifiées côté serveur', 'ok', "Le serveur relit la position et le verrouillage du véhicule à chaque ouverture." },
            { 'Classe du véhicule', 'warn', "La classe vient du client (limitée aux capacités que tu fixes) : un client modifié pourrait choisir une autre classe." },
            { 'Touches capot / moteur / ceinture / vitres', 'warn', "Actions locales au joueur ; jamais vérifiées dans un vrai client FiveM." },
        })
    end,
    doc = "## Coffres de véhicules\nÀ pied, près de l'arrière du véhicule, appuie sur la touche **coffre** (K par défaut) : le coffre s'ouvre et son contenu apparaît à droite de ton sac. Les touches **capot** (J), **moteur** (Y), **ceinture** (B) et **vitres** (U) sont aussi réglables ici et par chaque joueur dans les raccourcis FiveM.",
    view = function(ctx)
        return { tabs = { { id = 'keys', label = 'Touches et règles', icon = 'sliders', build = function() return { keys(ctx) } end },
            { id = 'classes', label = 'Capacités', icon = 'box', build = function() return { cls(ctx) } end } } }
    end,
})

PB.SelfTest.Add('coffres de véhicules', function(R)
    R.check(#cfg('classes', DEF) >= 15, 'coffre', 'classes de véhicules manquantes')
    R.check(Inv and Inv.ExtraAccess ~= nil and Inv.OpenFor ~= nil, 'coffre', "l'inventaire n'est pas chargé")
    local s, w = capFor(7)
    R.check(s < capFor(12), 'coffre', 'une supersportive devrait avoir moins de place qu\'un fourgon')
end)
