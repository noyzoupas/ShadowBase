-- Statut Discord des joueurs (panel › Statut Discord) : texte, images, boutons. Le client l'applique (client/richpresence.lua).
-- Les images se déposent sur le portail développeur de Discord, dans l'application dont l'identifiant est donné ici : on donne ensuite leur nom.
local cfgNs = 'richp'
PB.Cfg.Define(cfgNs, { enabled = true, app_id = '', text = '{serveur} · {joueurs}/{max} joueurs', large_key = '', large_text = '{serveur}', small_key = '', small_text = '',
    btn1_label = '', btn1_url = '', btn2_label = '', btn2_url = '', refresh = 30 })

-- nombre de joueurs lisible par tous : un client ne voit que les joueurs proches de lui
CreateThread(function()
    while true do
        if GlobalState then
            GlobalState.pb_online = #GetPlayers()
            GlobalState.pb_maxp = GetConvarInt('sv_maxclients', 48)
        end
        Wait(30000)
    end
end)

local URL = '^https://[^%s]+$'
local form = PB.Form.Cfg({ ns = cfgNs, id = 'settings', title = 'Statut Discord', perm = 'general.edit', cols = 2, desc = 'Ce que les autres voient sur le profil Discord des joueurs connectés.', fields = {
    { k = 'enabled', type = 'toggle', label = 'Statut Discord actif', default = true, wide = true },
    { k = 'app_id', type = 'text', label = "Identifiant de l'application Discord", default = '', maxlen = 24, pattern = '^%d*$', wide = true, hint = "discord.com/developers › ton application › Application ID. Le nom de l'application est le titre affiché (« Joue à … »)." },
    { k = 'text', type = 'text', label = 'Texte du statut', default = '{serveur} · {joueurs}/{max} joueurs', maxlen = 120, wide = true, hint = 'Variables : {serveur}, {joueurs}, {max}, {nom} (personnage), {id}.' },
    { k = 'large_key', type = 'text', label = 'Grande image : nom', default = '', maxlen = 64, hint = "Nom de l'image déposée dans Rich Presence › Art Assets." },
    { k = 'large_text', type = 'text', label = 'Grande image : texte au survol', default = '{serveur}', maxlen = 120 },
    { k = 'small_key', type = 'text', label = 'Petite image : nom', default = '', maxlen = 64 },
    { k = 'small_text', type = 'text', label = 'Petite image : texte au survol', default = '', maxlen = 120 },
    { k = 'btn1_label', type = 'text', label = 'Bouton 1 : texte', default = '', maxlen = 32 },
    { k = 'btn1_url', type = 'text', label = 'Bouton 1 : lien', default = '', maxlen = 200, pattern = URL },
    { k = 'btn2_label', type = 'text', label = 'Bouton 2 : texte', default = '', maxlen = 32 },
    { k = 'btn2_url', type = 'text', label = 'Bouton 2 : lien', default = '', maxlen = 200, pattern = URL },
    { k = 'refresh', type = 'number', label = 'Mise à jour toutes les (secondes)', default = 30, min = 15, max = 300 },
} })
PB.Module({
    id = 'richp', label = 'Statut Discord', icon = 'message', group = 'Serveur', order = 19, perm = 'general.edit', hint = 'Ce que Discord affiche quand on joue sur le serveur',
    caps = function() return PB.Capsify({
        { 'Texte, images et boutons', 'ok', 'Tout se règle ici ; les changements arrivent chez les joueurs à la prochaine mise à jour.' },
        { 'Images', 'partial', "Elles sont hébergées par Discord : à déposer dans l'application, ici on donne leur nom." },
        { 'Vérifié dans un vrai client FiveM', 'off', 'Non : testé en simulation.' } }) end,
    doc = "## Statut Discord\n1. Crée une application sur **discord.com/developers** : son nom est le titre affiché.\n2. Dépose tes images dans **Rich Presence › Art Assets**.\n3. Colle ici l'identifiant de l'application et le nom des images.\n\nVariables du texte : `{serveur}`, `{joueurs}`, `{max}`, `{nom}`, `{id}`.",
    view = function(ctx)
        return { tabs = { { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end } } }
    end,
})
