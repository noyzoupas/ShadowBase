-- Module 15 : Journaux (audit du panel, connexions, erreurs Lua et SQL), recherche, exportation CSV, conservation.

local B, P, Form, A = PB.B, PB.Perm, PB.Form, PB.Audit

P.Register('logs.export', 'Exporter les journaux', 'logs')
P.Register('logs.purge', 'Purger les journaux', 'logs', true)
P.Register('logs.settings', 'Régler la conservation des journaux', 'logs')

local CATS = { 'config', 'grade', 'permission', 'sanction', 'transaction', 'connexion', 'commande', 'ressource', 'sql', 'securite', 'sauvegarde', 'automatisation', 'discord', 'erreur_lua', 'serveur', 'panel' }
local PER = 30

local settings = Form.Cfg({
    ns = 'logs', id = 'settings', title = 'Conservation et collecte', perm = 'logs.settings', cols = 2,
    desc = "Le journal d'audit du panel est toujours actif. Les connexions sont optionnelles car elles contiennent des identifiants de joueurs.",
    fields = {
        { k = 'retention_days', type = 'number', label = 'Conservation (jours)', default = 90, min = 7, max = 3650, hint = 'Les entrées plus anciennes sont supprimées chaque jour.' },
        { k = 'log_connections', type = 'toggle', label = 'Journaliser les connexions et déconnexions', default = true },
        { k = 'log_lua_errors', type = 'toggle', label = 'Journaliser les erreurs de scripts dans le journal', default = true, hint = 'Nécessite l\'écoute de la console (voir Ressources › Erreurs).' },
    },
})

AddEventHandler('playerConnecting', function(name)
    if not PB.Cfg.Get('logs', 'log_connections', true) then return end
    local src = source
    local lic = ''
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if id:sub(1, 8) == 'license:' then lic = id end end
    A.Log('connexion', 'connexion', 'système', tostring(name or ''), nil, nil, { license = lic })
end)

AddEventHandler('playerDropped', function(reason)
    if not PB.Cfg.Get('logs', 'log_connections', true) then return end
    local src = source
    local lic = ''
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if id:sub(1, 8) == 'license:' then lic = id end end
    A.Log('connexion', 'déconnexion', 'système', GetPlayerName(src) or tostring(src), nil, nil, { license = lic, reason = tostring(reason or ''):sub(1, 160) })
end)

-- Purge quotidienne selon la conservation choisie
CreateThread(function()
    while true do
        Wait(6 * 3600 * 1000)
        if PB.IsReady then
            local days = PB.Cfg.Get('logs', 'retention_days', 90)
            A.Prune(days)
            -- autres journaux qui grossissent (colonnes en secondes Unix) ; une table absente est ignorée
            local limit = os.time() - days * 86400
            for _, t in ipairs({ { 'pb_kicks', 'at' }, { 'wb_activites_log', 'at' }, { 'wb_jobs_log', 'at' }, { 'wb_peche_log', 'at' }, { 'wb_chasse_log', 'at' }, { 'wb_minage_log', 'at' }, { 'wb_bucheron_log', 'at' }, { 'wb_armes_log', 'at' } }) do
                if PB.DB.TableExists(t[1]) then PB.DB.exec(('DELETE FROM %s WHERE %s < ?'):format(t[1], t[2]), { limit }) end
            end
            if PB.DB.TableExists('pb_calls') then PB.DB.exec("DELETE FROM pb_calls WHERE status <> 'open' AND created < ?", { limit }) end
        end
    end
end)

local function filters(params)
    return { cat = tostring(params and params.cat or ''), q = PB.Trim(tostring(params and params.q or '')):sub(1, 80), actor = PB.Trim(tostring(params and params.actor or '')):sub(1, 60),
        page = PB.ToInt(params and params.page, 1), per = PER }
end

local function csv(v)
    v = tostring(v or ''):gsub('"', '""')
    if v:match('^[=+@%-]') then v = "'" .. v end -- neutralise l'injection de formules dans un tableur
    return '"' .. v .. '"'
end

PB.Action('logs.export', 'logs.export', function(ctx, p)
    local f = filters(p.filters or p)
    f.per = 500
    local lines = { 'id,date,categorie,action,auteur,cible' }
    local rows = A.Search(f)
    for _, r in ipairs(rows) do lines[#lines + 1] = table.concat({ r.id, csv(r.created_at), csv(r.cat), csv(r.action), csv(r.actor), csv(r.target) }, ',') end
    ctx.audit('panel', 'logs.export', #rows .. ' ligne(s)')
    return true, { download = { name = 'journal.csv', text = table.concat(lines, '\n'), mime = 'text/csv' } }
end, { read = true, rate = 5 })

PB.Action('logs.purge', 'logs.purge', function(ctx, p)
    local days = PB.Clamp(PB.ToInt(p.values and p.values.days, 90), 1, 3650)
    local n = A.Prune(days)
    ctx.audit('panel', 'logs.purge', tostring(days) .. ' jours', nil, { removed = n })
    ctx.toast = n .. ' entrée(s) supprimée(s).'
    return true
end, { critical = true, pin = true, confirm = { title = 'Purger le journal ?', text = 'Les entrées plus anciennes que le nombre de jours choisi sont supprimées définitivement.' } })

PB.Module({
    id = 'logs', label = 'Journaux', icon = 'scroll', group = 'Système', order = 140, perm = 'logs.view', hint = 'Audit, connexions, erreurs',
    caps = function()
        return PB.Capsify({
            { "Journal d'audit du panel", 'ok', 'Toutes les modifications, avec valeur avant / après.' },
            { 'Connexions et déconnexions', 'ok', "Identifiant de licence et nom ; l'adresse IP n'est pas conservée." },
            { 'Erreurs de scripts', PB.ScriptErrors and 'partial' or 'off', 'Relevées depuis la console si le serveur le permet.' },
            { 'Erreurs SQL', 'ok', 'Requêtes passées par le panel.' },
            { 'Journaux des autres scripts', 'off', 'Chaque script a ses propres logs : le panel ne les réécrit pas.' },
            { 'Exportation', 'ok', 'CSV, jusqu\'à 500 lignes par fichier.' },
        })
    end,
    doc = "## Journaux\nLe journal d'audit enregistre qui a fait quoi, avec l'ancienne et la nouvelle valeur. Les mots de passe, clés et webhooks n'y apparaissent jamais en clair.",
    view = function(ctx, params)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('audit', 'Audit', 'list', function()
                local f = filters(params)
                local rows, total, per, page = A.Search(f)
                local out = {}
                for _, r in ipairs(rows) do
                    out[#out + 1] = { at = r.created_at, cat = { text = r.cat, tone = 'info' }, what = r.action, actor = r.actor, target = r.target,
                        actions = { { action = 'audit.detail', label = 'Détails', icon = 'diff', payload = { id = r.id } } } }
                end
                local copts = { { '', 'Toutes' } }
                for _, c in ipairs(CATS) do copts[#copts + 1] = { c, c } end
                return {
                    { type = 'form', id = 'logs.filter', title = 'Filtrer', cols = 3, fields = { { k = 'cat', type = 'select', label = 'Catégorie', options = copts }, { k = 'q', type = 'text', label = 'Texte', maxlen = 80 }, { k = 'actor', type = 'text', label = 'Auteur', maxlen = 60 } },
                        values = { cat = f.cat, q = f.q, actor = f.actor }, submit = { nav = { tab = 'audit' }, label = 'Filtrer', as = 'params' } },
                    B.table({ id = 'audit', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'cat', label = 'Catégorie', type = 'badge' }, { k = 'what', label = 'Action', type = 'mono' }, { k = 'actor', label = 'Auteur' }, { k = 'target', label = 'Cible' } },
                        rows = out, page = { n = page, per = per, total = total, tab = 'audit', cat = f.cat, q = f.q, actor = f.actor }, empty = 'Aucune entrée.' }),
                    ctx.has('logs.export') and B.actions({ { action = 'logs.export', label = 'Exporter la sélection (CSV)', icon = 'download', payload = { cat = f.cat, q = f.q, actor = f.actor } } }) or nil,
                }
            end),
            tab('connections', 'Connexions', 'users', function()
                local rows, total, per, page = A.Search({ cat = 'connexion', page = PB.ToInt(params and params.page, 1), per = PER, q = PB.Trim(tostring(params and params.q or '')):sub(1, 60) })
                local out = {}
                for _, r in ipairs(rows) do
                    local d = PB.FromJson(r.data, {})
                    out[#out + 1] = { at = r.created_at, what = r.action, who = r.target, license = d.license or '', reason = d.reason or '' }
                end
                return { { type = 'form', id = 'logs.cfilter', title = 'Chercher un joueur', cols = 2, fields = { { k = 'q', type = 'text', label = 'Nom ou licence', maxlen = 60 } }, values = { q = tostring(params and params.q or '') }, submit = { nav = { tab = 'connections' }, label = 'Chercher', as = 'params' } },
                    B.table({ id = 'conns', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'what', label = 'Évènement' }, { k = 'who', label = 'Joueur' }, { k = 'license', label = 'Licence', type = 'mono' }, { k = 'reason', label = 'Raison' } },
                        rows = out, page = { n = page, per = per, total = total, tab = 'connections', q = tostring(params and params.q or '') }, empty = 'Aucune connexion enregistrée.' }) }
            end),
            tab('errors', 'Erreurs', 'alert', function()
                local lua, sql = {}, {}
                for i = #(PB.ScriptErrors or {}), 1, -1 do lua[#lua + 1] = { at = PB.ScriptErrors[i].at, text = PB.ScriptErrors[i].text } end
                for _, e in ipairs(PB.DB.Errors) do sql[#sql + 1] = { at = e.at, sql = e.sql, err = e.error } end
                return { B.table({ id = 'luaerr', title = 'Erreurs de scripts (depuis le démarrage du panel)', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'text', label = 'Message' } }, rows = lua, empty = PB.ScriptErrors and 'Aucune erreur relevée.' or "L'écoute de la console n'est pas disponible sur ce serveur." }),
                    B.table({ id = 'sqlerr', title = 'Erreurs SQL', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'sql', label = 'Requête', type = 'mono' }, { k = 'err', label = 'Erreur' } }, rows = sql, empty = 'Aucune erreur SQL.' }) }
            end),
            tab('settings', 'Réglages', 'sliders', function()
                local blocks = { settings(ctx) }
                if ctx.has('logs.purge') then
                    blocks[#blocks + 1] = { type = 'form', id = 'logs.purge', title = 'Purger maintenant', cols = 2, fields = { { k = 'days', type = 'number', label = 'Supprimer ce qui a plus de (jours)', min = 1, max = 3650 } }, values = { days = 90 }, submit = { action = 'logs.purge', label = 'Purger', danger = true } }
                end
                return blocks
            end, 'logs.settings'),
        } }
    end,
})
