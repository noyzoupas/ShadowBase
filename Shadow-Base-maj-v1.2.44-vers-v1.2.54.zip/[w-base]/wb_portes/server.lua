-- Shadow Base — Portes verrouillables. N'importe quelle porte du jeu, rangée dans un groupe (ex. « Commissariat ») avec ses accès :
-- entreprises, gangs, ou tout le monde. Le staff en service ouvre toujours. Gestion en jeu : F10 › Builder › Portes, ou /portes.
-- Le serveur garde l'état (verrouillée / ouverte) et vérifie la distance et les droits à chaque changement.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local PERM = RES .. '.edit'

local groups, doors = {}, {}     -- id -> ligne
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Portes', text) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>"\\]', ''):sub(1, n)) end

-- Base -------------------------------------------------------------------------------------------------------------------------------------
local function load()
    groups, doors = {}, {}
    for _, g in ipairs(MySQL.query.await('SELECT * FROM wb_portes_groups') or {}) do
        g.access = json.decode(g.access or '[]') or {}
        groups[g.id] = g
    end
    for _, d in ipairs(MySQL.query.await('SELECT * FROM wb_portes_doors') or {}) do doors[d.id] = d end
end

-- Accès : la ligne d'accès contient des jetons « all », « biz:<id> », « gang:<id> » --------------------------------------------------------------
local function canUse(src, g)
    if not g then return false end
    local ok, staff = pcall(function() return W:IsStaffOnDuty(src) end)
    if ok and staff then return true end
    local job = W:GetJob(src)
    local gang = W:GetPlayerGang(src)
    for _, t in ipairs(g.access or {}) do
        if t == 'all' then return true end
        if job and t == 'biz:' .. tostring(job.biz) then return true end
        if gang and t == 'gang:' .. tostring(gang) then return true end
    end
    return false
end
local function canEdit(src) local ok, r = pcall(function() return W:HasPermission(src, PERM) end) return ok and r end

-- Envoi aux joueurs : toutes les portes (pour le système de portes du jeu) + celles que ce joueur peut utiliser
local function payload(src)
    local list = {}
    for id, d in pairs(doors) do
        local g = groups[d.grp]
        list[#list + 1] = { id = id, model = d.model, x = d.x, y = d.y, z = d.z, locked = d.locked == 1 or d.locked == true, label = g and g.label or 'Porte', can = canUse(src, g) or nil }
    end
    return json.encode(list)
end
-- modèles des portes déjà enregistrées : le menu ALT de pb_panel les reconnaît toujours comme des portes, quelle que soit leur forme
local function knownModels()
    local seen, out = {}, {}
    for _, d in pairs(doors) do local m = tonumber(d.model) if m and not seen[m] then seen[m] = true out[#out + 1] = m end end
    return out
end
local function push(target)
    local models = knownModels()
    if target then TriggerClientEvent(RES .. ':doors', target, payload(target)) TriggerClientEvent('pb:g:ctx:knownDoors', target, models) return end
    for _, s in ipairs(GetPlayers()) do TriggerClientEvent(RES .. ':doors', tonumber(s), payload(tonumber(s))) TriggerClientEvent('pb:g:ctx:knownDoors', tonumber(s), models) end
end
local function pushState(id) local d = doors[id] if d then TriggerClientEvent(RES .. ':state', -1, id, d.locked == 1) end end
RegisterNetEvent(RES .. ':hello', function() push(source) end)
-- métier / gang qui changent : on renvoie les droits de temps en temps
CreateThread(function() while true do Wait(60000) push() end end)
AddEventHandler('pb_panel:jobChanged', function(src) SetTimeout(500, function() push(src) end) end)

-- Ouvrir / verrouiller --------------------------------------------------------------------------------------------------------------------------
local last = {}
RegisterNetEvent(RES .. ':toggle', function(id)
    local src = source
    local t = GetGameTimer()
    if last[src] and t - last[src] < 700 then return end
    last[src] = t
    local d = doors[tonumber(id) or -1]
    if not d then return end
    local ped = GetPlayerPed(src)
    local c = ped ~= 0 and GetEntityCoords(ped)
    local inVeh = ped ~= 0 and GetVehiclePedIsIn(ped, false) ~= 0
    if not c or #(c - vector3(d.x, d.y, d.z)) > (inVeh and 30.0 or 22.0) then return end   -- position d'une grande porte : sur un bord ; la portée fine est vérifiée par le client
    if not canUse(src, groups[d.grp]) then notify(src, 'error', "Tu n'as pas la clé de cette porte.") return end
    d.locked = (d.locked == 1) and 0 or 1
    MySQL.update('UPDATE wb_portes_doors SET locked = ? WHERE id = ?', { d.locked, d.id })
    pushState(d.id)
    notify(src, d.locked == 1 and 'info' or 'success', d.locked == 1 and 'Porte verrouillée.' or 'Porte déverrouillée.')
end)
AddEventHandler('playerDropped', function() last[source] = nil end)

-- Gestion (staff) -----------------------------------------------------------------------------------------------------------------------------
local function manageData(src)
    local orgs = W:ListOrgs()
    local gl = {}
    for id, g in pairs(groups) do
        local n = 0
        for _, d in pairs(doors) do if d.grp == id then n = n + 1 end end
        gl[#gl + 1] = { id = id, label = g.label, access = g.access, locked = g.def_locked == 1, doors = n }
    end
    table.sort(gl, function(a, b) return a.label < b.label end)
    return json.encode({ groups = gl, biz = orgs.biz, gangs = orgs.gangs })
end
local function openManage(src)
    if not canEdit(src) then notify(src, 'error', "Il te faut la permission « " .. PERM .. " ».") return false end
    TriggerClientEvent(RES .. ':manage', src, manageData(src))
    return true
end
RegisterCommand('portes', function(src) if src > 0 then openManage(src) end end, false)

-- Verrouillage rapide (staff, menu ALT de pb_panel) : la porte cliquée, ses accès, recherche des entreprises et des gangs ----------------------
local function doorAt(model, x, y, z)
    for _, d in pairs(doors) do if d.model == model and #(vector3(d.x, d.y, d.z) - vector3(x, y, z)) < 0.5 then return d end end
end
local function readDoor(b)
    if type(b) ~= 'table' then return nil end
    local model, x, y, z = math.floor(tonumber(b.model) or 0), tonumber(b.x), tonumber(b.y), tonumber(b.z)
    if model == 0 or not (x and y and z) then return nil end
    return { model = model, x = x, y = y, z = z }
end
local function nearSrc(src, d, max)
    local ped = GetPlayerPed(src)
    local c = ped ~= 0 and GetEntityCoords(ped)
    return c and #(c - vector3(d.x, d.y, d.z)) <= (max or 30.0)
end
local function validTok(tok) return tok == 'all' or (type(tok) == 'string' and (tok:match('^biz:[%w_%-]+$') or tok:match('^gang:[%w_%-]+$'))) and true or false end
local function quickData(src, door)
    local orgs = W:ListOrgs()
    local cur = doorAt(door.model, door.x, door.y, door.z)
    local gl = {}
    for id, g in pairs(groups) do gl[#gl + 1] = { id = id, label = g.label } end
    table.sort(gl, function(a, b) return a.label < b.label end)
    local c
    if cur then
        local g = groups[cur.grp]
        local n = 0
        for _, d in pairs(doors) do if d.grp == cur.grp then n = n + 1 end end
        c = { id = cur.id, grp = cur.grp, label = g and g.label or 'Porte', locked = cur.locked == 1, access = g and g.access or {}, doors = n }
    end
    return json.encode({ door = door, cur = c, groups = gl, biz = orgs.biz, gangs = orgs.gangs })
end
AddEventHandler('pb_panel:ctxDoor', function(src, b)
    src = tonumber(src)
    local door = readDoor(b)
    if not src or not door then return end
    if not canEdit(src) then notify(src, 'error', "Il te faut la permission « " .. PERM .. " ».") return end
    if not nearSrc(src, door) then return end
    TriggerClientEvent(RES .. ':quick', src, quickData(src, door))
end)
-- libellé automatique : « Porte · Police, Ballas »
local function autoLabel(tokens)
    local orgs = W:ListOrgs()
    local names = {}
    for _, t in ipairs(tokens) do
        if t == 'all' then names[#names + 1] = 'Tout le monde'
        else
            local kind, id = t:match('^(%a+):(.+)$')
            for _, o in ipairs(kind == 'biz' and orgs.biz or orgs.gangs) do if tostring(o.id) == id then names[#names + 1] = o.label end end
        end
    end
    if #names == 0 then return 'Porte · Staff' end
    local s = 'Porte · ' .. table.concat(names, ', ', 1, math.min(#names, 2)) .. (#names > 2 and (' +' .. (#names - 2)) or '')
    return clean(s, 40)
end
RegisterNetEvent(RES .. ':quickop', function(op, a, b)
    local src = source
    if not canEdit(src) then return end
    local t = GetGameTimer()
    if last[src] and t - last[src] < 400 then return end
    last[src] = t
    op = tostring(op)
    local who = GetPlayerName(src) or ('#' .. src)
    if op == 'lock' then
        -- a = porte (+ a.pair : second battant éventuel), b = { tokens = {...}, label = '' }
        local door = readDoor(a)
        if not door or not nearSrc(src, door) or type(b) ~= 'table' then return end
        if doorAt(door.model, door.x, door.y, door.z) then notify(src, 'warn', 'Cette porte est déjà verrouillable.') return end
        local toks, seen = {}, {}
        for _, tok in ipairs(type(b.tokens) == 'table' and b.tokens or {}) do if validTok(tok) and not seen[tok] and #toks < 30 then seen[tok] = true toks[#toks + 1] = tok end end
        local label = clean(b.label, 40)
        if #label < 2 then label = autoLabel(toks) end
        local gid = MySQL.insert.await('INSERT INTO wb_portes_groups (label, access, def_locked) VALUES (?, ?, 1)', { label, json.encode(toks) })
        if not gid then return end
        MySQL.insert.await('INSERT INTO wb_portes_doors (grp, model, x, y, z, locked) VALUES (?, ?, ?, ?, ?, 1)', { gid, door.model, door.x, door.y, door.z })
        local pair = readDoor(a.pair)
        if pair and nearSrc(src, pair) and #(vector3(pair.x, pair.y, pair.z) - vector3(door.x, door.y, door.z)) < 4.0 and not doorAt(pair.model, pair.x, pair.y, pair.z) then
            MySQL.insert.await('INSERT INTO wb_portes_doors (grp, model, x, y, z, locked) VALUES (?, ?, ?, ?, ?, 1)', { gid, pair.model, pair.x, pair.y, pair.z })
        end
        notify(src, 'success', ('Porte verrouillée : « %s ».'):format(label) .. (#toks == 0 and ' Seul le staff peut ouvrir.' or ''))
    elseif op == 'join' then
        local door, g = readDoor(b), groups[tonumber(a) or -1]
        if not door or not g or not nearSrc(src, door) then return end
        if doorAt(door.model, door.x, door.y, door.z) then notify(src, 'warn', 'Cette porte est déjà verrouillable.') return end
        MySQL.insert.await('INSERT INTO wb_portes_doors (grp, model, x, y, z, locked) VALUES (?, ?, ?, ?, ?, ?)', { g.id, door.model, door.x, door.y, door.z, g.def_locked })
        notify(src, 'success', ('Porte ajoutée à « %s ».'):format(g.label))
    elseif op == 'toggle' then
        local d = doors[tonumber(a) or -1]
        if not d or not nearSrc(src, d) then return end
        d.locked = (d.locked == 1) and 0 or 1
        MySQL.update.await('UPDATE wb_portes_doors SET locked = ? WHERE id = ?', { d.locked, d.id })
        notify(src, 'info', d.locked == 1 and 'Porte verrouillée.' or 'Porte déverrouillée.')
    elseif op == 'access' then
        local g = groups[tonumber(a) or -1]
        if not g or not validTok(b) then return end
        local out, had = {}, false
        for _, x in ipairs(g.access or {}) do if x == b then had = true else out[#out + 1] = x end end
        if not had then out[#out + 1] = b end
        MySQL.update.await('UPDATE wb_portes_groups SET access = ? WHERE id = ?', { json.encode(out), g.id })
    elseif op == 'remove' then
        local d = doors[tonumber(a) or -1]
        if not d or not nearSrc(src, d) then return end
        MySQL.update.await('DELETE FROM wb_portes_doors WHERE id = ?', { d.id })
        TriggerClientEvent(RES .. ':forget', -1, d.id)
        -- groupe créé par le verrouillage rapide et maintenant vide : on le supprime aussi
        local left = MySQL.scalar.await('SELECT COUNT(*) FROM wb_portes_doors WHERE grp = ?', { d.grp })
        local g = groups[d.grp]
        if (tonumber(left) or 0) == 0 and g and tostring(g.label):find('Porte · ', 1, true) == 1 then MySQL.update.await('DELETE FROM wb_portes_groups WHERE id = ?', { d.grp }) end
        notify(src, 'success', 'Porte rendue normale.')
    else return end
    W:Log('portes', 'quick.' .. op, who, tostring(type(a) == 'table' and a.model or a), nil, nil, nil)
    load()
    push()
end)

RegisterNetEvent(RES .. ':edit', function(op, a, b)
    local src = source
    if not canEdit(src) then return end
    op = tostring(op)
    local who = GetPlayerName(src) or ('#' .. src)
    if op == 'new' then
        local label = clean(a, 40)
        if #label < 2 then notify(src, 'error', 'Donne un nom au groupe.') return end
        MySQL.insert.await('INSERT INTO wb_portes_groups (label, access, def_locked) VALUES (?, ?, 1)', { label, '[]' })
        notify(src, 'success', ('Groupe « %s » créé : ajoute ses portes et ses accès.'):format(label))
    elseif op == 'rename' then
        local g = groups[tonumber(a) or -1] if not g then return end
        local label = clean(b, 40) if #label < 2 then return end
        MySQL.update.await('UPDATE wb_portes_groups SET label = ? WHERE id = ?', { label, g.id })
    elseif op == 'access' then
        -- b = jeton à ajouter ou retirer : all | biz:<id> | gang:<id>
        local g = groups[tonumber(a) or -1] if not g then return end
        local tok = tostring(b or '')
        if not (tok == 'all' or tok:match('^biz:[%w_%-]+$') or tok:match('^gang:[%w_%-]+$')) then return end
        local out, had = {}, false
        for _, t in ipairs(g.access or {}) do if t == tok then had = true else out[#out + 1] = t end end
        if not had then out[#out + 1] = tok end
        MySQL.update.await('UPDATE wb_portes_groups SET access = ? WHERE id = ?', { json.encode(out), g.id })
    elseif op == 'deflock' then
        local g = groups[tonumber(a) or -1] if not g then return end
        MySQL.update.await('UPDATE wb_portes_groups SET def_locked = ? WHERE id = ?', { b == true and 1 or 0, g.id })
    elseif op == 'add' then
        -- b = { model, x, y, z } lu par le client sur la porte visée ; le serveur vérifie que le staff est à côté
        local g = groups[tonumber(a) or -1] if not g or type(b) ~= 'table' then return end
        local model, x, y, z = math.floor(tonumber(b.model) or 0), tonumber(b.x), tonumber(b.y), tonumber(b.z)
        if model == 0 or not x then return end
        local c = GetEntityCoords(GetPlayerPed(src))
        if #(c - vector3(x, y, z)) > 30.0 then notify(src, 'error', 'Porte trop loin.') return end
        for _, d in pairs(doors) do if d.model == model and #(vector3(d.x, d.y, d.z) - vector3(x, y, z)) < 0.5 then notify(src, 'warn', 'Cette porte est déjà dans le groupe « ' .. (groups[d.grp] and groups[d.grp].label or '?') .. ' ».') return end end
        MySQL.insert.await('INSERT INTO wb_portes_doors (grp, model, x, y, z, locked) VALUES (?, ?, ?, ?, ?, ?)', { g.id, model, x, y, z, g.def_locked })
        notify(src, 'success', ('Porte ajoutée à « %s ».'):format(g.label))
    elseif op == 'remove' then
        -- b = { model, x, y, z } : la porte visée
        if type(b) ~= 'table' then return end
        local model, x, y, z = math.floor(tonumber(b.model) or 0), tonumber(b.x) or 0, tonumber(b.y) or 0, tonumber(b.z) or 0
        local hit
        for _, d in pairs(doors) do if d.model == model and #(vector3(d.x, d.y, d.z) - vector3(x, y, z)) < 0.5 then hit = d end end
        if not hit then notify(src, 'warn', "Cette porte n'est dans aucun groupe.") return end
        MySQL.update.await('DELETE FROM wb_portes_doors WHERE id = ?', { hit.id })
        TriggerClientEvent(RES .. ':forget', -1, hit.id)
        notify(src, 'success', 'Porte retirée.')
    elseif op == 'delete' then
        local g = groups[tonumber(a) or -1] if not g then return end
        for id, d in pairs(doors) do if d.grp == g.id then TriggerClientEvent(RES .. ':forget', -1, id) end end
        MySQL.update.await('DELETE FROM wb_portes_doors WHERE grp = ?', { g.id })
        MySQL.update.await('DELETE FROM wb_portes_groups WHERE id = ?', { g.id })
        notify(src, 'success', ('Groupe « %s » supprimé.'):format(g.label))
    else return end
    W:Log('portes', op, who, tostring(a), nil, nil, nil)
    load()
    push()
    TriggerClientEvent(RES .. ':manage', src, manageData(src))
end)

-- Branchement sur Shadow Base ----------------------------------------------------------------------------------------------------------------------
local function setup()
    W:ExtRegister({ label = 'Portes', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Gérer les portes verrouillables (groupes, accès)', true)
    W:ExtMigrate(RES .. '_001_tables', 'Portes : groupes et portes', {
        [[CREATE TABLE IF NOT EXISTS wb_portes_groups (id INT NOT NULL AUTO_INCREMENT, label VARCHAR(40) NOT NULL, access TEXT NULL, def_locked TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
        [[CREATE TABLE IF NOT EXISTS wb_portes_doors (id INT NOT NULL AUTO_INCREMENT, grp INT NOT NULL, model BIGINT NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, locked TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id), KEY k_grp (grp))]],
    })
    W:ExtModule({
        id = RES, label = 'Portes', icon = 'lock', perm = PERM, hint = 'Portes verrouillables par groupe',
        doc = "## Portes\n**Le plus rapide (staff)** : maintiens **ALT**, les portes autour de toi s'entourent en jaune ; clique sur une porte, choisis qui garde l'accès (entreprises, gangs, avec recherche) et valide. Les deux battants d'une double porte sont pris ensemble.\n\nN'importe quelle porte du jeu peut être verrouillée. On crée un **groupe** (ex. « Commissariat »), on lui ajoute des portes en les **visant** (E), et on coche qui peut l'ouvrir : des entreprises, des gangs, ou tout le monde. Le **staff en service** ouvre toujours.\n\nEn jeu : menu staff **F10 › Builder › Portes** (puis Entrée), ou la commande **/portes**. Les joueurs autorisés ouvrent / verrouillent avec **E** devant la porte.",
        tabs = { { id = 'list', label = 'Groupes', icon = 'lock', build = function()
            local rows = {}
            for id, g in pairs(groups) do
                local n = 0
                for _, d in pairs(doors) do if d.grp == id then n = n + 1 end end
                rows[#rows + 1] = { label = g.label, doors = n, access = #g.access > 0 and table.concat(g.access, ', ') or 'staff seulement', def = g.def_locked == 1 and 'Verrouillée' or 'Ouverte' }
            end
            return { { type = 'notice', level = 'info', text = 'Les groupes se créent et se modifient en jeu : F10 › Builder › Portes, ou /portes.' },
                { type = 'table', id = 'grp', title = 'Groupes de portes', rows = rows, empty = 'Aucun groupe.', columns = { { k = 'label', label = 'Groupe' }, { k = 'doors', label = 'Portes' }, { k = 'access', label = 'Accès' }, { k = 'def', label = 'Par défaut' } } } }
        end } },
    })
    W:RegisterBuilder({ id = 'portes', label = 'Portes', icon = 'lock', points = { { id = 'manage', label = 'Gérer les portes (groupes, accès, ajouter / retirer)' } } },
        function(src) return openManage(src) end)
    load()
    push()
end
local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^1[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) end
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
