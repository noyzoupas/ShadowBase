-- Munitions en haut à droite (même style que les scores de territoire) : remplace l'affichage de base du jeu (icône d'arme + munitions).
-- Réglage : Panel › HUD › « Munitions en haut à droite ».
local G = PBG
local last = ''
local function enabled()
    local h = G.cfg and G.cfg.hud
    return G.begun and h and h.enabled ~= false and h.show_ammo ~= false
end
G.frameHooks = G.frameHooks or {}
table.insert(G.frameHooks, function()
    if enabled() then HideHudComponentThisFrame(2) return true end   -- icône d'arme et munitions du jeu
    return false
end)
CreateThread(function()
    while true do
        if not enabled() then
            if last ~= '' then last = '' G.send('ammo', { show = false }) end
            Wait(500)
        else
            local ped = PlayerPedId()
            local okw, w = GetCurrentPedWeapon(ped, true)
            local d
            if okw and w and w ~= 0 and w ~= GetHashKey('WEAPON_UNARMED') and not IsEntityDead(ped) then
                local total = GetAmmoInPedWeapon(ped, w)
                local cmax = GetMaxAmmoInClip(ped, w, true)
                if cmax and cmax > 0 then
                    local okc, inClip = GetAmmoInClip(ped, w)
                    inClip = okc and inClip or 0
                    d = { show = true, clip = inClip, reserve = math.max(0, total - inClip), max = cmax }
                elseif total and total > 0 then d = { show = true, clip = total, reserve = nil, max = total } end   -- armes jetées : seulement le nombre
            end
            local key = d and ('%d/%s/%d'):format(d.clip, tostring(d.reserve), d.max) or ''
            if key ~= last then last = key G.send('ammo', d or { show = false }) end
            Wait(d and 80 or 250)
        end
    end
end)
