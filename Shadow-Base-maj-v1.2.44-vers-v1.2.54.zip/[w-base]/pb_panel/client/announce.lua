-- Annonces plein écran : le serveur envoie le contenu, l'interface (web/game/announce.js) dessine le grand bandeau.
local G = PBG
RegisterNetEvent('pb:g:ann', function(j)
    local d = G.decode(j)
    if type(d) ~= 'table' or not d.text then return end
    G.send('announce.show', d)
    if d.sound then PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', true) end
end)
