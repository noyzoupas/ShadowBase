-- Territoires : invite E dans une zone, couleur de la zone sur la carte, ré-utilise la barre de progression des activités.
local G = PBG
local zones, owners, me, blips = {}, {}, nil, {}
local polys = {}   -- contours dessinés au Builder : { [id] = { {x, y}, … } }
local active = false
local exempt = false
local peace = true   -- réglage « tirs interdits » envoyé par le serveur
local bats = {}   -- batailles de zone en cours, par zone (envoyées par le serveur) : points de contrôle à dessiner + tableau des scores
-- zone en guerre = bataille de zone OU guerre planifiée (client/wars.lua) : tirs libres pour tout le monde, zone rouge sur la carte
local function anyWar(z) return z ~= nil and (bats[z.id] ~= nil or (G.plannedWar ~= nil and G.plannedWar.zid == z.id)) end
-- point dans un polygone (contour de la zone) ; sinon cercle
local function inPoly(x, y, poly)
    local inside, j = false, #poly
    for i = 1, #poly do
        local xi, yi, xj, yj = poly[i][1], poly[i][2], poly[j][1], poly[j][2]
        if ((yi > y) ~= (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1e-9) + xi) then inside = not inside end
        j = i
    end
    return inside
end
G.InPoly = inPoly
local function inZoneXY(z, x, y)
    local p = polys[z.id]
    if p and #p >= 3 then return inPoly(x, y, p) end
    local dx, dy = x - (z.x + 0.0), y - (z.y + 0.0)
    return math.sqrt(dx * dx + dy * dy) <= (tonumber(z.radius) or 30) + 0.0
end
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local t = c.territories or {}
    polys = type(t.polys) == 'table' and t.polys or {}
    zones = t.enabled == false and {} or (t.zones or {})
    G.terrBlips = t.show_blips ~= false
    G.terrAll = t.show_all ~= false
    G.redrawTerr()
end
-- Couleurs de blip du jeu (approximations RGB) : la carte du jeu ne sait afficher que cette palette, on prend la plus proche de la couleur du gang.
local PALETTE = {
    { 1, 224, 50, 50 }, { 2, 114, 204, 114 }, { 3, 93, 182, 229 }, { 5, 238, 198, 80 }, { 7, 156, 110, 175 }, { 8, 255, 123, 196 }, { 17, 234, 143, 53 },
    { 25, 59, 150, 60 }, { 29, 37, 102, 159 }, { 38, 36, 98, 165 }, { 40, 77, 77, 77 }, { 4, 240, 240, 240 }, { 39, 170, 170, 170 }, { 43, 140, 230, 200 }, { 46, 238, 220, 120 }, { 49, 155, 40, 40 }, { 54, 20, 120, 120 },
}
-- couleur exacte d'un repère (0xRRGGBBAA, acceptée par SetBlipColour en plus des couleurs numérotées) : la vraie couleur du gang
function G.blipRgba(hex)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 4 end
    return (tonumber(r, 16) << 24) | (tonumber(g, 16) << 16) | (tonumber(b, 16) << 8) | 0xFF
end
function G.blipColourFor(hex)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 4 end
    r, g, b = tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
    local best, bd = 4, 1e9
    for _, p in ipairs(PALETTE) do
        local d = (p[2] - r) ^ 2 + (p[3] - g) ^ 2 + (p[4] - b) ^ 2
        if d < bd then best, bd = p[1], d end
    end
    return best
end
-- zones visibles sur la carte : membres d'un groupe illégal, et staff qui gère les territoires (pour voir ce qu'il vient de créer)
-- couleur d'une zone libre (sur la carte et au sol) : bleu ; une zone tenue prend la couleur du gang
local FREE_HEX = '#4a9fe8'
local staffSee = false
local function canSee() return G.terrBlips and (G.terrAll or (me and me ~= '') or staffSee) end
-- zones pour la carte du serveur (client/atlas.lua)
function G.terrZoneList()
    if not canSee() then return {} end
    local out = {}
    for _, z in ipairs(zones) do
        local o = owners[z.id]
        local p = polys[z.id]
        out[#out + 1] = { x = z.x, y = z.y, r = tonumber(z.radius) or 30, poly = (p and #p >= 3) and p or nil, label = z.label, color = o and o.color or FREE_HEX, owner = o and o.label or nil }
    end
    return out
end
-- carte du serveur : montrer / cacher les zones et leurs repères
function G.terrShow(on)
    for _, e in ipairs(blips) do if DoesBlipExist(e[1]) then SetBlipDisplay(e[1], on and e[2] or 0) end end
end
-- Zone dessinée sur la carte du jeu : le jeu ne sait pas tracer un polygone, on le remplit de bandes horizontales
-- (une bande = un rectangle par suite de cases dans le contour). Résultat : la vraie forme de la zone, pas un grand cercle.
local function polyStrips(p)
    local x0, y0, x1, y1 = 1e9, 1e9, -1e9, -1e9
    for _, q in ipairs(p) do x0, y0, x1, y1 = math.min(x0, q[1]), math.min(y0, q[2]), math.max(x1, q[1]), math.max(y1, q[2]) end
    local step = math.max(3.0, math.max(x1 - x0, y1 - y0) / 60)
    local out
    repeat
        out = {}
        for yy = y0 + step / 2, y1, step do
            local run
            for xx = x0 + step / 2, x1 + step, step do
                if xx <= x1 and inPoly(xx, yy, p) then run = run or xx
                elseif run then out[#out + 1] = { (run + xx - step) / 2, yy, xx - run, step } run = nil end
            end
        end
        step = step * 1.4
    until #out <= 220
    return out
end
-- (v1.2.54) zones et repères seulement sur la grande carte : 3 = carte du jeu sans la mini-carte
local MAP_ONLY = 3
local function mapOnly(b)
    SetBlipDisplay(b, MAP_ONLY)
    if PBBlips.reg[b] then PBBlips.reg[b].disp = MAP_ONLY end   -- la passe de contrôle et la carte du serveur remettent ce réglage, pas 2
    blips[#blips + 1] = { b, MAP_ONLY }
end
local function addArea(x, y, w, hgt, colour, alpha, flash)
    local b = AddBlipForArea(x + 0.0, y + 0.0, 0.0, w + 0.0, hgt + 0.0)
    SetBlipColour(b, colour) SetBlipAlpha(b, alpha) SetBlipRotation(b, 0)
    if flash then SetBlipFlashes(b, true) end
    mapOnly(b)
end
function G.redrawTerr()
    for _, e in ipairs(blips) do if DoesBlipExist(e[1]) then RemoveBlip(e[1]) end end
    blips = {}
    local see = canSee()
    for _, z in ipairs(zones) do
        local war = anyWar(z)
        if see or war then
            local o = owners[z.id]
            local colour = war and 1 or G.blipRgba(o and o.color or FREE_HEX)   -- libre : bleu ; tenue : la couleur exacte du gang
            local alpha = war and 150 or (o and 150 or 120)
            local p = polys[z.id]
            if p and #p >= 3 then
                p.strips = p.strips or polyStrips(p)
                for _, s in ipairs(p.strips) do addArea(s[1], s[2], s[3], s[4], colour, alpha, war) end
            else
                local b = AddBlipForRadius(z.x + 0.0, z.y + 0.0, z.z + 0.0, (tonumber(z.radius) or 30) + 0.0)
                SetBlipColour(b, colour) SetBlipAlpha(b, alpha)
                if war then SetBlipFlashes(b, true) end
                mapOnly(b)
            end
            -- petit repère au centre avec le nom de la zone et du gang qui la tient (visible sur la carte du jeu)
            local c = AddBlipForCoord(z.x + 0.0, z.y + 0.0, z.z + 0.0)
            SetBlipSprite(c, 84) SetBlipColour(c, colour) SetBlipScale(c, 0.7) SetBlipAsShortRange(c, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName((war and 'GUERRE — ' or '') .. tostring(z.label) .. (o and (' — ' .. tostring(o.label)) or ' — libre')) EndTextCommandSetBlipName(c)
            mapOnly(c)
        end
    end
end
RegisterNetEvent('pb:g:terr:owners', function(j) local d = G.decode(j) if d then owners = d.owners or {} me = d.me peace = d.peace ~= false exempt = d.exempt == true staffSee = d.staff == true G.redrawTerr() if G.terrRefresh then G.terrRefresh() end end end)
-- Contour au sol : le tracé est découpé tous les 2,5 m et chaque morceau suit la hauteur réelle du sol (calculée à partir de la
-- hauteur du coin posé au Builder, gardée seulement quand le sol est chargé). On dessine un trait au sol et un voile lumineux de 2 m.
local function edgePoints(p)
    if p.seg then return p.seg end
    local seg = {}
    for i = 1, #p do
        local a, b = p[i], p[i % #p + 1]
        local dx, dy = b[1] - a[1], b[2] - a[2]
        local n = math.max(1, math.ceil(math.sqrt(dx * dx + dy * dy) / 2.5))
        local az, bz = tonumber(a[3]), tonumber(b[3])
        for k = 0, n - 1 do
            local t = k / n
            seg[#seg + 1] = { a[1] + dx * t, a[2] + dy * t, (az and bz) and (az + (bz - az) * t) or nil }
        end
    end
    p.seg, p.sz = seg, {}
    return seg
end
local function segZ(p, k, fallback)
    local q = p.seg[k]
    if p.sz[k] then return p.sz[k] end
    local z0 = (q[3] and q[3] ~= 0) and q[3] or fallback
    local ok, gz = GetGroundZFor_3dCoord(q[1] + 0.0, q[2] + 0.0, z0 + 4.0, false)
    if ok and gz ~= 0.0 then p.sz[k] = gz + 0.08 return p.sz[k] end
    return z0 + 0.08
end
local WALL = 2.0
CreateThread(function()
    while true do
        if not G.begun or #zones == 0 then Wait(1000) else
            local c = GetEntityCoords(PlayerPedId())
            local any = false
            for _, z in ipairs(zones) do
                local zx, zy, zz = z.x + 0.0, z.y + 0.0, z.z + 0.0
                local rr = (tonumber(z.radius) or 30) + 0.0
                if #(vector2(c.x, c.y) - vector2(zx, zy)) < rr + 120.0 then
                    any = true
                    local o = owners[z.id]
                    local war = anyWar(z)
                    local r, g, b = 93, 182, 229   -- libre : bleu
                    local hex = war and '#ff4d5e' or (o and (o.color or ''))
                    if type(hex) == 'string' then local rr2, gg, bb = hex:match('^#(%x%x)(%x%x)(%x%x)$') if rr2 then r, g, b = tonumber(rr2, 16), tonumber(gg, 16), tonumber(bb, 16) end end
                    local p = polys[z.id]
                    if p and #p >= 3 then
                        local seg = edgePoints(p)
                        local n = #seg
                        for k = 1, n do
                            local a, bq = seg[k], seg[k % n + 1]
                            local mx, my = (a[1] + bq[1]) / 2 - c.x, (a[2] + bq[2]) / 2 - c.y
                            if mx * mx + my * my < 10000.0 then   -- seulement les 100 m autour du joueur
                                local az, bz = segZ(p, k, c.z - 1.0), segZ(p, k % n + 1, c.z - 1.0)
                                local ax, ay, bx, by = a[1] + 0.0, a[2] + 0.0, bq[1] + 0.0, bq[2] + 0.0
                                DrawLine(ax, ay, az, bx, by, bz, r, g, b, 230)
                                DrawLine(ax, ay, az + WALL, bx, by, bz + WALL, r, g, b, 110)
                                -- voile visible des deux côtés
                                DrawPoly(ax, ay, az, bx, by, bz, bx, by, bz + WALL, r, g, b, 38)
                                DrawPoly(ax, ay, az, bx, by, bz + WALL, ax, ay, az + WALL, r, g, b, 38)
                                DrawPoly(bx, by, bz + WALL, bx, by, bz, ax, ay, az, r, g, b, 38)
                                DrawPoly(ax, ay, az + WALL, bx, by, bz + WALL, ax, ay, az, r, g, b, 38)
                            end
                        end
                    else
                        G.Zone(zx, zy, zz - 0.95, r, g, b, rr)
                    end
                end
            end
            Wait(any and 0 or 500)
        end
    end
end)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #zones == 0 or not me or active or G.Menu.IsOpen() then hide() Wait(700)
        else
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if inZoneXY(z, c.x, c.y) then hit = z break end end
            local o = hit and owners[hit.id]
            if hit and (not o or o.gang ~= me) then
                if anyWar(hit) then hide() Wait(400) goto continue end
                local txt = 'Attaquer : ' .. hit.label
                if shown ~= txt then shown = txt G.send('prompt', { show = true, key = 'E', text = txt }) end
                if IsControlJustPressed(0, 38) then hide() TriggerServerEvent('pb:g:terr:start', hit.id) end
                Wait(0)
            else hide() Wait(400) end
        end
        ::continue::
    end
end)

-- Territoires : petit bandeau (comme le braquage) tant qu'on est dans la zone, annonce à l'entrée, scores en bas à droite pendant une guerre,
-- tirs interdits dans une zone possédée hors guerre (sauf pour le gang propriétaire).
local cur = nil
local lastAnn = {}
local function warHere(z) return z and bats[z.id] or nil end
local info = nil   -- texte affiché en bas de l'écran tant qu'on est dans la zone
local function buildInfo()
    if not cur then info = nil return end
    local o = owners[cur.id]
    local war = anyWar(cur)
    info = { zone = cur.label, war = war, owner = o and o.label or nil, color = o and o.color or nil, mine = o ~= nil and o.gang == me, peace = peace and not exempt and o ~= nil and not war }
end
local function refreshHere()
    buildInfo()
    -- bandeau de guerre en haut de l'écran (web/game/territory.js), seulement dans la zone en guerre
    local war = cur and warHere(cur)
    if war then
        G.send('terr.war', { on = true, zone = war.zone, rows = war.rows or {}, target = war.target, left = math.max(0, (tonumber(war.left) or 0) - (GetGameTimer() - (war.recv or 0)) / 1000) })
    else G.send('terr.war', { on = false }) end
end
G.terrRefresh = refreshHere
-- zone où se trouve le joueur (contour dessiné, sinon cercle) : servira aussi au tableau des guerres planifiées
function G.terrInZone(zid)
    if not zid then return false end
    local c = GetEntityCoords(PlayerPedId())
    for _, z in ipairs(zones) do if z.id == zid then return inZoneXY(z, c.x, c.y) end end
    return nil
end
CreateThread(function()
    while true do
        Wait(400)
        if G.begun and #zones > 0 then
            local c = GetEntityCoords(PlayerPedId())
            local hit
            for _, z in ipairs(zones) do if inZoneXY(z, c.x, c.y) then hit = z break end end
            local id, old = hit and hit.id or nil, cur and cur.id or nil
            if id ~= old then
                cur = hit
                refreshHere()
            else buildInfo() end   -- toujours à jour (zones reçues à nouveau, propriétaire changé…) : le texte ne disparaît plus
        elseif cur then cur = nil refreshHere() else Wait(800) end
    end
end)
-- texte propre en bas de l'écran (natives du jeu, aucune interface) : territoire hors guerre (en guerre : bandeau en haut)
local function drawLine(text, y, scale, r, g, b, font)
    SetTextFont(font or 4) SetTextScale(0.0, scale) SetTextColour(r, g, b, 235) SetTextCentre(true)
    SetTextDropShadow(2, 0, 0, 0, 220) SetTextOutline()
    BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.5, y)
end
local function rgbOf(hex, d)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return d[1], d[2], d[3] end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
CreateThread(function()
    while true do
        if not info or info.war or not G.begun or IsPauseMenuActive() then Wait(300) else
            Wait(0)
            local y = 0.885
            do
                local r, g, b = rgbOf(info.color, { 223, 226, 231 })
                drawLine(('TERRITOIRE  ·  %s'):format(info.zone), y, 0.6, 255, 255, 255)
                if info.owner then
                    drawLine((info.mine and 'Territoire de ton gang  ·  toi seul peux tirer ici' or ('Territoire de %s%s'):format(info.owner, info.peace and '  ·  tirs interdits' or '')), y + 0.038, 0.38, r, g, b)
                else drawLine('Territoire libre', y + 0.038, 0.38, 200, 204, 212) end
            end
        end
    end
end)
-- tirs interdits : zone possédée, pas de guerre ici, et on n'est pas du gang propriétaire
CreateThread(function()
    while true do
        local o = cur and owners[cur.id]
        if peace and not exempt and o and not anyWar(cur) and o.gang ~= me and G.begun then
            Wait(0)
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true) DisableControlAction(0, 257, true) DisableControlAction(0, 69, true) DisableControlAction(0, 70, true)
            DisableControlAction(0, 92, true) DisableControlAction(0, 114, true) DisableControlAction(0, 331, true)
        else Wait(300) end
    end
end)

RegisterNetEvent('pb:g:zone:banner', function(j) local d = G.decode(j) if d then G.send('zone.banner', d) end end)

-- Builder › Créer › Territoire de gang : on marche jusqu'à chaque coin et on appuie sur Entrée ; la zone se dessine au fur et à mesure.
-- Retour arrière : retirer le dernier coin · E : terminer (3 coins minimum) · X : annuler. Ensuite : nom et objet offert toutes les 5 h.
local drawing = false
function G.TerrDraw(send, rewards)
    if drawing then return end
    drawing = true
    G.Menu.Suspend()
    local pts = {}
    local function help()
        G.send('prompt', { show = true, free = true, key = '↵', text = ('Coin %d : Entrée pour l\'ajouter ici  ·  Retour arrière : retirer  ·  E : terminer (3 coins min.)  ·  X : annuler'):format(#pts + 1) })
    end
    help()
    CreateThread(function()
        local finished = false
        while drawing do
            Wait(0)
            DisableControlAction(0, 200, true) DisableControlAction(0, 199, true)
            local c = GetEntityCoords(PlayerPedId())
            -- traits déjà posés, puis le trait vers le joueur (et le retour au premier coin)
            for i = 1, #pts - 1 do DrawLine(pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z, 255, 255, 255, 230) end
            for _, q in ipairs(pts) do DrawMarker(28, q.x, q.y, q.z, 0, 0, 0, 0, 0, 0, 0.35, 0.35, 0.35, 255, 255, 255, 200, false, false, 2, false, nil, nil, false) end
            local gz = c.z - 0.9
            if #pts > 0 then
                local l = pts[#pts]
                DrawLine(l.x, l.y, l.z, c.x, c.y, gz, 255, 255, 255, 140)
                if #pts >= 2 then DrawLine(c.x, c.y, gz, pts[1].x, pts[1].y, pts[1].z, 255, 255, 255, 70) end
            end
            if IsDisabledControlJustPressed(0, 191) or IsControlJustPressed(0, 191) then
                pts[#pts + 1] = { x = c.x, y = c.y, z = gz }
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                if #pts >= 40 then finished = true drawing = false end
                help()
            elseif IsDisabledControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                if #pts > 0 then table.remove(pts) help() end
            elseif IsControlJustPressed(0, 38) then
                if #pts >= 3 then finished = true drawing = false
                else G.send('notify', { type = 'warn', title = 'Territoire', text = 'Pose au moins 3 coins.' }) end
            elseif IsControlJustPressed(0, 73) then
                drawing = false
            end
        end
        G.send('prompt', { show = false })
        if not finished then G.Menu.Resume() return end
        -- fin du tracé : nom de la zone et objet offert au groupe qui la tient (toutes les 5 h)
        local st = { name = '', item = nil, qty = 1, hours = 5 }
        G.Menu.Resume()
        G.Menu.Open({ id = 'b.terr.new', title = 'Nouveau territoire', subtitle = #pts .. ' coins', refreshOnReturn = true, build = function() return {
            { type = 'input', label = 'Nom de la zone', icon = 'pen', value = st.name ~= '' and st.name or nil, prompt = 'Nom de la zone (ex. Grove Street)', maxlen = 40, onChange = function(_, v) st.name = tostring(v or '') end },
            G.TerrRewardItem(rewards, 'b.terr.new', st),
            { type = 'button', label = 'Créer la zone', icon = 'check', onSelect = function()
                if #st.name < 2 then G.send('notify', { type = 'warn', title = 'Territoire', text = 'Donne un nom à la zone.' }) return end
                local poly = {}
                for _, q in ipairs(pts) do poly[#poly + 1] = { x = q.x, y = q.y, z = q.z } end
                G.Menu.Close()
                send('b_terr', { label = st.name, poly = poly, item = st.item and st.item[1] or '', qty = st.qty, hours = st.hours })
            end },
            { type = 'button', label = 'Annuler', icon = 'x', onSelect = function() G.Menu.Close() end },
        } end })
    end)
end

-- (v1.2.45) objet offert par une zone : n'importe quel objet de l'inventaire (recherche, catégories), puis quantité et fréquence.
-- st = { item = { nom, libellé, … } | nil, qty, hours } ; parentId = menu où revenir après le choix
function G.TerrRewardItem(rewards, parentId, st)
    local right = st.item and (st.qty .. ' × ' .. st.item[2] .. ' · ' .. st.hours .. ' h') or 'Aucun'
    return { type = 'submenu', label = 'Objet offert', icon = 'box', right = right,
        description = "Déposé dans le coffre du groupe qui tient la zone. Choisis l'objet (recherche ou catégories), puis la quantité et toutes les combien d'heures.",
        submenu = { id = parentId .. '.reward', title = 'Objet offert', refreshOnReturn = true, build = function()
            local items = {
                { type = 'submenu', label = 'Choisir l\'objet', icon = 'search', right = st.item and st.item[2] or nil, submenu = G.ItemPicker and G.ItemPicker(rewards, { id = parentId .. '.pick', title = 'Objet offert', subtitle = 'Recherche ou catégorie',
                    onPick = function(it) st.item = it G.MenuBackTo(parentId .. '.reward') if G.Menu.Refresh then G.Menu.Refresh() end end }) or nil },
                { label = 'Quantité', icon = 'plus', right = tostring(st.qty), description = 'Combien à chaque fois (1 à 50).', onSelect = function()
                    local v = tonumber(G.Menu.Ask('Quantité offerte (1 à 50)', tostring(st.qty), 3))
                    if v then st.qty = math.max(1, math.min(50, math.floor(v))) if G.Menu.Refresh then G.Menu.Refresh() end end
                end },
                { label = 'Toutes les (heures)', icon = 'clock', right = st.hours .. ' h', description = 'Fréquence du don (1 à 168 h).', onSelect = function()
                    local v = tonumber(G.Menu.Ask('Toutes les combien d\'heures (1 à 168)', tostring(st.hours), 3))
                    if v then st.hours = math.max(1, math.min(168, math.floor(v))) if G.Menu.Refresh then G.Menu.Refresh() end end
                end },
            }
            if st.item then items[#items + 1] = { label = 'Aucun objet', icon = 'x', description = 'La zone ne donne plus rien.', onSelect = function() st.item = nil G.Menu.Stack:Back() end } end
            if st.onSave then items[#items + 1] = { type = 'button', label = 'Enregistrer', icon = 'check', onSelect = function() st.onSave() end } end
            return items
        end } }
end

-- Bataille de zone : tableau des scores (même carte que les guerres) + colonnes lumineuses sur chaque point de contrôle
local batBlip
RegisterNetEvent('pb:g:terr:bat', function(j)
    local d = G.decode(j) or {}
    if batBlip and DoesBlipExist(batBlip) then RemoveBlip(batBlip) end
    batBlip = nil
    if not d.zid then return end
    local was = bats[d.zid] ~= nil
    if d.on then d.recv = GetGameTimer() bats[d.zid] = d else bats[d.zid] = nil end
    if G.terrRefresh then G.terrRefresh() end
    -- la zone en guerre clignote en rouge sur la carte, avec sa vraie forme (redessinée seulement au début et à la fin)
    if (bats[d.zid] ~= nil) ~= was then G.redrawTerr() end
end)
local function rgb(hex, d)
    local r, g, b = tostring(hex or ''):match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return d[1], d[2], d[3] end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
CreateThread(function()
    while true do
        if not next(bats) then Wait(800) else
            local pc = GetEntityCoords(PlayerPedId())
            local any = false
            local all = {}
            for _, bt in pairs(bats) do for _, cp in ipairs(bt.cps or {}) do all[#all + 1] = cp end end
            for _, cp in ipairs(all) do
                local x, y = cp.x + 0.0, cp.y + 0.0
                if #(pc - vector3(x, y, pc.z)) < 150.0 then
                    any = true
                    local gz = G.Ground and G.Ground(x, y, pc.z) or (cp.z + 0.0)
                    local r, g, b = rgb(cp.color, { 220, 224, 232 })
                    DrawMarker(1, x, y, gz - 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 12.0, 12.0, 1.2, r, g, b, 90, false, false, 2, false, nil, nil, false)
                    -- anneau de progression d'un gang qui prend le point : colonne plus haute et de la couleur de l'attaquant
                    if cp.by and (cp.p or 0) > 0 then
                        local r2, g2, b2 = rgb(cp.by, { 255, 255, 255 })
                        DrawMarker(1, x, y, gz - 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 12.0 * cp.p, 12.0 * cp.p, 6.0, r2, g2, b2, 140, false, false, 2, false, nil, nil, false)
                    end
                end
            end
            Wait(any and 0 or 500)
        end
    end
end)
AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    if batBlip and DoesBlipExist(batBlip) then RemoveBlip(batBlip) end
    for _, e in ipairs(blips) do if DoesBlipExist(e[1]) then RemoveBlip(e[1]) end end
end)
