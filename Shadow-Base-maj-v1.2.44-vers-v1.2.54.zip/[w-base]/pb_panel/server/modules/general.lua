-- Module 1 : Configuration générale (identité, server.cfg, slots, réseau, secrets, langue, ressources à démarrer,
-- messages, annonces, maintenance, validation, historique, sauvegarde des configurations).

local B, Form, P, FC, F = PB.B, PB.Form, PB.Perm, PB.FileCfg, PB.Files

P.Register('general.edit', 'Modifier la configuration générale', 'general')
P.Register('general.srvcfg', 'Modifier le server.cfg brut et les secrets', 'general', true)
P.Register('general.maintenance', 'Gérer le mode maintenance', 'general')
P.Register('general.bypass', 'Se connecter pendant la maintenance', 'general')
P.Register('general.announce', 'Envoyer des annonces', 'general')
P.Register('general.restore', 'Restaurer ou importer des configurations', 'general', true)

local OPT_ONOFF = { { 'on', 'Activé' }, { 'off', 'Désactivé' } }

-- Champ de validation : image envoyée depuis l'interface (data URL)
-- (traité dans PB.Validate via le type 'image')

-- Identité ---------------------------------------------------------------------------------------------------------------
local identity = Form.Cfg({
    ns = 'general', id = 'identity', title = 'Identité du serveur', perm = 'general.edit', cols = 2,
    desc = "Un seul endroit : le nom, le slogan, les couleurs et le logo changent tout de suite sur le panel (même ouvert) et sur toutes les interfaces en jeu (menus, magasins, banque, garage, boutique, bienvenue, messages Discord).",
    fields = {
        { k = 'server_name', type = 'text', label = 'Nom du serveur', default = 'Shadow Base', maxlen = 48, required = true },
        { k = 'tagline', type = 'text', label = 'Slogan', default = '', maxlen = 80 },
        { k = 'color_primary', type = 'color', label = 'Couleur principale', default = '#dfe2e7' },
        { k = 'color_secondary', type = 'color', label = 'Couleur secondaire', default = '#aab0bb' },
        { k = 'server_logo', type = 'asset', label = 'Logo du serveur en jeu (depuis mon PC)', default = '', maxw = 600, maxh = 240, hint = 'Affiché dans les menus, les notifications et l\'écran de bienvenue.' },
        { k = 'server_banner', type = 'asset', label = 'Bannière du serveur en jeu (depuis mon PC)', default = '', wide = true, maxw = 1280, maxh = 360, hint = "Affichée en haut de l'écran de bienvenue." },
        { k = 'logo_data', type = 'image', label = 'Logo (fichier)', default = '', hint = "PNG, JPEG ou WebP, 400 Ko maximum. Affiché en grand en haut des onglets.", maxbytes = 400000 },
        { k = 'logo_url', type = 'text', label = 'Logo (adresse https)', default = '', maxlen = 300, pattern = '^https://[^%s]+$', hint = 'Utilisé seulement si aucun fichier n\'est envoyé.' },
    },
})

PB.Action('general.logo.clear', 'general.edit', function(ctx)
    PB.Cfg.Set('general', 'logo_data', '', ctx.actor, 'Logo retiré')
    ctx.audit('config', 'logo.retirer', 'general.logo_data')
    ctx.toast = 'Logo retiré.'
    return true
end)

-- Thèmes de fête ------------------------------------------------------------------------------------------------------------------
local season = Form.Cfg({
    ns = 'general', id = 'season', title = 'Thème de fête', perm = 'general.edit', cols = 2,
    desc = "Halloween ou Noël : couleurs, ambiance et décor du panel et des interfaces en jeu. Mode automatique : Halloween du 15 octobre au 1er novembre, Noël du 1er décembre au 2 janvier.",
    fields = {
        { k = 'season', type = 'select', label = 'Fête', default = 'off', opts = { { 'off', 'Aucune' }, { 'auto', 'Automatique selon la date' }, { 'halloween', 'Halloween (toujours)' }, { 'noel', 'Noël (toujours)' } } },
        { k = 'season_game', type = 'toggle', label = 'Appliquer aux interfaces des joueurs', default = true, hint = "Menus, magasins, banque, garage, boutique : couleurs et décor de la fête." },
        { k = 'season_decor', type = 'toggle', label = 'Décor animé (neige, chauves-souris, guirlande)', default = true, hint = 'Désactivé automatiquement si le joueur a coupé les animations.' },
    },
})

-- Server.cfg : liste du serveur ----------------------------------------------------------------------------------------------------
local listing = Form.Srv({
    id = 'listing', title = 'Liste des serveurs', perm = 'general.edit', live = true, restart = 'Visible dans la liste après redémarrage du serveur.',
    desc = 'Ce que voient les joueurs dans la liste FiveM.',
    fields = {
        { k = 'sv_projectName', mode = 'plain', type = 'text', label = 'Nom du projet', maxlen = 64, default = '' },
        { k = 'sv_projectDesc', mode = 'plain', type = 'text', label = 'Description courte', maxlen = 128, default = '' },
        { k = 'sv_hostname', mode = 'plain', type = 'text', label = 'Nom affiché (hostname)', maxlen = 64, default = '' },
        { k = 'tags', mode = 'sets', type = 'text', label = 'Tags', maxlen = 128, default = '', hint = 'Séparés par des virgules : roleplay, français, serieux' },
        { k = 'locale', mode = 'sets', type = 'text', label = 'Langue du serveur', maxlen = 10, default = 'fr-FR', pattern = '^%a%a%-?%a*$', hint = 'Ex. fr-FR, en-US' },
        { k = 'banner_detail', mode = 'sets', type = 'text', label = 'Bannière (page du serveur)', maxlen = 300, optional = true, pattern = '^https://[^%s]+$', default = '' },
        { k = 'banner_connecting', mode = 'sets', type = 'text', label = 'Bannière (connexion)', maxlen = 300, optional = true, pattern = '^https://[^%s]+$', default = '' },
    },
})

local slots = Form.Srv({
    id = 'slots', title = 'Slots et FXServer', perm = 'general.edit', restart = 'Redémarrage du serveur nécessaire.',
    fields = {
        { k = 'sv_maxclients', mode = 'plain', type = 'number', label = 'Slots (joueurs maximum)', min = 1, max = 2048, default = 48, hint = 'Plus de 48 slots demande OneSync activé.' },
        { k = 'onesync', mode = 'set', type = 'select', label = 'OneSync', opts = { { 'on', 'Activé' }, { 'off', 'Désactivé' }, { 'legacy', 'Legacy' } }, default = 'on' },
        { k = 'sv_enforceGameBuild', mode = 'plain', type = 'select', label = 'Version du jeu imposée', default = '3095',
          opts = { '2060', '2189', '2372', '2545', '2612', '2699', '2802', '2944', '3095', '3258', '3323', '3407', '3570' } },
        { k = 'sv_scriptHookAllowed', mode = 'plain', type = 'toggle', bool = '01', label = 'Autoriser ScriptHookV', default = false },
        { k = 'sv_pureLevel', mode = 'plain', type = 'select', label = 'Niveau de vérification des fichiers du jeu', opts = { { '0', '0 — désactivé' }, { '1', '1 — standard' }, { '2', '2 — strict' } }, default = '0' },
        { k = 'sv_filterRequestControl', mode = 'plain', type = 'select', label = 'Filtrage des demandes de contrôle d\'entité', opts = { { '0', '0 — aucun' }, { '1', '1' }, { '2', '2' }, { '3', '3' }, { '4', '4 — maximal' } }, default = '0' },
        { k = 'sv_requestParanoia', mode = 'plain', type = 'select', label = 'Paranoïa des requêtes', opts = { { '0', '0' }, { '1', '1' }, { '2', '2' }, { '3', '3' } }, default = '0' },
    },
})

local network = Form.Srv({
    id = 'network', title = 'Réseau et connexion', perm = 'general.srvcfg', restart = 'Redémarrage du serveur nécessaire.',
    desc = "Attention : une adresse d'écoute incorrecte empêche toute connexion. Garde l'accès à la console avant de modifier.",
    fields = {
        { k = 'endpoint_add_tcp', mode = 'plain', type = 'text', label = 'Écoute TCP', default = '0.0.0.0:30120', pattern = '^[%d%.]+:%d+$' },
        { k = 'endpoint_add_udp', mode = 'plain', type = 'text', label = 'Écoute UDP', default = '0.0.0.0:30120', pattern = '^[%d%.]+:%d+$' },
        { k = 'sv_endpointprivacy', mode = 'plain', type = 'toggle', label = "Masquer l'adresse IP des joueurs", default = true },
        { k = 'net_tcpConnLimit', mode = 'plain', type = 'number', label = 'Connexions TCP simultanées maximum', min = 1, max = 5000, default = 100 },
        { k = 'sv_listingIPOverride', mode = 'plain', type = 'text', label = 'Adresse IP annoncée', default = '', optional = true, pattern = '^[%d%.]+$' },
        { k = 'sv_forceIndirectListing', mode = 'plain', type = 'toggle', label = 'Annonce indirecte (derrière un proxy)', default = false },
    },
})

local keys = Form.Srv({
    id = 'keys', title = 'Clés et accès (secrets)', perm = 'general.srvcfg', restart = 'Redémarrage du serveur nécessaire.',
    desc = 'Les valeurs ne sont jamais renvoyées à ton navigateur : laisse un champ vide pour ne rien changer.',
    fields = {
        { k = 'sv_licenseKey', mode = 'plain', type = 'secret', label = 'Clé de licence Cfx.re' },
        { k = 'steam_webApiKey', mode = 'set', type = 'secret', label = 'Clé API Steam' },
        { k = 'rcon_password', mode = 'plain', type = 'secret', label = 'Mot de passe RCON' },
        { k = 'mysql_connection_string', mode = 'set', type = 'secret', label = 'Chaîne de connexion MySQL', hint = 'mysql://utilisateur:motdepasse@hôte/base' },
    },
})

-- Langue --------------------------------------------------------------------------------------------------------------------------
-- Configuration du panel lui-même (config.lua) -------------------------------------------------------------------------------------
local panelCfg = FC.Form({
    id = 'panelcfg', title = 'Démarrage du panel (config.lua)', perm = 'general.srvcfg', module = 'general',
    desc = "Ces réglages sont lus au démarrage : tape « restart pb_panel » dans la console du serveur après modification.",
    res = 'pb_panel', file = 'config.lua',
    fields = {
        { path = 'Config.OpenKey', type = 'text', label = "Touche d'ouverture", maxlen = 16 },
        { path = 'Config.OpenCommand', type = 'text', label = "Commande d'ouverture", maxlen = 24, pattern = '^[%w_]+$' },
        { path = 'Config.ServerPath', type = 'text', label = 'Dossier du serveur', maxlen = 200, hint = 'Laisse vide pour la détection automatique.' },
        { path = 'Config.Supervisor', type = 'select', label = 'Superviseur de redémarrage', opts = { { 'txadmin', 'txAdmin' }, { 'autre', 'Autre (systemd, pm2, Docker...)' }, { 'aucun', 'Aucun' } } },
    },
    after = function() return 'Tape « restart pb_panel » dans la console du serveur.' end,
})

-- Annonces et messages --------------------------------------------------------------------------------------------------------------
function PB.Announce(text, mode, target)
    mode = mode or 'both'
    text = PB.Sanitize(tostring(text), 400)
    if text == '' then return false end
    local prefix = PB.Cfg.Get('general', 'announce_prefix', 'Annonce')
    if mode == 'chat' or mode == 'both' or mode == 'all' then
        if PB.G and PB.G.ChatSystem then PB.G.ChatSystem(target or -1, prefix, text)
        else TriggerClientEvent('chat:addMessage', target or -1, { color = { 155, 140, 255 }, multiline = true, args = { prefix, text } }) end
    end
    if (mode == 'screen' or mode == 'all') and PB.G and PB.G.Announce and PB.G.Announce.Send then
        local ok = PB.G.Announce.Send({ title = prefix, text = text, style = 'info', target = target or -1, author = '' , sound = true })
        if ok then return true end
    end
    if mode == 'ticker' or mode == 'both' then
        -- Annonce à l'écran : carte avec la bannière du serveur (réglage Interface › Notifications) ; sans interface de jeu, l'ancien fil d'actualité du jeu.
        if PB.G and PB.G.Notify and PB.Cfg.Get('notify', 'announce_card', true) ~= false then
            PB.G.Notify(target or -1, { type = 'info', title = prefix, text = text, kind = 'announce', duration = 9000 })
        else TriggerClientEvent('pb:announce', target or -1, text) end
    end
    return true
end

local welcome = Form.Cfg({
    ns = 'general', id = 'welcome', title = 'Message de bienvenue', perm = 'general.edit',
    desc = 'Envoyé au joueur quelques secondes après son arrivée.',
    fields = {
        { k = 'welcome_on', type = 'toggle', label = 'Activer', default = false },
        { k = 'welcome_msg', type = 'area', label = 'Message', default = 'Bienvenue sur le serveur !', maxlen = 400 },
        { k = 'welcome_mode', type = 'select', label = 'Affichage', default = 'chat', opts = { { 'chat', 'Dans le chat' }, { 'ticker', 'Notification à l\'écran' }, { 'both', 'Les deux' } } },
        { k = 'welcome_delay', type = 'number', label = "Délai après l'arrivée (secondes)", min = 0, max = 120, default = 15 },
    },
})

local announce = Form.Cfg({
    ns = 'general', id = 'announce', title = 'Annonces automatiques', perm = 'general.announce',
    desc = 'Les messages défilent dans l\'ordre, un à chaque intervalle.',
    fields = {
        { k = 'announce_on', type = 'toggle', label = 'Activer', default = false },
        { k = 'announce_interval', type = 'number', label = 'Intervalle (minutes)', min = 1, max = 1440, default = 10 },
        { k = 'announce_mode', type = 'select', label = 'Affichage', default = 'chat', opts = { { 'chat', 'Dans le chat' }, { 'ticker', 'Notification à l\'écran' }, { 'both', 'Les deux' } } },
        { k = 'announce_prefix', type = 'text', label = 'Préfixe', default = 'Annonce', maxlen = 24 },
        { k = 'announce_list', type = 'list', label = 'Messages (un par ligne)', default = {}, maxlen = 400, maxitems = 30, wide = true },
    },
})

PB.Action('general.announce.now', 'general.announce', function(ctx, p)
    local text = PB.Trim(PB.Sanitize(tostring(p.values and p.values.text or ''), 400))
    if text == '' then return false, 'Écris un message.' end
    local mode = (p.values and p.values.mode) or 'both'
    if mode ~= 'chat' and mode ~= 'ticker' and mode ~= 'both' then return false, 'Affichage inconnu.' end
    PB.Announce(text, mode)
    ctx.audit('serveur', 'annonce', 'tous les joueurs', nil, { text = text, mode = mode })
    ctx.toast = 'Annonce envoyée.'
    return true
end, { rate = 10 })

CreateThread(function()
    local idx, last = 0, os.time()
    while true do
        Wait(30000)
        if PB.IsReady and PB.Cfg.Get('general', 'announce_on', false) then
            local list = PB.Cfg.Get('general', 'announce_list', {})
            local every = PB.Cfg.Get('general', 'announce_interval', 10) * 60
            if #list > 0 and os.time() - last >= every then
                idx = idx % #list + 1
                PB.Announce(list[idx], PB.Cfg.Get('general', 'announce_mode', 'chat'))
                last = os.time()
            end
        end
    end
end)

AddEventHandler('playerJoining', function()
    local src = source
    if not PB.Cfg.Get('general', 'welcome_on', false) then return end
    CreateThread(function()
        Wait(PB.Cfg.Get('general', 'welcome_delay', 15) * 1000)
        if GetPlayerName(src) then PB.Announce(PB.Cfg.Get('general', 'welcome_msg', ''), PB.Cfg.Get('general', 'welcome_mode', 'chat'), src) end
    end)
end)

-- Maintenance -------------------------------------------------------------------------------------------------------------------------
local maintenance = Form.Cfg({
    ns = 'general', id = 'maintenance', title = 'Mode maintenance', perm = 'general.maintenance',
    desc = "Quand il est actif, seuls les membres de l'équipe (permission « se connecter pendant la maintenance ») peuvent rejoindre.",
    fields = {
        { k = 'maintenance_on', type = 'toggle', label = 'Maintenance active', default = false },
        { k = 'maintenance_msg', type = 'area', label = 'Message affiché aux joueurs refusés', default = 'Le serveur est en maintenance. Reviens un peu plus tard.', maxlen = 300, wide = true },
        { k = 'maintenance_eta', type = 'text', label = 'Retour prévu (texte libre)', default = '', maxlen = 60, hint = 'Ex. 21h30. Ajouté à la fin du message.' },
    },
    after = function(changed, vals, ctx)
        if vals.maintenance_on ~= nil then
            PB.Audit.Log('serveur', vals.maintenance_on and 'maintenance.on' or 'maintenance.off', ctx.actor, '', nil, nil)
            if PB.Notify then PB.Notify('warn', vals.maintenance_on and 'Maintenance activée' or 'Maintenance désactivée', ctx.actor.name) end
        end
    end,
})

local function canBypass(src)
    if P.IsOwner(src) then return true end
    local lic = P.GetLicense(src)
    return lic ~= nil and P.HasLicense(lic, 'general.bypass')
end

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    if not PB.Cfg.Get('general', 'maintenance_on', false) then return end
    deferrals.defer()
    Wait(0)
    if canBypass(src) then deferrals.done() return end
    local msg = PB.Cfg.Get('general', 'maintenance_msg', '')
    local eta = PB.Cfg.Get('general', 'maintenance_eta', '')
    if eta ~= '' then msg = msg .. ' Retour prévu : ' .. eta .. '.' end
    deferrals.done(msg)
end)

PB.Action('general.maint.kick', 'general.maintenance', function(ctx, p)
    local msg = PB.Cfg.Get('general', 'maintenance_msg', 'Maintenance en cours.')
    local n = 0
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        if not canBypass(src) then PB.Drop(src, 'kick', 'maintenance', msg, 'Maintenance : expulsion des joueurs non autorisés.', ctx.actor and ctx.actor.name) n = n + 1 end
    end
    ctx.audit('serveur', 'maintenance.expulsion', 'joueurs sans accès', nil, { count = n })
    ctx.toast = n .. ' joueur(s) expulsé(s).'
    return true
end, { critical = true, confirm = { title = 'Expulser les joueurs ?', text = "Tous les joueurs qui n'ont pas le droit de se connecter en maintenance seront déconnectés." } })

-- Ressources à démarrer (ordre du server.cfg) ----------------------------------------------------------------------------------------
local function ensureOp(ctx, ops, label)
    local ok, err, info = F.CfgApply(ops, ctx.actor, label)
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'server.cfg mis à jour. Effet au prochain démarrage du serveur.'
    return true
end

PB.Action('general.ens.toggle', 'general.edit', function(ctx, p)
    return ensureOp(ctx, { { op = 'ensure', name = tostring(p.name), enabled = PB.ToBool(p.enabled) } }, 'Ressource ' .. tostring(p.name))
end)
PB.Action('general.ens.move', 'general.edit', function(ctx, p)
    return ensureOp(ctx, { { op = 'move', name = tostring(p.name), dir = PB.ToInt(p.dir, 1) } }, 'Ordre de ' .. tostring(p.name))
end)
PB.Action('general.ens.add', 'general.edit', function(ctx, p)
    local name = tostring(p.values and p.values.name or '')
    if not PB.Res.Valid(name) then return false, 'Choisis une ressource.' end
    return ensureOp(ctx, { { op = 'ensure', name = name, enabled = true } }, 'Ajout de ' .. name)
end)

local function ensureBlocks(ctx)
    local view, err = F.CfgView()
    if not view then return { B.unsupported('Ressources à démarrer', (err or 'server.cfg illisible') .. ' — indisponible.') } end
    local pos, all = {}, PB.Res.All()
    local present = {}
    local rows = {}
    local enabledList = {}
    for _, r in ipairs(view.resources) do
        present[r.name] = true
        if r.enabled then enabledList[#enabledList + 1] = r end
    end
    for i, r in ipairs(enabledList) do pos[r.name] = i end
    for _, r in ipairs(view.resources) do
        local st = r.state
        local tone = st == 'started' and 'ok' or (st == 'missing' and 'err' or 'off')
        local order = r.enabled and pos[r.name] or nil
        -- dépendances démarrées après la ressource
        local warn
        if r.enabled and st ~= 'missing' then
            local deps = PB.Res.Deps(r.name)
            for _, d in ipairs(deps) do
                if GetResourceState(d) == 'missing' then warn = 'dépendance absente : ' .. d break end
                if pos[d] and pos[d] > pos[r.name] then warn = d .. ' démarre après' break end
            end
        end
        local actions = {}
        if r.enabled then
            actions[#actions + 1] = { action = 'general.ens.move', label = 'Monter', icon = 'up', payload = { name = r.name, dir = -1 } }
            actions[#actions + 1] = { action = 'general.ens.move', label = 'Descendre', icon = 'down', payload = { name = r.name, dir = 1 } }
        end
        if not r.protected then
            actions[#actions + 1] = { action = 'general.ens.toggle', label = r.enabled and 'Désactiver' or 'Activer', icon = r.enabled and 'pause' or 'play', payload = { name = r.name, enabled = not r.enabled } }
        end
        rows[#rows + 1] = { id = r.name, order = order or '—', name = r.name, cmd = r.cmd, enabled = { text = r.enabled and 'Au démarrage' or 'Désactivée', tone = r.enabled and 'ok' or 'off' },
            state = { text = st, tone = tone }, note = warn and { text = warn, tone = 'warn' } or '', actions = actions }
    end
    local free = {}
    for _, n in ipairs(all) do if not present[n] and n ~= GetCurrentResourceName() then free[#free + 1] = n end end
    return {
        B.notice('info', "L'ordre compte : une ressource doit démarrer après celles dont elle dépend. Les changements s'appliquent au prochain démarrage du serveur ; pour agir tout de suite, utilise le module Ressources."),
        B.table({ id = 'ens', title = 'Ressources du server.cfg (' .. #view.resources .. ')', search = true,
            columns = { { k = 'order', label = '#', type = 'num', w = 50 }, { k = 'name', label = 'Ressource', type = 'mono' }, { k = 'enabled', label = 'Server.cfg', type = 'badge' },
                { k = 'state', label = 'État actuel', type = 'badge' }, { k = 'note', label = 'Alerte', type = 'badge' } },
            rows = rows, empty = 'Aucune ligne ensure/start dans le server.cfg.' }),
        { type = 'form', id = 'ens_add', title = 'Ajouter une ressource au démarrage', cols = 1,
            fields = { { k = 'name', type = 'select', label = 'Ressource installée', opts = free, required = true } }, values = {},
            submit = #free > 0 and { action = 'general.ens.add', label = 'Ajouter à la fin du server.cfg' } or nil,
            empty = #free == 0 and 'Toutes les ressources installées sont déjà dans le server.cfg.' or nil },
    }
end

-- Validation ------------------------------------------------------------------------------------------------------------------------------
local function checks()
    local out = {}
    local function add(status, name, detail) out[#out + 1] = { name = name, status = { text = status == 'ok' and 'OK' or (status == 'warn' and 'À vérifier' or 'Problème'), tone = status == 'ok' and 'ok' or (status == 'warn' and 'warn' or 'err') }, detail = detail or '' } end
    local view, err = F.CfgView()
    if not view then
        add('err', 'Lecture du server.cfg', err)
    else
        add('ok', 'Lecture du server.cfg', view.lines .. ' lignes — ' .. tostring(view.path))
        local kv = {}
        for _, c in ipairs(view.convars) do kv[c.key:lower()] = c end
        add(kv['sv_licensekey'] and kv['sv_licensekey'].value ~= '' and 'ok' or 'err', 'Clé de licence', kv['sv_licensekey'] and 'Présente (masquée)' or 'sv_licenseKey absente : le serveur ne démarre pas sans.')
        add((kv['endpoint_add_tcp'] and kv['endpoint_add_udp']) and 'ok' or 'err', 'Adresses d\'écoute', (kv['endpoint_add_tcp'] and kv['endpoint_add_udp']) and 'TCP et UDP définies' or 'endpoint_add_tcp / endpoint_add_udp manquantes.')
        local mc = tonumber(kv['sv_maxclients'] and kv['sv_maxclients'].value)
        local oneSync = kv['onesync'] and kv['onesync'].value or ''
        if not mc then add('warn', 'Slots', 'sv_maxclients non défini (valeur par défaut du serveur).')
        elseif mc > 48 and oneSync ~= 'on' and oneSync ~= 'legacy' then add('err', 'Slots', mc .. ' slots demandent OneSync activé.')
        else add('ok', 'Slots', mc .. ' slots') end
        add((oneSync == 'on' or oneSync == 'legacy') and 'ok' or 'warn', 'OneSync', oneSync ~= '' and oneSync or 'Non défini')
        local hasDb = kv['mysql_connection_string'] and kv['mysql_connection_string'].value ~= ''
        add(hasDb and 'ok' or 'warn', 'Connexion MySQL', hasDb and 'Chaîne présente (masquée)' or 'mysql_connection_string absente du server.cfg (peut être définie ailleurs).')
        -- ressources
        local seen, pos, missing, dup, order = {}, {}, {}, {}, {}
        local idx = 0
        for _, r in ipairs(view.resources) do
            if r.enabled then
                idx = idx + 1
                if seen[r.name] then dup[#dup + 1] = r.name end
                seen[r.name] = true
                pos[r.name] = pos[r.name] or idx
                if r.state == 'missing' then missing[#missing + 1] = r.name end
            end
        end
        add(#missing == 0 and 'ok' or 'err', 'Ressources présentes', #missing == 0 and 'Toutes les ressources du server.cfg existent.' or ('Introuvables : ' .. table.concat(missing, ', ')))
        add(#dup == 0 and 'ok' or 'warn', 'Doublons', #dup == 0 and 'Aucun doublon.' or ('Démarrées plusieurs fois : ' .. table.concat(dup, ', ')))
        for name, p in pairs(pos) do
            for _, d in ipairs((PB.Res.Deps(name))) do
                if pos[d] and pos[d] > p then order[#order + 1] = name .. ' → ' .. d end
            end
        end
        table.sort(order)
        add(#order == 0 and 'ok' or 'warn', "Ordre de démarrage", #order == 0 and 'Aucune dépendance démarrée trop tard.' or ('Dépendance démarrée après : ' .. table.concat(order, ' ; ')))
    end
    local one = PB.DB.scalar('SELECT 1')
    add(one == 1 and 'ok' or 'err', 'Base de données', one == 1 and 'Requête de test réussie.' or 'La base ne répond pas.')
    local X = PB.Exclusive
    local foreign = X and X.Running() or {}
    add(#foreign == 0 and 'ok' or 'err', 'Shadow Framework', #foreign > 0 and ('Ressources non compatibles démarrées : ' .. table.concat(foreign, ', ')) or (X and X.WFramework() and 'wframework démarré, aucun framework concurrent.' or 'Aucun framework concurrent ; « ensure wframework » absent de server.cfg.'))
    add(#(Config.Owners or {}) > 0 and 'ok' or 'warn', 'Propriétaires', #(Config.Owners or {}) > 0 and (#Config.Owners .. ' défini(s) dans config.lua') or 'Aucun propriétaire dans config.lua : utilise la commande console pb_grant.')
    if Config.AdminLib and Config.AdminLib.mode == 'export' then
        local st = PB.AdminLib.State()
        add(st == 'started' and 'ok' or 'err', 'Librairie admin', Config.AdminLib.resource .. ' : ' .. st)
    end
    return out
end

-- Historique ------------------------------------------------------------------------------------------------------------------------------
local function short(v, n) v = tostring(v or '') if #v > (n or 60) then v = v:sub(1, n or 60) .. '…' end return v end

PB.Action('general.cfg.diff', 'general.view', function(ctx, p)
    local b = PB.DB.one('SELECT * FROM pb_file_backups WHERE id = ? AND resource = ?', { PB.ToInt(p.id, 0), '@server' })
    if not b then return false, 'Sauvegarde introuvable.' end
    local current = F.CfgRawMasked()
    local old = F.MaskBackup(b.content or '')
    local d = PB.TextDiff(old, current or '')
    return true, { title = 'Sauvegarde #' .. b.id .. ' → server.cfg actuel', diff = d }
end, { read = true })

PB.Action('general.cfg.restore', 'general.restore', function(ctx, p)
    local ok, err = F.Restore(PB.ToInt(p.id, 0), ctx.actor)
    if not ok then return false, err end
    ctx.toast = 'server.cfg restauré (une sauvegarde de l\'état précédent a été créée).'
    return true
end, { critical = true, pin = true, confirm = { title = 'Restaurer cette version du server.cfg ?', text = "Le fichier actuel sera sauvegardé puis remplacé. Le serveur doit être redémarré pour appliquer." } })

PB.Action('general.cfg.snapshot', 'general.edit', function(ctx)
    local text, err = F.CfgRawMasked()
    if not text then return false, err end
    local real = nil
    -- sauvegarde du contenu réel (secrets inclus) : lecture directe, jamais envoyée au client
    local path = F.ServerCfgPath()
    local f = io.open(path, 'rb')
    if f then real = f:read('*a') f:close() end
    local id = real and F.Backup('@server', 'server.cfg', real, ctx.actor, 'Instantané manuel')
    if not id then return false, 'Sauvegarde impossible.' end
    ctx.audit('sauvegarde', 'server.cfg.instantane', 'server.cfg', nil, { backup = id })
    ctx.toast = 'Instantané enregistré (#' .. id .. ').'
    return true
end)

PB.Action('general.cfg.raw', 'general.srvcfg', function(ctx, p)
    local ok, err = F.CfgWriteRaw(tostring(p.content or ''), ctx.actor, 'Édition brute')
    if not ok then return false, err end
    ctx.audited = true
    ctx.toast = 'server.cfg enregistré (sauvegarde créée).'
    return true
end, { critical = true, pin = true, confirm = { title = 'Écrire le server.cfg ?', text = "Une erreur peut empêcher le serveur de démarrer. Une sauvegarde est créée avant l'écriture." } })

-- Export / import de la configuration du panel ----------------------------------------------------------------------------------------------------
local SKIP_NS = { prefs = true, security = true, monitor = true }

PB.Action('general.export', 'general.view', function(ctx)
    local out = {}
    for _, r in ipairs(PB.DB.q('SELECT ns, k, v FROM pb_kv ORDER BY ns, k') or {}) do
        if not SKIP_NS[r.ns] and r.ns:sub(1, 6) ~= 'prefs:' then
            out[r.ns] = out[r.ns] or {}
            out[r.ns][r.k] = PB.FromJson(r.v, nil)
        end
    end
    local doc = { format = 'pb_panel-config', version = 1, exported = os.date('!%Y-%m-%dT%H:%M:%SZ'), server = PB.Cfg.Get('general', 'server_name', ''), kv = out }
    ctx.audit('config', 'export', 'configuration du panel', nil, nil)
    return true, { download = { name = 'pb_panel-config.json', text = PB.Json(doc), mime = 'application/json' } }
end, { read = true })

PB.Action('general.import', 'general.restore', function(ctx, p)
    local doc = PB.FromJson(tostring(p.values and p.values.json or ''), nil)
    if type(doc) ~= 'table' or doc.format ~= 'pb_panel-config' or type(doc.kv) ~= 'table' then return false, "Ce fichier n'est pas une exportation du panel." end
    local count, ns = 0, {}
    for nsName, tbl in pairs(doc.kv) do
        if type(nsName) ~= 'string' or #nsName > 48 or not nsName:match('^[%w_%.]+$') then return false, 'Espace de noms invalide : ' .. tostring(nsName) end
        if SKIP_NS[nsName] then return false, "L'espace « " .. nsName .. " » ne peut pas être importé." end
        if type(tbl) ~= 'table' then return false, 'Contenu invalide pour ' .. nsName end
        for k in pairs(tbl) do if type(k) ~= 'string' or #k > 96 then return false, 'Clé invalide dans ' .. nsName end end
        ns[#ns + 1] = nsName
    end
    for _, nsName in ipairs(ns) do
        for k, v in pairs(doc.kv[nsName]) do
            local ok = PB.Cfg.Set(nsName, k, v, ctx.actor, 'Importation')
            if ok then count = count + 1 end
        end
    end
    ctx.audit('config', 'import', 'configuration du panel', nil, { namespaces = ns, values = count })
    ctx.toast = count .. ' valeur(s) importée(s). Chaque changement est dans l\'historique.'
    return true
end, { critical = true, pin = true, confirm = { title = 'Importer cette configuration ?', text = "Les valeurs du fichier remplacent celles du panel (l'historique permet de revenir en arrière)." } })

-- Vue -----------------------------------------------------------------------------------------------------------------------------------------
PB.Module({
    id = 'general', label = 'Configuration', icon = 'sliders', group = 'Pilotage', order = 10, perm = 'general.view', hint = 'Serveur, réseau, démarrage, maintenance',
    caps = function()
        return PB.Capsify({
            { 'Modifier le server.cfg (valeurs, ordre des ressources)', F.ServerCfgPath() and 'ok' or 'off', F.ServerCfgPath() and 'Sauvegarde avant chaque écriture, secrets masqués.' or 'server.cfg introuvable : renseigne Config.ServerPath.' },
            { 'Appliquer sans redémarrer', 'partial', 'Le server.cfg est lu au démarrage : la plupart des réglages demandent un redémarrage.' },
            { 'Maintenance, annonces, message de bienvenue', 'ok', 'Gérés par le panel, effet immédiat.' },
            { 'Langue du framework', 'ok', 'Shadow Framework : Shadow Base est entièrement en français.' },
            { 'Annonce à l\'écran (notification)', 'ok', 'Client du panel, sans dépendance au chat.' },
            { 'Annonce dans le chat', 'ok', 'Affichée dans le chat de la base (et dans le chat FiveM s\'il est installé).' },
        })
    end,
    doc = "## Configuration générale\nCe module modifie le **server.cfg** (avec sauvegarde avant chaque écriture), le mode maintenance, les annonces et les réglages de démarrage du panel.\n\n- Les valeurs sensibles (clé de licence, RCON, chaîne MySQL) ne sont **jamais** envoyées à ton navigateur.\n- Chaque modification apparaît dans **Historique** avec l'ancienne valeur.\n- Un redémarrage du serveur est nécessaire pour appliquer la plupart des réglages du server.cfg.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('overview', "Vue d'ensemble", 'home', function()
                local started = 0
                for _, n in ipairs(PB.Res.All()) do if GetResourceState(n) == 'started' then started = started + 1 end end
                return {
                    B.stats({
                        { label = 'Joueurs connectés', value = #GetPlayers(), icon = 'users' },
                        { label = 'Ressources démarrées', value = started, icon = 'box' },
                        { label = 'Framework', value = 'Shadow Framework', icon = 'layers' },
                        { label = 'Panel actif depuis', value = PB.FormatDuration and PB.FormatDuration(os.time() - PB.Info.startedAt) or tostring(os.time() - PB.Info.startedAt) .. ' s', icon = 'clock' },
                    }),
                    identity(ctx),
                    B.actions({ { action = 'general.logo.clear', label = 'Retirer le logo envoyé', icon = 'trash' } }),
                }
            end),
            tab('season', 'Fêtes', 'sparkle', function()
                local info = PB.Season.Info()
                local mode = tostring(PB.Cfg.Get('general', 'season', 'off'))
                local text = info and ('Fête active : ' .. info.label .. (mode == 'auto' and ' (mode automatique)' or '') .. '.')
                    or (mode == 'auto' and "Mode automatique : aucune fête en ce moment. Halloween du 15 octobre au 1er novembre, Noël du 1er décembre au 2 janvier." or 'Aucune fête active.')
                return { B.notice(info and 'ok' or 'info', text), season(ctx),
                    B.notice('info', "Les joueurs qui ont choisi eux-mêmes leur thème dans « Mes préférences » gardent le leur. Les couleurs de la fête remplacent temporairement les couleurs de l'identité ; tes couleurs reviennent quand la fête se termine.") }
            end),
            tab('listing', 'Liste du serveur', 'globe', function() return { listing(ctx) } end),
            tab('slots', 'Slots et FXServer', 'cpu', function() return { slots(ctx) } end),
            tab('network', 'Réseau', 'wifi', function() return { network(ctx) } end, 'general.srvcfg'),
            tab('keys', 'Clés et accès', 'key', function() return { keys(ctx) } end, 'general.srvcfg'),
            tab('lang', 'Langue et démarrage', 'language', function()
                local blocks = { B.notice('info', "Framework : Shadow Framework (wframework). Shadow Base fournit lui-même le personnage, l'inventaire, la banque et les menus, entièrement en français ; ESX, QBCore, Qbox et ox_inventory sont refusés.") }
                if ctx.has('general.srvcfg') then blocks[#blocks + 1] = panelCfg(ctx) end
                return blocks
            end),
            tab('resources', 'Ressources à démarrer', 'list', ensureBlocks),
            tab('messages', 'Messages et annonces', 'megaphone', function()
                return {
                    welcome(ctx), announce(ctx),
                    { type = 'form', id = 'announce_now', title = 'Envoyer une annonce maintenant', cols = 1,
                      fields = { { k = 'text', type = 'area', label = 'Message', maxlen = 400, required = true },
                          { k = 'mode', type = 'select', label = 'Affichage', default = 'both', opts = { { 'both', 'Chat et notification' }, { 'chat', 'Chat' }, { 'ticker', 'Notification à l\'écran' } } } },
                      values = { mode = 'both' }, submit = { action = 'general.announce.now', label = 'Envoyer à tous les joueurs' } },
                }
            end),
            tab('maintenance', 'Maintenance', 'wrench', function()
                return { maintenance(ctx), B.actions({ { action = 'general.maint.kick', label = 'Expulser les joueurs sans accès maintenance', danger = true, icon = 'door' } }, 'Actions') }
            end),
            tab('validate', 'Validation', 'check', function()
                local rows = checks()
                local bad, warn = 0, 0
                for _, r in ipairs(rows) do if r.status.tone == 'err' then bad = bad + 1 elseif r.status.tone == 'warn' then warn = warn + 1 end end
                return {
                    B.notice(bad > 0 and 'error' or (warn > 0 and 'warn' or 'ok'), bad > 0 and (bad .. ' problème(s) à corriger.') or (warn > 0 and (warn .. ' point(s) à vérifier.') or 'Tout est en ordre.'), 'Résultat'),
                    B.table({ id = 'checks', columns = { { k = 'name', label = 'Contrôle' }, { k = 'status', label = 'Résultat', type = 'badge' }, { k = 'detail', label = 'Détail' } }, rows = rows }),
                }
            end),
            tab('history', 'Historique', 'history', function()
                local rows = {}
                for _, h in ipairs(PB.Cfg.History({}, 60)) do
                    rows[#rows + 1] = { id = h.id, at = h.created_at, key = h.ns .. ' › ' .. h.k, before = short(h.before_v), after = short(h.after_v), actor = h.actor,
                        state = h.reverted and { text = 'Annulée', tone = 'off' } or '',
                        actions = (not h.reverted and ctx.has('general.restore')) and { { action = 'cfg.revert', label = 'Annuler', icon = 'undo', payload = { id = h.id } } } or {} }
                end
                local bk = {}
                for _, b in ipairs(PB.DB.q("SELECT id, size, actor, reason, created_at FROM pb_file_backups WHERE resource = '@server' ORDER BY id DESC LIMIT 30") or {}) do
                    bk[#bk + 1] = { id = b.id, at = b.created_at, size = PB.FormatBytes(tonumber(b.size) or 0), actor = b.actor, reason = b.reason,
                        actions = { { action = 'general.cfg.diff', label = 'Comparer', icon = 'diff', payload = { id = b.id } },
                            { action = 'general.cfg.restore', label = 'Restaurer', icon = 'undo', danger = true, payload = { id = b.id } } } }
                end
                return {
                    B.table({ id = 'cfgh', title = 'Modifications de configuration', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'key', label = 'Réglage', type = 'mono' },
                        { k = 'before', label = 'Avant', type = 'mono' }, { k = 'after', label = 'Après', type = 'mono' }, { k = 'actor', label = 'Par' }, { k = 'state', label = '', type = 'badge' } }, rows = rows, empty = 'Aucune modification enregistrée.' }),
                    B.table({ id = 'srvh', title = 'Sauvegardes du server.cfg', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'size', label = 'Taille' }, { k = 'actor', label = 'Par' }, { k = 'reason', label = 'Motif' } }, rows = bk, empty = 'Aucune sauvegarde du server.cfg.' }),
                }
            end),
            tab('backup', 'Sauvegarde et restauration', 'save', function()
                return {
                    B.notice('info', "Exporte la configuration du panel (réglages, jamais les secrets) pour la sauvegarder ou la copier vers un autre serveur."),
                    B.actions({ { action = 'general.export', label = 'Exporter la configuration du panel', icon = 'download' }, { action = 'general.cfg.snapshot', label = 'Faire un instantané du server.cfg', icon = 'save' } }, 'Sauvegarder'),
                    { type = 'form', id = 'import', title = 'Importer une configuration', cols = 1,
                      fields = { { k = 'json', type = 'area', label = 'Contenu du fichier exporté', rows = 8, maxlen = 1000000, required = true, code = true } }, values = {},
                      submit = { action = 'general.import', label = 'Importer' } },
                }
            end, 'general.restore'),
            tab('raw', 'server.cfg brut', 'code', function()
                local text, err = F.CfgRawMasked()
                if not text then return { B.unsupported('Éditeur du server.cfg', err) } end
                return {
                    B.notice('warn', "Les valeurs sensibles sont masquées (••••••••) : laisse-les telles quelles pour les conserver. Une sauvegarde est créée avant l'écriture."),
                    { type = 'editor', id = 'srvcfg', language = 'cfg', content = text, save = { action = 'general.cfg.raw', label = 'Enregistrer le server.cfg' } },
                }
            end, 'general.srvcfg'),
        } }
    end,
})

-- Nouveau nom de la base (2026-10-21) : un serveur qui avait gardé le nom par défaut « W Base » passe à « Shadow Base » (une seule fois).
PB.OnReady(function()
    if PB.Cfg.Get('general', 'renamed_shadow', false) == true then return end
    local n = tostring(PB.Cfg.Get('general', 'server_name', '') or '')
    if n == 'W Base' or n == 'W-Base' or n == 'W BASE' then PB.Cfg.Set('general', 'server_name', 'Shadow Base', nil, 'Nouveau nom : Shadow Base') end
    PB.Cfg.Set('general', 'renamed_shadow', true, nil, 'Migration')
end)
