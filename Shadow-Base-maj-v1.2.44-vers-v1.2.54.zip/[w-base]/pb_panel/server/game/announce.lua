-- Annonces plein écran (façon txAdmin) : bandeau géant au centre de l'écran de tous les joueurs, avec style, durée, son et auteur.
-- Réservé aux fondateurs (droit « announce.send »). Panel › Annonces, commande /annonce, ou PB.Announce(texte, 'screen' | 'all').
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G
local A = {}
G.Announce = A

P.Register('announce.send', 'Envoyer des annonces plein écran (comme txAdmin)', 'general', true)
P.Register('announce.view', "Voir l'historique des annonces plein écran", 'general')
PB.Migrate('138_announces', 'Annonces plein écran', {
    [[CREATE TABLE IF NOT EXISTS pb_announces (id INT AUTO_INCREMENT PRIMARY KEY, at INT NOT NULL DEFAULT 0, author VARCHAR(64) NOT NULL DEFAULT '', title VARCHAR(80) NOT NULL DEFAULT '', body VARCHAR(400) NOT NULL DEFAULT '', style VARCHAR(12) NOT NULL DEFAULT 'info', secs INT NOT NULL DEFAULT 12, target VARCHAR(24) NOT NULL DEFAULT 'tous')]],
})
PB.Migrate('139_announce_tpl', 'Annonces : modèles enregistrés', {
    [[CREATE TABLE IF NOT EXISTS pb_announce_tpl (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL, title VARCHAR(80) NOT NULL DEFAULT '', body VARCHAR(400) NOT NULL DEFAULT '', style VARCHAR(16) NOT NULL DEFAULT 'info', secs INT NOT NULL DEFAULT 12, aud VARCHAR(16) NOT NULL DEFAULT 'all', aud_val VARCHAR(64) NOT NULL DEFAULT '', author VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0)]],
})
PB.Cfg.Define('announce', { keep = 300, keep_days = 60, secs = 12, sound = true, chat_too = true, show_author = true, title_default = 'Annonce du staff' })
local function cfg(k, d) return PB.Cfg.Get('announce', k, d) end

A.STYLES = {
    info = { label = 'Information', color = '#5fa8ff' },
    event = { label = 'Événement', color = '#f5b942' },
    alert = { label = 'Alerte', color = '#ff4d5e' },
    success = { label = 'Bonne nouvelle', color = '#4ad991' },
}
local STYLE_OPTS = { { 'info', 'Information (bleu)' }, { 'event', 'Événement (or)' }, { 'alert', 'Alerte (rouge)' }, { 'success', 'Bonne nouvelle (vert)' } }

-- Destinataires : tous · un joueur · un groupe illégal · une entreprise · le staff · la police
A.AUDIENCES = { { 'all', 'Tous les joueurs' }, { 'player', 'Un joueur (ID)' }, { 'gang', 'Un groupe illégal' }, { 'biz', 'Une entreprise / un métier' }, { 'staff', 'Le staff' }, { 'police', 'La police' } }
function A.Resolve(kind, val)
    local out = {}
    for s in pairs(G.Players()) do
        local ok = false
        if kind == 'player' then ok = (s == tonumber(val))
        elseif kind == 'gang' then local g = G.Tags and G.Tags.Gang and G.Tags.Gang(s) ok = g ~= nil and g.id == tostring(val)
        elseif kind == 'biz' then local c = G.Biz and G.Biz.Ctx and G.Biz.Ctx(s) ok = c ~= nil and c.biz.id == tostring(val)
        elseif kind == 'staff' then ok = P.Has(s, 'staff.menu')
        elseif kind == 'police' then local c = G.Biz and G.Biz.Ctx and G.Biz.Ctx(s) ok = c ~= nil and c.biz.kind == 'police'
        else ok = true end
        if ok then out[#out + 1] = s end
    end
    return out
end
function A.AudLabel(kind, val)
    if kind == 'player' then return '#' .. tostring(val) end
    if kind == 'gang' then local d = G.Tags and G.Tags.GangDefs and G.Tags.GangDefs()[tostring(val)] return 'groupe ' .. (d and d.label or tostring(val)) end
    if kind == 'biz' then local b = G.Biz and G.Biz.Get and G.Biz.Get(val) return 'entreprise ' .. (b and b.label or tostring(val)) end
    if kind == 'staff' then return 'staff' end
    if kind == 'police' then return 'police' end
    return 'tous'
end
-- Ménage : on garde au plus `keep` annonces et `keep_days` jours.
function A.Purge()
    local keep, days = math.max(20, tonumber(cfg('keep', 300)) or 300), math.max(1, tonumber(cfg('keep_days', 60)) or 60)
    DB.exec('DELETE FROM pb_announces WHERE at < ?', { os.time() - days * 86400 })
    local r = DB.one('SELECT id FROM pb_announces ORDER BY id DESC LIMIT 1 OFFSET ?', { keep })
    if r and r.id then DB.exec('DELETE FROM pb_announces WHERE id <= ?', { r.id }) end
end
PB.OnReady(function() pcall(A.Purge) end)

-- opts : { title, text, style, secs, sound, chat, author, target = -1 | id de joueur, aud = 'all'|'player'|'gang'|'biz'|'staff'|'police', aud_val }
function A.Send(opts)
    opts = opts or {}
    local text = PB.Trim(PB.Sanitize(tostring(opts.text or ''), 300))
    if text == '' then return false, 'Écris un message.' end
    local title = PB.Trim(PB.Sanitize(tostring(opts.title or ''), 60))
    if title == '' then title = cfg('title_default', 'Annonce du staff') end
    local style = A.STYLES[opts.style] and opts.style or 'info'
    local secs = math.max(4, math.min(60, math.floor(tonumber(opts.secs) or tonumber(cfg('secs', 12)) or 12)))
    local target = tonumber(opts.target) or -1
    local aud, audVal = opts.aud or 'all', opts.aud_val
    if target ~= -1 then aud, audVal = 'player', target end
    if target ~= -1 and not G.Get(target) then return false, 'Ce joueur est hors ligne.' end
    local author = cfg('show_author', true) ~= false and PB.Sanitize(tostring(opts.author or ''), 40) or ''
    local sound = opts.sound ~= false
    local payload = PB.Json({ title = title, text = text, style = style, color = A.STYLES[style].color, secs = secs, sound = sound, author = author })
    local dest, n = nil, 0
    if aud == 'all' then
        TriggerClientEvent('pb:g:ann', -1, payload)
        if opts.chat and G.ChatSystem then G.ChatSystem(-1, title, text) end
        for _ in pairs(G.Players()) do n = n + 1 end
    else
        dest = A.Resolve(aud, audVal)
        if #dest == 0 then return false, 'Aucun joueur connecté ne correspond à ce ciblage.' end
        for _, s in ipairs(dest) do
            TriggerClientEvent('pb:g:ann', s, payload)
            if opts.chat and G.ChatSystem then G.ChatSystem(s, title, text) end
        end
        n = #dest
    end
    if not opts.preview then
        DB.insert('INSERT INTO pb_announces (at, author, title, body, style, secs, target) VALUES (?, ?, ?, ?, ?, ?, ?)',
            { os.time(), PB.Sanitize(tostring(opts.author or 'système'), 60), title, text, style, secs, A.AudLabel(aud, audVal) })
        if math.random(1, 10) == 1 then pcall(A.Purge) end
    end
    return true, nil, { title = title, style = style, secs = secs, count = n, aud = A.AudLabel(aud, audVal) }
end
function A.History(n)
    return DB.q('SELECT id, at, author, title, body, style, secs, target FROM pb_announces ORDER BY id DESC LIMIT ?', { n or 50 }) or {}
end
local function authorOf(src) return (G.Get(src) and ((G.Identity(src) or {}).firstname) and (G.Identity(src).firstname .. ' ' .. (G.Identity(src).lastname or ''))) or GetPlayerName(src) or 'Staff' end

-- /annonce [info|event|alert|success] message…  (fondateurs)
RegisterCommand('annonce', function(src, args)
    if src == 0 then return end
    if not P.Has(src, 'announce.send') then G.Notify(src, { type = 'error', title = 'Annonce', text = 'Réservé aux fondateurs.' }) return end
    local style = 'info'
    if args[1] and A.STYLES[args[1]:lower()] then style = table.remove(args, 1):lower() end
    local ok, err = A.Send({ text = table.concat(args, ' '), style = style, chat = cfg('chat_too', true), sound = cfg('sound', true) ~= false, author = authorOf(src) })
    if not ok then G.Notify(src, { type = 'error', title = 'Annonce', text = err }) return end
    PB.Audit.Log('serveur', 'annonce.ecran', src, 'tous les joueurs', nil, nil, { text = table.concat(args, ' '), style = style })
end, false)

-- Panel -----------------------------------------------------------------------------------------------------------------------------
local function form(v)
    local aud = v.aud or 'all'
    local val = aud == 'player' and v.player or aud == 'gang' and v.gang or aud == 'biz' and v.biz or nil
    local o = { title = v.title, text = v.text, style = v.style, secs = v.secs, chat = v.chat == true or v.chat == 'true', sound = v.sound ~= false and v.sound ~= 'false', aud = aud, aud_val = val }
    if aud == 'player' then o.target = tonumber(v.player) or -1 if o.target == -1 or o.target <= 0 then o.target = -2 end end
    return o
end
local function checkAud(o)
    if o.target == -2 then return false, "Indique l'ID du joueur." end
    if o.aud == 'gang' and (not o.aud_val or o.aud_val == '') then return false, 'Choisis le groupe.' end
    if o.aud == 'biz' and (not o.aud_val or o.aud_val == '') then return false, "Choisis l'entreprise." end
    return true
end
PB.Action('announce.send', 'announce.send', function(ctx, p)
    local o = form(p.values or p)
    o.author = ctx.name or ctx.actor or 'Staff'
    local okA, errA = checkAud(o) if not okA then return false, errA end
    local ok, err, info = A.Send(o)
    if not ok then return false, err end
    ctx.audit('serveur', 'annonce.ecran', info.aud, nil, { text = o.text, style = info.style, joueurs = info.count })
    ctx.toast = ('Annonce envoyée (%d joueur%s).'):format(info.count, info.count > 1 and 's' or '')
    return true
end, { rate = 20 })
PB.Action('announce.preview', 'announce.send', function(ctx, p)
    if not ctx.src or ctx.src <= 0 then return false, "Disponible seulement en jeu : connecte-toi au serveur." end
    local o = form(p.values or p)
    o.target, o.aud, o.preview, o.chat, o.author = ctx.src, 'player', true, false, 'Aperçu'
    local ok, err = A.Send(o)
    if not ok then return false, err end
    ctx.toast = 'Aperçu affiché sur ton écran.'
    return true
end, { rate = 30 })
PB.Action('announce.resend', 'announce.send', function(ctx, p)
    local r = DB.one('SELECT title, body, style, secs FROM pb_announces WHERE id = ?', { tonumber(p.id) or 0 })
    if not r then return false, 'Annonce introuvable.' end
    local ok, err = A.Send({ title = r.title, text = r.body, style = r.style, secs = r.secs, author = ctx.name or ctx.actor or 'Staff' })
    if not ok then return false, err end
    ctx.audit('serveur', 'annonce.ecran', 'tous les joueurs', nil, { text = r.body, renvoi = true })
    ctx.toast = 'Annonce renvoyée.'
    return true
end, { rate = 20 })

-- Modèles enregistrés
function A.Templates() return DB.q('SELECT id, name, title, body, style, secs, aud, aud_val, author, at FROM pb_announce_tpl ORDER BY name') or {} end
PB.Action('announce.tpl.save', 'announce.send', function(ctx, p)
    local v = p.values or p
    local name = PB.Trim(PB.Sanitize(tostring(v.tpl_name or v.name or ''), 60))
    if name == '' then return false, 'Donne un nom au modèle (champ « Nom du modèle »).' end
    local o = form(v)
    local text = PB.Trim(PB.Sanitize(tostring(o.text or ''), 300))
    if text == '' then return false, 'Écris un message.' end
    local c = DB.one('SELECT COUNT(*) AS n FROM pb_announce_tpl') if c and tonumber(c.n) >= 100 and not DB.one('SELECT id FROM pb_announce_tpl WHERE name = ?', { name }) then return false, '100 modèles maximum.' end
    local style = A.STYLES[o.style] and o.style or 'info'
    local aud = A.AUDIENCES and o.aud or 'all'
    local val = o.aud_val ~= nil and tostring(o.aud_val) or ''
    local ex = DB.one('SELECT id FROM pb_announce_tpl WHERE name = ?', { name })
    local title = PB.Trim(PB.Sanitize(tostring(o.title or ''), 60))
    local secs = math.max(4, math.min(60, math.floor(tonumber(o.secs) or 12)))
    if ex then DB.exec('UPDATE pb_announce_tpl SET title=?, body=?, style=?, secs=?, aud=?, aud_val=?, author=?, at=? WHERE id=?', { title, text, style, secs, aud, val, ctx.name or 'Staff', os.time(), ex.id })
    else DB.insert('INSERT INTO pb_announce_tpl (name, title, body, style, secs, aud, aud_val, author, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', { name, title, text, style, secs, aud, val, ctx.name or 'Staff', os.time() }) end
    ctx.audit('serveur', 'annonce.modele', name)
    ctx.toast = ex and 'Modèle mis à jour.' or 'Modèle enregistré.'
    return true
end, { rate = 20 })
PB.Action('announce.tpl.send', 'announce.send', function(ctx, p)
    local r = DB.one('SELECT * FROM pb_announce_tpl WHERE id = ?', { tonumber(p.id) or 0 })
    if not r then return false, 'Modèle introuvable.' end
    local ok, err, info = A.Send({ title = r.title, text = r.body, style = r.style, secs = r.secs, aud = r.aud, aud_val = r.aud_val, author = ctx.name or ctx.actor or 'Staff', chat = cfg('chat_too', true) })
    if not ok then return false, err end
    ctx.audit('serveur', 'annonce.ecran', info.aud, nil, { modele = r.name, joueurs = info.count })
    ctx.toast = ('Modèle envoyé (%d joueur%s).'):format(info.count, info.count > 1 and 's' or '')
    return true
end, { rate = 20 })
PB.Action('announce.tpl.delete', 'announce.send', function(ctx, p)
    DB.exec('DELETE FROM pb_announce_tpl WHERE id = ?', { tonumber(p.id) or 0 })
    ctx.audit('serveur', 'annonce.modele.suppr', tostring(p.id or ''))
    ctx.toast = 'Modèle supprimé.'
    return true
end)
PB.Action('announce.purge', 'announce.send', function(ctx)
    DB.exec('DELETE FROM pb_announces')
    ctx.audit('serveur', 'annonce.purge', 'historique')
    ctx.toast = 'Historique vidé.'
    return true
end, { critical = true, confirm = { title = "Vider tout l'historique des annonces ?", text = 'Action définitive.' } })
local settings = PB.Form.Cfg({ ns = 'announce', id = 'settings', title = 'Réglages des annonces', perm = 'announce.send', cols = 2, fields = {
    { k = 'title_default', type = 'text', label = 'Titre par défaut', default = 'Annonce du staff', maxlen = 40 },
    { k = 'secs', type = 'number', label = 'Durée par défaut (secondes)', default = 12, min = 4, max = 60 },
    { k = 'sound', type = 'toggle', label = 'Son à l’arrivée', default = true },
    { k = 'chat_too', type = 'toggle', label = 'Copie dans le chat avec /annonce', default = true },
    { k = 'show_author', type = 'toggle', label = "Afficher l'auteur sur le bandeau", default = true },
    { k = 'keep', type = 'number', label = "Historique : nombre d'annonces gardées", default = 300, min = 20, max = 5000 },
    { k = 'keep_days', type = 'number', label = 'Historique : jours gardés', default = 60, min = 1, max = 365 },
} })
local function gangOpts()
    local o = { { '', '— choisir —' } }
    if G.Tags and G.Tags.GangDefs then for gid, d in pairs(G.Tags.GangDefs()) do o[#o + 1] = { gid, d.label or gid } end end
    table.sort(o, function(a, b) return a[2] < b[2] end)
    return o
end
local function bizOpts()
    local o = { { '', '— choisir —' } }
    if G.Biz and G.Biz.List then for _, b in ipairs(G.Biz.List()) do o[#o + 1] = { b.id, b.label } end end
    table.sort(o, function(a, b) return a[2] < b[2] end)
    return o
end
PB.Module({
    id = 'announce', label = 'Annonces', icon = 'megaphone', group = 'Serveur', order = 141, perm = 'announce.view', hint = 'Annonces plein écran, historique',
    caps = function() return PB.Capsify({
        { 'Bandeau plein écran', 'ok', "Grand bandeau au centre de l'écran de tous les joueurs (comme txAdmin), 4 styles, durée réglable, son, auteur." },
        { 'Fondateurs seulement', 'ok', 'Droit « announce.send » : propriétaire, ou grade à qui tu le donnes. Chaque envoi est dans le journal.' },
        { 'Commande /annonce', 'ok', '/annonce [info|event|alert|success] message, depuis le jeu.' },
        { 'Ciblage', 'ok', 'Tous, un joueur, un groupe illégal, une entreprise, le staff ou la police.' },
        { 'Modèles', 'ok', 'Messages enregistrés à renvoyer en un clic.' },
        { 'Planification', 'off', "Pas d'envoi différé : l'annonce part tout de suite." },
    }) end,
    doc = "## Annonces\nEnvoie un grand bandeau à tous les joueurs (ou à un seul). Choisis le style, la durée, active la copie dans le chat. **Aperçu** l'affiche seulement sur ton écran. En jeu : `/annonce alert Redémarrage dans 10 minutes`. Les autres modules (territoires…) peuvent aussi utiliser `PB.Announce(texte, 'screen')`.",
    view = function(ctx) return { tabs = {
        { id = 'send', label = 'Envoyer', icon = 'megaphone', build = function()
            if not ctx.has('announce.send') then return { B.notice('warn', 'Réservé aux fondateurs.') } end
            return { { type = 'gpreview', kind = 'announce', title = 'Aperçu du bandeau', desc = 'Ce que verront les joueurs : il se met à jour pendant que tu écris.', form = 'announce_send', cfg = { style = 'info', secs = 12 } },
                { type = 'form', id = 'announce_send', title = 'Nouvelle annonce plein écran', cols = 2, fields = {
                { k = 'title', type = 'text', label = 'Titre (vide = titre par défaut)', maxlen = 60 },
                { k = 'style', type = 'select', label = 'Style', opts = STYLE_OPTS, options = STYLE_OPTS, default = 'info' },
                { k = 'text', type = 'area', label = 'Message', maxlen = 300, required = true, wide = true },
                { k = 'secs', type = 'number', label = 'Durée (secondes)', default = tonumber(cfg('secs', 12)) or 12, min = 4, max = 60 },
                { k = 'aud', type = 'select', label = 'Destinataires', opts = A.AUDIENCES, options = A.AUDIENCES, default = 'all' },
                { k = 'player', type = 'number', label = 'Si « Un joueur » : son ID', min = 0, max = 999999 },
                { k = 'gang', type = 'select', label = 'Si « Un groupe illégal » : le groupe', opts = gangOpts(), options = gangOpts() },
                { k = 'biz', type = 'select', label = 'Si « Une entreprise » : laquelle', opts = bizOpts(), options = bizOpts() },
                { k = 'sound', type = 'toggle', label = 'Son', default = true },
                { k = 'chat', type = 'toggle', label = 'Copie dans le chat', default = false },
                { k = 'tpl_name', type = 'text', label = 'Nom du modèle (pour l’enregistrer)', maxlen = 60, wide = true },
            }, values = { style = 'info', aud = 'all', secs = tonumber(cfg('secs', 12)) or 12, sound = true }, submit = { action = 'announce.send', label = 'Envoyer' },
              extra = { { action = 'announce.preview', label = "Voir sur mon écran en jeu", icon = 'eye' }, { action = 'announce.tpl.save', label = 'Enregistrer comme modèle', icon = 'save' } } } }
        end },
        { id = 'history', label = 'Historique', icon = 'clock', build = function()
            local rows = {}
            for _, r in ipairs(A.History(60)) do
                rows[#rows + 1] = { id = r.id, at = r.at, author = r.author, style = (A.STYLES[r.style] or A.STYLES.info).label, title = r.title, body = r.body, target = r.target,
                    actions = ctx.has('announce.send') and { { action = 'announce.resend', label = 'Renvoyer', icon = 'megaphone', payload = { id = r.id } } } or nil }
            end
            return { ctx.has('announce.send') and B.actions({ { action = 'announce.purge', label = "Vider l'historique", icon = 'trash' } }) or B.notice('info', 'Historique nettoyé automatiquement (réglages).'), B.table({ id = 'annh', title = 'Dernières annonces', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'author', label = 'Auteur' }, { k = 'style', label = 'Style', type = 'badge' }, { k = 'title', label = 'Titre' }, { k = 'body', label = 'Message' }, { k = 'target', label = 'Cible' } }, rows = rows, empty = 'Aucune annonce envoyée.' }) }
        end },
        { id = 'models', label = 'Modèles', icon = 'bookmark', build = function()
            local rows = {}
            for _, r in ipairs(A.Templates()) do
                rows[#rows + 1] = { id = r.id, name = r.name, body = r.body, style = (A.STYLES[r.style] or A.STYLES.info).label, aud = A.AudLabel(r.aud, r.aud_val), author = r.author,
                    actions = ctx.has('announce.send') and { { action = 'announce.tpl.send', label = 'Envoyer', icon = 'megaphone', payload = { id = r.id } },
                        { action = 'announce.tpl.delete', label = 'Supprimer', icon = 'trash', payload = { id = r.id } } } or nil }
            end
            return { B.notice('info', 'Remplis le formulaire « Envoyer », donne un nom au modèle puis « Enregistrer comme modèle ». Ensuite un clic suffit pour le renvoyer au même public.'),
                B.table({ id = 'annm', title = 'Modèles enregistrés', search = true, columns = { { k = 'name', label = 'Nom' }, { k = 'style', label = 'Style', type = 'badge' }, { k = 'aud', label = 'Destinataires' }, { k = 'body', label = 'Message' }, { k = 'author', label = 'Auteur' } }, rows = rows, empty = 'Aucun modèle enregistré.' }) }
        end },
        { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { settings(ctx) } end },
    } } end,
})
PB.SelfTest.Add('annonces', function(R)
    R.check(G.Announce ~= nil and G.Announce.Send ~= nil, 'envoi disponible', "le module d'annonces manque")
    for k, st in pairs(A.STYLES) do R.check(tostring(st.color):match('^#%x%x%x%x%x%x$') ~= nil, 'couleur du style ' .. k, 'couleur invalide') end
end)
