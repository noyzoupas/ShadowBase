-- HUD en jeu : trois styles, éléments, couleurs, position, besoins (faim, soif, stress). Rendu par client/game.lua et web/game.js.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G = PB.G
local DB = PB.DB

PB.Cfg.Define('hud', { show_ammo = true, pos_x = 14, pos_y = 90, scale = 1, opacity = 1, status_on = false, speedo_style = 'digits', speed_max = 0, show_rpm = true, veh_x = 90, veh_y = 90, veh_scale = 1, style = 'ring', ring_x = 19.6, ring_y = 97.5, bar_x = 8.6, bar_y = 97.6, bar_w = 14, tank_l = 0, l_per_100 = 9, photo_x = 16.4, photo_y = 2.4 })

local STYLES = { { 'shadow', 'Shadow : collé à la mini-carte, heure et serveur en haut à droite' }, { 'ring', 'Anneaux + barre sous la mini-carte (épuré)' }, { 'spotlight', 'Spotlight (barres en verre)' }, { 'minimal', 'Minimal (icônes rondes)' }, { 'classic', 'Classique (barres au centre bas)' }, { 'photo', 'Photo (colonne grise en bas à gauche, voix en vert)' } }

local look = Form.Cfg({
    ns = 'hud', id = 'look', title = 'Apparence du HUD', perm = 'hud.edit', cols = 2,
    desc = "Appliqué à tous les joueurs connectés dès l'enregistrement. L'aperçu ci-dessous suit tes réglages avant même d'enregistrer.",
    fields = {
        { k = 'enabled', type = 'toggle', label = 'Afficher le HUD du panel', default = true, hint = 'Désactivé : aucun HUD n\'est dessiné.' },
        { k = 'style', type = 'select', label = 'Style', opts = STYLES, default = 'ring' },
        { k = 'units', type = 'select', label = 'Vitesse', opts = { { 'kmh', 'km/h' }, { 'mph', 'mph' } }, default = 'kmh' },
        { k = 'tank_l', type = 'number', label = 'Réservoir (litres, 0 = valeur du véhicule)', default = 0, min = 0, max = 400, hint = "Sert au pourcentage et à l'autonomie." },
        { k = 'l_per_100', type = 'number', label = 'Consommation estimée (L / 100 km)', default = 9, min = 1, max = 60, int = false, step = 0.5, hint = "Autonomie affichée = carburant restant ÷ consommation. C'est une estimation : le jeu ne calcule pas de consommation réelle." },
        { k = 'low_threshold', type = 'number', label = 'Alerte sous (%)', default = 20, min = 0, max = 50, hint = 'La barre clignote sous ce seuil.' },
        { k = 'hide_full', type = 'toggle', label = 'Masquer faim et soif quand elles sont pleines', default = false },
        { k = 'hide_pause', type = 'toggle', label = 'Masquer dans le menu pause', default = true },
        { k = 'minimap', type = 'select', label = 'Mini-carte', opts = { { 'always', 'Toujours' }, { 'vehicle', 'En véhicule seulement' }, { 'never', 'Jamais' } }, default = 'always' },
        { k = 'c_accent', type = 'color', label = 'Couleur principale', default = '#dfe2e7' },
        { k = 'c_health', type = 'color', label = 'Vie', default = '#ff6b7d' },
        { k = 'c_armor', type = 'color', label = 'Armure', default = '#6fb4ff' },
        { k = 'c_hunger', type = 'color', label = 'Faim', default = '#ffb457' },
        { k = 'c_thirst', type = 'color', label = 'Soif', default = '#58d6ff' },
        { k = 'c_stress', type = 'color', label = 'Stress', default = '#b58cff' },
        { k = 'c_stamina', type = 'color', label = 'Endurance / oxygène', default = '#7be0a4' },
        { k = 'show_health', type = 'toggle', label = 'Vie', default = true },
        { k = 'show_armor', type = 'toggle', label = 'Armure (si > 0)', default = true },
        { k = 'show_hunger', type = 'toggle', label = 'Faim', default = true },
        { k = 'show_thirst', type = 'toggle', label = 'Soif', default = true },
        { k = 'show_stress', type = 'toggle', label = 'Stress', default = false },
        { k = 'show_stamina', type = 'toggle', label = 'Endurance / oxygène', default = true },
        { k = 'status_on', type = 'toggle', label = 'Afficher le HUD de statut (vie, faim, soif, argent, heure, boussole…)', default = false },
        { k = 'speedo_style', type = 'select', label = 'Style du compteur', default = 'digits', opts = { { 'digits', 'Chiffres seuls (vitesse + km)' }, { 'disc', 'Cadran avec fond' }, { 'floating', 'Flottant (sans fond)' } } },
        { k = 'speed_max', type = 'number', label = 'Vitesse max du cadran (0 = auto)', default = 0, min = 0, max = 500 },
        { k = 'show_odo', type = 'toggle', label = 'Kilométrage réel du véhicule', default = true },
        { k = 'show_rpm', type = 'toggle', label = 'Arc de régime moteur', default = true },
        { k = 'show_voice', type = 'toggle', label = 'Micro (qui parle)', default = true },
        { k = 'show_clock', type = 'toggle', label = 'Heure', default = true },
        { k = 'show_money', type = 'toggle', label = 'Argent (espèces et banque)', default = true },
        { k = 'show_street', type = 'toggle', label = 'Rue et quartier', default = true },
        { k = 'show_ammo', type = 'toggle', label = "Munitions en haut à droite (remplace celles du jeu)", default = true },
        { k = 'show_compass', type = 'toggle', label = 'Boussole', default = true },
        { k = 'show_vehicle', type = 'toggle', label = 'Compteur en véhicule', default = true },
        { k = 'show_fuel', type = 'toggle', label = 'Carburant', default = true },
    },
})

local needs = Form.Cfg({
    ns = 'hud', id = 'needs', title = 'Besoins : faim, soif, stress', perm = 'hud.edit', cols = 2,
    desc = "Le HUD de statut est masqué par défaut (seul le compteur s'affiche) ; les besoins continuent de descendre en arrière-plan, coupe-les ici si tu ne les utilises pas. Le serveur fait foi : les valeurs sont gérées côté serveur et sauvegardées. Pour restaurer un besoin depuis un script de nourriture : exports.pb_panel:AddStatus(source, 'hunger', 25).",
    fields = {
        { k = 'needs_enabled', type = 'toggle', label = 'Activer la faim, la soif et le stress', default = true },
        { k = 'hunger_rate', type = 'number', label = 'Faim perdue par minute (points)', default = 1.0, min = 0, max = 20, int = false, step = 0.1 },
        { k = 'thirst_rate', type = 'number', label = 'Soif perdue par minute (points)', default = 1.4, min = 0, max = 20, int = false, step = 0.1 },
        { k = 'stress_decay', type = 'number', label = 'Stress retombant par minute (points)', default = 0.5, min = 0, max = 20, int = false, step = 0.1 },
        { k = 'starve_coma', type = 'toggle', label = 'Faim ou soif à 0 : le joueur tombe dans le coma', default = true, hint = "Écran d'inconscience : un secouriste peut le réanimer, sinon réapparition à l'hôpital. Désactivé : il perd de la vie à la place." },
        { k = 'starve_damage', type = 'number', label = 'Dégâts toutes les 10 s quand faim ou soif = 0 (coma désactivé)', default = 2, min = 0, max = 25, hint = '0 = aucun dégât.' },
    },
})

PB.Action('hud.layout.save', 'hud.edit', function(ctx, p)
    local v = p.values or {}
    local grp = (p.group == 'vehicle' or p.group == 'ring' or p.group == 'bar') and p.group or 'main'
    local fields = {
        { k = 'x', type = 'number', label = 'x', min = 0, max = 100, int = false },
        { k = 'y', type = 'number', label = 'y', min = 0, max = 100, int = false },
        { k = 'scale', type = 'number', label = 'Taille', min = 0.5, max = 1.8, int = false },
        { k = 'opacity', type = 'number', label = 'Opacité', min = 0.3, max = 1, int = false },
    }
    local c, err = PB.Validate(fields, { x = v.x, y = v.y, scale = v.scale or 1, opacity = v.opacity or 1 })
    if not c then return false, err end
    local patch
    if grp == 'main' then patch = { pos_x = c.x, pos_y = c.y, scale = c.scale, opacity = c.opacity }
    elseif grp == 'ring' then patch = { ring_x = c.x, ring_y = c.y, scale = c.scale, opacity = c.opacity }
    elseif grp == 'bar' then patch = { bar_x = c.x, bar_y = c.y }
    else patch = { veh_x = c.x, veh_y = c.y, veh_scale = c.scale } end
    local before = {}
    for k in pairs(patch) do before[k] = PB.Cfg.Get('hud', k) end
    local changed, e = PB.Cfg.SetMany('hud', patch, ctx.actor, 'Position du HUD')
    if not changed then return false, e end
    ctx.audit('config', 'hud.position', grp, before, patch)
    ctx.toast = 'Position enregistrée et envoyée aux joueurs.'
    return true
end)

local function preview(ctx)
    return { type = 'gpreview', kind = 'hud', title = 'Aperçu en direct', form = 'hud.look', cfg = PB.Cfg.All('hud') }
end

PB.Module({
    id = 'hud', label = 'HUD', icon = 'activity', group = 'Serveur', order = 130, perm = 'hud.view', hint = 'Vie, faim, soif, compteur, argent',
    caps = function()
        return PB.Capsify({
            { 'Affichage (3 styles, éléments, couleurs, position)', 'ok', 'Appliqué en direct à tous les joueurs connectés.' },
            { 'Faim, soif, stress', 'ok', 'Gérés par le serveur dans la table pb_players ; restauration par exports.pb_panel:AddStatus.' },
            { 'Argent affiché', 'partial', "Affiche l'argent du noyau du panel (pb_players). Il ne lit aucun autre framework." },
            { 'Micro / niveau de voix', 'partial', 'Indique qui parle (voix native du jeu). Pas de portée de voix : pas de lecture de pma-voice ni de saltychat.' },
            { 'Carburant et autonomie', 'partial', "Lit le niveau natif du véhicule (litres) ; l'autonomie est une estimation avec ta consommation moyenne. Un script de carburant tiers peut afficher autre chose." },
            { 'Autre HUD déjà lancé', (GetResourceState('esx_hud') == 'started' or GetResourceState('qb-hud') == 'started' or GetResourceState('ps-hud') == 'started') and 'partial' or 'ok',
                'Deux HUD affichés en même temps se superposent : arrête esx_hud, qb-hud ou ps-hud.' },
        })
    end,
    doc = "## HUD\nQuatre styles au choix, chaque élément s'active ou se masque, les couleurs se règlent ici ; la position se déplace dans **Placement à l'écran** (vrais éléments, glisser-déposer).\n\n- Les **besoins** (faim, soif, stress) sont suivis par le serveur ; ils s'arrêtent tant que le personnage n'est pas créé ou s'il est mort.\n- **Restaurer un besoin** depuis un autre script : `exports.pb_panel:AddStatus(source, 'hunger', 25)`.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('look', 'Apparence', 'palette', function() return { look(ctx), preview(ctx) } end),
            tab('needs', 'Besoins', 'heart', function() return { needs(ctx) } end),
            tab('qmap', 'Carte rapide (M)', 'map', function() return { G.MiniMapForm and G.MiniMapForm(ctx) or { type = 'notice', text = '' } } end),
        } }
    end,
})

-- Kilométrage réel ------------------------------------------------------------------------------------------------------------------
-- Le client mesure la distance réellement parcourue (positions successives, conducteur seulement) et l'envoie par paquets ;
-- le serveur plafonne selon le temps écoulé (anti-triche), ne retient que les véhicules possédés et sauvegarde par plaque.
PB.Migrate('160_game_odometer', 'Compteur kilométrique des véhicules', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_vehicle_odo (plate VARCHAR(12) NOT NULL, meters BIGINT NOT NULL DEFAULT 0, updated INT NOT NULL DEFAULT 0, PRIMARY KEY (plate))]]))
end)
PB.Cfg.Define('odo', { enabled = true })
local Odo, odoLast = {}, {}
G.Odo = Odo
local function plateKey(p) p = tostring(p or ''):upper():gsub('^%s+', ''):gsub('%s+$', '') if #p < 1 or #p > 8 then return nil end return p end
local function ownsPlate(p) return DB.one('SELECT 1 AS x FROM pb_vehicles WHERE plate = ?', { p }) ~= nil end
function Odo.Get(plate) local p = plateKey(plate) if not p then return nil end local r = DB.one('SELECT meters FROM pb_vehicle_odo WHERE plate = ?', { p }) return r and tonumber(r.meters) or 0 end
-- Ajoute des mètres : plafonné à 100 m/s depuis le dernier envoi (+150 m de marge), jamais plus de 25 km d'un coup.
function Odo.Add(src, plate, meters, tnow)
    local p = plateKey(plate) meters = math.floor(tonumber(meters) or 0)
    if not p or meters < 1 then return 0 end
    local last = odoLast[src] or (tnow - 30000)
    local cap = math.min(25000, ((tnow - last) / 1000) * 100 + 150)
    odoLast[src] = tnow
    if meters > cap then meters = math.floor(cap) end
    if meters < 1 or not ownsPlate(p) then return 0 end
    DB.exec('INSERT INTO pb_vehicle_odo (plate, meters, updated) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE meters = meters + VALUES(meters), updated = VALUES(updated)', { p, meters, os.time() })
    return meters
end
RegisterNetEvent('pb:g:odo:get', function(plate)
    local src = source
    if not PB.Cfg.Get('odo', 'enabled', true) then return end
    local p = plateKey(plate) if not p then return end
    odoLast[src] = (GetGameTimer and GetGameTimer() or os.time() * 1000)
    TriggerClientEvent('pb:g:odo', src, PB.Json({ plate = p, m = Odo.Get(p) or 0, own = ownsPlate(p) }))
end)
RegisterNetEvent('pb:g:odo:add', function(plate, meters)
    local src = source
    if not PB.Cfg.Get('odo', 'enabled', true) or not G.Get(src) then return end
    Odo.Add(src, plate, meters, GetGameTimer and GetGameTimer() or os.time() * 1000)
end)
AddEventHandler('playerDropped', function() odoLast[source] = nil end)

-- Une seule fois : le HUD « photo » devient le style de base (les réglages faits ensuite dans le panel sont conservés).
PB.OnReady(function()
    if PB.Cfg.Get('hud', 'photo_v1', false) ~= true then
        PB.Cfg.Set('hud', 'style', 'photo', nil, 'HUD photo par défaut')
        PB.Cfg.Set('hud', 'status_on', true, nil, 'HUD photo par défaut')
        PB.Cfg.Set('hud', 'photo_v1', true, nil, 'Migration')
    end
end)

-- Une seule fois : le HUD « Shadow » (comme la référence) devient le style de base ; réglable ensuite dans le panel
PB.OnReady(function()
    if PB.Cfg.Get('hud', 'shadow_v1', false) ~= true then
        PB.Cfg.Set('hud', 'style', 'shadow', nil, 'HUD Shadow par défaut')
        PB.Cfg.Set('hud', 'shadow_v1', true, nil, 'Migration')
    end
end)
-- joueurs en ligne (coin en haut à droite du HUD Shadow), envoyé à tous toutes les 15 secondes
CreateThread(function()
    Wait(math.random(0, 15000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(15000)
        local n = 0
        for _ in pairs(PB.G.Players()) do n = n + 1 end
        TriggerClientEvent('pb:g:hud:srv', -1, PB.Json({ online = n, max = GetConvarInt and GetConvarInt('sv_maxclients', 48) or 48 }))
    end
end)

-- métier et organisation du joueur (HUD Shadow, en haut à droite) : à l'arrivée, à chaque changement, et toutes les 30 s
local function meOf(src)
    local j = PB.G.Biz and PB.G.Biz.Job and PB.G.Biz.Job(src)
    local g = PB.G.Tags and PB.G.Tags.Gang and PB.G.Tags.Gang(src)
    return { job = j and j.label or nil, grade = j and j.gradeLabel or nil, duty = j and j.onDuty or nil, org = g and g.label or nil, oc = g and g.color or nil }
end
local function pushMe(src) if PB.G.Players()[src] then TriggerClientEvent('pb:g:hud:me', src, PB.Json(meOf(src))) end end
table.insert(PB.G.beginHooks, function(src) SetTimeout(1500, function() pushMe(src) end) end)
AddEventHandler('pb_panel:jobChanged', function(src) SetTimeout(300, function() pushMe(tonumber(src)) end) end)
AddEventHandler('pb_panel:gangChanged', function(src) SetTimeout(300, function() pushMe(tonumber(src)) end) end)
AddEventHandler('pb_panel:duty', function(src) SetTimeout(300, function() pushMe(tonumber(src)) end) end)
CreateThread(function() Wait(math.random(0, 30000)) while true do Wait(30000) for src in pairs(PB.G.Players()) do pushMe(src) end end end)
