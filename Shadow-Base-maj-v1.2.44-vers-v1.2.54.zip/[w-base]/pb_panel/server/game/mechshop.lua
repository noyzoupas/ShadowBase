-- Atelier facturé : le mécanicien en service répare, nettoie ou customise le véhicule, puis ENVOIE LA FACTURE au client.
-- Le client voit le montant et paie (ou refuse) ; l'argent va dans la caisse de l'entreprise. Une customisation refusée est retirée
-- du véhicule ; payée, elle est enregistrée avec le véhicule (elle revient à chaque sortie de garage).
-- Customisation : le mécanicien doit être DANS le véhicule ; chaque option s'affiche en direct sur la voiture (le client voit le rendu).
-- Le serveur recalcule tous les prix à partir de sa propre grille : le client n'envoie que la liste des changements.
local P, DB, G = PB.Perm, PB.DB, PB.G
local M = G.Mech

PB.Cfg.Define('mech', { repair_price = 500, clean_price = 100, repair_secs = 10, clean_secs = 6, bill_dist = 8, offer_secs = 60,
    prices = { color = 600, pearl = 400, wheelcol = 250, interior = 300, rgb = 900, wheel = 900, body = 500, turbo = 4000, xenon = 800, xcol = 200,
        neon = 1200, ncol = 200, smoke = 300, scol = 150, tint = 250, plate = 300, horn = 150, livery = 500, extra = 350 } })
local function cfg(k, d) return PB.Cfg.Get('mech', k, d) end
local function eco(v) return G.Eco and G.Eco.Final and G.Eco.Final(v) or v end   -- onglet Économie : multiplicateur des prix × TVA
local function price(k) local p = cfg('prices', {}) or {} return eco(math.max(0, math.floor(tonumber(p[k]) or 0))) end
local function money(n) return PB.Money(n) end   -- (v1.2.43) « -500 $ » s'affichait « - 500 $ »
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end
local function now() return os.time() end
local function price_or(v) return eco(math.max(0, math.floor(tonumber(v) or 0))) end

local function mechanic(src)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or not c.duty or not G.Biz.Allowed(c, 'repair') then return nil, 'Il faut être mécanicien en service.' end
    local p = G.Get(src)
    if not p or PB.ToBool(p.row.dead) or (G.IsCuffed and G.IsCuffed(src)) then return nil, 'Indisponible.' end
    return c
end
local function entOf(netId) local ok, e = pcall(NetworkGetEntityFromNetworkId, math.floor(tonumber(netId) or 0)) if ok and e and e ~= 0 and DoesEntityExist(e) then return e end end
local function distTo(src, ent) local a, b = GetEntityCoords(ent), GetEntityCoords(GetPlayerPed(src)) local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z return math.sqrt(dx * dx + dy * dy + dz * dz) end
local function plateOf(ent) return (tostring(GetVehicleNumberPlateText(ent) or '')):gsub('%s+$', ''):sub(1, 12) end

-- Travail en cours du mécanicien : ce qui sera facturé { items = { { label, price } }, custom, plate, netId }
local work, jobs, pending = {}, {}, {}
local function addItem(src, label, amount, extra)
    local w = work[src] or { items = {} }
    work[src] = w
    w.items[#w.items + 1] = { label = label, price = math.floor(amount) }
    for k, v in pairs(extra or {}) do w[k] = v end
    local total = 0 for _, it in ipairs(w.items) do total = total + it.price end
    return total
end
function M.Work(src) return work[src] end
M.AddItem = addItem   -- actions de métier (jobpacks.lua) : moteur, carrosserie, pneus… ajoutés à la facture

-- Réparation / nettoyage : début (le serveur note l'heure), fin (durée vérifiée), ajout à la facture
RegisterNetEvent('pb:g:mech:start', function(kind, netId)
    local src = source
    local c, err = mechanic(src)
    if not c then G.Notify(src, { type = 'error', title = 'Atelier', text = err }) return end
    kind = kind == 'clean' and 'clean' or 'repair'
    local ent = entOf(netId)
    if ent and distTo(src, ent) > 7.0 then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Approche-toi du véhicule.' }) return end
    local secs = math.max(2, tonumber(cfg(kind .. '_secs', kind == 'clean' and 6 or 10)) or 8)
    jobs[src] = { kind = kind, netId = math.floor(tonumber(netId) or 0), at = now(), secs = secs }
    TriggerClientEvent('pb:g:mech:work', src, PB.Json({ kind = kind, netId = jobs[src].netId, secs = secs }))
end)
RegisterNetEvent('pb:g:mech:done', function()
    local src = source
    local j = jobs[src]
    jobs[src] = nil
    if not j then return end
    local c = mechanic(src)
    if not c then return end
    if now() - j.at < j.secs - 1 then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Travail bâclé : recommence.' }) return end
    local ent = entOf(j.netId)
    if ent and distTo(src, ent) > 8.0 then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Tu t\'es éloigné du véhicule.' }) return end
    TriggerClientEvent('pb:g:mech:do', src, PB.Json({ netId = j.netId, key = j.kind, kind = j.kind, level = 1 }))
    local plate = ent and plateOf(ent) or ''
    if j.kind == 'repair' and plate ~= '' and G.Garage then G.Garage.ResetDamage(plate) end
    local amount = j.kind == 'clean' and price_or(cfg('clean_price', 100)) or price_or(cfg('repair_price', 500))
    local total = addItem(src, j.kind == 'clean' and 'Nettoyage' or 'Réparation complète', amount, { plate = plate, netId = j.netId })
    G.Notify(src, { type = 'success', title = 'Atelier', text = ('%s ajouté à la facture (%s). Total : %s — F6 › Envoyer la facture.'):format(j.kind == 'clean' and 'Nettoyage' or 'Réparation', money(amount), money(total)) })
end)

-- Customisation : liste des changements { { k, v } } -> devis recalculé ici ------------------------------------------------------------------------
local PERF = { [11] = true, [12] = true, [13] = true, [15] = true, [16] = true }
local function num(v, lo, hi) v = tonumber(v) if not v or v ~= v then return nil end v = math.floor(v) if v < lo or v > hi then return nil end return v end
local function rgb(v) if type(v) ~= 'table' then return nil end local r, g, b = num(v[1], 0, 255), num(v[2], 0, 255), num(v[3], 0, 255) if not (r and g and b) then return nil end return { r, g, b } end
local LABEL = { col1 = 'Peinture principale', col2 = 'Peinture secondaire', pearl = 'Nacré', wheelcol = 'Couleur des jantes', int = 'Couleur intérieure', dash = 'Couleur du tableau de bord',
    rgb1 = 'Teinte personnalisée (principale)', rgb2 = 'Teinte personnalisée (secondaire)', wheel = 'Jantes', turbo = 'Turbo', xenon = 'Phares xénon', xcol = 'Couleur des xénons',
    neon = 'Néons', ncol = 'Couleur des néons', smoke = 'Fumée des pneus', scol = 'Couleur de la fumée', tint = 'Vitres teintées', plate = 'Plaque', horn = 'Klaxon', livery = 'Livrée' }
-- renvoie valeur nettoyée, libellé, prix ; nil si refusé
function M.CustomPrice(k, v, partLabel)
    k = tostring(k or '')
    if k == 'col1' or k == 'col2' then local t = type(v) == 'table' and num(v[1], 0, 160) if not t then return nil end return { t }, LABEL[k], price('color') end
    if k == 'pearl' or k == 'wheelcol' or k == 'int' or k == 'dash' then local x = num(v, 0, 160) if not x then return nil end return x, LABEL[k], price(k == 'pearl' and 'pearl' or k == 'wheelcol' and 'wheelcol' or 'interior') end
    if k == 'rgb1' or k == 'rgb2' then
        if v == false then return false, LABEL[k] .. ' retirée', 0 end   -- « Aucune » : on enlève la teinte libre, gratuit
        local c = rgb(v) if not c then return nil end return c, LABEL[k], price('rgb')
    end
    local xt = num(tostring(k):match('^xt:(%d+)$'), 1, 14)   -- option propre au modèle (extras, surtout des véhicules addon)
    if xt then if type(v) ~= 'boolean' then return nil end return v, 'Option du modèle ' .. xt .. (v and ' montée' or ' retirée'), price('extra') end
    if k == 'wheel' then if type(v) ~= 'table' then return nil end local t, i = num(v[1], 0, 12), num(v[2], -1, 250) if not (t and i) then return nil end return { t, i, v[3] == true }, LABEL.wheel, price('wheel') end
    if k == 'turbo' or k == 'xenon' or k == 'smoke' then return v == true, LABEL[k], v == true and price(k) or 0 end
    if k == 'xcol' then local x = num(v, -1, 12) if not x then return nil end return x, LABEL.xcol, price('xcol') end
    if k == 'neon' then if type(v) ~= 'table' then return nil end local t = { v[1] == true, v[2] == true, v[3] == true, v[4] == true } local any = t[1] or t[2] or t[3] or t[4] return t, LABEL.neon, any and price('neon') or 0 end
    if k == 'ncol' or k == 'scol' then local c = rgb(v) if not c then return nil end return c, LABEL[k], price(k) end
    if k == 'tint' then local x = num(v, 0, 6) if not x then return nil end return x, LABEL.tint, price('tint') end
    if k == 'plate' then local x = num(v, 0, 5) if not x then return nil end return x, LABEL.plate, price('plate') end
    if k == 'horn' then local x = num(v, -1, 60) if not x then return nil end return x, LABEL.horn, price('horn') end
    if k == 'livery' then local x = num(v, -1, 60) if not x then return nil end return x, LABEL.livery, price('livery') end
    local mt = num(tostring(k):match('^mod:(%d+)$'), 0, 48)
    if mt then
        local x = num(v, -1, 250)
        if not x then return nil end
        local lab = tostring(partLabel or ('Pièce ' .. mt)):gsub('[%c<>]', ''):sub(1, 40)
        if PERF[mt] then
            local base = mt == 11 and 1500 or mt == 12 and 900 or mt == 13 and 1100 or mt == 15 and 700 or 1200
            for _, p in ipairs(cfg('parts', {}) or {}) do if tonumber(p.mod) == mt and p.kind == 'mod' then base = tonumber(p.price) or base end end
            return x, lab, x < 0 and 0 or eco(math.floor(base * (x + 1)))
        end
        return x, lab, x < 0 and 0 or price(mt >= 25 and 'extra' or 'body')
    end
    return nil
end

RegisterNetEvent('pb:g:mech:quote', function(netId, changes)
    local src = source
    local c, err = mechanic(src)
    if not c then G.Notify(src, { type = 'error', title = 'Atelier', text = err }) return end
    local ent = entOf(netId)
    if not ent then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Véhicule introuvable.' }) return end
    if GetVehiclePedIsIn(GetPlayerPed(src), false) ~= ent then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Pour customiser, il faut être dans le véhicule.' }) return end
    if type(changes) ~= 'table' then return end
    local custom, items, total, refused = {}, {}, 0, {}
    for i, ch in ipairs(changes) do
        if i > 60 then break end
        if type(ch) == 'table' then
            local v, lab, p = M.CustomPrice(ch.k, ch.v, ch.label)
            if v ~= nil then
                local ks = tostring(ch.k)
                if ks:match('^mod:') then custom.mods = custom.mods or {} custom.mods[ks:sub(5)] = v
                elseif ks:match('^xt:') then custom.extras = custom.extras or {} custom.extras[ks:sub(4)] = v
                else custom[ch.k] = v end
                items[#items + 1] = { label = lab, price = p }
                total = total + p
            else
                refused[#refused + 1] = tostring(ch.label or ch.k):gsub('[%c<>]', ''):sub(1, 30)   -- jamais en silence : le mécanicien le voit
            end
        end
    end
    if #refused > 0 then
        G.Notify(src, { type = 'warn', title = 'Atelier', text = ('%d réglage(s) refusé(s) par le serveur : %s.'):format(#refused, table.concat(refused, ', ')) })
    end
    if #items == 0 then G.Notify(src, { type = 'warn', title = 'Atelier', text = 'Le devis est vide.' }) return end
    local plate = plateOf(ent)
    -- un nouveau devis remplace la customisation précédente pas encore facturée ; réparation / nettoyage restent
    local w = work[src] or { items = {} }
    local keep = {}
    for _, it in ipairs(w.items) do if not it.custom then keep[#keep + 1] = it end end
    for _, it in ipairs(items) do it.custom = true keep[#keep + 1] = it end
    work[src] = { items = keep, custom = custom, plate = plate, netId = math.floor(tonumber(netId) or 0) }
    local sum = 0 for _, it in ipairs(keep) do sum = sum + it.price end
    TriggerClientEvent('pb:g:mech:quoted', src, PB.Json({ items = items, total = total, all = sum }))
    G.Notify(src, { type = 'success', title = 'Devis prêt', text = ('Customisation : %s (%d options). Total à facturer : %s. Envoie la facture au client.'):format(money(total), #items, money(sum)) })
end)

-- Facture au client : il voit le détail et paie ou refuse ----------------------------------------------------------------------------------------
function M.Bill(src, target)
    local c, err = mechanic(src)
    if not c then G.Notify(src, { type = 'error', title = 'Atelier', text = err }) return end
    local w = work[src]
    if not w or #w.items == 0 then G.Notify(src, { type = 'warn', title = 'Atelier', text = "Rien à facturer : répare, nettoie ou fais un devis d'abord." }) return end
    target = tonumber(target)
    local tp = target and G.Get(target)
    if not tp or target == src then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Choisis un client à côté de toi.' }) return end
    if G.DistBetween(src, target) > (tonumber(cfg('bill_dist', 8)) or 8) then G.Notify(src, { type = 'error', title = 'Atelier', text = 'Le client est trop loin.' }) return end
    local total, parts = 0, {}
    for _, it in ipairs(w.items) do total = total + it.price parts[#parts + 1] = it.label end
    local reason = ('Atelier : %s'):format(table.concat(parts, ', ')):sub(1, 120)
    local id = DB.insert('INSERT INTO pb_biz_invoices (biz_id, license, name, amount, reason, kind, status, by_name, by_license, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { c.biz.id, tp.license, display(target), total, reason, 'invoice', 'pending', display(src), c.license, now() })
    if not id then return end
    pending[id] = { mech = src, custom = w.custom, plate = w.plate, netId = w.netId, biz = c.biz.label, at = now() }
    work[src] = nil
    TriggerClientEvent('pb:g:mech:offer', target, PB.Json({ id = id, biz = c.biz.label, from = display(src), amount = total, items = w.items }))
    G.Notify(src, { type = 'info', title = 'Facture envoyée', text = ('%s pour %s. En attente du paiement.'):format(money(total), display(target)) })
    TriggerEvent('pb_panel:invoice', src, target, c.biz.id, total, reason)
    return true
end
RegisterNetEvent('pb:g:mech:bill', function(target) M.Bill(source, target) end)
RegisterNetEvent('pb:g:mech:answer', function(id, accept)
    local src = source
    id = math.floor(tonumber(id) or 0)
    local pd = pending[id]
    local inv = DB.one('SELECT * FROM pb_biz_invoices WHERE id = ?', { id })
    if not inv or inv.status ~= 'pending' then return end
    if accept ~= true then
        local p = G.Get(src)
        if not p or p.license ~= inv.license then return end
        DB.exec("UPDATE pb_biz_invoices SET status = 'cancelled' WHERE id = ?", { id })
        if pd then
            pending[id] = nil
            if G.Get(pd.mech) then
                G.Notify(pd.mech, { type = 'warn', title = 'Facture refusée', text = display(src) .. ' a refusé la facture.' .. (pd.custom and ' La customisation est retirée du véhicule.' or '') })
                if pd.custom then TriggerClientEvent('pb:g:mech:revert', pd.mech, pd.netId) end
            end
        end
        return
    end
    local ok, why = G.Biz.PayInvoice(src, id)
    if not ok then G.Notify(src, { type = 'error', title = 'Facture', text = why }) end
end)
-- paiement (ici ou plus tard dans la tablette / le téléphone) : la customisation devient définitive
AddEventHandler('pb_panel:invoicePaid', function(id, payer)
    local pd = pending[id]
    if not pd then return end
    pending[id] = nil
    if pd.custom and pd.plate ~= '' and G.Garage and G.Garage.Vehicle(pd.plate) then
        local v = G.Garage.Vehicle(pd.plate)
        local t = PB.FromJson(v.props, nil)
        local cur = type(t) == 'table' and type(t.mods) == 'table' and type(t.mods.custom) == 'table' and t.mods.custom or {}
        for k, val in pairs(pd.custom) do
            if k == 'mods' or k == 'extras' then cur[k] = cur[k] or {} for mk, mv in pairs(val) do cur[k][mk] = mv end else cur[k] = val end
        end
        G.Garage.SetMod(pd.plate, 'custom', cur)
    end
    if payer then G.Notify(payer, { type = 'success', title = pd.biz, text = 'Facture payée. Merci de ta visite !' }) end   -- payé depuis la tablette : le client peut ne pas être en ligne
    if G.Get(pd.mech) then
        G.Notify(pd.mech, { type = 'success', title = 'Facture payée', text = (payer and display(payer) or 'Le client') .. ' a payé : l\'argent est dans la caisse.' .. (pd.custom and ' Customisation enregistrée avec le véhicule.' or '') })
        if pd.custom then TriggerClientEvent('pb:g:mech:keep', pd.mech, pd.netId) end
    end
end)
-- factures oubliées : au bout de 30 minutes, une customisation non payée est retirée
CreateThread(function()
    Wait(math.random(0, 60000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(60000)
        for id, pd in pairs(pending) do
            if now() - pd.at > 1800 then
                pending[id] = nil
                if pd.custom and G.Get(pd.mech) then TriggerClientEvent('pb:g:mech:revert', pd.mech, pd.netId) end
            end
        end
    end
end)
AddEventHandler('playerDropped', function() work[source] = nil jobs[source] = nil end)

-- La customisation se fait seulement au garage : à moins de 15 m d'un point « atelier » de l'entreprise (posé au Builder).
-- Plus depuis le menu F6, ni sans atelier posé.
function M.AtWorkshop(src, c)
    local list = {}
    for _, p in ipairs(G.Points and G.Points.Of('biz', c.biz.id) or {}) do if p.kind == 'workshop' then list[#list + 1] = p end end
    if #list == 0 then G.Notify(src, { type = 'warn', title = 'Atelier', text = "Ton garage n'a pas encore d'atelier : le staff doit le poser au Builder." }) return false end
    for _, p in ipairs(list) do if G.DistTo(src, p.x, p.y, p.z) <= 15.0 then return true end end
    G.Notify(src, { type = 'warn', title = 'Atelier', text = "La customisation se fait au garage : amène le véhicule à l'atelier." })
    return false
end
-- Ouverture de l'atelier (point « atelier » du Builder) : la grille de prix part au client
function M.Open(src)
    local c, err = mechanic(src)
    if not c then G.Notify(src, { type = 'warn', title = 'Atelier', text = err }) return end
    if not M.AtWorkshop(src, c) then return end
    local ped = GetPlayerPed(src)
    if GetVehiclePedIsIn(ped, false) == 0 then G.Notify(src, { type = 'warn', title = 'Atelier', text = 'Monte dans le véhicule du client pour le customiser.' }) return end
    -- prix affichés = prix réellement facturés (onglet Économie compris) ; performances : prix du niveau 1 (niveau N = N × ce prix)
    local shown, perf = {}, {}
    for k in pairs(cfg('prices', {}) or {}) do shown[k] = price(k) end
    for _, t in ipairs({ 11, 12, 13, 15, 16 }) do local _, _, pr = M.CustomPrice('mod:' .. t, 0, '') perf[tostring(t)] = pr or 0 end
    TriggerClientEvent('pb:g:mech:ui', src, PB.Json({ prices = shown, perf = perf, parts = cfg('parts', {}), biz = c.biz.label }))
end

local pricesForm = PB.Form.Cfg({ ns = 'mech', id = 'billing', title = 'Atelier facturé', perm = 'mech.edit', cols = 2, fields = {
    { k = 'repair_price', type = 'number', label = 'Prix de la réparation complète (facturé au client)', default = 500, min = 0, max = 1000000 },
    { k = 'clean_price', type = 'number', label = 'Prix du nettoyage', default = 100, min = 0, max = 1000000 },
    { k = 'repair_secs', type = 'number', label = 'Durée de la réparation (s)', default = 10, min = 2, max = 120 },
    { k = 'clean_secs', type = 'number', label = 'Durée du nettoyage (s)', default = 6, min = 2, max = 120 },
    { k = 'bill_dist', type = 'number', label = 'Distance maximale du client pour la facture (m)', default = 8, min = 2, max = 30 },
} })
M.BillingForm = pricesForm

-- (v1.2.43) « Pièces détachées » des garages : jamais vide. Le stock de kits de réparation remonte tout seul jusqu'au minimum réglé ;
-- par défaut seul le patron y accède (kits offerts aux clients). Réglages : Atelier › Kits de réparation.
PB.Cfg.Define('mech', { kits_min = 25, kits_boss_only = true })
local function partsStashes()
    return DB.q("SELECT s.id FROM pb_inv_stashes s JOIN pb_biz b ON b.id = s.biz WHERE b.kind = 'garage' AND s.label = 'Pièces détachées'") or {}
end
function M.RestockKits()
    local want = math.max(0, math.min(500, math.floor(tonumber(PB.Cfg.Get('mech', 'kits_min', 25)) or 25)))
    if want <= 0 or not (G.Inv and G.Inv.Def and G.Inv.Def('repair_kit')) then return 0 end
    local n = 0
    for _, r in ipairs(partsStashes()) do
        local owner = 's:' .. tostring(r.id)
        local have = G.Inv.Count(owner, 'repair_kit')
        if have < want and G.Inv.Add(owner, 'repair_kit', want - have) then n = n + 1 end
    end
    return n
end
local function applyBossOnly()
    local g = PB.Cfg.Get('mech', 'kits_boss_only', true) ~= false and 99 or 0
    for _, r in ipairs(partsStashes()) do DB.exec('UPDATE pb_inv_stashes SET min_grade = ? WHERE id = ?', { g, r.id }) end
end
M.KitsBossOnly = applyBossOnly
PB.OnReady(function()
    applyBossOnly()
    M.RestockKits()
    CreateThread(function() while true do Wait(5 * 60 * 1000) pcall(M.RestockKits) pcall(applyBossOnly) end end)
end)
PB.Cfg.OnChange('mech', function() pcall(applyBossOnly) pcall(M.RestockKits) end)
M.KitsForm = PB.Form.Cfg({ ns = 'mech', id = 'kits', title = 'Kits de réparation (Pièces détachées)', perm = 'mech.edit', cols = 2, fields = {
    { k = 'kits_min', type = 'number', label = 'Kits toujours disponibles (réassort automatique)', default = 25, min = 0, max = 500, hint = 'Le coffre « Pièces détachées » de chaque garage remonte à ce nombre toutes les 5 minutes. 0 = pas de réassort.' },
    { k = 'kits_boss_only', type = 'toggle', label = 'Réservé au patron', default = true, hint = 'Le patron y prend des kits à offrir à ses clients ; les employés n\'y ont pas accès.' },
} })

PB.SelfTest.Add('atelier_customs', function(R)
    local v, _, p = M.CustomPrice('rgb1', false)
    R.check(v == false and p == 0, 'customs', 'retirer la teinte libre doit être accepté et gratuit')
    R.check(M.CustomPrice('rgb1', { -1, -1, -1 }) == nil, 'customs', '{ -1, -1, -1 } ne doit jamais être enregistré')
    local x, lab = M.CustomPrice('xt:3', true)
    R.check(x == true and tostring(lab):find('montée'), 'customs', 'option du modèle (extra) refusée')
    R.check(M.CustomPrice('xt:15', true) == nil and M.CustomPrice('xt:3', 'oui') == nil, 'customs', 'extra invalide accepté')
    R.check(M.CustomPrice('mod:99', 1) == nil, 'customs', 'pièce inconnue acceptée')
end)
