-- Props permanents (menu staff F10 › Props permanents) : le staff pose des objets du jeu (barrières, tables, décor…) qui restent
-- après un redémarrage. Le serveur garde la liste et revérifie chaque pose (droit, service, modèle, distance) ; chaque client
-- fait apparaître localement les objets proches de lui (aucun objet réseau : rien à synchroniser, rien à voler).

local G, DB, P = PB.G, PB.DB, PB.Perm
local Pr = {}
G.Props = Pr

P.Register('staff.props', 'Poser et retirer des props permanents', 'staff', true)
PB.Migrate('376_props', 'Props permanents du staff', {
    [[CREATE TABLE IF NOT EXISTS pb_props (id INT NOT NULL AUTO_INCREMENT, model VARCHAR(64) NOT NULL, label VARCHAR(48) NOT NULL DEFAULT '', x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
        h DOUBLE NOT NULL DEFAULT 0, pitch DOUBLE NOT NULL DEFAULT 0, roll DOUBLE NOT NULL DEFAULT 0, collide TINYINT(1) NOT NULL DEFAULT 1, by_name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (id))]],
})
PB.Cfg.Define('props', { enabled = true, max = 500, place_dist = 40, presets = {
    'prop_barrier_work05|Barrière de chantier', 'prop_mp_barrier_02b|Barrière de police', 'prop_roadcone02a|Cône', 'prop_table_03|Table', 'prop_chair_01a|Chaise',
    'prop_bench_01a|Banc', 'prop_tent_01|Tente', 'prop_gazebo_02|Barnum', 'prop_worklight_03b|Projecteur', 'prop_generator_03b|Groupe électrogène',
    'prop_boxpile_07d|Pile de cartons', 'prop_pallet_02a|Palette', 'prop_container_01a|Conteneur', 'prop_dumpster_01a|Benne', 'prop_bbq_1|Barbecue',
    'prop_fire_exting_1a|Extincteur', 'prop_atm_01|Distributeur (décor)', 'prop_vend_soda_01|Distributeur de boissons', 'prop_streetlight_01|Lampadaire', 'prop_flag_france|Drapeau' } })
local function cfg(k, d) return PB.Cfg.Get('props', k, d) end
local function num(v, lo, hi) v = tonumber(v) if not v or v ~= v then return nil end return math.max(lo, math.min(hi, v)) end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):sub(1, n)) end

local cache = nil
function Pr.List()
    if cache then return cache end
    local rows = DB.q('SELECT id, model, label, x, y, z, h, pitch, roll, collide FROM pb_props ORDER BY id') or {}
    cache = {}
    for _, r in ipairs(rows) do cache[#cache + 1] = { id = tonumber(r.id), m = r.model, l = r.label, x = tonumber(r.x), y = tonumber(r.y), z = tonumber(r.z), h = tonumber(r.h) or 0, p = tonumber(r.pitch) or 0, r = tonumber(r.roll) or 0, c = PB.ToBool(r.collide) and 1 or 0 } end
    return cache
end
local function pushAll(target)
    local j = PB.Json(cfg('enabled', true) ~= false and Pr.List() or {})
    TriggerClientEvent('pb:g:props:all', target or -1, j)
end
table.insert(G.beginHooks, function(src) pushAll(src) end)

local function allowed(src)
    if not P.Has(src, 'staff.props') then return false, 'Droit manquant (props permanents).' end
    if G.Staff and G.Staff.OnDuty and PB.Cfg.Get('staff', 'require_duty', true) ~= false and not G.Staff.OnDuty(src) then return false, 'Passe en service staff.' end
    return true
end
local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < ms then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

function Pr.Place(src, d)
    local ok, why = allowed(src)
    if not ok then return false, why end
    if type(d) ~= 'table' then return false, 'Données invalides.' end
    local model = tostring(d.model or ''):lower()
    if not model:match('^[%w_]+$') or #model > 64 then return false, 'Nom de modèle invalide.' end
    if #Pr.List() >= (tonumber(cfg('max', 500)) or 500) then return false, 'Trop de props posés (maximum atteint).' end
    local x, y, z = num(d.x, -10000, 10000), num(d.y, -10000, 10000), num(d.z, -500, 3000)
    if not x or not y or not z then return false, 'Position invalide.' end
    if G.DistTo(src, x, y, z) > (tonumber(cfg('place_dist', 40)) or 40) then return false, 'Trop loin de toi.' end
    local h, pitch, roll = num(d.h, -360, 720) or 0, num(d.p, -90, 90) or 0, num(d.r, -90, 90) or 0
    local label = clean(d.label, 48)
    local who = PB.Actor and PB.Actor(src).name or ('#' .. src)
    DB.insert('INSERT INTO pb_props (model, label, x, y, z, h, pitch, roll, collide, by_name, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        { model, label, x, y, z, h % 360, pitch, roll, d.c == false and 0 or 1, tostring(who):sub(1, 64), os.time() })
    cache = nil
    PB.Audit.Log('staff', 'props.place', src, model, nil, nil, { x = math.floor(x), y = math.floor(y), z = math.floor(z) })
    pushAll()
    return true, (label ~= '' and label or model) .. ' posé : il restera après un redémarrage.'
end
function Pr.Remove(src, id)
    local ok, why = allowed(src)
    if not ok then return false, why end
    id = math.floor(tonumber(id) or 0)
    local row
    for _, r in ipairs(Pr.List()) do if r.id == id then row = r end end
    if not row then return false, 'Prop introuvable.' end
    if G.DistTo(src, row.x, row.y, row.z) > 150 then return false, 'Approche-toi du prop pour le retirer.' end
    DB.exec('DELETE FROM pb_props WHERE id = ?', { id })
    cache = nil
    PB.Audit.Log('staff', 'props.remove', src, row.m, nil, nil, { id = id })
    pushAll()
    return true, 'Prop retiré.'
end
RegisterNetEvent('pb:g:props:place', function(d)
    local src = source
    if not throttle(src, 700) then return end
    local ok, msg = Pr.Place(src, d)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Props', text = msg })
end)
RegisterNetEvent('pb:g:props:remove', function(id)
    local src = source
    if not throttle(src, 500) then return end
    local ok, msg = Pr.Remove(src, id)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Props', text = msg })
end)
-- liste des modèles proposés (menu staff)
RegisterNetEvent('pb:g:props:presets', function()
    local src = source
    if not allowed(src) then return end
    local out = {}
    for _, line in ipairs(cfg('presets', {}) or {}) do
        local m, l = tostring(line):match('^([%w_]+)|(.+)$')
        if m then out[#out + 1] = { m = m:lower(), l = clean(l, 40) } end
    end
    TriggerClientEvent('pb:g:props:presets', src, PB.Json(out))
end)
PB.Cfg.OnChange('props', function() pushAll() end)

local form = PB.Form.Cfg({ ns = 'props', id = 'settings', title = 'Props permanents', perm = 'staff.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Props permanents affichés', default = true },
    { k = 'max', type = 'number', label = 'Nombre maximum de props', default = 500, min = 10, max = 3000 },
    { k = 'place_dist', type = 'number', label = 'Distance max de pose (m)', default = 40, min = 5, max = 200 },
    { k = 'presets', type = 'list', label = 'Modèles proposés (modele|nom, un par ligne)', default = {}, maxitems = 60, maxlen = 80, pattern = '^[%w_]+|.+$', wide = true, hint = "Noms de modèles du jeu (ex. prop_barrier_work05). Le staff peut aussi taper un autre nom de modèle en jeu." },
} })
PB.Module({
    id = 'props', label = 'Props permanents', icon = 'box', group = 'Serveur', order = 141, perm = 'staff.edit', hint = 'Objets posés par le staff, gardés après redémarrage',
    caps = function() return PB.Capsify({
        { 'Pose en jeu avec aperçu (F10 › Props permanents)', 'ok', 'Flèches pour le déplacer, molette pour le tourner, puis E ; le serveur vérifie le droit, le service et la distance.' },
        { 'Gardés après un redémarrage', 'ok', 'Enregistrés en base ; chaque joueur fait apparaître les props proches de lui.' },
        { 'Vérifié dans un vrai client FiveM', 'off', 'Non : testé en simulation.' } }) end,
    doc = "## Props permanents\nMenu staff **F10 › Props permanents** (droit « Poser et retirer des props permanents », en service) :\n- **Poser un prop** : choisis un modèle de la liste (ou tape son nom), il apparaît en transparence devant toi. **← →** gauche / droite, **↑ ↓** monter / descendre, **Maj + ↑ ↓** avancer / reculer, **molette** ou **Q / X** tourner, **G** suivre de nouveau la visée, **E** poser, **Retour arrière** annuler.\n- **Props proches** : le prop survolé est entouré ; Entrée pour le retirer.\n\nLes props restent après un redémarrage du serveur.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Props posés', icon = 'box', build = function()
                local rows = {}
                for _, r in ipairs(Pr.List()) do rows[#rows + 1] = { id = r.id, model = r.m, label = r.l, pos = ('%d, %d, %d'):format(math.floor(r.x), math.floor(r.y), math.floor(r.z)) } end
                return { PB.B.table({ id = 'propsl', title = 'Props permanents (' .. #rows .. ')', search = true, columns = { { k = 'id', label = 'N°' }, { k = 'model', label = 'Modèle', type = 'mono' }, { k = 'label', label = 'Nom' }, { k = 'pos', label = 'Position' } }, rows = rows, empty = 'Aucun prop posé.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('props permanents', function(R)
    R.check(DB.TableExists == nil or DB.TableExists('pb_props'), 'table pb_props', 'migration non appliquée')
end)
