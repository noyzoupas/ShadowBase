/* Annonces plein écran (façon txAdmin) : grand bandeau au centre-haut, file d'attente, barre de temps qui se vide. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const queue = [];
let showing = false;
function color(c) { return /^#[0-9a-fA-F]{6}$/.test(c || '') ? c : '#5fa8ff'; }
const COLORS = { info: '#5fa8ff', event: '#f5b942', alert: '#ff4d5e', success: '#4ad991' };
function build(d, secs) {
  const st = String(d.style || 'info').replace(/[^a-z]/g, '');
  const bar = h('i');
  bar.style.animationDuration = secs + 's';
  const el = h('div', { class: 'gp-box gh-box ga-box ann-' + st },
    h('div', { class: 'hst-top' }, h('span', null, String(d.title || 'Annonce du staff').slice(0, 60)), d.author ? h('em', null, String(d.author).slice(0, 40)) : null),
    h('b', { class: 'ga-text' }, String(d.text || '').slice(0, 300)),
    h('div', { class: 'gp-bar ga-time' }, bar));
  el.style.setProperty('--ac', color(d.color || COLORS[d.style]));
  return el;
}
function next() {
  if (showing || !queue.length) return;
  showing = true;
  const d = queue.shift();
  const secs = Math.max(4, Math.min(60, Number(d.secs) || 12));
  const el = build(d, secs);
  G.root.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  setTimeout(() => {
    el.classList.remove('in'); el.classList.add('out');
    setTimeout(() => { el.remove(); showing = false; next(); }, 500);
  }, secs * 1000);
}
G.on('announce.show', (d) => {
  if (!d || !d.text) return;
  if (queue.length < 5) queue.push(d);
  next();
});
// Aperçu du panel : le vrai bandeau, mis à jour pendant la saisie du formulaire
G.preview.announce = function (box, cfg) {
  G.clear(box);
  cfg = cfg || {};
  const stage = h('div', { class: 'gstage' });
  const d = { title: cfg.title || 'Annonce du staff', text: cfg.text || 'Le serveur redémarre dans 10 minutes. Pensez à ranger vos véhicules.', style: cfg.style || 'info', secs: Number(cfg.secs) || 12, author: 'Ton nom' };
  const el = build(d, d.secs);
  el.classList.add('in', 'pv');
  stage.appendChild(el);
  box.appendChild(stage);
};
})();
