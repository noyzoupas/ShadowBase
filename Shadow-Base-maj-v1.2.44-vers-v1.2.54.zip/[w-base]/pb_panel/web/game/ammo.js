/* Munitions en haut à droite : « Munitions (chargeur / réserve) », texte seul (rouge quand le chargeur est presque vide). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
function build(d) {
  const label = 'Munitions (' + (Number(d.clip) || 0) + (d.reserve != null ? ' / ' + (Number(d.reserve) || 0) : '') + ')';
  const max = Math.max(1, Number(d.max) || 1), pct = Math.min(100, (Number(d.clip) || 0) / max * 100);
  const low = pct <= 20;
  return h('div', { id: 'g-ammo', class: low ? 'low' : '' }, h('span', null, label));
}
let el = null;
G.on('ammo', (d) => {
  if (!d || !d.show) { if (el) { el.remove(); el = null; } return; }
  const n = build(d);
  if (!el) { el = n; G.root.appendChild(el); return; }
  el.className = n.className;
  el.firstChild.textContent = n.firstChild.textContent;
  // mise à jour sur place : pas de clignotement en tirant
});
// Aperçu du panel : ajouté à l'aperçu du HUD
const prev = G.preview.hud;
G.preview.hud = function (box, cfg) {
  if (prev) prev(box, cfg);
  const stage = box.querySelector && box.querySelector('.gstage');
  if (stage && (cfg || {}).show_ammo !== false) { const a = build({ clip: 24, reserve: 90, max: 30 }); a.classList.add('pv'); stage.appendChild(a); }
};
})();
