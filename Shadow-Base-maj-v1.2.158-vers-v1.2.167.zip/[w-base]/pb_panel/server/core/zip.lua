-- (v1.2.78) Outils pour installer une mise à jour sans aide extérieure : SHA-256, CRC-32, décompression DEFLATE et lecture d'un zip.
-- Pur Lua 5.4 (opérateurs binaires natifs). Utilisé par server/core/updates.lua (commande wupdate).

local Z = {}
PB.Zip = Z
local byte, char, concat, unpack = string.byte, string.char, table.concat, table.unpack

-- SHA-256 ----------------------------------------------------------------------------------------------------------------------------
local K = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
}
local M32 = 0xffffffff
local function rrot(x, n) return ((x >> n) | (x << (32 - n))) & M32 end
function Z.Sha256(msg, yield, progress)
    local ml = #msg * 8
    msg = msg .. '\128' .. string.rep('\0', (55 - #msg) % 64) .. string.pack('>I8', ml)
    local h0, h1, h2, h3, h4, h5, h6, h7 = 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    local w = {}
    for chunk = 1, #msg, 64 do
        for i = 0, 15 do w[i] = string.unpack('>I4', msg, chunk + i * 4) end
        for i = 16, 63 do
            local a, b = w[i - 15], w[i - 2]
            local s0 = rrot(a, 7) ~ rrot(a, 18) ~ (a >> 3)
            local s1 = rrot(b, 17) ~ rrot(b, 19) ~ (b >> 10)
            w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & M32
        end
        local a, b, c, d, e, f, g, h = h0, h1, h2, h3, h4, h5, h6, h7
        for i = 0, 63 do
            local S1 = rrot(e, 6) ~ rrot(e, 11) ~ rrot(e, 25)
            local ch = (e & f) ~ ((~e) & g)
            local t1 = (h + S1 + ch + K[i + 1] + w[i]) & M32
            local S0 = rrot(a, 2) ~ rrot(a, 13) ~ rrot(a, 22)
            local maj = (a & b) ~ (a & c) ~ (b & c)
            local t2 = (S0 + maj) & M32
            h, g, f, e, d, c, b, a = g, f, e, (d + t1) & M32, c, b, a, (t1 + t2) & M32
        end
        h0, h1, h2, h3 = (h0 + a) & M32, (h1 + b) & M32, (h2 + c) & M32, (h3 + d) & M32
        h4, h5, h6, h7 = (h4 + e) & M32, (h5 + f) & M32, (h6 + g) & M32, (h7 + h) & M32
        if yield and chunk % (64 * 256) == 1 then
            yield()
            if progress then progress(chunk / #msg) end
        end
    end
    return ('%08x%08x%08x%08x%08x%08x%08x%08x'):format(h0, h1, h2, h3, h4, h5, h6, h7)
end

-- CRC-32 -----------------------------------------------------------------------------------------------------------------------------
local CRC = {}
for i = 0, 255 do
    local c = i
    for _ = 1, 8 do if c & 1 == 1 then c = 0xEDB88320 ~ (c >> 1) else c = c >> 1 end end
    CRC[i] = c
end
function Z.Crc32(s, yield)
    local c = 0xffffffff
    for i = 1, #s do
        c = CRC[(c ~ byte(s, i)) & 0xff] ~ (c >> 8)
        if yield and i & 16383 == 0 then yield() end
    end
    return c ~ 0xffffffff
end

-- DEFLATE (RFC 1951) ---------------------------------------------------------------------------------------------------------------------
local LBASE = { 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258 }
local LEXT = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 }
local DBASE = { 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577 }
local DEXT = { 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 }
local CLORDER = { 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 }

-- table de décodage : clé (longueur << 16 | code inversé) -> symbole ; on lit bit par bit jusqu'à trouver
local function huff(lengths, n)
    local count, offs, maxl = {}, {}, 0
    for i = 0, 15 do count[i] = 0 end
    for i = 0, n - 1 do local l = lengths[i] or 0 count[l] = count[l] + 1 if l > maxl then maxl = l end end
    count[0] = 0
    local code, next_ = 0, {}
    for b = 1, 15 do code = (code + count[b - 1]) << 1 next_[b] = code end
    local map = {}
    for i = 0, n - 1 do
        local l = lengths[i] or 0
        if l > 0 then
            local c = next_[l] next_[l] = c + 1
            -- inverse les bits (le flux DEFLATE lit les codes de Huffman du bit fort au bit faible)
            local r = 0
            for _ = 1, l do r = (r << 1) | (c & 1) c = c >> 1 end
            map[(l << 16) | r] = i
        end
    end
    return { map = map, maxl = maxl }
end

function Z.Inflate(data, yield)
    local pos, bitbuf, bitcnt = 1, 0, 0
    local out, olen = {}, 0          -- fenêtre de sortie (tableau d'entiers) : les anciens octets sont versés dans `parts` pour ne pas garder un entier par octet d'un gros fichier
    local parts, done, ticks = {}, 0, 0
    local function flush(all)
        local cut = all and olen or (olen - 32768)
        for i = 1, cut, 4096 do parts[#parts + 1] = char(unpack(out, i, math.min(cut, i + 4095))) end
        if not all then
            local new = {}
            for i = 1, 32768 do new[i] = out[cut + i] end
            out = new
        end
        olen = olen - cut
        done = done + cut
    end
    local function need(n)
        while bitcnt < n do
            local b = byte(data, pos)
            if not b then error('flux DEFLATE tronqué') end
            pos = pos + 1
            bitbuf = bitbuf | (b << bitcnt)
            bitcnt = bitcnt + 8
        end
    end
    local function bits(n)
        if n == 0 then return 0 end
        need(n)
        local v = bitbuf & ((1 << n) - 1)
        bitbuf = bitbuf >> n
        bitcnt = bitcnt - n
        return v
    end
    local function decode(t)
        local code, len = 0, 0
        local map = t.map
        while true do
            need(1)
            code = code | ((bitbuf & 1) << len)
            bitbuf = bitbuf >> 1 bitcnt = bitcnt - 1
            len = len + 1
            local s = map[(len << 16) | code]
            if s then return s end
            if len > 15 then error('code de Huffman invalide') end
        end
    end
    local FIXL, FIXD
    local blocks = 0
    repeat
        local final = bits(1)
        local typ = bits(2)
        if typ == 0 then
            bitbuf, bitcnt = 0, 0   -- aligné sur l'octet
            local len = string.unpack('<I2', data, pos)
            pos = pos + 4
            for i = pos, pos + len - 1 do olen = olen + 1 out[olen] = byte(data, i) end
            pos = pos + len
            if olen >= 131072 then flush() end
        else
            local lit, dist
            if typ == 1 then
                if not FIXL then
                    local l = {}
                    for i = 0, 143 do l[i] = 8 end for i = 144, 255 do l[i] = 9 end for i = 256, 279 do l[i] = 7 end for i = 280, 287 do l[i] = 8 end
                    FIXL = huff(l, 288)
                    local d = {} for i = 0, 29 do d[i] = 5 end
                    FIXD = huff(d, 30)
                end
                lit, dist = FIXL, FIXD
            elseif typ == 2 then
                local hlit, hdist, hclen = bits(5) + 257, bits(5) + 1, bits(4) + 4
                local cl = {}
                for i = 0, 18 do cl[i] = 0 end
                for i = 1, hclen do cl[CLORDER[i]] = bits(3) end
                local clt = huff(cl, 19)
                local lens, n = {}, 0
                while n < hlit + hdist do
                    local s = decode(clt)
                    if s < 16 then lens[n] = s n = n + 1
                    elseif s == 16 then local prev = lens[n - 1] or 0 for _ = 1, 3 + bits(2) do lens[n] = prev n = n + 1 end
                    elseif s == 17 then for _ = 1, 3 + bits(3) do lens[n] = 0 n = n + 1 end
                    else for _ = 1, 11 + bits(7) do lens[n] = 0 n = n + 1 end end
                end
                local ll, dl = {}, {}
                for i = 0, hlit - 1 do ll[i] = lens[i] end
                for i = 0, hdist - 1 do dl[i] = lens[hlit + i] end
                lit, dist = huff(ll, hlit), huff(dl, hdist)
            else error('type de bloc DEFLATE invalide') end
            while true do
                local s = decode(lit)
                ticks = ticks + 1
                if ticks & 4095 == 0 then
                    if olen >= 131072 then flush() end
                    if yield then yield() end
                end
                if s < 256 then olen = olen + 1 out[olen] = s
                elseif s == 256 then break
                else
                    s = s - 257
                    local len = LBASE[s + 1] + bits(LEXT[s + 1])
                    local ds = decode(dist)
                    local d = DBASE[ds + 1] + bits(DEXT[ds + 1])
                    local from = olen - d
                    for i = 1, len do olen = olen + 1 out[olen] = out[from + i] end
                end
            end
        end
        blocks = blocks + 1
        if yield and blocks % 8 == 0 then yield() end
    until final == 1
    flush(true)
    return concat(parts)
end

-- Zip : liste des fichiers (répertoire central), puis contenu de chacun -------------------------------------------------------------------
function Z.Entries(zip)
    local eocd
    for i = #zip - 21, math.max(1, #zip - 65557), -1 do
        if zip:sub(i, i + 3) == 'PK\5\6' then eocd = i break end
    end
    if not eocd then return nil, 'Zip illisible (fin du fichier introuvable).' end
    local n = string.unpack('<I2', zip, eocd + 10)
    local cdoff = string.unpack('<I4', zip, eocd + 16)
    local p, list = cdoff + 1, {}
    for _ = 1, n do
        if zip:sub(p, p + 3) ~= 'PK\1\2' then return nil, 'Zip illisible (répertoire central).' end
        local method = string.unpack('<I2', zip, p + 10)
        local crc, csize, usize = string.unpack('<I4I4I4', zip, p + 16)
        local fnl, exl, cml = string.unpack('<I2I2I2', zip, p + 28)
        local lho = string.unpack('<I4', zip, p + 42)
        local name = zip:sub(p + 46, p + 45 + fnl)
        list[#list + 1] = { name = name, method = method, crc = crc, csize = csize, usize = usize, lho = lho }
        p = p + 46 + fnl + exl + cml
    end
    return list
end
function Z.Read(zip, e, yield)
    local p = e.lho + 1
    if zip:sub(p, p + 3) ~= 'PK\3\4' then return nil, 'Entrée illisible : ' .. e.name end
    local fnl, exl = string.unpack('<I2I2', zip, p + 26)
    local raw = zip:sub(p + 30 + fnl + exl, p + 29 + fnl + exl + e.csize)
    local data
    if e.method == 0 then data = raw
    elseif e.method == 8 then
        local ok, r = pcall(Z.Inflate, raw, yield)
        if not ok then return nil, ('Décompression impossible (%s) : %s'):format(e.name, tostring(r)) end
        data = r
    else return nil, 'Compression non prise en charge : ' .. e.name end
    if #data ~= e.usize or Z.Crc32(data, yield) ~= e.crc then return nil, 'Fichier abîmé dans le zip : ' .. e.name end
    return data
end
