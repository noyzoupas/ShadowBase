-- Anticheat (client) : répond au « pouls » du serveur et signale l'arrêt d'une ressource protégée.
-- Il ne détecte rien tout seul : le serveur décide. Un cheat injecté pourrait imiter le pouls (voir la liste des limites dans le panel).
local sec, protected = nil, {}

local function hash(s)
    local h = 5381
    for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
    return h
end

RegisterNetEvent('pb:ac:hello', function(secret, list)
    sec = tostring(secret or '')
    protected = {}
    for _, r in ipairs(type(list) == 'table' and list or {}) do protected[tostring(r)] = true end
end)

RegisterNetEvent('pb:ac:ping', function(seq, nonce)
    if not sec then TriggerServerEvent('pb:ac:need') return end   -- code jamais reçu : on le redemande
    TriggerServerEvent('pb:ac:pong', seq, hash(tostring(nonce) .. sec))
end)

AddEventHandler('onClientResourceStop', function(res)
    if sec and protected[res] then TriggerServerEvent('pb:ac:cstop', res) end
end)

-- Filet de sécurité : une ressource protégée qui n'est plus « started » côté client alors qu'on a la liste.
CreateThread(function()
    local told = {}
    while true do
        Wait(5000)
        if sec then
            for r in pairs(protected) do
                local st = GetResourceState(r)
                if st ~= 'started' and st ~= 'starting' and st ~= 'missing' and not told[r] then told[r] = true TriggerServerEvent('pb:ac:cstop', r)
                elseif st == 'started' then told[r] = nil end
            end
        end
    end
end)

-- ================= (suite) contrôles locaux : le client ne sanctionne rien, il signale ; le serveur recoupe et décide =================
local function proof(kind, val) return hash(sec .. '|' .. kind .. '|' .. tostring(math.floor(tonumber(val) or 0))) end
local function report(kind, val)
    if sec then TriggerServerEvent('pb:ac:rep', kind, math.floor(tonumber(val) or 0), proof(kind, val)) end
end

CreateThread(function()
    Wait(20000)
    local shots, last = 0, nil
    while true do
        Wait(3000)
        if sec then
            local ped = PlayerPedId()
            if ped ~= 0 and DoesEntityExist(ped) and not IsPlayerSwitchInProgress() and not IsCutsceneActive() then
                local veh = GetVehiclePedIsIn(ped, false)
                local hp, arm = GetEntityHealth(ped), GetPedArmour(ped)
                if hp > 200 then report('hp', hp) end
                if arm > 100 then report('armor', arm) end
                if veh == 0 and not IsEntityAttached(ped) then
                    local sp = GetEntitySpeed(ped)
                    local ok = not IsPedFalling(ped) and not IsPedRagdoll(ped) and not IsPedInParachuteFreeFall(ped) and GetPedParachuteState(ped) <= 0 and not IsPedClimbing(ped) and not IsPedSwimming(ped) and not IsPedJumping(ped)
                    if ok and sp > 14.0 then report('speed', sp) end
                    if GetEntityCollisonDisabled and GetEntityCollisonDisabled(ped) and ok then report('noclip', 1) end
                    if IsPedJumping(ped) and GetEntityHeightAboveGround(ped) > 7.0 then report('jump', 1) end
                end
                if not IsEntityVisible(ped) or GetEntityAlpha(ped) < 40 then report('invisible', 1) end
                if NetworkIsInSpectatorMode() then report('spectate', 1) end
                if GetPedConfigFlag(ped, 223, true) then report('tiny', 1) end
                if (IsNightvisionActive and IsNightvisionActive()) or (IsSeethroughActive and IsSeethroughActive()) then report('vision', 1) end
            end
        end
    end
end)

-- munitions infinies : 15 tirs d'affilée sans que le chargeur baisse
CreateThread(function()
    local run, lastClip, lastT = 0, nil, 0
    while true do
        Wait(0)
        local ped = PlayerPedId()
        if sec and IsPedShooting(ped) and GetGameTimer() - lastT > 250 then
            lastT = GetGameTimer()
            local _, w = GetCurrentPedWeapon(ped, true)
            local clip = GetAmmoInClip(ped, w)
            local infinite = GetPedInfiniteAmmoClip and false
            if lastClip and clip >= lastClip and clip > 0 and not infinite and GetWeapontypeGroup(w) ~= 0 then run = run + 1 else run = 0 end
            lastClip = clip
            if run >= 15 then run = 0 report('ammo', 1) end
        elseif not sec or not IsPedArmed(ped, 4) then Wait(500) run, lastClip = 0, nil end
    end
end)

-- ressources chargées côté client : le serveur compare avec les siennes
CreateThread(function()
    Wait(90000)
    while true do
        if sec then
            local list = {}
            for i = 0, GetNumResources() - 1 do
                local n = GetResourceByFindIndex(i)
                if n and GetResourceState(n) == 'started' then list[#list + 1] = n end
            end
            TriggerServerEvent('pb:ac:res', list, hash(sec .. '|res|' .. #list))
        end
        Wait(300000)
    end
end)

-- caméra libre, invincibilité, véhicule boosté ou indestructible
CreateThread(function()
    Wait(25000)
    local far = 0
    while true do
        Wait(2500)
        if sec then
            local pid, ped = PlayerId(), PlayerPedId()
            if ped ~= 0 and DoesEntityExist(ped) and not IsPlayerSwitchInProgress() and not IsCutsceneActive() then
                -- caméra libre : la caméra de rendu s'éloigne du joueur sans spectateur ni cinématique
                local cam, pc = GetFinalRenderedCamCoord(), GetEntityCoords(ped)
                if #(cam - pc) > 60.0 and not NetworkIsInSpectatorMode() and not IsPlayerSwitchInProgress() then far = far + 1 else far = 0 end
                if far >= 3 then far = 0 report('freecam', 1) end
                -- invincibilité
                if GetPlayerInvincible(pid) or (not GetEntityCanBeDamaged(ped) and not IsEntityDead(ped)) then report('god', 1) end
                -- véhicule
                local veh = GetVehiclePedIsIn(ped, false)
                if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                    local mx = GetVehicleModelEstimatedMaxSpeed(GetEntityModel(veh))
                    if mx and mx > 5.0 then
                        local pct = (GetEntitySpeed(veh) / mx) * 100.0
                        if pct > 150.0 and not IsEntityInAir(veh) and not IsEntityInWater(veh) then report('vehboost', pct) end
                    end
                    if GetEntityHealth(veh) > 1000 or GetVehicleEngineHealth(veh) > 1000.5 then report('vehgod', 1) end
                end
            end
        end
    end
end)

-- modificateurs de dégâts / défense / régénération
CreateThread(function()
    Wait(30000)
    while true do
        Wait(10000)
        if sec and GetPlayerWeaponDamageModifier then
            local pid = PlayerId()
            local worst = 100
            local function chk(f) if f then local v = f(pid) if v and v > 1.02 then worst = math.max(worst, math.floor(v * 100)) end end end
            chk(GetPlayerWeaponDamageModifier) chk(GetPlayerMeleeWeaponDamageModifier) chk(GetPlayerVehicleDamageModifier) chk(GetPlayerHealthRechargeMultiplier)
            if GetPlayerWeaponDefenseModifier then local v = GetPlayerWeaponDefenseModifier(pid) if v and v < 0.98 then worst = math.max(worst, math.floor((1 / math.max(v, 0.01)) * 100)) end end
            if worst > 100 then report('dmgmod', worst) end
        end
    end
end)

-- modificateurs de véhicule (lus directement, donc exacts) et sonde des outils de développement de l'interface
CreateThread(function()
    Wait(35000)
    while true do
        Wait(3000)
        if sec then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                local a = GetVehicleCheatPowerIncrease and GetVehicleCheatPowerIncrease(veh) or 1.0
                local b = GetVehicleTopSpeedModifier and GetVehicleTopSpeedModifier(veh) or 1.0
                local m = math.max(a or 1.0, b or 1.0)
                if m > 2.0 then report('vehmod', m * 100) end
            end
        end
    end
end)
local GG = PB and PB.G
if GG and GG.nui then GG.nui['ac.devtools'] = function() report('devtools', 1) return {} end end

-- Ce que les ressources protégées ont annoncé (collision du joueur coupée, caméra scriptée) : tout le reste est étranger à ton serveur
local hub = { coll = {}, cam = {}, god = {}, inv = {} }
AddEventHandler('wb_shield:state', function(kind, res, on)
    local t = hub[kind]
    -- une annonce n'est acceptée que si elle vient bien de la ressource qu'elle prétend être : un code étranger ne peut pas s'annoncer à sa place
    local from = GetInvokingResource and GetInvokingResource()
    if t and type(res) == 'string' and (from == nil or from == res) and GetResourceState(res) == 'started' then t[res] = on and true or nil end
end)
local function announced(t)
    for r in pairs(t) do
        if GetResourceState(r) ~= 'started' then t[r] = nil else return true end
    end
    return false
end
CreateThread(function()
    Wait(40000)
    local cam, col, gd, iv = 0, 0, 0, 0
    while true do
        Wait(2000)
        if sec then
            local ped = PlayerPedId()
            local quiet = ped ~= 0 and DoesEntityExist(ped) and not IsEntityDead(ped) and not IsCutsceneActive() and not IsPlayerSwitchInProgress()
                and not NetworkIsInSpectatorMode() and not IsScreenFadedOut() and not IsPauseMenuActive()
            -- caméra scriptée affichée que personne n'a annoncée = caméra libre / spectateur d'un menu
            if quiet and not IsGameplayCamRendering() and not announced(hub.cam) then cam = cam + 1 else cam = 0 end
            if cam >= 3 then cam = 0 report('freecam', 2) end
            -- collision du joueur coupée sans que personne l'ait annoncé = noclip d'un menu
            if quiet and GetEntityCollisonDisabled and GetEntityCollisonDisabled(ped) and GetVehiclePedIsIn(ped, false) == 0 and not IsEntityAttached(ped) and not announced(hub.coll) then col = col + 1 else col = 0 end
            if col >= 3 then col = 0 report('noclip', 2) end
            -- invincibilité / invisibilité que personne n'a annoncée : appliquées par du code étranger
            if quiet and GetPlayerInvincible(PlayerId()) and not announced(hub.god) then gd = gd + 1 else gd = 0 end
            if gd >= 3 then gd = 0 report('god', 2) end
            if quiet and not IsEntityVisible(ped) and not announced(hub.inv) then iv = iv + 1 else iv = 0 end
            if iv >= 3 then iv = 0 report('invisible', 2) end
        end
    end
end)
