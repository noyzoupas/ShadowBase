-- Shadow Base — Portes verrouillables (client) : enregistre les portes dans le système de portes du jeu, invite E devant celles qu'on peut utiliser,
-- menu de gestion du staff (viser une porte + E pour l'ajouter ou la retirer).
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local doors = {}            -- id -> { id, model, x, y, z, locked, label, can }

local function hashOf(id) return GetHashKey(RES .. '_' .. tostring(id)) end
-- portée de la touche E : porte normale à pied 2,2 m ; grande porte (garage, portail) à pied 7 m ; en véhicule 15 m (le serveur revérifie)
local wide = {}
local function isWide(d)
    if wide[d.model] == nil then
        local ok, mn, mx = pcall(GetModelDimensions, d.model)
        wide[d.model] = ok and mn and mx and math.max(mx.x - mn.x, mx.y - mn.y) >= 2.6 or false
    end
    return wide[d.model]
end
local function reach(d, inVeh) if inVeh then return 15.0 end return isWide(d) and 7.0 or 2.2 end
local function apply(d)
    local h = hashOf(d.id)
    if not IsDoorRegisteredWithSystem(h) then AddDoorToSystem(h, d.model, d.x + 0.0, d.y + 0.0, d.z + 0.0, false, false, false) end
    DoorSystemSetDoorState(h, d.locked and 1 or 0, false, true)
end
local function forget(id)
    local h = hashOf(id)
    if IsDoorRegisteredWithSystem(h) then RemoveDoorFromSystem(h) end
    doors[id] = nil
end

RegisterNetEvent(RES .. ':doors', function(j)
    local ok, list = pcall(json.decode, j)
    if not ok or type(list) ~= 'table' then return end
    local seen = {}
    for _, d in ipairs(list) do seen[d.id] = true doors[d.id] = d apply(d) end
    for id in pairs(doors) do if not seen[id] then forget(id) end end
end)
RegisterNetEvent(RES .. ':state', function(id, locked)
    local d = doors[id]
    if not d then return end
    d.locked = locked == true
    apply(d)
end)
RegisterNetEvent(RES .. ':forget', function(id) forget(id) end)

CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2500)
    TriggerServerEvent(RES .. ':hello')
end)

local freeCache, freeAt = false, 0   -- W:IsFree() est un appel entre ressources : mis en cache 0,3 s
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end

-- Invite E devant une porte qu'on a le droit d'utiliser ------------------------------------------------------------------------------------------
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 700
        if next(doors) and isFree() then
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local inVeh = IsPedInAnyVehicle(ped, false)
            local best, bd
            for _, d in pairs(doors) do
                if d.can then
                    local dist = #(c - vector3(d.x, d.y, d.z))
                    if dist < reach(d, inVeh) and (not bd or dist < bd) then best, bd = d, dist end
                    if dist < 25.0 then sleep = 200 end
                end
            end
            if best then
                sleep = 0
                local key = best.id .. (best.locked and 'L' or 'O')
                if shown ~= key then shown = key W:Prompt((best.locked and 'Déverrouiller' or 'Verrouiller') .. ' : ' .. best.label, 'E', best.x, best.y, best.z) end
                if inVeh then DisableControlAction(0, 86, true) end   -- E en voiture : pas de klaxon pendant qu'on ouvre la porte
                if IsControlJustPressed(0, 38) or (inVeh and IsDisabledControlJustPressed(0, 86)) then
                    hide()
                    if not inVeh then
                        RequestAnimDict('anim@heists@keycard@')
                        local t = GetGameTimer() + 800
                        while not HasAnimDictLoaded('anim@heists@keycard@') and GetGameTimer() < t do Wait(10) end
                        if HasAnimDictLoaded('anim@heists@keycard@') then TaskPlayAnim(ped, 'anim@heists@keycard@', 'exit', 8.0, -8.0, 900, 48, 0, false, false, false) end
                    end
                    TriggerServerEvent(RES .. ':toggle', best.id)
                    Wait(700)
                end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Viser une porte : rayon depuis la caméra (10 m), renvoie le modèle et la position de l'objet touché ---------------------------------------------
local function rotToDir(r)
    local x, z = math.rad(r.x), math.rad(r.z)
    return vector3(-math.sin(z) * math.abs(math.cos(x)), math.cos(z) * math.abs(math.cos(x)), math.sin(x))
end
local function aimedDoor()
    local from = GetGameplayCamCoord()
    local to = from + rotToDir(GetGameplayCamRot(2)) * 10.0
    local ray = StartShapeTestRay(from.x, from.y, from.z, to.x, to.y, to.z, 16, PlayerPedId(), 0)
    local _, hit, _, _, ent = GetShapeTestResult(ray)
    if hit ~= 1 or ent == 0 or GetEntityType(ent) ~= 3 then return nil end
    local c = GetEntityCoords(ent)
    return { model = GetEntityModel(ent), x = c.x, y = c.y, z = c.z, ent = ent }
end
-- Mode visée : la porte visée est entourée ; E valide, Retour arrière annule
local function pickDoor(title, cb)
    CreateThread(function()
        W:CloseMenu()
        W:Prompt(title .. ' — vise la porte puis E (Retour arrière : annuler)', 'E')
        while true do
            Wait(0)
            local d = aimedDoor()
            if d then
                local c = vector3(d.x, d.y, d.z)
                DrawMarker(0, c.x, c.y, c.z + 1.4, 0, 0, 0, 0, 0, 0, 0.3, 0.3, 0.3, 255, 210, 80, 200, true, true, 2, false, nil, nil, false)
                SetEntityDrawOutline(d.ent, true)
                SetEntityDrawOutlineColor(255, 210, 80, 255)
            end
            if IsControlJustPressed(0, 38) and d then SetEntityDrawOutline(d.ent, false) W:HidePrompt() cb(d) return end
            if IsControlJustPressed(0, 177) then W:HidePrompt() return end
            if d then SetEntityDrawOutline(d.ent, false) end
        end
    end)
end

-- Menu de gestion (staff) -----------------------------------------------------------------------------------------------------------------------
local function send(op, a, b) TriggerServerEvent(RES .. ':edit', op, a, b) end
local function has(list, tok) for _, t in ipairs(list or {}) do if t == tok then return true end end return false end
local function openManage(data)
    local items = {}
    items[#items + 1] = { type = 'input', label = 'Nouveau groupe de portes', icon = 'plus', description = 'Nom du groupe (ex. Commissariat, Labo des Ballas).', maxlen = 40,
        onSelect = function(_, text) if text and #text >= 2 then send('new', text) end end }
    items[#items + 1] = { label = 'Retirer la porte visée', icon = 'x', description = 'Vise une porte déjà ajoutée puis E.', onSelect = function() pickDoor('Retirer une porte', function(d) send('remove', 0, { model = d.model, x = d.x, y = d.y, z = d.z }) end) end }
    if #data.groups > 0 then items[#items + 1] = { type = 'separator', label = 'Groupes' } end
    for _, g in ipairs(data.groups) do
        local acc = {}
        acc[#acc + 1] = { type = 'checkbox', label = 'Tout le monde', checked = has(g.access, 'all'), onChange = function() send('access', g.id, 'all') end }
        if #data.biz > 0 then acc[#acc + 1] = { type = 'separator', label = 'Entreprises' } end
        for _, b in ipairs(data.biz) do acc[#acc + 1] = { type = 'checkbox', label = b.label, checked = has(g.access, 'biz:' .. b.id), onChange = function() send('access', g.id, 'biz:' .. b.id) end } end
        if #data.gangs > 0 then acc[#acc + 1] = { type = 'separator', label = 'Gangs et organisations' } end
        for _, x in ipairs(data.gangs) do acc[#acc + 1] = { type = 'checkbox', label = x.label, checked = has(g.access, 'gang:' .. x.id), onChange = function() send('access', g.id, 'gang:' .. x.id) end } end
        local sub = {
            { label = 'Ajouter une porte', icon = 'plus', description = 'Vise la porte puis E. Pour une double porte, ajoute les deux battants.', onSelect = function() pickDoor('Ajouter à « ' .. g.label .. ' »', function(d) send('add', g.id, { model = d.model, x = d.x, y = d.y, z = d.z }) end) end },
            { type = 'submenu', label = 'Qui peut ouvrir', icon = 'users', right = #g.access > 0 and tostring(#g.access) or 'Staff', description = 'Le staff en service ouvre toujours.', submenu = { id = RES .. '.acc.' .. g.id, title = 'Accès', subtitle = g.label, items = acc } },
            { type = 'checkbox', label = 'Verrouillée par défaut', checked = g.locked, description = 'État des nouvelles portes ajoutées à ce groupe.', onChange = function(_, v) send('deflock', g.id, v == true) end },
            { type = 'input', label = 'Renommer', icon = 'edit', maxlen = 40, onSelect = function(_, text) if text and #text >= 2 then send('rename', g.id, text) end end },
            { label = 'Supprimer le groupe', icon = 'trash', description = 'Ses portes redeviennent normales.', onSelect = function() send('delete', g.id) end },
        }
        items[#items + 1] = { type = 'submenu', label = g.label, icon = 'lock', right = g.doors .. ' porte' .. (g.doors > 1 and 's' or ''), submenu = { id = RES .. '.g.' .. g.id, title = g.label, subtitle = 'Groupe de portes', items = sub } }
    end
    W:OpenMenu({ id = RES .. '.manage', title = 'Portes', subtitle = 'Gestion des portes', items = items })
end
-- Verrouillage rapide depuis le menu ALT (staff) ----------------------------------------------------------------------------------------------
local quick                 -- { door, cur, groups, biz, gangs, sel = { jeton = true }, filter = 1..3, q = '' }
local FILTERS = { 'Tout', 'Entreprises', 'Gangs' }
local function qsend(op, a, b) TriggerServerEvent(RES .. ':quickop', op, a, b) end
local function norm(s) return tostring(s or ''):lower():gsub('[éèêë]', 'e'):gsub('[àâä]', 'a'):gsub('[îï]', 'i'):gsub('[ôö]', 'o'):gsub('[ùûü]', 'u'):gsub('ç', 'c') end
local function doorEntity(d) local o = GetClosestObjectOfType(d.x + 0.0, d.y + 0.0, d.z + 0.0, 1.0, d.model, false, false, false) return o ~= 0 and o or nil end
-- second battant : même modèle, à moins de 3 m
local function pairOf(d)
    local me = doorEntity(d)
    for _, obj in ipairs(GetGamePool('CObject')) do
        if obj ~= me and GetEntityModel(obj) == d.model then
            local c = GetEntityCoords(obj)
            local dist = #(c - vector3(d.x, d.y, d.z))
            if dist > 0.3 and dist < 3.0 then return { model = d.model, x = c.x, y = c.y, z = c.z } end
        end
    end
end
-- liste des accès cochables, filtrée (Tout / Entreprises / Gangs) et par la recherche
local function accessItems(isOn, onToggle)
    local out = {}
    local many = #(quick.biz or {}) + #(quick.gangs or {}) > 12
    if many then
        out[#out + 1] = { type = 'input', label = 'Rechercher', icon = 'search', right = quick.q ~= '' and quick.q or nil, maxlen = 30, description = 'Tape une partie du nom (vide = tout afficher).', onSelect = function(_, text) quick.q = tostring(text or '') W:RefreshMenu() end }
    end
    out[#out + 1] = { type = 'checkbox', label = 'Tout le monde', checked = isOn('all'), onChange = function() onToggle('all') end }
    local q, n = norm(quick.q), 0
    local function add(list, kind, tag)
        for _, o in ipairs(list or {}) do
            if q == '' or norm(o.label):find(q, 1, true) then
                n = n + 1
                local tok = kind .. ':' .. o.id
                out[#out + 1] = { type = 'checkbox', label = o.label, right = tag, checked = isOn(tok), onChange = function() onToggle(tok) end }
            end
        end
    end
    add(quick.biz, 'biz', 'Entreprise')
    add(quick.gangs, 'gang', 'Gang')
    if n == 0 then out[#out + 1] = { label = 'Aucun résultat', disabled = true } end
    return out
end
local function selCount() local n = 0 for _ in pairs(quick.sel) do n = n + 1 end return n end
local function quickMenu()
    local d, cur = quick.door, quick.cur
    if cur then
        return { id = RES .. '.quick', title = cur.label, subtitle = cur.locked and 'Verrouillée' or 'Ouverte', build = function()
            local acc = {}
            for _, t in ipairs(cur.access or {}) do acc[t] = true end
            return {
                { label = cur.locked and 'Déverrouiller' or 'Verrouiller', icon = cur.locked and 'key' or 'lock', onSelect = function() qsend('toggle', cur.id) W:CloseMenu() end },
                { type = 'submenu', label = "Qui garde l'accès", icon = 'users', right = #cur.access > 0 and tostring(#cur.access) or 'Staff',
                  description = cur.doors > 1 and ('Groupe de %d portes : le changement vaut pour toutes.'):format(cur.doors) or 'Le staff en service ouvre toujours.',
                  submenu = { id = RES .. '.quick.acc', title = "Qui garde l'accès", subtitle = cur.label, build = function()
                      return accessItems(function(t) return acc[t] == true end, function(t)
                          acc[t] = not acc[t] or nil
                          local l = {}
                          for k in pairs(acc) do l[#l + 1] = k end
                          cur.access = l
                          qsend('access', cur.grp, t)
                      end)
                  end } },
                { label = 'Rendre la porte normale', icon = 'trash', description = 'Retire cette porte du verrouillage.', onSelect = function() qsend('remove', cur.id) W:CloseMenu() end },
            }
        end }
    end
    -- nouvelle porte : coche qui y a accès, puis « Valider » (le staff en service ouvre toujours)
    return { id = RES .. '.quick', title = 'Porte', subtitle = 'Qui a accès ?', build = function()
        local items = { { type = 'separator', label = 'Coche qui peut ouvrir cette porte' } }
        for _, it in ipairs(accessItems(function(t) return quick.sel[t] == true end, function(t) quick.sel[t] = not quick.sel[t] or nil W:RefreshMenu() end)) do items[#items + 1] = it end
        local n = selCount()
        items[#items + 1] = { type = 'separator', label = '' }
        items[#items + 1] = { label = 'Valider', icon = 'check', right = n == 0 and 'Staff seulement' or (n .. ' accès'),
            description = "La porte est verrouillée ; ceux cochés l'ouvrent avec E (de loin en voiture). Une double porte est prise en entier.", onSelect = function()
                local toks = {}
                for t in pairs(quick.sel) do toks[#toks + 1] = t end
                local a = { model = d.model, x = d.x, y = d.y, z = d.z, pair = pairOf(d) }
                qsend('lock', a, { tokens = toks, label = '' })
                W:CloseMenu()
            end }
        return items
    end }
end
RegisterNetEvent(RES .. ':quick', function(j)
    local ok, data = pcall(json.decode, j)
    if not ok or type(data) ~= 'table' or type(data.door) ~= 'table' then return end
    quick = { door = data.door, cur = data.cur, groups = data.groups or {}, biz = data.biz or {}, gangs = data.gangs or {}, sel = {}, filter = 1, q = '' }
    W:CloseMenu()
    if not W:OpenMenu(quickMenu()) then return end
    -- la porte reste entourée tant que le menu est ouvert
    CreateThread(function()
        local ent = doorEntity(data.door)
        while ent and W:IsMenuOpen() do
            SetEntityDrawOutline(ent, true)
            SetEntityDrawOutlineColor(255, 200, 80, 255)
            Wait(250)
        end
        if ent then SetEntityDrawOutline(ent, false) end
    end)
end)

RegisterNetEvent(RES .. ':manage', function(j)
    local ok, data = pcall(json.decode, j)
    if ok and type(data) == 'table' then openManage(data) end
end)

AddEventHandler('onClientResourceStop', function(res)
    if res ~= RES then return end
    for id in pairs(doors) do local h = hashOf(id) if IsDoorRegisteredWithSystem(h) then RemoveDoorFromSystem(h) end end
end)
