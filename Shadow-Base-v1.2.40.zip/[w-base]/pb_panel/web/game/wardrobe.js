/* Vestiaire des magasins de vêtements, au style « boutique » (coque G.shell) : rail de catégories, grille de numéros, variantes, fiche de la tenue, bouton payer.
   Les envois au jeu restent ceux du créateur : creator.preview / creator.textures / creator.cam / creator.rotate, puis wardrobe.pay ou shop.close. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const SLOTS = [['Hauts', 'hanger', [['Haut', 'c', 11], ['Sous-haut', 'c', 8], ['Bras / torse', 'c', 3], ['Gilet', 'c', 9]]],
  ['Bas', 'user', [['Pantalon', 'c', 4]]], ['Chaussures', 'paw', [['Chaussures', 'c', 6]]],
  ['Accessoires', 'star', [['Accessoires', 'c', 7], ['Sac', 'c', 5], ['Masque', 'c', 1], ['Écusson', 'c', 10]]],
  ['Tête', 'face', [['Chapeau', 'p', 0], ['Lunettes', 'p', 1], ['Oreilles', 'p', 2]]], ['Poignets', 'clock', [['Montre', 'p', 6], ['Bracelet', 'p', 7]]]];

const SCOPES = { masks: [3], hats: [4], tops: [0], bottoms: [1], shoes: [2], accessories: [3, 5] };
// image d'une pièce : modèle d'adresse réglé dans le panel ({sex} {type} {id} {d} {t}) ; absente, la case garde son numéro
function tileImg(shop, k, id, dr, t) {
  const tpl = shop && shop.img;
  if (!tpl || dr < 0) return null;
  const src = String(tpl).replace(/\{sex\}/g, shop.sex || 'male').replace(/\{type\}/g, k === 'c' ? 'clothing' : 'prop').replace(/\{k\}/g, k).replace(/\{id\}/g, id).replace(/\{d\}/g, dr).replace(/\{t\}/g, t || 0);
  return h('img', { src, alt: '', loading: 'lazy', draggable: false, onerror: (e) => { e.target.parentNode && e.target.parentNode.classList.remove('im'); e.target.remove(); } });
}
function wardrobeView(d, opt) {
  opt = opt || {};
  // rayons proposés par la boutique (masques seulement, chapeaux…) : on garde les mêmes catégories, filtrées
  const scope = d.shop && d.shop.scope;
  const slots = (scope && SCOPES[scope]) ? SLOTS.map((g, i) => ({ g, i })).filter((x) => SCOPES[scope].indexOf(x.i) >= 0).map((x) => x.g) : SLOTS.slice();   // copie : le magasin de masques ne doit pas modifier les rayons des autres magasins
  if (scope === 'masks') { const acc = SLOTS[3]; slots[0] = ['Masques', 'face', acc[2].filter((x) => x[2] === 1)]; }
  if (scope === 'accessories') { slots[0] = ['Accessoires', 'star', SLOTS[3][2].filter((x) => x[2] !== 1)]; if (slots[1]) slots[1] = SLOTS[5]; }
  // masques et sacs : deux rayons, chaque article s'achète seul et arrive dans le sac du joueur
  const gear = d.shop && d.shop.gear;
  if (gear) { slots.length = 0; slots.push(['Masques', 'face', [['Masque', 'c', 1]]], ['Sacs', 'bag', [['Sac', 'c', 5]]]); }
  const isBags = () => gear && cur()[2] === 5;
  const price = Number(d.shop && d.shop.price) || 0;
  const app = d.appearance ? JSON.parse(JSON.stringify(d.appearance)) : { comps: Array.from({ length: 12 }, () => ({ d: 0, t: 0 })), props: [] };
  app.comps = app.comps || []; app.props = app.props || [];
  for (let i = 0; i < 12; i++) if (!app.comps[i]) app.comps[i] = { d: 0, t: 0 };
  const lim = () => d.limits || { comps: Array(12).fill(60), props: { 0: 60, 1: 30, 2: 20, 6: 20, 7: 20 } };
  const prop = (id) => { let p = app.props.find((x) => x.id === id); if (!p) { p = { id, d: -1, t: 0 }; app.props.push(p); } return p; };
  let group = 0, sub = 0, tex = 1, timer = null;
  const sendPrev = () => { if (opt.static) return; clearTimeout(timer); timer = setTimeout(() => G.post('creator.preview', { appearance: app }).then((r) => { if (r && r.comps) d.limits = r; }), 70); };
  const cur = () => slots[group][2][sub];
  const state = () => { const [, k, id] = cur(); return k === 'c' ? app.comps[id] : prop(id); };
  const count = () => { const [, k, id] = cur(); return k === 'c' ? Math.max(1, lim().comps[id] || 1) : Math.max(1, (lim().props[id] || 1)); };
  const loadTex = () => {
    const [, k, id] = cur(), st = state();
    if (opt.static) { tex = 4; st.t = Math.min(st.t, 3); draw(); return; }
    if (k === 'p' && st.d < 0) { tex = 1; draw(); return; }
    G.post('creator.textures', { kind: k === 'c' ? 'comp' : 'prop', id, drawable: st.d }).then((r) => { tex = (r && r.n) || 1; st.t = Math.min(st.t, tex - 1); draw(); });
  };
  const sh = G.shell({ title: (d.shop && d.shop.label) || 'Vêtements', sub: gear ? 'Chaque article arrive dans ton sac : équipe-le depuis l\'inventaire' : price > 0 ? 'Passage en cabine : ' + G.money(price) : 'Essayage libre', accent: d.accent, money: d.cash != null ? { cash: d.cash, bank: d.bank } : null,
    onClose: opt.onCancel, searchPlaceholder: 'Aller au numéro…', rail: slots.map((g, i) => ({ id: String(i), icon: g[1], label: g[0] })), railOn: '0',
    onRail: (id) => { group = Number(id); sub = 0; draw(); loadTex(); }, onSearch: (q) => { const n = parseInt(q, 10); if (n >= 1 && n <= count()) { pickDrawable(n - 1); } } });
  function pickDrawable(i) { const st = state(); st.d = i; st.t = 0; sendPrev(); draw(); loadTex(); }
  function draw() {
    G.clear(sh.items); G.clear(sh.info); G.clear(sh.act);
    const g = slots[group], st = state(), n = count(), isProp = cur()[1] === 'p';
    if (g[2].length > 1) sh.items.appendChild(h('div', { class: 'sh-slots' }, g[2].map((s, i) => h('button', { class: 'sh-slot' + (i === sub ? ' on' : ''), onclick: () => { sub = i; draw(); loadTex(); } }, s[0]))));
    const shop = d.shop || {}, imgs = !!shop.img;
    const grid = h('div', { class: 'sh-grid' + (imgs ? ' pics' : '') });
    const tile = (on, label, img, click, extra) => { const b = h('button', { class: 'sh-tile' + (img ? ' im' : '') + (on ? ' on' : ''), onclick: click }, img, h('span', null, label), extra || null); return b; };
    // style Nova : une ligne par modèle (comme la maquette), la ligne choisie s'ouvre sur ses variantes
    if (G.nova && G.nova() && !isBags()) {
      const list = h('div', { class: 'sh-nlist' });
      let onEl = null;
      const setT = (t) => { st.t = ((t % tex) + tex) % tex; sendPrev(); draw(); };
      const pager = () => {
        if (tex < 2) return null;
        const w = 8, a = Math.max(0, Math.min(st.t - 3, tex - w)), nums = [];
        for (let k = a; k < Math.min(tex, a + w); k++) nums.push(h('button', { type: 'button', class: k === st.t ? 'on' : '', onclick: (e) => { e.stopPropagation(); setT(k); } }, String(k + 1)));
        return h('div', { class: 'sh-npg' }, h('button', { type: 'button', class: 'ar', title: 'Variante précédente', onclick: (e) => { e.stopPropagation(); setT(st.t - 1); } }, '‹'), nums, h('button', { type: 'button', class: 'ar', title: 'Variante suivante', onclick: (e) => { e.stopPropagation(); setT(st.t + 1); } }, '›'));
      };
      const row = (on, label, num, img, click, right) => {
        const r = h('div', { class: 'sh-nrow' + (on ? ' on' : ''), role: 'button', tabindex: '0', onclick: click },
          h('span', { class: 'sh-nth' + (img ? ' im' : '') }, img || num),
          h('span', { class: 'sh-ntx' }, h('b', null, label), h('small', null, on && tex > 1 ? 'Variante ' + (st.t + 1) + ' / ' + tex : (on ? 'Porté' : 'Essayer'))),
          right ? h('em', null, right) : null, on ? pager() : null);
        if (on) onEl = r;
        return r;
      };
      const base = cur()[0];
      if (isProp) list.appendChild(row(st.d < 0, 'Aucun', '—', null, () => pickDrawable(-1)));
      for (let i = 0; i < n; i++) {
        if (gear && i === 0) { list.appendChild(row(st.d === 0, 'Aucun', '—', null, () => pickDrawable(0))); continue; }
        list.appendChild(row(st.d === i, base + ' ' + (i + 1), '#' + (i + 1), tileImg(shop, cur()[1], cur()[2], i, 0), () => pickDrawable(i), gear ? G.money(gear.mask_price || 0) : null));
      }
      sh.items.appendChild(list);
      if (onEl) requestAnimationFrame(() => { try { onEl.scrollIntoView({ block: 'nearest' }); } catch (e) { /* aperçu */ } });
    } else if (isBags()) {
      gear.bags.forEach((b) => grid.appendChild(tile(st.d === b.d && st.t === b.t, '+' + b.kg + ' kg', tileImg(shop, 'c', 5, b.d, b.t), () => { st.d = b.d; st.t = b.t; sendPrev(); draw(); }, h('em', null, G.money(b.price)))));
    } else {
      if (isProp) grid.appendChild(tile(st.d < 0, 'Aucun', null, () => pickDrawable(-1)));
      for (let i = 0; i < n; i++) grid.appendChild(tile(st.d === i, gear && i === 0 ? 'Aucun' : String(i + 1), gear && i === 0 ? null : tileImg(shop, cur()[1], cur()[2], i, 0), () => pickDrawable(i)));
    }
    if (!sh.items.querySelector('.sh-nlist')) sh.items.appendChild(grid);
    const bagNow = isBags() ? gear.bags.find((b) => b.d === st.d && b.t === st.t) : null;
    sh.info.append(...[h('h2', null, bagNow ? bagNow.label : cur()[0]), h('p', { class: 'sh-d' }, isBags() ? (bagNow ? 'Porté (case Sac) : +' + bagNow.kg + ' kg dans ton sac' : 'Choisis un sac dans la liste') : st.d < 0 || (gear && st.d === 0) ? 'Aucun' : 'Modèle ' + (st.d + 1) + ' sur ' + n),
      isBags() ? null : h('div', { class: 'sh-var' }, h('button', { onclick: () => { st.t = ((st.t - 1) % tex + tex) % tex; sendPrev(); draw(); } }, '‹'), h('b', null, 'Variante ' + (st.t + 1) + ' / ' + tex), h('button', { onclick: () => { st.t = (st.t + 1) % tex; sendPrev(); draw(); } }, '›')),
      gear ? null : h('div', { class: 'sh-ef' }, SLOTS.flatMap((s) => s[2]).filter((s) => s[1] === 'c' && [11, 4, 6].includes(s[2])).map((s) => h('div', { class: 'sh-e' }, h('span', null, s[0]), h('i', null, h('u', { style: { width: Math.min(100, ((app.comps[s[2]].d + 1) / Math.max(1, lim().comps[s[2]] || 1)) * 100) + '%' } })), h('b', null, String(app.comps[s[2]].d + 1)))))].filter(Boolean));
    if (gear) {
      const bag = isBags() ? gear.bags.find((b) => b.d === st.d && b.t === st.t) : null;
      const cost = isBags() ? (bag && bag.price) : gear.mask_price;
      const can = isBags() ? !!bag : st.d > 0;
      sh.act.append(h('button', { class: 'sh-btn ghost', onclick: opt.onCancel }, 'Quitter'),
        sh.button(!can ? (isBags() ? 'Choisis un sac' : 'Choisis un masque') : 'Acheter ' + G.money(cost || 0), () => { if (can && opt.onBuy) opt.onBuy({ kind: isBags() ? 'bag' : 'mask', d: st.d, t: st.t }); }));
      return;
    }
    sh.act.append(h('button', { class: 'sh-btn ghost', onclick: opt.onCancel }, 'Annuler'), sh.button(price > 0 ? 'Payer ' + G.money(price) : 'Valider', () => opt.onSubmit && opt.onSubmit(app)));
  }
  const cam = opt.static ? null : h('div', { class: 'sh-cam' }, [['face', 'Visage'], ['body', 'Corps'], ['feet', 'Pieds']].map(([m, l]) => h('button', { onclick: () => G.post('creator.cam', { mode: m }) }, l)),
    h('button', { title: 'Tourner à gauche', onclick: () => G.post('creator.rotate', { delta: -25 }) }, '⟲'), h('button', { title: 'Tourner à droite', onclick: () => G.post('creator.rotate', { delta: 25 }) }, '⟳'));
  draw(); loadTex();
  if (cam) sh.el.appendChild(cam);
  return { el: sh.el, app, sh, select: pickDrawable };
}
G.wardrobeView = wardrobeView;

const box = () => document.getElementById('g-wardrobe') || (function () { const e = h('div', { id: 'g-wardrobe' }); G.root.appendChild(e); return e; })();
G.on('wardrobe.open', (d) => {
  G.hints && G.hints.set([{ k: 'Visage · Corps · Pieds', t: 'Changer la caméra' }, { k: '⟲ ⟳', t: 'Tourner le personnage' }, { k: 'Numéro', t: 'Aller à un modèle' }, { k: 'Échap', t: 'Quitter la cabine' }]);
  const v = wardrobeView(d, { onCancel: () => G.post('shop.close', {}), onSubmit: (a) => G.post('wardrobe.pay', { appearance: a }), onBuy: (it) => G.post('wardrobe.buy', it) });
  const r = G.clear(box()); r.classList.remove('hidden'); r.appendChild(v.el); document.body.classList.add('wd-on');
  G.uiStack = G.uiStack.filter((u) => u.id !== 'wardrobe'); G.uiStack.push({ id: 'wardrobe', onEscape: () => G.post('shop.close', {}) });
});
G.on('wardrobe.close', () => {
  G.hints && G.hints.clear(); document.body.classList.remove('wd-on'); const r = document.getElementById('g-wardrobe'); if (r) { G.clear(r); r.classList.add('hidden'); } G.uiStack = G.uiStack.filter((u) => u.id !== 'wardrobe'); });

G.preview.wardrobe = function (b) {
  G.clear(b);
  const v = wardrobeView({ shop: { label: 'Binco', price: 25 }, cash: 640, bank: 18250, limits: null, appearance: null }, { static: true });
  b.appendChild(h('div', { class: 'sh-stage' }, v.el));
};
})();
