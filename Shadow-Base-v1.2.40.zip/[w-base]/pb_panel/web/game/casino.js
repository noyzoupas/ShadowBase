/* Casino : caisse (jetons, loterie) et jeux. Le serveur fait tous les tirages : cette page anime le résultat reçu et renvoie les choix.
   Aucune donnée serveur n'est insérée via innerHTML. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const NS = 'http://www.w3.org/2000/svg';
const fmt = (n) => Math.floor(Number(n) || 0).toLocaleString('fr-FR');
const money = (n) => fmt(n) + ' $';
const chips = (n) => fmt(n) + ' jetons';
let S = null;   // { info, game, el, stage, chipsEl, view, bet, busy }

// Sons (synthétisés : aucun fichier à charger) -------------------------------------------------------------------------------------------------
let AC = null;
function tone(f, d, type, vol, delay) {
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const t = AC.currentTime + (delay || 0), o = AC.createOscillator(), g = AC.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.06, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d + 0.03);
  } catch (e) { /* pas de son */ }
}
const SFX = {
  tick: () => tone(1900, 0.025, 'square', 0.015), stop: () => tone(180, 0.09, 'triangle', 0.09), chip: () => { tone(2600, 0.03, 'square', 0.025); tone(3400, 0.03, 'square', 0.015, 0.03); },
  card: () => tone(700, 0.05, 'triangle', 0.05), lose: () => { tone(220, 0.18, 'sawtooth', 0.03); tone(165, 0.3, 'sawtooth', 0.03, 0.15); },
  win: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, 'triangle', 0.07, i * 0.08)),
  big: () => [523, 659, 784, 1047, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, 0.3, 'triangle', 0.08, i * 0.1)),
  dice: () => { for (let i = 0; i < 6; i++) tone(300 + Math.random() * 500, 0.04, 'square', 0.02, i * 0.09); },
};

// Dessins (symboles, jeton) -------------------------------------------------------------------------------------------------------------------
function sv(tag, a, kids) { const e = document.createElementNS(NS, tag); for (const k in a || {}) e.setAttribute(k, a[k]); (kids || []).forEach((c) => c && e.appendChild(c)); return e; }
function svgBox(size, kids, vb) { return sv('svg', { viewBox: vb || '0 0 64 64', width: size, height: size, class: 'cs-sym' }, kids); }
let gid = 0;
function grad(id, stops, x2, y2) { return sv('linearGradient', { id, x1: '0', y1: '0', x2: x2 || '0', y2: y2 || '1' }, stops.map((s) => sv('stop', { offset: s[0], 'stop-color': s[1] }))); }
const SYMS = {
  cerise: (u) => [sv('defs', {}, [sv('radialGradient', { id: u + 'c', cx: '.35', cy: '.35', r: '.7' }, [sv('stop', { offset: '0', 'stop-color': '#ff8a8a' }), sv('stop', { offset: '.5', 'stop-color': '#e01b2f' }), sv('stop', { offset: '1', 'stop-color': '#7a0614' })])]),
    sv('path', { d: 'M22 40 C24 26 30 14 40 8 M42 40 C40 28 40 18 40 8', stroke: '#3d7a1c', 'stroke-width': '3', fill: 'none', 'stroke-linecap': 'round' }),
    sv('path', { d: 'M40 8 C48 4 56 8 58 14 C50 16 44 14 40 8z', fill: '#5bb83a' }),
    sv('circle', { cx: '20', cy: '45', r: '12', fill: `url(#${u}c)` }), sv('circle', { cx: '43', cy: '46', r: '12', fill: `url(#${u}c)` }),
    sv('ellipse', { cx: '16', cy: '40', rx: '3', ry: '2', fill: '#fff', opacity: '.7' }), sv('ellipse', { cx: '39', cy: '41', rx: '3', ry: '2', fill: '#fff', opacity: '.7' })],
  citron: (u) => [sv('defs', {}, [sv('radialGradient', { id: u + 'l', cx: '.35', cy: '.35', r: '.75' }, [sv('stop', { offset: '0', 'stop-color': '#fff7a6' }), sv('stop', { offset: '.55', 'stop-color': '#f5d10f' }), sv('stop', { offset: '1', 'stop-color': '#b48a00' })])]),
    sv('path', { d: 'M8 33 C8 18 22 10 34 11 C46 12 56 20 57 32 C58 46 44 54 32 54 C18 54 8 46 8 33z', fill: `url(#${u}l)` }),
    sv('path', { d: 'M6 33 l-3 1 l3 1z M57 31 l4 0 l-3 3z', fill: '#b48a00' }), sv('ellipse', { cx: '22', cy: '24', rx: '6', ry: '3', fill: '#fff', opacity: '.55' })],
  raisin: (u) => {
    const out = [sv('defs', {}, [sv('radialGradient', { id: u + 'g', cx: '.35', cy: '.3', r: '.75' }, [sv('stop', { offset: '0', 'stop-color': '#d7a4ff' }), sv('stop', { offset: '.6', 'stop-color': '#7b2fc9' }), sv('stop', { offset: '1', 'stop-color': '#3a0d66' })])]),
      sv('path', { d: 'M32 14 C32 8 36 4 42 3', stroke: '#3d7a1c', 'stroke-width': '3', fill: 'none', 'stroke-linecap': 'round' }), sv('path', { d: 'M33 10 C38 4 50 6 52 12 C44 14 38 13 33 10z', fill: '#5bb83a' })];
    [[22, 20], [32, 20], [42, 20], [17, 30], [27, 30], [37, 30], [47, 30], [22, 40], [32, 40], [42, 40], [27, 50], [37, 50], [32, 59]].forEach((p) => out.push(sv('circle', { cx: p[0], cy: p[1] - 2, r: '6.4', fill: `url(#${u}g)` })));
    return out;
  },
  cloche: (u) => [sv('defs', {}, [grad(u + 'b', [['0', '#fff3b0'], ['.45', '#f2c230'], ['1', '#9c6b00']], '1', '1')]),
    sv('path', { d: 'M32 6 C20 6 15 16 15 28 L15 38 C15 42 10 44 8 48 L56 48 C54 44 49 42 49 38 L49 28 C49 16 44 6 32 6z', fill: `url(#${u}b)`, stroke: '#7a5200', 'stroke-width': '1.5' }),
    sv('rect', { x: '6', y: '47', width: '52', height: '5', rx: '2.5', fill: '#c99a1b' }), sv('circle', { cx: '32', cy: '56', r: '5', fill: '#9c6b00' }), sv('path', { d: 'M23 16 C25 12 28 11 30 11', stroke: '#fff', 'stroke-width': '3', fill: 'none', opacity: '.6', 'stroke-linecap': 'round' })],
  bar: (u) => [sv('defs', {}, [grad(u + 'r', [['0', '#3a3a44'], ['1', '#0b0b10']])]), sv('rect', { x: '4', y: '18', width: '56', height: '28', rx: '6', fill: `url(#${u}r)`, stroke: '#e3b341', 'stroke-width': '2.5' }),
    sv('text', { x: '32', y: '40', 'text-anchor': 'middle', 'font-family': 'BarlowC, Impact, sans-serif', 'font-weight': '800', 'font-size': '22', fill: '#ffd76a', 'letter-spacing': '1' }, [document.createTextNode('BAR')])],
  sept: (u) => [sv('defs', {}, [grad(u + 's', [['0', '#ff6b6b'], ['.5', '#e0102b'], ['1', '#8a0010']])]),
    sv('text', { x: '32', y: '54', 'text-anchor': 'middle', 'font-family': 'BarlowC, Impact, sans-serif', 'font-weight': '800', 'font-style': 'italic', 'font-size': '60', fill: `url(#${u}s)`, stroke: '#ffd76a', 'stroke-width': '2.5', 'paint-order': 'stroke' }, [document.createTextNode('7')])],
  diamant: (u) => [sv('defs', {}, [grad(u + 'd', [['0', '#e8fdff'], ['.5', '#5fe1ff'], ['1', '#1270c9']], '1', '1')]),
    sv('path', { d: 'M14 22 L22 10 L42 10 L50 22 L32 56z', fill: `url(#${u}d)`, stroke: '#0b4f8f', 'stroke-width': '1.2' }),
    sv('path', { d: 'M14 22 L50 22 M22 10 L27 22 L32 56 L37 22 L42 10 M27 22 L32 10 L37 22', stroke: '#0b4f8f', 'stroke-width': '1', fill: 'none', opacity: '.55' }), sv('path', { d: 'M24 13 L28 13 L25 20z', fill: '#fff', opacity: '.8' })],
};
function sym(id, size) { const u = 'cs' + (++gid); return svgBox(size || 64, (SYMS[id] || SYMS.cerise)(u)); }
function chipIco(size, color) {
  const c = color || '#d4af37';
  return svgBox(size || 18, [sv('circle', { cx: '32', cy: '32', r: '29', fill: c, stroke: '#00000055', 'stroke-width': '2' }), sv('circle', { cx: '32', cy: '32', r: '20', fill: 'none', stroke: '#fff', 'stroke-width': '4', 'stroke-dasharray': '8 7' }), sv('circle', { cx: '32', cy: '32', r: '13', fill: '#ffffff30' })]);
}
const CHIP_COL = { 10: '#e9e9ee', 25: '#2f9e5b', 50: '#2a6fd6', 100: '#1d1d24', 250: '#8e3fd1', 500: '#7b2fc9', 1000: '#e3b341', 5000: '#e0102b', 10000: '#ff8a00' };

// Effets -------------------------------------------------------------------------------------------------------------------------------------------
function coinRain(n) {
  if (!S) return;
  const layer = h('div', { class: 'cs-rain' });
  for (let i = 0; i < (n || 26); i++) {
    const c = h('i', { style: { left: (Math.random() * 100) + '%', animationDelay: (Math.random() * 0.8) + 's', animationDuration: (1.4 + Math.random() * 1.2) + 's' } });
    c.appendChild(chipIco(26, ['#e3b341', '#e0102b', '#2a6fd6', '#2f9e5b'][i % 4]));
    layer.appendChild(c);
  }
  S.el.appendChild(layer);
  setTimeout(() => layer.remove(), 3200);
}
function banner(text, tone, sub) {
  if (!S) return;
  const b = h('div', { class: 'cs-banner ' + (tone || '') }, h('b', null, text), sub ? h('span', null, sub) : null);
  S.el.appendChild(b);
  setTimeout(() => b.classList.add('out'), 2300);
  setTimeout(() => b.remove(), 2800);
}
function toast(text, tone) {
  if (!S) return;
  const t = h('div', { class: 'cs-toast ' + (tone || '') }, text);
  S.el.appendChild(t);
  setTimeout(() => t.classList.add('out'), 3200);
  setTimeout(() => t.remove(), 3700);
}
function countTo(el, from, to) {
  const t0 = performance.now(), d = 700;
  (function step(t) { const k = Math.min(1, (t - t0) / d), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(from + (to - from) * e); if (k < 1) requestAnimationFrame(step); })(t0);
}
function setChips(n) {
  if (!S || n == null) return;
  const from = S.info.chips || 0;
  S.info.chips = n;
  if (S.chipsEl) { countTo(S.chipsEl, from, n); S.chipsEl.parentNode.classList.toggle('up', n > from); }
  if (S.view && S.view.chips) S.view.chips();
}

// Envoi au serveur ------------------------------------------------------------------------------------------------------------------------
function act(game, action, payload) {
  if (!S || S.busy) return false;
  S.busy = true;
  G.post('casino.act', { game, action, payload: payload || {} });
  clearTimeout(S.busyT);
  S.busyT = setTimeout(() => { if (S) S.busy = false; }, 6000);   // filet de sécurité si la réponse se perd
  return true;
}

// Sélecteur de mise commun ---------------------------------------------------------------------------------------------------------------
function betBox(onChange) {
  const i = S.info;
  if (!S.bet) S.bet = Math.min(i.max, Math.max(i.min, 100));
  const val = h('input', { class: 'cs-betin', type: 'text', value: fmt(S.bet), oninput: (e) => { const n = parseInt(String(e.target.value).replace(/\D/g, ''), 10) || 0; S.bet = n; onChange && onChange(); }, onblur: () => set(S.bet) });
  function set(n) { S.bet = Math.max(i.min, Math.min(i.max, Math.floor(n) || i.min)); val.value = fmt(S.bet); SFX.chip(); onChange && onChange(); }
  const btn = (label, fn) => h('button', { class: 'cs-mini', onclick: fn }, label);
  return h('div', { class: 'cs-bet' },
    h('div', { class: 'cs-betl' }, h('span', null, 'Mise'), h('small', null, 'de ' + fmt(i.min) + ' à ' + fmt(i.max))),
    h('div', { class: 'cs-betrow' }, btn('½', () => set(S.bet / 2)), btn('−', () => set(S.bet - stepOf(S.bet))), h('div', { class: 'cs-betv' }, chipIco(20), val), btn('+', () => set(S.bet + stepOf(S.bet))), btn('×2', () => set(S.bet * 2)), btn('MAX', () => set(Math.min(i.max, i.chips || i.max)))));
}
function stepOf(n) { return n >= 10000 ? 1000 : n >= 1000 ? 100 : n >= 100 ? 10 : 5; }

// Machine à sous ------------------------------------------------------------------------------------------------------------------------------------
function viewSlots(stage) {
  const ids = S.info.slots.map((s) => s.id);
  const rnd = () => ids[Math.floor(Math.random() * ids.length)];
  const CELL = 112;
  const reels = [], strips = [];
  const win = h('div', { class: 'cs-slotwin' }, h('span', null, 'Bonne chance !'));
  const line = h('div', { class: 'cs-payline' });
  const box = h('div', { class: 'cs-reels' });
  for (let r = 0; r < 3; r++) {
    const strip = h('div', { class: 'cs-strip' });
    [rnd(), rnd(), rnd()].forEach((id) => strip.appendChild(h('div', { class: 'cs-cell' }, sym(id, 84))));
    strips.push(strip);
    const reel = h('div', { class: 'cs-reel' }, strip);
    reels.push(reel);
    box.appendChild(reel);
  }
  box.appendChild(line);
  let auto = 0;
  const spinBtn = h('button', { class: 'cs-go', onclick: () => spin() }, 'LANCER');
  const autoBtn = h('button', { class: 'cs-ghost', onclick: () => { auto = auto ? 0 : 10; autoBtn.classList.toggle('on', !!auto); autoBtn.textContent = auto ? 'Arrêter (auto)' : 'Auto × 10'; if (auto && !S.busy) spin(); } }, 'Auto × 10');
  const pay = h('div', { class: 'cs-paytable' }, h('h4', null, 'Gains (× la mise)'),
    S.info.slots.slice().sort((a, b) => b.three - a.three).map((s) => h('div', { class: 'cs-payrow' }, h('span', { class: 'cs-p3' }, sym(s.id, 26), sym(s.id, 26), sym(s.id, 26)), h('b', null, '× ' + s.three))),
    h('div', { class: 'cs-payrow' }, h('span', { class: 'cs-p3' }, sym('cerise', 26), sym('cerise', 26)), h('b', null, '× 2')),
    h('div', { class: 'cs-payrow' }, h('span', { class: 'cs-p3' }, sym('cerise', 26)), h('b', null, 'mise rendue')));
  const cab = h('div', { class: 'cs-cabinet' }, h('div', { class: 'cs-marquee' }, Array.from({ length: 18 }, () => h('i'))), h('div', { class: 'cs-cabtitle' }, 'JACKPOT ', h('b', null, '× ' + Math.max(...S.info.slots.map((s) => s.three)))), box, win);
  stage.appendChild(h('div', { class: 'cs-slots' }, h('div', { class: 'cs-slotsl' }, cab, h('div', { class: 'cs-ctrl' }, betBox(), autoBtn, spinBtn)), pay));
  function spin() {
    if (S.busy) return;
    if ((S.info.chips || 0) < S.bet) { toast("Pas assez de jetons : passe à la caisse.", 'bad'); auto = 0; autoBtn.classList.remove('on'); autoBtn.textContent = 'Auto × 10'; return; }
    if (act('slots', 'spin', { bet: S.bet })) { spinBtn.disabled = true; win.className = 'cs-slotwin'; win.firstChild.textContent = '…'; box.classList.remove('won'); }
  }
  return {
    res(r) {
      if (!r.ok) { spinBtn.disabled = false; auto = 0; autoBtn.classList.remove('on'); autoBtn.textContent = 'Auto × 10'; return true; }
      const d = r.data;
      let done = 0;
      d.reels.forEach((col, i) => {
        const strip = strips[i];
        const n = 18 + i * 6;
        while (strip.firstChild) strip.removeChild(strip.firstChild);
        const list = [rnd(), rnd(), rnd()];
        for (let k = 0; k < n; k++) list.push(rnd());
        list.push(col[0], col[1], col[2]);
        list.forEach((id) => strip.appendChild(h('div', { class: 'cs-cell' }, sym(id, 84))));
        strip.style.transition = 'none';
        strip.style.transform = 'translateY(0)';
        void strip.offsetHeight;
        const dur = 1.1 + i * 0.45;
        strip.style.transition = `transform ${dur}s cubic-bezier(.15,.55,.15,1.02)`;
        strip.style.transform = `translateY(${-(list.length - 3) * CELL}px)`;
        let ticks = 0;
        const tk = setInterval(() => { SFX.tick(); if (++ticks > dur * 12) clearInterval(tk); }, 80);
        setTimeout(() => {
          clearInterval(tk); SFX.stop();
          if (++done === 3) {
            S.busy = false; spinBtn.disabled = false;
            setChips(r.chips);
            if (d.win > 0) {
              box.classList.add('won');
              win.className = 'cs-slotwin on' + (d.mult >= 20 ? ' big' : '');
              win.firstChild.textContent = d.mult >= 2 ? `+ ${fmt(d.win)} jetons (× ${d.mult})` : 'Mise rendue';
              if (d.mult >= 20) { SFX.big(); coinRain(40); banner('JACKPOT !', 'gold', '+ ' + chips(d.win)); } else if (d.mult >= 2) SFX.win();
            } else { win.className = 'cs-slotwin'; win.firstChild.textContent = 'Perdu, retente ta chance'; }
            if (auto > 0) { auto--; if (auto === 0) { autoBtn.classList.remove('on'); autoBtn.textContent = 'Auto × 10'; } else setTimeout(spin, d.mult >= 20 ? 2200 : 700); }
          }
        }, dur * 1000 + 30);
      });
      return true;
    },
  };
}

// Roulette ----------------------------------------------------------------------------------------------------------------------------------------
const WHEEL_ORDER = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
const REDS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
const colorOf = (n) => n === 0 ? 'green' : (REDS.has(n) ? 'red' : 'black');
function viewRoulette(stage) {
  const SZ = 360, cv = h('canvas', { width: SZ * 2, height: SZ * 2, class: 'cs-rwheel' });
  const ctx = cv.getContext('2d');
  let wA = 0, bA = 0, bR = 0.86, showBall = false;
  function draw() {
    const c = ctx, R = SZ, step = Math.PI * 2 / 37;
    c.clearRect(0, 0, SZ * 2, SZ * 2);
    c.save(); c.translate(R, R);
    // bois
    let g = c.createRadialGradient(0, 0, R * 0.7, 0, 0, R);
    g.addColorStop(0, '#6b3a1a'); g.addColorStop(0.6, '#3b1d0b'); g.addColorStop(1, '#1d0d04');
    c.beginPath(); c.arc(0, 0, R - 2, 0, Math.PI * 2); c.fillStyle = g; c.fill();
    c.beginPath(); c.arc(0, 0, R * 0.9, 0, Math.PI * 2); c.strokeStyle = '#d4af37'; c.lineWidth = 6; c.stroke();
    c.rotate(wA);
    for (let i = 0; i < 37; i++) {
      const n = WHEEL_ORDER[i], a0 = -Math.PI / 2 + (i - 0.5) * step, a1 = a0 + step;
      c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, R * 0.86, a0, a1); c.closePath();
      c.fillStyle = n === 0 ? '#0e8a3e' : (REDS.has(n) ? '#c8102e' : '#141418'); c.fill();
      c.strokeStyle = '#d4af37'; c.lineWidth = 2; c.stroke();
      c.save(); c.rotate(a0 + step / 2 + Math.PI / 2); c.fillStyle = '#fff'; c.font = `700 ${R * 0.075}px BarlowC, Impact, sans-serif`; c.textAlign = 'center'; c.fillText(String(n), 0, -R * 0.76); c.restore();
    }
    c.beginPath(); c.arc(0, 0, R * 0.62, 0, Math.PI * 2); g = c.createRadialGradient(0, 0, 0, 0, 0, R * 0.62); g.addColorStop(0, '#7a4a22'); g.addColorStop(1, '#2a1406'); c.fillStyle = g; c.fill();
    c.strokeStyle = '#d4af37'; c.lineWidth = 4; c.stroke();
    for (let k = 0; k < 4; k++) { c.save(); c.rotate(k * Math.PI / 2); c.fillStyle = '#e8c45a'; c.fillRect(-5, -R * 0.55, 10, R * 0.5); c.restore(); }
    c.beginPath(); c.arc(0, 0, R * 0.12, 0, Math.PI * 2); c.fillStyle = '#f4d675'; c.fill();
    c.restore();
    if (showBall) {
      c.save(); c.translate(R, R);
      const x = Math.cos(bA - Math.PI / 2) * R * bR, y = Math.sin(bA - Math.PI / 2) * R * bR;
      const bg = c.createRadialGradient(x - 4, y - 4, 1, x, y, 13); bg.addColorStop(0, '#fff'); bg.addColorStop(1, '#9aa0aa');
      c.beginPath(); c.arc(x, y, 12, 0, Math.PI * 2); c.fillStyle = bg; c.fill(); c.restore();
    }
  }
  draw();
  // tapis
  const bets = {}; let lastBets = null;
  let chipV = [10, 25, 100, 500, 1000, 5000].filter((v) => v <= S.info.max)[2] || S.info.min;
  const cells = {};
  const keyOf = (t, v) => t + (v != null ? ':' + v : '');
  function cell(t, v, label, cls) {
    const k = keyOf(t, v);
    const e = h('button', { class: 'cs-rc ' + (cls || ''), onclick: () => place(k, 1), oncontextmenu: (ev) => { ev.preventDefault(); place(k, -1); } }, h('span', null, label), h('i', { class: 'cs-stack hidden' }));
    cells[k] = e;
    return e;
  }
  function place(k, dir) {
    if (S.busy) return;
    const cur = bets[k] || 0, nv = Math.max(0, cur + dir * chipV);
    if (nv === cur) return;
    if (dir > 0 && total() + chipV > S.info.max) { toast('Mise maximale du tapis : ' + chips(S.info.max), 'bad'); return; }
    if (nv) bets[k] = nv; else delete bets[k];
    SFX.chip(); paint();
  }
  const total = () => Object.values(bets).reduce((a, b) => a + b, 0);
  const totalEl = h('b', null, '0');
  function paint() {
    for (const k in cells) {
      const st = cells[k].querySelector('.cs-stack');
      if (bets[k]) { st.classList.remove('hidden'); st.textContent = bets[k] >= 1000 ? (bets[k] / 1000).toLocaleString('fr-FR') + 'k' : String(bets[k]); st.style.background = CHIP_COL[chipV] || '#e3b341'; } else st.classList.add('hidden');
    }
    totalEl.textContent = fmt(total());
  }
  const grid = h('div', { class: 'cs-rgrid' });
  grid.appendChild(cell('n', 0, '0', 'green zero'));
  // position explicite de chaque case : 3 lignes (3, 6… 36 en haut), 12 colonnes, puis les colonnes « 2:1 »
  for (let n = 1; n <= 36; n++) { const e = cell('n', n, String(n), colorOf(n)); e.style.gridColumn = String(Math.floor((n - 1) / 3) + 2); e.style.gridRow = String(3 - ((n - 1) % 3)); grid.appendChild(e); }
  [3, 2, 1].forEach((c, i) => { const e = cell('col', c, '2:1', 'out colb'); e.style.gridRow = String(i + 1); grid.appendChild(e); });
  const dozens = h('div', { class: 'cs-rrow3' }, cell('dozen', 1, '1 à 12', 'out'), cell('dozen', 2, '13 à 24', 'out'), cell('dozen', 3, '25 à 36', 'out'));
  const outs = h('div', { class: 'cs-rrow6' }, cell('low', null, '1 à 18', 'out'), cell('even', null, 'PAIR', 'out'), cell('red', null, '◆', 'out red'), cell('black', null, '◆', 'out black'), cell('odd', null, 'IMPAIR', 'out'), cell('high', null, '19 à 36', 'out'));
  const chipBar = h('div', { class: 'cs-chipbar' }, [10, 25, 100, 500, 1000, 5000].filter((v) => v <= S.info.max).map((v) => {
    const b = h('button', { class: 'cs-chipsel' + (v === chipV ? ' on' : ''), onclick: () => { chipV = v; chipBar.querySelectorAll('.cs-chipsel').forEach((x) => x.classList.remove('on')); b.classList.add('on'); SFX.chip(); } }, chipIco(44, CHIP_COL[v]), h('span', null, v >= 1000 ? (v / 1000) + 'k' : String(v)));
    return b;
  }));
  const hist = h('div', { class: 'cs-rhist' });
  const goBtn = h('button', { class: 'cs-go', onclick: () => {
    const list = Object.keys(bets).map((k) => { const [t, v] = k.split(':'); return { t, v: v != null ? Number(v) : undefined, a: bets[k] }; });
    if (!list.length) { toast('Pose tes jetons sur le tapis (clic gauche : poser, clic droit : retirer).', 'bad'); return; }
    if (total() < S.info.min) { toast('Mise minimale : ' + chips(S.info.min), 'bad'); return; }
    if (act('roulette', 'spin', { bets: list })) { lastBets = Object.assign({}, bets); goBtn.disabled = true; }
  } }, 'LANCER LA BILLE');
  const tools = h('div', { class: 'cs-rtools' },
    h('button', { class: 'cs-ghost', onclick: () => { for (const k in bets) delete bets[k]; paint(); } }, 'Effacer'),
    h('button', { class: 'cs-ghost', onclick: () => { if (!lastBets) return; for (const k in bets) delete bets[k]; Object.assign(bets, lastBets); paint(); SFX.chip(); } }, 'Rejouer'),
    h('button', { class: 'cs-ghost', onclick: () => { if (total() * 2 > S.info.max) { toast('Dépasse la mise maximale.', 'bad'); return; } for (const k in bets) bets[k] *= 2; paint(); SFX.chip(); } }, 'Doubler'),
    h('div', { class: 'cs-rtotal' }, 'Total ', totalEl), goBtn);
  stage.appendChild(h('div', { class: 'cs-roulette' }, h('div', { class: 'cs-rwl' }, h('div', { class: 'cs-rwheelbox' }, cv, h('div', { class: 'cs-rptr' })), hist),
    h('div', { class: 'cs-rtable' }, h('div', { class: 'cs-felt' }, grid, dozens, outs), chipBar, tools, h('small', { class: 'cs-hint' }, 'Clic gauche : poser un jeton · clic droit : le retirer. Numéro × 36, douzaine et colonne × 3, chances simples × 2.'))));
  function spinTo(n, done) {
    const idx = WHEEL_ORDER.indexOf(n), step = Math.PI * 2 / 37, t0 = performance.now(), D = 6200;
    const w0 = wA, w1 = w0 + Math.PI * 2 * 3 + Math.random() * Math.PI;
    const finalBall = w1 + idx * step;            // la bille finit sur la case, qui tourne avec la roue
    const b0 = finalBall + Math.PI * 2 * 7;       // part de plus loin, sens inverse
    showBall = true;
    let lastT = 0;
    (function frame(t) {
      const k = Math.min(1, (t - t0) / D), e = 1 - Math.pow(1 - k, 3), eb = 1 - Math.pow(1 - k, 2.2);
      wA = w0 + (w1 - w0) * e;
      bA = b0 + (finalBall - b0) * eb;
      bR = k < 0.65 ? 0.86 : 0.86 - (k - 0.65) / 0.35 * 0.13 + (k < 0.9 ? Math.sin(k * 60) * 0.012 : 0);
      if (t - lastT > 90 && k < 0.95) { lastT = t; SFX.tick(); }
      draw();
      if (k < 1) requestAnimationFrame(frame); else done();
    })(t0);
  }
  return {
    res(r) {
      if (!r.ok) { goBtn.disabled = false; return true; }
      const d = r.data;
      spinTo(d.n, () => {
        S.busy = false; goBtn.disabled = false; setChips(r.chips);
        const dot = h('span', { class: 'cs-hn ' + colorOf(d.n) }, String(d.n));
        hist.insertBefore(dot, hist.firstChild);
        while (hist.childElementCount > 12) hist.lastChild.remove();
        const c = cells[keyOf('n', d.n)]; if (c) { c.classList.add('hit'); setTimeout(() => c.classList.remove('hit'), 3000); }
        const label = d.n === 0 ? 'Le zéro !' : `${d.n} ${REDS.has(d.n) ? 'rouge' : 'noir'}`;
        if (d.win > 0) { (d.win >= d.bet * 10 ? SFX.big : SFX.win)(); if (d.win >= d.bet * 10) coinRain(36); banner(label, 'gold', '+ ' + chips(d.win)); }
        else { SFX.lose(); banner(label, 'dim', 'Perdu'); }
      });
      return true;
    },
  };
}

// Cartes ----------------------------------------------------------------------------------------------------------------------------------------------
const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'V', 'D', 'R', 'A'];
const SUITS = ['♠', '♥', '♦', '♣'];
function cardEl(c, deal, delay) {
  if (!c || c.hidden) return h('div', { class: 'cs-card back' + (deal ? ' deal' : ''), style: { animationDelay: (delay || 0) + 's' } });
  const red = c.s === 1 || c.s === 2, r = RANKS[c.r], s = SUITS[c.s];
  return h('div', { class: 'cs-card' + (red ? ' red' : '') + (deal ? ' deal' : ''), style: { animationDelay: (delay || 0) + 's' } },
    h('div', { class: 'cs-ci tl' }, h('b', null, r), h('span', null, s)), h('div', { class: 'cs-cs' }, c.r >= 9 && c.r <= 11 ? h('em', null, r) : s), h('div', { class: 'cs-ci br' }, h('b', null, r), h('span', null, s)));
}

// Blackjack ----------------------------------------------------------------------------------------------------------------------------------------------
function viewBlackjack(stage) {
  const dealer = h('div', { class: 'cs-bjdealer' }), hands = h('div', { class: 'cs-bjhands' });
  const acts = h('div', { class: 'cs-bjacts' });
  const felt = h('div', { class: 'cs-bjfelt' }, h('div', { class: 'cs-bjarc' }, `LE BLACKJACK PAIE ${S.info.bjPayout === 1.5 ? '3 POUR 2' : '× ' + S.info.bjPayout} · LE CROUPIER RESTE SUR 17`), dealer, h('div', { class: 'cs-bjshoe' }), hands);
  stage.appendChild(h('div', { class: 'cs-bj' }, felt, acts));
  let shown = { d: 0, h: [] }, state = S.info.bj || null;
  const LABEL = { win: 'GAGNÉ', lose: 'PERDU', push: 'ÉGALITÉ', bust: 'SAUTÉ', blackjack: 'BLACKJACK !' };
  function render(st, final) {
    G.clear(dealer); G.clear(hands);
    const dw = h('div', { class: 'cs-bjrow' });
    let delay = 0;
    (st ? st.dealer : []).forEach((c, i) => { const isNew = i >= shown.d || (final && i === 1); dw.appendChild(cardEl(c, isNew, isNew ? (delay += 0.18) : 0)); });
    dealer.appendChild(h('div', { class: 'cs-bjlab' }, 'Croupier', st ? h('span', { class: 'cs-tot' }, String(st.dealerTotal)) : null));
    dealer.appendChild(dw);
    (st ? st.hands : []).forEach((hd, hi) => {
      const row = h('div', { class: 'cs-bjrow' });
      hd.cards.forEach((c, i) => { const isNew = i >= (shown.h[hi] || 0); row.appendChild(cardEl(c, isNew, isNew ? (delay += 0.18) : 0)); });
      hands.appendChild(h('div', { class: 'cs-bjhand' + (hd.active ? ' active' : '') + (hd.result ? ' ' + hd.result : '') },
        row, h('div', { class: 'cs-bjlab' }, h('span', { class: 'cs-tot' }, String(hd.total)), h('span', null, chips(hd.bet)), hd.result ? h('b', { class: 'cs-res' }, LABEL[hd.result] + (hd.win ? ' +' + fmt(hd.win) : '')) : null)));
    });
    if (delay) for (let i = 0; i * 0.18 < delay; i++) setTimeout(SFX.card, i * 180);
    shown = { d: st ? st.dealer.length : 0, h: st ? st.hands.map((x) => x.cards.length) : [] };
    G.clear(acts);
    if (!st || st.over) {
      acts.appendChild(betBox());
      acts.appendChild(h('button', { class: 'cs-go', onclick: () => { shown = { d: 0, h: [] }; act('blackjack', 'deal', { bet: S.bet }); } }, 'DISTRIBUER'));
    } else {
      const L = { hit: 'Tirer', stand: 'Rester', double: 'Doubler', split: 'Partager' };
      st.actions.forEach((a) => acts.appendChild(h('button', { class: a === 'stand' ? 'cs-go' : 'cs-ghost big', onclick: () => act('blackjack', a, {}) }, L[a])));
    }
  }
  render(state, false);
  return {
    res(r) {
      S.busy = false;
      if (!r.ok) return true;
      const st = r.data;
      render(st, st.over);
      setChips(r.chips);
      if (st.over) {
        const net = (st.total || 0) - st.hands.reduce((a, x) => a + x.bet, 0);
        setTimeout(() => {
          if (st.hands.some((x) => x.result === 'blackjack')) { SFX.big(); coinRain(30); banner('BLACKJACK !', 'gold', '+ ' + chips(st.total)); }
          else if (net > 0) { SFX.win(); banner('Gagné', 'gold', '+ ' + chips(st.total)); }
          else if (net === 0 && st.total > 0) banner('Égalité', 'dim', 'Mise rendue');
          else { SFX.lose(); banner(st.dealerTotal > 21 ? 'Croupier sauté' : 'Perdu', 'dim'); }
        }, 600);
      }
      return true;
    },
  };
}

// Roue de la fortune ------------------------------------------------------------------------------------------------------------------------------
function viewWheel(stage) {
  const segs = S.info.wheel, n = segs.length, SZ = 380;
  const cv = h('canvas', { width: SZ * 2, height: SZ * 2, class: 'cs-fwheel' });
  const ctx = cv.getContext('2d');
  const COL = (m) => m >= 10 ? ['#ffd76a', '#b8860b'] : m >= 5 ? ['#ff6b8a', '#a1123a'] : m >= 3 ? ['#b48cff', '#5a2fc9'] : m >= 2 ? ['#5fe1ff', '#1270c9'] : m >= 1.5 ? ['#7be0a4', '#1f8a4c'] : ['#3a3d48', '#1b1d24'];
  let ang = 0;
  function draw() {
    const c = ctx, R = SZ, step = Math.PI * 2 / n;
    c.clearRect(0, 0, SZ * 2, SZ * 2); c.save(); c.translate(R, R);
    c.beginPath(); c.arc(0, 0, R - 4, 0, Math.PI * 2); c.fillStyle = '#1a1206'; c.fill();
    c.rotate(ang);
    for (let i = 0; i < n; i++) {
      const a0 = -Math.PI / 2 + (i - 0.5) * step, col = COL(segs[i]);
      const g = c.createRadialGradient(0, 0, R * 0.2, 0, 0, R * 0.9); g.addColorStop(0, col[1]); g.addColorStop(1, col[0]);
      c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, R * 0.9, a0, a0 + step); c.closePath(); c.fillStyle = g; c.fill(); c.strokeStyle = '#d4af37'; c.lineWidth = 2; c.stroke();
      c.save(); c.rotate(a0 + step / 2 + Math.PI / 2); c.fillStyle = segs[i] ? '#fff' : '#8b90a0'; c.font = `800 ${R * (segs[i] >= 10 ? 0.075 : 0.06)}px BarlowC, Impact, sans-serif`; c.textAlign = 'center';
      c.fillText(segs[i] ? '×' + String(segs[i]).replace('.', ',') : '✕', 0, -R * 0.74); c.restore();
    }
    for (let i = 0; i < n; i++) { c.save(); c.rotate(-Math.PI / 2 + (i - 0.5) * step); c.beginPath(); c.arc(R * 0.9, 0, 5, 0, Math.PI * 2); c.fillStyle = '#ffe9a8'; c.fill(); c.restore(); }
    c.restore();
    c.save(); c.translate(R, R);
    const hub = c.createRadialGradient(-10, -10, 4, 0, 0, R * 0.2); hub.addColorStop(0, '#fff3c4'); hub.addColorStop(1, '#b8860b');
    c.beginPath(); c.arc(0, 0, R * 0.19, 0, Math.PI * 2); c.fillStyle = hub; c.fill(); c.lineWidth = 6; c.strokeStyle = '#6b4a00'; c.stroke();
    c.fillStyle = '#3b2600'; c.font = `800 ${R * 0.07}px BarlowC, Impact, sans-serif`; c.textAlign = 'center'; c.fillText('LUCKY', 0, R * 0.025);
    c.restore();
  }
  draw();
  const goBtn = h('button', { class: 'cs-go', onclick: () => { if (act('wheel', 'spin', { bet: S.bet })) goBtn.disabled = true; } }, 'FAIRE TOURNER');
  const counts = {};
  segs.forEach((m) => { counts[m] = (counts[m] || 0) + 1; });
  const legend = h('div', { class: 'cs-wlegend' }, Object.keys(counts).map(Number).sort((a, b) => b - a).map((m) => h('div', { class: 'cs-wl' }, h('i', { style: { background: COL(m)[0] } }), h('b', null, m ? '× ' + String(m).replace('.', ',') : 'Perdu'), h('span', null, counts[m] + ' case' + (counts[m] > 1 ? 's' : '')))));
  stage.appendChild(h('div', { class: 'cs-wheel' }, h('div', { class: 'cs-fwbox' }, cv, h('div', { class: 'cs-fptr' })), h('div', { class: 'cs-wside' }, h('h4', null, 'Roue de la fortune'), h('p', null, 'Ta mise est multipliée par la case où s\'arrête la roue.'), legend, betBox(), goBtn)));
  return {
    res(r) {
      if (!r.ok) { goBtn.disabled = false; return true; }
      const d = r.data, step = Math.PI * 2 / n, t0 = performance.now(), D = 5600;
      // la case i est en haut (sous la flèche) quand l'angle vaut -(i - 1) × pas ; on y arrive après 7 tours complets
      const TAU = Math.PI * 2, target = -(d.index - 1) * step + (Math.random() - 0.5) * step * 0.6;
      const a0 = ang, a1 = a0 + (((target - a0) % TAU) + TAU) % TAU + TAU * 7;
      let lastSeg = -1;
      (function frame(t) {
        const k = Math.min(1, (t - t0) / D), e = 1 - Math.pow(1 - k, 4);
        ang = a0 + (a1 - a0) * e;
        const seg = Math.floor(ang / step);
        if (seg !== lastSeg) { lastSeg = seg; SFX.tick(); }
        draw();
        if (k < 1) requestAnimationFrame(frame);
        else {
          S.busy = false; goBtn.disabled = false; setChips(r.chips);
          if (d.win > 0) { (d.mult >= 5 ? SFX.big : SFX.win)(); if (d.mult >= 5) coinRain(34); banner('× ' + String(d.mult).replace('.', ','), 'gold', '+ ' + chips(d.win)); }
          else { SFX.lose(); banner('Perdu', 'dim', 'La roue tourne, retente ta chance'); }
        }
      })(t0);
      return true;
    },
  };
}

// Dés ---------------------------------------------------------------------------------------------------------------------------------------------------
const PIPS = { 1: [5], 2: [1, 9], 3: [1, 5, 9], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
const FACE_ROT = { 1: [0, 0], 2: [0, -90], 3: [-90, 0], 4: [90, 0], 5: [0, 90], 6: [0, 180] };
function die() {
  const cube = h('div', { class: 'cs-cube' });
  [1, 2, 3, 4, 5, 6].forEach((f) => { const face = h('div', { class: 'cs-face f' + f }); for (let i = 1; i <= 9; i++) face.appendChild(h('i', { class: PIPS[f].includes(i) ? 'on' : '' })); cube.appendChild(face); });
  return { el: h('div', { class: 'cs-die' }, cube), cube };
}
function viewDice(stage) {
  const d1 = die(), d2 = die();
  let pick = 'over';
  const opts = [['under', 'Moins de 7', S.info.dice.side], ['seven', '7 exact', S.info.dice.seven], ['over', 'Plus de 7', S.info.dice.side]];
  const pickBox = h('div', { class: 'cs-dpick' }, opts.map((o) => {
    const b = h('button', { class: 'cs-dopt' + (o[0] === pick ? ' on' : ''), onclick: () => { pick = o[0]; pickBox.querySelectorAll('.cs-dopt').forEach((x) => x.classList.remove('on')); b.classList.add('on'); SFX.chip(); } },
      h('b', null, o[1]), h('span', null, '× ' + String(o[2]).replace('.', ',')));
    return b;
  }));
  const sum = h('div', { class: 'cs-dsum' }, '?');
  const goBtn = h('button', { class: 'cs-go', onclick: () => { if (act('dice', 'roll', { bet: S.bet, pick })) { goBtn.disabled = true; [d1, d2].forEach((d) => { d.cube.style.transition = 'none'; d.cube.classList.add('roll'); }); SFX.dice(); sum.textContent = '…'; } } }, 'LANCER LES DÉS');
  stage.appendChild(h('div', { class: 'cs-dice' }, h('div', { class: 'cs-dtable' }, d1.el, sum, d2.el), pickBox, h('div', { class: 'cs-ctrl' }, betBox(), goBtn)));
  function show(d, v) { const r = FACE_ROT[v]; d.cube.classList.remove('roll'); void d.cube.offsetWidth; d.cube.style.transition = 'transform .7s cubic-bezier(.2,1.4,.4,1)'; d.cube.style.transform = `rotateX(${r[0] + 720}deg) rotateY(${r[1] + 720}deg)`; }
  return {
    res(r) {
      if (!r.ok) { goBtn.disabled = false; [d1, d2].forEach((d) => d.cube.classList.remove('roll')); return true; }
      const d = r.data;
      setTimeout(() => { show(d1, d.d[0]); show(d2, d.d[1]); }, 900);
      setTimeout(() => {
        S.busy = false; goBtn.disabled = false; setChips(r.chips); sum.textContent = String(d.sum);
        if (d.win > 0) { SFX.win(); if (d.pick === 'seven') coinRain(24); banner('Total ' + d.sum, 'gold', '+ ' + chips(d.win)); } else { SFX.lose(); banner('Total ' + d.sum, 'dim', 'Perdu'); }
      }, 1750);
      return true;
    },
  };
}

// Plus haut / plus bas ------------------------------------------------------------------------------------------------------------------------------------
function viewHilo(stage) {
  const cardBox = h('div', { class: 'cs-hlcard' }), hist = h('div', { class: 'cs-hlhist' }), ctrl = h('div', { class: 'cs-hlctrl' }), info = h('div', { class: 'cs-hlinfo' });
  stage.appendChild(h('div', { class: 'cs-hilo' }, h('h4', null, 'La prochaine carte sera-t-elle plus haute ou plus basse ?'), h('div', { class: 'cs-hlmid' }, cardBox), info, ctrl, hist));
  function render(st, res) {
    G.clear(cardBox); G.clear(ctrl); G.clear(hist); G.clear(info);
    if (st) {
      cardBox.appendChild(cardEl(st.card, true));
      (st.history || []).slice(0, -1).forEach((c) => hist.appendChild(cardEl(c)));
    } else cardBox.appendChild(cardEl({ hidden: true }));
    if (st && !st.over) {
      info.appendChild(h('div', null, 'Gain actuel ', h('b', null, chips(st.cash)), ' · × ' + String(st.mult).replace('.', ',')));
      ctrl.appendChild(h('button', { class: 'cs-ghost big', disabled: !st.lo, onclick: () => act('hilo', 'guess', { dir: 'lo' }) }, '▼ Plus bas', st.lo ? h('small', null, '× ' + String(st.lo).replace('.', ',')) : null));
      ctrl.appendChild(h('button', { class: 'cs-go', disabled: !st.steps, onclick: () => act('hilo', 'cash', {}) }, 'ENCAISSER ' + fmt(st.cash)));
      ctrl.appendChild(h('button', { class: 'cs-ghost big', disabled: !st.hi, onclick: () => act('hilo', 'guess', { dir: 'hi' }) }, '▲ Plus haut', st.hi ? h('small', null, '× ' + String(st.hi).replace('.', ',')) : null));
    } else {
      if (res === 'lose') info.appendChild(h('div', { class: 'bad' }, 'Raté !'));
      if (res === 'cash') info.appendChild(h('div', { class: 'good' }, 'Encaissé : ' + chips(st.cash)));
      ctrl.appendChild(betBox());
      ctrl.appendChild(h('button', { class: 'cs-go', onclick: () => act('hilo', 'start', { bet: S.bet }) }, 'COMMENCER'));
    }
  }
  render(S.info.hilo || null);
  return {
    res(r) {
      S.busy = false;
      if (!r.ok) return true;
      const st = r.data;
      SFX.card();
      render(st, st.result);
      setChips(r.chips);
      if (st.result === 'win') SFX.chip();
      else if (st.result === 'push') toast('Égalité : on continue.', '');
      else if (st.result === 'lose') SFX.lose();
      else if (st.result === 'cash') { (st.mult >= 10 ? SFX.big : SFX.win)(); if (st.mult >= 10) coinRain(30); banner('Encaissé', 'gold', '+ ' + chips(st.cash)); }
      return true;
    },
  };
}

// Tickets à gratter -----------------------------------------------------------------------------------------------------------------------------------
function viewScratch(stage) {
  const price = S.info.scratchPrice;
  const ticket = h('div', { class: 'cs-ticket' });
  const buy = h('button', { class: 'cs-go', onclick: () => { if (act('scratch', 'buy', {})) buy.disabled = true; } }, 'ACHETER UN TICKET · ' + chips(price));
  const all = h('button', { class: 'cs-ghost hidden', onclick: () => reveal() }, 'Tout gratter');
  const prizes = h('div', { class: 'cs-paytable' }, h('h4', null, '3 symboles identiques'), S.info.scratch.slice().reverse().map((s) => h('div', { class: 'cs-payrow' }, h('span', { class: 'cs-p3' }, sym(s.id, 24), sym(s.id, 24), sym(s.id, 24)), h('b', null, s.mult === 1 ? 'remboursé' : fmt(price * s.mult)))));
  stage.appendChild(h('div', { class: 'cs-scratch' }, h('div', { class: 'cs-scl' }, ticket, h('div', { class: 'cs-ctrl' }, all, buy)), prizes));
  let cur = null, revealed = true;
  function idle() {
    G.clear(ticket);
    ticket.appendChild(h('div', { class: 'cs-tkhead' }, h('b', null, 'GRATTE & GAGNE'), h('span', null, "jusqu'à " + chips(price * 200))));
    ticket.appendChild(h('div', { class: 'cs-tkidle' }, sym('diamant', 90), h('p', null, 'Achète un ticket puis gratte les 9 cases à la souris.')));
  }
  idle();
  function reveal() {
    if (revealed || !cur) return;
    revealed = true; all.classList.add('hidden');
    const cv = ticket.querySelector('canvas'); if (cv) cv.classList.add('gone');
    buy.disabled = false;
    setChips(cur.chips);
    const d = cur.data;
    if (d.win > 0) {
      ticket.querySelectorAll('.cs-tkcell').forEach((c, i) => { if (d.cells[i] === d.symbol) c.classList.add('win'); });
      if (d.win >= price * 10) { SFX.big(); coinRain(36); } else SFX.win();
      banner(d.win === price ? 'Remboursé' : 'Gagné !', 'gold', '+ ' + chips(d.win));
    } else { SFX.lose(); banner('Perdu', 'dim', 'Pas de chance cette fois'); }
  }
  function setup(r) {
    cur = r; revealed = false;
    G.clear(ticket);
    ticket.appendChild(h('div', { class: 'cs-tkhead' }, h('b', null, 'GRATTE & GAGNE'), h('span', null, "jusqu'à " + chips(price * 200))));
    const grid = h('div', { class: 'cs-tkgrid' }, r.data.cells.map((id) => h('div', { class: 'cs-tkcell' }, sym(id, 62))));
    const W = 420, H = 300, cv = h('canvas', { width: W, height: H, class: 'cs-tkcover' });
    const wrap = h('div', { class: 'cs-tkwrap' }, grid, cv);
    ticket.appendChild(wrap);
    const c = cv.getContext('2d');
    const g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#cfd3da'); g.addColorStop(0.5, '#f4f6f9'); g.addColorStop(1, '#a9aeb8');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.fillStyle = 'rgba(80,86,98,.35)'; c.font = '800 22px BarlowC, Impact, sans-serif'; c.textAlign = 'center';
    for (let y = 40; y < H; y += 56) for (let x = (y / 56 % 2) * 70 + 40; x < W; x += 140) c.fillText('GRATTEZ', x, y);
    c.globalCompositeOperation = 'destination-out';
    let down = false, moves = 0;
    const at = (e) => { const b = cv.getBoundingClientRect(); return [(e.clientX - b.left) * W / b.width, (e.clientY - b.top) * H / b.height]; };
    function scratch(e) {
      if (!down || revealed) return;
      const [x, y] = at(e);
      c.beginPath(); c.arc(x, y, 22, 0, Math.PI * 2); c.fill();
      if (++moves % 6 === 0) { tone(5000 + Math.random() * 2000, 0.02, 'square', 0.006); check(); }
    }
    function check() {
      const px = c.getImageData(0, 0, W, H).data;
      let clear = 0;
      for (let i = 3; i < px.length; i += 64) if (px[i] < 40) clear++;
      if (clear / (px.length / 64) > 0.58) reveal();
    }
    cv.addEventListener('mousedown', (e) => { down = true; scratch(e); });
    cv.addEventListener('mousemove', scratch);
    window.addEventListener('mouseup', () => { down = false; });
    all.classList.remove('hidden');
  }
  return {
    res(r) {
      S.busy = false;
      if (!r.ok) { buy.disabled = false; return true; }
      setup(r);
      return true;
    },
  };
}

// Caisse : jetons et loterie ------------------------------------------------------------------------------------------------------------------------------
function viewCashier(stage) {
  const i = S.info;
  let buyN = 1000, sellN = Math.min(i.chips || 0, 1000), acc = 'cash';
  const cost = h('b'), net = h('b');
  const upd = () => { cost.textContent = money(buyN * i.value); net.textContent = money(Math.floor(sellN * i.value * (100 - i.fee) / 100)); };
  const num = (v, set) => h('input', { class: 'cs-in', type: 'text', value: fmt(v), oninput: (e) => { set(parseInt(String(e.target.value).replace(/\D/g, ''), 10) || 0); upd(); } });
  const buyIn = num(buyN, (v) => { buyN = v; }), sellIn = num(sellN, (v) => { sellN = v; });
  const quick = (vals, inp, set) => h('div', { class: 'cs-quick' }, vals.map((v) => h('button', { class: 'cs-mini', onclick: () => { set(v); inp.value = fmt(v); upd(); SFX.chip(); } }, v >= 1000 ? (v / 1000) + 'k' : String(v))));
  const accSel = h('div', { class: 'cs-seg' }, [['cash', 'Espèces', i.cash], ['bank', 'Banque', i.bank]].map((a) => {
    const b = h('button', { class: a[0] === acc ? 'on' : '', onclick: () => { acc = a[0]; accSel.querySelectorAll('button').forEach((x) => x.classList.remove('on')); b.classList.add('on'); } }, a[1], h('small', null, money(a[2])));
    return b;
  }));
  upd();
  const exch = h('div', { class: 'cs-cards2' },
    h('div', { class: 'cs-box' }, h('h4', null, 'Acheter des jetons'), h('p', null, '1 jeton = ' + money(i.value)), buyIn, quick([100, 500, 1000, 5000, 10000], buyIn, (v) => { buyN = v; }), accSel,
      h('div', { class: 'cs-sum' }, 'À payer ', cost), h('button', { class: 'cs-go', onclick: () => act('cashier', 'buy', { n: buyN, acc }) }, 'ACHETER')),
    h('div', { class: 'cs-box' }, h('h4', null, 'Revendre des jetons'), h('p', null, 'Tu as ' + chips(i.chips) + (i.fee ? ' · commission ' + i.fee + ' %' : '')), sellIn,
      quick([100, 500, 1000, 5000], sellIn, (v) => { sellN = v; }), h('button', { class: 'cs-mini wide', onclick: () => { sellN = S.info.chips; sellIn.value = fmt(sellN); upd(); } }, 'Tout revendre'),
      h('div', { class: 'cs-sum' }, 'Tu reçois ', net, ' en espèces'), h('button', { class: 'cs-go alt', onclick: () => act('cashier', 'sell', { n: sellN }) }, 'REVENDRE')));
  stage.appendChild(exch);
  const L = i.lotto;
  if (L) {
    const picked = new Set();
    const grid = h('div', { class: 'cs-lgrid' });
    const left = h('span');
    const updL = () => { left.textContent = picked.size === L.pick ? 'Grille complète' : `Encore ${L.pick - picked.size} numéro${L.pick - picked.size > 1 ? 's' : ''}`; grid.querySelectorAll('button').forEach((b) => b.classList.toggle('on', picked.has(Number(b.dataset.n)))); };
    for (let n = 1; n <= L.max; n++) grid.appendChild(h('button', { 'data-n': n, onclick: () => { if (picked.has(n)) picked.delete(n); else if (picked.size < L.pick) picked.add(n); SFX.chip(); updL(); } }, String(n)));
    updL();
    const nextTxt = new Date(L.next * 1000).toLocaleString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
    const mine = h('div', { class: 'cs-ltix' }, (L.mine || []).length ? L.mine.map((t) => h('div', { class: 'cs-ltk' }, t.split(',').map((x) => h('span', null, x)))) : h('small', null, 'Aucun ticket pour ce tirage.'));
    stage.appendChild(h('div', { class: 'cs-lotto' },
      h('div', { class: 'cs-lhead' }, h('div', null, h('small', null, 'LOTERIE · TIRAGE N°' + L.draw), h('b', { class: 'cs-pot' }, money(L.pot)), h('span', null, 'Tirage ' + nextTxt)),
        h('div', { class: 'cs-lrules' }, h('div', null, '5 bons numéros : ', h('b', null, 'la cagnotte')), h('div', null, '4 bons : ', h('b', null, money(L.p4))), h('div', null, '3 bons : ', h('b', null, money(L.p3))))),
      h('div', { class: 'cs-lbody' }, h('div', null, grid, h('div', { class: 'cs-lact' }, left,
        h('button', { class: 'cs-ghost', onclick: () => { picked.clear(); const pool = Array.from({ length: L.max }, (_, k) => k + 1); while (picked.size < L.pick) picked.add(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]); SFX.chip(); updL(); } }, 'Grille au hasard'),
        h('button', { class: 'cs-go', onclick: () => { if (picked.size !== L.pick) { toast(`Choisis ${L.pick} numéros.`, 'bad'); return; } act('cashier', 'lotto', { nums: Array.from(picked) }); } }, 'VALIDER · ' + money(L.price)))),
        h('div', { class: 'cs-lside' }, h('h4', null, 'Mes tickets'), mine, L.last ? h('div', { class: 'cs-llast' }, h('h4', null, 'Dernier tirage (n°' + L.last.id + ')'), h('div', { class: 'cs-ltk big' }, String(L.last.nums).split(',').map((x) => h('span', null, x)))) : null))));
  }
  return {
    res(r) {
      S.busy = false;
      if (r.ok) { SFX.chip(); toast(r.msg, 'good'); if (r.info) { const g = S.game; S.info = Object.assign(S.info, r.info); setChips(r.info.chips); open(g, true); } }
      return false;
    },
  };
}

// Poker (entre joueurs) ------------------------------------------------------------------------------------------------------------------------------
const PK_SLOTS = [[50, 86], [11, 68], [11, 22], [50, 5], [89, 22], [89, 68]];
const STREET = { pre: 'Avant le flop', flop: 'Flop', turn: 'Turn', river: 'Rivière' };
function viewPoker(stage) {
  const wrap = h('div', { class: 'pk' });
  stage.appendChild(wrap);
  let st = null, timer = null, raiseTo = 0, boardShown = 0;
  const live = () => document.body.contains(wrap);
  function slotOf(i) {
    const n = st.max || 6, base = st.mySeat || 1, rel = ((i - base) % n + n) % n;
    return PK_SLOTS[Math.round(rel * 6 / n) % 6];
  }
  function seatEl(e) {
    const pos = slotOf(e.i);
    const cards = h('div', { class: 'pk-cards' });
    if (e.cards) e.cards.forEach((c, k) => cards.appendChild(cardEl(c, false, k * 0.1)));
    else if (e.hidden) for (let k = 0; k < e.hidden; k++) cards.appendChild(cardEl(null));
    const bar = e.turn && st.left != null ? h('div', { class: 'pk-time' }, h('i', { style: { width: Math.max(0, Math.min(100, st.left / (st.turnSecs || 25) * 100)) + '%' } })) : null;
    return h('div', { class: 'pk-seat' + (e.me ? ' me' : '') + (e.turn ? ' turn' : '') + (e.folded ? ' folded' : '') + (e.won ? ' won' : '') + (e.out ? ' out' : ''), style: { left: pos[0] + '%', top: pos[1] + '%' } },
      cards,
      h('div', { class: 'pk-plate' },
        e.button ? h('b', { class: 'pk-btn' }, 'D') : null,
        h('div', { class: 'pk-name' }, e.name || 'Place libre'),
        h('div', { class: 'pk-stack' }, chipIco(14), fmt(e.stack)),
        e.won ? h('div', { class: 'pk-won' }, '+ ' + fmt(e.won)) : (e.hand ? h('div', { class: 'pk-hand' }, e.hand) : (e.last ? h('div', { class: 'pk-last' }, e.last) : (e.out ? h('div', { class: 'pk-last' }, 'Attend la prochaine main') : null))),
        bar),
      e.bet ? h('div', { class: 'pk-bet' }, chipIco(14), fmt(e.bet)) : null);
  }
  function actions() {
    const box = h('div', { class: 'pk-acts' });
    const T = st.tour;
    const passIn = () => h('input', { class: 'cs-in pk-pass', type: 'password', maxlength: '12', placeholder: 'Mot de passe' });
    if (T && !T.started) {
      // tournoi en attente des inscriptions
      const pw = st.locked && !T.mine ? passIn() : null;
      box.appendChild(h('div', { class: 'pk-row' },
        h('span', { class: 'pk-wait' }, T.entrants + ' inscrit' + (T.entrants > 1 ? 's' : '') + ' sur ' + st.max + (T.host ? ' · lance quand tu veux (2 joueurs minimum)' : ' · le créateur lance le tournoi')),
        !T.mine ? pw : null,
        !T.mine ? h('button', { class: 'cs-go', onclick: () => act('poker', 'tjoin', { pass: pw ? pw.value : '' }) }, "S'INSCRIRE · " + fmt(T.buyin)) : null,
        T.host ? h('button', { class: 'cs-go alt', onclick: () => act('poker', 'tstart', {}) }, 'LANCER LE TOURNOI') : null,
        T.mine ? h('button', { class: 'cs-ghost', onclick: () => act('poker', 'leave', {}) }, 'Se désinscrire') : null));
      return box;
    }
    if (!st.mySeat) {
      if (T) { box.appendChild(h('div', { class: 'pk-row' }, h('span', { class: 'pk-wait' }, T.mine ? 'Tu es éliminé(e) : tu peux regarder la fin du tournoi.' : 'Tournoi en cours : tu peux regarder.'))); return box; }
      let amt = Math.max(st.minBuy, Math.min(st.maxBuy, S.info.chips || st.minBuy));
      const inp = h('input', { class: 'cs-in', type: 'text', value: fmt(amt), oninput: (e) => { amt = parseInt(String(e.target.value).replace(/\D/g, ''), 10) || 0; } });
      const pw = st.locked ? passIn() : null;
      box.appendChild(h('div', { class: 'pk-sit' },
        h('div', null, h('b', null, (st.locked ? '🔒 Table privée · ' : '') + 'Blindes ' + fmt(st.sb) + ' / ' + fmt(st.bb)), h('small', null, 'Cave de ' + fmt(st.minBuy) + ' à ' + fmt(st.maxBuy) + ' jetons · commission ' + st.rake + ' % dès le flop')),
        pw, inp, h('button', { class: 'cs-go', onclick: () => act('poker', 'sit', { amount: amt, pass: pw ? pw.value : '' }) }, "S'ASSEOIR")));
      // table vide : créer un tournoi
      if (st.tourney && !(st.seats || []).length) {
        let buy = Math.max(st.tourney.min, Math.min(st.tourney.max, 1000));
        const bin = h('input', { class: 'cs-in', type: 'text', value: fmt(buy), oninput: (e) => { buy = parseInt(String(e.target.value).replace(/\D/g, ''), 10) || 0; } });
        const tpw = passIn();
        box.appendChild(h('div', { class: 'pk-sit pk-tnew' },
          h('div', null, h('b', null, 'Créer un tournoi'), h('small', null, "Droit d'entrée de " + fmt(st.tourney.min) + ' à ' + fmt(st.tourney.max) + ' · ' + fmt(st.tourney.stack) + ' jetons de tournoi chacun · blindes qui doublent · part du casino ' + st.tourney.fee + ' %')),
          tpw, bin, h('button', { class: 'cs-go alt', onclick: () => act('poker', 'tcreate', { buyin: buy, pass: tpw.value }) }, 'CRÉER')));
      }
      return box;
    }
    if (st.toCall != null) {
      const call = st.toCall;
      raiseTo = Math.max(st.minTo, Math.min(st.maxTo, raiseTo || st.minTo));
      const val = h('b', null, fmt(raiseTo));
      const range = h('input', { type: 'range', class: 'pk-range', min: st.minTo, max: st.maxTo, step: Math.max(1, st.sb), value: raiseTo, oninput: (e) => { raiseTo = Number(e.target.value); val.textContent = fmt(raiseTo); } });
      const preset = (label, v) => h('button', { class: 'cs-mini', onclick: () => { raiseTo = Math.max(st.minTo, Math.min(st.maxTo, Math.floor(v))); range.value = raiseTo; val.textContent = fmt(raiseTo); SFX.chip(); } }, label);
      const pot = st.pot || 0;
      box.appendChild(h('div', { class: 'pk-row' },
        h('button', { class: 'cs-ghost big', onclick: () => act('poker', 'fold', {}) }, 'Se coucher'),
        st.canCheck ? h('button', { class: 'cs-ghost big', onclick: () => act('poker', 'check', {}) }, 'Parole') : h('button', { class: 'cs-go', onclick: () => act('poker', 'call', {}) }, 'Suivre ' + fmt(call)),
        st.maxTo > (st.myBet || 0) + call ? h('div', { class: 'pk-raise' },
          h('div', { class: 'pk-pre' }, preset('Min', st.minTo), preset('½ pot', (st.myBet || 0) + call + pot / 2), preset('Pot', (st.myBet || 0) + call + pot), preset('Tapis', st.maxTo)),
          range, h('button', { class: 'cs-go alt', onclick: () => act('poker', raiseTo >= st.maxTo ? 'allin' : 'raise', { to: raiseTo }) }, st.canCheck ? 'Miser ' : 'Relancer à ', val)) : null,
        h('button', { class: 'cs-go red', onclick: () => act('poker', 'allin', {}) }, 'TAPIS')));
    } else {
      const wait = st.nextIn != null ? 'Prochaine main dans ' + st.nextIn + ' s' : (st.street ? 'À un autre joueur de parler…' : 'En attente d\'un deuxième joueur…');
      let lockBox = null;
      if (st.isHost && !T) {
        const pw = passIn();
        lockBox = st.locked ? h('button', { class: 'cs-ghost', onclick: () => act('poker', 'lock', { pass: '' }) }, 'Rendre publique')
          : h('span', { class: 'pk-lock' }, pw, h('button', { class: 'cs-ghost', onclick: () => act('poker', 'lock', { pass: pw.value }) }, 'Rendre privée'));
      }
      box.appendChild(h('div', { class: 'pk-row' }, h('span', { class: 'pk-wait' }, wait), lockBox,
        st.canRebuy && !T ? h('button', { class: 'cs-ghost', onclick: () => act('poker', 'rebuy', { amount: Math.max(1, st.maxBuy - (st.seats.find((x) => x.me) || { stack: 0 }).stack) }) }, 'Recaver') : null,
        h('button', { class: 'cs-ghost', onclick: () => act('poker', 'leave', {}) }, T ? 'Abandonner' : 'Se lever')));
    }
    return box;
  }
  function render() {
    G.clear(wrap);
    const board = h('div', { class: 'pk-board' });
    (st.board || []).forEach((c, k) => board.appendChild(cardEl(c, k >= boardShown, k >= boardShown ? (k - boardShown) * 0.15 : 0)));
    for (let k = (st.board || []).length; k < 5; k++) board.appendChild(h('div', { class: 'cs-card slot' }));
    if ((st.board || []).length > boardShown) for (let k = boardShown; k < st.board.length; k++) setTimeout(SFX.card, (k - boardShown) * 150);
    boardShown = (st.board || []).length;
    const felt = h('div', { class: 'pk-felt' },
      h('div', { class: 'pk-center' },
        st.result && st.over ? h('div', { class: 'pk-result' }, st.result.lines.map((l) => h('div', null, l)), st.result.rake ? h('small', null, 'Commission du casino : ' + fmt(st.result.rake)) : null) : null,
        h('div', { class: 'pk-street' }, st.street ? STREET[st.street] : (st.label || 'Poker')),
        board,
        st.pot ? h('div', { class: 'pk-pot' }, chipIco(18), h('b', null, fmt(st.pot)), h('small', null, 'au pot')) : h('div', { class: 'pk-pot dim' }, "Texas Hold'em · blindes " + fmt(st.sb) + ' / ' + fmt(st.bb)),
        null),
      (st.seats || []).map(seatEl));
    const log = h('div', { class: 'pk-log' }, h('h4', null, 'Table'), (st.log || []).map((l) => h('div', null, l)));
    const T = st.tour;
    if (T) {
      const mmss = (x) => Math.floor(x / 60) + ':' + String(x % 60).padStart(2, '0');
      const pr = (T.prizes || []).map((v, i) => (i + 1) + (i ? 'e' : 'er') + ' ' + fmt(v)).join(' · ');
      wrap.appendChild(h('div', { class: 'pk-tour' }, h('b', null, 'TOURNOI'),
        h('span', null, T.started ? ('Niveau ' + (T.level || 1) + ' · blindes ' + fmt(st.sb) + ' / ' + fmt(st.bb)) : ('Inscriptions · ' + fmt(T.stack) + ' jetons de départ')),
        T.started && T.nextLevel != null ? h('span', { class: 'pk-lvl' }, 'Niveau suivant ' + mmss(T.nextLevel)) : null,
        h('span', null, 'Cagnotte ' + fmt(T.pot)), pr ? h('span', { class: 'pk-prz' }, pr) : null));
    }
    wrap.appendChild(h('div', { class: 'pk-main' }, felt, log));
    wrap.appendChild(actions());
  }
  function onState(d) {
    if ((d.board || []).length < boardShown) boardShown = 0;   // nouvelle main : le tableau repart de zéro
    const me = (d.seats || []).find((x) => x.me);
    if (d.over && !(st && st.over) && me && me.won) { SFX.win(); coinRain(14); }
    if (d.toCall != null && (!st || st.toCall == null)) { raiseTo = 0; tone(880, 0.12, 'triangle', 0.06); }
    st = d;
    render();
    clearInterval(timer);
    timer = setInterval(() => {
      if (!live()) { clearInterval(timer); return; }
      if (st.left != null && st.left > 0) st.left -= 1;
      if (st.nextIn != null && st.nextIn > 0) st.nextIn -= 1;
      if (st.tour && st.tour.nextLevel > 0) {
        st.tour.nextLevel -= 1;
        const lv = wrap.querySelector('.pk-lvl');
        if (lv) lv.textContent = 'Niveau suivant ' + Math.floor(st.tour.nextLevel / 60) + ':' + String(st.tour.nextLevel % 60).padStart(2, '0');
      }
      const bar = wrap.querySelector('.pk-seat.turn .pk-time i');
      if (bar) bar.style.width = Math.max(0, st.left / (st.turnSecs || 25) * 100) + '%';
      const w = wrap.querySelector('.pk-wait');
      if (w && st.nextIn != null) w.textContent = 'Prochaine main dans ' + st.nextIn + ' s';
    }, 1000);
  }
  wrap.appendChild(h('div', { class: 'cs-empty' }, 'Connexion à la table…'));
  setTimeout(() => act('poker', 'watch', {}), 0);
  return {
    res(r) {
      S.busy = false;
      if (r.ok && r.data && r.data.seats) onState(r.data);
      if (r.chips != null) setChips(r.chips);
      return true;
    },
  };
}

// Mes parties (historique du joueur) --------------------------------------------------------------------------------------------------------------
function viewHistory(stage) {
  const box = h('div', { class: 'cs-hist' }, h('div', { class: 'cs-empty' }, 'Chargement…'));
  stage.appendChild(box);
  setTimeout(() => act('history', 'list', {}), 0);
  const signed = (n) => (n > 0 ? '+ ' : n < 0 ? '− ' : '') + fmt(Math.abs(n));
  function card(label, s) {
    const net = s.win - s.bet;
    return h('div', { class: 'cs-hcard ' + (net > 0 ? 'up' : net < 0 ? 'down' : '') }, h('small', null, label), h('b', null, signed(net)), h('span', null, s.n + ' partie' + (s.n > 1 ? 's' : '') + ' · misé ' + fmt(s.bet)));
  }
  function render(d) {
    G.clear(box);
    box.appendChild(h('div', { class: 'cs-hcards' }, card("Aujourd'hui", d.today), card('7 derniers jours', d.week), card('Depuis toujours', d.all)));
    const facts = h('div', { class: 'cs-hfacts' });
    if (d.fav) facts.appendChild(h('div', null, 'Jeu préféré : ', h('b', null, d.fav)));
    if (d.best) facts.appendChild(h('div', null, 'Plus gros gain : ', h('b', null, '+ ' + chips(d.best.net)), ' (' + d.best.game + ', ' + new Date(d.best.at * 1000).toLocaleDateString('fr-FR') + ')'));
    if (d.limit > 0) facts.appendChild(h('div', null, 'Limite de pertes sur 24 h : ', h('b', null, fmt(Math.max(0, d.lossToday)) + ' / ' + fmt(d.limit))));
    box.appendChild(facts);
    const list = h('div', { class: 'cs-hlist' });
    if (!d.rows.length) list.appendChild(h('div', { class: 'cs-empty' }, 'Aucune partie pour le moment.'));
    d.rows.forEach((r) => {
      const net = r.win - r.bet;
      list.appendChild(h('div', { class: 'cs-hrow ' + (net > 0 ? 'up' : net < 0 ? 'down' : '') },
        h('span', null, new Date(r.at * 1000).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })),
        h('span', null, r.game), h('span', null, 'mise ' + fmt(r.bet)), h('b', null, signed(net))));
    });
    box.appendChild(list);
  }
  return { res(r) { S.busy = false; if (r.ok && r.data) render(r.data); return true; } };
}

// Fenêtre ------------------------------------------------------------------------------------------------------------------------------------------------
const VIEWS = { cashier: viewCashier, slots: viewSlots, roulette: viewRoulette, blackjack: viewBlackjack, wheel: viewWheel, dice: viewDice, hilo: viewHilo, scratch: viewScratch, poker: viewPoker, history: viewHistory };
const TITLES = { cashier: 'Caisse', slots: 'Machine à sous', roulette: 'Roulette', blackjack: 'Blackjack', wheel: 'Roue de la fortune', dice: 'Dés', hilo: 'Plus haut / plus bas', scratch: 'Tickets à gratter', poker: "Poker · Texas Hold'em", history: 'Mes parties' };
function open(game, keep) {
  if (!S) return;
  S.game = game;
  G.clear(S.stage);
  S.stage.className = 'cs-stage g-' + game;
  S.titleEl.textContent = TITLES[game] || '';
  S.nav.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.g === game));
  S.view = VIEWS[game](S.stage);
  if (!keep) S.stage.classList.add('fade');
}
function build(info) {
  const r = document.getElementById('g-casino') || (function () { const e = h('div', { id: 'g-casino' }); G.root.appendChild(e); return e; })();
  G.clear(r); r.classList.remove('hidden');
  S = { info, bet: S && S.bet };
  const chipsEl = h('b', null, fmt(info.chips));
  const games = (info.point.kind === 'cashier' ? [{ id: 'cashier', label: 'Caisse', icon: 'coins' }] : info.games.slice());
  if (games.length) games.push({ id: 'history', label: 'Mes parties', icon: 'clock' });
  const nav = h('nav', { class: 'cs-nav' + (games.length > 1 ? '' : ' hidden') }, games.map((g) => h('button', { 'data-g': g.id, onclick: () => { if (!S.busy) open(g.id); } }, G.ico(g.icon), h('span', null, g.label))));
  S.titleEl = h('span', { class: 'cs-title' });
  S.stage = h('div', { class: 'cs-stage' });
  S.nav = nav; S.chipsEl = chipsEl;
  S.el = h('div', { class: 'cs-win' },
    h('header', { class: 'cs-head' }, h('div', { class: 'cs-brand' }, h('i', null, '♠'), h('div', null, h('small', null, String(info.point.label || 'Casino')), S.titleEl)),
      h('div', { class: 'cs-chips' }, chipIco(26), chipsEl, h('small', null, 'jetons')), h('button', { class: 'cs-x', onclick: close }, G.ico('x'))),
    h('div', { class: 'cs-body' }, nav, S.stage));
  r.appendChild(h('div', { class: 'cs-back' }, S.el));
  G.uiStack = G.uiStack.filter((u) => u.id !== 'casino'); G.uiStack.push({ id: 'casino', onEscape: close });
  if (!games.length) { S.stage.appendChild(h('div', { class: 'cs-empty' }, 'Aucun jeu ouvert ici pour le moment.')); return; }
  const start = info.bj ? 'blackjack' : (info.hilo ? 'hilo' : games[0].id);
  open(games.some((g) => g.id === start) ? start : games[0].id);
}
function close() {
  if (!S) return;
  if (S.busy && (S.game === 'roulette' || S.game === 'wheel' || S.game === 'slots' || S.game === 'dice')) return;   // on laisse finir l'animation
  S = null;
  const r = document.getElementById('g-casino'); if (r) { G.clear(r); r.classList.add('hidden'); }
  G.uiStack = G.uiStack.filter((u) => u.id !== 'casino');
  G.post('casino.close', {});
}
G.on('casino.open', (d) => build(d));
G.on('casino.res', (r) => {
  if (!S) return;
  clearTimeout(S.busyT);
  if (!r.ok && r.msg) { S.busy = false; toast(r.msg, 'bad'); }
  if (S.view && r.game === (S.game === 'cashier' ? 'cashier' : S.game)) { if (S.view.res(r) === false) return; }
  else S.busy = false;
  if (r.chips != null && !r.ok) setChips(r.chips);
});
G.on('casino.close', () => { if (S) { S.busy = false; close(); } });
})();
