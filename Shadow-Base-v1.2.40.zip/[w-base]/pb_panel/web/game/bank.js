/* Banque : fenêtre dans la DA du serveur (web/game/daview.js) : pages, cartes, formulaires. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let cur = null;
const host = () => document.getElementById('g-bank') || (function () { const e = h('div', { id: 'g-bank', class: 'hidden' }); G.root.appendChild(e); return e; })();
G.on('bank.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = G.daView({ frame: d.frame, page: d.page, onClose: () => G.post('bank.close', {}), onPage: (p) => G.post('bank.page', { page: p }), onAct: (n, pl, p) => G.post('bank.act', { name: n, payload: pl, page: p }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'bank'); G.uiStack.push({ id: 'bank', onEscape: () => G.post('bank.close', {}) });
});
G.on('bank.page', (d) => { if (cur) cur.set(d); });
G.on('bank.result', (d) => { if (!cur) return; cur.set(d); cur.say(d.ok, d.msg); });
G.on('bank.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'bank'); });

G.preview.bank = function (box) {
  G.clear(box);
  const frame = { name: 'Camille Durand', brand: 'Fleeca — Legion Square', tone: '#6fb4ff', cash: 640, bank: 18250,
    nav: [{ id: 'home', label: 'Mon compte', icon: 'card', group: 'Banque' }, { id: 'ops', label: 'Dépôt / retrait', icon: 'coins', group: 'Banque' }, { id: 'transfer', label: 'Virement', icon: 'file', group: 'Banque' }, { id: 'history', label: 'Historique', icon: 'clock', group: 'Banque' }] };
  const page = { page: 'home', title: 'Mon compte', blocks: [
    { type: 'hero', title: 'Camille Durand', sub: 'Ton compte bancaire', tone: '#6fb4ff', chips: [['IBAN', 'PB48215093'], ['Solde', '18 250 $'], ['Espèces', '640 $']] },
    { type: 'cards', items: [{ title: 'Compte bancaire', value: '18 250 $', icon: 'card', tone: '#6fb4ff', sub: 'Disponible' }, { title: 'Argent liquide', value: '640 $', icon: 'coins', tone: '#7be0a4', sub: 'Sur toi' }, { title: 'Frais de virement', value: '1 %', icon: 'file', tone: '#ffb457', sub: 'Dépôt et retrait gratuits' }] },
    { type: 'table', title: 'Dernières opérations', columns: [{ k: 'at', label: 'Date' }, { k: 'kind', label: 'Opération' }, { k: 'amount', label: 'Montant' }], rows: [{ at: '14/10 18:02', kind: 'Dépôt', amount: '+500 $' }, { at: '14/10 17:40', kind: 'Virement reçu', amount: '+1 200 $' }] }] };
  box.appendChild(G.fitStage(G.daView({ frame, page, onPage: () => {}, onAct: () => {} }).el));
};
})();
