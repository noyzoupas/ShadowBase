/* Taximètre : petit afficheur en haut à droite pendant une course (chauffeur et passagers). Valeurs calculées par le serveur. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, hideT = null;
G.on('taxi.meter', (d) => {
  if (!el) { el = h('div', { id: 'g-taxi', class: 'hidden' }); G.root.appendChild(el); }
  clearTimeout(hideT);
  G.clear(el);
  el.classList.remove('hidden');
  el.classList.toggle('done', !d.on);
  el.appendChild(h('div', { class: 'tx-top' }, h('i', null, 'TAXI'), h('span', null, d.on ? 'Course en cours' : 'Course terminée')));
  el.appendChild(h('b', { class: 'tx-fare' }, (Number(d.fare) || 0).toLocaleString('fr-FR') + ' $'));
  el.appendChild(h('div', { class: 'tx-sub' }, h('span', null, String(d.km || 0).replace('.', ',') + ' km'), h('span', null, (d.mins || 0) + ' min'), d.driver ? h('span', null, d.driver) : null));
  if (!d.on) hideT = setTimeout(() => el.classList.add('hidden'), 8000);
});
G.preview.taxi = function (box) { G.clear(box); const s = h('div', { class: 'gstage' }); box.appendChild(s); const prev = G.root; G.root = s; el = null; G.handlers['taxi.meter'].forEach((fn) => fn({ on: true, fare: 386, km: 6.4, mins: 7, driver: 'Alex Martin' })); G.root = prev; el = null; };
})();
