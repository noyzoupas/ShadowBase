/* Guerre de territoire : tableau des scores en haut à gauche, compte à rebours local entre deux mises à jour du serveur. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let el = null, tick = null, endAt = 0;
function clock(box) {
  const s = Math.max(0, Math.round((endAt - Date.now()) / 1000));
  box.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
G.on('war.board', (d) => {
  if (!el) { el = h('div', { id: 'g-war', class: 'hidden' }); G.root.appendChild(el); }
  clearInterval(tick);
  G.clear(el);
  if (!d || !d.on) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  endAt = Date.now() + (Number(d.left) || 0) * 1000;
  const t = h('b', { class: 'wr-clock' });
  el.appendChild(h('div', { class: 'wr-top' }, h('i', null, 'GUERRE'), h('span', null, d.zone || ''), t));
  clock(t);
  tick = setInterval(() => clock(t), 1000);
  const rows = (d.rows || []).slice(0, 6);
  const max = Math.max(1, ...rows.map((r) => Number(r.pts) || 0));
  if (!rows.length) el.appendChild(h('div', { class: 'wr-empty' }, 'Entrez dans la zone pour marquer.'));
  rows.forEach((r, i) => {
    const bar = h('div', { class: 'wr-bar' }, h('div', { style: 'width:' + Math.round((Number(r.pts) || 0) / max * 100) + '%;background:' + (r.color || '#e5384f') }));
    el.appendChild(h('div', { class: 'wr-row' + (i === 0 ? ' lead' : '') }, h('span', { class: 'wr-name' }, r.label || r.id), h('span', { class: 'wr-pts' }, String(r.pts || 0)), bar,
      r.kills ? h('small', null, r.kills + ' élim.') : null));
  });
});
G.preview.war = function (box) { G.clear(box); const s = h('div', { class: 'gstage' }); box.appendChild(s); const prev = G.root; G.root = s; el = null;
  G.handlers['war.board'].forEach((fn) => fn({ on: true, zone: 'Mirror Park', left: 1260, rows: [{ id: 'ballas', label: 'Ballas', color: '#a64dff', pts: 86, kills: 4 }, { id: 'fam', label: 'Families', color: '#2fbf4a', pts: 61, kills: 2 }, { id: 'vagos', label: 'Vagos', color: '#f2c200', pts: 23 }] }));
  G.root = prev; el = null; };
})();
