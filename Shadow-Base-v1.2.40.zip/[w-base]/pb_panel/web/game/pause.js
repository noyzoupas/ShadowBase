/* Menu Échap : accueil, personnage (filmé par le jeu), parcours, carte (carte du jeu ou survol 3D), réglages du jeu.
   Toutes les données viennent du serveur ; les réglages sont envoyés au jeu (clé + valeur) qui les valide. Texte inséré avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;

const TABS = [['home', 'Accueil', 'home'], ['character', 'Personnage', 'user'], ['path', 'Parcours', 'clock'], ['map', 'Carte', 'gps'], ['settings', 'Réglages du jeu', 'sliders']];
const DEFAULTS = { foot_view: 'keep', veh_view: 'keep', no_cinematic: false, radio_start: 'keep', filter: 'none', filter_str: 60, lod: 100, shadows: 'normal', radio_vol: 100, call_vol: 100 };
const OPTS = {
  foot_view: [['keep', 'Ne pas changer'], ['near', 'Proche'], ['mid', 'Moyenne'], ['far', 'Loin'], ['first', 'Première personne']],
  veh_view: [['keep', 'Ne pas changer'], ['far', 'Loin'], ['mid', 'Moyenne'], ['near', 'Proche'], ['first', 'Première personne']],
  radio_start: [['keep', 'Ne pas changer'], ['off', 'Éteinte'], ['rock', 'Rock'], ['pop', 'Pop'], ['hiphop', 'Hip-hop'], ['punk', 'Punk'], ['talk', 'Parlée'], ['chill', 'Country']],
  filter: [['none', 'Aucun'], ['cinema', 'Cinéma'], ['warm', 'Chaud'], ['cool', 'Froid'], ['vivid', 'Vif']],
  shadows: [['normal', 'Normales'], ['sharp', 'Précises'], ['reduced', 'Réduites (plus fluide)']],
};

let host = null, st = null, tab = 'home', fly = false, sel = 'ped', live = true;
const root = () => host || (host = (function () { const e = h('div', { id: 'g-pause', class: 'hidden' }); G.root.appendChild(e); return e; })());
const send = (n, d) => { if (live) G.post(n, d || {}); };
const dur = (a, b) => { const s = Math.max(0, (b || Math.floor(Date.now() / 1000)) - a), d = Math.floor(s / 86400); return d >= 1 ? d + ' j' : Math.max(1, Math.floor(s / 3600)) + ' h'; };
const dt = (t) => { try { return new Date(t * 1000).toLocaleDateString('fr-FR'); } catch (e) { return ''; } };

function card(title, ...kids) { return h('section', { class: 'pa-card' }, title ? h('h3', null, title) : null, ...kids); }
function kv(k, v) { return h('div', { class: 'pa-kv' }, h('span', null, k), h('b', null, v == null || v === '' ? '—' : String(v))); }

function pHome(d) {
  const s = d.stats || {};
  const out = h('div', { class: 'pa-home' },
    h('div', { class: 'pa-hello' }, h('h1', null, d.welcome || ('Bienvenue, ' + d.name + '.')), h('p', null, 'ID ' + d.id + ' · ' + (s.online || 1) + ' joueur' + ((s.online || 1) > 1 ? 's' : '') + ' en ligne')),
    h('div', { class: 'pa-chips' }, [['Espèces', s.cash], ['Banque', s.bank], ['Emploi', s.job], s.gang ? ['Organisation', s.gang] : null, s.coins ? ['Boutique', s.coins] : null].filter(Boolean).map((c) => h('div', { class: 'pa-chip' }, h('small', null, c[0]), h('b', null, c[1])))),
    h('div', { class: 'pa-row' }, h('button', { type: 'button', class: 'pa-btn', onclick: () => send('pause.shop') }, ico('star'), 'Boutique du serveur')));
  const ann = d.announcements || [];
  out.appendChild(card('Annonces', ann.length ? h('div', { class: 'pa-ann' }, ann.map((a) => h('article', null, h('b', null, a.title), a.date ? h('small', null, a.date) : null, a.text ? h('p', null, a.text) : null))) : h('p', { class: 'pa-mu' }, 'Aucune annonce pour le moment.')));
  return out;
}

function pChar(d) {
  const c = d.char || {}, i = c.identity || {};
  const left = h('div', { class: 'pa-col' },
    card((i.firstname || '') + ' ' + (i.lastname || ''), kv('Naissance', i.dob), kv('Nationalité', i.nationality), kv('Taille', i.height ? i.height + ' cm' : ''), kv('Emploi', c.job ? c.job.label + ' · ' + c.job.grade : 'Sans emploi'),
      kv('Organisation', c.gang ? c.gang.label : 'Aucune'), kv('Espèces', c.cash), kv('Banque', c.bank)));
  const list = h('div', { class: 'pa-list' });
  const pick = (mode, model, btn) => { sel = mode === 'ped' ? 'ped' : model; list.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn)); send('pause.studio', { mode, model }); };
  const b0 = h('button', { type: 'button', class: 'pa-li on', onclick: () => pick('ped', null, b0) }, ico('user'), h('span', null, 'Moi'));
  list.appendChild(b0);
  (c.cars || []).forEach((v) => { const b = h('button', { type: 'button', class: 'pa-li', onclick: () => pick('veh', v.model, b) }, ico('car'), h('span', null, v.label), h('small', null, v.plate)); list.appendChild(b); });
  const right = h('div', { class: 'pa-col' }, card('Filmer', list, h('p', { class: 'pa-mu' }, "Glisse dans la zone du milieu pour tourner autour. Le véhicule est une copie visible de toi seul, posée devant toi.")));
  const stage = h('div', { class: 'pa-stage' }, h('span', null, 'Glisse pour tourner'));
  let down = false, lx = 0;
  stage.addEventListener('mousedown', (e) => { down = true; lx = e.clientX; });
  window.addEventListener('mouseup', () => { down = false; });
  stage.addEventListener('mousemove', (e) => { if (!down) return; const dx = e.clientX - lx; lx = e.clientX; if (dx) send('pause.rot', { dx }); });
  setTimeout(() => send('pause.studio', { mode: 'ped' }), 60);
  return h('div', { class: 'pa-three' }, left, stage, right);
}

function pPath(d) {
  const rows = d.path || [];
  if (!rows.length) return card('Parcours', h('p', { class: 'pa-mu' }, "Rien à afficher : tes prochains emplois et organisations apparaîtront ici."));
  return card('Parcours', h('ol', { class: 'pa-tl' }, rows.map((r) => h('li', { class: r.current ? 'on' : '' },
    h('i', null, ico(r.kind === 'gang' ? 'users' : 'briefcase')),
    h('div', null, h('b', null, r.label), h('small', null, (r.grade ? r.grade + ' · ' : '') + (r.kind === 'gang' ? 'Organisation' : 'Emploi'))),
    h('span', null, r.current ? 'Depuis ' + dt(r.from) + ' (' + dur(r.from) + ')' : dt(r.from) + ' → ' + dt(r.to) + ' (' + dur(r.from, r.to) + ')')))));
}

function pMap(d, rerender) {
  const places = d.places || [];
  const mk = (t, i, fn, cls) => h('button', { type: 'button', class: 'pa-btn' + (cls ? ' ' + cls : ''), onclick: fn }, ico(i), t);
  const top = h('div', { class: 'pa-row' },
    mk('Carte 2D du jeu', 'gps', () => send('pause.map2d')), mk('Effacer le GPS', 'x', () => send('pause.gpsoff'), 'ghost'));
  const list = h('div', { class: 'pa-places' });
  if (!places.length) list.appendChild(h('p', { class: 'pa-mu' }, 'Aucun lieu enregistré. Ajoute celui où tu te trouves.'));
  places.forEach((p) => list.appendChild(h('div', { class: 'pa-place' }, ico('gps'), h('b', null, p.label), p.shared ? h('small', null, 'Serveur') : null,
    h('span', { class: 'pa-acts' },
      h('button', { type: 'button', class: 'pa-mini', onclick: () => send('pause.gps', { id: p.id }) }, 'GPS'),
      h('button', { type: 'button', class: 'pa-mini', onclick: () => { fly = p; send('pause.fly', { x: p.x, y: p.y, z: p.z }); rerender(); } }, 'Survoler'),
      p.shared ? null : h('button', { type: 'button', class: 'pa-mini bad', onclick: () => send('pause.placedel', { id: p.id }) }, 'Supprimer')))));
  const inp = h('input', { type: 'text', class: 'pa-in', maxlength: '40', placeholder: 'Nom du lieu (ex. Chez moi)' });
  inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') add(); });
  const add = () => { const v = inp.value.trim(); if (v.length < 2) return; send('pause.placeadd', { label: v }); inp.value = ''; };
  return h('div', { class: 'pa-col wide' }, card('Carte', top, h('p', { class: 'pa-mu' }, "La carte 2D ouvre celle du jeu avec tes lieux et ton GPS. Le survol 3D fait voler la caméra jusqu'au lieu choisi.")),
    card('Lieux enregistrés', list, h('div', { class: 'pa-row' }, inp, mk('Enregistrer ici', 'plus', add))));
}

function ctl(label, k, kind, val, hint) {
  const wrap = h('div', { class: 'pa-ctl' }, h('label', null, label, hint ? h('small', null, hint) : null));
  const apply = (v) => { st.settings[k] = v; send('pause.set', { k, v }); };
  if (kind === 'select') {
    const s = h('select', { class: 'pa-in' }, OPTS[k].map((o) => { const e = h('option', { value: o[0] }, o[1]); if (o[0] === val) e.selected = true; return e; }));
    s.addEventListener('change', () => apply(s.value)); wrap.appendChild(s);
  } else if (kind === 'toggle') {
    const b = h('button', { type: 'button', class: 'pa-tg' + (val ? ' on' : ''), role: 'switch', 'aria-checked': String(!!val) }, h('i'));
    b.addEventListener('click', () => { const v = !b.classList.contains('on'); b.classList.toggle('on', v); b.setAttribute('aria-checked', String(v)); apply(v); }); wrap.appendChild(b);
  } else {
    const r = h('input', { type: 'range', min: kind[0], max: kind[1], step: '5', value: String(val) }), o = h('output', null, val + ' %');
    r.addEventListener('input', () => { o.textContent = r.value + ' %'; }); r.addEventListener('change', () => apply(Number(r.value)));
    wrap.appendChild(r); wrap.appendChild(o);
  }
  return wrap;
}
function pSet(d) {
  const s = st.settings = Object.assign({}, DEFAULTS, st.settings || {});
  return h('div', { class: 'pa-col wide' },
    card('Caméras', ctl('Vue à pied', 'foot_view', 'select', s.foot_view), ctl('Vue en véhicule (à l\'entrée)', 'veh_view', 'select', s.veh_view), ctl('Bloquer la caméra cinématique', 'no_cinematic', 'toggle', s.no_cinematic)),
    card('Radio et voix', ctl('Station au démarrage du véhicule', 'radio_start', 'select', s.radio_start), ctl('Volume de la radio (voix)', 'radio_vol', [0, 100], s.radio_vol, 'pma-voice'), ctl('Volume des appels', 'call_vol', [0, 100], s.call_vol, 'pma-voice')),
    card('Image', ctl('Filtre', 'filter', 'select', s.filter), ctl('Intensité du filtre', 'filter_str', [0, 100], s.filter_str), ctl('Ombres', 'shadows', 'select', s.shadows), ctl("Distance d'affichage", 'lod', [50, 200], s.lod, '100 % = normal')),
    card('Touches', h('div', { class: 'pa-keys' }, (d.keys || []).map((k) => h('div', { class: 'pa-kv' }, h('span', null, k.label), h('kbd', null, String(k.key))))),
      h('p', { class: 'pa-mu' }, "Pour changer une touche : Échap du jeu (touche P) > Paramètres > Raccourcis clavier > FiveM. Une ressource ne peut pas la modifier à ta place.")),
    h('div', { class: 'pa-row' }, h('button', { type: 'button', class: 'pa-btn ghost', onclick: () => { send('pause.setreset'); st.settings = Object.assign({}, DEFAULTS); draw(); } }, ico('undo'), 'Réinitialiser les réglages')));
}

function draw() {
  const r = root();
  G.clear(r);
  if (!st) return;
  const stat = r.classList.contains('pa-static') ? ' pa-static' : '';
  const d = st.data;
  const vis = TABS.filter((t) => t[0] === 'home' || t[0] === 'settings' ? true : (d.tabs || {})[t[0]] !== false);
  if (!vis.some((t) => t[0] === tab)) tab = 'home';
  if (fly) {
    r.className = 'fly' + stat;
    r.appendChild(h('div', { class: 'pa-flybar' }, ico('gps'), h('b', null, fly.label), h('button', { type: 'button', class: 'pa-mini', onclick: () => send('pause.gps', { id: fly.id }) }, 'GPS'),
      h('button', { type: 'button', class: 'pa-btn', onclick: () => { fly = false; send('pause.fly', { stop: true }); draw(); } }, 'Retour au menu')));
    return;
  }
  r.className = 'tab-' + tab + stat;
  const nav = h('nav', { class: 'pa-nav' }, h('div', { class: 'pa-brand' }, G.brandName() || ' '),
    vis.map((t) => h('button', { type: 'button', class: 'pa-n' + (t[0] === tab ? ' on' : ''), onclick: () => { if (tab === t[0]) return; tab = t[0]; send('pause.tab', { tab }); draw(); } }, ico(t[2]), t[1])),
    h('button', { type: 'button', class: 'pa-n out', onclick: () => send('pause.close') }, ico('x'), 'Fermer'));
  const view = tab === 'character' ? pChar(d) : tab === 'path' ? pPath(d) : tab === 'map' ? pMap(d, draw) : tab === 'settings' ? pSet(d) : pHome(d);
  r.appendChild(nav); r.appendChild(h('main', { class: 'pa-main' }, view));
}

function open(d) {
  st = { data: d.data || {}, settings: Object.assign({}, DEFAULTS, d.settings || {}) };
  tab = 'home'; fly = false; live = true;
  root().classList.remove('hidden'); draw();
  G.uiStack = G.uiStack.filter((u) => u.id !== 'pause');
  G.uiStack.push({ id: 'pause', onEscape: () => { if (fly) { fly = false; send('pause.fly', { stop: true }); draw(); } else send('pause.close'); } });
}
G.on('pause.open', open);
G.on('pause.data', (d) => { if (st && d.data) { st.data = d.data; draw(); } });
G.on('pause.places', (d) => { if (st) { st.data.places = d.places || []; if (tab === 'map' && !fly) draw(); } });
G.on('pause.settings', (d) => { if (st) { st.settings = Object.assign({}, DEFAULTS, d.settings || {}); if (tab === 'settings') draw(); } });
G.on('pause.close', () => { fly = false; st = null; if (host) { G.clear(host); host.classList.add('hidden'); } G.uiStack = G.uiStack.filter((u) => u.id !== 'pause'); });

G.preview.pause = function (box, cfg, blk) {
  G.clear(box);
  const demo = { name: 'Camille Durand', id: 12, welcome: 'Bienvenue, Camille Durand.', tabs: {}, stats: { cash: '640 $', bank: '18 250 $', job: 'Police · Officier', gang: 'Ballas', online: 42 },
    announcements: [{ title: 'Mise à jour de la semaine', text: 'Nouveaux braquages et territoires. Passe voir le menu F7.', date: '14 oct.' }, { title: 'Événement samedi', text: 'Course de rue au port à 21 h.', date: '12 oct.' }],
    char: { identity: { firstname: 'Camille', lastname: 'Durand', dob: '1994-03-02', nationality: 'Française', height: 175 }, job: { label: 'Police', grade: 'Officier' }, gang: { label: 'Ballas' }, cars: [{ label: 'Sultan', model: 'sultan', plate: 'PB 1111' }], cash: '640 $', bank: '18 250 $' },
    path: [{ kind: 'job', label: 'Police', grade: 'Officier', from: 1760000000, current: true }, { kind: 'job', label: 'Garage', grade: 'Employé', from: 1750000000, to: 1760000000 }],
    places: [{ id: 'p1', label: 'Chez moi', x: 0, y: 0, z: 0 }, { id: 's1', label: 'Commissariat', x: 0, y: 0, z: 0, shared: true }], keys: [{ label: 'Inventaire', key: 'I' }, { label: 'Téléphone', key: 'F1' }] };
  const prevLive = live, prevSt = st, prevHost = host, prevTab = tab, prevFly = fly;
  live = false; st = { data: demo, settings: Object.assign({}, DEFAULTS) }; fly = false;
  tab = (blk && blk.tab) || 'home';
  const mine = h('div', { id: 'g-pause', class: 'pa-static' });
  host = mine; draw();
  host = prevHost; st = prevSt; tab = prevTab; fly = prevFly; live = prevLive;
  box.appendChild(G.fitStage(h('div', { class: 'pa-scene', style: { width: '1280px', height: '720px' } }, mine), 1280, 720));
};
})();
