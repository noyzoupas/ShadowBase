/* Carte rapide (touche M, client/minimap.lua) : panneau collé à la mini-carte agrandie du jeu, en bas à gauche.
   Pas de souris : le jeu envoie la sélection (↑ ↓), le zoom et le GPS. Textes du serveur insérés avec textContent. */
(function () {
'use strict';
const G = window.PBGame, h = G.h, ico = G.ico;
let cur = null;
const host = () => document.getElementById('g-qmap') || (function () { const e = h('div', { id: 'g-qmap', class: 'hidden' }); G.root.appendChild(e); return e; })();

function qmapView(o) {
  o = o || {};
  const list = h('div', { class: 'qm-list' }), zoomEl = h('div', { class: 'qm-zoom' }), wp = h('div', { class: 'qm-wp hidden' });
  const el = h('div', { class: 'qm' },
    h('header', { class: 'qm-h' }, h('div', null, h('small', null, 'Carte rapide'), h('b', null, 'Destinations')), zoomEl),
    wp, list,
    h('footer', { class: 'qm-k' }, [['↑↓', 'Choisir'], ['Entrée', 'GPS'], ['←→', 'Zoom'], ['Suppr', 'Effacer'], ['Échap', 'Carte complète'], ['M', 'Fermer']].map((k) => h('span', null, h('kbd', null, k[0]), k[1]))));
  let rows = [], sel = 1;
  function place(r) {
    if (!r) return;
    el.style.left = 'calc(' + ((r.l + r.w) * 100).toFixed(2) + 'vw + 12px)';
    el.style.bottom = ((1 - r.b) * 100).toFixed(2) + 'vh';
    el.style.height = (r.h * 100).toFixed(2) + 'vh';
  }
  function setZoom(z, n) { G.clear(zoomEl); for (let i = 1; i <= (n || 4); i++) zoomEl.appendChild(h('i', { class: i <= z ? 'on' : '' })); }
  function setList(sections) {
    G.clear(list); rows = [];
    if (!sections || !sections.length) { list.appendChild(h('div', { class: 'qm-empty' }, 'Chargement des destinations…')); return; }
    sections.forEach((s) => {
      list.appendChild(h('div', { class: 'qm-sec' }, String(s.title || '')));
      (s.items || []).forEach((it) => {
        const r = h('div', { class: 'qm-r' }, h('span', { class: 'qm-i' }, ico(it.icon || 'pin')), h('div', null, h('b', null, String(it.label || '')), it.sub ? h('small', null, String(it.sub)) : null), h('em', null, String(it.right || '')));
        rows.push(r); list.appendChild(r);
      });
    });
    if (!rows.length) list.appendChild(h('div', { class: 'qm-empty' }, 'Aucune destination pour le moment.'));
    select(1);
  }
  function select(i) {
    sel = i;
    rows.forEach((r, k) => r.classList.toggle('on', k === i - 1));
    const r = rows[i - 1];
    if (r && r.scrollIntoView) r.scrollIntoView({ block: 'nearest' });
  }
  function setWp(on, label) { wp.classList.toggle('hidden', !on); G.clear(wp); if (on) wp.append(ico('pin'), h('span', null, label ? 'GPS : ' + label : 'GPS actif'), h('kbd', null, 'Suppr')); }
  place(o.rect); setZoom(o.zoom || 1, o.zooms); setList(o.sections); setWp(!!o.wp, '');
  return { el, setList, select, setZoom, setWp };
}
G.qmapView = qmapView;

G.on('qmap.open', (d) => { const r = host(); G.clear(r); r.classList.remove('hidden'); cur = qmapView(d); r.appendChild(cur.el); });
G.on('qmap.list', (d) => { if (cur) cur.setList(d.sections); });
G.on('qmap.sel', (d) => { if (cur) cur.select(Number(d.i) || 1); });
G.on('qmap.zoom', (d) => { if (cur) cur.setZoom(Number(d.zoom) || 1); });
G.on('qmap.wp', (d) => { if (cur) cur.setWp(!!d.on, d.label); });
G.on('qmap.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; });

G.qmapSample = () => ({ rect: { l: 0.0135, b: 0.9865, w: 0.2278, h: 0.3877 }, zoom: 2, zooms: 4, wp: true, sections: [
  { title: 'À moi', items: [{ label: 'Sultan (PB 4821)', sub: 'Position en direct', right: '120 m', icon: 'car' }, { label: 'Appartement Tinsel Towers', sub: 'Mon logement', right: '1,8 km', icon: 'home' }, { label: 'LSPD', sub: 'Mon entreprise', right: '2,4 km', icon: 'briefcase' }] },
  { title: 'Mes lieux', items: [{ label: 'Spot de pêche', sub: 'Lieu enregistré', right: '6,1 km', icon: 'pin' }] },
  { title: 'Au plus près', items: [{ label: 'Distributeur', sub: 'Fleeca Legion', right: '90 m', icon: 'card' }, { label: 'Supérette', sub: '24/7 Strawberry', right: '450 m', icon: 'cart' }, { label: 'Station-service', sub: 'Globe Oil', right: '780 m', icon: 'drop' },
    { label: 'Garage public', sub: 'Legion Square', right: '1,1 km', icon: 'car' }, { label: 'Hôpital', sub: 'Pillbox Hill', right: '1,9 km', icon: 'heart' }] }] });
G.preview.qmap = function (box) {
  G.clear(box);
  const s = h('div', { class: 'gstage qm-stage' }, h('div', { class: 'qm-fake' }));
  box.appendChild(s);
  const v = qmapView(G.qmapSample());
  v.el.classList.add('qm-prev');
  s.appendChild(v.el);
};
})();
