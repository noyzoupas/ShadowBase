/* Logements : fenêtre dans la DA du serveur (web/game/daview.js). */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
let cur = null;
const host = () => document.getElementById('g-housing') || (function () { const e = h('div', { id: 'g-housing', class: 'hidden' }); G.root.appendChild(e); return e; })();
G.on('housing.open', (d) => {
  const r = host(); G.clear(r); r.classList.remove('hidden');
  cur = G.daView({ frame: d.frame, page: d.page, onClose: () => G.post('housing.close', {}), onPage: (p) => G.post('housing.page', { page: p }), onAct: (n, pl, p) => G.post('housing.act', { name: n, payload: pl, page: p }) });
  r.appendChild(cur.el);
  G.uiStack = G.uiStack.filter((u) => u.id !== 'housing'); G.uiStack.push({ id: 'housing', onEscape: () => G.post('housing.close', {}) });
});
G.on('housing.page', (d) => { if (cur) cur.set(d); });
G.on('housing.result', (d) => { if (!cur) return; cur.set(d); cur.say(d.ok, d.msg); });
G.on('housing.close', () => { const r = host(); G.clear(r); r.classList.add('hidden'); cur = null; G.uiStack = G.uiStack.filter((u) => u.id !== 'housing'); });

G.preview.housing = function (box) {
  G.clear(box);
  const frame = { name: 'Camille Durand', brand: 'Appartement — Tinsel Towers', tone: '#dfe2e7', cash: 640, bank: 18250,
    nav: [{ id: 'home', label: 'Logement', icon: 'home', group: 'Logement' }, { id: 'access', label: 'Accès', icon: 'lock', group: 'Logement' }] };
  const page = { page: 'home', title: 'Appartement — Tinsel Towers', blocks: [
    { type: 'cards', items: [{ title: 'Statut', value: 'Chez toi', icon: 'home', tone: '#7be0a4', sub: 'Achat' }, { title: 'Prix', value: G.money(85000), icon: 'card', tone: '#6fb4ff', sub: '' }] },
    { type: 'actions', items: [{ act: 'stash', label: 'Ouvrir le coffre' }, { act: 'lock', label: 'Déverrouiller la porte' }, { act: 'leave', label: 'Vendre (' + G.money(59500) + ')', danger: true }] },
    { type: 'table', title: 'Informations', columns: [{ k: 'k', label: '' }, { k: 'v', label: '' }], rows: [{ k: 'Type', v: 'À vendre' }, { k: 'Occupant', v: 'Toi' }, { k: 'Porte', v: 'Verrouillée' }] }] };
  box.appendChild(G.fitStage(G.daView({ frame, page, onPage: () => {}, onAct: () => {} }).el));
};
})();
