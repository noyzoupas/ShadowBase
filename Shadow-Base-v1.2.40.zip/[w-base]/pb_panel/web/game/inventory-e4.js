/* Inventaire « E4 » (maquette Figma) : sac à gauche, équipements et raccourcis au centre, coffre ou sol à droite, zone de don en bas à droite.
   Scène fixe de 1920×1080 mise à l'échelle ; les cases vides sont dessinées dans le fond, le HTML pose le contenu par-dessus.
   Mêmes données et mêmes actions que l'inventaire classique (inventory.js). Le texte des objets passe par textContent uniquement. */
(function () {
'use strict';
const G = window.PBGame, h = G.h;
const QUICK = 5, COLS = 5, ROWS = 6, PX = 96, PY = 93;
const SAFE_IMG = /^(img\/[a-z]+\/[\w-]+\.[a-z]{3,4}|https:\/\/[\w.-]+\/[\w.%\/-]+)$/i;
const EQ_L = [['hat', 'Chapeau'], ['mask', 'Masque'], ['glasses', 'Lunettes'], ['ears', 'Oreilles'], ['chain', 'Collier'], ['bag', 'Sac']];
const EQ_R = [['top', 'Veste'], ['shirt', 'T-shirt'], ['vest', 'Gilet'], ['gloves', 'Gants'], ['legs', 'Pantalon'], ['shoes', 'Chaussures']];
// Icônes des équipements : même rendu que le chapeau de la maquette (forme à peine plus claire que la case, un trait sombre, bords doux)
const icn = (shape, lines) => '<g fill="rgba(255,255,255,.05)" stroke="rgba(255,255,255,.025)" stroke-width="2">' + shape + '</g><g fill="none" stroke="rgba(0,0,0,.6)" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">' + (lines || '') + '</g>';
const ICON = {
  mask: icn('<path d="M15 17q21-11 42 0l-2 15q-19 13-38 0z"/>', '<path d="M21 22q15-5 30 0M21 28q15-5 30 0M15 19q-6 2-4 8t7 5M57 19q6 2 4 8t-7 5"/>'),
  glasses: icn('<path d="M11 18h21v4l-2 7q-1 4-5 4h-8q-4 0-5-4l-1-7zM40 18h21v4l-1 7q-1 4-5 4h-8q-4 0-5-4l-2-7z"/>', '<path d="M32 21q4-3 8 0M11 18h50"/>'),
  ears: icn('<path fill-rule="evenodd" d="M27 15a11 11 0 1 1 0 22a11 11 0 1 1 0-22zm0 5a6 6 0 1 0 0 12a6 6 0 1 0 0-12zM45 15a11 11 0 1 1 0 22a11 11 0 1 1 0-22zm0 5a6 6 0 1 0 0 12a6 6 0 1 0 0-12z"/>', '<path d="M27 9v6M45 9v6"/>'),
  chain: icn('<path d="M16 7q1 19 20 24q19-5 20-24h-4q-2 15-16 19q-14-4-16-19z"/><path d="M36 30l7 7l-7 9l-7-9z"/>', '<path d="M18 9q3 16 18 20q15-4 18-20"/>'),
  bag: icn('<path d="M24 12q0-7 12-7t12 7v1q8 2 8 11v16q0 4-4 4h-32q-4 0-4-4v-16q0-9 8-11z"/>', '<path d="M29 12q0-3 7-3t7 3M24 27h24v8h-24z"/>'),
  top: icn('<path d="M27 5l9 7l9-7l13 5l10 16l-8 5l-5-7v25h-38v-25l-5 7l-8-5l10-16z"/>', '<path d="M36 12v32M29 30h4M39 30h4"/>'),
  shirt: icn('<path d="M26 6q4 6 10 6t10-6l15 6l6 12l-9 4l-4-5v22h-36v-22l-4 5l-9-4l6-12z"/>', '<path d="M27 7q3 8 9 8t9-8"/>'),
  vest: icn('<path d="M23 5h7q2 8 6 8t6-8h7q2 6 7 8v27q0 4-4 4h-32q-4 0-4-4v-27q5-2 7-8z"/>', '<path d="M22 24h11v8h-11zM39 24h11v8h-11zM36 13v31"/>'),
  gloves: icn('<path d="M26 45v-11l-8-9q-2-4 1-6t5 1l4 4v-16q0-3 3-3t3 3v-2q0-3 3-3t3 3v2q0-3 3-3t3 3v4q0-3 3-3t3 3v15q0 6-4 11v6z"/>', '<path d="M27 39h20M33 10v12M39 8v13M45 11v11"/>'),
  legs: icn('<path d="M23 5h26l4 39h-12l-5-26l-5 26h-12z"/>', '<path d="M23 10h26M36 10v8"/>'),
  shoes: icn('<path d="M9 22q0-6 5-5q6 1 10 6q7 2 12-3l3 3q9 6 21 8q6 1 6 7v5h-57z"/>', '<path d="M9 38h57M27 25l3 4M33 23l3 4"/>'),
};
const LOCK = '<svg viewBox="0 0 26 30"><path fill="#fff" d="M13 1a8 8 0 0 0-8 8v4H3a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V15a2 2 0 0 0-2-2h-2V9a8 8 0 0 0-8-8zm-5 12V9a5 5 0 0 1 10 0v4zm5 4a2.5 2.5 0 0 1 1.3 4.6V25h-2.6v-3.4A2.5 2.5 0 0 1 13 17z"/></svg>';
const svg = (inner, vb) => { const s = document.createElement('span'); s.innerHTML = '<svg viewBox="' + (vb || '0 0 72 48') + '">' + inner + '</svg>'; return s.firstChild; };   // icônes constantes ci-dessus uniquement
const KIC = { food: 'food', drink: 'drop', medical: 'heart', tool: 'engine', doc: 'id', weapon: 'crosshair', clothes: 'tag', clothing: 'tag', misc: 'cart' };   // icônes de Shadow Base si l'objet n'a pas d'image

// ---------- couleur : celle du serveur (Identité), des menus, une couleur choisie, ou le vert d'origine ----------
function parseColor(s) {
  if (typeof s !== 'string') return null;
  s = s.trim();
  let m = s.match(/^#([0-9a-f]{3})$/i);
  if (m) return m[1].split('').map((c) => parseInt(c + c, 16));
  m = s.match(/^#([0-9a-f]{6})([0-9a-f]{2})?$/i);
  if (m) return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16));
  m = s.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  if (m) return [m[1], m[2], m[3]].map((v) => Math.min(255, Number(v)));
  return null;
}
function hsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return [0, 0, l];
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
  const hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [hh * 60, s, l];
}
const BASE_H = 156.05;   // teinte du vert de la maquette (#00f895)
function themeOf(cfg) {
  const c = (cfg && cfg.inv) || {}, mode = c.color_mode || 'server';
  const col = mode === 'custom' ? c.color : mode === 'menus' ? (cfg.menus || {}).accent : mode === 'server' ? (cfg.brand || {}).color : null;
  const rgb = parseColor(col);
  if (!rgb) return { ac: '0,248,149', tint: 'none' };
  let [hh, s, l] = hsl(rgb[0], rgb[1], rgb[2]);
  l = Math.max(0.45, Math.min(0.72, l));   // toujours lisible sur le fond sombre
  const deg = ((hh - BASE_H) % 360 + 540) % 360 - 180;
  const ac = (() => {   // couleur d'accent recalculée (même teinte, luminosité lisible)
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = (t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    return [f(hh / 360 + 1 / 3), f(hh / 360), f(hh / 360 - 1 / 3)].map((v) => Math.round(v * 255)).join(',');
  })();
  if (Math.abs(deg) < 2 && s > 0.95) return { ac, tint: 'none' };
  return { ac, tint: 'hue-rotate(' + deg.toFixed(1) + 'deg) saturate(' + Math.max(0, s).toFixed(2) + ')' };
}

function pic(it, cls) {
  if (it && it.image && SAFE_IMG.test(it.image)) {
    const im = h('img', { class: cls, src: it.image, alt: '', draggable: false });
    im.onerror = () => { if (im.parentNode) im.parentNode.replaceChild(h('span', { class: 'e4-ph' }, G.ico(KIC[it.kind] || 'cart')), im); };
    return im;
  }
  return h('span', { class: 'e4-ph' }, G.ico(KIC[it && it.kind] || 'cart'));
}

function inventoryE4(opt) {
  opt = opt || {};
  let data = opt.data || { me: { slots: 0, items: [], weight: 0, maxw: 1, owner: 'p:x' }, near: [] };
  let cfg = opt.cfg || G.cfg || {}, sel = null, qty = '', menu = null, tip = null, drag = null, noClick = 0;
  const scroll = { l: 0, r: 0 };
  const ic = () => (cfg && cfg.inv) || {};

  const st = h('div', { class: 'e4-st' });
  const el = h('div', { class: 'e4' }, st);
  const bg = h('img', { class: 'e4-bg e4-tint', alt: '', draggable: false });
  const add = (x) => { st.appendChild(x); return x; };
  const img = (src, x, y, cls) => add(h('img', { class: 'e4-img' + (cls ? ' ' + cls : ''), src: 'img/inv/' + src, alt: '', draggable: false, style: { left: x + 'px', top: y + 'px' } }));
  add(bg);
  // titres en texte (les images d'origine étaient en anglais et le sous-titre débordait sur la jauge de poids)
  add(h('div', { class: 'e4-tt', style: { left: '72px', top: '180px' } }, 'Sac à dos'));
  add(h('div', { class: 'e4-sb', style: { left: '72px', top: '216px' } }, 'Ce que ton personnage porte sur lui'));
  add(h('div', { class: 'e4-tt', style: { left: '861px', top: '172px' } }, 'Équipement'));
  const wt = add(h('div', { class: 'e4-wt' }));
  img('bar.png', 72, 249, 'e4-bar');
  const fill = add(h('i', { class: 'e4-fill' }));
  const gl = add(h('div', { class: 'e4-g l' })), gr = add(h('div', { class: 'e4-g r' }));
  const rtrack = add(h('i', { class: 'e4-rtrack hidden' })), rthumb = add(h('i', { class: 'e4-rthumb hidden' }));
  const rt = add(h('div', { class: 'e4-rt' })), rs = add(h('div', { class: 'e4-rs' }));
  const promo = add(h('div', { class: 'e4-promo' }));
  const ped = add(h('div', { class: 'e4-ped' }, h('span', { class: 'e4-dh' }, 'Utiliser / enfiler')));
  img('drop.png', 1378, 827, 'e4-tint');
  const ppl = h('div', { class: 'e4-ppl' }), dh = h('span', { class: 'e4-dh' });
  const dz = add(h('div', { class: 'e4-dz' }, ppl, dh));
  if (opt.onClose) add(h('button', { type: 'button', class: 'e4-close', 'aria-label': 'Fermer', onclick: opt.onClose }, '×'));
  // ---------- style Nova (panel › Interface › Style des interfaces en jeu) : panneaux en verre, catégories flottantes, jauge par catégorie ----------
  const nvLogo = h('img', { class: 'nv-logo', alt: '', draggable: false });
  const nvCats = h('div', { class: 'nv-cats' }), nvCap = h('div', { class: 'nv-cap' }), nvLeg = h('div', { class: 'nv-leg' });
  [h('div', { class: 'nv-pan l' }), h('div', { class: 'nv-pan r' }), h('div', { class: 'nv-rail l' }), h('div', { class: 'nv-rail r' }), nvLogo, nvCats, nvCap, nvLeg].reverse().forEach((x) => st.insertBefore(x, st.firstChild.nextSibling));   // juste après le fond : derrière les cases
  let cat = '';
  // barre d'outils sous le sac : recherche, tri, coffre du véhicule, poids par catégorie
  let search = '';
  const sIn = h('input', { class: 'e4-search', type: 'text', placeholder: 'Rechercher un objet…', maxlength: 30 });
  sIn.addEventListener('input', () => { search = sIn.value.trim().toLowerCase(); drawLeft(); drawRight(); });
  sIn.addEventListener('keydown', (e) => e.stopPropagation());
  const wPop = h('div', { class: 'e4-wpop hidden' });
  const tools = add(h('div', { class: 'e4-tools' }, sIn,
    h('button', { type: 'button', class: 'e4-tb', title: 'Ranger le sac par catégorie (la barre de raccourcis ne bouge pas)', onclick: () => G.post('inv.sort', {}) }, 'Trier'),
    h('button', { type: 'button', class: 'e4-tb', title: 'Ouvrir le coffre du véhicule le plus proche, à côté du sac', onclick: () => G.post('inv.trunk', {}) }, 'Coffre'),
    h('button', { type: 'button', class: 'e4-tb', title: 'Poids par catégorie', onclick: () => { wPop.classList.toggle('hidden'); drawWeights(); } }, 'Poids')));
  add(wPop);
  const CAT = { weapon: 'Armes', food: 'Nourriture', drink: 'Boissons', medical: 'Soins', tool: 'Outils', doc: 'Papiers', clothes: 'Vêtements', clothing: 'Vêtements', misc: 'Divers' };
  function drawWeights() {
    if (wPop.classList.contains('hidden')) return;
    const by = {};
    me().items.forEach((i) => { const k = CAT[i.kind] || 'Divers'; by[k] = (by[k] || 0) + (i.weight || 0) * i.qty; });
    G.clear(wPop);
    const keys = Object.keys(by).sort((a, b) => by[b] - by[a]);
    if (!keys.length) wPop.appendChild(h('span', null, 'Sac vide.'));
    keys.forEach((k) => wPop.appendChild(h('div', { class: 'e4-wl' }, h('span', null, k), h('b', null, (by[k] / 1000).toFixed(2) + ' kg'))));
  }
  const catOf = (it) => CAT[it && it.kind] || 'Divers';
  const hit = (it) => (!cat || (it && catOf(it) === cat)) && (!search || (it && (String(it.label || '').toLowerCase().includes(search) || String(it.item || '').toLowerCase().includes(search))));
  // Nova : pastilles de catégories (filtre) et jauge de poids découpée par catégorie
  const NV_ORDER = ['Armes', 'Nourriture', 'Boissons', 'Soins', 'Outils', 'Papiers', 'Vêtements', 'Divers'];
  const NV_IC = { Armes: 'gun', Nourriture: 'food', Boissons: 'drop', Soins: 'heart', Outils: 'wrench', Papiers: 'id', 'Vêtements': 'hanger', Divers: 'box' };
  function drawNova() {
    if (!el.classList.contains('nova')) return;
    const m = me(), by = {};
    m.items.forEach((i) => { const k = catOf(i); by[k] = (by[k] || 0) + (i.weight || 0) * i.qty; });
    const present = NV_ORDER.filter((k) => by[k] > 0);
    if (cat && present.indexOf(cat) < 0) cat = '';
    G.clear(nvCats);
    const pill = (k, label, icon) => h('button', { type: 'button', class: 'nv-cat' + (cat === k ? ' on' : ''), onclick: () => { cat = cat === k ? '' : k; drawLeft(); drawRight(); } }, icon ? G.ico(icon) : null, label);
    nvCats.appendChild(pill('', 'Tout'));
    present.forEach((k) => nvCats.appendChild(pill(k, k, NV_IC[k])));
    const maxw = Math.max(1, m.maxw), r = m.weight / maxw;
    const rgb = r < 0.75 ? '255,255,255' : r < 0.9 ? '255,170,60' : '255,85,85';
    el.style.setProperty('--nv-w', 'rgb(' + rgb + ')');
    const keys = Object.keys(by).sort((a, b) => by[b] - by[a]);
    G.clear(nvCap); G.clear(nvLeg);
    keys.forEach((k, i) => {
      const o = Math.max(0.22, 1 - i * 0.2);
      nvCap.appendChild(h('i', { style: { width: (by[k] / maxw * 100).toFixed(2) + '%', background: 'rgba(' + rgb + ',' + o + ')' } }));
      if (i < 3) nvLeg.appendChild(h('span', null, h('b', { style: { background: 'rgba(' + rgb + ',' + o + ')' } }), k + ' ' + (by[k] / 1000).toFixed(1).replace('.', ',')));
    });
    const free = Math.max(0, m.maxw - m.weight) / 1000;
    nvLeg.appendChild(h('em', null, r >= 0.9 ? 'Presque plein · ' + free.toFixed(1).replace('.', ',') + ' kg' : r >= 0.75 ? 'Lourd · ' + free.toFixed(1).replace('.', ',') + ' kg libres' : free.toFixed(1).replace('.', ',') + ' kg libres'));
  }

  const cellsL = [], cellsR = [];
  for (let i = 0; i < COLS * ROWS; i++) {
    const x = (i % COLS) * PX + 'px', y = Math.floor(i / COLS) * PY + 'px';
    cellsL.push(gl.appendChild(h('div', { class: 'e4-c', style: { left: x, top: y } })));
    cellsR.push(gr.appendChild(h('div', { class: 'e4-c', style: { left: x, top: y } })));
  }
  const hot = [];
  for (let i = 0; i < QUICK; i++) hot.push(add(h('div', { class: 'e4-h', style: { left: (662 + i * 120) + 'px' } })));
  const eq = {};
  EQ_L.concat(EQ_R).forEach((d, i) => {
    const left = i < 6, k = i % 6;
    eq[d[0]] = add(h('div', { class: 'e4-q', 'data-eq': d[0], title: d[1], style: { left: (left ? 662 : 1153) + 'px', top: (265 + k * 97) + 'px' } }));
  });

  // ---------- données ----------
  const me = () => data.me || { slots: 0, items: [], owner: 'p:x', weight: 0, maxw: 1 };
  const other = () => data.other || null;
  const boxes = () => [data.me, data.other].filter(Boolean);
  const find = (owner, slot) => { const b = boxes().find((x) => x.owner === owner); return b && b.items.find((i) => i.slot === slot); };
  const amount = (it) => { const n = parseInt(qty, 10); return n > 0 ? Math.min(n, it.qty) : it.qty; };
  function firstFree(box, it) {
    const used = {}; box.items.forEach((i) => { used[i.slot] = i; });
    for (let s = QUICK + 1; s <= box.slots; s++) { const i = used[s]; if (i && i.item === it.item && i.qty < i.stack) return s; }
    for (let s = 1; s <= box.slots; s++) { const i = used[s]; if (i && i.item === it.item && i.qty < i.stack) return s; }
    const from = box.owner === me().owner ? QUICK + 1 : 1;
    for (let s = from; s <= box.slots; s++) if (!used[s]) return s;
    for (let s = 1; s <= box.slots; s++) if (!used[s]) return s;
    return null;
  }
  const rowsL = () => ROWS;   // le sac affiche toujours 30 cases (6 × 5) : pas de défilement, les places en plus se débloquent
  const rowsR = () => { const o = other(); return o ? Math.max(ROWS, Math.ceil(o.slots / COLS)) : ROWS; };
  const slotL = (i) => QUICK + scroll.l * COLS + i + 1;
  const slotR = (i) => scroll.r * COLS + i + 1;
  const wornLabel = (slot) => ((data.worn || {})[slot]);
  const wornItem = (slot) => { const lab = wornLabel(slot); return lab ? me().items.find((i) => i.cloth === slot && i.label === lab) : null; };
  const isWorn = (it) => !!(it && it.cloth && wornLabel(it.cloth) === it.label);

  // ---------- dessin ----------
  function paint(c, it, owner, slot, locked, none) {
    G.clear(c);
    if (none) { c.className = 'e4-c none'; c.setAttribute('data-owner', ''); c.setAttribute('data-slot', '0'); return; }   // au-delà de la capacité d'un coffre : case absente, pas un cadenas
    c.className = 'e4-c' + (it ? ' has' : '') + (locked ? ' lock' : '') + (it && sel && sel.owner === owner && sel.slot === slot ? ' on' : '');
    c.setAttribute('data-owner', owner || ''); c.setAttribute('data-slot', locked ? '0' : String(slot));
    if (locked) { c.innerHTML = LOCK; return; }   // constante
    if (!it) return;
    if (!hit(it)) c.classList.add('dim');
    c.appendChild(pic(it, 'e4-im'));
    if (it.qty > 1) c.appendChild(h('b', { class: 'e4-x' }, 'x' + it.qty));
    c.appendChild(h('span', { class: 'e4-n' }, it.label));
  }
  function drawLeft() {
    const m = me(), used = {};
    m.items.forEach((i) => { used[i.slot] = i; });
    scroll.l = Math.max(0, Math.min(scroll.l, rowsL() - ROWS));
    cellsL.forEach((c, i) => { const s = slotL(i); paint(c, used[s], m.owner, s, s > m.slots); });
    G.clear(wt);
    wt.appendChild(document.createTextNode((m.weight / 1000).toFixed(2) + '/'));
    wt.appendChild(h('i', null, (m.maxw / 1000).toFixed(2) + ' KG'));
    const pct = Math.min(1, m.weight / Math.max(1, m.maxw));
    fill.style.width = Math.round(471 * pct) + 'px';
    fill.classList.toggle('over', pct >= 0.95);
    drawWeights();
    drawNova();
  }
  function drawRight() {
    const o = other(), used = {};
    if (o) o.items.forEach((i) => { used[i.slot] = i; });
    scroll.r = Math.max(0, Math.min(scroll.r, rowsR() - ROWS));
    cellsR.forEach((c, i) => {
      const s = slotR(i);
      if (o) paint(c, used[s], o.owner, s, false, s > o.slots);
      else { paint(c, null, 'ground', s, false); if (ic().allow_drop === false) c.classList.add('dim'); }
    });
    rt.textContent = o ? (o.label || 'Coffre') : 'Au sol';
    G.clear(rs);
    if (o) { rs.appendChild(h('b', null, (o.weight / 1000).toFixed(2) + '/')); rs.appendChild(document.createTextNode((o.maxw / 1000).toFixed(2) + ' KG')); }
    else rs.textContent = ic().allow_drop === false ? 'Jeter des objets est désactivé sur ce serveur.' : 'Glisse un objet ici pour le poser par terre.';
    const tot = rowsR(), scrollable = tot > ROWS;
    rtrack.classList.toggle('hidden', !scrollable); rthumb.classList.toggle('hidden', !scrollable);
    if (scrollable) { const th = Math.max(40, Math.round(549 * ROWS / tot)); rthumb.style.height = th + 'px'; rthumb.style.top = (267 + Math.round((549 - th) * scroll.r / (tot - ROWS))) + 'px'; }
  }
  function drawHot() {
    const m = me();
    hot.forEach((c, i) => {
      const s = i + 1, it = m.items.find((x) => x.slot === s);
      G.clear(c);
      c.className = 'e4-h' + (it ? ' has' : '') + (it && sel && sel.owner === m.owner && sel.slot === s ? ' on' : '');
      c.setAttribute('data-owner', m.owner); c.setAttribute('data-slot', String(s));
      c.appendChild(h('span', { class: 'e4-k' }, String(s)));
      if (it) { c.appendChild(pic(it, 'e4-im')); if (it.qty > 1) c.appendChild(h('b', { class: 'e4-x' }, 'x' + it.qty)); }
      c.appendChild(h('span', { class: 'e4-hl' }, it ? it.label : 'Slot ' + s));
    });
  }
  function drawEquip() {
    const imgs = data.wornImg || {};
    Object.keys(eq).forEach((k) => {
      const c = eq[k], lab = wornLabel(k), d = EQ_L.concat(EQ_R).find((x) => x[0] === k);
      G.clear(c);
      c.className = 'e4-q' + (lab ? ' on' : '');
      c.title = lab ? d[1] + ' : ' + lab + ' (clic pour retirer)' : d[1];
      if (lab) c.appendChild(pic({ image: imgs[k], kind: 'clothes' }, 'e4-im'));
      else if (k === 'hat') c.appendChild(h('img', { class: 'e4-qi', src: 'img/inv/hat.png', alt: '', draggable: false }));
      else c.appendChild(h('span', { class: 'e4-qi' }, svg(ICON[k])));
      c.appendChild(h('span', { class: 'e4-ql' }, lab || d[1]));
    });
  }
  function drawPeople() {
    G.clear(ppl);
    const list = (data.near || []).slice(0, 8);
    list.forEach((n, k) => ppl.appendChild(h('span', { class: 'e4-pp' + (n.far ? ' far' : ''), 'data-id': String(n.id), title: n.far ? 'Trop loin pour donner' : 'Glisse un objet ici pour le donner' },
      h('i', null, String(k + 1)), n.name || 'Personne')));
    dh.className = 'e4-dh';
    dh.textContent = ic().allow_give === false ? 'Donner est désactivé sur ce serveur.' : list.length ? 'Glisse un objet sur un joueur pour le lui donner' : 'Personne autour de toi pour un échange.';
  }
  function drawPromo() {
    const txt = typeof ic().promo === 'string' ? ic().promo : 'Pour débloquer plus de slot dans votre inventaire,\nachetez le *Premium*. Il est vendu dans la boutique\nserveur *24h/24 et 7j/7.*';
    G.clear(promo);
    txt.slice(0, 300).replace(/\\n/g, '\n').split('*').forEach((part, i) => promo.appendChild(i % 2 ? h('span', null, part) : document.createTextNode(part)));
  }
  function applyCfg() {
    const t = themeOf(cfg);
    el.style.setProperty('--ac-rgb', t.ac); el.style.setProperty('--ac', 'rgb(' + t.ac + ')'); el.style.setProperty('--tint', t.tint);
    const pv = (ic().ped_mode || 'menu') !== 'off' && !opt.preview;   // vrai personnage au centre (aperçu du menu pause ou caméra)
    el.classList.toggle('ped', pv);
    el.classList.toggle('pmenu', pv && (ic().ped_mode || 'menu') === 'menu');   // le jeu assombrit lui-même le décor derrière le personnage
    el.classList.toggle('nova', !!(G.nova && G.nova()));
    const lg = (G.cfg && G.cfg.brand && G.cfg.brand.logo) ? G.assetUrl(G.cfg.brand.logo) : '';
    const lsrc = lg || 'img/brand/shadow-logo.png';
    if (nvLogo.getAttribute('src') !== lsrc) nvLogo.setAttribute('src', lsrc);
    const src = 'img/inv/' + (pv ? 'bg_ped.webp' : 'bg.webp');
    if (bg.getAttribute('src') !== src) bg.setAttribute('src', src);
    drawPromo();
  }
  function refresh() { drawLeft(); drawRight(); drawHot(); drawEquip(); drawPeople(); }

  // ---------- échelle ----------
  function fit() {
    const w = el.clientWidth || window.innerWidth, hh = el.clientHeight || window.innerHeight;
    el.style.setProperty('--k', String(Math.min(w / 1920, hh / 1080)));
  }
  const ro = window.ResizeObserver ? new ResizeObserver(fit) : null;
  if (ro) ro.observe(el); else window.addEventListener('resize', fit);
  const k = () => Number(el.style.getPropertyValue('--k')) || 1;
  const toStage = (x, y) => { const r = st.getBoundingClientRect(); return { x: (x - r.left) / k(), y: (y - r.top) / k() }; };

  // ---------- info-bulle et menu ----------
  function hideTip() { if (tip) { tip.remove(); tip = null; } }
  // info-bulle placée à côté de la souris (dans la scène 1920×1080), retournée près des bords
  function placeTip(ev) {
    if (!tip || !ev) return;
    const p = toStage(ev.clientX, ev.clientY), w = tip.offsetWidth || 250, hh = tip.offsetHeight || 110;
    let tx = p.x + 18, ty = p.y + 18;
    if (tx + w > 1910) tx = p.x - w - 18;
    if (ty + hh > 1070) ty = p.y - hh - 18;
    tip.style.left = Math.max(10, tx) + 'px'; tip.style.top = Math.max(10, ty) + 'px';
  }
  function showTip(cell, it, ev) {
    hideTip();
    if (!it || drag || menu) return;
    const tx = 0, ty = 0;
    const mine = boxOf(cell) === me().owner;
    const how = mine ? (it.weapon ? (it.slot <= QUICK ? 'Touche ' + it.slot + ' pour la sortir' : 'Place-la dans un raccourci 1 à 5') : it.usable ? 'Double-clic pour ' + (it.cloth ? (isWorn(it) ? 'retirer' : 'enfiler') : 'utiliser') : '') : 'Double-clic pour prendre';
    tip = add(h('div', { class: 'e4-tip', style: { left: tx + 'px', top: Math.min(ty, 1080 - 150) + 'px' } },
      h('b', null, it.label), it.desc ? h('p', null, it.desc) : null,
      h('small', null, 'Quantité ' + it.qty + ' · ' + (it.weight / 1000).toFixed(2) + ' kg' + (it.qty > 1 ? ' (' + ((it.weight * it.qty) / 1000).toFixed(2) + ' kg)' : '')),
      h('small', null, how ? h('em', null, how) : null, (how ? ' · ' : '') + 'clic droit : actions')));
    placeTip(ev);
  }
  function closeMenu() { if (menu) { menu.remove(); menu = null; } }
  function openMenu(ev, owner, slot) {
    closeMenu(); hideTip();
    const it = find(owner, slot); if (!it) return;
    sel = { owner, slot }; markSel();
    const mine = owner === me().owner, p = toStage(ev.clientX, ev.clientY);
    const inp = h('input', { type: 'number', min: 1, max: it.qty, value: qty, placeholder: 'Tout', oninput: (e) => { qty = e.target.value; } });
    const go = (fn) => () => { closeMenu(); fn(); };
    const kids = [h('div', { class: 'e4-mh' }, it.label + (it.qty > 1 ? '  x' + it.qty : ''))];
    if (it.qty > 1) kids.push(h('label', null, 'Quantité', inp));
    if (mine && it.usable && !it.weapon) kids.push(h('button', { type: 'button', class: 'pri', onclick: go(() => opt.onUse && opt.onUse(slot)) }, it.cloth ? (isWorn(it) ? 'Retirer' : 'Enfiler') : 'Utiliser'));
    if (mine && it.weapon) kids.push(h('div', { class: 'e4-mt' }, slot <= QUICK ? 'Arme : touche ' + slot + ' pour la sortir ou la ranger.' : 'Arme : glisse-la dans un raccourci (1 à 5) pour l\'équiper.'));
    if (!mine) kids.push(h('button', { type: 'button', class: 'pri', onclick: go(() => { const f = firstFree(me(), it); if (f) opt.onMove && opt.onMove(owner, slot, me().owner, f, amount(it)); }) }, 'Prendre'));
    if (mine && other()) kids.push(h('button', { type: 'button', onclick: go(() => { const f = firstFree(other(), it); if (f) opt.onMove && opt.onMove(owner, slot, other().owner, f, amount(it)); }) }, 'Ranger dans « ' + (other().label || 'Coffre') + ' »'));
    if (mine && ic().allow_give !== false) (data.near || []).filter((n) => !n.far).slice(0, 4).forEach((n) => kids.push(h('button', { type: 'button', onclick: go(() => opt.onGive && opt.onGive(n.id, slot, amount(it))) }, 'Donner à ' + (n.name || ('Joueur ' + n.id)))));
    if (mine && ic().allow_drop !== false) kids.push(h('button', { type: 'button', class: 'bad', onclick: go(() => opt.onDrop && opt.onDrop(slot, amount(it))) }, 'Jeter'));
    menu = add(h('div', { class: 'e4-menu', style: { left: Math.min(p.x, 1920 - 210) + 'px', top: Math.min(p.y, 1080 - 40 - kids.length * 30) + 'px' } }, kids));
    menu.addEventListener('pointerdown', (e) => e.stopPropagation());
  }
  el.addEventListener('pointerdown', () => closeMenu());

  // ---------- souris ----------
  function boxOf(c) { const o = c && c.getAttribute('data-owner'); return o || ''; }
  function cellAt(t) { return t && t.closest ? t.closest('.e4-c,.e4-h') : null; }
  function target(x, y) {
    const t = document.elementFromPoint(x, y); if (!t || !t.closest) return null;
    const pp = t.closest('.e4-pp'); if (pp) return { kind: 'person', el: pp };
    if (t.closest('.e4-dz')) return { kind: 'zone', el: dz };
    const q = t.closest('.e4-q'); if (q) return { kind: 'equip', el: q, slot: q.getAttribute('data-eq') };
    if (t.closest('.e4-ped')) return { kind: 'ped', el: ped };
    const c = cellAt(t);
    if (c && c.getAttribute('data-slot') !== '0') return { kind: 'slot', el: c, owner: boxOf(c), slot: Number(c.getAttribute('data-slot')) };
    return null;
  }
  function flash(msg) { dh.textContent = msg; dh.classList.remove('e4-flash'); void dh.offsetWidth; dh.classList.add('e4-flash'); setTimeout(drawPeople, 2200); }
  function dropOn(tg, owner, slot) {
    const src = find(owner, slot); if (!src || !tg) return;
    const mine = owner === me().owner, n = amount(src);
    if (tg.kind === 'person' || tg.kind === 'zone') {
      if (!mine) return;
      if (ic().allow_give === false) return flash('Donner est désactivé sur ce serveur.');
      let pid = tg.kind === 'person' && !tg.el.classList.contains('far') ? Number(tg.el.getAttribute('data-id')) : 0;
      if (!pid && tg.kind === 'zone') { const ok = (data.near || []).filter((p) => !p.far); if (ok.length === 1) pid = ok[0].id; else return flash(ok.length ? 'Lâche l\'objet sur le joueur à qui le donner.' : 'Personne assez près pour recevoir.'); }
      if (pid) opt.onGive && opt.onGive(pid, slot, n);
      return;
    }
    if (tg.kind === 'ped' || tg.kind === 'equip') {
      if (!mine || !src.usable || src.weapon) return;
      if (tg.kind === 'equip' && src.cloth !== tg.slot) return;
      opt.onUse && opt.onUse(slot);
      return;
    }
    if (tg.owner === 'ground') { if (mine && ic().allow_drop !== false) opt.onDrop && opt.onDrop(slot, n); return; }
    const box = boxes().find((b) => b.owner === tg.owner); if (!box) return;
    const ts = tg.slot || firstFree(box, src); if (!ts || (tg.owner === owner && ts === slot)) return;
    opt.onMove && opt.onMove(owner, slot, tg.owner, ts, n);
  }
  function beginDrag(e, owner, slot, it) {
    const x0 = e.clientX, y0 = e.clientY; let ghost = null, last = null;
    const mark = (n) => { if (last && last !== n) last.classList.remove('over'); last = n; if (n) n.classList.add('over'); };
    const move = (ev) => {
      if (!ghost) {
        if (Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) < 6) return;
        hideTip(); closeMenu();
        ghost = add(h('div', { class: 'e4-ghost' }, pic(it, 'e4-im'), h('b', null, 'x' + amount(it))));
        drag = { owner, slot }; el.classList.add('dragging');
      }
      const p = toStage(ev.clientX, ev.clientY); ghost.style.left = p.x + 'px'; ghost.style.top = p.y + 'px';
      const tg = target(ev.clientX, ev.clientY);
      mark(tg ? (tg.kind === 'person' && tg.el.classList.contains('far') ? null : tg.el) : null);
    };
    const end = (ev) => {
      document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', end); document.removeEventListener('pointercancel', end);
      if (!ghost) return;
      noClick = Date.now() + 250; ghost.remove(); mark(null); drag = null; el.classList.remove('dragging');
      if (ev.type !== 'pointercancel') dropOn(target(ev.clientX, ev.clientY), owner, slot);
    };
    document.addEventListener('pointermove', move); document.addEventListener('pointerup', end); document.addEventListener('pointercancel', end);
  }
  st.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    const c = cellAt(e.target); if (!c) return;
    const s = Number(c.getAttribute('data-slot')), it = s && find(boxOf(c), s);
    if (it) beginDrag(e, boxOf(c), s, it);
  });
  st.addEventListener('click', (e) => {
    if (Date.now() < noClick) return;
    const q = e.target.closest && e.target.closest('.e4-q.on');
    if (q) { const it = wornItem(q.getAttribute('data-eq')); if (it) opt.onUse && opt.onUse(it.slot); return; }
    const c = cellAt(e.target); if (!c) return;
    const s = Number(c.getAttribute('data-slot')), o = boxOf(c);
    if (s && find(o, s)) { sel = { owner: o, slot: s }; markSel(); }
  });
  // sélection : seulement la surbrillance (redessiner la case casserait le double-clic)
  function markSel() {
    st.querySelectorAll('.e4-c,.e4-h').forEach((c) => c.classList.toggle('on', !!(sel && c.classList.contains('has') && boxOf(c) === sel.owner && Number(c.getAttribute('data-slot')) === sel.slot)));
  }
  st.addEventListener('dblclick', (e) => {
    const c = cellAt(e.target); if (!c) return;
    const s = Number(c.getAttribute('data-slot')), o = boxOf(c), it = s && find(o, s); if (!it) return;
    if (o === me().owner) { if (it.usable && !it.weapon) opt.onUse && opt.onUse(s); else if (other()) { const f = firstFree(other(), it); if (f) opt.onMove && opt.onMove(o, s, other().owner, f, amount(it)); } }
    else { const f = firstFree(me(), it); if (f) opt.onMove && opt.onMove(o, s, me().owner, f, amount(it)); }
  });
  st.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const c = cellAt(e.target); if (!c) return;
    const s = Number(c.getAttribute('data-slot')), o = boxOf(c);
    if (s && find(o, s)) openMenu(e, o, s);
  });
  st.addEventListener('mouseover', (e) => {
    const c = cellAt(e.target);
    if (!c) { if (tip && !(e.target.closest && e.target.closest('.e4-tip'))) hideTip(); return; }
    const s = Number(c.getAttribute('data-slot')), it = s && find(boxOf(c), s);
    if (it) { if (!tip || tipFor !== c) { tipFor = c; showTip(c, it, e); } } else { tipFor = null; hideTip(); }
  });
  let tipFor = null;
  st.addEventListener('mousemove', (e) => placeTip(e));
  st.addEventListener('mouseleave', () => { tipFor = null; hideTip(); });
  const wheel = (side) => (e) => {
    e.preventDefault(); closeMenu(); hideTip();
    const tot = side === 'l' ? rowsL() : rowsR(), n = Math.max(0, Math.min(tot - ROWS, scroll[side] + (e.deltaY > 0 ? 1 : -1)));
    if (n !== scroll[side]) { scroll[side] = n; side === 'l' ? drawLeft() : drawRight(); }
  };
  gr.addEventListener('wheel', wheel('r'), { passive: false });

  applyCfg(); refresh();
  requestAnimationFrame(fit);
  return {
    el,
    set(d) { data = d || data; if (sel && !find(sel.owner, sel.slot)) sel = null; closeMenu(); hideTip(); refresh(); },
    setPos() {},   // les copies des joueurs proches ne sont pas utilisées par cette maquette
    setCfg(c) { cfg = c || cfg; applyCfg(); refresh(); },
    destroy() { if (ro) ro.disconnect(); else window.removeEventListener('resize', fit); },
  };
}
G.inventoryE4 = inventoryE4;
G.inventoryE4Theme = themeOf;
})();
