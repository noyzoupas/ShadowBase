-- Tableau de bord de l'accueil du panel : état du serveur, courbes, à faire, derniers événements, joueurs en ligne.
-- Toutes les données sont calculées côté serveur ; chaque section n'est envoyée que si le rôle a le droit de la voir.

local function ago(t)
    local d = os.time() - t
    if d < 60 then return "à l'instant" elseif d < 3600 then return ('il y a %d min'):format(d // 60) elseif d < 86400 then return ('il y a %d h'):format(d // 3600) end
    return ('il y a %d j'):format(d // 86400)
end

local started = os.time()

local function series(hist, key, n)
    local out = {}
    local from = math.max(1, #hist - n + 1)
    for i = from, #hist do out[#out + 1] = tonumber(hist[i][key]) or 0 end
    return out
end

local function build(ctx)
    local d = {}
    local name = PB.Cfg.Get('general', 'server_name', '')
    local players = GetPlayers()
    local maxc = tonumber(GetConvar('sv_maxclients', '48')) or 48
    d.server = { name = name ~= '' and name or 'Shadow Base', online = #players, max = maxc, up = os.time() - started, upText = nil }
    local up = d.server.up
    d.server.upText = up >= 86400 and ('%d j %d h'):format(up // 86400, (up % 86400) // 3600) or ('%d h %02d min'):format(up // 3600, (up % 3600) // 60)
    -- ressources
    local total, ok, stopped = 0, 0, {}
    for i = 0, ((GetNumResources and GetNumResources()) or 0) - 1 do
        local r = GetResourceByFindIndex and GetResourceByFindIndex(i)
        if r then
            total = total + 1
            local st = GetResourceState and GetResourceState(r) or 'started'
            if st == 'started' then ok = ok + 1 elseif st == 'stopped' or st == 'missing' then if #stopped < 4 then stopped[#stopped + 1] = r end end
        end
    end
    d.res = { total = total, started = ok, stopped = stopped }
    d.lua_mb = PB.Round(collectgarbage('count') / 1024, 1)
    -- historique
    local hist = PB.Monitor and PB.Monitor.History() or {}
    if ctx.has('monitor.view') and #hist > 1 then
        local labels = {}
        for i = math.max(1, #hist - 59), #hist do labels[#labels + 1] = os.date('%H:%M', hist[i].at) end
        d.chart = { labels = labels, players = series(hist, 'players', 60), ping = series(hist, 'ping', 60) }
        local peak = 0 for _, v in ipairs(d.chart.players) do if v > peak then peak = v end end
        d.peak = peak
        d.ping = d.chart.ping[#d.chart.ping]
    end
    -- à faire
    local function count(tbl) local ok2, n = pcall(function() return PB.DB.scalar('SELECT COUNT(*) FROM ' .. tbl) end) return ok2 and tonumber(n) or 0 end
    local logo = PB.Cfg.Get('general', 'logo_data', '') ~= '' or PB.Cfg.Get('general', 'logo_url', '') ~= ''
    d.todo = {
        { title = 'Donne un nom à ton serveur', sub = 'Il apparaît sur le panel et dans les menus.', done = name ~= '', module = 'general' },
        { title = 'Ajoute ton logo et tes couleurs', sub = "Identité visible partout : panel, menus F5 / F6 / F7, notifications.", done = logo, module = 'general' },
        { title = 'Crée une première entreprise', sub = 'Police, secours, garage… à partir d\'un modèle.', done = count('pb_biz') > 0, module = 'biz' },
        { title = 'Place un point bancaire', sub = 'Sans agence ni distributeur, personne ne peut déposer.', done = count('pb_bank_points') > 0, module = 'bank' },
        { title = 'Place un garage', sub = 'Pour sortir et ranger les véhicules des joueurs.', done = count('pb_garages') > 0, module = 'garage' },
    }
    -- derniers événements
    if ctx.has('logs.view') then
        d.feed = {}
        for _, r in ipairs(PB.DB.q('SELECT cat, action, actor, target, UNIX_TIMESTAMP(created_at) AS t FROM pb_audit ORDER BY id DESC LIMIT 6') or {}) do
            d.feed[#d.feed + 1] = { who = tostring(r.actor or ''), what = tostring(r.action or ''), target = tostring(r.target or ''), cat = tostring(r.cat or ''), ago = ago(tonumber(r.t) or os.time()) }
        end
    end
    -- joueurs en ligne
    if ctx.has('monitor.view') and PB.G and PB.G.Players then
        d.players = {}
        for src, p in pairs(PB.G.Players()) do
            if #d.players >= 6 then break end
            local id = PB.G.Identity and PB.G.Identity(src) or {}
            local nm = ((id.firstname or '') .. ' ' .. (id.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
            local job = PB.G.Biz and PB.G.Biz.Job and PB.G.Biz.Job(src)
            d.players[#d.players + 1] = { name = nm ~= '' and nm or (GetPlayerName and GetPlayerName(src)) or ('Joueur ' .. src), id = src, job = job and job.label or 'Sans emploi', ping = (GetPlayerPing and GetPlayerPing(src)) or 0 }
        end
        table.sort(d.players, function(a, b) return a.id < b.id end)
    end
    if PB.News then local unseen, list = PB.News.For(ctx.license, 3) d.news = { unseen = unseen, entries = list } end
    return d
end

PB.Action('ui.dashboard', nil, function(ctx) return true, build(ctx) end, { read = true })
PB.Dashboard = { Build = build }

PB.SelfTest.Add('tableau de bord', function(R)
    local ok, err = pcall(build, { has = function() return true end })
    R.check(ok, "calcul du tableau de bord", tostring(err))
end)
