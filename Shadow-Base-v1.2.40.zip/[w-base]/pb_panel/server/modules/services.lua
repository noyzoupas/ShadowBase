-- Module 11 : Police, EMS, mécaniciens et entreprises. Le panel ne remplace pas ces scripts : il détecte celui qui est installé
-- et expose les valeurs simples de sa configuration (formulaire automatique), plus les comptes d'entreprise en lecture.

local B, P, FC, F, DB = PB.B, PB.Perm, PB.FileCfg, PB.Files, PB.DB

P.Register('services.view', 'Voir les services (police, EMS, mécanos, entreprises)', 'services')

local SERVICES = {
    { id = 'police', label = 'Police', icon = 'shield', scripts = {} },
    { id = 'ems', label = 'EMS', icon = 'heart', scripts = {} },
    { id = 'mechanic', label = 'Mécaniciens', icon = 'wrench', scripts = {} },
}
local CFG_FILES = { 'config.lua', 'shared/config.lua', 'config/config.lua', 'config/shared.lua', 'config/server.lua', 'config/client.lua' }

local function find(svc)
    for _, s in ipairs(svc.scripts) do if GetResourceState(s) == 'started' then return s end end
end

local function jobsFor(kinds)
    local out = {}
    for _, g in ipairs(PB.Fw.Groups('job') or {}) do
        if g.type and kinds[g.type] then out[#out + 1] = g end
    end
    return out
end

local TYPE_OF = { police = { leo = true, police = true }, ems = { ems = true, medic = true }, mechanic = { mechanic = true, mecano = true } }

local function companies()
    local rows = {}
    if DB.TableExists('pb_accounts') then
        local lab = {}
        for _, b in ipairs(DB.q('SELECT id, label FROM pb_biz') or {}) do lab[b.id] = b.label end
        for _, r in ipairs(DB.q("SELECT id, balance FROM pb_accounts WHERE id LIKE 'biz:%' ORDER BY id") or {}) do
            local id = r.id:gsub('^biz:', '')
            rows[#rows + 1] = { name = lab[id] or id, money = tonumber(r.balance) or 0 }
        end
        return rows, 'caisses des entreprises de Shadow Base'
    end
    return nil
end

PB.Module({
    id = 'services', label = 'Services', icon = 'shield', group = 'Serveur', order = 100, perm = 'services.view', hint = 'Police, EMS, mécaniciens, entreprises',
    caps = function()
        local c = {}
        for _, svc in ipairs(SERVICES) do
            local s = find(svc)
            c[#c + 1] = { svc.label, s and 'partial' or 'ok', s and (s .. ' : valeurs simples de sa configuration.') or 'Service intégré de Shadow Base (module Entreprises).' }
        end
        local rows, src = companies()
        c[#c + 1] = { "Comptes d'entreprise", rows and 'ok' or 'off', rows and ('Lecture : ' .. src .. '.') or 'Aucune table de comptes reconnue.' }
        c[#c + 1] = { 'Création de commissariats, hôpitaux, ateliers', 'off', "Dépend du script : modifie ses fichiers dans Ressources › Fichiers." }
        return PB.Capsify(c)
    end,
    doc = "## Services\nLe panel détecte le script de police, d'EMS et de mécanique installés, et te laisse modifier les valeurs simples de leur configuration. Les grades et salaires des métiers correspondants se règlent dans Métiers.",
    view = function(ctx, params)
        local tabs = {}
        for _, svc in ipairs(SERVICES) do
            tabs[#tabs + 1] = { id = svc.id, label = svc.label, icon = svc.icon, build = function()
                local blocks = {}
                local jobs = jobsFor(TYPE_OF[svc.id])
                local rows = {}
                for _, g in ipairs(jobs) do rows[#rows + 1] = { name = g.name, label = g.label, grades = #g.grades, actions = { { nav = { module = 'jobs', tab = 'editor', params = { name = g.name } }, label = 'Ouvrir dans Métiers', icon = 'edit' } } } end
                blocks[#blocks + 1] = B.table({ id = svc.id .. '.jobs', title = 'Métiers liés (type « ' .. next(TYPE_OF[svc.id]) .. ' »)', columns = { { k = 'name', label = 'Identifiant', type = 'mono' }, { k = 'label', label = 'Nom' }, { k = 'grades', label = 'Grades', type = 'num' } }, rows = rows, empty = 'Aucun métier de ce type.' })
                local s = find(svc)
                if not s then
                    local kind = ({ police = 'police', ems = 'ems', mechanic = 'garage' })[svc.id]
                    local bz = {}
                    for _, b in ipairs(DB.q('SELECT id, label, enabled FROM pb_biz WHERE kind = ? ORDER BY label', { kind }) or {}) do
                        local n = DB.scalar('SELECT COUNT(*) FROM pb_biz_members WHERE biz_id = ?', { b.id })
                        bz[#bz + 1] = { id = b.id, label = b.label, members = tonumber(n) or 0, on = PB.ToBool(b.enabled) and 'Actif' or 'Désactivé' }
                    end
                    blocks[#blocks + 1] = B.notice('info', "Aucun script externe : ce service est celui de Shadow Base (module « Entreprises » : grades, employés, caisse, factures, menu F6 en jeu).")
                    blocks[#blocks + 1] = B.table({ id = svc.id .. '.biz', title = 'Entreprises de Shadow Base de ce type', columns = { { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'label', label = 'Nom' }, { k = 'members', label = 'Employés', type = 'num' }, { k = 'on', label = 'État' } }, rows = bz, empty = "Aucune entreprise de ce type : crée-en une dans le module Entreprises." })
                    return blocks
                end
                if not ctx.has('resources.edit') then blocks[#blocks + 1] = B.notice('info', s .. ' détecté. Tu n\'as pas la permission de modifier sa configuration.') return blocks end
                for _, f in ipairs(CFG_FILES) do
                    if F.Read(s, f) then
                        blocks[#blocks + 1] = B.notice('info', 'Script détecté : ' .. s .. '.')
                        blocks[#blocks + 1] = FC.AutoForm(s, f, { title = s .. '/' .. f })
                        return blocks
                    end
                end
                blocks[#blocks + 1] = B.unsupported(s, "Aucun fichier de configuration reconnu : utilise Ressources › Fichiers.")
                return blocks
            end }
        end
        tabs[#tabs + 1] = { id = 'companies', label = 'Entreprises', icon = 'building', build = function()
            local rows, src = companies()
            if not rows then return { B.unsupported("Comptes d'entreprise", 'Aucune table de comptes reconnue (addon_account_data, management_funds, bank_accounts_new).') } end
            local total = 0
            for _, r in ipairs(rows) do total = total + r.money end
            return { B.stats({ { label = 'Comptes', value = #rows, icon = 'building' }, { label = 'Total', value = total, icon = 'coins' } }),
                B.table({ id = 'companies', search = true, title = 'Source : ' .. src, columns = { { k = 'name', label = 'Entreprise', type = 'mono' }, { k = 'money', label = 'Solde', type = 'num' } }, rows = rows, empty = 'Aucun compte.' }) }
        end }
        return { tabs = tabs }
    end,
})
