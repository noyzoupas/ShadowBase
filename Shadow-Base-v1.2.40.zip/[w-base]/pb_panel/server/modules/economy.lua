-- Module 10 : Économie. Réglages de l'économie de Shadow Base, amendes et taxes (catalogue publié par exports), supervision de la masse monétaire.

local B, P, Form, FC, DB = PB.B, PB.Perm, PB.Form, PB.FileCfg, PB.DB

P.Register('economy.edit', "Modifier l'économie", 'economy')
P.Register('economy.catalog', 'Gérer les amendes et les taxes', 'economy')

-- Catalogues : amendes et taxes ------------------------------------------------------------------------------------------------------------------
PB.Migrate('021_economy', 'Amendes et taxes', {
    [[CREATE TABLE IF NOT EXISTS pb_fines (
        code VARCHAR(48) NOT NULL, label VARCHAR(96) NOT NULL, amount INT NOT NULL DEFAULT 0, jail INT NOT NULL DEFAULT 0, category VARCHAR(32) NOT NULL DEFAULT '', PRIMARY KEY (code))]],
    [[CREATE TABLE IF NOT EXISTS pb_taxes (
        code VARCHAR(48) NOT NULL, label VARCHAR(96) NOT NULL, rate DOUBLE NOT NULL DEFAULT 0, PRIMARY KEY (code))]],
})

exports('GetFines', function() return DB.q('SELECT code, label, amount, jail, category FROM pb_fines ORDER BY category, label') or {} end)
exports('GetFine', function(code) return DB.one('SELECT code, label, amount, jail, category FROM pb_fines WHERE code = ?', { tostring(code) }) end)
exports('GetTaxRate', function(code)
    local r = DB.one('SELECT rate FROM pb_taxes WHERE code = ?', { tostring(code) })
    return r and tonumber(r.rate) or 0
end)

PB.Action('economy.fine.save', 'economy.catalog', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' },
        { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
        { k = 'amount', type = 'number', label = 'Montant', min = 0, max = 100000000 },
        { k = 'jail', type = 'number', label = 'Prison (minutes)', min = 0, max = 100000 },
        { k = 'category', type = 'text', label = 'Catégorie', maxlen = 32 },
    }, { code = v.code, label = v.label, amount = v.amount or 0, jail = v.jail or 0, category = v.category or '' })
    if not c then return false, err end
    local before = DB.one('SELECT * FROM pb_fines WHERE code = ?', { c.code })
    DB.upsert('pb_fines', c, { 'code' })
    ctx.audit('config', before and 'amende.modifier' or 'amende.creer', c.code, before, c)
    ctx.toast = 'Amende enregistrée.'
    return true
end)

PB.Action('economy.fine.delete', 'economy.catalog', function(ctx, p)
    local code = tostring(p.code or '')
    local before = DB.one('SELECT * FROM pb_fines WHERE code = ?', { code })
    if not before then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_fines WHERE code = ?', { code })
    ctx.audit('config', 'amende.supprimer', code, before)
    ctx.toast = 'Amende supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette amende ?', text = 'Les scripts qui la lisent ne la trouveront plus.' } })

PB.Action('economy.tax.save', 'economy.catalog', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' },
        { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
        { k = 'rate', type = 'number', label = 'Taux (%)', min = 0, max = 100, int = false },
    }, { code = v.code, label = v.label, rate = v.rate or 0 })
    if not c then return false, err end
    local before = DB.one('SELECT * FROM pb_taxes WHERE code = ?', { c.code })
    DB.upsert('pb_taxes', c, { 'code' })
    ctx.audit('config', before and 'taxe.modifier' or 'taxe.creer', c.code, before, c)
    ctx.toast = 'Taxe enregistrée.'
    return true
end)

PB.Action('economy.tax.delete', 'economy.catalog', function(ctx, p)
    local code = tostring(p.code or '')
    local before = DB.one('SELECT * FROM pb_taxes WHERE code = ?', { code })
    if not before then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_taxes WHERE code = ?', { code })
    ctx.audit('config', 'taxe.supprimer', code, before)
    ctx.toast = 'Taxe supprimée.'
    return true
end, { critical = true, confirm = { title = 'Supprimer cette taxe ?', text = 'Les scripts qui la lisent utiliseront 0 %.' } })

-- Supervision -------------------------------------------------------------------------------------------------------------------------------------------
local function supervision()
    local rows, totals = {}, {}
    if DB.TableExists('pb_players') then
        for _, u in ipairs(DB.q("SELECT firstname, lastname, license, cash, bank FROM pb_players WHERE created = 1 LIMIT 5000") or {}) do
            local cash, bank = tonumber(u.cash) or 0, tonumber(u.bank) or 0
            totals.cash, totals.bank = (totals.cash or 0) + cash, (totals.bank or 0) + bank
            local who = ((u.firstname or '') .. ' ' .. (u.lastname or '')):gsub('^%s+', '')
            rows[#rows + 1] = { who = who ~= '' and who or u.license, total = cash + bank, detail = PB.Json({ cash = cash, bank = bank }) }
        end
    else
        return nil
    end
    table.sort(rows, function(a, b) return a.total > b.total end)
    return rows, totals
end

PB.Module({
    id = 'economy', label = 'Amendes et taxes', icon = 'gavel', group = 'Serveur', order = 91, perm = 'economy.view', hint = 'Amendes, taxes, masse monétaire',
    caps = function()
        local c = PB.Capsify({
            { 'Réglages d\'argent', 'ok', "Économie intégrée de Shadow Base : salaires, impôts, prix, banque, argent de départ (effet immédiat)." },
            { 'Supervision de la masse monétaire', 'ok', 'Comptes des joueurs de Shadow Base (lecture seule).' },
            { 'Amendes et taxes', 'partial', 'Catalogue publié par exports (GetFines, GetFine, GetTaxRate) : un script doit les utiliser.' },
            { 'Transfert / création d\'argent', 'off', "Outil d'administration en jeu : fourni par ta librairie admin, pas par le panel." },
        })
        return c
    end,
    doc = "## Économie\nLes amendes et les taxes sont un catalogue central. Tes scripts les lisent avec `exports.pb_panel:GetFine('code')` et `exports.pb_panel:GetTaxRate('code')`.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            -- Tableau de bord : où est l'argent de la ville, qui gagne vite, d'où viennent les gains
            tab('board', 'Tableau de bord', 'chart', function()
                local money = function(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
                local rows, totals = supervision()
                totals = totals or {}
                local bizSum = DB.one("SELECT COALESCE(SUM(balance), 0) AS s, COUNT(*) AS n FROM pb_accounts WHERE id LIKE 'biz:%'") or {}
                local state = DB.one("SELECT balance FROM pb_accounts WHERE id = 'state'") or {}
                local players = (tonumber(totals.cash) or 0) + (tonumber(totals.bank) or 0)
                local blocks = { B.stats({
                    { label = 'Argent des joueurs', value = money(players), icon = 'wallet', sub = ('espèces %s · banque %s'):format(money(totals.cash), money(totals.bank)) },
                    { label = "Caisses d'entreprises", value = money(bizSum.s), icon = 'building', sub = tostring(bizSum.n or 0) .. ' caisses' },
                    { label = 'Trésor public', value = money(state.balance), icon = 'coins' },
                    { label = 'Masse monétaire totale', value = money(players + (tonumber(bizSum.s) or 0)), icon = 'chart' } }) }
                local h0 = math.floor(os.time() / 3600) - 24
                local cats = {}
                for _, r in ipairs(DB.TableExists('pb_eco_hourly') and DB.q('SELECT cat, SUM(amount) AS a, SUM(n) AS n FROM pb_eco_hourly WHERE hour >= ? GROUP BY cat ORDER BY a DESC LIMIT 12', { h0 }) or {}) do
                    cats[#cats + 1] = { cat = r.cat, amount = money(r.a), n = tonumber(r.n) or 0 }
                end
                blocks[#blocks + 1] = B.table({ id = 'ecocats', title = "D'où vient l'argent gagné (24 h)", columns = { { k = 'cat', label = 'Activité' }, { k = 'amount', label = 'Gagné' }, { k = 'n', label = 'Versements', type = 'num' } }, rows = cats, empty = 'Pas encore de données (mises à jour toutes les 5 minutes).' })
                local fast = {}
                for _, r in ipairs(DB.TableExists('pb_vigil_log') and DB.q("SELECT l.license, SUM(l.delta) AS s, p.firstname, p.lastname FROM pb_vigil_log l LEFT JOIN pb_players p ON p.license = l.license WHERE l.kind = 'money' AND l.delta > 0 AND l.at > ? GROUP BY l.license, p.firstname, p.lastname ORDER BY s DESC LIMIT 10", { os.time() - 86400 }) or {}) do
                    local who = ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')
                    fast[#fast + 1] = { who = who ~= '' and who or r.license, gained = money(r.s) }
                end
                blocks[#blocks + 1] = B.table({ id = 'ecofast', title = 'Ceux qui ont le plus gagné (24 h)', columns = { { k = 'who', label = 'Joueur' }, { k = 'gained', label = 'Gagné' } }, rows = fast, empty = 'Aucun gain enregistré.' })
                local open = DB.TableExists('pb_vigil_alerts') and DB.one("SELECT COUNT(*) AS n FROM pb_vigil_alerts WHERE status = 'open'") or nil
                if open and (tonumber(open.n) or 0) > 0 then table.insert(blocks, 2, B.notice('warn', ('%d alerte(s) anti-duplication à traiter : Staff › Surveillance.'):format(open.n))) end
                local cais = {}
                for _, r in ipairs(DB.q("SELECT a.id, a.balance, b.label FROM pb_accounts a LEFT JOIN pb_biz b ON CONCAT('biz:', b.id) = a.id WHERE a.id LIKE 'biz:%' ORDER BY a.balance DESC LIMIT 8") or {}) do cais[#cais + 1] = { who = r.label or r.id, balance = money(r.balance) } end
                blocks[#blocks + 1] = B.table({ id = 'ecobiz', title = 'Caisses les plus riches', columns = { { k = 'who', label = 'Entreprise' }, { k = 'balance', label = 'Caisse' } }, rows = cais, empty = 'Aucune caisse.' })
                return blocks
            end),
            tab('fines', 'Amendes', 'gavel', function()
                local rows = {}
                for _, f in ipairs(DB.q('SELECT * FROM pb_fines ORDER BY category, label') or {}) do
                    rows[#rows + 1] = { code = f.code, label = f.label, amount = f.amount, jail = f.jail, category = f.category,
                        actions = ctx.has('economy.catalog') and { { action = 'economy.fine.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { code = f.code } } } or nil }
                end
                local blocks = { B.table({ id = 'fines', search = true, columns = { { k = 'code', label = 'Code', type = 'mono' }, { k = 'label', label = 'Intitulé' }, { k = 'amount', label = 'Montant', type = 'num' }, { k = 'jail', label = 'Prison (min)', type = 'num' }, { k = 'category', label = 'Catégorie' } }, rows = rows, empty = "Aucune amende. Ajoute-en : ton script de police pourra les lire." }) }
                if ctx.has('economy.catalog') then
                    blocks[#blocks + 1] = { type = 'form', id = 'fine.new', title = 'Ajouter ou modifier une amende', cols = 3, fields = {
                        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' }, { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
                        { k = 'amount', type = 'number', label = 'Montant', min = 0, max = 100000000 }, { k = 'jail', type = 'number', label = 'Prison (min)', min = 0, max = 100000 }, { k = 'category', type = 'text', label = 'Catégorie', maxlen = 32 } },
                        values = { code = '', label = '', amount = 0, jail = 0, category = '' }, submit = { action = 'economy.fine.save', label = 'Enregistrer' } }
                end
                return blocks
            end),
            tab('taxes', 'Taxes', 'percent', function()
                local rows = {}
                for _, t in ipairs(DB.q('SELECT * FROM pb_taxes ORDER BY label') or {}) do
                    rows[#rows + 1] = { code = t.code, label = t.label, rate = t.rate,
                        actions = ctx.has('economy.catalog') and { { action = 'economy.tax.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { code = t.code } } } or nil }
                end
                local blocks = { B.table({ id = 'taxes', columns = { { k = 'code', label = 'Code', type = 'mono' }, { k = 'label', label = 'Intitulé' }, { k = 'rate', label = 'Taux (%)', type = 'num' } }, rows = rows, empty = 'Aucune taxe.' }) }
                if ctx.has('economy.catalog') then
                    blocks[#blocks + 1] = { type = 'form', id = 'tax.new', title = 'Ajouter ou modifier une taxe', cols = 3, fields = {
                        { k = 'code', type = 'text', label = 'Code', required = true, maxlen = 48, pattern = '^[%w_%-]+$' }, { k = 'label', type = 'text', label = 'Intitulé', required = true, maxlen = 96 },
                        { k = 'rate', type = 'number', label = 'Taux (%)', min = 0, max = 100, int = false, step = 0.1 } },
                        values = { code = '', label = '', rate = 0 }, submit = { action = 'economy.tax.save', label = 'Enregistrer' } }
                end
                return blocks
            end),
            tab('deals', 'Contrats', 'file', function()
                local rows = {}
                for _, r in ipairs(DB.q("SELECT created_at, actor, target, data FROM pb_audit WHERE action IN ('deal.veh', 'deal.house') ORDER BY id DESC LIMIT 40") or {}) do
                    local d = PB.FromJson(r.data, {}) or {}
                    rows[#rows + 1] = { seller = r.actor, buyer = r.target, what = tostring(d.bien or ''), price = tostring(d.prix or ''), at = r.created_at }
                end
                return { PB.G.DealsForm and PB.G.DealsForm(ctx) or B.notice('warn', 'Module des contrats non chargé.'),
                    B.table({ id = 'deals', title = 'Derniers contrats signés', columns = { { k = 'seller', label = 'Vendeur' }, { k = 'buyer', label = 'Acheteur' }, { k = 'what', label = 'Bien' }, { k = 'price', label = 'Prix ($)' }, { k = 'at', label = 'Date', type = 'date' } }, rows = rows, empty = 'Aucun contrat signé.' }) }
            end, 'economy.edit'),
            tab('supervision', 'Masse monétaire', 'chart', function()
                local rows, totals = supervision()
                if not rows then return { B.unsupported('Masse monétaire', 'Table des joueurs introuvable pour le framework détecté.') } end
                local items = {}
                for k, v in pairs(totals) do items[#items + 1] = { label = k, value = v, icon = 'coins' } end
                table.sort(items, function(a, b) return a.label < b.label end)
                local top = {}
                for i = 1, math.min(20, #rows) do top[#top + 1] = rows[i] end
                return { B.stats(items), B.table({ id = 'rich', title = 'Les 20 plus gros patrimoines', columns = { { k = 'who', label = 'Joueur' }, { k = 'total', label = 'Total', type = 'num' }, { k = 'detail', label = 'Détail', type = 'mono' } }, rows = top, empty = 'Aucun joueur.' }) }
            end),
        } }
    end,
})
