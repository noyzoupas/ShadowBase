-- Menu F6 : actions communes à TOUTES les entreprises (pas seulement police, secours, garage, taxi, bar).
-- Ouvrir / fermer l'établissement, annonce publique, demander du renfort, collègues en service, soins (métiers de santé).
-- Les entrées sont ajoutées au menu par Q.Common ; chaque action est revérifiée ici (service, droits, délai, distance).

local G = PB.G
local Q, Biz = G.Quick, G.Biz
local M = { open = {}, lastAd = {}, lastOpen = {}, lastBackup = {}, lastHeal = {} }
G.BizMenu = M

PB.Cfg.Define('bizmenu', { open_status = true, ads = true, ad_cooldown = 300, ad_maxlen = 120, backup = true, backup_cooldown = 30, heal = true })
local function cfg(k, d) return PB.Cfg.Get('bizmenu', k, d) end
local function now() return os.time() end
local function clean(s, n) return (tostring(s or ''):gsub('[%c<>]', ''):gsub('%s+', ' '):gsub('^ ', ''):sub(1, n)) end
local function display(src) return Biz.Display and Biz.Display(src) or ('#' .. tostring(src)) end
local function wait(t, secs) local left = (t or 0) + secs - now() return left > 0 and left or nil end

-- employés en service d'une entreprise : { src, name, grade }
function M.OnDuty(bizId)
    local out = {}
    for s in pairs(G.Players()) do
        local c = Biz.Ctx(s)
        if c and c.biz.id == bizId and c.duty then out[#out + 1] = { src = s, name = display(s), grade = c.grade.label } end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end
-- ouvert = annoncé ouvert ET quelqu'un en service (fermé tout seul quand le dernier employé part)
function M.IsOpen(bizId) return M.open[bizId] == true and #M.OnDuty(bizId) > 0 end
local function canManage(c) return c.boss or Biz.Can(c, 'hire') or Biz.Can(c, 'vault') end
local function everyone(n) for s in pairs(G.Players()) do G.Notify(s, n) end end

table.insert(Q.Common, function(src, c, add)
    local duty = M.OnDuty(c.biz.id)
    add({ type = 'separator', label = 'Mon établissement' })
    if c.duty then
        if cfg('open_status', true) and canManage(c) then
            local open = M.IsOpen(c.biz.id)
            add({ id = 'biz_open', label = open and "Fermer l'établissement" or "Ouvrir l'établissement", right = open and 'Ouvert' or 'Fermé', icon = open and 'lock' or 'key',
                desc = open and 'Annonce à toute la ville que vous fermez.' or 'Annonce à toute la ville que vous êtes ouverts ; « Ouvert » apparaît dans l\'annuaire des entreprises.' })
        end
        if cfg('ads', true) then
            add({ id = 'biz_ad', label = 'Annonce publique', icon = 'chat', desc = ('Un message de %s à tous les joueurs (une annonce toutes les %d min pour l\'entreprise).'):format(c.biz.label, math.max(1, math.floor((tonumber(cfg('ad_cooldown', 300)) or 300) / 60))),
                inputs = { { k = 'text', label = 'Annonce (vue par toute la ville)', maxlen = tonumber(cfg('ad_maxlen', 120)) or 120 } } })
        end
        if cfg('backup', true) and not Biz.Allowed(c, 'security') then add({ id = 'biz_backup', label = 'Demander du renfort', icon = 'gps', desc = 'Tes collègues en service reçoivent ta position sur leur carte.' }) end
        if cfg('heal', true) and Biz.Allowed(c, 'revive') then add({ id = 'biz_heal', needs = 'target', label = 'Soigner', icon = 'heart', desc = 'Soigne une personne blessée à côté de toi (santé au maximum). Inscrit dans les dossiers.' }) end
    end
    local items = {}
    for _, d in ipairs(duty) do items[#items + 1] = { label = d.name, right = d.grade } end
    add({ id = 'colleagues', type = 'info', label = 'Collègues en service', right = tostring(#duty), icon = 'users', items = items, desc = 'Les employés de ton entreprise en service en ce moment.' })
end)

Q.Handlers.biz_open = function(src, c)
    if not c or not c.duty or not canManage(c) then return false, 'Réservé aux responsables en service.' end
    local id = c.biz.id
    local w = wait(M.lastOpen[id], 60)
    if w then return false, ('Attends %d s avant de changer encore.'):format(w) end
    M.lastOpen[id] = now()
    local open = not M.IsOpen(id)
    M.open[id] = open or nil
    everyone({ type = 'info', title = c.biz.label, text = open and 'Nous sommes ouverts : venez nous voir !' or 'Nous fermons pour le moment. À bientôt !', duration = 9000 })
    PB.Audit.Log('serveur', open and 'biz.open' or 'biz.close', src, id)
    return true, open and 'Établissement ouvert : la ville est prévenue.' or 'Établissement fermé.'
end

Q.Handlers.biz_ad = function(src, c, p)
    if not c or not c.duty then return false, 'Prends ton service.' end
    local text = clean(p.text, tonumber(cfg('ad_maxlen', 120)) or 120)
    if #text < 3 then return false, 'Écris ton annonce.' end
    local w = wait(M.lastAd[c.biz.id], tonumber(cfg('ad_cooldown', 300)) or 300)
    if w then return false, ('Une annonce de ton entreprise vient de passer : encore %d min %02d s.'):format(w // 60, w % 60) end
    M.lastAd[c.biz.id] = now()
    everyone({ type = 'info', title = c.biz.label, text = text, duration = 12000 })
    PB.Audit.Log('serveur', 'biz.ad', src, c.biz.id, nil, nil, { text = text })
    return true, 'Annonce envoyée à toute la ville.'
end

Q.Handlers.biz_backup = function(src, c)
    if not c or not c.duty then return false, 'Prends ton service.' end
    local w = wait(M.lastBackup[src], tonumber(cfg('backup_cooldown', 30)) or 30)
    if w then return false, ('Renfort déjà demandé : attends %d s.'):format(w) end
    local ped = GetPlayerPed(src)
    local pos = ped and ped ~= 0 and GetEntityCoords(ped)
    if not pos then return false, 'Ta position est illisible.' end
    M.lastBackup[src] = now()
    local n, name = 0, display(src)
    for _, d in ipairs(M.OnDuty(c.biz.id)) do
        if d.src ~= src then
            n = n + 1
            G.Notify(d.src, { type = 'warn', title = c.biz.label, text = name .. ' demande du renfort : sa position est sur ta carte.', duration = 9000 })
            TriggerClientEvent('pb:g:points:ping', d.src, PB.Json({ x = pos.x, y = pos.y, label = 'Renfort : ' .. name }))
        end
    end
    if n == 0 then return false, "Aucun collègue en service pour l'instant." end
    return true, ('%d collègue(s) prévenu(s).'):format(n)
end

Q.Handlers.biz_heal = function(src, c, p)
    if not c or not c.duty or not Biz.Allowed(c, 'revive') then return false, 'Réservé aux soignants en service.' end
    local tp, err, tid = Biz.Target(src, p.id)
    if not tp then return false, err end
    if PB.ToBool(tp.row.dead) then return false, 'Cette personne est inconsciente : utilise « Réanimer ».' end
    local w = wait(M.lastHeal[tid], 20)
    if w then return false, ('Cette personne vient d\'être soignée (%d s).'):format(w) end
    M.lastHeal[tid] = now()
    TriggerClientEvent('pb:g:staff:fx', tid, 'heal', PB.Json({}))
    if Biz.Record then Biz.Record(c, tp.license, display(tid), 'care', 'Soins', 0) end
    G.Notify(tid, { type = 'success', title = c.biz.label, text = 'Tu as été soigné(e) par ' .. display(src) .. '.' })
    return true, display(tid) .. ' est soigné(e).'
end

AddEventHandler('playerDropped', function() local s = source M.lastBackup[s] = nil M.lastHeal[s] = nil end)

G.BizMenuForm = PB.Form.Cfg({ ns = 'bizmenu', id = 'settings', title = 'Menu F6 : actions de toutes les entreprises', perm = 'quick.edit', cols = 2, fields = {
    { k = 'open_status', type = 'toggle', label = 'Ouvrir / fermer l\'établissement (responsables)', default = true, hint = 'Annonce à toute la ville ; « Ouvert » dans l\'annuaire des entreprises.' },
    { k = 'ads', type = 'toggle', label = 'Annonce publique (employés en service)', default = true },
    { k = 'ad_cooldown', type = 'number', label = 'Délai entre deux annonces d\'une entreprise (s)', default = 300, min = 30, max = 3600 },
    { k = 'ad_maxlen', type = 'number', label = 'Longueur maximale d\'une annonce', default = 120, min = 20, max = 240 },
    { k = 'backup', type = 'toggle', label = 'Demander du renfort (position aux collègues)', default = true },
    { k = 'backup_cooldown', type = 'number', label = 'Délai entre deux demandes de renfort (s)', default = 30, min = 5, max = 600 },
    { k = 'heal', type = 'toggle', label = 'Soigner (métiers de santé)', default = true },
} })
