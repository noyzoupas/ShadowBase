-- Garages, fourrière et clés : sortir / ranger un véhicule acheté, clés partagées, verrouillage, récupération en fourrière payante.
-- Le client exécute (création du véhicule, suppression) ; le serveur décide (propriétaire ou clé, état, proximité, frais).

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB

P.Register('garage.edit', 'Modifier garages, fourrière et réglages des véhicules', 'garage', true)
P.Register('garage.manage', 'Envoyer en fourrière, rendre ou supprimer un véhicule depuis le panel', 'garage', true)

local GARAGE_SQL = {
    [[CREATE TABLE IF NOT EXISTS pb_garages (
        id VARCHAR(32) NOT NULL, label VARCHAR(48) NOT NULL, kind VARCHAR(8) NOT NULL DEFAULT 'public', x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
        sx DOUBLE NOT NULL DEFAULT 0, sy DOUBLE NOT NULL DEFAULT 0, sz DOUBLE NOT NULL DEFAULT 0, sh DOUBLE NOT NULL DEFAULT 0, biz VARCHAR(32) NOT NULL DEFAULT '', enabled TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY (id))]],
    [[CREATE TABLE IF NOT EXISTS pb_vehicle_state (
        plate VARCHAR(12) NOT NULL, state VARCHAR(8) NOT NULL DEFAULT 'garage', garage VARCHAR(32) NOT NULL DEFAULT '', props TEXT NULL, net INT NOT NULL DEFAULT 0, out_at INT NOT NULL DEFAULT 0, updated INT NOT NULL DEFAULT 0, reason VARCHAR(80) NOT NULL DEFAULT '', PRIMARY KEY (plate))]],
    [[CREATE TABLE IF NOT EXISTS pb_vehicle_keys (plate VARCHAR(12) NOT NULL, license VARCHAR(64) NOT NULL, by_license VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL DEFAULT 0, PRIMARY KEY (plate, license))]],
}
local DEFAULT_GARAGES = {
    { 'legion', 'Garage public — Legion Square', 'public', 215.8, -809.6, 30.7, 222.6, -804.0, 30.0, 248.0 },
    { 'pillbox', 'Garage public — Pillbox Hill', 'public', 275.5, -345.6, 45.0, 270.5, -340.0, 44.9, 70.0 },
    { 'fourriere', 'Fourrière de la ville', 'impound', 409.0, -1623.0, 29.3, 401.0, -1631.0, 29.3, 320.0 },
}
PB.Migrate('048_game_garage', 'Garages, état des véhicules, clés', function()
    for _, sql in ipairs(GARAGE_SQL) do DB.exec(PB.Table(sql)) end
    for _, d in ipairs(DEFAULT_GARAGES) do DB.exec('INSERT IGNORE INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', d) end
end)

local SERVICE = {
    { model = 'polmav', label = 'Hélicoptère de police', price = 350000 }, { model = 'maverick', label = 'Maverick', price = 250000 },
    { model = 'supervolito', label = 'SuperVolito', price = 400000 }, { model = 'frogger', label = 'Frogger', price = 300000 }, { model = 'swift', label = 'Swift (secours)', price = 380000 },
    { model = 'police', label = 'Voiture de police', price = 45000 }, { model = 'police3', label = 'Interceptor', price = 60000 }, { model = 'ambulance', label = 'Ambulance', price = 60000 },
    { model = 'towtruck', label = 'Dépanneuse', price = 40000 }, { model = 'flatbed', label = 'Plateau', price = 55000 }, { model = 'taxi', label = 'Taxi', price = 30000 },
    { model = 'predator', label = 'Bateau de police', price = 180000 }, { model = 'dinghy', label = 'Zodiac', price = 60000 },
}
PB.Cfg.Define('garage', { service_catalog = SERVICE, service_resale = 50, plate_price = 15000, fleet_max = 10, any_garage = true, max_vehicles = 12, impound_fee = 250, impound_delay = 5, store_dist = 25, use_distance = 2.5, lock_key = 'L', lock_dist = 6, blips = true, keep_props = true })

local Gr = {}
G.Garage = Gr
local function cfg(k, d) return PB.Cfg.Get('garage', k, d) end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local KIND_LABEL = { public = 'Garage', impound = 'Fourrière', biz = 'Garage d\'entreprise', gang = 'Garage de gang' }

-- Données -------------------------------------------------------------------------------------------------------------------------------
function Gr.Points() return DB.q('SELECT * FROM pb_garages ORDER BY label') or {} end
function Gr.Point(id) return DB.one('SELECT * FROM pb_garages WHERE id = ?', { tostring(id) }) end
-- Dernière position connue d'un véhicule sorti (enregistrée pendant qu'on le conduit) : « Où est ma voiture ? »
PB.Migrate('347_vehicle_lastpos', 'Garages : dernière position connue des véhicules', {
    "ALTER TABLE pb_vehicle_state ADD COLUMN lx DOUBLE NOT NULL DEFAULT 0", "ALTER TABLE pb_vehicle_state ADD COLUMN ly DOUBLE NOT NULL DEFAULT 0",
    "ALTER TABLE pb_vehicle_state ADD COLUMN lz DOUBLE NOT NULL DEFAULT 0", "ALTER TABLE pb_vehicle_state ADD COLUMN lat INT NOT NULL DEFAULT 0",
})
-- Types de garages : voitures (car), hangar aérien (air : hélicoptères et avions), port (boat). Un véhicule ne sort et ne se range
-- que dans un garage de son type ; la fourrière aussi a un type (sinon un bateau sortirait sur le bitume).
PB.Migrate('345_garage_types', 'Garages : type (voitures, aérien, naval) et gardien posé', {
    "ALTER TABLE pb_garages ADD COLUMN vtype VARCHAR(8) NOT NULL DEFAULT 'car'",
    "ALTER TABLE pb_garages ADD COLUMN nx DOUBLE NOT NULL DEFAULT 0", "ALTER TABLE pb_garages ADD COLUMN ny DOUBLE NOT NULL DEFAULT 0",
    "ALTER TABLE pb_garages ADD COLUMN nz DOUBLE NOT NULL DEFAULT 0", "ALTER TABLE pb_garages ADD COLUMN nh DOUBLE NOT NULL DEFAULT 0",
})
Gr.VTYPES = { car = 'Voitures', air = 'Aérien', boat = 'Naval' }
local AIR_NAMES = { 'heli', 'copter', 'buzzard', 'maverick', 'frogger', 'swift', 'volatus', 'supervolito', 'havok', 'annihilator', 'valkyrie', 'savage', 'hunter', 'akula', 'cargobob', 'skylift', 'polmav', 'seasparrow',
    'luxor', 'shamal', 'nimbus', 'vestra', 'miljet', 'velum', 'mammatus', 'cuban800', 'duster', 'dodo', 'stunt', 'besra', 'lazer', 'titan', 'jet', 'cargoplane', 'hydra', 'mogul', 'molotok', 'nokota', 'pyro', 'rogue', 'starling', 'seabreeze', 'howard', 'alphaz1', 'microlight', 'tula', 'bombushka', 'volatol', 'avenger', 'strikeforce', 'alkonost', 'blimp' }
local BOAT_NAMES = { 'dinghy', 'jetmax', 'marquis', 'seashark', 'speeder', 'squalo', 'suntrap', 'toro', 'tropic', 'tug', 'predator', 'submersible', 'avisa', 'kosatka', 'longfin', 'patrolboat' }
function Gr.VType(model)
    model = tostring(model or ''):lower()
    local cls = G.VehCat and G.VehCat.Class and G.VehCat.Class(model)
    if cls then
        for _, c in ipairs(G.VehCat.classes or {}) do if c.id == cls then if c.kind == 'boat' then return 'boat' elseif c.kind == 'heli' or c.kind == 'plane' then return 'air' end return 'car' end end
    end
    for _, n in ipairs(BOAT_NAMES) do if model:find(n, 1, true) == 1 then return 'boat' end end
    for _, n in ipairs(AIR_NAMES) do if model:find(n, 1, true) == 1 then return 'air' end end
    return 'car'
end
local function vtypeOf(pt) return (pt and pt.vtype ~= nil and pt.vtype ~= '') and pt.vtype or 'car' end
Gr.VTypeOfPoint = vtypeOf
local WRONG = { car = 'ce véhicule se range dans un garage', air = 'cet appareil se range dans un hangar aérien', boat = 'ce bateau se range dans un port' }
-- fourrière : un véhicule se récupère à la fourrière de son type, ou à n'importe laquelle s'il n'en existe pas de ce type
local function impoundFits(pt, model)
    local vt = Gr.VType(model)
    if vt == vtypeOf(pt) then return true end
    return DB.one("SELECT id FROM pb_garages WHERE kind = 'impound' AND vtype = ? AND enabled = 1 LIMIT 1", { vt }) == nil
end
Gr.ImpoundFits = impoundFits
function Gr.Vehicle(plate) return DB.one('SELECT v.*, COALESCE(s.state, ?) AS state, COALESCE(s.garage, ?) AS garage, s.props AS props, COALESCE(s.net, 0) AS net, COALESCE(s.out_at, 0) AS out_at, COALESCE(s.reason, ?) AS reason FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.plate = ?', { 'garage', '', '', tostring(plate) }) end
-- Véhicules d'entreprise (colonne biz) et doubles de clé temporaires (until_at, 0 = pour toujours)
PB.Migrate('343_fleet_keys', "Garages : véhicules d'entreprise, clés prêtées pour une durée", {
    "ALTER TABLE pb_vehicles ADD COLUMN biz VARCHAR(32) NOT NULL DEFAULT ''",
    "ALTER TABLE pb_vehicle_keys ADD COLUMN until_at INT NOT NULL DEFAULT 0",
})
function Gr.Owned(license) return DB.q('SELECT v.*, COALESCE(s.state, ?) AS state, COALESCE(s.garage, ?) AS garage, COALESCE(s.out_at, 0) AS out_at, COALESCE(s.reason, ?) AS reason FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.license = ? AND v.gang = ? AND v.biz = ? ORDER BY v.label', { 'garage', '', '', license, '', '' }) or {} end
function Gr.OfBiz(bid) return DB.q('SELECT v.*, COALESCE(s.state, ?) AS state, COALESCE(s.garage, ?) AS garage, COALESCE(s.out_at, 0) AS out_at, COALESCE(s.reason, ?) AS reason FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.biz = ? ORDER BY v.label', { 'garage', '', '', tostring(bid) }) or {} end
function Gr.OfGang(gid) return DB.q('SELECT v.*, COALESCE(s.state, ?) AS state, COALESCE(s.garage, ?) AS garage, COALESCE(s.out_at, 0) AS out_at, COALESCE(s.reason, ?) AS reason FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate WHERE v.gang = ? ORDER BY v.label', { 'garage', '', '', tostring(gid) }) or {} end
local function setState(plate, state, garage, extra)
    extra = extra or {}
    DB.exec('INSERT INTO pb_vehicle_state (plate, state, garage, net, out_at, updated, reason) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state), garage = VALUES(garage), net = VALUES(net), out_at = VALUES(out_at), updated = VALUES(updated), reason = VALUES(reason)',
        { plate, state, garage or '', extra.net or 0, state == 'out' and now() or 0, now(), extra.reason or '' })
end
function Gr.MarkOut(plate) setState(plate, 'out', '') end
-- Véhicule de service donné à une entreprise (Builder du staff) : au nom de l'entreprise, rangé, clé aux employés en service
function Gr.AddFleet(bid, model, label)
    model = tostring(model or ''):lower()
    if not model:match('^[%w_]+$') or not G.Biz.Get(bid) then return false, 'Modèle ou entreprise invalide.' end
    if #Gr.OfBiz(bid) >= cfg('fleet_max', 10) + 20 then return false, "L'entreprise a déjà trop de véhicules." end
    local plate
    for _ = 1, 30 do
        local x = ('SV%06d'):format(math.random(0, 999999))
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { x }) then plate = x break end
    end
    if not plate then return false, 'Réessaie.' end
    DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price, biz) VALUES (?, ?, ?, ?, ?, ?, ?)', { 'biz:' .. bid, plate, model, tostring(label or model):sub(1, 40), os.time(), 0, bid })
    setState(plate, 'garage', '')
    return true, plate
end
function Gr.RemoveFleet(bid, plate)
    local v = Gr.Vehicle(tostring(plate or ''))
    if not v or v.biz ~= bid then return false, 'Véhicule introuvable.' end
    DB.exec('DELETE FROM pb_vehicles WHERE plate = ? AND biz = ?', { v.plate, bid })
    DB.exec('DELETE FROM pb_vehicle_state WHERE plate = ?', { v.plate })
    return true
end

-- Gang d'un joueur d'après sa licence (en ligne : source de vérité des tags ; sinon base)
local function gangOfLicense(license)
    for id, pl in pairs(G.Players()) do
        if pl.license == license then local g = G.Tags and G.Tags.Gang and G.Tags.Gang(id) return g and g.id or nil end
    end
    local r = DB.one('SELECT gang FROM pb_tag_gang WHERE license = ?', { license })
    return r and r.gang or nil
end
local function gangIdOf(src) local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src) return g and g.id or nil end
-- employé en service de l'entreprise (véhicules de l'entreprise : clé pendant le service seulement)
local function onDutyFor(license, bid)
    local m = DB.one('SELECT biz_id, on_duty FROM pb_biz_members WHERE license = ?', { license })
    return m ~= nil and m.biz_id == bid and PB.ToBool(m.on_duty)
end
-- Fausses plaques : plaque affichée -> vraie plaque (en mémoire ; tout redevient normal au redémarrage)
Gr.Fake = {}
function Gr.Real(plate) plate = tostring(plate or ''):gsub('%s+$', '') return Gr.Fake[plate] or plate end
function Gr.HasKey(license, plate)
    plate = Gr.Real(plate)
    local v = DB.one('SELECT license, gang, biz FROM pb_vehicles WHERE plate = ?', { tostring(plate) })
    if not v then return false end
    if (v.biz or '') ~= '' then
        if onDutyFor(license, v.biz) then return true end
    elseif (v.gang or '') ~= '' then
        -- véhicule d'organisation : les membres ont la clé ; l'ancien propriétaire non (sauf double explicite)
        if gangOfLicense(license) == v.gang then return true end
    elseif v.license == license then return true end
    return DB.one('SELECT plate FROM pb_vehicle_keys WHERE plate = ? AND license = ? AND (until_at = 0 OR until_at > ?)', { tostring(plate), license, os.time() }) ~= nil
end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 60) end return 'Joueur ' .. src end

exports('HasKeys', function(src, plate) local p = G.Get(tonumber(src)) return p ~= nil and Gr.HasKey(p.license, plate) end)
exports('GetVehicleState', function(plate) local v = Gr.Vehicle(plate) return v and v.state or nil end)

-- Y a-t-il encore un véhicule dans le monde ? (OneSync requis ; sinon on se fie au délai)
local function stillInWorld(v)
    if (v.net or 0) == 0 then return nil end
    local ok, ent = pcall(function() return NetworkGetEntityFromNetworkId(v.net) end)
    if not ok or not ent then return nil end
    local ok2, ex = pcall(function() return DoesEntityExist(ent) end)
    if not ok2 then return nil end
    return ex and true or false
end

-- Point de sortie des véhicules : celui posé pour le garage, sinon juste à côté du point (une fourrière sans sortie ne bloque plus)
local function spawnOf(pt)
    if (tonumber(pt.sx) or 0) ~= 0 or (tonumber(pt.sy) or 0) ~= 0 then return { x = pt.sx, y = pt.sy, z = pt.sz, h = pt.sh or 0 } end
    return { x = pt.x + 3.0, y = pt.y, z = pt.z, h = 0.0 }
end
Gr.SpawnOf = spawnOf
Gr.InWorld = stillInWorld   -- utilisé par la fourrière automatique (coherence.lua)

-- Sessions de menu -----------------------------------------------------------------------------------------------------------------------
local sessions = {}
local function usable(src) local p = G.Get(src) return p and PB.ToBool(p.row.created) and not PB.ToBool(p.row.dead) and not (G.IsCuffed and G.IsCuffed(src)) end
local function nearPoint(src, pt, extra) return G.DistTo(src, pt.x, pt.y, pt.z) <= (extra or cfg('use_distance', 2.5) + 5) end
local last = {}
local function throttle(src, ms) local t = GetGameTimer and GetGameTimer() or os.time() * 1000 local k = tostring(src) if last[k] and t - last[k] < ms then return false end last[k] = t return true end

local function impoundFee() return G.Eco and G.Eco.Fine(cfg('impound_fee', 250)) or cfg('impound_fee', 250) end

-- le véhicule « dehors » peut-il être récupéré à la fourrière ?
local function recoverable(v)
    if v.state == 'impound' then return true end
    if v.state ~= 'out' then return false end
    local w = stillInWorld(v)
    if w ~= nil then return true end   -- encore en ville : il sera retiré du monde à la récupération
    return now() - (v.out_at or 0) >= cfg('impound_delay', 5) * 60
end

local function parseProps(s) local t = PB.FromJson(s, nil) return type(t) == 'table' and t or nil end
local function cleanProps(p)
    if type(p) ~= 'table' then return nil end
    local function n(v, lo, hi) v = tonumber(v) if not v or v ~= v then return nil end return math.max(lo, math.min(hi, v)) end
    local out = { eh = n(p.eh, 0, 1000), bh = n(p.bh, 0, 1000), th = n(p.th, 0, 1000), fuel = n(p.fuel, 0, 400), c1 = n(p.c1, 0, 160), c2 = n(p.c2, 0, 160), dirt = n(p.dirt, 0, 15),
        ty = n(p.ty, 0, 1023), dr = n(p.dr, 0, 255) }
    -- les améliorations de l'atelier sont conservées telles qu'elles sont en base : un client ne peut pas les écraser
    return out
end
-- État d'un véhicule : carburant, moteur, carrosserie (en %), en direct s'il est sorti et visible du serveur, sinon au dernier rangement
function Gr.Condition(plate)
    local st = DB.one('SELECT state, props, net FROM pb_vehicle_state WHERE plate = ?', { tostring(plate) })
    local p = st and parseProps(st.props) or {}
    local function pct(v, d) v = tonumber(v) if not v then return d end return math.max(0, math.min(100, math.floor(v + 0.5))) end
    local out = { fuel = pct(p.fuel, 100), engine = pct(p.eh and p.eh / 10, 100), body = pct(p.bh and p.bh / 10, 100), live = false, c1 = tonumber(p.c1), c2 = tonumber(p.c2) }
    if st and st.state == 'out' and (tonumber(st.net) or 0) > 0 then
        local ok, ent = pcall(NetworkGetEntityFromNetworkId, tonumber(st.net))
        if ok and ent and ent ~= 0 and DoesEntityExist(ent) then
            local okE, eh = pcall(GetVehicleEngineHealth, ent)
            local okB, bh = pcall(GetVehicleBodyHealth, ent)
            if okE and eh then out.engine = pct(eh / 10, out.engine) end
            if okB and bh then out.body = pct(bh / 10, out.body) end
            local c = GetEntityCoords(ent)
            out.live, out.x, out.y = true, c.x, c.y
        end
    end
    return out
end
local function condChips(plate)
    local c = Gr.Condition(plate)
    return ('Carburant %d %%'):format(c.fuel), ('Moteur %d %% · Carrosserie %d %%'):format(c.engine, c.body), c
end
-- améliorations (atelier) : stockées dans les mêmes propriétés, jamais modifiées par ce que renvoie un joueur
local function modsOf(plate)
    local v = DB.one('SELECT props FROM pb_vehicle_state WHERE plate = ?', { plate })
    local t = v and parseProps(v.props)
    return t and type(t.mods) == 'table' and t.mods or nil
end
function Gr.SetMod(plate, key, level)
    local st = DB.one('SELECT props FROM pb_vehicle_state WHERE plate = ?', { plate })
    if not st then return false end
    local t = parseProps(st.props) or {}
    t.mods = type(t.mods) == 'table' and t.mods or {}
    t.mods[key] = level
    DB.exec('UPDATE pb_vehicle_state SET props = ? WHERE plate = ?', { PB.Json(t), plate })
    return true
end
function Gr.ResetDamage(plate)
    local st = DB.one('SELECT props FROM pb_vehicle_state WHERE plate = ?', { plate })
    if not st then return false end
    local t = parseProps(st.props) or {}
    t.eh, t.bh, t.th, t.ty, t.dr, t.dirt = 1000, 1000, 1000, 0, 0, 0
    DB.exec('UPDATE pb_vehicle_state SET props = ? WHERE plate = ?', { PB.Json(t), plate })
    return true
end

-- Pages ---------------------------------------------------------------------------------------------------------------------------------
local PAGES = {}
Gr.PAGES = PAGES
local function stateLabel(v)
    if v.state == 'garage' then return 'Au garage' elseif v.state == 'out' then return 'Dehors' elseif v.state == 'impound' then return 'Fourrière' end
    return v.state
end
PAGES.cars = function(src, s)
    local p = G.Get(src)
    local rows = {}
    local isImpound = s.point.kind == 'impound'
    local here = vtypeOf(s.point)
    local function fits(v) if isImpound then return impoundFits(s.point, v.model) end return Gr.VType(v.model) == here end
    -- (v1.2.39) garage d'entreprise : seulement ses véhicules de service, jamais les véhicules personnels
    local sharedGarage = s.point.kind == 'biz'
    for _, v in ipairs(sharedGarage and {} or Gr.Owned(p.license)) do
        if not fits(v) then goto nextcar end
        local acts = {}
        if isImpound then
            local rec, why = recoverable(v)
            if rec then acts[#acts + 1] = { act = 'recover', label = 'Récupérer (' .. money(impoundFee()) .. ')', payload = { plate = v.plate }, primary = true } end
        elseif v.state == 'garage' and (cfg('any_garage', true) or v.garage == '' or v.garage == s.point.id) then
            acts[#acts + 1] = { act = 'take', label = 'Sortir', payload = { plate = v.plate }, primary = true }
        end
        if v.state == 'out' then acts[#acts + 1] = { act = 'locate', label = 'Localiser sur la carte', payload = { plate = v.plate } } end
        local fuelTxt, healthTxt, cond = condChips(v.plate)
        rows[#rows + 1] = { plate = v.plate, model = v.model, label = v.label, state = stateLabel(v), where = v.state == 'garage' and (v.garage ~= '' and v.garage or 'N\'importe quel garage') or (v.reason ~= '' and v.reason or ''), fuel = fuelTxt, health = healthTxt, c1 = cond.c1, c2 = cond.c2, actions = acts }
        ::nextcar::
    end
    -- véhicules de l'entreprise : à son garage (employés en service) et à la fourrière (patron)
    local bc = G.Biz and G.Biz.Ctx(src)
    if bc and ((s.point.kind == 'biz' and s.point.biz == bc.biz.id) or isImpound) then
        for _, v in ipairs(Gr.OfBiz(bc.biz.id)) do
            local acts = {}
            if isImpound then
                if bc.boss and recoverable(v) then acts[#acts + 1] = { act = 'recover', label = 'Récupérer (' .. money(impoundFee()) .. ')', payload = { plate = v.plate }, primary = true } end
            elseif v.state == 'garage' and bc.duty then
                acts[#acts + 1] = { act = 'take', label = 'Sortir', payload = { plate = v.plate }, primary = true }
            end
            rows[#rows + 1] = { plate = v.plate, model = v.model, label = v.label .. ' · ' .. bc.biz.label, state = stateLabel(v), where = v.state == 'garage' and (bc.duty and 'Véhicule de service' or 'Prends ton service pour le sortir') or (v.reason ~= '' and v.reason or ''), actions = acts }
        end
    end
    local gid = gangIdOf(src)
    local gangHere = s.point.kind == 'gang' and gid ~= nil and gid == s.point.biz
    if gid and (gangHere or isImpound) then
        local boss = G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, gid)
        local gradeOk = not G.Orga or G.Orga.Grade(src) >= (PB.Cfg.Get('orgs', 'take_grade', 0) or 0)
        for _, v in ipairs(Gr.OfGang(gid)) do
            local acts = {}
            if isImpound then
                if boss and recoverable(v) then acts[#acts + 1] = { act = 'recover', label = 'Récupérer (' .. money(impoundFee()) .. ')', payload = { plate = v.plate }, primary = true } end
            elseif v.state == 'garage' and gradeOk then
                acts[#acts + 1] = { act = 'take', label = 'Sortir', payload = { plate = v.plate }, primary = true }
            end
            rows[#rows + 1] = { plate = v.plate, model = v.model, label = v.label .. ' · organisation', state = stateLabel(v), where = v.state == 'garage' and 'Garage de gang' or (v.reason ~= '' and v.reason or ''), actions = acts }
        end
    end
    local plateForm
    if not isImpound and (tonumber(cfg('plate_price', 15000)) or 0) >= 0 then
        local opts = {}
        for _, v in ipairs(Gr.Owned(p.license)) do if v.state == 'garage' then opts[#opts + 1] = { v.plate, v.label .. ' — ' .. v.plate } end end
        if #opts > 0 then plateForm = { type = 'form', id = 'plate', title = 'Plaque personnalisée', desc = ('Coût : %s. Le véhicule doit être rangé.'):format(money(cfg('plate_price', 15000))), cols = 2,
            fields = { { k = 'plate', type = 'select', label = 'Véhicule', opts = opts }, { k = 'new', type = 'text', label = 'Nouvelle plaque', maxlen = 8 } }, submit = { act = 'plate', label = 'Changer la plaque' } } end
    end
    return { { type = 'table', title = isImpound and 'Véhicules récupérables' or (gangHere and 'Mes véhicules et ceux de l\'organisation' or 'Mes véhicules'), columns = { { k = 'plate', label = 'Plaque' }, { k = 'label', label = 'Modèle' }, { k = 'state', label = 'État' }, { k = 'where', label = 'Détail' }, { k = 'fuel', label = 'Carburant' }, { k = 'health', label = 'État mécanique' } }, rows = rows, empty = 'Tu ne possèdes aucun véhicule : achète-en un à la concession.' },
        isImpound and { type = 'notice', text = ('Frais de fourrière : %s. Un véhicule « dehors » n\'est récupérable que s\'il a disparu du monde (ou après %d minutes si le serveur ne peut pas le vérifier).'):format(money(impoundFee()), cfg('impound_delay', 5)) } or plateForm }, isImpound and 'Fourrière' or s.point.label
end
PAGES.org = function(src, s)
    local p = G.Get(src)
    local gid = gangIdOf(src)
    if not gid or gid ~= s.point.biz then return { { type = 'notice', level = 'warn', text = "Ce garage n'est pas celui de ton organisation." } }, 'Organisation' end
    local boss = G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, gid)
    local mine, gang = Gr.Owned(p.license), Gr.OfGang(gid)
    local give, take, mineOpts, donated = {}, {}, {}, {}
    for _, v in ipairs(mine) do if v.state == 'garage' then mineOpts[#mineOpts + 1] = { v.plate, v.label .. ' — ' .. v.plate } end end
    for _, v in ipairs(gang) do
        if v.state == 'garage' then
            give[#give + 1] = { v.plate, v.label .. ' — ' .. v.plate }
            if v.license == p.license then donated[#donated + 1] = { v.plate, v.label .. ' — ' .. v.plate } end
        end
    end
    local members = {}
    for id, pl in pairs(G.Players()) do if id ~= src and PB.ToBool(pl.row.created) and gangIdOf(id) == gid and G.DistBetween(src, id) <= 10 then members[#members + 1] = { tostring(id), display(id) .. ' (' .. id .. ')' } end end
    local mx = PB.Cfg.Get('orgs', 'max_vehicles', 10)
    local blocks = { { type = 'notice', level = 'info', text = ('Véhicules de l\'organisation : %d / %d. Un véhicule donné reste au nom de l\'organisation : tous les membres ont la clé. Il doit être rangé au garage.'):format(#gang, mx) } }
    if PB.Cfg.Get('orgs', 'allow_donate', true) then
        blocks[#blocks + 1] = { type = 'form', id = 'donate', title = "Donner un de mes véhicules à l'organisation", cols = 1, fields = { { k = 'plate', type = 'select', label = 'Mon véhicule (rangé)', opts = mineOpts } }, submit = { act = 'donate', label = "Donner à l'organisation" } }
    end
    blocks[#blocks + 1] = { type = 'form', id = 'reclaim', title = 'Reprendre un véhicule que j\'ai donné', cols = 1, fields = { { k = 'plate', type = 'select', label = 'Véhicule donné (rangé)', opts = donated } }, submit = { act = 'reclaim', label = 'Reprendre' } }
    if boss then
        blocks[#blocks + 1] = { type = 'form', id = 'giveto', title = 'Attribuer un véhicule à un membre (chef)', desc = 'Le membre doit être à côté de toi. Le véhicule devient le sien et quitte l\'organisation.', cols = 2, fields = { { k = 'plate', type = 'select', label = "Véhicule de l'organisation (rangé)", opts = give }, { k = 'id', type = 'select', label = 'Membre', opts = members } }, submit = { act = 'give_member', label = 'Attribuer' } }
    end
    return blocks, 'Organisation'
end
PAGES.fleet = function(src, s)
    local p = G.Get(src)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or s.point.kind ~= 'biz' or s.point.biz ~= c.biz.id then return { { type = 'notice', level = 'warn', text = "Ce garage n'est pas celui de ton entreprise." } }, 'Entreprise' end
    local fleet = Gr.OfBiz(c.biz.id)
    local rows = {}
    for _, v in ipairs(fleet) do rows[#rows + 1] = { plate = v.plate, label = v.label, state = stateLabel(v) } end
    local blocks = { { type = 'notice', level = 'info', text = ("Véhicules de l'entreprise : %d / %d. Les employés EN SERVICE en ont la clé et les sortent de ce garage ; ils ne peuvent pas les garder hors service."):format(#fleet, cfg('fleet_max', 10)) },
        { type = 'table', title = "Véhicules de l'entreprise", columns = { { k = 'plate', label = 'Plaque' }, { k = 'label', label = 'Modèle' }, { k = 'state', label = 'État' } }, rows = rows, empty = 'Aucun véhicule de service.' } }
    if c.boss then
        local mineOpts, back = {}, {}
        for _, v in ipairs(Gr.Owned(p.license)) do if v.state == 'garage' then mineOpts[#mineOpts + 1] = { v.plate, v.label .. ' — ' .. v.plate } end end
        for _, v in ipairs(fleet) do if v.state == 'garage' and v.license == p.license then back[#back + 1] = { v.plate, v.label .. ' — ' .. v.plate } end end
        blocks[#blocks + 1] = { type = 'form', id = 'fdonate', title = "Mettre un de mes véhicules au service de l'entreprise", cols = 1, fields = { { k = 'plate', type = 'select', label = 'Mon véhicule (rangé)', opts = mineOpts } }, submit = { act = 'fleet_add', label = "Donner à l'entreprise" } }
        blocks[#blocks + 1] = { type = 'form', id = 'fback', title = 'Reprendre un véhicule que j\'ai donné', cols = 1, fields = { { k = 'plate', type = 'select', label = 'Véhicule (rangé)', opts = back } }, submit = { act = 'fleet_back', label = 'Reprendre' } }
        -- catalogue de service : seulement ce qui se range ici (hélicoptères à l'hélipad, voitures au garage, bateaux au port)
        local buy, sell = {}, {}
        local vt = vtypeOf(s.point)
        for i, it in ipairs(cfg('service_catalog', SERVICE) or {}) do
            if Gr.VType(it.model) == vt then buy[#buy + 1] = { tostring(i), ('%s — %s'):format(it.label, money(tonumber(it.price) or 0)) } end
        end
        for _, v in ipairs(fleet) do if v.state == 'garage' and v.license == 'biz:' .. c.biz.id then sell[#sell + 1] = { v.plate, ('%s — %s (reprise %s)'):format(v.label, v.plate, money(math.floor((tonumber(v.price) or 0) * cfg('service_resale', 50) / 100))) } end end
        local bal = G.Eco and G.Eco.Balance('biz:' .. c.biz.id) or 0
        if #buy > 0 then blocks[#blocks + 1] = { type = 'form', id = 'fbuy', title = ({ air = 'Acheter un hélicoptère de service', boat = 'Acheter un bateau de service' })[vt] or 'Acheter un véhicule de service', desc = 'Payé par la caisse de l\'entreprise (' .. money(bal) .. ').', cols = 1,
            fields = { { k = 'item', type = 'select', label = 'Modèle', opts = buy } }, submit = { act = 'fleet_buy', label = 'Acheter' } } end
        if #sell > 0 then blocks[#blocks + 1] = { type = 'form', id = 'fsell', title = 'Revendre un véhicule de service', cols = 1, fields = { { k = 'plate', type = 'select', label = 'Véhicule (rangé)', opts = sell } }, submit = { act = 'fleet_sell', label = 'Revendre' } } end
    end
    return blocks, 'Entreprise'
end
PAGES.keys = function(src, s)
    local p = G.Get(src)
    local rows, opts = {}, {}
    local mine = Gr.Owned(p.license)
    for id, pl in pairs(G.Players()) do if id ~= src and PB.ToBool(pl.row.created) and G.DistBetween(src, id) <= 8 then opts[#opts + 1] = { tostring(id), display(id) .. ' (' .. id .. ')' } end end
    local carOpts = {}
    for _, v in ipairs(mine) do
        carOpts[#carOpts + 1] = { v.plate, v.label .. ' — ' .. v.plate }
        for _, k in ipairs(DB.q('SELECT k.license, k.until_at, p.firstname, p.lastname FROM pb_vehicle_keys k LEFT JOIN pb_players p ON p.license = k.license WHERE k.plate = ?', { v.plate }) or {}) do
            local who = ((k.firstname or '') .. ' ' .. (k.lastname or '')):gsub('^%s+', '')
            if (tonumber(k.until_at) or 0) > 0 then who = who .. ' · jusqu\'à ' .. os.date('%d/%m %Hh%M', k.until_at) end
            rows[#rows + 1] = { plate = v.plate, label = v.label, who = who, actions = { { act = 'revoke', label = 'Retirer la clé', payload = { plate = v.plate, license = k.license }, danger = true } } }
        end
    end
    local got = {}
    for _, k in ipairs(DB.q('SELECT k.plate, k.until_at, v.label FROM pb_vehicle_keys k JOIN pb_vehicles v ON v.plate = k.plate WHERE k.license = ? AND (k.until_at = 0 OR k.until_at > ?)', { G.Get(src).license, now() }) or {}) do
        got[#got + 1] = { plate = k.plate, label = k.label .. ((tonumber(k.until_at) or 0) > 0 and (' · prêt jusqu\'à ' .. os.date('%Hh%M', k.until_at)) or ''), actions = { { act = 'return_key', label = 'Rendre la clé', payload = { plate = k.plate }, danger = true } } }
    end
    return { { type = 'form', id = 'give', title = 'Donner ou prêter une clé', desc = 'La personne doit être à côté de toi. Un prêt se termine tout seul.', fields = { { k = 'plate', type = 'select', label = 'Véhicule', opts = carOpts }, { k = 'id', type = 'select', label = 'Personne', opts = opts },
            { k = 'hours', type = 'select', label = 'Durée', opts = { { '0', 'Double de clé (pour toujours)' }, { '1', 'Prêt : 1 heure' }, { '2', 'Prêt : 2 heures' }, { '6', 'Prêt : 6 heures' }, { '24', 'Prêt : 24 heures' } } } }, submit = { act = 'give_key', label = 'Donner la clé', disabled = #opts == 0 or #carOpts == 0 } },
        { type = 'table', title = 'Clés prêtées', columns = { { k = 'plate', label = 'Plaque' }, { k = 'label', label = 'Modèle' }, { k = 'who', label = 'Titulaire du double' } }, rows = rows, empty = 'Aucun double de clé en circulation.' },
        { type = 'table', title = 'Clés que j\'ai reçues', columns = { { k = 'plate', label = 'Plaque' }, { k = 'label', label = 'Modèle' } }, rows = got, empty = "Personne ne t'a prêté de clé." } }, 'Clés'
end

local META = { { 'cars', 'Véhicules', 'car' }, { 'keys', 'Clés', 'lock' } }
local function frame(src, s)
    local p = G.Get(src)
    local nav = { { id = 'cars', label = 'Véhicules', icon = 'car', group = KIND_LABEL[s.point.kind] or 'Garage' } }
    if s.point.kind == 'gang' then nav[#nav + 1] = { id = 'org', label = 'Organisation', icon = 'users', group = KIND_LABEL.gang } end
    if s.point.kind == 'biz' then nav[#nav + 1] = { id = 'fleet', label = 'Entreprise', icon = 'building', group = KIND_LABEL.biz } end
    if s.point.kind ~= 'impound' then nav[#nav + 1] = { id = 'keys', label = 'Clés', icon = 'lock', group = KIND_LABEL[s.point.kind] or 'Garage' } end
    return { name = display(src), id = (G.UidOf(src) or src), nav = nav, tone = s.point.kind == 'impound' and '#ffb457' or '#6fb4ff', brand = s.point.label, cash = p.row.cash, bank = p.row.bank, spawn = spawnOf(s.point), impound = s.point.kind == 'impound' or nil }
end
local function page(src, name)
    local s = sessions[src]
    local fn = s and PAGES[name or 'cars']
    if not fn then return nil end
    local blocks, title = fn(src, s)
    local clean = {}
    for _, b in ipairs(blocks) do if b then clean[#clean + 1] = b end end
    return { page = name or 'cars', title = title, blocks = clean }
end
local function ui(src, ev, extra)
    local s = sessions[src]
    local msg = { ev = ev, frame = frame(src, s) }
    for k, v in pairs(extra or {}) do msg[k] = v end
    TriggerClientEvent('pb:g:garage:ui', src, PB.Json(msg))
end

RegisterNetEvent('pb:g:garage:open', function(id)
    if G.DutyGate and G.DutyGate(source) then return end
    local src = source
    if not usable(src) or not throttle(src, 400) then return end
    local pt = Gr.Point(id)
    if not pt or not PB.ToBool(pt.enabled) or not nearPoint(src, pt) then return end
    if pt.biz ~= '' and pt.kind ~= 'gang' then
        local c = G.Biz and G.Biz.Ctx(src)
        if not c or c.biz.id ~= pt.biz then G.Notify(src, { type = 'error', text = "Ce garage est réservé à une entreprise." }) return end
    end
    if pt.kind == 'gang' and gangIdOf(src) ~= pt.biz then G.Notify(src, { type = 'error', text = "Ce garage est réservé à une organisation." }) return end
    sessions[src] = { point = pt }
    ui(src, 'open', { page = page(src, 'cars') })
end)
RegisterNetEvent('pb:g:garage:page', function(name)
    local src = source
    if not sessions[src] or not throttle(src, 150) then return end
    local pg = page(src, tostring(name))
    ui(src, 'page', { page = pg, err = pg == nil and 'Page indisponible.' or nil })
end)
RegisterNetEvent('pb:g:garage:close', function() sessions[source] = nil end)
AddEventHandler('playerDropped', function() sessions[source] = nil last[tostring(source)] = nil end)

-- Actions --------------------------------------------------------------------------------------------------------------------------------
local ACT = {}
Gr.ACT = ACT
local function ownedBy(src, plate)         -- véhicule personnel (jamais celui d'une organisation)
    local p = G.Get(src)
    local v = Gr.Vehicle(plate)
    if not v or v.license ~= p.license or (v.gang or '') ~= '' then return nil end
    return v, p
end
local function carFor(src, plate)             -- personnel, ou de son organisation
    local p = G.Get(src)
    local v = Gr.Vehicle(plate)
    if not v then return nil end
    if (v.biz or '') ~= '' then
        local c = G.Biz and G.Biz.Ctx(src)
        if not c or c.biz.id ~= v.biz then return nil end
        return v, p, false, true
    end
    if (v.gang or '') ~= '' then
        if gangIdOf(src) ~= v.gang then return nil end
        return v, p, true
    end
    if v.license ~= p.license then return nil end
    return v, p, false
end

-- Localiser un véhicule sorti : repère GPS sur sa position actuelle
ACT.locate = function(s, src, p)
    local pl = G.Get(src)
    local v = Gr.Vehicle(tostring(p.plate or ''))
    if not v or v.license ~= pl.license then return false, 'Ce véhicule ne t\'appartient pas.' end
    local c = Gr.Condition(v.plate)
    if not c.live then return false, 'Véhicule introuvable : trop loin ou plus dans le monde (va à la fourrière).' end
    TriggerClientEvent('pb:g:phone:gps', src, c.x, c.y, v.label or v.plate)
    return true, 'Ton véhicule est repéré sur la carte.'
end
ACT.take = function(s, src, p)
    if s.point.kind == 'impound' then return false, 'Utilise « Récupérer » à la fourrière.' end
    local v, _, isGang, isBiz = carFor(src, p.plate)
    if not v then return false, 'Véhicule introuvable.' end
    if isBiz then
        if s.point.kind ~= 'biz' or s.point.biz ~= v.biz then return false, "Les véhicules de l'entreprise sortent de son garage." end
        local c = G.Biz.Ctx(src)
        if not c or not c.duty then return false, 'Prends ton service pour sortir un véhicule de l\'entreprise.' end
    end
    if not isGang and not isBiz and s.point.kind == 'biz' then return false, 'Tes véhicules personnels sortent des garages publics.' end
    if isGang then
        if s.point.kind ~= 'gang' or s.point.biz ~= v.gang then return false, "Les véhicules de l'organisation sortent de son garage." end
        if G.Orga and G.Orga.Grade(src) < (PB.Cfg.Get('orgs', 'take_grade', 0) or 0) then return false, "Ton grade ne permet pas de sortir ce véhicule." end
    end
    if v.state ~= 'garage' then return false, 'Ce véhicule n\'est pas au garage.' end
    if Gr.VType(v.model) ~= vtypeOf(s.point) then return false, 'Ici on ne sort pas ce véhicule : ' .. WRONG[Gr.VType(v.model)] .. '.' end
    if not isGang and not isBiz and not cfg('any_garage', true) and v.garage ~= '' and v.garage ~= s.point.id then return false, 'Il est rangé dans un autre garage.' end
    setState(v.plate, 'out', '')
    TriggerClientEvent('pb:g:veh:spawn', src, PB.Json({ model = v.model, plate = v.plate, spawn = spawnOf(s.point), props = cfg('keep_props', true) and parseProps(v.props) or nil }))
    return true, v.label .. ' sorti.'
end

ACT.recover = function(s, src, p)
    if s.point.kind ~= 'impound' then return false, 'Rends-toi à la fourrière.' end
    local v, pl, isGang, isBiz = carFor(src, p.plate)
    if not v then return false, 'Véhicule introuvable.' end
    if isGang and not (G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, v.gang)) then return false, "Seul le chef peut récupérer un véhicule de l'organisation." end
    if isBiz and not (G.Biz.Ctx(src) or {}).boss then return false, "Seul le patron peut récupérer un véhicule de l'entreprise." end
    local ok, why = recoverable(v)
    if not ok then return false, why or "Ce véhicule n'est pas en fourrière." end
    if not impoundFits(s.point, v.model) then return false, "Il se récupère à la fourrière de son type (" .. Gr.VTYPES[Gr.VType(v.model)]:lower() .. ")." end
    local fee = impoundFee()
    if fee > 0 then
        local acc = G.Pay(src, fee, 'bank')
        if not acc then return false, ("Il te faut %s."):format(money(fee)) end
        if G.Eco then G.Eco.Book('state', fee, 'Fourrière ' .. v.plate, pl.license) end
    end
    -- encore en ville (abandonné quelque part) : retiré du monde avant d'en recréer un à la fourrière
    if stillInWorld(v) == true then pcall(function() local ent = NetworkGetEntityFromNetworkId(v.net) if ent and ent ~= 0 then DeleteEntity(ent) end end) end
    setState(v.plate, 'out', '')
    TriggerClientEvent('pb:g:veh:spawn', src, PB.Json({ model = v.model, plate = v.plate, spawn = spawnOf(s.point), props = cfg('keep_props', true) and parseProps(v.props) or nil }))
    TriggerEvent('pb_panel:impoundRecovered', src, v.plate, fee)
    return true, ('%s récupéré (%s).'):format(v.label, money(fee))
end

-- Véhicules d'organisation ---------------------------------------------------------------------------------------------------------------
local function atOwnGangGarage(s, src) return s.point.kind == 'gang' and gangIdOf(src) ~= nil and gangIdOf(src) == s.point.biz end
ACT.donate = function(s, src, p)
    if not PB.Cfg.Get('orgs', 'allow_donate', true) then return false, 'Les dons de véhicules sont désactivés.' end
    if not atOwnGangGarage(s, src) then return false, "Rends-toi au garage de ton organisation." end
    local v, me = ownedBy(src, p.plate)
    if not v then return false, 'Véhicule introuvable.' end
    if v.state ~= 'garage' then return false, 'Range le véhicule au garage avant de le donner.' end
    local gid = s.point.biz
    local n = #Gr.OfGang(gid)
    local mx = PB.Cfg.Get('orgs', 'max_vehicles', 10)
    if n >= mx then return false, ("L'organisation a déjà %d véhicules (maximum)."):format(mx) end
    DB.exec("UPDATE pb_vehicles SET gang = ? WHERE plate = ? AND gang = ''", { gid, v.plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { v.plate })
    PB.Audit.Log('economy', 'org.vehicle.donate', src, v.plate, nil, { gang = gid, model = v.model })
    return true, ('%s donné à l\'organisation.'):format(v.label)
end
ACT.reclaim = function(s, src, p)
    if not atOwnGangGarage(s, src) then return false, "Rends-toi au garage de ton organisation." end
    local v, me, isGang = carFor(src, p.plate)
    if not v or not isGang or v.license ~= me.license then return false, "Tu ne peux reprendre que les véhicules que tu as donnés." end
    if v.state ~= 'garage' then return false, 'Le véhicule doit être rangé au garage.' end
    local mx = cfg('max_vehicles', 12)
    if #Gr.Owned(me.license) >= mx then return false, ('Tu possèdes déjà %d véhicules (maximum).'):format(mx) end
    DB.exec("UPDATE pb_vehicles SET gang = '' WHERE plate = ?", { v.plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { v.plate })
    PB.Audit.Log('economy', 'org.vehicle.reclaim', src, v.plate, nil, { gang = v.gang })
    return true, ('%s repris.'):format(v.label)
end
ACT.give_member = function(s, src, p)
    if not atOwnGangGarage(s, src) then return false, "Rends-toi au garage de ton organisation." end
    local gid = s.point.biz
    if not (G.Flags and G.Flags.IsBoss and G.Flags.IsBoss(src, gid)) then return false, "Seul le chef peut attribuer un véhicule." end
    local v, me, isGang = carFor(src, p.plate)
    if not v or not isGang then return false, 'Véhicule introuvable.' end
    if v.state ~= 'garage' then return false, 'Le véhicule doit être rangé au garage.' end
    local id = tonumber(p.id)
    local tp = id and G.Get(id)
    if not tp or id == src or not PB.ToBool(tp.row.created) or gangIdOf(id) ~= gid then return false, "Choisis un membre de l'organisation, à côté de toi." end
    if G.DistBetween(src, id) > 10 then return false, 'Ce membre est trop loin.' end
    local mx = cfg('max_vehicles', 12)
    if #Gr.Owned(tp.license) >= mx then return false, 'Ce membre possède déjà trop de véhicules.' end
    DB.exec("UPDATE pb_vehicles SET license = ?, gang = '' WHERE plate = ?", { tp.license, v.plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { v.plate })
    PB.Audit.Log('economy', 'org.vehicle.give', src, v.plate, nil, { gang = gid, to = tp.license })
    G.Notify(id, { type = 'success', title = 'Véhicule reçu', text = ('Le chef t\'a attribué %s (%s).'):format(v.label, v.plate) })
    return true, ('%s attribué à %s.'):format(v.label, display(id))
end

ACT.fleet_add = function(s, src, p)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or not c.boss or s.point.kind ~= 'biz' or s.point.biz ~= c.biz.id then return false, "Seul le patron, au garage de l'entreprise." end
    local v = ownedBy(src, p.plate)
    if not v then return false, 'Véhicule introuvable.' end
    if v.state ~= 'garage' then return false, 'Range le véhicule au garage avant de le donner.' end
    if #Gr.OfBiz(c.biz.id) >= cfg('fleet_max', 10) then return false, ("L'entreprise a déjà %d véhicules (maximum)."):format(cfg('fleet_max', 10)) end
    DB.exec("UPDATE pb_vehicles SET biz = ? WHERE plate = ? AND gang = '' AND biz = ''", { c.biz.id, v.plate })
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { v.plate })
    PB.Audit.Log('economy', 'biz.vehicle.add', src, v.plate, nil, { biz = c.biz.id, model = v.model })
    return true, ("%s est maintenant un véhicule de service de %s."):format(v.label, c.biz.label)
end
ACT.fleet_back = function(s, src, p)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or not c.boss or s.point.kind ~= 'biz' or s.point.biz ~= c.biz.id then return false, "Seul le patron, au garage de l'entreprise." end
    local me = G.Get(src)
    local v = Gr.Vehicle(tostring(p.plate or ''))
    if not v or v.biz ~= c.biz.id or v.license ~= me.license then return false, 'Tu ne peux reprendre que les véhicules que tu as donnés.' end
    if v.state ~= 'garage' then return false, 'Le véhicule doit être rangé au garage.' end
    if #Gr.Owned(me.license) >= cfg('max_vehicles', 12) then return false, ('Tu possèdes déjà %d véhicules (maximum).'):format(cfg('max_vehicles', 12)) end
    DB.exec("UPDATE pb_vehicles SET biz = '' WHERE plate = ?", { v.plate })
    PB.Audit.Log('economy', 'biz.vehicle.back', src, v.plate, nil, { biz = c.biz.id })
    return true, ('%s repris.'):format(v.label)
end
-- Achat d'un véhicule de service avec la caisse de l'entreprise (il appartient à l'entreprise, pas au patron)
ACT.fleet_buy = function(s, src, p)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or not c.boss or s.point.kind ~= 'biz' or s.point.biz ~= c.biz.id then return false, "Seul le patron, au garage de l'entreprise." end
    local it = (cfg('service_catalog', SERVICE) or {})[math.floor(tonumber(p.item) or 0)]
    if not it or Gr.VType(it.model) ~= vtypeOf(s.point) then return false, 'Ce modèle ne se range pas ici.' end
    if #Gr.OfBiz(c.biz.id) >= cfg('fleet_max', 10) then return false, ("L'entreprise a déjà %d véhicules (maximum)."):format(cfg('fleet_max', 10)) end
    local price = math.floor(tonumber(it.price) or 0)
    local plate
    for _ = 1, 30 do
        local x = ('SV%06d'):format(math.random(0, 999999))
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { x }) then plate = x break end
    end
    if not plate then return false, 'Réessaie.' end
    if price > 0 and not G.Eco.Take('biz:' .. c.biz.id, price, 'Véhicule de service : ' .. it.label, G.Get(src).license) then return false, ("La caisse ne couvre pas %s."):format(money(price)) end
    DB.insert('INSERT INTO pb_vehicles (license, plate, model, label, bought_at, price, biz) VALUES (?, ?, ?, ?, ?, ?, ?)', { 'biz:' .. c.biz.id, plate, it.model, it.label, os.time(), price, c.biz.id })
    setState(plate, 'garage', s.point.id)
    PB.Audit.Log('economy', 'biz.vehicle.buy', src, plate, nil, { biz = c.biz.id, model = it.model, price = price })
    return true, ('%s acheté pour %s (plaque %s).'):format(it.label, money(price), plate)
end
ACT.fleet_sell = function(s, src, p)
    local c = G.Biz and G.Biz.Ctx(src)
    if not c or not c.boss or s.point.kind ~= 'biz' or s.point.biz ~= c.biz.id then return false, "Seul le patron, au garage de l'entreprise." end
    local v = Gr.Vehicle(tostring(p.plate or ''))
    if not v or v.biz ~= c.biz.id or v.license ~= 'biz:' .. c.biz.id then return false, "Seuls les véhicules achetés par l'entreprise se revendent ici." end
    if v.state ~= 'garage' then return false, 'Le véhicule doit être rangé.' end
    if (tonumber(DB.exec('DELETE FROM pb_vehicles WHERE plate = ? AND biz = ?', { v.plate, c.biz.id })) or 0) < 1 then return false, 'Déjà revendu.' end
    DB.exec('DELETE FROM pb_vehicle_state WHERE plate = ?', { v.plate })
    local back = math.floor((tonumber(v.price) or 0) * cfg('service_resale', 50) / 100)
    if back > 0 then G.Eco.Book('biz:' .. c.biz.id, back, 'Reprise : ' .. v.label, G.Get(src).license) end
    PB.Audit.Log('economy', 'biz.vehicle.sell', src, v.plate, nil, { biz = c.biz.id, back = back })
    return true, ('%s revendu : %s pour la caisse.'):format(v.label, money(back))
end
local KEY_HOURS = { ['0'] = 0, ['1'] = 1, ['2'] = 2, ['6'] = 6, ['24'] = 24 }
ACT.give_key = function(s, src, p)
    local v, me = ownedBy(src, p.plate)
    if not v then return false, "Seul le propriétaire peut donner une clé." end
    local id = tonumber(p.id)
    local tp = id and G.Get(id)
    if not tp or id == src or not PB.ToBool(tp.row.created) then return false, 'Choisis une personne proche.' end
    if G.DistBetween(src, id) > 10 then return false, 'Cette personne est trop loin.' end
    local hours = KEY_HOURS[tostring(p.hours or '0')] or 0
    local untilAt = hours > 0 and (now() + hours * 3600) or 0
    DB.exec('INSERT INTO pb_vehicle_keys (plate, license, by_license, at, until_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE until_at = VALUES(until_at), at = VALUES(at)', { v.plate, tp.license, me.license, now(), untilAt })
    G.Notify(id, { type = 'info', title = 'Clé reçue', text = hours > 0 and ('%s (%s) t\'est prêté pour %d h.'):format(v.label, v.plate, hours) or ('Tu as un double de clé pour %s (%s).'):format(v.label, v.plate) })
    return true, hours > 0 and ('Clé prêtée à %s pour %d h.'):format(display(id), hours) or ('Double de clé donné à %s.'):format(display(id))
end
ACT.return_key = function(s, src, p)
    local me = G.Get(src)
    local plate = tostring(p.plate or '')
    if not DB.one('SELECT plate FROM pb_vehicle_keys WHERE plate = ? AND license = ?', { plate, me.license }) then return false, "Tu n'as pas de double de cette clé." end
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ? AND license = ?', { plate, me.license })
    return true, 'Clé rendue.'
end
ACT.revoke = function(s, src, p)
    local v = ownedBy(src, p.plate)
    if not v then return false, "Seul le propriétaire peut retirer une clé." end
    DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ? AND license = ?', { v.plate, tostring(p.license or '') })
    return true, 'Clé retirée.'
end

RegisterNetEvent('pb:g:garage:act', function(name, payload, pgname)
    local src = source
    local s = sessions[src]
    if not s or not usable(src) or not throttle(src, 400) then return end
    local fn = ACT[tostring(name)]
    local ok, msg = false, 'Action inconnue.'
    if fn then
        if not nearPoint(src, s.point, cfg('use_distance', 2.5) + 8) then ok, msg = false, 'Tu es trop loin.'
        else ok, msg = fn(s, src, type(payload) == 'table' and payload or {}) end
    end
    ui(src, 'result', { ok = ok and true or false, msg = msg, page = page(src, tostring(pgname or 'cars')) })
end)

-- Ranger : le client envoie la plaque du véhicule dans lequel il est ; on vérifie l'état et la proximité du garage
RegisterNetEvent('pb:g:garage:store', function(id, plate, props, netId)
    local src = source
    if not usable(src) or not throttle(src, 600) then return end
    local pt = Gr.Point(id)
    local pl = G.Get(src)
    if not pt or pt.kind == 'impound' or not PB.ToBool(pt.enabled) or not nearPoint(src, pt, cfg('store_dist', 25)) then return end
    plate = tostring(plate or ''):sub(1, 12)
    -- le véhicule doit être là : sinon on pourrait « ranger » une voiture laissée ailleurs et la ressortir (doublon)
    local ent
    if G.ServerSees() then
        local e, real = G.VehNear(src, netId, cfg('store_dist', 25) + 10)
        if not e then G.Notify(src, { type = 'error', text = 'Amène le véhicule au garage pour le ranger.' }) return end
        if real:upper() ~= plate:gsub('%s+$', ''):upper() then return end
        ent = e
    end
    if Gr.Fake[plate:gsub('%s+$', '')] then G.Notify(src, { type = 'error', text = 'Retire d\'abord la fausse plaque (ALT sur le véhicule).' }) return end
    local v, _, isGang = carFor(src, plate)
    if not v then G.Notify(src, { type = 'error', text = "Ce véhicule ne t'appartient pas." }) return end
    if isGang and (pt.kind ~= 'gang' or pt.biz ~= v.gang) then G.Notify(src, { type = 'error', text = "Un véhicule d'organisation se range dans le garage de l'organisation." }) return end
    if (v.biz or '') ~= '' and (pt.kind ~= 'biz' or pt.biz ~= v.biz) then G.Notify(src, { type = 'error', text = "Un véhicule de l'entreprise se range dans le garage de l'entreprise." }) return end
    if pt.kind == 'gang' and gangIdOf(src) ~= pt.biz then return end
    if pt.kind == 'biz' and (v.biz or '') == '' and (v.gang or '') == '' then G.Notify(src, { type = 'error', text = "Ici on ne range que les véhicules de service. Ton véhicule personnel va dans un garage public." }) return end
    if v.state ~= 'out' then G.Notify(src, { type = 'error', text = "Ce véhicule est déjà rangé." }) return end
    if Gr.VType(v.model) ~= vtypeOf(pt) then G.Notify(src, { type = 'error', text = 'Impossible de le ranger ici : ' .. WRONG[Gr.VType(v.model)] .. '.' }) return end
    local clean = cfg('keep_props', true) and cleanProps(props) or nil
    local mods = modsOf(plate)
    setState(plate, 'garage', pt.id)
    if clean then clean.mods = mods DB.exec('UPDATE pb_vehicle_state SET props = ? WHERE plate = ?', { PB.Json(clean), plate }) end
    TriggerClientEvent('pb:g:veh:stored', src, plate)
    if ent then SetTimeout(1500, function() if DoesEntityExist(ent) then DeleteEntity(ent) end end) end
    G.Notify(src, { type = 'success', title = pt.label, text = v.label .. ' rangé.' })
end)

-- Sortie ratée côté joueur (modèle absent, place refusée…) : le véhicule revient au garage au lieu de rester « dehors » sans exister
RegisterNetEvent('pb:g:veh:spawnfail', function(plate)
    local src = source
    local pl = G.Get(src)
    plate = tostring(plate or ''):sub(1, 12)
    local v = pl and Gr.Vehicle(plate)
    if not v or v.state ~= 'out' or not Gr.HasKey(pl.license, plate) then return end
    local st = DB.one('SELECT net, out_at FROM pb_vehicle_state WHERE plate = ?', { plate })
    if not st or (tonumber(st.net) or 0) > 0 or now() - (tonumber(st.out_at) or 0) > 120 then return end
    setState(plate, 'garage', '')
    PB.Audit.Log('garage', 'veh.spawnfail', src, plate, nil, nil, { model = v.model })
end)
RegisterNetEvent('pb:g:veh:spawned', function(plate, netId)
    local src = source
    local pl = G.Get(src)
    plate = tostring(plate or ''):sub(1, 12)
    local v = pl and Gr.Vehicle(plate)
    if not v or v.state ~= 'out' or not Gr.HasKey(pl.license, plate) then return end
    DB.exec('UPDATE pb_vehicle_state SET net = ? WHERE plate = ?', { math.floor(tonumber(netId) or 0), plate })
end)

-- Dégâts qui persistent : le client envoie l'état du véhicule qu'il conduit ; le serveur ne garde que ce qui est plausible
local syncAt = {}
RegisterNetEvent('pb:g:veh:sync', function(plate, props)
    local src = source
    local pl = G.Get(src)
    if not pl or not throttle(src, 4000) then return end
    plate = tostring(plate or ''):gsub('%s+$', ''):sub(1, 12)
    local v = Gr.Vehicle(plate)
    if not v or v.state ~= 'out' or not Gr.HasKey(pl.license, plate) then return end
    local clean = cleanProps(props)
    if not clean then return end
    clean.mods = modsOf(plate)
    local ped = GetPlayerPed(src)
    local c = ped and ped ~= 0 and GetEntityCoords(ped)
    if c and (c.x ~= 0 or c.y ~= 0) then
        DB.exec('UPDATE pb_vehicle_state SET props = ?, lx = ?, ly = ?, lz = ?, lat = ? WHERE plate = ?', { PB.Json(clean), c.x, c.y, c.z, os.time(), plate })
    else DB.exec('UPDATE pb_vehicle_state SET props = ? WHERE plate = ?', { PB.Json(clean), plate }) end
end)

-- Où est le véhicule ? En direct (OneSync), sinon dernière position connue ; rangé : le garage ; en fourrière : la fourrière la plus proche
function Gr.Where(plate, src)
    local v = Gr.Vehicle(plate)
    if not v then return nil end
    if v.state == 'out' then
        local ok, ent = pcall(NetworkGetEntityFromNetworkId, tonumber(v.net) or 0)
        if ok and ent and ent ~= 0 and DoesEntityExist(ent) then local c = GetEntityCoords(ent) return { x = c.x, y = c.y, z = c.z, kind = 'live', text = 'Position en direct' } end
        local st = DB.one('SELECT lx, ly, lz, lat FROM pb_vehicle_state WHERE plate = ?', { v.plate })
        if st and ((tonumber(st.lx) or 0) ~= 0 or (tonumber(st.ly) or 0) ~= 0) then
            local mins = math.floor((os.time() - (tonumber(st.lat) or 0)) / 60)
            return { x = st.lx, y = st.ly, z = st.lz, kind = 'last', text = mins < 1 and 'Dernière position (à l\'instant)' or ('Dernière position (il y a %d min)'):format(mins) }
        end
        return { kind = 'unknown', text = 'Position inconnue' }
    end
    local g = v.garage ~= '' and Gr.Point(v.garage) or nil
    if v.state == 'impound' and not g then
        local best, bd
        for _, x in ipairs(DB.q("SELECT * FROM pb_garages WHERE kind = 'impound' AND enabled = 1") or {}) do
            if vtypeOf(x) == Gr.VType(v.model) then
                local d = src and G.DistTo(src, x.x, x.y, x.z) or 0
                if not bd or d < bd then best, bd = x, d end
            end
        end
        g = best
    end
    if not g then return { kind = 'unknown', text = v.state == 'impound' and 'En fourrière' or 'Rangé' } end
    return { x = g.x, y = g.y, z = g.z, kind = v.state, text = (v.state == 'impound' and 'En fourrière : ' or 'Rangé : ') .. tostring(g.label) }
end
-- véhicule détruit : épave à la fourrière, très abîmée (réparable par un mécanicien)
RegisterNetEvent('pb:g:veh:wreck', function(plate)
    local src = source
    local pl = G.Get(src)
    if not pl or not throttle(src, 3000) or not PB.Cfg.Get('fuel', 'wreck_to_impound', true) then return end
    plate = tostring(plate or ''):gsub('%s+$', ''):sub(1, 12)
    local v = Gr.Vehicle(plate)
    if not v or v.state ~= 'out' or not Gr.HasKey(pl.license, plate) then return end
    local t = parseProps(v.props) or {}
    t.eh, t.bh, t.th, t.fuel = 250, 200, 600, 5
    setState(plate, 'impound', '', { reason = 'Épave' })
    DB.exec('UPDATE pb_vehicle_state SET props = ? WHERE plate = ?', { PB.Json(t), plate })
    G.Notify(src, { type = 'warn', title = 'Véhicule détruit', text = v.label .. ' est à la fourrière.' })
    TriggerEvent('pb_panel:vehicleWrecked', src, plate)
end)
-- le moteur d'un véhicule acheté en ville ne démarre qu'avec la clé ; les véhicules inconnus (trafic) restent libres
RegisterNetEvent('pb:g:veh:check', function(plate)
    local src = source
    local pl = G.Get(src)
    if not pl or not throttle(src, 500) then return end
    plate = tostring(plate or ''):gsub('%s+$', ''):sub(1, 12)
    local v = DB.one('SELECT license FROM pb_vehicles WHERE plate = ?', { Gr.Real(plate) })
    TriggerClientEvent('pb:g:veh:checked', src, PB.Json({ plate = plate, owned = v ~= nil, key = v ~= nil and Gr.CanDrive(src, plate) or false }))
end)

-- Mécanicien en service (droit « réparer ») : il peut ouvrir, démarrer et conduire les véhicules des clients sans leur clé
function Gr.IsMechanic(src)
    local c = G.Biz and G.Biz.Ctx(src)
    return c ~= nil and c.duty == true and G.Biz.Allowed(c, 'repair') == true
end
function Gr.CanDrive(src, plate) local pl = G.Get(src) return pl ~= nil and (Gr.HasKey(pl.license, plate) or Gr.IsMechanic(src)) end

-- Verrouillage : toggle serveur, clé requise
local locks = {}
function Gr.ToggleLock(src, plate)
    local pl = G.Get(src)
    if not pl then return false, 'Joueur introuvable.' end
    plate = tostring(plate or ''):gsub('%s+$', ''):sub(1, 12)
    if not Gr.CanDrive(src, plate) then return false, "Tu n'as pas la clé de ce véhicule." end
    locks[plate] = not locks[plate]
    local msg = PB.Json({ plate = plate, locked = locks[plate] })
    for _, id in ipairs(GetPlayers()) do TriggerClientEvent('pb:g:veh:lockState', tonumber(id), msg) end
    return true, locks[plate] and 'Véhicule verrouillé.' or 'Véhicule déverrouillé.'
end
RegisterNetEvent('pb:g:veh:lock', function(plate, netId)
    local src = source
    local pl = G.Get(src)
    if not pl or not usable(src) or not throttle(src, 700) then return end
    local ok, msg = Gr.ToggleLock(src, plate)
    if not ok then G.Notify(src, { type = 'error', text = msg }) end
end)
local keyAsk = {}
AddEventHandler('playerDropped', function() keyAsk[source] = nil end)
RegisterNetEvent('pb:g:veh:hasKey', function(plate)   -- invites près d'un véhicule : le client demande s'il a la clé
    local src = source
    local pl = G.Get(src)
    local now = GetGameTimer()
    keyAsk[src] = keyAsk[src] or {}
    if not pl or #keyAsk[src] > 0 and now - keyAsk[src][1] < 300 then return end
    keyAsk[src][1] = now
    plate = tostring(plate or ''):gsub('%s+$', ''):sub(1, 12)
    TriggerClientEvent('pb:g:veh:keyInfo', src, plate, Gr.CanDrive(src, plate) == true)
end)
RegisterNetEvent('pb:g:veh:needLocks', function()
    for plate, st in pairs(locks) do TriggerClientEvent('pb:g:veh:lockState', source, PB.Json({ plate = plate, locked = st })) end
end)

-- Prêts de clé terminés : on retire le double et on prévient l'emprunteur s'il est en ville
CreateThread(function()
    Wait(math.random(0, 120000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(120000)
        local t = os.time()
        for _, k in ipairs(DB.q('SELECT k.plate, k.license, v.label FROM pb_vehicle_keys k LEFT JOIN pb_vehicles v ON v.plate = k.plate WHERE k.until_at > 0 AND k.until_at <= ?', { t }) or {}) do
            DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ? AND license = ? AND until_at > 0 AND until_at <= ?', { k.plate, k.license, t })
            for id, pl in pairs(G.Players()) do if pl.license == k.license then G.Notify(id, { type = 'info', title = 'Prêt terminé', text = ('Le prêt de %s (%s) est terminé : la clé est rendue.'):format(k.label or 'véhicule', k.plate) }) end end
        end
    end
end)

-- Plaque personnalisée : tout ce qui est rangé sous l'ancienne plaque suit (état, clés, compteur, coffre du véhicule)
function Gr.Rename(old, new)
    old, new = tostring(old), tostring(new)
    if DB.exec('UPDATE pb_vehicles SET plate = ? WHERE plate = ?', { new, old }) == 0 then return false end
    for _, t in ipairs({ 'pb_vehicle_state', 'pb_vehicle_keys', 'pb_vehicle_odo' }) do pcall(DB.exec, 'UPDATE ' .. t .. ' SET plate = ? WHERE plate = ?', { new, old }) end
    DB.exec('UPDATE pb_inv SET owner = ? WHERE owner = ?', { 'v:' .. new, 'v:' .. old })
    TriggerEvent('pb_panel:plateChanged', old, new)
    return true
end
function Gr.PlateOk(p)
    p = tostring(p or ''):upper():gsub('^%s+', ''):gsub('%s+$', '')
    if not p:match('^[A-Z0-9 ]+$') or #p < 2 or #p > 8 then return nil, 'Plaque : 2 à 8 caractères, lettres, chiffres et espaces.' end
    if DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { p }) or Gr.Fake[p] then return nil, 'Cette plaque est déjà prise.' end
    return p
end
ACT.plate = function(s, src, p)
    if s.point.kind == 'impound' then return false, 'Pas ici.' end
    local v, me = ownedBy(src, p.plate)
    if not v then return false, 'Choisis un de tes véhicules.' end
    if v.state ~= 'garage' then return false, 'Le véhicule doit être rangé au garage.' end
    local new, err = Gr.PlateOk(p.new)
    if not new then return false, err end
    local price = tonumber(cfg('plate_price', 15000)) or 0
    if price > 0 then
        if not G.Pay(src, price, 'bank') then return false, ('Une plaque personnalisée coûte %s.'):format(money(price)) end
        G.Eco.Book('state', price, 'Plaque personnalisée', me.license)
    end
    if not Gr.Rename(v.plate, new) then return false, 'Changement impossible.' end
    PB.Audit.Log('economy', 'garage.plate', src, v.plate, { plate = v.plate }, { plate = new })
    if G.Timeline then G.Timeline.Add(me.license, 'plate', ('Plaque %s remplacée par %s'):format(v.plate, new), 'info') end
    return true, ('Nouvelle plaque : %s.'):format(new)
end
-- Fausse plaque (objet « fausse_plaque ») : au volant, la plaque affichée change ; le fichier de la police ne trouve plus le véhicule
local function randomPlate()
    local c = 'ABCDEFGHJKLMNPRSTUVWXYZ0123456789'
    for _ = 1, 30 do
        local t = {}
        for i = 1, 8 do local k = math.random(1, #c) t[i] = c:sub(k, k) end
        local p = table.concat(t)
        if not DB.one('SELECT id FROM pb_vehicles WHERE plate = ?', { p }) and not Gr.Fake[p] then return p end
    end
end
function Gr.FakeOn(src)
    local ped = GetPlayerPed(src)
    local veh = ped and ped ~= 0 and GetVehiclePedIsIn(ped, false) or 0
    if veh == 0 or GetPedInVehicleSeat(veh, -1) ~= ped then return false, 'Mets-toi au volant du véhicule.' end
    local cur = tostring(GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', '')
    if Gr.Fake[cur] then return false, 'Ce véhicule a déjà une fausse plaque.' end
    local fake = randomPlate()
    if not fake then return false, 'Réessaie.' end
    SetVehicleNumberPlateText(veh, fake)
    Gr.Fake[fake] = cur
    PB.Audit.Log('crime', 'plate.fake', src, cur, nil, { fake = fake })
    return true, ('Fausse plaque posée : %s.'):format(fake)
end
function Gr.FakeOff(ent, shown)
    local real = Gr.Fake[shown]
    if not real then return false end
    SetVehicleNumberPlateText(ent, real)
    Gr.Fake[shown] = nil
    return true, real
end
PB.OnReady(function()
    if not DB.one('SELECT name FROM pb_inv_items WHERE name = ?', { 'fausse_plaque' }) then
        DB.exec('INSERT INTO pb_inv_items (name, label, weight, stack, kind, usable, description) VALUES (?, ?, 600, 5, ?, 1, ?)', { 'fausse_plaque', 'Fausse plaque', 'misc', 'Au volant : remplace la plaque affichée. Illégal.' })
        if G.Inv and G.Inv.Reload then G.Inv.Reload() end
    end
    if G.Inv and G.Inv.RegisterUsable then G.Inv.RegisterUsable('fausse_plaque', function(src) local ok, msg = Gr.FakeOn(src) if not ok then return false, msg end return true, msg end) end
end)

-- Fourrière par un agent (police) ou par le panel
function Gr.Impound(plate, reason)
    local v = Gr.Vehicle(plate)
    if not v then return false, 'Véhicule inconnu (non acheté en ville).' end
    setState(v.plate, 'impound', '', { reason = tostring(reason or 'Mise en fourrière'):sub(1, 80) })
    if (v.net or 0) ~= 0 then
        pcall(function() local e = NetworkGetEntityFromNetworkId(v.net) if e and DoesEntityExist(e) then DeleteEntity(e) end end)
    end
    TriggerEvent('pb_panel:impounded', v.plate, reason)
    return true
end
exports('ImpoundVehicle', function(plate, reason) return Gr.Impound(plate, reason) end)

function G.GaragePoints()
    local out = {}
    for _, g in ipairs(Gr.Points()) do if PB.ToBool(g.enabled) then out[#out + 1] = { id = g.id, kind = g.kind, label = g.label, x = g.x, y = g.y, z = g.z, gang = g.kind == 'gang' and g.biz or nil, vtype = vtypeOf(g),
        npc = ((tonumber(g.nx) or 0) ~= 0 or (tonumber(g.ny) or 0) ~= 0) and { x = g.nx, y = g.ny, z = g.nz, h = g.nh } or nil } end end
    return out
end

-- Panel ---------------------------------------------------------------------------------------------------------------------------------
PB.Action('garage.point.save', 'garage.edit', function(ctx, p)
    local v = p.values or {}
    local c, err = PB.Validate({
        { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
        { k = 'kind', type = 'select', label = 'Type', opts = { { 'public', 'Garage public' }, { 'impound', 'Fourrière' }, { 'biz', "Garage d'entreprise" }, { 'gang', 'Garage de gang' } } },
        { k = 'coords', type = 'coords', label = 'Entrée' }, { k = 'spawn', type = 'coords', label = 'Sortie des véhicules' }, { k = 'biz', type = 'text', label = 'Entreprise', maxlen = 32, pattern = '^[%w_]*$' }, { k = 'enabled', type = 'toggle', label = 'Actif' },
        { k = 'vtype', type = 'select', label = 'Véhicules acceptés', opts = { { 'car', 'Voitures et motos' }, { 'air', 'Aérien (hélicoptères, avions)' }, { 'boat', 'Naval (bateaux)' } } },
    }, { id = v.id, label = v.label, kind = v.kind or 'public', vtype = v.vtype or 'car', coords = v.coords or { x = 0, y = 0, z = 0, h = 0 }, spawn = v.spawn or { x = 0, y = 0, z = 0, h = 0 }, biz = v.biz or '', enabled = v.enabled ~= false })
    if not c then return false, err end
    if c.coords.x == 0 and c.coords.y == 0 then return false, "Place l'entrée sur la carte." end
    if c.spawn.x == 0 and c.spawn.y == 0 then return false, 'Place la sortie des véhicules.' end
    if c.kind == 'biz' and (c.biz == '' or not (G.Biz and G.Biz.Get(c.biz))) then return false, "Choisis une entreprise existante pour un garage d'entreprise." end
    if c.kind == 'gang' and (c.biz == '' or not (G.Tags and G.Tags.GangDefs()[c.biz])) then return false, "Indique l'identifiant d'un gang existant pour un garage de gang." end
    local before = Gr.Point(c.id)
    DB.exec('INSERT INTO pb_garages (id, label, kind, x, y, z, sx, sy, sz, sh, biz, enabled, vtype) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), kind = VALUES(kind), x = VALUES(x), y = VALUES(y), z = VALUES(z), sx = VALUES(sx), sy = VALUES(sy), sz = VALUES(sz), sh = VALUES(sh), biz = VALUES(biz), enabled = VALUES(enabled), vtype = VALUES(vtype)',
        { c.id, c.label, c.kind, c.coords.x, c.coords.y, c.coords.z, c.spawn.x, c.spawn.y, c.spawn.z, c.spawn.h, (c.kind == 'biz' or c.kind == 'gang') and c.biz or '', c.enabled and 1 or 0, c.vtype })
    ctx.audit('config', before and 'garage.point.edit' or 'garage.point.create', c.id, before, c)
    G.PushConfig()
    ctx.toast = 'Point enregistré.'
    return true
end)
PB.Action('garage.point.delete', 'garage.edit', function(ctx, p)
    local g = Gr.Point(p.id)
    if not g then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_garages WHERE id = ?', { g.id })
    DB.exec("UPDATE pb_vehicle_state SET garage = '' WHERE garage = ?", { g.id })
    ctx.audit('config', 'garage.point.delete', g.id, g, nil)
    G.PushConfig()
    ctx.toast = 'Point supprimé : ses véhicules sont rangés « partout ».'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce point ?', text = 'Les véhicules rangés ici restent à leurs propriétaires.' } })

PB.Action('garage.vehicle.impound', 'garage.manage', function(ctx, p)
    local ok, err = Gr.Impound(tostring(p.plate or ''), 'Mise en fourrière par ' .. tostring(ctx.actor and ctx.actor.name or 'staff'))
    if not ok then return false, err end
    ctx.audit('serveur', 'garage.impound', tostring(p.plate), nil, nil)
    ctx.toast = 'Véhicule envoyé en fourrière.'
    return true
end)
PB.Action('garage.vehicle.release', 'garage.manage', function(ctx, p)
    local v = Gr.Vehicle(tostring(p.plate or ''))
    if not v then return false, 'Introuvable.' end
    setState(v.plate, 'garage', '')
    ctx.audit('serveur', 'garage.release', v.plate, { state = v.state }, { state = 'garage' })
    ctx.toast = 'Véhicule rendu à son propriétaire (au garage).'
    return true
end)
PB.Action('garage.vehicle.delete', 'garage.manage', function(ctx, p)
    local v = Gr.Vehicle(tostring(p.plate or ''))
    if not v then return false, 'Introuvable.' end
    DB.exec('DELETE FROM pb_vehicles WHERE plate = ?', { v.plate }) DB.exec('DELETE FROM pb_vehicle_state WHERE plate = ?', { v.plate }) DB.exec('DELETE FROM pb_vehicle_keys WHERE plate = ?', { v.plate })
    ctx.audit('serveur', 'garage.delete', v.plate, v, nil)
    ctx.toast = 'Véhicule supprimé.'
    return true
end, { critical = true, confirm = { title = 'Supprimer ce véhicule ?', text = 'Il disparaît définitivement du compte de son propriétaire.', danger = true } })

local settings = Form.Cfg({ ns = 'garage', id = 'settings', title = 'Réglages des véhicules', perm = 'garage.edit', cols = 2, fields = {
    { k = 'any_garage', type = 'toggle', label = "Sortir un véhicule de n'importe quel garage public", default = true },
    { k = 'keep_props', type = 'toggle', label = 'Garder les dégâts, le carburant et la couleur au rangement', default = true },
    { k = 'max_vehicles', type = 'number', label = 'Véhicules maximum par joueur', default = 12, min = 1, max = 200 }, { k = 'fleet_max', type = 'number', label = "Véhicules de service maximum par entreprise", default = 10, min = 0, max = 100 },
    { k = 'service_resale', type = 'number', label = 'Reprise d\'un véhicule de service (% du prix)', default = 50, min = 0, max = 100 },
    { k = 'service_catalog', type = 'rows', label = "Catalogue des véhicules de service (achetés par les patrons au garage, à l'hélipad ou au port)", default = SERVICE, wide = true, maxitems = 60,
      cols = { { k = 'model', label = 'Modèle', maxlen = 32, pattern = '^[%w_]+$', lower = true, required = true }, { k = 'label', label = 'Nom', maxlen = 40, required = true }, { k = 'price', label = 'Prix ($)', type = 'number', min = 0, max = 100000000 } } }, { k = 'plate_price', type = 'number', label = 'Prix d\'une plaque personnalisée ($)', default = 15000, min = 0, max = 10000000 }, { k = 'impound_fee', type = 'number', label = 'Frais de fourrière (avant multiplicateur des amendes)', default = 250, min = 0, max = 1000000 },
    { k = 'impound_delay', type = 'number', label = "Délai avant récupération d'un véhicule « dehors » (minutes)", default = 5, min = 0, max = 240, hint = "Utilisé seulement si le serveur ne peut pas vérifier que le véhicule a disparu (OneSync)." },
    { k = 'store_dist', type = 'number', label = 'Distance pour ranger un véhicule (m)', default = 25, min = 5, max = 100 }, { k = 'use_distance', type = 'number', label = 'Distance pour ouvrir le menu (m)', default = 2.5, min = 1, max = 10, int = false, step = 0.5 },
    { k = 'lock_key', type = 'text', label = 'Touche de verrouillage (par défaut)', default = 'L', maxlen = 12, pattern = '^[%w_]+$' }, { k = 'lock_dist', type = 'number', label = 'Portée du verrouillage (m)', default = 6, min = 2, max = 30 },
    { k = 'blips', type = 'toggle', label = 'Afficher garages et fourrière sur la carte', default = true },
} })

PB.Module({
    id = 'garage', label = 'Garages et véhicules', icon = 'car', group = 'Serveur', order = 96, perm = 'garage.view', hint = 'Garages, fourrière, clés, verrouillage',
    caps = function()
        return PB.Capsify({
            { 'Garages publics et d\'entreprise : sortir / ranger', 'ok', 'Propriétaire vérifié, état suivi par le serveur (au garage / dehors / fourrière).' },
            { 'Fourrière payante', 'ok', "Frais selon le multiplicateur d'amendes de l'économie, versés au compte « État »." },
            { 'Clés partagées et verrouillage', 'ok', 'Doubles de clés par plaque ; le verrouillage est décidé par le serveur.' },
            { 'Dégâts, carburant, couleurs conservés', 'ok', 'Valeurs bornées par le serveur.' },
            { 'Véhicules de ESX / QBCore existants', 'off', 'Seuls les véhicules achetés via les concessions du panel sont gérés.' },
            { 'Tuning détaillé, plaques personnalisées, assurance', 'off', 'Non prévu.' },
            { 'Détection exacte de la disparition d\'un véhicule', 'ok', "Avec OneSync ; sinon un délai réglable s'applique." },
        })
    end,
    doc = "## Garages et véhicules\nLe joueur sort un véhicule au garage, le range en arrivant avec (touche E), peut donner un double de clé et verrouiller (touche L). Un véhicule abandonné se récupère à la **fourrière** contre des frais.\n\nPour tes scripts : `HasKeys(source, plate)`, `ImpoundVehicle(plate, raison)`, `GetVehicleState(plate)`.",
    view = function(ctx)
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                for _, g in ipairs(Gr.Points()) do pts[#pts + 1] = { id = g.id, x = g.x, y = g.y, color = g.kind == 'impound' and '#ff7a7a' or '#6fd3ff', label = g.label, sub = g.kind == 'impound' and 'fourrière' or 'garage' } end
                return { { type = 'map', id = 'gmap', title = 'Garages et fourrières', points = pts, legend = { { color = '#6fd3ff', label = 'Garage' }, { color = '#ff7a7a', label = 'Fourrière' } } } }
            end },
            { id = 'overview', label = "Vue d'ensemble", icon = 'chart', build = function()
                local n = DB.one('SELECT COUNT(*) AS n FROM pb_vehicles')
                local counts = { garage = 0, out = 0, impound = 0 }
                for _, r in ipairs(DB.q("SELECT COALESCE(s.state, 'garage') AS st, COUNT(*) AS n FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate GROUP BY COALESCE(s.state, 'garage')") or {}) do counts[r.st] = r.n end
                return { { type = 'cards', items = {
                    { title = 'Véhicules', value = tostring(n and n.n or 0), icon = 'car', tone = '#6fb4ff', sub = 'Achetés en concession' },
                    { title = 'Au garage', value = tostring(counts.garage), icon = 'building', tone = '#7be0a4', sub = 'Rangés' }, { title = 'Dehors', value = tostring(counts.out), icon = 'activity', tone = '#dfe2e7', sub = 'En ville' },
                    { title = 'En fourrière', value = tostring(counts.impound), icon = 'lock', tone = '#ffb457', sub = ('Frais : %s'):format(money(impoundFee())) } } } }
            end },
            { id = 'points', label = 'Garages et fourrière', icon = 'pin', build = function()
                local list = {}
                for _, g in ipairs(Gr.Points()) do list[#list + 1] = { label = g.label, id = g.id, kind = KIND_LABEL[g.kind] or g.kind, biz = g.biz ~= '' and g.biz or '', on = PB.ToBool(g.enabled) and { text = 'Actif', tone = 'ok' } or { text = 'Inactif', tone = 'off' },
                    actions = ctx.has('garage.edit') and { { action = 'garage.point.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { id = g.id } } } or {} } end
                local blocks = { B.table({ id = 'gp', title = 'Points (' .. #list .. ')', columns = { { k = 'label', label = 'Nom' }, { k = 'id', label = 'Identifiant', type = 'mono' }, { k = 'kind', label = 'Type' }, { k = 'biz', label = 'Entreprise' }, { k = 'on', label = 'État', type = 'badge' } }, rows = list }),
                    B.notice('info', 'Coordonnées par défaut : des lieux connus de Los Santos. Vérifie l\'entrée et la sortie en jeu avant d\'ouvrir.') }
                if ctx.has('garage.edit') then blocks[#blocks + 1] = { type = 'form', id = 'garage.pt', title = 'Ajouter ou modifier un point', desc = 'Même identifiant = modification.', cols = 2, fields = {
                    { k = 'id', type = 'text', label = 'Identifiant', required = true, maxlen = 32, pattern = '^[%w_]+$' }, { k = 'label', type = 'text', label = 'Nom', required = true, maxlen = 48 },
                    { k = 'kind', type = 'select', label = 'Type', opts = { { 'public', 'Garage public' }, { 'impound', 'Fourrière' }, { 'biz', "Garage d'entreprise" }, { 'gang', 'Garage de gang' } } }, { k = 'biz', type = 'text', label = 'Entreprise ou gang (identifiant)', maxlen = 32 },
                    { k = 'coords', type = 'coords', label = 'Entrée (menu)', wide = true }, { k = 'spawn', type = 'coords', label = 'Sortie des véhicules', wide = true }, { k = 'enabled', type = 'toggle', label = 'Actif' }, { k = 'vtype', type = 'select', label = 'Véhicules acceptés', opts = { { 'car', 'Voitures et motos' }, { 'air', 'Aérien (hélicoptères, avions)' }, { 'boat', 'Naval (bateaux)' } } } },
                    values = { id = '', label = '', kind = 'public', vtype = 'car', biz = '', coords = { x = 0, y = 0, z = 0, h = 0 }, spawn = { x = 0, y = 0, z = 0, h = 0 }, enabled = true }, submit = { action = 'garage.point.save', label = 'Enregistrer' } } end
                return blocks
            end },
            { id = 'vehicles', label = 'Véhicules', icon = 'car', build = function()
                local rows = {}
                for _, v in ipairs(DB.q("SELECT v.plate, v.label, v.model, v.license, COALESCE(s.state, 'garage') AS state, p.firstname, p.lastname FROM pb_vehicles v LEFT JOIN pb_vehicle_state s ON s.plate = v.plate LEFT JOIN pb_players p ON p.license = v.license ORDER BY v.id DESC LIMIT 300") or {}) do
                    local acts = {}
                    if ctx.has('garage.manage') then
                        if v.state ~= 'impound' then acts[#acts + 1] = { action = 'garage.vehicle.impound', label = 'Fourrière', icon = 'lock', payload = { plate = v.plate } } end
                        if v.state ~= 'garage' then acts[#acts + 1] = { action = 'garage.vehicle.release', label = 'Rendre au garage', icon = 'refresh', payload = { plate = v.plate } } end
                        acts[#acts + 1] = { action = 'garage.vehicle.delete', label = 'Supprimer', icon = 'trash', danger = true, payload = { plate = v.plate } }
                    end
                    rows[#rows + 1] = { plate = v.plate, label = v.label, who = ((v.firstname or '') .. ' ' .. (v.lastname or '')):gsub('^%s+', ''), state = { text = stateLabel(v), tone = v.state == 'garage' and 'ok' or (v.state == 'impound' and 'warn' or 'off') }, actions = acts }
                end
                return { B.table({ id = 'veh', title = 'Véhicules des joueurs', search = true, columns = { { k = 'plate', label = 'Plaque', type = 'mono' }, { k = 'label', label = 'Modèle' }, { k = 'who', label = 'Propriétaire' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows, empty = 'Aucun véhicule vendu pour le moment.' }) }
            end },
            { id = 'preview', label = 'Aperçu', icon = 'eye', build = function() return { { type = 'gpreview', kind = 'garage', title = 'Garage vu par le joueur', cfg = {} } } end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'garage.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})

PB.SelfTest.Add('garages', function(R)
    for _, g in ipairs(Gr.Points()) do
        R.check(g.x ~= 0 or g.y ~= 0, 'garage ' .. g.id, 'entrée non définie')
        if g.sx == 0 and g.sy == 0 then R.warn('garage ' .. g.id, 'pas de point de sortie : les véhicules sortent à 3 m du point (pose la sortie au Builder)') else R.ok() end
        if g.kind == 'gang' then R.check(G.Tags and G.Tags.GangDefs()[g.biz] ~= nil, 'garage ' .. g.id, "le gang « " .. g.biz .. " » n'existe pas") end
        if g.kind == 'biz' then R.check(G.Biz and G.Biz.Get(g.biz) ~= nil, 'garage ' .. g.id, "l'entreprise « " .. g.biz .. " » n'existe pas") end
    end
    local orphan = DB.one('SELECT COUNT(*) AS n FROM pb_vehicle_state s LEFT JOIN pb_vehicles v ON v.plate = s.plate WHERE v.plate IS NULL')
    R.check(not orphan or orphan.n == 0, 'états de véhicules', 'des états référencent un véhicule supprimé')
    local noPublic = DB.one("SELECT COUNT(*) AS n FROM pb_garages WHERE kind = 'public' AND enabled = 1")
    R.check(noPublic and noPublic.n > 0, 'garages publics', 'aucun garage public actif : les joueurs ne pourront pas sortir leurs véhicules')
end)
