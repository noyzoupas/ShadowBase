-- Tickets : les signalements (/report) deviennent de vraies conversations joueur ↔ staff, avec catégorie, suivi et lien Discord.
-- Le joueur ouvre ses tickets avec /ticket. Le staff répond dans le panel (Tickets), dans le menu F10 (prise en charge, aller voir),
-- ou directement sur Discord : avec le bot du panel, une réponse au message du ticket revient en jeu (« !fermer » le clôt).
-- Sans bot, les tickets partent seulement vers le webhook « Tickets des joueurs ».
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

PB.Migrate('330_tickets', 'Tickets : catégorie, conversation, lien Discord', {
    "ALTER TABLE pb_reports ADD COLUMN category VARCHAR(16) NOT NULL DEFAULT 'aide'",
    "ALTER TABLE pb_reports ADD COLUMN discord_msg VARCHAR(24) NOT NULL DEFAULT ''",
    "ALTER TABLE pb_reports ADD COLUMN updated INT NOT NULL DEFAULT 0",
})
PB.Migrate('331_ticket_msgs', 'Tickets : messages', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_report_msgs (id INT NOT NULL AUTO_INCREMENT, report_id INT NOT NULL, who VARCHAR(8) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', text VARCHAR(500) NOT NULL, at INT NOT NULL, PRIMARY KEY (id), KEY k_rep (report_id))]]))
end)
PB.Migrate('382_ticket_vip', 'Tickets : priorité des VIP', { "ALTER TABLE pb_reports ADD COLUMN vip TINYINT(1) NOT NULL DEFAULT 0" })
PB.Cfg.Define('tickets', { enabled = true, discord_channel = '', poll_secs = 20, max_open = 3, cooldown = 60 })

local T = {}
G.Tickets = T
-- VIP (VIP › Avantages › Reports prioritaires) : ticket marqué, en tête de liste du staff
function T.MarkVip(src, id)
    if not id or not (G.Vip and G.Vip.Is(src)) or PB.Cfg.Get('vip', 'report_prio', true) == false then return false end
    DB.exec("UPDATE pb_reports SET vip = 1, name = LEFT(CONCAT('★ VIP · ', name), 64) WHERE id = ?", { id })
    return true
end
local function cfg(k, d) return PB.Cfg.Get('tickets', k, d) end
local function now() return os.time() end
local function clean(s, n) return PB.Trim(PB.Sanitize(tostring(s or ''):gsub('[%c]', ' '), n)) end
local CATS = { { 'aide', 'Aide / question' }, { 'bug', 'Bug' }, { 'plainte', 'Plainte contre un joueur' }, { 'rembourse', 'Remboursement' }, { 'autre', 'Autre' } }
local CAT = {} for _, c in ipairs(CATS) do CAT[c[1]] = c[2] end
local STATUS = { open = 'Ouvert', claimed = 'Pris en charge', closed = 'Clos' }
T.CATS = CATS

local function playerOf(license) for id, p in pairs(G.Players()) do if p.license == license then return id end end end
local function rpName(src) local i = G.Identity and G.Identity(src) if i and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 64) end return GetPlayerName(src) or ('Joueur ' .. src) end

-- Discord ---------------------------------------------------------------------------------------------------------------------------------------
local D = PB.Discord
local function channel() local c = tostring(cfg('discord_channel', '')) return c:match('^%d+$') and c or nil end
local function botOn() return D and D.BotToken and D.BotToken() ~= nil and channel() ~= nil end
local function embedOf(r, title, text)
    return { title = title, description = text, color = 0x6fb4ff, fields = { { name = 'Ticket', value = '#' .. r.id, inline = true }, { name = 'Catégorie', value = CAT[r.category] or r.category or '—', inline = true }, { name = 'Joueur', value = r.name, inline = true } },
        footer = { text = botOn() and 'Réponds à ce message pour répondre en jeu · « !fermer » pour clore' or 'Réponds en jeu ou dans le panel (Tickets)' } }
end
function T.ToDiscord(r, title, text)
    if botOn() then
        local body = { embeds = { embedOf(r, title, text) }, allowed_mentions = { parse = {} } }
        if r.discord_msg and r.discord_msg ~= '' then body.message_reference = { message_id = r.discord_msg, fail_if_not_exists = false } end
        D.Api('POST', '/channels/' .. channel() .. '/messages', body, function(status, txt)
            if status >= 200 and status < 300 and (r.discord_msg or '') == '' then
                local m = PB.FromJson(txt, nil)
                if m and m.id then DB.exec('UPDATE pb_reports SET discord_msg = ? WHERE id = ?', { tostring(m.id), r.id }) end
            end
        end)
    elseif D and D.Send then
        D.Send('tickets', embedOf(r, title, text))
    end
end

-- Cycle de vie --------------------------------------------------------------------------------------------------------------------------------
function T.Get(id) return DB.one('SELECT * FROM pb_reports WHERE id = ?', { math.floor(tonumber(id) or 0) }) end
function T.AddMsg(id, who, name, text)
    DB.insert('INSERT INTO pb_report_msgs (report_id, who, name, text, at) VALUES (?, ?, ?, ?, ?)', { id, who, tostring(name or ''):sub(1, 64), tostring(text):sub(1, 500), now() })
    DB.exec('UPDATE pb_reports SET updated = ? WHERE id = ?', { now(), id })
end
-- Appelé par /report (staff.lua) ou par la fenêtre /ticket après la création de la ligne
function T.Created(id)
    local r = T.Get(id)
    if not r then return end
    if not DB.one('SELECT id FROM pb_report_msgs WHERE report_id = ? LIMIT 1', { r.id }) then T.AddMsg(r.id, 'player', r.name, r.text) end
    T.ToDiscord(r, 'Nouveau ticket #' .. r.id, r.text)
end
local last = {}
function T.Create(src, category, text)
    local p = G.Get(src)
    if not p then return false, 'Indisponible.' end
    if cfg('enabled', true) == false then return false, 'Les tickets sont désactivés.' end
    text = clean(text, 280)
    if #text < 5 then return false, 'Décris ton problème (au moins quelques mots).' end
    category = CAT[tostring(category)] and tostring(category) or 'aide'
    local t = now()
    if last[src] and t - last[src] < (tonumber(cfg('cooldown', 60)) or 60) then return false, 'Attends un peu avant un nouveau ticket.' end
    local open = DB.one("SELECT COUNT(*) AS n FROM pb_reports WHERE license = ? AND status <> 'closed'", { p.license })
    if open and open.n >= (tonumber(cfg('max_open', 3)) or 3) then return false, ('Tu as déjà %d tickets ouverts.'):format(open.n) end
    last[src] = t
    local id = DB.insert('INSERT INTO pb_reports (license, name, text, status, created, category, updated) VALUES (?, ?, ?, ?, ?, ?, ?)', { p.license, rpName(src), text, 'open', t, category, t })
    local vip = T.MarkVip(src, id)
    T.Created(id)
    for s in pairs(G.Players()) do
        if G.Staff and G.Staff.OnDuty(s) and P.Has(s, 'staff.reports') then G.Notify(s, { type = 'warn', title = (vip and '★ VIP · ' or '') .. 'Nouveau ticket #' .. tostring(id), text = rpName(src) .. ' (' .. CAT[category] .. ') : ' .. text, click = 'reports', duration = 12000 }) end
    end
    return true, id
end
-- Réponse du staff (panel, Discord) : le joueur est prévenu s'il est connecté
function T.StaffReply(id, name, text, via)
    local r = T.Get(id)
    if not r then return false, 'Ticket introuvable.' end
    if r.status == 'closed' then return false, 'Ce ticket est clos.' end
    text = clean(text, 500)
    if text == '' then return false, 'Écris une réponse.' end
    T.AddMsg(r.id, via == 'discord' and 'discord' or 'staff', name, text)
    if r.status == 'open' then DB.exec("UPDATE pb_reports SET status = 'claimed', claimed_by = ? WHERE id = ?", { tostring(name):sub(1, 64), r.id }) end
    local t = playerOf(r.license)
    if t then
        G.Notify(t, { type = 'info', title = 'Réponse du staff · ticket #' .. r.id, text = text:sub(1, 160) .. ' — /ticket pour répondre.', duration = 12000 })
        T.Refresh(t)
    end
    if via ~= 'discord' then T.ToDiscord(r, 'Réponse de ' .. name, text) end
    return true
end
function T.Close(id, name, via)
    local r = T.Get(id)
    if not r or r.status == 'closed' then return false, 'Ticket introuvable ou déjà clos.' end
    DB.exec("UPDATE pb_reports SET status = 'closed', closed_at = ?, claimed_by = ? WHERE id = ?", { now(), tostring(name):sub(1, 64), r.id })
    T.AddMsg(r.id, 'system', name, 'Ticket clos par ' .. name .. '.')
    local t = playerOf(r.license)
    if t then G.Notify(t, { type = 'success', title = 'Ticket #' .. r.id, text = 'Ton ticket a été clos par ' .. name .. '.' }) T.Refresh(t) end
    if via ~= 'discord' then T.ToDiscord(r, 'Ticket clos', 'Clos par ' .. name .. '.') end
    return true
end

-- Réponses venues de Discord (bot) : réponses au message du ticket dans le canal choisi
local lastSeen
function T.Poll()
    if not botOn() then return end
    local path = '/channels/' .. channel() .. '/messages?limit=50' .. (lastSeen and ('&after=' .. lastSeen) or '')
    local list = D.ApiSync('GET', path)
    if type(list) ~= 'table' then return end
    table.sort(list, function(a, b) return #tostring(a.id) < #tostring(b.id) or (#tostring(a.id) == #tostring(b.id) and tostring(a.id) < tostring(b.id)) end)
    local first = lastSeen == nil
    for _, m in ipairs(list) do
        lastSeen = tostring(m.id)
        local ref = m.message_reference and m.message_reference.message_id
        if not first and ref and not (m.author and m.author.bot) then
            local r = DB.one('SELECT id FROM pb_reports WHERE discord_msg = ?', { tostring(ref) })
            if r then
                local who = (m.author and (m.author.global_name or m.author.username) or 'Discord') .. ' (Discord)'
                local txt = tostring(m.content or '')
                if txt:lower():match('^%s*!fermer') then T.Close(r.id, who, 'discord') else T.StaffReply(r.id, who, txt, 'discord') end
            end
        end
    end
end
CreateThread(function()
    while true do
        Wait(math.max(10, tonumber(cfg('poll_secs', 20)) or 20) * 1000)
        pcall(T.Poll)
    end
end)

-- Fenêtre joueur (/ticket) : même moteur que la banque ------------------------------------------------------------------------------------------
local sessions = {}
local PAGES = {}
local function stamp(t) return os.date('%d/%m %H:%M', tonumber(t) or 0) end
PAGES.home = function(src)
    local p = G.Get(src)
    local rows = {}
    for _, r in ipairs(DB.q('SELECT * FROM pb_reports WHERE license = ? ORDER BY (status = ?) ASC, id DESC LIMIT 20', { p.license, 'closed' }) or {}) do
        rows[#rows + 1] = { ref = '#' .. r.id, cat = CAT[r.category] or r.category or '', text = tostring(r.text):sub(1, 60), status = STATUS[r.status] or r.status, at = stamp(r.updated ~= 0 and r.updated or r.created),
            actions = { { act = 'open', label = 'Ouvrir', payload = { id = r.id }, primary = r.status ~= 'closed' } } }
    end
    return { { type = 'table', title = 'Mes tickets', columns = { { k = 'ref', label = 'N°' }, { k = 'cat', label = 'Catégorie' }, { k = 'text', label = 'Sujet' }, { k = 'status', label = 'État' }, { k = 'at', label = 'Dernière activité' } }, rows = rows, empty = "Aucun ticket. Besoin d'aide ? Écris au staff ci-dessous." },
        { type = 'form', id = 'new', title = 'Nouveau ticket', desc = "Le staff te répond ici ; tu es prévenu dès qu'il y a une réponse.", fields = { { k = 'cat', type = 'select', label = 'Catégorie', opts = CATS }, { k = 'text', type = 'text', label = 'Ton message', maxlen = 280 } }, submit = { act = 'create', label = 'Envoyer au staff' } } }, 'Tickets'
end
PAGES.thread = function(src, s)
    local p = G.Get(src)
    local r = s.id and T.Get(s.id)
    if not r or r.license ~= p.license then return { { type = 'notice', text = 'Choisis un ticket.' } }, 'Ticket' end
    local rows = {}
    for _, m in ipairs(DB.q('SELECT * FROM pb_report_msgs WHERE report_id = ? ORDER BY id LIMIT 80', { r.id }) or {}) do
        rows[#rows + 1] = { who = m.who == 'player' and 'Toi' or m.who == 'system' and 'Info' or ('Staff · ' .. m.name), text = m.text, at = stamp(m.at) }
    end
    local blocks = { { type = 'hero', title = 'Ticket #' .. r.id, sub = (CAT[r.category] or '') .. ' · ' .. (STATUS[r.status] or r.status), tone = '#6fb4ff', chips = { { 'Ouvert le', stamp(r.created) }, { 'Suivi par', r.claimed_by ~= '' and r.claimed_by or '—' } } },
        { type = 'table', title = 'Conversation', columns = { { k = 'who', label = 'De' }, { k = 'text', label = 'Message' }, { k = 'at', label = 'Date' } }, rows = rows, empty = 'Aucun message.' } }
    if r.status ~= 'closed' then
        blocks[#blocks + 1] = { type = 'form', id = 'reply', title = 'Répondre', fields = { { k = 'text', type = 'text', label = 'Message', maxlen = 280 } }, submit = { act = 'reply', label = 'Envoyer' } }
        blocks[#blocks + 1] = { type = 'actions', items = { { act = 'close', label = 'Mon problème est réglé : clore le ticket' }, { act = 'back', label = 'Retour à mes tickets' } } }
    else blocks[#blocks + 1] = { type = 'actions', items = { { act = 'back', label = 'Retour à mes tickets' } } } end
    return blocks, 'Ticket #' .. r.id
end
local ACT = {}
ACT.create = function(s, src, p) local ok, id = T.Create(src, p.cat, p.text) if not ok then return false, id end s.id = id return true, 'Ticket #' .. id .. ' envoyé au staff.', 'thread' end
ACT.open = function(s, src, p) s.id = math.floor(tonumber(p.id) or 0) return true, nil, 'thread' end
ACT.back = function(s) s.id = nil return true, nil, 'home' end
ACT.reply = function(s, src, p)
    local r = s.id and T.Get(s.id)
    local pl = G.Get(src)
    if not r or r.license ~= pl.license then return false, 'Ticket introuvable.' end
    if r.status == 'closed' then return false, 'Ce ticket est clos.' end
    local text = clean(p.text, 280)
    if text == '' then return false, 'Écris un message.' end
    T.AddMsg(r.id, 'player', r.name, text)
    T.ToDiscord(r, 'Réponse du joueur', text)
    if r.claimed_by ~= '' then
        for st in pairs(G.Players()) do if PB.Actor(st).name:sub(1, 64) == r.claimed_by then G.Notify(st, { type = 'info', title = 'Ticket #' .. r.id, text = r.name .. ' : ' .. text:sub(1, 120) }) end end
    end
    return true, 'Message envoyé.', 'thread'
end
ACT.close = function(s, src)
    local r = s.id and T.Get(s.id)
    if not r or r.license ~= G.Get(src).license then return false, 'Ticket introuvable.' end
    local ok, why = T.Close(r.id, r.name)
    return ok, ok and 'Ticket clos. Merci !' or why, 'thread'
end

local function frame(src)
    local p = G.Get(src)
    return { name = rpName(src), id = (G.UidOf(src) or src), tone = '#6fb4ff', brand = 'Support du serveur', cash = p.row.cash, bank = p.row.bank, nav = { { id = 'home', label = 'Mes tickets', icon = 'help', group = 'Support' } } }
end
local function page(src, name)
    local fn = PAGES[name or 'home']
    if not fn or not sessions[src] then return nil end
    local blocks, title = fn(src, sessions[src])
    return { page = name or 'home', title = title, blocks = blocks }
end
local function ui(src, ev, extra) local m = { ev = ev, frame = frame(src) } for k, v in pairs(extra or {}) do m[k] = v end TriggerClientEvent('pb:g:ticket:ui', src, PB.Json(m)) end
function T.Refresh(src) local s = sessions[src] if s then ui(src, 'page', { page = page(src, s.id and 'thread' or 'home') }) end end
local lastUi = {}
local function throttle(src, ms) local t = GetGameTimer() if lastUi[src] and t - lastUi[src] < ms then return false end lastUi[src] = t return true end

RegisterCommand('ticket', function(src)
    if src == 0 or not G.Get(src) or not throttle(src, 400) then return end
    if cfg('enabled', true) == false then G.Notify(src, { type = 'warn', text = 'Les tickets sont désactivés.' }) return end
    sessions[src] = {}
    ui(src, 'open', { page = page(src, 'home') })
end, false)
RegisterNetEvent('pb:g:ticket:page', function(name)
    local src = source
    if not sessions[src] or not throttle(src, 150) then return end
    ui(src, 'page', { page = page(src, tostring(name)) })
end)
RegisterNetEvent('pb:g:ticket:act', function(name, payload, pgname)
    local src = source
    local s = sessions[src]
    if not s or not throttle(src, 300) then return end
    local fn = ACT[tostring(name)]
    local ok, msg, go = false, 'Action inconnue.', nil
    if fn then ok, msg, go = fn(s, src, type(payload) == 'table' and payload or {}) end
    ui(src, 'result', { ok = ok and true or false, msg = msg, page = page(src, go or tostring(pgname or 'home')) })
end)
RegisterNetEvent('pb:g:ticket:close', function() sessions[source] = nil end)
AddEventHandler('playerDropped', function() sessions[source] = nil last[source] = nil lastUi[source] = nil end)

-- Panel -----------------------------------------------------------------------------------------------------------------------------------------
PB.Action('tickets.reply', 'staff.reports', function(ctx, p)
    local v = type(p.values) == 'table' and p.values or p
    local ok, why = T.StaffReply(p.id, ctx.actor and ctx.actor.name or 'Staff', v.text)
    if not ok then return false, why end
    ctx.audit('staff', 'ticket.reply', '#' .. tostring(p.id), nil, nil)
    ctx.toast = 'Réponse envoyée au joueur.'
    return true
end)
PB.Action('tickets.close', 'staff.reports', function(ctx, p)
    local ok, why = T.Close(p.id, ctx.actor and ctx.actor.name or 'Staff')
    if not ok then return false, why end
    ctx.audit('staff', 'ticket.close', '#' .. tostring(p.id), nil, nil)
    ctx.toast = 'Ticket clos.'
    return true
end)
PB.Action('tickets.reopen', 'staff.reports', function(ctx, p)
    local id = math.floor(tonumber(p.id) or 0)
    if DB.exec("UPDATE pb_reports SET status = 'open', closed_at = 0 WHERE id = ? AND status = 'closed'", { id }) == 0 then return false, 'Ticket introuvable ou déjà ouvert.' end
    T.AddMsg(id, 'system', ctx.actor and ctx.actor.name or 'Staff', 'Ticket rouvert.')
    ctx.toast = 'Ticket rouvert.'
    return true
end)

local settings = PB.Form.Cfg({ ns = 'tickets', id = 'settings', title = 'Réglages des tickets', perm = 'discord.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Tickets joueurs (/ticket et /report)', default = true },
    { k = 'max_open', type = 'number', label = 'Tickets ouverts maximum par joueur', default = 3, min = 1, max = 20 },
    { k = 'cooldown', type = 'number', label = 'Délai entre deux tickets (secondes)', default = 60, min = 0, max = 3600 },
    { k = 'discord_channel', type = 'text', label = 'Canal Discord des tickets (identifiant, avec le bot)', default = '', maxlen = 24, pattern = '^%d*$',
      hint = "Avec le bot du panel (module Discord) : le ticket est posté dans ce canal et une RÉPONSE à son message revient en jeu. Sans bot : renseigne le webhook « Tickets des joueurs » (envoi seulement)." },
    { k = 'poll_secs', type = 'number', label = 'Lecture des réponses Discord toutes les (secondes)', default = 20, min = 10, max = 600 },
} })

PB.Module({
    id = 'tickets', label = 'Tickets', icon = 'help', group = 'Serveur', order = 96, perm = 'staff.reports', hint = 'Demandes des joueurs, réponses, Discord',
    caps = function()
        return PB.Capsify({
            { 'Tickets joueurs (/ticket, /report)', 'ok', 'Catégorie, conversation, état, notification du joueur à chaque réponse.' },
            { 'Envoi vers Discord', (botOn() or (D and D.WebhookMask and D.WebhookMask('tickets'))) and 'ok' or 'off', botOn() and 'Par le bot, dans le canal choisi.' or 'Renseigne le webhook « Tickets des joueurs » ou le bot + le canal.' },
            { 'Réponses depuis Discord', botOn() and 'ok' or 'off', botOn() and 'Réponds au message du ticket dans Discord ; « !fermer » pour le clore. Toute personne qui peut écrire dans ce canal répond au nom du staff : réserve-le au staff.' or 'Nécessite le bot du panel et l\'identifiant du canal.' },
        })
    end,
    doc = "## Tickets\nUn joueur écrit au staff avec **/ticket** (fenêtre avec catégorie et suivi) ou **/report message**. Le staff répond ici, prend en charge et va voir le joueur depuis le menu F10, ou répond **depuis Discord** si le bot est branché.",
    view = function(ctx)
        return { tabs = {
            { id = 'list', label = 'Tickets', icon = 'help', build = function(_, params)
                params = params or {}
                local closed = params.closed == '1'
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_reports WHERE ' .. (closed and "status = 'closed'" or "status <> 'closed'") .. ' ORDER BY ' .. (closed and '' or 'vip DESC, ') .. 'id DESC LIMIT 100') or {}) do
                    rows[#rows + 1] = { ref = '#' .. r.id, at = tonumber(r.updated) ~= 0 and r.updated or r.created, name = r.name, cat = CAT[r.category] or r.category or '', text = r.text, status = { text = STATUS[r.status] or r.status, tone = r.status == 'open' and 'warn' or r.status == 'claimed' and 'info' or 'off' }, by = r.claimed_by,
                        actions = { { nav = { tab = 'thread', params = { id = r.id } }, label = 'Ouvrir', icon = 'eye' } } }
                end
                return { B.actions({ { nav = { tab = 'list', params = { closed = closed and '0' or '1' } }, label = closed and 'Voir les tickets ouverts' or 'Voir les tickets clos', icon = 'list' } }),
                    B.table({ id = 'tk', title = closed and 'Tickets clos' or 'Tickets ouverts', columns = { { k = 'ref', label = 'N°' }, { k = 'at', label = 'Activité', type = 'date' }, { k = 'name', label = 'Joueur' }, { k = 'cat', label = 'Catégorie' }, { k = 'text', label = 'Sujet' }, { k = 'status', label = 'État', type = 'badge' }, { k = 'by', label = 'Suivi par' } }, rows = rows, empty = 'Aucun ticket.' }) }
            end },
            { id = 'thread', label = 'Conversation', icon = 'chat', build = function(_, params)
                local r = params and T.Get(params.id)
                if not r then return { B.notice('info', 'Ouvre un ticket depuis la liste.') } end
                local rows = {}
                for _, m in ipairs(DB.q('SELECT * FROM pb_report_msgs WHERE report_id = ? ORDER BY id', { r.id }) or {}) do
                    rows[#rows + 1] = { at = m.at, who = m.who == 'player' and (r.name .. ' (joueur)') or m.who == 'system' and 'Info' or m.name, text = m.text }
                end
                local blocks = { B.kv('Ticket #' .. r.id, { { 'Joueur', r.name }, { 'Licence', r.license }, { 'Catégorie', CAT[r.category] or r.category or '' }, { 'État', STATUS[r.status] or r.status }, { 'Suivi par', r.claimed_by ~= '' and r.claimed_by or '—' } }),
                    B.table({ id = 'tm', title = 'Conversation', columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'who', label = 'De' }, { k = 'text', label = 'Message' } }, rows = rows, empty = 'Aucun message.' }) }
                if r.status ~= 'closed' then
                    blocks[#blocks + 1] = { type = 'form', id = 'tickets.reply', title = 'Répondre au joueur', cols = 1, fields = { { k = 'text', type = 'area', label = 'Réponse', required = true, rows = 3, maxlen = 500 } }, values = { text = '' }, submit = { action = 'tickets.reply', payload = { id = r.id }, label = 'Envoyer' } }
                    blocks[#blocks + 1] = B.actions({ { action = 'tickets.close', payload = { id = r.id }, label = 'Clore le ticket', icon = 'check' } })
                else blocks[#blocks + 1] = B.actions({ { action = 'tickets.reopen', payload = { id = r.id }, label = 'Rouvrir', icon = 'refresh' } }) end
                return blocks
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'discord.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})
