-- Catalogue d'entreprises prêtes à l'emploi : catégories, modèles (grades, salaires, droits, blip, position du siège), installation sans écrasement,
-- recherche tolérante d'une entreprise par son nom (« police » retrouve « Police de Los Santos »), deuxième emploi, points d'entreprise (service, patron, siège).
-- Tout est modifiable ensuite dans Entreprises › Modifier : le catalogue ne fait que donner un point de départ.

local B, P, Form = PB.B, PB.Perm, PB.Form
local G, DB = PB.G, PB.DB
local Biz = G.Biz
local C = {}
G.BizCat = C

local function now() return os.time() end

-- Catégories ------------------------------------------------------------------------------------------------------------------------------
C.Cats = {
    { id = 'public', label = 'Services publics', icon = 'shield', color = '#6fb4ff', desc = 'Police, secours, justice, administration.' },
    { id = 'sante', label = 'Santé', icon = 'heart', color = '#ff6b7d', desc = 'Hôpitaux, cliniques, pharmacies.' },
    { id = 'auto', label = 'Automobile', icon = 'engine', color = '#ffb457', desc = 'Garages, concessions, taxis, dépannage.' },
    { id = 'resto', label = 'Restauration et bars', icon = 'food', color = '#ff9d57', desc = 'Restaurants, fast-foods, bars, boîtes de nuit.' },
    { id = 'commerce', label = 'Commerce', icon = 'bag', color = '#7be0a4', desc = 'Magasins, boutiques, artisans.' },
    { id = 'services', label = 'Services et immobilier', icon = 'briefcase', color = '#b58cff', desc = 'Banque, assurance, avocats, sécurité privée.' },
    { id = 'medias', label = 'Médias et culture', icon = 'chat', color = '#5fd4f4', desc = 'Presse, radio, télévision, studios.' },
    { id = 'loisirs', label = 'Loisirs', icon = 'star', color = '#f2c14e', desc = 'Casino, sport, cinéma, golf.' },
    { id = 'industrie', label = 'Transport et travaux', icon = 'box', color = '#dfe2e7', desc = 'Livraison, BTP, mines, agriculture, pêche.' },
    { id = 'facade', label = 'Couvertures et façades', icon = 'lock', color = '#8e95a1', desc = 'Commerces utiles aux activités illégales (blanchiment, recel).' },
}
local CATBY = {}
for _, c in ipairs(C.Cats) do CATBY[c.id] = c end
C.CatBy = CATBY

-- Modèles -----------------------------------------------------------------------------------------------------------------------------------
-- key, label, cat, kind (police|ems|garage|generic : décide des droits propres au métier), icon, grades, salaire de départ / du patron, blip { sprite, couleur }, position du siège
-- core = installé au premier lancement du serveur.
local L = {}
local function add(key, label, cat, kind, icon, grades, pay, blip, pos, desc, core)
    L[#L + 1] = { key = key, label = label, cat = cat, kind = kind, icon = icon, grades = grades, pay = pay, blip = blip, pos = pos, desc = desc, core = core }
end
local G3 = { 'Employé', 'Gérant', 'Patron' }
local G4 = { 'Apprenti', 'Employé', 'Responsable', 'Patron' }
local G5 = { 'Stagiaire', 'Employé', 'Chef d\'équipe', 'Directeur', 'Patron' }

-- Services publics
add('lspd', 'Police de Los Santos', 'public', 'police', 'shield', { 'Cadet', 'Officier', 'Sergent', 'Lieutenant', 'Capitaine', 'Chef de la police' }, { 250, 1100 }, { 60, 29 }, { 441.0, -981.0, 30.7 }, "Maintien de l'ordre : amendes, dossiers, caisse du commissariat.", true)
add('sheriff', 'Shérif du comté de Blaine', 'public', 'police', 'shield', { 'Deputy stagiaire', 'Deputy', 'Sergent', 'Lieutenant', 'Shérif adjoint', 'Shérif' }, { 250, 1100 }, { 60, 31 }, { 1853.0, 3689.0, 34.2 }, 'Bureau du shérif du comté.', true)
add('rangers', 'Garde forestiers', 'public', 'police', 'shield', { 'Garde', 'Garde confirmé', 'Chef de secteur', 'Directeur' }, { 250, 800 }, { 60, 25 }, nil, 'Parcs nationaux, chasse et pêche.')
add('fib', 'Agence fédérale (FIB)', 'public', 'police', 'shield', { 'Agent stagiaire', 'Agent', 'Agent spécial', 'Superviseur', 'Directeur adjoint', 'Directeur' }, { 400, 1500 }, { 60, 3 }, { 136.0, -762.0, 45.8 }, 'Enquêtes fédérales.')
add('prison', 'Administration pénitentiaire', 'public', 'police', 'lock', { 'Surveillant', 'Surveillant chef', 'Lieutenant', 'Directeur' }, { 300, 900 }, { 188, 1 }, { 1845.0, 2585.0, 45.7 }, 'Gardiens de la prison de Bolingbroke.')
add('douane', 'Douanes', 'public', 'police', 'shield', { 'Agent', 'Contrôleur', 'Inspecteur', 'Directeur' }, { 300, 900 }, { 60, 5 }, nil, 'Contrôles aux frontières, port et aéroport.')
add('ems', 'Secours de Los Santos', 'public', 'ems', 'heart', { 'Stagiaire', 'Ambulancier', 'Infirmier', 'Médecin', 'Chef de service', 'Directeur' }, { 230, 1000 }, { 61, 1 }, { 311.0, -593.0, 43.3 }, 'Soins, réanimation et facturation des interventions.', true)
add('fire', 'Pompiers', 'public', 'ems', 'heart', { 'Sapeur', 'Caporal', 'Sergent', 'Lieutenant', 'Capitaine', 'Chef de caserne' }, { 250, 950 }, { 436, 1 }, { 199.8, -1643.4, 29.8 }, 'Incendies et secours à personne.', true)
add('justice', 'Tribunal et justice', 'public', 'generic', 'file', { 'Greffier', 'Avocat commis', 'Procureur', 'Juge', 'Président du tribunal' }, { 350, 1000 }, { 419, 3 }, { 232.5, -411.0, 48.1 }, 'Audiences, jugements, greffe.')
add('mairie', 'Mairie et gouvernement', 'public', 'generic', 'building', { 'Agent d\'accueil', 'Secrétaire', 'Conseiller', 'Adjoint', 'Maire' }, { 300, 1200 }, { 419, 2 }, { -544.9, -204.4, 38.2 }, 'Administration de la ville, état civil, permis.', true)
add('dmv', 'Auto-école et permis', 'public', 'generic', 'key', { 'Moniteur', 'Examinateur', 'Directeur' }, { 250, 600 }, { 225, 3 }, { 227.0, -1394.0, 30.5 }, 'Code, conduite et délivrance des permis.')
add('urbanisme', 'Urbanisme et travaux publics', 'public', 'generic', 'building', { 'Ouvrier', 'Chef de chantier', 'Ingénieur', 'Directeur' }, { 250, 800 }, nil, nil, 'Voirie, chantiers de la ville.')

-- Santé
add('clinic', 'Clinique privée', 'sante', 'ems', 'heart', G4, { 280, 900 }, { 61, 2 }, nil, 'Consultations et soins privés.')
add('pharmacy', 'Pharmacie', 'sante', 'generic', 'heart', G3, { 220, 600 }, { 51, 2 }, nil, 'Médicaments et parapharmacie.')
add('vet', 'Vétérinaire', 'sante', 'ems', 'paw', G3, { 250, 700 }, { 273, 2 }, nil, 'Soins aux animaux.')
add('psy', 'Cabinet de psychologie', 'sante', 'generic', 'chat', { 'Assistant', 'Psychologue', 'Directeur' }, { 280, 700 }, nil, nil, 'Suivi psychologique.')
add('dentist', 'Cabinet dentaire', 'sante', 'generic', 'heart', { 'Assistant', 'Dentiste', 'Directeur' }, { 280, 750 }, nil, nil, 'Soins dentaires.')
add('ambulance_priv', 'Ambulances privées', 'sante', 'ems', 'heart', G4, { 250, 700 }, { 61, 3 }, nil, 'Transport sanitaire privé.')

-- Automobile
add('mecano', 'Garage Los Santos Customs', 'auto', 'garage', 'engine', { 'Apprenti', 'Mécanicien', "Chef d'atelier", 'Patron' }, { 200, 700 }, { 446, 47 }, { -347.3, -133.0, 39.0 }, 'Réparations, dépannage et facturation des clients.', true)
add('beekers', "Beeker's Garage", 'auto', 'garage', 'engine', { 'Apprenti', 'Mécanicien', "Chef d'atelier", 'Patron' }, { 200, 700 }, { 446, 47 }, { 112.0, 6608.0, 31.9 }, 'Garage de Paleto Bay.')
add('hayes', "Hayes Auto", 'auto', 'garage', 'engine', G4, { 200, 700 }, { 446, 47 }, { -1423.0, -447.0, 35.9 }, 'Garage de Del Perro.')
add('autoexotic', 'Auto Exotic', 'auto', 'garage', 'engine', { 'Apprenti', 'Mécanicien', "Chef d'atelier", 'Patron' }, { 200, 700 }, { 446, 5 }, nil, 'Garage mécanique : réparations, améliorations, dépannage et facturation.')
add('bodyshop', 'Carrosserie', 'auto', 'garage', 'engine', G4, { 200, 700 }, { 446, 47 }, nil, 'Peinture et carrosserie.')
add('towing', 'Dépannage et fourrière', 'auto', 'garage', 'engine', G3, { 200, 600 }, { 477, 47 }, { 408.0, -1624.0, 29.3 }, 'Remorquage et mise en fourrière.')
add('cardealer', 'Concessionnaire', 'auto', 'generic', 'engine', { 'Vendeur', 'Vendeur confirmé', 'Responsable', 'Patron' }, { 250, 750 }, { 225, 3 }, { -56.8, -1097.0, 26.4 }, 'Vente de véhicules neufs et occasions.', true)
add('luxurycars', 'Concession de luxe', 'auto', 'generic', 'engine', { 'Vendeur', 'Conseiller', 'Responsable', 'Patron' }, { 300, 900 }, { 225, 5 }, nil, 'Véhicules haut de gamme.')
add('bikes', 'Concession motos', 'auto', 'generic', 'engine', G4, { 220, 650 }, { 226, 3 }, nil, 'Motos et scooters.')
add('rental', 'Location de véhicules', 'auto', 'generic', 'key', G3, { 200, 550 }, { 225, 25 }, nil, 'Location courte durée.')
add('taxi', 'Taxi Downtown Cab', 'auto', 'generic', 'engine', { 'Chauffeur', 'Chauffeur confirmé', 'Patron' }, { 200, 500 }, { 198, 5 }, { 903.0, -170.0, 74.1 }, 'Transport de passagers dans toute la ville.', true)
add('limo', 'Limousines et VTC', 'auto', 'generic', 'engine', G3, { 250, 650 }, { 198, 0 }, nil, 'Chauffeurs privés.')
add('carwash', 'Station de lavage', 'auto', 'generic', 'engine', G3, { 180, 450 }, { 100, 3 }, { 25.4, -1391.9, 29.3 }, 'Lavage de véhicules.')
add('gasstation', 'Station-service', 'auto', 'generic', 'engine', G3, { 180, 450 }, { 361, 1 }, nil, 'Carburant et boutique.')
add('tires', 'Pneus et vidange', 'auto', 'garage', 'engine', G3, { 200, 550 }, { 446, 47 }, nil, 'Entretien rapide.')
add('driving', 'École de conduite', 'auto', 'generic', 'key', G3, { 220, 550 }, nil, nil, 'Permis moto, voiture et poids lourds.')

-- Restauration et bars
add('burgershot', 'Burger Shot', 'resto', 'generic', 'food', G3, { 160, 450 }, { 106, 17 }, { -1192.0, -884.0, 13.9 }, 'Restauration rapide : caisse et factures.', true)
add('bean', 'Bean Machine', 'resto', 'generic', 'food', G3, { 160, 450 }, { 106, 21 }, { 280.0, -963.0, 29.4 }, 'Café et pâtisseries.', true)
add('bahamas', 'Bahama Mamas', 'resto', 'generic', 'food', { 'Serveur', 'Barman', 'Responsable', 'Patron' }, { 160, 550 }, { 93, 27 }, { -1388.0, -586.0, 30.2 }, 'Boîte de nuit : bar, entrées et soirées.', true)
add('unicorn', 'Vanilla Unicorn', 'resto', 'generic', 'food', { 'Serveur', 'Danseur', 'Responsable', 'Patron' }, { 160, 550 }, { 121, 8 }, { 129.2, -1299.3, 29.2 }, 'Club de nuit.', true)
add('tequilala', 'Tequi-la-la', 'resto', 'generic', 'food', G4, { 160, 500 }, { 93, 46 }, { -565.2, 273.0, 83.0 }, 'Bar de Vinewood.')
add('pizzeria', 'Pizzeria', 'resto', 'generic', 'food', G3, { 160, 450 }, { 267, 2 }, nil, 'Pizzas sur place et à emporter.')
add('restaurant', 'Restaurant gastronomique', 'resto', 'generic', 'food', G5, { 180, 600 }, { 106, 46 }, nil, 'Cuisine soignée.')
add('sushi', 'Restaurant asiatique', 'resto', 'generic', 'food', G3, { 160, 450 }, { 106, 3 }, nil, 'Sushis et cuisine asiatique.')
add('bakery', 'Boulangerie', 'resto', 'generic', 'food', G3, { 160, 400 }, { 106, 17 }, nil, 'Pain et viennoiseries.')
add('icecream', 'Glacier', 'resto', 'generic', 'food', G3, { 150, 380 }, { 106, 5 }, nil, 'Glaces artisanales.')
add('foodtruck', 'Food truck', 'resto', 'generic', 'food', { 'Aide', 'Cuisinier', 'Patron' }, { 160, 450 }, nil, nil, 'Restauration ambulante.')
add('pub', 'Pub', 'resto', 'generic', 'food', G4, { 160, 480 }, { 93, 17 }, nil, 'Bière et ambiance.')
add('nightclub', 'Discothèque', 'resto', 'generic', 'food', { 'Serveur', 'Barman', 'DJ', 'Responsable', 'Patron' }, { 170, 620 }, { 614, 27 }, nil, 'Grande boîte de nuit.')
-- Galaxy : boîte de nuit avec ses agents de sécurité (droit « security » : palpation, contrôle à l'entrée, bracelets, interdits, expulsion)
add('galaxy', 'Galaxy Club', 'resto', 'generic', 'star', { 'Serveur', 'Barman', 'Agent de sécurité', 'DJ', 'Chef de la sécurité', 'Responsable', 'Patron' }, { 180, 750 }, { 614, 83 }, nil,
    'Boîte de nuit : bar, entrées, carré VIP et agents de sécurité.')
L[#L].gperms = { 'invoice', 'invoice', 'invoice,security', 'invoice', 'invoice,security', 'invoice,security,hire,fire,promote,vault', '' }
add('vineyard', 'Vignoble', 'resto', 'generic', 'food', G4, { 180, 520 }, { 85, 27 }, { -1888.0, 2051.0, 140.9 }, 'Vin, dégustations, vendanges.')
add('brewery', 'Brasserie artisanale', 'resto', 'generic', 'food', G4, { 180, 520 }, nil, nil, 'Bière brassée sur place.')
add('catering', 'Traiteur', 'resto', 'generic', 'food', G3, { 170, 480 }, nil, nil, 'Buffets et réceptions.')
add('cafe', 'Café du coin', 'resto', 'generic', 'food', G3, { 150, 400 }, { 106, 21 }, nil, 'Petit café de quartier.')

-- Commerce
add('mart', 'Épicerie de quartier', 'commerce', 'generic', 'bag', G3, { 160, 420 }, { 52, 2 }, nil, 'Épicerie et dépannage.')
add('supermarket', 'Supermarché', 'commerce', 'generic', 'bag', G5, { 180, 520 }, { 52, 2 }, nil, 'Grande surface.')
add('gunshop', 'Armurerie légale', 'commerce', 'generic', 'shield', { 'Vendeur', 'Armurier', 'Patron' }, { 250, 700 }, { 110, 1 }, nil, 'Armes légales avec permis.')
add('clothes', 'Magasin de vêtements', 'commerce', 'generic', 'hanger', G3, { 160, 450 }, { 73, 47 }, nil, 'Prêt-à-porter.')
add('jewelry', 'Bijouterie', 'commerce', 'generic', 'star', { 'Vendeur', 'Gemmologue', 'Patron' }, { 220, 650 }, { 617, 5 }, { -622.0, -230.0, 38.1 }, 'Bijoux et montres.')
add('florist', 'Fleuriste', 'commerce', 'generic', 'gift', G3, { 150, 380 }, nil, nil, 'Fleurs et bouquets.')
add('hardware', 'Quincaillerie', 'commerce', 'generic', 'box', G3, { 170, 450 }, { 402, 17 }, { 46.0, -1749.3, 29.6 }, 'Outils et matériel.')
add('tobacco', 'Bureau de tabac', 'commerce', 'generic', 'bag', G3, { 160, 400 }, nil, nil, 'Tabac, presse, jeux.')
add('books', 'Librairie', 'commerce', 'generic', 'book', G3, { 150, 380 }, nil, nil, 'Livres et papeterie.')
add('electronics', 'Magasin d\'électronique', 'commerce', 'generic', 'tablet', G3, { 180, 500 }, nil, nil, 'Téléphones, ordinateurs, consoles.')
add('barber', 'Coiffeur et barbier', 'commerce', 'generic', 'users', G3, { 170, 420 }, { 71, 4 }, { -814.3, -183.8, 37.6 }, 'Coupes et soins.')
add('tattoo', 'Salon de tatouage', 'commerce', 'generic', 'star', G3, { 180, 500 }, { 75, 1 }, { 322.1, 180.4, 103.6 }, 'Tatouages.')
add('petshop', 'Animalerie', 'commerce', 'generic', 'paw', G3, { 160, 420 }, nil, nil, 'Animaux et accessoires.')
add('optician', 'Opticien', 'commerce', 'generic', 'eye', G3, { 180, 480 }, nil, nil, 'Lunettes et lentilles.')
add('furniture', 'Magasin de meubles', 'commerce', 'generic', 'box', G3, { 170, 450 }, nil, nil, 'Mobilier et décoration.')
add('pawn', 'Prêteur sur gages', 'commerce', 'generic', 'coins', G3, { 170, 500 }, { 431, 5 }, nil, "Achat et revente d'objets.")
add('antiques', 'Antiquaire', 'commerce', 'generic', 'star', G3, { 170, 500 }, nil, nil, 'Objets anciens.')
add('sportshop', 'Magasin de sport', 'commerce', 'generic', 'bolt', G3, { 170, 450 }, nil, nil, 'Équipement sportif.')

-- Services et immobilier
add('realestate', 'Agence immobilière', 'services', 'generic', 'building', { 'Agent', 'Agent senior', 'Directeur' }, { 250, 650 }, { 374, 2 }, nil, 'Ventes et locations de logements.')
add('bank', 'Banque privée', 'services', 'generic', 'coins', { 'Conseiller', 'Gestionnaire', 'Directeur' }, { 300, 700 }, { 108, 2 }, { -66.0, -802.0, 44.2 }, 'Employés de banque.')
add('insurance', 'Assurances', 'services', 'generic', 'file', G3, { 250, 650 }, nil, nil, 'Contrats et sinistres.')
add('lawyers', 'Cabinet d\'avocats', 'services', 'generic', 'file', { 'Stagiaire', 'Avocat', 'Associé', 'Patron' }, { 350, 900 }, { 419, 3 }, nil, 'Défense et conseil juridique.')
add('notary', 'Notaire', 'services', 'generic', 'file', { 'Clerc', 'Notaire', 'Patron' }, { 300, 800 }, nil, nil, 'Actes et successions.')
add('pi', 'Détective privé', 'services', 'generic', 'eye', { 'Enquêteur', 'Détective', 'Patron' }, { 250, 650 }, nil, nil, 'Enquêtes privées.')
add('security', 'Sécurité privée', 'services', 'generic', 'shield', { 'Agent', 'Chef de poste', 'Responsable', 'Patron' }, { 250, 650 }, { 60, 4 }, nil, 'Gardiennage et protection.')
add('interim', "Agence d'intérim", 'services', 'generic', 'users', G3, { 200, 500 }, nil, nil, 'Placement de personnel.')
add('accounting', 'Cabinet comptable', 'services', 'generic', 'coins', G3, { 250, 650 }, nil, nil, 'Comptabilité et paie.')
add('coworking', 'Espace de coworking', 'services', 'generic', 'briefcase', G3, { 200, 500 }, nil, nil, 'Bureaux partagés.')
add('cleaning', 'Entreprise de nettoyage', 'services', 'generic', 'box', G3, { 180, 450 }, nil, nil, 'Ménage et entretien.')

-- Médias et culture
add('weazel', 'Weazel News', 'medias', 'generic', 'chat', { 'Stagiaire', 'Reporter', 'Présentateur', 'Rédacteur en chef' }, { 180, 600 }, { 184, 1 }, { -598.3, -929.9, 23.9 }, 'Chaîne de télévision et presse.', true)
add('radio', 'Radio locale', 'medias', 'generic', 'chat', G3, { 180, 500 }, { 136, 5 }, nil, 'Animateurs et programmation.')
add('newspaper', 'Journal', 'medias', 'generic', 'file', G3, { 170, 480 }, nil, nil, 'Presse écrite.')
add('studio', 'Studio de production', 'medias', 'generic', 'star', G4, { 200, 600 }, nil, nil, 'Cinéma, musique et clips.')
add('label', 'Label musical', 'medias', 'generic', 'star', G3, { 220, 700 }, nil, nil, 'Artistes et concerts.')
add('gallery', "Galerie d'art", 'medias', 'generic', 'star', G3, { 180, 500 }, nil, nil, 'Expositions et ventes.')
add('museum', 'Musée', 'medias', 'generic', 'book', G3, { 200, 520 }, nil, nil, 'Collections et visites.')
add('photo', 'Studio photo', 'medias', 'generic', 'eye', G3, { 170, 450 }, nil, nil, 'Portraits et événements.')

-- Loisirs
add('casino', 'Casino', 'loisirs', 'generic', 'star', { 'Croupier', 'Chef de salle', 'Directeur', 'Patron' }, { 250, 900 }, { 679, 5 }, { 925.3, 46.9, 81.1 }, 'Jeux et spectacles.')
add('gym', 'Salle de sport', 'loisirs', 'generic', 'bolt', G3, { 170, 450 }, { 311, 3 }, { -1198.0, -1558.0, 4.6 }, 'Musculation et cours collectifs.')
add('cinema', 'Cinéma', 'loisirs', 'generic', 'star', G3, { 160, 420 }, { 135, 2 }, { 301.0, 200.0, 104.4 }, 'Séances de cinéma.')
add('golf', 'Golf', 'loisirs', 'generic', 'bolt', G3, { 180, 500 }, { 109, 25 }, { -1336.0, 59.0, 54.5 }, 'Parcours et club-house.')
add('themepark', "Parc d'attractions", 'loisirs', 'generic', 'star', G4, { 170, 500 }, { 266, 5 }, nil, 'Manèges et animations.')
add('bowling', 'Bowling et arcade', 'loisirs', 'generic', 'bolt', G3, { 160, 420 }, nil, nil, 'Jeux et bowling.')
add('racing', 'Circuit de course', 'loisirs', 'generic', 'engine', G4, { 200, 600 }, { 315, 1 }, nil, 'Courses organisées.')
add('hunting', 'Club de chasse', 'loisirs', 'generic', 'paw', G3, { 170, 480 }, { 141, 25 }, nil, 'Chasse encadrée.')
add('diving', 'Club de plongée', 'loisirs', 'generic', 'cloud', G3, { 180, 500 }, nil, nil, 'Sorties plongée.')

-- Transport et travaux
add('delivery', 'Livraison de colis', 'industrie', 'generic', 'box', { 'Livreur', 'Chef de tournée', 'Directeur' }, { 200, 600 }, { 478, 5 }, nil, 'Tournées de colis.')
add('trucking', 'Transport routier', 'industrie', 'generic', 'engine', G4, { 220, 650 }, { 477, 31 }, nil, 'Camions et marchandises.')
add('movers', 'Déménageurs', 'industrie', 'generic', 'box', G3, { 190, 500 }, nil, nil, 'Déménagements.')
add('garbage', 'Éboueurs', 'industrie', 'generic', 'box', G3, { 190, 500 }, { 318, 25 }, nil, 'Collecte des déchets.')
add('construction', 'BTP', 'industrie', 'generic', 'building', G4, { 220, 650 }, { 566, 47 }, nil, 'Chantiers et terrassement.')
add('electrician', 'Électricien', 'industrie', 'generic', 'bolt', G3, { 210, 580 }, nil, nil, 'Installations électriques.')
add('plumber', 'Plombier', 'industrie', 'generic', 'cloud', G3, { 210, 580 }, nil, nil, 'Plomberie et chauffage.')
add('gardener', 'Jardinier paysagiste', 'industrie', 'generic', 'paw', G3, { 180, 480 }, nil, nil, 'Espaces verts.')
add('mining', 'Mine', 'industrie', 'generic', 'box', G4, { 230, 650 }, { 618, 31 }, nil, 'Extraction de minerai.')
add('lumber', 'Bûcherons', 'industrie', 'generic', 'box', G3, { 200, 520 }, { 480, 25 }, nil, 'Bois et scierie.')
add('fishing', 'Pêcherie', 'industrie', 'generic', 'cloud', G3, { 190, 500 }, { 68, 3 }, nil, 'Pêche et poissonnerie.')
add('farm', 'Ferme', 'industrie', 'generic', 'paw', G4, { 190, 520 }, { 285, 25 }, nil, 'Élevage et cultures.')
add('oil', 'Pétrole et raffinerie', 'industrie', 'generic', 'bolt', G4, { 250, 750 }, nil, nil, 'Extraction et raffinage.')
add('port', 'Port et dockers', 'industrie', 'generic', 'box', G4, { 230, 680 }, { 410, 3 }, { 1198.0, -2979.0, 5.9 }, 'Manutention et conteneurs.')
add('airline', 'Compagnie aérienne', 'industrie', 'generic', 'cloud', { 'Hôtesse', 'Pilote', 'Chef pilote', 'Directeur' }, { 300, 1000 }, { 307, 3 }, { -1037.0, -2737.0, 13.8 }, 'Vols commerciaux.')
add('airtaxi', 'Taxi aérien', 'industrie', 'generic', 'cloud', G3, { 280, 800 }, { 307, 5 }, nil, 'Hélicoptères et petits avions.')
add('boats', 'Transport maritime', 'industrie', 'generic', 'cloud', G3, { 220, 600 }, { 427, 3 }, nil, 'Bateaux et navettes.')
add('post', 'Poste', 'industrie', 'generic', 'file', G3, { 190, 520 }, { 478, 3 }, nil, 'Courrier et colis.')

-- Couvertures et façades
add('laundromat', 'Laverie', 'facade', 'generic', 'box', G3, { 160, 450 }, nil, nil, 'Commerce de façade pour le blanchiment.')
add('scrapyard', 'Casse automobile', 'facade', 'garage', 'engine', G3, { 180, 500 }, { 380, 25 }, { 2351.0, 3132.0, 48.2 }, 'Recyclage de ferraille et pièces.')
add('motorclub', 'Club de motards', 'facade', 'generic', 'engine', G3, { 160, 450 }, nil, nil, 'Bar-garage de club.')
add('nightcover', 'Bar de nuit discret', 'facade', 'generic', 'food', G3, { 160, 450 }, nil, nil, 'Bar servant de couverture.')
add('shippingfront', "Import-export", 'facade', 'generic', 'box', G3, { 180, 520 }, nil, nil, 'Négoce de marchandises.')
add('tanning', 'Salon de bronzage', 'facade', 'generic', 'star', G3, { 150, 400 }, nil, nil, 'Petit commerce de façade.')

C.List = L
-- Catalogue court : les entreprises proposées par défaut (Builder, panel, premier lancement). Le reste du catalogue s'affiche avec
-- le réglage « Catalogue complet » (Entreprises › Réglages).
C.Essential = { lspd = true, ems = true, justice = true, mecano = true, autoexotic = true, taxi = true, cardealer = true, burgershot = true,
    bean = true, bahamas = true, unicorn = true, realestate = true, weazel = true, delivery = true, nightclub = true, galaxy = true, pub = true, cafe = true }
function C.Visible(t) return C.Essential[t.key] or PB.Cfg.Get('biz', 'full_catalog', false) == true or (G.Biz and G.Biz.Get(t.key) ~= nil) end
local BYKEY = {}
for _, t in ipairs(L) do BYKEY[t.key] = t end
C.ByKey = BYKEY

-- Entreprise sur mesure : elle garde le fonctionnement d'un modèle du catalogue (colonne « activity »), avec son propre nom, identifiant et icône
PB.Migrate('310_biz_activity', "Entreprises : type d'activité et icône choisie", {
    "ALTER TABLE pb_biz ADD COLUMN activity VARCHAR(32) NOT NULL DEFAULT ''",
    "ALTER TABLE pb_biz ADD COLUMN blip INT NOT NULL DEFAULT -1",
    "ALTER TABLE pb_biz ADD COLUMN bcolor INT NOT NULL DEFAULT -1",
})
-- Modèle qui décide du fonctionnement (cuisine, comptoir, missions…) : le type choisi, sinon l'identifiant s'il vient du catalogue
function C.ModelKey(b)
    if type(b) ~= 'table' then b = Biz.Get(tostring(b or '')) end
    if not b then return nil end
    local a = tostring(b.activity or '')
    if a ~= '' and BYKEY[a] then return a end
    return BYKEY[b.id] and b.id or nil
end
function C.ModelOf(b) local k = C.ModelKey(b) return k and BYKEY[k] or nil end
-- Icône du siège : celle choisie à la création, sinon celle du modèle, sinon un bureau bleu
function C.BlipOf(b)
    if type(b) ~= 'table' then b = Biz.Get(tostring(b or '')) end
    local t = b and C.ModelOf(b)
    local s = b and tonumber(b.blip) or -1
    local c = b and tonumber(b.bcolor) or -1
    return { s >= 0 and s or (t and t.blip and t.blip[1] or 475), c >= 0 and c or (t and t.blip and t.blip[2] or 3) }
end

-- Droits par grade : le bas de l'échelle fait le minimum, l'avant-dernier gère l'équipe, le dernier est patron (tous les droits).
local PERMS = {
    police = { low = 'records', mid = 'fine,records,cuff,search,jail', mid2 = 'fine,records,invoice,cuff,search,seize,jail,dispatch', high = 'fine,records,invoice,cuff,search,seize,jail,dispatch,hire,fire,promote,vault' },
    ems = { low = 'records', mid = 'revive,records,invoice', mid2 = 'revive,records,invoice,dispatch', high = 'revive,records,invoice,dispatch,hire,fire,promote,vault' },
    garage = { low = 'repair', mid = 'repair,invoice', mid2 = 'repair,invoice,hire', high = 'repair,invoice,hire,fire,promote,vault' },
    generic = { low = 'invoice', mid = 'invoice', mid2 = 'invoice,hire', high = 'invoice,hire,fire,promote,vault' },
}
function C.Grades(t)
    local n, out = #t.grades, {}
    local p = PERMS[t.kind] or PERMS.generic
    local lo, hi = t.pay[1], t.pay[2]
    for i, name in ipairs(t.grades) do
        local perms = ''
        -- police / secours : le grade du milieu (sergent, infirmier) est déjà répartiteur, comme dans les modèles de base
        local mid2 = i * 2 > n or ((t.kind == 'police' or t.kind == 'ems') and i * 2 >= n)
        if i == 1 then perms = p.low elseif i == n then perms = '' elseif i == n - 1 and n >= 3 then perms = p.high elseif mid2 then perms = p.mid2 else perms = p.mid end
        if t.gperms and t.gperms[i] then perms = t.gperms[i] end   -- droits propres au modèle (ex. agent de sécurité du Galaxy)
        local sal = n == 1 and lo or math.floor(lo + (hi - lo) * ((i - 1) / (n - 1)) ^ 1.2 + 0.5)
        out[#out + 1] = { i - 1, name, sal, i == n, perms }
    end
    return out
end

-- Création d'une entreprise depuis un modèle ; ne remplace jamais une entreprise existante. Renvoie ok, id | message.
function C.Create(t, opts)
    opts = opts or {}
    local id = (opts.id and opts.id ~= '' and opts.id or t.key):lower():gsub('[^A-Za-z0-9_]', ''):sub(1, 32)
    if id == '' then return false, 'Identifiant invalide.' end
    if Biz.Get(id) then return false, 'exists' end
    local cat = CATBY[t.cat] or CATBY.services
    local label = (opts.label and opts.label ~= '' and opts.label or t.label):sub(1, 48)
    local pos = not opts.nopos and t.pos or nil
    DB.exec('INSERT INTO pb_biz (id, label, kind, color, icon, pay_from, enabled, hiring, description, created_at, category) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)',
        { id, label, t.kind, cat.color, t.icon or cat.icon, 'free', (t.cat == 'public') and 0 or 1, (t.desc or cat.desc):sub(1, 160), now(), t.cat })
    if pos then DB.exec('UPDATE pb_biz SET hx = ?, hy = ?, hz = ? WHERE id = ?', { pos[1], pos[2], pos[3], id }) end
    for _, g in ipairs(C.Grades(t)) do
        DB.exec('INSERT INTO pb_biz_grades (biz_id, grade, label, salary, boss, perms) VALUES (?, ?, ?, ?, ?, ?)', { id, g[1], g[2], g[3], g[4] and 1 or 0, g[5] })
    end
    -- type d'activité (le modèle) et icône choisie
    local bs, bc = math.floor(tonumber(opts.blip) or -1), math.floor(tonumber(opts.bcolor) or -1)
    if bs < -1 or bs > 999 then bs = -1 end
    if bc < -1 or bc > 85 then bc = -1 end
    DB.exec('UPDATE pb_biz SET activity = ?, blip = ?, bcolor = ? WHERE id = ?', { t.key, bs, bc, id })
    -- le siège a un blip visible de tous (modifiable ensuite : visibilité, icône, couleur, taille)
    if pos and t.blip and G.Points then
        G.Points.Add({ owner_kind = 'biz', owner = id, kind = 'hq', label = label, x = pos[1], y = pos[2], z = pos[3], sprite = bs >= 0 and bs or t.blip[1], bcolor = bc >= 0 and bc or t.blip[2], vis = 'all' })
    end
    return true, id
end

-- Premier lancement : installe tout le catalogue (supprimable ensuite depuis le panel) et classe celles du pack de base dans une catégorie.
function C.Seed()
    local n = 0
    for _, t in ipairs(L) do
        if not Biz.Get(t.key) and (C.Essential[t.key] or PB.Cfg.Get('biz', 'full_catalog', false) == true) then
            local ok = C.Create(t)
            if ok then n = n + 1 end
        end
    end
    -- classer les entreprises existantes (pack de base ou création antérieure) et leur donner un blip de siège
    for _, t in ipairs(L) do
        local b = Biz.Get(t.key)
        if b and (b.category == nil or b.category == '' or b.category == 'services') and t.cat ~= 'services' then DB.exec('UPDATE pb_biz SET category = ? WHERE id = ?', { t.cat, t.key }) end
        if b and b.hx and t.blip and G.Points and not DB.one("SELECT id FROM pb_points WHERE owner_kind = 'biz' AND owner = ? AND kind = 'hq'", { t.key }) then
            G.Points.Add({ owner_kind = 'biz', owner = t.key, kind = 'hq', label = b.label, x = b.hx, y = b.hy, z = b.hz or 0, sprite = t.blip[1], bcolor = t.blip[2], vis = 'all' })
        end
    end
    return n
end

-- Pour les ressources compagnons (ex. burgershot) : crée l'entreprise du catalogue si elle n'existe pas encore. Renvoie true si elle existe.
exports('EnsureBusiness', function(key)
    key = tostring(key or '')
    if Biz.Get(key) then return true end
    for _, t in ipairs(L) do
        if t.key == key then local ok = C.Create(t) return ok == true end
    end
    return false
end)

-- Recherche tolérante : « police » retrouve « lspd » (même type) ; « Taxi » retrouve « taxi » ; renvoie l'entreprise ou nil.
function C.Resolve(q)
    q = tostring(q or ''):lower():gsub('^%s+', ''):gsub('%s+$', '')
    if q == '' then return nil end
    local b = Biz.Get(q)
    if b then return b end
    local all = Biz.List()
    for _, r in ipairs(all) do if r.label:lower() == q then return r end end
    for _, r in ipairs(all) do if r.id:lower():sub(1, #q) == q then return r end end
    for _, r in ipairs(all) do if r.label:lower():find(q, 1, true) then return r end end
    for _, r in ipairs(all) do if r.kind == q then return r end end
    return nil
end

-- Deuxième emploi ----------------------------------------------------------------------------------------------------------------------------
-- Burger Shot : sa vraie icône (radar_burger_shot, 98) au lieu de l'icône générique de restaurant posée par les anciennes versions
PB.Migrate('185_burgershot_blip', 'Burger Shot : icône de la carte', { "UPDATE pb_points SET sprite = 98 WHERE owner_kind = 'biz' AND owner = 'burgershot' AND kind = 'hq' AND sprite = 106" })
PB.Migrate('180_biz_category', 'Entreprises : catégorie, points et deuxième emploi', {
    "ALTER TABLE pb_biz ADD COLUMN category VARCHAR(16) NOT NULL DEFAULT 'services'",
    [[CREATE TABLE IF NOT EXISTS pb_biz_job2 (license VARCHAR(64) NOT NULL, biz_id VARCHAR(32) NOT NULL, grade INT NOT NULL DEFAULT 0, PRIMARY KEY (license))]],
})

function C.Job2(license)
    local r = DB.one('SELECT biz_id, grade FROM pb_biz_job2 WHERE license = ?', { tostring(license or '') })
    if not r then return nil end
    local b, g = Biz.Get(r.biz_id), Biz.Grade(r.biz_id, r.grade)
    if not b or not g then return nil end
    return { biz = b.id, label = b.label, grade = g.grade, gradeLabel = g.label, salary = g.salary }
end
function C.SetJob2(src, bizId, grade)
    local p = G.Get(tonumber(src))
    if not p then return false, 'Joueur introuvable.' end
    if bizId == nil or bizId == '' then DB.exec('DELETE FROM pb_biz_job2 WHERE license = ?', { p.license }) return true end
    local b = Biz.Get(bizId)
    if not b then return false, 'Entreprise introuvable.' end
    local g = Biz.Grade(b.id, grade or 0)
    if not g then return false, 'Grade introuvable.' end
    DB.exec('REPLACE INTO pb_biz_job2 (license, biz_id, grade) VALUES (?, ?, ?)', { p.license, b.id, g.grade })
    return true
end
-- Échange l'emploi principal et le second (le joueur passe de l'un à l'autre).
function C.Swap(src)
    local p = G.Get(tonumber(src))
    if not p then return false, 'Joueur introuvable.' end
    local j2 = DB.one('SELECT biz_id, grade FROM pb_biz_job2 WHERE license = ?', { p.license })
    if not j2 then return false, "Tu n'as pas de second emploi." end
    local j1 = Biz.MemberOf(p.license)
    if j1 then DB.exec('REPLACE INTO pb_biz_job2 (license, biz_id, grade) VALUES (?, ?, ?)', { p.license, j1.biz_id, j1.grade }) else DB.exec('DELETE FROM pb_biz_job2 WHERE license = ?', { p.license }) end
    return Biz.SetJob(src, j2.biz_id, j2.grade)
end
exports('GetJob2', function(src) local p = G.Get(tonumber(src)) return p and C.Job2(p.license) or nil end)
exports('SetJob2', function(src, id, grade) return C.SetJob2(tonumber(src), id, grade) end)
exports('SwapJobs', function(src) return C.Swap(tonumber(src)) end)

-- Le deuxième emploi est payé avec le premier, à la moitié du salaire, s'il est en service dans l'une des deux entreprises.
-- (les chiffres sont réglables dans Entreprises › Réglages : « Salaire du deuxième emploi (%) »)
PB.Cfg.Define('biz', { job2_pct = 50 })

-- Liste pour les menus (entreprises avec grades) --------------------------------------------------------------------------------------------
function C.Menu()
    local out = {}
    for _, b in ipairs(Biz.List()) do
        local gs = {}
        for _, g in ipairs(Biz.Grades(b.id)) do gs[#gs + 1] = { g.grade, g.label } end
        out[#out + 1] = { id = b.id, label = b.label, cat = b.category or 'services', grades = gs }
    end
    table.sort(out, function(a, b) if a.cat ~= b.cat then return a.cat < b.cat end return a.label < b.label end)
    return out
end

-- Commandes pour le staff : /setjob [id] [entreprise] [grade] — /setjob2 — /setgang — /setgroup. Les noms approximatifs sont acceptés.
local function who(src, a)
    local t = tonumber(a)
    if not t or not G.Get(t) then return nil end
    return t
end
local function reply(src, ok, msg)
    if src == 0 then print('[pb_panel] ' .. tostring(msg)) else G.Notify(src, { type = ok and 'success' or 'error', title = 'Staff', text = tostring(msg) }) end
end
local function commandAllowed(src, perm)
    if src == 0 then return true end
    return P.Has(src, perm) and (not G.Staff or G.Staff.OnDuty(src) or PB.Cfg.Get('staff', 'require_duty', true) == false)
end
RegisterCommand('setjob', function(src, args)
    if not commandAllowed(src, 'staff.job') then return end
    local t = who(src, args[1])
    if not t then return reply(src, false, 'Usage : /setjob [id joueur] [entreprise] [grade]') end
    if args[2] == nil or args[2] == 'none' or args[2] == 'chomeur' then local ok, why = Biz.SetJob(t, nil) return reply(src, ok, ok and 'Sans emploi.' or why) end
    local b = C.Resolve(args[2])
    if not b then return reply(src, false, 'Aucune entreprise « ' .. tostring(args[2]) .. ' ». Liste : Panel › Entreprises.') end
    local ok, why = Biz.SetJob(t, b.id, tonumber(args[3]) or 0)
    reply(src, ok, ok and (b.label .. ' attribué.') or why)
end, false)
RegisterCommand('setjob2', function(src, args)
    if not commandAllowed(src, 'staff.job') then return end
    local t = who(src, args[1])
    if not t then return reply(src, false, 'Usage : /setjob2 [id joueur] [entreprise] [grade]') end
    if args[2] == nil or args[2] == 'none' then local ok, why = C.SetJob2(t, nil) return reply(src, ok, ok and 'Second emploi retiré.' or why) end
    local b = C.Resolve(args[2])
    if not b then return reply(src, false, 'Aucune entreprise « ' .. tostring(args[2]) .. ' ».') end
    local ok, why = C.SetJob2(t, b.id, tonumber(args[3]) or 0)
    reply(src, ok, ok and ('Second emploi : ' .. b.label .. '.') or why)
end, false)

-- Actions du panel -----------------------------------------------------------------------------------------------------------------------
PB.Action('biz.cat.create', 'biz.edit', function(ctx, p)
    local t = BYKEY[tostring(p.key or '')]
    if not t then return false, 'Modèle inconnu.' end
    local ok, id = C.Create(t)
    if not ok then return false, id == 'exists' and 'Cette entreprise est déjà installée.' or id end
    ctx.audit('config', 'biz.cat.create', id, nil, { cat = t.cat })
    G.PushConfig()
    ctx.toast = '« ' .. t.label .. ' » installée. Règle-la dans « Modifier ».'
    return true
end)
PB.Action('biz.cat.install', 'biz.edit', function(ctx, p)
    local cat, n = tostring(p.cat or ''), 0
    for _, t in ipairs(L) do
        if (cat == 'all' or t.cat == cat) and not Biz.Get(t.key) and C.Create(t) then n = n + 1 end
    end
    ctx.audit('config', 'biz.cat.install', cat, nil, { n = n })
    G.PushConfig()
    ctx.toast = n .. ' entreprise(s) installée(s).'
    return true
end, { critical = true, confirm = { title = 'Installer ces entreprises ?', text = 'Les entreprises déjà installées ne sont jamais modifiées.' } })

-- Rangement (une fois) : les entreprises du catalogue hors liste courte, sans employé ni point posé, sont supprimées.
-- Celles qui servent (employés, points, argent en caisse) restent. Réinstallables depuis « Nouvelle entreprise » avec le catalogue complet.
function C.Trim()
    local n = 0
    for _, t in ipairs(L) do
        local b = not C.Essential[t.key] and Biz.Get(t.key)
        if b then
            local used = DB.one('SELECT 1 AS x FROM pb_biz_members WHERE biz_id = ? LIMIT 1', { t.key }) or DB.one("SELECT 1 AS x FROM pb_points WHERE owner_kind = 'biz' AND owner = ? AND kind <> 'hq' LIMIT 1", { t.key })
                or DB.one('SELECT 1 AS x FROM pb_biz_job2 WHERE biz_id = ? LIMIT 1', { t.key })
            local cash = G.Eco and G.Eco.Balance and tonumber(G.Eco.Balance('biz:' .. t.key)) or 0
            if not used and cash == 0 then
                DB.exec('DELETE FROM pb_biz_grades WHERE biz_id = ?', { t.key })
                DB.exec("DELETE FROM pb_points WHERE owner_kind = 'biz' AND owner = ?", { t.key })
                DB.exec('DELETE FROM pb_biz WHERE id = ?', { t.key })
                n = n + 1
            end
        end
    end
    if n > 0 then
        if Biz.Reload then pcall(Biz.Reload) end
        if G.Points and G.Points.PushAll then G.Points.PushAll() end
        G.PushConfig()
    end
    return n
end
-- Burger Shot : son siège porte l'icône burger (106, orange), visible par tous ; l'icône 98 « burger_shot » n'a pas d'image en jeu. Sans siège (entreprise créée sans position), il est posé
-- au restaurant de Vespucci. Un siège masqué volontairement (« personne ») n'est pas touché.
function C.FixBurgerBlip()
    local b = Biz.Get('burgershot')
    local t = BYKEY.burgershot
    if not b or not t or not G.Points then return false end
    local hq
    for _, r in ipairs(G.Points.Of('biz', 'burgershot')) do if r.kind == 'hq' then hq = r break end end
    if not hq then
        G.Points.Add({ owner_kind = 'biz', owner = 'burgershot', kind = 'hq', label = b.label or t.label, x = t.pos[1], y = t.pos[2], z = t.pos[3], sprite = t.blip[1], bcolor = t.blip[2], vis = 'all' })
    elseif hq.vis ~= 'none' then
        local sp = tonumber(hq.sprite) or 0
        local fix = sp <= 0 or sp == 98   -- sans icône, ou l'icône invisible
        DB.exec('UPDATE pb_points SET sprite = ?, bcolor = ?, vis = ? WHERE id = ?', { fix and t.blip[1] or sp, fix and t.blip[2] or hq.bcolor, 'all', hq.id })
        if G.Points.PushAll then G.Points.PushAll() end
    end
    return true
end
PB.OnReady(function()
    if PB.Cfg.Get('biz', 'trimmed_v1', false) ~= true and PB.Cfg.Get('biz', 'full_catalog', false) ~= true then
        local n = C.Trim()
        PB.Cfg.Set('biz', 'trimmed_v1', true, nil, 'Catalogue court : ' .. n .. ' entreprises inutilisées retirées')
        if n > 0 then PB.Log(('Catalogue court : %d entreprises inutilisées retirées (employés, points et caisses conservés ailleurs).'):format(n)) end
    end
    if PB.Cfg.Get('biz', 'cat_seed', false) ~= true then
        local n = C.Seed()
        PB.Cfg.Set('biz', 'cat_seed', true, nil, 'Catalogue : ' .. n .. ' entreprises de base')
    end
    -- 1.2.30 : icône Burger Shot visible de tous sur la carte (une fois ; ensuite les réglages du siège sont respectés)
    if PB.Cfg.Get('biz', 'bs_blip_v1', false) ~= true then
        pcall(C.FixBurgerBlip)
        PB.Cfg.Set('biz', 'bs_blip_v1', true, nil, 'Burger Shot : icône de la carte')
    end
    -- 1.2.29 : la boîte de nuit Galaxy (avec ses agents de sécurité) est créée une fois ; supprimée ensuite, elle ne revient pas
    if PB.Cfg.Get('biz', 'galaxy_v1', false) ~= true then
        if not Biz.Get('galaxy') and BYKEY.galaxy then pcall(C.Create, BYKEY.galaxy) if Biz.Reload then pcall(Biz.Reload) end end
        PB.Cfg.Set('biz', 'galaxy_v1', true, nil, 'Galaxy Club ajouté')
    end
end)

PB.SelfTest.Add('catalogue entreprises', function(R)
    R.check(#L >= 100, 'catalogue', 'moins de 100 modèles : ' .. #L)
    local seen = {}
    for _, t in ipairs(L) do
        R.check(not seen[t.key], 'catalogue', 'identifiant en double : ' .. t.key) seen[t.key] = true
        R.check(CATBY[t.cat] ~= nil, 'catalogue', 'catégorie inconnue pour ' .. t.key)
        local gs = C.Grades(t)
        R.check(#gs >= 2 and gs[#gs][4] == true, 'catalogue', 'pas de patron : ' .. t.key)
        for i = 2, #gs do R.check(gs[i][3] >= gs[i - 1][3], 'catalogue', 'salaires non croissants : ' .. t.key) end
    end
    R.check(C.Resolve('police') ~= nil or Biz.Get('lspd') == nil, 'catalogue', "« police » ne retrouve pas l'entreprise")
end)

RegisterCommand('jobswap', function(src)
    if src == 0 then return end
    local ok, why = C.Swap(src)
    G.Notify(src, { type = ok and 'success' or 'error', title = 'Emploi', text = ok and 'Tu as changé d\'emploi.' or tostring(why) })
end, false)
