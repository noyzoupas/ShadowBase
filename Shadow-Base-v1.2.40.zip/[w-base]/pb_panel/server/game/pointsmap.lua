-- Points posés : carte de TOUS les points du serveur (entreprises, groupes, magasins, garages, banques) avec les problèmes détectables
-- côté serveur (position vide, hors carte, sous le niveau de la mer, doublon, très loin du siège), et « Tester en jeu » :
-- le staff est téléporté sur le point, puis son jeu vérifie le sol (sous le sol, dans le vide, en l'air).
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G
local PM = {}
G.PointsMap = PM

local function f(v) return tonumber(v) or 0 end
local function d2(a, b) local dx, dy = f(a.x) - f(b.x), f(a.y) - f(b.y) return math.sqrt(dx * dx + dy * dy) end

function PM.Collect()
    local out = {}
    local function add(kind, oid, owner, key, label, x, y, z, hq)
        out[#out + 1] = { key = kind .. '|' .. oid .. '|' .. key, kind = kind, oid = oid, owner = owner, label = label, x = f(x), y = f(y), z = f(z), hq = hq }
    end
    for _, b in ipairs(G.Biz and G.Biz.List() or {}) do
        local hq = (f(b.hx) ~= 0 or f(b.hy) ~= 0) and { x = b.hx, y = b.hy } or nil
        for _, p in ipairs(G.BuilderAllPoints and G.BuilderAllPoints('biz', b.id, 0) or {}) do add('biz', b.id, b.label, p.key, p.label, p.x, p.y, p.z, hq) end
    end
    for gid, g in pairs(G.Tags and G.Tags.GangDefs() or {}) do
        local all = G.BuilderAllPoints and G.BuilderAllPoints('gang', gid, 0) or {}
        local hq
        for _, p in ipairs(all) do if p.label:find('QG', 1, true) then hq = p break end end
        for _, p in ipairs(all) do add('gang', gid, g.label or gid, p.key, p.label, p.x, p.y, p.z, hq) end
    end
    -- sub : sorte de point (deux points de même sorte au même endroit = doublon) ; del : table et identifiant pour la suppression des doublons
    local function last(sub, tbl, rid) out[#out].sub, out[#out].del = sub, { tbl, rid } end
    for _, r in ipairs(DB.q("SELECT id, kind, label, x, y, z, opts FROM pb_shops WHERE opts NOT LIKE '%biz%' OR opts IS NULL ORDER BY id") or {}) do add('shop', 'shops', 'Magasins', 'sh:' .. r.id, (r.label ~= '' and r.label or r.kind), r.x, r.y, r.z) last(r.kind, 'pb_shops', r.id) end
    for _, r in ipairs(DB.q("SELECT id, label, kind, x, y, z FROM pb_garages WHERE biz = '' ORDER BY id") or {}) do add('garage', 'garages', 'Garages publics', 'ga:' .. r.id, r.label, r.x, r.y, r.z) last(r.kind, 'pb_garages', r.id) end
    for _, r in ipairs(DB.q('SELECT id, kind, label, x, y, z FROM pb_bank_points ORDER BY id') or {}) do add('bank', 'bank', 'Banques', 'bk:' .. r.id, r.label, r.x, r.y, r.z) last(r.kind, 'pb_bank_points', r.id) end
    for _, r in ipairs(DB.q("SELECT id, kind, label, x, y, z, sprite FROM pb_places WHERE kind IN ('blip', 'zone') ORDER BY id") or {}) do add('place', 'places', 'Cartographie', 'pl:' .. r.id, r.label, r.x, r.y, r.z) last(r.kind .. ':' .. tostring(r.sprite), 'pb_places', r.id) end
    return out
end

-- Problèmes visibles sans être en jeu
function PM.Issues(list)
    for i, p in ipairs(list) do
        local iss = {}
        if p.x == 0 and p.y == 0 then iss[#iss + 1] = 'Position vide (0, 0)'
        else
            if p.x < -4500 or p.x > 4600 or p.y < -4600 or p.y > 8600 then iss[#iss + 1] = 'Hors de la carte' end
            if p.z < -5 then iss[#iss + 1] = ('Sous le niveau de la mer (z = %.0f)'):format(p.z) end
            if p.hq and d2(p, p.hq) > 1500 and not p.label:find('Garage', 1, true) then iss[#iss + 1] = ('À %.1f km du siège'):format(d2(p, p.hq) / 1000) end
            for j = 1, i - 1 do
                local q = list[j]
                if q.oid == p.oid and q.label == p.label and d2(p, q) < 0.4 and math.abs(p.z - q.z) < 1 then iss[#iss + 1] = 'Doublon (même point au même endroit)' p.dup = true break end
                -- même sorte de magasin / garage / banque / repère à moins de 3 m : deux blips l'un sur l'autre sur la carte
                if p.sub and q.sub == p.sub and q.kind == p.kind and d2(p, q) < 3 and math.abs(p.z - q.z) < 3 then iss[#iss + 1] = 'Doublon : « ' .. q.label .. ' » est déjà là' p.dup = true break end
            end
        end
        p.issues = iss
    end
    return list
end

PB.Action('points.goto', 'carte.place', function(ctx, p)
    local src = tonumber(ctx.src) or 0
    if src <= 0 or not G.Get(src) then return false, 'Ouvre le panel en jeu pour te téléporter.' end
    for _, pt in ipairs(PM.Collect()) do
        if pt.key == tostring(p.key) then
            TriggerClientEvent('pb:g:staff:fx', src, 'tp', PB.Json({ x = pt.x, y = pt.y, z = pt.z }))
            TriggerClientEvent('pb:g:points:check', src, PB.Json({ x = pt.x, y = pt.y, z = pt.z, label = pt.owner .. ' — ' .. pt.label }))
            ctx.close = true
            ctx.toast = 'Téléporté : ton jeu vérifie le sol sous le point.'
            return true
        end
    end
    return false, 'Point introuvable (supprimé entre-temps ?).'
end)

-- Doublons supprimables d'un coup : magasins, garages publics, banques, repères de la Cartographie (le plus ancien est gardé)
local DEL_TABLES = { pb_shops = true, pb_garages = true, pb_bank_points = true, pb_places = true }
local function deleteRow(del)
    if not del or not DEL_TABLES[del[1]] then return false end
    DB.exec('DELETE FROM ' .. del[1] .. ' WHERE id = ?', { del[2] })
    return true
end
local function afterDelete()
    G.PushConfig()
    if PB.PushPlaces then PB.PushPlaces() end
end
PB.Action('points.dedupe', 'carte.delete', function(ctx)
    local n = 0
    for _, p in ipairs(PM.Issues(PM.Collect())) do if p.dup and deleteRow(p.del) then n = n + 1 end end
    if n == 0 then return false, 'Aucun doublon supprimable.' end
    afterDelete()
    ctx.audit('carte', 'points.dedupe', tostring(n))
    ctx.toast = n .. ' doublon(s) supprimé(s). Les joueurs voient la carte à jour.'
    return true
end)
PB.Action('points.delete', 'carte.delete', function(ctx, p)
    for _, pt in ipairs(PM.Collect()) do
        if pt.key == tostring(p.key) then
            if not deleteRow(pt.del) then return false, 'Ce point se supprime depuis le Builder (F10 › Builder).' end
            afterDelete()
            ctx.audit('carte', 'points.delete', pt.key, nil, nil, { label = pt.label })
            ctx.toast = '« ' .. pt.label .. ' » supprimé.'
            return true
        end
    end
    return false, 'Point introuvable (supprimé entre-temps ?).'
end)

-- Repères des joueurs : réinitialiser chez tout le monde (efface et redessine), ou chez soi
P.Register('carte.blips', 'Réinitialiser les repères de la carte chez tous les joueurs', 'carte')
PB.Action('blips.resetall', 'carte.blips', function(ctx, p)
    TriggerClientEvent('pb:g:blips:reset', -1, p.deep == true)
    ctx.audit('carte', 'blips.resetall', p.deep and 'complet' or 'normal')
    ctx.toast = 'Repères réinitialisés chez tous les joueurs connectés.'
    return true
end)
-- Un joueur a effacé ses repères : on lui renvoie tout ce qui en dessine (une fois toutes les 5 s au plus)
local resync = {}
RegisterNetEvent('pb:g:blips:resync', function()
    local src = source
    if not G.Get(src) or (resync[src] and os.time() - resync[src] < 5) then return end
    resync[src] = os.time()
    G.PushConfig(src)
    if PB.PushPlaces then PB.PushPlaces(src) end
    for _, m in ipairs({ G.Points, G.Territories, G.Flags }) do if m and m.Push then pcall(m.Push, src) end end
end)
AddEventHandler('playerDropped', function() resync[source] = nil end)

local COLOR = { biz = '#6fb4ff', gang = '#ff7a7a', shop = '#7bd88f', garage = '#f2c14e', bank = '#b48cff', place = '#9ad0ff' }
local KIND = { biz = 'Entreprise', gang = 'Groupe', shop = 'Magasin', garage = 'Garage', bank = 'Banque', place = 'Repère (Cartographie)' }
local function rows(list, onlyBad)
    local out = {}
    for _, p in ipairs(list) do
        if not onlyBad or #p.issues > 0 then
            out[#out + 1] = { owner = p.owner, kind = KIND[p.kind] or p.kind, label = p.label, pos = ('%.0f, %.0f, %.0f'):format(p.x, p.y, p.z), issue = #p.issues > 0 and { text = table.concat(p.issues, ' · '), tone = 'warn' } or { text = 'OK', tone = 'ok' },
                actions = { { action = 'points.goto', label = 'Tester en jeu', icon = 'pin', payload = { key = p.key } },
                    p.dup and p.del and { action = 'points.delete', label = 'Supprimer', icon = 'trash', danger = true, confirm = 'Supprimer « ' .. p.label .. ' » ?', payload = { key = p.key } } or nil } }
        end
    end
    return out
end
local COLS = { { k = 'owner', label = 'À qui' }, { k = 'kind', label = 'Type' }, { k = 'label', label = 'Point' }, { k = 'pos', label = 'Position', type = 'mono' }, { k = 'issue', label = 'Problème', type = 'badge' } }

PB.Module({
    id = 'pointsmap', label = 'Points posés', icon = 'map', group = 'Serveur', order = 82, perm = 'carte.place', hint = 'Carte de tous les points, problèmes, tester en jeu',
    caps = function()
        return PB.Capsify({
            { 'Carte de tous les points', 'ok', 'Entreprises, groupes, magasins, garages publics, banques.' },
            { 'Problèmes détectés par le serveur', 'ok', 'Position vide, hors carte, sous le niveau de la mer, doublon, très loin du siège.' },
            { 'Sol vérifié en jeu', 'ok', '« Tester en jeu » téléporte le staff ; son jeu dit si le point est sous le sol, dans le vide ou en l\'air (le serveur ne voit pas le décor).' },
        })
    end,
    doc = "## Points posés\nTous les points du serveur sur une carte. L'onglet **Problèmes** liste ceux qui sont visiblement faux ; **Tester en jeu** t'y téléporte et ton jeu vérifie le sol. Pour corriger : F10 › Builder › la cible › le point (« Y aller », « Dupliquer ici », « Tout déplacer »).",
    view = function()
        local list = PM.Issues(PM.Collect())
        local bad = 0
        for _, p in ipairs(list) do if #p.issues > 0 then bad = bad + 1 end end
        return { tabs = {
            { id = 'map', label = 'Carte', icon = 'map', build = function()
                local pts = {}
                for _, p in ipairs(list) do if p.x ~= 0 or p.y ~= 0 then pts[#pts + 1] = { x = p.x, y = p.y, color = #p.issues > 0 and '#ff3b30' or COLOR[p.kind], label = p.owner .. ' — ' .. p.label, sub = #p.issues > 0 and table.concat(p.issues, ' · ') or nil } end end
                local legend = { { color = '#ff3b30', label = 'Problème' } }
                for k, c in pairs(COLOR) do legend[#legend + 1] = { color = c, label = KIND[k] } end
                return { B.stats({ { label = 'Points posés', value = tostring(#list), icon = 'pin' }, { label = 'Avec un problème', value = tostring(bad), icon = 'alert' } }),
                    { type = 'map', id = 'pmap', title = 'Tous les points', points = pts, legend = legend } }
            end },
            { id = 'issues', label = 'Problèmes (' .. bad .. ')', icon = 'alert', build = function()
                local dups = 0
                for _, p in ipairs(list) do if p.dup and p.del then dups = dups + 1 end end
                local blocks = {}
                if dups > 0 then blocks[1] = B.actions({ { action = 'points.dedupe', label = 'Supprimer les ' .. dups .. ' doublon(s)', icon = 'trash', danger = true, confirm = 'Supprimer les doublons ? Le plus ancien point de chaque endroit est gardé.' } }, 'Doublons') end
                blocks[#blocks + 1] = B.table({ id = 'pi', title = 'Points à vérifier', columns = COLS, rows = rows(list, true), empty = 'Aucun problème détecté côté serveur. Pense quand même à tester en jeu les points importants.' })
                return blocks
            end },
            { id = 'blips', label = 'Repères des joueurs', icon = 'eye', build = function()
                return { B.notice('info', "Chaque joueur peut aussi le faire lui-même : « /blips reset ». Les repères en double sont déjà masqués automatiquement dans le jeu ; les doublons enregistrés se suppriment dans l'onglet Problèmes."),
                    B.actions({
                        { action = 'blips.resetall', label = 'Réinitialiser les repères de tous les joueurs', icon = 'sync', primary = true, payload = { deep = false } },
                        { action = 'blips.resetall', label = 'Nettoyage complet (efface aussi les repères perdus)', icon = 'trash', danger = true, confirm = "Effacer tous les repères de la carte, y compris ceux d'autres scripts, puis redessiner ceux de Shadow Base ?", payload = { deep = true } },
                    }, 'Réinitialiser') }
            end, perm = 'carte.blips' },
            { id = 'all', label = 'Tous', icon = 'list', build = function()
                return { B.table({ id = 'pa', title = 'Tous les points', columns = COLS, rows = rows(list, false), empty = 'Aucun point posé.' }) }
            end },
        } }
    end,
})
