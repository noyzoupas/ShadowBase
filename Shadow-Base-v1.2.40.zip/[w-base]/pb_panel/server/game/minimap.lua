-- Carte rapide (touche M) : la mini-carte du jeu s'agrandit en bas à gauche et un panneau propose les destinations utiles,
-- triées par distance : mes véhicules, mon logement, mon entreprise, mon organisation, mes lieux, puis les services les plus proches.
-- Le serveur construit la liste (il connaît les points, les véhicules et les logements) ; le client met le GPS. La carte plein écran reste sur Échap.

local G, DB = PB.G, PB.DB
local MM = {}
G.MiniMap = MM

PB.Cfg.Define('minimap', { enabled = true, key = 'M', services = true })
local function cfg(k, d) return PB.Cfg.Get('minimap', k, d) end
local function d2(c, x, y) local dx, dy = c.x - (tonumber(x) or 0), c.y - (tonumber(y) or 0) return math.sqrt(dx * dx + dy * dy) end
local function km(m) return m < 1000 and (math.floor(m / 10 + 0.5) * 10 .. ' m') or (('%.1f km'):format(m / 1000):gsub('%.', ',')) end
local function item(c, label, x, y, icon, sub)
    x, y = tonumber(x), tonumber(y)
    if not x or not y or (x == 0 and y == 0) then return nil end
    local m = d2(c, x, y)
    return { label = tostring(label):sub(1, 48), x = x, y = y, icon = icon, sub = sub, d = math.floor(m), right = km(m) }
end
local function nearest(c, list, f)
    local best, bd
    for _, r in ipairs(list or {}) do
        if not f or f(r) then local m = d2(c, r.x, r.y) if not bd or m < bd then best, bd = r, m end end
    end
    return best
end

function MM.List(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    local p = G.Get(src)
    if not p then return nil end
    local sections = {}
    local function sec(title, list)
        local out = {}
        for _, x in ipairs(list) do if x then out[#out + 1] = x end end
        if #out > 0 then sections[#sections + 1] = { title = title, items = out } end
    end

    -- à moi
    local mine = {}
    if G.Garage then
        for _, v in ipairs(G.Garage.Owned(p.license) or {}) do
            local w = G.Garage.Where(v.plate, src)
            if w and w.x then mine[#mine + 1] = item(c, (v.label ~= '' and v.label or v.model) .. ' (' .. v.plate .. ')', w.x, w.y, 'car', w.text) end
        end
    end
    if G.Housing and G.Housing.OwnedBy then
        for _, h in ipairs(G.Housing.OwnedBy(p.license) or {}) do mine[#mine + 1] = item(c, h.label, h.x, h.y, 'home', 'Mon logement') end
    end
    local bc = G.Biz and G.Biz.Ctx(src)
    if bc and G.Points then
        local hq = nearest(c, G.Points.Of('biz', bc.biz.id), function(r) return r.kind == 'hq' or r.kind == 'duty' end)
        if hq then mine[#mine + 1] = item(c, bc.biz.label, hq.x, hq.y, 'briefcase', 'Mon entreprise') end
    end
    local g = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
    if g and G.Points then
        local hq = nearest(c, G.Points.Of('gang', g.id), function(r) return r.kind == 'hq' or r.kind == 'boss' end)
        if hq then mine[#mine + 1] = item(c, g.label, hq.x, hq.y, 'users', 'QG de mon organisation') end
    end
    table.sort(mine, function(a, b) return a and b and a.d < b.d end)
    sec('À moi', mine)

    -- lieux enregistrés (menu Échap › Carte)
    local places = {}
    if G.Pause and G.Pause.Places then for _, pl in ipairs(G.Pause.Places(src) or {}) do places[#places + 1] = item(c, pl.label, pl.x, pl.y, 'pin', 'Lieu enregistré') end end
    table.sort(places, function(a, b) return a and b and a.d < b.d end)
    sec('Mes lieux', places)

    -- services les plus proches
    if cfg('services', true) ~= false then
        local sv = {}
        local shops = DB.q('SELECT kind, label, x, y FROM pb_shops WHERE enabled = 1') or {}
        local SHOPS = { { 'store', 'Supérette', 'cart' }, { 'clothes', 'Vêtements', 'hanger' }, { 'weapons', 'Armurerie', 'crosshair' }, { 'barber', 'Coiffeur', 'scissors' }, { 'tattoo', 'Tatoueur', 'brush' }, { 'dealer', 'Concession', 'car' } }
        for _, s in ipairs(SHOPS) do local r = nearest(c, shops, function(x) return x.kind == s[1] end) if r then sv[#sv + 1] = item(c, s[2], r.x, r.y, s[3], r.label) end end
        if G.Bank and G.Bank.Points then
            local bp = G.Bank.Points()
            local b = nearest(c, bp, function(x) return x.kind ~= 'atm' end) if b then sv[#sv + 1] = item(c, 'Banque', b.x, b.y, 'building', b.label) end
            local a = nearest(c, bp, function(x) return x.kind == 'atm' end) if a then sv[#sv + 1] = item(c, 'Distributeur', a.x, a.y, 'card', a.label) end
        end
        local st = nearest(c, PB.Cfg.Get('fuel', 'stations', {}) or {})
        if st then sv[#sv + 1] = item(c, 'Station-service', st.x, st.y, 'drop', st.label) end
        if G.Garage then
            local gp = G.Garage.Points()
            local r = nearest(c, gp, function(x) return x.kind == 'public' and PB.ToBool(x.enabled) end) if r then sv[#sv + 1] = item(c, 'Garage public', r.x, r.y, 'car', r.label) end
            local i = nearest(c, gp, function(x) return x.kind == 'impound' and PB.ToBool(x.enabled) end) if i then sv[#sv + 1] = item(c, 'Fourrière', i.x, i.y, 'lock', i.label) end
        end
        -- commissariat, hôpital, garage mécanique : sièges des entreprises de ce type
        if G.Biz and G.Biz.List and G.Points then
            local kinds = {}
            for _, b in ipairs(G.Biz.List() or {}) do if PB.ToBool(b.enabled) then kinds[b.id] = b end end
            local hqs = {}
            for _, pt in ipairs(G.Points.All() or {}) do local b = pt.owner_kind == 'biz' and pt.kind == 'hq' and kinds[pt.owner] if b then hqs[#hqs + 1] = { x = pt.x, y = pt.y, kind = b.kind, label = b.label } end end
            for _, k in ipairs({ { 'police', 'Police', 'shield' }, { 'ems', 'Hôpital', 'heart' }, { 'garage', 'Mécanicien', 'engine' } }) do
                local r = nearest(c, hqs, function(x) return x.kind == k[1] end) if r then sv[#sv + 1] = item(c, k[2], r.x, r.y, k[3], r.label) end
            end
        end
        table.sort(sv, function(a, b) return a and b and a.d < b.d end)
        sec('Au plus près', sv)
    end
    return sections
end

local last = {}
AddEventHandler('playerDropped', function() last[source] = nil end)
RegisterNetEvent('pb:g:map:list', function()
    local src = source
    local t = GetGameTimer()
    if last[src] and t - last[src] < 800 then return end
    last[src] = t
    if cfg('enabled', true) == false then return end
    local ok, list = pcall(MM.List, src)
    if not ok then print('[pb_panel] carte rapide : ' .. tostring(list)) list = {} end
    TriggerClientEvent('pb:g:map:list', src, PB.Json({ sections = list or {} }))
end)

G.MiniMapForm = PB.Form.Cfg({ ns = 'minimap', id = 'settings', title = 'Carte rapide (touche M)', perm = 'hud.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Carte rapide', default = true, hint = "M agrandit la mini-carte en bas à gauche avec les destinations rapides ; la carte plein écran reste dans le menu Échap." },
    { k = 'key', type = 'text', label = 'Touche par défaut', default = 'M', maxlen = 12, pattern = '^[%w_]+$', hint = 'Chaque joueur peut la changer dans les raccourcis FiveM.' },
    { k = 'services', type = 'toggle', label = 'Proposer les services les plus proches', default = true, hint = 'Supérette, banque, distributeur, station-service, garage, police, hôpital…' },
} })
