-- ID permanent : chaque compte (licence Rockstar) reçoit un numéro fixe à sa toute première connexion et le garde pour toujours,
-- quel que soit le personnage joué ou l'ordre de connexion. C'est cet ID qui est affiché (tête des joueurs, HUD, /id, menus staff,
-- journaux) et qui est demandé dans les commandes (/goto 12…) ; l'ID de connexion du serveur ne sert plus qu'en interne.
-- Côté client, l'ID est lisible par tous via l'état du joueur : Player(serverId).state.pb_uid.

local G, P, DB = PB.G, PB.Perm, PB.DB
local U = { bySrc = {}, toSrc = {} }
local ready = false   -- la base est prête (migrations passées)
local leaving = {}    -- joueurs en cours de déconnexion : leur ID reste lisible (journaux) mais n'est plus réattribué
G.Uid = U

PB.Migrate('377_uids', 'ID permanent des joueurs', {
    [[CREATE TABLE IF NOT EXISTS pb_uids (
        uid INT NOT NULL AUTO_INCREMENT, license VARCHAR(64) NOT NULL, first_seen INT NOT NULL DEFAULT 0,
        PRIMARY KEY (uid), UNIQUE KEY uq_license (license))]],
    -- comptes déjà connus : numérotés dans l'ordre de leur dernière connexion (les personnages 2 et 3 partagent l'ID du compte)
    [[INSERT IGNORE INTO pb_uids (license, first_seen)
        SELECT license, last_seen FROM pb_players WHERE license NOT LIKE '%#%' ORDER BY last_seen, license]],
})

local function base(src) local l = P.GetLicense(src) return l and (tostring(l):gsub('#%d+$', '')) or nil end

-- numéro du compte (créé à la première demande)
function U.OfLicense(license, create)
    if not license or license == '' then return nil end
    license = tostring(license):gsub('#%d+$', '')
    local r = DB.one('SELECT uid FROM pb_uids WHERE license = ?', { license })
    if not r and create then
        DB.exec('INSERT IGNORE INTO pb_uids (license, first_seen) VALUES (?, ?)', { license, os.time() })
        r = DB.one('SELECT uid FROM pb_uids WHERE license = ?', { license })
    end
    return r and tonumber(r.uid) or nil
end
function U.LicenseOf(uid)
    local r = DB.one('SELECT license FROM pb_uids WHERE uid = ?', { math.floor(tonumber(uid) or 0) })
    return r and r.license or nil
end

-- attribue (ou relit) l'ID d'un joueur connecté et le rend visible de tous les clients
function U.Assign(src)
    src = tonumber(src)
    if not src or src <= 0 then return nil end
    if U.bySrc[src] then return U.bySrc[src] end
    if not ready or leaving[src] then return nil end   -- base pas encore prête : l'ID sera attribué au démarrage (PB.OnReady)
    local uid = U.OfLicense(base(src), true)
    if not uid then return nil end
    local old = U.toSrc[uid]
    if old and old ~= src then U.bySrc[old] = nil end
    U.bySrc[src], U.toSrc[uid] = uid, src
    pcall(function() Player(src).state:set('pb_uid', uid, true) end)
    return uid
end

-- ID permanent d'un joueur connecté (nil si inconnu)
function G.UidOf(src)
    src = tonumber(src)
    if not src then return nil end
    return U.bySrc[src] or (GetPlayerName and GetPlayerName(src) and U.Assign(src)) or nil
end
-- joueur connecté qui porte cet ID permanent (nil s'il n'est pas en ligne)
function G.SrcOfUid(uid)
    local s = U.toSrc[math.floor(tonumber(uid) or -1)]
    if s and G.Get(s) then return s end
    return nil
end
-- texte à afficher : « #12 » (ID permanent ; l'ID de connexion seulement si l'autre n'est pas encore connu)
function G.Tag(src) local u = G.UidOf(src) return '#' .. tostring(u or src) end

AddEventHandler('playerJoining', function()
    local src = source
    leaving[src] = nil
    local old = U.bySrc[src]   -- numéro de connexion réutilisé : on repart de zéro
    if old and U.toSrc[old] == src then U.toSrc[old] = nil end
    U.bySrc[src] = nil
    SetTimeout(0, function() U.Assign(src) end)
end)
table.insert(G.beginHooks, function(src) U.Assign(src) end)
-- à la déconnexion : l'ID reste lisible quelques secondes (les autres scripts écrivent leurs journaux), puis il est libéré
AddEventHandler('playerDropped', function()
    local src = source
    local uid = U.bySrc[src]
    leaving[src] = true
    if uid and U.toSrc[uid] == src then U.toSrc[uid] = nil end   -- plus de joueur en ligne pour cet ID
    SetTimeout(5000, function()
        if leaving[src] then leaving[src] = nil if U.bySrc[src] == uid then U.bySrc[src] = nil end end
    end)
end)
-- redémarrage de la ressource : on renumérote les joueurs déjà là
PB.OnReady(function()
    ready = true
    for _, s in ipairs(GetPlayers and GetPlayers() or {}) do U.Assign(tonumber(s)) end
end)

exports('GetPermanentId', function(src) return G.UidOf(src) end)
exports('GetSourceFromPermanentId', function(uid) return G.SrcOfUid(uid) end)

PB.SelfTest.Add('ID permanent', function(R)
    R.check(DB.TableExists == nil or DB.TableExists('pb_uids'), 'table pb_uids', 'migration non appliquée')
end)
