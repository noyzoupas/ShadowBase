-- Lien Discord ↔ personnage : chaque joueur connecté avec Discord ouvert est relié à son compte. Le bot (module Discord) peut alors
-- lui donner automatiquement des rôles selon le jeu (VIP, métier, groupe illégal) et renommer son pseudo avec le nom du personnage.
-- Seuls les rôles listés ici sont gérés : les autres rôles du membre ne sont jamais touchés.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('discordlink.edit', 'Régler le lien Discord ↔ personnage (rôles automatiques)', 'discord', true)
PB.Migrate('348_discord_link', 'Lien Discord ↔ personnage', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_discord_link (license VARCHAR(80) NOT NULL, discord VARCHAR(32) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, synced INT NOT NULL DEFAULT 0, PRIMARY KEY (license), KEY k_dc (discord))]]))
end)
PB.Cfg.Define('discordlink', { enabled = false, nick = false, require = false, vip_role = '', vip_role2 = '', job_roles = {}, gang_role = '', duty_only = false })
local L = {}
G.DiscordLink = L
local function cfg(k, d) return PB.Cfg.Get('discordlink', k, d) end
local function now() return os.time() end
local function discordOf(src) for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if id:sub(1, 8) == 'discord:' then return id:sub(9) end end end
local function display(src) local i = G.Identity(src) if i and i.created and (i.firstname or '') ~= '' then return (i.firstname .. ' ' .. (i.lastname or '')):sub(1, 32) end return nil end

-- rôles voulus pour ce joueur (parmi les rôles gérés)
function L.Wanted(src)
    local want, managed = {}, {}
    local function m(r) r = tostring(r or '') if r:match('^%d+$') then managed[r] = true return r end end
    local vip = m(cfg('vip_role', ''))
    local gold = m(cfg('vip_role2', ''))
    if G.Vip and G.Vip.Is(src) then if vip then want[vip] = true end if gold then want[gold] = true end end
    local c = G.Biz and G.Biz.Ctx(src)
    for _, row in ipairs(cfg('job_roles', {}) or {}) do
        local r = m(row.role)
        if r and c and c.biz.id == row.biz and (not cfg('duty_only', false) or c.duty) then want[r] = true end
    end
    local gr = m(cfg('gang_role', ''))
    if gr and G.Tags and G.Tags.Gang and G.Tags.Gang(src) then want[gr] = true end
    return want, managed
end
local lastNick = {}
function L.Sync(src)
    if cfg('enabled', false) ~= true or not PB.Discord or not PB.Discord.BotToken() then return false end
    local p = G.Get(src)
    local dc = discordOf(src)
    if not p or not dc then return false end
    local gid = PB.Cfg.Get('discord', 'guild_id', '')
    if gid == '' then return false end
    local have = PB.Discord.MemberRoles(dc)
    if not have then return false end
    local hasSet = {}
    for _, r in ipairs(have) do hasSet[tostring(r)] = true end
    local want, managed = L.Wanted(src)
    for r in pairs(managed) do
        if want[r] and not hasSet[r] then PB.Discord.Api('PUT', ('/guilds/%s/members/%s/roles/%s'):format(gid, dc, r))
        elseif not want[r] and hasSet[r] then PB.Discord.Api('DELETE', ('/guilds/%s/members/%s/roles/%s'):format(gid, dc, r)) end
    end
    if cfg('nick', false) == true then
        local n = display(src)
        if n and lastNick[dc] ~= n then lastNick[dc] = n PB.Discord.Api('PATCH', ('/guilds/%s/members/%s'):format(gid, dc), { nick = n }) end
    end
    DB.exec('UPDATE pb_discord_link SET synced = ? WHERE license = ?', { now(), p.license })
    return true
end
-- une seule synchronisation en attente par joueur (plusieurs changements rapprochés = un seul appel à Discord)
local queued = {}
local function later(src, ms)
    if queued[src] then return end
    queued[src] = true
    SetTimeout(ms or 2000, function() queued[src] = nil if G.Get(src) then pcall(L.Sync, src) end end)
end
AddEventHandler('playerDropped', function() queued[source] = nil end)
table.insert(G.beginHooks, function(src, p)
    local dc = discordOf(src)
    if dc then DB.exec('INSERT INTO pb_discord_link (license, discord, name, at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE discord = VALUES(discord), name = VALUES(name), at = VALUES(at)', { p.license, dc, display(src) or GetPlayerName(src) or '', now() }) end
    later(src, 5000)
end)
AddEventHandler('pb_panel:jobChanged', function(src) later(src) end)
AddEventHandler('pb_panel:duty', function(src) if cfg('duty_only', false) then later(src) end end)
AddEventHandler('pb_panel:vipChanged', function(src) later(src) end)
AddEventHandler('pb_panel:gangChanged', function(src) if src then later(src) end end)
-- Discord obligatoire : refus à la connexion sans Discord ouvert
AddEventHandler('playerConnecting', function(_, _, deferrals)
    if cfg('require', false) ~= true then return end
    local src = source
    if not discordOf(src) then
        deferrals.defer() Wait(0)
        deferrals.done('Ce serveur demande que Discord soit ouvert sur ton PC et relié à FiveM (Paramètres FiveM › Discord), puis reconnecte-toi.')
    end
end)

PB.Action('discordlink.syncall', 'discordlink.edit', function(ctx)
    local n = 0
    for src in pairs(G.Players()) do n = n + 1 later(src, n * 1500) end   -- étalé : pas de limite de débit Discord
    ctx.toast = n .. ' joueur(s) en cours de synchronisation (environ ' .. math.ceil(n * 1.5) .. ' s).'
    return true
end)
local form = PB.Form.Cfg({ ns = 'discordlink', id = 'settings', title = 'Rôles Discord automatiques', perm = 'discordlink.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Donner les rôles Discord selon le jeu', default = false, hint = 'Il faut le jeton du bot et l\'identifiant du serveur Discord (module Discord).' },
    { k = 'nick', type = 'toggle', label = 'Pseudo Discord = nom du personnage', default = false },
    { k = 'require', type = 'toggle', label = 'Discord obligatoire pour se connecter', default = false },
    { k = 'duty_only', type = 'toggle', label = 'Rôle de métier seulement en service', default = false },
    { k = 'vip_role', type = 'text', label = 'Rôle des VIP (identifiant)', default = '', maxlen = 24, pattern = '^%d*$', hint = 'Donne à ce rôle l\'accès aux salons vocaux VIP et au salon textuel VIP (enchères) dans les réglages de ton serveur Discord.' },
    { k = 'vip_role2', type = 'text', label = 'Second rôle des VIP : Gold (identifiant)', default = '', maxlen = 24, pattern = '^%d*$', hint = 'Donné et retiré en même temps que le rôle VIP.' },
    { k = 'gang_role', type = 'text', label = 'Rôle des membres de groupes illégaux (identifiant)', default = '', maxlen = 24, pattern = '^%d*$' },
    { k = 'job_roles', type = 'rows', label = 'Métier → rôle Discord', default = {}, wide = true, maxitems = 40,
      cols = { { k = 'biz', label = "Identifiant de l'entreprise", type = 'text', maxlen = 32, pattern = '^[%w_]+$' }, { k = 'role', label = 'Identifiant du rôle', type = 'text', maxlen = 24, pattern = '^%d+$' } } },
} })
PB.Module({
    id = 'discordlink', label = 'Discord ↔ personnage', icon = 'link', group = 'Système', order = 161, perm = 'discordlink.edit', hint = 'Rôles automatiques, pseudo, Discord obligatoire',
    caps = function() return PB.Capsify({
        { 'Lien compte Discord ↔ personnage', 'ok', 'Enregistré à chaque connexion (Discord ouvert sur le PC du joueur).' },
        { 'Rôles automatiques', PB.Discord and PB.Discord.BotToken() and 'ok' or 'warn', PB.Discord and PB.Discord.BotToken() and 'VIP, métier, groupe : ajoutés et retirés selon le jeu.' or 'Jeton du bot à renseigner dans le module Discord.' },
        { 'Rôles non listés', 'ok', 'Jamais touchés.' },
    }) end,
    doc = "## Discord ↔ personnage\nLe bot doit être sur ton serveur Discord avec la permission **Gérer les rôles** (et **Gérer les pseudos** pour renommer), et son rôle placé au-dessus des rôles qu'il donne.",
    view = function(ctx)
        return { tabs = {
            { id = 'links', label = 'Comptes reliés', icon = 'link', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_discord_link ORDER BY at DESC LIMIT 200') or {}) do rows[#rows + 1] = { name = r.name, discord = r.discord, at = r.at, synced = r.synced > 0 and r.synced or nil } end
                return { B.actions({ { action = 'discordlink.syncall', label = 'Synchroniser les joueurs connectés', icon = 'refresh', primary = true } }),
                    B.table({ id = 'dll', title = 'Comptes reliés', search = true, columns = { { k = 'name', label = 'Personnage' }, { k = 'discord', label = 'Discord', type = 'mono' }, { k = 'at', label = 'Dernière connexion', type = 'date' }, { k = 'synced', label = 'Rôles mis à jour', type = 'date' } }, rows = rows, empty = 'Aucun compte relié.' }) }
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', build = function() return { form(ctx) } end },
        } }
    end,
})
