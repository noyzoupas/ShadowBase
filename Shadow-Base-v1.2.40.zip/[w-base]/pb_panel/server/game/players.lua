-- Gestion des joueurs dans le panel : liste en ligne, fiche, position sur la carte, actions de modération (relever, expulser).
-- Les actions sont réservées (droit « players.moderate »), journalisées et validées côté serveur.
local B, P = PB.B, PB.Perm
local G = PB.G
local DB = PB.DB
local Pl = {}
G.Players_ = Pl

P.Register('players.view', 'Voir les joueurs en ligne (liste, position)', 'players', true)
P.Register('players.sheet', 'Modifier la fiche joueur (grade staff, métier, gang)', 'players', true)
P.Register('players.moderate', 'Modérer les joueurs (relever, expulser)', 'players', true)

local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
function Pl.List()
    local out = {}
    for src, p in pairs(G.Players()) do
        local x, y, z = 0.0, 0.0, 0.0
        if GetPlayerPed and GetEntityCoords then
            local ped = GetPlayerPed(src)
            local c = ped and ped ~= 0 and GetEntityCoords(ped)
            if c then x, y, z = c.x, c.y, c.z end
        end
        local gang = G.Tags and G.Tags.Gang and G.Tags.Gang(src)
        local biz = G.Biz and G.Biz.Ctx and G.Biz.Ctx(src)
        local created = PB.ToBool(p.row.created)
        out[#out + 1] = { id = src, uid = G.UidOf(src) or src, name = (GetPlayerName and GetPlayerName(src)) or G.Tag(src),
            char = created and ((p.row.firstname or '') .. ' ' .. (p.row.lastname or '')) or 'Création en cours',
            gang = gang and gang.label or '', job = biz and biz.biz and biz.biz.label or '', cash = tonumber(p.row.cash) or 0, bank = tonumber(p.row.bank) or 0,
            dead = PB.ToBool(p.row.dead), ping = GetPlayerPing and GetPlayerPing(src) or 0, x = x, y = y, z = z, color = gang and gang.color or nil }
    end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out
end
function Pl.Revive(id) return G.Revive and G.Revive(tonumber(id)) end
function Pl.Kick(id, reason, actor)
    id = tonumber(id)
    if not G.Players()[id] then return false, 'Joueur hors ligne.' end
    reason = PB.Kicks.Cut((tostring(reason or 'Expulsé par un administrateur.'):gsub('[%c]', ' ')), 120)
    PB.Drop(id, 'kick', 'panel', 'Expulsé : ' .. reason, 'Expulsion depuis le panel (module Joueurs).', actor)
    return true
end

PB.Module({
    id = 'players', label = 'Joueurs', icon = 'users', group = 'Serveur', order = 20, perm = 'players.view', hint = 'Liste en ligne, carte, relever, expulser',
    caps = function() return PB.Capsify({
        { 'Liste et fiche', 'ok', 'Joueurs connectés avec personnage, gang, entreprise, argent, latence.' },
        { 'Position sur la carte', 'partial', 'Carte satellite calibrée à ~100 m près ; position lue côté serveur (nécessite OneSync).' },
        { 'Relever / expulser', 'ok', 'Réservé au droit « Modérer les joueurs », journalisé.' },
        { 'Bannissement', 'off', "Pas de bannissement ici : voir l'onglet Sécurité." },
    }) end,
    doc = "## Joueurs\nTout ce qui concerne les joueurs connectés : qui est là, où, et les actions de modération courantes.",
    view = function(ctx) return { tabs = {
        { id = 'list', label = 'En ligne', icon = 'users', build = function()
            local rows, mod = {}, ctx.has('players.moderate')
            for _, v in ipairs(Pl.List()) do
                rows[#rows + 1] = { id = v.id, who = { text = ('#%d %s'):format(v.uid or v.id, (v.char ~= '' and v.char ~= 'Création en cours') and v.char or v.name), src = G.Photos and G.Photos.Of(v.id) or '' },  gang = v.gang ~= '' and v.gang or '—', job = v.job ~= '' and v.job or '—', cash = money(v.cash), bank = money(v.bank), ping = v.ping .. ' ms', state = v.dead and 'À terre' or 'Debout',
                    actions = mod and { { action = 'players.revive', label = 'Relever', icon = 'heart', payload = { id = v.id } }, { action = 'players.kick', label = 'Expulser', icon = 'x', danger = true, payload = { id = v.id } } } or nil }
            end
            return { B.stats({ { label = 'En ligne', value = #rows, icon = 'users' } }),
                B.table({ id = 'plist', search = true, columns = { { k = 'who', label = 'Joueur', type = 'avatar' }, { k = 'gang', label = 'Gang', type = 'badge' }, { k = 'job', label = 'Entreprise' }, { k = 'cash', label = 'Liquide' }, { k = 'bank', label = 'Banque' }, { k = 'ping', label = 'Ping' }, { k = 'state', label = 'État', type = 'badge' } }, rows = rows, empty = 'Personne en ligne.' }) }
        end },
        { id = 'sheet', label = 'Fiche joueur', icon = 'users', build = function()
            if not ctx.has('players.sheet') then return { B.notice('info', 'Droit « Modifier la fiche joueur » requis.') } end
            local pls, opts = {}, {}
            for _, v in ipairs(Pl.List()) do pls[#pls + 1] = { v.id, ('#%d %s'):format(v.uid or v.id, v.char ~= '' and v.char or v.name) } end
            local grades = { { '', 'Aucun grade staff' } }
            for _, g in ipairs(P.Grades()) do grades[#grades + 1] = { g.name, g.label } end
            local function form(action, label, choices)
                return { type = 'form', id = action, title = label, cols = 2, values = {}, submit = { action = action, label = 'Appliquer' }, fields = {
                    { k = 'id', label = 'Joueur', type = 'select', opts = pls, required = true },
                    { k = choices.key, label = choices.label, type = 'select', opts = choices.opts, required = choices.key ~= 'grade' } } }
            end
            return {
                form('players.setrank', 'Grade staff', { key = 'grade', label = 'Grade', opts = grades }),
                form('players.setjob', 'Métier (organisation légale)', { key = 'value', label = 'Métier et grade', opts = Pl.OrgChoices('job') }),
                form('players.setgang', 'Gang (organisation illégale)', { key = 'value', label = 'Gang et grade', opts = Pl.OrgChoices('gang') }),
            }
        end },
        { id = 'gestures', label = 'Gestes', icon = 'star', build = function()
            if not ctx.has('staff.gestures') then return { B.notice('info', 'Droit « Gestes sur un joueur » requis.') } end
            local pls = {}
            for _, v in ipairs(Pl.List()) do pls[#pls + 1] = { v.id, ('#%d %s'):format(v.uid or v.id, v.char ~= '' and v.char or v.name) } end
            local opts = G.Gestures and G.Gestures.PanelOptions(ctx.src) or {}
            local out = { B.notice('info', "Les gestes agissent sur le joueur choisi (vie, déplacement, apparence, animations, médias, troll, véhicule). Le champ « Texte / modèle / adresse » ne sert qu'aux gestes qui en demandent un. Chaque geste est journalisé ; le rang du joueur est vérifié.") }
            out[#out + 1] = { type = 'form', id = 'gesture', title = 'Envoyer un geste', cols = 2, values = {}, submit = { action = 'players.gesture', label = 'Envoyer' }, fields = {
                { k = 'id', label = 'Joueur', type = 'select', opts = pls, required = true },
                { k = 'gesture', label = 'Geste', type = 'select', opts = opts, required = true },
                { k = 'text', label = 'Texte / modèle de ped / adresse du média', type = 'text', maxlen = 300, wide = true },
                { k = 'duration', label = 'Durée (secondes)', type = 'number', min = 3, max = 300 } } }
            if G.GesturesForm and ctx.has('staff.edit') then out[#out + 1] = G.GesturesForm(ctx) end
            return out
        end },
        { id = 'screen', label = 'Écran', icon = 'eye', build = function(_, params)
            if not ctx.has('staff.screen') then return { B.notice('info', "Droit « Voir l'écran d'un joueur » requis.") } end
            local pls = {}
            for _, v in ipairs(Pl.List()) do pls[#pls + 1] = { v.id, ('#%d %s'):format(v.uid or v.id, v.char ~= '' and v.char or v.name) } end
            local shot = G.Gestures and G.Gestures.last and G.Gestures.last[ctx.src]
            local ready = GetResourceState and GetResourceState('screenshot-basic') == 'started'
            local out = { B.notice(ready and 'info' or 'warn', ready and "La capture passe par screenshot-basic : le joueur ne voit rien. Chaque consultation est journalisée. Le direct se regarde en jeu (menu staff › joueur › Gestes › Écran)." or "screenshot-basic n'est pas démarré sur ce serveur : la vue d'écran est indisponible. Installe-le et démarre-le avant pb_panel.") }
            out[#out + 1] = { type = 'form', id = 'screenreq', title = "Demander une capture d'écran", cols = 2, values = {}, submit = { action = 'players.screen', label = 'Capturer' }, fields = {
                { k = 'id', label = 'Joueur', type = 'select', opts = pls, required = true } } }
            if shot then out[#out + 1] = { type = 'image', title = 'Dernière capture : ' .. tostring(shot.name), src = shot.img, caption = os.date('%d/%m/%Y %H:%M:%S', shot.at) .. ' — actualise l\'onglet après avoir demandé une capture.' } end
            return out
        end },
        { id = 'offline', label = 'Hors ligne', icon = 'users', build = function()
            local rows = {}
            for _, r in ipairs(DB.q("SELECT p.license, p.firstname, p.lastname, p.cash, p.bank, p.last_seen, p.created, (SELECT u.uid FROM pb_uids u WHERE u.license = SUBSTRING_INDEX(p.license, '#', 1)) AS uid FROM pb_players p ORDER BY p.last_seen DESC LIMIT 300") or {}) do
                local name = r.created and tonumber(r.created) ~= 0 and (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) or 'Sans personnage'
                local gname = P.GradeOf(r.license)
                rows[#rows + 1] = { id = r.license, uid = r.uid and ('#' .. r.uid) or '—', who = { text = name, src = G.Photos and G.Photos.Url(r.license) or '' }, lic = r.license:gsub('^license:', ''):sub(1, 14), staff = gname and (P.Grade(gname) and P.Grade(gname).label or gname) or '—',
                    cash = money(r.cash), bank = money(r.bank), seen = tonumber(r.last_seen) or 0,
                    actions = { { nav = { tab = 'offsheet', params = { lic = r.license } }, label = 'Fiche', icon = 'users' } } }
            end
            return { B.notice('info', "Tous les joueurs connus du serveur, même hors ligne (les 300 derniers vus). Filtre par ID permanent, nom ou licence, puis ouvre la fiche."),
                B.table({ id = 'offlist', search = true, columns = { { k = 'uid', label = 'ID', type = 'mono' }, { k = 'who', label = 'Joueur', type = 'avatar' }, { k = 'lic', label = 'Licence', type = 'mono' }, { k = 'staff', label = 'Grade staff', type = 'badge' }, { k = 'cash', label = 'Liquide' }, { k = 'bank', label = 'Banque' }, { k = 'seen', label = 'Vu', type = 'date' } }, rows = rows, empty = 'Aucun joueur enregistré.' }) }
        end },
        { id = 'offsheet', label = 'Fiche hors ligne', icon = 'users', hidden = true, build = function(_, params)
            local lic = tostring(params and params.lic or '')
            local r = lic:match('^license:%w+$') and DB.one('SELECT * FROM pb_players WHERE license = ?', { lic })
            if not r then return { B.notice('info', 'Choisis un joueur dans l\'onglet « Hors ligne ».') } end
            return Pl.OfflineSheet(ctx, r)
        end },
        { id = 'map', label = 'Carte', icon = 'map', build = function()
            local pts = {}
            for _, v in ipairs(Pl.List()) do pts[#pts + 1] = { id = v.id, x = v.x, y = v.y, color = v.dead and '#ff5a5a' or v.color or '#ffffff', label = ('#%d %s'):format(v.uid or v.id, v.char ~= '' and v.char or v.name), sub = v.dead and 'à terre' or nil } end
            return { { type = 'map', id = 'pmap', title = 'Joueurs en ligne', desc = 'Positions au moment où tu ouvres l’onglet. Rouge : à terre.', points = pts } }
        end },
    } } end,
})

-- Fiche joueur : grade staff, métier légal, gang illégal (prédéfinis dans leurs onglets respectifs).
local function sheetOf(id)
    id = tonumber(id)
    local p = id and G.Players()[id]
    if not p then return nil end
    return p, id
end
function Pl.OrgChoices(kind)
    local list = PB.Fw and PB.Fw.Groups and PB.Fw.Groups(kind) or {}
    local out = {}
    for _, g in ipairs(list or {}) do
        for _, gr in ipairs(g.grades or {}) do out[#out + 1] = { g.name .. ':' .. gr.grade, ('%s — %s'):format(g.label, gr.label) } end
    end
    return out
end
PB.Action('players.setrank', 'players.sheet', function(ctx, p)
    local pl, id = sheetOf(p.id)
    if not pl then return false, 'Joueur hors ligne.' end
    local grade = p.grade ~= '' and p.grade or nil
    if grade and not P.Grade(grade) then return false, 'Grade inconnu.' end
    local ok, e = P.SetStaff(ctx.src, pl.license, GetPlayerName and GetPlayerName(id) or G.Tag(id), grade)
    if not ok then return false, e end
    ctx.audit('staff', 'players.setrank', ('%d -> %s'):format(id, tostring(grade or 'aucun')))
    ctx.toast = grade and 'Grade staff attribué.' or 'Grade staff retiré.'
    return true
end)
local function setOrg(kind)
    return function(ctx, p)
        local pl, id = sheetOf(p.id)
        if not pl then return false, 'Joueur hors ligne.' end
        local name, gr = tostring(p.value or ''):match('^([%w_%-]+):(%d+)$')
        if not name then return false, 'Choisis un groupe et un grade.' end
        local ok, e = PB.Fw.Assign(kind, { src = id, id = pl.license }, name, tonumber(gr))
        if not ok then return false, e end
        ctx.audit('staff', 'players.set' .. kind, ('%d -> %s:%s'):format(id, name, gr))
        ctx.toast = kind == 'gang' and 'Gang attribué.' or 'Métier attribué.'
        return true
    end
end
PB.Action('players.setjob', 'players.sheet', setOrg('job'))
PB.Action('players.setgang', 'players.sheet', setOrg('gang'))
PB.Action('players.revive', 'players.moderate', function(ctx, p)
    local id = tonumber(p.id)
    if not id or not G.Players()[id] then return false, 'Joueur hors ligne.' end
    Pl.Revive(id)
    ctx.audit('staff', 'players.revive', tostring(id))
    ctx.toast = 'Joueur relevé.'
    return true
end)
PB.Action('players.kick', 'players.moderate', function(ctx, p)
    local ok, e = Pl.Kick(p.id, p.reason, ctx.actor and ctx.actor.name)
    if not ok then return false, e end
    ctx.audit('staff', 'players.kick', tostring(p.id))
    ctx.toast = 'Joueur expulsé.'
    return true
end)
PB.SelfTest.Add('joueurs', function(R)
    R.check(type(Pl.List()) == 'table', 'liste des joueurs lisible', 'erreur de lecture')
end)


-- Fiche d'un joueur hors ligne ---------------------------------------------------------------------------------------------------------------
function Pl.OfflineSheet(ctx, r)
    local gname = P.GradeOf(r.license)
    local g = gname and P.Grade(gname)
    local name = (tonumber(r.created) or 0) ~= 0 and (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) or 'Sans personnage'
    local online
    for id, p in pairs(G.Players()) do if p.license == r.license then online = id end end
    local photo, kind = G.Photos and G.Photos.Url(r.license)
    local sanc = {}
    for _, s in ipairs(DB.q("SELECT id, kind, reason, by_name, created, expires, revoked FROM pb_sanctions WHERE license = ? ORDER BY id DESC LIMIT 20", { r.license }) or {}) do
        sanc[#sanc + 1] = { kind = s.kind, reason = s.reason, by = s.by_name, at = s.created, state = (tonumber(s.revoked) or 0) ~= 0 and 'Levé' or ((tonumber(s.expires) or 0) == 0 and (s.kind == 'ban' and 'Définitif' or '—') or ('jusqu\'au ' .. os.date('%d/%m/%Y', s.expires))) }
    end
    local out = {}
    if photo then out[#out + 1] = { type = 'image', title = 'Photo (' .. (kind == 'portrait' and 'portrait du personnage' or 'Discord') .. ')', src = photo } end
    out[#out + 1] = PB.B.kv(name, { { 'Licence', r.license }, { 'Naissance', (r.dob ~= '' and r.dob) or '—' }, { 'Sexe', r.sex == 'f' and 'Femme' or 'Homme' }, { 'Taille', tostring(r.height) .. ' cm' }, { 'Nationalité', (r.nationality ~= '' and r.nationality) or '—' },
        { 'Liquide', money(r.cash) }, { 'Banque', money(r.bank) }, { 'Grade staff', g and g.label or 'Aucun' }, { 'Dernière connexion', (tonumber(r.last_seen) or 0) > 0 and os.date('%d/%m/%Y %H:%M', r.last_seen) or '—' }, { 'ID permanent', G.Uid and G.Uid.OfLicense(r.license) and ('#' .. G.Uid.OfLicense(r.license)) or '—' }, { 'État', online and ('En ligne (' .. G.Tag(online) .. ')') or 'Hors ligne' } })
    local gopts = { { '', 'Aucun grade staff' } }
    for _, x in ipairs(P.Grades()) do gopts[#gopts + 1] = { x.name, x.label } end
    local function f(action, title, fields, label) return { type = 'form', id = action, title = title, cols = 2, values = {}, submit = { action = action, label = label or 'Appliquer', payload = { lic = r.license } }, fields = fields } end
    if ctx.has('players.sheet') then out[#out + 1] = f('players.off.setrank', 'Grade staff', { { k = 'grade', label = 'Grade', type = 'select', opts = gopts } }) end
    if ctx.has('staff.money') then out[#out + 1] = f('players.off.money', 'Argent', { { k = 'account', label = 'Compte', type = 'select', opts = { { 'cash', 'Liquide' }, { 'bank', 'Banque' } }, required = true }, { k = 'amount', label = 'Montant (négatif pour retirer)', type = 'number', required = true } }) end
    if ctx.has('staff.warn') then out[#out + 1] = f('players.off.warn', 'Avertissement', { { k = 'reason', label = 'Motif', type = 'text', maxlen = 120, required = true, wide = true } }, 'Avertir') end
    if ctx.has('staff.ban') then out[#out + 1] = f('players.off.ban', 'Bannissement', { { k = 'minutes', label = 'Durée en minutes (0 = définitif)', type = 'number', min = 0, max = 525600, required = true }, { k = 'reason', label = 'Motif', type = 'text', maxlen = 120, required = true } }, 'Bannir') end
    out[#out + 1] = PB.B.table({ id = 'offsanc', title = 'Sanctions', columns = { { k = 'kind', label = 'Type', type = 'badge' }, { k = 'reason', label = 'Motif' }, { k = 'by', label = 'Par' }, { k = 'at', label = 'Date', type = 'date' }, { k = 'state', label = 'Durée / état' } }, rows = sanc, empty = 'Aucune sanction.' })
    return out
end
local function offTarget(ctx, p, perm)
    local lic = tostring(p.lic or '')
    local r = lic:match('^license:%w+$') and DB.one('SELECT license, firstname, lastname, created FROM pb_players WHERE license = ?', { lic })
    if not r then return nil, 'Joueur inconnu.' end
    local gname = P.GradeOf(lic)
    local gl = gname and P.Grade(gname)
    if gl and (tonumber(gl.level) or 0) >= P.Level(ctx.src) and P.Level(ctx.src) < 1000 then return nil, 'Ce joueur a un grade supérieur ou égal au tien.' end
    local name = (tonumber(r.created) or 0) ~= 0 and (((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', '')) or 'Inconnu'
    return r, nil, name
end
local function onlineOf(lic) for id, p in pairs(G.Players()) do if p.license == lic then return id, p end end end
PB.Action('players.off.setrank', 'players.sheet', function(ctx, p)
    local r, err, name = offTarget(ctx, p) if not r then return false, err end
    local grade = tostring(p.grade or '') ~= '' and tostring(p.grade) or nil
    if grade and not P.Grade(grade) then return false, 'Grade inconnu.' end
    local ok, e = P.SetStaff(ctx.src, r.license, name, grade)
    if not ok then return false, e end
    ctx.audit('staff', 'players.off.setrank', ('%s -> %s'):format(r.license, tostring(grade or 'aucun')))
    ctx.toast = grade and 'Grade staff attribué.' or 'Grade staff retiré.'
    return true
end)
PB.Action('players.off.money', 'staff.money', function(ctx, p)
    local r, err, name = offTarget(ctx, p) if not r then return false, err end
    local acc = p.account == 'bank' and 'bank' or (p.account == 'cash' and 'cash' or nil)
    local n = math.floor(tonumber(p.amount) or 0)
    local max = PB.Cfg.Get('staff', 'money_max', 1000000)
    if not acc or n == 0 or math.abs(n) > max then return false, 'Montant invalide (0 ou trop grand).' end
    local id = onlineOf(r.license)
    if id then
        if n > 0 then G.AddMoney(id, acc, n) elseif not G.RemoveMoney(id, acc, -n) then return false, 'Pas assez de fonds.' end
    else
        local cur = DB.one('SELECT ' .. acc .. ' AS v FROM pb_players WHERE license = ?', { r.license })
        if n < 0 and (tonumber(cur and cur.v) or 0) < -n then return false, 'Pas assez de fonds.' end
        DB.exec('UPDATE pb_players SET ' .. acc .. ' = ' .. acc .. ' + ? WHERE license = ?', { n, r.license })
    end
    ctx.audit('staff', 'players.off.money', ('%s %s %+d'):format(r.license, acc, n))
    ctx.toast = ('%s : %+d $.'):format(acc == 'bank' and 'Banque' or 'Liquide', n)
    return true
end)
PB.Action('players.off.warn', 'staff.warn', function(ctx, p)
    local r, err, name = offTarget(ctx, p) if not r then return false, err end
    local reason = PB.Trim(PB.Sanitize(tostring(p.reason or ''), 120))
    if reason == '' then return false, 'Motif obligatoire.' end
    G.Staff.AddSanction('warn', r.license, name, reason, ctx.src, 0, { r.license })
    local id = onlineOf(r.license)
    if id then G.Notify(id, { type = 'warn', title = 'Avertissement', text = reason, duration = 15000 }) end
    ctx.audit('staff', 'players.off.warn', r.license .. ' : ' .. reason)
    ctx.toast = 'Avertissement enregistré.'
    return true
end)
PB.Action('players.off.ban', 'staff.ban', function(ctx, p)
    local r, err, name = offTarget(ctx, p) if not r then return false, err end
    local reason = PB.Trim(PB.Sanitize(tostring(p.reason or ''), 120))
    if reason == '' then return false, 'Motif obligatoire.' end
    local m = math.floor(tonumber(p.minutes) or -1)
    if m < 0 or m > 525600 then return false, 'Durée invalide.' end
    G.Staff.AddSanction('ban', r.license, name, reason, ctx.src, m, { r.license })
    local id = onlineOf(r.license)
    if id then PB.Drop(id, 'ban', 'panel', 'Banni : ' .. reason, ('Ban depuis le panel (module Joueurs), %s.'):format(m == 0 and 'définitif' or (m .. ' min')), ctx.actor and ctx.actor.name) end
    ctx.audit('staff', 'players.off.ban', ('%s %s min : %s'):format(r.license, m, reason))
    ctx.toast = name .. ' est banni.'
    return true
end, { critical = true })
PB.Action('players.screen', 'staff.screen', function(ctx, p)
    local id = tonumber(p.id)
    if not id or not G.Get(id) then return false, 'Joueur introuvable.' end
    local ok, msg = G.Gestures.Run(ctx.src, 'screen_shot', id, {}, true)
    if not ok then return false, msg end
    ctx.toast = msg
    return true
end)
