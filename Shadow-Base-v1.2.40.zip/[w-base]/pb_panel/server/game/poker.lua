-- Poker (Texas Hold'em) entre joueurs, aux tables posées au Builder (Casino › Jeu › Poker). On s'assoit avec une cave en jetons,
-- les blindes tournent, quatre tours d'enchères, pots secondaires quand quelqu'un est à tapis, commission du casino dès le flop.
-- Tout est décidé par le serveur (paquet, ordre de parole, mains) : l'interface n'affiche que ce que le serveur lui envoie.
local G = PB.G
local Ca = G.Casino
local Pk = { tables = {}, seatOf = {} }   -- seatOf[src] = { t = id de table, i = place }
G.Poker = Pk
local CHIP = Ca.CHIP

local function cfg(k, d) return PB.Cfg.Get('casino', k, d) end
local function num(k, d) return tonumber(cfg(k, d)) or d end
local function now() return os.time() end
local function fmt(n) return tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '') end
PB.Cfg.Define('casino', { tourney_stack = 1500, tourney_sb = 10, tourney_level_min = 5, tourney_min = 100, tourney_max = 50000, tourney_fee = 10 })
PB.Migrate('349_poker_tourneys', 'Casino : tournois de poker', function()
    PB.DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_poker_tourneys (id INT NOT NULL AUTO_INCREMENT, at INT NOT NULL, tbl VARCHAR(64) NOT NULL DEFAULT '', buyin INT NOT NULL DEFAULT 0, pot INT NOT NULL DEFAULT 0, players INT NOT NULL DEFAULT 0, winner VARCHAR(64) NOT NULL DEFAULT '', results TEXT NULL, PRIMARY KEY (id), KEY k_at (at))]]))
end)
-- blindes : celles de la table d'argent, ou celles du niveau du tournoi (elles doublent toutes les N minutes)
local function blinds(t)
    local tr = t and t.tour
    if tr and tr.started then
        local lvl = math.floor((now() - tr.started) / (math.max(1, num('tourney_level_min', 5)) * 60))
        local sb = math.floor(math.max(1, num('tourney_sb', 10)) * 2 ^ math.min(lvl, 12))
        return sb, sb * 2, lvl + 1
    end
    local sb = math.max(1, math.floor(num('poker_sb', 10)))
    return sb, math.max(sb, math.floor(num('poker_bb', 20))), nil
end
-- peut jouer la prochaine main : tapis ≥ grosse blinde (table d'argent) ; en tournoi, il suffit d'avoir des jetons (on joue à tapis)
local function canPlay(t, s, bb) if t.tour and t.tour.started then return s.stack > 0 end return s.stack >= bb and not s.away end
local function buyRange() local _, bb = blinds(nil) return math.floor(num('poker_min_buy', 20) * bb), math.floor(num('poker_max_buy', 100) * bb) end
local function maxSeats() return math.max(2, math.min(6, math.floor(num('poker_seats', 6)))) end

-- Cartes : 0 à 51 ; rang = c % 13 (0 = deux … 12 = as), couleur = c // 13 (même codage que le blackjack)
local function newDeck()
    local d = {}
    for i = 0, 51 do d[#d + 1] = i end
    for i = #d, 2, -1 do local j = math.random(i) d[i], d[j] = d[j], d[i] end
    return d
end
local function cardOut(c) return { r = c % 13, s = c // 13 } end

-- Évaluation : meilleure main de 5 cartes parmi 7 -> score comparable (plus grand = meilleur) et nom de la main ---------------------------
local NAMES = { [0] = 'Carte haute', 'Paire', 'Deux paires', 'Brelan', 'Quinte', 'Couleur', 'Full', 'Carré', 'Quinte flush' }
Pk.NAMES = NAMES
local function straightHigh(set)
    for hi = 12, 4, -1 do
        local ok = true
        for k = 0, 4 do if not set[hi - k] then ok = false break end end
        if ok then return hi end
    end
    if set[12] and set[0] and set[1] and set[2] and set[3] then return 3 end   -- quinte blanche (as, 2, 3, 4, 5)
    return nil
end
local function score(cat, ks) local s = cat for i = 1, 5 do s = s * 16 + (ks[i] or 0) end return s end
function Pk.Eval(cards)
    local cnt, bySuit, set = {}, { [0] = {}, {}, {}, {} }, {}
    for _, c in ipairs(cards) do
        local r, su = c % 13, c // 13
        cnt[r] = (cnt[r] or 0) + 1
        bySuit[su][#bySuit[su] + 1] = r
        set[r] = true
    end
    local flush
    for su = 0, 3 do
        if #bySuit[su] >= 5 then
            local fs = {}
            for _, r in ipairs(bySuit[su]) do fs[r] = true end
            local sh = straightHigh(fs)
            if sh then return score(8, { sh }), sh == 12 and 'Quinte flush royale' or NAMES[8] end
            table.sort(bySuit[su], function(a, b) return a > b end)
            flush = { bySuit[su][1], bySuit[su][2], bySuit[su][3], bySuit[su][4], bySuit[su][5] }
        end
    end
    local groups = {}
    for r, n in pairs(cnt) do groups[#groups + 1] = { r = r, n = n } end
    table.sort(groups, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.r > b.r end)
    local function kick(excl, n)
        local out = {}
        for r = 12, 0, -1 do if cnt[r] and not excl[r] then out[#out + 1] = r if #out >= n then break end end end
        return out
    end
    local top = groups[1]
    if top.n == 4 then local k = kick({ [top.r] = true }, 1) return score(7, { top.r, k[1] }), NAMES[7] end
    if top.n == 3 then
        local pair
        for i = 2, #groups do if groups[i].n >= 2 and (not pair or groups[i].r > pair) then pair = groups[i].r end end
        if pair then return score(6, { top.r, pair }), NAMES[6] end
    end
    if flush then return score(5, flush), NAMES[5] end
    local sh = straightHigh(set)
    if sh then return score(4, { sh }), NAMES[4] end
    if top.n == 3 then local k = kick({ [top.r] = true }, 2) return score(3, { top.r, k[1], k[2] }), NAMES[3] end
    if top.n == 2 and groups[2] and groups[2].n == 2 then
        local a, b = top.r, groups[2].r
        local k = kick({ [a] = true, [b] = true }, 1)
        return score(2, { a, b, k[1] }), NAMES[2]
    end
    if top.n == 2 then local k = kick({ [top.r] = true }, 3) return score(1, { top.r, k[1], k[2], k[3] }), NAMES[1] end
    return score(0, kick({}, 5)), NAMES[0]
end

-- Tables -------------------------------------------------------------------------------------------------------------------------------------
local function tableFor(pt)
    local t = Pk.tables[pt.id]
    if not t then
        t = { id = pt.id, label = pt.label, seats = {}, button = 0, watchers = {}, log = {} }
        Pk.tables[pt.id] = t
    end
    t.label = pt.label
    return t
end
local function addLog(t, txt) table.insert(t.log, 1, txt) if #t.log > 8 then table.remove(t.log) end end
-- prochaine place (après i, en tournant) qui vérifie ok(place)
local function nextSeat(t, i, ok)
    local n = maxSeats()
    for k = 1, n do
        local j = ((i + k - 1) % n) + 1
        if ok(j) then return j end
    end
end
local function hp(t, i) return t.hand and t.hand.players[i] end
local function alive(t, i) local p = hp(t, i) return p and not p.folded end
local function canAct(t, i) local p = hp(t, i) return p and not p.folded and not p.allin and t.seats[i] ~= nil end

-- Vue envoyée à un joueur : ses cartes, celles des autres seulement à l'abattage
function Pk.View(t, src)
    local h, me = t.hand, Pk.seatOf[src]
    local mine = me and me.t == t.id and me.i or nil
    local seats = {}
    for i = 1, maxSeats() do
        local s, p = t.seats[i], hp(t, i)
        local e = { i = i }
        if s then
            e.name, e.stack, e.me = s.name, s.stack, i == mine
            e.out = (not p) and true or nil
        elseif p then e.name, e.stack, e.left = p.name, 0, true end
        if p then
            e.bet, e.folded, e.allin, e.last = p.bet, p.folded or nil, p.allin or nil, p.last
            if i == mine or (h.shown and h.shown[i]) then e.cards = { cardOut(p.cards[1]), cardOut(p.cards[2]) } elseif not p.folded then e.hidden = 2 end
            if h.shown and h.shown[i] then e.hand = h.shown[i] end
            if h.won and h.won[i] then e.won = h.won[i] end
        end
        e.button = (t.button == i) or nil
        e.turn = (h and not h.over and h.turn == i) or nil
        if s or p then seats[#seats + 1] = e end
    end
    local sb, bb, lvl = blinds(t)
    local minB, maxB = buyRange()
    local v = { id = t.id, label = t.label, sb = sb, bb = bb, minBuy = minB, maxBuy = maxB, seats = seats, max = maxSeats(), mySeat = mine, log = t.log, rake = num('poker_rake', 5),
        locked = t.pass ~= nil or nil, isHost = (t.host == src) or nil }
    local tr = t.tour
    if tr then
        local n = 0 for _ in pairs(tr.entrants) do n = n + 1 end
        local lvlSecs = math.max(1, num('tourney_level_min', 5)) * 60
        v.tour = { buyin = tr.buyin, pot = tr.pot, prizes = Pk.Prizes(tr.pot, n), entrants = n, started = tr.started and true or nil, level = lvl,
            nextLevel = tr.started and (lvlSecs - (now() - tr.started) % lvlSecs) or nil, stack = math.floor(num('tourney_stack', 1500)), mine = tr.entrants[src] ~= nil or nil, host = tr.host == src or nil }
    else
        v.tourney = { min = math.floor(num('tourney_min', 100)), max = math.floor(num('tourney_max', 50000)), stack = math.floor(num('tourney_stack', 1500)), fee = num('tourney_fee', 10) }
    end
    if h then
        local pot = 0
        for _, p in pairs(h.players) do pot = pot + p.total end
        v.board, v.pot, v.street, v.over = {}, pot, h.street, h.over or nil
        for _, c in ipairs(h.board) do v.board[#v.board + 1] = cardOut(c) end
        v.left = (not h.over and h.deadline) and math.max(0, h.deadline - now()) or nil
        v.turnSecs = math.floor(num('poker_turn', 25))
        if mine and not h.over and h.turn == mine and canAct(t, mine) then
            local p, s = h.players[mine], t.seats[mine]
            v.toCall = math.min(h.cur - p.bet, s.stack)
            v.minTo = math.min(h.cur + h.minRaise, p.bet + s.stack)
            v.maxTo = p.bet + s.stack
            v.myBet = p.bet
            v.canCheck = h.cur - p.bet <= 0
        end
        if h.result then v.result = h.result end
    end
    v.nextIn = (t.nextAt and (not h or h.over)) and math.max(0, t.nextAt - now()) or nil
    if mine then local s = t.seats[mine] v.canRebuy = s and (not h or h.over or not alive(t, mine)) and s.stack < maxB or nil end
    return v
end
function Pk.Push(t, except)
    local sent = {}
    local function send(src)
        if sent[src] or src == except or not GetPlayerName(src) then return end
        sent[src] = true
        TriggerClientEvent('pb:g:casino:res', src, PB.Json({ game = 'poker', action = 'state', ok = true, data = Pk.View(t, src) }))
    end
    for i = 1, maxSeats() do if t.seats[i] then send(t.seats[i].src) end end
    for src in pairs(t.watchers) do send(src) end
end

-- Déroulement d'une main ---------------------------------------------------------------------------------------------------------------------
local function setTurn(t, i)
    t.hand.turn = i
    t.hand.deadline = now() + math.floor(num('poker_turn', 25))
end
local function put(t, i, a)
    local p, s = t.hand.players[i], t.seats[i]
    a = math.max(0, math.min(a, s.stack))
    s.stack = s.stack - a
    p.bet, p.total = p.bet + a, p.total + a
    if s.stack <= 0 then p.allin = true end
    return a
end
local function give(t, i, n, h)
    if n <= 0 then return end
    local s = t.seats[i]
    if s then s.stack = s.stack + n end
    h.won[i] = (h.won[i] or 0) + n
end

local finish
-- Pots : par niveaux de mise (pots secondaires quand quelqu'un est à tapis) ; seuls les joueurs encore en jeu peuvent gagner un niveau
local function layers(h)
    local levels, seen = {}, {}
    for _, p in pairs(h.players) do if p.total > 0 and not seen[p.total] then seen[p.total] = true levels[#levels + 1] = p.total end end
    table.sort(levels)
    local out, prev = {}, 0
    for _, L in ipairs(levels) do
        local amt, elig = 0, {}
        for i, p in pairs(h.players) do
            amt = amt + math.max(0, math.min(p.total, L) - math.min(p.total, prev))
            if not p.folded and p.total >= L then elig[#elig + 1] = i end
        end
        table.sort(elig)
        if amt > 0 then
            if #elig == 0 and #out > 0 then out[#out].amt = out[#out].amt + amt   -- (ne devrait pas arriver) rendu au niveau précédent
            elseif #out > 0 and table.concat(out[#out].elig, ',') == table.concat(elig, ',') then out[#out].amt = out[#out].amt + amt   -- mêmes joueurs : un seul pot
            else out[#out + 1] = { amt = amt, elig = elig } end
        end
        prev = L
    end
    return out
end
Pk.Layers = layers

local function takeRake(h, pots)
    if #h.board < 3 then return 0 end   -- pas de flop, pas de commission
    local total = 0
    for _, l in ipairs(pots) do total = total + l.amt end
    local rake = math.min(math.floor(num('poker_rake_cap', 500)), math.floor(total * num('poker_rake', 5) / 100))
    local left = rake
    for _, l in ipairs(pots) do local d = math.min(left, l.amt) l.amt, left = l.amt - d, left - d end
    return rake - left
end

local function showdown(t)
    local h = t.hand
    h.shown, h.won = {}, {}
    local scores = {}
    for i, p in pairs(h.players) do
        if not p.folded then
            local seven = { p.cards[1], p.cards[2] }
            for _, c in ipairs(h.board) do seven[#seven + 1] = c end
            local sc, name = Pk.Eval(seven)
            scores[i], h.shown[i] = sc, name
        end
    end
    local pots = layers(h)
    h.rake = takeRake(h, pots)
    local lines = {}
    for k, l in ipairs(pots) do
        local best, win = -1, {}
        for _, i in ipairs(l.elig) do
            if scores[i] > best then best, win = scores[i], { i } elseif scores[i] == best then win[#win + 1] = i end
        end
        local share = math.floor(l.amt / #win)
        local rest = l.amt - share * #win
        -- le jeton en trop va au premier gagnant après le bouton
        table.sort(win, function(a, b) return ((a - t.button - 1) % maxSeats()) < ((b - t.button - 1) % maxSeats()) end)
        for n, i in ipairs(win) do give(t, i, share + (n == 1 and rest or 0), h) end
        local names = {}
        for _, i in ipairs(win) do names[#names + 1] = h.players[i].name end
        lines[#lines + 1] = ('%s%s : %s (%s)'):format(k == 1 and 'Pot principal' or ('Pot secondaire ' .. (k - 1)), '', table.concat(names, ', '), h.shown[win[1]])
    end
    for _, l in ipairs(lines) do addLog(t, l) end
    h.result = { lines = lines, rake = h.rake }
end

local function nextStreet(t)
    local h = t.hand
    for _, p in pairs(h.players) do p.bet, p.acted = 0, false end
    local _, bb = blinds(t)
    h.cur, h.minRaise = 0, bb
    local function deal(n) for _ = 1, n do h.board[#h.board + 1] = table.remove(h.deck) end end
    if h.street == 'pre' then table.remove(h.deck) deal(3) h.street = 'flop'
    elseif h.street == 'flop' then table.remove(h.deck) deal(1) h.street = 'turn'
    elseif h.street == 'turn' then table.remove(h.deck) deal(1) h.street = 'river'
    else showdown(t) finish(t) return end
    local actors = 0
    for i in pairs(h.players) do if canAct(t, i) then actors = actors + 1 end end
    if actors <= 1 then return nextStreet(t) end   -- tout le monde à tapis : on dévoile jusqu'à la rivière
    setTurn(t, nextSeat(t, t.button, function(j) return canAct(t, j) end))
end

local function advance(t)
    local h = t.hand
    local left, last = 0, nil
    for i, p in pairs(h.players) do if not p.folded then left, last = left + 1, i end end
    if left == 1 then
        -- tout le monde s'est couché : le dernier prend tout, sans abattage
        h.won = {}
        local pots = layers(h)
        h.rake = takeRake(h, pots)
        local total = 0
        for _, l in ipairs(pots) do total = total + l.amt end
        give(t, last, total, h)
        addLog(t, ('%s remporte %s jetons'):format(h.players[last].name, fmt(total)))
        h.result = { lines = { ('%s remporte le pot (tout le monde s\'est couché)'):format(h.players[last].name) }, rake = h.rake }
        return finish(t)
    end
    local pending
    for i in pairs(h.players) do
        local p = h.players[i]
        if canAct(t, i) and (not p.acted or p.bet < h.cur) then pending = true end
    end
    if pending then
        local j = nextSeat(t, h.turn or t.button, function(k) local p = h.players[k] return canAct(t, k) and (not p.acted or p.bet < h.cur) end)
        local actors = 0
        for i in pairs(h.players) do if canAct(t, i) then actors = actors + 1 end end
        -- un seul joueur peut encore parler et il a déjà égalisé : rien à décider
        if j and not (actors == 1 and h.players[j].bet >= h.cur) then setTurn(t, j) return end
    end
    nextStreet(t)
end

finish = function(t)
    local h = t.hand
    h.over, h.turn, h.deadline = true, nil, nil
    t.nextAt = now() + 7
    for i, s in pairs(t.seats) do
        local p = h.players[i]
        if p then
            local net = (h.won[i] or 0) - p.total
            s.net = (s.net or 0) + net
            if not t.tour and s.stack < select(2, blinds(t)) then G.Notify(s.src, { type = 'warn', title = 'Poker', text = 'Tu n\'as plus assez de jetons : recave ou lève-toi.' }) end
        end
    end
    if t.tour and t.tour.started then
        local out = {}
        for i, s in pairs(t.seats) do if s.stack <= 0 then out[#out + 1] = i end end
        for _, i in ipairs(out) do Pk.Eliminate(t, i) end
        local left = 0 for _ in pairs(t.seats) do left = left + 1 end
        if left <= 1 then Pk.EndTourney(t) end
    end
    Pk.Push(t)
end

function Pk.Start(t)
    local sb, bb = blinds(t)
    local ready = {}
    for i, s in pairs(t.seats) do if canPlay(t, s, bb) then ready[i] = true end end
    local n = 0 for _ in pairs(ready) do n = n + 1 end
    t.nextAt = nil
    if n < 2 then t.hand = nil Pk.Push(t) return false end
    t.button = nextSeat(t, t.button, function(j) return ready[j] end)
    local h = { deck = newDeck(), board = {}, street = 'pre', players = {}, won = {} }
    t.hand = h
    for i in pairs(ready) do
        h.players[i] = { cards = { table.remove(h.deck), table.remove(h.deck) }, bet = 0, total = 0, name = t.seats[i].name }
    end
    local sbI, bbI
    if n == 2 then sbI = t.button else sbI = nextSeat(t, t.button, function(j) return ready[j] end) end
    bbI = nextSeat(t, sbI, function(j) return ready[j] end)
    put(t, sbI, sb) h.players[sbI].last = 'Petite blinde'
    put(t, bbI, bb) h.players[bbI].last = 'Grosse blinde'
    h.cur, h.minRaise, h.turn = bb, bb, bbI
    addLog(t, ('Nouvelle main : blindes %s / %s'):format(fmt(sb), fmt(bb)))
    if Ca.Dealer then local pt for _, x in ipairs(PB.Cfg.Get('casino', 'points', {}) or {}) do if x.id == t.id then pt = x end end pcall(Ca.Dealer, pt) end
    local first = nextSeat(t, bbI, function(j) return canAct(t, j) end)
    if not first then nextStreet(t) else
        h.turn = bbI
        advance(t)
    end
    Pk.Push(t)
    return true
end

-- Actions d'un joueur ------------------------------------------------------------------------------------------------------------------------
local ACT_LABEL = { fold = 'Se couche', check = 'Parole', call = 'Suit', raise = 'Relance', allin = 'Tapis' }
function Pk.Act(t, i, action, amount)
    local h = t.hand
    if not h or h.over or h.turn ~= i or not canAct(t, i) then return false, 'Ce n\'est pas à toi de parler.' end
    local p, s = h.players[i], t.seats[i]
    local toCall = h.cur - p.bet
    if action == 'check' then
        if toCall > 0 then return false, 'Tu dois suivre, relancer ou te coucher.' end
        p.last = 'Parole'
    elseif action == 'fold' then
        p.folded, p.last = true, 'Couché'
    elseif action == 'call' then
        if toCall <= 0 then p.last = 'Parole' else put(t, i, toCall) p.last = p.allin and 'Tapis' or ('Suit ' .. fmt(p.bet)) end
    elseif action == 'raise' or action == 'allin' then
        local maxTo = p.bet + s.stack
        local to = action == 'allin' and maxTo or math.floor(tonumber(amount) or 0)
        if to >= maxTo then to = maxTo end
        if to <= h.cur then
            if to < maxTo then return false, 'Relance trop petite.' end
            put(t, i, to - p.bet) p.last = 'Tapis'           -- tapis inférieur à la mise en cours : simple suivi
        else
            if to < h.cur + h.minRaise and to < maxTo then return false, ('Relance minimale : %s.'):format(fmt(h.cur + h.minRaise)) end
            if to - h.cur >= h.minRaise then h.minRaise = to - h.cur end
            h.cur = to
            put(t, i, to - p.bet)
            p.last = p.allin and 'Tapis' or ((toCall > 0 and 'Relance à ' or 'Mise ') .. fmt(to))
            for j, q in pairs(h.players) do if j ~= i then q.acted = false end end
        end
    else return false, 'Action inconnue.' end
    p.acted = true
    s.timeouts = 0
    addLog(t, ('%s : %s'):format(p.name, p.last))
    advance(t)
    return true
end

-- S'asseoir, recaver, se lever ---------------------------------------------------------------------------------------------------------------
local function nearTable(src)
    local pt = Ca.Near(src, 'poker', 4.0)
    return pt and tableFor(pt)
end
function Pk.Sit(src, amount, pass)
    if Pk.seatOf[src] then return false, 'Tu es déjà assis(e) à une table.' end
    local t = nearTable(src)
    if not t then return false, 'Approche-toi de la table.' end
    if t.tour then return false, 'Un tournoi se joue à cette table : inscris-toi ou attends la fin.' end
    if t.pass and tostring(pass or '') ~= t.pass then return false, 'Table privée : mot de passe incorrect.' end
    local minB, maxB = buyRange()
    amount = math.floor(tonumber(amount) or 0)
    if amount < minB or amount > maxB then return false, ('Cave : de %s à %s jetons.'):format(fmt(minB), fmt(maxB)) end
    if Ca.Chips(src) < amount then return false, "Tu n'as pas assez de jetons : passe à la caisse." end
    local lim = num('loss_limit', 0)
    if lim > 0 and Ca.LossToday(src) + amount > lim then return false, 'Limite de pertes sur 24 h atteinte.' end
    local free = nextSeat(t, 0, function(j) return not t.seats[j] and not hp(t, j) end)
    if not free then return false, 'La table est complète.' end
    if not Ca.Take(src, amount) then return false, "Tu n'as pas assez de jetons." end
    local pl = G.Get(src)
    t.seats[free] = { src = src, name = Ca.Display(src), lic = pl.license, owner = G.Inv.PlayerOwner(src), stack = amount, bought = amount, timeouts = 0 }
    Pk.seatOf[src] = { t = t.id, i = free }
    t.watchers[src] = true
    if not t.host or not Pk.seatOf[t.host] then t.host = src end   -- le premier assis choisit si la table est privée
    addLog(t, ('%s s\'assoit avec %s jetons'):format(t.seats[free].name, fmt(amount)))
    if not t.hand or t.hand.over then if not t.nextAt then t.nextAt = now() + 4 end end
    return true, t
end
function Pk.Rebuy(src, amount)
    local at = Pk.seatOf[src]
    local t = at and Pk.tables[at.t]
    local s = t and t.seats[at.i]
    if not s then return false, 'Tu n\'es pas assis(e).' end
    if t.tour then return false, 'Pas de recave en tournoi.' end
    if t.hand and not t.hand.over and alive(t, at.i) then return false, 'Attends la fin de la main.' end
    local _, maxB = buyRange()
    amount = math.floor(tonumber(amount) or 0)
    if amount < 1 or s.stack + amount > maxB then return false, ('Tu peux avoir au plus %s jetons sur la table.'):format(fmt(maxB)) end
    if not Ca.Take(src, amount) then return false, "Tu n'as pas assez de jetons." end
    s.stack, s.bought = s.stack + amount, s.bought + amount
    addLog(t, ('%s recave %s jetons'):format(s.name, fmt(amount)))
    return true, t
end
function Pk.Leave(src, why)
    local at = Pk.seatOf[src]
    for _, t in pairs(Pk.tables) do t.watchers[src] = nil end
    if not at then return false end
    Pk.seatOf[src] = nil
    local t = Pk.tables[at.t]
    local s = t and t.seats[at.i]
    if not s then return false end
    local h = t.hand
    -- en pleine main : il se couche (ses mises restent dans le pot)
    if h and not h.over and alive(t, at.i) then
        h.players[at.i].folded, h.players[at.i].last = true, 'Parti'
    end
    t.seats[at.i] = nil
    if t.tour then
        Pk.TourLeave(t, s, at.i, why)
        if h and not h.over then
            if h.turn == at.i then advance(t) else
                local left = 0 for _, p in pairs(h.players) do if not p.folded then left = left + 1 end end
                if left <= 1 then advance(t) end
            end
        end
        Pk.Push(t)
        return true
    end
    local cash = s.stack
    if cash > 0 then
        if GetPlayerName(src) and G.Get(src) then Ca.Give(src, cash, 'poker')
        elseif not (s.owner and G.Inv.Add(s.owner, CHIP, cash)) then
            PB.DB.exec('UPDATE pb_players SET bank = bank + ? WHERE license = ?', { math.floor(cash * num('chip_value', 1)), s.lic })
        end
    end
    pcall(Ca.Record, src, 'poker', s.bought, cash)
    addLog(t, ('%s quitte la table (%s jetons)'):format(s.name, fmt(cash)))
    if t.host == src then t.host = nil for _, x in pairs(t.seats) do t.host = x.src break end end
    if not next(t.seats) then t.pass, t.host = nil, nil end   -- table vide : redevient publique
    if GetPlayerName(src) then G.Notify(src, { type = 'info', title = 'Poker', text = ('Tu te lèves avec %s jetons%s.'):format(fmt(cash), why and (' (' .. why .. ')') or '') }) end
    if h and not h.over then
        if h.turn == at.i then advance(t) else
            local left = 0 for _, p in pairs(h.players) do if not p.folded then left = left + 1 end end
            if left <= 1 then advance(t) end
        end
    end
    Pk.Push(t)
    return true
end
Ca.PokerLeave = Pk.Leave
AddEventHandler('playerDropped', function() local src = source pcall(Pk.Leave, src, 'déconnexion') end)

-- Point d'entrée depuis la fenêtre du casino (server/game/casino.lua) ------------------------------------------------------------------------
function Ca.Poker(src, action, p)
    if not Ca.GameOn('poker') then return false, 'Le poker est fermé.' end
    local t
    if action == 'watch' then
        t = nearTable(src)
        if not t then return false, 'Approche-toi de la table.' end
        for _, x in pairs(Pk.tables) do x.watchers[src] = nil end
        t.watchers[src] = true
        return true, Pk.View(t, src)
    elseif action == 'lock' then
        local at = Pk.seatOf[src]
        t = at and Pk.tables[at.t]
        if not t or t.host ~= src then return false, 'Seul le premier joueur assis rend la table privée.' end
        local pass = tostring(p.pass or ''):gsub('[^%w]', ''):sub(1, 12)
        if pass ~= '' and #pass < 3 then return false, 'Mot de passe : 3 caractères minimum.' end
        t.pass = pass ~= '' and pass or nil
        addLog(t, t.pass and 'La table est maintenant privée.' or 'La table est de nouveau ouverte à tous.')
    elseif action == 'tcreate' or action == 'tjoin' or action == 'tstart' then
        local ok, r = Pk.Tourney(src, action, p)
        if not ok then return false, r end
        t = r
    elseif action == 'sit' then
        local ok, r = Pk.Sit(src, p.amount, p.pass)
        if not ok then return false, r end
        t = r
    elseif action == 'rebuy' then
        local ok, r = Pk.Rebuy(src, p.amount)
        if not ok then return false, r end
        t = r
    elseif action == 'leave' then
        local at = Pk.seatOf[src]
        t = at and Pk.tables[at.t]
        Pk.Leave(src)
        t = t or nearTable(src)
        if t then t.watchers[src] = true return true, Pk.View(t, src) end
        return true, {}
    else
        local at = Pk.seatOf[src]
        t = at and Pk.tables[at.t]
        if not t then return false, 'Tu n\'es pas assis(e).' end
        local ok, msg = Pk.Act(t, at.i, action, p.to)
        if not ok then return false, msg end
    end
    Pk.Push(t, src)
    return true, Pk.View(t, src)
end

-- Tournois (sit & go) --------------------------------------------------------------------------------------------------------------------------
-- Inscription avec un droit d'entrée en jetons ; chacun reçoit le même tapis de tournoi ; les blindes doublent à chaque niveau ;
-- éliminé à zéro, pas de recave ; le dernier en jeu gagne. Prix : cagnotte (moins la part du casino) partagée entre les premiers.
function Pk.Prizes(pot, n)
    local net = math.floor(pot * (100 - num('tourney_fee', 10)) / 100)
    local split = n <= 3 and { 100 } or (n <= 5 and { 70, 30 } or { 50, 30, 20 })
    local out = {}
    for i, pct in ipairs(split) do out[i] = math.floor(net * pct / 100) end
    return out
end
local function startTour(t)
    local tr = t.tour
    local n = 0 for _ in pairs(t.seats) do n = n + 1 end
    tr.started, tr.players = now(), n
    t.nextAt = now() + 4
    addLog(t, ('Le tournoi commence : %d joueurs, cagnotte %s jetons.'):format(n, fmt(tr.pot)))
    for _, x in pairs(t.seats) do G.Notify(x.src, { type = 'info', title = 'Tournoi de poker', text = 'Le tournoi commence. Bonne chance !' }) end
end
local function seatTour(t, src, free)
    local pl = G.Get(src)
    t.seats[free] = { src = src, name = Ca.Display(src), lic = pl.license, owner = G.Inv.PlayerOwner(src), stack = math.floor(num('tourney_stack', 1500)), bought = t.tour.buyin, timeouts = 0 }
    t.tour.entrants[src] = { name = t.seats[free].name, lic = pl.license, owner = G.Inv.PlayerOwner(src) }
    Pk.seatOf[src] = { t = t.id, i = free }
    t.watchers[src] = true
end
function Pk.Tourney(src, action, p)
    local t = nearTable(src)
    if not t then return false, 'Approche-toi de la table.' end
    if action == 'tcreate' then
        if t.tour or next(t.seats) or (t.hand and not t.hand.over) then return false, 'La table doit être vide pour créer un tournoi.' end
        if Pk.seatOf[src] then return false, 'Tu es déjà assis(e) à une table.' end
        local buy = math.floor(tonumber(p.buyin) or 0)
        local mn, mx = math.floor(num('tourney_min', 100)), math.floor(num('tourney_max', 50000))
        if buy < mn or buy > mx then return false, ("Droit d'entrée : de %s à %s jetons."):format(fmt(mn), fmt(mx)) end
        if not Ca.Take(src, buy) then return false, "Tu n'as pas assez de jetons." end
        t.tour = { buyin = buy, pot = buy, entrants = {}, out = {}, host = src }
        t.host = src
        t.pass = (tostring(p.pass or ''):gsub('[^%w]', ''):sub(1, 12))
        if t.pass == '' or #t.pass < 3 then t.pass = nil end
        seatTour(t, src, 1)
        t.log = {}
        addLog(t, ("Tournoi créé : droit d'entrée %s jetons."):format(fmt(buy)))
        return true, t
    end
    local tr = t.tour
    if not tr then return false, 'Aucun tournoi à cette table.' end
    if action == 'tjoin' then
        if tr.started then return false, 'Le tournoi a déjà commencé.' end
        if Pk.seatOf[src] then return false, 'Tu es déjà assis(e) à une table.' end
        if t.pass and tostring(p.pass or '') ~= t.pass then return false, 'Tournoi privé : mot de passe incorrect.' end
        local free = nextSeat(t, 0, function(j) return not t.seats[j] end)
        if not free then return false, 'Le tournoi est complet.' end
        local lim = num('loss_limit', 0)
        if lim > 0 and Ca.LossToday(src) + tr.buyin > lim then return false, 'Limite de pertes sur 24 h atteinte.' end
        if not Ca.Take(src, tr.buyin) then return false, "Tu n'as pas assez de jetons." end
        tr.pot = tr.pot + tr.buyin
        seatTour(t, src, free)
        addLog(t, ('%s s\'inscrit au tournoi.'):format(t.seats[free].name))
        local n = 0 for _ in pairs(t.seats) do n = n + 1 end
        if n >= maxSeats() then startTour(t) end   -- complet : il démarre tout seul
        return true, t
    end
    if action == 'tstart' then
        if tr.started then return false, 'Déjà commencé.' end
        if tr.host ~= src then return false, "Seul le créateur du tournoi le lance (ou il démarre quand la table est complète)." end
        local n = 0 for _ in pairs(t.seats) do n = n + 1 end
        if n < 2 then return false, 'Il faut au moins 2 inscrits.' end
        startTour(t)
        return true, t
    end
    return false, 'Action inconnue.'
end
-- élimination (tapis à zéro ou départ en cours de tournoi) : la place est donnée par l'ordre de sortie
function Pk.Eliminate(t, i, why)
    local s = t.seats[i]
    if not s then return end
    t.seats[i] = nil
    Pk.seatOf[s.src] = nil
    t.watchers[s.src] = true
    table.insert(t.tour.out, 1, { src = s.src, name = s.name, lic = s.lic, owner = s.owner })
    local left = 0 for _ in pairs(t.seats) do left = left + 1 end
    addLog(t, ('%s est éliminé(e) (%de place).'):format(s.name, left + 1))
    if GetPlayerName(s.src) then G.Notify(s.src, { type = 'warn', title = 'Tournoi de poker', text = ('Éliminé(e) : %de place%s.'):format(left + 1, why and (' (' .. why .. ')') or '') }) end
end
function Pk.TourLeave(t, s, i, why)
    local tr = t.tour
    Pk.seatOf[s.src] = nil
    if not tr.started then
        -- avant le début : droit d'entrée rendu
        tr.entrants[s.src] = nil
        tr.pot = tr.pot - tr.buyin
        if GetPlayerName(s.src) and G.Get(s.src) then Ca.Give(s.src, tr.buyin, 'tournoi annulé') elseif s.owner then G.Inv.Add(s.owner, CHIP, tr.buyin) end
        addLog(t, ('%s se désinscrit.'):format(s.name))
        if not next(t.seats) then t.tour, t.pass, t.host = nil, nil, nil
        elseif tr.host == s.src then for _, x in pairs(t.seats) do tr.host, t.host = x.src, x.src break end end
        return
    end
    t.seats[i] = s   -- remis le temps de l'éliminer proprement
    Pk.Eliminate(t, i, why or 'abandon')
    local left = 0 for _ in pairs(t.seats) do left = left + 1 end
    if left <= 1 and not (t.hand and not t.hand.over) then Pk.EndTourney(t) end
end
local function payChips(e, n, why)
    if n <= 0 then return end
    if e.src and GetPlayerName(e.src) and G.Get(e.src) and G.Get(e.src).license == e.lic then Ca.Give(e.src, n, why)
    elseif not (e.owner and G.Inv.Add(e.owner, CHIP, n)) then PB.DB.exec('UPDATE pb_players SET bank = bank + ? WHERE license = ?', { math.floor(n * num('chip_value', 1)), e.lic }) end
end
function Pk.EndTourney(t)
    local tr = t.tour
    if not tr or tr.done then return end
    tr.done = true
    local order = {}
    for i, s in pairs(t.seats) do order[1] = { src = s.src, name = s.name, lic = s.lic, owner = s.owner } t.seats[i] = nil Pk.seatOf[s.src] = nil t.watchers[s.src] = true end
    for _, e in ipairs(tr.out) do order[#order + 1] = e end
    local n = tr.players or #order
    local prizes = Pk.Prizes(tr.pot, n)
    local results = {}
    for place, e in ipairs(order) do
        local won = prizes[place] or 0
        payChips(e, won, 'tournoi de poker')
        results[#results + 1] = { place = place, name = e.name, lic = e.lic, prize = won }
        if e.src and GetPlayerName(e.src) and G.Get(e.src) then
            pcall(Ca.Record, e.src, 'poker', tr.buyin, won)
            G.Notify(e.src, { type = won > 0 and 'success' or 'info', title = 'Tournoi de poker', text = won > 0 and ('%de place : tu gagnes %s jetons !'):format(place, fmt(won)) or ('Tournoi terminé : %de place.'):format(place) })
        end
    end
    local win = order[1]
    PB.DB.insert('INSERT INTO pb_poker_tourneys (at, tbl, buyin, pot, players, winner, results) VALUES (?, ?, ?, ?, ?, ?, ?)', { now(), tostring(t.label or ''), tr.buyin, tr.pot, n, win and win.name or '', PB.Json(results) })
    addLog(t, win and ('%s remporte le tournoi (%s jetons) !'):format(win.name, fmt(prizes[1] or 0)) or 'Tournoi terminé.')
    if win and n >= 3 and Ca.Display then
        for s2 in pairs(G.Players()) do G.Notify(s2, { type = 'success', title = 'Casino', text = ('%s remporte le tournoi de poker (%s jetons) !'):format(win.name, fmt(prizes[1] or 0)), duration = 8000 }) end
    end
    t.tour, t.pass, t.host, t.hand, t.nextAt = nil, nil, nil, nil, nil
    Pk.Push(t)
end

-- Horloge : temps de parole, lancement des mains -----------------------------------------------------------------------------------------------
function Pk.Tick()
    for _, t in pairs(Pk.tables) do
        local h = t.hand
        if h and not h.over and h.deadline and now() >= h.deadline then
            local i = h.turn
            local s = t.seats[i]
            if s then
                s.timeouts = (s.timeouts or 0) + 1
                local p = h.players[i]
                Pk.Act(t, i, (h.cur - p.bet) <= 0 and 'check' or 'fold')
                if s.timeouts >= 2 then
                    s.away = true
                    G.Notify(s.src, { type = 'warn', title = 'Poker', text = 'Tu n\'as pas joué deux fois de suite : tu passes les prochaines mains (rejoue pour revenir).' })
                end
            else advance(t) end
            Pk.Push(t)
        elseif (not h or h.over) then
            local n = 0
            local _, bb = blinds(t)
            for _, s in pairs(t.seats) do if canPlay(t, s, bb) then n = n + 1 end end
            if t.tour and not t.tour.started then n = 0 end   -- tournoi : on attend le lancement
            if n >= 2 and not t.nextAt then t.nextAt = now() + 4 end
            if t.nextAt and now() >= t.nextAt then Pk.Start(t) end
        end
    end
end
-- revenir après une absence : n'importe quelle action de la fenêtre (regarder la table) suffit
local oldPoker = Ca.Poker
function Ca.Poker(src, action, p)
    local at = Pk.seatOf[src]
    local s = at and Pk.tables[at.t] and Pk.tables[at.t].seats[at.i]
    if s and s.away and action ~= 'leave' then s.away, s.timeouts = nil, 0 end
    return oldPoker(src, action, p)
end
CreateThread(function() while true do Wait(1000) local ok, err = pcall(Pk.Tick) if not ok then PB.Err('poker : ' .. tostring(err)) end end end)
