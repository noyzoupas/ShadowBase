-- Surveillance de l'économie : journal des mouvements d'argent et d'objets par joueur, alertes quand quelqu'un gagne anormalement vite
-- (duplication d'argent ou d'objets, faille dans un script), et chronologie d'un joueur pour le staff : connexions, argent, objets,
-- sanctions, signalements, expulsions. Les déplacements d'objets (coffre -> sac, don entre joueurs) ne comptent pas comme des gains.
local B, P, DB, G = PB.B, PB.Perm, PB.DB, PB.G

P.Register('vigil.view', 'Voir les alertes anti-duplication et la chronologie des joueurs', 'staff')
P.Register('vigil.edit', 'Régler les seuils anti-duplication', 'staff', true)
PB.Migrate('320_vigil', 'Surveillance : journal des joueurs et alertes', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_vigil_log (id BIGINT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, kind VARCHAR(8) NOT NULL, what VARCHAR(48) NOT NULL DEFAULT '', delta BIGINT NOT NULL DEFAULT 0, reason VARCHAR(64) NOT NULL DEFAULT '', at INT NOT NULL, PRIMARY KEY (id), KEY k_lic (license, at), KEY k_at (at))]]))
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_vigil_alerts (id INT NOT NULL AUTO_INCREMENT, license VARCHAR(80) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', kind VARCHAR(8) NOT NULL, what VARCHAR(48) NOT NULL DEFAULT '', amount BIGINT NOT NULL DEFAULT 0, detail TEXT NULL, at INT NOT NULL, status VARCHAR(8) NOT NULL DEFAULT 'open', PRIMARY KEY (id), KEY k_st (status, at))]]))
end)
PB.Cfg.Define('vigil', { enabled = true, money_hour = 150000, item_hour = 250, log_min = 100, keep_days = 30, notify_staff = true, discord = true, ignore_items = {} })

local V = {}
G.Vigil = V
local function cfg(k, d) return PB.Cfg.Get('vigil', k, d) end
local function now() return os.time() end
local function money(n) return ('%s $'):format(tostring(math.floor((tonumber(n) or 0) + 0.5)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) end
local function nameOf(license)
    local r = DB.one('SELECT firstname, lastname FROM pb_players WHERE license = ?', { license })
    local n = r and ((r.firstname or '') .. ' ' .. (r.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '') or ''
    return n ~= '' and n or license
end
local function log(license, kind, what, delta, reason)
    MySQL.insert('INSERT INTO pb_vigil_log (license, kind, what, delta, reason, at) VALUES (?, ?, ?, ?, ?, ?)', { license, kind, tostring(what or ''):sub(1, 48), math.floor(delta or 0), tostring(reason or ''):sub(1, 64), now() })
end

-- Fenêtre glissante d'une heure par licence : argent gagné, objets reçus, raisons principales
local win = {}
local function bucket(license)
    local w = win[license]
    if not w or now() - w.t0 >= 3600 then w = { t0 = now(), money = 0, reasons = {}, items = {}, alerted = {} } win[license] = w end
    return w
end
local function top(t, n)
    local list = {}
    for k, v in pairs(t) do list[#list + 1] = { k, v } end
    table.sort(list, function(a, b) return a[2] > b[2] end)
    local out = {}
    for i = 1, math.min(n, #list) do out[#out + 1] = list[i][1] .. ' : ' .. list[i][2] end
    return out
end

function V.Alert(license, kind, what, amount, detail)
    local name = nameOf(license)
    local id = DB.insert('INSERT INTO pb_vigil_alerts (license, name, kind, what, amount, detail, at) VALUES (?, ?, ?, ?, ?, ?, ?)', { license, name:sub(1, 64), kind, tostring(what):sub(1, 48), math.floor(amount), detail or '', now() })
    local text = kind == 'money' and ('%s a gagné %s en moins d\'une heure.'):format(name, money(amount)) or ('%s a reçu %d × %s en moins d\'une heure.'):format(name, amount, what)
    PB.Audit.Log('anticheat', 'dupe_' .. kind, 'système', name, nil, nil, { licence = license, quoi = what, quantite = amount, detail = detail })
    if cfg('notify_staff', true) then
        for s in pairs(G.Players()) do
            if P.Has(s, 'vigil.view') and (not G.Staff or G.Staff.OnDuty(s)) then G.Notify(s, { type = 'warn', title = 'Alerte duplication #' .. tostring(id or '?'), text = text, duration = 12000 }) end
        end
    end
    if cfg('discord', true) and PB.Discord then
        PB.Discord.Send('alerts', { title = 'Alerte duplication #' .. tostring(id or '?'), description = text, fields = { { name = 'Licence', value = license, inline = true }, { name = 'Détail', value = detail or '—' } } })
    end
    return id
end

function V.Money(src, account, delta, reason)
    if cfg('enabled', true) == false then return end
    local p = G.Get(src)
    if not p then return end
    reason = tostring(reason or ''):sub(1, 64)
    if math.abs(delta) >= (tonumber(cfg('log_min', 100)) or 100) then log(p.license, 'money', account, delta, reason) end
    if delta <= 0 then return end
    local w = bucket(p.license)
    w.money = w.money + delta
    local rk = reason ~= '' and reason or 'sans motif'
    w.reasons[rk] = (w.reasons[rk] or 0) + delta
    local lim = tonumber(cfg('money_hour', 150000)) or 0
    if lim > 0 and w.money >= lim and not w.alerted.money then
        w.alerted.money = true
        V.Alert(p.license, 'money', account, w.money, 'Principales sources : ' .. table.concat(top(w.reasons, 4), ' · '))
    end
end

local moving = 0   -- > 0 pendant un déplacement d'objets (coffre, don) : ce n'est pas un gain
function V.Item(owner, item, qty)
    if cfg('enabled', true) == false or moving > 0 then return end
    owner = tostring(owner or '')
    if owner:sub(1, 2) ~= 'p:' then return end
    for _, i in ipairs(cfg('ignore_items', {}) or {}) do if i == item then return end end
    local license = owner:sub(3)
    local w = bucket(license)
    w.items[item] = (w.items[item] or 0) + qty
    if qty >= 10 then log(license, 'item', item, qty, '') end
    local lim = tonumber(cfg('item_hour', 250)) or 0
    if lim > 0 and w.items[item] >= lim and not w.alerted['i:' .. item] then
        w.alerted['i:' .. item] = true
        V.Alert(license, 'item', item, w.items[item], 'Objets reçus dans l\'heure (hors coffres et dons) : ' .. table.concat(top(w.items, 4), ' · '))
    end
end

-- Gains par heure et par activité (onglet Économie › Gains par activité) -----------------------------------------------------------------
-- La source vient de la ressource qui verse l'argent (wb_peche, wb_chasse…) ou, pour Shadow Base, du motif du versement.
PB.Migrate('321_eco_hourly', 'Économie : gains par heure et par activité', function()
    DB.exec(PB.Table([[CREATE TABLE IF NOT EXISTS pb_eco_hourly (hour INT NOT NULL, cat VARCHAR(40) NOT NULL, amount BIGINT NOT NULL DEFAULT 0, n INT NOT NULL DEFAULT 0, players INT NOT NULL DEFAULT 0, PRIMARY KEY (hour, cat))]]))
end)
local RES_CAT = { wb_peche = 'Pêche', wb_chasse = 'Chasse', wb_activites = 'Activités (récolte, craft)', wb_jobs = 'Petits jobs', wb_braquages = 'Braquages et trafics', wb_armes = "Atelier d'armes", wb_animaux = 'Animaux', burgershot = 'Burger Shot' }
local KEYWORDS = { { 'virement', 'Transferts entre joueurs' }, { 'don entre', 'Transferts entre joueurs' }, { 'salaire', 'Salaires' }, { 'paie', 'Salaires' }, { 'bar', 'Bar et restauration' },
    { 'drogue', 'Drogue' }, { 'pochon', 'Drogue' }, { 'braquage', 'Braquages et trafics' }, { 'blanchi', 'Blanchiment' }, { 'mission', 'Métiers civils' }, { 'staff', 'Staff' }, { 'rembourse', 'Staff' }, { 'vente', 'Ventes diverses' } }
local TRANSFER = { ['Transferts entre joueurs'] = true }
function V.CatOf(res, reason)
    if res and RES_CAT[res] then return RES_CAT[res] end
    local r = tostring(reason or ''):lower()
    for _, k in ipairs(KEYWORDS) do if r:find(k[1], 1, true) then return k[2] end end
    if res and res ~= GetCurrentResourceName() then return 'Ressource ' .. res end
    return 'Autres (sans motif)'
end
local hourly = {}   -- [hour][cat] = { amount, n, players = { [licence] = true }, flushedAmount, flushedN }
function V.Source(license, delta, res, reason)
    local h = math.floor(now() / 3600)
    local cat = V.CatOf(res, reason)
    hourly[h] = hourly[h] or {}
    local e = hourly[h][cat]
    if not e then e = { amount = 0, n = 0, players = {}, np = 0 } hourly[h][cat] = e end
    e.amount, e.n = e.amount + delta, e.n + 1
    if not e.players[license] then e.players[license] = true e.np = e.np + 1 end
end
function V.Flush()
    local cur = math.floor(now() / 3600)
    for h, cats in pairs(hourly) do
        for cat, e in pairs(cats) do
            if e.amount ~= 0 or e.n ~= 0 then
                DB.exec('INSERT INTO pb_eco_hourly (hour, cat, amount, n, players) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE amount = amount + ?, n = n + ?', { h, cat, e.amount, e.n, e.np, e.amount, e.n })
                DB.exec('UPDATE pb_eco_hourly SET players = ? WHERE hour = ? AND cat = ? AND players < ?', { e.np, h, cat, e.np })
                e.amount, e.n = 0, 0
            end
        end
        if h < cur then hourly[h] = nil end
    end
end
CreateThread(function() Wait(math.random(0, 300000)) while true do Wait(300000) pcall(V.Flush) pcall(DB.exec, 'DELETE FROM pb_eco_hourly WHERE hour < ?', { math.floor(now() / 3600) - 24 * 60 }) end end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then pcall(V.Flush) end end)

function V.SourcesBlocks()
    pcall(V.Flush)
    local function period(hours)
        local since = math.floor(now() / 3600) - hours
        local rows, created, active = {}, 0, {}
        for _, r in ipairs(DB.q('SELECT cat, SUM(amount) AS amount, SUM(n) AS n, SUM(players) AS ph, COUNT(*) AS hrs FROM pb_eco_hourly WHERE hour > ? GROUP BY cat', { since }) or {}) do
            local amount, ph = tonumber(r.amount) or 0, tonumber(r.ph) or 0
            if not TRANSFER[r.cat] then created = created + amount end
            rows[#rows + 1] = { cat = r.cat .. (TRANSFER[r.cat] and ' (ne crée pas d\'argent)' or ''), amount = amount, perHour = math.floor(amount / math.max(1, tonumber(r.hrs) or 1)), perPlayerHour = math.floor(amount / math.max(1, ph)), n = tonumber(r.n) or 0, sort = TRANSFER[r.cat] and -1 or amount }
        end
        table.sort(rows, function(a, b) return a.sort > b.sort end)
        return rows, created
    end
    local cols = { { k = 'cat', label = 'Source' }, { k = 'amount', label = 'Total', type = 'num' }, { k = 'perHour', label = 'Par heure active', type = 'num' }, { k = 'perPlayerHour', label = 'Par joueur et par heure', type = 'num' }, { k = 'n', label = 'Versements', type = 'num' } }
    local d1, c1 = period(24)
    local d7, c7 = period(24 * 7)
    return { B.notice('info', "Argent versé aux joueurs, classé par activité. La colonne « par joueur et par heure » est celle à comparer pour équilibrer : aucune activité légale ne devrait écraser les autres. Les transferts entre joueurs sont montrés à part : ils ne créent pas d'argent."),
        B.stats({ { label = 'Argent créé (24 h)', value = money(c1), icon = 'coins' }, { label = 'Argent créé (7 jours)', value = money(c7), icon = 'coins' } }),
        B.table({ id = 'src1', title = 'Dernières 24 heures', columns = cols, rows = d1, empty = 'Rien de versé pour le moment.' }),
        B.table({ id = 'src7', title = '7 derniers jours', columns = cols, rows = d7, empty = 'Rien de versé pour le moment.' }) }
end

-- Branchements : toutes les entrées d'argent passent par G.AddMoney / G.RemoveMoney, tous les objets par Inv.Add
do
    local addM, remM = G.AddMoney, G.RemoveMoney
    G.AddMoney = function(src, account, amount, reason)
        local ok = addM(src, account, amount, reason)
        if ok then
            pcall(V.Money, src, account, math.floor(tonumber(amount) or 0), reason)
            local p = G.Get(src)
            if p then pcall(V.Source, p.license, math.floor(tonumber(amount) or 0), GetInvokingResource and GetInvokingResource() or nil, reason) end
        end
        return ok
    end
    G.RemoveMoney = function(src, account, amount, reason)
        local ok = remM(src, account, amount, reason)
        if ok then pcall(V.Money, src, account, -math.floor(tonumber(amount) or 0), reason) end
        return ok
    end
    local Inv = G.Inv
    if Inv then
        local add, mov, give = Inv.Add, Inv.Move, Inv.Give
        Inv.Add = function(owner, item, qty, ...)
            local a, b = add(owner, item, qty, ...)
            if a then pcall(V.Item, owner, item, math.floor(tonumber(qty) or 0)) end
            return a, b
        end
        local function shielded(fn) return function(...) moving = moving + 1 local r = table.pack(pcall(fn, ...)) moving = moving - 1 if not r[1] then error(r[2], 0) end return table.unpack(r, 2, r.n) end end
        if mov then Inv.Move = shielded(mov) end
        if give then Inv.Give = shielded(give) end
    end
end

-- Connexions dans la chronologie
table.insert(G.beginHooks, function(src) local p = G.Get(src) if p then log(p.license, 'conn', 'in', 0, GetPlayerName(src) or '') end end)
AddEventHandler('playerDropped', function(reason)
    local p = G.Get(source)
    if p then log(p.license, 'conn', 'out', 0, tostring(reason or '')) end
end)

-- Ménage
CreateThread(function()
    Wait(math.random(0, 3600000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(3600000)
        local d = tonumber(cfg('keep_days', 30)) or 30
        if d > 0 then pcall(DB.exec, 'DELETE FROM pb_vigil_log WHERE at < ?', { now() - d * 86400 }) end
        for lic, w in pairs(win) do if now() - w.t0 >= 3600 then win[lic] = nil end end
    end
end)

-- Chronologie d'un joueur : tout ce que la base sait de lui, du plus récent au plus ancien ------------------------------------------------------
-- oxmysql rend un TIMESTAMP en millisecondes ; on accepte aussi le texte « AAAA-MM-JJ HH:MM:SS »
local function epoch(v)
    local n = tonumber(v)
    if n then return n > 1e11 and math.floor(n / 1000) or n end
    local y, mo, d, h, mi, se = tostring(v or ''):match('^(%d+)-(%d+)-(%d+)[ T](%d+):(%d+):(%d+)')
    if not y then return 0 end
    return os.time({ year = tonumber(y), month = tonumber(mo), day = tonumber(d), hour = tonumber(h), min = tonumber(mi), sec = tonumber(se) })
end
function V.Timeline(license, limit)
    limit = limit or 150
    local base = tostring(license):gsub('#%d+$', '')
    local out = {}
    local function add(at, kind, text, tone) out[#out + 1] = { at = tonumber(at) or 0, kind = kind, text = text, tone = tone } end
    for _, r in ipairs(DB.q('SELECT * FROM pb_vigil_log WHERE license = ? ORDER BY id DESC LIMIT ?', { license, limit }) or {}) do
        if r.kind == 'money' then add(r.at, 'money', ('%s%s %s%s'):format(r.delta >= 0 and '+' or '−', money(math.abs(r.delta)), r.what == 'bank' and '(banque)' or (r.what == 'jetons' and '(jetons de casino)' or '(espèces)'), r.reason ~= '' and (' — ' .. r.reason) or ''), r.delta >= 0 and 'ok' or 'off')
        elseif r.kind == 'item' then add(r.at, 'item', ('Reçu %d × %s'):format(r.delta, r.what), 'info')
        elseif r.kind == 'conn' then add(r.at, 'conn', r.what == 'in' and 'Connexion' or ('Déconnexion' .. (r.reason ~= '' and (' — ' .. r.reason) or '')), 'info') end
    end
    for _, r in ipairs(DB.q('SELECT * FROM pb_kicks WHERE license = ? OR license = ? ORDER BY id DESC LIMIT 40', { license, base }) or {}) do add(r.at, 'kick', ('%s #%d — %s'):format(r.kind == 'ban' and 'Ban' or r.kind == 'kick' and 'Expulsion' or r.kind, r.id, r.reason), 'bad') end
    for _, r in ipairs(DB.q('SELECT * FROM pb_sanctions WHERE license = ? OR license = ? ORDER BY id DESC LIMIT 40', { license, base }) or {}) do add(r.created, 'sanction', ('Sanction (%s) par %s : %s'):format(r.kind, r.by_name, r.reason), 'warn') end
    for _, r in ipairs(DB.q('SELECT * FROM pb_reports WHERE license = ? ORDER BY id DESC LIMIT 40', { license }) or {}) do add(r.created, 'report', ('Ticket #%d : %s'):format(r.id, tostring(r.text):sub(1, 120)), 'info') end
    for _, r in ipairs(DB.q('SELECT * FROM pb_vigil_alerts WHERE license = ? ORDER BY id DESC LIMIT 20', { license }) or {}) do add(r.at, 'alert', ('Alerte #%d : %s %s'):format(r.id, r.kind == 'money' and money(r.amount) or (r.amount .. ' ×'), r.kind == 'money' and 'gagnés en 1 h' or r.what), 'bad') end
    local name = nameOf(license)
    for _, r in ipairs(DB.q('SELECT created_at, cat, action, actor FROM pb_audit WHERE (target = ? OR target = ?) ORDER BY id DESC LIMIT 60', { name, license }) or {}) do
        add(epoch(r.created_at), 'audit', ('%s · %s (par %s)'):format(r.cat, r.action, r.actor), 'off')
    end
    table.sort(out, function(a, b) return a.at > b.at end)
    while #out > limit do table.remove(out) end
    return out
end

-- Panel ------------------------------------------------------------------------------------------------------------------------------------------
PB.Action('vigil.alert.set', 'vigil.view', function(ctx, p)
    local st = ({ ok = 'ok', open = 'open', seen = 'seen' })[tostring(p.status)]
    if not st then return false, 'État inconnu.' end
    if DB.exec('UPDATE pb_vigil_alerts SET status = ? WHERE id = ?', { st, math.floor(tonumber(p.id) or 0) }) == 0 then return false, 'Alerte introuvable.' end
    ctx.audit('anticheat', 'vigil.alert.' .. st, tostring(p.id), nil, nil)
    ctx.toast = st == 'ok' and 'Alerte classée : fausse alerte.' or 'Alerte mise à jour.'
    return true
end)

local settings = PB.Form.Cfg({ ns = 'vigil', id = 'settings', title = 'Seuils anti-duplication', perm = 'vigil.edit', cols = 2, fields = {
    { k = 'enabled', type = 'toggle', label = 'Surveillance active', default = true },
    { k = 'money_hour', type = 'number', label = 'Alerte si un joueur gagne plus de ($ en 1 h, 0 = jamais)', default = 150000, min = 0, max = 100000000 },
    { k = 'item_hour', type = 'number', label = 'Alerte si un joueur reçoit plus de (objets identiques en 1 h, 0 = jamais)', default = 250, min = 0, max = 100000, hint = 'Les objets sortis d\'un coffre ou reçus d\'un joueur ne comptent pas.' },
    { k = 'log_min', type = 'number', label = 'Noter dans la chronologie les mouvements d\'argent à partir de ($)', default = 100, min = 1, max = 100000 },
    { k = 'keep_days', type = 'number', label = 'Conservation du journal (jours)', default = 30, min = 1, max = 365 },
    { k = 'notify_staff', type = 'toggle', label = 'Prévenir le staff en service', default = true },
    { k = 'discord', type = 'toggle', label = 'Envoyer les alertes sur Discord (canal « Alertes anti-duplication »)', default = true },
    { k = 'ignore_items', type = 'list', label = 'Objets ignorés (récoltes en masse, ex. water)', default = {}, maxitems = 40, maxlen = 40, pattern = '^[%w_%-]+$', wide = true },
} })

local TONE = { open = 'warn', seen = 'info', ok = 'ok' }
local ST = { open = 'À vérifier', seen = 'Vue', ok = 'Fausse alerte' }
PB.Module({
    id = 'vigil', label = 'Anti-duplication', icon = 'shield', group = 'Serveur', order = 97, perm = 'vigil.view', hint = 'Gains anormaux et chronologie des joueurs',
    caps = function()
        return PB.Capsify({
            { "Gains d'argent anormaux sur 1 h", 'ok', "Toutes les entrées d'argent du serveur passent par le même point : rien n'échappe au compteur." },
            { "Objets reçus en masse sur 1 h", 'ok', "Les déplacements (coffre vers sac, dons entre joueurs) sont exclus : seuls les objets créés comptent." },
            { 'Chronologie d\'un joueur', 'ok', 'Connexions, argent, objets, sanctions, tickets, expulsions et journal du panel, sur une seule ligne du temps.' },
            { 'Sanction automatique', 'off', 'Volontairement non : une alerte peut venir d\'un gros braquage réussi. Le staff décide.' },
        })
    end,
    doc = "## Anti-duplication\nLe serveur additionne, pour chaque joueur, l'argent gagné et les objets reçus sur une heure. Au-delà des seuils, une **alerte** est créée : le staff en service est prévenu, Discord aussi (canal « Alertes anti-duplication »).\n\nUne alerte n'est **pas** une preuve : regarde la **chronologie** du joueur (d'où vient l'argent) avant de sanctionner.",
    view = function(ctx)
        return { tabs = {
            { id = 'alerts', label = 'Alertes', icon = 'alert', build = function()
                local rows = {}
                for _, r in ipairs(DB.q('SELECT * FROM pb_vigil_alerts ORDER BY (status = ?) DESC, id DESC LIMIT 100', { 'open' }) or {}) do
                    rows[#rows + 1] = { ref = '#' .. r.id, at = r.at, name = r.name, what = r.kind == 'money' and ('Argent : ' .. money(r.amount)) or (('Objet : %d × %s'):format(r.amount, r.what)), detail = r.detail or '', status = { text = ST[r.status] or r.status, tone = TONE[r.status] or 'off' },
                        actions = { { nav = { tab = 'timeline', params = { lic = r.license } }, label = 'Chronologie', icon = 'clock' },
                            r.status ~= 'ok' and { action = 'vigil.alert.set', label = 'Fausse alerte', icon = 'check', payload = { id = r.id, status = 'ok' } } or nil,
                            r.status == 'open' and { action = 'vigil.alert.set', label = 'Vue', icon = 'eye', payload = { id = r.id, status = 'seen' } } or nil } }
                end
                local open = DB.one("SELECT COUNT(*) AS n FROM pb_vigil_alerts WHERE status = 'open'")
                return { B.stats({ { label = 'Alertes à vérifier', value = tostring(open and open.n or 0), icon = 'alert' }, { label = 'Seuil argent / h', value = money(cfg('money_hour', 150000)), icon = 'coins' }, { label = 'Seuil objets / h', value = tostring(cfg('item_hour', 250)), icon = 'bag' } }),
                    B.table({ id = 'va', title = 'Alertes', columns = { { k = 'ref', label = 'Réf.' }, { k = 'at', label = 'Date', type = 'date' }, { k = 'name', label = 'Joueur' }, { k = 'what', label = 'Quoi' }, { k = 'detail', label = 'Détail' }, { k = 'status', label = 'État', type = 'badge' } }, rows = rows, empty = 'Aucune alerte. Tout est calme.' }) }
            end },
            { id = 'timeline', label = 'Chronologie', icon = 'clock', build = function(_, params)
                params = params or {}
                local blocks = { { type = 'form', id = 'vigil.find', title = 'Chercher un joueur', cols = 2, fields = { { k = 'q', type = 'text', label = 'Nom, prénom ou licence', maxlen = 64 } }, values = { q = params.q or '' }, submit = { nav = { tab = 'timeline' }, as = 'params', label = 'Chercher' } } }
                local q = tostring(params.q or ''):sub(1, 64)
                if q ~= '' and not params.lic then
                    local like = '%' .. q:gsub('[%%_]', '') .. '%'
                    local rows = {}
                    for _, r in ipairs(DB.q("SELECT license, firstname, lastname, last_seen FROM pb_players WHERE firstname LIKE ? OR lastname LIKE ? OR license LIKE ? OR (firstname LIKE ? AND lastname LIKE ?) ORDER BY last_seen DESC LIMIT 30",
                        { like, like, like, '%' .. (q:match('^(%S+)') or ''):gsub('[%%_]', '') .. '%', '%' .. (q:match('(%S+)$') or ''):gsub('[%%_]', '') .. '%' }) or {}) do
                        rows[#rows + 1] = { name = ((r.firstname or '') .. ' ' .. (r.lastname or '')), license = r.license, seen = tonumber(r.last_seen) or 0, actions = { { nav = { tab = 'timeline', params = { lic = r.license } }, label = 'Chronologie', icon = 'clock' } } }
                    end
                    blocks[#blocks + 1] = B.table({ id = 'vf', title = 'Résultats', columns = { { k = 'name', label = 'Personnage' }, { k = 'license', label = 'Licence', type = 'mono' }, { k = 'seen', label = 'Vu', type = 'date' } }, rows = rows, empty = 'Personne ne correspond.' })
                end
                if params.lic then
                    local lic = tostring(params.lic):sub(1, 80)
                    local rows = {}
                    for _, e in ipairs(V.Timeline(lic)) do rows[#rows + 1] = { at = e.at, kind = { text = ({ money = 'Argent', item = 'Objet', conn = 'Connexion', kick = 'Expulsion', sanction = 'Sanction', report = 'Ticket', audit = 'Journal', alert = 'Alerte', bill = 'Facture', fine = 'Amende', warrant = 'Mandat', impound = 'Fourrière', care = 'Soins', down = 'À terre', death = 'Mort', kill = 'Tue', jail = 'Prison', house = 'Logement', inv = 'Inventaire', deal = 'Contrat', plate = 'Plaque' })[e.kind] or e.kind, tone = e.tone }, text = e.text } end
                    blocks[#blocks + 1] = B.table({ id = 'vt', title = 'Chronologie de ' .. nameOf(lic), columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'kind', label = 'Type', type = 'badge' }, { k = 'text', label = 'Détail' } }, rows = rows, empty = 'Rien d\'enregistré pour ce joueur.' })
                end
                return blocks
            end },
            { id = 'settings', label = 'Réglages', icon = 'sliders', perm = 'vigil.edit', build = function() return { settings(ctx) } end },
        } }
    end,
})
exports('GetTimeline', function(license, limit) return V.Timeline(tostring(license), tonumber(limit)) end)
