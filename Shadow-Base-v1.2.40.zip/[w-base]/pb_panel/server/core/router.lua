-- Routeur : sessions du panel, actions serveur, modules, vues pilotées par le serveur, notifications.
-- Principe : l'interface n'a AUCUN bouton en dur. Chaque bouton est décrit par une vue renvoyée par le serveur
-- et pointe vers une action enregistrée ici. Une action inconnue ou non autorisée est retirée de la vue.
-- Chaque appel est vérifié côté serveur : session, permission, limite de débit, confirmation, PIN, audit.

local P = PB.Perm
local Audit = PB.Audit

PB.Modules = { list = {}, byId = {} }
PB.Session = PB.Session or {}
PB.Pin = PB.Pin or {}

local CHUNK = 30000
local MAX_UP = 3 * 1024 * 1024
local actions = {}
local sessions = {}       -- [src] = { token, license, name, opened, last }
local notifs, notifId = {}, 0
local warned = {}

PB.Cfg.Define('security', { session_minutes = 30, rate_limit = 40, pin_hash = '', pin_required_critical = false })

-- Enregistrement --------------------------------------------------------------------------------------------------
-- perm : chaîne (permission requise), fonction(ctx, payload) -> booléen, ou nil (toute session ouverte).
-- opts : critical (confirmation serveur), pin (PIN requis si défini), read (lecture seule : pas de rafraîchissement),
--        audit (catégorie d'audit automatique), confirm = { title, text }, rate (appels/minute).
function PB.Action(name, perm, fn, opts)
    if actions[name] then PB.Warn("action déjà enregistrée, remplacée : " .. name) end
    actions[name] = { name = name, perm = perm, fn = fn, opts = opts or {} }
end

function PB.ActionExists(name) return actions[name] ~= nil end
function PB.ActionRemove(name) actions[name] = nil end   -- extensions arrêtées (server/core/ext.lua)
function PB.ActionList() return actions end

-- def : id, label, icon, group, order, perm (affichage), view(ctx, params) -> { tabs = {...} }, caps() -> liste, doc
function PB.Module(def)
    if PB.Modules.byId[def.id] then return end
    def.perm = def.perm or (def.id .. '.view')
    def.order = def.order or 100
    PB.Modules.byId[def.id] = def
    PB.Modules.list[#PB.Modules.list + 1] = def
    table.sort(PB.Modules.list, function(a, b) return a.order < b.order end)
    P.Register(def.perm, 'Voir : ' .. def.label, def.id)
end

-- Limite de débit -----------------------------------------------------------------------------------------------------
local buckets = {}
local function rate(src, key, limit, windowSec)
    local now = os.time()
    local k = src .. ':' .. key
    local b = buckets[k]
    if not b or now - b.t >= windowSec then b = { t = now, n = 0 } buckets[k] = b end
    b.n = b.n + 1
    return b.n <= limit
end

-- Messages vers le client (découpés si volumineux) ------------------------------------------------------------------------
local function sendJson(src, kind, id, tbl)
    local s = PB.Json(tbl)
    if #s <= CHUNK then
        TriggerClientEvent('pb:msg', src, kind, id, s)
        return
    end
    -- coupures sur une frontière de caractère UTF-8 : jamais au milieu d'une lettre accentuée
    local parts, pos = {}, 1
    while pos <= #s do
        local e = math.min(pos + CHUNK - 1, #s)
        while e < #s and e > pos do
            local nb = s:byte(e + 1)
            if nb and nb >= 0x80 and nb <= 0xBF then e = e - 1 else break end
        end
        parts[#parts + 1] = s:sub(pos, e)
        pos = e + 1
    end
    -- gros messages (ex. une image) en évènements « latents » : envoyés d'un coup en évènements normaux, ils saturent la file réseau du joueur
    local latent = #parts > 2
    for i = 1, #parts do
        if latent then TriggerLatentClientEvent('pb:msgChunk', src, 200000, kind, id, i, #parts, parts[i])
        else TriggerClientEvent('pb:msgChunk', src, kind, id, i, #parts, parts[i]) end
        if i % 6 == 0 then Wait(0) end
    end
end
PB.SendJson = sendJson

-- Sessions ---------------------------------------------------------------------------------------------------------------------
local counter = 0
local function newToken()
    counter = counter + 1
    return PB.Sha256(table.concat({ os.time(), GetGameTimer(), counter, math.random(1, 2 ^ 30), math.random(1, 2 ^ 30), tostring({}) }, ':'))
end

function PB.Session.Get(src) return sessions[src] end

function PB.Session.Revoke(src, reason)
    local s = sessions[src]
    if not s then return false end
    sessions[src] = nil
    sendJson(src, 'revoked', 0, { reason = reason or 'Session fermée.' })
    return true
end

function PB.Session.List()
    local out = {}
    for src, s in pairs(sessions) do
        local g, gr = P.GetGrade(src)
        out[#out + 1] = { src = src, name = s.name, license = s.license, grade = gr and gr.label or g, opened = s.opened, last = s.last }
    end
    table.sort(out, function(a, b) return a.opened < b.opened end)
    return out
end

AddEventHandler('playerDropped', function() sessions[source] = nil end)

-- Contexte d'une action ------------------------------------------------------------------------------------------------------
local function makeCtx(src)
    local s = sessions[src]
    local grade, gr = P.GetGrade(src)
    local ctx = {
        src = src, actor = PB.Actor(src), license = s and s.license or P.GetLicense(src),
        grade = grade, gradeLabel = gr and gr.label or grade, level = P.Level(src),
    }
    ctx.has = function(perm) return P.Has(src, perm) end
    ctx.audit = function(cat, action, target, before, after, data)
        ctx.audited = true
        return Audit.Log(cat, action, ctx.actor, target, before, after, data)
    end
    return ctx
end
PB.MakeCtx = makeCtx

-- Retire des vues les éléments non autorisés ou pointant vers une action inexistante ------------------------------------------
local function prune(node, ctx, where)
    if type(node) ~= 'table' then return node end
    if type(node.action) == 'string' then
        local a = actions[node.action]
        if not a then
            if not warned[node.action] then
                warned[node.action] = true
                PB.Warn("bouton retiré : l'action « " .. node.action .. " » n'existe pas (" .. tostring(where) .. ')')
            end
            return nil
        end
        if type(a.perm) == 'string' and not ctx.has(a.perm) then return nil end
    end
    if type(node.perm) == 'string' and not ctx.has(node.perm) then return nil end
    if PB.IsArray(node) then
        local out = {}
        for _, v in ipairs(node) do
            local r = prune(v, ctx, where)
            if r ~= nil then out[#out + 1] = r end
        end
        return out
    end
    for k, v in pairs(node) do
        if type(v) == 'table' then node[k] = prune(v, ctx, where) end
    end
    return node
end

-- Vues ------------------------------------------------------------------------------------------------------------------------------
local function buildView(ctx, id, params)
    local m = PB.Modules.byId[id]
    if not m then return nil, 'Module inconnu.' end
    if not ctx.has(m.perm) then return nil, 'Permission refusée (' .. m.perm .. ').' end
    if PB.License and PB.License.Locked and id ~= 'license' then return nil, 'Licence requise : active ta licence (module Licence).' end
    local ok, view = pcall(m.view, ctx, params or {})
    if not ok then
        PB.Err('vue ' .. id .. ' : ' .. tostring(view))
        PB.LastError = { at = os.time(), where = 'vue ' .. id, err = tostring(view) }
        return nil, 'Erreur interne dans le module « ' .. m.label .. ' » (voir la console).'
    end
    view = view or { tabs = {} }
    view.tabs = view.tabs or {}
    -- Onglets paresseux : seul l'onglet actif construit ses blocs (sauf pour l'index de recherche).
    local active = (params and params.tab) or (view.tabs[1] and view.tabs[1].id)
    view.active = active
    for _, t in ipairs(view.tabs) do
        if t.build then
            if (params and params.all) or t.id == active then
                local okb, blocks = pcall(t.build, ctx, params or {})
                if okb then t.blocks = blocks or {}
                else
                    PB.Err('onglet ' .. id .. '/' .. t.id .. ' : ' .. tostring(blocks))
                    PB.LastError = { at = os.time(), where = 'onglet ' .. id .. '/' .. t.id, err = tostring(blocks) }
                    t.blocks = { { type = 'notice', level = 'error', text = "Erreur interne dans cet onglet (voir la console du serveur)." } }
                end
            end
            t.build = nil
        end
    end
    if m.caps then
        local okc, caps = pcall(m.caps)
        if okc and type(caps) == 'table' then
            caps = PB.Capsify(caps)
            view.tabs[#view.tabs + 1] = { id = '_compat', label = 'Compatibilité', icon = 'shield', blocks = {
                { type = 'notice', level = 'info', text = "Ce que ce module peut vraiment faire sur ton serveur. Ce qui n'est pas pris en charge est indiqué ici au lieu d'être simulé." },
                { type = 'caps', items = caps },
            } }
            view.compat = PB.CapSummary(caps)
        end
    end
    if m.doc then
        view.tabs[#view.tabs + 1] = { id = '_doc', label = 'Aide', icon = 'info', blocks = { { type = 'doc', text = m.doc } } }
    end
    view = prune(view, ctx, id)
    view.module = id
    view.title = m.label
    view.icon = m.icon
    return view
end

-- Préférences de l'utilisateur (favoris, thème, langue, positions) -------------------------------------------------------------------
local PREF_KEYS = { theme = 'string', accent = 'string', lang = 'string', density = 'string', favorites = 'table', lastModule = 'string',
    sidebar = 'boolean', dock = 'table', staffMenu = 'table', opacity = 'number', blur = 'number', recent = 'table' }

local function getPrefs(license) return PB.Cfg.Get('prefs', license or '?', {}) end

PB.Action('ui.prefs.set', nil, function(ctx, p)
    local cur = getPrefs(ctx.license)
    for k, t in pairs(PREF_KEYS) do
        local v = (p.values or {})[k]
        if v ~= nil and type(v) == t then
            if t == 'string' then v = PB.Sanitize(v, 64) end
            if t == 'number' then v = PB.Clamp(v, 0, 100) end
            cur[k] = v
        end
    end
    if #PB.Json(cur) > 8192 then return false, 'Préférences trop volumineuses.' end
    PB.Cfg.Set('prefs', ctx.license or '?', cur, ctx.actor, nil, true)
    return true
end, { read = true })

-- Notifications ------------------------------------------------------------------------------------------------------------------------
function PB.Notify(level, title, text, perm)
    notifId = notifId + 1
    local e = { id = notifId, at = os.time(), level = level or 'info', title = title, text = text or '', perm = perm or 'logs.view' }
    table.insert(notifs, 1, e)
    if #notifs > 100 then table.remove(notifs) end
    for src in pairs(sessions) do
        if P.Has(src, e.perm) then sendJson(src, 'push', 0, { type = 'notify', entry = e }) end
    end
    return e
end

PB.Action('ui.notifs', nil, function(ctx)
    local out = {}
    for _, e in ipairs(notifs) do if ctx.has(e.perm) then out[#out + 1] = e end end
    return true, out
end, { read = true })

-- Démarrage de l'interface -------------------------------------------------------------------------------------------------------------
local GROUP_ORDER = { 'Pilotage', 'Serveur', 'Extensions', 'Système' }

local function buildBoot(ctx)
    local nav = {}
    for _, m in ipairs(PB.Modules.list) do
        if ctx.has(m.perm) and not (PB.License and PB.License.Locked and m.id ~= 'license') then
            nav[#nav + 1] = { id = m.id, label = m.label, icon = m.icon, group = m.group or 'Pilotage', hint = m.hint }
        end
    end
    local owner = P.IsOwner(ctx.src)
    local season = PB.Season and PB.Season.Info()
    return {
        nav = nav, groups = GROUP_ORDER,
        user = { name = ctx.actor.name, grade = ctx.grade, gradeLabel = ctx.gradeLabel, level = ctx.level, owner = owner, src = ctx.src },
        brand = {
            name = PB.Cfg.Get('general', 'server_name', 'Shadow Base'),
            tagline = PB.Cfg.Get('general', 'tagline', ''),
            color = season and season.color or PB.Cfg.Get('general', 'color_primary', '#dfe2e7'),
            color2 = season and season.color2 or PB.Cfg.Get('general', 'color_secondary', '#aab0bb'),
            logoUrl = (PB.Cfg.Get('general', 'logo_data', '') ~= '' and PB.Cfg.Get('general', 'logo_data', '')) or (PB.Cfg.Get('general', 'logo_url', '') ~= '' and PB.Cfg.Get('general', 'logo_url', '')) or 'img/brand/shadow-logo.png',   -- par défaut : le logo de Shadow Base
            season = season and { id = season.id, label = season.label, theme = season.theme, decor = season.decor } or nil,
        },
        prefs = getPrefs(ctx.license),
        interface = PB.Cfg.All('interface') or {},
        pinSet = PB.Pin.IsSet(),
        framework = 'wframework',
        version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '1.0.0',
    }
end

PB.Action('ui.boot', nil, function(ctx) return true, buildBoot(ctx) end, { read = true })

PB.Action('ui.view', nil, function(ctx, p)
    local view, err = buildView(ctx, tostring(p.module or ''), p.params)
    if not view then return false, err end
    return true, view
end, { read = true })

-- Recherche globale : modules, onglets et libellés de champs --------------------------------------------------------------------------------
local searchCache = {}
local function indexFor(ctx)
    local c = searchCache[ctx.src]
    if c and os.time() - c.at < 60 then return c.items end
    local items = {}
    for _, m in ipairs(PB.Modules.list) do
        if ctx.has(m.perm) then
            items[#items + 1] = { label = m.label, module = m.id, kind = 'module', hint = m.group or '' }
            local ok, view = pcall(buildView, ctx, m.id, { all = true })
            if ok and view and view.tabs then
                for _, t in ipairs(view.tabs) do
                    if t.id:sub(1, 1) ~= '_' then
                        items[#items + 1] = { label = t.label, module = m.id, tab = t.id, kind = 'onglet', hint = m.label }
                        local function scan(node)
                            if type(node) ~= 'table' then return end
                            if node.k and node.label and node.type and node.type ~= 'info' then
                                items[#items + 1] = { label = node.label, module = m.id, tab = t.id, kind = 'réglage', hint = m.label .. ' › ' .. t.label, field = node.k }
                            end
                            for _, v in pairs(node) do if type(v) == 'table' then scan(v) end end
                        end
                        scan(t.blocks)
                    end
                end
            end
        end
    end
    searchCache[ctx.src] = { at = os.time(), items = items }
    return items
end

PB.Action('ui.search', nil, function(ctx, p)
    local q = PB.Trim(tostring(p.q or '')):lower()
    if #q < 2 then return true, {} end
    local out = {}
    for _, it in ipairs(indexFor(ctx)) do
        local l = it.label:lower()
        local score = l == q and 100 or (l:sub(1, #q) == q and 80 or (l:find(q, 1, true) and 50 or ((it.hint or ''):lower():find(q, 1, true) and 20 or 0)))
        if score > 0 then out[#out + 1] = { score = score, item = it } end
    end
    table.sort(out, function(a, b) return a.score > b.score end)
    local res = {}
    for i = 1, math.min(#out, 14) do res[i] = out[i].item end
    return true, res
end, { read = true })

-- PIN des actions critiques ------------------------------------------------------------------------------------------------------------------
local pinFails = {}
function PB.Pin.IsSet() return (PB.Cfg.Get('security', 'pin_hash', '') or '') ~= '' end

function PB.Pin.Set(pin, actor)
    if pin == nil or pin == '' then
        PB.Cfg.Set('security', 'pin_hash', '', actor, nil, true)
        return true
    end
    if not tostring(pin):match('^%d%d%d%d%d?%d?%d?%d?$') then return false, 'Le PIN doit contenir 4 à 8 chiffres.' end
    local salt = PB.Sha256(tostring(os.time()) .. tostring(math.random(1, 2 ^ 30)) .. tostring(GetGameTimer())):sub(1, 16)
    PB.Cfg.Set('security', 'pin_hash', salt .. ':' .. PB.Sha256(salt .. tostring(pin)), actor, nil, true)
    return true
end

function PB.Pin.Verify(license, pin)
    local stored = PB.Cfg.Get('security', 'pin_hash', '')
    if stored == '' then return true end
    local f = pinFails[license] or { n = 0, untilT = 0 }
    if os.time() < f.untilT then return false, 'Trop d\'essais : réessaie dans ' .. (f.untilT - os.time()) .. ' s.' end
    local salt, hash = stored:match('^(%w+):(%w+)$')
    if salt and PB.Sha256(salt .. tostring(pin or '')) == hash then pinFails[license] = nil return true end
    f.n = f.n + 1
    if f.n >= 5 then
        f.untilT = os.time() + 300 f.n = 0
        Audit.Log('securite', 'pin.verrouille', 0, license or '?', nil, nil)
        PB.Notify('warn', 'PIN verrouillé', 'Trop de PIN erronés pour ' .. tostring(license), 'security.view')
    end
    pinFails[license] = f
    return false, 'PIN incorrect.'
end

-- Répartition d'un appel -------------------------------------------------------------------------------------------------------------------------------
local lastDenied = {}
local function dispatch(src, name, payload)
    local a = actions[name]
    if not a then return { ok = false, err = 'Action inconnue.' } end
    if PB.License and PB.License.Locked and name ~= 'ui.boot' and name ~= 'ui.view' and name:sub(1, 8) ~= 'license.' then
        return { ok = false, err = 'Licence requise : active ta licence (module Licence) pour utiliser le panel.' }
    end
    local ctx = makeCtx(src)
    if type(a.perm) == 'string' and not ctx.has(a.perm) then
        if os.time() - (lastDenied[src] or 0) > 30 then
            lastDenied[src] = os.time()
            Audit.Log('securite', 'acces.refuse', src, name, nil, nil, { perm = a.perm })
        end
        return { ok = false, err = 'Permission refusée (' .. a.perm .. ').' }
    elseif type(a.perm) == 'function' then
        local okp, allowed = pcall(a.perm, ctx, payload)
        if not okp or not allowed then return { ok = false, err = 'Permission refusée.' } end
    end
    local o = a.opts
    if o.critical then
        if not rate(src, 'crit', 8, 60) then return { ok = false, err = 'Trop d\'actions sensibles : patiente un instant.' } end
        local needPin = o.pin and PB.Pin.IsSet()
        if payload._confirm ~= true or (needPin and not payload._pin) then
            local c = o.confirm or {}
            local text = c.text
            if type(text) == 'function' then local okt, tt = pcall(text, ctx, payload) text = okt and tt or nil end
            return { ok = false, confirm = { title = c.title or 'Confirmer cette action', text = text or 'Cette action est sensible et sera journalisée.', danger = c.danger ~= false, pin = needPin and true or false, action = name } }
        end
        if needPin then
            local okp, perr = PB.Pin.Verify(ctx.license, payload._pin)
            if not okp then return { ok = false, err = perr, pinError = true } end
        end
    elseif o.rate and not rate(src, name, o.rate, 60) then
        return { ok = false, err = 'Trop de requêtes pour cette action.' }
    end
    payload._confirm, payload._pin = nil, nil
    if payload.values ~= nil and type(payload.values) ~= 'table' then payload.values = {} end   -- une requête mal formée ne doit pas faire planter l'action
    local ok, r1, r2 = pcall(a.fn, ctx, payload)
    if not ok then
        PB.Err('action ' .. name .. ' : ' .. tostring(r1))
        PB.LastError = { at = os.time(), where = 'action ' .. name, err = tostring(r1) }
        Audit.Log('erreur_lua', name, src, name, nil, nil, { err = tostring(r1):sub(1, 400) })
        return { ok = false, err = 'Erreur interne (voir la console du serveur).' }
    end
    if r1 == false or r1 == nil then
        return { ok = false, err = type(r2) == 'string' and r2 or 'Action refusée.' }
    end
    if o.audit and not ctx.audited then
        Audit.Log(o.audit, name, src, ctx.target or '', ctx.before, ctx.after, ctx.audit_data)
    end
    local res = { ok = true, data = r2, toast = ctx.toast }
    if ctx.refresh ~= nil then res.refresh = ctx.refresh else res.refresh = not o.read end
    if ctx.close then res.close = true end
    return res
end

-- Évènements réseau ---------------------------------------------------------------------------------------------------------------------------------------
local function sessionOk(src, token)
    local s = sessions[src]
    if not s or type(token) ~= 'string' or s.token ~= token then return false end
    local idle = PB.Cfg.Get('security', 'session_minutes', 30) * 60
    if os.time() - s.last > idle then sessions[src] = nil sendJson(src, 'revoked', 0, { reason = 'Session expirée : rouvre le panel.' }) return false end
    if P.GetLicense(src) ~= s.license then sessions[src] = nil return false end
    s.last = os.time()
    return true
end

local function handle(src, token, reqId, name, payload)
    if type(reqId) ~= 'number' and type(reqId) ~= 'string' then return end
    if not sessionOk(src, token) then sendJson(src, 'res', reqId, { ok = false, err = 'Session invalide. Rouvre le panel.', expired = true }) return end
    if not rate(src, 'all', PB.Cfg.Get('security', 'rate_limit', 40), 5) then
        sendJson(src, 'res', reqId, { ok = false, err = 'Trop de requêtes : ralentis.' }) return
    end
    if type(name) ~= 'string' or #name > 64 then return end
    if type(payload) ~= 'table' then payload = {} end
    local res = dispatch(src, name, payload)
    sendJson(src, 'res', reqId, res)
end

RegisterNetEvent('pb:open', function()
    local src = source
    if not rate(src, 'open', 6, 20) then return end
    if not P.Has(src, 'panel.open') then
        if os.time() - (lastDenied[src] or 0) > 30 then
            lastDenied[src] = os.time()
            Audit.Log('securite', 'panel.refuse', src, 'ouverture')
        end
        sendJson(src, 'denied', 0, { reason = "Accès refusé : ton compte n'a pas la permission d'ouvrir le panel." })
        return
    end
    local lic = P.GetLicense(src)
    local s = { token = newToken(), license = lic, name = GetPlayerName(src) or '?', opened = os.time(), last = os.time() }
    sessions[src] = s
    local ctx = makeCtx(src)
    Audit.Log('panel', 'panel.ouvrir', src, '')
    sendJson(src, 'opened', 0, { token = s.token, boot = buildBoot(ctx) })
end)

RegisterNetEvent('pb:close', function()
    local src = source
    sessions[src] = nil
    searchCache[src] = nil
end)

RegisterNetEvent('pb:call', function(token, reqId, name, json)
    local src = source
    local payload = type(json) == 'string' and PB.FromJson(json, {}) or {}
    handle(src, token, reqId, name, payload)
end)

-- Envois volumineux du client (éditeur de fichiers, import SQL...) en plusieurs morceaux.
local uploads = {}
RegisterNetEvent('pb:upChunk', function(token, reqId, name, i, n, part)
    local src = source
    if type(i) ~= 'number' or type(n) ~= 'number' or type(part) ~= 'string' or n < 1 or n > 200 or i < 1 or i > n then return end
    local key = src .. ':' .. tostring(reqId)
    local u = uploads[key]
    -- les évènements latents n'arrivent pas forcément dans l'ordre : n'importe quel morceau peut ouvrir l'envoi
    -- (un envoi resté inachevé avec le même identifiant est remplacé, au lieu d'avaler les nouveaux morceaux)
    if not u or u.n ~= n then
        u = { parts = {}, size = 0, at = os.time(), n = n }
        uploads[key] = u
    end
    u.at = os.time()   -- l'envoi reste vivant tant que des morceaux arrivent
    if u.parts[i] then return end
    u.parts[i] = part
    u.size = u.size + #part
    if u.size > MAX_UP then uploads[key] = nil sendJson(src, 'res', reqId, { ok = false, err = 'Envoi trop volumineux.' }) return end
    local count = 0
    for _ in pairs(u.parts) do count = count + 1 end
    if count == n then
        uploads[key] = nil
        local payload = PB.FromJson(table.concat(u.parts), {})
        handle(src, token, reqId, name, payload)
    end
end)

CreateThread(function()
    Wait(math.random(0, 30000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(30000)
        local now = os.time()
        for k, u in pairs(uploads) do if now - u.at > 60 then uploads[k] = nil end end
        for k, b in pairs(buckets) do if now - b.t > 120 then buckets[k] = nil end end
        for src, c in pairs(searchCache) do if now - c.at > 300 then searchCache[src] = nil end end
    end
end)

-- Le nom, les couleurs et les thèmes se répercutent tout de suite sur les panels ouverts (sans les rouvrir)
local function pushBrand() for src in pairs(sessions) do sendJson(src, 'push', 0, { type = 'brand' }) end end
PB.Cfg.OnChange('general', function(k) if k == 'server_name' or k == 'tagline' or k == 'color_primary' or k == 'color_secondary' or k == 'logo_data' or k == 'logo_url' or k == 'season' or k == 'season_decor' or k == 'season_game' or k == nil then pushBrand() end end)
PB.Cfg.OnChange('interface', function() pushBrand() end)
PB.PushBrand = pushBrand

-- Révocation quand les permissions changent : l'interface est actualisée à la prochaine action ;
-- les joueurs qui perdent 'panel.open' sont déconnectés du panel immédiatement.
P.OnChange(function()
    searchCache = {}
    for src in pairs(sessions) do
        if not P.Has(src, 'panel.open') then PB.Session.Revoke(src, 'Ton accès au panel a été retiré.')
        else sendJson(src, 'push', 0, { type = 'perms' }) end
    end
end)

P.Register('panel.open', "Ouvrir le panel", 'panel')
