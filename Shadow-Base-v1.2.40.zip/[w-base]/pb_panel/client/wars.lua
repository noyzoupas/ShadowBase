-- Guerre de territoire : zone clignotante sur la carte + tableau des scores à l'écran (valeurs envoyées par le serveur).
local G = PBG
local blip
RegisterNetEvent('pb:g:war', function(j)
    local d = G.decode(j) or {}
    if blip and DoesBlipExist(blip) then RemoveBlip(blip) end
    blip = nil
    if d.on then
        blip = AddBlipForRadius(d.x + 0.0, d.y + 0.0, 0.0, (d.r or 30) + 15.0)
        SetBlipColour(blip, 1) SetBlipAlpha(blip, 110) SetBlipFlashes(blip, true)
    end
    G.send('war.board', d)
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and blip and DoesBlipExist(blip) then RemoveBlip(blip) end end)
