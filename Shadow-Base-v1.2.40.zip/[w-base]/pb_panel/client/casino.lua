-- Casino : points posés au Builder (caisse, jeux), décor du casino de GTA, croupier à la caisse, invite « E », fenêtre des jeux.
-- Tous les tirages sont faits par le serveur : ce fichier relaie les choix de l'interface et affiche les résultats.
local G = PBG
local cas = { points = {} }
local isOpen, openAt = false, nil
local blips, props = {}, {}
local OFFSET = { slots = 0.75, roulette = 1.25, blackjack = 1.1, wheel = 1.6, dice = 1.1, hilo = 1.1, scratch = 0.6, poker = 1.2, all = 0.75 }
local LABEL = { cashier = 'CAISSE DU CASINO', slots = 'MACHINE À SOUS', roulette = 'ROULETTE', blackjack = 'BLACKJACK', wheel = 'ROUE DE LA FORTUNE', dice = 'DÉS', hilo = 'PLUS HAUT / PLUS BAS', scratch = 'TICKETS À GRATTER', poker = 'TABLE DE POKER', all = 'JEUX DU CASINO' }

-- croupiers : tables où il y en a un, animations du casino de GTA (si la version du jeu les a, sinon geste générique)
local DEALER = { blackjack = true, roulette = true, dice = true, hilo = true, poker = true }
local DEALER_IDLE = { 'anim_casino_b@amb@casino@games@shared@dealer@', 'idle' }
local DEALER_DEAL = { 'anim_casino_b@amb@casino@games@blackjack@dealer', 'deal_card_player_01' }
CreateThread(function() if DoesAnimDictExist(DEALER_IDLE[1]) then RequestAnimDict(DEALER_IDLE[1]) end end)
local function ahead(p, d)
    local r = math.rad(p.h or 0.0)
    return p.x - math.sin(r) * d, p.y + math.cos(r) * d
end
-- Aperçu au Builder (client/carte.lua) : le jeu apparaît en transparence exactement où il sera posé
G.PlaceGhost = G.PlaceGhost or {}
G.PlaceGhost.casino_game = function(preset)
    local kind = (preset and preset ~= '') and preset or 'slots'
    local props = cas.props or {}
    local model = props[kind] or (kind == 'all' and props.slots) or nil
    if not model then return nil end
    return { model = model, dist = OFFSET[kind] or 0.8, turn = 180.0 }
end

-- Repère : un seul par casino (la caisse), et une borne isolée à plus de 80 m d'une caisse a le sien
local function drawBlips()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not cas.enabled or not cas.blips then return end
    local cashiers = {}
    for _, p in ipairs(cas.points) do if p.kind == 'cashier' then cashiers[#cashiers + 1] = p end end
    for _, p in ipairs(cas.points) do
        local show = p.kind == 'cashier'
        if not show then
            show = true
            for _, c in ipairs(cashiers) do if #(vector2(p.x, p.y) - vector2(c.x, c.y)) < 80.0 then show = false break end end
        end
        if show then
            local b = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
            SetBlipSprite(b, 679) SetBlipColour(b, 46) SetBlipScale(b, 0.85) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(p.kind == 'cashier' and p.label or 'Casino')) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        end
    end
end

-- Décor : machines et tables du casino de GTA, posées localement devant chaque point de jeu (si le modèle existe dans le jeu)
local function clearProps() for id, o in pairs(props) do if DoesEntityExist(o) then DeleteEntity(o) end props[id] = nil end end
CreateThread(function()
    while true do
        Wait(2000)
        if cas.enabled and cas.props and #cas.points > 0 then
            local me = GetEntityCoords(PlayerPedId())
            local want = {}
            for _, p in ipairs(cas.points) do
                local model = p.kind ~= 'cashier' and (cas.props[p.kind] or (p.kind == 'all' and cas.props.slots)) or nil
                if model and #(me - vector3(p.x, p.y, p.z)) < 90.0 then want[p.id] = { p = p, model = model } end
            end
            for id, o in pairs(props) do if not want[id] then if DoesEntityExist(o) then DeleteEntity(o) end props[id] = nil end end
            for id, w in pairs(want) do
                if not props[id] or not DoesEntityExist(props[id]) then
                    local h = joaat(w.model)
                    if IsModelInCdimage(h) then
                        RequestModel(h)
                        local t = GetGameTimer() + 3000
                        while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
                        if HasModelLoaded(h) then
                            local x, y = ahead(w.p, OFFSET[w.p.kind] or 0.8)
                            local gz = G.Ground and G.Ground(x, y, w.p.z) or (w.p.z - 1.0)
                            local o = CreateObjectNoOffset(h, x, y, gz, false, false, false)
                            SetEntityHeading(o, ((w.p.h or 0.0) + 180.0) % 360.0)
                            FreezeEntityPosition(o, true)
                            SetModelAsNoLongerNeeded(h)
                            props[id] = o
                        end
                    else
                        props[id] = 0   -- modèle absent (version du jeu trop ancienne) : on n'insiste pas
                    end
                end
            end
        elseif next(props) then clearProps() end
    end
end)

local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    local cc = c.casino or {}
    cas = { enabled = cc.enabled ~= false, points = cc.points or {}, props = cc.props, blips = cc.blips ~= false }
    clearProps()
    drawBlips()
    -- croupier derrière la caisse, tourné vers le client
    local npcs = {}
    local model = IsModelInCdimage(joaat('u_f_m_casinocash_01')) and 'u_f_m_casinocash_01' or 'a_f_y_business_02'   -- croupière du casino de GTA si la version du jeu l'a
    if cas.enabled then
        for _, p in ipairs(cas.points) do
            if p.kind == 'cashier' then
                local x, y = ahead(p, 1.3)
                npcs[#npcs + 1] = { id = p.id, model = model, x = x, y = y, z = p.z, h = ((p.h or 0.0) + 180.0) % 360.0 }
            end
        end
    end
    -- croupiers derrière les tables (blackjack, roulette, dés, plus haut / plus bas, poker), face aux joueurs
    if cas.enabled then
        local dm = IsModelInCdimage(joaat('s_f_y_casino_01')) and 's_f_y_casino_01' or 'a_f_y_business_02'
        local dm2 = IsModelInCdimage(joaat('s_m_y_casino_01')) and 's_m_y_casino_01' or dm
        for n, p in ipairs(cas.points) do
            if DEALER[p.kind] then
                local x, y = ahead(p, (OFFSET[p.kind] or 1.1) + 0.95)
                npcs[#npcs + 1] = { id = 'd_' .. p.id, model = n % 2 == 0 and dm2 or dm, x = x, y = y, z = p.z, h = ((p.h or 0.0) + 180.0) % 360.0, noturn = true,
                    anim = { DEALER_IDLE[1], DEALER_IDLE[2] }, scenario = 'PROP_HUMAN_STAND_IMPATIENT' }
            end
        end
    end
    G.Npcs('casino', npcs)
end
-- geste du croupier quand une main est distribuée / une mise jouée à sa table (le serveur prévient les joueurs proches)
RegisterNetEvent('pb:g:casino:dealer', function(pointId)
    local ped = G.NpcPed and G.NpcPed('casino', 'd_' .. tostring(pointId))
    if not ped or #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(ped)) > 40.0 then return end
    local dict, name = DEALER_DEAL[1], DEALER_DEAL[2]
    if not DoesAnimDictExist(dict) then dict, name = 'mp_common', 'givetake1_a' end
    RequestAnimDict(dict)
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(20) end
    if not HasAnimDictLoaded(dict) then return end
    TaskPlayAnim(ped, dict, name, 3.0, 3.0, 2200, 0, 0, false, false, false)
    SetTimeout(2400, function()
        if DoesEntityExist(ped) and DoesAnimDictExist(DEALER_IDLE[1]) and HasAnimDictLoaded(DEALER_IDLE[1]) then TaskPlayAnim(ped, DEALER_IDLE[1], DEALER_IDLE[2], 2.0, 2.0, -1, 1, 0, false, false, false) end
    end)
end)

-- Ouverture / fermeture ------------------------------------------------------------------------------------------------------------------
local function close(silent)
    if not isOpen then return end
    isOpen, openAt = false, nil
    G.focus(false)
    if not silent then G.send('casino.close', {}) end
    TriggerServerEvent('pb:g:casino:close')
end
RegisterNetEvent('pb:g:casino:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if not isOpen then isOpen = true G.focus(true) end
    openAt = GetEntityCoords(PlayerPedId())
    G.send('casino.open', d)
end)
RegisterNetEvent('pb:g:casino:res', function(j)
    local d = G.decode(j)
    if not d or not isOpen then return end
    G.send('casino.res', d)
end)
G.nui['casino.act'] = function(d)
    if isOpen and type(d.game) == 'string' and type(d.action) == 'string' then
        TriggerServerEvent('pb:g:casino:act', d.game:sub(1, 12), d.action:sub(1, 12), json.encode(type(d.payload) == 'table' and d.payload or {}))
    end
    return {}
end
G.nui['casino.close'] = function() close(true) return {} end
G.onForceClose(function() close(true) end)

-- Invite « E » et point lumineux
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        local sleep = 800
        if isOpen then
            hide()
            sleep = 300
            local me = GetEntityCoords(PlayerPedId())
            if openAt and (#(me - openAt) > 4.0 or G.state.dead) then G.send('casino.close', {}) close(true) end
        elseif cas.enabled and #cas.points > 0 and G.begun and not G.state.dead and (G.locked or 0) == 0 then
            local me = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, p in ipairs(cas.points) do
                local d = #(me - vector3(p.x, p.y, p.z))
                if d < 25.0 and (not bd or d < bd) then best, bd = p, d end
            end
            if best then
                sleep = 0
                G.Point(best.x + 0.0, best.y + 0.0, best.z - 1.0, 255, 215, 120, 1.0)
                if bd < 1.6 then
                    local key = best.id
                    if shown ~= key then shown = key G.send('prompt', { show = true, key = 'E', text = LABEL[best.kind] or 'CASINO' }) end
                    if IsControlJustReleased(0, 38) then hide() TriggerServerEvent('pb:g:casino:open') end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then clearProps() end end)
