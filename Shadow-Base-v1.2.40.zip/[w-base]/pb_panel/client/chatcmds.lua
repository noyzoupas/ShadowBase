-- Commandes de chat côté joueur (rien à vérifier côté serveur) : raccourcis des touches du véhicule, vider le chat, changer de siège…
local G = PBG

local function note(kind, text) G.send('notify', { type = kind, title = 'Commandes', text = text }) end
local function alias(names, target, help)
    for _, n in ipairs(names) do
        RegisterCommand(n, function() ExecuteCommand(target) end, false)
        TriggerEvent('chat:addSuggestion', '/' .. n, help)
    end
end

alias({ 'moteur' }, 'pb_engine', 'Allumer / couper le moteur')
alias({ 'coffre' }, 'pb_trunk', 'Ouvrir le coffre du véhicule')
alias({ 'capot' }, 'pb_hood', 'Ouvrir / fermer le capot')
alias({ 'vitres' }, 'pb_windows', 'Baisser / remonter les vitres')
alias({ 'ceinture' }, 'pb_belt', 'Mettre / enlever la ceinture')
alias({ 'verrou', 'lock' }, 'pb_lock', 'Verrouiller / déverrouiller ton véhicule')
alias({ 'sac', 'inventaire' }, 'pb_inv', "Ouvrir l'inventaire")
alias({ 'telephone', 'tel' }, 'pb_phone', 'Ouvrir le téléphone')

RegisterCommand('clear', function() G.send('chat.clear', {}) end, false)
TriggerEvent('chat:addSuggestion', '/clear', 'Vider ton chat')

-- /siege 1 à 4 : 1 = conducteur, 2 = passager avant, 3 et 4 = arrière (seulement si la place est libre et le véhicule arrêté)
RegisterCommand('siege', function(_, args)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then note('warn', 'Tu dois être dans un véhicule.') return end
    local n = math.floor(tonumber(args[1]) or 0)
    local max = GetVehicleMaxNumberOfPassengers(veh) + 1
    if n < 1 or n > max then note('warn', ('Utilisation : /siege 1 à %d'):format(max)) return end
    if GetEntitySpeed(veh) > 1.5 then note('warn', "Arrête le véhicule d'abord.") return end
    local seat = n - 2
    if not IsVehicleSeatFree(veh, seat) then note('warn', 'Cette place est occupée.') return end
    SetPedIntoVehicle(ped, veh, seat)
end, false)
TriggerEvent('chat:addSuggestion', '/siege', 'Changer de place dans le véhicule', { { name = 'place', help = '1 conducteur, 2 passager, 3-4 arrière' } })

RegisterCommand('position', function()
    local c = GetEntityCoords(PlayerPedId())
    local s1, s2 = GetStreetNameAtCoord(c.x, c.y, c.z)
    local street = GetStreetNameFromHashKey(s1)
    local cross = s2 ~= 0 and GetStreetNameFromHashKey(s2) or ''
    local zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
    note('info', street .. (cross ~= '' and (' / ' .. cross) or '') .. (zone ~= '' and zone ~= 'NULL' and (' · ' .. zone) or ''))
end, false)
TriggerEvent('chat:addSuggestion', '/position', 'Nom de la rue et du quartier où tu es')
