-- Téléphone : touche réglable, fenêtre de type tablette, rafraîchissement à l'arrivée d'un message.
local G = PBG
local isOpen = false
local curPage = 'home'

local function busy() return G.creating or G.wardrobe or G.state.dead or (G.shopIsOpen and G.shopIsOpen()) end

-- Objet et animation « téléphone en main » (réglable côté serveur, non testé dans un vrai client FiveM)
local prop
local function animOn()
    local ped = PlayerPedId()
    if prop or IsPedInAnyVehicle(ped, false) or IsEntityDead(ped) then return end
    local model = joaat('prop_npc_phone_02')
    RequestModel(model)
    local t = GetGameTimer() + 1500
    while not HasModelLoaded(model) and GetGameTimer() < t do Wait(10) end
    if not HasModelLoaded(model) then return end
    local c = GetEntityCoords(ped)
    prop = CreateObject(model, c.x, c.y, c.z + 0.2, true, true, false)
    AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(model)
    local dict = 'cellphone@'
    RequestAnimDict(dict)
    local t2 = GetGameTimer() + 1500
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t2 do Wait(10) end
    if HasAnimDictLoaded(dict) then TaskPlayAnim(ped, dict, 'cellphone_text_read_base', 3.0, -1.0, -1, 50, 0, false, false, false) end
end
local function animOff()
    local ped = PlayerPedId()
    if prop then
        if DoesEntityExist(prop) then DetachEntity(prop, true, true) DeleteEntity(prop) end
        prop = nil
        StopAnimTask(ped, 'cellphone@', 'cellphone_text_read_base', 1.0)
    end
end
local function animEnabled() return G.cfg.phone and G.cfg.phone.anim ~= false end
G.phoneOpen = function() return isOpen end

local function close()
    if not isOpen then return end
    animOff()
    isOpen = false
    TriggerServerEvent('pb:g:phone:close')
    G.focus(false)
    G.send('phone.close', {})
end

RegisterNetEvent('pb:g:phone:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if d.ev == 'open' then
        if isOpen or busy() then TriggerServerEvent('pb:g:phone:close') return end
        isOpen = true
        G.focus(true)
        if animEnabled() then CreateThread(animOn) end
    elseif not isOpen then return end
    if d.page and d.page.page then curPage = d.page.page end
    if d.ev == 'open' then d.clock = { GetClockHours(), GetClockMinutes() } end
    G.send('phone.' .. tostring(d.ev), d)
end)
RegisterNetEvent('pb:g:phone:incoming', function(j)
    local d = G.decode(j) or {}
    if d.sound then PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true) end
    if isOpen then TriggerServerEvent('pb:g:phone:page', curPage) end
end)
-- GPS : le serveur envoie un point (ou rien pour effacer) ; on pose le repère natif du jeu.
RegisterNetEvent('pb:g:phone:gps', function(x, y)
    if x and y then SetNewWaypoint(x + 0.0, y + 0.0) else DeleteWaypoint() end
end)
-- « Où est ma voiture ? » : repères temporaires sur la carte (2 minutes), retirés ensuite
local carBlips = {}
RegisterNetEvent('pb:g:phone:carblip', function(j)
    for _, b in ipairs(carBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    carBlips = {}
    for _, c in ipairs(G.decode(j) or {}) do
        local b = AddBlipForCoord(c.x + 0.0, c.y + 0.0, (c.z or 0.0) + 0.0)
        SetBlipSprite(b, 225) SetBlipColour(b, c.live and 3 or 40) SetBlipScale(b, 0.9) SetBlipFlashes(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(c.label or 'Mon véhicule') .. (c.live and '' or ' (dernière position)')) EndTextCommandSetBlipName(b)
        carBlips[#carBlips + 1] = b
    end
    local mine = carBlips
    SetTimeout(120000, function() for _, b in ipairs(mine) do if DoesBlipExist(b) then RemoveBlip(b) end end end)
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then for _, b in ipairs(carBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end end end)
-- Heure du jeu dans la barre d'état
CreateThread(function()
    local last
    while true do
        Wait(2000)
        if isOpen then
            local k = GetClockHours() * 60 + GetClockMinutes()
            if k ~= last then last = k G.send('phone.clock', { h = GetClockHours(), m = GetClockMinutes() }) end
        else last = nil end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then animOff() end end)

G.nui['phone.page'] = function(d) if isOpen then curPage = tostring(d.page or 'home') TriggerServerEvent('pb:g:phone:page', curPage) end return {} end
G.nui['phone.act'] = function(d) if isOpen and type(d.name) == 'string' then TriggerServerEvent('pb:g:phone:act', d.name, type(d.payload) == 'table' and d.payload or {}, tostring(d.page or curPage)) end return {} end
G.nui['phone.close'] = function() close() return {} end

RegisterCommand('pb_phone', function()
    if not G.begun or busy() then return end
    if isOpen then close() else TriggerServerEvent('pb:g:phone:open') end
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.phone and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_phone', 'Ouvrir le téléphone', 'keyboard', (G.cfg.phone and G.cfg.phone.key) or 'F1')
end)
CreateThread(function() while true do Wait(500) if isOpen and busy() then close() end end end)
G.onForceClose(function() close() end)

-- Contrat de vente reçu (app Contrats) : signer ou refuser
RegisterNetEvent('pb:g:deal:offer', function(j)
    local d = PBG.decode(j)
    if not d then return end
    local G = PBG
    local function money(n) return (tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) .. ' $' end
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    G.Menu.Open({ id = 'deal.offer', title = 'Contrat de vente', subtitle = tostring(d.from or '') .. ' te propose', banner = { text = 'Contrat' }, items = {
        { type = 'separator', label = tostring(d.what or '') },
        { label = 'Signer et payer ' .. money(d.price), icon = 'check', description = ('Banque puis espèces. Tu as %d secondes pour signer.'):format(d.secs or 60), onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:deal:answer', true) end },
        { label = 'Refuser', icon = 'x', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:deal:answer', false) end },
    } })
end)
