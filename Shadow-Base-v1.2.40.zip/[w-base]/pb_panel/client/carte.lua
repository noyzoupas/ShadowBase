-- Carte : téléporte l'admin à l'endroit cliqué sur la carte du panel, puis attend sa confirmation (E) ou son annulation (Retour arrière).
-- Rien n'est créé ici : le serveur relit la position du joueur au moment de la confirmation.
local G = PBG
local active   -- { label, name }
local pack     -- { i, n, name, hint } : pose de tous les points d'une entreprise ou d'une organisation

local function findGround(x, y)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true)
    local z = 1000.0
    local found = nil
    local t0 = GetGameTimer()
    while GetGameTimer() - t0 < 6000 do
        RequestCollisionAtCoord(x, y, z)
        SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)
        Wait(50)
        local ok, gz = GetGroundZFor_3dCoord(x, y, z, false)
        if ok and gz and gz > -150.0 then found = gz break end
        z = z - 40.0
        if z < -100.0 then z = 1000.0 end
    end
    return found
end

RegisterNetEvent('pb:carte:go', function(j)
    local d = G.decode(j)
    if not d or not tonumber(d.x) or not tonumber(d.y) then return end
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16) Wait(800) ped = PlayerPedId() end
    DoScreenFadeOut(400)
    while not IsScreenFadedOut() do Wait(10) end
    local gz = findGround(d.x + 0.0, d.y + 0.0)
    if gz then SetEntityCoordsNoOffset(ped, d.x + 0.0, d.y + 0.0, gz + 1.0, false, false, false) end
    FreezeEntityPosition(ped, false)
    DoScreenFadeIn(500)
    active = { label = tostring(d.label or ''), name = tostring(d.name or '') }
    G.send('notify', { type = gz and 'info' or 'warn', text = gz and 'Tu es sur place. Place-toi exactement où tu veux (noclip possible).' or 'Sol introuvable ici : avance puis confirme là où tu veux.' })
end)

-- Aperçu de ce qui va être posé (jeu du casino…) : objet local en transparence devant toi, il suit tes mouvements
local ghost
local function ghostOff() if ghost and ghost.ent and DoesEntityExist(ghost.ent) then DeleteEntity(ghost.ent) end ghost = nil end
local function ghostOn(info)
    ghostOff()
    if not info or not info.model then return end
    local h = joaat(info.model)
    if not IsModelInCdimage(h) then return end
    ghost = { info = info }
    local mine = ghost
    CreateThread(function()
        RequestModel(h)
        local t = GetGameTimer() + 3000
        while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
        if ghost ~= mine or not HasModelLoaded(h) then return end
        local c = GetEntityCoords(PlayerPedId())
        local e = CreateObjectNoOffset(h, c.x, c.y, c.z, false, false, false)
        SetModelAsNoLongerNeeded(h)
        SetEntityAlpha(e, 150, false)
        SetEntityCollision(e, false, false)
        FreezeEntityPosition(e, true)
        mine.ent = e
    end)
end
local function ghostTick()
    if not ghost or not ghost.ent or not DoesEntityExist(ghost.ent) then return end
    local ped = PlayerPedId()
    local c, hd = GetEntityCoords(ped), GetEntityHeading(ped)
    local r = math.rad(hd)
    local d = ghost.info.dist or 0.0
    local x, y = c.x - math.sin(r) * d, c.y + math.cos(r) * d
    local ok, gz = GetGroundZFor_3dCoord(x, y, c.z + 1.0, false)
    SetEntityCoordsNoOffset(ghost.ent, x, y, ok and gz or (c.z - 1.0), false, false, false)
    SetEntityHeading(ghost.ent, (hd + (ghost.info.turn or 0.0)) % 360.0)
end

-- Builder du menu staff : on pose sur place, sans téléportation ; le menu revient ensuite là où il était
RegisterNetEvent('pb:carte:arm', function(j)
    local d = G.decode(j)
    if not d then return end
    active = { label = tostring(d.label or ''), name = tostring(d.name or '') }
    local fn = G.PlaceGhost and G.PlaceGhost[tostring(d.type or '')]
    ghostOn(fn and fn(tostring(d.preset or '')) or nil)
end)
function G.PlaceArmed() return active ~= nil end

RegisterNetEvent('pb:carte:pack', function(j)
    local d = G.decode(j)
    if not d or d.done then pack = nil G.send('prompt', { show = false }) return end
    pack = { i = tonumber(d.i) or 1, n = tonumber(d.n) or 1, name = tostring(d.name or ''), hint = tostring(d.hint or '') }
    G.send('prompt', { show = true, free = true, key = 'E', text = ('Étape %d/%d · %s : poser ici  ·  Retour arrière : passer  ·  /carte_annuler : arrêter'):format(pack.i, pack.n, pack.name) })
    if pack.hint ~= '' then G.send('notify', { type = 'info', title = pack.name, text = pack.hint }) end
end)
RegisterNetEvent('pb:carte:done', function()
    active = nil
    ghostOff()
    G.send('prompt', { show = false })
    if G.Menu.IsSuspended and G.Menu.IsSuspended() then G.Menu.Resume() end   -- retour d'une étape dans le menu du Builder
end)
RegisterNetEvent('pb:carte:back', function(j)
    local c = G.decode(j)
    if not c then return end
    local ped = PlayerPedId()
    RequestCollisionAtCoord(c.x + 0.0, c.y + 0.0, c.z + 0.0)
    SetEntityCoordsNoOffset(ped, c.x + 0.0, c.y + 0.0, c.z + 0.0, false, false, false)
end)

CreateThread(function()
    while true do
        if pack and not active then
            if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:carte:pack:set')
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then TriggerServerEvent('pb:carte:pack:skip') end
            Wait(0)
        else Wait(300) end
    end
end)

CreateThread(function()
    local shown = false
    while true do
        if active then
            if not shown then shown = true G.send('prompt', { show = true, free = true, key = 'E', text = 'Placer « ' .. active.name .. ' » ici  ·  Retour arrière : annuler' }) end
            ghostTick()
            if IsControlJustPressed(0, 38) then TriggerServerEvent('pb:carte:confirm') active = nil shown = false ghostOff() G.send('prompt', { show = false })
            elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then TriggerServerEvent('pb:carte:cancel') active = nil shown = false ghostOff() G.send('prompt', { show = false }) end
            Wait(0)
        else
            if shown then shown = false G.send('prompt', { show = false }) end
            Wait(500)
        end
    end
end)

RegisterCommand('carte_annuler', function()
    if active then TriggerServerEvent('pb:carte:cancel') active = nil end
    if pack then TriggerServerEvent('pb:carte:pack:stop') pack = nil G.send('prompt', { show = false }) end
end, false)
G.onForceClose(function() active = nil pack = nil ghostOff() end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then ghostOff() end end)
