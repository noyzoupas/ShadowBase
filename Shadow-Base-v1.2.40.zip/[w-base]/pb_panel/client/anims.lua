-- Menu des animations (accès direct depuis le menu ALT, sur soi) : scénarios du jeu et animations rangés par thème, plus celles du panel.
-- Purement cosmétique : rien n'est décidé ici ; on refuse seulement quand le personnage est à terre, menotté ou en véhicule.
local G = PBG

local THEMES = {
    { 'Salutations', 'hand', {
        { 'Mains en l\'air', 'anim', 'missminuteman_1ig_2', 'handsup_base', 49 }, { 'Salut militaire', 'anim', 'anim@mp_player_intincarsalutestd@ds@', 'idle_a', 49 },
        { 'Coucou', 'anim', 'friends@frj@ig_1', 'wave_a', 49 }, { 'Bras croisés', 'anim', 'amb@world_human_hang_out_street@female_arms_crossed@idle_a', 'idle_a', 49 } } },
    { 'Humeur', 'face', {
        { 'Facepalm', 'anim', 'anim@mp_player_intcelebrationmale@face_palm', 'face_palm', 49 }, { 'Pouce en l\'air', 'anim', 'anim@mp_player_intincarthumbs_upbodhi@ps@', 'enter', 49 },
        { 'Applaudir', 'scn', 'WORLD_HUMAN_CHEERING' }, { 'Pleurer', 'anim', 'amb@code_human_wander_texting_fat@male@idle_a', 'idle_c', 49 } } },
    { 'Repos', 'bed', {
        { 'S\'asseoir', 'scn', 'PROP_HUMAN_SEAT_BENCH' }, { 'S\'adosser au mur', 'scn', 'WORLD_HUMAN_LEANING' }, { 'Fumer', 'scn', 'WORLD_HUMAN_SMOKING' },
        { 'Boire un café', 'scn', 'WORLD_HUMAN_AA_COFFEE' }, { 'Se détendre', 'scn', 'WORLD_HUMAN_STAND_IMPATIENT' }, { 'Regarder autour', 'scn', 'WORLD_HUMAN_BINOCULARS' } } },
    { 'Sport', 'bolt', {
        { 'Pompes', 'scn', 'WORLD_HUMAN_PUSH_UPS' }, { 'Abdos', 'scn', 'WORLD_HUMAN_SIT_UPS' }, { 'Yoga', 'scn', 'WORLD_HUMAN_YOGA' },
        { 'Jogging sur place', 'scn', 'WORLD_HUMAN_JOG_STANDING' }, { 'Muscu', 'scn', 'WORLD_HUMAN_MUSCLE_FLEX' } } },
    { 'Danses', 'music', {
        { 'Danse 1', 'anim', 'anim@amb@nightclub@dancers@crowddance_groups@', 'hi_dance_crowd_09_v1_male^1', 1 }, { 'Danse 2', 'anim', 'anim@amb@nightclub@dancers@crowddance_groups@', 'hi_dance_crowd_11_v1_female^1', 1 },
        { 'Fêter ça', 'scn', 'WORLD_HUMAN_PARTYING' } } },
    { 'Métier', 'briefcase', {
        { 'Prendre des notes', 'scn', 'WORLD_HUMAN_CLIPBOARD' }, { 'Téléphoner', 'scn', 'WORLD_HUMAN_STAND_MOBILE' }, { 'Photographier', 'scn', 'WORLD_HUMAN_PAPARAZZI' },
        { 'Réparer', 'scn', 'WORLD_HUMAN_WELDING' }, { 'Garde', 'scn', 'WORLD_HUMAN_GUARD_STAND' } } },
}

local function allowed()
    local ped = PlayerPedId()
    if G.state.dead or IsEntityDead(ped) then G.send('notify', { type = 'warn', text = 'Impossible à terre.' }) return false end
    if IsPedInAnyVehicle(ped, false) then G.send('notify', { type = 'warn', text = 'Sors du véhicule pour jouer une animation.' }) return false end
    if G.IsCuffed and G.IsCuffed() then return false end
    return true
end
local function play(a)
    if not allowed() then return end
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    if a[2] == 'scn' then TaskStartScenarioInPlace(ped, a[3], 0, true) return end
    RequestAnimDict(a[3])
    local t = GetGameTimer() + 3000
    while not HasAnimDictLoaded(a[3]) and GetGameTimer() < t do Wait(10) end
    if HasAnimDictLoaded(a[3]) then TaskPlayAnim(ped, a[3], a[4], 4.0, -4.0, -1, tonumber(a[5]) or 1, 0, false, false, false) else G.send('notify', { type = 'warn', text = 'Animation introuvable.' }) end
end

-- animations du panel : « libellé|dictionnaire|clip|drapeau »
local function customs()
    local out = {}
    for _, line in ipairs(((G.cfg.ctx or {}).custom_anims) or {}) do
        local l, d, c, f = tostring(line):match('^([^|]+)|([%w_@%-%.]+)|([%w_%-%.]+)|(%d+)$')
        if l then out[#out + 1] = { l, 'anim', d, c, tonumber(f) } end
    end
    return out
end

local def = { id = 'anims', title = 'Animations', subtitle = 'Choisis une animation', refreshOnReturn = true }
def.build = function()
    local items = {}
    for _, th in ipairs(THEMES) do
        local sub = {}
        for _, a in ipairs(th[3]) do sub[#sub + 1] = { label = a[1], onSelect = function() play(a) end } end
        items[#items + 1] = { type = 'submenu', label = th[1], icon = th[2], submenu = { id = 'anims.' .. th[1], title = th[1], subtitle = 'Animations', items = sub } }
    end
    local c = customs()
    if #c > 0 then
        local sub = {}
        for _, a in ipairs(c) do sub[#sub + 1] = { label = a[1], onSelect = function() play(a) end } end
        items[#items + 1] = { type = 'submenu', label = 'Du serveur', icon = 'star', submenu = { id = 'anims.custom', title = 'Du serveur', subtitle = 'Animations ajoutées', items = sub } }
    end
    items[#items + 1] = { label = 'Arrêter l\'animation', icon = 'x', onSelect = function() ClearPedTasks(PlayerPedId()) end }
    return items
end
RegisterCommand('pb_anims', function()
    if not G.begun or G.creating or G.wardrobe or G.state.dead then return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    G.Menu.Open(def)
end, false)
