-- Carburant : consommation selon la vitesse, moteur qui cale à sec, pompes (menu), sauvegarde des dégâts en route, épave, clé du véhicule.
-- Le serveur décide du prix et du paiement ; ici on lit le jeu (vitesse, régime) et on applique le niveau d'essence.
local G = PBG
local stations, blips = {}, {}
local dry = {}                      -- véhicules à sec déjà signalés
local keyOk = {}                    -- plaque -> clé vérifiée par le serveur

local function cfg() return G.cfg and G.cfg.fuel or {} end
local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', '') end
local function tankOf(veh)
    local hud = G.cfg and G.cfg.hud or {}
    local t = tonumber(hud.tank_l) or 0
    if t <= 0 then t = (GetVehicleHandlingFloat and GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')) or 0.0 end
    if not t or t < 1.0 then t = 65.0 end
    return t
end
local function level(veh) return GetVehicleFuelLevel and GetVehicleFuelLevel(veh) or 0.0 end

-- Consommation --------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(1000)
        local c = cfg()
        if c.enabled ~= false and G.begun then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and GetIsVehicleEngineRunning(veh) and not IsEntityDead(veh) then
                local maxs = (GetVehicleEstimatedMaxSpeed and GetVehicleEstimatedMaxSpeed(veh) or 40.0) + 0.1
                local ratio = math.min(1.0, GetEntitySpeed(veh) / maxs)
                local rpm = GetVehicleCurrentRpm and GetVehicleCurrentRpm(veh) or 0.3
                local idle, drive = tonumber(c.idle_pct_min) or 0.35, tonumber(c.drive_pct_min) or 2.6
                local pct = idle + (drive - idle) * (ratio ^ 1.3) * (0.6 + 0.4 * rpm)
                local lv = level(veh)
                local nlv = math.max(0.0, lv - tankOf(veh) * pct / 100.0 / 60.0)
                if SetVehicleFuelLevel then SetVehicleFuelLevel(veh, nlv) end
                -- consommation moyenne réelle (L/100 km), lissée : sert à l'autonomie du compteur
                local kmh = GetEntitySpeed(veh) * 3.6
                if kmh > 10.0 then
                    local per100 = (lv - nlv) / (kmh / 3600.0) * 100.0
                    per100 = math.max(3.0, math.min(60.0, per100))
                    G.fuelAvg = G.fuelAvg and (G.fuelAvg * 0.9 + per100 * 0.1) or per100
                end
                if nlv <= 0.05 then
                    SetVehicleEngineOn(veh, false, true, true)
                    if not dry[veh] then dry[veh] = true G.send('notify', { type = 'warn', title = 'Carburant', text = 'Panne sèche !' }) end
                end
            end
        end
    end
end)
-- à sec, le moteur ne se rallume pas
CreateThread(function()
    while true do
        Wait(250)
        local veh = GetVehiclePedIsIn(PlayerPedId(), false)
        if veh ~= 0 and level(veh) <= 0.05 and GetIsVehicleEngineRunning(veh) and (cfg().enabled ~= false) then SetVehicleEngineOn(veh, false, true, true) end
        if veh ~= 0 and level(veh) > 0.5 then dry[veh] = nil end
    end
end)

-- Stations -------------------------------------------------------------------------------------------------------------------------------
local prev = G.onCfg
G.onCfg = function(c)
    if prev then prev(c) end
    stations = (c.fuel and c.fuel.stations) or {}
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not (c.fuel and c.fuel.blips) then return end
    for _, s in ipairs(stations) do
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, 361) SetBlipColour(b, 1) SetBlipScale(b, 0.7) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end

local fillVeh = 0   -- véhicule choisi pour le plein (à pied : celui garé à côté de la pompe)
local function pumpMenu(st, veh)
    fillVeh = veh
    local c = cfg()
    local tank = tankOf(veh)
    local need = math.floor(tank - level(veh) + 0.5)
    if need < 1 then G.send('notify', { type = 'info', title = st.label, text = 'Le réservoir est déjà plein.' }) return end
    local price = (tonumber(st.price) or 0) > 0 and tonumber(st.price) or (tonumber(c.price) or 3)
    local function opt(label, l)
        l = math.min(l, need)
        return { label = ('%s — %d L'):format(label, l), right = ('≈ %d $'):format(math.floor(price * l + 0.5)), onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:fuel:buy', st.id, l) end }
    end
    G.Menu.Open({ id = 'fuel', title = st.label, subtitle = ('%s $ le litre · il manque %d L'):format(tostring(price), need), items = { opt('Un peu', 10), opt('Moyen', 25), opt('Faire le plein', need) } })
end

RegisterNetEvent('pb:g:fuel:add', function(j)
    local d = G.decode(j)
    local veh = (fillVeh ~= 0 and DoesEntityExist(fillVeh)) and fillVeh or GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 then local c = GetEntityCoords(PlayerPedId()) veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    if not d or veh == 0 or not SetVehicleFuelLevel then return end
    local target = math.min(tankOf(veh), level(veh) + (tonumber(d.liters) or 0))
    CreateThread(function()
        local start = level(veh)
        for i = 1, 20 do Wait(120) SetVehicleFuelLevel(veh, start + (target - start) * i / 20) end
        dry[veh] = nil
    end)
end)

-- (v1.2.39) Plein à une vraie pompe : à pied à côté de la pompe (véhicule garé à côté) ou au volant, moteur coupé automatiquement.
local PUMPS = {}
for _, m in ipairs({ 'prop_gas_pump_1a', 'prop_gas_pump_1b', 'prop_gas_pump_1c', 'prop_gas_pump_1d', 'prop_vintage_pump', 'prop_gas_pump_old2', 'prop_gas_pump_old3' }) do PUMPS[#PUMPS + 1] = GetHashKey(m) end
local function pumpNear(pos, r)
    for _, h in ipairs(PUMPS) do
        local o = GetClosestObjectOfType(pos.x, pos.y, pos.z, r, h, false, false, false)
        if o ~= 0 then return o end
    end
end
local function carNear(ped)
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 then return GetPedInVehicleSeat(veh, -1) == ped and veh or 0 end
    local c = GetEntityCoords(ped)
    local best, bd = 0, 7.0
    for _, v in ipairs(GetGamePool and GetGamePool('CVehicle') or {}) do
        local d = #(c - GetEntityCoords(v))
        if d < bd then best, bd = v, d end
    end
    return best
end
CreateThread(function()
    local shown = false
    local function hide() if shown then shown = false G.send('prompt', { show = false }) end end
    while true do
        if not G.begun or #stations == 0 or G.Menu.IsOpen() or cfg().enabled == false then hide() Wait(600)
        else
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd
            for _, s in ipairs(stations) do local d = #(c - vector3(s.x + 0.0, s.y + 0.0, s.z + 0.0)) if not bd or d < bd then best, bd = s, d end end
            local area = tonumber(cfg().area) or 30.0
            local ok, veh = false, 0
            if best and bd <= area then
                veh = carNear(ped)
                local inCar = GetVehiclePedIsIn(ped, false) ~= 0
                local reach = (tonumber(cfg().use_dist) or 4.0) + (inCar and 2.5 or 0.0)
                local pump = pumpNear(c, reach)
                -- station sur mesure sans pompe du jeu : au point lui-même
                ok = veh ~= 0 and (pump ~= nil or bd <= reach)
            end
            if ok then
                if not shown then shown = true G.send('prompt', { show = true, key = 'E', text = 'Faire le plein : ' .. best.label }) end
                if IsControlJustPressed(0, 38) then
                    if cfg().engine_off_to_fill ~= false and GetIsVehicleEngineRunning(veh) then SetVehicleEngineOn(veh, false, false, true) end
                    hide() pumpMenu(best, veh)
                end
                Wait(0)
            else hide() Wait(bd and bd < 60 and 250 or 900) end
        end
    end
end)

-- Dégâts : sauvegarde de l'état toutes les 30 s et en sortant, épave si le véhicule est détruit ---------------------------------------
local function tyres(veh) local m = 0 for i = 0, 7 do if IsVehicleTyreBurst(veh, i, false) then m = m | (1 << i) end end return m end
local function doors(veh) local m = 0 for i = 0, 5 do if IsVehicleDoorDamaged and IsVehicleDoorDamaged(veh, i) then m = m | (1 << i) end end return m end
function G.VehProps(veh)
    local c1, c2 = GetVehicleColours(veh)
    return { eh = GetVehicleEngineHealth(veh), bh = GetVehicleBodyHealth(veh), th = GetVehiclePetrolTankHealth(veh), fuel = level(veh), c1 = c1, c2 = c2, dirt = GetVehicleDirtLevel(veh), ty = tyres(veh), dr = doors(veh) }
end
function G.ApplyDamage(veh, p)
    if p.ty then for i = 0, 7 do if p.ty & (1 << i) ~= 0 then SetVehicleTyreBurst(veh, i, true, 1000.0) end end end
    if p.dr then for i = 0, 5 do if p.dr & (1 << i) ~= 0 then SetVehicleDoorBroken(veh, i, true) end end end
end
CreateThread(function()
    local lastVeh, lastPlate = 0, ''
    while true do
        Wait(1500)
        if G.begun then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                lastVeh, lastPlate = veh, plateOf(veh)
                if IsEntityDead(veh) then TriggerServerEvent('pb:g:veh:wreck', lastPlate) Wait(4000) end
            elseif lastVeh ~= 0 then
                if DoesEntityExist(lastVeh) and not IsEntityDead(lastVeh) then TriggerServerEvent('pb:g:veh:sync', lastPlate, G.VehProps(lastVeh)) end
                lastVeh, lastPlate = 0, ''
            end
        end
    end
end)
CreateThread(function()
    while true do
        Wait(30000)
        local ped = PlayerPedId()
        local veh = G.begun and GetVehiclePedIsIn(ped, false) or 0
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and not IsEntityDead(veh) then TriggerServerEvent('pb:g:veh:sync', plateOf(veh), G.VehProps(veh)) end
    end
end)

-- Clé : un véhicule acheté en ville ne démarre qu'avec sa clé (le trafic reste libre) ---------------------------------------------------
RegisterNetEvent('pb:g:veh:checked', function(j)
    local d = G.decode(j)
    if d and d.plate then keyOk[d.plate] = (not d.owned) or d.key == true end
end)
CreateThread(function()
    local asked = {}
    while true do
        Wait(300)
        local veh = G.begun and GetVehiclePedIsIn(PlayerPedId(), false) or 0
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == PlayerPedId() then
            local plate = plateOf(veh)
            if keyOk[plate] == nil then
                if not asked[plate] or GetGameTimer() - asked[plate] > 4000 then asked[plate] = GetGameTimer() TriggerServerEvent('pb:g:veh:check', plate) end
                -- en attendant la réponse du serveur, le moteur reste coupé quelques instants
                if GetIsVehicleEngineRunning(veh) then SetVehicleEngineOn(veh, false, true, true) end
            elseif keyOk[plate] == false then
                if GetIsVehicleEngineRunning(veh) then SetVehicleEngineOn(veh, false, true, true) G.send('notify', { type = 'warn', title = 'Véhicule', text = "Tu n'as pas la clé de ce véhicule." }) end
            end
        end
    end
end)
