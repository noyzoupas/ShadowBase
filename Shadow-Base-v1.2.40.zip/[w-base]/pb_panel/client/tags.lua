-- Gamertags : le serveur envoie les textes (nom, rang, métier) ; ici on calcule seulement où les poser à l'écran.
local G = PBG
local map = {}
local shownLast = ''
local through = false
RegisterNetEvent('pb:g:tags:walls', function(v) through = v == 1 end)

RegisterNetEvent('pb:g:tags', function(j)
    local l = G.decode(j) or {}
    map = {}
    for _, e in ipairs(l) do if type(e) == 'table' and e.i then map[e.i] = e end end
    G.send('tags.data', { list = l })
end)

local function cfg() return G.cfg and G.cfg.tags or {} end
-- (v1.2.40) chaque joueur (staff compris) peut masquer les noms au-dessus des têtes : F5 › Mes paramètres
G.tagsOff = GetResourceKvpString('pb_tags_off') == 'on'

CreateThread(function()
    while true do
        local c = cfg()
        if c.enabled == false or G.tagsOff or next(map) == nil or IsPauseMenuActive() then
            if shownLast ~= '' then shownLast = '' G.send('tags.pos', { p = {} }) end
            Wait(500)
        else
            Wait(0)
            local me = PlayerPedId()
            local mc = GetEntityCoords(me)
            local maxd = (tonumber(c.distance) or 25) + 0.0
            local maxn = tonumber(c.max_shown) or 24
            local out, n = {}, 0
            for _, pl in ipairs(GetActivePlayers()) do
                local sid = GetPlayerServerId(pl)
                local e = map[sid]
                if e and (pl ~= PlayerId() or c.show_self == true) and n < maxn then
                    local ped = GetPlayerPed(pl)
                    if ped ~= 0 and DoesEntityExist(ped) and not (IsEntityVisible and not IsEntityVisible(ped)) then
                        local pc = GetEntityCoords(ped)
                        local d = #(pc - mc)
                        if d <= maxd and (pl == PlayerId() or through or HasEntityClearLosToEntity(me, ped, 17)) then
                            -- ancre fixe au-dessus du personnage (la tête bouge avec les animations : l'étiquette tremblait)
                            local top = IsPedInAnyVehicle(ped, false) and 0.95 or 1.25
                            local ok, x, y = GetScreenCoordFromWorldCoord(pc.x, pc.y, pc.z + top)
                            if ok then
                                n = n + 1
                                local sc = 1.0 - (d / maxd) * 0.45
                                out[n] = { i = sid, x = math.floor(x * 10000 + 0.5) / 10000, y = math.floor(y * 10000 + 0.5) / 10000, s = math.floor(sc * 50 + 0.5) / 50,
                                    t = (c.show_talking ~= false and NetworkIsPlayerTalking(pl)) and 1 or 0 }
                                if c.show_bar ~= 'none' then
                                    local mx = (GetEntityMaxHealth(ped) or 200) - 100
                                    out[n].b = mx > 0 and math.max(0, math.min(100, math.floor(((GetEntityHealth(ped) or 100) - 100) * 100 / mx))) or 100
                                end
                            end
                        end
                    end
                end
            end
            local key = json.encode(out)
            if key ~= shownLast then shownLast = key G.send('tags.pos', { p = out }) end
        end
    end
end)
