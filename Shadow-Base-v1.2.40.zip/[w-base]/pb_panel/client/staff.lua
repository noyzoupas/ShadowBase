-- Menu staff (F10) : le serveur envoie la liste des actions autorisées, ce fichier en fait un menu « RageUI » et exécute les effets
-- (téléportation, noclip, véhicules…) que le serveur a autorisés. Rien n'est décidé ici : une action refusée par le serveur ne produit aucun effet.
local G = PBG
local spec = nil
local dutyOn, graceUntil, godApplied = false, 0, false   -- invincibilité du staff (voir refreshGod)
local self = {}                     -- outils actifs (noclip, god, invisible, names, speed)
local spectating = false

-- le serveur ignore deux actions à moins de 250 ms : on espace les envois au lieu de les perdre (sinon une case cochée revenait en arrière)
local nextSend = 0
local function send(id, payload)
    local now = GetGameTimer()
    local at = math.max(now, nextSend)
    nextSend = at + 300
    if at == now then TriggerServerEvent('pb:g:staff:act', id, payload or {})
    else SetTimeout(at - now, function() TriggerServerEvent('pb:g:staff:act', id, payload or {}) end) end
end
local function note(t, text) G.send('notify', { type = t, title = 'Menu staff', text = text }) end

local PL = {
    info = { 'Informations', "Argent, métier, ping et nombre de sanctions.", 'search' },
    history = { 'Historique des sanctions', 'Les dernières sanctions de ce joueur.', 'history' },
    ['goto'] = { 'Aller vers lui', 'Te téléporte à côté de lui.', 'gps' },
    bring = { 'Le ramener', 'Le téléporte à toi.', 'gps' },
    heal = { 'Soigner / réanimer', 'Remet la santé, la faim, la soif et le stress.', 'heart' },
    revive = { 'Réanimer', 'Relève la personne à terre.', 'heart' },
    freeze = { 'Geler / libérer', "Bloque ou libère ses déplacements.", 'lock' },
    spectate = { 'Observer', 'Voir son écran. Relance pour arrêter.', 'eye' },
    message = { 'Envoyer un message', 'Notification visible par lui seul.', 'chat' },
    whisper = { 'Chuchoter', 'Parle à lui seul, sans casser la scène RP.', 'chat' },
    cash = { 'Espèces', 'Donner (montant positif) ou retirer (négatif).', 'wallet' },
    bank = { 'Banque', 'Donner (montant positif) ou retirer (négatif).', 'card' },
    item = { 'Donner un objet', 'Nom technique de l\'objet et quantité.', 'bag' },
    job = { 'Entreprise (emploi 1)', "Choisis une catégorie, l'entreprise, puis le grade.", 'building' },
    job2 = { 'Deuxième emploi', "Même chose pour son second emploi.", 'building' },
    gang = { 'Gang', 'Choisis le gang puis le grade.', 'users' },
    setrank = { 'Grade staff', 'Donne ou retire un grade du staff.', 'shield' },
    warn = { 'Avertir', "Enregistré dans son casier et affiché à l'écran.", 'alert' },
    kick = { 'Expulser', 'Le déconnecte avec le motif.', 'x' },
    ban = { 'Bannir', 'Choisis une durée puis le motif.', 'shield' },
    mute = { 'Réduire au silence', "Bloque son chat. Relance pour lever la sanction.", 'chat' },
    note = { 'Ajouter une note', 'Note privée, visible par le staff seulement.', 'file' },
    notes = { 'Lire les notes', 'Les dernières notes du staff sur ce joueur.', 'file' },
    inv_view = { "Voir l'inventaire", 'Résumé de ses objets.', 'bag' },
    inv_clear = { "Vider l'inventaire", 'Supprime tous ses objets (irréversible).', 'x' },
    jail = { 'Envoyer en prison', 'Minutes puis motif.', 'lock' },
    unjail = { 'Libérer de prison', 'Met fin à sa peine (prison ou TIG) et le ramène à la sortie.', 'check' },
    vip_give = { 'Donner le VIP', 'Durée en jours (0 = permanent). Prolonge un VIP en cours.', 'crown' },
    vip_remove = { 'Retirer le VIP', 'Il perd ses avantages VIP tout de suite.', 'x' },
    give_vehicle = { 'Donner un véhicule', 'Ajoute un véhicule à son garage.', 'engine' },
    feed = { 'Nourrir', 'Faim et soif au maximum, stress à zéro.', 'food' },
    armor = { 'Donner un gilet', 'Gilet pare-balles au maximum.', 'shield' },
    weapon = { 'Donner une arme', 'Liste des armes, puis le nombre de munitions. Elle arrive dans son inventaire.', 'crosshair' },
    strip = { 'Retirer les armes', 'Lui retire toutes ses armes.', 'x' },
    slap = { 'Projeter en l\'air', 'Une petite claque pour attirer son attention.', 'bolt' },
    kill = { 'Mettre à terre', 'Le met à terre (il peut être réanimé).', 'alert' },
    leave_veh = { 'Sortir du véhicule', 'Le fait descendre de force.', 'engine' },
}

local function askAll(inputs, payload)
    for _, inp in ipairs(inputs or {}) do
        local v = G.Menu.Ask(inp.label, '', inp.maxlen or 60)
        if (v == nil or v == '') and not inp.optional then return false end
        payload[inp.k] = inp.number and tonumber(v) or v
    end
    return true
end


local function bizPicker(pl, actionId, withNone)
    local byCat, cats = {}, {}
    for _, b in ipairs(spec.bizlist or {}) do byCat[b.cat] = byCat[b.cat] or {} table.insert(byCat[b.cat], b) end
    for _, c in ipairs(spec.bizcats or {}) do
        local list = byCat[c.id]
        if list and #list > 0 then
            local sub = {}
            for _, b in ipairs(list) do
                local gs = {}
                for _, g in ipairs(b.grades or {}) do
                    gs[#gs + 1] = { label = g[2], right = 'Grade ' .. g[1], onSelect = function() send(actionId, { id = pl.id, biz = b.id, grade = g[1] }) end }
                end
                sub[#sub + 1] = { type = 'submenu', label = b.label, submenu = { id = 'staff.' .. actionId .. '.' .. pl.id .. '.' .. b.id, title = b.label, subtitle = 'Choisis le grade', items = gs } }
            end
            cats[#cats + 1] = { type = 'submenu', label = c.label, badge = tostring(#list), submenu = { id = 'staff.' .. actionId .. '.' .. pl.id .. '.c.' .. c.id, title = c.label, subtitle = 'Choisis l\'entreprise', items = sub } }
        end
    end
    if withNone ~= false then table.insert(cats, 1, { label = 'Aucun (retirer)', icon = 'x', onSelect = function() send(actionId, { id = pl.id, biz = 'none' }) end }) end
    if #cats == 0 then cats[1] = { label = 'Aucune entreprise', description = 'Crée-en dans le panel › Entreprises.', disabled = true } end
    return { id = 'staff.' .. actionId .. '.' .. pl.id, title = 'Entreprise', subtitle = pl.name, items = cats }
end
local function gangPicker(pl)
    local items = { { label = 'Aucun (quitter son gang)', icon = 'x', onSelect = function() send('gang', { id = pl.id, gang = 'none' }) end } }
    for _, g in ipairs(spec.ganglist or {}) do
        local gs = {}
        for i, name in ipairs(spec.gangGrades or {}) do gs[#gs + 1] = { label = name, right = 'Grade ' .. i, onSelect = function() send('gang', { id = pl.id, gang = g[1], grade = i }) end } end
        items[#items + 1] = { type = 'submenu', label = g[2], submenu = { id = 'staff.gang.' .. pl.id .. '.' .. g[1], title = g[2], subtitle = 'Choisis le grade', items = gs } }
    end
    if #items == 1 then items[2] = { label = 'Aucun gang défini', description = 'Crée-en dans le panel › Gangs.', disabled = true } end
    return { id = 'staff.gang.' .. pl.id, title = 'Gang', subtitle = pl.name, items = items }
end
local function rankPicker(pl)
    local items = { { label = 'Aucun grade (retirer)', icon = 'x', onSelect = function() send('setrank', { id = pl.id, grade = 'none' }) end } }
    for _, g in ipairs(spec.gradeList or {}) do items[#items + 1] = { label = g.label, right = g.name, onSelect = function() send('setrank', { id = pl.id, grade = g.name }) end } end
    return { id = 'staff.rank.' .. pl.id, title = 'Grade staff', subtitle = pl.name, items = items }
end
local function weaponPicker(pl)
    local byCat, order = {}, {}
    for _, w in ipairs(spec.weapons or {}) do
        if not byCat[w[3]] then byCat[w[3]] = {} order[#order + 1] = w[3] end
        table.insert(byCat[w[3]], { label = w[2], right = w[4] ~= '' and 'munitions' or nil, onSelect = function()
            local n = 0
            if w[4] ~= '' then
                local v = G.Menu.Ask('Munitions à donner (0 = aucune)', '', 5)
                if v == nil then return end
                n = tonumber(v) or 0
            end
            send('weapon', { id = pl.id, name = w[1], ammo = n })
        end })
    end
    local items = {}
    for _, c in ipairs(order) do items[#items + 1] = { type = 'submenu', label = c, badge = tostring(#byCat[c]), submenu = { id = 'staff.w.' .. pl.id .. '.' .. c, title = c, subtitle = pl.name, items = byCat[c] } } end
    if #items == 0 then items[1] = { label = 'Aucune arme', disabled = true } end
    return { id = 'staff.w.' .. pl.id, title = 'Donner une arme', subtitle = pl.name, items = items }
end
local PICK = { job = function(pl) return bizPicker(pl, 'job') end, job2 = function(pl) return bizPicker(pl, 'job2') end, gang = gangPicker, setrank = rankPicker, weapon = weaponPicker }

local function playerMenu(pl)
    local items = {}
    for _, a in ipairs(spec.pactions or {}) do
        if not ((a.id == 'jail' and pl.jailed) or (a.id == 'unjail' and not pl.jailed) or (a.id == 'vip_remove' and not pl.vip)) then
            local meta = PL[a.id] or { a.id, '', 'star' }
            local locked = a.rank and not pl.rank
            local it = { label = meta[1], description = locked and 'Ce joueur a un rang égal ou supérieur au tien.' or meta[2], icon = meta[3], disabled = locked or nil }
            if a.pickBan then
                local sub = {}
                for _, d in ipairs(spec.bans_presets or {}) do
                    sub[#sub + 1] = { label = d[1], onSelect = function()
                        local reason = G.Menu.Ask('Motif du bannissement', '', 120)
                        if reason and reason ~= '' then send('ban', { id = pl.id, duration = d[1], reason = reason }) end
                    end }
                end
                if #sub == 0 then sub[1] = { label = 'Aucune durée configurée', disabled = true } end
                it.type, it.submenu = 'submenu', { id = 'staff.ban.' .. pl.id, title = 'Durée', subtitle = pl.name, items = sub }
            elseif PICK[a.id] and not locked then
                it.type, it.submenu = 'submenu', PICK[a.id](pl)
            else
                it.onSelect = function()
                    local p = { id = pl.id }
                    if askAll(a.inputs, p) then send(a.id, p) end
                end
            end
            items[#items + 1] = it
        end
    end
    if spec.gestures and #spec.gestures > 0 then
        local themes = {}
        for _, th in ipairs(spec.gestures) do
            local sub = {}
            for _, g in ipairs(th.items or {}) do
                sub[#sub + 1] = { label = g.label, description = pl.rank and g.desc or 'Ce joueur a un rang égal ou supérieur au tien.', disabled = (not pl.rank) or nil, onSelect = function()
                    local p = { id = pl.id }
                    if askAll(g.inputs, p) then send(g.id, p) end
                end }
            end
            themes[#themes + 1] = { type = 'submenu', label = th.label, icon = 'star', badge = tostring(#sub), submenu = { id = 'staff.g.' .. th.id .. '.' .. pl.id, title = th.label, subtitle = pl.name, items = sub } }
        end
        table.insert(items, 1, { type = 'submenu', label = 'Gestes', icon = 'star', description = 'Vie, déplacement, apparence, animations, médias, troll, véhicule, écran.', submenu = { id = 'staff.gs.' .. pl.id, title = 'Gestes', subtitle = pl.name, items = themes } })
    end
    return { id = 'staff.p.' .. pl.id, title = pl.name, subtitle = ('Joueur #%d · %s ms'):format(pl.uid or pl.id, tostring(pl.ping or 0)), items = items }
end

local function catPlayers()
    local items = {}
    for _, pl in ipairs(spec.players or {}) do
        items[#items + 1] = { label = pl.name, right = '#' .. (pl.uid or pl.id), badge = pl.staff and 'STAFF' or (pl.jailed and 'PRISON') or (pl.dead and 'À TERRE' or nil), submenu = playerMenu(pl), type = 'submenu' }
    end
    if #items == 0 then items[1] = { label = 'Personne', disabled = true } end
    return items
end

local function toggle(label, desc, icon, feature)
    return { type = 'checkbox', label = label, description = desc, icon = icon, checked = (spec.self or {})[feature] == true,
        onChange = function(_, v) send('self', { feature = feature, on = v }) end }
end
local function can(id) return spec.can and spec.can[id] end

local function catSelf()
    local out = {}
    if can('self') then
        out[#out + 1] = toggle('Noclip', 'Vole à travers tout, invisible pour les joueurs (tu te vois en transparence, ton véhicule aussi). Molette : vitesse, Ctrl : ralenti, Maj : boost, E : monter, A : descendre.', 'bolt', 'noclip')
        out[#out + 1] = toggle('Mode photo', "Noclip + ton personnage invisible + toute l'interface cachée (radar, HUD, notifications) pour prendre des photos. Le menu staff reste accessible pour en sortir.", 'eye', 'photo')
        out[#out + 1] = toggle('Invincible', 'Aucun dégât.', 'shield', 'god')
        out[#out + 1] = toggle('Invisible', "Les autres ne te voient plus.", 'eye', 'invisible')
        out[#out + 1] = toggle('Noms au-dessus des têtes', "Affiche l'ID et le nom des joueurs proches.", 'users', 'names')
        out[#out + 1] = toggle('Course rapide', 'Cours plus vite.', 'bolt', 'speed')
        out[#out + 1] = toggle('Afficher mes coordonnées', 'Position et cap à l\'écran.', 'gps', 'coords')
        out[#out + 1] = toggle('Endurance infinie', 'Ne te fatigue plus en courant ou nageant.', 'bolt', 'stamina')
        out[#out + 1] = toggle('Super saut', 'Saute beaucoup plus haut.', 'bolt', 'jump')
        out[#out + 1] = toggle('Nage rapide', 'Nage plus vite.', 'bolt', 'swim')
        out[#out + 1] = toggle('Squelette des joueurs', "Dessine le squelette des joueurs proches, même à travers le ped et les murs (en noclip ou non).", 'users', 'skeleton')
        out[#out + 1] = toggle('Repères des joueurs', 'Points sur la carte pour les joueurs chargés près de toi.', 'users', 'blips')
    end
    if can('heal_me') then out[#out + 1] = { label = 'Me soigner', description = 'Santé, faim, soif et stress au maximum.', icon = 'heart', onSelect = function() send('heal_me') end } end
    if can('tp_back') then out[#out + 1] = { label = 'Retourner où j\'étais', description = 'Revient à la position avant ta dernière téléportation.', icon = 'undo', onSelect = function() send('tp_back') end } end
    if can('tp_waypoint') then out[#out + 1] = { label = 'Aller au point GPS', description = "Place un point sur la carte, puis choisis ceci.", icon = 'gps', onSelect = function() send('tp_waypoint') end } end
    if can('tp_coords') then out[#out + 1] = { label = 'Aller aux coordonnées', description = 'Saisis : x y z', icon = 'gps', onSelect = function() local v = G.Menu.Ask('Coordonnées : x y z', '', 40) if v and v ~= '' then send('tp_coords', { text = v }) end end } end
    if can('tp_player') then out[#out + 1] = { label = 'Aller vers un ID', description = "Saisis l'ID du joueur.", icon = 'users', onSelect = function() local v = G.Menu.Ask("ID du joueur", '', 6) if tonumber(v) then send('tp_player', { uid = tonumber(v) }) end end } end
    return out
end

local function catVehicles()
    local sub = {}
    for _, m in ipairs(spec.spawn or {}) do sub[#sub + 1] = { label = m[1], onSelect = function() send('veh_spawn', { model = m[1] }) end } end
    sub[#sub + 1] = { label = 'Autre modèle…', description = 'Saisis le nom du modèle (ex. adder).', onSelect = function() local v = G.Menu.Ask('Modèle du véhicule', '', 32) if v and v ~= '' then send('veh_spawn', { model = v }) end end }
    return {
        { label = 'Créer un véhicule', description = 'Le véhicule apparaît autour de toi.', icon = 'engine', type = 'submenu', submenu = { id = 'staff.spawn', title = 'Véhicules', subtitle = 'Choisis un modèle', items = sub } },
        { label = 'Réparer', description = 'Répare et nettoie ton véhicule.', icon = 'key', onSelect = function() send('veh_repair') end },
        { label = 'Remettre sur les roues', icon = 'refresh', onSelect = function() send('veh_flip') end },
        { label = 'Nettoyer', description = 'Retire la saleté de ton véhicule.', icon = 'refresh', onSelect = function() send('veh_clean') end },
        { label = 'Plein de carburant', icon = 'engine', onSelect = function() send('veh_fuel') end },
        { label = 'Performances au maximum', description = 'Moteur, freins, transmission, suspension et turbo.', icon = 'bolt', onSelect = function() send('veh_max') end },
        { label = 'Déverrouiller', description = 'Ouvre ton véhicule ou le plus proche.', icon = 'lock', onSelect = function() send('veh_unlock') end },
        { label = 'Moteur : démarrer / couper', icon = 'key', onSelect = function() send('veh_engine') end },
        { label = 'Coup de boost', description = 'Accélère d\'un coup.', icon = 'bolt', onSelect = function() send('veh_boost') end },
        { label = 'Monter dans le véhicule proche', description = 'Te place dans le véhicule le plus proche (25 m).', icon = 'engine', onSelect = function() send('veh_tpin') end },
        { label = 'Supprimer mon véhicule', description = 'Supprime le véhicule dans lequel tu es (ou le plus proche).', icon = 'x', onSelect = function() send('veh_delete') end },
        { label = 'Nettoyer les véhicules vides (50 m)', description = 'Supprime les véhicules sans conducteur autour de toi.', icon = 'x', onSelect = function() send('veh_purge') end },
    }
end

local function catServer()
    local out = {}
    if can('clear_peds') then out[#out + 1] = { label = 'Supprimer les piétons (60 m)', description = 'Retire les piétons non joueurs autour de toi.', icon = 'x', onSelect = function() send('clear_peds') end } end
    if can('announce') then
        local sub = {}
        for _, a in ipairs(spec.announce or {}) do sub[#sub + 1] = { label = a[1], description = a[2], onSelect = function() send('announce', { text = a[2] }) end } end
        sub[#sub + 1] = { label = 'Message libre…', onSelect = function() local v = G.Menu.Ask('Annonce à tous les joueurs', '', 200) if v and v ~= '' then send('announce', { text = v }) end end }
        out[#out + 1] = { label = 'Annonce', description = 'Message à tous les joueurs (chat + bandeau).', icon = 'chat', type = 'submenu', submenu = { id = 'staff.announce', title = 'Annonce', subtitle = 'À tous les joueurs', items = sub } }
    end
    if can('weather') then
        if spec.world_on then
            local sub = {}
            for _, w in ipairs(spec.weather or {}) do sub[#sub + 1] = { label = w, onSelect = function() send('weather', { value = w }) end } end
            out[#out + 1] = { label = 'Météo', icon = 'cloud', type = 'submenu', submenu = { id = 'staff.weather', title = 'Météo', subtitle = 'Pour tout le monde', items = sub } }
            local hs = { { label = 'Le temps reprend son cours', onSelect = function() send('hour', { value = 'cycle' }) end } }
            for h = 0, 23, 2 do hs[#hs + 1] = { label = ('Figer à %02d h'):format(h), onSelect = function() send('hour', { value = h }) end } end
            out[#out + 1] = { label = 'Heure', icon = 'clock', type = 'submenu', submenu = { id = 'staff.hour', title = 'Heure', subtitle = 'Pour tout le monde', items = hs } }
        else
            out[#out + 1] = { label = 'Météo et heure', right = 'Indisponible', description = "Le panel ne pilote pas le monde. Active-le dans Monde › Réglages.", icon = 'cloud', disabled = true }
        end
    end
    if can('blackout') then out[#out + 1] = { type = 'checkbox', label = 'Coupure de courant', description = 'Éteint les lumières de la ville pour tout le monde.', icon = 'bolt', checked = spec.blackout == true, onChange = function() send('blackout') end } end
    if can('heal_all') then out[#out + 1] = { label = 'Soigner tout le monde', icon = 'heart', description = 'Réanime et soigne tous les joueurs en ligne.', onSelect = function() send('heal_all') end } end
    if can('restart') then
        local sub = {}
        if spec.restart then sub[#sub + 1] = { label = 'Annuler le redémarrage', description = ('Arrêt dans %d s.'):format(spec.restart.left or 0), icon = 'x', onSelect = function() send('restart_cancel') end } end
        for _, m in ipairs({ 1, 2, 5, 10, 15, 30, 60 }) do sub[#sub + 1] = { label = ('Dans %d minute%s'):format(m, m > 1 and 's' or ''), onSelect = function() send('restart', { minutes = m }) end } end
        out[#out + 1] = { label = 'Redémarrer le serveur', right = spec.restart and 'En cours' or nil, description = 'Annonce à tous les joueurs, sauvegarde, puis arrêt.', icon = 'refresh', type = 'submenu', submenu = { id = 'staff.restart', title = 'Redémarrage', subtitle = 'Avec annonce et compte à rebours', items = sub } }
    end
    if can('maintenance') then out[#out + 1] = { type = 'checkbox', label = 'Mode maintenance', description = "Seuls les membres autorisés peuvent se connecter.", icon = 'lock', checked = spec.maint == true, onChange = function() send('maintenance') end } end
    return out
end

local function ago(s) s = tonumber(s) or 0 if s < 90 then return s .. ' s' elseif s < 5400 then return math.floor(s / 60) .. ' min' else return math.floor(s / 3600) .. ' h' end end
local function catReports()
    local items = {}
    for _, r in ipairs(spec.reports or {}) do
        local sub = {
            { label = 'Aller vers lui', icon = 'gps', onSelect = function() send('report_goto', { rid = r.id }) end },
            { label = 'Prendre en charge', icon = 'check', onSelect = function() send('report_claim', { rid = r.id }) end },
            { label = 'Clore', icon = 'x', onSelect = function() send('report_close', { rid = r.id }) end },
        }
        items[#items + 1] = { type = 'submenu', label = r.name, right = ago(r.ago), badge = r.status == 'claimed' and (r.by ~= '' and r.by or 'PRIS') or 'NOUVEAU', description = r.text,
            submenu = { id = 'staff.r.' .. r.id, title = 'Signalement #' .. r.id, subtitle = r.name, items = sub } }
    end
    if #items == 0 then items[1] = { label = 'Aucun signalement ouvert', disabled = true } end
    return items
end

local function catSanctions()
    local items = {}
    if can('ban_offline') then
        items[#items + 1] = { label = 'Bannir un joueur hors ligne', description = 'Par sa licence (6 caractères au moins).', icon = 'shield', onSelect = function()
            local p = {}
            local inputs = { { k = 'who', label = 'Licence (ou fin de licence)', maxlen = 60 }, { k = 'minutes', label = 'Durée en minutes (0 = définitif)', number = true, maxlen = 6 }, { k = 'reason', label = 'Motif', maxlen = 120 } }
            if askAll(inputs, p) then send('ban_offline', p) end
        end }
    end
    for _, j in ipairs(spec.jailed or {}) do
        local left = j.kind == 'tig' and (tostring(j.remaining) .. ' tâche(s)') or (tostring(math.ceil((j.remaining or 0) / 60)) .. ' min')
        items[#items + 1] = { type = 'submenu', label = j.name, icon = 'lock', right = (j.kind == 'tig' and 'TIG · ' or 'Prison · ') .. left, description = (j.online and ('#' .. (G.UidOf(j.online) or j.online) .. ' · ') or 'Hors ligne · ') .. (j.reason or ''),
            submenu = { id = 'staff.j.' .. j.license, title = j.name, subtitle = 'Détenu', items = { { label = 'Libérer de prison', icon = 'check', description = 'Met fin à sa peine' .. (j.online and ' et le ramène à la sortie.' or ' (il sera libre à sa prochaine connexion).'), onSelect = function() send('unjail_license', { license = j.license }) end } } } }
    end
    for _, b in ipairs(spec.bans or {}) do
        items[#items + 1] = { type = 'submenu', label = b.name, right = (b.expires or 0) == 0 and 'Définitif' or os.date('%d/%m %H:%M', b.expires), description = b.reason,
            submenu = { id = 'staff.b.' .. b.id, title = b.name, subtitle = 'Bannissement', items = { { label = 'Lever le bannissement', icon = 'check', description = 'Autorise à nouveau la connexion.', onSelect = function() send('unban', { sid = b.id }) end } } } }
    end
    if #items == 0 then items[1] = { label = 'Aucun bannissement ni détenu', disabled = true } end
    return items
end

local BUILD = { players = catPlayers, self = catSelf, vehicles = catVehicles, server = catServer, reports = catReports, sanctions = catSanctions,
    builder = function() return G.BuilderItems and G.BuilderItems(spec, send) or {} end,
    props = function() return G.PropsItems and G.PropsItems() or {} end }

local function mainItems()
    local hidden = {}
    for _, id in ipairs(spec.hide or {}) do hidden[id] = true end
    if dutyOn ~= (spec.duty == true) then dutyOn = spec.duty == true end
    local items = { { type = 'separator', label = spec.grade .. (spec.duty and ' · en service' or ' · hors service') },
        { id = 'duty', type = 'checkbox', label = 'Prendre mon service', description = spec.require_duty and 'Obligatoire pour utiliser les outils.' or 'Optionnel : visible par les autres staff.', icon = 'bolt', checked = spec.duty == true,
          onChange = function(_, v) send('duty', { on = v }) end } }
    if can('search') then
        items[#items + 1] = { id = 'search', label = 'Rechercher', icon = 'search', description = 'Un joueur (nom, prénom, ID, licence), un véhicule (plaque) ou un numéro de téléphone.', onSelect = function()
            local q = G.Menu.Ask('Nom, ID, plaque ou numéro', '', 48)
            if q and q ~= '' then send('search', { q = q }) end
        end }
    end
    if spec.dutycfg then
        local dc = spec.dutycfg
        items[#items + 1] = { type = 'submenu', label = 'Réglages du service', icon = 'sliders', description = 'Ped de service par grade et blocage des accès joueur.', submenu = { id = 'staff.dutycfg', title = 'Service', subtitle = 'Réglages', refreshOnReturn = true, build = function()
            dc = spec.dutycfg or dc   -- valeurs à jour à chaque reconstruction (pas celles de l'ouverture du menu)
            local sub = {
                { type = 'checkbox', label = 'Ped de service', description = 'En service, chaque grade prend son ped ; il retrouve son personnage en quittant.', checked = dc.ped == true, onChange = function(_, v) send('duty_cfg', { key = 'ped', on = v }) end },
                { type = 'checkbox', label = 'Bloquer les accès joueur en service', description = 'Inventaire, métier, téléphone, banque… coupés ; les outils staff restent ouverts.', checked = dc.block == true, onChange = function(_, v) send('duty_cfg', { key = 'block', on = v }) end },
            }
            for _, g in ipairs(spec.gradeList or {}) do
                sub[#sub + 1] = { label = 'Ped : ' .. g.label, right = (dc.peds or {})[g.name] or '—', description = 'Modèle du ped de service de ce grade (vide = aucun).', onSelect = function()
                    local v = G.Menu.Ask('Modèle de ped pour ' .. g.label .. ' (vide = aucun)', (dc.peds or {})[g.name] or '', 40)
                    if v ~= nil then send('duty_cfg', { key = 'grade_ped', grade = g.name, model = v }) end
                end }
            end
            return sub
        end } }
    end
    for _, c in ipairs(spec.cats or {}) do
        if not hidden[c.id] or c.id == 'panel' then
            if c.id == 'panel' then
                items[#items + 1] = { id = 'panel', label = c.label, icon = c.icon, description = 'Ouvre le panel de configuration du serveur.', onSelect = function() send('panel') end }
            elseif BUILD[c.id] then
                items[#items + 1] = { id = c.id, type = 'submenu', label = c.label, icon = c.icon, badge = (c.count and c.count > 0) and tostring(c.count) or nil,
                    submenu = { id = 'staff.' .. c.id, title = c.label, subtitle = spec.grade, refreshOnReturn = true, build = BUILD[c.id] } }
            end
        end
    end
    return items
end

local def = { id = 'staff', title = 'Menu staff', refreshOnReturn = true, banner = { text = 'Menu admin' } }
def.build = function()
    local items = G.Menu.Sorted('staff', mainItems(), spec.order)
    items[#items + 1] = G.Menu.OrderEntry('staff', mainItems, spec.order)
    return items
end

RegisterNetEvent('pb:g:staff:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    if not d.spec then if G.Menu.IsOpen() then G.Menu.Close() end return end
    spec = d.spec
    if d.ev == 'open' then
        def.subtitle = spec.grade
        def.banner = { text = 'Menu admin' }
        local f = spec.focus
        if f and f.k == 'reports' and can('report_claim') then
            G.Menu.Open({ id = 'staff.reports', title = 'Gestion des reports', subtitle = spec.grade, refreshOnReturn = true, banner = { text = 'Menu admin' }, build = catReports })
        elseif f and f.k == 'player' then
            for _, pl in ipairs(spec.players or {}) do if pl.id == f.id then G.Menu.Open(playerMenu(pl)) return end end
            G.Menu.Open(def)
        else G.Menu.Open(def) end
    elseif G.Menu.IsOpen() then
        G.Menu.Refresh()
    end
end)

RegisterNetEvent('pb:g:staff:panel', function()
    G.Menu.Close()
    Wait(100)
    ExecuteCommand(GetConvar('pb_panel_cmd', 'panel'))
end)

-- Effets autorisés par le serveur ----------------------------------------------------------------------------------------------------------
local function groundZ(x, y, z)
    for h = 1000, -100, -50 do
        local ok, gz = GetGroundZFor_3dCoord(x + 0.0, y + 0.0, h + 0.0, false)
        if ok and math.abs(gz - z) < 400 then return gz end
    end
    return z
end
local backPos = nil
local function teleport(c)
    local ped = PlayerPedId()
    local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
    local from = GetEntityCoords(ent)
    if not c.back then backPos = { x = from.x, y = from.y, z = from.z } end
    RequestCollisionAtCoord(c.x + 0.0, c.y + 0.0, c.z + 0.0)
    local t = GetGameTimer() + 1500
    while not HasCollisionLoadedAroundEntity(ent) and GetGameTimer() < t do Wait(0) end
    SetEntityCoordsNoOffset(ent, c.x + 0.0, c.y + 0.0, c.z + 0.5, false, false, false)
end

-- Invincibilité du staff : en service, en noclip ou avec « Invincible » actif, aucun dégât (chute, balles, explosion, feu…).
-- Elle est réaffirmée en boucle (un changement de ped ou un respawn la remet à zéro) et prolongée 4 s après la sortie du noclip.
local function wantGod() return (dutyOn and G.cfg.staff and G.cfg.staff.duty_god == true) or self.god == true or self.noclip == true or GetGameTimer() < graceUntil end
local function refreshGod()
    local ped, want = PlayerPedId(), wantGod()
    if want then
        SetPlayerInvincible(PlayerId(), true) SetEntityInvincible(ped, true)
        SetEntityProofs(ped, true, true, true, true, true, true, true, true)
        godApplied = true
    elseif godApplied then
        SetPlayerInvincible(PlayerId(), false) SetEntityInvincible(ped, false)
        SetEntityProofs(ped, false, false, false, false, false, false, false, false)
        godApplied = false
    end
end
CreateThread(function()
    while true do
        Wait(250)
        refreshGod()
    end
end)

-- Pose le ped (ou le véhicule) sur le sol sous lui, sans dégât, à la sortie du noclip.
local function landOnGround(ent)
    local p = GetEntityCoords(ent)
    RequestCollisionAtCoord(p.x, p.y, p.z)
    local t = GetGameTimer() + 1500
    while not HasCollisionLoadedAroundEntity(ent) and GetGameTimer() < t do Wait(0) end
    local gz
    for _, dz in ipairs({ 2.0, 40.0, 300.0 }) do
        local ok, z = GetGroundZFor_3dCoord(p.x + 0.0, p.y + 0.0, p.z + dz, false)
        if ok and z <= p.z + dz then gz = z break end
    end
    if gz and p.z - gz > 0.8 then
        SetEntityCoordsNoOffset(ent, p.x, p.y, gz + (IsEntityAPed(ent) and 1.0 or 0.6), false, false, false)
    end
    SetEntityVelocity(ent, 0.0, 0.0, 0.0)
end

local function noclipLoop()
    CreateThread(function()
        local ped = PlayerPedId()
        local touched = {}     -- tout ce qu'on a gelé : rendu en sortie, même si on est descendu du véhicule en cours de route
        local function release(e)
            if e and e ~= 0 and DoesEntityExist(e) then SetEntityCollision(e, true, true) FreezeEntityPosition(e, false) end
        end
        local lastEnt
        -- fantôme : invisible pour les autres joueurs (réseau), visible pour soi en transparence ; pareil pour le véhicule
        local ghosted = {}
        local function ghost(e)
            if not e or e == 0 or not DoesEntityExist(e) then return end
            if not ghosted[e] then ghosted[e] = true NetworkSetEntityInvisibleToNetwork(e, true) end
            SetEntityAlpha(e, 120, false)
        end
        local function unghost(e)
            if e and e ~= 0 and DoesEntityExist(e) then ResetEntityAlpha(e) NetworkSetEntityInvisibleToNetwork(e, false) end
            ghosted[e] = nil
        end
        local base = 0.6                       -- vitesse de base ; la molette la règle de 0,1 à 5
        local function showHints()
            if G and G.send then G.send('hints', { items = { { k = 'CTRL', t = 'Ralenti' }, { k = 'SHIFT', t = 'Boost' }, { k = 'mouse', t = ('Vitesse %.1f'):format(base) }, { k = 'A · E · Q', t = 'Monter · descendre' } } }) end
        end
        showHints()
        while self.noclip do
            Wait(0)
            DisableControlAction(0, 14, true) DisableControlAction(0, 15, true) DisableControlAction(0, 16, true) DisableControlAction(0, 17, true)
            if IsDisabledControlJustPressed(0, 15) or IsDisabledControlJustPressed(0, 17) then base = math.min(5.0, base + 0.1) showHints()
            elseif IsDisabledControlJustPressed(0, 14) or IsDisabledControlJustPressed(0, 16) then base = math.max(0.1, base - 0.1) showHints() end
            ped = PlayerPedId()
            local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
            if lastEnt and lastEnt ~= ent then
                -- on est monté / descendu : l'ancienne entité est libérée tout de suite (sinon le véhicule reste figé et le ped bloqué)
                release(lastEnt)
                if lastEnt ~= ped then unghost(lastEnt) landOnGround(lastEnt) end
            end
            lastEnt = ent
            ghost(ent)
            if ent ~= ped then ghost(ped) end
            touched[ent] = true
            SetEntityCollision(ent, false, false)
            FreezeEntityPosition(ent, true)
            local rot = GetGameplayCamRot(2)
            local rz, rx = math.rad(rot.z), math.rad(rot.x)
            local fwd = { x = -math.sin(rz) * math.cos(rx), y = math.cos(rz) * math.cos(rx), z = math.sin(rx) }
            local right = { x = math.cos(rz), y = math.sin(rz) }
            local speed = IsControlPressed(0, 21) and base * 4.0 or (IsControlPressed(0, 36) and base * 0.25 or base)
            local p = GetEntityCoords(ent)
            local x, y, z = p.x, p.y, p.z
            if IsControlPressed(0, 32) then x, y, z = x + fwd.x * speed, y + fwd.y * speed, z + fwd.z * speed end
            if IsControlPressed(0, 33) then x, y, z = x - fwd.x * speed, y - fwd.y * speed, z - fwd.z * speed end
            if IsControlPressed(0, 34) then x, y = x - right.x * speed, y - right.y * speed end
            if IsControlPressed(0, 35) then x, y = x + right.x * speed, y + right.y * speed end
            if IsControlPressed(0, 38) then z = z + speed end
            if IsControlPressed(0, 44) then z = z - speed end
            SetEntityCoordsNoOffset(ent, x, y, z, true, true, true)
            SetEntityHeading(ent, rot.z)
        end
        if G and G.send then G.send('hints', { items = {} }) end
        local ent = IsPedInAnyVehicle(PlayerPedId(), false) and GetVehiclePedIsIn(PlayerPedId(), false) or PlayerPedId()
        graceUntil = GetGameTimer() + 4000
        refreshGod()
        for e in pairs(touched) do release(e) end
        release(PlayerPedId())
        for e in pairs(ghosted) do unghost(e) end
        if self.invisible or self.photo then SetEntityVisible(PlayerPedId(), false, false) end
        landOnGround(ent)
    end)
end

local function namesLoop()
    CreateThread(function()
        while self.names do
            Wait(0)
            local me = PlayerPedId()
            local mp = GetEntityCoords(me)
            for _, pid in ipairs(GetActivePlayers()) do
                local ped = GetPlayerPed(pid)
                if ped ~= me and DoesEntityExist(ped) then
                    local c = GetEntityCoords(ped)
                    if #(c - mp) < 60.0 then
                        local on, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z + 1.05)
                        if on then
                            SetTextScale(0.0, 0.32) SetTextFont(4) SetTextCentre(true) SetTextOutline()
                            SetTextEntry('STRING') AddTextComponentString(('[%d] %s'):format(GetPlayerServerId(pid), GetPlayerName(pid))) DrawText(sx, sy)
                        end
                    end
                end
            end
        end
    end)
end

-- Squelette : traits entre les os, visibles à travers le ped et les décors (DrawLine ignore la profondeur).
local BONES = { { 31086, 39317 }, { 39317, 24818 }, { 24818, 11816 }, { 24818, 40269 }, { 24818, 45509 }, { 40269, 28252 }, { 28252, 57005 }, { 45509, 61163 }, { 61163, 18905 },
    { 11816, 58271 }, { 58271, 63931 }, { 63931, 14201 }, { 11816, 51826 }, { 51826, 36864 }, { 36864, 52301 } }
local function skeletonLoop()
    CreateThread(function()
        while self.skeleton do
            Wait(0)
            local me = PlayerPedId()
            local mp = GetEntityCoords(me)
            for _, pid in ipairs(GetActivePlayers()) do
                local ped = GetPlayerPed(pid)
                if ped ~= me and DoesEntityExist(ped) and #(GetEntityCoords(ped) - mp) < 120.0 then
                    for _, b in ipairs(BONES) do
                        local a, c = GetPedBoneCoords(ped, b[1], 0.0, 0.0, 0.0), GetPedBoneCoords(ped, b[2], 0.0, 0.0, 0.0)
                        DrawLine(a.x, a.y, a.z, c.x, c.y, c.z, 255, 255, 255, 255)
                    end
                end
            end
        end
    end)
end

local blipOf = {}
local function clearBlips() for _, b in pairs(blipOf) do if DoesBlipExist(b) then RemoveBlip(b) end end blipOf = {} end
local function coordsLoop()
    CreateThread(function()
        while self.coords do
            Wait(0)
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            SetTextScale(0.0, 0.34) SetTextFont(4) SetTextOutline() SetTextEntry('STRING')
            AddTextComponentString(('%.2f  %.2f  %.2f  ·  cap %.1f'):format(c.x, c.y, c.z, GetEntityHeading(ped)))
            DrawText(0.5, 0.012)
        end
    end)
end
local function blipsLoop()
    CreateThread(function()
        while self.blips do
            local seen = {}
            for _, pid in ipairs(GetActivePlayers()) do
                if pid ~= PlayerId() then
                    local ped = GetPlayerPed(pid)
                    if DoesEntityExist(ped) then
                        seen[pid] = true
                        if blipOf[pid] and DoesBlipExist(blipOf[pid]) and GetBlipInfoIdEntityIndex(blipOf[pid]) ~= ped then RemoveBlip(blipOf[pid]) blipOf[pid] = nil end   -- nouveau personnage (réapparition, tenue) : l'ancien repère restait figé
                        if not blipOf[pid] or not DoesBlipExist(blipOf[pid]) then
                            local b = AddBlipForEntity(ped)
                            SetBlipSprite(b, 1) SetBlipScale(b, 0.8) SetBlipColour(b, 0) SetBlipCategory(b, 7)
                            BeginTextCommandSetBlipName('STRING') AddTextComponentString(('[%d] %s'):format(GetPlayerServerId(pid), GetPlayerName(pid))) EndTextCommandSetBlipName(b)
                            blipOf[pid] = b
                        end
                    end
                end
            end
            for pid, b in pairs(blipOf) do if not seen[pid] then if DoesBlipExist(b) then RemoveBlip(b) end blipOf[pid] = nil end end
            Wait(1000)
        end
        clearBlips()
    end)
end

-- Mode photo : noclip + personnage invisible + interface cachée (le menu staff reste visible pour en sortir)
local photoNoclip = false
local function photoLoop()
    CreateThread(function()
        G.send('photo', { on = true })
        while self.photo do
            HideHudAndRadarThisFrame()
            DisplayRadar(false)
            SetEntityVisible(PlayerPedId(), false, false)
            Wait(0)
        end
        DisplayRadar(true)
        G.send('photo', { on = false })
        if not self.invisible then SetEntityVisible(PlayerPedId(), true, false) end
    end)
end

local function applySelf(feature, on)
    self[feature] = on or nil
    local ped = PlayerPedId()
    if feature == 'photo' then
        if on then
            photoNoclip = not self.noclip
            if photoNoclip then self.noclip = true refreshGod() noclipLoop() end
            photoLoop()
        else
            if photoNoclip then self.noclip = nil photoNoclip = false end
        end
    elseif feature == 'noclip' then if on then refreshGod() noclipLoop() end
    elseif feature == 'god' then refreshGod()
    elseif feature == 'invisible' then SetEntityVisible(ped, not on, false)
    elseif feature == 'names' then if on then namesLoop() end
    elseif feature == 'coords' then if on then coordsLoop() end
    elseif feature == 'blips' then if on then blipsLoop() end
    elseif feature == 'skeleton' then if on then skeletonLoop() end
    elseif feature == 'speed' then SetRunSprintMultiplierForPlayer(PlayerId(), on and 1.49 or 1.0) SetPedMoveRateOverride(ped, on and 1.4 or 1.0)
    elseif feature == 'swim' then SetSwimMultiplierForPlayer(PlayerId(), on and 1.49 or 1.0)
    elseif feature == 'stamina' or feature == 'jump' then
        if on then CreateThread(function()
            while self[feature] do
                if feature == 'stamina' then RestorePlayerStamina(PlayerId(), 1.0)
                elseif feature == 'jump' then SetSuperJumpThisFrame(PlayerId())
                end
                Wait(feature == 'jump' and 0 or 250)
            end
        end) end
    end
end

local function vehicleFx(d)
    local ped = PlayerPedId()
    local veh = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or 0
    if d.op == 'spawn' then
        local hash = GetHashKey(tostring(d.model))
        if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then note('error', 'Modèle de véhicule inconnu : ' .. tostring(d.model)) return end
        RequestModel(hash)
        local t = GetGameTimer() + 4000
        while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(0) end
        if not HasModelLoaded(hash) then note('error', 'Chargement du modèle impossible.') return end
        if veh ~= 0 then SetEntityAsMissionEntity(veh, true, true) DeleteVehicle(veh) end
        local c = GetEntityCoords(ped)
        local v = CreateVehicle(hash, c.x, c.y, c.z + 0.3, GetEntityHeading(ped), true, false)
        SetPedIntoVehicle(ped, v, -1)
        SetVehicleNumberPlateText(v, 'STAFF')
        SetModelAsNoLongerNeeded(hash)
    elseif d.op == 'repair' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleDirtLevel(veh, 0.0) SetVehicleEngineHealth(veh, 1000.0)
    elseif d.op == 'flip' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleOnGroundProperly(veh)
    elseif d.op == 'delete' then
        if veh == 0 then
            local c = GetEntityCoords(ped)
            veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71)
        end
        if veh ~= 0 and DoesEntityExist(veh) then SetEntityAsMissionEntity(veh, true, true) DeleteVehicle(veh) else note('warn', 'Aucun véhicule à proximité.') end
    elseif d.op == 'purge' then
        local c = GetEntityCoords(ped)
        local n = 0
        for _, v in ipairs(GetGamePool('CVehicle')) do
            if v ~= veh and #(GetEntityCoords(v) - c) < 50.0 and GetPedInVehicleSeat(v, -1) == 0 and GetVehicleNumberOfPassengers(v) == 0 then
                SetEntityAsMissionEntity(v, true, true) DeleteVehicle(v) n = n + 1
            end
        end
        note('success', n .. ' véhicule(s) vide(s) supprimé(s).')
    elseif d.op == 'clean' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleDirtLevel(veh, 0.0) WashDecalsFromVehicle(veh, 1.0)
    elseif d.op == 'fuel' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleFuelLevel(veh, 100.0)
    elseif d.op == 'max' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleModKit(veh, 0)
        for _, m in ipairs({ 11, 12, 13, 15, 16 }) do SetVehicleMod(veh, m, GetNumVehicleMods(veh, m) - 1, false) end
        ToggleVehicleMod(veh, 18, true)
    elseif d.op == 'unlock' then
        local v = veh
        if v == 0 then local c = GetEntityCoords(ped) v = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
        if v ~= 0 and DoesEntityExist(v) then SetVehicleDoorsLocked(v, 1) SetVehicleDoorsLockedForAllPlayers(v, false) else note('warn', 'Aucun véhicule à proximité.') end
    elseif d.op == 'boost' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleForwardSpeed(veh, math.min(80.0, GetEntitySpeed(veh) + 25.0))
    elseif d.op == 'tpin' then
        local c = GetEntityCoords(ped)
        local v = GetClosestVehicle(c.x, c.y, c.z, 25.0, 0, 71)
        if v ~= 0 and DoesEntityExist(v) then
            for seat = -1, GetVehicleModelNumberOfSeats(GetEntityModel(v)) - 2 do if IsVehicleSeatFree(v, seat) then SetPedIntoVehicle(ped, v, seat) return end end
            note('warn', 'Aucune place libre.')
        else note('warn', 'Aucun véhicule à moins de 25 m.') end
    elseif d.op == 'engine' then
        if veh == 0 then note('warn', 'Monte dans un véhicule.') return end
        SetVehicleEngineOn(veh, not GetIsVehicleEngineRunning(veh), true, true)
    end
end

RegisterNetEvent('pb:g:staff:fx', function(kind, j)
    local d = G.decode(j) or {}
    local ped = PlayerPedId()
    if kind == 'tp' and type(d.x) == 'number' then teleport(d)
    elseif kind == 'tpback' then
        if not backPos then note('warn', "Aucune position précédente.") return end
        local c = { x = backPos.x, y = backPos.y, z = backPos.z, back = true }
        teleport(c)
        backPos = nil
    elseif kind == 'blackout' then
        SetArtificialLightsState(d.on == true) SetArtificialLightsStateAffectsVehicles(false)
    elseif kind == 'tpwp' then
        local blip = GetFirstBlipInfoId(8)
        if not DoesBlipExist(blip) then note('warn', "Pas de point GPS sur la carte.") return end
        local c = GetBlipInfoIdCoord(blip)
        teleport({ x = c.x, y = c.y, z = groundZ(c.x, c.y, 100.0) })
    elseif kind == 'heal' then
        SetEntityHealth(ped, GetEntityMaxHealth(ped)) ClearPedBloodDamage(ped) SetPedArmour(ped, 0)
    elseif kind == 'freeze' then
        local ent = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
        FreezeEntityPosition(ent, d.on == true)
    elseif kind == 'spectate' then
        if d.on and d.target then
            CreateThread(function() G.SpectateStart(d) end)
        else
            G.SpectateStop()
        end
    elseif kind == 'self' and type(d.feature) == 'string' then applySelf(d.feature, d.on == true)
    elseif kind == 'dutystate' then dutyOn = d.on == true refreshGod()
    elseif kind == 'follow' then
        G.send('staff.follow', { id = d.id, name = d.name })
    elseif kind == 'dutyped' then
        if d.on and type(d.model) == 'string' then
            local h = GetHashKey(d.model)
            if not IsModelInCdimage(h) or not IsModelAPed(h) then note('error', 'Ped de service inconnu : ' .. d.model) return end
            RequestModel(h)
            local t = GetGameTimer() + 4000
            while not HasModelLoaded(h) and GetGameTimer() < t do Wait(0) end
            if HasModelLoaded(h) then SetPlayerModel(PlayerId(), h) SetModelAsNoLongerNeeded(h) SetPedDefaultComponentVariation(PlayerPedId()) end
        elseif G.appearance and G.applyAppearance then
            G.applyAppearance(G.appearance, true)
        end
    elseif kind == 'kill' then SetEntityHealth(ped, 0)
    elseif kind == 'slap' then
        if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 4160) Wait(400) end
        SetPedToRagdoll(PlayerPedId(), 1500, 1500, 0, false, false, false) ApplyForceToEntity(PlayerPedId(), 1, 0.0, 0.0, 9.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
    elseif kind == 'armor' then SetPedArmour(ped, 100)
    elseif kind == 'leaveveh' then if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16) end
    elseif kind == 'strip' then RemoveAllPedWeapons(ped, true)
    elseif kind == 'weapon' and type(d.name) == 'string' then
        local hash = GetHashKey(d.name)
        if IsWeaponValid(hash) then GiveWeaponToPed(ped, hash, math.floor(tonumber(d.ammo) or 0), false, false) else note('error', 'Arme inconnue : ' .. d.name) end
    elseif kind == 'clearpeds' then
        local c, n = GetEntityCoords(ped), 0
        for _, p in ipairs(GetGamePool('CPed')) do
            if not IsPedAPlayer(p) and #(GetEntityCoords(p) - c) < 60.0 then SetEntityAsMissionEntity(p, true, true) DeletePed(p) n = n + 1 end
        end
        note('success', n .. ' piéton(s) supprimé(s).')
    elseif kind == 'veh' then vehicleFx(d) end
end)

G.nui['staff.follow.open'] = function() TriggerServerEvent('pb:g:staff:open', 'follow') return {} end
G.nui['staff.notif.click'] = function(d) if d.k == 'reports' then TriggerServerEvent('pb:g:staff:open', 'reports') end return {} end

RegisterCommand('pb_staff', function()
    if not G.begun or G.creating or G.wardrobe then return end
    if G.Menu.IsOpen() then G.Menu.Close() return end
    TriggerServerEvent('pb:g:staff:open')
end, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.staff and GetGameTimer() < t do Wait(250) end
    RegisterKeyMapping('pb_staff', 'Menu staff', 'keyboard', (G.cfg.staff and G.cfg.staff.key) or 'F10')
end)
-- Raccourcis clavier staff (modifiables dans les raccourcis de FiveM). Le serveur décide : sans droit ou hors service, rien ne se passe.
local BINDS = {
    { 'noclip', 'noclip', 'Staff : noclip', 'noclip' }, { 'tpm', nil, 'Staff : téléportation au point GPS', 'tpm' }, { 'back', nil, 'Staff : retour à la position précédente', 'back' },
    { 'god', 'god', 'Staff : invincibilité', 'god' }, { 'invisible', 'invisible', 'Staff : invisibilité', 'invisible' }, { 'names', 'names', 'Staff : noms au-dessus des têtes', 'names' },
    { 'heal', nil, 'Staff : me soigner', 'heal' }, { 'photo', 'photo', 'Staff : mode photo (tout invisible)', 'photo' },
}
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.staff and GetGameTimer() < t do Wait(250) end
    local c = G.cfg.staff or {}
    local defaults = { noclip = 'F3' }   -- F4 = poste radio des joueurs
    for _, b in ipairs(BINDS) do
        local name, feature, label = b[1], b[2], b[3]
        local cmd = 'pb_staff_' .. name
        RegisterCommand(cmd, function()
            if not G.begun or G.creating or G.wardrobe or G.Menu.IsOpen() then return end
            TriggerServerEvent('pb:g:staff:bind', name, feature and not self[feature] or false)
        end, false)
        local key = c['bind_' .. name]
        if type(key) ~= 'string' then key = defaults[name] or '' end
        RegisterKeyMapping(cmd, label, 'keyboard', key)
    end
end)

AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    if spectating then NetworkSetInSpectatorMode(false, PlayerPedId()) end
    local ped = PlayerPedId()
    dutyOn, graceUntil = false, 0
    self.noclip, self.god, self.photo = nil, nil, nil
    DisplayRadar(true)
    refreshGod()
    SetEntityVisible(ped, true, false) FreezeEntityPosition(ped, false)
end)

RegisterNetEvent('pb:g:staff:hud', function(j)
    local d = G.decode(j)
    G.send('staff.hud', (type(d) == 'table' and d.items) and d or { items = {} })
end)

-- Spectateur amélioré : on se rapproche invisiblement si la cible est loin, on revient à sa place à la fin ;
-- infos de la cible à l'écran ; ← → joueur suivant / précédent ; Retour arrêter.
local specState
function G.SpectateStart(d)
    local ped = PlayerPedId()
    if not specState then specState = { back = GetEntityCoords(ped), list = d.list or {} } end
    if d.list then specState.list = d.list end
    specState.target, specState.name = d.target, d.name
    local pid = GetPlayerFromServerId(d.target)
    if pid == -1 and d.pos then
        SetEntityVisible(ped, false, false) SetEntityCollision(ped, false, false) FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true)
        SetEntityCoords(ped, d.pos.x + 0.0, d.pos.y + 0.0, d.pos.z - 30.0, false, false, false, false)
        local t = GetGameTimer() + 5000
        while GetPlayerFromServerId(d.target) == -1 and GetGameTimer() < t do Wait(100) end
        pid = GetPlayerFromServerId(d.target)
    end
    if pid == -1 then note('error', 'Impossible de rejoindre ce joueur.') G.SpectateStop() return end
    SetEntityVisible(ped, false, false) SetEntityCollision(ped, false, false) FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true)
    NetworkSetInSpectatorMode(true, GetPlayerPed(pid))
    spectating = true
    if specState.loop then return end
    specState.loop = true
    CreateThread(function()
        while spectating and specState do
            Wait(0)
            local tp = GetPlayerFromServerId(specState.target)
            local tped = tp ~= -1 and GetPlayerPed(tp) or 0
            -- la position du staff suit la cible (sous le sol) pour rester à portée réseau
            if tped ~= 0 then local c = GetEntityCoords(tped) SetEntityCoords(PlayerPedId(), c.x, c.y, c.z - 30.0, false, false, false, false) end
            local lines = { ('%s (#%d)'):format(tostring(specState.name or '?'), G.UidOf(specState.target) or specState.target) }
            if tped ~= 0 then
                lines[#lines + 1] = ('Vie %d · Gilet %d'):format(math.max(0, GetEntityHealth(tped) - 100), GetPedArmour(tped))
                local v = GetVehiclePedIsIn(tped, false)
                if v ~= 0 then lines[#lines + 1] = ('%s · %d km/h'):format(GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(v))), math.floor(GetEntitySpeed(v) * 3.6)) end
                local _, w = GetCurrentPedWeapon(tped, true)
                if w and w ~= joaat('WEAPON_UNARMED') then lines[#lines + 1] = 'Arme en main' end
            end
            lines[#lines + 1] = '← → joueur suivant · Retour : arrêter'
            for i, l in ipairs(lines) do
                SetTextFont(4) SetTextScale(0.38, 0.38) SetTextColour(255, 255, 255, 230) SetTextOutline()
                BeginTextCommandDisplayText('STRING') AddTextComponentSubstringPlayerName(l) EndTextCommandDisplayText(0.015, 0.30 + i * 0.028)
            end
            DisableControlAction(0, 174, true) DisableControlAction(0, 175, true) DisableControlAction(0, 177, true) DisableControlAction(0, 194, true)
            if IsDisabledControlJustPressed(0, 175) or IsDisabledControlJustPressed(0, 174) then
                local l, cur, nextId = specState.list or {}, 0, nil
                for i, id in ipairs(l) do if id == specState.target then cur = i end end
                if #l > 0 then nextId = l[((cur - 1 + (IsDisabledControlJustPressed(0, 175) and 1 or -1)) % #l) + 1] end
                if nextId and nextId ~= specState.target then TriggerServerEvent('pb:g:staff:specnext', nextId) end
            elseif IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 194) then
                G.SpectateStop()
            end
        end
    end)
end
function G.SpectateStop()
    local ped = PlayerPedId()
    NetworkSetInSpectatorMode(false, ped)
    spectating = false
    if specState then
        local b = specState.back
        specState = nil
        if b then SetEntityCoords(ped, b.x, b.y, b.z, false, false, false, false) end
    end
    SetEntityVisible(ped, true, false) SetEntityCollision(ped, true, true) FreezeEntityPosition(ped, false)
    if refreshGod then refreshGod() else SetEntityInvincible(ped, false) end
end
