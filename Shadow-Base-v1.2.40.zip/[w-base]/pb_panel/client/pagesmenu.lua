-- Pages de l'entreprise et de l'organisation dans le menu lib (F6 / F7, siège, QG) : il n'y a plus de tablette.
-- Le serveur envoie les mêmes pages qu'avant (cartes, tableaux, formulaires, actions) ; G.Menu.FromBlocks en fait des éléments de menu.
-- Une action renvoie la page à jour : le menu revient sur cette page et l'actualise. Le serveur revérifie tout (droits, bureau du patron…).
local G = PBG
local PM = {}
G.PagesMenu = PM

local KINDS = {
    biz = { ev = 'pb:g:biz', title = 'Mon entreprise' },
    orga = { ev = 'pb:g:orga', title = 'Organisation' },
}
local wait = nil   -- réponse attendue : { kind, page, label, mode = 'push' | 'act', parent | def }

local function money(n) return (tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) .. ' $' end
local function notify(ok, title, text) if text and text ~= '' then G.send('notify', { type = ok and 'success' or 'error', title = title, text = tostring(text) }) end end
local function top() local m = G.Menu.Stack:Current() return m and m.def or nil end

local pageDef
local function act(kind, page, def, name, payload)
    if type(name) ~= 'string' or name == '' then return end
    wait = { kind = kind, page = page, mode = 'act', def = def }
    TriggerServerEvent(KINDS[kind].ev .. ':act', name, type(payload) == 'table' and payload or {}, page)
end
function pageDef(kind, data, label)
    local page = tostring(data.page or 'home')
    local def = { id = kind .. '.page.' .. page, title = (data.title and data.title ~= '') and tostring(data.title) or tostring(label or KINDS[kind].title), subtitle = label and data.title ~= label and tostring(label) or nil, keepSel = true }
    def.items = G.Menu.FromBlocks(data.blocks or {}, function(name, payload) act(kind, page, def, name, payload) end, def.id, function(p, l) PM.Open(kind, p, l) end)
    return def
end

-- Ouvre une page par-dessus le menu affiché (réponse du serveur un instant plus tard)
function PM.Open(kind, page, label)
    if not KINDS[kind] then return end
    wait = { kind = kind, page = tostring(page), label = label, mode = 'push', parent = top() }
    TriggerServerEvent(KINDS[kind].ev .. ':page', tostring(page))
end
-- Élément de menu qui mène à une page (utilisé par les menus F6 et F7)
function PM.Item(kind, e)
    return { label = tostring(e.label or e.title or e.page), icon = e.icon, right = '›', description = e.desc, onSelect = function() PM.Open(kind, e.page or e.id, e.label or e.title) end }
end

-- Menu d'accueil (point du siège / QG, /tablette, /orga, F6 sans entreprise) : toutes les pages permises
local function rootDef(kind, f)
    f = f or {}
    local items = {}
    if kind == 'biz' then
        if f.biz then items[#items + 1] = { type = 'separator', label = tostring(f.biz.label) .. ' · ' .. tostring(f.biz.grade or '') } end
        items[#items + 1] = { label = 'Espèces', right = money(f.cash), icon = 'wallet', disabled = true }
        items[#items + 1] = { label = 'Banque', right = money(f.bank), icon = 'card', disabled = true }
        local last
        for _, n in ipairs(f.nav or {}) do
            if n.group ~= last then last = n.group items[#items + 1] = { type = 'separator', label = tostring(n.group or '') } end
            items[#items + 1] = PM.Item('biz', { page = n.id, label = n.id == 'home' and 'Tableau de bord' or n.label, icon = n.icon })
        end
    else
        for _, x in ipairs(f.xp or {}) do items[#items + 1] = { label = x.icon == 'users' and 'XP du groupe' or 'Mon XP', right = tostring(x.value or '') .. ((x.rank or '') ~= '' and (' · ' .. x.rank) or ''), icon = 'star', disabled = true } end
        items[#items + 1] = { type = 'separator', label = 'Gestion de l\'organisation' }
        for _, t in ipairs(f.tiles or {}) do items[#items + 1] = PM.Item('orga', { page = t.page or t.id, label = t.title, icon = t.icon }) end
    end
    local title = kind == 'biz' and (f.biz and f.biz.label or 'Espace citoyen') or 'Organisation'
    return { id = kind .. '.root', title = title, subtitle = kind == 'biz' and (f.biz and (f.biz.duty and 'En service' or 'Hors service') or tostring(f.name or '')) or tostring(f.subtitle or ''):gsub('^Accueil tablette illégale · ', ''),
        banner = { text = title }, items = items }
end

local function onUi(kind, j)
    local d = G.decode(j)
    if not d then return end
    local K = KINDS[kind]
    if d.ev == 'open' then
        if G.creating or G.wardrobe or (G.state and G.state.dead) then return end
        wait = nil
        if G.Menu.IsOpen() then G.Menu.Close() end
        G.Menu.Open(rootDef(kind, d.frame))
        return
    end
    local w = wait
    if not w or w.kind ~= kind then
        if d.ev == 'result' then notify(d.ok, K.title, d.msg) end
        return
    end
    wait = nil
    if d.ev == 'page' and w.mode == 'push' then
        if not d.page then notify(false, K.title, d.err or 'Page indisponible.') return end
        if not G.Menu.IsOpen() or top() ~= w.parent then return end   -- le joueur a quitté ce menu entre-temps
        G.Menu.Push(pageDef(kind, d.page, w.label))
    elseif d.ev == 'result' then
        notify(d.ok, K.title, d.msg)
        if w.mode == 'act' and d.page and G.Menu.IsOpen() then G.Menu.PopTo(w.def, pageDef(kind, d.page, w.def.subtitle or w.def.title)) end
    end
end
RegisterNetEvent('pb:g:biz:ui', function(j) onUi('biz', j) end)
RegisterNetEvent('pb:g:orga:ui', function(j) onUi('orga', j) end)
-- le coffre de l'organisation s'ouvre : le menu laisse la place à l'inventaire
RegisterNetEvent('pb:g:orga:shut', function() wait = nil if G.Menu.IsOpen() then G.Menu.Close() end end)
