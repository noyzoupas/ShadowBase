-- Écran d'accueil / règlement : affiché avant la création du personnage. L'acceptation et la lecture minimale sont vérifiées par le serveur.
local G = PBG
local shown = false
local blurred = false

RegisterNetEvent('pb:g:flow:welcome', function(j)
    local d = G.decode(j)
    if not d then return end
    -- pas pendant l'arrivée en ville (transition de l'écran d'entrée) : on attend qu'elle se termine
    local wait = GetGameTimer() + 25000
    while (G.arriving or G.entrance) and GetGameTimer() < wait do Wait(250) end
    if G.creating then return end   -- jamais par-dessus le créateur
    shown = true
    G.focus(true)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true) SetEntityInvincible(ped, true)
    if d.blur ~= false then TriggerScreenblurFadeIn(400) blurred = true end
    G.send('welcome.open', d)
end)

RegisterNetEvent('pb:g:flow:welcomeClose', function()
    if not shown then return end
    shown = false
    G.focus(false)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false) SetEntityInvincible(ped, false)
    if blurred then TriggerScreenblurFadeOut(400) blurred = false end
    G.send('welcome.close', {})
end)

G.nui['welcome.accept'] = function() if shown then TriggerServerEvent('pb:g:flow:accept') end return {} end
G.nui['welcome.decline'] = function() if shown then TriggerServerEvent('pb:g:flow:decline') end return {} end
