-- Repères de la carte (blips) : registre de TOUS les blips créés par pb_panel. Chargé juste après keys.lua, avant les autres scripts client :
-- AddBlipFor* / RemoveBlip sont remplacés par des versions qui notent chaque repère (position, fichier qui l'a créé).
--  · doublons : deux repères du même icône à moins de 3 m (ou deux zones identiques) -> un seul reste affiché, l'autre est masqué
--    (il revient tout seul si le premier disparaît) ;
--  · repères fantômes : un repère accroché à un personnage / véhicule qui n'existe plus est supprimé ;
--  · réinitialisation (/blips, menu staff, panel) : tout est effacé puis redemandé au serveur et aux extensions.
PBBlips = { reg = {}, hidden = {} }
local R = PBBlips
local _coord, _radius, _entity, _remove, _setCoords = AddBlipForCoord, AddBlipForRadius, AddBlipForEntity, RemoveBlip, SetBlipCoords

local function origin()
    if not (debug and debug.getinfo) then return '?' end
    local ok, i = pcall(debug.getinfo, 3, 'S')
    return (ok and i and tostring(i.short_src or '?'):match('([^/\\]+)$')) or '?'
end
local function note(b, d) if b and b ~= 0 then d.t, d.f = GetGameTimer(), origin() R.reg[b] = d end return b end

function AddBlipForCoord(x, y, z) return note(_coord(x, y, z), { k = 'c', x = x + 0.0, y = y + 0.0 }) end
function AddBlipForRadius(x, y, z, r) return note(_radius(x, y, z, r), { k = 'r', x = x + 0.0, y = y + 0.0, r = r + 0.0 }) end
function AddBlipForEntity(e) return note(_entity(e), { k = 'e', e = e }) end
function RemoveBlip(b)
    R.reg[b], R.hidden[b] = nil, nil
    return _remove(b)
end
function SetBlipCoords(b, x, y, z)
    local d = R.reg[b]
    if d then d.x, d.y = x + 0.0, y + 0.0 end
    return _setCoords(b, x, y, z)
end

-- Passe de contrôle (toutes les 4 s) -------------------------------------------------------------------------------------------------------
local CELL = 3.0
local function pass()
    local cells = {}
    local list = {}
    for b, d in pairs(R.reg) do
        if not DoesBlipExist(b) then R.reg[b], R.hidden[b] = nil, nil
        elseif d.k == 'e' then
            if not DoesEntityExist(d.e) then _remove(b) R.reg[b], R.hidden[b] = nil, nil end
        else list[#list + 1] = b end
    end
    -- le plus ancien repère d'un endroit est celui qu'on garde
    table.sort(list, function(a, b) return R.reg[a].t < R.reg[b].t end)
    for _, b in ipairs(list) do
        local d = R.reg[b]
        local dup = false
        if not IsBlipFlashing(b) then   -- alertes (911, joueur à terre…) : jamais masquées
            local sp = d.k == 'r' and -1 or GetBlipSprite(b)
            local cx, cy = math.floor(d.x / CELL), math.floor(d.y / CELL)
            for ix = cx - 1, cx + 1 do
                for iy = cy - 1, cy + 1 do
                    for _, o in ipairs(cells[ix .. ':' .. iy] or {}) do
                        local od = R.reg[o]
                        if od and od.sp == sp and math.abs(od.x - d.x) < CELL and math.abs(od.y - d.y) < CELL and (d.k ~= 'r' or math.abs(od.r - d.r) < 1.0) then dup = true break end
                    end
                    if dup then break end
                end
                if dup then break end
            end
            if not dup then
                d.sp = sp
                local key = cx .. ':' .. cy
                cells[key] = cells[key] or {}
                table.insert(cells[key], b)
            end
        end
        if dup and not R.hidden[b] then R.hidden[b] = true SetBlipDisplay(b, 0)
        elseif not dup and R.hidden[b] then R.hidden[b] = nil SetBlipDisplay(b, d.k == 'r' and 8 or 2) end
    end
end
CreateThread(function() while true do Wait(4000) pcall(pass) end end)

-- Réinitialisation ---------------------------------------------------------------------------------------------------------------------------
-- deep = true : efface aussi les repères perdus qui ne sont dans aucun registre (anciens scripts, repères restés après un crash…),
-- sauf le repère du joueur, le point GPS, les itinéraires en cours et les repères accrochés à un personnage ou un véhicule.
local lastReset = -60000
function R.Reset(deep)
    if GetGameTimer() - lastReset < 5000 then return false end
    lastReset = GetGameTimer()
    local n = 0
    -- un repère avec itinéraire GPS (mission, livraison, appel en cours) est gardé : il n'est redessiné par personne
    local function busy(b) return DoesBlipHaveGpsRoute(b) or IsBlipFlashing(b) end
    for b in pairs(R.reg) do
        if not DoesBlipExist(b) then R.reg[b], R.hidden[b] = nil, nil
        elseif not busy(b) then _remove(b) R.reg[b], R.hidden[b] = nil, nil n = n + 1 end
    end
    if deep then
        local me, kill = GetMainPlayerBlipId(), {}
        for sprite = 0, 900 do
            if sprite ~= 8 and sprite ~= 162 then   -- 8 : point GPS du joueur
                local b = GetFirstBlipInfoId(sprite)
                while DoesBlipExist(b) do
                    if b ~= me and GetBlipInfoIdEntityIndex(b) == 0 and not R.reg[b] and not busy(b) then kill[#kill + 1] = b end
                    b = GetNextBlipInfoId(sprite)
                end
            end
        end
        for _, b in ipairs(kill) do if DoesBlipExist(b) then _remove(b) n = n + 1 end end
    end
    TriggerEvent('pb:blips:reset')               -- extensions Shadow Base : elles effacent les leurs et redemandent leur liste
    TriggerServerEvent('pb:g:blips:resync')      -- pb_panel : le serveur renvoie magasins, garages, points, zones, cartographie…
    return true, n
end
function R.Stats()
    local total, hidden, by = 0, 0, {}
    for b, d in pairs(R.reg) do
        if DoesBlipExist(b) then
            total = total + 1
            if R.hidden[b] then hidden = hidden + 1 by[d.f] = (by[d.f] or 0) + 1 end
        end
    end
    return total, hidden, by
end

local function say(kind, text) if PBG and PBG.send then PBG.send('notify', { type = kind, title = 'Carte', text = text }) end end
local function doReset(deep)
    local ok, n = R.Reset(deep)
    if not ok then say('warn', 'Patiente quelques secondes avant de recommencer.') return end
    say('success', ('Repères réinitialisés (%d effacés). Ils reviennent dans un instant.'):format(n or 0))
end
-- /blips : état ; /blips reset : réinitialiser ; /blips complet : réinitialiser + effacer les repères perdus
RegisterCommand('blips', function(_, args)
    local a = tostring(args[1] or ''):lower()
    if a == 'reset' then doReset(false)
    elseif a == 'complet' or a == 'full' then doReset(true)
    else
        local total, hidden = R.Stats()
        say('info', ('%d repères Shadow Base, %d doublons masqués. « /blips reset » pour tout réinitialiser, « /blips complet » pour effacer aussi les repères perdus.'):format(total, hidden))
    end
end, false)
-- demandé par le staff (panel ou menu staff) pour tous les joueurs
RegisterNetEvent('pb:g:blips:reset', function(deep) lastReset = -60000 doReset(deep == true) end)
exports('ResetBlips', function(deep) return R.Reset(deep == true) end)
