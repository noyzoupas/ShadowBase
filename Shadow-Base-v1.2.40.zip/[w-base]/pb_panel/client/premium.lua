-- Boutique du serveur (coins) : ouverture (touche réglable, /boutique), envoi des achats. Le serveur décide de tout (solde, livraison).
local G = PBG
local isOpen = false

local function close()
    if not isOpen then return end
    isOpen = false
    G.focus(false)
    G.send('premium.close', {})
end
local function open()
    -- pas par-dessus une autre interface (inventaire, téléphone, menus…), ni à terre
    if isOpen or (G.locked or 0) > 0 or G.creating or G.wardrobe or (G.state and G.state.dead) or IsPauseMenuActive() then return end
    TriggerServerEvent('pb:g:premium:open')
end
RegisterCommand('pb_shop', open, false)
RegisterNetEvent('pb:g:premium:key', open)

-- Fiche technique lue dans le jeu : vitesse, accélération, freinage, adhérence (véhicules) ; dégâts, chargeur (armes). Gardée en cache.
local statCache = {}
local function pct(v, max) return math.max(3, math.min(100, math.floor((tonumber(v) or 0) / max * 100 + 0.5))) end
local function vehStats(model)
    if statCache[model] ~= nil then return statCache[model] or nil end
    local h = joaat(model)
    local out = false
    if model ~= '' and IsModelInCdimage(h) and IsModelAVehicle(h) then
        local ok, sp, ac, br, tr = pcall(function() return GetVehicleModelEstimatedMaxSpeed(h), GetVehicleModelAcceleration(h), GetVehicleModelMaxBraking(h), GetVehicleModelMaxTraction(h) end)
        if ok then out = { kmh = math.floor((sp or 0) * 3.6 + 0.5), bars = { { 'Vitesse', pct(sp, 55) }, { 'Accélération', pct(ac, 0.45) }, { 'Freinage', pct(br, 1.6) }, { 'Adhérence', pct(tr, 3.2) } } } end
    end
    statCache[model] = out
    return out or nil
end
local function weapStats(hashName)
    if statCache[hashName] ~= nil then return statCache[hashName] or nil end
    local h = joaat(hashName)
    local out = false
    if hashName ~= '' and IsWeaponValid(h) then
        local ok, dmg, clip = pcall(function() return GetWeaponDamage(h, 0), GetWeaponClipSize(h) end)
        if ok then
            out = { bars = { { 'Dégâts', pct(dmg, 120) } } }
            if (tonumber(clip) or 0) > 0 then out.bars[2] = { 'Chargeur', pct(clip, 60), tostring(math.floor(clip)) .. ' balles' } end
        end
    end
    statCache[hashName] = out
    return out or nil
end
local function enrich(d)
    for _, it in ipairs((d and d.d and d.d.items) or {}) do
        if it.cat == 'vehicle' and type(it.model) == 'string' then it.stats = vehStats(it.model:lower())
        elseif it.cat == 'weapon' and type(it.hash) == 'string' then it.stats = weapStats(it.hash:upper()) end
    end
end

RegisterNetEvent('pb:g:premium:ui', function(j)
    local d = G.decode(j)
    if not d then return end
    pcall(enrich, d)
    if d.ev == 'open' then
        if isOpen then return end
        isOpen = true
        G.focus(true)
    elseif not isOpen then return end
    G.send('premium.' .. tostring(d.ev), d)
end)
RegisterNetEvent('pb:g:premium:coins', function(n) if isOpen then G.send('premium.coins', { coins = tonumber(n) or 0 }) end end)
RegisterNetEvent('pb:g:premium:gps', function(x, y)
    x, y = tonumber(x), tonumber(y)
    if x and y then SetNewWaypoint(x + 0.0, y + 0.0) end
end)

G.nui['premium.buy'] = function(d) if isOpen and tonumber(d.id) then TriggerServerEvent('pb:g:premium:buy', tonumber(d.id), type(d.p) == 'table' and d.p or {}) end return {} end
G.nui['premium.claim'] = function(d) if isOpen and tonumber(d.id) then TriggerServerEvent('pb:g:premium:claim', tonumber(d.id)) end return {} end
G.nui['premium.close'] = function() close() return {} end
G.onForceClose(function() close() end)

CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.premium and GetGameTimer() < t do Wait(250) end
    local k = G.cfg.premium and G.cfg.premium.key or 'F11'
    if type(k) == 'string' and k ~= '' then RegisterKeyMapping('pb_shop', 'Ouvrir la boutique du serveur', 'keyboard', k) end
end)
