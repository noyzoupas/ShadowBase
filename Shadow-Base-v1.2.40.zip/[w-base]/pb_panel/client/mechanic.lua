-- Atelier : customisation en direct dans le véhicule, réparation et nettoyage facturés au client. Le serveur vérifie métier, service, distance et prix.
local G = PBG

local function nearestVeh()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then local c = GetEntityCoords(ped) veh = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71) end
    return veh ~= 0 and DoesEntityExist(veh) and veh or nil
end
local function plateOf(veh) return (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', '') end
local function grab(veh) if NetworkHasControlOfEntity(veh) then return true end NetworkRequestControlOfEntity(veh) local t = GetGameTimer() + 1500 while not NetworkHasControlOfEntity(veh) and GetGameTimer() < t do Wait(30) end return NetworkHasControlOfEntity(veh) end

-- Applique une pièce (aussi utilisée à la sortie du garage)
function G.ApplyPart(veh, kind, mod, level)
    level = math.floor(tonumber(level) or 0)
    if kind == 'mod' then
        SetVehicleModKit(veh, 0)
        SetVehicleMod(veh, mod, level - 1, false)
    elseif kind == 'toggle' then SetVehicleModKit(veh, 0) ToggleVehicleMod(veh, mod, level > 0)
    elseif kind == 'tint' then SetVehicleModKit(veh, 0) SetVehicleWindowTint(veh, level)
    elseif kind == 'plate' then SetVehicleNumberPlateTextIndex(veh, level)
    elseif kind == 'paint' then local _, c2 = GetVehicleColours(veh) SetVehicleColours(veh, level, c2) end
end
function G.ApplyMods(veh, mods)
    local parts = (G.cfg.mech and G.cfg.mech.parts) or {}
    for _, p in ipairs(parts) do
        local lv = mods and mods[p.key]
        if lv then G.ApplyPart(veh, p.kind, p.mod, lv) end
    end
end

-- Customisation (atelier) ---------------------------------------------------------------------------------------------------------------------------------
-- Le mécanicien est DANS le véhicule. Chaque option survolée s'affiche sur la voiture (le client voit le rendu) ; Entrée l'ajoute au devis.
-- En quittant une liste, la voiture revient à l'état du devis. « Valider le devis » envoie les changements au serveur, qui fixe les prix.
local CLASSIC = { { 0, 'Noir' }, { 1, 'Graphite' }, { 2, 'Noir acier' }, { 3, 'Argent foncé' }, { 4, 'Argent' }, { 5, 'Argent bleuté' }, { 6, 'Gris acier' }, { 7, 'Argent ombré' },
    { 8, 'Argent pierre' }, { 9, 'Argent minuit' }, { 10, 'Gris canon' }, { 11, 'Anthracite' }, { 27, 'Rouge' }, { 28, 'Rouge Turin' }, { 29, 'Rouge formule' }, { 30, 'Rouge flamme' },
    { 31, 'Rouge grenat' }, { 32, 'Rouge désert' }, { 33, 'Rouge cabernet' }, { 34, 'Rouge bonbon' }, { 35, 'Rouge aurore' }, { 36, 'Orange' }, { 37, 'Or classique' }, { 38, 'Orange vif' },
    { 49, 'Vert foncé' }, { 50, 'Vert course' }, { 51, 'Vert mer' }, { 52, 'Vert olive' }, { 53, 'Vert vif' }, { 54, 'Vert essence' }, { 61, 'Bleu nuit' }, { 62, 'Bleu foncé' },
    { 63, 'Bleu saxe' }, { 64, 'Bleu' }, { 65, 'Bleu marine' }, { 66, 'Bleu port' }, { 67, 'Bleu diamant' }, { 68, 'Bleu surf' }, { 69, 'Bleu nautique' }, { 70, 'Bleu électrique' },
    { 71, 'Violet' }, { 72, 'Violet spinnaker' }, { 73, 'Bleu ultra' }, { 74, 'Bleu clair' }, { 88, 'Jaune' }, { 89, 'Jaune course' }, { 90, 'Bronze' }, { 91, 'Jaune pâle' },
    { 92, 'Vert citron' }, { 94, 'Brun' }, { 96, 'Chocolat' }, { 97, 'Érable' }, { 98, 'Selle' }, { 99, 'Paille' }, { 100, 'Mousse' }, { 101, 'Bison' }, { 102, 'Bois' },
    { 103, 'Hêtre' }, { 104, 'Sienne' }, { 105, 'Sable' }, { 106, 'Beige' }, { 107, 'Crème' }, { 111, 'Blanc' }, { 112, 'Blanc givré' }, { 135, 'Rose vif' }, { 136, 'Rose saumon' },
    { 137, 'Rose' }, { 138, 'Orange brûlé' }, { 141, 'Bleu nuit profond' }, { 142, 'Violet nuit' }, { 143, 'Rouge vin' }, { 145, 'Violet clair' }, { 150, 'Rouge lave' } }
local MATTE = { { 12, 'Noir mat' }, { 13, 'Gris mat' }, { 14, 'Gris clair mat' }, { 39, 'Rouge mat' }, { 40, 'Rouge foncé mat' }, { 41, 'Orange mat' }, { 42, 'Jaune mat' },
    { 55, 'Vert lime mat' }, { 82, 'Bleu foncé mat' }, { 83, 'Bleu mat' }, { 84, 'Bleu nuit mat' }, { 128, 'Vert mat' }, { 131, 'Blanc mat' }, { 148, 'Violet mat' },
    { 149, 'Violet foncé mat' }, { 151, 'Vert forêt mat' }, { 152, 'Olive mat' }, { 153, 'Terre mat' }, { 154, 'Désert mat' }, { 155, 'Feuillage mat' } }
local METAL = { { 117, 'Acier brossé' }, { 118, 'Acier noir brossé' }, { 119, 'Aluminium brossé' }, { 158, 'Or pur' }, { 159, 'Or brossé' }, { 120, 'Chrome' } }
local RGB = { { 'Blanc pur', 255, 255, 255 }, { 'Noir profond', 8, 8, 8 }, { 'Rouge vif', 220, 20, 30 }, { 'Bordeaux', 110, 10, 30 }, { 'Orange', 255, 120, 0 }, { 'Jaune', 255, 210, 0 },
    { 'Vert lime', 120, 255, 30 }, { 'Vert émeraude', 0, 150, 90 }, { 'Turquoise', 0, 200, 200 }, { 'Bleu ciel', 80, 170, 255 }, { 'Bleu roi', 20, 60, 220 }, { 'Bleu nuit', 10, 20, 70 },
    { 'Violet', 130, 40, 220 }, { 'Rose', 255, 80, 170 }, { 'Or', 212, 175, 55 }, { 'Gris béton', 120, 120, 125 } }
local WHEELS = { { 0, 'Sport' }, { 1, 'Muscle' }, { 2, 'Lowrider' }, { 3, 'SUV' }, { 4, 'Tout-terrain' }, { 5, 'Tuner' }, { 7, 'Haut de gamme' }, { 8, "Benny's originales" }, { 9, "Benny's bespoke" },
    { 10, 'Ouvertes' }, { 11, 'Rue' }, { 12, 'Circuit' }, { 6, 'Moto' } }
local BODY = { { 0, 'Aileron' }, { 1, 'Pare-chocs avant' }, { 2, 'Pare-chocs arrière' }, { 3, 'Bas de caisse' }, { 4, 'Échappement' }, { 5, 'Arceau / châssis' }, { 6, 'Calandre' },
    { 7, 'Capot' }, { 8, 'Ailes' }, { 9, 'Ailes droites' }, { 10, 'Toit' } }
local EXTRA = { { 25, 'Support de plaque' }, { 26, 'Plaques personnalisées' }, { 27, 'Garnitures' }, { 28, 'Ornements' }, { 29, 'Tableau de bord' }, { 30, 'Compteurs' },
    { 31, 'Haut-parleurs de porte' }, { 32, 'Sièges' }, { 33, 'Volant' }, { 34, 'Levier de vitesse' }, { 35, 'Plaques' }, { 36, 'Haut-parleurs' }, { 37, 'Coffre' },
    { 38, 'Hydraulique' }, { 39, 'Bloc moteur' }, { 40, 'Filtre à air' }, { 41, 'Jambes de force' }, { 42, 'Passages de roue' }, { 43, 'Antennes' }, { 44, 'Garnitures extérieures' },
    { 45, 'Réservoir' }, { 46, 'Vitres' } }
local PERF = { { 11, 'Moteur' }, { 12, 'Freins' }, { 13, 'Transmission' }, { 15, 'Suspension' }, { 16, 'Blindage' } }
local XENON = { { -1, "Blanc d'origine" }, { 0, 'Blanc' }, { 1, 'Bleu' }, { 2, 'Bleu électrique' }, { 3, 'Vert menthe' }, { 4, 'Vert lime' }, { 5, 'Jaune' }, { 6, 'Or' },
    { 7, 'Orange' }, { 8, 'Rouge' }, { 9, 'Rose poney' }, { 10, 'Rose vif' }, { 11, 'Violet' }, { 12, 'Lumière noire' } }
local TINT = { { 0, 'Aucune' }, { 4, 'Légère' }, { 5, 'Fumée' }, { 3, 'Fumée claire' }, { 1, 'Noir intégral' }, { 2, 'Noir foncé' }, { 6, 'Verte' } }
local PLATES = { { 0, 'Bleu sur blanc 1' }, { 3, 'Bleu sur blanc 2' }, { 4, 'Bleu sur blanc 3' }, { 1, 'Jaune sur noir' }, { 2, 'Jaune sur bleu' }, { 5, 'Yankton' } }

-- Lecture et application d'un état complet (mêmes clés que le devis)
local function readState(veh)
    local s = { mods = {} }
    local c1, c2 = GetVehicleColours(veh)
    local pearl, wcol = GetVehicleExtraColours(veh)
    s.col1, s.col2, s.pearl, s.wheelcol = { c1 }, { c2 }, pearl, wcol
    s.int = GetVehicleInteriorColour and GetVehicleInteriorColour(veh) or 0
    s.dash = GetVehicleDashboardColour and GetVehicleDashboardColour(veh) or 0
    if GetIsVehiclePrimaryColourCustom(veh) then local r, g, b = GetVehicleCustomPrimaryColour(veh) s.rgb1 = { r, g, b } end
    if GetIsVehicleSecondaryColourCustom(veh) then local r, g, b = GetVehicleCustomSecondaryColour(veh) s.rgb2 = { r, g, b } end
    SetVehicleModKit(veh, 0)
    s.wheel = { GetVehicleWheelType(veh), GetVehicleMod(veh, 23), GetVehicleModVariation(veh, 23) }
    for t = 0, 48 do if t ~= 23 and t ~= 18 and t ~= 22 and t ~= 20 then s.mods[tostring(t)] = GetVehicleMod(veh, t) end end
    s.turbo, s.xenon, s.smoke = IsToggleModOn(veh, 18), IsToggleModOn(veh, 22), IsToggleModOn(veh, 20)
    s.xcol = GetVehicleXenonLightsColor and GetVehicleXenonLightsColor(veh) or -1
    s.neon = { IsVehicleNeonLightEnabled(veh, 0), IsVehicleNeonLightEnabled(veh, 1), IsVehicleNeonLightEnabled(veh, 2), IsVehicleNeonLightEnabled(veh, 3) }
    local nr, ng, nb = GetVehicleNeonLightsColour(veh) s.ncol = { nr, ng, nb }
    local sr, sg, sb = GetVehicleTyreSmokeColor(veh) s.scol = { sr, sg, sb }
    s.tint, s.plate = GetVehicleWindowTint(veh), GetVehicleNumberPlateTextIndex(veh)
    s.horn, s.livery = GetVehicleMod(veh, 14), GetVehicleLivery(veh)
    return s
end
function G.ApplyCustom(veh, s)
    if not veh or veh == 0 or type(s) ~= 'table' then return end
    SetVehicleModKit(veh, 0)
    local c1, c2 = GetVehicleColours(veh)
    if s.col1 or s.col2 then SetVehicleColours(veh, s.col1 and s.col1[1] or c1, s.col2 and s.col2[1] or c2) end
    if s.rgb1 then SetVehicleCustomPrimaryColour(veh, s.rgb1[1], s.rgb1[2], s.rgb1[3]) elseif s.col1 then ClearVehicleCustomPrimaryColour(veh) end
    if s.rgb2 then SetVehicleCustomSecondaryColour(veh, s.rgb2[1], s.rgb2[2], s.rgb2[3]) elseif s.col2 then ClearVehicleCustomSecondaryColour(veh) end
    local pearl, wcol = GetVehicleExtraColours(veh)
    if s.pearl or s.wheelcol then SetVehicleExtraColours(veh, s.pearl or pearl, s.wheelcol or wcol) end
    if s.int and SetVehicleInteriorColour then SetVehicleInteriorColour(veh, s.int) end
    if s.dash and SetVehicleDashboardColour then SetVehicleDashboardColour(veh, s.dash) end
    if s.wheel then SetVehicleWheelType(veh, s.wheel[1]) SetVehicleMod(veh, 23, s.wheel[2], s.wheel[3] == true) end
    for k, v in pairs(s.mods or {}) do local t = tonumber(k) if t then if v < 0 then RemoveVehicleMod(veh, t) else SetVehicleMod(veh, t, v, false) end end end
    if s.turbo ~= nil then ToggleVehicleMod(veh, 18, s.turbo == true) end
    if s.xenon ~= nil then ToggleVehicleMod(veh, 22, s.xenon == true) end
    if s.xcol and SetVehicleXenonLightsColor then SetVehicleXenonLightsColor(veh, s.xcol) end
    if s.neon then for i = 0, 3 do SetVehicleNeonLightEnabled(veh, i, s.neon[i + 1] == true) end end
    if s.ncol then SetVehicleNeonLightsColour(veh, s.ncol[1], s.ncol[2], s.ncol[3]) end
    if s.smoke ~= nil then ToggleVehicleMod(veh, 20, s.smoke == true) end
    if s.scol then SetVehicleTyreSmokeColor(veh, s.scol[1], s.scol[2], s.scol[3]) end
    if s.tint then SetVehicleWindowTint(veh, s.tint) end
    if s.plate then SetVehicleNumberPlateTextIndex(veh, s.plate) end
    if s.horn then if s.horn < 0 then RemoveVehicleMod(veh, 14) else SetVehicleMod(veh, 14, s.horn, false) end end
    if s.livery and s.livery >= 0 then SetVehicleLivery(veh, s.livery) end
end

local shop   -- { veh, base, cart = { [k] = { v, label, txt } }, prices }
local function merged()
    local st = {}
    for k, v in pairs(shop.base) do if k ~= 'mods' then st[k] = v end end
    st.mods = {}
    for k, v in pairs(shop.base.mods) do st.mods[k] = v end
    for k, e in pairs(shop.cart) do
        local mt = k:match('^mod:(%d+)$')
        if mt then st.mods[mt] = e.v else st[k] = e.v end
    end
    return st
end
local function restore() if shop and DoesEntityExist(shop.veh) then G.ApplyCustom(shop.veh, merged()) end end
local function preview(k, v)
    if not shop or not DoesEntityExist(shop.veh) then return end
    local st = merged()
    local mt = k:match('^mod:(%d+)$')
    if mt then st.mods[mt] = v else st[k] = v end
    G.ApplyCustom(shop.veh, st)
end
local function money(n) return (tostring(math.floor(tonumber(n) or 0)):reverse():gsub('(%d%d%d)', '%1 '):reverse():gsub('^ ', '')) .. ' $' end
local function cartCount() local n = 0 for _ in pairs(shop.cart) do n = n + 1 end return n end
local function pick(k, v, label, txt) shop.cart[k] = { v = v, label = label, txt = txt } G.send('notify', { type = 'success', title = 'Devis', text = (txt or label) .. ' ajouté au devis.' }) end
-- une liste d'options : survol = aperçu sur la voiture, Entrée = au devis, sortie = retour à l'état du devis
local function optList(id, title, k, opts, priceKey, partLabel)
    local items = {}
    for _, o in ipairs(opts) do
        local cur = shop.cart[k]
        items[#items + 1] = { label = o.label, right = (cur and json.encode(cur.v) == json.encode(o.v)) and 'Au devis' or (shop.prices[priceKey] and money(shop.prices[priceKey]) or nil), val = o.v,
            onSelect = function() pick(k, o.v, partLabel or title, (partLabel or title) .. ' : ' .. o.label) end }
    end
    return { id = 'mech.' .. id, title = title, subtitle = 'Survole pour voir · Entrée : au devis', items = items,
        onHover = function(it) if it and it.val ~= nil then preview(k, it.val) end end,
        onOpen = function(m) local it = m.items and m.items[m.sel or 1] if it and it.val ~= nil then preview(k, it.val) end end,
        onClose = function() restore() end }
end
local function colorMenu(id, title, k)
    local function list(src) local o = {} for _, c in ipairs(src) do o[#o + 1] = { label = c[2], v = { c[1] } } end return o end
    local items = {
        { type = 'submenu', label = 'Classique et métallisé', submenu = optList(id .. '.c', title .. ' · classique', k, list(CLASSIC), 'color', title) },
        { type = 'submenu', label = 'Mat', submenu = optList(id .. '.m', title .. ' · mat', k, list(MATTE), 'color', title) },
        { type = 'submenu', label = 'Métal et chrome', submenu = optList(id .. '.x', title .. ' · métal', k, list(METAL), 'color', title) },
    }
    local rk = k == 'col1' and 'rgb1' or 'rgb2'
    local rl = {}
    for _, c in ipairs(RGB) do rl[#rl + 1] = { label = c[1], v = { c[2], c[3], c[4] } } end
    items[#items + 1] = { type = 'submenu', label = 'Teinte personnalisée', description = 'Couleur libre, plus vive que la palette du jeu.', submenu = optList(id .. '.r', title .. ' · teinte libre', rk, rl, 'rgb', title .. ' (teinte libre)') }
    return { id = 'mech.' .. id, title = title, items = items }
end
local function modList(t, label)
    SetVehicleModKit(shop.veh, 0)
    local n = GetNumVehicleMods(shop.veh, t) or 0
    if n <= 0 then return nil end
    local opts = { { label = "D'origine", v = -1 } }
    for i = 0, n - 1 do
        local txt = GetModTextLabel(shop.veh, t, i)
        local name = txt and txt ~= '' and GetLabelText(txt) or nil
        if not name or name == 'NULL' then name = label .. ' ' .. (i + 1) end
        opts[#opts + 1] = { label = name, v = i }
    end
    return optList('mod' .. t, label, 'mod:' .. t, opts, nil, label)
end
local function wheelsMenu()
    local items = {}
    for _, w in ipairs(WHEELS) do
        items[#items + 1] = { type = 'submenu', label = w[2], submenu = { id = 'mech.w' .. w[1], title = 'Jantes · ' .. w[2], subtitle = 'Survole pour voir · Entrée : au devis', build = function()
            local veh = shop.veh
            SetVehicleModKit(veh, 0)
            SetVehicleWheelType(veh, w[1])
            local n = GetNumVehicleMods(veh, 23) or 0
            local list = {}
            for i = 0, n - 1 do
                local txt = GetModTextLabel(veh, 23, i)
                local name = txt and txt ~= '' and GetLabelText(txt) or nil
                if not name or name == 'NULL' then name = 'Jante ' .. (i + 1) end
                list[#list + 1] = { label = name, right = money(shop.prices.wheel or 0), val = { w[1], i, false },
                    onSelect = function() pick('wheel', { w[1], i, false }, 'Jantes', 'Jantes : ' .. name) end }
            end
            if #list == 0 then list[1] = { label = 'Aucune jante de ce type pour ce véhicule', disabled = true } end
            return list
        end, onHover = function(it) if it and it.val then preview('wheel', it.val) end end, onClose = function() restore() end } }
    end
    local wl = {}
    for _, c in ipairs(CLASSIC) do wl[#wl + 1] = { label = c[2], v = c[1] } end
    for _, c in ipairs(METAL) do wl[#wl + 1] = { label = c[2], v = c[1] } end
    items[#items + 1] = { type = 'submenu', label = 'Couleur des jantes', submenu = optList('wcol', 'Couleur des jantes', 'wheelcol', wl, 'wheelcol') }
    items[#items + 1] = { type = 'submenu', label = 'Pneus', submenu = optList('tyre', 'Pneus', 'wheel', { { label = 'Pneus de série', v = { shop.base.wheel[1], shop.base.wheel[2], false } }, { label = 'Pneus personnalisés', v = { shop.base.wheel[1], shop.base.wheel[2], true } } }, 'wheel', 'Pneus') }
    local sm = {}
    for _, c in ipairs(RGB) do sm[#sm + 1] = { label = c[1], v = { c[2], c[3], c[4] } } end
    items[#items + 1] = { type = 'submenu', label = 'Fumée des pneus', submenu = { id = 'mech.smoke', title = 'Fumée des pneus', items = {
        { type = 'submenu', label = 'Activer / retirer', submenu = optList('smk', 'Fumée des pneus', 'smoke', { { label = 'Retirer', v = false }, { label = 'Installer', v = true } }, 'smoke') },
        { type = 'submenu', label = 'Couleur', submenu = optList('scol', 'Couleur de la fumée', 'scol', sm, 'scol') } } } }
    return { id = 'mech.wheels', title = 'Jantes et pneus', items = items }
end

local function openShop(d)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Monte dans le véhicule du client pour le customiser.' }) return end
    if not NetworkHasControlOfEntity(veh) then NetworkRequestControlOfEntity(veh) end
    shop = { veh = veh, base = readState(veh), cart = {}, prices = d.prices or {} }
    local function build()
        local items = { { type = 'separator', label = (d.biz or 'Atelier') .. ' · ' .. cartCount() .. ' option(s) au devis' } }
        items[#items + 1] = { type = 'submenu', label = 'Peinture', icon = 'brush', submenu = { id = 'mech.paint', title = 'Peinture', items = {
            { type = 'submenu', label = 'Couleur principale', submenu = colorMenu('p1', 'Couleur principale', 'col1') },
            { type = 'submenu', label = 'Couleur secondaire', submenu = colorMenu('p2', 'Couleur secondaire', 'col2') },
            { type = 'submenu', label = 'Nacré', submenu = (function() local o = {} for _, c in ipairs(CLASSIC) do o[#o + 1] = { label = c[2], v = c[1] } end return optList('pearl', 'Nacré', 'pearl', o, 'pearl') end)() },
            { type = 'submenu', label = 'Intérieur', submenu = (function() local o = {} for _, c in ipairs(CLASSIC) do o[#o + 1] = { label = c[2], v = c[1] } end return optList('int', 'Couleur intérieure', 'int', o, 'interior') end)() },
            { type = 'submenu', label = 'Tableau de bord', submenu = (function() local o = {} for _, c in ipairs(CLASSIC) do o[#o + 1] = { label = c[2], v = c[1] } end return optList('dash', 'Tableau de bord', 'dash', o, 'interior') end)() },
        } } }
        items[#items + 1] = { type = 'submenu', label = 'Jantes et pneus', icon = 'car', submenu = wheelsMenu() }
        local body = {}
        for _, b in ipairs(BODY) do local m = modList(b[1], b[2]) if m then body[#body + 1] = { type = 'submenu', label = b[2], submenu = m } end end
        local lv = GetVehicleLiveryCount(veh)
        if lv and lv > 0 then local o = {} for i = 0, lv - 1 do o[#o + 1] = { label = 'Livrée ' .. (i + 1), v = i } end body[#body + 1] = { type = 'submenu', label = 'Livrée', submenu = optList('livery', 'Livrée', 'livery', o, 'livery') } end
        local m48 = modList(48, 'Livrée (kit)') if m48 then body[#body + 1] = { type = 'submenu', label = 'Livrée (kit)', submenu = m48 } end
        items[#items + 1] = { type = 'submenu', label = 'Carrosserie', icon = 'car', description = #body == 0 and "Aucune pièce de carrosserie pour ce modèle." or nil, submenu = { id = 'mech.body', title = 'Carrosserie', items = #body > 0 and body or { { label = 'Aucune pièce pour ce modèle', disabled = true } } } }
        local ex = {}
        for _, b in ipairs(EXTRA) do local m = modList(b[1], b[2]) if m then ex[#ex + 1] = { type = 'submenu', label = b[2], submenu = m } end end
        if #ex > 0 then items[#items + 1] = { type = 'submenu', label = "Benny's (intérieur et détails)", icon = 'sliders', submenu = { id = 'mech.extra', title = "Benny's", items = ex } } end
        local perf = {}
        for _, p in ipairs(PERF) do local m = modList(p[1], p[2]) if m then perf[#perf + 1] = { type = 'submenu', label = p[2], submenu = m } end end
        perf[#perf + 1] = { type = 'submenu', label = 'Turbo', submenu = optList('turbo', 'Turbo', 'turbo', { { label = 'Sans turbo', v = false }, { label = 'Turbo installé', v = true } }, 'turbo') }
        items[#items + 1] = { type = 'submenu', label = 'Performances', icon = 'engine', submenu = { id = 'mech.perf', title = 'Performances', items = perf } }
        local nl = {}
        for _, c in ipairs(RGB) do nl[#nl + 1] = { label = c[1], v = { c[2], c[3], c[4] } } end
        local xl = {}
        for _, x in ipairs(XENON) do xl[#xl + 1] = { label = x[2], v = x[1] } end
        items[#items + 1] = { type = 'submenu', label = 'Éclairage', icon = 'bolt', submenu = { id = 'mech.lights', title = 'Éclairage', items = {
            { type = 'submenu', label = 'Phares xénon', submenu = optList('xen', 'Phares xénon', 'xenon', { { label = "D'origine", v = false }, { label = 'Xénon', v = true } }, 'xenon') },
            { type = 'submenu', label = 'Couleur des xénons', submenu = optList('xcol', 'Couleur des xénons', 'xcol', xl, 'xcol') },
            { type = 'submenu', label = 'Néons', submenu = optList('neon', 'Néons', 'neon', { { label = 'Aucun', v = { false, false, false, false } }, { label = 'Tout autour', v = { true, true, true, true } },
                { label = 'Côtés', v = { true, true, false, false } }, { label = 'Avant et arrière', v = { false, false, true, true } } }, 'neon') },
            { type = 'submenu', label = 'Couleur des néons', submenu = optList('ncol', 'Couleur des néons', 'ncol', nl, 'ncol') } } } }
        local tl, pl = {}, {}
        for _, t in ipairs(TINT) do tl[#tl + 1] = { label = t[2], v = t[1] } end
        for _, p in ipairs(PLATES) do pl[#pl + 1] = { label = p[2], v = p[1] } end
        items[#items + 1] = { type = 'submenu', label = 'Vitres teintées', icon = 'eye', submenu = optList('tint', 'Vitres teintées', 'tint', tl, 'tint') }
        items[#items + 1] = { type = 'submenu', label = 'Plaque', icon = 'sliders', submenu = optList('plate', 'Style de plaque', 'plate', pl, 'plate') }
        local horn = modList(14, 'Klaxon')
        if horn then
            -- klaxon : en survolant une option, on l'entend (une seconde) avant de la choisir
            local hover = horn.onHover
            local function honk() if shop and DoesEntityExist(shop.veh) then StartVehicleHorn(shop.veh, 1100, joaat('HELDDOWN'), false) end end
            horn.subtitle = 'Survole pour entendre · Entrée : au devis'
            horn.onHover = function(it, m) hover(it, m) if it and it.val ~= nil then SetTimeout(120, honk) end end
            local open0 = horn.onOpen
            horn.onOpen = function(m) open0(m) SetTimeout(150, honk) end
            for _, it in ipairs(horn.items) do it.description = "On l'entend en le survolant." end
            items[#items + 1] = { type = 'submenu', label = 'Klaxon', icon = 'music', description = "Survole chaque klaxon pour l'entendre.", submenu = horn }
        end
        -- devis
        local cartItems = {}
        for k, e in pairs(shop.cart) do cartItems[#cartItems + 1] = { label = e.txt or e.label, right = 'Retirer', onSelect = function() shop.cart[k] = nil restore() G.Menu.Refresh() end } end
        table.sort(cartItems, function(a, b) return a.label < b.label end)
        if #cartItems == 0 then cartItems[1] = { label = 'Rien au devis pour le moment', disabled = true } end
        items[#items + 1] = { type = 'separator', label = 'Devis' }
        items[#items + 1] = { type = 'submenu', label = 'Voir le devis (' .. cartCount() .. ')', icon = 'sliders', submenu = { id = 'mech.cart', title = 'Devis', subtitle = 'Entrée : retirer une option', refreshOnReturn = true, items = cartItems } }
        items[#items + 1] = { label = 'Valider le devis', icon = 'check', description = 'Le serveur calcule le prix ; ensuite F6 › Envoyer la facture au client.', disabled = cartCount() == 0, onSelect = function()
            local list = {}
            for k, e in pairs(shop.cart) do list[#list + 1] = { k = k, v = e.v, label = e.label } end
            TriggerServerEvent('pb:g:mech:quote', NetworkGetNetworkIdFromEntity(veh), list)
        end }
        items[#items + 1] = { label = 'Tout annuler', icon = 'x', description = "Remet la voiture comme à l'arrivée.", onSelect = function() shop.cart = {} restore() G.Menu.Refresh() end }
        return items
    end
    G.Menu.Open({ id = 'mechanic', title = 'Atelier', subtitle = (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', ''), refreshOnReturn = true, banner = { text = 'Customisation' }, build = build,
        onClose = function() restore() end })
end
RegisterNetEvent('pb:g:mech:ui', function(j) local d = G.decode(j) if d then openShop(d) end end)
RegisterNetEvent('pb:g:mech:quoted', function() if G.Menu.IsOpen() then G.Menu.Refresh() end end)
-- facture refusée : la voiture revient comme avant ; payée : le devis devient l'état de base
RegisterNetEvent('pb:g:mech:revert', function(netId)
    if not shop then return end
    local veh = shop.veh
    if DoesEntityExist(veh) then if not NetworkHasControlOfEntity(veh) then NetworkRequestControlOfEntity(veh) Wait(200) end G.ApplyCustom(veh, shop.base) end
    shop.cart = {}
end)
RegisterNetEvent('pb:g:mech:keep', function() if shop then shop.base = merged() shop.cart = {} end end)

-- Réparer / nettoyer (menu F6) : véhicule le plus proche, animation, le serveur vérifie la durée
local function closestVeh(r)
    local ped = PlayerPedId()
    local v = GetVehiclePedIsIn(ped, false)
    if v ~= 0 then return v end
    local c = GetEntityCoords(ped)
    v = GetClosestVehicle(c.x, c.y, c.z, r or 5.0, 0, 71)
    return v ~= 0 and v or nil
end
RegisterCommand('pb_mech_repair', function() local v = closestVeh() if not v then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun véhicule à côté.' }) return end TriggerServerEvent('pb:g:mech:start', 'repair', NetworkGetNetworkIdFromEntity(v)) end, false)
RegisterCommand('pb_mech_clean', function() local v = closestVeh() if not v then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun véhicule à côté.' }) return end TriggerServerEvent('pb:g:mech:start', 'clean', NetworkGetNetworkIdFromEntity(v)) end, false)
RegisterNetEvent('pb:g:mech:work', function(j)
    local d = G.decode(j)
    if not d then return end
    CreateThread(function()
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then TaskLeaveAnyVehicle(ped, 0, 0) Wait(1500) end
        local start = GetEntityCoords(ped)
        TaskStartScenarioInPlace(ped, d.kind == 'clean' and 'WORLD_HUMAN_MAID_CLEAN' or 'PROP_HUMAN_BUM_BIN', 0, true)
        G.send('crime.progress', { label = d.kind == 'clean' and 'Nettoyage du véhicule' or 'Réparation du véhicule', secs = d.secs })
        local t = GetGameTimer() + d.secs * 1000
        while GetGameTimer() < t do
            Wait(250)
            if #(GetEntityCoords(ped) - start) > 3.0 or IsEntityDead(ped) then ClearPedTasks(ped) G.send('crime.progress', { cancel = true }) G.send('notify', { type = 'warn', title = 'Atelier', text = 'Travail interrompu.' }) return end
        end
        ClearPedTasks(ped)
        TriggerServerEvent('pb:g:mech:done')
    end)
end)
-- Facture : choix du client parmi les joueurs proches
RegisterCommand('pb_mech_bill', function()
    local me = GetEntityCoords(PlayerPedId())
    local items = {}
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= PlayerPedId() and #(GetEntityCoords(ped) - me) < 8.0 then
            local sid = GetPlayerServerId(pid)
            items[#items + 1] = { label = 'Client à ' .. math.floor(#(GetEntityCoords(ped) - me) + 0.5) .. ' m', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:mech:bill', sid) end }
        end
    end
    if #items == 0 then G.send('notify', { type = 'warn', title = 'Atelier', text = 'Aucun client à côté de toi.' }) return end
    G.Menu.Open({ id = 'mech.bill', title = 'Envoyer la facture', subtitle = 'Choisis le client', items = items })
end, false)
-- Le client reçoit la facture : payer ou refuser
RegisterNetEvent('pb:g:mech:offer', function(j)
    local d = G.decode(j)
    if not d then return end
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    local items = {}
    for _, it in ipairs(d.items or {}) do items[#items + 1] = { label = it.label, right = money(it.price), disabled = true } end
    items[#items + 1] = { type = 'separator', label = 'Total : ' .. money(d.amount) }
    items[#items + 1] = { label = 'Payer ' .. money(d.amount), icon = 'check', description = 'Banque d\'abord, sinon espèces.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:mech:answer', d.id, true) end }
    items[#items + 1] = { label = 'Refuser', icon = 'x', description = 'La customisation est retirée du véhicule.', onSelect = function() G.Menu.Close() TriggerServerEvent('pb:g:mech:answer', d.id, false) end }
    G.Menu.Open({ id = 'mech.offer', title = tostring(d.biz or 'Garage'), subtitle = 'Facture de ' .. tostring(d.from or ''), banner = { text = 'Facture' }, items = items })
end)


RegisterNetEvent('pb:g:mech:do', function(j)
    local d = G.decode(j)
    if not d then return end
    local veh = NetworkGetEntityFromNetworkId(d.netId or 0)
    if not veh or veh == 0 or not DoesEntityExist(veh) then veh = nearestVeh() end
    if not veh or not grab(veh) then G.send('notify', { type = 'error', title = 'Atelier', text = 'Impossible de travailler sur ce véhicule.' }) return end
    if d.kind == 'clean' then SetVehicleDirtLevel(veh, 0.0) WashDecalsFromVehicle(veh, 1.0)
    elseif d.kind == 'repair' then
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleBodyHealth(veh, 1000.0) SetVehiclePetrolTankHealth(veh, 1000.0) SetVehicleDirtLevel(veh, 0.0)
    else G.ApplyPart(veh, d.kind, d.mod, d.level) end
end)
