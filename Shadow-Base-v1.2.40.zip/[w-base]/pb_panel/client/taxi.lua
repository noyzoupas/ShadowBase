-- Taxi : repère des courses pour les chauffeurs, taximètre à l'écran (chauffeur et passagers). Le serveur mesure et facture.
local G = PBG
local pings = {}
RegisterNetEvent('pb:g:taxi:ping', function(j)
    local d = G.decode(j)
    if not d or not tonumber(d.x) then return end
    if pings[d.id] and DoesBlipExist(pings[d.id]) then RemoveBlip(pings[d.id]) end
    local b = AddBlipForCoord(d.x + 0.0, d.y + 0.0, (d.z or 0) + 0.0)
    SetBlipSprite(b, 280) SetBlipColour(b, 5) SetBlipScale(b, 0.9) SetBlipFlashes(b, true)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Client taxi : ' .. tostring(d.name or '')) EndTextCommandSetBlipName(b)
    pings[d.id] = b
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    local id = d.id
    SetTimeout(600000, function() if pings[id] == b then if DoesBlipExist(b) then RemoveBlip(b) end pings[id] = nil end end)
end)
RegisterNetEvent('pb:g:taxi:clear', function(id)
    local b = pings[id]
    if b and DoesBlipExist(b) then RemoveBlip(b) end
    pings[id] = nil
end)
RegisterNetEvent('pb:g:taxi:meter', function(j)
    local d = G.decode(j)
    if d then G.send('taxi.meter', d) end
end)
