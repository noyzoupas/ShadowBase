-- Largages et chasses au trésor : zone sur la carte, caisse posée au sol (largage), E pour ouvrir / creuser. Le serveur décide du gagnant.
local G = PBG
local ev, zoneBlip, crateBlip, crate = nil, nil, nil, nil
local busy = false
local function clear()
    if zoneBlip and DoesBlipExist(zoneBlip) then RemoveBlip(zoneBlip) end
    if crateBlip and DoesBlipExist(crateBlip) then RemoveBlip(crateBlip) end
    if crate and DoesEntityExist(crate) then DeleteEntity(crate) end
    zoneBlip, crateBlip, crate = nil, nil, nil
end
RegisterNetEvent('pb:g:wev', function(j)
    local d = G.decode(j)
    clear()
    ev = d and d.on and d or nil
    if not ev then return end
    zoneBlip = AddBlipForRadius(ev.zx + 0.0, ev.zy + 0.0, 0.0, (ev.r or 200) + 0.0)
    SetBlipColour(zoneBlip, ev.kind == 'airdrop' and 1 or 46) SetBlipAlpha(zoneBlip, 90) SetBlipFlashes(zoneBlip, true)
    if ev.crate then
        crateBlip = AddBlipForCoord(ev.crate.x + 0.0, ev.crate.y + 0.0, ev.crate.z + 0.0)
        SetBlipSprite(crateBlip, 478) SetBlipColour(crateBlip, 1) SetBlipScale(crateBlip, 1.0)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName('Caisse du largage') EndTextCommandSetBlipName(crateBlip)
    end
end)
-- caisse : posée au sol quand on approche (objet local, chaque joueur la voit au même endroit)
CreateThread(function()
    while true do
        if ev and ev.crate and not crate then
            local me = GetEntityCoords(PlayerPedId())
            if #(me - vector3(ev.crate.x, ev.crate.y, ev.crate.z)) < 200.0 then
                local h = joaat('prop_mil_crate_01')
                RequestModel(h)
                local t = GetGameTimer() + 3000
                while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
                if HasModelLoaded(h) then
                    local gz = G.Ground and G.Ground(ev.crate.x, ev.crate.y, ev.crate.z) or ev.crate.z
                    crate = CreateObjectNoOffset(h, ev.crate.x + 0.0, ev.crate.y + 0.0, gz, false, false, false)
                    FreezeEntityPosition(crate, true)
                    SetModelAsNoLongerNeeded(h)
                end
            end
        end
        Wait(1500)
    end
end)
-- E : ouvrir la caisse / creuser (le serveur dit si c'est le bon endroit)
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil G.send('prompt', { show = false }) end end
    while true do
        local sleep = 1000
        if ev and not busy and G.begun and not G.dead and (G.locked or 0) == 0 then
            local me = GetEntityCoords(PlayerPedId())
            local near
            if ev.crate then near = #(me - vector3(ev.crate.x, ev.crate.y, ev.crate.z)) < 3.0
            elseif ev.kind == 'treasure' then near = #(vector2(me.x, me.y) - vector2(ev.zx, ev.zy)) < (ev.r or 0) + 5.0 and not IsPedInAnyVehicle(PlayerPedId(), false) end
            if near then
                sleep = 0
                if ev.crate then G.Point(ev.crate.x + 0.0, ev.crate.y + 0.0, ev.crate.z - 1.0, 255, 80, 80, 1.0) end
                local key = ev.crate and 'open' or 'dig'
                if shown ~= key then shown = key G.send('prompt', { show = true, key = 'E', text = ev.crate and 'OUVRIR LA CAISSE' or 'CREUSER ICI' }) end
                if IsControlJustReleased(0, 38) then hide() TriggerServerEvent('pb:g:wev:begin') end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)
RegisterNetEvent('pb:g:wev:progress', function(secs)
    busy = true
    CreateThread(function()
        local ped = PlayerPedId()
        local start = GetEntityCoords(ped)
        TaskStartScenarioInPlace(ped, ev and ev.kind == 'treasure' and 'WORLD_HUMAN_GARDENER_PLANT' or 'PROP_HUMAN_BUM_BIN', 0, true)
        G.send('crime.progress', { label = (ev and ev.kind == 'treasure') and 'Tu creuses…' or 'Tu ouvres la caisse…', secs = secs })
        local t = GetGameTimer() + secs * 1000
        local ok = true
        while GetGameTimer() < t do
            Wait(200)
            if #(GetEntityCoords(ped) - start) > 2.0 or IsEntityDead(ped) then ok = false break end
        end
        ClearPedTasks(ped)
        if ok then TriggerServerEvent('pb:g:wev:done') else G.send('crime.progress', { cancel = true }) TriggerServerEvent('pb:g:wev:cancel') end
        busy = false
    end)
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then clear() end end)
