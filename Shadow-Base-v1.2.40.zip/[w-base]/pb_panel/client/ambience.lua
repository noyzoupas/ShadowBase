-- Musique des magasins coupée : les radios des intérieurs de GTA (vêtements, supérettes, Ammu-Nation, coiffeurs, tatoueurs,
-- concession, garages de customisation) se taisent quand le joueur est dedans. Réglage : panel (ambience.mute_shop_music).
-- Les noms viennent de la liste des émetteurs sonores extraite du jeu (gta-v-data-dumps, staticEmitters.json).
local G = PBG
-- émetteurs nommés : coupés une fois pour toutes
local EMITTERS = { 'se_ammunation_paleto', 'se_ammunation_vinewood', 'se_ammunation_east_ls', 'LOS_SANTOS_AMMUNATION_GUN_RANGE', 'SE_AMMUNATION_CYPRESS_FLATS_GUN_RANGE',
    'supermarket_01', 'LOS_SANTOS_ARMENIAN_CAR_DEALERSHIP' }
-- intérieurs « magasin » : les autres radios (sans nom connu) sont coupées tant qu'on est dedans
local SHOPS = {}
for _, n in ipairs({ 'v_clotheslo', 'v_clothesmid', 'v_clotheshi', 'v_shop_247', 'v_gasstation', 'v_gen_liquor', 'v_gun', 'v_gun2', 'v_barbers', 'v_hairdresser',
    'v_tattoo', 'v_tattoo2', 'v_carshowroom', 'v_jewel2', 'v_carmod', 'v_carmod2', 'v_carmod3' }) do
    local k = joaat(n)
    SHOPS[k] = true
    SHOPS[k % 4294967296] = true                                   -- le jeu peut rendre le nombre signé ou non
    SHOPS[k >= 2147483648 and k - 4294967296 or k] = true
end
local SCENE = 'MP_POSITIONED_RADIO_MUTE_SCENE'
local function on() local c = G.cfg and G.cfg.ambience return not c or c.mute_shop_music ~= false end
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not (G.cfg and G.cfg.ambience) and GetGameTimer() < t do Wait(500) end
    local applied, inScene = nil, false
    while true do
        local want = on()
        if want ~= applied then
            applied = want
            for _, e in ipairs(EMITTERS) do SetStaticEmitterEnabled(e, not want) end
        end
        local inShop = false
        if want then
            local int = GetInteriorFromEntity(PlayerPedId())
            if int ~= 0 then
                local _, hash = GetInteriorLocationAndNamehash(int)
                inShop = SHOPS[hash] == true
            end
        end
        if inShop and not inScene then StartAudioScene(SCENE) inScene = true
        elseif not inShop and inScene then StopAudioScene(SCENE) inScene = false end
        Wait(inShop and 500 or 1000)
    end
end)
AddEventHandler('onResourceStop', function(r)
    if r ~= GetCurrentResourceName() then return end
    StopAudioScene(SCENE)
    for _, e in ipairs(EMITTERS) do SetStaticEmitterEnabled(e, true) end
end)
