-- Carte rapide (touche M) : la mini-carte du jeu s'agrandit en bas à gauche, un panneau à côté liste les destinations (serveur).
-- Pas de souris : on continue de marcher ou de conduire. ↑ ↓ choisir, Entrée GPS, Suppr effacer le GPS, ← → (ou Page ↑ / ↓) zoom,
-- M fermer, Échap : carte plein écran du jeu.
local G = PBG
local open, sel, count, zoom = false, 1, 0, 1
local ZOOMS = { 0, 350, 800, 1300 }   -- niveaux de zoom de la mini-carte agrandie
local rows = {}

local function busy() return not G.begun or G.creating or G.wardrobe or (G.state and G.state.dead) or IsPauseMenuActive() or IsNuiFocused() or (G.Menu and G.Menu.IsOpen and G.Menu.IsOpen()) end
local function refreshHud() G.mmAt = 0 end   -- le cadre de la mini-carte est recalculé à la prochaine mise à jour du HUD

local function close()
    if not open then return end
    open = false
    G.qmapOpen, G.bigmap = nil, nil
    SetBigmapActive(false, false)
    SetRadarZoom(0)
    refreshHud()
    G.send('qmap.close', {})
end

local function place()
    -- même calcul que le HUD (client/game.lua), avec la taille de la mini-carte agrandie
    local safe, ar = GetSafeZoneSize(), GetAspectRatio(false)
    local w, hgt = 1.0 / (4.0 * ar) * 1.62, 1.0 / 5.674 * 2.2
    local left, bottom = 0.05 * (math.abs(safe - 1.0) * 10), 1.0 - 0.05 * (math.abs(safe - 1.0) * 10)
    return { l = left, b = bottom, w = w, h = hgt }
end

local function openMap()
    if open or busy() then return end
    if G.cfg.minimap and G.cfg.minimap.enabled == false then return end
    open, sel, count = true, 1, 0
    G.qmapOpen, G.bigmap = true, true
    SetBigmapActive(true, false)
    SetRadarZoom(ZOOMS[zoom])
    refreshHud()
    rows = {}
    G.send('qmap.open', { rect = place(), zoom = zoom, zooms = #ZOOMS, wp = IsWaypointActive() or nil })
    TriggerServerEvent('pb:g:map:list')
    CreateThread(function()
        while open do
            Wait(0)
            if busy() then close() break end   -- une autre interface s'ouvre, mort, menu du jeu : on referme
            -- touches du panneau (le reste des commandes reste libre : on peut marcher, conduire)
            DisableControlAction(0, 172, true) DisableControlAction(0, 173, true) DisableControlAction(0, 174, true) DisableControlAction(0, 175, true)
            DisableControlAction(0, 191, true) DisableControlAction(0, 201, true) DisableControlAction(0, 178, true)
            DisableControlAction(0, 199, true) DisableControlAction(0, 200, true) DisableControlAction(0, 10, true) DisableControlAction(0, 11, true)
            if IsDisabledControlJustPressed(0, 172) and count > 0 then sel = sel > 1 and sel - 1 or count G.send('qmap.sel', { i = sel }) G.send('ui.click', {}) end
            if IsDisabledControlJustPressed(0, 173) and count > 0 then sel = sel < count and sel + 1 or 1 G.send('qmap.sel', { i = sel }) G.send('ui.click', {}) end
            if IsDisabledControlJustPressed(0, 10) or IsDisabledControlJustPressed(0, 175) then zoom = math.min(#ZOOMS, zoom + 1) SetRadarZoom(ZOOMS[zoom]) G.send('qmap.zoom', { zoom = zoom }) end
            if IsDisabledControlJustPressed(0, 11) or IsDisabledControlJustPressed(0, 174) then zoom = math.max(1, zoom - 1) SetRadarZoom(ZOOMS[zoom]) G.send('qmap.zoom', { zoom = zoom }) end
            if (IsDisabledControlJustPressed(0, 191) or IsDisabledControlJustPressed(0, 201)) and rows[sel] then
                local r = rows[sel]
                SetNewWaypoint(r.x + 0.0, r.y + 0.0)
                G.send('ui.click', {})
                G.send('qmap.wp', { on = true, label = r.label })
                G.send('notify', { type = 'success', title = 'GPS', text = r.label .. ' · ' .. tostring(r.right or '') })
            end
            if IsDisabledControlJustPressed(0, 178) then   -- Suppr : effacer le GPS
                if IsWaypointActive() then SetWaypointOff() G.send('qmap.wp', { on = false }) G.send('ui.click', {}) end
            end
            -- Échap (ou P) : la carte plein écran du jeu
            if IsDisabledControlJustReleased(0, 200) or IsDisabledControlJustReleased(0, 199) then
                close()
                CreateThread(function()
                    Wait(150)
                    pcall(function() ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), false, -1) end)
                    Wait(300)
                    pcall(function() PauseMenuceptionGoDeeper(0) end)
                end)
                break
            end
        end
    end)
end

RegisterNetEvent('pb:g:map:list', function(j)
    local d = G.decode(j)
    if not open or not d then return end
    rows = {}
    for _, s in ipairs(d.sections or {}) do for _, it in ipairs(s.items or {}) do rows[#rows + 1] = it end end
    count, sel = #rows, 1
    G.send('qmap.list', { sections = d.sections or {}, sel = 1 })
end)

local lastToggle = 0
local function toggle()
    local t = GetGameTimer()
    if t - lastToggle < 300 then return end
    lastToggle = t
    if open then close() else openMap() end
end
RegisterCommand('pb_quickmap', toggle, false)
RegisterCommand('carte', toggle, false)
CreateThread(function()
    local t = GetGameTimer() + 15000
    while not G.cfg.minimap and GetGameTimer() < t do Wait(250) end
    local k = (G.cfg.minimap and G.cfg.minimap.key) or 'M'
    if type(k) == 'string' and k ~= '' then RegisterKeyMapping('pb_quickmap', 'Carte rapide (mini-carte agrandie et destinations)', 'keyboard', k) end
end)
G.onForceClose(function() close() end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() and open then SetBigmapActive(false, false) end end)
