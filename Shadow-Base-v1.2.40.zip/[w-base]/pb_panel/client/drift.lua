-- Mode drift (avantage VIP) : /drift l'active ou le coupe (mémorisé sur le poste). Au volant, Maj gauche maintenue fait décrocher l'arrière.
local G = PBG
local on = GetResourceKvpInt('pb_drift') == 1
local gripped = nil   -- véhicule dont l'adhérence est réduite

local function allowed() return G.vip == true and (G.vipPerks or {}).drift ~= false end
local function release()
    if gripped and DoesEntityExist(gripped) then SetVehicleReduceGrip(gripped, false) end
    gripped = nil
end

RegisterCommand('drift', function()
    if not allowed() then G.send('notify', { type = 'warn', title = 'Mode drift', text = 'Réservé aux VIP.' }) return end
    on = not on
    SetResourceKvpInt('pb_drift', on and 1 or 0)
    if not on then release() end
    G.send('notify', { type = on and 'success' or 'info', title = 'Mode drift', text = on and 'Activé : maintiens Maj gauche au volant pour drifter.' or 'Désactivé.' })
end, false)
G.DriftOn = function() return on and allowed() end

CreateThread(function()
    while true do
        if not on or not allowed() then release() Wait(1000)
        else
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh == 0 or GetPedInVehicleSeat(veh, -1) ~= ped or not IsThisModelACar(GetEntityModel(veh)) then release() Wait(500)
            else
                local want = IsControlPressed(0, 21)   -- Maj gauche
                if want and gripped ~= veh then release() SetVehicleReduceGrip(veh, true) gripped = veh
                elseif not want and gripped then release() end
                Wait(0)
            end
        end
    end
end)
AddEventHandler('onResourceStop', function(r) if r == GetCurrentResourceName() then release() end end)
