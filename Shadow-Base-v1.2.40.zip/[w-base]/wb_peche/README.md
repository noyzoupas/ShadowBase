# wb_peche — pêche (extension Shadow Base)

Une vraie pêche : raretés de poissons, raretés de leurres, cannes, ferrage, marché aux prix variables et records du serveur.
Extension de `pb_panel` : redémarrable seule (`restart wb_peche`). Réglages : **panel › Extensions › Pêche**.

## Côté joueur
1. Achète une canne et des appâts au **magasin de pêche**.
2. Place-toi **face à l'eau** (ou dans un bateau) et **utilise la canne** depuis l'inventaire.
3. Choisis l'appât, attends la touche (**X** pour remonter la ligne).
4. Ça mord : appuie sur **E** quand le curseur passe dans la **zone verte**. Plus le poisson est rare, plus il faut de coups et plus la zone est petite. Trop de ratés : la ligne casse.
5. Revends au **marché aux poissons**.

## Eaux et poissons (27 espèces + trouvailles)
| Rareté | Mer (côte) | Large (bateau) | Lac | Rivière |
|---|---|---|---|---|
| Commun | sardine, maquereau | bonite | gardon, perche | goujon, truite |
| Peu commun | dorade, bar | coryphène | carpe, sandre | ombre |
| Rare | calamar, homard | thon rouge | brochet | anguille, saumon sauvage |
| Épique | raie manta | espadon, marlin bleu | silure | — |
| Légendaire | cœlacanthe | requin-tigre | esturgeon | poisson-chat albinos |

Trouvailles possibles partout : vieille botte, bouteille à la mer, **coffre englouti**, **leurre doré**.
Le lac : Alamo Sea, réservoir de Land Act, lac de Mirror Park. Le large : en bateau, loin des côtes (eau profonde).

## Leurres et cannes
| Appât / leurre | Rareté | Effet |
|---|---|---|
| Vers de terre | Commun | de base, consommé à chaque prise |
| Crevettes | Peu commun | plus de poissons peu communs et rares, idéal en mer |
| Cuillère tournante | Rare | nettement plus de rares, parfois perdue |
| Poisson nageur | Épique | rares et épiques bien plus fréquents, idéal au large |
| Leurre doré | Légendaire | introuvable en boutique ; meilleures chances de légendaire |

Cannes : **canne à pêche** (de base), **canne renforcée** (ferrage plus facile, un peu plus de chance), **canne carbone** (la meilleure). La meilleure canne du sac est utilisée.

## Marché vivant
- Chaque vente fait **baisser le cours** de l'espèce vendue (plus fort pour les espèces rares) ; vendre beaucoup d'un coup rapporte donc de moins en moins.
- Le cours **remonte tout seul** toutes les 5 minutes, avec un peu de hasard.
- La **pêche du jour** (une espèce commune à rare) est mieux payée (+50 %) et change toutes les 3 heures.
- Cours, prix plancher, vitesse de remontée et bonus : panel, onglets **Marché** et **Réglages**.

## Poser les points
Menu staff **F10 › Builder › Pêche** : marché aux poissons, magasin de pêche, « supprimer le point le plus proche ».
Les zones de pêche de **wb_activites** continuent de fonctionner.

## Évènement serveur
`wb_peche:caught` (src, objet, kg, rareté)

## VIP : pêche automatique
Un joueur VIP lance sa canne comme d'habitude : chaque touche est ferrée automatiquement et la ligne est relancée toute seule avec le même appât, jusqu'à ce qu'il appuie sur X, bouge, n'ait plus d'appât ou que son sac soit plein. Le ferrage automatique est décidé par le serveur au lancer. Réglage : panel › VIP › Avantages › « Pêche automatique pour les VIP ».
