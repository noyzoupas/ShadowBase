-- Shadow Base — Activités (client) : icônes, cercle au sol autour des zones, invite E, animation + objet en main, barre, menus grossiste / établi.
-- Le serveur valide tout ; ici on affiche et on prévient le serveur.
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {} }
local blips = {}
local active = nil

local function clearBlips() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end blips = {} end
RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    clearBlips()
    if not C.enabled or not C.blips then return end
    for _, s in ipairs(C.spots or {}) do
        if (s.sprite or 0) > 0 then
            local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
            SetBlipSprite(b, s.sprite) SetBlipColour(b, s.color or 0) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
            blips[#blips + 1] = b
        end
    end
end)

-- Réinitialisation des repères (/blips reset ou panel) : on efface les nôtres et on redemande la liste
AddEventHandler('pb:blips:reset', function() clearBlips() TriggerServerEvent(RES .. ':hello') end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(2000)
    TriggerServerEvent(RES .. ':hello')
end)

-- Marqueur et « libre ? » en local : appeler un export de pb_panel à chaque image coûte cher (appel entre ressources)
local function marker(x, y, z)
    -- petit point lumineux à hauteur de poitrine (même rendu que Shadow Base)
    local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
    DrawMarker(28, x + 0.0, y + 0.0, z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
    DrawMarker(28, x + 0.0, y + 0.0, z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local freeCache, freeAt = false, 0
local function isFree()
    local now = GetGameTimer()
    if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end
    return freeCache
end
local VERB = { harvest = 'Récolter', process = 'Transformer', sell = 'Vendre', bench = 'Fabriquer' }
local function dist2(c, s) local dx, dy = c.x - s.x, c.y - s.y return math.sqrt(dx * dx + dy * dy) end

-- Zone la plus proche : cercle au sol (grandes zones) ou marqueur (petits points), invite E quand on est dedans --------------------------------------------
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if C.enabled and not active and isFree() then
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            local best, bd
            for _, s in ipairs(C.spots or {}) do
                if math.abs(c.z - s.z) < 25.0 then
                    local d = dist2(c, s) - (s.r or 3)          -- distance au bord de la zone
                    if not bd or d < bd then best, bd = s, d end
                end
            end
            if best and bd < 50.0 then sleep = 250 end
            if best and bd < 35.0 then
                sleep = 0
                local r = best.r or 3
                if C.markers then
                    if r > 4 then DrawMarker(1, best.x, best.y, best.z - 1.2, 0, 0, 0, 0, 0, 0, r * 2.0, r * 2.0, 0.8, 223, 226, 231, 45, false, false, 2, false, nil, nil, false)
                    else marker(best.x, best.y, best.z - 0.95) end
                end
                local reach = r > 4 and r or math.max(r, C.use_dist or 2.5)
                if dist2(c, best) <= reach and GetVehiclePedIsIn(ped, false) == 0 then
                    if shown ~= best.id then shown = best.id W:Prompt((VERB[best.kind] or 'Utiliser') .. ' : ' .. best.label, 'E', r <= 4 and best.x or nil, best.y, best.z) end
                    if IsControlJustPressed(0, 38) then
                        hide()
                        if best.kind == 'sell' or best.kind == 'bench' then TriggerServerEvent(RES .. ':menu', best.id)
                        else TriggerServerEvent(RES .. ':start', 'spot', best.id) end
                        Wait(500)
                    end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)

-- Animation : scénario GTA, ou « dictionnaire|animation » en boucle ; objet tenu dans la main droite ----------------------------------------------------------
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end
local function attachProp(ped, model)
    local h = joaat(model)
    if not IsModelInCdimage(h) then return nil end
    RequestModel(h)
    local t = GetGameTimer() + 2000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(10) end
    if not HasModelLoaded(h) then return nil end
    local c = GetEntityCoords(ped)
    local obj = CreateObject(h, c.x, c.y, c.z + 0.2, false, false, false)
    AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 57005), 0.1, 0.0, -0.02, -80.0, 0.0, 0.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(h)
    return obj
end
local function startAnim(ped, anim)
    anim = tostring(anim or '')
    if anim == '' then return end
    local dict, clip = anim:match('^([^|]+)|(.+)$')
    if dict then
        if loadDict(dict) then TaskPlayAnim(ped, dict, clip, 3.0, 3.0, -1, 1, 0, false, false, false) end
    else
        TaskStartScenarioInPlace(ped, anim, 0, true)
    end
end

RegisterNetEvent(RES .. ':go', function(j)
    local ok, d = pcall(json.decode, j)
    if not ok or type(d) ~= 'table' or active then return end
    active = d
    local ped = PlayerPedId()
    startAnim(ped, d.anim)
    local prop = (d.prop or '') ~= '' and attachProp(ped, d.prop) or nil
    W:Progress(d.label, d.secs)
    local stop = GetGameTimer() + math.floor(d.secs * 1000)
    local cancelled = false
    local zone = { x = d.x, y = d.y }
    while GetGameTimer() < stop do
        Wait(0)
        DisableControlAction(0, 24, true) DisableControlAction(0, 25, true)   -- pas de tir pendant l'activité
        local c = GetEntityCoords(ped)
        if dist2(c, zone) > (d.r or 3) + 3.0 or IsPedInAnyVehicle(ped, false) or IsEntityDead(ped) or IsControlJustPressed(0, 73) then cancelled = true break end
    end
    ClearPedTasks(ped)
    if prop and DoesEntityExist(prop) then DeleteEntity(prop) end
    active = nil
    if cancelled then
        W:CancelProgress()
        TriggerServerEvent(RES .. ':cancel')
        W:Notify({ type = 'warn', title = 'Activités', text = 'Action annulée.' })
    else
        TriggerServerEvent(RES .. ':finish')
    end
end)

-- Menus (style des menus Shadow Base) -----------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent(RES .. ':menu', function(id, kind, title, j)
    local ok, list = pcall(json.decode, j)
    if not ok or type(list) ~= 'table' then return end
    local items = {}
    if kind == 'sell' then
        for _, it in ipairs(list) do
            items[#items + 1] = { label = it.label, right = ('%d × $%d'):format(it.count, it.price), description = ('Tout vendre : $%d'):format(it.count * it.price),
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':sell', id, it.item) end }
        end
        if #items == 0 then items[1] = { label = 'Rien à vendre ici', description = "Le grossiste n'achète que les produits des activités.", disabled = true } end
        W:OpenMenu({ id = RES .. '.sell', title = title, subtitle = 'Revente', items = items })
    else
        for _, r in ipairs(list) do
            items[#items + 1] = { label = r.label, right = (r.qty > 1 and ('×' .. r.qty .. ' · ') or '') .. r.time .. ' s', description = r.need, disabled = (not r.can) or nil,
                onSelect = function() W:CloseMenu() TriggerServerEvent(RES .. ':start', 'craft', id, r.id) end }
        end
        if #items == 0 then items[1] = { label = 'Aucune recette', disabled = true } end
        W:OpenMenu({ id = RES .. '.bench', title = title, subtitle = 'Fabrication', items = items })
    end
end)

AddEventHandler('onClientResourceStop', function(res)
    if res ~= RES then return end
    clearBlips()
    if active then ClearPedTasks(PlayerPedId()) W:CancelProgress() end
end)
