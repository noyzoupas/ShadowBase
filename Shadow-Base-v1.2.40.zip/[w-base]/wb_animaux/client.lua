-- Shadow Base — Animaux de compagnie (client) : animalerie, /animal (appeler, renvoyer, assis, couché, suivre / rester, renommer).
local W = exports.pb_panel
local RES = GetCurrentResourceName()
local C = { enabled = false, spots = {} }
local blips = {}
local mine        -- { model, name, kind }
local pet         -- ped de l'animal
local mode = 'follow'

local function notify(kind, text) W:Notify({ type = kind, title = 'Animaux', text = text }) end
local function marker(x, y, z)
    -- petit point lumineux à hauteur de poitrine (même rendu que Shadow Base)
    local s = 0.06 + 0.008 * math.sin(GetGameTimer() / 333.0)
    DrawMarker(28, x + 0.0, y + 0.0, z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s * 2.2, s * 2.2, s * 2.2, 255, 255, 255, 40, false, false, 2, false, nil, nil, false)
    DrawMarker(28, x + 0.0, y + 0.0, z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, s, s, s, 255, 255, 255, 235, false, false, 2, false, nil, nil, false)
end
local freeCache, freeAt = false, 0
local function isFree() local now = GetGameTimer() if now >= freeAt then freeAt = now + 300 freeCache = W:IsFree() end return freeCache end
local function loadDict(d) RequestAnimDict(d) local t = GetGameTimer() + 2000 while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(10) end return HasAnimDictLoaded(d) end

RegisterNetEvent(RES .. ':cfg', function(j)
    local ok, c = pcall(json.decode, j)
    if not ok or type(c) ~= 'table' then return end
    C = c
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    if not C.enabled or not C.blips then return end
    for _, s in ipairs(C.spots or {}) do
        local b = AddBlipForCoord(s.x + 0.0, s.y + 0.0, s.z + 0.0)
        SetBlipSprite(b, 273) SetBlipColour(b, 0) SetBlipScale(b, 0.75) SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(tostring(s.label)) EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end)
-- Réinitialisation des repères (/blips reset ou panel) : on efface les nôtres et on redemande la liste
AddEventHandler('pb:blips:reset', function()
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    TriggerServerEvent(RES .. ':hello')
end)
RegisterNetEvent(RES .. ':mine', function(j) mine = j and json.decode(j) or nil end)
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(500) end
    Wait(3000)
    TriggerServerEvent(RES .. ':hello')
end)

-- L'animal ---------------------------------------------------------------------------------------------------------------------------------------------------------
local petBlip
local function dismiss()
    if petBlip and DoesBlipExist(petBlip) then RemoveBlip(petBlip) end
    petBlip = nil
    if pet and DoesEntityExist(pet) then SetEntityAsMissionEntity(pet, true, true) DeleteEntity(pet) end
    pet = nil
end
local function follow()
    if not (pet and DoesEntityExist(pet)) then return end
    ClearPedTasks(pet)
    TaskFollowToOffsetOfEntity(pet, PlayerPedId(), 0.6, -1.0, 0.0, 5.0, -1, 1.5, true)
    mode = 'follow'
end
local function call()
    if not mine then notify('info', "Tu n'as pas d'animal.") return end
    if pet and DoesEntityExist(pet) then follow() return end
    local h = joaat(mine.model)
    RequestModel(h)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(h) and GetGameTimer() < t do Wait(20) end
    if not HasModelLoaded(h) then notify('error', 'Modèle introuvable.') return end
    local me = PlayerPedId()
    local c = GetOffsetFromEntityInWorldCoords(me, 1.0, -1.5, 0.0)
    pet = CreatePed(28, h, c.x, c.y, c.z, GetEntityHeading(me), true, true)
    SetModelAsNoLongerNeeded(h)
    SetEntityAsMissionEntity(pet, true, true)
    SetBlockingOfNonTemporaryEvents(pet, true)
    SetPedFleeAttributes(pet, 0, false)
    SetEntityInvincible(pet, true)
    SetPedCanBeTargetted(pet, false)
    if petBlip and DoesBlipExist(petBlip) then RemoveBlip(petBlip) end
    local b = AddBlipForEntity(pet)
    petBlip = b
    SetBlipSprite(b, 923) SetBlipScale(b, 0.6) SetBlipColour(b, 0)
    BeginTextCommandSetBlipName('STRING') AddTextComponentSubstringPlayerName(mine.name or 'Animal') EndTextCommandSetBlipName(b)
    follow()
end
local SIT = { big = { 'creatures@rottweiler@amb@world_dog_sitting@base', 'base' }, small = { 'creatures@pug@amb@world_dog_sitting@base', 'base' }, cat = { 'creatures@cat@amb@world_cat_sleeping_ground@base', 'base' } }
local LAY = { big = { 'creatures@rottweiler@amb@sleep_in_kennel@', 'sleep_in_kennel' }, small = { 'creatures@pug@amb@world_dog_sitting@base', 'base' }, cat = { 'creatures@cat@amb@world_cat_sleeping_ground@base', 'base' } }
local function pose(set)
    if not (pet and DoesEntityExist(pet)) then return end
    local a = set[(mine and mine.kind) or 'big'] or set.big
    ClearPedTasks(pet)
    if loadDict(a[1]) then TaskPlayAnim(pet, a[1], a[2], 8.0, -8.0, -1, 1, 0, false, false, false) end
    mode = 'stay'
end
local function stay() if pet and DoesEntityExist(pet) then ClearPedTasks(pet) TaskStandStill(pet, -1) mode = 'stay' end end

RegisterNetEvent(RES .. ':dismiss', function() dismiss() end)
RegisterNetEvent(RES .. ':open', function(j)
    local d = json.decode(j or '{}') or {}
    mine = d
    local out = pet and DoesEntityExist(pet)
    local items = {
        { label = out and 'Revenir près de moi' or 'Appeler ' .. (d.name or 'mon animal'), icon = 'user', onSelect = function() W:CloseMenu() call() end },
        { label = 'Assis', icon = 'star', disabled = (not out) or nil, onSelect = function() pose(SIT) end },
        { label = 'Couché', icon = 'bed', disabled = (not out) or nil, onSelect = function() pose(LAY) end },
        { label = mode == 'follow' and 'Rester ici' or 'Me suivre', icon = 'gps', disabled = (not out) or nil, onSelect = function() if mode == 'follow' then stay() else follow() end W:CloseMenu() end },
        { label = 'Renommer', icon = 'edit', onSelect = function()
            W:CloseMenu()
            AddTextEntry('PB_PET_NAME', 'Nouveau nom')
            DisplayOnscreenKeyboard(1, 'PB_PET_NAME', '', d.name or '', '', '', '', 24)
            while UpdateOnscreenKeyboard() == 0 do Wait(0) end
            local v = GetOnscreenKeyboardResult()
            if v and #v >= 2 then TriggerServerEvent(RES .. ':rename', v) end
        end },
        { label = 'Renvoyer à la maison', icon = 'home', disabled = (not out) or nil, onSelect = function() W:CloseMenu() dismiss() end },
    }
    W:OpenMenu({ id = RES .. '.pet', title = d.name or 'Mon animal', subtitle = 'Animal de compagnie', items = items })
end)
RegisterCommand('animal', function() TriggerServerEvent(RES .. ':menu') end, false)

-- l'animal suit dans les véhicules : il monte avec toi, il redescend avec toi
CreateThread(function()
    local inVeh = false
    while true do
        Wait(1000)
        if pet and DoesEntityExist(pet) and mode == 'follow' then
            local me = PlayerPedId()
            local v = GetVehiclePedIsIn(me, false)
            if v ~= 0 and not inVeh then
                for seat = 0, GetVehicleMaxNumberOfPassengers(v) - 1 do if IsVehicleSeatFree(v, seat) then SetPedIntoVehicle(pet, v, seat) break end end
                inVeh = true
            elseif v == 0 and inVeh then
                inVeh = false
                local c = GetOffsetFromEntityInWorldCoords(me, 1.0, -1.0, 0.0)
                SetEntityCoords(pet, c.x, c.y, c.z, false, false, false, false)
                follow()
            elseif v == 0 and #(GetEntityCoords(pet) - GetEntityCoords(me)) > 60.0 then
                local c = GetOffsetFromEntityInWorldCoords(me, 1.0, -1.0, 0.0)
                SetEntityCoords(pet, c.x, c.y, c.z, false, false, false, false)
                follow()
            end
        end
    end
end)

-- Animalerie
CreateThread(function()
    local shown
    local function hide() if shown then shown = nil W:HidePrompt() end end
    while true do
        local sleep = 800
        if C.enabled and #(C.spots or {}) > 0 and isFree() then
            local c = GetEntityCoords(PlayerPedId())
            local best, bd
            for _, s in ipairs(C.spots) do local d = #(c - vector3(s.x, s.y, s.z)) if not bd or d < bd then best, bd = s, d end end
            if best and bd < 25.0 then
                sleep = 0
                marker(best.x, best.y, best.z - 0.95)
                if bd < 2.5 then
                    if shown ~= best.id then shown = best.id W:Prompt('Animalerie : ' .. best.label, 'E', best.x, best.y, best.z) end
                    if IsControlJustPressed(0, 38) then hide() TriggerServerEvent(RES .. ':shop', best.id) Wait(500) end
                else hide() end
            else hide() end
        else hide() end
        Wait(sleep)
    end
end)
RegisterNetEvent(RES .. ':shopmenu', function(id, title, j, current)
    local list = json.decode(j or '[]') or {}
    local items = {}
    if current then items[#items + 1] = { label = 'Ton animal : ' .. current, description = 'En acheter un autre le remplace.', disabled = true } end
    for _, p in ipairs(list) do
        items[#items + 1] = { label = p.label, right = '$' .. p.price, description = 'Payé par la banque. Nom au choix.', onSelect = function()
            W:CloseMenu()
            AddTextEntry('PB_PET_NAME', 'Son nom')
            DisplayOnscreenKeyboard(1, 'PB_PET_NAME', '', '', '', '', '', 24)
            while UpdateOnscreenKeyboard() == 0 do Wait(0) end
            local name = GetOnscreenKeyboardResult() or ''
            TriggerServerEvent(RES .. ':buy', id, p.model, name)
        end }
    end
    W:OpenMenu({ id = RES .. '.shop', title = title, subtitle = 'Animalerie (VIP)', items = items })
end)

AddEventHandler('onClientResourceStop', function(r) if r == RES then dismiss() for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end end end)
