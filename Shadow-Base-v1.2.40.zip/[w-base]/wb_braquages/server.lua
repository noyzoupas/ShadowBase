-- Shadow Base — Braquages et trafics (serveur).
--   Cambriolages : maisons posées au Builder ; crochetage (crochet), fouille de la maison, alerte possible du voisinage, butin revendu au receleur.
--   Receleur : point caché (pas de blip) posé au Builder ; rachète le butin.
--   Distributeurs : les distributeurs de la banque se forcent à la perceuse (vendue par le receleur).
--   GoFast : points de départ cachés à trouver en RP ; une voiture chargée à livrer à un point d'arrivée avant la fin du temps, la police suit sa trace.
--   Fourgons blindés : un fourgon apparaît régulièrement ; charge thermique à l'arrière, puis on ramasse les sacs.
-- Tout est payé en argent sale (objet « black_money » si présent). Le serveur vérifie distances, délais, objets et temps de recharge.

local W = exports.pb_panel
local RES = GetCurrentResourceName()
local NS = RES
local PERM = RES .. '.edit'

local cache = {}
local function cfg(k, d) local v = cache[k] if v == nil then v = W:CfgGet(NS, k, d) cache[k] = v end if v == nil then return d end return v end
local function notify(src, kind, text) W:NotifyPlayer(src, kind, 'Illégal', text) end
local function pos(src) local ped = GetPlayerPed(src) if not ped or ped == 0 then return nil end return GetEntityCoords(ped) end
local function dist(src, x, y, z) local c = pos(src) if not c then return 9999 end return #(c - vector3(x + 0.0, y + 0.0, z + 0.0)) end
local function find(list, id) for _, x in ipairs(list or {}) do if x.id == id then return x end end end
local function now() return os.time() end
local function label(item) local i = W:ItemInfo(item) return i and i.label or item end
local function police() local ok, n = pcall(function() return W:CountPolice() end) return ok and tonumber(n) or 0 end
local function alert(text, x, y, z) pcall(function() W:PoliceAlert(text, x, y, z) end) end
local function payDirty(src, amount, why)
    amount = math.floor(amount)
    if amount <= 0 then return end
    if W:ItemInfo('black_money') and W:CanCarryItem(src, 'black_money', amount) then W:AddItem(src, 'black_money', amount) return 'sale' end
    W:AddMoney(src, 'cash', amount, why) return 'espèces'
end
local function busyOk(src) return W:CanAct(src) end
HIDDEN = { fence = true, gofast_start = true, truck = true }

local useDrill
-- Réglages, page du panel -----------------------------------------------------------------------------------------------------------------------------
local function setup()
    W:ExtRegister({ label = 'Braquages et trafics', version = GetResourceMetadata(RES, 'version', 0) })
    W:ExtPerm(PERM, 'Modifier les braquages et trafics', true)
    for _, b in ipairs(BURGLARY_LOOT) do W:EnsureItem({ name = b.name, label = b.label, weight = 800, stack = 20, kind = 'misc', usable = false, description = 'Butin volé : se revend au receleur.' }) end
    for _, t in ipairs(TOOLS) do W:EnsureItem({ name = t.name, label = t.label, weight = 1500, stack = 5, kind = 'tool', usable = t.name == 'perceuse', description = t.desc }) end
    W:RegisterUsable('perceuse', function(src) return useDrill(src) end)
    local main = W:ExtSettings({ ns = NS, id = 'main', title = 'Réglages', perm = PERM, cols = 2, fields = {
        { k = 'enabled', type = 'toggle', label = 'Braquages et trafics actifs', default = true },
        { k = 'house_cooldown', type = 'number', label = 'Cambriolage : délai avant de revisiter la même maison (min)', default = 120, min = 5, max = 10080 },
        { k = 'house_police', type = 'number', label = 'Cambriolage : policiers en service minimum', default = 0, min = 0, max = 20 },
        { k = 'house_alert', type = 'number', label = 'Cambriolage : chance que le voisin appelle la police (%)', default = 35, min = 0, max = 100 },
        { k = 'house_search', type = 'number', label = 'Cambriolage : fouilles par maison', default = 4, min = 1, max = 10 },
        { k = 'atm_cooldown', type = 'number', label = 'Distributeur : délai entre deux braquages du même (min)', default = 90, min = 5, max = 10080 },
        { k = 'atm_police', type = 'number', label = 'Distributeur : policiers en service minimum', default = 1, min = 0, max = 20 },
        { k = 'atm_min', type = 'number', label = 'Distributeur : gain minimum ($)', default = 1500, min = 0, max = 1000000 },
        { k = 'atm_max', type = 'number', label = 'Distributeur : gain maximum ($)', default = 4500, min = 0, max = 1000000 },
        { k = 'gofast_minutes', type = 'number', label = 'GoFast : temps pour livrer (min)', default = 8, min = 2, max = 60 },
        { k = 'gofast_pay', type = 'number', label = 'GoFast : paie de base ($, + bonus de temps)', default = 12000, min = 0, max = 10000000 },
        { k = 'gofast_cooldown', type = 'number', label = 'GoFast : délai entre deux GoFast d\'un joueur (min)', default = 45, min = 1, max = 10080 },
        { k = 'gofast_police', type = 'number', label = 'GoFast : policiers en service minimum', default = 1, min = 0, max = 20 },
        { k = 'truck_every', type = 'number', label = 'Fourgon blindé : un toutes les (min, 0 = jamais)', default = 60, min = 0, max = 10080 },
        { k = 'truck_police', type = 'number', label = 'Fourgon blindé : policiers en service minimum', default = 2, min = 0, max = 20 },
        { k = 'truck_bag', type = 'number', label = "Fourgon blindé : argent par sac ($, 4 sacs)", default = 6000, min = 0, max = 1000000 },
    } })
    local spots = W:ExtSettings({ ns = NS, id = 'spots', title = 'Points posés', perm = PERM, fields = {
        { k = 'spots', type = 'rows', label = 'Maisons, receleurs, départs et arrivées de GoFast, départs de fourgons', default = {}, wide = true, maxitems = 300, unique = 'id',
          hint = 'Pose-les en jeu : F10 › Builder › Braquages. Types : house, fence, gofast_start, gofast_drop, truck.',
          cols = { { k = 'id', label = 'Identifiant', pattern = '^[%w_]+$', required = true, maxlen = 40, lower = true }, { k = 'kind', label = 'Type', pattern = '^[%a_]+$', required = true, maxlen = 14, lower = true },
            { k = 'label', label = 'Nom', required = true, maxlen = 40 }, { k = 'x', label = 'X', type = 'number', min = -10000, max = 10000, int = false },
            { k = 'y', label = 'Y', type = 'number', min = -10000, max = 10000, int = false }, { k = 'z', label = 'Z', type = 'number', min = -500, max = 3000, int = false }, { k = 'h', label = 'Cap', type = 'number', min = 0, max = 360, int = false } } } } })
    W:ExtModule({
        id = RES, label = 'Braquages et trafics', icon = 'skull', perm = PERM, hint = 'Cambriolages, receleur, distributeurs, GoFast, fourgons blindés',
        doc = "## Braquages et trafics\n- **Cambriolages** : une maison posée au Builder se crochète (crochet), puis se fouille. Le voisin peut appeler la police. Le butin se revend au **receleur** (point caché, sans icône).\n- **Distributeurs** : les distributeurs de la banque se forcent avec une **perceuse** (vendue par le receleur).\n- **GoFast** : des points de départ **cachés** (sans icône), à trouver en RP. On récupère une voiture chargée, à livrer avant la fin du temps ; la police reçoit sa position.\n- **Fourgons blindés** : un fourgon roule en ville ; une **charge thermique** à l'arrière l'ouvre, puis on ramasse les sacs.\n\nPoser les points : **F10 › Builder › Braquages**.",
        tabs = { { id = 'main', label = 'Réglages', icon = 'sliders', form = main }, { id = 'spots', label = 'Points posés', icon = 'pin', form = spots } },
    })
end

-- Données envoyées aux joueurs : les maisons (à repérer), pas les points cachés (receleurs et GoFast restent secrets : proximité seulement)
local function publicCfg()
    local out = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do if not HIDDEN[s.kind] then out[#out + 1] = { id = s.id, kind = s.kind, label = s.label, x = s.x, y = s.y, z = s.z } end end
    local atms = {}
    local ok, list = pcall(function() return W:GetAtms() end)
    for _, a in ipairs(ok and list or {}) do atms[#atms + 1] = { id = a.id, x = a.x, y = a.y, z = a.z } end
    return { enabled = cfg('enabled', true) ~= false, spots = out, atms = atms }
end
local function push(t) TriggerClientEvent(RES .. ':cfg', t or -1, json.encode(publicCfg())) end
-- points cachés : signalés seulement au joueur qui est juste à côté (jamais envoyés à l'avance)
local nearSent = {}
AddEventHandler('playerDropped', function() nearSent[source] = nil end)
CreateThread(function()
    while true do
        Wait(1500)
        local hidden = {}
        for _, sp in ipairs(cfg('spots', {}) or {}) do if HIDDEN[sp.kind] and sp.kind ~= 'truck' then hidden[#hidden + 1] = sp end end
        for _, id in ipairs(GetPlayers()) do
            local src = tonumber(id)
            local c = pos(src)
            local list, key = {}, ''
            if c then for _, sp in ipairs(hidden) do if #(c - vector3(sp.x + 0.0, sp.y + 0.0, sp.z + 0.0)) < 8.0 then list[#list + 1] = { id = sp.id, kind = sp.kind, label = sp.label, x = sp.x, y = sp.y, z = sp.z } key = key .. sp.id end end end
            if nearSent[src] ~= key then nearSent[src] = key TriggerClientEvent(RES .. ':near', src, json.encode(list)) end
        end
    end
end)
AddEventHandler('pb_panel:cfgChanged', function(ns) if ns == NS then cache = {} push() end end)
RegisterNetEvent(RES .. ':hello', function() push(source) end)

local last = {}
local function throttle(src, ms) local t = GetGameTimer() if last[src] and t - last[src] < (ms or 800) then return false end last[src] = t return true end
AddEventHandler('playerDropped', function() last[source] = nil end)

-- Cambriolages -------------------------------------------------------------------------------------------------------------------------------------------------
local houses = {}   -- id -> { until = recharge, open = { src, left, t } }
RegisterNetEvent(RES .. ':house', function(id, step)
    local src = source
    if not throttle(src) or not cfg('enabled', true) or not busyOk(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    if not s or s.kind ~= 'house' or dist(src, s.x, s.y, s.z) > 4.0 then return end
    local hs = houses[s.id] or {}
    houses[s.id] = hs
    if step == 'pick' then
        if hs.open and hs.open.src == src then TriggerClientEvent(RES .. ':houseopen', src, s.id, hs.open.left) return end
        if (hs['until'] or 0) > now() then notify(src, 'warn', 'Cette maison a déjà été visitée récemment.') return end
        if police() < (tonumber(cfg('house_police', 0)) or 0) then notify(src, 'warn', 'Trop calme en ville : pas assez de policiers en service.') return end
        if not W:HasItem(src, 'lockpick', 1) then notify(src, 'error', 'Il te faut un crochet.') return end
        hs.pick = { src = src, t = now() }
        TriggerClientEvent(RES .. ':lockpick', src, s.id)
    elseif step == 'picked' then
        local pk = hs.pick
        hs.pick = nil
        if not pk or pk.src ~= src or now() - pk.t < 7 then return end
        if math.random(100) <= 30 then W:RemoveItem(src, 'lockpick', 1) notify(src, 'warn', 'Ton crochet s\'est cassé.') end
        hs.open = { src = src, left = math.floor(tonumber(cfg('house_search', 4)) or 4), t = now() }
        hs['until'] = now() + (tonumber(cfg('house_cooldown', 120)) or 120) * 60
        if math.random(100) <= (tonumber(cfg('house_alert', 35)) or 35) then alert(('Cambriolage signalé par un voisin : %s'):format(s.label), s.x, s.y, s.z) end
        TriggerClientEvent(RES .. ':houseopen', src, s.id, hs.open.left)
    elseif step == 'search' then
        local o = hs.open
        if not o or o.src ~= src or o.left <= 0 or now() - (o.last or 0) < 5 then return end
        o.last = now()
        o.left = o.left - 1
        local total = 0
        for _, b in ipairs(BURGLARY_LOOT) do total = total + b.w end
        local r, pick = math.random() * total, BURGLARY_LOOT[1]
        for _, b in ipairs(BURGLARY_LOOT) do r = r - b.w if r <= 0 then pick = b break end end
        if math.random(100) <= 25 then notify(src, 'info', 'Rien d\'intéressant ici.')
        elseif W:CanCarryItem(src, pick.name, 1) and W:AddItem(src, pick.name, 1) then notify(src, 'success', 'Trouvé : ' .. pick.label .. '.')
        else notify(src, 'error', 'Ton sac est plein.') end
        if o.left <= 0 then hs.open = nil notify(src, 'info', 'Plus rien à fouiller : file avant que la police arrive.') end
        TriggerClientEvent(RES .. ':houseopen', src, s.id, o.left)
    end
end)

-- Receleur (point caché) ----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent(RES .. ':fence', function(id, action, item)
    local src = source
    if not throttle(src) or not busyOk(src) then return end
    local s = find(cfg('spots', {}), tostring(id))
    if not s or s.kind ~= 'fence' or dist(src, s.x, s.y, s.z) > 4.0 then return end
    if action == 'sell' then
        local b = BURGLARY_BY[tostring(item)]
        if not b then return end
        local n = math.min(W:GetItemCount(src, b.name) or 0, 50)
        if n <= 0 or not W:RemoveItem(src, b.name, n) then return end
        local how = payDirty(src, b.price * n, 'Receleur')
        notify(src, 'success', ('Vendu : %d × %s pour $%d (%s).'):format(n, b.label, b.price * n, how == 'sale' and 'argent sale' or 'espèces'))
    elseif action == 'buy' then
        local t
        for _, x in ipairs(TOOLS) do if x.name == item then t = x end end
        if not t then return end
        if not W:CanCarryItem(src, t.name, 1) then notify(src, 'error', 'Ton sac est plein.') return end
        if not W:Pay(src, t.price, 'cash', 'Receleur') then notify(src, 'error', "Pas assez d'espèces.") return end
        W:AddItem(src, t.name, 1)
        notify(src, 'success', 'Acheté : ' .. t.label .. '.')
    end
    local list = {}
    for _, b in ipairs(BURGLARY_LOOT) do list[#list + 1] = { item = b.name, label = b.label, price = b.price, n = W:GetItemCount(src, b.name) or 0 } end
    local tools = {}
    for _, x in ipairs(TOOLS) do tools[#tools + 1] = { item = x.name, label = x.label, price = x.price, desc = x.desc } end
    TriggerClientEvent(RES .. ':fencemenu', src, s.id, json.encode({ loot = list, tools = tools }))
end)

-- Distributeurs ---------------------------------------------------------------------------------------------------------------------------------------------------
local atmUntil, drilling = {}, {}
AddEventHandler('playerDropped', function() drilling[source] = nil end)
local function atmStep(src, id, step)
    if not throttle(src) or not cfg('enabled', true) or not busyOk(src) then return end
    local a
    local ok, list = pcall(function() return W:GetAtms() end)
    for _, x in ipairs(ok and list or {}) do if x.id == id then a = x end end
    if not a or dist(src, a.x, a.y, a.z) > 3.0 then return end
    if step == 'start' then
        if (atmUntil[a.id] or 0) > now() then notify(src, 'warn', 'Ce distributeur est vide pour le moment.') return end
        if police() < (tonumber(cfg('atm_police', 1)) or 1) then notify(src, 'warn', 'Pas assez de policiers en service.') return end
        if not W:HasItem(src, 'perceuse', 1) then notify(src, 'error', 'Il te faut une perceuse (receleur).') return end
        for other, d in pairs(drilling) do if other ~= src and d.id == a.id and now() - d.t < 120 then notify(src, 'warn', 'Quelqu\'un force déjà ce distributeur.') return end end
        drilling[src] = { id = a.id, t = now() }
        alert('Distributeur forcé : ' .. tostring(a.label or a.id), a.x, a.y, a.z)
        TriggerClientEvent(RES .. ':drill', src, a.id, 40)
    elseif step == 'done' then
        local d = drilling[src]
        drilling[src] = nil
        if not d or d.id ~= a.id or now() - d.t < 38 then return end
        if (atmUntil[a.id] or 0) > now() then notify(src, 'warn', 'Ce distributeur est vide.') return end
        atmUntil[a.id] = now() + (tonumber(cfg('atm_cooldown', 90)) or 90) * 60
        if math.random(100) <= 20 then W:RemoveItem(src, 'perceuse', 1) notify(src, 'warn', 'La perceuse a rendu l\'âme.') end
        local amount = math.random(math.floor(tonumber(cfg('atm_min', 1500)) or 1500), math.max(math.floor(tonumber(cfg('atm_min', 1500)) or 1500), math.floor(tonumber(cfg('atm_max', 4500)) or 4500)))
        payDirty(src, amount, 'Distributeur')
        notify(src, 'success', ('Le distributeur crache %d $.'):format(amount))
    elseif step == 'cancel' then drilling[src] = nil end
end
RegisterNetEvent(RES .. ':atm', function(id, step) atmStep(source, id, step) end)
-- la perceuse s'utilise depuis l'inventaire, près d'un distributeur (E y reste le distributeur de la banque)
useDrill = function(src)
    local c = pos(src)
    if not c then return false end
    local ok, list = pcall(function() return W:GetAtms() end)
    local best, bd
    for _, a in ipairs(ok and list or {}) do local d = #(c - vector3(a.x + 0.0, a.y + 0.0, a.z + 0.0)) if d < 2.0 and (not bd or d < bd) then best, bd = a, d end end
    if not best then return false, "Approche-toi d'un distributeur." end
    last[src] = nil
    atmStep(src, best.id, 'start')
    return true, 'Perçage…', true
end

-- GoFast ----------------------------------------------------------------------------------------------------------------------------------------------------------
local gofast, gfLast = {}, {}   -- src -> { drop, net, t0, limit }
AddEventHandler('playerDropped', function() gofast[source] = nil end)
RegisterNetEvent(RES .. ':gofast', function(id, step, net)
    local src = source
    if not throttle(src) or not cfg('enabled', true) then return end
    if step == 'start' then
        local s = find(cfg('spots', {}), tostring(id))
        if not s or s.kind ~= 'gofast_start' or dist(src, s.x, s.y, s.z) > 4.0 or not busyOk(src) then return end
        if gofast[src] then notify(src, 'warn', 'Tu as déjà un GoFast en cours.') return end
        if gfLast[src] and now() - gfLast[src] < (tonumber(cfg('gofast_cooldown', 45)) or 45) * 60 then notify(src, 'warn', 'Reviens plus tard, ça chauffe.') return end
        if police() < (tonumber(cfg('gofast_police', 1)) or 1) then notify(src, 'warn', "Pas de travail aujourd'hui (pas assez de policiers en service).") return end
        local drops = {}
        for _, d in ipairs(cfg('spots', {}) or {}) do if d.kind == 'gofast_drop' and #(vector2(d.x, d.y) - vector2(s.x, s.y)) > 800 then drops[#drops + 1] = d end end
        if #drops == 0 then notify(src, 'warn', 'Aucun point d\'arrivée assez loin : le staff doit en poser.') return end
        local drop = drops[math.random(#drops)]
        local limit = (tonumber(cfg('gofast_minutes', 8)) or 8) * 60
        gofast[src] = { drop = drop.id, t0 = now(), limit = limit }
        gfLast[src] = now()
        TriggerClientEvent(RES .. ':gfgo', src, json.encode({ x = drop.x, y = drop.y, z = drop.z, label = drop.label, secs = limit, sx = s.x, sy = s.y, sz = s.z, h = s.h or 0 }))
    elseif step == 'car' then
        -- la voiture du GoFast est déclarée une seule fois, au départ (sinon on pourrait livrer avec n'importe quel véhicule)
        local g = gofast[src]
        if not g or g.net or now() - g.t0 > 120 then return end
        g.net = tonumber(net)
    elseif step == 'drop' then
        local g = gofast[src]
        local d = g and find(cfg('spots', {}), g.drop)
        if not g or not d or dist(src, d.x, d.y, d.z) > 12.0 then return end
        gofast[src] = nil
        local veh = g.net and NetworkGetEntityFromNetworkId(g.net) or 0
        if veh == 0 or not DoesEntityExist(veh) or #(GetEntityCoords(veh) - vector3(d.x, d.y, d.z)) > 20.0 then notify(src, 'error', 'Sans la voiture, pas de paie.') return end
        local okp, plate = pcall(GetVehicleNumberPlateText, veh)
        if not okp or not tostring(plate or ''):match('^%s*GF%d%d%d%d%d') then notify(src, 'error', 'Ce n\'est pas la voiture du client.') return end
        local left = g.limit - (now() - g.t0)
        if left < 0 then notify(src, 'error', 'Trop tard : le client est parti.') DeleteEntity(veh) return end
        local pay = math.floor((tonumber(cfg('gofast_pay', 12000)) or 12000) * (1 + 0.5 * left / g.limit))
        DeleteEntity(veh)
        payDirty(src, pay, 'GoFast')
        notify(src, 'success', ('Livraison réussie : %d $.'):format(pay))
    elseif step == 'fail' then
        gofast[src] = nil
    end
end)
-- la police suit le GoFast : position envoyée toutes les 45 s
CreateThread(function()
    while true do
        Wait(45000)
        for src, g in pairs(gofast) do
            if now() - g.t0 > g.limit + 60 then gofast[src] = nil
            elseif g.net then
                local veh = NetworkGetEntityFromNetworkId(g.net)
                if veh ~= 0 and DoesEntityExist(veh) then local c = GetEntityCoords(veh) alert('GoFast en cours : véhicule suspect à grande vitesse', c.x, c.y, c.z) end
            end
        end
    end
end)

-- Fourgons blindés --------------------------------------------------------------------------------------------------------------------------------------------------
local truck   -- { net, bags, opened, by, t }
local function startTruck()
    if truck or not cfg('enabled', true) then return end
    if police() < (tonumber(cfg('truck_police', 2)) or 2) then return end
    local starts = {}
    for _, s in ipairs(cfg('spots', {}) or {}) do if s.kind == 'truck' then starts[#starts + 1] = s end end
    if #starts == 0 then return end
    local s = starts[math.random(#starts)]
    -- le joueur le plus proche du départ fait apparaître le fourgon (entité réseau) ; tous les joueurs reçoivent sa position approximative
    local best, bd
    for _, id in ipairs(GetPlayers()) do local d = dist(tonumber(id), s.x, s.y, s.z) if d < 400 and (not bd or d < bd) then best, bd = tonumber(id), d end end
    if not best then return end
    truck = { bags = 4, t = now(), host = best }
    TriggerClientEvent(RES .. ':truckspawn', best, json.encode({ x = s.x, y = s.y, z = s.z, h = s.h or 0 }))
    TriggerClientEvent(RES .. ':truckinfo', -1, json.encode({ x = s.x, y = s.y, z = s.z, label = 'Fourgon blindé repéré' }))
end
RegisterNetEvent(RES .. ':truck', function(step, net)
    local src = source
    if not truck then return end
    if step == 'spawned' and src == truck.host then truck.net = tonumber(net) return end
    if not throttle(src) or not busyOk(src) then return end
    local veh = truck.net and NetworkGetEntityFromNetworkId(truck.net) or 0
    if veh == 0 or not DoesEntityExist(veh) then return end
    local c = GetEntityCoords(veh)
    if dist(src, c.x, c.y, c.z) > 8.0 then return end
    if step == 'charge' then
        if truck.opened or truck.charging then return end
        if not W:HasItem(src, 'thermite', 1) or not W:RemoveItem(src, 'thermite', 1) then notify(src, 'error', 'Il te faut une charge thermique (receleur).') return end
        truck.charging = { src = src, t = now() }
        alert('Attaque de fourgon blindé en cours !', c.x, c.y, c.z)
        TriggerClientEvent(RES .. ':truckboom', -1, truck.net, 15)
    elseif step == 'opened' then
        local ch = truck.charging
        if ch and now() - ch.t >= 14 then truck.opened, truck.charging = true, nil end
    elseif step == 'loot' then
        if not truck.opened or truck.bags <= 0 then return end
        truck.bags = truck.bags - 1
        local amount = math.floor(tonumber(cfg('truck_bag', 6000)) or 6000)
        payDirty(src, amount, 'Fourgon blindé')
        notify(src, 'success', ('Sac récupéré : %d $ (%d restant(s)).'):format(amount, truck.bags))
        if truck.bags <= 0 then truck = nil TriggerClientEvent(RES .. ':truckend', -1) end
    end
end)
CreateThread(function()
    while true do
        local every = tonumber(cfg('truck_every', 60)) or 60
        Wait(math.max(5, every) * 60000)
        if truck and now() - truck.t > 20 * 60 then truck = nil TriggerClientEvent(RES .. ':truckend', -1) end
        if every > 0 then pcall(startTruck) end
    end
end)

-- Builder -------------------------------------------------------------------------------------------------------------------------------------------------------------
local KINDS = { house = 'Maison à cambrioler', fence = 'Receleur (caché)', gofast_start = 'Départ de GoFast (caché)', gofast_drop = 'Arrivée de GoFast', truck = 'Départ de fourgon blindé (sur une route)' }
local function placeSpot(src, what, extra)
    local ok, r = pcall(function() return W:HasPermission(src, 'carte.place') end)
    if not (ok and r) then return false end
    local ped = GetPlayerPed(src)
    local c = pos(src)
    if not c then return false end
    local spots = cfg('spots', {}) or {}
    if what == 'delete' then
        local bi, bd
        for i, s in ipairs(spots) do local d = #(vector2(c.x, c.y) - vector2(s.x, s.y)) if d < 10 and (not bd or d < bd) then bi, bd = i, d end end
        if not bi then notify(src, 'error', 'Aucun point à moins de 10 m.') return false end
        table.remove(spots, bi)
        W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : suppression')
        notify(src, 'success', 'Point supprimé.')
        return true
    end
    if not KINDS[what] then return false end
    local n = 1
    while find(spots, what .. '_' .. n) do n = n + 1 end
    local name = tostring(extra or ''):gsub('[%c<>"\\]', ''):sub(1, 40)
    spots[#spots + 1] = { id = what .. '_' .. n, kind = what, label = name ~= '' and name or KINDS[what], x = math.floor(c.x * 100) / 100, y = math.floor(c.y * 100) / 100, z = math.floor(c.z * 100) / 100, h = math.floor(GetEntityHeading(ped)) }
    W:CfgSet(NS, 'spots', spots, GetPlayerName(src), 'Builder : ' .. KINDS[what])
    notify(src, 'success', KINDS[what] .. ' posé ici.')
    return true
end
local bootedAt
local function boot()
    if bootedAt and GetGameTimer() - bootedAt < 5000 then return end
    bootedAt = GetGameTimer()
    local ok, err = pcall(setup)
    if not ok then print(('^3[%s]^7 branchement sur pb_panel impossible : %s'):format(RES, tostring(err))) return end
    pcall(function()
        local points = {}
        for _, k in ipairs({ 'house', 'fence', 'gofast_start', 'gofast_drop', 'truck' }) do points[#points + 1] = { id = k, label = KINDS[k], ask = 'Nom (vide = « ' .. KINDS[k] .. ' »)' } end
        points[#points + 1] = { id = 'delete', label = 'Supprimer le point le plus proche' }
        W:RegisterBuilder({ id = 'braquages', label = 'Braquages', icon = 'skull', points = points }, function(src, what, extra) return placeSpot(src, tostring(what), tostring(extra or '')) end)
    end)
    push()
end
CreateThread(function()
    while GetResourceState('pb_panel') ~= 'started' do Wait(250) end
    while not W:ExtReady() do Wait(250) end
    boot()
end)
AddEventHandler('pb_panel:ready', function() SetTimeout(500, boot) end)
