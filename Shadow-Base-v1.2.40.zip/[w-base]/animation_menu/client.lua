local isOpen = false
local emotesSent = false
local currentProp = nil

local emotesById = {}
for _, e in ipairs(Config.Emotes) do
  emotesById[e.id] = e
end

-- Notification Shadow Base (pb_panel), sinon rien
local function notify(text, kind)
  if GetResourceState('pb_panel') ~= 'started' then return end
  pcall(function() exports.pb_panel:Notify({ type = kind or 'info', text = text }) end)
end

-- ---------- Thème (panel Shadow Base > Menu animations) ----------

local theme = nil

-- c = configuration de jeu de Shadow Base (G.cfg) : brand.color (Identité), menus.accent, animmenu.*
local function applyConfig(c)
  if type(c) ~= 'table' then return end
  local a = type(c.animmenu) == 'table' and c.animmenu or {}
  local mode = a.color_mode or 'server'
  local color
  if mode == 'custom' then color = a.color
  elseif mode == 'menus' then color = type(c.menus) == 'table' and c.menus.accent or nil
  elseif mode == 'server' then color = type(c.brand) == 'table' and c.brand.color or nil
  end
  -- n'importe quel format (#rgb, #rrggbb, rgb(...)) : le menu le lit et l'éclaircit s'il est trop sombre
  if type(color) ~= 'string' or #color > 40 then color = nil end
  theme = { action = 'theme', color = color, neon = a.neon ~= false, neonPower = tonumber(a.neon_power) or 100 }
  SendNUIMessage(theme)
end

-- Envoyée par Shadow Base à la connexion et à chaque changement dans le panel
RegisterNetEvent('pb:g:cfg', function(j)
  local ok, c = pcall(json.decode, j)
  if ok then applyConfig(c) end
end)

-- Au (re)démarrage de la ressource : on lit la configuration déjà reçue par Shadow Base
CreateThread(function()
  Wait(1000)
  if GetResourceState('pb_panel') ~= 'started' then return end
  local ok, c = pcall(function() return exports.pb_panel:GetClientConfig() end)
  if ok then applyConfig(c) end
end)

-- ---------- Menu ----------

local function sendEmotes()
  local list = {}
  for _, e in ipairs(Config.Emotes) do
    -- chaque carte a son aperçu : html/img/emotes/<id>.svg (ou l'image donnée dans config.lua)
    list[#list + 1] = { id = e.id, name = e.label, category = e.category, type = e.type, image = e.image or ('img/emotes/' .. e.id .. '.svg') }
  end
  SendNUIMessage({ action = 'setEmotes', emotes = list })
  emotesSent = true
end

local function setOpen(state)
  isOpen = state
  if state and not emotesSent then sendEmotes() end
  if state and theme then SendNUIMessage(theme) end
  SetNuiFocus(state, state)
  SendNUIMessage({ action = state and 'open' or 'close' })
end

RegisterCommand('animmenu', function()
  setOpen(not isOpen)
end, false)
RegisterKeyMapping('animmenu', 'Ouvrir le menu animations', 'keyboard', Config.OpenKey)

RegisterNUICallback('close', function(_, cb)
  setOpen(false)
  cb('ok')
end)

-- ---------- Animations ----------

-- Mêmes règles que Shadow Base : pas à terre, pas menotté, pas en véhicule
local function canPlay()
  local ped = PlayerPedId()
  if IsEntityDead(ped) or IsPedRagdoll(ped) then
    notify('Impossible à terre.', 'warn')
    return false
  end
  if IsPedInAnyVehicle(ped, false) then
    notify('Sors du véhicule pour jouer une animation.', 'warn')
    return false
  end
  if IsPedCuffed(ped) or IsEntityPlayingAnim(ped, 'mp_arresting', 'idle', 3) then
    return false
  end
  return true
end

local function loadDict(dict)
  RequestAnimDict(dict)
  local timeout = GetGameTimer() + 5000
  while not HasAnimDictLoaded(dict) do
    if GetGameTimer() > timeout then return false end
    Wait(0)
  end
  return true
end

local function loadModel(model)
  local hash = joaat(model)
  RequestModel(hash)
  local timeout = GetGameTimer() + 5000
  while not HasModelLoaded(hash) do
    if GetGameTimer() > timeout then return nil end
    Wait(0)
  end
  return hash
end

local function removeProp()
  if currentProp and DoesEntityExist(currentProp) then
    DeleteEntity(currentProp)
  end
  currentProp = nil
end

local function stopEmote()
  ClearPedTasks(PlayerPedId())
  removeProp()
end

local function closestPlayer(maxDist)
  local ped = PlayerPedId()
  local coords = GetEntityCoords(ped)
  local best, bestDist = nil, maxDist
  for _, pl in ipairs(GetActivePlayers()) do
    if pl ~= PlayerId() then
      local d = #(GetEntityCoords(GetPlayerPed(pl)) - coords)
      if d <= bestDist then best, bestDist = pl, d end
    end
  end
  return best
end

-- Geste à deux : on passe par le système de Shadow Base (invitation Y / N, distance et droits vérifiés côté serveur)
local function playShared(e)
  local target = closestPlayer(Config.SharedDistance)
  if not target then
    notify('Personne à proximité.', 'warn')
    return
  end
  if isOpen then setOpen(false) end
  TriggerServerEvent('pb:g:ctx:act', GetPlayerServerId(target), e.shared)
end

local function playEmote(e)
  if not canPlay() then return end

  if e.shared then
    playShared(e)
    return
  end

  local ped = PlayerPedId()
  stopEmote()

  if e.scenario then
    TaskStartScenarioInPlace(ped, e.scenario, 0, true)
    return
  end

  if not loadDict(e.dict) then
    notify('Animation introuvable.', 'warn')
    return
  end
  TaskPlayAnim(ped, e.dict, e.anim, 8.0, -8.0, -1, e.flag or 1, 0, false, false, false)
  RemoveAnimDict(e.dict)

  if e.prop then
    local hash = loadModel(e.prop.model)
    if hash then
      local coords = GetEntityCoords(ped)
      currentProp = CreateObject(hash, coords.x, coords.y, coords.z + 0.2, true, true, true)
      AttachEntityToEntity(currentProp, ped, GetPedBoneIndex(ped, e.prop.bone),
        e.prop.pos.x, e.prop.pos.y, e.prop.pos.z, e.prop.rot.x, e.prop.rot.y, e.prop.rot.z,
        true, true, false, true, 1, true)
      SetModelAsNoLongerNeeded(hash)
    end
  end
end

RegisterNUICallback('playEmote', function(data, cb)
  cb('ok')
  local e = emotesById[data.id]
  if not e then return end
  if Config.CloseOnPlay then setOpen(false) end
  playEmote(e)
end)

RegisterCommand('stopemote', stopEmote, false)
RegisterKeyMapping('stopemote', 'Arrêter l\'animation', 'keyboard', Config.CancelKey)

-- /e <nom> : joue une emote sans ouvrir le menu (identifiant ou libellé, sans accents ni majuscules) ; /e seul arrête
local function norm(s)
  s = tostring(s or ''):lower()
  for a, r in pairs({ ['à'] = 'a', ['â'] = 'a', ['é'] = 'e', ['è'] = 'e', ['ê'] = 'e', ['ë'] = 'e', ['î'] = 'i', ['ï'] = 'i', ['ô'] = 'o', ['ù'] = 'u', ['û'] = 'u', ['ç'] = 'c', ['œ'] = 'oe' }) do s = s:gsub(a, r) end
  return (s:gsub('[^%w]', ''))
end
local byName = {}
for _, e in ipairs(Config.Emotes) do
  byName[norm(e.id)] = e
  byName[norm(e.label)] = byName[norm(e.label)] or e
end
RegisterCommand('e', function(_, args)
  if not args[1] then stopEmote() return end
  local e = byName[norm(table.concat(args, ' '))]
  if not e then notify('Emote inconnue. Ouvre le menu avec /emotes (ou ' .. Config.OpenKey .. ').', 'warn') return end
  playEmote(e)
end, false)
RegisterCommand('emotes', function() setOpen(not isOpen) end, false)
CreateThread(function()
  TriggerEvent('chat:addSuggestion', '/e', "Jouer une emote (ex. /e danse 3, /e pompes) ; /e seul pour arrêter", { { name = 'emote', help = "nom de l'emote" } })
  TriggerEvent('chat:addSuggestion', '/emotes', 'Ouvrir le menu des emotes')
  TriggerEvent('chat:addSuggestion', '/stopemote', "Arrêter l'animation")
end)

-- Nettoyage si la ressource est redémarrée
AddEventHandler('onResourceStop', function(resource)
  if resource ~= GetCurrentResourceName() then return end
  if isOpen then SetNuiFocus(false, false) end
  removeProp()
end)
