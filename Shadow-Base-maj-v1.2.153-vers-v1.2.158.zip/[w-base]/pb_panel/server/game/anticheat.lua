-- Anticheat de base : protections simples, côté serveur d'abord. Rien ici ne remplace un anticheat commercial :
--  * le serveur décide (évènements natifs refusés, comptage, listes noires) ; le client ne fait que répondre à un « pouls » et signaler l'arrêt d'une ressource ;
--  * un cheat injecté dans le jeu peut imiter le pouls : on bloque les cas courants (arrêt des scripts, évènements pièges, explosions, armes interdites), pas un attaquant déterminé ;
--  * tout est journalisé (catégorie « securite ») et les joueurs avec le droit « anticheat.bypass » ne sont jamais sanctionnés : leurs évènements natifs passent, et une détection reste écrite en simple journal.
local G = PB.G
local P, B, Form = PB.Perm, PB.B, PB.Form

local AC = { alerts = {}, track = {}, honey = {}, expected = {}, counts = { kick = 0, ban = 0, log = 0 } }
PB.AC = AC
G.AC = AC

P.Register('anticheat.view', "Voir l'anticheat (alertes, joueurs, réglages)", 'security')
P.Register('anticheat.edit', "Régler l'anticheat", 'security', true)
P.Register('anticheat.bypass', "Exempté de l'anticheat (jamais expulsé ni banni par lui)", 'security', true)

local MODES = { { 'off', 'Désactivé' }, { 'log', 'Journaliser seulement' }, { 'kick', 'Expulser' }, { 'ban', 'Bannir (définitif)' } }
local KINDS = {   -- id, libellé, mode par défaut, aide
    { 'resource_stop', "Arrêt d'une ressource protégée côté client", 'kick', "Un joueur qui coupe un de tes scripts (le serveur le confirme encore actif)." },
    { 'heartbeat', 'Protection client silencieuse', 'kick', "Plus de réponse au pouls : le script client a été arrêté ou bloqué." },
    { 'explosion', 'Explosions en rafale ou interdites', 'kick', 'Trop d\'explosions en peu de temps, ou explosion invisible.' },
    { 'entity', 'Objet, véhicule ou ped interdit', 'kick', 'Modèle de la liste noire créé par un joueur (refusé avant qu\'il apparaisse).' },
    { 'weapon', 'Arme interdite utilisée', 'kick', 'Dégâts infligés avec une arme de la liste noire.' },
    { 'give_weapon', 'Arme donnée à un autre joueur', 'kick', 'Le serveur gère les armes : un client ne donne pas d\'arme à un ped qui n\'est pas le sien.' },
    { 'clear_tasks', 'Tâches annulées sur un autre joueur', 'kick', 'Annule l\'action d\'un autre joueur (menottes, animation…).' },
    { 'fire', 'Feux en rafale', 'kick', 'Trop de départs de feu en peu de temps.' },
    { 'ptfx', 'Particules en rafale', 'log', "Trop d'effets visuels envoyés à tout le monde." },
    { 'honeypot', 'Évènement piège déclenché', 'ban', "Évènement qu'aucun script légitime n'appelle : seuls les outils de triche l'appellent." },
    { 'godmode', 'Invincibilité', 'log', 'Joueur invincible hors service staff. À passer en « Expulser » une fois les réglages éprouvés.' },
    { 'teleport', 'Déplacement impossible', 'log', 'Trop de distance en peu de temps hors téléportation du serveur. Peut se déclencher par erreur : commence par « Journaliser ».' },
    { 'damage_mod', 'Dégâts truqués', 'log', "Dégâts d'une arme bien au-dessus de ce que le jeu inflige (modificateur de dégâts)." },
    { 'hit_far', 'Tir impossible à cette distance', 'log', "Cible touchée beaucoup plus loin que la portée réelle de n'importe quelle arme (aimbot, silent aim)." },
    { 'projectile', 'Projectiles interdits ou en rafale', 'kick', 'Roquettes, grenades ou projectiles de la liste noire, ou trop de projectiles en peu de temps.' },
    { 'remove_weapons', "Armes retirées à un autre joueur", 'kick', "Un client qui désarme un ped qui n'est pas le sien." },
    { 'entity_spam', "Création d'entités en rafale", 'kick', "Trop de véhicules, peds ou objets créés en peu de temps (crash, chaos, trolling)." },
    { 'chat_spam', 'Spam ou insultes dans le chat', 'log', 'Messages trop rapprochés ou mots de la liste noire.' },
    { 'name', 'Pseudo interdit', 'kick', "À la connexion : pseudo vide, trop long, caractères invisibles ou mot de la liste noire." },
    { 'event_token', 'Évènement sans jeton valide (wb_shield)', 'ban', "Un évènement protégé a été déclenché sans le jeton signé, avec un faux jeton ou rejoué : menu de triche ou injection." },
    { 'event_args', "Arguments impossibles envoyés à un évènement (wb_shield)", 'log', "NaN, infini ou imbrication démesurée dans les arguments d'un évènement : l'évènement est jeté. Aucun client honnête n'en envoie." },
    { 'resource_kill', "Arrêt d'une ressource protégée attribué à un joueur", 'ban', "Une ressource protégée s'arrête sans ordre du staff, juste après une détection forte du même joueur (honeypot, évènement sans jeton, arguments impossibles) ou après qu'il l'a coupée chez lui. Elle est relancée aussitôt." },
    { 'event_flood', "Évènement déclenché en rafale (wb_shield)", 'log', "Un même évènement appelé bien trop souvent par un joueur (duplication d'objets, spam d'argent…)." },
    { 'ped_change', 'Modèle de joueur changé', 'log', "Le ped du joueur n'est pas un modèle autorisé (ped changer). Ajoute les modèles que tes scripts utilisent à la liste." },
    { 'veh_boost', 'Véhicule trop rapide ou boosté', 'log', "Vitesse du véhicule très au-dessus du maximum de son modèle (boost, modification de puissance)." },
    { 'veh_god', 'Véhicule indestructible', 'log', "Véhicule dont la santé dépasse le maximum ou qui ne peut pas être endommagé." },
    { 'escalation', 'Trop de signalements en peu de temps', 'kick', "Plusieurs détections différentes sur le même joueur en quelques minutes : une seule peut être une erreur, l'accumulation non." },
    { 'health_hack', 'Santé ou armure hors limites (serveur)', 'log', "Lu directement par le serveur, donc non falsifiable par le client : santé ou armure au-dessus du maximum." },
    { 'speed_hack', 'Vitesse à pied impossible (serveur)', 'log', "Vitesse horizontale soutenue à pied bien au-dessus d'un sprint." },
    { 'weapon_held', 'Arme interdite en main (serveur)', 'kick', "Le joueur tient une arme de la liste noire, même sans tirer." },
    { 'rapid_fire', 'Cadence de tir impossible', 'log', "Trop de coups déclarés en peu de temps pour une arme (rapid fire, modificateur de cadence)." },
    { 'aim_ratio', 'Précision suspecte (têtes)', 'log', "Part anormale de tirs à la tête sur plusieurs dizaines de touches : aimbot probable. Journal seulement." },
    { 'melee_far', 'Coup de mêlée ou taser à distance', 'log', "Coup de poing, couteau ou taser donné bien trop loin." },
    { 'ident', 'Identifiants manquants', 'kick', "À la connexion : un identifiant exigé (Discord, Steam…) est absent." },
    { 'dmg_modifier', 'Modificateur de dégâts du client', 'log', "Le client a un modificateur de dégâts ou de défense différent de 1." },
    { 'weapon_unlisted', 'Arme en main jamais donnée par un script (wb_shield)', 'kick', "Le joueur tient une arme qu'aucune ressource protégée ne lui a donnée : spawn d'arme d'un menu. Armé seulement après apprentissage." },
    { 'vehicle_unlisted', 'Véhicule créé hors de tout script (wb_shield)', 'kick', "Un véhicule réseau créé par un joueur sans que aucune ressource protégée l'ait annoncé : spawn de véhicule d'un menu. Le véhicule est supprimé. Armé après apprentissage." },
    { 'nui_devtools', "Outils de développement du jeu ouverts", 'log', "Les outils de développement de l'interface (F12 du navigateur intégré) servent à déclencher les fonctions du jeu à la main. Exempté : droit « anticheat.bypass »." },
    { 'super_jump', 'Super saut (serveur)', 'log', "Le serveur lit lui-même que le joueur utilise un super saut." },
    { 'explosion_type', "Type d'explosion impossible en RP", 'kick', "Canon orbital, missile scripté, dirigeable, sous-marin… jamais produit par un jeu de rôle normal." },
    { 'noclip', 'Noclip', 'log', "Déplacement de joueur figé ou sans vitesse (lu par le serveur), ou collision du joueur coupée par du code étranger à tes ressources." },
    { 'freecam', 'Caméra libre ou spectateur', 'log', "Caméra scriptée affichée sans qu'aucune ressource protégée l'ait annoncée, ou caméra très loin du joueur. Mesuré par le client : un cheat averti peut se taire." },
    { 'resource_inject', 'Ressource inconnue côté client', 'log', "Le client charge une ressource que le serveur n'a pas (injection d'un menu ou d'un exécuteur)." },
    { 'client_report', 'Anomalie signalée par le client', 'log', "Santé, armure, vitesse, noclip, invisibilité, caméra libre ou munitions anormales, vérifiés par le client puis recoupés par le serveur." },
}
local KIND = {}
for _, k in ipairs(KINDS) do KIND[k[1]] = k end

local defaults = {
    enabled = true, protected = { 'pb_panel', 'oxmysql' }, auto_restart = true, block_rcon = false,
    hb_timeout = 90, join_grace = 180,
    explosion_max = 4, fire_max = 6, ptfx_max = 30, speed_foot = 45, speed_veh = 140, tp_distance = 400,
    weapons = { 'weapon_rpg', 'weapon_minigun', 'weapon_railgun', 'weapon_hominglauncher', 'weapon_grenadelauncher', 'weapon_compactlauncher', 'weapon_firework', 'weapon_emplauncher', 'weapon_raypistol', 'weapon_railgunxm3' },
    models = { 'cargoplane', 'jet', 'lazer', 'hydra', 'rhino', 'khanjali', 'oppressor', 'oppressor2', 'buzzard', 'annihilator', 'savage', 'akula', 'titan', 'avenger', 'thruster', 'deluxo', 'scarab', 'apc', 'chernobog' },
    dmg_max = 400, hit_range = 900, proj_max = 8, ent_veh_max = 4, ent_ped_max = 8, ent_obj_max = 30, chat_min_gap = 1, chat_burst = 6,
    hp_max = 200, armor_max = 100, noclip_hits = 3,
    name_words = {}, chat_words = {}, veh_boost_pct = 190,
    foot_speed = 25, melee_range = 9, taser_range = 22, fire_rate = 30, aim_min_hits = 25, aim_ratio_pct = 80,
    escalate_n = 0, escalate_win = 600, breaker_n = 3, breaker_win = 600, breaker_pause = 1800, ban_delay = 6, require_idents = { 'license' },
    shot_webhook = '', shot_on = 'kick',
    peds = { 'mp_m_freemode_01', 'mp_f_freemode_01' },
    explosion_types = { 30, 38, 42, 43, 54, 56, 57, 58, 60, 63, 70, 71, 73, 74, 82, 83, 84 },
    projectiles = { 'weapon_rpg', 'weapon_grenadelauncher', 'weapon_hominglauncher', 'weapon_compactlauncher', 'weapon_firework', 'weapon_emplauncher', 'weapon_railgun' },
    honeypots = { 'esx_billing:sendBill', 'esx_society:setJob', 'esx_society:withdrawMoney', 'esx_society:depositMoney', 'esx_policejob:handcuff', 'esx_policejob:putInVehicle', 'esx_policejob:OutVehicle', 'esx_ambulancejob:revive', 'esx_ambulancejob:setDeathStatus', 'esx_jobs:caution', 'esx_status:set', 'esx_skin:responseSaveSkin', 'esx_vehicleshop:setVehicleOwned', 'esx_vehicleshop:setVehicleOwnedPlayerId', 'esx_garage:setParking', 'esx_mechanicjob:onNPCJobCompleted', 'esx_pizza:pay', 'esx_garbagejob:pay', 'esx_truckerjob:pay', 'esx_gopostaljob:pay', 'esx_carthief:pay', 'esx_fueldelivery:pay', 'esx_dmvschool:pay', 'esx_drugs:startHarvestWeed', 'esx_drugs:startTransformWeed', 'esx_drugs:startSellWeed', 'esx_blanchisseur:startWhitening', 'esx:giveInventoryItem', 'esx:removeInventoryItem', 'esx:onPickup', 'esx:updateLastPosition', 'QBCore:Server:SetMetaData', 'QBCore:Server:AddItem', 'QBCore:Server:RemoveItem', 'QBCore:Server:UpdateObject', 'qb-bossmenu:server:withdrawMoney', 'qb-bossmenu:server:depositMoney', 'qb-banking:server:giveCash', 'qb-banking:server:transfer', 'qb-drugs:server:updateDealerItems', 'qb-houses:server:buyHouse', 'qb-vehicleshop:server:buyShowroomVehicle', 'qb-garbagejob:server:payShift', 'qb-trucker:server:01', 'qb-ambulancejob:server:RespawnAtHospital', 'qb-policejob:server:CuffPlayer', 'AdminMenu:giveCash', 'AdminMenu:giveBank', 'AdminMenu:giveDirtyMoney', 'adminmenu:allowall', 'vrp:giveMoney', 'vrp:removeMoney', 'vrp_slotmachine:server:2', 'lscustoms:payGarage', 'LegacyFuel:PayFuel', 'bank:deposit', 'bank:withdraw', 'bank:transfer', 'paycheck:salary', 'mission:completed', 'truckerJob:success', 'ems:revive', 'DiscordBot:playerDied', 'pb_ac:giveMoney', 'pb_ac:setAdmin', 'pb_ac:giveItem', 'qb-admin:server:Spectate', 'wb_ac:giveMoney', 'wb_ac:setGroup' },
}
for _, k in ipairs(KINDS) do defaults['mode_' .. k[1]] = k[3] end
PB.Cfg.Define('anticheat', defaults)
local function cfg(k) return PB.Cfg.Get('anticheat', k, defaults[k]) end

local function now() return os.time() end
local function hash(s) local h = 5381 for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end return h end
-- Ressources que personne ne doit pouvoir arrêter : ta liste + le noyau (panel et bouclier), quoi que dise la configuration
local function protList(client)
    local out, seen = {}, {}
    for _, r in ipairs(cfg('protected') or {}) do r = tostring(r) if not seen[r:lower()] then seen[r:lower()] = true out[#out + 1] = r end end
    for _, r in ipairs({ 'pb_panel', 'wb_shield' }) do
        if not seen[r] and not (client and r == 'wb_shield') and GetResourceState(r) ~= 'missing' then seen[r] = true out[#out + 1] = r end   -- wb_shield n'a aucun script client : pas de contrôle côté joueur
    end
    return out
end
local function listSet(l) local t = {} for _, v in ipairs(l or {}) do t[tostring(v):lower()] = true end return t end
local function modelHash(n) return GetHashKey and GetHashKey(n) or n end

-- Qui est exempté -------------------------------------------------------------------------------------------------------------------------
function AC.Bypass(src)
    if not src or src <= 0 then return true end
    return P.Has(src, 'anticheat.bypass') and true or false
end
function AC.Grace(src, secs)
    local t = AC.track[tonumber(src) or -1]
    if t then t.grace = math.max(t.grace or 0, now() + (tonumber(secs) or 10)) end
end
local function inGrace(t) return t and (t.grace or 0) > now() end

-- Alertes ----------------------------------------------------------------------------------------------------------------------------------
local function idents(src)
    local t = {}
    for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do if not id:match('^ip:') then t[#t + 1] = id end end
    return t
end

-- Coupe-circuit : une détection qui touche plusieurs joueurs différents en peu de temps vient d'un réglage ou d'un bug, pas de tricheurs.
AC.breaker = {}
function AC.Tripped(kind)
    local b = AC.breaker[kind]
    return b and (b.untilT or 0) > now() or false
end
local function breaker(src, kind, mode)
    if kind == 'honeypot' or (mode ~= 'kick' and mode ~= 'ban') or src <= 0 then return AC.Tripped(kind) end
    local b = AC.breaker[kind] or { pl = {} }
    AC.breaker[kind] = b
    local n, win = now(), tonumber(cfg('breaker_win')) or 600
    b.pl[src] = n
    local c = 0
    for k, at in pairs(b.pl) do if n - at <= win then c = c + 1 else b.pl[k] = nil end end
    if c >= (tonumber(cfg('breaker_n')) or 3) and not AC.Tripped(kind) then
        b.untilT = n + (tonumber(cfg('breaker_pause')) or 1800)
        pcall(function() PB.Audit.Log('securite', 'anticheat.coupe_circuit', src, kind .. ' : ' .. c .. ' joueurs en ' .. win .. ' s') end)
        pcall(function() if PB.Notify then PB.Notify('error', 'Anticheat : coupe-circuit', ('« %s » a touché %d joueurs différents en peu de temps : sanctions suspendues (journal seulement). Vérifie ce réglage.'):format(KIND[kind] and KIND[kind][2] or kind, c), 'anticheat.view') end end)
    end
    return AC.Tripped(kind)
end

-- Escalade : plusieurs détections DIFFÉRENTES sur le même joueur dans la fenêtre => sanction, même si chacune est en « Journaliser ».
function AC.Escalate(src, kind, mode, exempt)
    if kind == 'escalation' or kind == 'heartbeat' or kind == 'resource_stop' or exempt or src <= 0 then return end
    local t = AC.track[src]
    if not t then return end
    local n, win = now(), tonumber(cfg('escalate_win')) or 600
    t.hist = t.hist or {}
    t.hist[kind] = n
    local kinds = {}
    for k, at in pairs(t.hist) do if n - at <= win then kinds[#kinds + 1] = k else t.hist[k] = nil end end
    local need = tonumber(cfg('escalate_n')) or 3
    if need > 0 and #kinds >= need then
        t.hist = {}
        table.sort(kinds)
        AC.Flag(src, 'escalation', table.concat(kinds, ', '))
    end
end

-- Enregistre une détection puis applique le mode réglé. Retourne le mode réellement appliqué.
AC.recent, AC.cstopAt = {}, {}
local STRONG = { honeypot = true, event_token = true, event_args = true, event_flood = true, resource_stop = true, nui_devtools = true, resource_inject = true, client_report = true }
function AC.Flag(src, kind, detail)
    local def = KIND[kind]
    if STRONG[kind] and tonumber(src) and src > 0 then AC.recent[src] = { kind = kind, at = now() } end
    if not def or cfg('enabled') == false then return 'off' end
    local mode = cfg('mode_' .. kind) or def[3]
    if mode == 'off' then return 'off' end
    src = tonumber(src) or 0
    local name = (src > 0 and GetPlayerName and GetPlayerName(src)) or G.Tag(src)
    local exempt = AC.Bypass(src)
    if exempt or mode == 'log' then mode = 'log' end
    local wanted = mode
    if breaker(src, kind, wanted) and (mode == 'kick' or mode == 'ban') then mode = 'log' detail = (tostring(detail or '') .. ' [coupe-circuit : sanction suspendue]') end
    detail = tostring(detail or ''):gsub('[%c]', ' '):sub(1, 160)
    local alert = { at = now(), src = src, name = name, kind = kind, label = def[2], detail = detail, mode = mode, exempt = exempt or nil }
    table.insert(AC.alerts, 1, alert)
    if #AC.alerts > 200 then table.remove(AC.alerts) end
    AC.counts[mode] = (AC.counts[mode] or 0) + 1
    local t = AC.track[src]
    if t then t.flags = (t.flags or 0) + 1 end
    pcall(function() PB.Audit.Log('securite', 'anticheat.' .. kind, src, detail ~= '' and detail or def[2], nil, { mode = mode, exempt = exempt or false }) end)
    pcall(function() if PB.Notify then PB.Notify(mode == 'ban' and 'error' or 'warn', 'Anticheat : ' .. def[2], ('%s (%s) — %s'):format(name, G.Tag(src), detail ~= '' and detail or def[2]), 'anticheat.view') end end)
    -- détail complet pour le journal des expulsions : détection, valeur mesurée, réglage, exemption
    local full = ('Détection « %s » (%s). Mesure : %s. Réglage : %s.'):format(def[2], kind, detail ~= '' and detail or '—', mode)
    local function act()
        if src > 0 and mode == 'kick' then
            PB.Drop(src, 'kick', 'anticheat', 'Anticheat : ' .. def[2] .. (detail ~= '' and (' (' .. detail .. ')') or '') .. '.', full)
        elseif src > 0 and mode == 'ban' then
            local S = G.Staff
            local pl = G.Get and G.Get(src)
            local lic = pl and pl.license or (GetPlayerIdentifiers(src) or {})[1] or ''
            local id = S and S.AddSanction and S.AddSanction('ban', lic, name, 'Anticheat : ' .. def[2], 0, 0, idents(src))
            local row = id and PB.DB.one('SELECT reason, expires FROM pb_sanctions WHERE id = ?', { id })
            PB.Drop(src, 'ban', 'anticheat', 'Anticheat : ' .. def[2] .. (detail ~= '' and (' (' .. detail .. ')') or '') .. '.', full .. (id and (' Ban n°' .. id .. '.') or ''), nil,
                (S and S.BanText and row) and S.BanText(row) or nil)
        end
    end
    local run = act
    local delay = tonumber(cfg('ban_delay')) or 0
    if mode == 'ban' and kind ~= 'honeypot' and kind ~= 'resource_kill' and delay > 0 and src > 0 then
        run = function()
            SetTimeout(delay * 1000, function()
                if AC.Tripped(kind) then
                    pcall(function() PB.Audit.Log('securite', 'anticheat.ban_annule', src, kind .. ' : coupe-circuit déclenché pendant le délai') end)
                elseif GetPlayerName(src) == name then act() end
            end)
        end
    end
    if src > 0 and mode ~= 'off' and AC.Shot then AC.Shot(src, kind, detail, mode, run) else run() end
    AC.Escalate(src, kind, mode, exempt)
    return mode
end

-- Compteur glissant : retourne le nombre d'évènements du même type dans la fenêtre.
local function bump(src, key, win)
    local t = AC.track[src]
    if not t then return 0 end
    t.rate = t.rate or {}
    local r = t.rate[key]
    local n = now()
    if not r or n - r.t0 >= win then r = { t0 = n, n = 0 } t.rate[key] = r end
    r.n = r.n + 1
    return r.n
end

AC.bump = bump
AC.Hash = hash
AC.ModeOf = function(kind) return cfg('mode_' .. kind) or (KIND[kind] and KIND[kind][3]) or 'off' end
AC.Tracked = function(src) src = tonumber(src) return src and AC.track[src] and src or nil end
AC.Cancel = function() if CancelEvent then CancelEvent() end end
AC.Cfg = function(k) return PB.Cfg.Get('anticheat', k, defaults[k]) end

-- Suivi des joueurs ------------------------------------------------------------------------------------------------------------------------
local function begin(src)
    src = tonumber(src)
    if not src or src <= 0 then return end
    local sec = tostring(math.random(100000, 999999)) .. tostring(math.random(100000, 999999))
    AC.track[src] = { sec = sec, since = now(), lastPong = now(), grace = now() + (tonumber(cfg('join_grace')) or 120), seq = 0, flags = 0 }
    local list = protList(true)
    TriggerClientEvent('pb:ac:hello', src, sec, list)
end
local function resendHello(src, t)
    local list = protList(true)
    t.hellos = (t.hellos or 0) + 1
    TriggerClientEvent('pb:ac:hello', src, t.sec, list)
end
RegisterNetEvent('pb:clientReady', function() begin(source) end)
-- le client redemande son code s'il ne l'a pas reçu (message arrivé pendant le chargement)
RegisterNetEvent('pb:ac:need', function()
    local src = source
    local t = AC.track[src]
    if t and (t.hellos or 0) < 20 then resendHello(src, t) end
end)
-- redémarrage d'une ressource protégée depuis txAdmin ou la console : tous les clients la voient s'arrêter, ce n'est pas de la triche
AddEventHandler('onResourceStop', function(res) AC.expected[res] = now() + 90 end)
AddEventHandler('onResourceStart', function(res) AC.expected[res] = now() + 90 end)
AddEventHandler('playerDropped', function() AC.track[source] = nil end)

RegisterNetEvent('pb:ac:pong', function(seq, tok)
    local src = source
    local t = AC.track[src]
    if not t or not t.asked then return end
    local q = t.asked[tonumber(seq) or -1]
    if not q then return end                                   -- question trop ancienne : ignorée (jamais sanctionnée)
    if tonumber(tok) ~= hash(q .. t.sec) then
        t.bad = (t.bad or 0) + 1
        -- un code faux peut venir d'un code renvoyé entre-temps : on redonne le code et on ne sanctionne qu'après 3 erreurs d'affilée
        if t.bad >= 3 then AC.Flag(src, 'heartbeat', ('réponse invalide au pouls (%d fois de suite)'):format(t.bad)) t.bad = 0
        else resendHello(src, t) end
        return
    end
    t.asked[tonumber(seq)] = nil
    t.bad = 0
    t.ever = true
    t.lastPong = now()
    t.misses = 0
end)

RegisterNetEvent('pb:ac:cstop', function(res)
    local src = source
    res = tostring(res or '')
    if not AC.track[src] or not listSet(protList(true))[res:lower()] then return end
    -- l'arrêt est normal si le serveur a lui-même arrêté la ressource (ou va la redémarrer)
    if (AC.expected[res] or 0) > now() then return end
    if GetResourceState(res) ~= 'started' then return end
    AC.cstopAt[src] = { res = res, at = now() }
    AC.Flag(src, 'resource_stop', 'ressource arrêtée côté client : ' .. res)
end)

-- Pouls : une question par joueur toutes les ~15 s, la réponse est vérifiée. `n` = heure courante (testable).
function AC.Step(n)
    n = n or now()
    local timeout = tonumber(cfg('hb_timeout')) or 60
    for src, t in pairs(AC.track) do
        if t.pending and t.pending.at then
            -- sans réponse à la question précédente, le compteur de silence continue
        end
        if (t.grace or 0) <= n and (n - (t.lastPong or n)) > timeout then
            if not t.ever and (t.hellos or 0) < 4 then
                -- jamais répondu : le code s'est sûrement perdu pendant le chargement, on le renvoie au lieu de sanctionner
                resendHello(src, t)
                t.lastPong = n
            else
                local ping = (GetPlayerPing and GetPlayerPing(src)) or 0
                AC.Flag(src, 'heartbeat', ('aucune réponse depuis %d s (seuil %d s), ping %d ms, %s'):format(n - (t.lastPong or n), timeout, ping,
                    t.ever and 'le script répondait avant puis s\'est tu' or ('jamais répondu malgré %d envois du code'):format(t.hellos or 0)))
                t.lastPong = n
            end
        end
        if AC.track[src] == t then
            t.seq = (t.seq or 0) + 1
            t.asked = t.asked or {}
            t.asked[t.seq] = tostring(math.random(100000, 999999))
            t.asked[t.seq - 3] = nil                              -- on garde les 3 dernières questions
            t.pending = { seq = t.seq, nonce = t.asked[t.seq], at = n }
            TriggerClientEvent('pb:ac:ping', src, t.seq, t.asked[t.seq])
        end
    end
end
CreateThread(function()
    Wait(math.random(0, 15000))   -- tâches périodiques étalées (pas toutes à la même seconde)
    while true do
        Wait(15000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            if cfg('enabled') ~= false then pcall(AC.Step) end
        end)
        if not ok then PB.Warn('anticheat', 'boucle : ' .. tostring(err)) end
    end
end)

-- Comportement : invincibilité et déplacements impossibles (lecture serveur, nécessite OneSync) ----------------------------------------
function AC.Behave(n)
    n = n or now()
    if cfg('enabled') == false then return end
    local S = G.Staff
    for src, t in pairs(AC.track) do
        local ped = GetPlayerPed and GetPlayerPed(src) or 0
        if ped and ped ~= 0 and not inGrace(t) and not (S and S.OnDuty and S.OnDuty(src)) then
            local pl = G.Get and G.Get(src)
            -- à terre, l'écran de mort rend le joueur invincible : ce n'est pas de la triche
            if GetPlayerInvincible and GetPlayerInvincible(src) and pl and PB.ToBool(pl.row.created) and not PB.ToBool(pl.row.dead) then
                t.god = (t.god or 0) + 1
                if t.god >= 3 then t.god = 0 AC.Flag(src, 'godmode', 'joueur invincible') end
            else t.god = 0 end
            local c = GetEntityCoords(ped)
            if c and t.last and n > t.last.t then
                local dt = n - t.last.t
                local d = math.sqrt((c.x - t.last.x) ^ 2 + (c.y - t.last.y) ^ 2 + (c.z - t.last.z) ^ 2)
                local veh = GetVehiclePedIsIn and GetVehiclePedIsIn(ped, false) or 0
                local limit = (veh and veh ~= 0) and (tonumber(cfg('speed_veh')) or 140) or (tonumber(cfg('speed_foot')) or 45)
                if d > (tonumber(cfg('tp_distance')) or 400) and d / dt > limit then
                    t.tp = (t.tp or 0) + 1
                    if t.tp >= 2 then t.tp = 0 AC.Flag(src, 'teleport', ('%d m en %d s'):format(math.floor(d), dt)) end
                else t.tp = 0 end
            end
            t.last = c and { x = c.x, y = c.y, z = c.z, t = n } or nil
        else
            t.last = nil
        end
    end
end
CreateThread(function()
    while true do
        Wait(2000)
        local ok, err = pcall(function()   -- (v1.2.96) une erreur ne coupe plus la boucle
            pcall(AC.Behave)
        end)
        if not ok then PB.Warn('anticheat', 'boucle : ' .. tostring(err)) end
    end
end)

-- Évènements natifs ------------------------------------------------------------------------------------------------------------------------
local function cancel() if CancelEvent then CancelEvent() end end
local function tracked(src) src = tonumber(src) return src and AC.track[src] and src or nil end

AddEventHandler('explosionEvent', function(sender, ev)
    local src = tracked(sender)
    if not src or cfg('enabled') == false or AC.Bypass(src) then return end
    ev = ev or {}
    local n = bump(src, 'explosion', 10)
    if ev.isInvisible == true or n > (tonumber(cfg('explosion_max')) or 4) then
        cancel()
        AC.Flag(src, 'explosion', ev.isInvisible and 'explosion invisible' or ('%d explosions en 10 s'):format(n))
    end
end)

AddEventHandler('fireEvent', function(sender)
    local src = tracked(sender)
    if not src or cfg('enabled') == false or AC.Bypass(src) then return end
    if bump(src, 'fire', 10) > (tonumber(cfg('fire_max')) or 6) then cancel() AC.Flag(src, 'fire', 'feux en rafale') end
end)

AddEventHandler('ptFxEvent', function(sender)
    local src = tracked(sender)
    if not src or cfg('enabled') == false or AC.Bypass(src) then return end
    local n = bump(src, 'ptfx', 10)
    if n > (tonumber(cfg('ptfx_max')) or 30) then cancel() if n == (tonumber(cfg('ptfx_max')) or 30) + 1 then AC.Flag(src, 'ptfx', 'particules en rafale') end end
end)

local function ownerOfNet(netId)
    if not netId or not NetworkGetEntityFromNetworkId then return nil end
    local e = NetworkGetEntityFromNetworkId(netId)
    if not e or e == 0 then return nil end
    return NetworkGetEntityOwner and NetworkGetEntityOwner(e) or nil
end
AddEventHandler('giveWeaponEvent', function(sender, data)
    local src = tracked(sender)
    if not src or cfg('enabled') == false or AC.Bypass(src) or type(data) ~= 'table' or data.givenAsPickup then return end
    local owner = ownerOfNet(data.pedId)
    if owner and owner ~= src then cancel() AC.Flag(src, 'give_weapon', 'arme donnée à #' .. tostring(owner)) end
end)
AddEventHandler('clearPedTasksEvent', function(sender, data)
    local src = tracked(sender)
    if not src or cfg('enabled') == false or AC.Bypass(src) or type(data) ~= 'table' then return end
    local owner = ownerOfNet(data.pedId)
    if owner and owner ~= src then cancel() AC.Flag(src, 'clear_tasks', 'tâches annulées sur #' .. tostring(owner)) end
end)

local bw
local function badWeapons()
    if not bw then bw = {} for _, w in ipairs(cfg('weapons') or {}) do bw[modelHash(tostring(w):lower())] = tostring(w):lower() end end
    return bw
end
AddEventHandler('weaponDamageEvent', function(sender, data)
    local src = tracked(sender)
    if not src or cfg('enabled') == false or AC.Bypass(src) or type(data) ~= 'table' then return end
    local name = badWeapons()[data.weaponType]
    if name then cancel() AC.Flag(src, 'weapon', 'arme interdite : ' .. name) end
end)

local bm
local function badModels()
    if not bm then bm = {} for _, m in ipairs(cfg('models') or {}) do bm[modelHash(tostring(m):lower())] = tostring(m):lower() end end
    return bm
end
PB.Cfg.OnChange('anticheat', function() bw, bm = nil, nil end)
AddEventHandler('entityCreating', function(ent)
    if cfg('enabled') == false or not ent or not GetEntityModel then return end
    local owner = NetworkGetEntityOwner and NetworkGetEntityOwner(ent) or nil
    local src = tracked(owner)
    if not src or AC.Bypass(src) then return end
    local name = badModels()[GetEntityModel(ent)]
    if name then cancel() AC.Flag(src, 'entity', 'modèle interdit : ' .. name) end
end)

-- Évènements pièges : aucun script légitime ne les appelle ; on n'en pose pas si une ressource de ce nom tourne ---------------------------
function AC.Honey()
    for _, ev in ipairs(cfg('honeypots') or {}) do
        ev = tostring(ev)
        local resName = ev:match('^([^:]+):')
        local fw = (ev:find('^esx') and GetResourceState('es_extended') == 'started') or (ev:find('^QBCore') and GetResourceState('qb-core') == 'started') or (ev:find('^qb%-') and GetResourceState('qb-core') == 'started')
        if not fw and not AC.honey[ev] and ev:match('^[%w_%-%.:]+$') and not (resName and GetResourceState and (GetResourceState(resName) == 'started' or GetResourceState(resName) == 'starting')) then
            AC.honey[ev] = true
            RegisterNetEvent(ev, function() AC.Flag(source, 'honeypot', ev) end)
        end
    end
end
PB.OnReady(function() AC.Honey() end)
PB.Cfg.OnChange('anticheat', function() AC.Honey() end)

-- Ressources protégées : arrêt côté serveur ------------------------------------------------------------------------------------------------
function AC.Expect(res, secs) AC.expected[tostring(res)] = now() + (tonumber(secs) or 30) end
exports('AntiCheatExpect', function(res, secs) AC.Expect(res, secs) end)
exports('AntiCheatGrace', function(src, secs) AC.Grace(src, secs) end)
exports('AntiCheatFlag', function(src, kind, detail) return AC.Flag(src, kind, detail) end)

AddEventHandler('onResourceStop', function(res)
    if cfg('enabled') == false or res == GetCurrentResourceName() then return end
    if not listSet(protList())[tostring(res):lower()] then return end
    if (AC.expected[res] or 0) > now() then return end
    pcall(function() PB.Audit.Log('securite', 'anticheat.resource_stop_server', 0, tostring(res), nil, { restart = cfg('auto_restart') ~= false }) end)
    pcall(function() if PB.Notify then PB.Notify('error', 'Anticheat : ressource protégée arrêtée', tostring(res) .. ' a été arrêtée.' .. (cfg('auto_restart') ~= false and ' Redémarrage automatique.' or ''), 'anticheat.view') end end)
    table.insert(AC.alerts, 1, { at = now(), src = 0, name = 'Serveur', kind = 'resource_stop', label = 'Ressource protégée arrêtée', detail = tostring(res), mode = cfg('auto_restart') ~= false and 'restart' or 'log' })
    -- Qui l'a arrêtée ? Seulement les joueurs avec une détection forte dans les 6 s qui précèdent, ou qui l'ont coupée chez eux : jamais un joueur « au hasard ».
    local culprits, n = {}, now()
    for src, r in pairs(AC.recent) do
        if n - r.at <= 6 and AC.track[src] then culprits[#culprits + 1] = { src = src, why = 'détection « ' .. r.kind .. ' » il y a ' .. (n - r.at) .. ' s' } end
    end
    for src, r in pairs(AC.cstopAt) do
        if r.res == tostring(res) and n - r.at <= 90 and AC.track[src] then culprits[#culprits + 1] = { src = src, why = 'l\'a coupée chez lui' } end
    end
    local done = {}
    for _, c in ipairs(culprits) do
        if not done[c.src] then
            done[c.src] = true
            pcall(function() AC.Flag(c.src, 'resource_kill', tostring(res) .. ' arrêtée : ' .. c.why) end)
        end
    end
    if cfg('auto_restart') ~= false then
        SetTimeout(0, function()
            if GetResourceState(res) == 'stopped' and GetResourceState(GetCurrentResourceName()) == 'started' then ExecuteCommand('start ' .. res) end
        end)
    end
end)

AddEventHandler('rconCommand', function(cmd, args)
    if cfg('enabled') == false or cfg('block_rcon') ~= true then return end
    cmd = tostring(cmd or ''):lower()
    if (cmd == 'stop' or cmd == 'restart') and args and args[1] and listSet(protList())[tostring(args[1]):lower()] then
        cancel()
        pcall(function() PB.Audit.Log('securite', 'anticheat.rcon_blocked', 0, cmd .. ' ' .. tostring(args[1])) end)
        if RconPrint then RconPrint('Anticheat : ' .. tostring(args[1]) .. " est protégée, commande refusée.\n") end
    end
end)

-- Panel -------------------------------------------------------------------------------------------------------------------------------------
local modeFields = {}
for _, k in ipairs(KINDS) do modeFields[#modeFields + 1] = { k = 'mode_' .. k[1], type = 'select', label = k[2], default = k[3], opts = MODES, hint = k[4] } end
table.insert(modeFields, 1, { k = 'enabled', type = 'toggle', label = "Anticheat actif", default = true })

local modes = Form.Cfg({ ns = 'anticheat', id = 'modes', title = 'Que faire à chaque détection', perm = 'anticheat.edit', cols = 2,
    desc = "Les joueurs avec le droit « Exempté de l'anticheat » sont seulement journalisés, jamais sanctionnés. Commence par « Journaliser » pour les détections de comportement, puis durcis.", fields = modeFields })
local limits = Form.Cfg({ ns = 'anticheat', id = 'limits', title = 'Seuils', perm = 'anticheat.edit', cols = 2, fields = {
    { k = 'hb_timeout', type = 'number', label = 'Silence toléré du script client (s)', default = 60, min = 30, max = 600 },
    { k = 'join_grace', type = 'number', label = 'Délai de grâce à la connexion (s)', default = 120, min = 30, max = 600 },
    { k = 'explosion_max', type = 'number', label = 'Explosions max par 10 s', default = 4, min = 1, max = 50 },
    { k = 'fire_max', type = 'number', label = 'Feux max par 10 s', default = 6, min = 1, max = 100 },
    { k = 'ptfx_max', type = 'number', label = 'Particules max par 10 s', default = 30, min = 5, max = 500 },
    { k = 'speed_foot', type = 'number', label = 'Vitesse impossible à pied (m/s)', default = 45, min = 10, max = 200 },
    { k = 'speed_veh', type = 'number', label = 'Vitesse impossible en véhicule (m/s)', default = 140, min = 40, max = 400 },
    { k = 'tp_distance', type = 'number', label = 'Distance minimale d\'un « téléport » (m)', default = 400, min = 100, max = 5000 },
    { k = 'dmg_max', type = 'number', label = 'Dégâts max par coup avant « dégâts truqués »', default = 400, min = 100, max = 5000 },
    { k = 'hit_range', type = 'number', label = 'Portée max d\'un tir (m)', default = 900, min = 300, max = 5000 },
    { k = 'proj_max', type = 'number', label = 'Projectiles max par 10 s', default = 8, min = 1, max = 100 },
    { k = 'ent_veh_max', type = 'number', label = 'Véhicules créés max par 10 s et par joueur', default = 4, min = 1, max = 50 },
    { k = 'ent_ped_max', type = 'number', label = 'Peds créés max par 10 s et par joueur', default = 8, min = 1, max = 100 },
    { k = 'ent_obj_max', type = 'number', label = 'Objets créés max par 10 s et par joueur', default = 30, min = 1, max = 300 },
    { k = 'chat_burst', type = 'number', label = 'Messages de chat max par 10 s', default = 6, min = 2, max = 50 },
    { k = 'hp_max', type = 'number', label = 'Santé maximale plausible', default = 200, min = 100, max = 1000 },
    { k = 'veh_boost_pct', type = 'number', label = 'Vitesse max du véhicule (% du maximum de son modèle)', default = 190, min = 120, max = 500 },
    { k = 'foot_speed', type = 'number', label = 'Vitesse à pied soutenue max (m/s)', default = 25, min = 8, max = 40 },
    { k = 'melee_range', type = 'number', label = 'Portée max d\'un coup de mêlée (m)', default = 9, min = 4, max = 30 },
    { k = 'taser_range', type = 'number', label = 'Portée max du taser (m)', default = 22, min = 10, max = 60 },
    { k = 'fire_rate', type = 'number', label = 'Coups max par seconde et par joueur', default = 30, min = 5, max = 60 },
    { k = 'aim_min_hits', type = 'number', label = 'Touches minimum avant d\'évaluer la précision', default = 25, min = 10, max = 200 },
    { k = 'aim_ratio_pct', type = 'number', label = 'Part de têtes suspecte (%)', default = 80, min = 50, max = 100 },
    { k = 'escalate_n', type = 'number', label = 'Détections différentes avant sanction (0 = jamais)', default = 0, min = 0, max = 20 },
    { k = 'breaker_n', type = 'number', label = 'Coupe-circuit : joueurs différents détectés avant de suspendre les sanctions de ce type', default = 3, min = 2, max = 20, hint = "Si plusieurs joueurs sont détectés pour la même chose en quelques minutes, c'est presque sûrement un bug de réglage : les sanctions de ce type passent en « Journaliser »." },
    { k = 'breaker_win', type = 'number', label = 'Coupe-circuit : fenêtre (s)', default = 600, min = 60, max = 3600 },
    { k = 'breaker_pause', type = 'number', label = 'Coupe-circuit : durée de la suspension (s)', default = 1800, min = 60, max = 86400 },
    { k = 'ban_delay', type = 'number', label = 'Délai avant un bannissement (s) — laisse le coupe-circuit voir les détections simultanées', default = 6, min = 0, max = 60 },
    { k = 'escalate_win', type = 'number', label = 'Fenêtre de cumul (s)', default = 600, min = 60, max = 7200 },
    { k = 'armor_max', type = 'number', label = 'Armure maximale plausible', default = 100, min = 50, max = 1000 },
} })
local protect = Form.Cfg({ ns = 'anticheat', id = 'protect', title = 'Ressources protégées', perm = 'anticheat.edit', cols = 1, fields = {
    { k = 'protected', type = 'list', label = 'Ressources que personne ne doit pouvoir arrêter', default = { 'pb_panel', 'oxmysql' }, maxitems = 40, maxlen = 64, pattern = '^[%w_%-%.%[%]]+$', wide = true },
    { k = 'auto_restart', type = 'toggle', label = 'Redémarrer automatiquement une ressource protégée arrêtée', default = true, hint = "Ne s'applique pas au panel lui-même (arrêté, il ne peut plus rien faire)." },
    { k = 'block_rcon', type = 'toggle', label = 'Refuser stop / restart sur ces ressources en rcon', default = false, hint = "La console du serveur et txAdmin ne passent pas par là : ils gardent la main." },
} })
local lists = Form.Cfg({ ns = 'anticheat', id = 'lists', title = 'Listes noires', perm = 'anticheat.edit', cols = 1, fields = {
    { k = 'weapons', type = 'list', label = "Armes interdites (nom d'arme, ex. weapon_rpg)", default = defaults.weapons, maxitems = 80, maxlen = 48, pattern = '^[%w_]+$', wide = true },
    { k = 'models', type = 'list', label = 'Modèles interdits à la création par un joueur (véhicules, objets, peds)', default = defaults.models, maxitems = 150, maxlen = 48, pattern = '^[%w_]+$', wide = true },
    { k = 'projectiles', type = 'list', label = 'Projectiles interdits (nom d\'arme)', default = defaults.projectiles, maxitems = 60, maxlen = 48, pattern = '^[%w_]+$', wide = true },
    { k = 'explosion_types', type = 'list', label = "Types d'explosion interdits (numéros du jeu)", default = defaults.explosion_types, maxitems = 100, maxlen = 3, pattern = '^%d+$', wide = true, hint = "30 dirigeable · 42 Valkyrie · 43 défense aérienne · 54/56/57/58 canons · 60 canon orbital · 63 Oppressor · 70 drone · 71 rayon · 73/82 missile scripté · 74 char RC · 83 sous-marin · 84 EMP." },
    { k = 'peds', type = 'list', label = 'Modèles de joueur autorisés (ped)', default = defaults.peds, maxitems = 200, maxlen = 48, pattern = '^[%w_]+$', wide = true, hint = "Tout autre ped est signalé « Modèle de joueur changé » (hors staff en service)." },
    { k = 'require_idents', type = 'list', label = 'Identifiants exigés à la connexion (license, discord, steam, fivem…)', default = { 'license' }, maxitems = 8, maxlen = 16, pattern = '^[%a]+$', wide = true },
    { k = 'shot_webhook', type = 'text', label = 'Webhook Discord pour les captures d\'écran (vide = désactivé)', default = '', maxlen = 300, pattern = '^$|^https://[^%s]+$', wide = true, hint = "Nécessite la ressource screenshot-basic démarrée. Une capture est envoyée à chaque détection sanctionnée (jamais plus d'une par minute et par joueur)." },
    { k = 'shot_on', type = 'select', label = 'Capturer quand', default = 'kick', opts = { { 'kick', 'Expulsion ou bannissement seulement' }, { 'all', 'Toute détection (y compris journal)' } } },
    { k = 'name_words', type = 'list', label = 'Mots interdits dans un pseudo', default = {}, maxitems = 200, maxlen = 32, wide = true },
    { k = 'chat_words', type = 'list', label = 'Mots interdits dans le chat', default = {}, maxitems = 200, maxlen = 32, wide = true },
    { k = 'honeypots', type = 'list', label = 'Évènements pièges (jamais appelés par un script légitime)', default = defaults.honeypots, maxitems = 60, maxlen = 80, pattern = '^[%w_%-%.:]+$', wide = true, hint = "Un évènement est ignoré si une ressource du même préfixe tourne. Prends-en d'autres qui n'existent pas chez toi." },
} })

PB.Action('anticheat.clear', 'anticheat.edit', function(ctx)
    AC.alerts = {}
    ctx.audit('securite', 'anticheat.vider', 'alertes en mémoire')
    ctx.toast = 'Liste vidée (le journal complet reste dans Logs).'
    return true
end, { critical = true, confirm = { title = 'Vider les alertes affichées ?', text = 'Le journal permanent n\'est pas touché.' } })


-- Profils : un clic règle tous les modes. Les détections statistiques (distance, cadence, précision, vitesse, santé) restent en journal dans tous les profils.
local PRESETS = {
    safe = { label = 'Prudent', ban = { 'honeypot' }, kick = {}, },
    strict = { label = 'Strict (recommandé)', ban = { 'honeypot', 'event_token', 'resource_kill', 'weapon_unlisted', 'vehicle_unlisted' }, kick = { 'event_args', 'noclip', 'freecam', 'nui_devtools', 'explosion_type', 'heartbeat', 'resource_stop', 'explosion', 'entity', 'weapon', 'projectile', 'give_weapon', 'clear_tasks', 'remove_weapons', 'fire', 'weapon_held', 'name', 'ident', 'entity_spam' } },
    max = { label = 'Implacable', ban = { 'honeypot', 'event_token', 'resource_kill', 'event_args', 'weapon_unlisted', 'vehicle_unlisted', 'noclip', 'freecam', 'nui_devtools', 'explosion_type', 'speed_hack', 'weapon', 'projectile', 'entity', 'weapon_held', 'give_weapon', 'clear_tasks', 'remove_weapons', 'explosion', 'fire', 'heartbeat', 'resource_stop', 'entity_spam' }, kick = { 'name', 'ident' } },
}
local function applyPreset(id, actor)
    local pr = PRESETS[id]
    if not pr then return end
    local want = {}
    for _, k in ipairs(pr.ban) do want[k] = 'ban' end
    for _, k in ipairs(pr.kick) do want[k] = 'kick' end
    for _, k in ipairs(KINDS) do
        PB.Cfg.Set('anticheat', 'mode_' .. k[1], want[k[1]] or (k[3] == 'off' and 'off' or 'log'), actor, 'Profil ' .. pr.label)
    end
end
for id, pr in pairs(PRESETS) do
    PB.Action('anticheat.preset_' .. id, 'anticheat.edit', function(ctx)
        applyPreset(id, ctx.actor)
        ctx.audit('securite', 'anticheat.profil', pr.label)
        ctx.toast = 'Profil « ' .. pr.label .. ' » appliqué.'
        return true
    end, { critical = true, confirm = { title = 'Appliquer le profil « ' .. pr.label .. ' » ?', text = "Tous les modes de détection seront remplacés. Les bannissements sont immédiats pour les détections prouvables ; les autres restent en journal." } })
end

local function kindLabel(k) return KIND[k] and KIND[k][2] or k end
PB.Module({
    id = 'anticheat', label = 'Anticheat', icon = 'shield', group = 'Système', order = 171, perm = 'anticheat.view', hint = 'Protections de base, alertes, listes noires',
    caps = function()
        return PB.Capsify({
            { 'Arrêt de tes scripts par un joueur', 'ok', "Détecté côté client puis confirmé par le serveur ; pouls toutes les 15 s : plus de réponse = sanction." },
            { 'Arrêt d\'une ressource par la console', 'partial', "Impossible à empêcher (la console fait foi) : la ressource protégée est redémarrée et l'alerte est écrite. Option rcon pour refuser stop/restart à distance." },
            { 'Explosions, feux, particules, armes et modèles interdits', 'ok', 'Évènements natifs refusés par le serveur et comptés par joueur.' },
            { 'Évènements pièges', 'ok', "Un client qui appelle un évènement inexistant chez toi est un outil de triche." },
            { 'Invincibilité et téléport', 'partial', "Lecture serveur (OneSync) ; faux positifs possibles, donc « Journaliser » par défaut." },
            { 'Dégâts truqués, tirs impossibles, projectiles, désarmement, entités et chat en rafale, pseudos', 'ok', "Évènements natifs refusés par le serveur (mode « Journaliser » pour dégâts et distance tant que tu n'as pas éprouvé les seuils)." },
            { 'Noclip, vitesse, invisibilité, spectateur, super saut, munitions infinies, santé et armure', 'partial', "Mesurés par le client, signés avec le code de session, recoupés par le serveur (3 signalements de suite). Un cheat qui lit le code de session peut les falsifier." },
            { 'Armes et véhicules créés hors de tout script (wb_shield)', 'ok', "Les ressources protégées annoncent chaque arme et véhicule qu'elles créent ; ce qui n'est pas annoncé est un spawn de menu. Armé seulement après apprentissage." },
            { 'Outils de développement de l\'interface ouverts', 'partial', "Mesure par instruction debugger chronométrée, 8 fois de suite ; un cheat peut la contourner. Les joueurs exemptés ne sont jamais sanctionnés." },
            { 'Santé, armure, vitesse à pied, arme en main (lus par le serveur)', 'ok', "Mesures du serveur lui-même : le client ne peut pas les falsifier. Santé/armure/vitesse démarrent en « Journaliser »." },
            { 'Cadence de tir, précision (têtes), mêlée et taser à distance, explosion lointaine', 'partial', "Statistiques sur les évènements de dégâts : indices, pas preuves. Journal seulement par défaut." },
            { 'Escalade', 'ok', "Plusieurs détections différentes sur un même joueur en 10 min déclenchent une sanction, même si chacune est en « Journaliser »." },
            { 'Captures d\'écran sur sanction', 'partial', "Webhook Discord + ressource screenshot-basic (à installer toi-même). La capture retarde la sanction de quelques secondes." },
            { 'Ressources inconnues côté client', 'partial', "Le client envoie sa liste de ressources, le serveur compare : repère les injections qui créent une ressource, pas celles qui s'exécutent sans en créer." },
            { 'Injection de menu, exécuteurs, modifications du jeu', 'off', "Non détectés : un anticheat en Lua ne peut pas voir ce qui s'exécute dans le jeu du joueur. Pour ça il faut un produit dédié." },
            { 'Testé dans un vrai client FiveM', 'off', "Non : vérifié par simulation uniquement. Teste chaque mode avec un compte de test avant de passer en « Bannir »." },
        })
    end,
    doc = "## Anticheat\nProtection de base côté serveur. Chaque détection est écrite dans le journal (catégorie Sécurité) et peut expulser ou bannir. Donne `anticheat.bypass` à ton équipe : elle n'est jamais sanctionnée.\n\nLes téléportations du serveur peuvent être déclarées avec `exports.pb_panel:AntiCheatGrace(source, 10)` ; l'arrêt volontaire d'une ressource protégée avec `exports.pb_panel:AntiCheatExpect('nom', 30)`.",
    view = function(ctx)
        local function tab(id, label, icon, fn, perm) return { id = id, label = label, icon = icon, build = fn, perm = perm } end
        return { tabs = {
            tab('overview', "Vue d'ensemble", 'shield', function()
                local prot, up = cfg('protected') or {}, 0
                for _, r in ipairs(prot) do if GetResourceState(r) == 'started' then up = up + 1 end end
                local online = 0
                for _ in pairs(AC.track) do online = online + 1 end
                return { B.stats({ { label = 'Joueurs surveillés', value = online, icon = 'users' }, { label = 'Ressources protégées actives', value = up .. ' / ' .. #prot, icon = 'lock' },
                        { label = 'Alertes (depuis le démarrage)', value = #AC.alerts, icon = 'alert' }, { label = 'Expulsions / bannissements', value = (AC.counts.kick or 0) .. ' / ' .. (AC.counts.ban or 0), icon = 'skull' } }),
                    B.notice(cfg('enabled') == false and 'warn' or 'info', cfg('enabled') == false and "L'anticheat est désactivé." or "Protection de base active. Elle arrête les cas courants (scripts coupés, évènements pièges, explosions, armes interdites) : elle ne remplace pas un anticheat commercial.", 'État') }
            end),
            tab('alerts', 'Alertes', 'alert', function()
                local rows = {}
                for _, a in ipairs(AC.alerts) do rows[#rows + 1] = { at = a.at, who = (a.src > 0 and (G.Tag(a.src) .. ' ') or '') .. a.name, kind = a.label or kindLabel(a.kind), detail = a.detail, mode = a.exempt and 'exempté' or a.mode } end
                return { B.table({ id = 'acalerts', search = true, columns = { { k = 'at', label = 'Date', type = 'date' }, { k = 'who', label = 'Joueur' }, { k = 'kind', label = 'Détection' }, { k = 'detail', label = 'Détail' }, { k = 'mode', label = 'Réponse', type = 'badge' } }, rows = rows, empty = 'Aucune alerte depuis le démarrage.' }),
                    ctx.has('anticheat.edit') and B.actions({ { action = 'anticheat.clear', label = 'Vider la liste', icon = 'trash', danger = true } }) or nil }
            end),
            tab('players', 'Joueurs', 'users', function()
                local rows = {}
                for src, t in pairs(AC.track) do rows[#rows + 1] = { id = G.UidOf(src) or src, name = GetPlayerName and GetPlayerName(src) or G.Tag(src), pong = now() - (t.lastPong or now()), flags = t.flags or 0, bypass = AC.Bypass(src) and 'oui' or '' } end
                table.sort(rows, function(a, b) return a.id < b.id end)
                return { B.table({ id = 'acplayers', columns = { { k = 'id', label = 'ID' }, { k = 'name', label = 'Joueur' }, { k = 'pong', label = 'Dernière réponse (s)' }, { k = 'flags', label = 'Alertes' }, { k = 'bypass', label = 'Exempté', type = 'badge' } }, rows = rows, empty = 'Personne.' }) }
            end),
            tab('modes', 'Réponses', 'sliders', function()
                return { ctx.has('anticheat.edit') and B.actions({ { action = 'anticheat.preset_safe', label = 'Profil prudent', icon = 'shield' }, { action = 'anticheat.preset_strict', label = 'Profil strict (recommandé)', icon = 'shield' }, { action = 'anticheat.preset_max', label = 'Profil implacable', icon = 'skull', danger = true } }) or nil, modes(ctx), limits(ctx) }
            end, 'anticheat.view'),
            tab('protect', 'Ressources protégées', 'lock', function() return { protect(ctx) } end),
            tab('lists', 'Listes noires', 'skull', function() return { lists(ctx) } end),
        } }
    end,
})

PB.OnReady(function() PB.SelfTest.Add('anticheat: listes valides et ressources vitales protégées', function(R)
    local prot = listSet(cfg('protected'))
    R.check(prot['oxmysql'] or #(cfg('protected') or {}) > 0, 'Anticheat', 'aucune ressource protégée', 'Ajoute au moins oxmysql et le panel dans « Ressources protégées ».')
    R.check(cfg('enabled') ~= false, 'Anticheat', "l'anticheat est désactivé", "Les protections ne s'appliquent plus.")
    for _, k in ipairs(KINDS) do R.check(cfg('mode_' .. k[1]) ~= nil, 'Anticheat', 'mode manquant : ' .. k[1]) end
end) end)

-- Veille mutuelle : si le bouclier est arrêté (par n'importe quoi, même sans évènement), le panel le relance
CreateThread(function()
    local down = 0
    while true do
        Wait(500)
        if cfg('enabled') ~= false and cfg('auto_restart') ~= false and GetResourceState('wb_shield') == 'stopped' and (AC.expected['wb_shield'] or 0) <= now() then
            down = down + 1
            if down >= 2 then
                down = 0
                pcall(function() PB.Audit.Log('securite', 'anticheat.shield_restart', 0, 'wb_shield relancé') end)
                ExecuteCommand('start wb_shield')
            end
        else down = 0 end
    end
end)
